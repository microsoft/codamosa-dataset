

# Generated at 2022-06-21 21:57:22.146625
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # Test for __init__
    assert isinstance(_PyInfo.PY2, bool)
    assert isinstance(_PyInfo.PY3, bool)
    assert isinstance(_PyInfo.string_types, tuple)
    assert isinstance(_PyInfo.text_type, type)
    assert isinstance(_PyInfo.binary_type, type)


# Generated at 2022-06-21 21:57:26.075333
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    logger.info('Unit test for function getLogger')


# Generated at 2022-06-21 21:57:34.190295
# Unit test for function get_config

# Generated at 2022-06-21 21:57:36.486013
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log.info('test')

# Generated at 2022-06-21 21:57:40.044001
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert logger != None
    logger.info("test")


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 21:57:51.656907
# Unit test for function get_config
def test_get_config():
    import yaml


# Generated at 2022-06-21 21:57:55.105514
# Unit test for function getLogger
def test_getLogger():
    try:
        global_namespace = __name__
        get_logger().info("test")
        assert get_logger().name == global_namespace, \
            "Function getLogger should return a logger with the same name as the global namespace"
    except Exception as ex:
        print(ex)


# Generated at 2022-06-21 21:58:01.102419
# Unit test for function get_config
def test_get_config():
    no_config = get_config(config=None, default=None)
    assert no_config is None

    default_config = get_config(config=None)
    assert default_config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=None, env_var='LOGGING')
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING')
    assert config == DEFAULT_CONFIG

    config = {}
    with pytest.raises(ValueError):
        get_config(config, 'LOGGING')

    config = {'name': 'test'}
    with pytest.raises(ValueError):
        get_

# Generated at 2022-06-21 21:58:03.347908
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)

    with logger_level(log, logging.INFO):
        log.info('test')

# Generated at 2022-06-21 21:58:11.287753
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import os

    log = logging.getLogger(__name__)

    # Avoid showing messages in other than important levels
    log.setLevel(logging.WARNING)

    with logger_level(log, logging.CRITICAL):
        log.critical("Critical")
        log.warning("Warning")
        log.info("Info")
        log.debug("Debug")
        log.notset("Notset")

    with logger_level(log, logging.ERROR):
        log.critical("Critical")
        log.warning("Warning")
        log.error("Error")
        log.info("Info")
        log.debug("Debug")
        log.notset("Notset")

    with logger_level(log, logging.WARNING):
        log.critical("Critical")
        log.warning("Warning")
       

# Generated at 2022-06-21 21:58:22.108950
# Unit test for function get_config
def test_get_config():
    # Test config: string -> dict
    config = '{"version": 1, "disable_existing_loggers": False}'
    cfg = get_config(config=config)
    assert cfg == json.loads(config)

    # Test config: bare -> dict
    config = 'version: 1'
    cfg = get_config(config=config)
    assert cfg == yaml.load(config)

    # Test default config
    cfg = get_config(config=None)
    assert cfg == DEFAULT_CONFIG


# Generated at 2022-06-21 21:58:27.600776
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    json_config = json.dumps(DEFAULT_CONFIG)
    yaml_config = yaml.dump(DEFAULT_CONFIG)
    assert get_config(json_config) == DEFAULT_CONFIG
    assert get_config(yaml_config) == DEFAULT_CONFIG
    assert get_config() == DEFAULT_CONFIG

# Generated at 2022-06-21 21:58:34.581276
# Unit test for function get_config
def test_get_config():
    config = """
version: 1
handlers:
  foo:
    class: logging.StreamHandler
    level: debug
    formatter: f
formatters:
  f:
    format: FOO
    """
    assert get_config(config) == {
        'version': 1,
        'handlers': {'foo': {
            'class': 'logging.StreamHandler',
            'level': 20,
            'formatter': 'f'}},
        'formatters': {'f': {
            'format': 'FOO'}}}


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:58:42.108950
# Unit test for function getLogger
def test_getLogger():
    # getLogger() returns a python logging logger object
    assert isinstance(get_logger(), logging.Logger)

    # getLogger() returns a python logger with the package name of the caller
    assert get_logger().name.endswith(__name__)

    # getLogger(name) returns a python logger named name
    assert get_logger('test').name.endswith('test')


if __name__ == '__main__':
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 21:58:47.210053
# Unit test for function get_config
def test_get_config():
    a = get_config(config = None, env_var = None, default = None)
    assert a == None
    b = get_config(config = "true", env_var = 'LOGGING', default = DEFAULT_CONFIG)
    c = get_config(config = None, env_var = 'LOGGING', default = DEFAULT_CONFIG)
    assert b == c

# Generated at 2022-06-21 21:58:57.825421
# Unit test for function getLogger
def test_getLogger():
    import logging.config
    from qcore import MY_APPLICATION_NAME
    import logging.handlers


# Generated at 2022-06-21 21:59:00.752967
# Unit test for function getLogger
def test_getLogger():
    log = getLogger('test')
    assert log.name == 'test'
    assert log.propagate == True


if __name__ == '__main__':
    logging.getLogger().debug('test')

# Generated at 2022-06-21 21:59:04.768724
# Unit test for function get_config
def test_get_config():
    assert get_config('{"handlers": {"null": {"class": "logging.NullHandler"}}}') == {
        'handlers': {
            'null': {
                'class': 'logging.NullHandler'
            }
        }
    }

# Generated at 2022-06-21 21:59:13.872707
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    p = _PyInfo()
    assert p.PY2 == sys.version_info[0] == 2
    assert p.PY3 == sys.version_info[0] == 3
    if p.PY3:
        assert p.string_types == (str,)
        assert p.text_type == str
        assert p.binary_type == bytes
    else:  # PY2
        assert p.string_types == (basestring,)
        assert p.text_type == unicode
        assert p.binary_type == str


# Generated at 2022-06-21 21:59:15.703222
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2
    assert not _PyInfo().PY3


# Generated at 2022-06-21 21:59:31.595087
# Unit test for function get_config

# Generated at 2022-06-21 21:59:39.734931
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2 == (sys.version_info[0] == 2)
    assert _PyInfo().PY3 == (sys.version_info[0] == 3)

    def _assert_str(str_type):
        import types
        assert isinstance(str_type(), types.StringTypes)

    _assert_str(_PyInfo().string_types[0])
    _assert_str(_PyInfo().text_type)
    _assert_str(_PyInfo().binary_type)


if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-21 21:59:47.868768
# Unit test for function logger_level
def test_logger_level():
    """Test logger_level

    >>> log = getLogger('test_logger_level')
    >>> with logger_level(log, logging.INFO):
    ...     log.debug('test_logger_level: %s', 'logging.DEBUG not printed')
    ...     log.info('test_logger_level: %s', 'logging.INFO')
    >>> log.debug('back to logging.DEBUG')
    """



# Generated at 2022-06-21 21:59:52.967253
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.binary_type == (str if sys.version_info[0] == 2 else bytes)
    assert _PyInfo.text_type == (unicode if sys.version_info[0] == 2 else str)
    assert _PyInfo.string_types == (basestring if sys.version_info[0] == 2 else str,)


# Generated at 2022-06-21 22:00:01.360492
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('unitTest')
    logger.debug('Logger is working\n')
    logger.info('This is a information message\n')
    logger.warning('This is a warning message\n')
    logger.error('This is a error message\n')
    logger.critical('This is a critical error message\n')


if __name__ == '__main__':
    # unit test getLogger
    test_getLogger()

# Generated at 2022-06-21 22:00:11.120540
# Unit test for function get_config
def test_get_config():
    class MockEnv(object):
        def __init__(self):
            self.my_env = None

        def get(self, var_name):
            return self.my_env

        def set(self, var_name, var_value):
            self.my_env = var_value
    mock_env = MockEnv()

    # test with given config string
    given_config = '{"loggers": {"my_name": {"level": "DEBUG"}}}'
    config = get_config(given=given_config)
    assert config['loggers']['my_name']['level'] == 'DEBUG'

    # test with given config dict
    given_config = { 'loggers': { 'my_name': { 'level': 'DEBUG' } } }
    config = get_config(given=given_config)


# Generated at 2022-06-21 22:00:17.273056
# Unit test for function configure
def test_configure():
    # create a null output device
    nullout = open(os.devnull, 'w')
    old_stdout = sys.stdout
    sys.stdout = nullout

    # test default config
    configure()
    logger = get_logger()
    logger.debug('test')
    nullout.close()

    # restore stdout
    sys.stdout.close()
    sys.stdout = old_stdout

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:00:25.779951
# Unit test for function get_config
def test_get_config():
    # Load config in JSON format
    config = get_config(config='{"disable_existing_loggers":true}', env_var=None, default=None)
    assert(config == {'disable_existing_loggers': True})

    # Load config in YAML format
    config = get_config(config='disable_existing_loggers: true', env_var=None, default=None)
    assert(config == {'disable_existing_loggers': True})


# Generated at 2022-06-21 22:00:30.658500
# Unit test for function get_config
def test_get_config():
    import json

    assert get_config() == {}
    assert get_config(None, default={}) == {}
    assert get_config('') == {}
    assert get_config(json.dumps({})) == {}
    assert get_config('{}') == {}

# Generated at 2022-06-21 22:00:37.136542
# Unit test for function get_config
def test_get_config():
    try:
        assert get_config(config=None, env_var=None, default=None)
    except ValueError:
        pass

    assert get_config(config={}, default=None) == {}
    assert get_config(config='{"version": 1}', default=None) == {"version": 1}
    assert get_config(config='version: 1', default=None) == {"version": 1}



# Generated at 2022-06-21 22:00:45.095469
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')

    log = get_logger('test2')
    log.info('test2')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:00:53.873393
# Unit test for function get_config
def test_get_config():
    cfg = get_config(None, 'LOGGING', {'formatters': {'simple': {'format': '%(asctime)s| %(message)s'}}})
    assert cfg == {'formatters': {'simple': {'format': '%(asctime)s| %(message)s'}}}
    cfg = get_config(None, 'LOGGING', {})
    assert cfg == {}

    json_config = {'name': 'config'}
    cfg = get_config(json.dumps(json_config), 'LOGGING', {})
    assert cfg == json_config

    yaml_config = {'name': 'config'}
    cfg = get_config(yaml.dump(yaml_config), 'LOGGING', {})
    assert cfg

# Generated at 2022-06-21 22:01:02.184127
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    if pyinfo.PY3:
        assert pyinfo.string_types == (str,)
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
    else:  # PY2
        assert pyinfo.string_types == (str, unicode)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str


# Generated at 2022-06-21 22:01:14.477990
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    if _PyInfo.PY2:
        assert isinstance("", _PyInfo.string_types)
        assert not isinstance(b"", _PyInfo.string_types)
        assert isinstance(u"", _PyInfo.string_types)
        assert not isinstance(b"", _PyInfo.text_type)
        assert not isinstance(u"", _PyInfo.text_type)
        assert not isinstance(u"", _PyInfo.binary_type)
        assert isinstance(b"", _PyInfo.binary_type)
    else:
        assert not isinstance("", _PyInfo.string_types)
        assert isinstance(b"", _PyInfo.string_types)

# Generated at 2022-06-21 22:01:22.460828
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)

    debug_msg = 'This is a debug message'
    info_msg = 'This is an info message'

    with logger_level(log, logging.INFO):
        log.debug(debug_msg)
        log.info(info_msg)

    # assert that logger_level hides the call to logger.debug
    assert debug_msg not in [record.getMessage() for record in log.handlers[0].stream.getvalue().split('\n')]
    assert info_msg in [record.getMessage() for record in log.handlers[0].stream.getvalue().split('\n')]


if __name__ == '__main__':
    import doctest

    # Tests
    doctest.testmod()


"""

"""

# Generated at 2022-06-21 22:01:28.035866
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger()
    log.debug("test debug")
    log.info("test info")
    log.warning("test warning")
    log.error("test error")
    log.critical("test critical")

# Generated at 2022-06-21 22:01:38.018437
# Unit test for function get_config

# Generated at 2022-06-21 22:01:50.272327
# Unit test for function get_config

# Generated at 2022-06-21 22:02:02.369380
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True or _PyInfo.PY3 is True
    assert _PyInfo.PY2 is False or _PyInfo.PY3 is False
    assert isinstance(_PyInfo.binary_type(), bytes) if _PyInfo.PY3 else isinstance(_PyInfo.binary_type(), str)
    assert isinstance(_PyInfo.text_type(), str) if _PyInfo.PY3 else isinstance(_PyInfo.text_type(), unicode)
    assert isinstance(_PyInfo.string_types[0](), str) if _PyInfo.PY3 else isinstance(_PyInfo.string_types[0](), str) and isinstance(_PyInfo.string_types[0](), unicode)


if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-21 22:02:05.934239
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert sys.version_info[0] == 2
    assert _PyInfo.PY2
    assert not _PyInfo.PY3

    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str

# Generated at 2022-06-21 22:02:25.669345
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    from logging import StreamHandler, WARNING
    from contextlib import redirect_stdout
    from .context import context
    from .logging import get_logger

    class TemporaryFileStreamHandler(StreamHandler):
        def __init__(self):
            self._file = tempfile.TemporaryFile()
            StreamHandler.__init__(self, self._file)

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            self._file.close()

        def read(self):
            self._file.seek(0)
            return self._file.read().decode('ascii')

    with context() as cx:
        log = get_logger()

        # log.addHandler(logging.StreamHandler())

# Generated at 2022-06-21 22:02:31.040893
# Unit test for function getLogger
def test_getLogger():

    log = get_logger()
    assert log.name == __name__

    log = get_logger('test_getLogger')
    log.debug('test_getLogger')
    assert log.name == 'test_getLogger'

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:02:39.893256
# Unit test for function get_config

# Generated at 2022-06-21 22:02:44.562928
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert not _PyInfo.PY2
    assert _PyInfo.PY3
    assert _PyInfo.string_types == (str,)
    assert _PyInfo.text_type == str
    assert _PyInfo.binary_type == bytes
    return True



# Generated at 2022-06-21 22:02:46.956225
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__file__)
    with logger_level(logger, logging.ERROR):
        logger.info('this will not be logged')
        logger.error('this will be logged')
    logger.info('this will be logged')
    logger.error('this will be logged')



# Generated at 2022-06-21 22:02:52.328911
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == True or pyinfo.PY3 == True
    if pyinfo.PY2:
        assert (type(pyinfo.string_types), type(pyinfo.text_type), type(pyinfo.binary_type)) == (tuple, unicode, str)
    if pyinfo.PY3:
        assert (type(pyinfo.string_types), type(pyinfo.text_type), type(pyinfo.binary_type)) == (tuple, str, bytes)

if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-21 22:02:54.567632
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert isinstance(logger, logging.Logger)



# Generated at 2022-06-21 22:02:58.202895
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.CRITICAL):
        log.debug("This should not be output")
    log.debug("This will be output")


# Generated at 2022-06-21 22:03:02.447598
# Unit test for function get_config
def test_get_config():
    assert get_config()
    assert get_config('{"version": 1, "disable_existing_loggers": False}')
    assert get_config('version: 1\ndisable_existing_loggers: False')
    assert get_config({"version": 1, "disable_existing_loggers": False})

# Generated at 2022-06-21 22:03:03.468312
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert isinstance(logger, logging.Logger)



# Generated at 2022-06-21 22:03:20.899342
# Unit test for function get_config
def test_get_config():
    assert get_config(config="{'version':1}") == {'version':1}
    assert get_config(config="{'version':1, 'loggers':{}}") == {'version':1, 'loggers':{}}
    assert get_config(config='{"version": 1, "loggers": {}}') == {"version": 1, "loggers": {}}
    assert get_config(config="""version: 1
loggers: """) == {'version': 1, 'loggers': {}}
    assert get_config(env_var='LOGGING', default={'version': 1, 'loggers': {}}) == \
            {'version': 1, 'loggers': {}}
    assert get_config() == DEFAULT_CONFIG


# Generated at 2022-06-21 22:03:27.750912
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

# Generated at 2022-06-21 22:03:39.191309
# Unit test for function getLogger
def test_getLogger():
    import sys
    name = 'mylogger.tests.test_getLogger'
    if name not in sys.modules:
        import mylogger.tests
        from mylogger.tests import test_getLogger
        sys.modules[name] = test_getLogger
    else:
        reload(sys.modules[name])
    test_getLogger = sys.modules[name]
    import logging
    logger = getLogger(__name__)
    root = logging.getLogger()
    assert logger.parent == root
    assert logger.name == 'mylogger.tests.test_getLogger'
    # logger = getLogger()
    # import time
    # time.sleep(1)
    # assert ('mylogger.tests' in sys.modules)
    # assert ('mylogger.tests.test

# Generated at 2022-06-21 22:03:40.119764
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log.info('test')


# Generated at 2022-06-21 22:03:45.281838
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert isinstance("hello", _PyInfo.string_types)
        assert not isinstance(b"hello", _PyInfo.text_type)
        assert not isinstance("hello", _PyInfo.binary_type)

    if _PyInfo.PY3:
        assert isinstance("hello", _PyInfo.string_types)
        assert isinstance("hello", _PyInfo.text_type)
        assert not isinstance(b"hello", _PyInfo.binary_type)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:03:47.281851
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger()
    log.info("test1")



# Generated at 2022-06-21 22:03:51.195979
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('logger_level works')
    logger.info('logger_level works')



# Generated at 2022-06-21 22:03:56.841344
# Unit test for function get_config
def test_get_config():
    # Test valid config
    result = get_config(config='{"version": 1}')
    assert isinstance(result, dict)
    result = get_config(config='version: 1\nformatters: {}\nhandlers: {}')
    assert isinstance(result, dict)
    # Test invalid config
    with pytest.raises(ValueError, match='Invalid logging config'):
        get_config(config='{version: 1}')



# Generated at 2022-06-21 22:04:02.623105
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.setLevel(logging.DEBUG)

    with logger_level(logger, logging.CRITICAL):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

# Generated at 2022-06-21 22:04:10.459359
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert sys.version_info[0] == 2 or sys.version_info[0] == 3
    assert isinstance(_PyInfo.PY2, bool)
    assert isinstance(_PyInfo.PY3, bool)
    assert isinstance(_PyInfo.text_type, type)
    assert isinstance(_PyInfo.binary_type, type)
    assert isinstance(_PyInfo.string_types, tuple)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:04:27.005065
# Unit test for function logger_level
def test_logger_level():
    'test if the logger level can be set'
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('Logger level is DEBUG')
    with logger_level(log, logging.INFO):
        log.info('Logger level is INFO')
    with logger_level(log, logging.WARN):
        log.warning('Logger level is WARNING')
    with logger_level(log, logging.ERROR):
        log.error('Logger level is ERROR')
    with logger_level(log, logging.CRITICAL):
        log.critical('Logger level is CRITICAL')


# Generated at 2022-06-21 22:04:33.527233
# Unit test for function get_config

# Generated at 2022-06-21 22:04:35.465511
# Unit test for function getLogger
def test_getLogger():
    import logging
    logger = getLogger('spam_application')
    assert logger.level == logging.DEBUG

# Generated at 2022-06-21 22:04:37.601845
# Unit test for function configure
def test_configure():
    logger = get_logger()
    logger.info('this is a test')

# Generated at 2022-06-21 22:04:43.091109
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.binary_type == bytes or _PyInfo.binary_type == str
    assert _PyInfo.text_type == str or _PyInfo.text_type == unicode
    assert isinstance('test', _PyInfo.string_types)
    assert isinstance(b'test', _PyInfo.string_types)
    if _PyInfo.PY2:
        assert isinstance(u'test', _PyInfo.string_types)

# Generated at 2022-06-21 22:04:45.836568
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    assert log.name == '__main__'
    log = get_logger(__name__)
    assert log.name == __name__
    assert log is not get_logger()


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:04:56.725665
# Unit test for function get_config

# Generated at 2022-06-21 22:04:58.362383
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-21 22:05:02.736904
# Unit test for function configure
def test_configure():
    logging.root.handlers = []
    configure('{"version":1,"disable_existing_loggers":false,"formatters":{},"handlers":{},"loggers":{},"root":{"handlers":["console"],"level":"DEBUG"}}')
    logger=logging.getLogger(__name__)
    assert logger.level == logging.DEBUG
    assert logging.root.handlers


# Generated at 2022-06-21 22:05:04.246425
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger("test_getLogger")
    logger.info("test_getLogger")



# Generated at 2022-06-21 22:05:25.840382
# Unit test for function getLogger
def test_getLogger():
    import logging
    import sys

    # Set up the logger
    logger = get_logger('pytest_getLogger')
    logger.setLevel(logging.INFO)
    logger.propagate = False

    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    ch.setFormatter(
        logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    )

    logger.addHandler(ch)
    logger.warning('This is a test')
    logger.info('This is a test without threading')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:05:27.764113
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True or _PyInfo.PY3 is True
    assert _PyInfo.PY2 is False or _PyInfo.PY3 is False


# Generated at 2022-06-21 22:05:38.876537
# Unit test for function logger_level
def test_logger_level():
    import logging

    root_logger = logging.getLogger()
    # Since no logger configured by default, we'll get the default level of logging==WARNING.
    assert root_logger.level == 30, "default logging level should be 30(logging.WARNING)"

    # Now let's configure our logger with the DEBUG level

# Generated at 2022-06-21 22:05:47.001197
# Unit test for function get_config
def test_get_config():
    # test default value
    config = get_config()
    assert config == DEFAULT_CONFIG
    # test json config

# Generated at 2022-06-21 22:05:57.256864
# Unit test for function logger_level
def test_logger_level():
    print('test_logger_level')
    logger = logging.getLogger('test_logger_level')
    assert logger.level == logging.NOTSET

    # Test to make sure nested context managers work
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        with logger_level(logger, logging.WARNING):
            assert logger.level == logging.WARNING
        assert logger.level == logging.INFO
    assert logger.level == logging.NOTSET

    # Test that the logger level is restored at the end of the context block.
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.NOTSET

    # Test that exception in a logger_level context block does not prevent the logger from being restored.

# Generated at 2022-06-21 22:06:04.730471
# Unit test for function logger_level
def test_logger_level():
    """Test function logger_level."""

    with logger_level(logging.getLogger('test'), logging.DEBUG):
        assert logging.getLogger('test').level == logging.DEBUG
    assert logging.getLogger('test').level == logging.NOTSET


try:
    import tetlog

    def get_tetlogger(name=None):
        """
        >>> log = get_tetlogger()
        >>> log.debug('test')
        """
        return tetlog.getLogger(name or __name__)

    tetlog.configure()

except ImportError:
    pass

# Generated at 2022-06-21 22:06:06.014240
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2


# Generated at 2022-06-21 22:06:13.717563
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == sys.version_info[0] == 2
    assert _PyInfo.PY3 == sys.version_info[0] == 3
    assert _PyInfo.binary_type == bytes
    assert _PyInfo.text_type == str
    assert _PyInfo.string_types == (str, )


# Generated at 2022-06-21 22:06:24.340175
# Unit test for function get_config
def test_get_config():
    actual = get_config(config='{"a":3}')
    expected = {'a': 3}
    assert actual == expected

    actual = get_config(config='a: 3', default={})
    expected = {'a': 3}
    assert actual == expected

    actual = get_config(config='a 3', default={})
    expected = {'a': 3}
    assert actual == expected

    actual = get_config(config='a: 3')
    expected = {'a': 3}
    assert actual == expected

    actual = get_config(config='a 3')
    expected = {'a': 3}
    assert actual == expected



# Generated at 2022-06-21 22:06:32.922387
# Unit test for function get_config
def test_get_config():
    # test given None
    assert get_config() == get_config(None, None, DEFAULT_CONFIG)
    # test given json string
    assert get_config('{"foo": "bar"}') == get_config(json.dumps({"foo": "bar"}), None, DEFAULT_CONFIG)
    # test given yaml string
    assert get_config("foo: bar") == get_config(yaml.dump({"foo": "bar"}), None, DEFAULT_CONFIG)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:06:49.702653
# Unit test for function get_config
def test_get_config():
    assert get_config("", None, None) is None
    assert get_config("", None, DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config("", "LOGGING", None) is None
    assert get_config("", "LOGGING", DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config("{}", None, None) == {}
    assert get_config("{}", None, DEFAULT_CONFIG) == {}
    assert get_config("{}", "LOGGING", None) == {}
    assert get_config("{}", "LOGGING", DEFAULT_CONFIG) == {}
    assert get_config("{'a':'b'}", None, None) == {'a':'b'}

# Generated at 2022-06-21 22:07:01.615187
# Unit test for function get_config

# Generated at 2022-06-21 22:07:10.862249
# Unit test for function get_config
def test_get_config():
    assert get_config(default='{"a": 1}') == {'a': 1}
    assert get_config(default='{"a": 2}') == {'a': 2}
    assert get_config(default='a: 1') == {'a': 1}
    assert get_config(default='a: 1') == {'a': 1}

    assert get_config(default={'a': 2}) == {'a': 2}
    assert get_config(default=[1, 2]) == [1, 2]
    assert get_config(default=1) == 1

    assert get_config(default=[]) == []
    assert get_config(default='') == ''
    assert get_config(default=None) is None



# Generated at 2022-06-21 22:07:18.408445
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    from inflection import underscore

    obj = _PyInfo()
    for attr, value in obj.__dict__.items():
        assert isinstance(value, type(None)) or issubclass(value, type(None)), '%s: %s' % (attr, value)
        assert obj.__dict__[attr] is getattr(obj, attr)


# Unit tests for functions get_config, configure and get_logger