

# Generated at 2022-06-21 21:57:25.575961
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('logger_level.test_logger_level')
    assert log.getEffectiveLevel() == logging.DEBUG
    with logger_level(log, logging.WARNING):
        assert log.getEffectiveLevel() == logging.WARNING
    assert log.getEffectiveLevel() == logging.DEBUG


# class Logger(logging.getLoggerClass()):

# Generated at 2022-06-21 21:57:28.222057
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert isinstance(logger, logging.Logger)

    logger = getLogger('test_getLogger')
    assert isinstance(logger, logging.Logger)
    logger.info('test getLogger logger')

# Generated at 2022-06-21 21:57:29.027199
# Unit test for function get_config
def test_get_config():
    pass

# Generated at 2022-06-21 21:57:39.872402
# Unit test for function get_config
def test_get_config():
    """
    >>> test_get_config()
    """
    import io

    config = get_config(
        default={'version': 1, 'disable_existing_loggers': False}
    )
    assert config == DEFAULT_CONFIG

    config = get_config(
        default=io.StringIO('{"version": 1, "disable_existing_loggers": false}')
    )
    assert config == DEFAULT_CONFIG

    config = get_config(
        default=io.StringIO(
            'version: 1\ndisable_existing_loggers: false\n'
        )
    )
    assert config == DEFAULT_CONFIG

    config = get_config(
        default='{"version": 1, "disable_existing_loggers": false}'
    )
    assert config == DEFAULT_CONFIG




# Generated at 2022-06-21 21:57:41.662798
# Unit test for function getLogger
def test_getLogger():
  getLogger('test').info('test')


# Generated at 2022-06-21 21:57:45.705209
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert(logger.getEffectiveLevel() == logging.DEBUG)

    assert(logger.getEffectiveLevel() == logging.NOTSET)

# Generated at 2022-06-21 21:57:55.992804
# Unit test for function configure

# Generated at 2022-06-21 21:57:57.451607
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')


# Generated at 2022-06-21 21:58:06.498551
# Unit test for function logger_level
def test_logger_level():
    import logging
    import os

    log = get_logger()

    with logger_level(log, logging.CRITICAL):
        assert log.isEnabledFor(logging.CRITICAL)
        log.warning('this warning should not appear in the test output!')

    assert log.isEnabledFor(logging.DEBUG)
    log.warning('this warning should appear in the test output')

    # if you see an error like
    # AssertionError: AssertionError() in <bound method Test.__del__ of <tests.log_test.LogTest testMethod=test_logger_level>
    # it is probably due to either multithreading or forking.


# Generated at 2022-06-21 21:58:13.037321
# Unit test for function get_config
def test_get_config():
    config_json = """{"version": 1, "root": {"level": "INFO"}}"""
    cfg_json = get_config(Default=None, given=config_json)
    assert cfg_json["root"]["level"] == "INFO"

    config_yaml = """version: 1\nroot:\n  level: INFO"""
    assert get_config(Default=None, given=config_yaml)["root"]["level"] == "INFO"

    # Test mixing of bare values, json, yaml
    config_bare = {"version": 1,
                   "root": {"level": "INFO"}}
    assert get_config(Default=None, given=config_bare)["root"]["level"] == "INFO"

# Generated at 2022-06-21 21:58:21.476770
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    # This should work
    with logger_level(log, logging.INFO):
        log.setLevel(logging.INFO)
    # This should error
    try:
        with logger_level(log, logging.INFO):
            log.setLevel(logging.ERROR)
        assert False
    except RuntimeError:
        pass

# Generated at 2022-06-21 21:58:25.780721
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test')
    logger.debug('look at I have a name!')
    assert logger.name == 'test'


if __name__ == '__main__':
    import pytest
    pytest.main(['-x', '-l', __file__])

# Generated at 2022-06-21 21:58:32.637946
# Unit test for function getLogger
def test_getLogger():
    import sys
    import unittest

    class TestGetLogger(unittest.TestCase):
        def test_getLogger(self):
            log = getLogger()
            log.info('test')

            log = getLogger('test2')
            log.info('test2')

    tests = unittest.TestLoader().loadTestsFromTestCase(TestGetLogger)
    unittest.TextTestRunner(verbosity=2).run(tests)
    sys.exit()


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 21:58:35.783733
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')
    log.debug('debug')



# Generated at 2022-06-21 21:58:40.422955
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert isinstance('test', pyinfo.string_types)
    assert isinstance(u'test', pyinfo.string_types)
    assert isinstance(b'test', pyinfo.binary_type)
    assert isinstance('test', pyinfo.text_type)

# Generated at 2022-06-21 21:58:45.180698
# Unit test for function logger_level
def test_logger_level():
    import logging
    temp_test_logger = logging.getLogger("temp_test_logger_level")
    configure()
    with logger_level(temp_test_logger, logging.WARNING):
        assert temp_test_logger.level == logging.WARNING
    assert temp_test_logger.level != logging.WARNING

# Generated at 2022-06-21 21:58:47.017139
# Unit test for function get_config
def test_get_config():
    config = {}
    assert get_config(config) == config



# Generated at 2022-06-21 21:58:57.650336
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    Unit test for constructor of class _PyInfo
    """
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == True or pyinfo.PY2 == False, '_PyInfo.PY2 is not boolean'
    assert pyinfo.PY3 == True or pyinfo.PY3 == False, '_PyInfo.PY3 is not boolean'
    if pyinfo.PY3:
        assert type(pyinfo.string_types) == tuple, 'string type is not tuple'
        assert type(pyinfo.string_types[0]) == str, 'string type is not str'
        assert type(pyinfo.text_type) == str, 'text type is not str'
        assert type(pyinfo.binary_type) == bytes, 'binary type is not bytes'

# Generated at 2022-06-21 21:58:58.565659
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-21 21:59:01.848679
# Unit test for function getLogger
def test_getLogger():
    """
    >>> test_getLogger()
    test
    """
    configure()
    logger = get_logger()
    logger.info('test')



# Generated at 2022-06-21 21:59:11.973698
# Unit test for constructor of class _PyInfo

# Generated at 2022-06-21 21:59:13.025992
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    logger.debug('hi')
    assert logging.getLogger(__name__).getEffectiveLevel() == logging.DEBUG



# Generated at 2022-06-21 21:59:18.460491
# Unit test for function getLogger
def test_getLogger():
    configure()
    log = getLogger('test')
    log.setLevel(logging.DEBUG)
    log.debug('test debug')
    log.info('test info')
    log.warning('test warning')
    log.error('test error')
    log.critical('test critical')
    logger = getLogger()
    logger.info('test')

# Generated at 2022-06-21 21:59:22.998036
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.DEBUG)
    log = get_logger()
    assert log.getEffectiveLevel() == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.getEffectiveLevel() == logging.INFO
        with logger_level(log, logging.CRITICAL):
            assert log.getEffectiveLevel() == logging.CRITICAL
        assert log.getEffectiveLevel() == logging.INFO
    assert log.getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-21 21:59:34.141921
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 ^ _PyInfo.PY3  # XOR
    if _PyInfo.PY2:
        assert isinstance('string', _PyInfo.string_types)
        assert isinstance(u'string', _PyInfo.string_types)
        assert isinstance('string', _PyInfo.binary_type)
        assert not isinstance(u'string', _PyInfo.binary_type)
    else:
        assert isinstance('string', _PyInfo.string_types)
        assert not isinstance(u'string', _PyInfo.string_types)
        assert not isinstance('string', _PyInfo.binary_type)
        assert isinstance(b'string', _PyInfo.binary_type)
    return _PyInfo



# Generated at 2022-06-21 21:59:38.214507
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')
    assert log == logging.getLogger(__name__)


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 21:59:43.420565
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py_info = _PyInfo()
    assert py_info.PY2 == (sys.version_info[0] == 2)
    assert py_info.PY3 == (sys.version_info[0] == 3)

    if py_info.PY3:
        assert py_info.string_types == (str,)
        assert py_info.text_type == str
        assert py_info.binary_type == bytes
    else:
        assert py_info.string_types == (basestring,)
        assert py_info.text_type == unicode
        assert py_info.binary_type == str



# Generated at 2022-06-21 21:59:53.524654
# Unit test for function get_config
def test_get_config():
    import json

# Generated at 2022-06-21 22:00:04.370620
# Unit test for function get_config
def test_get_config():
    assert get_config(default='DEBUG') == {'root': {'level': 10, 'handlers': ['default']},
                                           'handlers': {'default': {'level': 'DEBUG',
                                                                    'formatter': 'default',
                                                                    'class': 'logging.StreamHandler'}},
                                           'disable_existing_loggers': False,
                                           'loggers': {},
                                           'version': 1,
                                           'formatters': {'default': {'format': '%(levelname)s %(message)s'}}}
    # Test log configuration from environment variable
    os.environ['LOGGING'] = 'INFO'

# Generated at 2022-06-21 22:00:06.446620
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert isinstance(logger, logging.Logger)



# Generated at 2022-06-21 22:00:23.658771
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3

    if _PyInfo.PY2:
        assert _PyInfo.binary_type is str
        assert _PyInfo.text_type is unicode
        assert isinstance(u'c', _PyInfo.string_types)
        assert isinstance('c', _PyInfo.string_types)
    else:
        assert _PyInfo.binary_type is bytes
        assert _PyInfo.text_type is str
        assert isinstance('c', _PyInfo.string_types)



# Generated at 2022-06-21 22:00:28.586079
# Unit test for function configure
def test_configure():
    logging.shutdown()
    logging.root.handlers = []

    log = logging.getLogger('test')
    log.info('should not see this')

    configure()
    log.info('test2')
    logging.config.dictConfig(DEFAULT_CONFIG)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:00:34.608633
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config(default=DEFAULT_CONFIG)
    assert DEFAULT_CONFIG == get_config(default=DEFAULT_CONFIG)
    assert DEFAULT_CONFIG == get_config(default=DEFAULT_CONFIG)
    assert DEFAULT_CONFIG == get_config(default=DEFAULT_CONFIG)



# Generated at 2022-06-21 22:00:42.795265
# Unit test for function get_config
def test_get_config():
    example = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'colored': {
                '()': 'colorlog.ColoredFormatter',
                'format':
                    '%(bg_black)s%(log_color)s'
                    '[%(asctime)s] '
                    '[%(name)s/%(process)d] '
                    '%(message)s '
                    '%(blue)s@%(funcName)s:%(lineno)d '
                    '#%(levelname)s'
                    '%(reset)s',
                'datefmt': '%H:%M:%S',
            },
        },
    }

    import json
    import yaml


# Generated at 2022-06-21 22:00:45.095587
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY3 is not _PyInfo().PY2


# Generated at 2022-06-21 22:00:47.904087
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger(__name__)
    log.debug('should not show this line')
    log.info('should show this line')



# Generated at 2022-06-21 22:00:51.528389
# Unit test for function get_config
def test_get_config():
    assert isinstance(get_config("json"), dict)
    assert isinstance(get_config("yaml"), dict)
    assert isinstance(get_config("bare"), dict)
    assert isinstance(get_config("json"), dict)
    assert isinstance(get_config("json"), dict)



# Generated at 2022-06-21 22:00:55.813786
# Unit test for function configure
def test_configure():
    import colorlog

    # Set up a test logger, which should log only to stdout
    logger = logging.getLogger('TestConfigure')

    configure()
    assert logger.getEffectiveLevel() == logging.DEBUG
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0].formatter, colorlog.ColoredFormatter)
    # Cleanup
    logger.handlers = []



# Generated at 2022-06-21 22:01:03.155504
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert type('i am str') in _PyInfo.string_types
        assert type(u'i am unicode') in _PyInfo.string_types
        assert type(u'i am unicode') is _PyInfo.text_type
        assert type('i am str') is _PyInfo.binary_type
    elif _PyInfo.PY3:
        assert type('i am str') in _PyInfo.string_types
        assert type('i am str') is _PyInfo.text_type
        assert type(b'i am bytes') is _PyInfo.binary_type



# Generated at 2022-06-21 22:01:09.747042
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

    log = getLogger(__name__)
    log.info('test')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:01:26.592035
# Unit test for function configure
def test_configure():
    import tempfile
    import os
    import shutil
    logging.getLogger().setLevel(logging.WARN)
    dir_path = tempfile.mkdtemp()
    file_name = os.path.join(dir_path, 'test.json')
    with open(file_name, 'w') as f:
        f.write('{"version": 1}')
        f.close()
    os.environ['LOGGING'] = file_name
    configure()
    # Make sure the test.json file is used to configure logging
    assert logging.getLogger('test.json')
    shutil.rmtree(dir_path)

# Generated at 2022-06-21 22:01:33.052478
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    if pyinfo.PY2:
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str
    elif pyinfo.PY3:
        assert pyinfo.string_types == (str,)
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
    else:
        assert False

# Generated at 2022-06-21 22:01:35.693283
# Unit test for function configure
def test_configure():
    """Test logging configure by logger.basicConfig()"""
    logger = logging.getLogger(__name__)
    logger.debug('test')



# Generated at 2022-06-21 22:01:38.515788
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    print(logger.level)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')


# testing purposes
# if __name__ == '__main__':
#     test_logger_level()

# Generated at 2022-06-21 22:01:50.743526
# Unit test for function get_config
def test_get_config():
    from contextlib import contextmanager
    import six

    def _capture():
        @contextmanager
        def capture():
            try:
                from StringIO import StringIO
            except ImportError:
                from io import StringIO
            oldout, olderr = sys.stdout, sys.stderr
            out = [StringIO(), StringIO()]
            sys.stdout, sys.stderr = out
            try:
                yield out
            finally:
                sys.stdout, sys.stderr = oldout, olderr
                out[0] = out[0].getvalue()
                out[1] = out[1].getvalue()

        return capture

    def _assert_log(capture, message=None):
        with capture() as out:
            get_logger(__name__).info('test')
       

# Generated at 2022-06-21 22:01:55.738292
# Unit test for function configure
def test_configure():
    configure()
    logger = get_logger('test')
    logger.debug('test configure')
    with logger_level(logger, 10):
        logger.debug('test level')

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:01:59.820304
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARNING):
        assert logger.isEnabledFor(logging.WARNING)
        assert not logger.isEnabledFor(logging.INFO)
    assert logger.isEnabledFor(logging.INFO)

# Generated at 2022-06-21 22:02:09.068170
# Unit test for function get_config
def test_get_config():
    config = {}

    # Test a bare config
    config["bare"] = {"bare": "true"}
    assert get_config(config["bare"]) == {"bare": "true"}

    # Test a json config
    config["json"] = '{"json": "true"}'
    assert get_config(config["json"]) == {"json": "true"}

    # Test a yaml config
    config["yaml"] = 'yaml: true'
    assert get_config(config["yaml"]) == {"yaml": "true"}

    # Test an invalid config
    invalid = "nope, this is not json/yaml"
    try:
        get_config(invalid)
    except ValueError:
        # test passes, expected
        pass
    else:
        assert "Expected ValueError for config: %s" % invalid

# Generated at 2022-06-21 22:02:16.231713
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config(default=DEFAULT_CONFIG)
    assert get_config() == None
    assert get_config(default=None) == None
    assert get_config(env_var='LOGGING') == DEFAULT_CONFIG

    # Can parse json

# Generated at 2022-06-21 22:02:18.231297
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log.info('test')


# Generated at 2022-06-21 22:02:38.628893
# Unit test for constructor of class _PyInfo
def test__PyInfo():

    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str

# Generated at 2022-06-21 22:02:49.273786
# Unit test for function get_config
def test_get_config():
    # test_config_path = "tests/test_config.json"
    # config = get_config(path=test_config_path)
    # assert(config["loggers"]["root"]["level"] == "INFO")
    # assert(config["formatters"]["simple"]["format"] == "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s")

    # create config dict for testing
    config = dict()
    config["loggers"] = dict()
    config["loggers"]["root"] = dict()
    config["loggers"]["root"]["level"] = "INFO"

# Generated at 2022-06-21 22:02:51.960547
# Unit test for function getLogger
def test_getLogger():
    assert getLogger()
    assert getLogger('test')

# Generated at 2022-06-21 22:02:58.408123
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str



# Generated at 2022-06-21 22:03:02.576230
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance(_PyInfo().PY2, bool)
    assert isinstance(_PyInfo().PY3, bool)
    assert isinstance(_PyInfo().string_types, tuple)
    assert isinstance(_PyInfo().text_type, type)
    assert isinstance(_PyInfo().binary_type, type)



# Generated at 2022-06-21 22:03:03.166242
# Unit test for function getLogger
def test_getLogger():
    pass

# Generated at 2022-06-21 22:03:12.588896
# Unit test for function get_config
def test_get_config():
    test_cases = [
        None,
        '{"a": "b"}',
        '{"a": "b"}',
        {},
        {'a': 'b'},
    ]

    for config in test_cases:
        cfg = get_config(config, env_var=None, default=None)

    # Test with a single env var
    os.environ['LOGGING'] = '{"c": "d"}'
    cfg = get_config(config=None, env_var='LOGGING', default=None)

    # Test with a default value
    cfg = get_config(config=None, env_var=None, default={'e': 'f'})



# Generated at 2022-06-21 22:03:14.820396
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    log.info('test')
    assert log.name == __name__


# Generated at 2022-06-21 22:03:19.541528
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()

    assert logger.level == config.LOG_DEFAULT_LEVEL

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    assert logger.level == config.LOG_DEFAULT_LEVEL

    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL

    assert logger.level == config.LOG_DEFAULT_LEVEL


# Generated at 2022-06-21 22:03:27.082475
# Unit test for function configure

# Generated at 2022-06-21 22:03:47.482758
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test')
    logger.info('test')


# Generated at 2022-06-21 22:03:55.106801
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print("Testing _PyInfo...")
    assert _PyInfo.PY2, '_PyInfo.PY2 not set'
    assert _PyInfo.PY3, '_PyInfo.PY3 not set'
    assert _PyInfo.string_types, '_PyInfo.string_types not set'
    assert _PyInfo.text_type, '_PyInfo.text_type not set'
    assert _PyInfo.binary_type, '_PyInfo.binary_type not set'



# Generated at 2022-06-21 22:04:03.477465
# Unit test for function configure
def test_configure():
    import os
    import json
    import time
    import tempfile
    from os.path import isfile
    from contextlib import contextmanager

    @contextmanager
    def _temp_file_with(content):
        (fd, path) = tempfile.mkstemp()
        with open(path, 'w') as ostream:
            ostream.write(content)
        os.close(fd)
        try:
            yield path
        finally:
            os.remove(path)

    def _check_log_file_exists(path):
        assert isfile(path), 'File "%s" does not exist' % path
        # Read the first line of the file and make sure it's there.
        with open(path, 'r') as istream:
            line = istream.readline()

# Generated at 2022-06-21 22:04:09.272534
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    _p = _PyInfo()
    assert _p.PY2
    assert not _p.PY3
    assert _p.string_types == (basestring,)
    assert _p.text_type == unicode
    assert _p.binary_type == str


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:04:10.772743
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2 == (sys.version_info[0] == 2)

# Generated at 2022-06-21 22:04:17.828973
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert logger is not None
    assert logger is not None
    assert logger.name == '_common.logger'
    assert logger.handlers
    assert logger.handlers[0].formatter._fmt == '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s'

# Generated at 2022-06-21 22:04:26.966117
# Unit test for function get_config

# Generated at 2022-06-21 22:04:28.704661
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    with logger_level(log, logging.INFO):
        log.info("Testing")

# Generated at 2022-06-21 22:04:31.473645
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.DEBUG):
        logger.debug(
            'With logger_level, the debug message should appear'
        )
    logger.debug(
        'Without logger_level, the debug message should NOT appear'
    )

# Generated at 2022-06-21 22:04:34.203607
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test_getLogger')


# Generated at 2022-06-21 22:05:23.722776
# Unit test for function getLogger
def test_getLogger():
    """
    >>> import test.temp_logger

    >>> import logging
    >>> logging.basicConfig(level=logging.INFO)
    >>> test.temp_logger.getLogger().info('temp logger')

    """
    pass

# Escape newline characters in a string for logging

# Generated at 2022-06-21 22:05:27.567062
# Unit test for function getLogger
def test_getLogger():
    try:
        logger = get_logger()
        logger.error("This is an error message from getLogger")
        logger.exception("This is an exception message from getLogger")
        logger.info("This is an info message from getLogger")
    except Exception as e:
        raise e



# Generated at 2022-06-21 22:05:38.667879
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert isinstance("123", _PyInfo.string_types)
        assert not isinstance(b"123", _PyInfo.string_types)
        assert isinstance(u"123", _PyInfo.text_type)
        assert not isinstance("123", _PyInfo.text_type)
        assert isinstance(b"123", _PyInfo.binary_type)
        assert not isinstance("123", _PyInfo.binary_type)
    else:
        assert isinstance("123", _PyInfo.string_types)
        assert not isinstance(b"123", _PyInfo.string_types)
        assert isinstance("123", _PyInfo.text_type)
        assert not isinstance(u"123", _PyInfo.text_type)

# Generated at 2022-06-21 22:05:40.760221
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')
    log = getLogger('test2')
    log.info('test2')
    return True

# Generated at 2022-06-21 22:05:46.403538
# Unit test for function getLogger
def test_getLogger():

    import unittest
    class getLoggerTestCase(unittest.TestCase):
        def test_default(self):
            log = get_logger()
            self.assertIsNotNone(log)

        def test_custom(self):
            log = get_logger('test_logger')
            self.assertIsNotNone(log)
            self.assertEqual(log.name, 'test_logger')

    unittest.main(exit=False)



# Generated at 2022-06-21 22:05:53.119111
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('testlogger')
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    logger.addHandler(handler)

    with logger_level(logger, logging.DEBUG):
        logger.debug('test_debug')
        logger.info('test_info')
    logger.debug('test_debug')
    logger.info('test_info')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 22:06:01.571713
# Unit test for function logger_level
def test_logger_level():
    # Verify that logger_level changes the logger level inside a context block, and reverts the level change when exiting the context block.
    # For this test, we have the logger print warnings, errors, and criticals.
    # The context block sets the logger level to INFO, so it will only print errors and criticals.
    logger = getLogger(__name__)
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        logger.warning('This warning will be suppressed')
        logger.error('This error will be printed')
        logger.critical('This critical will be printed')
    assert logger.level == logging.WARNING
    logger.warning('This warning will be printed')
    logger.error('This error will be printed')
    logger.critical('This critical will be printed')

# Generated at 2022-06-21 22:06:05.214997
# Unit test for function configure
def test_configure():
    try:
        configure(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
        print("configure is working fine")
    except ValueError:
        print("error configuring")


# Generated at 2022-06-21 22:06:17.712101
# Unit test for function get_config
def test_get_config():

    # Test with None config
    assert get_config(config=None, env_var=None, default=None) is None

    # Test with JSON
    json = get_config(config="{'a': 1}", env_var=None, default=None)
    assert json == {'a': 1}

    # Test with YAML
    yaml = get_config(config="a: 1", env_var=None, default=None)
    assert yaml == {'a': 1}

    # Test with String
    string = get_config(config="a: 1", env_var=None, default=None)
    assert string == {'a': 1}

    # Test with Dictionary
    dictionary = get_config(config={'a': 1}, env_var=None, default=None)

# Generated at 2022-06-21 22:06:29.979485
# Unit test for function configure
def test_configure():
    configure(default=dict(
        version=1,
        disable_existing_loggers=False,
        formatters={
            'simple': {
                'format': '%(asctime)s - %(levelname)s - %(message)s',
                'datefmt': '%Y-%m-%d %H:%M:%S',
            },
        },
        handlers={
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
                'level': logging.DEBUG,
            },
        },
        root=dict(handlers=['console'], level=logging.DEBUG),
        loggers={
            'requests': dict(level=logging.INFO),
        },
    ),)

