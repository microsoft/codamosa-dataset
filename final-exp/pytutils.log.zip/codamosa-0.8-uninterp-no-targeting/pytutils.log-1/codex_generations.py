

# Generated at 2022-06-21 21:57:27.661990
# Unit test for function configure
def test_configure():
    import os
    import tempfile
    import json

    logging_path = os.path.join(tempfile.gettempdir(), 'logging.conf')

    logging_conf = json.dumps(DEFAULT_CONFIG)
    with open(logging_path, 'w') as f:
        f.write(logging_conf)

    configure(logging_path)

    log = logging.getLogger(__name__)
    log.info('test')

    try:
        configure('asdf')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-21 21:57:31.289124
# Unit test for function getLogger
def test_getLogger():
    log1 = get_logger()
    log2 = get_logger()
    assert log1 == log2



# Generated at 2022-06-21 21:57:37.774142
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger('TEST_GETLOGGER')
    logger.info('A simple message')
    logger.warning('A warning message')

if __name__ == '__main__':
    print('Unit testing function get_logger()')
    print('=========================================================================')
    print('=========================================================================')
    print()
    test_getLogger()

# Generated at 2022-06-21 21:57:40.819252
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')

# Generated at 2022-06-21 21:57:48.346520
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    logger.setLevel(logging.ERROR)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        try:
            1/0
        except ZeroDivisionError as e:
            logger.exception(e)
    logger.debug('debug')
    logger.info('info')
    try:
        1/0
    except ZeroDivisionError as e:
        logger.exception(e)



# Generated at 2022-06-21 21:57:50.378272
# Unit test for function configure
def test_configure():
    logging.config.dictConfig(DEFAULT_CONFIG)
    configure()

# Generated at 2022-06-21 21:57:58.467003
# Unit test for function configure
def test_configure():
    config1 = dict(version=1, disable_existing_loggers=False, formatters={
        'f1': {
            'format': '[%(levelname)s] %(asctime)s %(message)s'
        }
    }, handlers={
        'h1': {
            'class': 'logging.StreamHandler',
            'formatter': 'f1',
            'level': logging.DEBUG,
        },
    }, root=dict(handlers=['h1'], level=logging.DEBUG),
    )
    config2 = json.dumps(config1)
    config3 = json.dumps(config2)
    with pytest.raises(TypeError):
        logging.config.dictConfig(config1)
    logging.config.dictConfig(json.loads(config2))

# Generated at 2022-06-21 21:58:02.221848
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.WARN):
        assert logger.isEnabledFor(logging.WARN)

    assert logger.level == logging.DEBUG

# Generated at 2022-06-21 21:58:04.438729
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is False if _PyInfo.PY3 else True, "test_PyInfo failed."



# Generated at 2022-06-21 21:58:08.390897
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    obj = _PyInfo()
    assert isinstance(obj.PY2, bool)
    assert isinstance(obj.PY3, bool)
    assert isinstance(obj.string_types, tuple)
    assert isinstance(obj.text_type, type)
    assert isinstance(obj.binary_type, type)



# Generated at 2022-06-21 21:58:20.756538
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    try:
        with logger_level(logger, logging.DEBUG):
            logger.info("This shouldn't show up")
            logger.debug("This should show up")
    except:
        logger.info("Failed")
    finally:
        logger.debug("This shouldn't show up")

if __name__ == '__main__':
    configure(DEFAULT_CONFIG)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    test_logger_level()

# Generated at 2022-06-21 21:58:31.148638
# Unit test for function get_config
def test_get_config():
    config_string = '''
    version: 1
    root:
      level: INFO
      handlers: [console]
    formatters:
      simple:
        format: '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s'
        datefmt: '%Y-%m-%d %H:%M:%S'
    handlers:
      console:
        class: logging.StreamHandler
        level: DEBUG
        formatter: simple
    loggers:
      requests:
        handlers: [console]
        level: INFO
        propagate: no
    '''
    config_yaml = yaml

# Generated at 2022-06-21 21:58:35.041115
# Unit test for function configure
def test_configure():
    logging.getLogger().handlers = []
    logger = configure()
    assert isinstance(logger, logging.Logger)
    assert logger.name == __name__
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0], logging.StreamHandler)


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 21:58:41.174968
# Unit test for function configure
def test_configure():
    from io import StringIO

    s = StringIO()
    configure({'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'colored',
            'level': logging.DEBUG,
            'stream': s
        },
    }})
    log = logging.getLogger(__name__)
    log.info('test')
    assert 'test' in s.getvalue()

# Generated at 2022-06-21 21:58:44.742443
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert(_PyInfo.PY2)
    assert(isinstance('', _PyInfo.string_types))
    assert(isinstance('', _PyInfo.text_type))
    assert(isinstance(b'', _PyInfo.binary_type))

# Generated at 2022-06-21 21:58:49.130597
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__ + '.test_logger_level')
    with logger_level(logger, logging.NOTSET):
        assert logger.level == logging.NOTSET
    assert logger.level == logging.NOTSET



# Generated at 2022-06-21 21:58:50.363863
# Unit test for function configure
def test_configure():
    configure()
    logger = get_logger()
    logger.info('In test_configure')



# Generated at 2022-06-21 21:58:51.442462
# Unit test for function configure
def test_configure():
    logging.config.dictConfig(DEFAULT_CONFIG)
    logger = logging.getLogger('test')
    logger.debug('test log')


# Generated at 2022-06-21 21:59:00.023877
# Unit test for function get_config

# Generated at 2022-06-21 21:59:06.486797
# Unit test for function getLogger
def test_getLogger():
    from datetime import datetime
    from functools import partial

    dt = partial(datetime.strftime, '%H:%M:%S')
    today = dt(datetime.now())
    # with logger_level(getLogger(), logging.DEBUG):
    #     getLogger().debug('sometext : %s', today)
    getLogger().debug('sometext : %s', today)


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 21:59:22.579178
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger(__name__)
    with logger_level(test_logger, logging.INFO):
        assert test_logger.level == logging.INFO
        assert test_logger.getEffectiveLevel() == logging.INFO
        with logger_level(test_logger, logging.DEBUG):
            assert test_logger.level == logging.DEBUG
            assert test_logger.getEffectiveLevel() == logging.DEBUG
        assert test_logger.level == logging.INFO
        assert test_logger.getEffectiveLevel() == logging.INFO
    assert test_logger.level == logging.NOTSET
    assert test_logger.getEffectiveLevel() == logging.NOTSET

# Generated at 2022-06-21 21:59:33.792862
# Unit test for function configure
def test_configure():
    import tempfile

    with tempfile.NamedTemporaryFile() as _temp:
        # Write JSON to the tempfile
        _temp.write(
            b"""
        {
            "formatters": {
                "colored": {
                    "()": "colorlog.ColoredFormatter",
                    "format": "%(log_color)s[%(asctime)s] %(message)s",
                    "datefmt": "%H:%M:%S"
                }
            },
            "handlers": {
                "test": {
                    "class": "logging.StreamHandler",
                    "formatter": "colored"
                }
            }
        }
        """
        )
        _temp.flush()

        configure(config=_temp.name, env_var=None)

        logger = logging.get

# Generated at 2022-06-21 21:59:39.468660
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2 == True
    assert _PyInfo().PY3 == False
    assert _PyInfo().string_types == (basestring,)
    assert _PyInfo().text_type == unicode
    assert _PyInfo().binary_type == str
    if not sys.version_info[0] == 2:
        assert _PyInfo().PY2 == False

# Generated at 2022-06-21 21:59:47.104559
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)

    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        logger.debug('This should not be logged')
        logger.info('This should be logged')
    logger.debug('This should be logged')



# Generated at 2022-06-21 21:59:48.591922
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-21 21:59:53.587208
# Unit test for function configure
def test_configure():
    # Test whether set up configuration works
    try:
        configure()
        assert True == True
    except Exception as e:
        assert True == False, "Exception {}".format(e)

    # Test whether it throws error when configuration is not valid
    try:
        configure({'a': 'b'})
        assert True == False, "Exception not thrown for invalid configuration"
    except Exception as e:
        assert True == True


if __name__ == '__main__':
    print(repr(logging.DEBUG))
    configure()
    test_configure()

# Generated at 2022-06-21 22:00:04.399478
# Unit test for function configure
def test_configure():
    import io
    import sys


# Generated at 2022-06-21 22:00:15.602243
# Unit test for function get_config
def test_get_config():
    assert get_config(config=None, env_var=None, default=None) == {}

    assert get_config(config=None, env_var='LOGGING', default=None) == {}
    assert get_config(config=None, env_var=None, default={'key': 1}) == {'key': 1}
    assert get_config(config=None, env_var='LOGGING', default={'key': 1}) == {'key': 1}
    assert get_config(config={'key': 1}, env_var=None, default=None) == {'key': 1}
    assert get_config(config={'key': 1}, env_var='LOGGING', default=None) == {'key': 1}

# Generated at 2022-06-21 22:00:27.513850
# Unit test for function getLogger
def test_getLogger():
    import logging
    import logging.config
    import sys

    # log = logging.getLogger('test_getLogger')
    # log.info('test_getLogger')

# Generated at 2022-06-21 22:00:31.623721
# Unit test for function getLogger
def test_getLogger():
    testlog = getLogger('test_getLogger')
    testlog.info('test logger')
    testlog.debug('test logger')
    testlog.error('test logger')


# Generated at 2022-06-21 22:00:42.687194
# Unit test for function configure
def test_configure():
    log = logging.getLogger('test_configure')
    configure()
    # the logger should inherit the level configured in the logging config
    log.info('test_info')
    log.warning('test_warning')
    log.debug('test_debug')



# Generated at 2022-06-21 22:00:47.231908
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert _PyInfo.PY3 == False
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str


# Generated at 2022-06-21 22:00:47.916545
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-21 22:00:55.129372
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    info = _PyInfo()
    assert isinstance(info.PY2, bool)
    assert isinstance(info.PY3, bool)
    if info.PY3:
        assert isinstance(info.string_types, tuple)
        assert isinstance(info.text_type(), str)
        assert isinstance(info.binary_type(), bytes)
    else:
        assert isinstance(info.string_types, tuple)
        assert isinstance(info.text_type(), unicode)
        assert isinstance(info.binary_type(), str)


# Generated at 2022-06-21 22:01:00.677310
# Unit test for function logger_level
def test_logger_level():
    """ Test case for logger_level"""

    with logger_level(get_logger(), logging.DEBUG):
        logger = get_logger(__name__)
        logger.info("This message should be logged")
        logger.debug("This message is logged as logger level is DEBUG")


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:01:11.596839
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    cfg = {
        'formatters': {
            'simple': {
                'format': '%(lineno)s: %(message)s',
            },
        },
        'handlers': {
            'console': {
                'level': 'DEBUG',
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
            },
        },
        'loggers': {
            'default': {
                'handlers': ['console'],
                'level': 'DEBUG',
                'propagate': False,
            },
        },
    }
    logging.config.dictConfig(cfg)
    log = get_logger('default')
    output = []


# Generated at 2022-06-21 22:01:23.000293
# Unit test for function configure
def test_configure():
    import json
    from colorlog import ColoredFormatter

    # test default configure
    configure()
    logger = logging.getLogger()
    assert isinstance(logger.handlers[0].formatter, ColoredFormatter)

    # test bare string
    cfg = json.dumps(DEFAULT_CONFIG)
    configure(cfg)
    logger = logging.getLogger()
    assert isinstance(logger.handlers[0].formatter, ColoredFormatter)

    # test json string
    cfg = json.dumps(DEFAULT_CONFIG)
    configure(cfg)
    logger = logging.getLogger()
    assert isinstance(logger.handlers[0].formatter, ColoredFormatter)


# Generated at 2022-06-21 22:01:34.439323
# Unit test for function get_config
def test_get_config():
    # Test with empty config string
    assert get_config('') is None

    # Test with a JSON string
    cfg = '{"version": 1, "formatters": {"simple": {"format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"}}, "handlers": {"console": {"class": "logging.StreamHandler", "level": "INFO", "formatter": "simple"}}, "root": {"handlers": ["console"]}}'

# Generated at 2022-06-21 22:01:38.019374
# Unit test for function getLogger
def test_getLogger():
    import logging
    logger = getLogger('test')
    logger.debug('test')
    logger.info('test')
    logger.warn('test')
    logger.error('test')
    logger.critical('test')


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:01:50.273421
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        print("This is a Python 2 console")
    else:
        print("This is a Python 3 console")
    assert isinstance('string', _PyInfo.string_types), 'Py2 is_str not working'
    assert 'string' in _PyInfo.string_types, 'Py2 is_str not working'

    assert isinstance(b'string', _PyInfo.binary_type), 'Py2 is_binary not working'
    assert b'string' in _PyInfo.binary_type, 'Py2 is_binary not working'

    assert isinstance(u'string', _PyInfo.text_type), 'Py2 is_text not working'
    assert u'string' in _PyInfo.text_type, 'Py2 is_text not working'


# Generated at 2022-06-21 22:02:11.487139
# Unit test for function configure
def test_configure():
    logging.basicConfig(level=logging.DEBUG)
    logging.getLogger('test_configure').info('test')
    configure()
    logging.getLogger('test_configure').info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:02:24.870277
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    try:
        raise Exception("I am error")
    except:
        logger.exception("Test logger_level")

    with logger_level(logger, logging.CRITICAL):
        assert logger.getEffectiveLevel() == logging.CRITICAL

    logger.warning("Test logger_level")
    assert logger.getEffectiveLevel() == logging.DEBUG
    with logger_level(logger, logging.CRITICAL):
        assert logger.getEffectiveLevel() == logging.CRITICAL

    logger.warning("Test logger_level")
    assert logger.getEffectiveLevel() == logging.CRITICAL

    try:
        raise Exception("I am error")
    except:
        logger.exception("Test logger_level")

logging.getLogger = get_logger


# Generated at 2022-06-21 22:02:35.231297
# Unit test for function configure
def test_configure():
    import logging
    import os
    import sys
    assert os.environ.get('LOGGING') == None

# Generated at 2022-06-21 22:02:37.518373
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(name='test')
    logger.info("test_getLogger")



# Generated at 2022-06-21 22:02:41.839205
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test_logger_level')
    with logger_level(log, logging.DEBUG):
        log.info('test_logger_level')



if __name__ == "__main__":
    # execute only if run as a script
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:02:42.868681
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test')
    logger.debug("hello")

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:02:46.095623
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test')
    assert isinstance(logger, logging.Logger)



# Generated at 2022-06-21 22:02:47.393344
# Unit test for function configure
def test_configure():
    configure()

# unit test for function get_logger

# Generated at 2022-06-21 22:02:54.115633
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert logger.level == logging.DEBUG
    assert logger.name == __name__

    logger = getLogger('test2')
    assert logger.level == logging.DEBUG
    assert logger.name == 'test2'



# Generated at 2022-06-21 22:02:56.936390
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    #assert isinstance(logger, logging.Logger)



# Generated at 2022-06-21 22:03:38.206563
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2 == (sys.version_info[0] == 2)
    assert _PyInfo().PY3 == (sys.version_info[0] == 3)

    if _PyInfo().PY3:
        assert _PyInfo().string_types == (str,)
        assert _PyInfo().text_type == str
        assert _PyInfo().binary_type == bytes
    else:  # PY2
        assert _PyInfo().string_types == (basestring,)
        assert _PyInfo().text_type == unicode
        assert _PyInfo().binary_type == str

# Generated at 2022-06-21 22:03:45.396443
# Unit test for function configure
def test_configure():
    import logging
    import os

    # Change to save directory
    os.chdir(os.path.dirname(__file__))

    # First, test for no configuration
    try:
        configure()
        assert False
    except ValueError as e:
        pass

    # Then, test for using default configuration
    configure(None, None, DEFAULT_CONFIG)
    logging.warning('test_configure_1')

    # Then, test for using configuration from json file
    configure('logging_config.json')
    logging.warning('test_configure_2')

    # Then, test for using configuration from yaml file
    configure('logging_config.yaml')
    logging.warning('test_configure_3')

    # Then, test for using configuration from environment variable

# Generated at 2022-06-21 22:03:54.800350
# Unit test for function configure
def test_configure():
    logging.log(logging.DEBUG, 'the root logger should have hander')
    log = logging.getLogger(__name__)
    # log.info('the root logger should have hander')
    log.info('the root logger should have hander')
    log.debug('the root logger should have hander')
    #logging.log(logging.DEBUG, 'the root logger should have hander')
    log.error('the root logger should have hander')

    log = logging.getLogger('requests')
    log.info('test')
    log.debug('test')
    log.error('test')


# Generated at 2022-06-21 22:04:01.906377
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

    if _PyInfo.PY2:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    else:  # PY3
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes



# Generated at 2022-06-21 22:04:06.151366
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert type(2) in _PyInfo.string_types
    assert type(u"abc") in _PyInfo.string_types
    assert type(2) not in _PyInfo.string_types

# Generated at 2022-06-21 22:04:09.857112
# Unit test for function getLogger
def test_getLogger():
    # Default usage
    assert get_logger().name == __name__

    # Without argument
    assert get_logger(None).name == __name__

    # With argument
    assert get_logger('test').name == 'test'



# Generated at 2022-06-21 22:04:11.394047
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test_getLogger')

# Generated at 2022-06-21 22:04:17.381205
# Unit test for function get_config
def test_get_config():
    from pprint import pprint
    from json import dumps
    from yaml import dump
    import copy

    default = copy.deepcopy(DEFAULT_CONFIG)
    config = dumps(default)
    
    default_config = get_config(config)
    assert default == default_config, 'get_config(dumps(config)) should return config'

    config = dump(default)
    default_config = get_config(config)
    assert default == default_config, 'get_config(dump(config)) should return config'

    default_config = get_config(default)
    assert default == default_config, 'get_config(config) should return config'



# Generated at 2022-06-21 22:04:19.325813
# Unit test for function getLogger
def test_getLogger():
    log1 = getLogger()
    log2 = getLogger(__name__)

    assert log1 == log2

# Generated at 2022-06-21 22:04:25.568595
# Unit test for function configure
def test_configure():
    import logging
    import logging.config

    configure()
    assert logging.getLogger().handlers[0].formatter.datefmt == DEFAULT_CONFIG['formatters']['colored']['datefmt']
    assert logging.getLogger().handlers[0].level == logging.DEBUG
    assert logging.getLogger().getEffectiveLevel() == logging.DEBUG
    assert logging.getLogger('requests').level == logging.INFO


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:05:46.372929
# Unit test for function logger_level
def test_logger_level():
    import mock
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        with mock.patch.object(logger, 'debug') as mock_debug:
            logger.debug('Hello, world!')
            mock_debug.assert_called_once_with('Hello, world!')



# Generated at 2022-06-21 22:05:56.749049
# Unit test for function getLogger
def test_getLogger():
    """
    >>> getLogger()
    <logging.RootLogger object at 0x7f2e409a2eb8>
    """
    root_logger = getLogger()
#    print(root_logger)
    assert isinstance(root_logger, logging.Logger)

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    fmt = logging.Formatter('%(asctime)s [%(process)d-%(thread)d] %(name)s-%(levelname)s-%(message)s')
    ch.setFormatter(fmt)

    root_logger.addHandler(ch)

    root_logger.info('hello world')


if __name__ == "__main__":
    import doctest
    doctest.test

# Generated at 2022-06-21 22:05:58.407080
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    assert isinstance(logger, logging.Logger), 'Failed to get logger object'

# Generated at 2022-06-21 22:06:02.182977
# Unit test for function get_config
def test_get_config():
    config = get_config(default=None)
    assert config == DEFAULT_CONFIG
    config = get_config(env_var='LOGGING')
    assert config == DEFAULT_CONFIG
    test_dict = dict(logger=dict(level=10))
    config = get_config(given=test_dict, default=None)
    assert config == test_dict
    test_json = '{"logger": {"level": 10}}'
    config = get_config(given=test_json, default=None)
    assert config == test_dict
    test_yaml = 'logger:\n  level: 10'
    config = get_config(given=test_yaml, default=None)
    assert config == test_dict

# Generated at 2022-06-21 22:06:06.122153
# Unit test for function getLogger
def test_getLogger():
    l = getLogger()

    l.debug("Debug")
    l.info("Info")
    l.warning("Warning")
    l.error("Error")
    l.critical("Critical")


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 22:06:14.355887
# Unit test for function configure
def test_configure():
    configure(default=DEFAULT_CONFIG)
    log = logging.getLogger(__name__)
    log.info("configure")
    log.setLevel(logging.DEBUG)
    log.debug("debug")
    log.info("info")
    log.warning("warning")
    log.error("error")
    log.critical("critical")


# Generated at 2022-06-21 22:06:18.355780
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)


# Generated at 2022-06-21 22:06:24.689984
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import os

    logger = logging.getLogger('test_logger_level')

    logger.info('not shown')
    with logger_level(logger, logging.DEBUG):
        logger.info('info shown')
        logger.debug('debug shown')

    logger.info('debug not shown')

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-21 22:06:31.379707
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == sys.version_info[0] == 2
    assert _PyInfo.PY3 == sys.version_info[0] == 3
    assert _PyInfo.PY3 != _PyInfo.PY2
    if _PyInfo.PY3:
        assert _PyInfo.text_type == str
    else:
        assert _PyInfo.text_type == unicode

# Generated at 2022-06-21 22:06:32.397495
# Unit test for function configure
def test_configure():
    configure()
    assert True