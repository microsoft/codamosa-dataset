

# Generated at 2022-06-21 21:57:33.197185
# Unit test for function get_config
def test_get_config():
    yml_config = '\n'.join([
        "root:",
        "  level: DEBUG",
        "  handlers: [console, file_handler]",
        "handlers:",
        "  console:",
        "    class: logging.StreamHandler",
        "    formatter: colored",
        "    level: DEBUG",
    ])

    dict_config = {
        'root': {
            'level': 'DEBUG',
        },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'colored',
                'level': 'DEBUG',
            },
        },
    }

    # Test json string
    config = get_config(json.dumps(dict_config))
    assert config == dict_config

    # Test json dict
   

# Generated at 2022-06-21 21:57:41.481015
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance("str", _PyInfo.string_types)
    assert not isinstance(b"str", _PyInfo.string_types)
    assert isinstance("str", _PyInfo.string_types)
    assert not isinstance("str", _PyInfo.binary_type)
    assert not isinstance("str", _PyInfo.text_type)
    assert isinstance("str".encode(), _PyInfo.string_types)

# Generated at 2022-06-21 21:57:47.546053
# Unit test for function logger_level
def test_logger_level():
    # setup
    logger_name = 'test_logger'
    initial_level = logging.DEBUG
    logger = logging.getLogger(logger_name)
    logger.setLevel(initial_level)

    with logger_level(logger, logging.CRITICAL):
        pass

    # assert
    assert logger.level == initial_level

    # teardown
    del logging.Logger.manager.loggerDict[logger_name]

# Generated at 2022-06-21 21:57:52.670060
# Unit test for function get_config
def test_get_config():

    # Test for empty settings
    assert get_config() is None

    # Test for bare settings
    assert get_config(config={'1': '2'}) == {'1': '2'}

    # Test for JSON settings
    assert get_config(config='{"1": "2"}') == {"1": "2"}

    # Test for YAML settings
    assert get_config(config='1: 2') == {"1": "2"}


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:58:03.154115
# Unit test for function get_config
def test_get_config():
    import json

    config = get_config(config={'test': True}, env_var=None, default=None)
    assert config == {'test': True}

    config = get_config(config='{"test": true}', env_var=None, default=None)
    assert config == json.loads('{"test": true}')

    config = get_config(config='test: true', env_var=None, default=None)
    assert config == {"test": True}

    try:
        get_config(config='test: true', env_var=None, default='{"test": true}')
        assert False
    except ValueError:
        assert True


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()

# Generated at 2022-06-21 21:58:04.971473
# Unit test for function configure
def test_configure():

    configure()

    logger = get_logger()
    logger.info('test_configure')

# Generated at 2022-06-21 21:58:05.581158
# Unit test for function configure
def test_configure():
    configure()

# Generated at 2022-06-21 21:58:10.792896
# Unit test for function get_config
def test_get_config():
    config = get_config(
        given='{ "version": 1 }',
        env_var='',
        default=None,
    )
    assert config['version'] == 1, "Given a string of json, should parse json"

    config = get_config(
        given='version: 1',
        env_var='',
        default=None,
    )
    assert config['version'] == 1, "Given a string of yaml, should parse yaml"

if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-21 21:58:12.681167
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.ERROR):
        assert log.level == logging.ERROR
        log.info('test')
        assert log.level == logging.ERROR
    assert log.level != logging.ERROR



# Generated at 2022-06-21 21:58:24.021898
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    p = _PyInfo()
    assert p.PY2 or p.PY3, "PY2 and PY3 must be exclusive"
    # TODO: What's the point of this?
    # assert (isinstance("", unicode), int) == (p.PY2, p.PY3), "PY2 and PY3 are wrong"
    assert (isinstance("", p.string_types[0]), p.text_type) == (p.PY2, p.PY3), "PY2 and PY3 are wrong"
    assert (isinstance(u"", p.string_types[0]), p.text_type) == (p.PY2, p.PY3), "PY2 and PY3 are wrong"

# Generated at 2022-06-21 21:58:35.934177
# Unit test for function get_config

# Generated at 2022-06-21 21:58:40.172590
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str
    assert isinstance("string", _PyInfo.string_types)

# Generated at 2022-06-21 21:58:43.811764
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 is True
    assert _PyInfo.PY2 is False
    assert _PyInfo.string_types == (str,)
    assert _PyInfo.text_type == str
    assert _PyInfo.binary_type == bytes

# Generated at 2022-06-21 21:58:51.754171
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    if _PyInfo.PY2:
        assert _PyInfo.string_types == (str, unicode)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    else:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:58:52.848345
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 is True
    # assert _PyInfo.PY2 is True



# Generated at 2022-06-21 21:58:57.950684
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        assert log.isEnabledFor(logging.DEBUG)
        log.info("Hello world")
    assert not log.isEnabledFor(logging.DEBUG)
    log.info("Should not be printed")


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:59:03.725355
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test.logger_level')
    logger.setLevel(logging.WARNING)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')



# Generated at 2022-06-21 21:59:10.944464
# Unit test for function get_config
def test_get_config():
    from decimal import Decimal
    from json import loads
    from yaml import load

    assert get_config(default = {'a': 1}) == {'a': 1}
    assert get_config(default = '{"a": 1}') == {'a': 1}
    assert get_config(default = b'{"a": 1}') == {'a': 1}
    assert get_config(default = 'a: 1') == {'a': 1}
    assert get_config(default = b'a: 1') == {'a': 1}

    assert get_config(default = '{"a": 1',
                      env_var = 'LOGGING_DEFAULT') == {'a': 1}

# Generated at 2022-06-21 21:59:13.051841
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')

# Generated at 2022-06-21 21:59:17.831829
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default='{"root": {"level": "DEBUG"}}') == {'root': {'level': 'DEBUG'}}
    assert get_config(env_var='LOGGING', default='{"root": {"level": "DEBUG"}}') == {'root': {'level': 'DEBUG'}}
    assert get_config(config='{"root": {"level": "DEBUG"}}') == {'root': {'level': 'DEBUG'}}
    assert get_config(config='{"root": {"level": "DEBUG"}}') == {'root': {'level': 'DEBUG'}}

# Generated at 2022-06-21 21:59:33.782049
# Unit test for function configure
def test_configure():
    import json
    import os
    os.environ.update(
        {
            'LOGGING': json.dumps({
                'version': 1,
                'handlers': {
                    'console': {
                        'class': 'logging.StreamHandler',
                        'formatter': 'colored',
                        'level': 'DEBUG',
                    },
                },
                'root': {
                    'handlers': ['console'],
                    'level': 'DEBUG',
                },
                'loggers': {
                    'requests': {
                        'level': 'INFO',
                    },
                },
            })
        }
    )

    configure()

    logger = logging.getLogger()
    assert logger.level == logging.DEBUG
    logger = logging.getLogger('requests')
    assert logger.level == logging.INFO




# Generated at 2022-06-21 21:59:38.214207
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.debug("test debug")
    log.info("test info")
    log.critical("test critical")
    log.error("test error")
    log.warning("test warning")

test_getLogger()

# Generated at 2022-06-21 21:59:42.217883
# Unit test for function configure
def test_configure():
    import tempfile
    import shutil
    import json

    @contextmanager
    def temp_directory():
        tmpdir = tempfile.mkdtemp()
        try:
            yield tmpdir
        finally:
            shutil.rmtree(tmpdir)

    if not _PyInfo.PY2:
        from unittest import mock
    else:
        import mock
    with temp_directory() as tmpdir:
        logging_conf_path = os.path.join(tmpdir, 'logging.json')
        with open(logging_conf_path, 'w') as fp:
            json.dump(DEFAULT_CONFIG, fp)

        patcher = mock.patch('os.environ', {'LOGGING': logging_conf_path})
        with patcher:
            configure()

# Generated at 2022-06-21 21:59:50.903512
# Unit test for function get_config
def test_get_config():
    logging.shutdown()
    assert get_config(given=None, env_var=None, default=None) is None
    assert get_config(given=DEFAULT_CONFIG, env_var=None, default=None) == DEFAULT_CONFIG
    os.environ['LOGGING'] = json.dumps(DEFAULT_CONFIG)
    assert get_config(given=None, env_var="LOGGING", default=None) == DEFAULT_CONFIG
    del os.environ['LOGGING']
    assert get_config(given=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    os.environ['LOGGING'] = json.dumps(DEFAULT_CONFIG)

# Generated at 2022-06-21 22:00:00.086149
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    msg = 'my_log_level'
    with logger_level(log, logging.INFO):
        log.debug(msg)
    assert msg in log.handlers[0].stream.getvalue()
    with logger_level(log, logging.WARN):
        log.debug(msg)
    assert msg not in log.handlers[0].stream.getvalue()
    log.debug(msg)

# Generated at 2022-06-21 22:00:08.504991
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    assert log.level == logging.DEBUG, "log level: expected %s, got %s" % (logging.DEBUG, log.level)
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO, "log level: expected %s, got %s" % (logging.INFO, log.level)
    assert log.level == logging.DEBUG, "log level: expected %s, got %s" % (logging.DEBUG, log.level)



# Generated at 2022-06-21 22:00:14.511457
# Unit test for function get_config
def test_get_config():
    config = '''
    {
      "version": 1,
      "formatters": {
        "f": {
          "format": "%(asctime)s %(funcName)s %(lineno)d %(levelname)s %(message)s"
        }
      },
      "handlers": {
        "h": {
          "class": "logging.StreamHandler",
          "formatter": "f",
          "level": "DEBUG"
        }
      },
      "loggers": {
        "": {
          "handlers": [
            "h"
          ],
          "level": "DEBUG"
        }
      }
    }
    '''
    assert get_config(config) == DEFAULT_CONFIG


# Generated at 2022-06-21 22:00:18.498013
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True or _PyInfo.PY2 == False
    assert _PyInfo.PY3 == True or _PyInfo.PY3 == False

# Generated at 2022-06-21 22:00:22.652875
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), logging.CRITICAL):
        log = getLogger()
        assert log.isEnabledFor(logging.CRITICAL)
        assert not log.isEnabledFor(logging.DEBUG)

# Generated at 2022-06-21 22:00:30.987586
# Unit test for function configure
def test_configure():
    import subprocess
    import shutil

    config = """
    version: 1
    disable_existing_loggers: False
    formatters:
        simple:
            format: '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s'
            datefmt: '%%Y-%%m-%%d %%H:%%M:%%S'
    handlers:
        console:
            class: logging.StreamHandler
            formatter: simple
            level: DEBUG
    root:
        handlers: [console]
        level: DEBUG
    loggers:
        requests:
            level: INFO
    """

# Generated at 2022-06-21 22:00:38.189683
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY3 is True

# Generated at 2022-06-21 22:00:40.721889
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("Test logger level")



# Generated at 2022-06-21 22:00:42.753338
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test_getLogger')
    logger.info('test')
    logger.warn('test')
    logger.error('test')


# Generated at 2022-06-21 22:00:48.405401
# Unit test for function getLogger
def test_getLogger():
    expected_name = __name__
    log = getLogger()
    assert log.name == expected_name
    log.debug('test message')
    log.info('gg')


__all__ = [
    'getLogger',
    'get_logger',
    'configure',
    'get_config',
    'DEFAULT_CONFIG',
]



# Generated at 2022-06-21 22:00:56.211529
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    from unittest import TestCase
    import sys
    test = TestCase()
    py2 = TestCase()
    py3 = TestCase()
    py2.assertEqual(2, sys.version_info.major)
    py3.assertEqual(3, sys.version_info.major)

    if _PyInfo.PY2:
        test.assertEqual(basestring, _PyInfo.text_type)
        test.assertEqual(str, _PyInfo.binary_type)
        test.assertEqual((basestring,), _PyInfo.string_types)
    elif _PyInfo.PY3:
        test.assertEqual(str, _PyInfo.text_type)
        test.assertEqual(bytes, _PyInfo.binary_type)

# Generated at 2022-06-21 22:01:00.215078
# Unit test for function get_config
def test_get_config():
    config = get_config(env_var='test')
    assert config is DEFAULT_CONFIG
    config = get_config(default=None)
    assert config is None
    config = get_config('')
    assert config is None

# Generated at 2022-06-21 22:01:05.124279
# Unit test for function configure
def test_configure():
    log = logging.getLogger('logging.test')
    configure()
    log.info('test')
    log.warning('test')
    log.debug('test')


# Generated at 2022-06-21 22:01:15.865883
# Unit test for function configure

# Generated at 2022-06-21 22:01:18.303578
# Unit test for function getLogger
def test_getLogger():
    # Get logger and configure it
    logger = get_logger('test_logger')
    configure()
    assert logger.level == logging.DEBUG

    # Get logger and check its name
    logger2 = get_logger()
    assert logger2.name == 'test_getLogger'



# Generated at 2022-06-21 22:01:22.319406
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test')

    logger = getLogger('test2')
    logger.info('test2')

# Generated at 2022-06-21 22:01:35.068748
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.debug('test_config')
    log.info('Test_config')
    # assert False, "test_configure"

# Generated at 2022-06-21 22:01:46.276200
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance('test', _PyInfo.string_types)
    assert isinstance(u'test', _PyInfo.string_types)
    assert not isinstance(1, _PyInfo.string_types)

    assert isinstance(b'test', _PyInfo.binary_type)
    assert isinstance('test', _PyInfo.text_type)
    assert not isinstance(u'test', _PyInfo.binary_type)
    assert not isinstance(b'test', _PyInfo.text_type)
    assert not isinstance(1, _PyInfo.text_type)
    assert not isinstance(1, _PyInfo.binary_type)

# Generated at 2022-06-21 22:01:51.451368
# Unit test for function getLogger
def test_getLogger():
    logging.basicConfig(level=logging.DEBUG)
    log = getLogger()
    log.info("test")
    log.setLevel(logging.DEBUG)
    log.info("test")
    # log.debug("test")  # Debug message should be ignored
    print("test_getLogger is ok")

test_getLogger()

# Generated at 2022-06-21 22:01:55.590846
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger=logger, level=logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET

# Generated at 2022-06-21 22:02:02.467751
# Unit test for function configure
def test_configure():
    logging.getLogger(__name__).propagate=False
    get_logger(__name__).propagate=False

    configure()
    configure(default=DEFAULT_CONFIG)
    configure(config=DEFAULT_CONFIG)
    try:
        configure({})
    except TypeError as exc:
        try:
            logging.basicConfig(**{})
        except Exception as inner_exc:
            raise inner_exc from exc



# Generated at 2022-06-21 22:02:04.243902
# Unit test for function getLogger
def test_getLogger():
    logging.info(getLogger())


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 22:02:10.877064
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')

    # Test that logger_level actually works
    with logger_level(log, logging.WARNING):
        log.debug("you shouldn't see this")
        log.warning("you should see this")

    # Test that logger_level doesn't break anything
    log.debug("you should see this")



# Generated at 2022-06-21 22:02:15.398919
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('test_level')
    log.setLevel(logging.DEBUG)

    logger_level_test_var = 1

    def test_fn():
        log.info("test_fn start")
        log.warn("test_fn warn")
        log.debug("test_fn debug")

    with logger_level(log, logging.ERROR):
        log.warn("is this printed")
        log.error("is this printed")

    with logger_level(log, logging.DEBUG):
        test_fn()


if __name__ == '__main__':
    import nose

    nose.main()

# Generated at 2022-06-21 22:02:19.175001
# Unit test for function getLogger
def test_getLogger():
    getLogger().debug('test')
    getLogger().info('test')
    getLogger().warning('test')
    getLogger().error('test')
    getLogger().critical('test')


# Generated at 2022-06-21 22:02:21.089538
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    configure()
    logger.info('test')

# Generated at 2022-06-21 22:02:39.972865
# Unit test for function get_config

# Generated at 2022-06-21 22:02:47.572094
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    logger.setLevel(logging.INFO)
    assert logger.level == logging.INFO
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        assert logger.level == logging.DEBUG
    logger.debug("debug message")
    logger.info("info message")
    assert logger.level == logging.INFO

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-21 22:02:52.429630
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    logger.info('test info')
    logger.debug('test debug')



# Generated at 2022-06-21 22:02:59.322948
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert isinstance('', pyinfo.string_types)
    assert not isinstance(['', ''], pyinfo.string_types)

    assert isinstance('', pyinfo.text_type)
    assert not isinstance(['', ''], pyinfo.text_type)

    assert isinstance(b'', pyinfo.binary_type)
    assert not isinstance('', pyinfo.binary_type)

# Generated at 2022-06-21 22:03:03.974758
# Unit test for function configure

# Generated at 2022-06-21 22:03:06.739510
# Unit test for function configure
def test_configure():
    try:
        configure()
    except TypeError as exc:
        try:
            logging.basicConfig(**cfg)
        except Exception as inner_exc:
            raise inner_exc from exc



# Generated at 2022-06-21 22:03:08.328562
# Unit test for function configure
def test_configure():
    configure()
    assert(logging.getLogger().getEffectiveLevel() == logging.DEBUG)


# Generated at 2022-06-21 22:03:10.920305
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    assert log.name == 'tests.test_utils'

# Generated at 2022-06-21 22:03:19.798368
# Unit test for function get_config

# Generated at 2022-06-21 22:03:21.662754
# Unit test for function configure
def test_configure():
    configure()
    get_logger().info('hello')

# Generated at 2022-06-21 22:03:48.932754
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # create a dummy class, because _PyInfo is not public
    class PyInfo:
        PY2 = (1, 0)
        PY3 = (2, 0)

    myPyInfo = PyInfo()
    assert _PyInfo.PY2 == myPyInfo.PY2
    assert _PyInfo.PY3 == myPyInfo.PY3

# Generated at 2022-06-21 22:03:53.987463
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__ + '.test_logger_level')
    logger.info('This should be printed')
    with logger_level(logger, logging.WARNING):
        logger.info('This should NOT be printed')
        logger.warning('But this should be!')



# Generated at 2022-06-21 22:03:55.741407
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3, "Neither Python 2 or 3."



# Generated at 2022-06-21 22:04:00.191964
# Unit test for function logger_level
def test_logger_level():
    root_logger = logging.getLogger()
    get_logger('test_logger_level').debug('test')
    with logger_level(root_logger, logging.CRITICAL):
        get_logger('test_logger_level').debug('test')
    get_logger('test_logger_level').debug('test')

# Generated at 2022-06-21 22:04:05.401052
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.WARN):
        log.debug('debug')
        log.info('info')
        log.warn('warn')


# Generated at 2022-06-21 22:04:16.349364
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    try:
        assert _PyInfo.PY2 is not False
    except AssertionError:
        raise AssertionError('Unexpected value for class attribute PY2')
    try:
        assert _PyInfo.PY3 is not False
    except AssertionError:
        raise AssertionError('Unexpected value for class attribute PY3')

    if _PyInfo.PY2:
        try:
            assert isinstance('', _PyInfo.string_types)
            assert isinstance(u'', _PyInfo.string_types)
            assert isinstance(b'', _PyInfo.string_types)
            assert isinstance(u'', _PyInfo.string_types)
        except AssertionError:
            raise AssertionError('Unexpected value for class attribute string_types')

# Generated at 2022-06-21 22:04:20.306636
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    logger.warning('Warning before')
    with logger_level(logger, logging.CRITICAL):
        logger.warning('Warning after')
        logger.critical('Critical')
    logger.warning('Warning after')

# Generated at 2022-06-21 22:04:22.317229
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print('test___PyInfo')
    assert _PyInfo.PY2 or _PyInfo.PY3



# Generated at 2022-06-21 22:04:25.177014
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    assert logger.level == 10  # Warn by default
    with logger_level(logger, 5):
        assert logger.level == 5  # Debug
    assert logger.level == 10  # Warn again

# Generated at 2022-06-21 22:04:26.280989
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is not _PyInfo.PY3

# Generated at 2022-06-21 22:05:20.402685
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert isinstance(logger, logging.Logger)
    assert logger.name == '__main__'


# Generated at 2022-06-21 22:05:24.887081
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info("test")
    log.info("test")

    configure(default=DEFAULT_CONFIG)
    log = getLogger()
    log.info("test")
    log.info("test")

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:05:26.783522
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    print(logger)
    assert logger.name == "__main__"

# Unit testing for function get_logger

# Generated at 2022-06-21 22:05:37.960805
# Unit test for function get_config
def test_get_config():
    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger()

    # Custom configuration
    cfg = dict(
        version=1,
        formatters={
            'simple': {
                'format': '%(asctime)s %(levelname)s %(message)s',
            },
        },
        handlers={
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
                'level': logging.DEBUG,
            },
        },
        root=dict(handlers=['console'], level=logging.DEBUG),
    )

    # Setting configuration to local variable
    config = cfg
    logging.config.dictConfig(config)
    log.info('INFO message')

    # Setting configuration to environment variable
    config = json

# Generated at 2022-06-21 22:05:42.783888
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger,logging.DEBUG):
        logger.debug("Test Debug")
    with logger_level(logger,logging.INFO):
        logger.info("Test INFO")
    with logger_level(logger,logging.WARNING):
        logger.warning("Test WARNING")
    with logger_level(logger,logging.ERROR):
        logger.error("Test ERROR")


# Generated at 2022-06-21 22:05:45.477173
# Unit test for function configure
def test_configure():
    log = logging.getLogger('test_configure')
    log.error('error message')
    log.info('info message')
    log.debug('debug message')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:05:55.616551
# Unit test for function configure
def test_configure():
    conf = {
        'version': 1,
        'handlers': {
            'file': {
                'class': 'logging.FileHandler',
                'filename': 'logging_util.log',
                'formatter': 'simple'
            },
        },
        'formatters': {
            'simple': {
                'format': '%(asctime)s| %(message)s %(levelname)s',
                'datefmt': '%Y-%m-%d %H:%M:%S',
            },
        },
        'root': {
            'handlers': ['file'],
            'level': 'DEBUG'
        }
    }
    configure(conf)


# Generated at 2022-06-21 22:06:03.244493
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

    if _PyInfo.PY2:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    else:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:06:05.757414
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:06:15.404629
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    >>> _PyInfo().PY2 == sys.version_info[0] == 2
    True
    >>> _PyInfo().PY3 == sys.version_info[0] == 3
    True
    >>> _PyInfo().string_types
    (<class 'basestring'>,)
    >>> _PyInfo().text_type
    <class 'str'>
    >>> _PyInfo().binary_type
    <class 'bytes'>
    """
    pass


# Generated at 2022-06-21 22:07:19.498661
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 == (3 == sys.version_info[0])
    assert _PyInfo.PY2 == (2 == sys.version_info[0])

    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:  # PY2
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str

