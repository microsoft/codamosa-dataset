

# Generated at 2022-06-21 21:57:18.907962
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger(__name__)
    log.info('test')


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:57:29.007376
# Unit test for function get_config
def test_get_config():
    """Unit test for function get_config()
    """
    from nose.tools import assert_equal, assert_raises
    from pprint import pformat

    def assert_equal_pp(obj, other):
        if obj != other:
            raise AssertionError(pformat((obj, other)))

    def assert_is_instance_pp(obj, types):
        assert isinstance(obj, types), pformat((obj, types))

    # Test no config
    assert_raises(ValueError, get_config)

    # Test str config
    assert_is_instance_pp(get_config(config='{}'), dict)

    # Test default config
    assert_is_instance_pp(get_config(default=DEFAULT_CONFIG), dict)

    # Test given config

# Generated at 2022-06-21 21:57:37.140865
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

    with logger_level(logger, logging.WARNING):
        logger.debug('test')
        logger.warning('test')
    logger.debug('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 21:57:41.033292
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    import colorlog
    with logger_level(log, colorlog.logging.CRITICAL):
        log.error("This is log.error")
        log.critical("This is log.critical")
    log.debug("This is log.debug")



# Generated at 2022-06-21 21:57:50.107165
# Unit test for function getLogger
def test_getLogger():
    import re
    import sys
    import os
    import shutil

    # Check that logging module is imported
    try:
        import logging
    except ImportError:
        print("Logging module is not available")
        sys.exit()

    # Check that colorlog module is available
    try:
        import colorlog
    except ImportError:
        print("colorlog module is not available")
        sys.exit()

    # Check that YAML module is available
    try:
        import yaml
    except ImportError:
        print("YAML module is not available")
        sys.exit()

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    os.makedirs(temp_dir)

    # Create temporary test files

# Generated at 2022-06-21 21:57:55.324137
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    configure()
    logger.setLevel(logging.DEBUG)

    with logger_level(logger, logging.INFO):
        logger.debug("Debug not shown")
    logger.debug("Debug shown")

    with logger_level(logger, logging.WARNING):
        logger.info("Info not shown")
    logger.info("Info shown")

    assert True

# Unit tests for function configure

# Generated at 2022-06-21 21:57:58.021625
# Unit test for function getLogger
def test_getLogger():
    name = 'getLogger_test'
    log = getLogger(name)
    log.debug('DEBUG')
    log.info('INFO')
    log.warning('WARNING')
    log.error('ERROR')
    log.critical('CRITICAL')


# Generated at 2022-06-21 21:57:59.718579
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')

# Generated at 2022-06-21 21:58:08.753634
# Unit test for function logger_level
def test_logger_level():
    import sys
    import tempfile

    with tempfile.TemporaryFile(mode='w+') as f:
        logger = logging.getLogger('foo')
        logger.setLevel(logging.DEBUG)
        logger.addHandler(logging.StreamHandler(f))

        with logger_level(logger, logging.WARNING):
            logger.debug('foo')
            logger.info('bar')
            logger.warning('baz')
            logger.error('boo')
            logger.critical('bam')

        f.seek(0)
        for line in f:
            assert "baz" in line
            assert "boo" in line
            assert "bam" in line

        f.seek(0)
        assert "foo\nbar" not in f.read()

# Generated at 2022-06-21 21:58:20.900563
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.level = logging.INFO
    assert logger.level == logging.INFO, 'initial logger level is not correct'

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG, 'logger level is not correct for with block'
    assert logger.level == logging.INFO, 'logger level is not correct after with block'

# This would be the correct way to get the logger namespace
#  from a decorator.
#
# def _namespace_for_callable(callable):
#     """
#     Derive a namespace from the module containing the callable.
#
#     Either the module or the class containing the callable will be
#     used. If the callable is an instance method, the class takes
#     precedent.
#
#     :param call

# Generated at 2022-06-21 21:58:35.565682
# Unit test for function logger_level
def test_logger_level():
    """Set logger level to `level` within a context block. Don't use this except for debugging please, it's gross."""
    import logbook
    log = logging.getLogger(__name__)
    log2 = logbook.Logger(__name__)
    log.debug('test')
    assert log.isEnabledFor(logging.DEBUG)
    with logger_level(log, logging.WARNING):
        log.debug('test!')
        assert not log.isEnabledFor(logging.DEBUG)
    log.debug('test')
    assert log.isEnabledFor(logging.DEBUG)
    log2.debug('test')
    assert log2.is_enabled_for(logbook.DEBUG)
    with logger_level(log2, logbook.WARNING):
        log2.debug('test!')
        assert not log

# Generated at 2022-06-21 21:58:38.211948
# Unit test for function configure
def test_configure():
    get_logger().debug("test")
    get_logger().info("test")


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 21:58:39.626353
# Unit test for function configure
def test_configure():
    configure()
    logging.debug('test')

# Generated at 2022-06-21 21:58:45.561445
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test-logger-level')
    logging.basicConfig()
    
    with logger_level(logger, logging.INFO):
        logger.info('Logger: Level: INFO')
        logger.debug('Logger: Level: DEBUG')
        logger.error('Logger: Level: ERROR')
    
    logger.info('After logger_level')
    logger.debug
    logger.error



# Generated at 2022-06-21 21:58:56.308455
# Unit test for function get_config
def test_get_config():
    import os

# Generated at 2022-06-21 21:59:06.366139
# Unit test for function get_config
def test_get_config():
    # Test configuration is read from environment variable
    os.environ["LOGGING"] = ''
    config = get_config(env_var='LOGGING')
    assert config == DEFAULT_CONFIG

    # Test basic configuration
    config = get_config(config='basicConfig')
    assert(config['format'] == '%(asctime)s %(message)s')

    # Test configuration as JSON string
    config = get_config(config='{"format":"%(asctime)s %(message)s"}')
    assert(config['format'] == '%(asctime)s %(message)s')

    # Test configuration as JSON string
    config = get_config(config='format: "%(asctime)s %(message)s"')

# Generated at 2022-06-21 21:59:11.031553
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    if _PyInfo.PY2:
        assert _PyInfo.text_type == unicode
    if _PyInfo.PY3:
        assert _PyInfo.text_type == str


# Generated at 2022-06-21 21:59:14.918192
# Unit test for function getLogger
def test_getLogger():
    """
        Test function getLogger
        :return:
        """
    log = getLogger(__name__)
    print ('log=', log)
    log.info('test')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 21:59:21.967170
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()
    log = get_logger()
    with logger_level(log, logging.ERROR):
        try:
            log.debug("This should not print")
            log.critical("This should print")
        except Exception as exc:
            print("Exception: ", exc)
        else:
            print("Debug message does not print")
    log.critical("This should print")

if __name__ == '__main__':
    get_logger().info('Using default logging configuration.')
    test_logger_level()

# Generated at 2022-06-21 21:59:29.018864
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 ^ _PyInfo.PY3
    assert not _PyInfo.PY2 or not _PyInfo.PY3

    if _PyInfo.PY2:
        assert type('hello') in _PyInfo.string_types
    elif _PyInfo.PY3:
        assert type('hello') in _PyInfo.string_types

    assert type(u'hello') == _PyInfo.text_type



# Generated at 2022-06-21 21:59:49.015090
# Unit test for function logger_level
def test_logger_level():
    import logging
    import io

    buffer = io.StringIO()

    log = logging.getLogger('test_logger_level')
    log.setLevel(logging.INFO)
    log.addHandler(logging.StreamHandler(buffer))

    log.info('Logging @ INFO')
    log.debug('Logging @ DEBUG')
    log.error('Logging @ ERROR')

    assert buffer.getvalue() == 'Logging @ INFO\nLogging @ ERROR\n'

    buffer.seek(0)
    buffer.truncate()

    with logger_level(log, logging.DEBUG):
        log.info('Logging @ INFO')
        log.debug('Logging @ DEBUG')
        log.error('Logging @ ERROR')


# Generated at 2022-06-21 21:59:54.961970
# Unit test for function configure
def test_configure():
    import logging.config

    # Testing for ERROR logger level
    conf = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'standard': {
                'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
            },
        },
        'handlers': {
            'default': {
                'level': 'ERROR',
                'formatter': 'standard',
                'class': 'logging.StreamHandler',
            },
        },
        'loggers': {
            '': {
                'handlers': ['default'],
                'level': 'INFO',
                'propagate': True
            }
        }
    }
    configure(conf)
    logger = logging.getLogger()

# Generated at 2022-06-21 22:00:04.655904
# Unit test for function get_config
def test_get_config():
    config_json = '{"root": {"level": "DEBUG"}}'
    config_dict = {'root': {'level': 'DEBUG'}}

    # None
    assert get_config() is None

    # Given JSON string
    assert get_config(config_json) == config_dict
    # Given dict
    assert get_config(config_dict) == config_dict

    # Given JSON string with env_var
    os.environ['LOGGING'] = config_json
    assert get_config(env_var='LOGGING') == config_dict
    # Given dict with env_var
    os.environ['LOGGING'] = json.dumps(config_dict)
    assert get_config(env_var='LOGGING') == config_dict

    # Given JSON string with default

# Generated at 2022-06-21 22:00:08.089878
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert not _PyInfo.PY2
    assert _PyInfo.PY3
    assert _PyInfo.string_types == (str,)
    assert _PyInfo.text_type == str
    assert _PyInfo.binary_type == bytes



# Generated at 2022-06-21 22:00:14.423238
# Unit test for function getLogger
def test_getLogger():
    import tempfile
    import logging

    tmp_file = tempfile.mkstemp()[1]

    DEBUG_CONFIG = {
        'version': 1,
        'disable_existing_loggers': False,
        'handlers': {
            'file': {
                'class': 'logging.FileHandler',
                'filename': tmp_file,
                'formatter': 'colored',
                'level': logging.DEBUG,
            },
        },
        'root': {
            'handlers': ['file'],
            'level': logging.DEBUG
        },
    }
    log = get_logger('test')
    configure(DEBUG_CONFIG)
    log.debug('this is a debug message')
    log.info('this is an info message')
    log.warning('this is a warning message')

# Generated at 2022-06-21 22:00:16.984297
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    assert log.debug('debugging')
    assert log.info('info')
    assert log.warning('warning')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:00:27.179477
# Unit test for function get_config
def test_get_config():
    assert get_config(config=None, env_var='LOGGING') == DEFAULT_CONFIG
    assert get_config(config='{"version": 1}', env_var=None) == {'version': 1}
    assert get_config(config=None, env_var=None, default={'version': 1}) == {'version': 1}
    assert get_config(config=None, env_var=None, default=None) is None
    assert get_config(config="{bad_json", env_var=None, default={}) == {}

if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-21 22:00:30.427413
# Unit test for function configure
def test_configure():
    configure()

    # The above will raise an exception if it's not configured correctly,
    # so it's not really testable.



# Generated at 2022-06-21 22:00:33.089391
# Unit test for function getLogger
def test_getLogger():
    log = get_logger('test')
    assert log is not None

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:00:36.222401
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    logger.info('test')

    logger = get_logger('test2')
    logger.info('test2')



# Generated at 2022-06-21 22:00:52.290994
# Unit test for function configure
def test_configure():
    def test_log_msg():
        log.info('test')
        log.warning('test')
        log.error('test')

    configure()
    log = getLogger('root')
    test_log_msg()

    configure(config=DEFAULT_CONFIG)
    log = getLogger('root')
    test_log_msg()

    # TODO fix LOGGING_CONFIG env var parsing
    # os.environ['LOGGING_CONFIG'] = json.dumps(DEFAULT_CONFIG)
    # configure()
    # log = getLogger('root')
    # test_log_msg()



# Generated at 2022-06-21 22:00:55.078184
# Unit test for function configure
def test_configure():
    configure()
    assert isinstance(logging.getLogger(), object)
    assert(logging.getLogger().level <= 10)



# Generated at 2022-06-21 22:01:02.729031
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    o = _PyInfo()
    assert o.PY2 is True or o.PY2 is False
    assert o.PY3 is True or o.PY3 is False
    assert type(o.PY2) is bool
    assert type(o.PY3) is bool
    assert o.PY2 is not o.PY3
    assert type(o.string_types) is tuple
    assert type(o.text_type) is type
    assert type(o.binary_type) is type
    assert len(o.string_types) is 1
    # TODO: find a way to test this in both Python2 and Python3


# Generated at 2022-06-21 22:01:14.125059
# Unit test for function configure
def test_configure():
    log = get_logger(__name__)


# Generated at 2022-06-21 22:01:24.084335
# Unit test for function configure
def test_configure():
    from logging import getLogger, DEBUG

    log = getLogger(__name__)
    print('BEFORE CONFIGURATION')
    log.debug('DEBUG')
    log.info('INFO')


# Generated at 2022-06-21 22:01:27.533328
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.DEBUG):
        get_logger().debug('test')



# Generated at 2022-06-21 22:01:29.540075
# Unit test for function get_config
def test_get_config():
    config = get_config(default="""
    version: 1
    """)
    assert config == {'version': 1}

# Generated at 2022-06-21 22:01:38.764609
# Unit test for function configure
def test_configure():
    logger1 = logging.getLogger('python-logstash-logger')
    logger2 = logging.getLogger('root')
    logger3 = logging.getLogger('requests')

    configure()

# Generated at 2022-06-21 22:01:42.068866
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')
    log = getLogger('test2')
    log.info('test2')

# Generated at 2022-06-21 22:01:47.717339
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.WARNING), "logger should be enabled when level is set to INFO"
        assert logger.isEnabledFor(logging.INFO), "logger should be enabled when level is set to INFO"
        assert not logger.isEnabledFor(logging.DEBUG), "logger should not be enabled for DEBUG when level is set to INFO"

# Generated at 2022-06-21 22:02:02.711702
# Unit test for function get_config
def test_get_config():
    config = get_config()
    assert config == DEFAULT_CONFIG
    config = get_config({"a": "b"})
    assert config == {"a": "b"}
    config = get_config(env_var=None)
    assert config == DEFAULT_CONFIG
    config = get_config(env_var="LOGGING")
    assert config == DEFAULT_CONFIG


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:02:04.446973
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.debug('getLogger() test passed')

test_getLogger()

# Generated at 2022-06-21 22:02:10.762355
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger_level')
    test_level = logging.DEBUG
    with logger_level(logger, test_level):
        assert(logger.level == test_level)
        logger.info("test")
    assert(logger.level == logging.DEBUG)
    logger.info("test2")


# Generated at 2022-06-21 22:02:17.307919
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str


# Generated at 2022-06-21 22:02:20.568342
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert isinstance(config, dict)
    assert config['version'] == 1


# Generated at 2022-06-21 22:02:28.692632
# Unit test for function get_config
def test_get_config():
    config1 = {}

# Generated at 2022-06-21 22:02:35.230265
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.string_types == (basestring,) if _PyInfo.PY2 else (str,)
    assert _PyInfo.text_type == unicode if _PyInfo.PY2 else str
    assert _PyInfo.binary_type == str if _PyInfo.PY2 else bytes

# Generated at 2022-06-21 22:02:36.748672
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')


# Generated at 2022-06-21 22:02:48.177517
# Unit test for function get_config
def test_get_config():
    import json

# Generated at 2022-06-21 22:03:01.590967
# Unit test for function configure
def test_configure():
    import os
    import sys

    # print(">>> Logging config: %s" % os.environ)

    sys.argv = [
        "",
        "--logging=%s" % json.dumps(dict(version=1, loggers=dict(dbnd=dict(handlers=["console"], level="info"))))
    ]

    _stdout = sys.stdout

# Generated at 2022-06-21 22:03:25.748406
# Unit test for function get_config
def test_get_config():
    """
    >>> cfg = get_config(None, None, DEFAULT_CONFIG)
    >>> sorted(cfg.keys())
    ['disable_existing_loggers', 'formatters', 'handlers', 'loggers', 'root', 'version']
    >>> sorted(cfg['formatters'].keys())
    ['colored', 'simple']
    """
    pass



# Generated at 2022-06-21 22:03:30.186305
# Unit test for function logger_level
def test_logger_level():
    root_logger = logging.getLogger()
    with logger_level(root_logger, logging.DEBUG) as level:
        assert root_logger.level == logging.DEBUG
    assert root_logger.level == logging.DEBUG


# nocov

# Generated at 2022-06-21 22:03:40.751353
# Unit test for function configure
def test_configure():
    import os
    import tempfile

    def _temp_file_path():
        fd, path = tempfile.mkstemp()
        os.close(fd)
        return path

    def _temp_file_path_with_json_config(config):
        path = _temp_file_path()
        with open(path, 'w') as f:
            import json

            json.dump(config, f)
        return path

    def _temp_file_path_with_yaml_config(config):
        path = _temp_file_path()
        with open(path, 'w') as f:
            import yaml

            yaml.dump(config, f)
        return path

    def _assert_configured(logger):
        assert logger.level == logging.DEBUG, logger.level
        assert logger.hand

# Generated at 2022-06-21 22:03:48.769630
# Unit test for function get_config
def test_get_config():
    default_config = {'version': 1}
    raw_config = '{"version": "1"}'
    json_config = json.loads(raw_config)
    yaml_config = yaml.safe_load(raw_config)

    assert get_config(json_config, default=default_config) == default_config
    assert get_config(yaml_config, default=default_config) == default_config
    assert get_config(raw_config, default=default_config) == default_config


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:03:59.457049
# Unit test for function getLogger
def test_getLogger():
    config = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'verbose': {
                'format': '%(levelname)s %(asctime)s %(module)s %(process)d %(thread)d %(message)s'
            },
        },
        'handlers': {
            'console': {
                'level': 'DEBUG',
                'class': 'logging.StreamHandler',
                'formatter': 'verbose'
            },
        },
        'loggers': {
            '': {
                'handlers': ['console'],
                'level': 'DEBUG'
            },
        }
    }

    logging.config.dictConfig(config)

    log = getLogger()

# Generated at 2022-06-21 22:04:04.525985
# Unit test for function getLogger
def test_getLogger():
  logger = getLogger()
  logger.info(logger)
  logger.info('test_getLogger')


# Generated at 2022-06-21 22:04:06.534990
# Unit test for function configure
def test_configure():
    configure()
    assert logging.getLogger(__name__).getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-21 22:04:09.373129
# Unit test for function configure
def test_configure():
    try:
        configure()
        log = logging.getLogger(__name__)
        log.info('test')
    except:
        assert False



# Generated at 2022-06-21 22:04:17.746206
# Unit test for function get_config
def test_get_config():
    from pytest import raises

    with raises(ValueError):
        get_config()

    assert DEFAULT_CONFIG == get_config('invalid', env_var=None, default=DEFAULT_CONFIG)
    assert DEFAULT_CONFIG == get_config(default=DEFAULT_CONFIG)
    assert DEFAULT_CONFIG == get_config(None, 'INVALID', default=DEFAULT_CONFIG)
    assert DEFAULT_CONFIG == get_config(None, 'INVALID')
    assert DEFAULT_CONFIG == get_config(None, 'INVALID', None)


# Generated at 2022-06-21 22:04:26.895132
# Unit test for function get_config
def test_get_config():
    import json
    json_test = '''{
  "version": 1,
  "handlers": {
    "console": {
      "class": "logging.StreamHandler",
      "formatter": "simple",
      "level": "DEBUG",
    }
  },
  "root": {
    "handlers": [
      "console"
    ],
    "level": "DEBUG"
  },
  "loggers": {
    "requests": {
      "level": "INFO"
    }
  }
}'''
    json_test = json.loads(json_test)

    import yaml

# Generated at 2022-06-21 22:05:23.043374
# Unit test for function configure
def test_configure():
    # log = logging.getLogger(__name__)
    # log.debug('test')
    log = get_logger()
    log.debug('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:05:26.471312
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert isinstance('test', _PyInfo.string_types)
    assert isinstance(u'test', _PyInfo.string_types)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:05:34.040405
# Unit test for function getLogger
def test_getLogger():
    LOG = getLogger()
    LOG.level = logging.DEBUG
    LOG.debug("This is a debug message")
    LOG.warning("This is a warning message")

    error_string = "This is an error message"
    try:
        raise RuntimeError(error_string)
    except RuntimeError as e:
        LOG.exception("This is an exception message")
        assert(e.args[0] == error_string)


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:05:39.605714
# Unit test for function get_config
def test_get_config():
    logger = get_logger('test_get_config')
    logger.info('test_get_config')
    msg = 'Invalid logging config: bad_config'
    try:
        get_config('bad_config')
    except ValueError as exc:
        assert msg == str(exc)


if __name__ == '__main__':
    print(get_config('{"version":1}'))
    test_get_config()

# Generated at 2022-06-21 22:05:46.971480
# Unit test for function getLogger
def test_getLogger():
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    config = os.path.join(tmpdir, 'logging.yml')
    with open(config, 'w') as f:
        f.write('''\
version: 1
formatters:
  simple:
    format: '%(levelname)s %(message)s'
handlers:
  file:
    class : logging.FileHandler
    filename: output.log
    formatter: simple
root:
  level: DEBUG
  handlers: [file]
''')
    os.environ['LOGGING'] = config
    log = getLogger()
    log.debug('test')
    with open('output.log', 'r') as f:
        l = f.read().strip()

# Generated at 2022-06-21 22:05:57.256488
# Unit test for function logger_level
def test_logger_level():
    # Setup
    logger_name = 'test_logger_level'
    logger = get_logger(logger_name)
    handler = logging.StreamHandler(stream = sys.stderr)
    logger.addHandler(handler)
    # Check that the logger is disabled
    assert logger.disabled == True, 'Logger should be disabled'
    # Change the logger level
    with logger_level(logger, logging.DEBUG):
        # Check that the logger is enabled
        assert logger.disabled == False, 'Logger should be enabled'
        # Check that the log level has changed
        assert getattr(logger, 'level', None) == 10, 'Log level should be logging.DEBUG'
    # Check that the logger is disabled
    assert logger.disabled == True, 'Logger should be disabled'
    # Check that the log level has changed

# Generated at 2022-06-21 22:06:02.076677
# Unit test for function getLogger
def test_getLogger():
    logging.basicConfig()
    logger = getLogger()
    logger.debug("getLogger() worked!")
    logger.info("getLogger() worked!")
    logger.warning("getLogger() worked!")
    logger.error("getLogger() worked!")
    logger.critical("getLogger() worked!")


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 22:06:08.690507
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    from unittest import TestCase, main

    class Test(_PyInfo, TestCase):
        def test_string_types(self):
            self.assertEqual(type('string'), self.string_types[0])

        def test_text_type(self):
            self.assertEqual(type(u'string'), self.text_type)

        def test_binary_type(self):
            self.assertEqual(type(b'string'), self.binary_type)

    main()

# Generated at 2022-06-21 22:06:13.431582
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('info')
    logger.debug('debug')
    logger.error('error')
    logger.warn('warn')
    logger.critical('critical')



# Generated at 2022-06-21 22:06:14.746398
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

