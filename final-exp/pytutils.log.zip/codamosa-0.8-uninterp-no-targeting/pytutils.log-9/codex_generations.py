

# Generated at 2022-06-21 21:57:30.689454
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.INFO):
        # Make sure that the log level has changed:
        assert log.getEffectiveLevel() == logging.INFO
        log.debug('This should not be printed.')

    # Make sure it has changed back:
    assert log.getEffectiveLevel() == logging.DEBUG
    log.debug('test_stdlib_logging')


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:57:33.274919
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False
test__PyInfo()

# Generated at 2022-06-21 21:57:39.926947
# Unit test for function getLogger
def test_getLogger():
    with quark.TestApp() as testApp:
        testApp.setupPackagePath(os.path.abspath(__file__))
        testApp.setupPackagePathFromPath(os.path.abspath(__file__))
        testApp.run()


# Generated at 2022-06-21 21:57:43.555950
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.binary_type
    assert _PyInfo.text_type
    assert _PyInfo.string_types



# Generated at 2022-06-21 21:57:54.183852
# Unit test for function configure
def test_configure():
    import colorlog
    import logging

    configure()
    assert isinstance(logging.getLogger().handlers[0], logging.StreamHandler)
    assert isinstance(logging.getLogger().handlers[0].formatter, colorlog.ColoredFormatter)


# Generated at 2022-06-21 21:57:55.060597
# Unit test for function configure
def test_configure():
    """
    >>> configure()

    """

# Generated at 2022-06-21 21:57:56.443246
# Unit test for function configure
def test_configure():
    configure()
    logging.debug('test log message')



# Generated at 2022-06-21 21:58:02.065548
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, {'foo': 1}) == {'foo': 1}
    assert get_config('{"foo": 1}') == {'foo': 1}
    try:
        get_config('not yaml or json')
    except ValueError:
        pass
    else:
        assert False, "should not have gotten here"



# Generated at 2022-06-21 21:58:03.497812
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pytest.skip('nothing to be tested in _PyInfo anymore')



# Generated at 2022-06-21 21:58:06.666404
# Unit test for function configure
def test_configure():
    import logging

    try:
        configure()
        log = logging.getLogger(__name__)
        log.info('test')
    finally:
        logging.shutdown()
        logging.getLogger().handlers = []



# Generated at 2022-06-21 21:58:12.420293
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR


# Generated at 2022-06-21 21:58:14.364434
# Unit test for function configure
def test_configure():
    pass


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:58:15.847130
# Unit test for function getLogger
def test_getLogger():
    import logging
    logger = getLogger()
    logger.info('test')


# Generated at 2022-06-21 21:58:25.920933
# Unit test for function logger_level
def test_logger_level():
    from mock import patch

    # Create test logger
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    # Create handler to capture log message
    log_stream = io.BytesIO()
    handler = logging.StreamHandler(log_stream)
    log.addHandler(handler)

    # Perform tests
    with logger_level(log, logging.WARNING):
        log.info('Log message')
        log.warning('Log message')
        assert 'Log message' not in log_stream.getvalue()

    with logger_level(log, logging.INFO):
        log.debug('Log message')
        log.info('Log message')
        assert 'Log message' in log_stream.getvalue()

# Generated at 2022-06-21 21:58:27.162708
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3

# unit test for function namespace_from_calling_context

# Generated at 2022-06-21 21:58:29.627471
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:58:35.710640
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import sys
    is_py3 = sys.version_info[0] == 3
    if is_py3:
        assert _PyInfo.PY3 is True, "PY3 is expected to be True"
        assert _PyInfo.PY2 is False, "PY2 is expected to be False"
    else:
        assert _PyInfo.PY3 is False, "PY3 is expected to be False"
        assert _PyInfo.PY2 is True, "PY2 is expected to be True"


if __name__ == "__main__":
    test__PyInfo()

# Generated at 2022-06-21 21:58:46.526191
# Unit test for function configure
def test_configure():
    # Test 1: Missing arg
    try:
        configure()
        assert True
    except Exception as e:
        assert False

    # Test 2: Invalid config
    try:
        configure(config="abcdefgh")
        assert False
    except ValueError as e:
        assert True

    # Test 3: Streaming config
    try:
        config = (
            '{ '
            '    "version": 1,'
            '    "formatters": {'
            '        "simple": {'
            '            "format": "test",'
            '            "datefmt": "test"'
            '        }'
            '    }'
            '}'
        )
        configure(config=config)
        assert True
    except Exception as e:
        assert False

    # Test 4: File config

# Generated at 2022-06-21 21:58:50.611534
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()

    with logger_level(logger, logging.NOTSET):
        assert logger.level == logging.NOTSET
        with logger_level(logger, logging.INFO):
            assert logger.level == logging.INFO
        assert logger.level == logging.NOTSET

# Generated at 2022-06-21 21:58:54.616103
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        # All logging statements below are not output to console.
        logger.debug("debug info")
        logger.info("info")
    logger.debug("debug info")
    logger.info("info")

# Generated at 2022-06-21 21:59:02.313008
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    assert isinstance(log, logging.RootLogger)

    log = get_logger('test_getLogger')
    assert isinstance(log, logging.Logger)
    assert log.name == 'test_getLogger'

# Generated at 2022-06-21 21:59:07.563693
# Unit test for function getLogger
def test_getLogger():
    """
    >>> test_getLogger()
    >>> log = get_logger(__name__)
    >>> log.debug('THIS IS A TEST')
    >>> with logger_level(log, logging.INFO):
    ...     log.debug('TEST LOGGER LEVEL')
    ...     log.info('TEST LOGGER LEVEL')
    >>> log.debug('THIS IS A TEST')
    """
    print('Testing get_logger function')
    configure()



# Generated at 2022-06-21 21:59:19.153281
# Unit test for function get_config
def test_get_config():
    assert get_config('{"handlers": []}') == {"handlers": []}
    assert get_config(b'{"handlers": []}') == {"handlers": []}

    assert get_config('{"handlers": [], "formatters": []}') == {"handlers": [], "formatters": []}
    assert get_config(b'{"handlers": [], "formatters": []}') == {"handlers": [], "formatters": []}

    assert get_config('{"handlers": []}', default='{"handlers": [], "formatters": []}') == {"handlers": []}
    assert get_config(b'{"handlers": []}', default='{"handlers": [], "formatters": []}') == {"handlers": []}

# Generated at 2022-06-21 21:59:29.214279
# Unit test for function logger_level
def test_logger_level():
    # import logging.config
    # logging.config.dictConfig(DEFAULT_CONFIG)

    configure()

    print(logging.getLogger(__name__).level)

    with logger_level(logging.getLogger(__name__), logging.INFO):
        print(logging.getLogger(__name__).level)
        logging.getLogger(__name__).debug('level is set to INFO')
        logging.getLogger(__name__).info('this is printed')

    print(logging.getLogger(__name__).level)


if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-21 21:59:36.112098
# Unit test for function get_config

# Generated at 2022-06-21 21:59:47.479124
# Unit test for function logger_level
def test_logger_level():
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    log = get_logger('test')
    log.level = logging.DEBUG
    record = logging.LogRecord(
        'test',
        logging.INFO,
        '/tmp/x',
        2,
        'Test Logger Level',
        {},
        None
    )

    with logger_level(log, logging.ERROR):
        log.handle(record)
        log.addHandler.assert_not_called()

    log.handle(record)
    log.addHandler.assert_called_once()



# Generated at 2022-06-21 21:59:51.278125
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    if _PyInfo.PY2:
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    else:
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes

# Generated at 2022-06-21 22:00:03.329036
# Unit test for function get_config
def test_get_config():
    # This test only works with the yaml module installed.
    try:
        __import__('yaml')
    except ImportError:
        return

    # Test that a dict is passed through unchanged
    test_config = {'foo': 'bar'}
    assert get_config(test_config) == test_config

    # Test that a json string is parsed
    test_config = '{"foo": "bar"}'
    assert get_config(test_config) == json.loads(test_config)

    # Test that a yaml string is parsed
    test_config = 'foo: bar'
    assert get_config(test_config) == yaml.load(test_config)

    # Test that bad config fails
    test_config = '{foo: bar'

# Generated at 2022-06-21 22:00:11.728348
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)

    # basic test

# Generated at 2022-06-21 22:00:18.106855
# Unit test for function configure
def test_configure():
    """
    >>> import logging
    >>> log = logging.getLogger(__name__)
    >>> log.setLevel(logging.WARNING)
    >>> log.info('test')
    >>> configure()
    >>> log.info('test')
    [12:00:00] [test_logger.py/140521975642624] test  @test_configure:42 #INFO
    [12:00:00] [test_logger.py/140521975642624] test  @test_configure:43 #INFO

    """



# Generated at 2022-06-21 22:00:30.708554
# Unit test for function get_config
def test_get_config():
    try:
        get_config()
    except ValueError:
        pass
    else:
        assert False, "get_config should fail without argument"


# Generated at 2022-06-21 22:00:32.881088
# Unit test for function getLogger
def test_getLogger():
    log = get_logger('test')
    assert log
    log.info('test')



# Generated at 2022-06-21 22:00:43.328423
# Unit test for function get_config

# Generated at 2022-06-21 22:00:46.643142
# Unit test for function configure
def test_configure():
    logging.config.dictConfig(DEFAULT_CONFIG)

    logger = logging.getLogger(__name__)
    logger.info('test')


# Generated at 2022-06-21 22:00:51.160739
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3

    assert isinstance(u'unicode', pyinfo.string_types)
    assert isinstance('bytes', pyinfo.string_types)

    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str


# Generated at 2022-06-21 22:00:52.570677
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log.info('test')



# Generated at 2022-06-21 22:00:54.070142
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    obj = _PyInfo()
    assert obj.PY2 is True
    assert obj.PY3 is False


# Generated at 2022-06-21 22:00:57.686085
# Unit test for function getLogger
def test_getLogger():
    """Testing getLogger
    """
    log = getLogger()
    log.info('just for test')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:01:04.996293
# Unit test for function get_config
def test_get_config():
    import os
    import json

    # setup

# Generated at 2022-06-21 22:01:15.794600
# Unit test for function logger_level
def test_logger_level():
    # Given
    logger = getLogger()
    with logger_level(logger, logging.ERROR):
        # When
        try:
            logger.critical('critical message')
            logger.error('error message')
            logger.warning('warning message')
            logger.info('info message')
            logger.debug('debug message')
        except:
            assert False
        else:
            assert True
        # Then


if __name__ == '__main__':
    import argparse

    def main(args=None):
        args = args or sys.argv[1:]

        parser = argparse.ArgumentParser()

        parsers = parser.add_subparsers(dest='cmd')

        parser_configure = parsers.add_parser('configure', help="Configure logging")

        parser_configure.add_argument

# Generated at 2022-06-21 22:01:31.892816
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert(_PyInfo.PY2)
    import sys
    assert(_PyInfo.PY3 == (sys.version_info[0] == 3))
    assert(_PyInfo.binary_type)
    assert(_PyInfo.text_type)
    assert(_PyInfo.string_types)


if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-21 22:01:33.292864
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    p.name
    assert _PyInfo.PY2 or _PyInfo.PY3

# Generated at 2022-06-21 22:01:34.727991
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    _namespace_from_calling_context()


# Generated at 2022-06-21 22:01:41.018542
# Unit test for function get_config
def test_get_config():
    config = get_config(given='foo', env_var='LOGGING', default='bar')
    assert config == 'foo', 'Expected config to be "foo", but got "%s"' % config

    config = get_config(given='foo', default='bar')
    assert config == 'foo', 'Expected config to be "foo", but got "%s"' % config

    config = get_config(env_var='LOGGING', default='bar')
    assert config == 'bar', 'Expected config to be "bar", but got "%s"' % config

    config = get_config(default='bar')
    assert config == 'bar', 'Expected config to be "bar", but got "%s"' % config

    expected = {'foo': 'bar'}
    config = get_config(expected)

# Generated at 2022-06-21 22:01:47.968642
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    if _PyInfo.PY2:
        assert _PyInfo.string_types == basestring
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    if _PyInfo.PY3:
        assert _PyInfo.string_types == str
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes

# Generated at 2022-06-21 22:01:52.111343
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.ERROR):
        assert logger.isEnabledFor(logging.ERROR)
    assert logger.isEnabledFor(logging.DEBUG)



# Generated at 2022-06-21 22:02:04.060308
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    log.setLevel(logging.INFO)

    # Since logger should be set to INFO, if we try to log a debug message it
    # shouldn't pass.
    try:
        log.debug('This is a debug message')
        assert False, 'Should not have passed'
    except ValueError as e:
        assert True

    # If we set the logger to DEBUG temporarily, it should log the message.
    with logger_level(log, logging.DEBUG):
        log.debug('This is now a debug message')
        assert True

    # After we exit the context, it should revert to it's original state.
    try:
        log.debug('This is a debug message')
        assert False, 'Should not have passed'
    except ValueError as e:
        assert True



# Generated at 2022-06-21 22:02:14.043396
# Unit test for function logger_level
def test_logger_level():
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            # Make sure logging is configured
            _ensure_configured()

            # Get logger to test.
            self.logger = get_logger('logger_level')

        def test_logger_level(self):
            with logger_level(self.logger, logging.DEBUG):
                self.logger.debug('debug')
                self.logger.info('info')
                self.logger.warn('warn')
                self.logger.error('error')
                self.logger.critical('critical')

            # After the context, the logging level should be the same as it is after initialization.

# Generated at 2022-06-21 22:02:21.085500
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    try:
        with logger_level(logger, logging.DEBUG):
            log.info('Hello from within context.')
    except Exception:
        raise
    finally:
        assert logger.level == logging.INFO



# Generated at 2022-06-21 22:02:28.879173
# Unit test for function configure
def test_configure():
    class MyHandler(object):
        def __init__(self, level):
            self.level = level


# Generated at 2022-06-21 22:02:54.621950
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is not None and _PyInfo.PY2 is not None
    assert _PyInfo.string_types is not None
    assert _PyInfo.text_type is not None
    assert _PyInfo.binary_type is not None


# Generated at 2022-06-21 22:03:00.079476
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__ + '.test_logger_level')
    logger.setLevel(logging.INFO)
    # Test logger level is initially INFO
    assert logger.level == logging.INFO
    # Test logger level is temporarily changed to DEBUG and then reset to INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug('Temporarily set logger level to DEBUG')
    assert logger.level == logging.INFO
    # Test logger level is permanently changed to DEBUG and then reset to INFO
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug('Temporarily set logger level to DEBUG')
    logger.setLevel(logging.DEBUG)

# Generated at 2022-06-21 22:03:02.554853
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    info = _PyInfo()
    assert info.PY2 or info.PY3
    assert info.string_types
    assert info.text_type
    assert info.binary_type

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:03:06.467180
# Unit test for function configure
def test_configure():
    log = logging.getLogger('test_configure')
    # TODO: Needs to be a little better than this, maybe.
    try:
        configure()
        log.info('test')
    except Exception as e:
        assert False, "configure() failed with message: {}".format(e)


# Generated at 2022-06-21 22:03:12.394253
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2
    assert not _PyInfo().PY3
    assert _PyInfo().string_types == (str, )
    assert _PyInfo().text_type == str
    assert _PyInfo().binary_type == bytes


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:03:20.462331
# Unit test for function configure
def test_configure():
    import colorlog
    log = get_logger()
    assert isinstance(log, logging.Logger)
    assert isinstance(log.handlers[0], colorlog.ColorizingStreamHandler)
    assert isinstance(log.handlers[0].formatter, colorlog.ColoredFormatter)
    assert log.handlers[0].formatter._style._fmt == \
           '%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] ' \
           '%(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s' \
           '%(reset)s'

# Generated at 2022-06-21 22:03:26.226998
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    assert get_config(config={}) == {}
    assert get_config(config='{}') == {}
    assert get_config(config=' "{}" ') == {}

    d = {'key': 'value'}
    assert get_config(config=json.dumps(d)) == d
    assert get_config(config='  ' + json.dumps(d)) == d

    assert get_config(config=yaml.dump(d)) == d
    assert get_config(config='  ' + yaml.dump(d)) == d



# Generated at 2022-06-21 22:03:37.696067
# Unit test for function logger_level
def test_logger_level():
    import logging.handlers
    from contextlib import ExitStack
    from loggy import logger_level
    from unittest import TestCase

    # This is set to true if the logger_level's context manager worked.
    # (setting the logger level to the expected value on exit)
    result = False

    # This will capture all log messages and may be checked at any point,
    # by conveniently not using logging.DEBUG as the default level
    class CapturingHandler(logging.handlers.BufferingHandler):
        def __init__(self, *args, **kwargs):
            super(CapturingHandler, self).__init__(*args, **kwargs)
            self.buffer = None

        def emit(self, record):
            self.buffer = record.getMessage()

    logger = logging.getLogger()

# Generated at 2022-06-21 22:03:43.445917
# Unit test for function logger_level
def test_logger_level():
    import io

    logger = getLogger()
    stdo = io.StringIO()
    # The following lines cannot be written at the top of the module, because the logger_level function is not defined yet
    logger.addHandler(logging.StreamHandler(stdo))

    # Logger is not working
    with logger_level(logger, logging.ERROR):
        logger.debug('message')

    # Logger is working
    with logger_level(logger, logging.DEBUG):
        logger.debug('message')



# Generated at 2022-06-21 22:03:50.933938
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.root, logging.NOTSET):
        # This line should not print anything
        logging.root.warn("This is a warn, but will be replaced by info since we disabled warning")
        logging.root.info('This is an info')
    # This line should print normally
    logging.root.warn("This is a warn")
    logging.root.info("This is an info")
test_logger_level.__test__ = False



# Generated at 2022-06-21 22:04:39.189075
# Unit test for constructor of class _PyInfo

# Generated at 2022-06-21 22:04:44.276901
# Unit test for function configure
def test_configure():
    # Monkey patch
    import logging
    import logging.config
    import pytest

    class DummyStreamHandler(object):
        def emit(*args):
            pass

    logging.StreamHandler = DummyStreamHandler
    logging.config.dictConfig = lambda x: x

    try:
        with logger_level(logging.getLogger(), logging.CRITICAL):
            configure()
    except Exception as exc:
        pytest.fail('configure raised unexpected %s: %s' % (type(exc), exc))



# Generated at 2022-06-21 22:04:46.138784
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance(type(_PyInfo()), type)


# Generated at 2022-06-21 22:04:48.791584
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')

    log = get_logger('test2')
    log.info('test2')

# Generated at 2022-06-21 22:04:58.932194
# Unit test for function get_config
def test_get_config():
    print("Test get_config")
    config = get_config()
    assert config is not None
    print(config)
    config = get_config(config=DEFAULT_CONFIG)
    assert config is not None
    print(config)

    import yaml
    yaml_config = yaml.dump(DEFAULT_CONFIG)
    config = get_config(config=yaml_config)
    assert config is not None
    print(config)
    import json
    json_config = json.dumps(DEFAULT_CONFIG)
    config = get_config(config=json_config)
    assert config is not None
    print("config is : " + str(config))

    os.environ["LOGGING"] = json_config
    config = get_config(env_var="LOGGING")
    assert config

# Generated at 2022-06-21 22:05:00.543179
# Unit test for function getLogger
def test_getLogger():
    log = Logging.getLogger()
    assert isinstance(log, logging.Logger)

# Generated at 2022-06-21 22:05:04.789918
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.string_types == (str,) if _PyInfo.PY3 else (basestring,)
    assert _PyInfo.text_type == str if _PyInfo.PY3 else unicode
    assert _PyInfo.binary_type == bytes if _PyInfo.PY3 else str



# Generated at 2022-06-21 22:05:12.215983
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, {'foo': 'bar'}) == {'foo': 'bar'}
    assert get_config(None, None, '[1]') == [1]
    assert get_config(None, None, '{"foo": "bar"}') == {'foo': 'bar'}
    assert get_config('[1]', None, None) == [1]
    assert get_config('{"foo": "bar"}', None, None) == {'foo': 'bar'}

# Generated at 2022-06-21 22:05:16.520273
# Unit test for function logger_level
def test_logger_level():
    """Check that logger_level modifies the logger level in the desired way.  """
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG


# Generated at 2022-06-21 22:05:23.970101
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import unittest
    class _Test(_PyInfo):
        def test(self):
            self.assertEqual(type(self.binary_type(self.binary_type())), self.binary_type)
            self.assertEqual(type(self.text_type(self.text_type())), self.text_type)
            self.assertEqual(type(self.string_types[0]()), self.string_types[0])

    unittest.main()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:06:18.108974
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    expected_string_types = (basestring,) if pyinfo.PY2 else (str,)
    assert pyinfo.string_types == expected_string_types
    expected_text_type = unicode if pyinfo.PY2 else str
    assert pyinfo.text_type == expected_text_type
    expected_binary_type = str if pyinfo.PY2 else bytes
    assert pyinfo.binary_type == expected_binary_type


# Generated at 2022-06-21 22:06:24.190315
# Unit test for function getLogger
def test_getLogger():
    expected_message = 'INFO:root:test'
    log = getLogger()
    with logger_level(log, logging.DEBUG):
        log.info('test')
        assert len(log.handlers) == 1
        assert log.handlers[0].stream.stream.getvalue() == expected_message



# Generated at 2022-06-21 22:06:26.345281
# Unit test for function get_config
def test_get_config():
    # Given
    given = {}

    # When
    cfg = get_config(given)

    # Then
    assert cfg == given



# Generated at 2022-06-21 22:06:36.042127
# Unit test for function get_config
def test_get_config():
    # Check the case: if given valid json string, the config will be loaded
    config = '{"version": 1}'
    valid_config = get_config(config)
    assert valid_config == {"version": 1}

    # Check the case: if given valid  yaml string, the config will be loaded
    config = 'version: 1\n'
    valid_config = get_config(config)
    assert valid_config == {"version": 1}

    # Check the case: if given invalid  yaml string, the config will not be loaded and it will raise an exception
    config = 'version 1\n'
    with pytest.raises(ValueError):
        get_config(config)

    # Check the case: if given invalid json string, the config will not be loaded and it will raise an exception

# Generated at 2022-06-21 22:06:47.163016
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, None) is None
    assert get_config(None, 'test', None) is None
    assert get_config(None, None, {}) == {}
    assert get_config(None, 'test', {}) == {}
    assert get_config('test', 'test', {}) == 'test'

    assert get_config('{"foo": "bar"}', None, None) == {"foo": "bar"}
    assert get_config('{}', None, None) == {}
    assert get_config('{"foo": "bar"}', 'test', None) == {"foo": "bar"}
    assert get_config('{}', 'test', None) == {}
    assert get_config('{"foo": "bar"}', None, {}) == {"foo": "bar"}

# Generated at 2022-06-21 22:06:49.321994
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert (_PyInfo.PY2 or _PyInfo.PY3)
    assert not (_PyInfo.PY2 and _PyInfo.PY3)



# Generated at 2022-06-21 22:06:58.153137
# Unit test for function get_config
def test_get_config():
    from unittest import TestCase, main

    class TestConfig(TestCase):

        def test_load_config_default(self):
            config = get_config(default=DEFAULT_CONFIG)

            self.assertEqual(config, DEFAULT_CONFIG)

            for handler in config['handlers'].values():
                self.assertEqual(handler['level'], logging.DEBUG)

        def test_load_config_empty_default(self):
            with self.assertRaises(ValueError):
                get_config(default={})

    main()



# Generated at 2022-06-21 22:07:03.476050
# Unit test for function configure
def test_configure():
    logging.shutdown()
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')

    print(logger.level)
    logging.shutdown()

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:07:08.504733
# Unit test for function get_config
def test_get_config():
    config = get_config(default=None)
    assert config is None

    config = get_config(config='{"version": 1}', default={})
    assert config == {"version": 1}

    config = get_config(env_var='LOGGING', default={})
    assert config == {}


if __name__ == "__main__":
    print(get_config())

# Generated at 2022-06-21 22:07:14.578094
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    default_config = dict(
        version = 1,
        disable_existing_loggers = True,
        formatters = {
            'standard': {
                'format': "default: %(asctime)s [%(levelname)s] %(name)s: %(message)s"
            },
        },
        handlers = {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'standard',
                'level': logging.DEBUG,
            },
        },
        loggers = {
            '': {
                'handlers': ['console'],
                'level': logging.DEBUG,
            },
        },
    )

    cfg = get_config(config=None, env_var=None, default=default_config)
   