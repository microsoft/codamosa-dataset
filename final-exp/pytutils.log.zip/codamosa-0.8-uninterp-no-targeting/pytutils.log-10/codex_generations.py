

# Generated at 2022-06-21 21:57:24.448445
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 and not pyinfo.PY3


# Generated at 2022-06-21 21:57:33.825801
# Unit test for function logger_level
def test_logger_level():
    import logging
    import os
    from contextlib import contextmanager
    from io import StringIO
    from zsl import logger

    @contextmanager
    def capture_stdout():
        captured_stdout = StringIO()
        original_stdout = sys.stdout
        sys.stdout = captured_stdout
        try:
            yield captured_stdout
        finally:
            sys.stdout = original_stdout


# Generated at 2022-06-21 21:57:42.657783
# Unit test for function configure
def test_configure():
    import logging
    import sys

    # test for value error
    try:
        configure(config="None")
    except ValueError:
        pass

    # test for basic config
    configure(config={"version": 1, "disable_existing_loggers": False, "root": {"handlers": ["console"], "level": logging.NOTSET}, "loggers": {"requests": {"level": logging.WARNING}}, "handlers": {"console": {"level": logging.DEBUG, "class": "logging.StreamHandler", "formatter": "colored"}}})
    log = logging.getLogger(__name__)
    try:
        log.info("test")
        print("test succeed!")
    except:
        print("test fail!")
    log.info("test")
    log.warning("test")

    # test for dictConfig

# Generated at 2022-06-21 21:57:50.189188
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    configure()
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    with logger_level(logger, logging.CRITICAL):
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')


if __name__ == '__main__':
    configure()
    log = getLogger()
    log.info('test')
    test_logger_level()

# Generated at 2022-06-21 21:57:51.607600
# Unit test for function getLogger
def test_getLogger():
    _ensure_configured()
    getLogger('test')


# Generated at 2022-06-21 21:57:58.086604
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.debug("Test logger_level")
        assert logger.isEnabledFor(logging.DEBUG) == True
        assert logger.isEnabledFor(logging.INFO) == False
        assert logger.isEnabledFor(logging.ERROR) == False
    logger.debug("Test logger_level")
    assert logger.isEnabledFor(logging.DEBUG) == False
    assert logger.isEnabledFor(logging.INFO) == True
    assert logger.isEnabledFor(logging.ERROR) == False

# Generated at 2022-06-21 21:58:01.409403
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.debug('test_getLogger')

    logger = getLogger('test_getLogger')
    logger.debug('test_getLogger')



# Generated at 2022-06-21 21:58:04.827132
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR

    assert logger.level == logging.DEBUG


# Generated at 2022-06-21 21:58:12.369095
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 is not _PyInfo.PY2
    assert isinstance(__name__, _PyInfo.string_types)
    assert type(b'asdf') == _PyInfo.binary_type
    assert type(u'asdf') == _PyInfo.text_type
    assert 'asdf' != _PyInfo.binary_type and 'asdf' != _PyInfo.text_type



# Generated at 2022-06-21 21:58:16.191370
# Unit test for function logger_level
def test_logger_level():
    import unittest

    log = getLogger()
    log.setLevel(logging.ERROR)

    with logger_level(log, logging.DEBUG):
        log.info('DEBUG')
    log.info('ERROR')



# Generated at 2022-06-21 21:58:22.618441
# Unit test for function logger_level
def test_logger_level():
    configure()
    log = get_logger(__name__)

    with logger_level(log, logging.WARNING):
        log.debug('This should NOT be printed.')

    log.debug('This should be printed.')

# Generated at 2022-06-21 21:58:25.104081
# Unit test for function getLogger
def test_getLogger():
    """ this is a function level test function here can be improve to a class level """
    log = getLogger()
    log.info('test this')

# Generated at 2022-06-21 21:58:34.268202
# Unit test for function get_config

# Generated at 2022-06-21 21:58:36.461499
# Unit test for function configure
def test_configure():
    l = get_logger()
    l.info('This is a message to test logging.')



# Generated at 2022-06-21 21:58:37.848134
# Unit test for function configure
def test_configure():
    configure()
    logging.getLogger(__name__).info('test')

# Generated at 2022-06-21 21:58:41.277113
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO



# Generated at 2022-06-21 21:58:50.197320
# Unit test for function configure
def test_configure():
    import logging

    configure(
        default=dict(
            version=1,
            formatters={
                'verbose': {
                    'format': '%(name)s %(levelname)s %(asctime)s %(module)s %(process)d %(thread)d %(message)s'
                },
            },
            handlers={
                'console': {
                    'class': 'logging.StreamHandler',
                    'formatter': 'verbose',
                    'level': logging.DEBUG,
                },
            },
            root=dict(handlers=['console'], level=logging.DEBUG),
            loggers={
                'requests': dict(level=logging.INFO),
            },
        )
    )

    logger = logging.getLogger(__name__)


# Generated at 2022-06-21 21:58:51.971902
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()



# Generated at 2022-06-21 21:58:53.784452
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.CRITICAL):
        log.debug("debug")
        log.info("info")
        log.warn("warn")
        log.error("error")
        log.critical("critical")

# Generated at 2022-06-21 21:59:03.399921
# Unit test for function logger_level
def test_logger_level():
    import logging
    import unittest

    class TestCase(unittest.TestCase):
        def test_disabling_logging(self):
            logger = logging.getLogger(__name__)
            # Set logger level to CRITICAL to ensure that nothing is logged
            logger.setLevel(logging.CRITICAL)
            with logger_level(logger, logging.DEBUG):
                self.assertTrue(logger.isEnabledFor(logging.DEBUG))
                logger.debug(__name__)
            # Set logger level back to debug to ensure that we can log
            logger.setLevel(logging.DEBUG)
            logger.debug(__name__)

    unittest.main()

# Generated at 2022-06-21 21:59:15.659671
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    log.info('info')

    log.setLevel(logging.INFO)
    log.debug('debug')

    with logger_level(log, logging.DEBUG):
        log.debug('debug')

    log.debug('debug')



# Generated at 2022-06-21 21:59:24.091929
# Unit test for function configure

# Generated at 2022-06-21 21:59:26.478003
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test')
    print(logger)

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 21:59:35.208836
# Unit test for function get_config
def test_get_config():
    import pytest
    assert get_config() == DEFAULT_CONFIG
    assert get_config(config='{"version":1}') == {"version":1}
    with pytest.raises(ValueError):
        get_config(config='{"version":1')
    import json
    assert get_config(config=json.dumps({"version":1})) == {"version":1}
    import yaml
    assert get_config(config=yaml.dump({"version":1})) == {"version":1}
    with pytest.raises(ValueError):
        get_config(config='---\nversion: "1"\n')

# Generated at 2022-06-21 21:59:42.656043
# Unit test for function logger_level
def test_logger_level():
    # This is a stupid unit test, but it ensures that logging to DEBUG
    # will be suppressed when the logger is set to INFO
    # https://docs.python.org/3/library/logging.html#logging-levels
    logger_name = 'test_logger_level'
    log = get_logger(logger_name)
    logger_info = logging.getLogger(logger_name)
    log.debug('test_debug')
    with logger_level(logger_info, logging.INFO):
        log.debug('test_debug2')
        log.info('test_info')
    log.debug('test_debug3')



# Generated at 2022-06-21 21:59:52.869595
# Unit test for function get_config

# Generated at 2022-06-21 22:00:00.684508
# Unit test for function logger_level
def test_logger_level():
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = getLogger()
    logger.info('info before')
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug within context')
    logger.info('info after')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 22:00:05.150166
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-21 22:00:07.600850
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert type(_PyInfo.binary_type) != type(_PyInfo.text_type)

# Generated at 2022-06-21 22:00:13.112844
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test')

    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO

    assert log.level == logging.DEBUG


if __name__ == "__main__":  # pragma: no cover
    test_logger_level()

# Generated at 2022-06-21 22:00:21.730186
# Unit test for function configure
def test_configure():
    log = get_logger(__name__)
    assert log.name == __name__

# Generated at 2022-06-21 22:00:22.347480
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pass

# Generated at 2022-06-21 22:00:24.557219
# Unit test for constructor of class _PyInfo
def test__PyInfo():
  assert _PyInfo.PY2 == True
  assert _PyInfo.PY3 == False

# Generated at 2022-06-21 22:00:28.344718
# Unit test for function configure
def test_configure():
    try:
        configure()
    except ValueError as e:
        assert False, 'Environment variable LOGGING contains invalid value: %s' % e


# Generated at 2022-06-21 22:00:40.460586
# Unit test for function get_config
def test_get_config():
    # test if a config file is not provided
    with pytest.raises(ValueError):
        get_config()

    # test yaml config file
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_file.yaml')
    assert file_path.endswith('test_file.yaml')
    conf = get_config(file_path)
    assert conf
    assert conf.get('version') == 1

    # test json config file
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_file.json')
    assert file_path.endswith('test_file.json')
    conf = get_config(file_path)
    assert conf


# Generated at 2022-06-21 22:00:43.417908
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str


# Generated at 2022-06-21 22:00:51.034617
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    initial_level = log.level
    # Check with try finally to make sure the level is reset each time
    try:
        with logger_level(log,logging.DEBUG):
            assert(log.level == logging.DEBUG)
            log.debug('test')
        # With statement is over now, check that the logger level is back to what it was
        assert(log.level == initial_level)
    finally:
        # Make sure the level is back to what it was
        assert(log.level == initial_level)


# Generated at 2022-06-21 22:00:57.853133
# Unit test for function logger_level
def test_logger_level():
    import warnings
    import logging

    logger = logging.getLogger(__name__)

    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        with logger_level(logger, logging.DEBUG):
            logger.error("test")
        # Verify some things
        assert len(w) == 0

    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        logger.error("test")
        # Verify some things
        assert len(w) == 1
        assert issubclass(w[-1].category, UserWarning)

# Generated at 2022-06-21 22:01:02.311268
# Unit test for function get_config
def test_get_config():
    default_config = {'root': {'handlers': ['console']}}
    assert get_config(default_config) == default_config
    assert get_config("{'root': {'handlers': ['console']}}") == default_config
    assert get_config("root:\n  handlers: [console]") == default_config

# Generated at 2022-06-21 22:01:09.751728
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()
    import logging
    log = getLogger()
    log.info('start')
    with logger_level(log, logging.INFO):
        log.debug('this should be ignored')
        log.info('this should be output')
        with logger_level(log, logging.DEBUG):
            log.debug('this should be output')
        log.debug('this should be ignored')
    log.info('end')

# Generated at 2022-06-21 22:01:23.324047
# Unit test for function getLogger
def test_getLogger():
    import logging
    import logging.config
    import inspect

    logging.config.dictConfig(DEFAULT_CONFIG)
    logger = get_logger()
    logger.info('test')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:01:35.022426
# Unit test for function getLogger
def test_getLogger():
    from contextlib import contextmanager
    from io import StringIO
    from logging import DEBUG, INFO
    log = getLogger("test")
    log.info("test")
    log.debug("test")


# Generated at 2022-06-21 22:01:40.342458
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)

    # PY2
    if pyinfo.PY3:
        assert pyinfo.string_types == (str,)
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
    else:  # PY2
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str



# Generated at 2022-06-21 22:01:42.446491
# Unit test for function configure
def test_configure():
    configure()


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:01:54.644877
# Unit test for function configure
def test_configure():
    logger = logging.getLogger('test_configure')
    logfile = 'temp_log.log'

# Generated at 2022-06-21 22:01:56.399131
# Unit test for function configure
def test_configure():
    configure(DEFAULT_CONFIG)
    assert logging.root.handlers != list()



# Generated at 2022-06-21 22:02:00.120715
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger('test')
    assert isinstance(logger, logging.Logger)
    logger.info('test')


if __name__ == '__main__':
    configure()
    test_getLogger()

# Generated at 2022-06-21 22:02:09.297716
# Unit test for function getLogger

# Generated at 2022-06-21 22:02:12.134601
# Unit test for function get_config
def test_get_config():
    d = {'a': 1, 'b': 2}
    assert get_config(d) == d
    assert get_config(json.dumps(d)) == d
    assert get_config(json.dumps(d)) == d


# Generated at 2022-06-21 22:02:24.825611
# Unit test for function get_config
def test_get_config():
    # Test input string, parse as dict
    dict_config={'handlers': {'console': {'class': 'logging.StreamHandler'}},'loggers': {'foo': {'handlers': ['console'], 'level': 'DEBUG', 'propagate': True}}}
    assert get_config(config='{"handlers": {"console": {"class": "logging.StreamHandler"}},"loggers": {"foo": {"handlers": ["console"], "level": "DEBUG", "propagate": True}}}') == dict_config
    # Test input dict, returns input dict
    assert get_config(config=dict_config) == dict_config
    # Test input None, returns dict config
    assert get_config() == dict_config


# Generated at 2022-06-21 22:02:51.829259
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3, 'python version is not 2 nor 3'
    if _PyInfo.PY2:
        assert isinstance('abc', _PyInfo.string_types)
        assert not isinstance(b'abc', _PyInfo.string_types)
        assert isinstance(u'abc', _PyInfo.text_type)
        assert not isinstance(u'abc', _PyInfo.binary_type)
    elif _PyInfo.PY3:
        assert isinstance('abc', _PyInfo.string_types)
        assert isinstance(b'abc', _PyInfo.string_types)
        assert isinstance('abc', _PyInfo.text_type)
        assert not isinstance(b'abc', _PyInfo.text_type)

# Generated at 2022-06-21 22:02:56.609608
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.debug("This should not be displayed.")
        logger.error("This should be displayed.")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 22:03:06.523332
# Unit test for function get_config
def test_get_config():
    # case 1: given json config
    given_json_config = '{"loggers":{"console":{"level":"INFO","handlers":[' \
                        '"console"]}}}'
    assert get_config(given_json_config) == {'loggers': {'console': {'level': 'INFO', 'handlers': ['console']}}}

    # case 2: given yaml config
    given_yaml_config = 'loggers:\n  console:\n    level: INFO\n    handlers:\n      console'
    assert get_config(given_yaml_config) == {'loggers': {'console': {'level': 'INFO', 'handlers': ['console']}}}

    # case 3: given bare config
    given_bare_config = '- level: INFO'

# Generated at 2022-06-21 22:03:08.773654
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:03:19.314268
# Unit test for function get_config
def test_get_config():
    config = get_config(given = {'version': 1,'formatters':{'simple':{'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s','datefmt':'%Y-%m-%d %H:%M:%S'}},'handlers':{'console':{'class':'logging.StreamHandler','formatter': 'simple','level':'DEBUG'}},'root':{'handlers':['console'],'level':'DEBUG'}})
    assert config['version'] == 1

# Generated at 2022-06-21 22:03:22.085297
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')



# Generated at 2022-06-21 22:03:23.269254
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 == True or _PyInfo.PY2 == True

# Generated at 2022-06-21 22:03:28.411802
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3, "PY2 or PY3 must be True."
    assert not (_PyInfo.PY2 and _PyInfo.PY3), "PY2 and PY3 must not be both True."



# Generated at 2022-06-21 22:03:36.460324
# Unit test for function getLogger
def test_getLogger():
    # Use the logger for the current module
    logger = get_logger()
    # logging.basicConfig(filename='example.log', level=logging.DEBUG)
    logger.debug('This message should go to the log file')
    logger.info('So should this')
    logger.warning('And this, too')

    # Log messages to another logger
    logger = get_logger('other_logger')
    logger.info('This message should go to another logger')
    logger.debug('This message should NOT go to the log file')

# Generated at 2022-06-21 22:03:39.924983
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)

    with logger_level(logger, logging.DEBUG):
        logger.debug("TEST DEBUG")

    with logger_level(logger, logging.INFO):
        logger.info("TEST INFO")

# Generated at 2022-06-21 22:04:06.693166
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    assert log.level == logging.NOTSET
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    assert log.level == logging.NOTSET

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-21 22:04:12.069880
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    log.setLevel(logging.CRITICAL)
    assert log.isEnabledFor(logging.WARNING) is False
    with logger_level(log, logging.WARNING):
        assert log.isEnabledFor(logging.WARNING) is True
    assert log.isEnabledFor(logging.WARNING) is False



# Generated at 2022-06-21 22:04:22.687897
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # fail unless the class is defined
    try:
        py = _PyInfo()
    except NameError:
        assert False, "Unable to find _PyInfo class"

    # fail unless class items are defined and of the right type
    try:
        py.PY2
        py.PY3
        py.string_types
        py.text_type
        py.binary_type
    except AttributeError:
        assert False, "One of the class items not defined"
    if not type(py.PY2) == bool:
        assert False, "PY2 item not of type bool"
    if not type(py.PY3) == bool:
        assert False, "PY3 item not of type bool"

# Generated at 2022-06-21 22:04:26.430150
# Unit test for function configure
def test_configure():
    try:
        configure()
        logger = logging.getLogger('requests')
        assert (logger.level == logging.INFO)
    except:
        logging.basicConfig(level=logging.DEBUG)
        logger = logging.getLogger('requests')
        assert (logger.level == logging.DEBUG)


# Generated at 2022-06-21 22:04:33.340932
# Unit test for function get_config

# Generated at 2022-06-21 22:04:35.703302
# Unit test for function configure
def test_configure():
    configure()
    assert configure() is None
    logger = get_logger()
    logger.error('Testing configure()')



# Generated at 2022-06-21 22:04:41.689563
# Unit test for function configure
def test_configure():
    import json
    import yaml

    # Test for DEFAULT_CONFIG is dict
    configure()

    # Test for json
    json_cfg = json.dumps(DEFAULT_CONFIG)
    configure(json_cfg)

    # Test for yaml
    yaml_cfg = yaml.dump(DEFAULT_CONFIG)
    configure(yaml_cfg)

    # Test for None
    assert configure(None)



# Generated at 2022-06-21 22:04:46.710860
# Unit test for function get_config
def test_get_config():
    # invalid input format
    with pytest.raises(ValueError):
        assert get_config(1)
    # with json
    cfg = '{"key": "value"}'
    config = get_config(cfg)
    assert isinstance(config, dict)
    # with yaml
    cfg = """
    key: value
    """
    config = get_config(cfg)
    assert isinstance(config, dict)
    # with invalid yaml
    cfg = '{key: value}'
    with pytest.raises(ValueError):
        assert get_config(cfg)



# Generated at 2022-06-21 22:04:52.118207
# Unit test for function getLogger
def test_getLogger():
    """when logger name is not specified, getLogger() should return a logger with a name as the module name"""
    logger = getLogger()
    assert logger.name == __name__
    logger.debug('hello world')
    logger.warn('watch out')
    logger.error('oops')
    logger.info('hello world')
    logger.critical('Watch out')



# Generated at 2022-06-21 22:04:56.554191
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert(type(_PyInfo.PY2)==bool)
    assert(type(_PyInfo.PY3)==bool)
    assert(type(_PyInfo.string_types)==tuple)
    assert(type(_PyInfo.text_type)==type)
    assert(type(_PyInfo.binary_type)==type)


# Generated at 2022-06-21 22:05:23.188599
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    print(logger)
    logger.error("test")


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 22:05:30.457122
# Unit test for function getLogger
def test_getLogger():
    conf_str = '''
    ---
    version: 1
    handlers:
        console:
            class: logging.StreamHandler
            level: DEBUG
            formatter: simple
            stream: ext://sys.stdout
    loggers:
        root:
            handlers: [console]
    '''

    configure_from_string(conf_str)

    logger = get_logger('test_logger')

    logger.info('Info message')
    logger.debug('Debug message')
    logger.warning('Warn message')
    logger.error('Error message')


# Generated at 2022-06-21 22:05:31.410431
# Unit test for function configure
def test_configure():
    configure(default=None)



# Generated at 2022-06-21 22:05:38.207676
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('TEST_LOGGER_LEVEL')
    configure()
    with logger_level(logger,logging.INFO):
        logger.info("This is an INFO message")
        with logger_level(logger,logging.DEBUG):
            logger.debug("This is an DEBUG message")
            logger.info("This is an INFO message")
        logger.info("This is an INFO message")


if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-21 22:05:40.886982
# Unit test for function configure
def test_configure():
    """
    >>> log = logging.getLogger(__name__)
    >>> configure()
    >>> log.info('test')
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:05:42.625257
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger()
    log.info('test')


# Generated at 2022-06-21 22:05:45.123583
# Unit test for function configure
def test_configure():
    logger = get_logger(__name__)
    logger.setLevel(logging.INFO)
    logger.info('test configure')

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:05:56.344308
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    from base64 import b64encode

    cfg = DEFAULT_CONFIG

    # Test with default value
    val = get_config(config=None, env_var=None, default=cfg)
    assert val == cfg

    # Test with bare value
    val = get_config(config=cfg, env_var=None, default=None)
    assert val == cfg

    # Test with json value
    j = json.dumps(cfg)
    val = get_config(config=j, env_var=None, default=None)
    assert val == cfg

    # Test with yaml value
    y = yaml.dump(cfg)
    val = get_config(config=y, env_var=None, default=None)
    assert val == cfg

    # Test

# Generated at 2022-06-21 22:06:01.998888
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert type('') in _PyInfo.string_types
    assert type(u'') in _PyInfo.string_types
    assert type(b'') is _PyInfo.binary_type
    assert type(_PyInfo.text_type('')) is _PyInfo.text_type
    assert type(_PyInfo.binary_type('')) is _PyInfo.binary_type


# Test for function _namespace_from_calling_context()

# Generated at 2022-06-21 22:06:07.773983
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)

    def foo():
        log.critical('critical')
        log.error('error')
        log.warning('warning')
        log.info('info')
        log.debug('debug')

    with logger_level(log, logging.DEBUG):
        foo()

    with logger_level(log, logging.INFO):
        foo()


# Utility context manager

# Generated at 2022-06-21 22:06:33.252554
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    log.setLevel(logging.NOTSET)
    assert log.getEffectiveLevel() == logging.NOTSET
    configure()
    assert log.getEffectiveLevel() == 10



# Generated at 2022-06-21 22:06:34.696667
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')


# Generated at 2022-06-21 22:06:45.206099
# Unit test for function configure
def test_configure():
    from StringIO import StringIO
    import sys

    log = logging.getLogger(__name__)

    # create a StringIO for StringOutput
    StringOutput = StringIO()
    sys.stdout = StringOutput
    log.info('test')
    sys.stdout = sys.__stdout__

    # create a StringIO for StringError
    StringError = StringIO()
    sys.stderr = StringError
    log.error('test')
    sys.stderr = sys.__stderr__

    # get the string from StringOutput and StringError
    string_output = StringOutput.getvalue().strip()
    string_error = StringError.getvalue().strip()

    # validate the string

# Generated at 2022-06-21 22:06:54.995043
# Unit test for function get_config
def test_get_config():
    # JSON
    config = get_config(config=r'{"version": 1}')
    assert(config == {"version": 1})
    config = get_config(config=b'{"version": 1}')
    assert(config == {"version": 1})
    config = get_config(env_var="JSON_TEST", config=r'{"version": 1}')
    assert(config == {"version": 1})
    config = get_config(env_var="JSON_TEST", config=b'{"version": 1}')
    assert(config == {"version": 1})

    # YAML
    config = get_config(config=r'---\nversion: 1\n')
    assert(config == {"version": 1})
    config = get_config(config=b'---\nversion: 1\n')

# Generated at 2022-06-21 22:06:56.956972
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-21 22:06:58.464320
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3


# Generated at 2022-06-21 22:07:00.743970
# Unit test for function configure
def test_configure():
    configure()


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:07:10.826862
# Unit test for function logger_level
def test_logger_level():
    config = {'version': 1,
              'disable_existing_loggers': True,
              'handlers': {'console': {'class': 'logging.StreamHandler',
                                       'level': 'DEBUG',
                                       'formatter': 'simple'}},
              'root': {'level': 'DEBUG',
                       'handlers': ['console']},
              'loggers': {'test': {'level': 'DEBUG'}},
              'formatters': {'simple': {'format': '[%(levelname)s] %(message)s'}}}

    logging.config.dictConfig(config)
    logger = logging.getLogger('test')
    logger.debug('This should not be printed')
    with logger_level(logger, 'DEBUG'):
        logger.debug('This should be printed')

# Generated at 2022-06-21 22:07:14.371369
# Unit test for function getLogger
def test_getLogger():
    import logging
    import logging.config
    import json
    from contextlib import contextmanager
    from os import environ

    logger = get_logger()

    # print(logger.__doc__)
    logger.info('test')
    logger.warn('test2')
    logger.error('test3')
    logger.debug('test4')

    config = DEFAULT_CONFIG
    logging.config.dictConfig(config)

    # print(config)
    logger.debug('test3')

# Generated at 2022-06-21 22:07:24.859240
# Unit test for function get_config