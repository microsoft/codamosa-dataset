

# Generated at 2022-06-21 21:57:22.803308
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo1 = _PyInfo()
    assert pyinfo1.PY2 == (sys.version_info[0] == 2)
    assert pyinfo1.PY3 == (sys.version_info[0] == 3)

    if pyinfo1.PY3:
        assert pyinfo1.string_types == (str,)
        assert pyinfo1.text_type == str
        assert pyinfo1.binary_type == bytes
    else:  # PY2
        assert pyinfo1.string_types == (basestring,)
        assert pyinfo1.text_type == unicode
        assert pyinfo1.binary_type == str


# Generated at 2022-06-21 21:57:29.760987
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False
    assert isinstance('abc', _PyInfo.string_types)
    assert isinstance(u'abc', _PyInfo.string_types)
    assert _PyInfo.text_type == str
    assert _PyInfo.binary_type == bytes


# Generated at 2022-06-21 21:57:39.988443
# Unit test for function getLogger
def test_getLogger():
    from systemtools.duration import Duration
    from systemtools.logger import config as loggerConfig

    loggerConfig.configure(dict(disable_existing_loggers=False, loggers=dict(root=dict(level="ERROR"))))
    logger = getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.info("Hello world!")
    with Duration("Info"):
        logger.info("Hello world!")

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 21:57:51.611735
# Unit test for function get_config

# Generated at 2022-06-21 21:57:54.807409
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    _PyInfo.PY2
    _PyInfo.PY3
    _PyInfo.string_types
    _PyInfo.text_type
    _PyInfo.binary_type

if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-21 21:58:00.632527
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('logger_level')
    log.setLevel(logging.DEBUG)
    with logger_level(log, logging.INFO):
        log.info("This is info")
        log.debug("This is debug")

        with logger_level(log, logging.ERROR):
            log.error("This is error")
            log.debug("This is debug")
            log.info("This is info")

        log.warn("This is warning")
        log.debug("This is debug")
try:
    import unittest.mock
except ImportError:
    # noinspection PyUnresolvedReferences
    import mock
else:
    # noinspection PyUnresolvedReferences
    import unittest.mock



# Generated at 2022-06-21 21:58:08.826267
# Unit test for function logger_level
def test_logger_level():
    """Test function logger_level"""
    import logging

    # log_test = logging.getLogger("test")
    log_test = getLogger("test")

    # raise "test"
    log_test.debug("test")

    # with logger_level(log_test, logging.WARN):
    with logger_level(log_test, logging.WARNING):
        log_test.info("hello")
        log_test.debug("hello")
        log_test.warning("hello")
        # log_test.raiseException("hello")

    log_test.debug("test")
    log_test.info("test")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-21 21:58:10.850853
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.debug("not printed")
        logger.info("not printed")
        logger.error("printed")



# Generated at 2022-06-21 21:58:17.948783
# Unit test for function configure

# Generated at 2022-06-21 21:58:24.021617
# Unit test for function getLogger
def test_getLogger():
    import io
    import sys
    import contextlib
    with contextlib.redirect_stdout(io.StringIO()) as output:
        log = logging.getLogger(__name__)
        log.info("hello")
        assert '[%s] INFO hello %s' % (
            os.path.basename(__file__),
            inspect.stack()[1][3]
        ) in output.getvalue()

# Generated at 2022-06-21 21:58:30.794378
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py_info = _PyInfo()
    assert py_info.binary_type == binary_type
    assert py_info.string_types == string_types


# Unit tests for function _namespace_from_calling_context()

# Generated at 2022-06-21 21:58:33.358855
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), logging.DEBUG):
        getLogger().info('Info message')
        getLogger().debug('Debug message')
    getLogger().debug('Debug message')

# Generated at 2022-06-21 21:58:41.524019
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG, "configuration should match default"
    assert config == get_config(config, default=DEFAULT_CONFIG), "configuration should match default"
    assert config == get_config(json.dumps(config), default=DEFAULT_CONFIG), "configuration should match default"
    assert config == get_config(yaml.dump(config), default=DEFAULT_CONFIG), "configuration should match default"

# Generated at 2022-06-21 21:58:50.336403
# Unit test for function get_config
def test_get_config():
    print("Testing function get_config")
    assert get_config() == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config("""{"version": 1}""") == {"version": 1}
    assert get_config("""{"version": 1}""", env_var=None, default=DEFAULT_CONFIG) == {"version": 1}
    assert get_config("""{"version": 1}""", default=None, env_var=None) == {"version": 1}
    assert get_config("""{"version": 1}""", default=DEFAULT_CONFIG, env_var=None) == {"version": 1}

# Generated at 2022-06-21 21:58:53.539712
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    assert log.getEffectiveLevel() == 10
    log.info("test Logger")

    log = get_logger('test2')
    assert log.getEffectiveLevel() == 10
    log.info("test Logger2")

# Generated at 2022-06-21 21:59:04.087971
# Unit test for function configure
def test_configure():
    import json


# Generated at 2022-06-21 21:59:11.140370
# Unit test for function logger_level
def test_logger_level():
    import pytest
    import io
    import sys
    log = get_logger()
    sout = io.StringIO()
    sys.stdout = sout
    log.setLevel(10)
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')
    assert 'debug' not in sout.getvalue()
    assert 'info' not in sout.getvalue()
    assert 'warning' in sout.getvalue()
    assert 'error' in sout.getvalue()
    assert 'critical' in sout.getvalue()

    sout = io.StringIO()
    sys.stdout = sout
    log.setLevel(20)
    log.debug('debug')

# Generated at 2022-06-21 21:59:13.243320
# Unit test for function getLogger
def test_getLogger():
    log = getLogger("test_getLogger")
    log.info("test")
    log.debug("test")

# Generated at 2022-06-21 21:59:22.756930
# Unit test for function configure

# Generated at 2022-06-21 21:59:24.289346
# Unit test for function configure
def test_configure():
    configure()
    assert logging.Logger.root.handlers


# Generated at 2022-06-21 21:59:31.740121
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    info = _PyInfo()
    assert info.PY2 == True or info.PY2 == False, "PY2 is not boolean"
    assert info.PY3 == True or info.PY3 == False, "PY3 is not boolean"

# Generated at 2022-06-21 21:59:38.902162
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert isinstance(logger, logging.Logger)
    assert logger.name == '__main__'

    logger = get_logger('my_logger')
    assert isinstance(logger, logging.Logger)
    assert logger.name == 'my_logger'

    logger = get_logger(__name__)
    assert isinstance(logger, logging.Logger)
    assert logger.name == __name__



# Generated at 2022-06-21 21:59:41.009284
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test')



# Generated at 2022-06-21 21:59:50.040623
# Unit test for function get_config
def test_get_config():
    import collections


# Generated at 2022-06-21 21:59:56.401608
# Unit test for function configure
def test_configure():
    test_log = logging.getLogger('test')
    configure()
    test_log.info('test')
    test_log.debug('test')
    test_log.error('test')
    test_log.warning('test')
    test_log.critical('test')
    configure(default=None)


if __name__ == '__main__':
    configure()
    test_configure()

# Generated at 2022-06-21 22:00:05.712443
# Unit test for function get_config
def test_get_config():
    """
    >>> print(get_config('{"handlers": {"console": {"class": "logging.StreamHandler"}}}'))
    {'handlers': {'console': {'class': 'logging.StreamHandler'}}}

    >>> print(get_config('{"handlers": {"console": {"class": "logging.StreamHandler"}}}', env_var='LOGGING'))
    {'handlers': {'console': {'class': 'logging.StreamHandler'}}}

    >>> print(get_config(None, env_var='LOGGING', default='{"handlers": {"console": {"class": "logging.StreamHandler"}}}'))
    {'handlers': {'console': {'class': 'logging.StreamHandler'}}}
    """
    pass



# Generated at 2022-06-21 22:00:08.351044
# Unit test for function configure
def test_configure():
    import colorlog
    cfg = configure()
    formatters = cfg['formatters']
    colored = formatters['colored']
    assert colored['()'] == 'colorlog.ColoredFormatter'

# Generated at 2022-06-21 22:00:18.498557
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test success cases

    # 1. Logging config given as bare string.
    cfg = 'test'
    assert get_config(cfg) == cfg

    # 2. Logging config given as json string.
    cfg = '{"loggers": {"foo": "bar"}}'
    assert get_config(cfg) == json.loads(cfg)

    # 3. Logging config given as yaml string.
    cfg = 'loggers:\n foo: bar'
    assert get_config(cfg) == yaml.load(cfg)

    # Test failure cases

    # 1. Invalid logging config given as bare string.
    cfg = '{'
    try:
        get_config(cfg)
        assert False
    except ValueError:
        assert True

    # 2. Invalid logging

# Generated at 2022-06-21 22:00:21.883948
# Unit test for function getLogger
def test_getLogger():
    print(getLogger().name)
    print(getLogger('test').name)
    print(logging.getLogger().name)


# Generated at 2022-06-21 22:00:26.267213
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 ^ _PyInfo.PY3
    assert isinstance('str', _PyInfo.string_types)
    assert isinstance(u'unicode', _PyInfo.string_types)



# Generated at 2022-06-21 22:00:35.246617
# Unit test for function configure
def test_configure():
    # import colorlog
    # import logging
    # import logging.config
    # import sys
    # import os
    # from contextlib import contextmanager

    log = logging.getLogger(__name__)
    configure()
    log.info('test')


# Generated at 2022-06-21 22:00:39.037956
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        assert logging.INFO == logger.level
    assert logging.DEBUG == logger.level

# Generated at 2022-06-21 22:00:42.422776
# Unit test for function get_config
def test_get_config():
    assert get_config(1) == 1
    assert get_config('{"a": 1}') == {"a": 1}
    assert get_config('a: 1') == {"a": 1}

# Generated at 2022-06-21 22:00:50.083104
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import platform
    assert _PyInfo.PY2 == (platform.python_version_tuple()[0] == 2)
    assert _PyInfo.PY3 == (platform.python_version_tuple()[0] == 3)
    assert _PyInfo.string_types == (basestring, ) if _PyInfo.PY2 else (str, )
    assert _PyInfo.text_type == unicode if _PyInfo.PY2 else str
    assert _PyInfo.binary_type == str if _PyInfo.PY2 else bytes


# Generated at 2022-06-21 22:01:00.874207
# Unit test for function logger_level
def test_logger_level():
    class Record(logging.LogRecord):

        def __init__(self, *args, **kwargs):
            super(Record, self).__init__(*args, **kwargs)
            self.levelno = kwargs.get('levelno')

        def getMessage(self):
            return self.msg

    class DummyLogger(object):

        def __init__(self):
            self.level = logging.DEBUG
            self.msg = None
            self.levelno = logging.DEBUG

        def _log(self, level, msg, args, **kwargs):
            self.msg = msg
            self.levelno = level

    logger = DummyLogger()

# Generated at 2022-06-21 22:01:11.596960
# Unit test for function configure
def test_configure():
    import json
    import yaml
    import io

    log = logging.getLogger(__name__)


# Generated at 2022-06-21 22:01:17.212134
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')
    assert log.isEnabledFor(logging.INFO)
    assert not log.isEnabledFor(logging.DEBUG)



# Generated at 2022-06-21 22:01:22.659910
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert isinstance(u'', _PyInfo.binary_type)
    assert isinstance(b'', _PyInfo.text_type)



# Generated at 2022-06-21 22:01:32.146179
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # _PyInfo.__init__()
    pyinfo = _PyInfo()
    assert pyinfo.PY3 is True or pyinfo.PY3 is False
    assert pyinfo.PY2 is True or pyinfo.PY2 is False
    assert pyinfo.PY3 != pyinfo.PY2
    assert isinstance(pyinfo.string_types, tuple)
    assert len(pyinfo.string_types) > 0
    for s in pyinfo.string_types:
        assert isinstance(s, type(""))
    assert isinstance(pyinfo.text_type, str)
    assert isinstance(pyinfo.binary_type, bytes)


# Generated at 2022-06-21 22:01:34.033997
# Unit test for function getLogger
def test_getLogger():
    log = getLogger('test_getLogger')
    log.info('test_getLogger')

# Generated at 2022-06-21 22:01:44.001870
# Unit test for function get_config
def test_get_config():
    assert (get_config() == DEFAULT_CONFIG)
    assert (get_config(config={'hello': 'world'}) == {'hello': 'world'})
    assert (get_config(config='{"hello": "world"}') == {'hello': 'world'})


# Generated at 2022-06-21 22:01:49.544082
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test info')
    logger.warn('test warn')
    logger.error('test error')
    logger.debug('test debug')
    assert logger.level == logging.INFO
    logger.setLevel(logging.DEBUG)
    logger.debug('test debug')


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 22:01:55.455557
# Unit test for function getLogger
def test_getLogger():
    # Given
    _CONFIGURED.append(False)

    # When
    log = get_logger(name='test_logger')

    # Then
    assert log.name == 'test_logger'


if __name__ == '__main__':
    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-21 22:01:59.915178
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert not _PyInfo.PY2
    assert _PyInfo.PY3
    assert isinstance(b't', _PyInfo.binary_type)
    assert isinstance('t', _PyInfo.string_types)
    assert _PyInfo.binary_type != _PyInfo.string_types


# Generated at 2022-06-21 22:02:03.005007
# Unit test for function getLogger
def test_getLogger():
    """Test for function getLogger:

    >>> log = getLogger('test2')
    >>> log.info('test2')
    """
    pass



# Generated at 2022-06-21 22:02:07.508512
# Unit test for function logger_level
def test_logger_level():
    wrap_str = 'wrap'
    logger = getLogger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        logger.info(wrap_str)
    assert logger.level == logging.DEBUG
    logger.debug(wrap_str)

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 22:02:11.684856
# Unit test for function getLogger
def test_getLogger():
    """
    Unit test for getLogger

    >>> log = getLogger("mylogger")
    >>> log.info("Calling test_getLogger")

    """


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:02:20.200408
# Unit test for function getLogger
def test_getLogger():
    import time
    log = get_logger('test_get_logger')
    for i in range(2):
        log.debug('debug message')
        log.info('info message')
        log.warning('warning message')
        log.error('error message')
        log.critical('critical message')
        time.sleep(1)


# Uncomment below line to run this test
# test_getLogger()

# Generated at 2022-06-21 22:02:24.157591
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance(17, _PyInfo.PY2) is False
    assert isinstance(17, _PyInfo.PY3) is False


if __name__ == '__main__':
    log = get_logger()
    log.info('test')

# Generated at 2022-06-21 22:02:26.103933
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)

# Generated at 2022-06-21 22:02:38.977352
# Unit test for function logger_level
def test_logger_level():
    """
    >>> import logging
    >>> from funcy import lmap
    >>> logger = logging.getLogger(__name__)
    >>> configure()
    >>> for level in logging._levelNames.items():
    ...     with logger_level(logger, level[1]):
    ...         logger.info(u'This is a test string {}'.format(level[0]))
    ...
    """



# Generated at 2022-06-21 22:02:47.043043
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    if pyinfo.PY3:
        assert not isinstance("test", pyinfo.string_types)
        assert isinstance("test", pyinfo.string_types + (bytes, ))
    else:
        assert isinstance("test", pyinfo.string_types)
        assert pyinfo.binary_type is str


# Generated at 2022-06-21 22:02:57.526333
# Unit test for function getLogger
def test_getLogger():
    try:
        import simplejson as json
    except ImportError:
        import json

    import __main__ as mod

    cfg = get_config(None, 'LOGGING', DEFAULT_CONFIG)
    assert cfg == DEFAULT_CONFIG
    cfg = get_config(json.dumps(DEFAULT_CONFIG), None, None)
    assert cfg == DEFAULT_CONFIG
    logger = get_logger(mod.__name__)
    assert logger.getEffectiveLevel() == logging.DEBUG


# Generated at 2022-06-21 22:03:03.937086
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import sys
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.string_types == (basestring, ) if _PyInfo.PY2 else (str, )
    assert _PyInfo.text_type == unicode if _PyInfo.PY2 else str
    assert _PyInfo.binary_type == str if _PyInfo.PY2 else bytes

# Generated at 2022-06-21 22:03:10.017221
# Unit test for function configure
def test_configure():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        """Capture stdout/stderr from a block.
        :return: stdout/stderr
        :rtype: basestring
        """
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-21 22:03:19.542039
# Unit test for function get_config

# Generated at 2022-06-21 22:03:27.461585
# Unit test for function get_config
def test_get_config():
    try:
        get_config()
    except ValueError as e:
        assert(e.args[0] == 'Invalid logging config: None')

    try:
        get_config(None)
    except ValueError as e:
        assert(e.args[0] == 'Invalid logging config: None')

    try:
        get_config('abc')
    except ValueError as e:
        assert(e.args[0] == 'Invalid logging config: abc')

    try:
        get_config('abc', default='abc')
    except ValueError as e:
        assert(e.args[0] == 'Invalid logging config: abc')

    assert(get_config('{"version": 1}') == {"version": 1})

# Generated at 2022-06-21 22:03:30.478207
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    
    logger.setLevel(logging.CRITICAL)
    assert logger.level == logging.CRITICAL
    logger.critical('should appear')
    logger.warning('should not appear')
    
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
        logger.critical('should appear')
        logger.warning('should appear')

    assert logger.level == logging.CRITICAL
    logger.critical('should appear')
    logger.warning('should not appear')


# Unit test
test_logger_level()

# Generated at 2022-06-21 22:03:41.004037
# Unit test for function get_config
def test_get_config():
    print("Test get_config")

# Generated at 2022-06-21 22:03:50.929895
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.WARNING):
        logger.debug('test')

    # Set logger level back to debugging in case other tests need it
    logger.setLevel(logging.DEBUG)
    logger.debug('test')
    logger.warning('test')


# Note: the EMPTY_LOGGING dict is not the same as the DEFAULT_CONFIG
# dict!
# The DEFAULT_CONFIG dict contains a root logger, but disabling logging
# will remove the root logger.
EMPTY_LOGGING = dict(version=1, disable_existing_loggers=True)



# Generated at 2022-06-21 22:04:06.313627
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
        log.debug("debugging")
        log.info("informational")
    assert log.level == logging.INFO
    log.info("informational")

# Generated at 2022-06-21 22:04:17.410043
# Unit test for function get_config
def test_get_config():
    from yaml import version_info as yaml_version_info

    if yaml_version_info < (3, 0):
        # Skip test for old yaml version
        pass
    else:
        # Test bare string
        config = "bare string passed as logging config"
        assert get_config(config) == config

        # Test json string
        config = '{"version": 1, "disable_existing_loggers": false}'
        assert get_config(config) == json.loads(config)

        # Test yaml string

# Generated at 2022-06-21 22:04:26.646125
# Unit test for function get_config
def test_get_config():
    default = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "simple": {
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            }
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "level": "DEBUG",
                "formatter": "simple",
                "stream": "ext://sys.stdout"
            },
        },
        "root": {
            "level": "INFO",
            "handlers": ["console"]
        }
    }
    # Test for default
    assert default == get_config()
    # Test for False
    assert default == get_config(config=False)


# Generated at 2022-06-21 22:04:32.108963
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert _PyInfo.string_types == (basestring, ) if _PyInfo.PY2 else (str, )
    assert _PyInfo.text_type == unicode if _PyInfo.PY2 else str
    assert _PyInfo.binary_type == str if _PyInfo.PY2 else bytes



# Generated at 2022-06-21 22:04:40.852894
# Unit test for function logger_level
def test_logger_level():
    from StringIO import StringIO

    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        log = get_logger("test")
        with logger_level(log, logging.DEBUG):
            log.info("This should be logged even though INFO is the default")
        with logger_level(log, logging.WARNING):
            log.info("This should NOT be logged")
        assert "This should be logged" in out.getvalue()
        assert "This should NOT be logged" not in out.getvalue()
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-21 22:04:46.395993
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import sys
    import os
    import json
    import yaml

    class_test = _PyInfo()
    assert 'test_colorlog' in os.environ["LOGGING"], '"LOGGING" must be exported and set to test_colorlog.yaml'
    assert class_test.PY2 or class_test.PY3, 'Only python 2 or 3 are supported'
    assert sys.version_info[0] == json.loads(os.environ.get("LOGGING"))["version"]

    assert isinstance(yaml.load(os.environ.get("LOGGING")), dict)



# Generated at 2022-06-21 22:04:48.599825
# Unit test for function configure
def test_configure():
    configure()


if __name__ == '__main__':
    import nose

    nose.runmodule()

# Generated at 2022-06-21 22:04:51.961181
# Unit test for function get_config
def test_get_config():
    # get_config should raise a ValueError if no default is given and the argument or env var is None
    config = get_config(None, 'FOO', None)
    assert config == None


# Generated at 2022-06-21 22:05:01.396538
# Unit test for function get_config
def test_get_config():
    assert get_config(config=None, env_var=None, default=None) == None
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=None) == DEFAULT_CONFIG
    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config="any string", env_var=None, default=DEFAULT_CONFIG) == "any string"
    assert get_config(config='{ "version": 1}', env_var=None, default=DEFAULT_CONFIG) == { "version": 1}
    assert get_config(config='version: 1', env_var=None, default=DEFAULT_CONFIG) == { "version": 1}



# Generated at 2022-06-21 22:05:06.595460
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('utils.test')
    # logger.setLevel(logging.DEBUG)
    # logger.debug('start test_logger_level')
    with logger_level(logger, logging.DEBUG):
        assert logger.level == 10
        logger.debug('log under DEBUG')
    assert logger.level == 20
    logger.debug('log under INFO')
    # logger.debug('end test_logger_level')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 22:05:22.164562
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.string_types
    assert _PyInfo.text_type
    assert _PyInfo.binary_type


# Generated at 2022-06-21 22:05:27.793660
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 is sys.version_info[0] == 3
    assert _PyInfo.PY2 is sys.version_info[0] == 2

    if _PyInfo.PY2:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    else:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes




# Generated at 2022-06-21 22:05:33.294850
# Unit test for function logger_level
def test_logger_level():
    import time
    import requests

    log = getLogger()

    with logger_level(log, logging.ERROR):
        log.debug("DEBUG message")
        log.info("INFO message")

    log.debug("DEBUG message")
    log.info("INFO message")

    # End of test case
    log.info('=' * 100)



# Generated at 2022-06-21 22:05:35.933106
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')
    log.debug('test')
    log.info('test')


# Generated at 2022-06-21 22:05:44.613554
# Unit test for function configure
def test_configure():
    import json
    import logging
    import os
    import tempfile
    import unittest

    with tempfile.NamedTemporaryFile('w+') as fp:
        def get_logger(name):
            return logging.getLogger(name)

        def check_logger():
            return logging.getLogger('test')

        log = get_logger('test')

        # Check if basic logger works.

# Generated at 2022-06-21 22:05:56.303068
# Unit test for function logger_level
def test_logger_level():
    from . import TestCase
    from . import Abbrev

    import logging

    logger = logging.getLogger('test')
    logger.setLevel(logging.INFO)

    class test_logger_level(TestCase):
        def log_debug(self):
            with logger_level(logger, logging.DEBUG):
                logger.debug('foo')

        def log_info(self):
            with logger_level(logger, logging.INFO):
                logger.info('foo')

        def log_warn(self):
            with logger_level(logger, logging.WARN):
                logger.warn('foo')

    test = test_logger_level()

    test.log_debug()
    test.log_info()
    test.log_warn()

    assert Abbrev('DEBUG', 'foo') in test.log

# Generated at 2022-06-21 22:06:05.718788
# Unit test for function get_config
def test_get_config():
    config = get_config('{"version": 1}')
    assert config['version'] == 1

    config = get_config('version: 1')
    assert config['version'] == 1

    try:
        config = get_config('version: 1a')
    except ValueError:
        pass
    else:
        raise Exception('Bad yaml formatting should raise ValueError')

    assert get_config({'version': 1})['version'] == 1

    os.environ['LOGGING'] = json.dumps({'version': 1})
    assert get_config()['version'] == 1

    os.environ['LOGGING'] = 'version: 1'
    assert get_config()['version'] == 1


# Generated at 2022-06-21 22:06:12.785876
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test_logger_level')
    with logger_level(log, logging.DEBUG):
        log.debug('test_logger_level')
    try:
        log.debug('test_logger_level')
    except Exception:
        return True
    return False



# Generated at 2022-06-21 22:06:14.783884
# Unit test for function configure
def test_configure():
    import logging.handlers
    configure()
    logging.warning("test_configure")


# Generated at 2022-06-21 22:06:20.652443
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    obj = _PyInfo()
    assert type(obj.PY2) == bool
    assert type(obj.PY3) == bool
    assert type(obj.string_types) == tuple
    assert type(obj.text_type) == type
    assert type(obj.binary_type) == type



# Generated at 2022-06-21 22:06:34.309601
# Unit test for function get_config
def test_get_config():
  assert get_config('{"disable_existing_loggers": false}') == {'disable_existing_loggers': False}

if __name__ == '__main__':
    get_config()
    get_logger()
    test_get_config()

# Generated at 2022-06-21 22:06:36.090713
# Unit test for function configure
def test_configure():
    # TODO: need to be able to actually test the logging output
    log = get_logger(__name__)
    log.info('test')



# Generated at 2022-06-21 22:06:41.629213
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = get_logger('test')
    >>> with logger_level(logger, logging.WARN):
    ...   logger.info('a')
    ...
    >>> with logger_level(logger, logging.DEBUG):
    ...   logger.info('b')
    b
    >>> logger.info('c')
    c
    """



# Generated at 2022-06-21 22:06:44.065225
# Unit test for function configure
def test_configure():
    configure()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:06:51.906313
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    if pyinfo.PY2:
        assert isinstance('a', pyinfo.text_type)
        assert isinstance('a', pyinfo.string_types)
        assert not isinstance(u'a', pyinfo.binary_type)
    else:
        assert isinstance(u'a', pyinfo.text_type)
        assert isinstance(u'a', pyinfo.string_types)
        assert isinstance(b'a', pyinfo.binary_type)


if __name__ == '__main__':
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-21 22:07:00.642774
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    configure()

    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info - should not show up')

    log.debug('debug - should not show up')
    log.info('info')


if __name__ == '__main__':
    # import nose
    # nose.runmodule()
    # test_logger_level()
    test_logger_level()

# Generated at 2022-06-21 22:07:09.903499
# Unit test for function getLogger
def test_getLogger():
    import logging
    import sys
    from contextlib import contextmanager

    with logger_level(logging.getLogger(), logging.CRITICAL):

        old_stderr = sys.stderr
        sys.stderr = sys.stdout

        try:
            log = getLogger()
            log.info('error message')
            log.error('error message')
            log.debug('error message')
            log.warn('error message')
            log.warning('error message')
            log.fatal('error message')
            log.critical('error message')
        finally:
            sys.stderr = old_stderr

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:07:15.165130
# Unit test for function getLogger
def test_getLogger():

    # No args, default
    log = getLogger()
    assert log.name == '__main__'

    # name param
    log = getLogger('test')
    assert log.name == 'test'

    # name in a different module
    try:
        # Py3
        log = getLogger()  # noqa
        assert False, 'We should not be able to get a logger() in a function'
    except ValueError:
        pass

    def foo():
        log = getLogger()
        assert log.name == __name__ + '.foo'

    foo()

    import pkg_resources

    foo = pkg_resources.load_entry_point('requests', 'console_scripts', 'requests')
    log = getLogger()
    assert log.name == 'pkg_resources'