

# Generated at 2022-06-21 21:57:27.839061
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY3 == True
    assert pyinfo.PY2 == False


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:57:31.424223
# Unit test for function configure
def test_configure():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 21:57:38.561875
# Unit test for function getLogger
def test_getLogger():
    log = get_logger("test")
    print("%x" % id(log))
    log1 = get_logger("test")
    print("%x" % id(log1))
    assert(id(log) == id(log1))
    assert(log.name == "test")
    log2 = get_logger("test1")
    print("%x" % id(log2))
    assert(id(log) != id(log2))


# Generated at 2022-06-21 21:57:50.715833
# Unit test for function get_config
def test_get_config():
    # Test the config dict is parsed correctly
    dict_config = dict(version=1,
                       formatters={'simple': {'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'}},
                       handlers={'console': {'class': 'logging.StreamHandler',
                                             'formatter': 'simple',
                                             'level': logging.DEBUG}},
                       root={'handlers': ['console'], 'level': logging.DEBUG})

    assert get_config(dict_config) == dict_config

    # Test the config string represents a dict correctly
    dict_config_str = json.dumps(dict_config)
    assert get_config(dict_config_str) == dict_config

    # Test the config string represents a yaml correctly
    yaml

# Generated at 2022-06-21 21:57:53.846411
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    info = _PyInfo()
    assert info.PY2 == True or info.PY2 == False
    assert info.PY3 == True or info.PY3 == False
    assert info.PY2 != info.PY3


# Generated at 2022-06-21 21:57:55.403838
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    assert isinstance(log, logging.Logger)


# Generated at 2022-06-21 21:58:00.091476
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    logger = logging.getLogger()
    logger.level = logging.INFO
    assert logger.level == logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO


# Generated at 2022-06-21 21:58:07.211721
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('this')
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        # The below test depends on the fact that the logging
        # library suppresses output of log messages with a level
        # less than what is configured.
        # This is a pretty lame test, but... I don't see a
        # better way to actually check if the thing is working
        # or not.
        logger.info('test')
    assert logger.level == logging.INFO

# Generated at 2022-06-21 21:58:13.189264
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    info = _PyInfo()
    assert type(info.PY2) == type(info.PY3) == bool
    assert type(info.string_types) == tuple
    assert type(info.text_type) == type(info.binary_type) == type


# Generated at 2022-06-21 21:58:15.666975
# Unit test for function getLogger
def test_getLogger():
    try:
        getLogger()
    except:
        raise

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 21:58:21.912533
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test_getLogger')

    assert(
        str(logger)
        == str(logging.getLogger('test_getLogger'))
    )

# Generated at 2022-06-21 21:58:24.334787
# Unit test for function configure
def test_configure():
    logger = get_logger(__name__)
    logger.info('hello world')



# Generated at 2022-06-21 21:58:26.946012
# Unit test for function configure
def test_configure():
    """
    >>> import logging
    >>> log = logging.getLogger(__name__)
    >>> configure()
    >>> log.info('test')
    """


# Generated at 2022-06-21 21:58:32.557585
# Unit test for function get_config
def test_get_config():
    config = get_config(default={'key': 'value'})
    assert config == {'key': 'value'}
    assert get_config(config={'key': 'value'}) == {'key': 'value'}
    assert get_config('{"key": "value"}') == {'key': 'value'}
    assert get_config('key: value\n', default={'key': 'value'}) == {'key': 'value'}



# Generated at 2022-06-21 21:58:38.451755
# Unit test for function get_config

# Generated at 2022-06-21 21:58:40.666928
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2 is True

    assert (_PyInfo().PY2 is False) is not True


# Generated at 2022-06-21 21:58:43.060133
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

# Unit tests for function get_logger

# Generated at 2022-06-21 21:58:47.483044
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug(__name__)
    log.info(__name__)

if __name__ == "__main__":
    log = get_logger(__name__)
    configure()
    test_logger_level()

# Generated at 2022-06-21 21:58:49.414425
# Unit test for function configure
def test_configure():
    configure()


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:58:53.087876
# Unit test for function configure
def test_configure():
    configure()
    log = getLogger()
    log.info('test')
    log.debug('test')
    log.warning('test')
    log.error('test')
    log.critical('test')



# Generated at 2022-06-21 21:59:02.692623
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('logger_level')
    logger.setLevel(logging.INFO)
    logger.info("This is a test")
    logger.debug("This is NOT a test")
    with logger_level(logger, logging.DEBUG):
        logger.info("This is a test")
        logger.debug("This is NOT a test")


# Generated at 2022-06-21 21:59:05.992470
# Unit test for function getLogger
def test_getLogger():
    configure()
    logger = get_logger()
    logger.info("testing getLogger")
    logger = get_logger(__name__)
    logger.info("testing getLogger for current module")


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 21:59:12.014603
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert isinstance(config, dict)

    config = get_config(env_var='LOGGING', default=DEFAULT_CONFIG)
    assert isinstance(config, dict)

    config = get_config(given='{"version":1,"disable_existing_loggers":false,"formatters":{},"handlers":{},"root":{},"loggers":{}}')
    assert isinstance(config, dict)

    config = get_config(given='version: 1')
    assert isinstance(config, dict)

    with pytest.raises(ValueError):
        get_config(given='broken config')


if __name__ == '__main__':
    test_get_config()
    configure()
    log = get_logger()

# Generated at 2022-06-21 21:59:22.158751
# Unit test for function get_config
def test_get_config():
    # given=None, env_var=None, default=None
    assert get_config() == {}
    # given=None, env_var='LOGGING', default=None
    assert get_config(env_var='LOGGING') == {}
    # given=None, env_var='LOGGING', default=DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    # given={}, env_var='LOGGING', default=DEFAULT_CONFIG
    assert get_config(given={}, env_var='LOGGING', default=DEFAULT_CONFIG) == {}

    # given='', env_var='LOGGING', default=DEFAULT_CONFIG

# Generated at 2022-06-21 21:59:24.074096
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 or pyinfo.PY3


# Generated at 2022-06-21 21:59:29.359530
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    assert log == getLogger()

    log = getLogger('test')
    assert log == getLogger('test')

    log.info('test')
    log.info('test')

    log = getLogger(__name__)
    log.info('test2')
    log.info('test2')



# Generated at 2022-06-21 21:59:40.159635
# Unit test for function get_config

# Generated at 2022-06-21 21:59:49.837294
# Unit test for function get_config
def test_get_config():
    # Test for plain logging config
    plain_log_config = """
handlers:
  console:
    (): colorlog.handle.StreamHandler
    formatter: colored
    level: DEBUG
"""
    assert get_config(plain_log_config) == {
        'handlers': {
            'console': {
                '()': 'colorlog.handle.StreamHandler',
                'formatter': 'colored',
                'level': logging.DEBUG
            }
        }
    }

    # Test for json logging config
    json_log_config = """
{
  "handlers": {
    "console": {
      "()": "colorlog.handle.StreamHandler",
      "formatter": "colored",
      "level": "DEBUG"
    }
  }
}
"""

# Generated at 2022-06-21 21:59:57.611117
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test_logger_level')
    log.setLevel(logging.INFO)
    log.debug('This will not output.')
    with logger_level(log, logging.DEBUG):
        log.debug('This will output.')
        log.info('This will output.')
    log.info('This will output.')
    log.debug('This will not output.')

# Generated at 2022-06-21 22:00:05.121541
# Unit test for function configure
def test_configure():
    capture_out = StringIO()
    old_stdout = sys.stdout
    sys.stdout = capture_out

    try:
        configure(DEFAULT_CONFIG)
        log = get_logger()
        log.info("Test logging config")
    finally:
        sys.stdout = old_stdout

    captured_output = capture_out.getvalue().strip()
    assert("%(asctime)s" in captured_output)
    assert("%(name)s" in captured_output)
    assert("%(levelname)s" in captured_output)
    assert("%(message)s" in captured_output)


# Generated at 2022-06-21 22:00:14.470787
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')

    log = get_logger('test2')
    log.info('test2')

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 22:00:19.198827
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == sys.version_info[0] == 2
    assert _PyInfo.PY3 == sys.version_info[0] == 3
    if _PyInfo.PY2:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    else:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes


# Generated at 2022-06-21 22:00:24.282780
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.debug('This is a debug message')
    log.info('This is an info message')
    log.warning('This is a warning message')
    log.error('This is an error message')
    log.critical('This is a critical message')



# Generated at 2022-06-21 22:00:31.572527
# Unit test for function get_config

# Generated at 2022-06-21 22:00:35.358729
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    if _PyInfo.PY2:
        assert not _PyInfo.PY3
    else:
        assert not _PyInfo.PY2

# Generated at 2022-06-21 22:00:45.801485
# Unit test for function get_config
def test_get_config():
    """ Testing the function get_config
    """
    #Test JSON

# Generated at 2022-06-21 22:00:54.258927
# Unit test for function configure
def test_configure():
    import logging
    import tempfile
    import os
    from contextlib import contextmanager

    @contextmanager
    def temp_file(contents):
        fd, filename = tempfile.mkstemp()
        os.write(fd, contents.encode('utf-8'))
        os.close(fd)
        try:
            yield filename
        finally:
            os.remove(filename)

    with temp_file(
            "logging_config: 'json'\nTIME_ZONE: 'UTC'\n"
            "mylogger:\n"
            "  awesome: true\n"
            "  format: '%(levelname)s|%(message)s'\n"
    ) as filename:
        os.environ['LOGGING_CONFIG'] = filename
        configure()

        # Make a

# Generated at 2022-06-21 22:00:57.804210
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    try:
        assert _PyInfo.PY2 == True
        assert _PyInfo.PY3 == False
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
        print('test _PyInfo passed')
    except AssertionError:
        print('test _PyInfo failed')



# Generated at 2022-06-21 22:01:05.058838
# Unit test for function logger_level

# Generated at 2022-06-21 22:01:09.009541
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger('test_getLogger')
    logger.info('test')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:01:24.009902
# Unit test for function getLogger
def test_getLogger():
    from os import environ
    from os import path
    from linecache import getline
    from tempfile import TemporaryFile
    from time import sleep
    from pprint import pprint

    cfg_file = path.join(path.dirname(__file__), 'test_config.yaml')
    environ['LOGGING'] = cfg_file
    cfg = get_config()
    configure(cfg, env_var=None)

    log = getLogger()
    log.debug('Unit Test Message: Debug Start')
    log.info('Unit Test Message: Info')
    log.warning('Unit Test Message: Warning')
    log.error('Unit Test Message: Error')
    log.critical('Unit Test Message: Critical')

    # Modify log file name

# Generated at 2022-06-21 22:01:26.799918
# Unit test for function configure
def test_configure():
    getLogger("test_configure").info("Testing")
    assert True == True

# Generated at 2022-06-21 22:01:31.596279
# Unit test for function getLogger
def test_getLogger():
    """
    Unit test cases for function getLogger.
    """
    logger = getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.info("info")
    logger.debug("debug")


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 22:01:39.563458
# Unit test for constructor of class _PyInfo
def test__PyInfo():

    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

    assert _PyInfo.binary_type == str
    assert isinstance('', _PyInfo.binary_type)
    assert not isinstance(b'', _PyInfo.binary_type)

    assert _PyInfo.text_type == unicode
    assert isinstance(u'', _PyInfo.text_type)
    assert not isinstance('', _PyInfo.text_type)

    assert isinstance('', _PyInfo.string_types)
    assert isinstance(u'', _PyInfo.string_types)
    assert not isinstance(b'', _PyInfo.string_types)



# Generated at 2022-06-21 22:01:51.343411
# Unit test for function get_config
def test_get_config():
    # Get config from a bare string.
    cfg = '{"formatters": {"colored": {"format": "%(log_color)s%(levelname)s %(message)s", "()": "colorlog.ColoredFormatter"}}}'
    assert get_config(cfg)['formatters']['colored']['format'] == '%(log_color)s%(levelname)s %(message)s'

    # Get config from a json string.
    cfg = '{"formatters": {"colored": {"format": "%(log_color)s%(levelname)s %(message)s", "()": "colorlog.ColoredFormatter"}}}'

# Generated at 2022-06-21 22:01:54.737689
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

    log = getLogger('test2')
    log.info('test2')

# Generated at 2022-06-21 22:01:57.987452
# Unit test for function get_config
def test_get_config():
    cfg = get_config(None, None, DEFAULT_CONFIG)
    assert cfg == DEFAULT_CONFIG


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:02:01.335330
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    initial = log.level
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
        log.debug("This is a debug msg.")
    assert log.level == initial



# Generated at 2022-06-21 22:02:09.583909
# Unit test for function configure
def test_configure():
    configure()
    print(logging.getLevelName(logging.getLogger().getEffectiveLevel()))
    configure(config="""
        version: 1
        formatters:
                simple:
                        format: '%(asctime)s %(name)-12s %(levelname)-8s %(message)s'
                        datefmt: '%m-%d %H:%M'
        handlers:
                console:
                        class: logging.StreamHandler
                        level: DEBUG
                        formatter: simple
                        stream: ext://sys.stdout
        root:
                level: INFO
                handlers: [console]
    """)
    print(logging.getLevelName(logging.getLogger().getEffectiveLevel()))



# Generated at 2022-06-21 22:02:13.244269
# Unit test for function logger_level
def test_logger_level():
    """
    >>> import logging
    >>> logger = logging.getLogger('test')
    >>> logger.setLevel(logging.INFO)
    >>> logger.error("Should not show")
    >>> with logger_level(logger, logging.ERROR):
    ...    logger.error("Should show")
    >>> logger.error("Should not show")
    """



# Generated at 2022-06-21 22:02:24.506762
# Unit test for function logger_level
def test_logger_level():

    from six import StringIO

    f = StringIO()
    log = get_logger(__name__)
    log.addHandler(logging.StreamHandler(f))

    with logger_level(log, logging.INFO):
        log.info("foo")
        assert "foo" in f.getvalue()
        log.debug("bar")
        assert "bar" not in f.getvalue()


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 22:02:25.845253
# Unit test for function getLogger
def test_getLogger():

    logger = get_logger()

    assert logger.__module__ == '__main__'


# Generated at 2022-06-21 22:02:27.524044
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    #    configure()
    logger.info('test')



# Generated at 2022-06-21 22:02:34.905540
# Unit test for function get_config
def test_get_config():
    if not _PyInfo.PY2:
        from unittest import TestCase

        class T(TestCase):
            def test_get_config(self):
                self.assertEqual(get_config(default={'test': 1}), {'test': 1})
                self.assertEqual(get_config(config='{"test": 1}'), {'test': 1})
        T().test_get_config()


if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-21 22:02:38.161320
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    # if default is not used, the Level is not set to DEBUG and warning is not printed
    log.warning('test')
    log.error('test')
    getLogger(__name__).error('test')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:02:39.862445
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert logger


# Generated at 2022-06-21 22:02:40.475282
# Unit test for function configure
def test_configure():
    configure()

# Generated at 2022-06-21 22:02:45.447766
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert not _PyInfo.PY3
    assert isinstance('hi', _PyInfo.string_types)
    assert isinstance(b'hi', _PyInfo.binary_type)
    assert _PyInfo.text_type == unicode


# Generated at 2022-06-21 22:02:47.571740
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert _PyInfo.PY2 or _PyInfo.PY3


# Generated at 2022-06-21 22:02:58.255114
# Unit test for function get_config
def test_get_config():
    """
    Get Config

    >>> import json
    >>> cfg = dict(version=1, formatters=dict(json=dict(format='%(message)s')))
    >>> assert cfg == get_config(given=cfg)
    >>> assert cfg == get_config(given=json.dumps(cfg))
    >>> import yaml
    >>> assert cfg == get_config(given=yaml.dump(cfg))

    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:03:18.867174
# Unit test for function getLogger
def test_getLogger():
    # import doctest
    # doctest.run_docstring_examples(getLogger, globals(), name='logging')
    # Unit test for function configure
    def test_configure():
        # import doctest
        # doctest.run_docstring_examples(configure, globals(), name='logging')
        configure()
        test_logger = get_logger()
        test_logger.info("test_getLogger_info_message")
        test_logger.debug("test_getLogger_debug_message")
        test_logger.warning("test_getLogger_warning_message")
        test_logger.error("test_getLogger_error_message")
        test_logger.critical("test_getLogger_critical_message")

    test_configure()


#

# Generated at 2022-06-21 22:03:27.437594
# Unit test for function configure
def test_configure():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

# Generated at 2022-06-21 22:03:31.077605
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        logger.info("This message should not be displayed")

    logger.info("This message should be displayed")


# Generated at 2022-06-21 22:03:36.664162
# Unit test for function get_config
def test_get_config():
    config = get_config(env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config is not None
    assert config['formatters'] is not None
    assert config['handlers'] is not None
    assert config['root'] is not None


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:03:42.452096
# Unit test for function configure
def test_configure():
    # test case 1
    configure()
    log = get_logger(__name__)
    log.info('test')

    # test case 2

# Generated at 2022-06-21 22:03:44.812673
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert log.isEnabledFor(logging.DEBUG)
    with logger_level(log, logging.WARNING):
        assert not log.isEnabledFor(logging.DEBUG)
    assert log.isEnabledFor(logging.DEBUG)


# Generated at 2022-06-21 22:03:45.814567
# Unit test for function configure
def test_configure():
    pass

# Generated at 2022-06-21 22:03:48.281318
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info("test_getLogger")
    assert isinstance(logger, logging.Logger)



# Generated at 2022-06-21 22:03:58.457679
# Unit test for function logger_level
def test_logger_level():
    import unittest
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    class TestLoggerLevel(unittest.TestCase):
        def test_logger_level(self):
            with logger_level(logger, logging.WARN):
                logger.info('I am silenced.')
                logger.warn('I am not.')
    unittest.main()

# todo: decorators to debug functions
# todo: decorator to add log messages to exceptions. if given exception is
# not raised, log the message with an error level.
# todo: decorator to use only when log level is debug or higher
# todo: in-code configuration i.e. %(name)s -> %(name)d etc

# Generated at 2022-06-21 22:04:00.450615
# Unit test for function getLogger
def test_getLogger():
    configure()
    log = get_logger('test')
    log.info('test')
    log.error('test')

# Generated at 2022-06-21 22:04:21.049312
# Unit test for function configure

# Generated at 2022-06-21 22:04:28.459588
# Unit test for function configure
def test_configure():
    import json
    import logging
    from logutils import configure


# Generated at 2022-06-21 22:04:29.611707
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    assert log.name == __name__


# Generated at 2022-06-21 22:04:38.977037
# Unit test for function get_config
def test_get_config():
    from io import StringIO
    from logging import basicConfig, ERROR, DEBUG

    config = {'handlers': {'console': {'level': 'DEBUG'}}, 'loggers': {'test': {'level': 'DEBUG', 'handlers': ['console']}}, 'root': {'level': 'DEBUG', 'handlers': ['console']}}

    # env_var
    import os
    os.environ['LOGGING'] = str(config)
    basicConfig()

    # config

    # default
    basicConfig(dict(DEFAULT_CONFIG))

    # pytest -s
    pass


# Generated at 2022-06-21 22:04:42.181285
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG

    assert get_config(config={'a': 2}) == {'a': 2}

    assert get_config(config=json.dumps({'a': 2})) == {'a': 2}

# Generated at 2022-06-21 22:04:47.929004
# Unit test for function get_config
def test_get_config():
    from os import environ
    import tempfile, os

    print('Testing get_config()')
    with tempfile.NamedTemporaryFile() as f:
        yaml_config = """\
        default:
            loggers:
                test_class:
                    level: info
        """
        with open(f.name, 'w') as f:
            f.write(yaml_config)
            f.flush()
        environ['LOGGING_CONFIG'] = f.name

        config = get_config(env_var='LOGGING_CONFIG')
        print(config)
        assert config['loggers']['test_class']['level'] == 'info'

        config = get_config(env_var='LOGGING_CONFIG', default='flibble')
        print(config)
        assert config

# Generated at 2022-06-21 22:04:51.726518
# Unit test for function logger_level
def test_logger_level():
    log = get_logger("test")

    with logger_level(log, logging.DEBUG):
        log.info("Shouldn't print this")
        log.debug("Should print this")
    log.debug("Shouldn't print this")


# Generated at 2022-06-21 22:05:00.758650
# Unit test for function configure
def test_configure():
    import logging
    import tempfile
    from contextlib import contextmanager
    from os import remove, environ
    from os.path import join, exists
    from shutil import copyfile

    # Setup
    @contextmanager
    def tempdir():
        d = tempfile.mkdtemp()
        try:
            yield d
        finally:
            remove(d)

    cfgpath = join(tempfile.gettempdir(), 'logging.yml')
    copyfile('tests/cfg/logging.yml', cfgpath)
    environ['LOGGING'] = cfgpath

    # Testing
    assert not exists(cfgpath)
    configure()
    assert exists(cfgpath)
    log = logging.getLogger(__name__)
    log.debug("Testing")

# Generated at 2022-06-21 22:05:02.362925
# Unit test for function configure
def test_configure():
    """
    Tests if configure() can be called without an error
    """
    configure()


# Generated at 2022-06-21 22:05:05.112012
# Unit test for function configure
def test_configure():
    try:
        configure()
        log = get_logger()
        log.info('test')
    except Exception as e:
        print('configure failed: ', e)
        return False
    return True


# Generated at 2022-06-21 22:05:39.334304
# Unit test for function get_config
def test_get_config():
    from os import environ, pathsep
    import sys

    logger = getLogger(__name__)

    current_config = logging.getLogger().manager.loggerDict

    # test with config dictionary

# Generated at 2022-06-21 22:05:42.224568
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is False and _PyInfo.PY3 is True
    assert _PyInfo.string_types == (str,)
    assert _PyInfo.text_type == str
    assert _PyInfo.binary_type == bytes



# Generated at 2022-06-21 22:05:45.540721
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance('abc', _PyInfo.string_types)
    assert isinstance(b'abc', _PyInfo.binary_type)
    assert isinstance(u'abc', _PyInfo.text_type)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:05:56.004054
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3, 'No PY2 neither PY3'
    if _PyInfo.PY2:
        assert isinstance('', _PyInfo.string_types)
        assert isinstance(u'', _PyInfo.string_types)
        assert isinstance(u'', _PyInfo.text_type)
        assert isinstance('', _PyInfo.binary_type)
    if _PyInfo.PY3:
        assert isinstance('', _PyInfo.string_types)
        assert not isinstance(u'', _PyInfo.string_types)
        assert isinstance('', _PyInfo.text_type)
        assert isinstance(b'', _PyInfo.binary_type)



# Generated at 2022-06-21 22:06:05.005848
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test invalid logging config
    def test_invalid_config():
        get_config("test")

    assert_raises(ValueError, test_invalid_config)

    #Test simple logging config
    expected_config = {'version': 1, 'disable_existing_loggers': False}
    assert_equal(get_config(default=expected_config), expected_config)

    # Test json logging config
    json_config = json.dumps(expected_config)
    assert_equal(get_config(json_config), expected_config)

    # Test yaml config
    yaml_config = yaml.dump(expected_config)
    assert_equal(get_config(yaml_config), expected_config)



# Generated at 2022-06-21 22:06:11.899389
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    with logger_level(logger, logging.INFO):
        logger.debug('a')
        logger.info('b')

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:06:20.175583
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py_info = _PyInfo()
    assert py_info.PY2 == sys.version_info[0] == 2
    assert py_info.PY3 == sys.version_info[0] == 3
    if sys.version_info[0] == 2:
        assert py_info.string_types == (basestring,)
        assert py_info.text_type == unicode
        assert py_info.binary_type == str
    else:
        assert py_info.string_types == (str,)
        assert py_info.text_type == str
        assert py_info.binary_type == bytes


# Generated at 2022-06-21 22:06:25.884539
# Unit test for function logger_level
def test_logger_level():
    # Logger with level < debug
    logger = getLogger()
    logger.setLevel(logging.INFO)

    # Verify that logger level is set to debug in context block
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    # Verify that logger level is reset to its initial level after context block
    assert logger.level == logging.INFO


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:06:27.594564
# Unit test for function configure
def test_configure():
    cfg = configure()
    assert cfg is not None



# Generated at 2022-06-21 22:06:36.498435
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # _PyInfo.PY2
    assert _PyInfo.PY2 is (sys.version_info[0] == 2)

    # _PyInfo.PY3
    assert _PyInfo.PY3 is (sys.version_info[0] == 3)

    # _PyInfo.string_types
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.string_types == (str,)

    # _PyInfo.text_type
    assert _PyInfo.text_type == unicode
    assert _PyInfo.text_type == str

    # _PyInfo.binary_type
    assert _PyInfo.binary_type == str
    assert _PyInfo.binary_type == bytes


if __name__ == "__main__":
    test__PyInfo()

# Generated at 2022-06-21 22:07:07.971974
# Unit test for function getLogger
def test_getLogger():
    print(sys.getdefaultencoding())
    if _PyInfo.PY2:
        assert sys.getdefaultencoding() == 'ascii'
        # log = get_logger(u"中文")
        # log.info(u"中文")
    else:
        assert sys.getdefaultencoding() == 'utf-8'
        # log = get_logger("中文")
        # log.info("中文")


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:07:14.373181
# Unit test for function get_config
def test_get_config():
    a = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert(a == DEFAULT_CONFIG)

    a = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    assert(a == DEFAULT_CONFIG)

    a = get_config(config=json.dumps(DEFAULT_CONFIG), env_var=None, default=None)
    assert(a == DEFAULT_CONFIG)

    a = get_config(config=yaml.dump(DEFAULT_CONFIG, default_flow_style=False), env_var=None, default=None)
    assert(a == DEFAULT_CONFIG)


if __name__ == '__main__':
    import pytest
    import mock


# Generated at 2022-06-21 22:07:17.342613
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (2 == sys.version_info[0])
    assert _PyInfo.PY3 == (3 == sys.version_info[0])
