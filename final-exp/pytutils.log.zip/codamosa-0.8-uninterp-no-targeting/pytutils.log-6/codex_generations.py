

# Generated at 2022-06-21 21:57:20.377454
# Unit test for function configure
def test_configure():
    """Test function configure"""

    try:
        configure()
    except Exception as exc:
        raise exc



# Generated at 2022-06-21 21:57:32.903277
# Unit test for function get_config

# Generated at 2022-06-21 21:57:40.793871
# Unit test for function configure
def test_configure():
    import logging
    import os
    import json

    with open('logging.json') as f:
        config = json.load(f)
    t = os.environ.get('LOGGING')
    os.environ['LOGGING'] = json.dumps(config)

    try:
        configure()
        logging.info("logging configure")
    except:
        assert False
    finally:
        os.environ['LOGGING'] = t



# Generated at 2022-06-21 21:57:45.018208
# Unit test for function configure
def test_configure():
    try:
        configure(default=json.dumps(DEFAULT_CONFIG))
    except ValueError:
        # TODO: A better unit test for this function
        return
    assert False

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 21:57:51.026656
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    try:
        with logger_level(logger, logging.ERROR):
            logger.error('ERROR')
            logger.warn('WARN')
            logger.info('INFO')
            logger.debug('DEBUG')
    except Exception:
        logger.exception('Exception')

    try:
        with logger_level(logger, logging.WARN):
            logger.error('ERROR')
            logger.warn('WARN')
            logger.info('INFO')
            logger.debug('DEBUG')
    except Exception:
        logger.exception('Exception')

# Generated at 2022-06-21 21:57:58.807031
# Unit test for function get_config
def test_get_config():
    assert get_config(config='{"a":1}') == {
        'a': 1
    }
    assert get_config(config='{"a":1}', default={'b':2}) == {
        'a': 1
    }
    assert get_config(config='{"a":1}', env_var='', default={'b':2}) == {
        'a': 1
    }
    assert get_config(config='{"a":1}', env_var=None, default={'b':2}) == {
        'a': 1
    }
    assert get_config(config='{"a":1}', env_var='b', default={'b':2}) == {
        'a': 1
    }

# Generated at 2022-06-21 21:58:02.948881
# Unit test for function configure
def test_configure():
    """
    >> log = logging.getLogger(__name__)
    >> configure()
    >> log.info('test')
    """
    log = logging.getLogger(__name__)
    configure()
    log.info('test')



# Generated at 2022-06-21 21:58:04.732729
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test_getLogger')
    logger.info('test_getLogger')


# Generated at 2022-06-21 21:58:07.088077
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert isinstance(_PyInfo.text_type('str'), _PyInfo.string_types)

# Generated at 2022-06-21 21:58:09.872897
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.INFO):
        logger.debug("this should not be seen")
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG
    logger.debug("this should be seen")



# Generated at 2022-06-21 21:58:22.816344
# Unit test for function get_config
def test_get_config():
    # Testing empty config
    assert get_config() is None

    # Testing bare config
    assert get_config(config={'a': 'b'}) == {'a': 'b'}

    # Testing json config
    assert get_config(config='{"a": "b"}') == {'a': 'b'}

    # Testing yaml config
    import yaml
    assert get_config(config=yaml.dump({'a': 'b'})) == {'a': 'b'}


if __name__ == '__main__':
    import sys
    import nose

    args = sys.argv[1:]
    nose.main(argv=args)

# Generated at 2022-06-21 21:58:26.241347
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)


# Generated at 2022-06-21 21:58:31.227598
# Unit test for function get_config
def test_get_config():
    from tempfile import NamedTemporaryFile
    with NamedTemporaryFile() as f:
        _sample_cfg_contents = '{"a": 1, "b": 2, "c": 3}'
        f.write(_sample_cfg_contents.encode('u8'))
        f.flush()
        assert get_config(default=f.name) == json.loads(_sample_cfg_contents)

# Generated at 2022-06-21 21:58:33.125563
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')
    assert isinstance(log, logging.Logger)
    assert log.name == __name__

# Generated at 2022-06-21 21:58:36.914192
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log.info('test')
    log.warning('test')
    log.error('test')


# Generated at 2022-06-21 21:58:47.522698
# Unit test for function get_config

# Generated at 2022-06-21 21:58:49.117247
# Unit test for function get_config
def test_get_config():
    given = '{"version":1}'
    config = get_config(given)
    assert config == json.loads(given)

# Generated at 2022-06-21 21:58:59.111301
# Unit test for function configure
def test_configure():
    import io
    import sys
    import logging

    class FakeStdout(io.StringIO):
        def __init__(self, *args, **kwargs):
            self.closed = False
            self.encoding = 'UTF-8'
            super(FakeStdout, self).__init__(*args, **kwargs)

        def close(self):
            self.closed = True

    class FakeStderr(io.StringIO):
        def __init__(self, *args, **kwargs):
            self.closed = False
            self.encoding = 'UTF-8'
            super(FakeStderr, self).__init__(*args, **kwargs)

        def close(self):
            self.closed = True

    stdout = sys.__stdout__
    stdout_closed = stdout.closed

# Generated at 2022-06-21 21:59:03.766223
# Unit test for function getLogger
def test_getLogger():
    log_name = __name__
    log = get_logger(log_name)
    assert log.name == log_name

    log = get_logger(__name__)
    assert log.name == __name__

    log = get_logger()
    assert log.name == __name__

# Generated at 2022-06-21 21:59:15.105600
# Unit test for function get_config
def test_get_config():
    from pytest import raises
    from json import loads

    with raises(ValueError):
        get_config()

    cfg = get_config(default={})
    assert cfg == {}

    cfg = get_config(env_var='PYLOG_NOEXIST')
    assert cfg is None

    cfg = get_config(config={})
    assert cfg == {}

    cfg = get_config(config='{}')
    assert cfg == {}

    cfg = get_config(default=DEFAULT_CONFIG)
    assert cfg == DEFAULT_CONFIG

    cfg = get_config(env_var='PYLOG_CONFIG', default=DEFAULT_CONFIG)
    assert cfg == DEFAULT_CONFIG

    cfg = get_config(config=DEFAULT_CONFIG)
   

# Generated at 2022-06-21 21:59:31.254997
# Unit test for function configure
def test_configure():

    import os
    import json
    import random
    import string

    log = logging.getLogger(__name__)

    def randomword(length):
       return ''.join(random.choice(string.lowercase) for i in range(length))

    fmt = '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: ' \
          '%(message)s @%(funcName)s:%(lineno)d #%(levelname)s'

    # Test with empty config
    try:
        configure({})
        assert False
    except ValueError:
        pass

    # Test with config.json with incorrect logger

# Generated at 2022-06-21 21:59:41.204157
# Unit test for function get_config
def test_get_config():
    assert get_config(
        default='{"version": 1}') == {'version': 1}

    assert get_config(
        default='''
            version: 1
        ''') == {'version': 1}

    assert get_config(
        env_var='LOGGING',
        default='{"version": 1}') == {'version': 1}

    assert get_config(
        env_var='LOGGING',
        default='''
            version: 1
        ''') == {'version': 1}

    assert get_config(
        os.environ.copy(),
        env_var='LOGGING',
        default='{"version": 1}') == {'version': 1}


# Generated at 2022-06-21 21:59:47.577454
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2, "PY2 not defined"
    assert _PyInfo.PY3, "PY3 not defined"
    assert not (_PyInfo.PY2 and _PyInfo.PY3), "PY2 and PY3 both defined"


if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-21 21:59:54.345597
# Unit test for function get_config
def test_get_config():
    # test json
    json_config = '{"version":1,"disable_existing_loggers":false, "formatters":{"simple":{"format":"%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s","datefmt":"%Y-%m-%d %H:%M:%S"}}}'
    cfg = get_config(json_config)

# Generated at 2022-06-21 22:00:04.451870
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    python_info = _PyInfo()
    assert python_info.PY2 or not python_info.PY2
    assert python_info.PY3 or not python_info.PY3
    if _PyInfo.PY2:
        assert isinstance('', _PyInfo.string_types)
        assert isinstance(u'', _PyInfo.string_types)
    else:
        assert isinstance(b'', _PyInfo.string_types)
    if _PyInfo.PY2:
        assert isinstance(b'', _PyInfo.binary_type)
        assert isinstance('', _PyInfo.text_type)
    else:
        assert isinstance(b'', _PyInfo.text_type)
        assert isinstance('', _PyInfo.binary_type)


# Generated at 2022-06-21 22:00:08.539220
# Unit test for function logger_level
def test_logger_level():
    import logging
    import pandas.util.testing as tm

    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.ERROR):
        logger.info("Test")
        tm.assert_is_none(logging.getLogger(__name__).handlers[0].stream.getvalue())



# Generated at 2022-06-21 22:00:15.245337
# Unit test for function configure
def test_configure():
    from tempfile import NamedTemporaryFile


# Generated at 2022-06-21 22:00:16.806858
# Unit test for function configure
def test_configure():
    configure()
    logger = logging.getLogger(__name__)
    logger.debug('test configure')



# Generated at 2022-06-21 22:00:27.014812
# Unit test for function getLogger
def test_getLogger():
    import os, tempfile
    from cStringIO import StringIO

    log = get_logger()

    fd, path = tempfile.mkstemp(suffix='.cxlog')
    os.close(fd)
    try:
        log.level = logging.INFO
        with open(path, "w") as fp:
            log.addHandler(logging.StreamHandler(fp))
            log.info("Testing getLogger")
        with open(path) as fp:
            assert fp.read().strip().endswith("INFO: Testing getLogger")
    finally:
        os.unlink(path)


# Generated at 2022-06-21 22:00:33.153099
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('simple')
    with logger_level(logger, logging.INFO):
        for level in [logging.NOTSET, logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR, logging.CRITICAL]:
            logger.log(level, "testing log level %d" % level)



# Generated at 2022-06-21 22:00:39.608440
# Unit test for function configure
def test_configure():
    configure()
    get_logger(__name__).info('test')
    get_logger(__name__).info('test')


# Generated at 2022-06-21 22:00:43.959786
# Unit test for function get_config
def test_get_config():
    assert get_config(env_var="LOGGING") == DEFAULT_CONFIG
    assert get_config(env_var='logging') == DEFAULT_CONFIG
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=ENV_VAR) == DEFAULT_CONFIG



# Generated at 2022-06-21 22:00:48.126890
# Unit test for function configure
def test_configure():
    import logic
    import sys
    import io

    out = io.StringIO()
    sys.stdout = out

    configure()
    log = logging.getLogger(logic.__name__)
    log.info('Test')
    print('Please check the above "Test" message')

# Generated at 2022-06-21 22:00:52.036009
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    configure()
    test = getLogger(__name__)
    msg = 'test logger_level'
    with logger_level(test, logging.ERROR):
        log.debug(msg)
        log.error(msg)
        log.info(msg)
    log.info(msg)

# Generated at 2022-06-21 22:00:53.873136
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.PY2 != _PyInfo.PY3



# Generated at 2022-06-21 22:01:03.485761
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test json format
    json_config = get_config(default=None, env_var=None, given=json.dumps(DEFAULT_CONFIG))
    assert not (json_config is None)
    assert json_config == DEFAULT_CONFIG

    # Test yaml format
    yaml_config = get_config(default=None, env_var=None, given=yaml.dump(DEFAULT_CONFIG))
    assert not (yaml_config is None)
    assert yaml_config == DEFAULT_CONFIG

    # Test error cases
    try:
        get_config(default=None, env_var=None, given={})
        assert False
    except ValueError:
        pass

# Generated at 2022-06-21 22:01:07.378384
# Unit test for function configure
def test_configure():
    """
    >>> configure()
    >>> log = logging.getLogger(__name__)
    >>> log.info('test')
    """


# Generated at 2022-06-21 22:01:11.442996
# Unit test for function configure

# Generated at 2022-06-21 22:01:21.436147
# Unit test for function get_config
def test_get_config():
    """
    >>> test_get_config()
    """

    # Test the function with invalid data
    try:
        get_config()
        assert False, "Should have failed"
    except ValueError:
        pass

    # Test the function using data as an object
    data = "This is a test"
    try:
        get_config(data)
        assert False, "Should have failed"
    except ValueError:
        pass

    # Test the function using data as a yaml object
    data = "Some text: blah blah blah"
    try:
        get_config(data)
        assert False, "Should have failed"
    except ValueError:
        pass

    # Test the function using data as a valid yaml
    data = """
        name:
          - c1
    """

# Generated at 2022-06-21 22:01:23.111853
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    p = _PyInfo()
    assert p.PY2 or p.PY3
    assert p.string_types
    assert p.text_type
    assert p.binary_type



# Generated at 2022-06-21 22:01:37.672167
# Unit test for function get_config
def test_get_config():
    json_str = '{"version": 1, "disable_existing_loggers": false, "formatters": {"simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": 30}}, "root": {"handlers": ["console"], "level": 30}}'
    cfg = get_config(config=json_str)
    assert cfg['version'] == 1

# Generated at 2022-06-21 22:01:49.883708
# Unit test for function get_config
def test_get_config():
    # case 1: list as config
    config_list = ['a', 'b', 'c']
    assert get_config(config_list) == config_list

    # case 2: dict as config
    config_dict = {
        'a' : 'b',
        'c' : 'd'
    }
    assert get_config(config_dict) == config_dict

    # case 3: json string as config
    config_json = '{"a" : "b", "c" : "d"}'
    assert get_config(config_json) == config_dict

    # case 4: yaml string as config
    config_yaml = 'a: b\nc: d'
    assert get_config(config_yaml) == config_dict

    # case 5: no config given

# Generated at 2022-06-21 22:01:59.915151
# Unit test for function configure
def test_configure():
    logger = getLogger()
    logger.info("test")
    # using configure to customize log message format
    configure(config=dict(version = 1, formatters = {
        'f': {
            'format': '%(asctime)s %(name)-12s %(levelname)-8s %(message)s'
        }
    },
        handlers = {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'f'
            }
        },
        root = {
            'handlers': ['console'],
            'level': 'INFO'
        }
    ))
    logger.info("test")

# Generated at 2022-06-21 22:02:03.005531
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('info')
    log.warn('warn')
    log.error('error')
    log.debug('debug')


# Generated at 2022-06-21 22:02:04.157389
# Unit test for function configure
def test_configure():
    log = configure()
    log = logging.getLogger(__name__)
    log.info('test')

# Generated at 2022-06-21 22:02:09.442103
# Unit test for constructor of class _PyInfo
def test__PyInfo():
  assert _PyInfo.PY3

  assert _PyInfo.string_types == (str,)
  assert _PyInfo.text_type == str
  assert _PyInfo.binary_type == bytes

# Unit test: get_logger

# Generated at 2022-06-21 22:02:10.980728
# Unit test for function configure
def test_configure():
    """
    >>> configure()
    >>> log = logging.getLogger(__name__)
    >>> log.info('test')
    """
    pass

# Generated at 2022-06-21 22:02:17.526192
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str

# Generated at 2022-06-21 22:02:27.592562
# Unit test for function configure

# Generated at 2022-06-21 22:02:37.741863
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config(default=DEFAULT_CONFIG)

    config = {'disable_existing_loggers': False}
    assert config == get_config(config)

    config = json.dumps(config)
    assert config == get_config(config)

    config = yaml.dump(config)
    assert config == get_config(config)

    os.environ['LOGGING'] = config
    assert config == get_config(env_var='LOGGING')

    os.environ['LOGGING2'] = config
    assert config == get_config(env_var='LOGGING2')

    config = 'invalid'
    try:
        get_config(config)
    except ValueError:
        assert True
    else:
        raise Exception('invalid config not caught')

# Generated at 2022-06-21 22:02:47.902199
# Unit test for function getLogger
def test_getLogger():
    log = get_logger('test')
    log.info('test')



# Generated at 2022-06-21 22:02:53.457989
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.string_types
    assert _PyInfo.text_type
    assert _PyInfo.binary_type



# Generated at 2022-06-21 22:03:04.200849
# Unit test for function get_config
def test_get_config():
    # check for given
    config = {"version": 1, "disable_existing_loggers": False}
    assert config == get_config(given=config)

    # check for given as string
    config = {"version": 1, "disable_existing_loggers": False}
    json_string = json.dumps(config)
    assert config == get_config(given=json_string)

    # check for given as json string
    config = {"version": 1, "disable_existing_loggers": False}
    json_string = json.dumps(config)
    assert config == get_config(given=json_string)

    # check for given as yaml string
    config = {"version": 1, "disable_existing_loggers": False}
    yaml_string = yaml.dump(config)
    assert config == get_config

# Generated at 2022-06-21 22:03:08.628523
# Unit test for function configure
def test_configure():
    """Run the configure function to see if it throws any exceptions.
       If it doesn't an exception is thrown.
    """
    import subprocess
    try:
        subprocess.check_call(["python", "-m", "unit_test.test_logging_config" ])
    except subprocess.CalledProcessError as e:
        raise e

if __name__ == '__main__':
    logger = get_logger()
    logger.info("Hello World!")
    logger.info("Hello World!2")

# Generated at 2022-06-21 22:03:12.862712
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test_getLogger')
    assert logger is not None
    assert logger.name == 'test_getLogger'




# Generated at 2022-06-21 22:03:15.532369
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()

    assert isinstance(log, logging.Logger)
    assert log.name == __package__
    assert __name__ != __package__



# Generated at 2022-06-21 22:03:22.294680
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    logger.setLevel(logging.ERROR)
    logger.info("This should not appear")
    logger.error("This should appear")

    with logger_level(logger, logging.WARNING):
        logger.setLevel(logging.WARNING)
        logger.warning("This should appear")
        logger.info("This should not appear")

    logger.error("This should appear")
    logger.info("This should not appear")

# Generated at 2022-06-21 22:03:23.148135
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-21 22:03:24.499952
# Unit test for function getLogger
def test_getLogger():
    with logger_level(logger.Logger, logger.DEBUG):
        getLogger().debug("Test")

# Generated at 2022-06-21 22:03:36.821305
# Unit test for function configure

# Generated at 2022-06-21 22:03:50.719301
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger('dd')
    config = get_config()
    logger.info('dd')
    logger.error('dd')

    # logger = getLogger('dd')
    # logger.warn('dd')



# Generated at 2022-06-21 22:03:59.623103
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('')
    with logger_level(logger, logging.DEBUG):
        # everything logged
        logger.debug('This is debug message.')
        logger.info('This is info message.')
        logger.warning('This is warning message.')
    with logger_level(logger, logging.WARNING):
        # only warning message logged
        logger.debug('This is debug message.')
        logger.info('This is info message.')
        logger.warning('This is warning message.')
    # only warning message logged
    logger.debug('This is debug message.')
    logger.info('This is info message.')
    logger.warning('This is warning message.')

# Generated at 2022-06-21 22:04:04.972494
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert not ( _PyInfo.PY2 and _PyInfo.PY3 )


# Generated at 2022-06-21 22:04:10.878229
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert isinstance(_PyInfo.string_types, tuple)
    if _PyInfo.PY3:
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str



# Generated at 2022-06-21 22:04:17.768853
# Unit test for function configure
def test_configure():
    from io import StringIO
    import sys

    bak = sys.stderr
    sys.stderr = StringIO()
    try:
        configure()
        print('test')
        assert 'test' in sys.stderr.getvalue()
        configure()
        print('test2')
        assert 'test2' in sys.stderr.getvalue()
    finally:
        sys.stderr = bak

    bak = sys.stdout
    sys.stdout = StringIO()
    try:
        configure()
        print('test')
        assert 'test' in sys.stdout.getvalue()
        configure()
        print('test2')
        assert 'test2' in sys.stdout.getvalue()
    finally:
        sys.stdout = bak



# Generated at 2022-06-21 22:04:22.134881
# Unit test for function get_config
def test_get_config():
    import json
    config = os.environ.get("LOGGING")
    assert config == get_config()
    assert get_config(config) == get_config()
    assert json.loads(config) == get_config(config)
    assert isinstance(get_config(config), dict)



# Generated at 2022-06-21 22:04:24.370085
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not (_PyInfo.PY2 and _PyInfo.PY3)


# Generated at 2022-06-21 22:04:26.009069
# Unit test for function getLogger
def test_getLogger():
    assert getLogger().name == __name__
    assert getLogger(__name__).name == __name__



# Generated at 2022-06-21 22:04:29.114198
# Unit test for function getLogger
def test_getLogger():
    import unittest

    class TestGetLogger(unittest.TestCase):
        def test_getLogger(self):
            pass

    unittest.main()


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:04:31.649461
# Unit test for function logger_level
def test_logger_level():
    # how to
    log = logging.getLogger(__name__)
    configure()
    with logger_level(log, logging.INFO):
        log.info('test')



# Generated at 2022-06-21 22:04:44.662072
# Unit test for function configure
def test_configure():
    logger = get_logger('test')
    logger.info('test')

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:04:49.083087
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('logging at debug level')
        log.info('logging at debug level')
    log.critical('back to normal')

# Generated at 2022-06-21 22:04:54.313735
# Unit test for function configure
def test_configure():
    logger = getLogger('test_configure')
    with logger_level(logger, logging.CRITICAL):
        assert logger.getEffectiveLevel() == logging.CRITICAL, logger.getEffectiveLevel()
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG, logger.getEffectiveLevel()



# Generated at 2022-06-21 22:05:03.563206
# Unit test for function get_config
def test_get_config():
    """Test for function get_config"""
    # test for json
    config = '{"version": 1, "formatters": {"simple": {"format": "%(asctime)s|%(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]:%(message)s@%(funcName)s:%(lineno)d#%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": 10}}, "loggers": {"test": {"handlers": ["console"], "level": 10, "propagate": false}}}'
    dict_config = get_config(config)
    assert dict_config

# Generated at 2022-06-21 22:05:08.672732
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    if _PyInfo.PY2:
        assert sys.version_info[0] == 2
        assert isinstance('', _PyInfo.string_types)
        assert isinstance(u'', _PyInfo.text_type)
        assert isinstance('', _PyInfo.binary_type)
    else:
        assert sys.version_info[0] == 3
        assert isinstance('', _PyInfo.string_types)
        assert isinstance('', _PyInfo.text_type)
        assert isinstance(b'', _PyInfo.binary_type)

# Generated at 2022-06-21 22:05:12.676392
# Unit test for function get_config
def test_get_config():
    assert(get_config(env_var='TEST_LOGGING',default=DEFAULT_CONFIG) == DEFAULT_CONFIG)

# Generated at 2022-06-21 22:05:23.390803
# Unit test for function get_config

# Generated at 2022-06-21 22:05:26.162466
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.binary_type is str or _PyInfo.binary_type is bytes
    assert _PyInfo.text_type is str or _PyInfo.text_type is unicode

# Generated at 2022-06-21 22:05:31.068418
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3, "Test Failed: neither PY2 nor PY3"
    assert not _PyInfo.PY2 or not _PyInfo.PY3, "Test Failed: PY2 and PY3"



# Generated at 2022-06-21 22:05:36.010564
# Unit test for function logger_level
def test_logger_level():
    """Unit test for function logger_level"""
    logger = get_logger()
    for level in (logging.INFO, logging.DEBUG):
        with logger_level(logger, level):
            logger.info('always')
            logger.debug('level %d', level)
    logger.info('never')


# Generated at 2022-06-21 22:06:07.570053
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()

    @contextmanager
    def is_logger_level(level):
        with logger_level(logger, level):
            yield logger.level

    with is_logger_level(logging.WARN) as new_level:
        assert new_level == logging.WARN
        assert logger.level == logging.WARN

    with is_logger_level(logging.INFO) as new_level:
        assert new_level == logging.INFO
        assert logger.level == logging.INFO

    with is_logger_level(logging.DEBUG) as new_level:
        assert new_level == logging.DEBUG
        assert logger.level == logging.DEBUG


if __name__ == '__main__':
    configure()
    log = get_logger()
    log.debug('Hello World')


# Generated at 2022-06-21 22:06:19.778719
# Unit test for function getLogger
def test_getLogger():
    import json
    import os
    import tempfile
    import traceback
    import unittest
    import logging

    # We expect the following logging config to be set

# Generated at 2022-06-21 22:06:27.446325
# Unit test for function get_config
def test_get_config():
    config_dict = {'version': 1, 'disable_existing_loggers': False, 'formatters': {'simple': {'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s', 'datefmt': '%Y-%m-%d %H:%M:%S'}}, 'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'simple', 'level': logging.DEBUG}}, 'root': {'handlers': ['console'], 'level': logging.DEBUG}, 'loggers': {'requests': {'level': logging.INFO}}}
    config

# Generated at 2022-06-21 22:06:35.406445
# Unit test for function get_config
def test_get_config():
    options = [
        ('{"version": 1}', {'version': 1}),
        ('{"version": 1}', {'version': 1}),
        ('version: 1\nroot: {level: DEBUG}\n', {'version': 1, 'root': {'level': logging.DEBUG}}),
        ('version=1\n', {'version': 1}),
        ('level=DEBUG\n', {'level': logging.DEBUG}),
    ]

    for data, expected in options:
        assert expected == get_config(data)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:06:46.182178
# Unit test for function configure
def test_configure():
    # Case 1: configure with json
    cfg = '{"formatters": {"simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": 10}}, "root": {"handlers": ["console"], "level": 10}, "loggers": {"requests.packages.urllib3.connectionpool": {"level": 20}}}'
    with get_logger() as log:
        logger_level

# Generated at 2022-06-21 22:06:50.594181
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    from nose.tools import eq_, ok_
    p = _PyInfo()
    ok_(p.PY2 ^ p.PY3) # ^: XOR
    ok_(isinstance("", p.string_types))
    ok_(isinstance("", p.text_type))
    ok_(isinstance(b"", p.binary_type))



# Generated at 2022-06-21 22:06:58.567100
# Unit test for function logger_level
def test_logger_level():
    # Set the level to DEBUG so the logger prints stuff out
    get_logger().debug('test')
    with logger_level(logger=get_logger(), level=logging.DEBUG):
        get_logger().info('test')
        get_logger().debug('test')
    get_logger().info('test')
    get_logger().debug('test')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 22:07:01.318508
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')

# Generated at 2022-06-21 22:07:05.311218
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info("my longger")

    log = getLogger("test")
    log.info('test')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-21 22:07:12.359352
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    assert log.getEffectiveLevel() == logging.DEBUG


if __name__ == '__main__':
    import doctest
    import sys

    # allow modules that are not on the default python path.
    sys.path.append('.')
    sys.path.append('..')

    # Use colour if we can.
    try:
        import colorlog
    except ImportError:
        pass
    else:
        DEFAULT_CONFIG['formatters']['colored']['format'] = \
            '%(log_color)s%(message)s%(reset)s'

    doctest.testmod()