

# Generated at 2022-06-21 21:57:17.561246
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-21 21:57:28.924374
# Unit test for function get_config
def test_get_config():
    env_var = 'SOME_TEST_ENV_VAR'
    default = {'key': 'default_value'}
    given = {'key': 'given_value'}
    json_str = '{"key": "json_str_value"}'
    yaml_str = 'key: yaml_str_value'
    # Test with ENV var and default config
    os.environ[env_var] = json_str
    assert get_config(None, env_var, default) == json.loads(json_str)
    assert get_config(json_str, env_var, default) == json.loads(json_str)
    assert get_config(yaml_str, env_var, default) == yaml.load(yaml_str)

# Generated at 2022-06-21 21:57:37.392097
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger("logger_level_test")
    initial_level = logger.level
    try:
        with logger_level(logger, logging.DEBUG):
            logger.debug("debug message")
            logger.info("info message")
        with logger_level(logger, logging.INFO):
            logger.debug("debug message")
            logger.info("info message")
    finally:
        logger.level = initial_level

# Generated at 2022-06-21 21:57:41.726283
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _namespace_from_calling_context() == 'contextlib2'
    assert _PyInfo.PY2 or _PyInfo.PY3


# Generated at 2022-06-21 21:57:44.563629
# Unit test for function configure
def test_configure():
    try:
        configure()
    except TypeError as exc:
        try:
            logging.basicConfig()
        except Exception as inner_exc:
            raise inner_exc from exc

# Generated at 2022-06-21 21:57:47.911674
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.text_type in _PyInfo.string_types
    assert _PyInfo.binary_type not in _PyInfo.string_types



# Generated at 2022-06-21 21:57:57.520760
# Unit test for function get_config

# Generated at 2022-06-21 21:58:03.502839
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == (unicode,)
    assert _PyInfo.binary_type == (str,)



# Generated at 2022-06-21 21:58:14.370368
# Unit test for function configure
def test_configure():
    import logging, os
    logger = logging.getLogger('test')
    configure({'loggers': {'test': {'handlers': ['console'], 'level': 'DEBUG'}}}, 'LOGGING', None)
    logger.info('test')
    os.environ['LOGGING'] = json.dumps({'loggers': {'test': {'handlers': ['console'], 'level': 'DEBUG'}}})
    configure(None, 'LOGGING', None)
    logger.info('test')
    # configure(json.dumps({'loggers': {'test': {'handlers': ['console'], 'level': 'DEBUG'}}}), 'LOGGING', None)
    # logger.info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 21:58:20.554256
# Unit test for function get_config
def test_get_config():
    assert get_config(default={'key': 1}) == {'key': 1}
    assert get_config(env_var='TEST_LOGGING_ENV_VAR', default={'key': 1}) is None
    os.environ['TEST_LOGGING_ENV_VAR'] = json.dumps({'key': 1, 'key2': 2})
    assert get_config(env_var='TEST_LOGGING_ENV_VAR') == {'key': 1, 'key2': 2}
    del os.environ['TEST_LOGGING_ENV_VAR']



# Generated at 2022-06-21 21:58:26.710796
# Unit test for function getLogger
def test_getLogger():
    log = getLogger('test')
    log.info('wow')

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 21:58:33.321799
# Unit test for function get_config
def test_get_config():
    import json

    cfg_1 = {'version': 1}
    cfg_2 = '{ "version" : 1 }'
    cfg_3 = '''
version: 1
'''

    assert get_config(cfg_1) == cfg_1
    assert get_config(cfg_2) == cfg_1
    assert get_config(cfg_3) == cfg_1

    # test path
    os.environ['LOGGING'] = cfg_2
    assert get_config(env_var='LOGGING') == cfg_1



# Generated at 2022-06-21 21:58:39.464740
# Unit test for function get_config
def test_get_config():
    conf1 = get_config(given=None, env_var=None, default=DEFAULT_CONFIG)
    assert conf1 == DEFAULT_CONFIG
    conf2 = get_config(given=None, env_var=None, default=None)
    assert conf2 == DEFAULT_CONFIG

    #TODO: more complicated tests

# Generated at 2022-06-21 21:58:49.054891
# Unit test for function getLogger
def test_getLogger():
    import logging
    import logging.config
    import inspect
    from contextlib import contextmanager


# Generated at 2022-06-21 21:58:51.935233
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 21:58:56.753923
# Unit test for function get_config

# Generated at 2022-06-21 21:58:57.638150
# Unit test for function configure
def test_configure():
    pass



# Generated at 2022-06-21 21:59:07.078349
# Unit test for function logger_level
def test_logger_level():
    'Unit test for function logger_level, which is not a true unit test'
    fmt = '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s'
    logging.basicConfig(level=logging.DEBUG, format=fmt)
    log = logging.getLogger('test')
    logger_level(log, logging.INFO)
    with logger_level(log, logging.DEBUG):
        with logger_level(log, logging.INFO):
            log.debug('test')
        log.debug('test')
    log.debug('test')



# Generated at 2022-06-21 21:59:12.722124
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger("test_getLogger")
    logger.debug("foo")
    logger.error("bar")


if __name__ == '__main__':
    logging.getLogger("").setLevel(logging.DEBUG)
    logging.getLogger("test_getLogger").setLevel(logging.DEBUG)
    test_getLogger()

# Generated at 2022-06-21 21:59:17.525126
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == sys.version_info[0] == 2
    assert _PyInfo.PY3 == sys.version_info[0] == 3
    assert ''.join(map(chr, range(256))) == _PyInfo.text_type('').join([_PyInfo.text_type(chr(i)) for i in range(256)])
    assert ''.join(map(chr, range(256))) == _PyInfo.binary_type('').join([_PyInfo.binary_type(chr(i)) for i in range(256)])
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.binary_type == str
    assert _PyInfo.text_type == unicode


# Generated at 2022-06-21 21:59:34.361033
# Unit test for function get_config
def test_get_config():
    config = "abc"
    assert get_config(config) == config
    assert get_config(None, 'LOGGING', config) == config
    assert get_config(None, None, config) == config

    try:
        get_config(None, None, None)
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError expected')

    assert get_config(None, None, {"version": 1}) == {"version": 1}
    assert get_config(None, None, '{"version": 1}') == {"version": 1}
    assert get_config(None, None, 'version: 1') == {"version": 1}



# Generated at 2022-06-21 21:59:37.773973
# Unit test for function get_config
def test_get_config():
    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG


# Generated at 2022-06-21 21:59:49.125458
# Unit test for function configure
def test_configure():
    logger = getLogger('logging.test_configure')
    assert isinstance(logger, logging.Logger)

    log_file = 'logging/test_configure.log'
    if os.path.isfile(log_file):
        os.remove(log_file)

    # Test with simple file handler

# Generated at 2022-06-21 22:00:00.568946
# Unit test for function get_config
def test_get_config():
    import json
    assert get_config({'loggers': {'foo': {'level': 'INFO'}}})['loggers']['foo']['level'] == 'INFO'
    assert get_config(json.dumps({'loggers': {'foo': {'level': 'INFO'}}}))['loggers']['foo']['level'] == 'INFO'


if __name__ == '__main__':
    logging.basicConfig()
    _log = logging.getLogger(__name__)
    _log.debug('test debug')
    _log.info('test info')
    _log.warning('test warn')
    _log.error('test error')
    _log.critical('test crit')

    logger = get_logger()

    logger.debug('test debug')
    logger.info('test info')

# Generated at 2022-06-21 22:00:09.423625
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    instance = _PyInfo()
    if sys.version_info[0] == 3:
        assert type(instance.PY2) == bool
        assert instance.PY3
        assert instance.string_types == (str,)
        assert type(instance.text_type) == str
        assert type(instance.binary_type) == bytes
    else:  # PY2
        assert instance.PY2
        assert type(instance.PY3) == bool
        assert instance.string_types == (basestring,)
        assert type(instance.text_type) == unicode
        assert type(instance.binary_type) == str

# Generated at 2022-06-21 22:00:12.379377
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py_info = _PyInfo()
    assert py_info.PY2 == True
    assert py_info.PY3 == False
    assert py_info.string_types == (basestring,)
    assert py_info.text_type == unicode
    assert py_info.binary_type == str


# Generated at 2022-06-21 22:00:14.378606
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3


# Generated at 2022-06-21 22:00:19.742901
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:  # PY2
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:00:28.354786
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)

    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:  # PY2
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str



# Generated at 2022-06-21 22:00:30.893297
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info("Logger test")

# test_getLogger()

# Generated at 2022-06-21 22:00:49.107638
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be displayed')
    logger.debug('This should not be displayed')


# Generated at 2022-06-21 22:00:51.321861
# Unit test for function configure
def test_configure():
    import logging
    import logging.config

    configure()
    logger = logging.getLogger('test_configure')

    assert logger.handlers



# Generated at 2022-06-21 22:00:52.143240
# Unit test for function get_config
def test_get_config():
    pass


# Generated at 2022-06-21 22:00:55.813521
# Unit test for function logger_level
def test_logger_level():
    import nose, os

    with logger_level(getLogger(), logging.FATAL):
        assert getLogger().isEnabledFor(logging.FATAL)
        assert not getLogger().isEnabledFor(logging.DEBUG)

    with logger_level(getLogger(), logging.DEBUG):
        assert getLogger().isEnabledFor(logging.DEBUG)

# Generated at 2022-06-21 22:01:03.335809
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3, "Neither PY2 nor PY3"
    assert not (_PyInfo.PY2 and _PyInfo.PY3), "Both PY2 and PY3"
    if _PyInfo.PY2:
        assert _PyInfo.string_types == (basestring, )
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    else:
        assert _PyInfo.string_types == (str, )
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes


# Generated at 2022-06-21 22:01:10.289502
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
    if _PyInfo.PY2:
        assert isinstance('', _PyInfo.string_types)
        assert isinstance(u'', _PyInfo.text_type)
        assert isinstance('', _PyInfo.binary_type)


if __name__ == '__main__':
    configure()
    log = get_logger()
    log.info('test')

# Generated at 2022-06-21 22:01:21.005141
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
    import psycopg2
    import sys

    # A function that tests whether a log entry has the correct level
    def check_level(logmsg):
        for l in logmsg.split('\n'):
            if len(l)>1:
                assert l[l.index('#')+1:]=='LOGGER_LEVEL'

    # Set up a logger
    tf = tempfile.NamedTemporaryFile()
    logger = get_logger()
    logger.handlers[0] = logging.FileHandler(tf.name)
    logger.info('test not going to be logged')

    # Test logger_level

# Generated at 2022-06-21 22:01:25.665146
# Unit test for function get_config
def test_get_config():
    from collections import OrderedDict

# Generated at 2022-06-21 22:01:31.596062
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    print(pyinfo.PY2)
    print(pyinfo.PY3)
    print(pyinfo.string_types)
    print(pyinfo.text_type)
    print(pyinfo.binary_type)


if __name__ == "__main__":
    test__PyInfo()

# Generated at 2022-06-21 22:01:39.731840
# Unit test for function get_config
def test_get_config():
    import yaml

# Generated at 2022-06-21 22:02:19.551254
# Unit test for function logger_level
def test_logger_level():
    LOGGER.setLevel(logging.DEBUG)
    with logger_level(LOGGER, logging.ERROR):
        LOGGER.debug("this should not show up")
        LOGGER.error("this should show up")
    LOGGER.debug("this should show up")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 22:02:28.298526
# Unit test for function configure

# Generated at 2022-06-21 22:02:37.010977
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Test we can set the level to a new value
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR

    # Test we can set the level to an existing value
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    # Test that logger level is guaranteed to be restored
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
        logger.level = logging.DEBUG
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-21 22:02:40.691558
# Unit test for function getLogger
def test_getLogger():
    logging.config.dictConfig(DEFAULT_CONFIG)
    log = get_logger()
    log.info('test')
    log = get_logger('test2')
    log.info('test2')



# Generated at 2022-06-21 22:02:50.685623
# Unit test for function get_config
def test_get_config():
    # test with empty parameter
    get_config()

    # test with empty parameter and not None default

# Generated at 2022-06-21 22:02:57.311956
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, 10):
        assert logger.level == 10
    assert logger.isEnabledFor(logging.INFO)
    assert logger.isEnabledFor(logging.DEBUG)
    assert not logger.isEnabledFor(logging.NOTSET)
    assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.getEffectiveLevel() != 10



# Generated at 2022-06-21 22:03:00.816550
# Unit test for function configure
def test_configure():
    # log = get_logger(__name__)

    # logger = logging.getLogger('test_log')
    # configure(default=DEFAULT_CONFIG)
    # logger.info("test")

    assert False


# Generated at 2022-06-21 22:03:07.970034
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 or pyinfo.PY3
    if pyinfo.PY2:
        assert isinstance('', pyinfo.string_types)
        assert isinstance(u'', pyinfo.string_types)
        assert isinstance(b'', pyinfo.binary_type)
        assert isinstance(u'', pyinfo.text_type)
    else:
        assert isinstance('', pyinfo.string_types)
        assert isinstance(b'', pyinfo.binary_type)
        assert isinstance('', pyinfo.text_type)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:03:16.077378
# Unit test for function get_config
def test_get_config():
    from ast import literal_eval as eval
    
    configs = []
    configs.append(None)
    configs.append("")
    configs.append("{}")
    configs.append("{'version': 1}")
    
    for config in configs:
        config = get_config(given = config)
        config = eval(config)
        assert type(config) is dict


if __name__ == "__main__":
    test_get_config()

# Generated at 2022-06-21 22:03:22.939831
# Unit test for function getLogger
def test_getLogger():
    from io import StringIO

    # If a "logging config" is not provided to getLogger
    # (i.e. the configuration dictionary) at least one
    # handler must be configured  (see p. 77 of The
    # Logging Cookbook)
    assert len(logging.getLogger().handlers) == 0
    l = getLogger()
    assert len(l.handlers) == 1
    l.info("test")

    # If a "logging config" is provided to getLogger
    # (i.e. the configuration dictionary) the user
    # is responsible for configuring the handlers.

# Generated at 2022-06-21 22:04:42.106397
# Unit test for function getLogger
def test_getLogger():
    import logging

    with logger_level(logging.getLogger(), logging.CRITICAL):
        log = getLogger('test')
        log.info('test info')



# Generated at 2022-06-21 22:04:45.438952
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log.info('test getLogger()')
    with logger_level(log, logging.DEBUG):
        log.debug('Should see me')



# Generated at 2022-06-21 22:04:48.202931
# Unit test for function configure
def test_configure():
    logger = get_logger()
    logger.info("test")


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:04:57.314375
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()

    with logger_level(log, logging.ERROR):
        log.info('test 1, should not be logged')
        log.error('test 1, should be logged')
        log.debug('test 1, should not be logged')

    log.info('test 2, should be logged')

    with logger_level(log, logging.DEBUG):
        log.info('test 3, should be logged')
        log.debug('test 3, should be logged')
        log.critical('test 3, should be logged')

    with logger_level(log, logging.INFO):
        log.info('test 4, should be logged')
        log.debug('test 4, should not be logged')


# Generated at 2022-06-21 22:05:05.864866
# Unit test for function get_config
def test_get_config():
    config = get_config(given='{"loggers": {"test": {"level": "DEBUG"}}}')
    assert config == {"loggers": {"test": {"level": "DEBUG"}}}
    config = get_config(given='{"loggers": {"test": {"level": "DEBUG"}}}', env_var='NONE')
    assert config == {"loggers": {"test": {"level": "DEBUG"}}}
    config = get_config(default='{"loggers": {"test": {"level": "DEBUG"}}}')
    assert config == {"loggers": {"test": {"level": "DEBUG"}}}
    config = get_config('{"loggers": {"test": {"level": "DEBUG"}}}', default='{"loggers": {"test": {"level": "DEBUG"}}}')
    assert config == {"loggers": {"test": {"level": "DEBUG"}}}
   

# Generated at 2022-06-21 22:05:11.641519
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert not _PyInfo.PY3
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str

if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-21 22:05:14.006821
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 is not pyinfo.PY3

# Generated at 2022-06-21 22:05:21.003800
# Unit test for function get_config
def test_get_config():
    import unittest

    class GetConfigTestCase(unittest.TestCase):
        def test_json_config(self):
            result = get_config('{"key": "value"}')
            self.assertEqual(result, {"key": "value"})

        def test_yaml_config(self):
            result = get_config('key: value')
            self.assertEqual(result, {"key": "value"})

    unittest.main()


if __name__ == "__main__":
    test_get_config()

# Generated at 2022-06-21 22:05:25.364042
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str


## Unit test for function _namespace_from_calling_context

# Generated at 2022-06-21 22:05:30.544936
# Unit test for function configure
def test_configure():
    import json
    import yaml
    import tempfile
    import os
    import os.path
    from pprint import pprint

    json_text = '{"version": 1, "loggers":{"requests":{"level":"INFO"}}}'
    yaml_text = """
    ---
    version: 1
    loggers:
      requests:
        level: INFO
    """

    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    try:
        tmp_file.write(json_text.encode("utf8"))
        tmp_file.close()
        log = get_logger("test_configure")
        configure(config=tmp_file.name)

        pprint(log.logger.manager.loggerDict)
    finally:
        os.unlink(tmp_file.name)

