

# Generated at 2022-06-21 21:57:26.185892
# Unit test for function getLogger
def test_getLogger():
    log = getLogger('test')
    assert log.getEffectiveLevel() == logging.DEBUG

    log = getLogger('requests')
    assert log.getEffectiveLevel() == logging.INFO

# Generated at 2022-06-21 21:57:34.239301
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.debug('Using the default stream handler')

    if sys.version_info[0] == 2:
        # I don't know why python 2.7 getLogger reture "module" instead of "__main__"
        assert logger.name == "module"
    elif sys.version_info[0] == 3:
        if sys.version_info[1] < 6:
            # I don't know why python 3.5 getLogger reture "__main__" instead of "__main__"
            assert logger.name == "__main__"
        else:
            # I don't know why python 3.6 getLogger reture "__main__" instead of "__main__"
            assert logger.name == "__main__"

    assert logger.level == 0



# Generated at 2022-06-21 21:57:42.741709
# Unit test for function get_config

# Generated at 2022-06-21 21:57:44.613839
# Unit test for function getLogger
def test_getLogger():
	log = getLogger(__name__)
	log.info("test_getLogger passed")


# Generated at 2022-06-21 21:57:55.061908
# Unit test for function configure
def test_configure():
    import inspect
    import logging
    import os
    log = logging.getLogger(__name__)
    log.info('Test Info Message')
    log.debug('Test Debug Message')
    log.warn('Test Warn Message')
    log.error('Test Error Message')
    import tempfile
    temp_file_name = tempfile.mktemp(prefix='test_configure_', suffix='.log')
    temp_file_name = os.path.abspath(temp_file_name)
    temp_file = open(temp_file_name, 'w')
    handler = logging.StreamHandler(temp_file)
    log.addHandler(handler)

# Generated at 2022-06-21 21:57:59.989870
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    with logger_level(log, logging.DEBUG):
        log.debug('should see this only')
        log.info('and this too')
        log.warning('and this too')
    log.state = logging.INFO
    with logger_level(log, logging.DEBUG):
        log.debug('should not see this')
        log.info('should see this')
        log.warning('should see this')
    log.info('should see this too')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 21:58:09.206660
# Unit test for function getLogger
def test_getLogger():
    os.environ['LOGGING'] = '''
version: 1
formatters:
    colored:
        () : "colorlog.ColoredFormatter"
        format: "%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s%(reset)s"
        datefmt: "%H:%M:%S"
handlers:
    console:
        class: logging.StreamHandler
        formatter: colored
        level: DEBUG
root:
    level: INFO
    handlers: [console]
'''
    try:
        configure()
        logger = getLogger()
        logger.info('test')
    finally:
        del os.environ['LOGGING']


if __name__ == '__main__':
    test_get

# Generated at 2022-06-21 21:58:10.937982
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
    assert logger.level == logging.DEBUG

# Generated at 2022-06-21 21:58:17.991649
# Unit test for function configure
def test_configure():
    import json
    import logging

    import logging_config_dict

    expected = json.dumps(DEFAULT_CONFIG, sort_keys=True, indent=4, separators=(',', ': '))

    # No argument
    configure()
    actual = json.dumps(logging.getLogger().manager.loggerDict, sort_keys=True, indent=4, separators=(',', ': '))
    assert expected == actual
    logging.shutdown()

    # default argument
    configure(default=DEFAULT_CONFIG)
    actual = json.dumps(logging.getLogger().manager.loggerDict, sort_keys=True, indent=4, separators=(',', ': '))
    assert expected == actual
    logging.shutdown()

    # Given config argument

# Generated at 2022-06-21 21:58:20.663500
# Unit test for function get_config
def test_get_config():
    config = get_config(
        given=None, env_var=None, default=DEFAULT_CONFIG
    )
    assert config == DEFAULT_CONFIG



# Generated at 2022-06-21 21:58:34.232551
# Unit test for function logger_level
def test_logger_level():
    import sys
    import warnings

    from io import StringIO

    from tests.test_utils import suppress_warnings

    logger = logging.getLogger()
    old_level = logger.level

    logger.level = logging.CRITICAL

    # First test that nothing is printed if the logger is set to critical.
    buf = StringIO()
    with logger_level(logger, logging.DEBUG):
        with warnings.catch_warnings():
            warnings.showwarning = lambda *args, **kw: print(*args, file=buf, **kw)
            warnings.warn("Should be printed to buffer.")

    assert buf.getvalue() == ""

    # Next test that a warning is printed if the logger is set to debug.
    buf = StringIO()

# Generated at 2022-06-21 21:58:38.440208
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('test_logger_level')
    with logger_level(log, logging.INFO):
        log.debug('debug log')
        log.error('error log')
    log.debug('debug log')
    log.error('error log')

# Generated at 2022-06-21 21:58:41.077660
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    from nose.tools import assert_true
    assert_true(_PyInfo.PY2 or _PyInfo.PY3)



# Generated at 2022-06-21 21:58:44.015870
# Unit test for function get_config
def test_get_config():
    assert get_config(config="""
    - name: foo
    """) == [{'name': 'foo'}]

    assert get_config(config='{"name": "foo"}') == {'name': 'foo'}

# Generated at 2022-06-21 21:58:56.208004
# Unit test for function configure
def test_configure():
    import json
    import logging.config

# Generated at 2022-06-21 21:59:06.364676
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG

# TODO: Create a setup.py and move this test into setup test_suite
# # Unit test for function _namespace_from_calling_context
# def test_namespace_from_calling_context():
#     # The function below should return '__main__'
#     def test():
#         return _namespace_from_calling_context()
#
#     assert test() == '__main__'

# TODO: create a setup.py and move this test into setup test_suite
# # Unit test for function get_logger
# def test_get_logger():
#     get_log

# Generated at 2022-06-21 21:59:11.883438
# Unit test for function getLogger
def test_getLogger():
    import logging
    import tempfile
    import os

    # create temporary file
    fileobj = tempfile.NamedTemporaryFile()
    os.environ['LOGGING'] = os.path.join(fileobj.name)

    logger = getLogger()

    assert(logger == logging.getLogger())



# Generated at 2022-06-21 21:59:13.873303
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log = getLogger('test2')



# Generated at 2022-06-21 21:59:15.443040
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    info = _PyInfo
    assert info.PY2 or info.PY3, "Incorrect py info."


if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-21 21:59:24.050014
# Unit test for function get_config

# Generated at 2022-06-21 21:59:38.375292
# Unit test for function logger_level
def test_logger_level():
    from nose.tools import raises
    from logging import DEBUG
    from random import randint
    from os import mkdir
    from os.path import isdir, join
    from shutil import rmtree

    tmp = 'tmp' + str(randint(1, 10000))
    path = join(tmp, 'test.txt')
    mkdir(tmp)
    logger = get_logger(path)

    assert logger.level == DEBUG

    logger.debug('test should be written in test.log')

    with raises(Exception):
        with logger_level(logger, INFO):
            raise Exception()

    with logger_level(logger, DEBUG):
        logger.debug('test should be written in test.log')

    rmtree(tmp)

# Generated at 2022-06-21 21:59:43.091172
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str

# Generated at 2022-06-21 21:59:45.572201
# Unit test for function configure
def test_configure():
    logger = configure()
    assert logger == logging.getLogger(__name__)

# Generated at 2022-06-21 21:59:54.207609
# Unit test for function get_config
def test_get_config():
    config_dict = {'version': 1, 'disable_existing_loggers': False, 'formatters': {'simple': {'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s', 'datefmt': '%Y-%m-%d %H:%M:%S'}}, 'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'simple', 'level': 10}}, 'root': {'handlers': ['console'], 'level': 10}, 'loggers': {'requests': {'level': 20}}}

    assert get_config() == DE

# Generated at 2022-06-21 21:59:59.872344
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
    logger.debug("debug message")
    logger.info("info message")



# Generated at 2022-06-21 22:00:08.163970
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    log.info('test_logger_level.info')
    log.debug('test_logger_level.debug')
    with logger_level(log, logging.DEBUG):
        log.info('test_logger_level.info')
        log.debug('test_logger_level.debug')
    log.info('test_logger_level.info')
    log.debug('test_logger_level.debug')



# Generated at 2022-06-21 22:00:11.119049
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        log.info("this should be visible")
        log.debug("this should be visible too")
    log.info("this should not be visible")
    log.debug("this should not be visible either")

# Generated at 2022-06-21 22:00:18.678908
# Unit test for constructor of class _PyInfo

# Generated at 2022-06-21 22:00:24.050367
# Unit test for function getLogger
def test_getLogger():
    # set up a logger
    with configure():
        logger = get_logger('test_getLogger')
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.exception('test')
        logger.critical('test')

# Generated at 2022-06-21 22:00:28.319287
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:00:41.736457
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logger.level
    # Test that we can change level within a block.
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    # Test that the level is reset to its previous value.
    assert logger.level == level

# Test that the loggers are properly configured.
_ensure_configured()
logger = get_logger('test_imports')
logger.debug('logging properly configured')

# Generated at 2022-06-21 22:00:42.742469
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()


# Generated at 2022-06-21 22:00:45.796314
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger()
    log.info('test')


if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-21 22:00:54.259406
# Unit test for function get_config
def test_get_config():
    from json import loads
    from yaml import load
    from StringIO import StringIO

    json_config = StringIO('{"version":1}')
    yaml_config = StringIO('version: 1')

    assert get_config(default=False) is None
    assert get_config(config=False, default=False) is None
    assert get_config(default=1) == 1
    assert get_config(config=1, default=2) == 1
    assert get_config(config='{"version":1}', default=False) == {'version': 1}
    assert get_config(config=json_config) == {'version': 1}
    assert get_config(config=yaml_config) == {'version': 1}

# Generated at 2022-06-21 22:00:55.163114
# Unit test for function configure
def test_configure():
    pass

# Generated at 2022-06-21 22:00:59.635487
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is not None
    assert _PyInfo.PY3 is not None
    assert _PyInfo.string_types is not None
    assert _PyInfo.text_type is not None
    assert _PyInfo.binary_type is not None



# Generated at 2022-06-21 22:01:04.502511
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.DEBUG


# Generated at 2022-06-21 22:01:14.517453
# Unit test for function get_config
def test_get_config():
    import os
    import json
    import yaml
    import pytest

    def _config_stub(poop=None):
        """Use poop as a logging config instead of the env var."""
        os.environ['LOGGING'] = 'poop'
        return poop

    _config = '''{ "a": 1, "b": 2 }'''
    _yaml_config = '''a: 1
b: 2
'''
    _broken_config = '''{ "a: 1, "b": 2 }'''
    _broken_yaml = '''---
a: 1,
b: 2
'''
    with pytest.raises(ValueError):
        get_config(config=_config_stub())

# Generated at 2022-06-21 22:01:18.819690
# Unit test for function getLogger
def test_getLogger():
    """
    >>> getLogger().info("test")
    ... # doctest: +ELLIPSIS
    [INFO] ... : test
    """
    pass


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:01:25.647816
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("Test Debug")
    with logger_level(logger, logging.INFO):
        logger.info("Test Info")
    with logger_level(logger, logging.WARNING):
        logger.warning("Test Warning")
    with logger_level(logger, logging.ERROR):
        logger.error("Test Error")
    with logger_level(logger, logging.CRITICAL):
        logger.critical("Test Critical")

# Generated at 2022-06-21 22:01:51.393803
# Unit test for function get_config
def test_get_config():
    import json
    import logging

    # Check for None config
    assert get_config() is None


# Generated at 2022-06-21 22:01:58.208222
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger("TEST_LOG")
    INFO = 20 # Don't know why level names don't match up, but this is the level for INFO
    DEBUG = 10 # Ditto
    with logger_level(log, INFO):
        log.debug("This will be ignored.")
    with logger_level(log, DEBUG):
        log.debug("This will not be ignored.")
    assert log.level == INFO

# Generated at 2022-06-21 22:02:02.474041
# Unit test for function configure
def test_configure():
    import json
    import logging
    config = json.load(open('config_test.json'))
    assert configure(config) == None
    assert logging.getLogger('requests').level == logging.INFO
    assert logging.getLogger('using_logger').level == logging.DEBUG

# Generated at 2022-06-21 22:02:05.175499
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
    assert logger.level == logging.NOTSET

# Generated at 2022-06-21 22:02:14.774550
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    if _PyInfo.PY2:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
        assert isinstance("", (basestring, str)) == True
        assert isinstance("", str) == True
    else:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
        assert isinstance("", (str, str)) == True
        assert isinstance("", str) == True



# Generated at 2022-06-21 22:02:23.427816
# Unit test for function getLogger
def test_getLogger():
    import unittest
    class TestGetLogger(unittest.TestCase):
        def test_getLogger(self):
            class InnerTestGetLogger(object):
                def test_getLogger(self):
                    self.logger = logging.getLogger()
                    print(self.logger)
            obj = InnerTestGetLogger()
            print(obj.test_getLogger())
            self.assertTrue(obj)
    unittest.main()

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 22:02:26.155604
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG



# Generated at 2022-06-21 22:02:36.672984
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import tempfile
    import os
    import json

    _CONFIGURED.pop()
    config = dict(
        version=1,
        formatters={
            'test': {
                'format': '%(asctime)s %(name)s %(process)d %(levelname)s %(message)s',
            },
        },
        handlers={
            'test': {
                'class': 'logging.StreamHandler',
                'formatter': 'test',
                'level': logging.DEBUG,
            },
        },
        root=dict(handlers=['test'], level=logging.DEBUG),
    )

    config_file = tempfile.mktemp()

# Generated at 2022-06-21 22:02:47.862523
# Unit test for function get_config
def test_get_config():
    default_config = {'name': 'test'}
    assert get_config() == None
    assert get_config(default=default_config) == default_config
    assert get_config(env_var='LOGGING_ENV_TEST') == None
    os.environ['LOGGING_ENV_TEST'] = "{'name': 'test'}"
    assert get_config(env_var='LOGGING_ENV_TEST') == {'name': 'test'}
    del os.environ['LOGGING_ENV_TEST']
    assert get_config("{'name': 'test'}") == {'name': 'test'}
    assert get_config("name: test") == {'name': 'test'}


# Generated at 2022-06-21 22:02:56.229370
# Unit test for function getLogger
def test_getLogger():
    # Simple unit test, checks if the function is properly logging
    logger = getLogger()
    logger.debug("DEBUG")
    logger.info("INFO")
    logger.warning("WARNING")
    logger.error("ERROR")
    logger.critical("CRITICAL")


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:03:36.559002
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = logging.getLogger(__name__)
    >>> logger.setLevel(logging.DEBUG)
    >>> print(logger.level)
    10
    >>> with logger_level(logger, logging.WARNING):
    ...     print(logger.level)
    ...     # Todo: Why level is not 30?
    30
    >>> print(logger.level)
    10
    """

# Generated at 2022-06-21 22:03:37.239149
# Unit test for function configure
def test_configure():
    configure()

# Generated at 2022-06-21 22:03:43.484568
# Unit test for function logger_level
def test_logger_level():
    import logging
    import time
    import random

    log = getLogger(__name__)
    log.setLevel(logging.INFO)

    log.info('test')
    with logger_level(log, logging.DEBUG):
        log.debug('test')

    with logger_level(log, logging.INFO):
        log.debug('test')

    with logger_level(log, logging.NOTSET):
        log.debug('test')

    # Unit test for function configure
    def test_configure():
        import json
        import os

        config = DEFAULT_CONFIG
        config_str = json.dumps(config)
        os.environ['LOGGING'] = config_str
        configure(get_config(env_var='LOGGING'))

# Generated at 2022-06-21 22:03:46.004396
# Unit test for function get_config
def test_get_config():
    config = get_config(env_var=None,
                        default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG



# Generated at 2022-06-21 22:03:54.565005
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not (_PyInfo.PY2 and _PyInfo.PY3)
    assert isinstance('', _PyInfo.string_types)
    assert isinstance(u'', _PyInfo.string_types)
    assert not isinstance(b'', _PyInfo.string_types)
    if _PyInfo.PY2:
        assert not isinstance(b'', _PyInfo.text_type)
    else:
        assert isinstance(b'', _PyInfo.text_type)



# Generated at 2022-06-21 22:03:56.210324
# Unit test for function getLogger
def test_getLogger():
    log = get_logger('test_getLogger')
    log.info('test_getLogger')
    assert True

# Generated at 2022-06-21 22:04:00.665817
# Unit test for function logger_level
def test_logger_level():
    log=get_logger('test_logger_level')
    with logger_level(log, logging.DEBUG):
        log.info('test')
        log.debug('test debug')
    log.info('test')
    log.debug('test debug')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 22:04:02.717532
# Unit test for function get_config
def test_get_config():

    assert(get_config())



# Generated at 2022-06-21 22:04:14.334943
# Unit test for function configure
def test_configure():
    import io
    import logging
    import os

    log = get_logger()

    def _configure_from_io(contents):
        logging.shutdown()
        configure(contents)

    def _configure_from_os_var(var, contents):
        logging.shutdown()
        os.environ[var] = contents
        configure(env_var=var)

    def _validate_config(log_contents):
        assert log.level == logging.WARNING
        assert 'WARNING' in log_contents


# Generated at 2022-06-21 22:04:17.282795
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.ERROR):
        assert log.level == logging.ERROR
    assert log.level == logging.DEBUG

# Generated at 2022-06-21 22:05:39.984749
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info("test")



# Generated at 2022-06-21 22:05:43.320529
# Unit test for function configure
def test_configure():
    def cls_test():
        configure('./config/logging.json')
        log = get_logger()
        log.info('test')
        return True

    assert cls_test()

if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-21 22:05:49.754402
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    configure(
        dict(
            version=1,
            disable_existing_loggers=False,
            handlers={
                'console': {
                    'class': 'logging.StreamHandler',
                    'formatter': 'colored',
                    'level': logging.DEBUG,
                },
            },
            root=dict(handlers=['console'], level=logging.DEBUG),
            loggers={
                __name__: dict(level=logging.INFO),
            },
        )
    )
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.error('error')
    logger.debug('debug')
    logger.info('info')
    logger.error('error')
    return

# Generated at 2022-06-21 22:05:55.754740
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import sys
    assert isinstance(_PyInfo.string_types, tuple)
    assert isinstance(_PyInfo.text_type, str)
    assert isinstance(_PyInfo.binary_type, bytes)

    if sys.version_info[0] == 2:
        assert _PyInfo.PY2
        assert not _PyInfo.PY3
    else:
        assert _PyInfo.PY3
        assert not _PyInfo.PY2



# Generated at 2022-06-21 22:05:57.122772
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info( 'getLogger() passed' )



# Generated at 2022-06-21 22:06:00.774153
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger(__name__)
    log.info('start')
    with logger_level(log, logging.DEBUG):
            log.debug('debug')
    log.info('info')
    log.debug('end')

# Generated at 2022-06-21 22:06:03.778418
# Unit test for constructor of class _PyInfo
def test__PyInfo():
   if not _PyInfo.PY2:
       assert sys.version_info[0] == 3 
   else:
       assert sys.version_info[0] == 2


# Generated at 2022-06-21 22:06:12.739505
# Unit test for function logger_level
def test_logger_level():

    # Create a logger
    logger = logging.getLogger('testing.logger_level')
    logger.setLevel(logging.WARNING)

    # Create a handler and attach to the logger
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)

    # Check that we are logging only above the warning level
    logger.debug('This will not be logged')
    logger.warning('This will be logged')

    # Set the warning level to debug level
    with logger_level(logger, logging.DEBUG):
        # Now, both warnings and debugs will be logged
        logger.warning('This will be logged')
        logger.debug('This will be logged too')

    # Reset the warning level back to the initial
    logger.warning('This will also be logged')
    logger.debug('This will not be logged')

# Generated at 2022-06-21 22:06:14.788413
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('getLogger')
    logger.info('This test is to test getLogger in logging_utils')

# Generated at 2022-06-21 22:06:25.957936
# Unit test for function configure