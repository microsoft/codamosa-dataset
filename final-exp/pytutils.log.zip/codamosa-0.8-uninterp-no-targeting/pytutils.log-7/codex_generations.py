

# Generated at 2022-06-21 21:57:23.386820
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # info = _PyInfo()
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-21 21:57:27.564213
# Unit test for function getLogger
def test_getLogger():
    """
    >>> logger = getLogger('log')
    >>> assert logger.level == logging.DEBUG
    """



# Generated at 2022-06-21 21:57:31.222357
# Unit test for function configure
def test_configure():
    """ """
    assert (not isinstance(_CONFIGURED, bool))
    get_logger('test').info("test")



# Generated at 2022-06-21 21:57:37.464154
# Unit test for function get_config
def test_get_config():
    config = [
        {},
        dict(a=1),
        '{}',
        'a: b',
        '[]',
        'a: 1',
    ]
    for cfg in config:
        assert get_config(cfg) == cfg


if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-21 21:57:43.958646
# Unit test for function getLogger
def test_getLogger():
    log = getLogger('test logger')
    print(log.level)
    print(log)
    log.info('test info')
    log.debug('test debug')
    log.warning('test warning')
    log.error('test error')
    assert False

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 21:57:47.045224
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3, "should be one of PY2 and PY3"

if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-21 21:57:52.408562
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.NOTSET)
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.NOTSET

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 21:57:56.828527
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert type(_PyInfo.string_types) is type, "Should return <class 'type'>"
    #assert type(_PyInfo.string_types) is list, "Should return <class 'list'>"
    assert type(_PyInfo.text_type) is str, "Should return <class 'str'>"
    assert type(_PyInfo.binary_type) is str, "Should return <class 'str'>"



# Generated at 2022-06-21 21:58:03.298292
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if not _PyInfo.PY3:
        assert isinstance('a', _PyInfo.string_types)
        assert isinstance('a', _PyInfo.binary_type)
        assert isinstance(u'a', _PyInfo.text_type)
    else:
        assert not isinstance('a', _PyInfo.binary_type)
        assert not isinstance(u'a', _PyInfo.string_types)



# Generated at 2022-06-21 21:58:11.259592
# Unit test for function getLogger
def test_getLogger():
    from logl.logl import configure, getLogger
    import logging

    import os
    import tempfile
    import shutil

    log_cfg = {
        "version": 1,
        "formatters": {
            "simple": {
                "format": "%(levelname)s|%(name)s|%(message)s",
            }
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "formatter": "simple",
                "level": logging.DEBUG,
            },
        },
        "root": {
            "handlers": ["console"],
            "level": logging.DEBUG,
        }
    }
    cfg = {'logging': log_cfg}

    with tempfile.TemporaryDirectory() as temp_dir:
        f

# Generated at 2022-06-21 21:58:18.480389
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert not _PyInfo.PY3
    assert isinstance('', _PyInfo.string_types)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str


# Generated at 2022-06-21 21:58:20.330707
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
test__PyInfo()



# Generated at 2022-06-21 21:58:24.336257
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        log.info('test')


# TODO Fix this
# log = LoggerProxy(logging.getLogger(__name__))
# ...
# del log

# Generated at 2022-06-21 21:58:33.617354
# Unit test for function get_config
def test_get_config():
    assert get_config('') is None
    assert get_config('', '') is None
    assert get_config('', '', '') is None

    # given
    assert get_config({}) == {}
    assert get_config({}, '') == {}

    # env_var
    assert get_config(None, 'LOGGING') is None
    assert get_config(None, 'LOGGING', '') == ''

    # default
    assert get_config() == DEFAULT_CONFIG
    assert get_config(None, None, '') == ''
    assert get_config(None, None, {}) == {}
    assert get_config() == get_config(None, None)

    # given + env_var
    assert get_config({}, '') == {}
    assert get_config(None, '') is None


# Generated at 2022-06-21 21:58:36.124020
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.debug('some debug message')
    log.info('some info message')
    log.warning('some warning message')


if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-21 21:58:37.941028
# Unit test for function configure
def test_configure():
    configure()
    
if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-21 21:58:43.915155
# Unit test for function get_config
def test_get_config():
    assert isinstance(get_config(given=None, env_var=None, default=DEFAULT_CONFIG), dict)
    assert isinstance(get_config(
        given='{"version": 1, "disable_existing_loggers": False}',
        env_var=None,
        default=None
    ), dict)


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-21 21:58:55.353371
# Unit test for function get_config
def test_get_config():
    d = {'version': 1, 'disable_existing_loggers': False, 'handlers': {'console': {'level': 'INFO', 'class': 'logging.StreamHandler'}}, 'loggers': {'requests': {'level': 'INFO'}}, 'root': {'level': 'DEBUG', 'handlers': ['console'], 'propagate': True}}
    assert get_config(default=d) == d
    assert get_config(given={'version': 1}) == {'version': 1}
    assert get_config(env_var='LOGGING', default=d) == d
    assert get_config(env_var='LOGGING', given={'version': 1}) == {'version': 1}


# Generated at 2022-06-21 21:58:59.415042
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
    assert logger.level == logging.DEBUG

# Generated at 2022-06-21 21:59:08.726102
# Unit test for function getLogger
def test_getLogger():
    logfile = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'test_logger.log')
    if os.path.exists(logfile):
        os.unlink(logfile)


# Generated at 2022-06-21 21:59:13.589949
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    # Don't know how to test the rest.


# Generated at 2022-06-21 21:59:19.737247
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    assert log.getEffectiveLevel() == logging.DEBUG, "level should be set to DEBUG"

    log.setLevel(logging.WARNING)
    assert log.getEffectiveLevel() == logging.WARNING, "level should be set to WARNING"

    log.setLevel(logging.INFO)
    assert log.getEffectiveLevel() == logging.INFO, "level should be set to INFO"

# Generated at 2022-06-21 21:59:29.420119
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 is True, 'Environment is not python3'
    assert isinstance(_PyInfo.string_types, tuple), '_PyInfo.string_types have to be a tuple'
    assert isinstance(_PyInfo.string_types[0], type(str())), '_PyInfo.string_types have to be a tuple of str'
    assert isinstance(_PyInfo.text_type, type(str())), '_PyInfo.text_type have to be str'
    assert isinstance(_PyInfo.binary_type, type(bytes())), '_PyInfo.binary_type have to be str'


# Generated at 2022-06-21 21:59:32.135138
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert _PyInfo.PY2 or _PyInfo.PY3


# Generated at 2022-06-21 21:59:35.877655
# Unit test for function logger_level
def test_logger_level():
    """
    >>> log = getLogger(__name__)
    >>> with logger_level(log, logging.CRITICAL):
    ...   log.debug('should be ignored')
    >>> log.debug('this should be printed')
    """



# Generated at 2022-06-21 21:59:38.657546
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    log.info('test_logger_level')


# Generated at 2022-06-21 21:59:49.282140
# Unit test for function configure
def test_configure():

    logging_config_path = 'logging_config.ini'
    logging.config.fileConfig(logging_config_path)
    log = logging.getLogger('simpleExample')
    log.debug('debug message')
    log.info('info message')
    log.warning('warn message')
    log.error('error message')
    log.critical('critical message')


# Generated at 2022-06-21 21:59:53.524670
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test')
    assert logger.name == 'test'
    logger = getLogger()
    if logger.name:
        assert True
    else:
        assert False



# Generated at 2022-06-21 22:00:04.370880
# Unit test for function get_config
def test_get_config():
    # test for bare
    assert get_config('root:INFO') == {
        'root': {'level': 20},
        'version': 1,
        'disable_existing_loggers': False,
    }

    # test for json
    json_config = """
    {
        "root": {
            "level": "INFO"
        },
        "version": 1
    }
    """
    assert get_config(json_config) == {
        'root': {'level': 20},
        'version': 1,
        'disable_existing_loggers': False,
    }

    # test for yaml
    yaml_config = """
    root:
        level: INFO
    version: 1
    """

# Generated at 2022-06-21 22:00:10.180108
# Unit test for function configure
def test_configure():
    import io
    import sys

    old_stdout = sys.stdout
    dummy_stdout = io.StringIO()
    sys.stdout = dummy_stdout
    log = get_logger(__name__)
    log.info('test')
    sys.stdout = old_stdout
    dummy_stdout.seek(0)
    output = dummy_stdout.read()
    assert "test " in output
    dummy_stdout.close()
    return

if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-21 22:00:19.037219
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # If a new version of python is introduced, this test will fail
    #    and a new class will be necessary: _Py<version>Info
    if sys.version_info[0] == 2:
        assert _PyInfo.PY2 is True
        assert _PyInfo.PY3 is False
    elif sys.version_info[0] == 3:
        assert _PyInfo.PY2 is False
        assert _PyInfo.PY3 is True
    else:
        raise ValueError("Unsupported version: {}".format(sys.version_info[0]))


# Generated at 2022-06-21 22:00:28.028447
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:  # PY2
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str



# Generated at 2022-06-21 22:00:31.064433
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 22:00:33.748799
# Unit test for function configure
def test_configure():
    configure(
        config='{"version": 1}',
        env_var='LOGGING_TEST',
        default={},
    )

# Generated at 2022-06-21 22:00:43.098889
# Unit test for function get_config
def test_get_config():
    """Test for function get_config"""
    assert (get_config("test","test",DEFAULT_CONFIG) == "test")
    assert (get_config("test", "test") == "test")
    assert (get_config("test", default=DEFAULT_CONFIG) == "test")
    assert (get_config("{\"test\": 123}", env_var="test") == {"test": 123})
    assert (get_config("test: 123", env_var="test") == {"test": 123})
    assert (get_config("test: 123", env_var="test", default=DEFAULT_CONFIG) ==
               DEFAULT_CONFIG)

if __name__ == '__main__':
    configure()
    test_get_config()

# Generated at 2022-06-21 22:00:51.076129
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not (_PyInfo.PY2 and _PyInfo.PY3)
    assert not isinstance('test', _PyInfo.binary_type)
    assert not isinstance(u'test', _PyInfo.binary_type)
    assert isinstance(b'test', _PyInfo.binary_type)
    assert isinstance('test', _PyInfo.string_types)
    assert isinstance(u'test', _PyInfo.string_types)
    assert not isinstance(b'test', _PyInfo.string_types)



# Generated at 2022-06-21 22:00:53.446034
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-21 22:00:59.386794
# Unit test for function logger_level
def test_logger_level():
    # Given
    import logging
    logger = logging.getLogger(__name__ + '.test_logger_level')
    logger.setLevel(logging.INFO)
    # When
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
    # Then
    logger.info('info')

# Generated at 2022-06-21 22:01:00.643005
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('Test')


# Generated at 2022-06-21 22:01:07.377760
# Unit test for function getLogger
def test_getLogger():
    log_test = getLogger()
    # AssertionError: Failed to get info level log for module test_getLogger!
    try:
        log_test.info('This is an info-level log for module test_getLogger!')
    except AssertionError:
        assert False

# Generated at 2022-06-21 22:01:26.570865
# Unit test for function logger_level
def test_logger_level():
    def foo():
        logger = logging.getLogger('test')
        with logger_level(logger, logging.DEBUG):
            logger.debug('Inside the block')
        logger.debug('Outside the block')

    test_logger = logging.getLogger('test')
    test_logger.setLevel(logging.INFO)
    test_handler = logging.StreamHandler()
    test_logger.addHandler(test_handler)

    foo()

    # Check if test_logger received DEBUG and INFO messages
    assert len(test_handler.messages['debug']) == 1
    assert len(test_handler.messages['info']) == 1

    # Check if both messages are from different call locations
    assert test_handler.messages['debug'][0].find('test_logger_level') != -1

# Generated at 2022-06-21 22:01:32.244446
# Unit test for function configure
def test_configure():
    """
    >>> from io import StringIO
    >>> log = get_logger()
    >>> stream = StringIO()
    >>> handler = logging.StreamHandler(stream)
    >>> log.addHandler(handler)
    >>> configure()
    >>> log.info('test')
    >>> stream.seek(0)
    0
    >>> log.removeHandler(handler)
    """



# Generated at 2022-06-21 22:01:36.396896
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.INFO)

    log = logging.getLogger("test")
    log.warning("test")

    try:
        with logger_level(log, logging.DEBUG):
            log.debug("test")
    except Exception:
        raise Exception("test failed")

# Generated at 2022-06-21 22:01:42.014980
# Unit test for function getLogger
def test_getLogger():
    """
    >>> import logging
    >>> log = getLogger('test')
    >>> assert(log.level == logging.DEBUG)
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:01:49.833072
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3, "Flag PY2 and PY3 should not be identical"
    if _PyInfo.PY2 is True:
        assert type(_PyInfo.text_type()) is unicode
        assert type(_PyInfo.binary_type()) is str
    elif _PyInfo.PY3 is True:
        assert type(_PyInfo.text_type()) is str
        assert type(_PyInfo.binary_type()) is bytes
    else:
        assert False, "Should not reach here"

# Generated at 2022-06-21 22:01:57.880680
# Unit test for function logger_level
def test_logger_level():
    l = get_logger(__name__)
    with logger_level(l, logging.DEBUG):
        l.debug('test')
        assert l.isEnabledFor(logging.DEBUG)
        assert not l.isEnabledFor(logging.INFO)

    l.info('test')
    assert not l.isEnabledFor(logging.DEBUG)
    assert l.isEnabledFor(logging.INFO)

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-21 22:01:58.869116
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-21 22:02:04.604540
# Unit test for function getLogger
def test_getLogger():
    with logger_level(logging.root, logging.DEBUG):
        log = getLogger("test")
        log.debug("debug")
        log.info("info")
        log.warning("warning")
        log.error("error")
        log.critical("critical")


if __name__ == "__main__":
    test_getLogger()
    configure()
    get_logger().info('test')

# Generated at 2022-06-21 22:02:10.589092
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance(_PyInfo.PY2, bool)
    assert isinstance(_PyInfo.PY3, bool)
    assert isinstance(_PyInfo.string_types[0], type)
    assert isinstance(_PyInfo.text_type, type)
    assert isinstance(_PyInfo.binary_type, type)

# Generated at 2022-06-21 22:02:24.268931
# Unit test for function get_config
def test_get_config():
    try:
        get_config(default=None);
        assert False, "get_config should have thrown exception for default == None"
    except ValueError:
        pass
    try:
        get_config();
        assert False, "get_config should have thrown exception for no args"
    except ValueError:
        pass
    try:
        get_config(env_var='NOT_A_REAL_ENV_VAR');
        assert False, "get_config should have thrown exception for non-existent env var"
    except ValueError:
        pass
    try:
        get_config(config=123);
        assert False, "get_config should have thrown exception for config != str or dict"
    except ValueError:
        pass
    config = get_config(config="this is not json/yaml");

# Generated at 2022-06-21 22:02:49.308103
# Unit test for function get_config
def test_get_config():
    assert get_config(default = DEFAULT_CONFIG) == DEFAULT_CONFIG


if __name__ == '__main__':
    logging.config.dictConfig(DEFAULT_CONFIG)
    test_get_config()
    log = logging.getLogger(__name__)
    log.info('test')

    log = logging.getLogger('test2')
    log.info('test2')

# Generated at 2022-06-21 22:02:56.175126
# Unit test for function configure
def test_configure():
    """
    >>> configure(DEFAULT_CONFIG)
    >>> logger = logging.getLogger('logtest')
    >>> logger.info('Hello World!')
    [2018-08-30 07:10:46,501] [root/13076] Hello World! @test_configure:15 #INFO
    """
    pass


# Generated at 2022-06-21 22:03:03.905622
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3, "_PyInfo.PY2 or _PyInfo.PY3 should be True"
    assert isinstance("", _PyInfo.string_types), "\"\" should be an instance of _PyInfo.string_types"
    assert isinstance("", _PyInfo.text_type), "\"\" should be an instance of _PyInfo.text_type"
    assert isinstance(_PyInfo.binary_type(""), _PyInfo.binary_type), "_PyInfo.binary_type(\"\") should be an instance of _PyInfo.binary_type"


# Generated at 2022-06-21 22:03:10.000457
# Unit test for function get_config
def test_get_config():
    """Unit test for function get_config"""
    # Default Config
    assert get_config() == DEFAULT_CONFIG

    # Given Config
    assert get_config({'test': 'config'}) == {'test': 'config'}

    # JSON Config
    config_json = """
    {
        "version": 1,
        "test": "config"
    }
    """
    assert get_config(config_json) == {'version': 1, 'test': 'config'}

    # YAML Config
    config_yaml = """
    version: 1
    test: config
    """
    assert get_config(config_yaml) == {'version': 1, 'test': 'config'}

    # Invalid Config
    bad_config = 'invalid'

# Generated at 2022-06-21 22:03:13.533297
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.info('info test')
        logger.error('error test')

# Generated at 2022-06-21 22:03:21.211083
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG
    assert get_config(default=None) is None
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config='{"foo": "bar"}') == {"foo": "bar"}
    assert get_config(config='foo: bar') == {"foo": "bar"}
    assert get_config(config='foo: bar', default=None) == {"foo": "bar"}
    assert get_config(config='foo: bar', default=DEFAULT_CONFIG) == {"foo": "bar"}
    assert get_config(env_var='NOT_SET') == DEFAULT_CONFIG
    assert get_config(env_var='NOT_SET', default=None) is None

# Generated at 2022-06-21 22:03:24.013972
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True or _PyInfo.PY2 == False
    assert _PyInfo.PY3 == True or _PyInfo.PY3 == False
    assert _PyInfo.PY3 != _PyInfo.PY2

# Generated at 2022-06-21 22:03:36.768967
# Unit test for function getLogger
def test_getLogger():
  import io
  import sys

  def print_getLogger():
    print("testing getLogger")

  log = getLogger(name='test_getLogger')
  log.debug("DEBUG: getLogger")
  log.info("INFO: getLogger")

  # Unit test for function get_config
  def test_get_config():
    print("testing get_config")

# Generated at 2022-06-21 22:03:41.438115
# Unit test for function get_config
def test_get_config():
    import json

    global DEFAULT_CONFIG
    default = DEFAULT_CONFIG

    config = get_config(None, None, default)
    assert config == default

    config = get_config(None, 'LOGGING', default)
    assert config == default

    config = get_config(json.dumps(default), None, default)
    assert config == default



# Generated at 2022-06-21 22:03:52.691981
# Unit test for function get_config

# Generated at 2022-06-21 22:04:35.701891
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger(__name__)
    logger.warning('test')


if __name__ == '__main__':
    from . import test

    test.run()

# Generated at 2022-06-21 22:04:39.271776
# Unit test for function logger_level
def test_logger_level():
    l = get_logger()
    with logger_level(l, logging.DEBUG):
        assert l.level == logging.DEBUG
        l.debug("debug test")

    assert l.level == logging.DEBUG

# Generated at 2022-06-21 22:04:45.382574
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.ERROR):
        log.debug('debugging message')
        log.info('info message')
        log.error('error message')
    log.debug('debugging message')
    log.info('info message')
    log.error('error message')


# if __name__ == '__main__':
#    log = get_logger(__name__)
#    log.info('test')
#    log.debug('test debug')
#    log.info('test info')
#    log.error('test error')
#    log.exception('test exception')

# Generated at 2022-06-21 22:04:48.937337
# Unit test for function getLogger
def test_getLogger():
    self = getLogger("test_getLogger")
    self.info("Test message")
    self.debug("Test message")


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-21 22:04:53.210081
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert isinstance('str', pyinfo.string_types)
    assert isinstance(u'unicode', pyinfo.string_types)
    assert isinstance(b'bytes', pyinfo.binary_type)


# Generated at 2022-06-21 22:05:02.406334
# Unit test for function logger_level
def test_logger_level():
    # Note: The test below requires that DEBUG and INFO are correctly defined
    # as integers less than and greater than 25, respectively.  If this
    # assumption is incorrect, the code will raise an AttributeError below.
    logger = logging.getLogger(__name__)
    logger.addHandler(logging.NullHandler())

    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.INFO) == True
        assert logger.isEnabledFor(logging.DEBUG) == False

    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.INFO) == True
        assert logger.isEnabledFor(logging.DEBUG) == True

    assert logger.isEnabledFor(logging.INFO) == True

# Generated at 2022-06-21 22:05:12.062811
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import platform
    import sys

    info = _PyInfo()
    assert info.PY2 == (platform.python_version_tuple()[0] == '2')
    assert info.PY3 == (platform.python_version_tuple()[0] == '3')
    if info.PY3:
        assert info.string_types == (str,), info.string_types
        assert info.text_type == str
        assert info.binary_type == bytes
    else:  # info.PY2
        assert info.string_types == (basestring,)
        assert info.text_type == unicode
        assert info.binary_type == str


if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-21 22:05:18.343794
# Unit test for function get_config
def test_get_config():
    for config, expected in (
        (None, None),
        ('{}', {}),
        ('{"version": 1}', {"version": 1}),
        ('version: 1', {"version": 1}),
    ):
        assert get_config(config) == expected

    assert get_config(expected, default=expected) == expected


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:05:21.914983
# Unit test for function getLogger
def test_getLogger():
    with logger_level(getLogger(), logging.DEBUG):
        log = getLogger()
        log.debug('test')


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:05:23.339857
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test get logger')



# Generated at 2022-06-21 22:06:49.163784
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.DEBUG):
        log = get_logger(__name__)
        log.debug('print me')
        log.debug('print me again')
        log.warn('dont print me')
        log.warn('print me again')
    log.debug('dont print me')
    log.debug('dont print me again')
    log.warn('print me')
    log.warn('print me again')


if __name__ == '__main__':
    configure()
    test_logger_level()

# Generated at 2022-06-21 22:06:59.602770
# Unit test for function get_config
def test_get_config():
    # Test no input
    with pytest.raises(ValueError):
        get_config()

    # Test non-string input
    with pytest.raises(ValueError):
        get_config({})

    # Test invalid JSON
    with pytest.raises(ValueError):
        get_config('{"foo":1')

    # Test valid JSON
    assert get_config('{"foo":1}') == {"foo":1}

    # Test invalid YAML
    with pytest.raises(ValueError):
        get_config('foo: bar')

    # Test valid YAML
    assert get_config('foo: bar\n') == {"foo": 'bar'}



# Generated at 2022-06-21 22:07:10.046398
# Unit test for function get_config
def test_get_config():
    # Prepare test data
    given_none = None
    given_json_string = '{"version": 1, "formatters": {"simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}}}'

# Generated at 2022-06-21 22:07:12.100086
# Unit test for function getLogger
def test_getLogger():
    """
    >>> log = getLogger()
    >>> log.info('test init')
    """
    pass


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:07:15.464242
# Unit test for function getLogger
def test_getLogger():
    assert getLogger('ssecs') is logging.getLogger('ssecs')
    assert getLogger() is logging.getLogger('ssecs')