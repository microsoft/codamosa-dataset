

# Generated at 2022-06-21 21:57:33.091473
# Unit test for function getLogger
def test_getLogger():
    global _CONFIGURED
    _CONFIGURED = []

# Generated at 2022-06-21 21:57:43.464989
# Unit test for function get_config

# Generated at 2022-06-21 21:57:48.015770
# Unit test for function getLogger
def test_getLogger():
    """
    >>> logger = get_logger()
    >>> logger.debug('test message from test_getLogger')
    >>> logger.info('test message from test_getLogger')
    >>> logger.warning('test message from test_getLogger')
    >>> logger.error('test message from test_getLogger')
    >>> logger.critical('test message from test_getLogger')
    """



# Generated at 2022-06-21 21:57:51.512474
# Unit test for function getLogger
def test_getLogger():
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = getLogger('a')
    logger.info('a')


# Generated at 2022-06-21 21:57:59.023901
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.INFO):
        logger.debug("This should not appear")
        logger.info("This should appear")



# TODO just here as a reminder to implement this.
# def logging_cfg():
#     from .config import cfg
#
#     log_cfg = cfg.get('logging')
#     if log_cfg:
#         if isinstance(log_cfg, _PyInfo.string_types):
#             import json
#
#             try:
#                 log_cfg = json.loads(log_cfg)
#             except ValueError:
#                 import yaml
#
#                 try:
#                     log_cfg = yaml.load(log_cfg)
#                 except ValueError:
#

# Generated at 2022-06-21 21:58:01.921115
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level != logging.DEBUG

# Generated at 2022-06-21 21:58:03.399625
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3


# Generated at 2022-06-21 21:58:05.742952
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        logger.info('test')
    assert logger.level == logging.DEBUG



# Generated at 2022-06-21 21:58:11.560764
# Unit test for function get_config
def test_get_config():
    assert get_config(
        '{"version": 1, "handlers": {"test": {"class": "logging.StreamHandler" }}}'
    )
    assert get_config(
        'version: 1\nhandlers:\n    test:\n        class: logging.StreamHandler'
    )
    assert get_config(
        "version: 1\nhandlers:\n    test:\n        class: logging.StreamHandler"
    )
    s = "version: 1\nhandlers:\n    test:\n        class: logging.StreamHandler"
    assert get_config(s.decode('utf-8'))



# Generated at 2022-06-21 21:58:17.900148
# Unit test for function logger_level
def test_logger_level():
    import logging

    log = get_logger('test-logger-level')
    log.setLevel(logging.DEBUG)
    with logger_level(log, logging.DEBUG):
        log.debug('Should work')
    log.debug('Should not work')
    with logger_level(log, logging.INFO):
        log.debug('Should not work')
        log.info('Should work')
    log.debug('Should work')



# Generated at 2022-06-21 21:58:22.364849
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

# Generated at 2022-06-21 21:58:32.060958
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # Test class attribute PY2
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)

    # Test class attribute PY3
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

    # Test class attribute string_types
    assert _PyInfo.string_types == (basestring,)

    # Test class attribute text_type
    assert _PyInfo.text_type == unicode

    # Test class attribute binary_type
    assert _PyInfo.binary_type == str

    # Test _PyInfo__get_class_attr()
    assert _PyInfo._PyInfo__get_class_attr('PY2') == (sys.version_info[0] == 2)



# Generated at 2022-06-21 21:58:43.552595
# Unit test for function logger_level
def test_logger_level():
    import random
    import string
    import unittest

    # Random string generated using "random" module and choice() method
    _string = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
    class test_logger_level(unittest.TestCase):
        def test_logger_level(self):
            logger = get_logger()
            with logger_level(logger, logging.DEBUG):
                logger.debug('test_debug_log: %s', _string)
                logger.info('test_info_log: %s', _string)
                logger.warning('test_warning_log: %s', _string)
                logger.error('test_error_log: %s', _string)

# Generated at 2022-06-21 21:58:45.700381
# Unit test for function getLogger
def test_getLogger():
    """
    >>> log = get_logger()
    >>> log.info('test')
    >>> log.error('test')
    """

# Generated at 2022-06-21 21:58:56.400841
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # Test type of object PY2
    assert isinstance(DEFAULT_CONFIG['loggers']['requests'], dict)
    assert isinstance(DEFAULT_CONFIG['version'], int)
    assert isinstance(_namespace_from_calling_context(), str)
    assert isinstance(_CONFIGURED, list)
    assert isinstance(_ensure_configured, types.FunctionType)
    assert isinstance(get_logger, types.FunctionType)
    assert isinstance(getLogger, types.FunctionType)
    assert isinstance(logger_level, types.FunctionType)
    assert isinstance(configure, types.FunctionType)
    assert isinstance(get_config, types.FunctionType)
    assert isinstance(_PyInfo.PY3, bool)

# Generated at 2022-06-21 21:59:04.394047
# Unit test for function get_config
def test_get_config():
    config = get_config()
    assert config['version'] == 1

    config = get_config(config, env_var=None, default=None)
    assert config['version'] == 1

    config = get_config(config=None, env_var=None, default=None)
    assert config == None

    config = get_config(config='{"version": "2"}', env_var=None, default=None)
    assert config['version'] == '2'

    config = get_config(config='version: 2', env_var=None, default=None)
    assert config['version'] == 2



# Generated at 2022-06-21 21:59:11.274781
# Unit test for function get_config
def test_get_config():
    assert {
        'version': 1,
        'disable_existing_loggers': False
    } == get_config(config='{"version": 1, "disable_existing_loggers": false}')

    assert {
        'version': 1,
        'disable_existing_loggers': False
    } == get_config(config='{"version": 1, "disable_existing_loggers": false}')

    assert {
        'version': 1,
        'disable_existing_loggers': False
    } == get_config(
        config='''
        version: 1
        disable_existing_loggers: false
        ''')

if __name__ == '__main__':
    """
    >>> log = logging.getLogger(__name__)
    >>> configure()
    >>> log.info('test')
    """

# Generated at 2022-06-21 21:59:21.666375
# Unit test for function configure
def test_configure():
    logger = get_logger()
    logger.info("Testing configure")

    # Configure with default config
    log_level =  logger.getEffectiveLevel()
    cfg = get_config(default=DEFAULT_CONFIG)
    if log_level != logging.DEBUG:
        raise ValueError('Log level should be DEBUG')
    if not cfg:
        raise ValueError('default config is empty')

    # Configure with environment var
    os.environ['LOGGING'] = json.dumps(cfg)
    configure()

    # Configure with file
    os.environ['LOGGING'] = './logging_config.json'
    configure()

    # Configure with string
    c = '{"version": 1}'
    configure(config=c)

    # Configure with dict

# Generated at 2022-06-21 21:59:32.832252
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert isinstance('', _PyInfo.string_types)
        assert not isinstance(b'', _PyInfo.string_types)
        assert isinstance('', _PyInfo.text_type)
        assert not isinstance(b'', _PyInfo.text_type)
        assert not isinstance('', _PyInfo.binary_type)
        assert isinstance(b'', _PyInfo.binary_type)
    else:
        assert isinstance('', _PyInfo.string_types)
        assert not isinstance(b'', _PyInfo.string_types)
        assert isinstance('', _PyInfo.text_type)
        assert not isinstance(b'', _PyInfo.text_type)
        assert not isinstance('', _PyInfo.binary_type)

# Generated at 2022-06-21 21:59:34.796197
# Unit test for function configure
def test_configure():
    import time

    configure()
    log = logging.getLogger(__name__)
    log.warning("Warning")
    log.info("Info")
    log.debug("Debug")
    time.sleep(0.5)


# Generated at 2022-06-21 21:59:49.179419
# Unit test for function logger_level
def test_logger_level():
    from io import StringIO
    from logging import basicConfig, getLogger, DEBUG, INFO
    from .color import LevelFormatter

    # Redirect console output to StringIO
    console = StringIO()
    basicConfig(level=DEBUG, stream=console, format=LevelFormatter.DEFAULT_FORMAT)

    log = getLogger(__name__)
    log.info('INFO message')
    log.debug('DEBUG message')

    console.seek(0)
    assert console.readlines() == ['INFO message\n']

    with logger_level(log, INFO):
        log.info('INFO message')
        log.debug('DEBUG message')

    console.seek(0)
    assert console.readlines() == ['INFO message\n', 'INFO message\n', 'DEBUG message\n']

# Generated at 2022-06-21 21:59:56.237860
# Unit test for function logger_level
def test_logger_level():  # pragma: no cover
    import logging
    logger = logging.getLogger('logger_level.test')
    logger.setLevel(logging.ERROR)
    with logger_level(logger, logging.DEBUG):
        logger.debug('this should not appear')
        logger.info('this should appear')
    logger.info('this also should not appear')



# Generated at 2022-06-21 22:00:01.973288
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    obj = _PyInfo()
    if (_PyInfo.PY2):
         assert obj.string_types == (basestring,)
         assert obj.text_type == unicode
         assert obj.binary_type == str
    else:
         assert obj.string_types == (str,)
         assert obj.text_type == str
         assert obj.binary_type == bytes


# Generated at 2022-06-21 22:00:05.578360
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str

# Generated at 2022-06-21 22:00:07.941172
# Unit test for function configure
def test_configure():
    log = logging.getLogger('test_configure')
    cfg = get_config()
    configure(cfg)
    log.info('test')



# Generated at 2022-06-21 22:00:16.664169
# Unit test for function get_config
def test_get_config():
    assert get_config(config="test") == "test"
    assert get_config(config={"test": "test"}) == {"test": "test"}
    assert get_config(config=None) == None

    assert get_config(config="{'test': 'test'}") == {"test": "test"}
    assert get_config(config='{"test": "test"}') == {"test": "test"}

    assert get_config(config="'test': 'test' test2") == None
    assert get_config(config="'test': 'test' test2", default="test") == "test"



# Generated at 2022-06-21 22:00:20.735996
# Unit test for function configure
def test_configure():
    # Note: log is None before configure
    log = logging.getLogger(__name__)

    # Note: Exception will be raised if configure doesn't work
    configure()

    log.info('test')


# Generated at 2022-06-21 22:00:30.060120
# Unit test for function get_config

# Generated at 2022-06-21 22:00:33.905538
# Unit test for function logger_level
def test_logger_level():
    configure(None, None, None)
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('debug msg')
        logger.warning('warning msg')
        logger.info('info msg')
        logger.error('error msg')
        logger.critical('critical msg')
        # None of the above outputs should appear
    logger.debug('debug msg')
    logger.warning('warning msg')
    logger.info('info msg')
    logger.error('error msg')
    logger.critical('critical msg')
    # All of the above outputs should appear



# Generated at 2022-06-21 22:00:41.740713
# Unit test for function logger_level
def test_logger_level():
    # get a logger
    logger = getLogger("test_logger_level")
    logger.debug("Adebugmessage.")
    # set the level to warning
    with logger_level(logger, logging.WARNING):
        logger.debug("Awarningmessage.")


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, format='%(levelname)s|%(asctime)s|%(name)s|%(process)d|%(thread)d|%(message)s')
    logging.debug("Adebugmessage.")
    test_logger_level()

# Generated at 2022-06-21 22:00:55.928435
# Unit test for function getLogger
def test_getLogger():
    import sys
    import io

    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    log = logging.getLogger('__main__')
    log.debug('test')

    #assert stream.getvalue() == 'test\n', 'Incorrect value: %s' % stream.getvalue()
    #return stream.getvalue()


if __name__ == "__main__":
    print(test_getLogger())

# Generated at 2022-06-21 22:00:59.036172
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not _PyInfo.PY2 and _PyInfo.PY3
    # TODO: no check for _PyInfo.string_types
    assert isinstance(u'', _PyInfo.text_type)
    assert isinstance('', _PyInfo.binary_type)

if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-21 22:01:10.135625
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # Python 2.7
    assert _PyInfo.PY2
    assert not _PyInfo.PY3
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str
    # Python 3.3
    if _PyInfo.PY3:
        assert not _PyInfo.PY2
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes



# Generated at 2022-06-21 22:01:17.365949
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3
    assert _PyInfo.PY2 == False

# Generated at 2022-06-21 22:01:24.982899
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        with logger_level(logger, logging.DEBUG):
            assert logger.level == logging.DEBUG
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG



# Generated at 2022-06-21 22:01:33.581564
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    configure()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

if __name__ == '__main__':
    logger = logging.getLogger(__name__)
    configure()
    test_logger_level()
    logger.debug('debug')
    logger.info('info')
    logger.error('error')
    logger.warning('warning')

# Generated at 2022-06-21 22:01:37.892265
# Unit test for function getLogger
def test_getLogger():
    result = get_logger('test')
    suffix = repr(result)[-22:]
    assert suffix == 'test,0)>'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:01:42.125022
# Unit test for function getLogger
def test_getLogger():
    #test for null input
    assert get_logger() == logging.getLogger()

    #test for string input
    assert get_logger('test') == logging.getLogger('test')


# Generated at 2022-06-21 22:01:50.433064
# Unit test for function get_config
def test_get_config():
    assert get_config(config='{"version": 1}') == {'version': 1}
    assert get_config(config='version: 1') == {'version': 1}
    assert get_config(config='{"version": 1}', default={'version': 2}) == {'version': 1}
    assert get_config(config=None, default={'version': 2}) == {'version': 2}

    # Invalid configuration
    try:
        get_config(config=None, default=None)
        assert False
    except ValueError:
        pass


# Generated at 2022-06-21 22:01:53.909015
# Unit test for function get_config
def test_get_config():
    from pprint import pprint

    print("test_get_config():")
    pprint(DEFAULT_CONFIG)



# Generated at 2022-06-21 22:02:11.914319
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert isinstance(logger, logging.Logger)


test_getLogger()

# Generated at 2022-06-21 22:02:21.355027
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.INFO):
        logger.warn('foo')
        logger.info('bar')
        logger.debug('baz')
        with logger_level(logger, logging.WARN):
            logger.warn('fizz')
            logger.info('buzz')
        logger.info('bar again')
        logger.warn('foo again')
        logger.debug('baz again')


# Generated at 2022-06-21 22:02:26.731943
# Unit test for function configure
def test_configure():
    import tempfile

    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.write(b'{}')
    temp_file.close()
    os.environ['LOGGING'] = temp_file.name
    configure()
    os.unlink(temp_file.name)
    del os.environ['LOGGING']


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:02:37.159693
# Unit test for function get_config
def test_get_config():
    cfg = get_config(default='{"version": 1, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": "INFO"}}}')
    assert cfg["version"] == 1
    assert cfg["handlers"]["console"]["level"] == "INFO"
    assert cfg["handlers"]["console"]["formatter"] == "simple"
    assert cfg["handlers"]["console"]["class"] == "logging.StreamHandler"


# Generated at 2022-06-21 22:02:48.445441
# Unit test for function configure
def test_configure():
    import tempfile
    tf = tempfile.mktemp()
    with open(tf, 'w') as fp:
        fp.write('version: 1\n')
        fp.write('formatters:\n')
        fp.write('colored:\n')
        fp.write('()\n')
        fp.write('logging.config.dictConfig\n')
        fp.write('format\n')
        fp.write('%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s\n')
        fp.write('datefmt\n')


# Generated at 2022-06-21 22:03:01.591859
# Unit test for function configure
def test_configure():
    configure()
    assert logging.getLogger().level == logging.DEBUG
    configure(default=dict(version=1, disable_existing_loggers=False,
                           formatters={'simple': {'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s', 'datefmt': '%Y-%m-%d %H:%M:%S'}},
                           handlers={'console': {'class': 'logging.StreamHandler', 'formatter': 'simple', 'level': logging.INFO}},
                           root={'handlers': ['console'], 'level': logging.DEBUG}))

# Generated at 2022-06-21 22:03:07.592069
# Unit test for function logger_level
def test_logger_level():
    l = logging.getLogger('testing')
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    with logger_level(l, logging.DEBUG):
        assert l.level == logging.DEBUG
        assert logger.level == logging.DEBUG

    assert l.level == logging.NOTSET
    assert logger.level == logging.DEBUG


if __name__ == "__main__":
    configure('simple')
    logger = get_logger()

    logger.debug("debug")
    logger.info("info")
    logger.warn("warn")

# Generated at 2022-06-21 22:03:09.093925
# Unit test for function getLogger
def test_getLogger():
    configure()
    logger = getLogger()
    logger.info("test_getLogger")


# Generated at 2022-06-21 22:03:17.327813
# Unit test for function configure
def test_configure():
    """Unit test for logging configure
    """
    # use log in global scope
    global log

    # configure the logger
    configure()

    # get the logger
    log = get_logger()

    # test log info
    log.info('info message')

    # test log debug
    log.debug('debug message')

    # test log warning
    log.warning('warning message')

    # test log error
    log.error('error message')

    # test log critical
    log.critical('critical message')


# Generated at 2022-06-21 22:03:21.446278
# Unit test for function getLogger
def test_getLogger():
    import logging
    import os

    log = getLogger("foo")
    log.info("This is a test")

    log = getLogger("bar")
    log.info("This is a test")



# Generated at 2022-06-21 22:03:46.419816
# Unit test for function configure
def test_configure():
    from tempfile import NamedTemporaryFile
    from subprocess import check_output
    import yaml
    import logging
    import json

    # Test with no configuration
    with NamedTemporaryFile('w') as tf:
        cmd = [
            sys.executable,
            '-c',
            """
            import logging
            import sys
            import pytest
            from logutil import configure
            configure()
            try:
                assert logging._handlers
            except AttributeError as e:
                pytest.fail('Could not access `logging._handlers`')
            """,
        ]
        output = check_output(cmd)
        print(output.decode('utf-8'))

    # Test with bare configuration

# Generated at 2022-06-21 22:03:57.478999
# Unit test for function get_config
def test_get_config():
    import json
    # test if normal config works

# Generated at 2022-06-21 22:04:04.649594
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)

    # no logging
    with logger_level(log, logging.CRITICAL):
        log.debug('not logged')
        log.info('not logged')
        log.warning('not logged')
        log.error('not logged')
        log.critical('not logged')

    # only debug logging
    with logger_level(log, logging.DEBUG):
        log.debug('logged')
        log.info('logged: %s', 'test')
        log.warning('logged')
        log.error('logged')
        log.critical('logged')

    # all logging
    with logger_level(log, logging.NOTSET):
        log.debug('logged')
        log.info('logged: %s', 'test')
        log.warning('logged')


# Generated at 2022-06-21 22:04:09.702799
# Unit test for function get_config
def test_get_config():
    config = get_config('{"key" : "value"}')
    config = get_config(config, env_var=None, default=None)
    assert config == {'key': 'value'}
    config = get_config(config, env_var=None, default=None)
    assert config == {'key': 'value'}

# Generated at 2022-06-21 22:04:12.425662
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')
    log.warning('test')
    log.error('test')



# Generated at 2022-06-21 22:04:15.350987
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test logger_level')

# Generated at 2022-06-21 22:04:25.137764
# Unit test for function configure
def test_configure():
    assert configure()
    assert configure(
    )  # no exception raised if it was configured twice (the default)
    assert configure()
    assert configure(dict(version=1))  # no exception raised

# Generated at 2022-06-21 22:04:30.319354
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.__doc__:
        print('PY2:', _PyInfo.PY2)
        print('PY3:', _PyInfo.PY3)
        print('string_types:', _PyInfo.string_types)
        print('text_type:', _PyInfo.text_type)
        print('binary_type:', _PyInfo.binary_type)


if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-21 22:04:41.653396
# Unit test for function get_config

# Generated at 2022-06-21 22:04:47.015238
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    logging.basicConfig(level=logging.DEBUG)
    configure()
    log = logging.getLogger(__name__)
    assert log.handlers[0].level == logging.DEBUG
    log.debug("test_configure")
    configure(default={'level': logging.INFO})
    assert log.handlers[0].level == logging.INFO
    log.info("test_configure")
    configure(default={'level': logging.WARNING})
    assert log.handlers[0].level == logging.WARNING
    log.warning("test_configure")


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-21 22:05:21.866751
# Unit test for function configure
def test_configure():
    # import logging
    import colorlog
    from colorlog import ColoredFormatter

    configure()
    color_format = '%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s'
    log = logging.getLogger(__name__)
    log.info('test')
    console_handler = log.handlers[0]
    assert console_handler.level == logging.DEBUG
    assert console_handler.formatter._fmt == color_format
    assert isinstance(console_handler.formatter, ColoredFormatter)



# Generated at 2022-06-21 22:05:25.912396
# Unit test for function get_config
def test_get_config():
    """
        >>> import json
        >>> conf = json.dumps({'a': 1, 'b': 2})
        >>> cfg = get_config(conf, default=None)
        >>> cfg['a']
        1

        >>> get_config(conf, env_var=None)['a']
        1
    """
    pass



# Generated at 2022-06-21 22:05:27.985580
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-21 22:05:34.040265
# Unit test for function logger_level
def test_logger_level():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestLoggerLevel(unittest.TestCase):
        def test_basic(self):
            log = getLogger()
            with logger_level(log, logging.ERROR):
                log.debug('Should not see this.')

    unittest.main()



# Generated at 2022-06-21 22:05:36.482445
# Unit test for function configure
def test_configure():
    logger = getLogger(__name__)
    if not logger.hasHandlers():
        configure()
    logger.info('test')

# Generated at 2022-06-21 22:05:43.557146
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    # clear the logger
    loggers = logging.Logger.manager.loggerDict
    if logger.name in loggers:
        del loggers[logger.name]
    assert logger == logging.getLogger(logger.name)
    assert str(logger) == "<logger %s (WARNING)>" % logger.name
    assert logger.level == logging.WARNING

    logger = getLogger(__name__)
    assert logger == getLogger(logger.name)
    assert logger == getLogger(__name__)
    assert logger == logging.getLogger(__name__)

# Generated at 2022-06-21 22:05:47.498034
# Unit test for function logger_level
def test_logger_level():
    log = get_logger("test_logger_level")
    assert log.level == 10
    with logger_level(log, 20):
        assert log.level == 20
    assert log.level == 10



# Generated at 2022-06-21 22:05:51.804099
# Unit test for function logger_level
def test_logger_level():
    l = getLogger("test_logger_level")
    l.setLevel(logging.ERROR)
    assert l.level == logging.ERROR
    with logger_level(l, logging.DEBUG):
        assert l.level == logging.DEBUG
    assert l.level == logging.ERROR

# Generated at 2022-06-21 22:05:54.732757
# Unit test for function getLogger
def test_getLogger():
    try:
        _set_logger_config()
        getLogger('testlogger').info('this is info message')
    except Exception as e:
        print(e)
        raise e


# Generated at 2022-06-21 22:05:59.711755
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == sys.version_info[0] == 2
    assert pyinfo.PY3 == sys.version_info[0] == 3
    if pyinfo.PY3:
        assert pyinfo.string_types == (str,)
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
    else:
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str


# Generated at 2022-06-21 22:06:33.091428
# Unit test for function get_config

# Generated at 2022-06-21 22:06:36.053151
# Unit test for function get_config
def test_get_config():
    # Test Standalone string value
    config = '{"version": 1, "disable_existing_loggers": False}'
    config_dict = get_config(config)
    assert config_dict == {"version": 1, "disable_existing_loggers": False}



# Generated at 2022-06-21 22:06:38.933405
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    configure()
    logger.info("test logger")


if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-21 22:06:44.023306
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert(pyinfo.PY2 != pyinfo.PY3)


if __name__ == '__main__':
    import doctest
    if doctest.testmod()[0] == 0:
        print('Passed')
    else:
        print('Failed')

# Generated at 2022-06-21 22:06:45.634322
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test')
    logger.warning('test')



# Generated at 2022-06-21 22:06:53.006452
# Unit test for function configure
def test_configure():
    """
    >>> test_configure()
    """

    # Not py3k compat
    # def _remove_stack_frames(frames):
    #     while frames[-1].f_code.co_filename[-1] == 't':
    #         frames.pop()
    # remove_stack_frames(inspect.currentframe().f_back.f_back.f_back.f_back.f_back.f_back.f_back.f_back.f_back.f_back.f_back.f_back.f_back.f_back)

    configure()
    log = get_logger()
    log.info('test')

# Generated at 2022-06-21 22:07:06.115194
# Unit test for function get_config
def test_get_config():
    from nose.tools import eq_
    from io import StringIO

    with logger_level(get_logger(), logging.DEBUG):
        eq_(get_config(None), DEFAULT_CONFIG)


# Generated at 2022-06-21 22:07:11.377657
# Unit test for function logger_level
def test_logger_level():
    # logger_level will be tested by logging.basicConfig function
    logging.basicConfig()
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('In the context block: logger.level should be logging.DEBUG')
        logger.info('In the context block: logger.level should be logging.DEBUG')
    logger.debug('Outside the context block: logger.level should be not logging.DEBUG')



# Generated at 2022-06-21 22:07:13.152219
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.ERROR):
        logger.info('test')  # should not be logged
        logger.error('test2')  # should be logged

# Generated at 2022-06-21 22:07:17.342923
# Unit test for function getLogger
def test_getLogger():
    logging.basicConfig(level=logging.DEBUG)
    log = get_logger('test')
    log.info('test')
    if __name__ == '__main__':
        test_getLogger()