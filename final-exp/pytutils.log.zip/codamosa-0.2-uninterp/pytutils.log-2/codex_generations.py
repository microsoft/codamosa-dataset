

# Generated at 2022-06-18 04:26:55.796961
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:00.240452
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG

# Generated at 2022-06-18 04:27:02.583321
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:27:05.497077
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:27:09.063493
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:27:20.136576
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import os
    import tempfile
    import contextlib

    @contextlib.contextmanager
    def capture_stdout():
        old_stdout = sys.stdout
        sys.stdout = tempfile.TemporaryFile()
        try:
            yield
        finally:
            sys.stdout.seek(0)
            output = sys.stdout.read()
            sys.stdout.close()
            sys.stdout = old_stdout
        return output

    with capture_stdout() as output:
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)
        logger.info('test')
    assert output == b''

    with capture_stdout() as output:
        with logger_level(logger, logging.DEBUG):
            logger

# Generated at 2022-06-18 04:27:25.120294
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")

# Generated at 2022-06-18 04:27:26.874489
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')

# Generated at 2022-06-18 04:27:33.751067
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("debug")
        log.info("info")
        log.warning("warning")
        log.error("error")
        log.critical("critical")
    log.debug("debug")
    log.info("info")
    log.warning("warning")
    log.error("error")
    log.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:36.319042
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:27:46.214181
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=None, default=None)
    assert config == None

    config = get_config(config=DEFAULT_CONFIG, default=DEFAULT_CONFIG, env_var='LOGGING')

# Generated at 2022-06-18 04:27:48.693986
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    logger.info('info message')
    with logger_level(logger, logging.INFO):
        logger.info('info message')
    logger.debug('debug message')



# Generated at 2022-06-18 04:27:54.208371
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config(None, None, None) is None

    assert get_config(None, None, {}) == {}
    assert get_config(None, None, {'a': 'b'}) == {'a': 'b'}

    assert get_config(None, 'LOGGING', None) is None

    assert get_config(None, 'LOGGING', {}) == {}
    assert get_config(None, 'LOGGING', {'a': 'b'}) == {'a': 'b'}

    assert get_config('{"a": "b"}', None, None) == {'a': 'b'}
    assert get_config('{"a": "b"}', None, {}) == {'a': 'b'}

# Generated at 2022-06-18 04:27:56.320917
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:28:04.722209
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    log = logging.getLogger('test_logger_level')
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:09.854775
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:19.899159
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import inspect
    import sys
    import os
    from contextlib import contextmanager

    class _PyInfo(object):
        PY2 = sys.version_info[0] == 2
        PY3 = sys.version_info[0] == 3

        if PY3:
            string_types = str,
            text_type = str
            binary_type = bytes
        else:  # PY2
            string_types = basestring,
            text_type = unicode
            binary_type = str

    def _namespace_from_calling_context():
        """
        Derive a namespace from the module containing the caller's caller.

        :return: the fully qualified python name of a module.
        :rtype: str
        """
        # Not py3k compat
        #

# Generated at 2022-06-18 04:28:28.165551
# Unit test for function get_config
def test_get_config():
    import json
    import yaml


# Generated at 2022-06-18 04:28:32.226081
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:42.295790
# Unit test for function get_config
def test_get_config():
    assert get_config(config=None, env_var=None, default=None) is None
    assert get_config(config=None, env_var='LOGGING', default=None) is None
    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:28:48.707719
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG



# Generated at 2022-06-18 04:28:57.067554
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    import sys
    import os
    import tempfile
    import shutil
    import time

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the config

# Generated at 2022-06-18 04:28:59.043682
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug message")
    logger.info("This is an info message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:07.284295
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG
    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING')
    assert config == DEFAULT_CONFIG
    config = get_config(config=json.dumps(DEFAULT_CONFIG), env_var='LOGGING')
    assert config == DEFAULT_CONFIG

# Generated at 2022-06-18 04:29:17.078151
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import logging

    # Test with bare config
    config = 'hello'
    assert get_config(config) == 'hello'

    # Test with json config
    config = json.dumps({'hello': 'world'})
    assert get_config(config) == {'hello': 'world'}

    # Test with yaml config
    config = yaml.dump({'hello': 'world'})
    assert get_config(config) == {'hello': 'world'}

    # Test with invalid config
    config = '{'
    try:
        get_config(config)
    except ValueError:
        pass
    else:
        assert False

    # Test with invalid config
    config = '{'

# Generated at 2022-06-18 04:29:22.617423
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:29.102428
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:34.105147
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:29:35.488093
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:29:39.323280
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
        log.info('test')
        log.warning('test')
        log.error('test')
        log.critical('test')


# Generated at 2022-06-18 04:29:49.355415
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:51.600584
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:30:01.076565
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import os

    # Test for bare config

# Generated at 2022-06-18 04:30:05.621174
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:09.638753
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:14.868072
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:18.675844
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:26.379794
# Unit test for function get_config
def test_get_config():
    import json
    import yaml


# Generated at 2022-06-18 04:30:35.470784
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import inspect
    import sys
    import os

    from contextlib import contextmanager


    class _PyInfo(object):
        PY2 = sys.version_info[0] == 2
        PY3 = sys.version_info[0] == 3

        if PY3:
            string_types = str,
            text_type = str
            binary_type = bytes
        else:  # PY2
            string_types = basestring,
            text_type = unicode
            binary_type = str


    def _namespace_from_calling_context():
        """
        Derive a namespace from the module containing the caller's caller.

        :return: the fully qualified python name of a module.
        :rtype: str
        """
        # Not py3k compat


# Generated at 2022-06-18 04:30:40.023372
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:30:57.360088
# Unit test for function configure
def test_configure():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 04:31:04.984309
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    import sys
    import os

    from contextlib import contextmanager


# Generated at 2022-06-18 04:31:11.537661
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug message")
        logger.info("This is an info message")
        logger.warning("This is a warning message")
        logger.error("This is an error message")
        logger.critical("This is a critical message")
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:17.072070
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")


# Generated at 2022-06-18 04:31:23.181077
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:27.515379
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG

# Generated at 2022-06-18 04:31:33.810766
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:41.581308
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG
    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING')
    assert config == DEFAULT_CONFIG
    config = get_config(config=json.dumps(DEFAULT_CONFIG), env_var='LOGGING')
    assert config == DEFAULT_CONFIG

# Generated at 2022-06-18 04:31:44.556636
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
        log.info('test')
        log.warning('test')
        log.error('test')
        log.critical('test')
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')



# Generated at 2022-06-18 04:31:50.264684
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:03.204870
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG



# Generated at 2022-06-18 04:32:09.061552
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:15.420997
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:18.437397
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
        logger.info("This should not be logged")
    logger.info("This should be logged")
    logger.debug("This should not be logged")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:19.981451
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:32:24.790251
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:32:32.878593
# Unit test for function get_config
def test_get_config():
    # Test for invalid config
    try:
        get_config(config=None)
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')

    # Test for bare config
    config = get_config(config='{"version": 1}')
    assert config == {'version': 1}

    # Test for json config
    config = get_config(config='{"version": 1}')
    assert config == {'version': 1}

    # Test for yaml config
    config = get_config(config='version: 1')
    assert config == {'version': 1}


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:32:34.750626
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test2')


# Generated at 2022-06-18 04:32:44.017296
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

    with logger_level(logger, logging.WARNING):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:32:45.925011
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-18 04:32:58.611367
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

# Generated at 2022-06-18 04:33:06.713343
# Unit test for function configure
def test_configure():
    import logging
    import os
    import tempfile
    import json

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Write logging config to temporary file
    with open(path, 'w') as f:
        json.dump(DEFAULT_CONFIG, f)

    # Set environment variable
    os.environ['LOGGING'] = path

    # Configure logging
    configure()

    # Get logger
    log = logging.getLogger(__name__)

    # Log a message
    log.info('test')

    # Remove temporary file
    os.remove(path)



# Generated at 2022-06-18 04:33:08.643821
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:33:17.362244
# Unit test for function configure
def test_configure():
    import logging
    import os
    import tempfile
    import json

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Write logging config to the file
    with open(path, 'w') as f:
        json.dump(DEFAULT_CONFIG, f)

    # Set environment variable
    os.environ['LOGGING'] = path

    # Configure logging
    configure()

    # Get logger
    log = logging.getLogger(__name__)

    # Test logger
    log.info('test')

    # Remove the temporary file
    os.remove(path)



# Generated at 2022-06-18 04:33:18.937573
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:33:21.662961
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:25.278880
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    with logger_level(logger, logging.INFO):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:29.002171
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should print")
        logger.info("This should not print")
    logger.info("This should print")
    logger.debug("This should not print")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:35.518615
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:40.811179
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:51.670207
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:33:53.848753
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:33:56.672548
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:03.828429
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test_logger_level')
        logger.info('test_logger_level')
        logger.warning('test_logger_level')
        logger.error('test_logger_level')
        logger.critical('test_logger_level')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:09.244265
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:13.979841
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("debug")
        log.info("info")
        log.warning("warning")
        log.error("error")
        log.critical("critical")
    log.debug("debug")
    log.info("info")
    log.warning("warning")
    log.error("error")
    log.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:18.074588
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
    logger.debug('debug')
    logger.info('info')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:19.430423
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:34:28.235192
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import os

    config = get_config(config=None, env_var=None, default=None)
    assert config is None

    config = get_config(config=None, env_var='LOGGING', default=None)
    assert config is None

    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None)
    assert config == DEFAULT_CONFIG


# Generated at 2022-06-18 04:34:35.370532
# Unit test for function get_config
def test_get_config():
    # Test with given config
    config = get_config(given={'version': 1})
    assert config == {'version': 1}

    # Test with env_var
    os.environ['LOGGING'] = '{"version": 1}'
    config = get_config(env_var='LOGGING')
    assert config == {'version': 1}

    # Test with default config
    config = get_config(default={'version': 1})
    assert config == {'version': 1}

    # Test with invalid config
    with pytest.raises(ValueError):
        get_config()

    # Test with invalid json
    with pytest.raises(ValueError):
        get_config(given='{"version": 1')

    # Test with invalid yaml
    with pytest.raises(ValueError):
        get

# Generated at 2022-06-18 04:34:57.091242
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:02.075345
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    logger.info('info message')
    with logger_level(logger, logging.INFO):
        logger.debug('debug message')
    logger.info('info message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:07.687936
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:15.919844
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config='{"version": 1}', env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == {"version": 1}
    config = get_config(config='version: 1', env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == {"version": 1}
    config = get_config(config=None, env_var='LOGGING', default=None)
    assert config is None

if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-18 04:35:19.891898
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:21.874892
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:35:30.560226
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def test_logger_level(self):
            with logger_level(self.logger, logging.INFO):
                self.logger.debug('debug')
                self.logger.info('info')
                self.logger.warning('warning')
                self.logger.error('error')
                self.logger.critical('critical')

# Generated at 2022-06-18 04:35:32.549272
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')



# Generated at 2022-06-18 04:35:34.145396
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:35:36.891533
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    logger.info('info message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:57.139145
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:36:05.407561
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be logged')
        logger.info('This should be logged')
        logger.warning('This should be logged')
        logger.error('This should be logged')
        logger.critical('This should be logged')
    logger.debug('This should not be logged')
    logger.info('This should not be logged')
    logger.warning('This should not be logged')
    logger.error('This should not be logged')
    logger.critical('This should not be logged')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:10.209938
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:12.133135
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:36:14.617945
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:19.624624
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG



# Generated at 2022-06-18 04:36:21.136993
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:36:23.563765
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:36:26.743601
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:31.034966
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

