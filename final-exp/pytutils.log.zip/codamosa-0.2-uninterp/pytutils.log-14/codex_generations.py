

# Generated at 2022-06-18 04:26:49.992239
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:26:51.807131
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:26:56.898678
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be printed")
        logger.info("This should not be printed")
    logger.info("This should be printed")
    logger.debug("This should not be printed")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:26:58.576007
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:27:07.189363
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    with logger_level(logger, logging.WARNING):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    with logger_level(logger, logging.ERROR):
        logger.debug('debug')

# Generated at 2022-06-18 04:27:09.652467
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:27:20.490260
# Unit test for function get_config
def test_get_config():
    assert get_config(config=None, env_var=None, default=None) == None
    assert get_config(config=None, env_var='LOGGING', default=None) == None
    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:27:25.386795
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")

# Generated at 2022-06-18 04:27:35.853951
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"version": 1}', env_var=None, default=None)
    assert config == {"version": 1}

    config = get_config(config=None, env_var='LOGGING', default=None)
    assert config == {"version": 1}

    config = get_config(config=None, env_var=None, default={"version": 1})
    assert config == {"version": 1}

    config = get_config(config=None, env_var=None, default=None)
    assert config == None

    config = get_config(config='{"version": 1}', env_var=None, default={"version": 2})
    assert config == {"version": 1}

    config = get_config(config=None, env_var='LOGGING', default={"version": 2})


# Generated at 2022-06-18 04:27:40.224612
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:27:48.109814
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-18 04:27:54.349001
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:00.931875
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:02.062620
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:28:07.112323
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:17.999432
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test with bare string
    assert get_config('test') == 'test'

    # Test with json string
    assert get_config(json.dumps({'test': 'test'})) == {'test': 'test'}

    # Test with yaml string
    assert get_config(yaml.dump({'test': 'test'})) == {'test': 'test'}

    # Test with dict
    assert get_config({'test': 'test'}) == {'test': 'test'}

    # Test with invalid string
    try:
        get_config('{test: test}')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')

    # Test with invalid dict

# Generated at 2022-06-18 04:28:20.539138
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:26.363105
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:29.724560
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
    logger.info("info message")
    with logger_level(logger, logging.INFO):
        logger.info("info message")
    logger.debug("debug message")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:28:31.372248
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')


# Generated at 2022-06-18 04:28:40.283589
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')


# Generated at 2022-06-18 04:28:47.225606
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG), default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG), default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG


# Generated at 2022-06-18 04:28:49.216082
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    logger.debug('debug message')


# Generated at 2022-06-18 04:28:55.297017
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug message')
        log.info('info message')
        log.warning('warning message')
        log.error('error message')
        log.critical('critical message')
    log.debug('debug message')
    log.info('info message')
    log.warning('warning message')
    log.error('error message')
    log.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:02.003139
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    with pytest.raises(ValueError):
        get_config()


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:29:06.456303
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:09.127825
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET


# Generated at 2022-06-18 04:29:10.406272
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:29:12.076601
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:14.670841
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:29:23.693229
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:29:28.937622
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
        log.info('test')
        log.warning('test')
        log.error('test')
        log.critical('test')
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')



# Generated at 2022-06-18 04:29:37.356494
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    assert get_config('test') == 'test'
    # Test with json string
    assert get_config('{"test": "test"}') == {'test': 'test'}
    # Test with yaml string
    assert get_config('test: test') == {'test': 'test'}
    # Test with dict
    assert get_config({'test': 'test'}) == {'test': 'test'}
    # Test with invalid string
    try:
        get_config('test: test: test')
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'
    # Test with invalid json string
    try:
        get_config('{"test": "test": "test"}')
    except ValueError:
        pass

# Generated at 2022-06-18 04:29:45.809667
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:29:48.023572
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:29:57.677967
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config='{"version": 1}', env_var=None, default=DEFAULT_CONFIG)
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == {"version": 1}

    config = get_config(config=None, env_var='LOGGING', default=None)
    assert config == DEFAULT_CONFIG


# Generated at 2022-06-18 04:30:00.282642
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:04.621761
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:30:14.384387
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    # config = get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    # assert config == DEFAULT_CONFIG
    # config = get_config(config=None, env_var=None, default=None)
    # assert config == None
    # config = get_config(config=None, env_var='LOGGING', default=None)
    # assert config == None
    # config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    # assert config == DEFAULT_CONFIG
    # config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING

# Generated at 2022-06-18 04:30:18.537206
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.info('This should not be logged')
        logger.error('This should be logged')
    logger.info('This should be logged')



# Generated at 2022-06-18 04:30:23.877273
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:30:27.765709
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:34.572260
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:39.150124
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')


# Generated at 2022-06-18 04:30:45.504263
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:51.047517
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:55.973788
# Unit test for function configure
def test_configure():
    import tempfile
    import os
    import json

    with tempfile.NamedTemporaryFile() as f:
        f.write(json.dumps(DEFAULT_CONFIG).encode('utf-8'))
        f.flush()
        os.environ['LOGGING'] = f.name
        configure()


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-18 04:31:03.024979
# Unit test for function configure
def test_configure():
    import os
    import tempfile
    import json
    import yaml
    import logging

    def test_config(config):
        with tempfile.NamedTemporaryFile(mode='w') as f:
            f.write(config)
            f.flush()
            os.environ['LOGGING'] = f.name
            configure()
            log = logging.getLogger(__name__)
            log.info('test')

    test_config('{"version": 1}')
    test_config(json.dumps({'version': 1}))
    test_config(yaml.dump({'version': 1}))


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-18 04:31:10.120208
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(logger, logging.INFO):
        logger.debug('This should not be printed')
        logger.info('This should be printed')

    logger.debug('This should be printed')
    logger.info('This should be printed')

    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be printed')
        logger.info('This should be printed')

    logger.debug('This should be printed')
    logger.info('This should be printed')


# Generated at 2022-06-18 04:31:14.465140
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        logger.debug('This should not be printed')
        logger.info('This should be printed')
    logger.debug('This should be printed')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:25.551787
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:32.919898
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:40.932661
# Unit test for function get_config
def test_get_config():
    import json
    import yaml


# Generated at 2022-06-18 04:31:42.678034
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:31:46.855232
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    with pytest.raises(ValueError):
        get_config()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:31:48.925642
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:55.489387
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:01.482276
# Unit test for function configure
def test_configure():
    import logging
    import os
    import tempfile
    import json
    import yaml


# Generated at 2022-06-18 04:32:04.343328
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:32:09.736905
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-18 04:32:23.507177
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:25.382285
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:32:34.185484
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=None, env_var='LOGGING', default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config='{"version": 1}', env_var=None, default=None)
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', env_var=None, default=DEFAULT_CONFIG)
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING', default=None)
    assert config == {"version": 1}


# Generated at 2022-06-18 04:32:35.513439
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:32:42.018093
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:32:49.430986
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:53.622935
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")


# Generated at 2022-06-18 04:32:55.672372
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:00.078411
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:33:03.890170
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
    logger.info("info message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:21.093028
# Unit test for function get_config
def test_get_config():
    # Test with a bare string
    assert get_config('{"version": 1}') == {"version": 1}

    # Test with a json string
    assert get_config('{"version": 1}') == {"version": 1}

    # Test with a yaml string
    assert get_config('version: 1') == {"version": 1}

    # Test with a dict
    assert get_config({"version": 1}) == {"version": 1}

    # Test with an invalid string
    try:
        get_config('{"version": 1')
        assert False
    except ValueError:
        pass

    # Test with an invalid string
    try:
        get_config('{"version": 1')
        assert False
    except ValueError:
        pass

    # Test with an invalid string

# Generated at 2022-06-18 04:33:25.949036
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:34.510246
# Unit test for function get_config
def test_get_config():
    # Test for get_config with default config
    config = get_config()
    assert config == DEFAULT_CONFIG

    # Test for get_config with given config

# Generated at 2022-06-18 04:33:40.657491
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:45.878243
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-18 04:33:52.976727
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:57.886214
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:04.581578
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:12.437647
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test for bare string
    cfg = get_config('test')
    assert cfg == 'test'

    # Test for json string
    cfg = get_config(json.dumps({'test': 'test'}))
    assert cfg == {'test': 'test'}

    # Test for yaml string
    cfg = get_config(yaml.dump({'test': 'test'}))
    assert cfg == {'test': 'test'}

    # Test for invalid string
    try:
        cfg = get_config('{test: test}')
        assert False
    except ValueError:
        assert True

    # Test for invalid string

# Generated at 2022-06-18 04:34:15.220763
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:34:31.087465
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config(None, None, None) is None
    assert get_config(None, None, {}) == {}
    assert get_config(None, None, {'a': 1}) == {'a': 1}
    assert get_config(None, None, '{}') == {}
    assert get_config(None, None, '{"a": 1}') == {'a': 1}
    assert get_config(None, None, 'a: 1') == {'a': 1}
    assert get_config(None, None, 'a: 1\nb: 2') == {'a': 1, 'b': 2}
    assert get_config(None, None, json.dumps({'a': 1})) == {'a': 1}

# Generated at 2022-06-18 04:34:33.974985
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.debug('This should not be printed')
        logger.error('This should be printed')
    logger.debug('This should be printed')
    logger.error('This should be printed')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:35.837428
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:34:40.138558
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('This should not be printed')
        logger.info('This should be printed')
    logger.debug('This should be printed')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:43.482260
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:44.955704
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug("This should not be printed")
        logger.info("This should be printed")
    logger.debug("This should be printed")


# Generated at 2022-06-18 04:34:48.441936
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    with pytest.raises(ValueError):
        get_config()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:34:50.625241
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:51.931285
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-18 04:34:53.847713
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:35:16.649636
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-18 04:35:18.295504
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:35:21.279621
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:35:29.049616
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)
    with logger_level(logger, logging.INFO):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:30.483985
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:35:36.375933
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger('test_logger_level')
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')



# Generated at 2022-06-18 04:35:40.430013
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:42.640502
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:35:48.699525
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')


# Generated at 2022-06-18 04:35:53.243092
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:36:11.724473
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:36:15.356649
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    logger.info('info message')
    with logger_level(logger, logging.INFO):
        logger.info('info message')
        logger.debug('debug message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:22.061438
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:24.127186
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:36:31.592595
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:35.170728
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')
    with logger_level(logger, logging.INFO):
        logger.info('test')
    logger.debug('test')



# Generated at 2022-06-18 04:36:38.909333
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:42.608893
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

