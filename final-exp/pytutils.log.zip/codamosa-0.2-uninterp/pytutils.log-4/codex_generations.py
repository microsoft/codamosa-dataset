

# Generated at 2022-06-18 04:26:53.653295
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug message')
        log.info('info message')

    log.debug('debug message')
    log.info('info message')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:01.312503
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:08.008260
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:10.303051
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:27:14.292660
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:16.474820
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')



# Generated at 2022-06-18 04:27:25.586662
# Unit test for function get_config
def test_get_config():
    # Test for bare config
    config = get_config(config='DEBUG', default=None)
    assert config == 'DEBUG'

    # Test for json config
    config = get_config(config='{"version": 1}', default=None)
    assert config == {'version': 1}

    # Test for yaml config
    config = get_config(config='version: 1', default=None)
    assert config == {'version': 1}

    # Test for invalid config
    try:
        get_config(config='invalid', default=None)
    except ValueError:
        pass
    else:
        assert False

    # Test for default config
    config = get_config(config=None, default='DEBUG')
    assert config == 'DEBUG'

    # Test for invalid config

# Generated at 2022-06-18 04:27:35.139811
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger('test_logger_level')
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

    # Test that the logger level is restored
    assert log.level == logging.DEBUG



# Generated at 2022-06-18 04:27:39.982917
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:47.445479
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    # Set up a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)

    # Test that the logger is working
    logger.debug('test')
    assert stream.getvalue() == 'test\n'

    # Test that the logger is not working
    with logger_level(logger, logging.INFO):
        logger.debug('test')
        assert stream.getvalue() == 'test\n'

    # Test that the logger is working again
    logger.debug('test')
    assert stream.getvalue() == 'test\ntest\n'

    # Test that the logger is not working

# Generated at 2022-06-18 04:28:03.105146
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import StringIO
    import contextlib

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = StringIO.StringIO(), StringIO.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)
        logger.addHandler(logging.StreamHandler())
        logger.debug('debug message')
        logger

# Generated at 2022-06-18 04:28:09.454932
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    config = get_config('{"version": 1}')
    assert config == {'version': 1}

    # Test with json string
    config = get_config('{"version": 1}')
    assert config == {'version': 1}

    # Test with yaml string
    config = get_config('version: 1')
    assert config == {'version': 1}

    # Test with dict
    config = get_config({'version': 1})
    assert config == {'version': 1}

    # Test with invalid config
    try:
        get_config(None)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'



# Generated at 2022-06-18 04:28:18.731497
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:21.621230
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("test_logger_level")
    logger.debug("test_logger_level")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:25.037529
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:29.492471
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:32.728410
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

# Generated at 2022-06-18 04:28:38.660448
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)
        logger.addHandler(logging.StreamHandler())
        logger.debug('This is a debug message')
        logger

# Generated at 2022-06-18 04:28:45.200510
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:51.530361
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:59.640758
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:29:05.059543
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:09.201018
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
        logger.info("This should not be logged")
    logger.info("This should be logged")
    logger.debug("This should not be logged")



# Generated at 2022-06-18 04:29:13.633225
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.debug('This should not be printed')
        logger.error('This should be printed')
    logger.debug('This should be printed')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:19.538242
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:21.161413
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:29:23.097523
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:29:30.088580
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be logged')
        logger.info('This should be logged')
        logger.warning('This should be logged')
        logger.error('This should be logged')
        logger.critical('This should be logged')
    logger.debug('This should NOT be logged')
    logger.info('This should NOT be logged')
    logger.warning('This should NOT be logged')
    logger.error('This should NOT be logged')
    logger.critical('This should NOT be logged')

# Generated at 2022-06-18 04:29:35.590234
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:29:39.133423
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:55.591708
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:01.664818
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    with logger_level(logger, logging.INFO):
        logger.info('test')
    with logger_level(logger, logging.WARNING):
        logger.warning('test')
    with logger_level(logger, logging.ERROR):
        logger.error('test')
    with logger_level(logger, logging.CRITICAL):
        logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:06.057147
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:09.402023
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET


# Generated at 2022-06-18 04:30:14.680341
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:19.413327
# Unit test for function configure
def test_configure():
    import json
    import tempfile

    with tempfile.NamedTemporaryFile(mode='w+') as f:
        json.dump(DEFAULT_CONFIG, f)
        f.flush()

        configure(f.name)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:30:24.833206
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("debug")
        log.info("info")
        log.warning("warning")
        log.error("error")
        log.critical("critical")
    log.debug("debug")
    log.info("info")
    log.warning("warning")
    log.error("error")
    log.critical("critical")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:30:29.207505
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))
    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

# Generated at 2022-06-18 04:30:33.887476
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:41.341637
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import StringIO

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

    # Test that the logger level is restored
    assert log.level == logging.DEBUG


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:10.099433
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be logged')
    logger.debug('This should not be logged')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:18.255455
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import inspect
    import sys
    import os
    from contextlib import contextmanager

    class _PyInfo(object):
        PY2 = sys.version_info[0] == 2
        PY3 = sys.version_info[0] == 3

        if PY3:
            string_types = str,
            text_type = str
            binary_type = bytes
        else:  # PY2
            string_types = basestring,
            text_type = unicode
            binary_type = str

    def _namespace_from_calling_context():
        """
        Derive a namespace from the module containing the caller's caller.

        :return: the fully qualified python name of a module.
        :rtype: str
        """
        # Not py3k compat
        #

# Generated at 2022-06-18 04:31:19.428786
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:31:20.827328
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:31:22.282327
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:31:24.899236
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:31:28.863996
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:37.063455
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    with pytest.raises(ValueError):
        get_config()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:31:41.433117
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:42.733648
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG


# Generated at 2022-06-18 04:32:15.388448
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:19.329976
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:24.564173
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("debug")
        log.info("info")
        log.warning("warning")
        log.error("error")
        log.critical("critical")
    log.debug("debug")
    log.info("info")
    log.warning("warning")
    log.error("error")
    log.critical("critical")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:32:29.368111
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    logger.debug('test_logger_level')
    with logger_level(logger, logging.INFO):
        logger.debug('test_logger_level')
    logger.debug('test_logger_level')

# Generated at 2022-06-18 04:32:36.180480
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

    # Test with a StringIO
    sio = io.StringIO()
    log.addHandler(logging.StreamHandler(sio))


# Generated at 2022-06-18 04:32:45.923506
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import inspect
    import sys
    import os
    from contextlib import contextmanager

    class _PyInfo(object):
        PY2 = sys.version_info[0] == 2
        PY3 = sys.version_info[0] == 3

        if PY3:
            string_types = str,
            text_type = str
            binary_type = bytes
        else:  # PY2
            string_types = basestring,
            text_type = unicode
            binary_type = str

    def _namespace_from_calling_context():
        """
        Derive a namespace from the module containing the caller's caller.

        :return: the fully qualified python name of a module.
        :rtype: str
        """
        # Not py3k compat
        #

# Generated at 2022-06-18 04:32:50.905945
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:54.865337
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")



# Generated at 2022-06-18 04:33:03.741217
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test with bare config
    bare_config = {'version': 1, 'disable_existing_loggers': False}
    assert get_config(bare_config) == bare_config

    # Test with json config
    json_config = json.dumps(bare_config)
    assert get_config(json_config) == bare_config

    # Test with yaml config
    yaml_config = yaml.dump(bare_config)
    assert get_config(yaml_config) == bare_config

    # Test with invalid config
    invalid_config = 'invalid config'
    try:
        get_config(invalid_config)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test with no config

# Generated at 2022-06-18 04:33:09.195292
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug message')
        log.info('info message')
        log.warning('warning message')
        log.error('error message')
        log.critical('critical message')
    log.debug('debug message')
    log.info('info message')
    log.warning('warning message')
    log.error('error message')
    log.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:12.026655
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:16.985232
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    log.debug('test')
    with logger_level(log, logging.INFO):
        log.debug('test')
    log.debug('test')



# Generated at 2022-06-18 04:34:23.192878
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG
    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG
    with pytest.raises(ValueError):
        get_config()


# Generated at 2022-06-18 04:34:30.543674
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    config = get_config(config='{"version": 1}')
    assert config == {"version": 1}

    # Test with JSON string
    config = get_config(config='{"version": 1}')
    assert config == {"version": 1}

    # Test with YAML string
    config = get_config(config='version: 1')
    assert config == {"version": 1}

    # Test with dict
    config = get_config(config={"version": 1})
    assert config == {"version": 1}

    # Test with invalid string
    try:
        get_config(config='{"version": 1')
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"

    # Test with invalid string

# Generated at 2022-06-18 04:34:33.205652
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:38.260052
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")
    with logger_level(logger, logging.INFO):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")


# Generated at 2022-06-18 04:34:41.683721
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:34:45.594877
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:34:49.166734
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:34:54.441726
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    with pytest.raises(ValueError):
        get_config()


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:36:07.749206
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)

    # Capture stdout
    stdout = sys.stdout
    sys.stdout = io.StringIO()

    # Test that the logger is at INFO level
    log.debug('this should not print')
    assert sys.stdout.getvalue() == ''

    # Test that the logger is at DEBUG level
    with logger_level(log, logging.DEBUG):
        log.debug('this should print')
        assert sys.stdout.getvalue() != ''

    # Test that the logger is at INFO level again
    log.debug('this should not print')
    assert sys.stdout.getvalue() != ''

    # Restore stdout
    sys.stdout = stdout

# Generated at 2022-06-18 04:36:12.567721
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:14.507434
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.debug('test')


# Generated at 2022-06-18 04:36:20.504679
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:36:25.224581
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:32.544155
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:38.640948
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    assert stream.getvalue() == 'info\nwarning\nerror\ncritical\n'

    stream.close()
    handler.close()



# Generated at 2022-06-18 04:36:41.911231
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET


if __name__ == '__main__':
    import doctest

    doctest.testmod()