

# Generated at 2022-06-18 04:26:53.481581
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-18 04:27:01.210623
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:27:05.139023
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.ERROR):
        log.debug('debug')
        log.info('info')
        log.error('error')
    log.debug('debug')
    log.info('info')
    log.error('error')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:07.971343
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("This should be logged")
        log.info("This should not be logged")
    log.info("This should be logged")
    log.debug("This should not be logged")


# Generated at 2022-06-18 04:27:09.681357
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:27:14.836472
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger('test_logger_level')
            self.logger.setLevel(logging.DEBUG)
            self.logger.addHandler(logging.StreamHandler(sys.stdout))

        def test_logger_level(self):
            with logger_level(self.logger, logging.INFO):
                self.logger.debug('debug')
                self.logger.info('info')
                self.logger.warning('warning')
                self.logger.error('error')
                self.logger.critical('critical')
            self.logger.debug('debug')

# Generated at 2022-06-18 04:27:15.920716
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

# Generated at 2022-06-18 04:27:17.675426
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.INFO)
    logger.info('test_logger_level')

    with logger_level(logger, logging.DEBUG):
        logger.debug('test_logger_level')
    logger.info('test_logger_level')

# Generated at 2022-06-18 04:27:24.128529
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-18 04:27:31.712405
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:40.310823
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:27:46.579137
# Unit test for function get_config
def test_get_config():
    assert get_config(default=None) is None
    assert get_config(default=1) == 1
    assert get_config(default=dict(a=1)) == dict(a=1)
    assert get_config(default=dict(a=1), env_var='LOGGING') == dict(a=1)
    assert get_config(default=dict(a=1), env_var='LOGGING', config=dict(b=2)) == dict(b=2)
    assert get_config(default=dict(a=1), env_var='LOGGING', config=dict(b=2)) == dict(b=2)
    assert get_config(default=dict(a=1), env_var='LOGGING', config=dict(b=2)) == dict(b=2)

# Generated at 2022-06-18 04:27:48.346206
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:27:52.407064
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:27:55.841690
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:58.897659
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:28:07.080479
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import inspect
    import sys
    import os

    from contextlib import contextmanager

    class _PyInfo(object):
        PY2 = sys.version_info[0] == 2
        PY3 = sys.version_info[0] == 3

        if PY3:
            string_types = str,
            text_type = str
            binary_type = bytes
        else:  # PY2
            string_types = basestring,
            text_type = unicode
            binary_type = str

    def _namespace_from_calling_context():
        """
        Derive a namespace from the module containing the caller's caller.

        :return: the fully qualified python name of a module.
        :rtype: str
        """
        # Not py3k compat
        #

# Generated at 2022-06-18 04:28:16.017569
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:21.532812
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
        log.info('test')
        log.warning('test')
        log.error('test')
        log.critical('test')
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')



# Generated at 2022-06-18 04:28:24.109619
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.debug('test')

# Generated at 2022-06-18 04:28:33.682847
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:28:36.364038
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
        logger.info("This should not be logged")
    logger.info("This should be logged")
    logger.debug("This should not be logged")

# Generated at 2022-06-18 04:28:43.621760
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:46.796820
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test_logger_level')


# Generated at 2022-06-18 04:28:49.403925
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-18 04:28:51.627591
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

# Generated at 2022-06-18 04:28:53.898605
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:57.369882
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        assert logger.level == logging.DEBUG
    logger.debug('test')
    assert logger.level == logging.DEBUG

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:00.979327
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    log.addHandler(logging.StreamHandler(sys.stdout))
    log.info('test')

    with logger_level(log, logging.DEBUG):
        log.debug('test')

    log.info('test')



# Generated at 2022-06-18 04:29:07.545586
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"version": 1}')
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING')
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', default={"version": 1})
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING', default={"version": 1})
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING', default={"version": 2})
    assert config == {"version": 1}


# Generated at 2022-06-18 04:29:18.946894
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG

# Generated at 2022-06-18 04:29:21.678095
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:29:23.060570
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-18 04:29:32.575828
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    assert config == DEFAULT_CONFIG


# Generated at 2022-06-18 04:29:41.375814
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import logging

    # Test with bare config

# Generated at 2022-06-18 04:29:43.053707
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

# Generated at 2022-06-18 04:29:44.727777
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

# Generated at 2022-06-18 04:29:47.150834
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:49.917744
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

# Generated at 2022-06-18 04:29:55.823209
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


# Generated at 2022-06-18 04:30:10.957135
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-18 04:30:18.676929
# Unit test for function get_config
def test_get_config():
    # Test for bare config
    config = get_config(config='{"version": 1}')
    assert config == {"version": 1}

    # Test for json config
    config = get_config(config='{"version": 1}')
    assert config == {"version": 1}

    # Test for yaml config
    config = get_config(config='version: 1')
    assert config == {"version": 1}

    # Test for invalid config
    try:
        get_config(config='{"version": 1')
    except ValueError:
        pass
    else:
        assert False


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:30:22.565386
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be printed")
        logger.info("This should not be printed")
    logger.info("This should be printed")
    logger.debug("This should not be printed")


# Generated at 2022-06-18 04:30:24.530079
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:32.875629
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import logging

    # Test with bare string
    config = 'test'
    assert get_config(config) == config

    # Test with json string
    config = json.dumps({'test': 'test'})
    assert get_config(config) == {'test': 'test'}

    # Test with yaml string
    config = yaml.dump({'test': 'test'})
    assert get_config(config) == {'test': 'test'}

    # Test with invalid string
    config = '{'
    try:
        get_config(config)
        assert False
    except ValueError:
        assert True

    # Test with invalid string
    config = '{'

# Generated at 2022-06-18 04:30:38.319253
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:44.197577
# Unit test for function logger_level
def test_logger_level():
    import logging
    import time
    import random
    import string
    import sys
    import os
    import tempfile
    import contextlib

    @contextlib.contextmanager
    def temp_file():
        fd, path = tempfile.mkstemp()
        os.close(fd)
        try:
            yield path
        finally:
            os.remove(path)

    def random_string(length=10):
        return ''.join(random.choice(string.ascii_letters) for _ in range(length))

    def test_logger_level_with_file(level):
        with temp_file() as path:
            logger = logging.getLogger(random_string())
            logger.setLevel(logging.DEBUG)
            handler = logging.FileHandler(path)

# Generated at 2022-06-18 04:30:46.702315
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:30:55.469335
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import inspect
    import sys
    import os

    from contextlib import contextmanager

    class _PyInfo(object):
        PY2 = sys.version_info[0] == 2
        PY3 = sys.version_info[0] == 3

        if PY3:
            string_types = str,
            text_type = str
            binary_type = bytes
        else:  # PY2
            string_types = basestring,
            text_type = unicode
            binary_type = str

    def _namespace_from_calling_context():
        """
        Derive a namespace from the module containing the caller's caller.

        :return: the fully qualified python name of a module.
        :rtype: str
        """
        # Not py3k compat
        #

# Generated at 2022-06-18 04:30:57.510083
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:31:08.763921
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:31:12.883328
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:16.206922
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:18.506996
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:31:21.838259
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        log.debug('This should not be printed')
        log.info('This should be printed')
    log.debug('This should be printed')
    log.info('This should be printed')



# Generated at 2022-06-18 04:31:32.677279
# Unit test for function get_config
def test_get_config():
    # Test for bare string
    assert get_config('test') == 'test'
    # Test for json string
    assert get_config('{"test": "test"}') == {'test': 'test'}
    # Test for yaml string
    assert get_config('test: test') == {'test': 'test'}
    # Test for invalid string
    try:
        get_config('invalid')
    except ValueError:
        pass
    else:
        raise AssertionError('Invalid string should raise ValueError')
    # Test for invalid json string
    try:
        get_config('{"invalid": "json"}')
    except ValueError:
        pass
    else:
        raise AssertionError('Invalid json string should raise ValueError')
    # Test for invalid yaml string

# Generated at 2022-06-18 04:31:40.034372
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:42.312697
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:43.699090
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')


# Generated at 2022-06-18 04:31:46.301217
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug message")
        logger.info("This is an info message")
        logger.warning("This is a warning message")
        logger.error("This is an error message")
        logger.critical("This is a critical message")


# Generated at 2022-06-18 04:31:59.646542
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:04.593281
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:07.315683
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')


# Generated at 2022-06-18 04:32:09.871917
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test_logger_level')
    logger.info('test_logger_level')

# Generated at 2022-06-18 04:32:12.604753
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:32:16.688145
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')

    log.debug('debug')
    log.info('info')



# Generated at 2022-06-18 04:32:19.895272
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:22.431094
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-18 04:32:28.660034
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:32.420704
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("This should be logged")
        log.info("This should not be logged")
    log.info("This should be logged")
    log.debug("This should not be logged")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:42.674215
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

# Generated at 2022-06-18 04:32:48.270250
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:50.791264
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:58.072519
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:33:01.356253
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-18 04:33:04.258320
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:09.417977
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:19.171613
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config(config=None, env_var=None, default=None) is None

    assert get_config(config=None, env_var='LOGGING', default=None) is None

    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG

    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=None) == DEFAULT_CONFIG

    assert get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None) == DEFAULT_CONFIG

    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG


# Generated at 2022-06-18 04:33:24.711020
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import os

    # Test with bare config

# Generated at 2022-06-18 04:33:27.378658
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:33:41.006635
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:33:46.575968
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:49.418434
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:33:53.812915
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')
    with logger_level(logger, logging.INFO):
        logger.info('test')
    logger.debug('test')


# Generated at 2022-06-18 04:34:00.125133
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None)
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

# Generated at 2022-06-18 04:34:06.151939
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:08.278447
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:34:11.093709
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')


# Generated at 2022-06-18 04:34:13.006250
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.DEBUG


# Generated at 2022-06-18 04:34:18.495534
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:34.610872
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test bare config
    bare_config = {'version': 1, 'formatters': {'simple': {'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s', 'datefmt': '%Y-%m-%d %H:%M:%S'}}, 'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'simple', 'level': 10}}, 'root': {'handlers': ['console'], 'level': 10}}
    assert get_config(bare_config) == bare_config

    # Test

# Generated at 2022-06-18 04:34:37.581525
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
    logger.debug('debug')
    logger.info('info')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:45.157824
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:34:46.847145
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:34:50.018007
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.info("This is a test")
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a test")
    logger.info("This is a test")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:34:53.148909
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:01.157777
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

# Generated at 2022-06-18 04:35:02.538960
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-18 04:35:05.711892
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:07.858607
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')



# Generated at 2022-06-18 04:35:32.409391
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:35:37.331625
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:38.556966
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-18 04:35:45.206626
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:53.929689
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"version": 1}')
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING')
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', default=DEFAULT_CONFIG)
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == {"version": 1}


# Generated at 2022-06-18 04:36:03.412226
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"version": 1}', env_var=None, default=None)
    assert config == {'version': 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING', default=None)
    assert config == {'version': 1}

    config = get_config(config=None, env_var='LOGGING', default=None)
    assert config == None

    config = get_config(config=None, env_var=None, default={"version": 1})
    assert config == {'version': 1}

    config = get_config(config=None, env_var=None, default=None)
    assert config == None


# Generated at 2022-06-18 04:36:07.749866
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-18 04:36:11.169437
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:16.138318
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:20.158126
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:36:41.969456
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()