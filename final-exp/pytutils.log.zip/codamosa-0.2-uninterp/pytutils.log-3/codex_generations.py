

# Generated at 2022-06-18 04:26:56.480868
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None)
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

# Generated at 2022-06-18 04:27:05.611746
# Unit test for function configure
def test_configure():
    import logging
    import os
    import tempfile
    import json
    import yaml

    # Test with a dict

# Generated at 2022-06-18 04:27:10.535274
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.debug('test')
    with logger_level(logger, logging.INFO):
        logger.debug('test')
    logger.debug('test')



# Generated at 2022-06-18 04:27:17.238981
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:26.009351
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

    # Test that the context manager works with a logger that has no handlers
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)


# Generated at 2022-06-18 04:27:32.485303
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:27:37.809594
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:43.345240
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:45.504320
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:27:49.360234
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:28:00.810499
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.debug('debug message')
    logger.info('info message')
    with logger_level(logger, logging.INFO):
        logger.debug('debug message')
        logger.info('info message')
    logger.debug('debug message')
    logger.info('info message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:08.397508
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config(None, None, None) is None
    assert get_config(None, None, {}) == {}
    assert get_config(None, None, {'a': 1}) == {'a': 1}
    assert get_config(None, None, '{"a": 1}') == {'a': 1}
    assert get_config(None, None, 'a: 1') == {'a': 1}
    assert get_config(None, None, json.dumps({'a': 1})) == {'a': 1}
    assert get_config(None, None, yaml.dump({'a': 1})) == {'a': 1}

    assert get_config(None, 'LOGGING', None) is None

# Generated at 2022-06-18 04:28:11.892845
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.debug('This should not be printed')
        logger.error('This should be printed')
    logger.debug('This should be printed')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:21.656297
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None)
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

# Generated at 2022-06-18 04:28:24.752511
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:28:26.099468
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    configure()
    logger.info('test')



# Generated at 2022-06-18 04:28:30.518129
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:35.210562
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    logger.debug('test_logger_level')
    with logger_level(logger, logging.INFO):
        logger.debug('test_logger_level')
    logger.debug('test_logger_level')



# Generated at 2022-06-18 04:28:38.396142
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:28:45.837670
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    logger.debug('test_logger_level_debug')
    logger.info('test_logger_level_info')
    with logger_level(logger, logging.INFO):
        logger.debug('test_logger_level_debug')
        logger.info('test_logger_level_info')
    logger.debug('test_logger_level_debug')
    logger.info('test_logger_level_info')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:52.486527
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:28:56.893877
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')



# Generated at 2022-06-18 04:29:02.428845
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:06.804012
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:13.082024
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-18 04:29:18.873731
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:24.321222
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:26.518028
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:29:35.456747
# Unit test for function get_config
def test_get_config():
    import json
    import yaml


# Generated at 2022-06-18 04:29:36.992927
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:29:48.376384
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:29:51.825759
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.debug("Before context")
    with logger_level(logger, logging.INFO):
        logger.debug("Inside context")
    logger.debug("After context")


# Generated at 2022-06-18 04:30:01.151147
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.DEBUG):
        log.debug('debug message')
        log.info('info message')

    log.debug('debug message')
    log.info('info message')

    # Test that the context manager restores the logger level
    assert log.level == logging.INFO

    # Test that the context manager only affects the specified logger
    log2 = logging.getLogger(__name__ + '2')
    log2.setLevel(logging.INFO)
    log2.addHandler(logging.StreamHandler(sys.stdout))


# Generated at 2022-06-18 04:30:04.144187
# Unit test for function configure
def test_configure():
    import logging
    import logging.config

    logging.config.dictConfig(DEFAULT_CONFIG)
    log = logging.getLogger(__name__)
    log.info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-18 04:30:10.537157
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:30:16.854904
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:21.910685
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:30:23.765480
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:30:29.209373
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test bare config
    assert get_config(config='bare') == 'bare'

    # Test json config
    assert get_config(config=json.dumps({'json': 'config'})) == {'json': 'config'}

    # Test yaml config
    assert get_config(config=yaml.dump({'yaml': 'config'})) == {'yaml': 'config'}

    # Test invalid config
    try:
        get_config(config=None)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:30:35.806884
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:30:46.426484
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    with pytest.raises(ValueError):
        get_config()



# Generated at 2022-06-18 04:30:48.684161
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')


# Generated at 2022-06-18 04:30:53.368383
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:30:56.242179
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:31:04.075312
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, None) == None
    assert get_config(None, None, DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(None, 'LOGGING', None) == None
    assert get_config(None, 'LOGGING', DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(DEFAULT_CONFIG, None, None) == DEFAULT_CONFIG
    assert get_config(DEFAULT_CONFIG, None, DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(DEFAULT_CONFIG, 'LOGGING', None) == DEFAULT_CONFIG
    assert get_config(DEFAULT_CONFIG, 'LOGGING', DEFAULT_CONFIG) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:31:05.378854
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:31:10.638281
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be logged')
        logger.info('This should be logged')
        logger.warning('This should be logged')
        logger.error('This should be logged')
        logger.critical('This should be logged')
    logger.debug('This should not be logged')
    logger.info('This should not be logged')
    logger.warning('This should not be logged')
    logger.error('This should not be logged')
    logger.critical('This should not be logged')



# Generated at 2022-06-18 04:31:18.718432
# Unit test for function get_config
def test_get_config():
    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:31:20.083382
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:31:22.027730
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:31:32.041808
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:31:36.488458
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("This should be logged")
        log.info("This should not be logged")
    log.info("This should be logged")
    log.debug("This should not be logged")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:42.813909
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Create a handler to write to stdout
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)

    # Create a formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # Add the formatter to the handler
    handler.setFormatter(formatter)

    # Add the handler to the logger
    logger.addHandler(handler)

    # Test the logger_level function
    with logger_level(logger, logging.INFO):
        logger.debug('debug message')

# Generated at 2022-06-18 04:31:46.250588
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:53.165551
# Unit test for function get_config
def test_get_config():
    # Test bare
    assert get_config(config='test') == 'test'

    # Test json
    assert get_config(config='{"test": "test"}') == {'test': 'test'}

    # Test yaml
    assert get_config(config='test: test') == {'test': 'test'}

    # Test invalid
    try:
        get_config(config=1)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:31:56.111225
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')


# Generated at 2022-06-18 04:31:59.774626
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:04.098680
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.debug('test')



# Generated at 2022-06-18 04:32:09.242112
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:32:15.590649
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:34.460341
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:36.883758
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')


# Generated at 2022-06-18 04:32:40.462647
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("test")
    logger.info("test")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:32:48.957243
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import logging

    # test bare
    cfg = get_config(default=DEFAULT_CONFIG)
    assert isinstance(cfg, dict)

    # test json
    cfg = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert isinstance(cfg, dict)

    # test yaml
    cfg = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert isinstance(cfg, dict)

    # test bad
    try:
        get_config(config='{')
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # test bad
    try:
        get_config(config='{')
    except ValueError:
        pass

# Generated at 2022-06-18 04:32:50.751057
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.DEBUG


# Generated at 2022-06-18 04:32:55.385163
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:57.705292
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:32:59.778068
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    logger.info('info message')
    logger.debug('debug message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:01.156691
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.debug('test')


# Generated at 2022-06-18 04:33:03.852908
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
    logger.debug("This should not be logged")


# Generated at 2022-06-18 04:33:36.351376
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:33:38.697995
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:33:41.329986
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-18 04:33:45.513254
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
        logger.info("This should not be logged")
    logger.info("This should be logged")
    logger.debug("This should not be logged")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:48.345325
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG



# Generated at 2022-06-18 04:33:54.024278
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:33:58.425409
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    log.debug('test')
    with logger_level(log, logging.INFO):
        log.debug('test')
    log.debug('test')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:34:02.710865
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:10.581439
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import StringIO
    import contextlib

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = StringIO.StringIO(), StringIO.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        logger = logging.getLogger('test')
        logger.setLevel(logging.INFO)
        logger.addHandler(logging.StreamHandler())

# Generated at 2022-06-18 04:34:19.592690
# Unit test for function get_config
def test_get_config():
    assert get_config(config=None, env_var=None, default=None) is None
    assert get_config(config=None, env_var='LOGGING', default=None) is None
    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:35:23.770250
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:29.434045
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:31.977353
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET



# Generated at 2022-06-18 04:35:36.682652
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:40.665572
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:46.577200
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:55.130083
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import os
    import sys
    import tempfile
    import json
    import yaml

    # test json

# Generated at 2022-06-18 04:36:03.445315
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
        logger.info("This should be logged")
        logger.warning("This should be logged")
        logger.error("This should be logged")
        logger.critical("This should be logged")
    logger.debug("This should not be logged")
    logger.info("This should not be logged")
    logger.warning("This should not be logged")
    logger.error("This should not be logged")
    logger.critical("This should not be logged")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:05.285873
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test_logger_level')


# Generated at 2022-06-18 04:36:07.713271
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()