

# Generated at 2022-06-18 04:26:56.007864
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    config = get_config(config='{"version": 1}')
    assert config['version'] == 1

    # Test with json string
    config = get_config(config='{"version": 1}')
    assert config['version'] == 1

    # Test with yaml string
    config = get_config(config='version: 1')
    assert config['version'] == 1

    # Test with dict
    config = get_config(config={'version': 1})
    assert config['version'] == 1

    # Test with invalid config
    try:
        get_config(config=1)
    except ValueError:
        pass
    else:
        assert False

    # Test with invalid json
    try:
        get_config(config='{"version": 1')
    except ValueError:
        pass

# Generated at 2022-06-18 04:26:58.414565
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:27:03.948192
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:27:06.446916
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
    logger.info("info message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:11.263612
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug message")
        logger.info("This is an info message")
        logger.warning("This is a warning message")
        logger.error("This is an error message")
        logger.critical("This is a critical message")
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:18.960292
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:20.986603
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:27:24.255488
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:31.759446
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:36.747851
# Unit test for function configure
def test_configure():
    import tempfile
    import json
    import os

    with tempfile.NamedTemporaryFile(mode='w') as f:
        f.write(json.dumps(DEFAULT_CONFIG))
        f.flush()
        os.environ['LOGGING'] = f.name
        configure()
        log = get_logger()
        log.info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-18 04:27:42.525195
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:27:44.310500
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:27:51.286823
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import inspect
    import sys
    import os

    from contextlib import contextmanager


    class _PyInfo(object):
        PY2 = sys.version_info[0] == 2
        PY3 = sys.version_info[0] == 3

        if PY3:
            string_types = str,
            text_type = str
            binary_type = bytes
        else:  # PY2
            string_types = basestring,
            text_type = unicode
            binary_type = str


    def _namespace_from_calling_context():
        """
        Derive a namespace from the module containing the caller's caller.

        :return: the fully qualified python name of a module.
        :rtype: str
        """
        # Not py3k compat


# Generated at 2022-06-18 04:27:56.563537
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    log.addHandler(handler)

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

    assert stream.getvalue() == 'debug\ninfo\nwarning\nerror\ncritical\n'

    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    log.addHandler(handler)


# Generated at 2022-06-18 04:28:03.152624
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:07.746924
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-18 04:28:18.139001
# Unit test for function get_config
def test_get_config():
    assert get_config(default={'a': 1}) == {'a': 1}
    assert get_config(config={'a': 1}) == {'a': 1}
    assert get_config(config='{"a": 1}') == {'a': 1}
    assert get_config(config='a: 1') == {'a': 1}
    assert get_config(env_var='LOGGING', default={'a': 1}) == {'a': 1}
    assert get_config(env_var='LOGGING', config='{"a": 1}') == {'a': 1}
    assert get_config(env_var='LOGGING', config='a: 1') == {'a': 1}
    assert get_config(env_var='LOGGING', default={'a': 1}) == {'a': 1}

# Generated at 2022-06-18 04:28:23.952410
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:26.429921
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:31.037933
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:42.520132
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("debug")
        log.info("info")
        log.warning("warning")
        log.error("error")
        log.critical("critical")
    log.debug("debug")
    log.info("info")
    log.warning("warning")
    log.error("error")
    log.critical("critical")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:48.058116
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG


# Generated at 2022-06-18 04:28:53.193448
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:28:58.472815
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:29:04.156051
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:11.519347
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')


# Generated at 2022-06-18 04:29:20.489883
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, None) is None
    assert get_config(None, 'LOGGING', None) is None
    assert get_config(None, None, DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(DEFAULT_CONFIG, None, None) == DEFAULT_CONFIG
    assert get_config(DEFAULT_CONFIG, 'LOGGING', None) == DEFAULT_CONFIG
    assert get_config(DEFAULT_CONFIG, None, DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(DEFAULT_CONFIG, 'LOGGING', DEFAULT_CONFIG) == DEFAULT_CONFIG

    assert get_config(json.dumps(DEFAULT_CONFIG), None, None) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:29:22.470283
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG



# Generated at 2022-06-18 04:29:28.101716
# Unit test for function get_config

# Generated at 2022-06-18 04:29:34.518827
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.debug("debug")
    logger.info("info")
    with logger_level(logger, logging.INFO):
        logger.debug("debug")
        logger.info("info")
    logger.debug("debug")
    logger.info("info")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:29:41.596832
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test_logger_level')
    logger.info('test_logger_level')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:45.907622
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:29:53.073500
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
        logger.info("This should be logged")
        logger.warning("This should be logged")
        logger.error("This should be logged")
        logger.critical("This should be logged")
    logger.debug("This should not be logged")
    logger.info("This should not be logged")
    logger.warning("This should not be logged")
    logger.error("This should not be logged")
    logger.critical("This should not be logged")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:58.982954
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:01.292698
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:30:03.445334
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:30:08.962289
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
        logger.info("This should not be logged")
    logger.info("This should be logged")
    logger.debug("This should not be logged")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:10.956707
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

# Generated at 2022-06-18 04:30:12.363726
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:30:13.721145
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:30:19.142571
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:30:21.326749
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-18 04:30:23.226541
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG



# Generated at 2022-06-18 04:30:25.522101
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test2')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:29.360601
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:36.628253
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:39.392883
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:42.578070
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:45.161129
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')


# Generated at 2022-06-18 04:30:48.601553
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("test_logger_level")
    logger.debug("test_logger_level")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:55.893659
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be printed")
        logger.info("This should not be printed")
    logger.info("This should be printed")
    logger.debug("This should not be printed")

# Generated at 2022-06-18 04:30:58.277317
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:31:00.206712
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.debug('test')


# Generated at 2022-06-18 04:31:05.335387
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:09.629529
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
        log.info('test')
        log.warning('test')
        log.error('test')
        log.critical('test')
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')


# Generated at 2022-06-18 04:31:11.862526
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')


# Generated at 2022-06-18 04:31:15.727045
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:20.500064
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:26.191840
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:32.029385
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    with logger_level(logger, logging.INFO):
        logger.debug("This should not be printed")
        logger.info("This should be printed")

    logger.debug("This should be printed")
    logger.info("This should be printed")



# Generated at 2022-06-18 04:31:40.747694
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:41.926378
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:31:43.892735
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("test_logger_level")
    logger.info("test_logger_level")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:45.857704
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")
    logger.info("info message")

# Generated at 2022-06-18 04:31:48.876512
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:53.635308
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        log.debug('This should not be logged')
        log.info('This should be logged')
    log.debug('This should be logged')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:58.816433
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    with pytest.raises(ValueError):
        get_config()



# Generated at 2022-06-18 04:32:09.487706
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config=None, env_var='LOGGING', default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config=None, env_var=None, default=None)
    assert config is None

    config = get_config(config='{"version": 1}', env_var=None, default=None)
    assert config == {"version": 1}

    config = get_config(config='version: 1', env_var=None, default=None)

# Generated at 2022-06-18 04:32:12.764480
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')



# Generated at 2022-06-18 04:32:15.140701
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:28.286816
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)

        def test_logger_level(self):
            with logger_level(self.logger, logging.INFO):
                self.logger.debug('debug')
                self.logger.info('info')
                self.logger.warning('warning')
                self.logger.error('error')


# Generated at 2022-06-18 04:32:30.238566
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')



# Generated at 2022-06-18 04:32:34.908282
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:41.185673
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    config = {'a': 1}
    assert get_config(config) == config

    config = json.dumps(config)
    assert get_config(config) == json.loads(config)

    config = yaml.dump(config)
    assert get_config(config) == yaml.load(config)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:32:46.840477
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
        log.info('test')
        log.warning('test')
        log.error('test')
        log.critical('test')
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:51.684091
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:54.158990
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:59.590807
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:04.719894
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('this should not be logged')
        logger.info('this should be logged')
    logger.debug('this should be logged')
    logger.info('this should be logged')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:14.050424
# Unit test for function get_config
def test_get_config():
    config = get_config(config="""
    version: 1
    disable_existing_loggers: False
    formatters:
      simple:
        format: '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s'
        datefmt: '%Y-%m-%d %H:%M:%S'
    handlers:
      console:
        class: logging.StreamHandler
        formatter: simple
        level: DEBUG
    root:
      handlers: [console]
      level: DEBUG
    loggers:
      requests:
        level: INFO
    """)

# Generated at 2022-06-18 04:33:25.603867
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
    logger.debug('debug')
    logger.info('info')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:30.153297
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:33:32.575902
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:33:41.265929
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:33:43.313730
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:33:49.724162
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:52.943911
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')


# Generated at 2022-06-18 04:33:55.326939
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.debug('test')



# Generated at 2022-06-18 04:33:59.208810
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:01.321514
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-18 04:34:14.242176
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:34:18.562535
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')



# Generated at 2022-06-18 04:34:20.404451
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should print")
        logger.info("This should not print")
    logger.info("This should print")
    logger.debug("This should not print")


# Generated at 2022-06-18 04:34:21.761223
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-18 04:34:26.675126
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:34:28.593402
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:34:31.951259
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:33.486889
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG



# Generated at 2022-06-18 04:34:41.503515
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    with logger_level(logger, logging.INFO):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:47.135211
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:34:59.732610
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:35:05.181396
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:07.824617
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:35:12.042539
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:14.313308
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:35:17.445509
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:20.381012
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:35:28.423940
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    config = get_config(config='{"version": 1}')
    assert config == {'version': 1}

    # Test with json string
    config = get_config(config='{"version": 1}')
    assert config == {'version': 1}

    # Test with yaml string
    config = get_config(config='version: 1')
    assert config == {'version': 1}

    # Test with dict
    config = get_config(config={'version': 1})
    assert config == {'version': 1}

    # Test with invalid config
    try:
        get_config(config=None)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'



# Generated at 2022-06-18 04:35:35.932227
# Unit test for function configure
def test_configure():
    import json
    import yaml
    import logging
    import logging.config

    # Test with a bare dict

# Generated at 2022-06-18 04:35:38.987069
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('debug message')
        log.info('info message')
        log.warning('warning message')
        log.error('error message')
        log.critical('critical message')
    log.info('info message')

# Generated at 2022-06-18 04:35:52.785512
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:35:59.683370
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    from contextlib import contextmanager

    @contextmanager
    def logger_level(logger, level):
        """Set logger level to `level` within a context block. Don't use this except for debugging please, it's gross."""
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    logger = logging.getLogger(__name__)
    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.setLevel(logging.DEBUG)

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

    with logger_level(logger, logging.WARNING):
        logger.debug('debug')

# Generated at 2022-06-18 04:36:04.854450
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:36:07.548105
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.info('test')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

# Generated at 2022-06-18 04:36:11.832441
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    config = {'a': 1}
    assert get_config(config) == config

    config = json.dumps(config)
    assert get_config(config) == json.loads(config)

    config = yaml.dump(config)
    assert get_config(config) == yaml.load(config)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:36:20.995302
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:36:23.442268
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:36:24.931711
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.debug('test')


# Generated at 2022-06-18 04:36:32.264583
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.info("This is a test")
    with logger_level(logger, logging.DEBUG):
        logger.info("This is a test")
        logger.debug("This is a test")
    logger.info("This is a test")
    logger.debug("This is a test")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:34.420295
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("test_logger_level")