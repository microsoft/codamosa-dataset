

# Generated at 2022-06-18 04:26:48.879618
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')


# Generated at 2022-06-18 04:26:53.553504
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:27:01.311786
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:04.024641
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:06.013626
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:27:13.679075
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:27:17.307323
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:27:23.675184
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:27:35.139164
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    # Test that the logger is not logging at the level we want to test
    with logger_level(logger, logging.INFO):
        logger.debug('This should not be logged')

    # Test that the logger is logging at the level we want to test
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be logged')

    # Test that the logger is not logging at the level we want to test
    with logger_level(logger, logging.INFO):
        logger.debug('This should not be logged')

    # Test that the logger is logging at the level we want to test


# Generated at 2022-06-18 04:27:39.889852
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:45.505706
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:27:49.333836
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:51.319026
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:27:56.584776
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING')
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG), env_var='LOGGING')
    assert config == DEFAULT_CONFIG


# Generated at 2022-06-18 04:28:05.890286
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test with bare string
    config = 'test'
    assert get_config(config) == config

    # Test with json string
    config = json.dumps({'test': 'test'})
    assert get_config(config) == json.loads(config)

    # Test with yaml string
    config = yaml.dump({'test': 'test'})
    assert get_config(config) == yaml.load(config)

    # Test with invalid string
    config = 'test'
    try:
        get_config(config)
    except ValueError:
        pass
    else:
        assert False

    # Test with invalid json string
    config = '{test: test}'
    try:
        get_config(config)
    except ValueError:
        pass

# Generated at 2022-06-18 04:28:09.130740
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:11.428420
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-18 04:28:14.365979
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.debug('test')


# Generated at 2022-06-18 04:28:20.942219
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:24.357300
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    logger.info('info message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:31.995618
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:38.335377
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:28:44.948318
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:47.970383
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:28:50.110374
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:28:52.960598
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET

# Generated at 2022-06-18 04:28:54.399872
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:28:59.292658
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:01.339154
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:29:05.907636
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:10.849687
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:16.479605
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:19.307584
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:21.632137
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:29:24.060985
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:29.734135
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug message")
    logger.info("This is an info message")
    with logger_level(logger, logging.INFO):
        logger.info("This is an info message")
        logger.debug("This is a debug message")
    logger.debug("This is a debug message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:35.252868
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:41.159970
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:46.074302
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:48.023338
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-18 04:30:00.938346
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import inspect
    import sys
    import os
    from contextlib import contextmanager

    class _PyInfo(object):
        PY2 = sys.version_info[0] == 2
        PY3 = sys.version_info[0] == 3

        if PY3:
            string_types = str,
            text_type = str
            binary_type = bytes
        else:  # PY2
            string_types = basestring,
            text_type = unicode
            binary_type = str

    def _namespace_from_calling_context():
        """
        Derive a namespace from the module containing the caller's caller.

        :return: the fully qualified python name of a module.
        :rtype: str
        """
        # Not py3k compat
        #

# Generated at 2022-06-18 04:30:03.123505
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:30:09.715715
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("debug")
        log.info("info")
        log.warning("warning")
        log.error("error")
        log.critical("critical")
    log.debug("debug")
    log.info("info")
    log.warning("warning")
    log.error("error")
    log.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:12.770145
# Unit test for function logger_level
def test_logger_level():
    import logging
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    log.info('test')

    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.debug('test')



# Generated at 2022-06-18 04:30:19.011197
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:23.740133
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

# Generated at 2022-06-18 04:30:25.521738
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:30:34.224533
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config(config=None, env_var=None, default=None) is None
    assert get_config(config=None, env_var='LOGGING', default=None) is None
    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG

    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG


# Generated at 2022-06-18 04:30:35.665611
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:30:40.473458
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-18 04:30:49.072538
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')



# Generated at 2022-06-18 04:30:51.009046
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:30:54.307872
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:02.484270
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def test_logger_level(self):
            with logger_level(self.logger, logging.INFO):
                self.logger.debug('debug')
                self.logger.info('info')
                self.logger.warning('warning')
                self.logger.error('error')
                self.logger.critical('critical')


# Generated at 2022-06-18 04:31:04.307916
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:31:11.182665
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    assert get_config('test') == 'test'

    # Test with json string
    assert get_config('{"test": "test"}') == {'test': 'test'}

    # Test with yaml string
    assert get_config('test: test') == {'test': 'test'}

    # Test with dict
    assert get_config({'test': 'test'}) == {'test': 'test'}

    # Test with invalid string
    try:
        get_config('test')
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"

    # Test with invalid json string
    try:
        get_config('{"test": "test"')
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"



# Generated at 2022-06-18 04:31:19.174069
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:31:20.828030
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

# Generated at 2022-06-18 04:31:22.090055
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

# Generated at 2022-06-18 04:31:26.699973
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    assert get_config('test') == 'test'

    # Test with json string
    assert get_config('{"test": "test"}') == {'test': 'test'}

    # Test with yaml string
    assert get_config('test: test') == {'test': 'test'}

    # Test with dict
    assert get_config({'test': 'test'}) == {'test': 'test'}

    # Test with invalid config
    try:
        get_config(None)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:31:42.433523
# Unit test for function get_config
def test_get_config():
    # Test for config as None
    assert get_config(config=None) is None

    # Test for config as string
    assert get_config(config='{"version": 1}') == {'version': 1}

    # Test for config as dict
    assert get_config(config={'version': 1}) == {'version': 1}

    # Test for config as invalid string
    try:
        get_config(config='{"version": 1')
        assert False
    except ValueError:
        assert True

    # Test for config as invalid dict
    try:
        get_config(config={'version': 1, 'disable_existing_loggers': 'True'})
        assert False
    except TypeError:
        assert True


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:31:45.864010
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:48.898327
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:52.391739
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:31:58.112986
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be logged')
        logger.info('This should be logged')
        logger.warning('This should be logged')
        logger.error('This should be logged')
        logger.critical('This should be logged')
    logger.debug('This should not be logged')
    logger.info('This should not be logged')
    logger.warning('This should not be logged')
    logger.error('This should not be logged')
    logger.critical('This should not be logged')



# Generated at 2022-06-18 04:32:08.739955
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG), default=DEFAULT_CONFIG) == DEFAULT_CONFIG

    with pytest.raises(ValueError):
        get_config()

    with pytest.raises(ValueError):
        get_config(config='{')

    with pytest.raises(ValueError):
        get_config(config='{}')


# Generated at 2022-06-18 04:32:11.996230
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("test_logger_level")


# Generated at 2022-06-18 04:32:18.584720
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(default=DEFAULT_CONFIG, env_var='LOGGING')
    assert config == DEFAULT_CONFIG

    config = get_config(default=DEFAULT_CONFIG, env_var='LOGGING_NOT_SET')
    assert config == DEFAULT_CONFIG

    config = get_config(
        given=json.dumps(DEFAULT_CONFIG),
        env_var='LOGGING_NOT_SET',
    )
    assert config == DEFAULT_CONFIG

    config = get_config(
        given=yaml.dump(DEFAULT_CONFIG),
        env_var='LOGGING_NOT_SET',
    )

# Generated at 2022-06-18 04:32:20.121663
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')



# Generated at 2022-06-18 04:32:24.955621
# Unit test for function configure
def test_configure():
    import tempfile
    import json
    import os

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        f.write(json.dumps(DEFAULT_CONFIG))
        f.close()
        os.environ['LOGGING'] = f.name
        configure()
        os.unlink(f.name)


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-18 04:32:39.704441
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.debug('test')
    with logger_level(logger, logging.INFO):
        logger.debug('test')
    logger.debug('test')

# Generated at 2022-06-18 04:32:41.700698
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

# Generated at 2022-06-18 04:32:47.326786
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:54.684077
# Unit test for function get_config
def test_get_config():
    import json
    import yaml


# Generated at 2022-06-18 04:32:58.982545
# Unit test for function configure
def test_configure():
    import tempfile
    import json
    import os

    with tempfile.NamedTemporaryFile(mode='w') as f:
        f.write(json.dumps(DEFAULT_CONFIG))
        f.flush()
        os.environ['LOGGING'] = f.name
        configure()
        log = get_logger()
        log.info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-18 04:33:03.271827
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('This should not be printed')
        logger.info('This should be printed')
    logger.debug('This should be printed')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:07.417159
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:13.934433
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:19.602148
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:21.696490
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:33:36.212346
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:33:40.531426
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

# Generated at 2022-06-18 04:33:49.680390
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    config = get_config('{"version": 1}')
    assert config == {'version': 1}

    # Test with json string
    config = get_config('{"version": 1}')
    assert config == {'version': 1}

    # Test with yaml string
    config = get_config('version: 1')
    assert config == {'version': 1}

    # Test with dict
    config = get_config({'version': 1})
    assert config == {'version': 1}

    # Test with None
    try:
        get_config(None)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test with invalid string
    try:
        get_config('invalid')
    except ValueError:
        pass

# Generated at 2022-06-18 04:33:52.905602
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:33:58.053677
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:07.785775
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"version": 1}')
    assert config == {'version': 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING')
    assert config == {'version': 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING', default={'version': 2})
    assert config == {'version': 1}

    config = get_config(config=None, env_var='LOGGING', default={'version': 2})
    assert config == {'version': 2}

    config = get_config(config=None, env_var=None, default={'version': 2})
    assert config == {'version': 2}


# Generated at 2022-06-18 04:34:14.946948
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"version": 1}')
    assert config == {'version': 1}

    config = get_config(config='version: 1')
    assert config == {'version': 1}

    config = get_config(config='version: 1', default={'version': 2})
    assert config == {'version': 1}

    config = get_config(config='version: 1', env_var='LOGGING', default={'version': 2})
    assert config == {'version': 1}

    config = get_config(config='version: 1', env_var='LOGGING')
    assert config == {'version': 1}

    config = get_config(config='version: 1', env_var='LOGGING', default={'version': 2})
    assert config == {'version': 1}

    config

# Generated at 2022-06-18 04:34:16.442346
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:34:24.961345
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"version": 1}', env_var=None, default=None)
    assert config == {"version": 1}

    config = get_config(config=None, env_var='LOGGING', default=None)
    assert config == {"version": 1}

    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config='{"version": 2}', env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == {"version": 2}

    config = get_config(config='{"version": 3}', env_var=None, default=DEFAULT_CONFIG)
    assert config == {"version": 3}


# Generated at 2022-06-18 04:34:29.614701
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:55.578341
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:35:01.809027
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


# Generated at 2022-06-18 04:35:04.360916
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:35:10.798944
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:15.159627
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

# Generated at 2022-06-18 04:35:16.732288
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')


# Generated at 2022-06-18 04:35:20.181640
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")


# Generated at 2022-06-18 04:35:22.726864
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
    logger.debug('debug')
    logger.info('info')



# Generated at 2022-06-18 04:35:31.443778
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import logging
    import logging.config
    import os

    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger(__name__)

    # Test with bare config
    cfg = get_config(default=DEFAULT_CONFIG)
    assert isinstance(cfg, dict)
    assert cfg['version'] == 1
    assert cfg['disable_existing_loggers'] == False

# Generated at 2022-06-18 04:35:34.712992
# Unit test for function get_config
def test_get_config():
    # Test for bare config
    assert get_config(config='bare') == 'bare'

    # Test for json config
    assert get_config(config='{"json": "config"}') == {'json': 'config'}

    # Test for yaml config
    assert get_config(config='yaml: config') == {'yaml': 'config'}

    # Test for invalid config
    try:
        get_config(config='invalid')
    except ValueError:
        pass
    else:
        assert False, 'Invalid config should raise ValueError'


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:35:59.992703
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger()
    log.info('test')


# Generated at 2022-06-18 04:36:08.042145
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    import sys
    import os

    from contextlib import contextmanager


# Generated at 2022-06-18 04:36:11.794303
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.error('test')
    logger.debug('test')
    logger.info('test')
    logger.error('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:16.490446
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:21.884994
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:26.213439
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:33.552343
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    logger.debug('test_logger_level')
    with logger_level(logger, logging.INFO):
        logger.debug('test_logger_level')
    logger.debug('test_logger_level')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:36.321145
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')


# Generated at 2022-06-18 04:36:41.479766
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

