

# Generated at 2022-06-18 04:26:53.264052
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:26:55.474568
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:27:04.848363
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(handler)

        def test_logger_level(self):
            with logger_level(self.logger, logging.INFO):
                self.logger.debug('debug')
                self.logger.info('info')
            self.logger.debug('debug')
            self.logger.info('info')

# Generated at 2022-06-18 04:27:16.170638
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test for bare config

# Generated at 2022-06-18 04:27:22.609209
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:27:26.405114
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:36.518378
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    import sys
    import os

    from contextlib import contextmanager


# Generated at 2022-06-18 04:27:40.942628
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:27:42.766723
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG



# Generated at 2022-06-18 04:27:45.379568
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:54.515694
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:27:57.019771
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:28:04.684639
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import StringIO

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug("This should not print")
        log.info("This should print")
        log.warning("This should print")

    log.debug("This should print")
    log.info("This should print")
    log.warning("This should print")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:09.269140
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:28:19.379920
# Unit test for function configure
def test_configure():
    import json
    import yaml
    import logging

    # Test with a bare config

# Generated at 2022-06-18 04:28:27.394069
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:29.161181
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:28:32.403744
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:38.515572
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config(None, None, None) is None

    assert get_config(None, None, {}) == {}

    assert get_config(None, None, {'a': 1}) == {'a': 1}

    assert get_config(None, None, json.dumps({'a': 1})) == {'a': 1}

    assert get_config(None, None, yaml.dump({'a': 1})) == {'a': 1}

    assert get_config(None, None, '{"a": 1}') == {'a': 1}

    assert get_config(None, None, 'a: 1') == {'a': 1}

    assert get_config(None, None, '{"a": 1') is None


# Generated at 2022-06-18 04:28:42.482018
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:28:51.624608
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")



# Generated at 2022-06-18 04:28:54.080839
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')


# Generated at 2022-06-18 04:28:59.011149
# Unit test for function configure
def test_configure():
    import tempfile
    import os
    import json
    import logging

    with tempfile.NamedTemporaryFile(mode='w+') as f:
        f.write(json.dumps(DEFAULT_CONFIG))
        f.flush()
        os.environ['LOGGING'] = f.name
        configure()

        log = logging.getLogger(__name__)
        log.info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-18 04:29:00.797013
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-18 04:29:05.458877
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:08.017018
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')


# Generated at 2022-06-18 04:29:17.725250
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    config = get_config(config='{"version": 1}')
    assert config == {'version': 1}

    # Test with json string
    config = get_config(config='{"version": 1}')
    assert config == {'version': 1}

    # Test with yaml string
    config = get_config(config='version: 1')
    assert config == {'version': 1}

    # Test with dict
    config = get_config(config={'version': 1})
    assert config == {'version': 1}

    # Test with invalid string
    try:
        config = get_config(config='{"version": 1')
        assert False
    except ValueError:
        assert True

    # Test with invalid string

# Generated at 2022-06-18 04:29:18.842013
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:29:21.269737
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-18 04:29:23.203478
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')



# Generated at 2022-06-18 04:29:30.735471
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET


# Generated at 2022-06-18 04:29:33.028117
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:29:38.929683
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:44.361696
# Unit test for function get_config
def test_get_config():
    # Test for function get_config
    # Case 1: config is None
    assert get_config(config=None) == DEFAULT_CONFIG

    # Case 2: config is a string
    assert get_config(config='{"version": 1}') == {'version': 1}

    # Case 3: config is a dict
    assert get_config(config={'version': 1}) == {'version': 1}

    # Case 4: config is a list
    assert get_config(config=[1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-18 04:29:46.449577
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should print")
        logger.info("This should not print")
    logger.info("This should print")
    logger.debug("This should not print")



# Generated at 2022-06-18 04:29:49.012384
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:55.832221
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:01.259266
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:07.261123
# Unit test for function get_config
def test_get_config():
    # Test for bare config
    assert get_config(config='test') == 'test'

    # Test for json config
    assert get_config(config='{"test": "test"}') == {'test': 'test'}

    # Test for yaml config
    assert get_config(config='test: test') == {'test': 'test'}

    # Test for invalid config
    try:
        get_config(config=1)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test for invalid json config
    try:
        get_config(config='{test: test}')
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test for invalid yaml config

# Generated at 2022-06-18 04:30:12.258033
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:30:21.567821
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-18 04:30:27.306527
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(DEFAULT_CONFIG, None, None) == DEFAULT_CONFIG
    assert get_config(DEFAULT_CONFIG, None, DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(DEFAULT_CONFIG, 'LOGGING', None) == DEFAULT_CONFIG
    assert get_config(DEFAULT_CONFIG, 'LOGGING', DEFAULT_CONFIG) == DEFAULT_CONFIG

    assert get_config(None, 'LOGGING', DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(None, 'LOGGING', None) == DEFAULT_CONFIG

    assert get_config(None, None, None) == None


# Generated at 2022-06-18 04:30:36.741329
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config(None, None, None) is None
    assert get_config(None, None, {}) == {}
    assert get_config(None, None, {'a': 1}) == {'a': 1}

    assert get_config(None, 'LOGGING', None) is None
    assert get_config(None, 'LOGGING', {}) == {}
    assert get_config(None, 'LOGGING', {'a': 1}) == {'a': 1}

    assert get_config({'a': 1}, None, None) == {'a': 1}
    assert get_config({'a': 1}, None, {}) == {'a': 1}
    assert get_config({'a': 1}, None, {'b': 2}) == {'a': 1}



# Generated at 2022-06-18 04:30:41.165002
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:30:44.293312
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:49.422670
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:30:51.639703
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG



# Generated at 2022-06-18 04:30:54.348781
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:30:59.804742
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:01.707794
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:31:23.571877
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:29.715413
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG

    with pytest.raises(ValueError):
        get_config()



# Generated at 2022-06-18 04:31:35.241395
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:31:37.329480
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:31:41.405485
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:44.730905
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')
    with logger_level(logger, logging.INFO):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:47.766650
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

# Generated at 2022-06-18 04:31:50.073255
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:53.675154
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:32:00.393106
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"version": 1}')
    assert config == {"version": 1}

    config = get_config(config='version: 1')
    assert config == {"version": 1}

    config = get_config(config='version: 1', default={"version": 2})
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', default={"version": 2})
    assert config == {"version": 1}

    config = get_config(config='version: 1', default={"version": 2}, env_var='LOGGING')
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', default={"version": 2}, env_var='LOGGING')
    assert config == {"version": 1}

    os.environ

# Generated at 2022-06-18 04:32:21.158905
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
        log.info('test')
        log.warning('test')
        log.error('test')
        log.critical('test')
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')



# Generated at 2022-06-18 04:32:26.961253
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:33.006586
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:36.818088
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:42.400763
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


# Generated at 2022-06-18 04:32:50.617662
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import inspect
    import sys
    import os

    from contextlib import contextmanager

    class _PyInfo(object):
        PY2 = sys.version_info[0] == 2
        PY3 = sys.version_info[0] == 3

        if PY3:
            string_types = str,
            text_type = str
            binary_type = bytes
        else:  # PY2
            string_types = basestring,
            text_type = unicode
            binary_type = str

    def _namespace_from_calling_context():
        """
        Derive a namespace from the module containing the caller's caller.

        :return: the fully qualified python name of a module.
        :rtype: str
        """
        # Not py3k compat
        #

# Generated at 2022-06-18 04:32:55.097006
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:57.325060
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:33:06.339052
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import os

    # Test for bare string
    config = 'bare string'
    assert get_config(config) == config

    # Test for json string
    config = json.dumps({'json': 'string'})
    assert get_config(config) == {'json': 'string'}

    # Test for yaml string
    config = yaml.dump({'yaml': 'string'})
    assert get_config(config) == {'yaml': 'string'}

    # Test for env var
    os.environ['LOGGING'] = 'env var'
    assert get_config(env_var='LOGGING') == 'env var'
    del os.environ['LOGGING']

    # Test for default

# Generated at 2022-06-18 04:33:12.673774
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:53.703261
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug message")
    logger.info("This is an info message")
    with logger_level(logger, logging.INFO):
        logger.debug("This is a debug message")
    logger.info("This is an info message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:59.135956
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
        logger.info("This should be logged")
        logger.warning("This should be logged")
        logger.error("This should be logged")
        logger.critical("This should be logged")
    logger.debug("This should not be logged")
    logger.info("This should not be logged")
    logger.warning("This should not be logged")
    logger.error("This should not be logged")
    logger.critical("This should not be logged")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:34:05.889007
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:11.188713
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:34:17.722072
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    config = get_config(config='{"version": 1}')
    assert config == {'version': 1}

    # Test with json string
    config = get_config(config='{"version": 1}')
    assert config == {'version': 1}

    # Test with yaml string
    config = get_config(config='version: 1')
    assert config == {'version': 1}

    # Test with dict
    config = get_config(config={'version': 1})
    assert config == {'version': 1}

    # Test with invalid config
    try:
        get_config(config=1)
    except ValueError:
        pass
    else:
        assert False, 'get_config should raise ValueError'



# Generated at 2022-06-18 04:34:19.992981
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:22.637902
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:34:27.957353
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:29.643682
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:34:35.568060
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:35:54.139630
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:03.646790
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test get_config with no config
    assert get_config() == DEFAULT_CONFIG

    # Test get_config with a config
    config = {'foo': 'bar'}
    assert get_config(config) == config

    # Test get_config with a config as a string
    config = json.dumps(config)
    assert get_config(config) == json.loads(config)

    # Test get_config with a config as a string
    config = yaml.dump(config)
    assert get_config(config) == yaml.load(config)

    # Test get_config with a config as a string
    config = '{foo: bar}'
    assert get_config(config) == json.loads(config)

    # Test get_config with a config as a string


# Generated at 2022-06-18 04:36:10.978048
# Unit test for function get_config
def test_get_config():
    assert get_config(default={'a': 1}) == {'a': 1}
    assert get_config(config={'a': 1}) == {'a': 1}
    assert get_config(config='{"a": 1}') == {'a': 1}
    assert get_config(config='a: 1') == {'a': 1}
    assert get_config(env_var='LOGGING', default={'a': 1}) == {'a': 1}
    assert get_config(env_var='LOGGING', config={'a': 1}) == {'a': 1}
    assert get_config(env_var='LOGGING', config='{"a": 1}') == {'a': 1}
    assert get_config(env_var='LOGGING', config='a: 1') == {'a': 1}

# Generated at 2022-06-18 04:36:15.679114
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:20.572981
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
    logger.debug('debug')
    logger.info('info')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:26.211815
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug message")
        logger.info("This is an info message")
        logger.warning("This is a warning message")
        logger.error("This is an error message")
        logger.critical("This is a critical message")
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:31.035429
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:36:35.171071
# Unit test for function get_config
def test_get_config():
    assert get_config(default='{"version": 1}') == {"version": 1}
    assert get_config(default='{"version": 1}') == {"version": 1}
    assert get_config(default='{"version": 1}') == {"version": 1}


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:36:39.931030
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')

    with logger_level(logger, logging.WARNING):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')

# Generated at 2022-06-18 04:36:43.552796
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()