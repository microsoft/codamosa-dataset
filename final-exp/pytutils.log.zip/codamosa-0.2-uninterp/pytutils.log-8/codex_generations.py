

# Generated at 2022-06-18 04:26:51.043117
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:26:57.382419
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:06.318007
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:27:15.507546
# Unit test for function logger_level
def test_logger_level():
    import logging
    import tempfile
    import os

    with tempfile.NamedTemporaryFile() as f:
        logging.basicConfig(filename=f.name, level=logging.DEBUG)
        logger = logging.getLogger(__name__)
        logger.debug('test')
        with logger_level(logger, logging.INFO):
            logger.debug('test')
            logger.info('test')
        logger.debug('test')
        with open(f.name, 'r') as f:
            assert f.read() == 'test\ntest\n'



# Generated at 2022-06-18 04:27:17.685009
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:27:24.375786
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:35.214377
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG), default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG), env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG), env_var='LOGGING') == DE

# Generated at 2022-06-18 04:27:39.493723
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        log.debug('test')
        log.info('test')
        log.warning('test')
        log.error('test')
        log.critical('test')
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')



# Generated at 2022-06-18 04:27:43.438101
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:27:48.065920
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:58.524461
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    logger.info('info message')
    with logger_level(logger, logging.INFO):
        logger.debug('debug message')
    logger.info('info message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:04.146002
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
        log.info('test')
        log.warning('test')
        log.error('test')
        log.critical('test')
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:10.725827
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    config = {'a': 1}
    assert get_config(config) == config

    config = json.dumps(config)
    assert get_config(config) == {'a': 1}

    config = yaml.dump(config)
    assert get_config(config) == {'a': 1}

    config = '{"a": 1}'
    assert get_config(config) == {'a': 1}

    config = 'a: 1'
    assert get_config(config) == {'a': 1}

    config = '{"a": 1'
    assert get_config(config) == {'a': 1}

    config = 'a: 1'
    assert get_config(config) == {'a': 1}

    config = '{"a": 1'

# Generated at 2022-06-18 04:28:14.467100
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:16.938098
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')



# Generated at 2022-06-18 04:28:26.030778
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import os

    # test for bare config
    config = 'test'
    assert get_config(config) == config

    # test for json config
    config = json.dumps({'test': 'test'})
    assert get_config(config) == {'test': 'test'}

    # test for yaml config
    config = yaml.dump({'test': 'test'})
    assert get_config(config) == {'test': 'test'}

    # test for env var
    os.environ['LOGGING'] = config
    assert get_config(env_var='LOGGING') == {'test': 'test'}

    # test for default config
    assert get_config(default={'test': 'test'}) == {'test': 'test'}

    #

# Generated at 2022-06-18 04:28:31.584819
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:36.325071
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:43.585470
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:53.231562
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:29:00.508191
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:02.179898
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

# Generated at 2022-06-18 04:29:04.017668
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG



# Generated at 2022-06-18 04:29:06.932583
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:29:10.064168
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-18 04:29:13.713214
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')


# Generated at 2022-06-18 04:29:17.192068
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')


# Generated at 2022-06-18 04:29:22.768281
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:32.001889
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:29:40.808331
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test bare config
    bare_config = {'version': 1}
    assert get_config(bare_config) == bare_config

    # Test json config
    json_config = json.dumps(bare_config)
    assert get_config(json_config) == bare_config

    # Test yaml config
    yaml_config = yaml.dump(bare_config)
    assert get_config(yaml_config) == bare_config

    # Test invalid config
    invalid_config = '{version: 1}'
    try:
        get_config(invalid_config)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test invalid config
    invalid_config = '{version: 1}'

# Generated at 2022-06-18 04:29:51.422089
# Unit test for function logger_level
def test_logger_level():
    import logging
    import StringIO
    import sys

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('This should not appear')
        log.info('This should appear')

    log.debug('This should appear')
    log.info('This should appear')


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:29:57.639267
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')


# Generated at 2022-06-18 04:30:02.836704
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:06.130217
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug message")
    logger.info("This is an info message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:16.034261
# Unit test for function get_config
def test_get_config():
    # Test case 1:
    # Given: config is None, env_var is None, default is None
    # Expect: ValueError
    config = None
    env_var = None
    default = None
    try:
        get_config(config, env_var, default)
    except ValueError:
        pass
    else:
        assert False

    # Test case 2:
    # Given: config is None, env_var is None, default is not None
    # Expect: default
    config = None
    env_var = None
    default = DEFAULT_CONFIG
    assert get_config(config, env_var, default) == default

    # Test case 3:
    # Given: config is None, env_var is not None, default is None
    # Expect: ValueError
    config = None

# Generated at 2022-06-18 04:30:21.406794
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:30:23.160432
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug message")
    logger.debug("This is a debug message")


# Generated at 2022-06-18 04:30:26.350366
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:28.155073
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:30:29.770431
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:30:40.574332
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:46.391550
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:49.269013
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:57.778154
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def capture_stdout():
        old = sys.stdout
        capturer = io.StringIO()
        sys.stdout = capturer
        try:
            yield capturer
        finally:
            sys.stdout = old

    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)

    with capture_stdout() as capturer:
        logger.debug('test')
        assert 'test' in capturer.getvalue()

    with capture_stdout() as capturer:
        with logger_level(logger, logging.INFO):
            logger.debug('test')
            assert 'test' not in capturer.getvalue()


# Generated at 2022-06-18 04:31:04.006823
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:05.647693
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:31:07.837232
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:31:09.908604
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:31:12.295535
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    logger.info('info message')
    logger.error('error message')


# Generated at 2022-06-18 04:31:15.737229
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:31:25.088084
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:33.597170
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug message")
        logger.info("This is an info message")
        logger.warning("This is a warning message")
        logger.error("This is an error message")
        logger.critical("This is a critical message")
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")



# Generated at 2022-06-18 04:31:41.432214
# Unit test for function logger_level
def test_logger_level():
    # Set up logger
    logger = get_logger()
    logger.setLevel(logging.DEBUG)

    # Set up handler
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    # Set up formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # Test logger_level
    with logger_level(logger, logging.INFO):
        logger.debug('This is a debug message')
        logger.info('This is an info message')
    logger.debug('This is a debug message')
    logger.info('This is an info message')


# Generated at 2022-06-18 04:31:43.753093
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:46.549537
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG



# Generated at 2022-06-18 04:31:55.168638
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"version": 1}')
    assert config == {'version': 1}

    config = get_config(config='{"version": 1}', default={'version': 2})
    assert config == {'version': 1}

    config = get_config(config='{"version": 1}', default={'version': 2}, env_var='LOGGING')
    assert config == {'version': 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING')
    assert config == {'version': 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING', default={'version': 2})
    assert config == {'version': 1}


# Generated at 2022-06-18 04:31:59.561250
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:04.185120
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:32:12.388918
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    with pytest.raises(ValueError):
        get_config()


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:32:14.524091
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:32:21.982540
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')


# Generated at 2022-06-18 04:32:24.511973
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    logger.info('info message')

# Generated at 2022-06-18 04:32:30.761312
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:35.333759
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:38.940743
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:32:44.461639
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:52.493742
# Unit test for function configure
def test_configure():
    import logging
    import sys
    import os
    import tempfile
    import json
    import yaml
    import os

    # Test with default config
    configure()
    log = logging.getLogger(__name__)
    log.info('test')

    # Test with json config
    json_config = json.dumps(DEFAULT_CONFIG)
    configure(json_config)
    log = logging.getLogger(__name__)
    log.info('test')

    # Test with yaml config
    yaml_config = yaml.dump(DEFAULT_CONFIG)
    configure(yaml_config)
    log = logging.getLogger(__name__)
    log.info('test')

    # Test with config file

# Generated at 2022-06-18 04:32:53.824152
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:32:55.901664
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:32:59.695476
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:16.140340
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:18.136013
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:33:22.797126
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:24.425122
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:33:33.612419
# Unit test for function get_config
def test_get_config():
    # Test for bare string
    config = get_config('test')
    assert config == 'test'

    # Test for json string
    config = get_config('{"test": "test"}')
    assert config == {"test": "test"}

    # Test for yaml string
    config = get_config('test: test')
    assert config == {"test": "test"}

    # Test for invalid string
    try:
        get_config('test')
    except ValueError:
        pass
    else:
        assert False, "Should raise ValueError"

    # Test for invalid string
    try:
        get_config('{"test": "test"')
    except ValueError:
        pass
    else:
        assert False, "Should raise ValueError"

    # Test for invalid string

# Generated at 2022-06-18 04:33:38.192747
# Unit test for function logger_level
def test_logger_level():
    """
    >>> log = get_logger()
    >>> with logger_level(log, logging.DEBUG):
    ...     log.debug('test')
    ...     log.info('test')
    ...     log.warning('test')
    ...     log.error('test')
    ...     log.critical('test')
    """



# Generated at 2022-06-18 04:33:40.201869
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:33:49.569828
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import unittest

    class TestLoggerLevel(unittest.TestCase):

        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def test_logger_level(self):
            self.logger.debug('debug')
            self.logger.info('info')
            self.logger.warning('warning')
            self.logger.error('error')
            self.logger.critical('critical')

# Generated at 2022-06-18 04:33:56.104703
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:04.238121
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    with pytest.raises(ValueError):
        get_config()



# Generated at 2022-06-18 04:34:18.560825
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:24.041518
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')


# Generated at 2022-06-18 04:34:27.525878
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:34:31.082014
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:34:33.033784
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.INFO)

    with logger_level(logger, logging.DEBUG):
        logger.debug('test')

    assert logger.level == logging.INFO

# Generated at 2022-06-18 04:34:34.131157
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger()
    log.info('test')


# Generated at 2022-06-18 04:34:38.213162
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:34:46.644577
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:50.018636
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

# Generated at 2022-06-18 04:34:52.246231
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:12.736864
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-18 04:35:15.874589
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:35:19.391967
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:35:28.413204
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    assert get_config(config='{"version": 1}') == {"version": 1}

    # Test with json string
    assert get_config(config='{"version": 1}') == {"version": 1}

    # Test with yaml string
    assert get_config(config='version: 1') == {"version": 1}

    # Test with dict
    assert get_config(config={"version": 1}) == {"version": 1}

    # Test with invalid string
    try:
        get_config(config='{"version": 1')
    except ValueError:
        pass
    else:
        assert False, "Should have raised ValueError"

    # Test with invalid string
    try:
        get_config(config='{"version": 1')
    except ValueError:
        pass

# Generated at 2022-06-18 04:35:32.582369
# Unit test for function get_config
def test_get_config():
    assert get_config(config=None, env_var=None, default=None) is None
    assert get_config(config=None, env_var='LOGGING', default=None) is None
    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:35:36.958043
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.debug('debug')
    logger.info('info')
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
    logger.debug('debug')
    logger.info('info')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:40.856897
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:43.281099
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')



# Generated at 2022-06-18 04:35:51.284841
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:55.219042
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

# Generated at 2022-06-18 04:36:36.845773
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import os

    # Test with bare string
    config = 'test'
    assert get_config(config) == config

    # Test with json string
    config = json.dumps({'test': 'test'})
    assert get_config(config) == json.loads(config)

    # Test with yaml string
    config = yaml.dump({'test': 'test'})
    assert get_config(config) == yaml.load(config)

    # Test with env var
    os.environ['TEST_LOGGING'] = 'test'
    assert get_config(env_var='TEST_LOGGING') == 'test'

    # Test with default
    assert get_config(default={'test': 'test'}) == {'test': 'test'}

    # Test

# Generated at 2022-06-18 04:36:44.057566
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger('test_logger_level')
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def test_logger_level(self):
            self.logger.debug('debug')
            self.logger.info('info')
            self.logger.warning('warning')
            self.logger.error('error')
            self.logger.critical('critical')
