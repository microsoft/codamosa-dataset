

# Generated at 2022-06-18 04:26:51.843004
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:26:57.297407
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.INFO)
    logger.info('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test_logger_level')
    logger.info('test_logger_level')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:06.284059
# Unit test for function get_config
def test_get_config():
    # Test with json config
    json_config = '{"version": 1, "disable_existing_loggers": false, "formatters": {"simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": 10}}, "root": {"handlers": ["console"], "level": 10}, "loggers": {"requests": {"level": 20}}}'

# Generated at 2022-06-18 04:27:14.766237
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:17.643605
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        assert logger.level == logging.DEBUG
    logger.debug('test')
    assert logger.level == logging.DEBUG



# Generated at 2022-06-18 04:27:24.374555
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:27:35.248528
# Unit test for function configure
def test_configure():
    import tempfile
    import json

    # Test with json
    with tempfile.NamedTemporaryFile(mode='w') as f:
        json.dump(DEFAULT_CONFIG, f)
        f.flush()
        configure(config=f.name)
        log = get_logger()
        log.info('test')

    # Test with yaml
    with tempfile.NamedTemporaryFile(mode='w') as f:
        import yaml

        yaml.dump(DEFAULT_CONFIG, f)
        f.flush()
        configure(config=f.name)
        log = get_logger()
        log.info('test')

    # Test with dict
    configure(config=DEFAULT_CONFIG)
    log = get_logger()
    log.info('test')


# Unit test

# Generated at 2022-06-18 04:27:41.253806
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    logger = logging.getLogger('test')
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    assert stream.getvalue() == 'info\nwarning\nerror\ncritical\n'

    stream.close()
    handler.close()



# Generated at 2022-06-18 04:27:46.463988
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:52.104021
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, None) is None
    assert get_config(None, None, {}) == {}
    assert get_config(None, None, {'a': 1}) == {'a': 1}
    assert get_config(None, 'LOGGING', None) is None
    assert get_config(None, 'LOGGING', {}) == {}
    assert get_config(None, 'LOGGING', {'a': 1}) == {'a': 1}
    assert get_config({'a': 1}, None, None) == {'a': 1}
    assert get_config({'a': 1}, None, {}) == {'a': 1}
    assert get_config({'a': 1}, None, {'a': 2}) == {'a': 1}

# Generated at 2022-06-18 04:27:58.665804
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:28:01.133093
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:28:06.217679
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:08.308121
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-18 04:28:14.755040
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:21.046148
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:23.567781
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

# Generated at 2022-06-18 04:28:26.616980
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug("This should not be printed")
        logger.info("This should be printed")
    logger.debug("This should be printed")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:30.550765
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


# Generated at 2022-06-18 04:28:37.857573
# Unit test for function get_config
def test_get_config():
    assert get_config(default={'a': 1}) == {'a': 1}
    assert get_config(config={'a': 1}) == {'a': 1}
    assert get_config(config='{"a": 1}') == {'a': 1}
    assert get_config(config='a: 1') == {'a': 1}
    assert get_config(env_var='LOGGING', default={'a': 1}) == {'a': 1}
    assert get_config(env_var='LOGGING', config={'a': 1}) == {'a': 1}
    assert get_config(env_var='LOGGING', config='{"a": 1}') == {'a': 1}
    assert get_config(env_var='LOGGING', config='a: 1') == {'a': 1}

# Generated at 2022-06-18 04:28:51.435666
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:59.303050
# Unit test for function configure
def test_configure():
    import tempfile
    import json
    import os
    import logging

    log = logging.getLogger(__name__)

    with tempfile.NamedTemporaryFile(mode='w') as f:
        f.write(json.dumps(DEFAULT_CONFIG))
        f.flush()
        os.environ['LOGGING'] = f.name
        configure()
        log.info('test')

    with tempfile.NamedTemporaryFile(mode='w') as f:
        f.write(json.dumps(DEFAULT_CONFIG))
        f.flush()
        os.environ['LOGGING'] = f.name
        configure()
        log.info('test')


# Generated at 2022-06-18 04:29:04.700510
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:07.807968
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:29:13.312936
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

# Generated at 2022-06-18 04:29:16.848094
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET



# Generated at 2022-06-18 04:29:19.014162
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
    logger.debug("This should not be logged")

# Generated at 2022-06-18 04:29:26.177916
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import os

    os.environ['LOGGING'] = json.dumps(DEFAULT_CONFIG)
    assert get_config(env_var='LOGGING') == DEFAULT_CONFIG

    os.environ['LOGGING'] = yaml.dump(DEFAULT_CONFIG)
    assert get_config(env_var='LOGGING') == DEFAULT_CONFIG

    os.environ['LOGGING'] = '{}'
    assert get_config(env_var='LOGGING') == {}

    os.environ['LOGGING'] = '---'
    assert get_config(env_var='LOGGING') == {}

    os.environ['LOGGING'] = '{'

# Generated at 2022-06-18 04:29:28.288505
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:29:34.442230
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:46.254234
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    logger = logging.getLogger('test')
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.error('error')
    logger.debug('debug')
    logger.info('info')
    logger.error('error')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:55.347599
# Unit test for function get_config
def test_get_config():
    assert get_config(config=None, env_var=None, default=None) is None
    assert get_config(config=None, env_var='LOGGING', default=None) is None
    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:30:02.358877
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:03.381456
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:30:05.886006
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug("This should not be logged")
        logger.info("This should be logged")
    logger.debug("This should be logged")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:11.716380
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:30:13.687738
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')



# Generated at 2022-06-18 04:30:14.785409
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:30:24.263383
# Unit test for function get_config
def test_get_config():
    import json


# Generated at 2022-06-18 04:30:29.347687
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    config = get_config('{"version": 1}')
    assert config == {'version': 1}

    # Test with json string
    config = get_config('{"version": 1}')
    assert config == {'version': 1}

    # Test with yaml string
    config = get_config('version: 1')
    assert config == {'version': 1}

    # Test with default
    config = get_config(default={'version': 1})
    assert config == {'version': 1}

    # Test with env var
    os.environ['LOGGING'] = '{"version": 1}'
    config = get_config(env_var='LOGGING')
    assert config == {'version': 1}

    # Test with given config

# Generated at 2022-06-18 04:30:40.889081
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:43.029324
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:30:48.874211
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug message')
        log.info('info message')
        log.warning('warning message')
        log.error('error message')
        log.critical('critical message')
    log.debug('debug message')
    log.info('info message')
    log.warning('warning message')
    log.error('error message')
    log.critical('critical message')


# Generated at 2022-06-18 04:30:51.418375
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:56.669185
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:31:04.472822
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG), default=None)
    assert config == DEFAULT_CONFIG


# Generated at 2022-06-18 04:31:13.090741
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config='{"version": 1}', default=DEFAULT_CONFIG)
    assert config == {"version": 1}

    config = get_config(config='version: 1', default=DEFAULT_CONFIG)
    assert config == {"version": 1}

    config = get_config(config='version: 1', env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == {"version": 1}

    config = get_config(config='{"version": 1}', env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == {"version": 1}

    config = get_config(config='version: 1', env_var='LOGGING')
    assert config

# Generated at 2022-06-18 04:31:17.308199
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:31:24.072982
# Unit test for function get_config
def test_get_config():
    # Test for bare string
    assert get_config('test') == 'test'

    # Test for json string
    assert get_config('{"test": "test"}') == {'test': 'test'}

    # Test for yaml string
    assert get_config('test: test') == {'test': 'test'}

    # Test for invalid string
    try:
        get_config('{test: test}')
    except ValueError:
        pass
    else:
        assert False, 'ValueError not raised'

    # Test for invalid string
    try:
        get_config('test: test')
    except ValueError:
        pass
    else:
        assert False, 'ValueError not raised'

    # Test for invalid string
    try:
        get_config('test')
    except ValueError:
        pass
   

# Generated at 2022-06-18 04:31:31.524795
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:48.710467
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test with bare string
    config = '{"version": 1, "formatters": {"simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}}}'
    assert get_config(config) == json.loads(config)

    # Test with json string

# Generated at 2022-06-18 04:31:51.874340
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:31:59.276487
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import StringIO

    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    # Test that the logger is not logging at the INFO level
    with logger_level(logger, logging.INFO):
        logger.debug('This should not be logged')
        logger.info('This should be logged')

    # Test that the logger is logging at the DEBUG level
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be logged')
        logger.info('This should be logged')

    # Test that the logger is logging at the DEBUG level
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be logged')
       

# Generated at 2022-06-18 04:32:03.114710
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

# Generated at 2022-06-18 04:32:08.395405
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        logger.debug('This should not be printed')
        logger.info('This should be printed')
    logger.debug('This should be printed')
    logger.info('This should be printed')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:16.990566
# Unit test for function get_config
def test_get_config():
    # Test with bare config
    config = get_config(default='DEBUG')
    assert config == 'DEBUG'

    # Test with json config
    config = get_config(default='{"version": 1}')
    assert config == {"version": 1}

    # Test with yaml config
    config = get_config(default='version: 1')
    assert config == {"version": 1}

    # Test with invalid config
    try:
        get_config(default='invalid')
        assert False
    except ValueError:
        pass

    # Test with invalid config
    try:
        get_config(default='{"invalid": "json"}')
        assert False
    except ValueError:
        pass

    # Test with invalid config

# Generated at 2022-06-18 04:32:24.304265
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    assert get_config(config='test') == 'test'

    # Test with json string
    assert get_config(config='{"test": "test"}') == {'test': 'test'}

    # Test with yaml string
    assert get_config(config='test: test') == {'test': 'test'}

    # Test with dict
    assert get_config(config={'test': 'test'}) == {'test': 'test'}

    # Test with no config
    assert get_config() == DEFAULT_CONFIG

    # Test with env var
    os.environ['LOGGING'] = '{"test": "test"}'
    assert get_config(env_var='LOGGING') == {'test': 'test'}
    del os.environ['LOGGING']

   

# Generated at 2022-06-18 04:32:25.934148
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

# Generated at 2022-06-18 04:32:29.431327
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:32:33.729546
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:33:07.183372
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
        logger.info("This should be logged")
        logger.warning("This should be logged")
        logger.error("This should be logged")
        logger.critical("This should be logged")
    logger.debug("This should not be logged")
    logger.info("This should not be logged")
    logger.warning("This should not be logged")
    logger.error("This should not be logged")
    logger.critical("This should not be logged")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:33:10.711661
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:13.182224
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:33:20.159556
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    assert get_config('test') == 'test'

    # Test with json string
    assert get_config('{"test": "test"}') == {"test": "test"}

    # Test with yaml string
    assert get_config('test: test') == {"test": "test"}

    # Test with dict
    assert get_config({"test": "test"}) == {"test": "test"}

    # Test with invalid config
    try:
        get_config(None)
        assert False
    except ValueError:
        pass


if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-18 04:33:22.332858
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.debug('test')


# Generated at 2022-06-18 04:33:27.666704
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:33.212688
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:38.849226
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:33:44.952029
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:47.145729
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:34:47.713207
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:34:49.488071
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    logger.info('info message')



# Generated at 2022-06-18 04:34:55.695408
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var='LOGGING') == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG), env_var='LOGGING') == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG), env_var='LOGGING') == DEFAULT_CONFIG

# Generated at 2022-06-18 04:35:05.559104
# Unit test for function get_config
def test_get_config():
    assert get_config(config=None, env_var=None, default=None) is None
    assert get_config(config=None, env_var='LOGGING', default=None) is None
    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:35:12.325594
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:15.387717
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:35:16.973407
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:35:18.386079
# Unit test for function get_config
def test_get_config():
    config = get_config(env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG


# Generated at 2022-06-18 04:35:27.732845
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')

    with logger_level(logger, logging.INFO):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')

    with logger_level(logger, logging.WARNING):
        logger.debug('debug message')
        logger

# Generated at 2022-06-18 04:35:33.034594
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')


if __name__ == '__main__':
    test_logger_level()