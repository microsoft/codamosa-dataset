

# Generated at 2022-06-18 04:26:55.799827
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("Debug message")
        logger.info("Info message")
        logger.warning("Warning message")
        logger.error("Error message")
        logger.critical("Critical message")
    logger.debug("Debug message")
    logger.info("Info message")
    logger.warning("Warning message")
    logger.error("Error message")
    logger.critical("Critical message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:26:58.623994
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:27:07.187961
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"version": 1}')
    assert config['version'] == 1

    config = get_config(config='version: 1')
    assert config['version'] == 1

    config = get_config(config='{"version": 1}', env_var='LOGGING')
    assert config['version'] == 1

    config = get_config(config='version: 1', env_var='LOGGING')
    assert config['version'] == 1

    config = get_config(config='{"version": 1}', default=DEFAULT_CONFIG)
    assert config['version'] == 1

    config = get_config(config='version: 1', default=DEFAULT_CONFIG)
    assert config['version'] == 1


# Generated at 2022-06-18 04:27:12.430329
# Unit test for function get_config
def test_get_config():
    assert get_config(default={'a': 1}) == {'a': 1}
    assert get_config(config={'a': 1}) == {'a': 1}
    assert get_config(config='{"a": 1}') == {'a': 1}
    assert get_config(config='a: 1') == {'a': 1}
    assert get_config(config='a: 1', default={'b': 2}) == {'a': 1}
    assert get_config(config='a: 1', env_var='LOGGING') == {'a': 1}
    assert get_config(config='a: 1', env_var='LOGGING', default={'b': 2}) == {'a': 1}

# Generated at 2022-06-18 04:27:23.325281
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import inspect
    import sys

    from contextlib import contextmanager

    class _PyInfo(object):
        PY2 = sys.version_info[0] == 2
        PY3 = sys.version_info[0] == 3

        if PY3:
            string_types = str,
            text_type = str
            binary_type = bytes
        else:  # PY2
            string_types = basestring,
            text_type = unicode
            binary_type = str

    def _namespace_from_calling_context():
        """
        Derive a namespace from the module containing the caller's caller.

        :return: the fully qualified python name of a module.
        :rtype: str
        """
        # Not py3k compat
        # return inspect.current

# Generated at 2022-06-18 04:27:24.955020
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:27:27.521980
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:27:34.612724
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:40.838525
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    config = {'a': 1}
    assert get_config(config) == config

    config = json.dumps(config)
    assert get_config(config) == json.loads(config)

    config = yaml.dump(config)
    assert get_config(config) == yaml.load(config)

    config = 'not a valid config'
    try:
        get_config(config)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:27:48.286331
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test bare string
    assert get_config('test') == 'test'

    # Test json string
    assert get_config(json.dumps({'test': 'test'})) == {'test': 'test'}

    # Test yaml string
    assert get_config(yaml.dump({'test': 'test'})) == {'test': 'test'}

    # Test invalid string
    try:
        get_config('{test: test}')
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test invalid string
    try:
        get_config('test: test')
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test invalid type

# Generated at 2022-06-18 04:28:02.183440
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:28:04.607379
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("test_logger_level")
    logger.info("test_logger_level")



# Generated at 2022-06-18 04:28:09.721447
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:18.337986
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    with pytest.raises(ValueError):
        get_config()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-18 04:28:21.519959
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
        logger.info("This should not be logged")
    logger.info("This should be logged")
    logger.debug("This should not be logged")



# Generated at 2022-06-18 04:28:25.250092
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.INFO)
    logger.info('test')

    with logger_level(logger, logging.DEBUG):
        logger.debug('test')

    logger.info('test')

# Generated at 2022-06-18 04:28:28.132563
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('This should not be printed')
        logger.info('This should be printed')
    logger.debug('This should be printed')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:29.890556
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')


# Generated at 2022-06-18 04:28:33.220893
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")



# Generated at 2022-06-18 04:28:38.879173
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:28:46.505903
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:55.036035
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import logging

    # Test with bare config
    cfg = get_config(config=DEFAULT_CONFIG)
    assert cfg == DEFAULT_CONFIG

    # Test with json config
    cfg = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert cfg == DEFAULT_CONFIG

    # Test with yaml config
    cfg = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert cfg == DEFAULT_CONFIG

    # Test with invalid config
    try:
        get_config(config='invalid')
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test with no config

# Generated at 2022-06-18 04:28:59.362723
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:29:02.567678
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:06.485049
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:29:16.365475
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import inspect
    import sys
    import os

    from contextlib import contextmanager


    class _PyInfo(object):
        PY2 = sys.version_info[0] == 2
        PY3 = sys.version_info[0] == 3

        if PY3:
            string_types = str,
            text_type = str
            binary_type = bytes
        else:  # PY2
            string_types = basestring,
            text_type = unicode
            binary_type = str


    def _namespace_from_calling_context():
        """
        Derive a namespace from the module containing the caller's caller.

        :return: the fully qualified python name of a module.
        :rtype: str
        """
        # Not py3k compat


# Generated at 2022-06-18 04:29:21.971139
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:27.828606
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))
    log.info("This is a test")
    with logger_level(log, logging.INFO):
        log.debug("This is a test")
    log.info("This is a test")

    # Test with a StringIO
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(io.StringIO()))
    log.info("This is a test")
    with logger_level(log, logging.INFO):
        log.debug("This is a test")

# Generated at 2022-06-18 04:29:30.204805
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

# Generated at 2022-06-18 04:29:35.106999
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:29:50.797397
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def test_logger_level(self):
            with logger_level(self.logger, logging.INFO):
                self.logger.debug('debug')
                self.logger.info('info')
                self.logger.warning('warning')
                self.logger.error('error')
                self.logger.critical('critical')

# Generated at 2022-06-18 04:29:58.022881
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:30:00.052733
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:30:03.125387
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')
    with logger_level(log, logging.INFO):
        log.info('test')
    log.debug('test')



# Generated at 2022-06-18 04:30:10.567738
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:14.090572
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:17.741704
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:30:23.293259
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:28.851547
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import time

    # Create a logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Create a handler to print to stdout
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)

    # Create a formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # Add the formatter to the handler
    handler.setFormatter(formatter)

    # Add the handler to the logger
    logger.addHandler(handler)

    # Create a string buffer to capture the output
    buffer = io.StringIO()
    handler = logging.StreamHandler(buffer)


# Generated at 2022-06-18 04:30:34.798536
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    logger.debug('test_logger_level')
    with logger_level(logger, logging.INFO):
        logger.debug('test_logger_level')
    logger.debug('test_logger_level')


# Generated at 2022-06-18 04:30:56.554345
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

# Generated at 2022-06-18 04:31:04.340979
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config(None, None, None) is None
    assert get_config(None, None, {}) == {}
    assert get_config(None, None, {'a': 1}) == {'a': 1}

    assert get_config(None, 'LOGGING', None) is None
    assert get_config(None, 'LOGGING', {}) == {}
    assert get_config(None, 'LOGGING', {'a': 1}) == {'a': 1}

    assert get_config(None, 'LOGGING', None) is None
    assert get_config(None, 'LOGGING', {}) == {}
    assert get_config(None, 'LOGGING', {'a': 1}) == {'a': 1}


# Generated at 2022-06-18 04:31:06.175995
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:31:12.921293
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    assert config == DEFAULT_CONFIG


# Generated at 2022-06-18 04:31:17.686688
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:31:19.042340
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:31:25.848379
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG
    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG
    config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING')
    assert config == DEFAULT_CONFIG
    config = get_config(config=json.dumps(DEFAULT_CONFIG), env_var='LOGGING')
    assert config == DEFAULT_CONFIG

# Generated at 2022-06-18 04:31:32.956561
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:35.059060
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:31:39.655345
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

# Generated at 2022-06-18 04:31:58.797526
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG



# Generated at 2022-06-18 04:32:09.451893
# Unit test for function get_config
def test_get_config():
    # Test for bare string
    assert get_config('test') == 'test'

    # Test for json string
    assert get_config('{"test": "test"}') == {'test': 'test'}

    # Test for yaml string
    assert get_config('test: test') == {'test': 'test'}

    # Test for invalid string
    try:
        get_config('invalid')
    except ValueError:
        pass
    else:
        assert False, 'Invalid string should raise ValueError'

    # Test for invalid json string
    try:
        get_config('{"test": "test"')
    except ValueError:
        pass
    else:
        assert False, 'Invalid json string should raise ValueError'

    # Test for invalid yaml string

# Generated at 2022-06-18 04:32:14.659388
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

# Generated at 2022-06-18 04:32:20.250969
# Unit test for function configure
def test_configure():
    import logging
    import os
    import tempfile

    # Test with default config
    configure()
    log = logging.getLogger(__name__)
    log.info('test')

    # Test with config from environment variable

# Generated at 2022-06-18 04:32:23.755917
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

# Generated at 2022-06-18 04:32:25.934812
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:32:29.179106
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')



# Generated at 2022-06-18 04:32:34.018878
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:39.731785
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-18 04:32:42.322975
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:33:01.875375
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:10.965023
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    import sys
    import os

    from contextlib import contextmanager


# Generated at 2022-06-18 04:33:17.098789
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:20.434499
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('This should not be logged')
        logger.info('This should be logged')
    logger.debug('This should be logged')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:21.763416
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')


# Generated at 2022-06-18 04:33:29.651391
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    config = get_config(config='{"version": 1}')
    assert config == {"version": 1}

    # Test with json string
    config = get_config(config='{"version": 1}')
    assert config == {"version": 1}

    # Test with yaml string
    config = get_config(config='version: 1')
    assert config == {"version": 1}

    # Test with dict
    config = get_config(config={"version": 1})
    assert config == {"version": 1}

    # Test with invalid config
    try:
        get_config(config=1)
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:33:32.724462
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test_logger_level')
    logger.info('test_logger_level')



# Generated at 2022-06-18 04:33:41.345634
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

    # Test that logger_level does not affect other loggers
    log2 = logging.getLogger(__name__ + '2')
    log2.setLevel(logging.DEBUG)
    log2.add

# Generated at 2022-06-18 04:33:45.670941
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug message')
    log.info('info message')
    with logger_level(log, logging.INFO):
        log.debug('debug message')
    log.info('info message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:51.473051
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
        log.info('test')
        log.warning('test')
        log.error('test')
        log.critical('test')
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')



# Generated at 2022-06-18 04:34:13.417227
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:34:21.593831
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')

    with logger_level(logger, logging.WARNING):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:27.078928
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:30.542372
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        logger.debug('debug message')
        logger.info('info message')
    logger.debug('debug message')
    logger.info('info message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:34.258255
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
        log.info('test')
        log.warning('test')
        log.error('test')
        log.critical('test')
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:43.481868
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test with bare string
    config = 'test'
    assert get_config(config) == config

    # Test with json string
    config = json.dumps({'test': 'test'})
    assert get_config(config) == {'test': 'test'}

    # Test with yaml string
    config = yaml.dump({'test': 'test'})
    assert get_config(config) == {'test': 'test'}

    # Test with invalid string
    config = '{'
    try:
        get_config(config)
    except ValueError:
        pass
    else:
        assert False, 'Invalid string should raise ValueError'

    # Test with dict
    config = {'test': 'test'}
    assert get_config(config) == config

   

# Generated at 2022-06-18 04:34:48.405112
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:34:52.711658
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:55.962140
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        logger.debug("This should not be printed")
        logger.info("This should be printed")
    logger.debug("This should be printed")
    logger.info("This should be printed")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:04.321635
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be visible')
        logger.info('This should be visible')
        logger.warning('This should be visible')
        logger.error('This should be visible')
        logger.critical('This should be visible')
    logger.debug('This should not be visible')
    logger.info('This should be visible')
    logger.warning('This should be visible')
    logger.error('This should be visible')
    logger.critical('This should be visible')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:29.587059
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:34.545021
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:39.156874
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:46.540701
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("This should be logged")
        log.info("This should be logged")
        log.warning("This should be logged")
        log.error("This should be logged")
        log.critical("This should be logged")
    log.debug("This should not be logged")
    log.info("This should not be logged")
    log.warning("This should not be logged")
    log.error("This should not be logged")
    log.critical("This should not be logged")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:55.065976
# Unit test for function get_config
def test_get_config():
    assert get_config(default=None) is None
    assert get_config(default=1) == 1
    assert get_config(default=dict(a=1)) == dict(a=1)
    assert get_config(default=dict(a=1)) == dict(a=1)
    assert get_config(default=dict(a=1)) == dict(a=1)
    assert get_config(default=dict(a=1)) == dict(a=1)
    assert get_config(default=dict(a=1)) == dict(a=1)
    assert get_config(default=dict(a=1)) == dict(a=1)
    assert get_config(default=dict(a=1)) == dict(a=1)

# Generated at 2022-06-18 04:36:04.788006
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=None)
    assert config is None

    config = get_config(config=None, env_var='LOGGING', default=None)
    assert config is None

    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG)
   

# Generated at 2022-06-18 04:36:08.774367
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:36:16.236457
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test with bare config

# Generated at 2022-06-18 04:36:23.410225
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:24.906413
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("test_logger_level")
