

# Generated at 2022-06-18 04:26:50.140735
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:26:55.948476
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:02.426838
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:09.368205
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')



# Generated at 2022-06-18 04:27:11.524905
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

# Generated at 2022-06-18 04:27:19.258440
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:21.957715
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:27:26.231149
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug message')
        log.info('info message')
        log.warning('warning message')
        log.error('error message')
        log.critical('critical message')
    log.debug('debug message')
    log.info('info message')
    log.warning('warning message')
    log.error('error message')
    log.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:30.034386
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:27:35.751065
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:43.695532
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:46.189877
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:27:47.286247
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:27:48.531487
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:27:54.231665
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')



# Generated at 2022-06-18 04:27:56.622835
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:28:05.925368
# Unit test for function get_config
def test_get_config():
    # Test case 1: given is None, env_var is None, default is None
    config = get_config()
    assert config == DEFAULT_CONFIG

    # Test case 2: given is None, env_var is not None, default is None
    config = get_config(env_var='TEST_LOGGING')
    assert config == DEFAULT_CONFIG

    # Test case 3: given is None, env_var is None, default is not None
    config = get_config(default=dict(version=1))
    assert config == dict(version=1)

    # Test case 4: given is not None, env_var is None, default is None
    config = get_config(given=dict(version=1))
    assert config == dict(version=1)

    # Test case 5: given is not None, env_var is

# Generated at 2022-06-18 04:28:13.932494
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("This should be logged")
        log.info("This should be logged")
        log.warning("This should be logged")
        log.error("This should be logged")
        log.critical("This should be logged")
    log.debug("This should not be logged")
    log.info("This should not be logged")
    log.warning("This should not be logged")
    log.error("This should not be logged")
    log.critical("This should not be logged")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-18 04:28:16.058863
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:28:25.611899
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def test_logger_level(self):
            with logger_level(self.logger, logging.INFO):
                self.logger.debug('debug')
                self.logger.info('info')
                self.logger.warning('warning')
                self.logger.error('error')
                self.logger.critical('critical')

# Generated at 2022-06-18 04:28:34.913742
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.handler.close()
            self.stream.close()

        def test_logger_level(self):
            self.logger.debug('debug')
            self.logger.info('info')
            self.logger.warning('warning')

# Generated at 2022-06-18 04:28:42.369523
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:28:46.359686
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:28:47.825901
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:28:49.216296
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-18 04:28:56.995483
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # Test bare config
    config = get_config(config='test')
    assert config == 'test'

    # Test json config
    config = get_config(config=json.dumps({'test': 'test'}))
    assert config == {'test': 'test'}

    # Test yaml config
    config = get_config(config=yaml.dump({'test': 'test'}))
    assert config == {'test': 'test'}

    # Test invalid config
    try:
        get_config(config=None)
    except ValueError:
        pass
    else:
        assert False


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:29:01.461985
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:06.028092
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:09.051037
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:11.829091
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:29:23.203680
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    config = get_config(config=None, env_var=None, default=None)
    assert config is None

    config = get_config(config=None, env_var='LOGGING', default=None)
    assert config is None

    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG), env_var=None, default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG), env_var=None, default=None)
    assert config == DEFAULT_CONFIG


# Generated at 2022-06-18 04:29:29.607490
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("debug")
        log.info("info")
        log.warning("warning")
        log.error("error")
        log.critical("critical")
    log.debug("debug")
    log.info("info")
    log.warning("warning")
    log.error("error")
    log.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:35.144738
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:29:38.938360
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.debug('test')
    with logger_level(logger, logging.INFO):
        logger.debug('test')
    logger.debug('test')



# Generated at 2022-06-18 04:29:43.464559
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')



# Generated at 2022-06-18 04:29:48.724156
# Unit test for function get_config
def test_get_config():
    assert get_config(default='{"version": 1}') == {'version': 1}
    assert get_config(default='{"version": 1}') == {'version': 1}
    assert get_config(default='version: 1') == {'version': 1}
    assert get_config(default='version: 1') == {'version': 1}
    assert get_config(default='{"version": 1}') == {'version': 1}
    assert get_config(default='{"version": 1}') == {'version': 1}
    assert get_config(default='version: 1') == {'version': 1}
    assert get_config(default='version: 1') == {'version': 1}

# Generated at 2022-06-18 04:29:50.798290
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')



# Generated at 2022-06-18 04:29:59.207399
# Unit test for function logger_level
def test_logger_level():
    import logging
    import tempfile
    import os

    with tempfile.NamedTemporaryFile() as f:
        logging.basicConfig(filename=f.name, level=logging.DEBUG)
        logger = logging.getLogger(__name__)
        logger.debug('test')
        with logger_level(logger, logging.INFO):
            logger.debug('test')
            logger.info('test')
        logger.debug('test')
        with open(f.name) as f:
            lines = f.readlines()
            assert len(lines) == 2
            assert 'DEBUG' in lines[0]
            assert 'INFO' in lines[1]

# Generated at 2022-06-18 04:30:02.972988
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:04.680479
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test2')



# Generated at 2022-06-18 04:30:16.147941
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(logger, logging.INFO):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')

    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:22.362219
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:24.195767
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:30:27.617383
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')



# Generated at 2022-06-18 04:30:29.315142
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:30:33.155020
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')

# Generated at 2022-06-18 04:30:35.293026
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')



# Generated at 2022-06-18 04:30:40.436987
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:46.332058
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:30:55.039748
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    # Test that the logger is not logging at the INFO level
    with logger_level(logger, logging.INFO):
        logger.debug('This should not be logged')
    assert not logger.handlers[0].stream.getvalue()

    # Test that the logger is logging at the DEBUG level
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be logged')
    assert logger.handlers[0].stream.getvalue()

    # Test that the logger is logging at the INFO level again
    logger.debug('This should be logged')
    assert logger.handlers

# Generated at 2022-06-18 04:31:02.437492
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.debug('debug')
    logger.info('info')
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
    logger.debug('debug')
    logger.info('info')

# Generated at 2022-06-18 04:31:09.566482
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    # Test that the logger is not logging at the level we want to test
    with logger_level(logger, logging.INFO):
        logger.debug('This should not be logged')

    # Test that the logger is logging at the level we want to test
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be logged')

    # Test that the logger is not logging at the level we want to test
    with logger_level(logger, logging.INFO):
        logger.debug('This should not be logged')

    # Test that the logger is logging at the level we want

# Generated at 2022-06-18 04:31:13.979781
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
    logger.info('info')
    with logger_level(logger, logging.INFO):
        logger.info('info')
    logger.debug('debug')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:21.805371
# Unit test for function get_config
def test_get_config():
    # Test for bare config
    config = get_config(config='test')
    assert config == 'test'

    # Test for json config
    config = get_config(config='{"test": "test"}')
    assert config == {'test': 'test'}

    # Test for yaml config
    config = get_config(config='test: test')
    assert config == {'test': 'test'}

    # Test for invalid config
    try:
        get_config(config='{test: test}')
    except ValueError:
        pass
    else:
        assert False

    # Test for invalid config
    try:
        get_config(config='test: test: test')
    except ValueError:
        pass
    else:
        assert False


if __name__ == '__main__':
    import doctest

# Generated at 2022-06-18 04:31:24.448401
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test_logger_level')


# Generated at 2022-06-18 04:31:31.309237
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug message")
        logger.info("This is an info message")
        logger.warning("This is a warning message")
        logger.error("This is an error message")
        logger.critical("This is a critical message")


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:31:32.780217
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:31:34.874861
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test')


# Generated at 2022-06-18 04:31:40.736929
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    with pytest.raises(ValueError):
        get_config()



# Generated at 2022-06-18 04:31:43.337714
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:49.525969
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:31:53.709660
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:00.405301
# Unit test for function get_config
def test_get_config():
    # test with bare string
    assert get_config('test') == 'test'

    # test with json string
    assert get_config('{"test": "test"}') == {'test': 'test'}

    # test with yaml string
    assert get_config('test: test') == {'test': 'test'}

    # test with dict
    assert get_config({'test': 'test'}) == {'test': 'test'}

    # test with invalid string
    try:
        get_config('{test: test}')
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # test with invalid string
    try:
        get_config('test: test')
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'



# Generated at 2022-06-18 04:32:06.142879
# Unit test for function logger_level
def test_logger_level():
    """
    >>> import logging
    >>> log = logging.getLogger(__name__)
    >>> configure()
    >>> log.info('test')
    >>> with logger_level(log, logging.DEBUG):
    ...     log.debug('test')
    >>> log.info('test')
    """
    pass



# Generated at 2022-06-18 04:32:12.388591
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:18.842015
# Unit test for function configure
def test_configure():
    import logging
    import os
    import tempfile
    import json
    import yaml

    def _write_config(f, cfg):
        if isinstance(cfg, dict):
            cfg = json.dumps(cfg)
        elif isinstance(cfg, _PyInfo.string_types):
            try:
                cfg = json.loads(cfg)
            except ValueError:
                cfg = yaml.load(cfg)
        f.write(cfg)
        f.flush()

    with tempfile.NamedTemporaryFile(mode='w+') as f:
        _write_config(f, DEFAULT_CONFIG)
        os.environ['LOGGING'] = f.name
        configure()
        assert logging.getLogger().getEffectiveLevel() == logging.DEBUG
        assert logging.getLogger

# Generated at 2022-06-18 04:32:25.618730
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import os

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(sys.stdout))

    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:34.529129
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)
        assert not logger.isEnabledFor(logging.INFO)
        assert not logger.isEnabledFor(logging.WARNING)
        assert not logger.isEnabledFor(logging.ERROR)
        assert not logger.isEnabledFor(logging.CRITICAL)

    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.DEBUG)
        assert logger.isEnabledFor(logging.INFO)
        assert not logger.isEnabledFor(logging.WARNING)
        assert not logger.isEnabledFor(logging.ERROR)
        assert not logger.isEnabledFor(logging.CRITICAL)


# Generated at 2022-06-18 04:32:41.142259
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:32:43.267592
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-18 04:32:49.170976
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
    logger.debug("This should not be logged")



# Generated at 2022-06-18 04:32:51.101544
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:32:53.011356
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-18 04:32:56.933230
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:32:58.445095
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:33:01.104931
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:05.682947
# Unit test for function configure
def test_configure():
    import tempfile
    import json
    import logging

    with tempfile.NamedTemporaryFile(mode='w') as f:
        f.write(json.dumps(DEFAULT_CONFIG))
        f.flush()
        configure(config=f.name)
        log = logging.getLogger(__name__)
        log.info('test')



# Generated at 2022-06-18 04:33:08.097302
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:16.449129
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('This should be logged')
        log.info('This should be logged')
        log.warning('This should be logged')
        log.error('This should be logged')
        log.critical('This should be logged')
    log.debug('This should not be logged')
    log.info('This should not be logged')
    log.warning('This should not be logged')
    log.error('This should not be logged')
    log.critical('This should not be logged')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:33:19.871131
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


# Generated at 2022-06-18 04:33:37.508086
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=yaml.dump(DEFAULT_CONFIG))
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, default=None)
    assert config == DEFAULT_CONFIG

    config = get_config(config=json.dumps(DEFAULT_CONFIG), default=None)
    assert config == DEFAULT_CONFIG


# Generated at 2022-06-18 04:33:39.595597
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:33:41.680357
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:33:46.696601
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:33:56.706541
# Unit test for function get_config
def test_get_config():
    # Test with bare string
    assert get_config('test') == 'test'

    # Test with JSON string
    assert get_config('{"test": "test"}') == {'test': 'test'}

    # Test with YAML string
    assert get_config('test: test') == {'test': 'test'}

    # Test with dict
    assert get_config({'test': 'test'}) == {'test': 'test'}

    # Test with invalid string
    try:
        get_config('{test: test}')
    except ValueError:
        pass
    else:
        assert False, 'Should have raised ValueError'

    # Test with invalid dict
    try:
        get_config({'test': 'test'}, default='test')
    except ValueError:
        pass

# Generated at 2022-06-18 04:34:07.150988
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config(None, None, None) is None
    assert get_config(None, None, {}) == {}
    assert get_config(None, None, {'a': 1}) == {'a': 1}
    assert get_config(None, None, '{}') == {}
    assert get_config(None, None, '{"a": 1}') == {'a': 1}
    assert get_config(None, None, 'a: 1') == {'a': 1}
    assert get_config(None, None, 'a: 1') == yaml.load('a: 1')
    assert get_config(None, None, '{"a": 1}') == json.loads('{"a": 1}')

# Generated at 2022-06-18 04:34:13.144923
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    config = {'a': 1}
    assert get_config(config) == config

    config = json.dumps(config)
    assert get_config(config) == json.loads(config)

    config = yaml.dump(config)
    assert get_config(config) == yaml.load(config)

    config = 'invalid'
    try:
        get_config(config)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-18 04:34:16.476720
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:19.429125
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')


# Generated at 2022-06-18 04:34:22.059532
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:34:31.456316
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-18 04:34:35.023188
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:36.916552
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:34:46.108704
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be visible')
        logger.info('This should be visible')
        logger.warning('This should be visible')
        logger.error('This should be visible')
        logger.critical('This should be visible')
    logger.debug('This should not be visible')
    logger.info('This should be visible')
    logger.warning('This should be visible')
    logger.error('This should be visible')
    logger.critical('This should be visible')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:34:52.489213
# Unit test for function get_config
def test_get_config():
    # test for bare string
    assert get_config(config='test') == 'test'

    # test for json string
    assert get_config(config='{"test": "test"}') == {'test': 'test'}

    # test for yaml string
    assert get_config(config='test: test') == {'test': 'test'}

    # test for dict
    assert get_config(config={'test': 'test'}) == {'test': 'test'}

    # test for invalid string
    try:
        get_config(config='test: test')
    except ValueError:
        pass
    else:
        assert False

    # test for invalid dict
    try:
        get_config(config={'test': 'test'})
    except ValueError:
        pass
    else:
        assert False




# Generated at 2022-06-18 04:34:57.518078
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(logging.DEBUG)
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)

        def test_logger_level(self):
            with logger_level(self.logger, logging.ERROR):
                self.logger.debug('debug')
                self.logger.info('info')
                self.logger.warning('warning')
                self.logger.error('error')
                self.logger.critical('critical')


# Generated at 2022-06-18 04:35:07.034570
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"version": 1}')
    assert config == {'version': 1}
    config = get_config(config='version: 1')
    assert config == {'version': 1}
    config = get_config(config='version: 1', default={'version': 2})
    assert config == {'version': 1}
    config = get_config(config=None, default={'version': 2})
    assert config == {'version': 2}
    config = get_config(config=None, env_var='LOGGING', default={'version': 2})
    assert config == {'version': 2}
    os.environ['LOGGING'] = '{"version": 1}'
    config = get_config(config=None, env_var='LOGGING', default={'version': 2})
   

# Generated at 2022-06-18 04:35:11.016805
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:16.006722
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:19.535635
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-18 04:35:40.740445
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import logging

    # Test with bare string
    config = 'test'
    assert get_config(config) == config

    # Test with json string
    config = json.dumps({'test': 'test'})
    assert get_config(config) == json.loads(config)

    # Test with yaml string
    config = yaml.dump({'test': 'test'})
    assert get_config(config) == yaml.load(config)

    # Test with invalid string
    config = 'test'
    try:
        get_config(config)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test with dict
    config = {'test': 'test'}
    assert get_config(config) == config

    #

# Generated at 2022-06-18 04:35:45.638177
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

# Generated at 2022-06-18 04:35:51.642543
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:35:55.200135
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-18 04:35:57.110061
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')


# Generated at 2022-06-18 04:36:04.272562
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-18 04:36:06.098055
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.DEBUG


# Generated at 2022-06-18 04:36:07.975811
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.info('test')


# Generated at 2022-06-18 04:36:09.964465
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.debug('test2')


# Generated at 2022-06-18 04:36:14.727551
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')

if __name__ == '__main__':
    test_logger_level()