

# Generated at 2022-06-24 02:53:39.049113
# Unit test for function getLogger
def test_getLogger():
    from colorlog import escape_codes

    # TODO this also tests configure, but not exhaustively.
    log = getLogger()
    log.debug('test')

    log = getLogger('test3')
    log.debug('test3')
    log.setLevel(logging.DEBUG)
    log.debug('test3')

    # Test the extras
    configured = str(DEFAULT_CONFIG)
    # print(configured)

    config = get_config(configured, None, None)
    assert config == DEFAULT_CONFIG

    # get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG

    assert not configure('')
    assert not configure(None)

    assert get_config('{}') == {}

    assert getLogger()


# Generated at 2022-06-24 02:53:41.388579
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.ERROR) as level:
        assert level == logger.level
        assert level == logging.ERROR
    assert logger.level == logging.DEBUG

# Generated at 2022-06-24 02:53:53.250095
# Unit test for function get_config
def test_get_config():
    from io import StringIO
    import logging
    import logging.config
    import sys
    import os
    import json

    _CONFIGURED[:] = []

    # PATH refers to any logging configs in the environment
    # The key/value pair in `environ` will override the config in the current environment
    environ = {
        "PATH": os.path.abspath(os.path.join(os.path.dirname( __file__ ), 'low_verbose_logging.yml'))
    }
    # Save existing environment variables
    saved_env = os.environ.copy()
    # Insert new environment variables
    os.environ.update(environ)

    log_stream = StringIO()
    sys.stdout = log_stream

    # LOGGING is the environment variable that holds a logging config


# Generated at 2022-06-24 02:53:56.575573
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level != logging.DEBUG

# Generated at 2022-06-24 02:54:00.451975
# Unit test for function configure
def test_configure():
    logger = get_logger('test_configure')
    logger.info('test_configure is called')


# Generated at 2022-06-24 02:54:03.370442
# Unit test for function getLogger
def test_getLogger():
    log = get_logger(__name__)
    log.info('test')
    log.debug('debug test')
    log.error('error test')
    log.warn('warn test')


# Generated at 2022-06-24 02:54:06.350223
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('Message from configure')



# Generated at 2022-06-24 02:54:11.717316
# Unit test for function logger_level
def test_logger_level():
    import logging
    from garcon.logger import logger_level, get_logger

    log = get_logger()
    assert isinstance(log, logging.Logger)

    with logger_level(log, logging.ERROR):
        assert log.level == logging.ERROR
        log.info("Not supposed to see this!")
        log.error("Should see this!")

    assert log.level == logging.NOTSET



# Generated at 2022-06-24 02:54:16.566673
# Unit test for function get_config
def test_get_config():
    try:
        get_config()
    except ValueError:
        pass
    except Exception as e:
        raise e
    else:
        raise Exception('default get_config should cause ValueError')
    try:
        get_config(env_var='LOGGING')
    except ValueError:
        pass
    except Exception as e:
        raise e
    else:
        raise Exception('empty env_var get_config should cause ValueError')
    config = get_config(default=DEFAULT_CONFIG)
    if not isinstance(config, dict):
        raise Exception('default get_config should return same result as DEFAULT_CONFIG')



# Generated at 2022-06-24 02:54:18.997045
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # Test
    pyinfo = _PyInfo()
    assert pyinfo.PY2 is True
    assert pyinfo.PY3 is False
    assert pyinfo.string_types == (basestring,)
    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str

# Test for function _namespace_from_calling_context()

# Generated at 2022-06-24 02:54:19.915478
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3


# Generated at 2022-06-24 02:54:26.127953
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str


# Unit tests for function _namespace_from_calling_context()

# Generated at 2022-06-24 02:54:28.265547
# Unit test for function getLogger
def test_getLogger():
    assert True



# Generated at 2022-06-24 02:54:31.800590
# Unit test for function getLogger
def test_getLogger():
    """
    >>> log = get_logger()
    >>> log.info('test')

    >>> log = get_logger('test2')
    >>> log.info('test2')
    """
    _ensure_configured()


# Generated at 2022-06-24 02:54:35.349802
# Unit test for function getLogger
def test_getLogger():
    configure()
    log1 = logging.getLogger(__name__)
    log2 = get_logger(__name__)
    log1.info('test')
    log2.info('test')

test_getLogger()

# Generated at 2022-06-24 02:54:38.080245
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    log.debug('Hello')

    with logger_level(log, logging.DEBUG):
        log.debug('Hello')

    log.debug('Hello')

# Generated at 2022-06-24 02:54:43.027707
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    assert logger.level == logging.NOTSET

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug('test')

    assert logger.level == logging.NOTSET



# Generated at 2022-06-24 02:54:44.782709
# Unit test for function getLogger
def test_getLogger():
    log = getLogger('test')
    assert isinstance(log, logging.Logger)
    log.info('test')



# Generated at 2022-06-24 02:54:47.039046
# Unit test for function getLogger
def test_getLogger():
    log = getLogger('test')
    log.info('test')
    log = getLogger()
    log.info('test')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:54:55.079017
# Unit test for function get_config

# Generated at 2022-06-24 02:55:04.301772
# Unit test for function get_config
def test_get_config():
    print ('Testing for function get_config')
    config = '{"version": 1, "formatters": {"simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": "DEBUG"}}, "loggers": {"root": {"handlers": ["console"], "level": "DEBUG"}}}'
    # config = {"version": 1, "formatters": {"simple": {"format": "%(asctime)

# Generated at 2022-06-24 02:55:09.084977
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    log.info('Before')
    with logger_level(log, logging.WARNING):
        log.info('During the block')
        log.warning('Still during the block')
    log.info('After')

    # assert False
    # import pytest
    # with pytest.raises(AssertionError):
    #     assert False, 'Nope!'

# Generated at 2022-06-24 02:55:12.744353
# Unit test for function logger_level
def test_logger_level():
    """
    >>> log = get_logger(__name__)
    >>> with logger_level(log, logging.WARNING):
    ...     log.critical('should print')
    ...     log.error('should print')
    ...     log.warning('should print')
    ...     log.info('should not print')
    ...     log.debug('should not print')
    """



# Generated at 2022-06-24 02:55:15.816649
# Unit test for function logger_level
def test_logger_level():
    cfg = {'handlers': {'console': {'class': 'logging.NullHandler'}}}
    logging.config.dictConfig(cfg)

    l = logging.getLogger('test_logger_level')
    l.info('test_logger_level message')

    with logger_level(l, logging.WARNING):
        l.debug('test_logger_level message')
        l.info('test_logger_level message')
        l.warning('test_logger_level message')


# Generated at 2022-06-24 02:55:20.739988
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True or _PyInfo.PY2 == False
    assert _PyInfo.PY3 == True or _PyInfo.PY3 == False

# Generated at 2022-06-24 02:55:21.803301
# Unit test for function configure
def test_configure():
    configure()
    logging.getLogger(__name__).info('info')

# Generated at 2022-06-24 02:55:28.200218
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

    if _PyInfo.PY3:
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
        assert _PyInfo.string_types == (str,)
    else: # PY2
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
        assert _PyInfo.string_types == (basestring,)

# Generated at 2022-06-24 02:55:33.265339
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print("from hex2dec import _PyInfo")
    pi = _PyInfo()
    print("pi.PY2 = %s" % pi.PY2)
    print("pi.PY3 = %s" % pi.PY3)
    print("pi.string_types = %s" % pi.string_types)
    print("pi.text_type = %s" % pi.text_type)
    print("pi.binary_type = %s" % pi.binary_type)


# Generated at 2022-06-24 02:55:39.916219
# Unit test for function getLogger
def test_getLogger():
    """
    >>> test1 = getLogger('test1')
    >>> test1.info('test1')
    >>> test2 = getLogger('test2')
    >>> test2.info('test2')
    >>> test3 = getLogger('test3')
    >>> test3.info('test3')
    """

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:55:41.252694
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3



# Generated at 2022-06-24 02:55:48.165822
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger()
    # We need a root logger with a handler to avoid
    # it logging to our console.
    with logger_level(test_logger, logging.CRITICAL):
        assert test_logger.getEffectiveLevel() == logging.CRITICAL
        test_logger.debug('DEBUG')
        test_logger.info('INFO')
        test_logger.warning('WARNING')
    assert test_logger.getEffectiveLevel() != logging.CRITICAL



# Generated at 2022-06-24 02:55:51.987254
# Unit test for function get_config
def test_get_config():
    print('Running unit test for function get_config')
    cfg = get_config(env_var='LOGGING_CONFIG')
    print(cfg)


# Generated at 2022-06-24 02:55:54.504398
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    print(log)
    assert log is not None
    log.info('test')


# Generated at 2022-06-24 02:56:04.759096
# Unit test for function configure
def test_configure():
    # also tests get_config
    log = logging.getLogger('testing')
    assert not log.handlers, \
        "Calling configure() shouldn't add handlers if there are none"
    # test with json
    configure(json.dumps(DEFAULT_CONFIG))
    assert len(log.handlers) == 1
    # test with yaml
    configure(yaml.dump(DEFAULT_CONFIG))
    assert len(log.handlers) == 1
    # test with dict
    configure(DEFAULT_CONFIG)
    assert len(log.handlers) == 1
    assert len(log.handlers) <= 1, \
        "Calling configure() multiple times should only add 1 handler"

# Generated at 2022-06-24 02:56:10.879219
# Unit test for function get_config
def test_get_config():
    assert get_config(env_var='NOT_A_REAL_ENV_VAR') is None
    assert get_config(default={}) == {}

    assert get_config(default={}, config={'foo': 'bar'}) == {'foo': 'bar'}
    assert get_config(default={}, config={'foo': 'bar'}) == {'foo': 'bar'}

    assert get_config(config='{"foo": "bar"}') == {'foo': 'bar'}
    assert get_config(config='foo: bar') == {'foo': 'bar'}

# Generated at 2022-06-24 02:56:11.948325
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3


# Generated at 2022-06-24 02:56:12.990456
# Unit test for function configure
def test_configure():
    logger = get_logger()
    logger.warning("this is a test")

# Generated at 2022-06-24 02:56:20.265717
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager

    @contextmanager
    def _logger_level(logger, level):
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    logger = logging.getLogger(__name__)
    configure()

    # Set the logger level to WARNING (30) and check that messages with a level lower than 30 are not printed
    with _logger_level(logger, logging.WARNING):
        logger.debug('This should not be printed')
        logger.info('This should not be printed')
        logger.warning('This should be printed')
        logger.error('This should be printed')

    # Set the logger level to DEBUG (10) and check that messages with a level lower than 10 are printed

# Generated at 2022-06-24 02:56:24.127780
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert _PyInfo.PY2 or _PyInfo.PY3


# Generated at 2022-06-24 02:56:28.863056
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not (_PyInfo.PY2 and _PyInfo.PY3)
    assert _PyInfo.string_types
    assert _PyInfo.text_type
    assert _PyInfo.binary_type


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:56:32.190551
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True or _PyInfo.PY2 == False
    assert _PyInfo.PY3 == True or _PyInfo.PY3 == False



# Generated at 2022-06-24 02:56:38.510689
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    assert logger.level == 10 # The default level is 10

    with logger_level(logger, 0):
        assert logger.level == 0

    assert logger.level == 10 # The level should be restored after the context manager


if __name__ == '__main__':
    logging.basicConfig()

    log = get_logger()
    log.info('test')

# Generated at 2022-06-24 02:56:45.374052
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    def is_py2():
        """
        Check whether the current Python interpreter is Python 2.

        :return: `True` if the version is Python 2, `False` otherwise.
        :rtype: bool
        """
        return sys.version_info[0] == 2

    def is_py3():
        """
        Check whether the current Python interpreter is Python 3.

        :return: `True` if the version is Python 3, `False` otherwise.
        :rtype: bool
        """
        return sys.version_info[0] == 3

    assert _PyInfo.PY2 == is_py2()
    assert _PyInfo.PY3 == is_py3()



# Generated at 2022-06-24 02:56:51.069232
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    assert get_config('{"level": "DEBUG"}') == json.loads('{"level": "DEBUG"}')
    assert get_config(json.dumps({'level': 'DEBUG'})) == json.loads('{"level": "DEBUG"}')
    assert get_config(yaml.dump({'version': 1, 'level': 'DEBUG'})) == yaml.load(yaml.dump({'version': 1, 'level': 'DEBUG'}))
    assert get_config(None, 'TEST', {}) == {}
    assert get_config(None, 'TEST', None) == None
    assert get_config(None, 'TEST', None, None) == None
    os.environ['TEST'] = json.dumps({'level': 'DEBUG'})

# Generated at 2022-06-24 02:56:56.268715
# Unit test for function configure
def test_configure():
    configure()
    logging.debug('logging.debug')
    logging.info('logging.info')
    logging.warning('logging.warning')
    logging.error('logging.error')
    logging.critical('logging.critical')

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:56:58.440356
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')


# Generated at 2022-06-24 02:57:03.275997
# Unit test for function configure
def test_configure():
    tb = get_logger(__name__)
    with logger_level(tb, logging.ERROR):
        tb.debug('test')
    configure(default={})
    tb.debug('test')

# Generated at 2022-06-24 02:57:09.981951
# Unit test for function getLogger
def test_getLogger():
    assert getLogger() == getLogger(), "getLogger() should return the same instance"
    assert getLogger("foo") == getLogger("foo"), "getLogger() should return the same instance"
    assert getLogger("bar") != getLogger("foo"), "getLogger() should return different instances"
    assert "foo" == getLogger("foo").name, "getLogger() should return a logger with the expected name"


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:57:12.620222
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger()
    log.info('test')
    log.error('test')
    log.debug('test')



# Generated at 2022-06-24 02:57:16.263961
# Unit test for function configure
def test_configure():
    logger = getLogger()
    with logger_level(logger, logging.FATAL):
        assert logger.level == logging.FATAL, 'Logging level should be FATAL'
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO, 'Logging level should be INFO'



# Generated at 2022-06-24 02:57:19.682830
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

# Generated at 2022-06-24 02:57:28.301389
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY3 == False or pyinfo.PY3 == True
    assert pyinfo.PY2 == False or pyinfo.PY2 == True
    assert (pyinfo.PY3 + pyinfo.PY2) == 1, "Either PY3 or PY2 should be True"

    if pyinfo.PY2:
        assert isinstance("val", pyinfo.string_types)
        assert isinstance(u"val", pyinfo.string_types)
        assert isinstance("val", pyinfo.binary_type)
    elif pyinfo.PY3:
        assert isinstance("val", pyinfo.string_types)
        assert isinstance("val", pyinfo.text_type)
        assert isinstance(b"val", pyinfo.binary_type)

# Generated at 2022-06-24 02:57:30.590096
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config(env_var=None, default=DEFAULT_CONFIG)


# Generated at 2022-06-24 02:57:37.232490
# Unit test for function configure
def test_configure():
    import logging.config

    configure()

    # Make sure we can log a message
    log = logging.getLogger(__name__)
    log.info("test_configure")

    # Make sure we get the right log level
    with logger_level(logging.getLogger(), logging.FATAL):
        log.info("test_configure")

    # Make sure we get a traceback
    try:
        raise ValueError("test_configure")
    except ValueError:
        log.exception("test_configure")



# Generated at 2022-06-24 02:57:40.439382
# Unit test for function configure
def test_configure():
    try:
        configure(env_var='LOGGING')
        logger = logging.getLogger(__name__)
        logger.error("test")
        with logger_level(logger, logging.ERROR):
            logger.error("test")
    finally:
        logging.shutdown()

# Generated at 2022-06-24 02:57:44.611627
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    try:
        info = _PyInfo()
        assert info.PY2 == True, "I'm not running on version 2, am I?"
    except TypeError as e:
        assert info.PY3 == True, "I'm not running on version 3, am I?"

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:57:49.163195
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = getLogger('test_logger_level')
    >>> with logger_level(logger, logging.DEBUG):
    ...     logger.debug('hi')
    ...     with logger_level(logger, logging.INFO):
    ...         logger.debug('should not be seen')
    ...         logger.warning('hi')
    ...     logger.debug('seen again')
    """



# Generated at 2022-06-24 02:57:51.644147
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-24 02:57:55.084094
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py_info = _PyInfo()
    assert py_info.PY2 or py_info.PY3
    assert py_info.string_types
    assert py_info.text_type
    assert py_info.binary_type



# Generated at 2022-06-24 02:57:58.514565
# Unit test for function configure
def test_configure():
    logging.basicConfig(level=logging.DEBUG)
    logging.getLogger(__name__).setLevel(logging.DEBUG)
    configure(default=None)


if __name__ == "__main__":
    from py.test import cmdline

    cmdline.main()

# Generated at 2022-06-24 02:58:01.697968
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    assert(log != None)

    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')
    print("getLogger unit-test passed!")

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:58:08.032055
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert isinstance(logger, logging.Logger)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:58:19.379417
# Unit test for function getLogger
def test_getLogger():
    # Get the root logger
    root = get_logger('')

    # Get the root logger again
    root2 = get_logger('')

    # Get the default logger
    # default = get_logger()

    # Get a sub logger
    sub = get_logger('sub')

    # Get a sub-sub logger
    subsub = get_logger('sub.sub')

    # These should all be the same logger
    assert root is root2 # is default is sub is subsub

    # This should be a different logger
    assert root is not get_logger()

    # This should be a different logger
    assert sub is not subsub

    # These should not be the same
    assert get_logger() is not get_logger('sub')

if __name__ == '__main__':
    test_

# Generated at 2022-06-24 02:58:28.863860
# Unit test for function logger_level
def test_logger_level():
    import os
    import sys
    import logging
    import StringIO

    # make sure logging is configured
    configure()

    # make sure environment variable is not set
    if 'TESTLOG_LEVEL' in os.environ:
        del os.environ['TESTLOG_LEVEL']

    root_handler = None
    for handler in logging.root.handlers:
        if isinstance(handler, logging.StreamHandler):
            root_handler = handler
            break
    assert root_handler is not None

#    print('root_handler.level=', root_handler.level)

    capture_file = StringIO.StringIO()
    root_handler.stream = capture_file

    log = logging.getLogger(__name__)

#    print('log.level=', log.level)


# Generated at 2022-06-24 02:58:35.672219
# Unit test for function getLogger
def test_getLogger():
    '''
    from pyrin.logging.decorators import getLogger, DEFAULT_CONFIG
    import os, json
    log = getLogger()
    log.info('test')
    os.environ['LOGGING'] = json.dumps(DEFAULT_CONFIG)

    getLogger()
    log.info('test2')
    '''
    pass



# Generated at 2022-06-24 02:58:44.850411
# Unit test for function get_config
def test_get_config():
    import re
    # test None
    assert get_config(None) is None
    # test string json
    json_str = '{"a":1}'
    assert get_config(json_str) == {"a": 1}
    # test json
    json_dict = {"a": 1}
    assert get_config(json_dict) == {"a": 1}
    # test string yaml
    yaml_str = ("a: 1\n"
                "b: 2\n"
                "c:\n")
    assert get_config(yaml_str) == {"a": 1, "b": 2, "c": None}
    # test yaml
    yaml_dict = {"a": 1, "b": 2, "c": None, "d": []}

# Generated at 2022-06-24 02:58:54.123071
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config(default=DEFAULT_CONFIG)
    assert DEFAULT_CONFIG == get_config(default=DEFAULT_CONFIG)
    assert DEFAULT_CONFIG == get_config(config=DEFAULT_CONFIG)

    try:
        get_config()
        assert False, 'Expected an exception'
    except ValueError:
        pass

    try:
        get_config(config='')
        assert False, 'Expected an exception'
    except (ValueError, TypeError):
        pass

    try:
        get_config(config='{}')
        assert False, 'Expected an exception'
    except TypeError:
        pass

    assert DEFAULT_CONFIG == get_config(config=json.dumps(DEFAULT_CONFIG))
    assert DEFAULT_CONFIG

# Generated at 2022-06-24 02:58:56.384790
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import pytest
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == sys.version_info[0] == 2
    assert pyinfo.PY3 == sys.version_info[0] == 3

if __name__ == '__main__':
    configure()
    logging.info('test')
    test__PyInfo()

# Generated at 2022-06-24 02:58:59.608554
# Unit test for function logger_level
def test_logger_level():
    """
    >>> import logging
    >>> log = getLogger(__name__)
    >>> with logger_level(log, logging.DEBUG):
    ...     log.info('this will never show')
    ...     log.debug('this should show')
    ...
    """

# Generated at 2022-06-24 02:59:05.455050
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test')
    logger.info('test')

    # kwargs = dict(
    #     debug=True,
    #     filename='/var/log/test.log',
    # )
    # getLogger('test', **kwargs)


# Generated at 2022-06-24 02:59:08.760389
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py_info = _PyInfo()
    assert py_info.PY2 is True or py_info.PY2 is False
    assert py_info.PY3 is True or py_info.PY3 is False


# Generated at 2022-06-24 02:59:12.096800
# Unit test for function getLogger
def test_getLogger():
    # Check if logger has handler console
    assert get_logger().handlers[0].name == "console"
    # Get custom logger
    logger = get_logger("logger")
    # Check if custom logger has handler console
    assert logger.handlers[0].name == "console"



# Generated at 2022-06-24 02:59:20.758011
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import sys
    if sys.version_info[0] == 2:
        assert _PyInfo.PY2 == True
        assert _PyInfo.PY3 == False
        assert type(sys.version_info[0]) == int
    else:
        assert _PyInfo.PY2 == False
        assert _PyInfo.PY3 == True
        assert type(sys.version_info[0]) == int

    assert inspect.stack()[0][0].f_globals["__name__"] == '__main__'


# Generated at 2022-06-24 02:59:24.240177
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')



# Generated at 2022-06-24 02:59:31.927292
# Unit test for function get_config
def test_get_config():
    env_var = 'LOGGING'
    # Test bare config as a list of strings
    given = "{'version': 1, 'handlers': {'console': {'level': 'DEBUG', 'class': 'logging.StreamHandler', 'formatter': 'colored', 'stream': 'ext://sys.stdout'}}, 'loggers': {}, 'root': {'handlers': ['console'], 'level': 'DEBUG'}, 'formatters': {'colored': {'()': 'colorlog.ColoredFormatter', 'format': '%(log_color)s[%(asctime)s] %(message)s %(reset)s', 'log_colors': {'DEBUG': 'white', 'INFO': 'green', 'WARNING': 'yellow', 'ERROR': 'red', 'CRITICAL': 'red,bg_white'}}}}"

# Generated at 2022-06-24 02:59:40.696111
# Unit test for function get_config
def test_get_config():
    import json

    # dict
    given = {
        'version': 1,
        'formatters': {
            'simple': {
                'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s',
                'datefmt': '%Y-%m-%d %H:%M:%S',
            },
        }
    }
    assert get_config(given=given) == given

    # json string

# Generated at 2022-06-24 02:59:44.148502
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

    log = getLogger('test2')
    log.info('test2')


# Generated at 2022-06-24 02:59:52.690996
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import unittest
    class Test_PyInfo(unittest.TestCase):
        """Unit test for class _PyInfo

        Class _PyInfo is a helper class that is used by module logging.
        It inherit from object and has three attributes: PY2, PY3, string_types and binary_type.
        """
        def test_PY2(self):
            """test if PY2 attribute is set correctly"""
            self.assertEqual(_PyInfo.PY2, sys.version_info[0] == 2)
        def test_PY3(self):
            """test if PY3 attribute is set correctly"""
            self.assertEqual(_PyInfo.PY3, sys.version_info[0] == 3)

# Generated at 2022-06-24 03:00:00.018548
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert inspect.isclass(_PyInfo)
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not (_PyInfo.PY2 and _PyInfo.PY3)
    assert hasattr(_PyInfo, 'string_types')
    assert hasattr(_PyInfo, 'text_type')
    assert hasattr(_PyInfo, 'binary_type')
    assert _PyInfo.string_types == (str,) if _PyInfo.PY3 else (basestring,)
    assert _PyInfo.text_type == str if _PyInfo.PY3 else unicode
    assert _PyInfo.binary_type == bytes if _PyInfo.PY3 else str

# Generated at 2022-06-24 03:00:09.440758
# Unit test for function logger_level
def test_logger_level():
    from contextlib import ExitStack
    import logging

    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.INFO)

    capture = logging.LoggerAdapter(logger, {'name': 'test'})

    try:
        with ExitStack() as stack:
            stack.enter_context(logger_level(logger, logging.DEBUG))
            logger.debug('debug message')
            with logger_level(logger, logging.ERROR):
                logger.error('error message')
        capture.info('info message')
        capture.warning('warning message')

    except Exception:
        raise
    else:
        # Fail if we see any DEBUG messages in the output
        lines = sys.stdout.getvalue().splitlines()

# Generated at 2022-06-24 03:00:12.150780
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-24 03:00:20.276612
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.string_types == basestring if sys.version_info[0] == 2 else str
    assert _PyInfo.text_type == unicode if sys.version_info[0] == 2 else str
    assert _PyInfo.binary_type == str if sys.version_info[0] == 2 else bytes



# Generated at 2022-06-24 03:00:23.015495
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.info("This should not print.")
    logger.info("This should print.")
    logger.error("This should print.")
    assert logger.level == logging.ERROR

if __name__ == "__main__":
    configure()
    test_logger_level()

# Generated at 2022-06-24 03:00:26.183636
# Unit test for function get_config
def test_get_config():
    logging_config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    assert logging_config == DEFAULT_CONFIG


# Generated at 2022-06-24 03:00:31.325437
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance("", _PyInfo.string_types)
    assert isinstance("", _PyInfo.text_type)
    assert isinstance("", _PyInfo.binary_type)

    assert isinstance("", type(""))
    assert not isinstance("", type("")())

if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 03:00:36.960917
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert not (sys.version_info[0] == 2), 'sys.version_info[0] == 2'
    assert sys.version_info[0] == 3, 'sys.version_info[0] == 3'
    assert _PyInfo.PY2, '_PyInfo.PY2'
    assert not _PyInfo.PY3, '_PyInfo.PY3'



# Generated at 2022-06-24 03:00:43.383686
# Unit test for function logger_level
def test_logger_level():
    """Test for function logger_level."""
    import logging
    import sys

    logger = get_logger("test_logger_level")

    logger.setLevel(logging.DEBUG)
    assert logger.level == logging.DEBUG
    logger.debug("Test debug")
    logger.info("Test info")
    logger.warning("Test warning")
    logger.error("Test error")

    logger.setLevel(logging.INFO)
    assert logger.level == logging.INFO
    logger.debug("Test debug")
    logger.info("Test info")
    logger.warning("Test warning")
    logger.error("Test error")

    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
        logger.debug("Test debug")
        logger.info("Test info")

# Generated at 2022-06-24 03:00:47.122653
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger("test_configure")
    log.setLevel(logging.DEBUG)
    log.debug("tests running")

    with logger_level(log, level=logging.ERROR):
        log.debug("this should not print")
    log.debug("this should print")
    log.error("this should print")
    log.info("this should not print")


# Generated at 2022-06-24 03:00:55.440028
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:  # PY2
        assert _PyInfo.string_types == (basestring,)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:00:58.242270
# Unit test for function configure
def test_configure():
    logging.shutdown()
    log = get_logger(__name__)
    configure()
    log.info('Test configure')
    logging.shutdown()


# Generated at 2022-06-24 03:01:03.522888
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log.debug("to be removed")
    with logger_level(log, logging.DEBUG):
        log.debug("this should not be prited")
    log.debug("this should not be prited either")

if __name__ == "__main__":
    configure()
    test_getLogger()

# Generated at 2022-06-24 03:01:10.105459
# Unit test for function get_config
def test_get_config():
    assert dict == type(get_config(None, env_var=None, default=DEFAULT_CONFIG))

    assert dict == type(get_config('{"a": 1, "b": 2}', env_var=None, default=DEFAULT_CONFIG))

    assert dict == type(get_config('a: 1\nb: 2', env_var=None, default=DEFAULT_CONFIG))

    try:
        assert dict == type(get_config('a: 1, b: 2', env_var=None, default=DEFAULT_CONFIG))
    except Exception as exc:
        assert True
    else:
        assert False



# Generated at 2022-06-24 03:01:14.996415
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    assert(logger.getEffectiveLevel() == logging.DEBUG)
    with logger_level(logger,logging.INFO):
        assert(logger.getEffectiveLevel() == logging.INFO)
    assert(logger.getEffectiveLevel() == logging.DEBUG)

# Generated at 2022-06-24 03:01:24.582719
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert logging.DEBUG == 10
    assert logging.INFO == 20
    assert logging.WARNING == 30
    assert logging.ERROR == 40
    assert logging.CRITICAL == 50
    if _PyInfo.PY2:
        assert isinstance('str',_PyInfo.string_types)
        assert isinstance(u'uni',_PyInfo.string_types)
        assert not isinstance(b'byte',_PyInfo.string_types)
        assert isinstance(u'string',_PyInfo.text_type)
        assert not isinstance('string',_PyInfo.text_type)
        assert isinstance(b'string',_PyInfo.binary_type)
        assert not isinstance(u'string',_PyInfo.binary_type)

# Generated at 2022-06-24 03:01:30.038133
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    if _PyInfo.PY3:
        assert isinstance('', _PyInfo.text_type)
        assert isinstance(b'', _PyInfo.binary_type)
        assert isinstance(u'', _PyInfo.text_type)
    else:
        assert isinstance('', _PyInfo.string_types)
        for i in _PyInfo.string_types:
            assert isinstance('', i)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:01:37.405714
# Unit test for function getLogger
def test_getLogger():
    # using a logger before it is configured will produce a warning
    # the code below is a workaround for that
    logging.basicConfig()

    logger = getLogger()
    assert type(logger) is logging.Logger
    assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.name == __name__

    logger = getLogger("test_name")
    assert type(logger) is logging.Logger
    assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.name == "test_name"


# Generated at 2022-06-24 03:01:46.399307
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # test with json
    json_config = '{"a": "b"}'
    assert get_config(config=json_config) == yaml.load(json_config)
    assert get_config(config=json.loads(json_config)) == yaml.load(json_config)

    # test with yaml
    yaml_config = 'a: b'
    assert get_config(config=yaml_config) == yaml.load(yaml_config)

    # test with bare strings
    # This is deprecated, so don't test it.



# Generated at 2022-06-24 03:01:50.009248
# Unit test for function logger_level
def test_logger_level():
    level = logging.DEBUG
    with logger_level(logger=logging.getLogger(__name__), level=level):
        assert logging.getLogger(__name__).level == level

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 03:01:55.052201
# Unit test for function configure
def test_configure():
    log = get_logger()
    log.info('test')

    log = get_logger('test2')
    log.info('test2')

# Generated at 2022-06-24 03:02:02.135956
# Unit test for function logger_level
def test_logger_level():
    import sys

    # Capture stdout so we can test
    capture = []
    old_stdout = sys.stdout
    sys.stdout = capture
    # Setup logger
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        # The log should be written to stdout
        logger.info('hello')
        assert len(capture) == 1
    # The log should not be written to stdout
    logger.info('world')
    assert len(capture) == 1
    # Reset stdout to normal
    sys.stdout = old_stdout



_CURRENT_LOGGERS = []



# Generated at 2022-06-24 03:02:08.741764
# Unit test for function configure
def test_configure():
    from unittest.mock import patch

    with patch('logging.config.dictConfig') as mock_dic:
        configure()
        mock_dic.assert_called_once_with(DEFAULT_CONFIG)

    with patch('logging.config.dictConfig') as mock_dic:
        logging.config.dictConfig = 2
        mock_dic.return_value = 2
        configure()
        mock_dic.assert_called_once_with(DEFAULT_CONFIG)


if __name__ == '__main__':
    configure()
    test_configure()

# Generated at 2022-06-24 03:02:15.364189
# Unit test for function configure
def test_configure():
    import logging

    configure()

    # Logging is configured
    logger = logging.getLogger(__name__)
    assert logger.level == logging.DEBUG


# Generated at 2022-06-24 03:02:16.784107
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger('test')

    assert logger.getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-24 03:02:22.283540
# Unit test for function get_config
def test_get_config():
    config = get_config(dict(key='value'))
    assert config == {'key': 'value'}

    # test dictConfig works too
    assert logging.config.dictConfig(config) is None

    config = get_config(json.dumps(dict(key='value')))
    assert config == {'key': 'value'}

    config = get_config(yaml.dump(dict(key='value')))
    assert config == {'key': 'value'}

    with pytest.raises(ValueError):
        get_config(None)



# Generated at 2022-06-24 03:02:26.166327
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert(_PyInfo.PY2 is True)
    assert(_PyInfo.PY3 is False)
    assert(_PyInfo.string_types == (basestring,))
    assert(_PyInfo.text_type == unicode)
    assert(_PyInfo.binary_type == str)


# Generated at 2022-06-24 03:02:37.246494
# Unit test for function get_config
def test_get_config():
    # test with good input
    def _test_get_config_good_input(good_input):
        config = get_config(good_input,None,None)
        assert config == good_input
    _test_get_config_good_input({'version':1})
    _test_get_config_good_input([])

    # test with bad input
    def _test_get_config_bad_input(good_input):
        try:
            get_config(good_input,None,None)
            assert False
        except ValueError as exc:
            assert True
    _test_get_config_bad_input(None)

    # test with string input
    def _test_get_config_string_input(good_input,config):
        assert get_config(good_input,None,None) == config


# Generated at 2022-06-24 03:02:39.283430
# Unit test for function getLogger
def test_getLogger():
    log = get_logger(__name__)
    assert log is not None
    log.debug('test_getLogger')



# Generated at 2022-06-24 03:02:41.397507
# Unit test for function configure
def test_configure():
    configure()

# vim:set ft=python sw=4 et spell spelllang=en:

# Generated at 2022-06-24 03:02:42.977847
# Unit test for function configure
def test_configure():
    # Test function with default argument
    configure()

    # Test function with default argument
    assert type(get_config()) is dict

# Generated at 2022-06-24 03:02:49.226664
# Unit test for function configure
def test_configure():
    try:
        configure()
        logging.info('test')
    except Exception as e:
        configure(config=DEFAULT_CONFIG)
        logging.info('test')


# Generated at 2022-06-24 03:02:54.480967
# Unit test for function logger_level
def test_logger_level():
    import unittest

    class TestLoggerLeve(unittest.TestCase):
        def test_logger_level(self):
            logger = getLogger(__name__)
            with logger_level(logger, logging.NOTSET):
                self.assertEqual(logger.level, logging.NOTSET)
            self.assertEqual(logger.level, logging.DEBUG)
    unittest.main()

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 03:02:57.828929
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False
    assert isinstance(inspect.stack()[0][0], frame) == True


# Generated at 2022-06-24 03:03:02.119020
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)


# Generated at 2022-06-24 03:03:12.158969
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    with logger_level(logger, 'INFO'):
        logger.debug('This should not be seen')
        logger.info('This should be seen')
        logger.error('This should be seen')

    logger.debug('This should be seen')
    logger.info('This should be seen')
    logger.error('This should be seen')



# Generated at 2022-06-24 03:03:18.104617
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import sys
    import os
    import json

    # This unittest is for py2k compat
    if sys.version_info[0] == 3:
        # skip unittest
        return

    log = get_logger()

    # check constructor of class _PyInfo
    assert _PyInfo.PY2 is True
    assert _PyInfo.PY3 is False


if __name__ == "__main__":
    test__PyInfo()

# Generated at 2022-06-24 03:03:22.926629
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == False 
    assert pyinfo.PY3 == True 
    assert pyinfo.string_types == (str,)
    assert pyinfo.text_type == str
    assert pyinfo.binary_type == bytes


# Generated at 2022-06-24 03:03:24.362576
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-24 03:03:30.148715
# Unit test for function get_config
def test_get_config():
    import os
    import json
    import yaml

    try:
        config = get_config()
    except ValueError as e:
        print(e)

    os.environ['LOGGING'] = '{"version": 1}'
    try:
        config = get_config()
    except ValueError as e:
        print(e)

    os.environ['LOGGING'] = '{"version": 1, "formatters": {"simple": {"format": "%(levelname)s %(asctime)s %(message)s"}}, "handlers": {"wsgi": {"class": "logging.StreamHandler", "stream": "ext://flask.logging.wsgi_errors_stream", "formatter": "simple"}}, "root": {"level": "DEBUG", "handlers": ["wsgi"]}}'