

# Generated at 2022-06-24 02:53:39.048953
# Unit test for function logger_level
def test_logger_level():
    from unittest import TestCase, mock
    import logging

    class TestLoggerLevel(TestCase):
        @mock.patch('logging.Logger.setLevel')
        @mock.patch('logging.Logger.getEffectiveLevel')
        def test_set_logger_level(self, mock_getEffectiveLevel, mock_setLevel):
            # Setup
            logger = logging.getLogger('test')
            level = logging.DEBUG

            mock_getEffectiveLevel.return_value = True

            # Run test
            with logger_level(logger, level):
                mock_setLevel.assert_called_with(level)

            # Assertion
            mock_setLevel.assert_has_calls([
                mock.call(level),
                mock.call(True),
            ])

    test_logger_

# Generated at 2022-06-24 02:53:44.986208
# Unit test for function configure
def test_configure():
    from io import BytesIO

    from colorlog import ColoredFormatter

    # Test 1: should ignore the DEFAULT_CONFIG and use the logging.basicConfig.
    old_stderr = sys.stderr
    sys.stderr = BytesIO()
    configure()
    log = logging.getLogger(__name__)
    log.info('test')
    stderr = sys.stderr
    sys.stderr = old_stderr

    logging.basicConfig(format='%(levelname)s:%(message)s')

    log.info('test')

    # Test 2: should use the DEFAULT_CONFIG dictionary, and have logging.basicConfig raise an Exception.
    old_stderr = sys.stderr
    sys.stderr = BytesIO()

    configure()

# Generated at 2022-06-24 02:53:46.857995
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    a = _PyInfo()
    print("a: ", a)



# Generated at 2022-06-24 02:53:57.706212
# Unit test for function configure
def test_configure():
    from io import StringIO

    conf = """
    {
    "version": 1,
    "formatters": {
        "simple": {
            "format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}},
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "simple",
            "level": "DEBUG"}},
    "root": {"handlers": ["console"], "level": "DEBUG"}}
    """
    saved_std

# Generated at 2022-06-24 02:54:00.889533
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    logger.info('test')



# Generated at 2022-06-24 02:54:09.019958
# Unit test for function get_config
def test_get_config():
    # Naked string
    assert get_config('{"foo": "bar"}') == {'foo': 'bar'}
    # JSON
    assert get_config('{"foo": "bar"}') == {'foo': 'bar'}
    # YAML
    assert get_config("foo: bar") == {'foo': 'bar'}
    # Bad JSON
    try:
        get_config('{"foo": "bar"')
    except:
        assert True
    else:
        assert False
    # Bad YAML
    try:
        get_config('{"foo": "bar"')
    except:
        assert True
    else:
        assert False
    # No config provided
    try:
        get_config()
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-24 02:54:11.716829
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-24 02:54:16.866523
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.NOTSET



# Generated at 2022-06-24 02:54:22.217378
# Unit test for function getLogger
def test_getLogger():
    try:
        log = getLogger()
        print(log)
        log.info("Test")
    except:
        print("fail")


if __name__ == '__main__':

    if len(sys.argv) < 2:
        print("Usage: python log.py funcname")
        sys.exit(0)
    else:
        funcname = sys.argv[1]
        eval(funcname)()

# Generated at 2022-06-24 02:54:24.948948
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO

# Generated at 2022-06-24 02:54:30.463168
# Unit test for function getLogger
def test_getLogger():
    import unittest
    import logging

    class LoggingTestCase(unittest.TestCase):
        def test_getLogger(self):
            log = get_logger()
            self.assertEqual(log, logging.getLogger('test.test_logger'))

    unittest.main()

# Generated at 2022-06-24 02:54:35.350431
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.ERROR):
        logger.debug('Should not see this.')
        logger.info('Should not see this.')
        logger.error('Should see this.')
        logger.warning('Should see this.')
        logger.critical('Should see this.')

# Generated at 2022-06-24 02:54:37.919346
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert 'str' == pyinfo.text_type
    assert 'str' == pyinfo.binary_type
    assert ('str',) == pyinfo.string_types


# Generated at 2022-06-24 02:54:42.054589
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("test_logger_level")
    assert logger.level == 0
    try:
        with logger_level(logger, logging.WARNING):
            assert logger.level == 30
            logger_level(logger, logging.INFO)
            assert logger.level == 20
    finally:
        assert logger.level == 30
    assert logger.level == 0



# Generated at 2022-06-24 02:54:44.486366
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger('test'), logging.WARNING):
        assert logging.getLogger('test').getEffectiveLevel() == logging.WARNING
    assert logging.getLogger('test').getEffectiveLevel() == logging.INFO

# Generated at 2022-06-24 02:54:49.816186
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert(isinstance(_PyInfo.string_types[0], type))
    assert(isinstance(_PyInfo.text_type, type))
    assert(isinstance(_PyInfo.binary_type, type))
    assert(_PyInfo.PY2 or _PyInfo.PY3)
    assert(not (_PyInfo.PY2 and _PyInfo.PY3))
    if _PyInfo.PY2:
        assert(_PyInfo.string_types == (str, unicode))
        assert(_PyInfo.text_type == unicode)
        assert(_PyInfo.binary_type == str)
    elif _PyInfo.PY3:
        assert(_PyInfo.string_types == (str,))
        assert(_PyInfo.text_type == str)
        assert(_PyInfo.binary_type == bytes)



# Generated at 2022-06-24 02:54:59.167838
# Unit test for function configure
def test_configure():

    logging.basicConfig()

    log = logging.getLogger('test_configure')
    log.debug('test_configure')

    # log = getLogger('configure.test')
    # log.debug('configure.test')

    configure(
        config=DEFAULT_CONFIG,
        env_var='LOGGING'
    )

    # log = getLogger('configure.test')
    # log.debug('configure.test')

    log = logging.getLogger('test_configure')
    log.debug('test_configure')

    # log = logging.getLogger('configure.test')
    # log.debug('configure.test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:55:05.065279
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    assert log.__dict__['name'] == 'logging_utils'


# Generated at 2022-06-24 02:55:11.049587
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    log.debug('initial debug log')
    log.info('initial info log')
    assert log.getEffectiveLevel() == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.getEffectiveLevel() == logging.INFO
        log.debug('debug log inside context manager')
        log.info('info log inside context manager')
    assert log.getEffectiveLevel() == logging.DEBUG
    log.debug('debug log outside context manager')
    log.info('info log outside context manager')


# Generated at 2022-06-24 02:55:20.451089
# Unit test for function getLogger
def test_getLogger():
    from io import StringIO
    from .utils import capture_stdout
    log = getLogger('TESTING')
    assert log.name == 'TESTING'
    with capture_stdout() as s:
        log.info('test')
    assert 'test' in s.getvalue()


if __name__ == '__main__':
    # Unit test for function get_config
    def test_get_config():
        import json
        import yaml


# Generated at 2022-06-24 02:55:28.326777
# Unit test for function configure
def test_configure():
    """
    >>> configure({'version': 1, 'formatters': {'simple': {'format': '%(message)s', 'datefmt': '%Y-%m-%d %H:%M:%S'}}, 'handlers': {'console': {'class': 'logging.StreamHandler', 'level': 'DEBUG', 'formatter': 'simple'}}, 'root': {'level': 'DEBUG', 'handlers': ['console']}})
    >>> log = logging.getLogger(__name__)
    >>> log.setLevel(logging.DEBUG)
    >>> log.info('test')
    test
    >>> log.warn('test')
    test
    >>> log.error('test')
    test
    """



# Generated at 2022-06-24 02:55:31.360547
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    assert logger.level == logging.NOTSET

    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO

    assert logger.level == logging.NOTSET



# Generated at 2022-06-24 02:55:36.406535
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.debug('test')


# For pytest - s.t. py.test . doesn't raise error
test_configure()

# Generated at 2022-06-24 02:55:38.866478
# Unit test for function logger_level
def test_logger_level():
    import logging
    root_logger = logging.getLogger()
    default_level = root_logger.level
    new_level = logging.DEBUG
    with logger_level(root_logger, new_level):
        assert root_logger.level == new_level
    assert root_logger.level == default_level

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:55:46.211478
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    log = logging.getLogger('test_logger_level')
    with logger_level(log, logging.DEBUG):
        log.critical('critical')
        log.error('error')
        log.warning('warn')
        log.info('info')
        log.debug('debug')
    log.critical('critical')
    log.error('error')
    log.warning('warn')
    log.info('info')
    log.debug('debug')



# Generated at 2022-06-24 02:55:52.935147
# Unit test for function configure
def test_configure():
    import colorlog
    log = logging.getLogger('log')
    formatter = logging.Formatter('%(asctime)s| %(name)s: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s',
                                  datefmt='%Y-%m-%d %H:%M:%S')
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)
    log.info('test')


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:56:04.794712
# Unit test for function configure
def test_configure():
    import tempfile

    # Test configuring a logger with a config file
    config_file = tempfile.NamedTemporaryFile(mode='wt', delete=True)
    config_file.write('{"version": 1, "root": {"level": "DEBUG"}}')
    config_file.flush()

    logging.config.dictConfig(config_file.name)
    log = logging.getLogger()
    assert log.level == logging.DEBUG

    # Test passing in a json string
    config = '{"version": 1, "root": {"level": "INFO"}}'
    logging.config.dictConfig(config)
    log = logging.getLogger()
    assert log.level == logging.INFO

    # Test passing in a dict, which is a bit of a weird edge case since you
    # could just pass the result of json.loads

# Generated at 2022-06-24 02:56:06.324652
# Unit test for function get_config
def test_get_config():
    assert get_config(default='{"version": 1}') == {'version': 1}



# Generated at 2022-06-24 02:56:07.741097
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.debug('test')

# Generated at 2022-06-24 02:56:15.660682
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        with tempfile.NamedTemporaryFile() as fp:
            logger.debug('test_logger_level')
            assert 'DEBUG' in fp.read().decode('utf8')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:56:19.221764
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    original_level = log.level

    with logger_level(log, logging.DEBUG):
        log.debug('this should log')
        log.info('this should log')

    log.debug('this should not log')
    log.info('this should log')

    log.setLevel(original_level)


# Generated at 2022-06-24 02:56:24.333701
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    with logger_level(log, logging.CRITICAL):
        log.debug('Should not show up')
        log.info('Should not show up')
    log.debug('This will show up')



# Generated at 2022-06-24 02:56:29.083879
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    log.info('Testing logger_level')
    with logger_level(log, logging.DEBUG):
        log.debug('Debug level on')
    log.debug('Debug level off')
    log.info('After logger_level')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:56:34.463170
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert not _PyInfo.PY3
    assert isinstance('', _PyInfo.string_types)
    assert isinstance(u'', _PyInfo.string_types)
    assert isinstance('', _PyInfo.text_type)
    assert isinstance(b'', _PyInfo.binary_type)



# Generated at 2022-06-24 02:56:39.242025
# Unit test for function configure
def test_configure():
    f = get_logger()
    with logger_level(f, logging.INFO):
        f.debug('This should not be printed')
        f.info('This should be printed')
        f.warn('And this too')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:56:47.153955
# Unit test for function get_config
def test_get_config():
    # test for bare config
    given_config = "simple"
    default_config = {"formatters": {"simple": {'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s', 'datefmt': '%Y-%m-%d %H:%M:%S'}}}

    config = get_config(given_config, None, default_config)

    assert config == default_config

    # test for json config

# Generated at 2022-06-24 02:56:59.155347
# Unit test for function configure

# Generated at 2022-06-24 02:57:03.120470
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True or _PyInfo.PY2 == False
    assert _PyInfo.PY3 == True or _PyInfo.PY3 == False

# Generated at 2022-06-24 02:57:05.674473
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.debug('test')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:57:11.462722
# Unit test for function logger_level
def test_logger_level():
    import sys
    import StringIO

    stream = StringIO.StringIO()
    handler = logging.StreamHandler(stream)
    log = logging.getLogger('test_logger_level')
    log.addHandler(handler)
    log.setLevel(logging.INFO)

    with logger_level(log, logging.DEBUG):
        log.debug('Testing logger_level')

    assert stream.getvalue() == 'Testing logger_level\n'


# Generated at 2022-06-24 02:57:12.971582
# Unit test for function configure
def test_configure():
    logger = get_logger(__name__)
    logger.info('something to say')



# Generated at 2022-06-24 02:57:17.154855
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    >>> pyinfo = _PyInfo()
    >>> pyinfo.PY2
    True
    >>> pyinfo.PY3
    False
    >>> pyinfo.string_types[0]
    <class 'basestring'>
    >>> pyinfo.text_type
    <class 'unicode'>
    >>> pyinfo.binary_type
    <class 'str'>
    """
    pass

# Generated at 2022-06-24 02:57:26.897350
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test_getLogger')
    logger.debug('This is debug message')
    logger.info('This is info message')
    logger.warn('This is warn message')
    logger.error('This is error message')
    logger.critical('This is critical message')
    logger.setLevel(logging.CRITICAL)
    logger.debug('This is debug message')
    logger.info('This is info message')
    logger.warn('This is warn message')
    logger.error('This is error message')
    logger.critical('This is critical message')
    try:
        raise RuntimeError

    except RuntimeError:
        logger.exception('This is exception message')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:57:28.302220
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("You should see this")
    log.debug("You should NOT see this")

# Generated at 2022-06-24 02:57:30.284715
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    assert 'logging_util' in log.name

# Generated at 2022-06-24 02:57:37.267369
# Unit test for function get_config
def test_get_config():
    from json import dumps
    from yaml import safe_dump
    from tempfile import NamedTemporaryFile

    config = dict(a=1, b=[1,{'c': 2}])
    for dumper in dumps, safe_dump:
        with NamedTemporaryFile() as f:
            f.write(dumper(config).encode())
            f.flush()
            assert get_config(config) == config
            assert get_config(f.name) == config

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:57:46.662399
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    cfg_str = '{"version": 1}'
    cfg = get_config(cfg_str)
    assert cfg == json.loads(cfg_str), 'json'

    cfg_str = 'version: 1'
    cfg = get_config(cfg_str)
    assert cfg == yaml.load(cfg_str), 'yaml'

    cfg_str = 'version: 1'
    cfg = get_config(cfg_str, default='foo')
    assert cfg == yaml.load(cfg_str), 'yaml from file'

    cfg_str = 'version: 1'
    cfg = get_config(cfg_str, env_var='LOGGING')

# Generated at 2022-06-24 02:57:53.127402
# Unit test for function configure
def test_configure():
    import tempfile
    import os

    with tempfile.NamedTemporaryFile(delete=False) as f:
        tmp_file_name = f.name
        f.write(b'{"version": 1, "loggers": {"": {"level": "INFO"}}}')
        f.close()


# Generated at 2022-06-24 02:58:03.478016
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False
    assert _PyInfo.string_types == (basestring,)
    assert isinstance('', _PyInfo.string_types)
    assert isinstance(u'', _PyInfo.string_types)
    assert not isinstance(b'', _PyInfo.string_types)
    assert _PyInfo.text_type == unicode
    assert isinstance(u'', _PyInfo.text_type)
    assert not isinstance('', _PyInfo.text_type)
    assert not isinstance(b'', _PyInfo.text_type)
    assert _PyInfo.binary_type == str
    assert isinstance(b'', _PyInfo.binary_type)

# Generated at 2022-06-24 02:58:07.030228
# Unit test for function logger_level
def test_logger_level():
    def foo():
        logger = get_logger()
        with logger_level(logger, logging.INFO):
            logger.info('message')
        logger.info('message2')
    buf = StringIO()
    with override_stdio(buf):
        foo()
    print(buf.getvalue())

# Generated at 2022-06-24 02:58:12.913011
# Unit test for function configure
def test_configure():
    """
    >>> import json
    >>> import logging
    >>> with open(os.path.join(os.path.dirname(__file__), 'logging.json'), 'r') as f:
    ...     d = json.load(f)
    >>> configure(d)

    >>> import logging
    >>> logging.getLogger().info('test')
    """
    pass

# Generated at 2022-06-24 02:58:21.776137
# Unit test for function configure
def test_configure():
    import logging
    import os
    import json

    from cStringIO import StringIO

    sio = StringIO()
    fh = logging.FileHandler(sio)

# Generated at 2022-06-24 02:58:27.022353
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("tests.logger_level")
    orig_level = logger.getEffectiveLevel()
    logger.warning("First log line.")

    with logger_level(logger, logging.CRITICAL):
        logger.warning("This line should not be shown.")
        with logger_level(logger, logging.DEBUG):
            logger.debug("This line should be shown.")

    logger.warning("Last log line.")

    assert logger.getEffectiveLevel() == orig_level



# Generated at 2022-06-24 02:58:34.916431
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    '''
    >>> pi = _PyInfo()
    >>> pi.PY2
    False
    >>> pi.PY3
    True
    >>> pi.string_types
    (<class 'str'>,)
    >>> pi.text_type
    <class 'str'>
    >>> pi.binary_type
    <class 'bytes'>
    '''
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:58:37.474930
# Unit test for function getLogger
def test_getLogger():
    #log = logging.getLogger()
    log = getLogger()
    #log = getLogger('test')
    log.info('test')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:58:47.515576
# Unit test for function get_config
def test_get_config():
    # Default config
    assert DEFAULT_CONFIG == get_config()
    # Config as dict
    assert dict(a=1) == get_config(dict(a=1))
    # Config as JSON string
    assert dict(a=1) == get_config('{"a": 1}')
    # Config as YAML string
    assert dict(a=1) == get_config('a: 1')
    assert dict(a=1) == get_config('a: 1\n')
    assert dict(a=1) == get_config('a: 1\n\n')
    assert dict(a=1) == get_config('a: 1\n\nb:2\n')
    # tests and examples below
    assert dict(a=1) == get_config(given=dict(a=1))

# Generated at 2022-06-24 02:58:53.599324
# Unit test for function getLogger
def test_getLogger():
    if __name__ == '__main__':
        logging.getLogger('logger.test1').error('test1')
        logging.getLogger('logger.test2').error('test2')
        logging.getLogger('logger.test2').error('test2')
        log = logging.getLogger('logger.test3')
        log.error('test3')
        log.error('test3')
        log.error('test3')
        log.error('test3')
        log.error('test3')
        log.error('test3')
        log.error('test3')
        log.error('test3')
        log.error('test3')
        log.error('test3')
        log.error('test3')
        log.error('test3')

# Generated at 2022-06-24 02:58:56.301299
# Unit test for function configure
def test_configure():
    logger = get_logger(__name__)
    logger.info('test_configure')
    assert True


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:58:58.747932
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    logger.info('test')


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 02:59:10.580882
# Unit test for function get_config
def test_get_config():
    # config = {'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'colored', 'level': 10}}}
    # config = '{"handlers": {"console": {"class": "logging.StreamHandler", "formatter": "colored", "level": 10}}}'
    # config = 'handlers \n\tconsole: \n\tclass: logging.StreamHandler\n\tformatter: colored\n\tlevel: 10'

    config = 'handlers\n console: \n\tclass: logging.StreamHandler\n\tformatter: colored\n\tlevel: 10'
    result = get_config(config)
    print("result=", result)


# Generated at 2022-06-24 02:59:16.915918
# Unit test for function logger_level
def test_logger_level():
    logger=get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test_debug')
        logger.info('test_info')
    logger.debug('test_debug2')
    logger.info('test_info2')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:59:18.438148
# Unit test for function getLogger
def test_getLogger():
    assert getLogger()
    assert isinstance(getLogger(), logging.Logger)



# Generated at 2022-06-24 02:59:19.183950
# Unit test for function getLogger
def test_getLogger():

    log = getLogger('test')
    log.info('test')

# Generated at 2022-06-24 02:59:28.819190
# Unit test for function getLogger
def test_getLogger():
    """
    getLogger is the main method to use in this module. It returns a
    Python `logging.Logger` instance with the appropriate configuration.
    """
    # Configure the logging module.
    configure()

    # Get a logger instance.
    log = getLogger()

    # Test some methods.
    log.debug("This is a debugging message!")
    log.info("A piece of information!")
    log.warning("A warning for the user!")
    log.error("Oops, an error has occurred!")
    log.critical("A critical error has occurred!")

    # Test handling of exceptions.
    try:
        raise RuntimeError("This is an error!")
    except RuntimeError as e:
        log.exception("An exception has occurred!")
        log.error("Reason: %s", e)

# Generated at 2022-06-24 02:59:37.443999
# Unit test for function get_config
def test_get_config():
    # Test config as a string
    config = '{"version": 1}'
    cfg = get_config(config, None, None)
    assert isinstance(cfg, dict)
    assert cfg["version"] == 1

    # Test config as a dict
    config = {"version": 1}
    cfg = get_config(config, None, None)
    assert isinstance(cfg, dict)
    assert cfg["version"] == 1

    # Test config from env_var
    os.environ["LOGGING"] = '{"version": 1}'
    cfg = get_config(None, "LOGGING", None)
    assert isinstance(cfg, dict)
    assert cfg["version"] == 1

    # Test config from default
    cfg = get_config(None, None, {"version": 1})

# Generated at 2022-06-24 02:59:39.316725
# Unit test for function getLogger
def test_getLogger():
    import __main__  # this module
    logger = getLogger()
    assert logger.name == __main__.__name__


# Generated at 2022-06-24 02:59:45.732551
# Unit test for function logger_level
def test_logger_level():
    logger_level(logging.getLogger(), logging.INFO)
    logging.getLogger().info("INFO")
    with logger_level(logging.getLogger(), logging.ERROR):
        logging.getLogger().error("ERROR")
        logging.getLogger().warn("WARN")
        logging.getLogger().info("INFO")
    logging.getLogger().info("INFO")



# Generated at 2022-06-24 02:59:52.501674
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 and not _PyInfo.PY3, '_PyInfo.PY2 should be False'
    assert not _PyInfo.PY2 and _PyInfo.PY3, '_PyInfo.PY2 should be True'

    assert issubclass(str, _PyInfo.string_types), '_PyInfo should return the right string types'
    assert issubclass(bytes, _PyInfo.binary_type), '_PyInfo should return the right binary type'
    assert issubclass(str, _PyInfo.text_type), '_PyInfo should return the right text type'


# Generated at 2022-06-24 02:59:54.080047
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert isinstance(pyinfo, object)



# Generated at 2022-06-24 03:00:00.018897
# Unit test for function configure
def test_configure():
    import tempfile
    import json

    temp_log_config = tempfile.NamedTemporaryFile()
    temp_log_config.file.write(json.dumps(DEFAULT_CONFIG))
    temp_log_config.file.flush()

    configure(config=DEFAULT_CONFIG)
    configure(env_var=None)
    configure(default=DEFAULT_CONFIG)
    configure(config=None)
    configure(env_var=temp_log_config.name)
    configure(default=None)



# Generated at 2022-06-24 03:00:03.517861
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not (_PyInfo.PY2 and _PyInfo.PY3)
    assert _PyInfo.string_types == (basestring,)


# Generated at 2022-06-24 03:00:07.863538
# Unit test for function logger_level
def test_logger_level():

    log = get_logger()
    # When using logger_level, level should be change
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    # When not using logger_level, level should not be change
    log.level = logging.INFO
    assert log.level == logging.INFO

test_logger_level()

# Generated at 2022-06-24 03:00:09.482021
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')



# Generated at 2022-06-24 03:00:10.727079
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test')
    assert logger is not None

# Generated at 2022-06-24 03:00:13.733269
# Unit test for function get_config
def test_get_config():
    with open('test.json') as f:
        expect_dict = json.load(f)
        config = get_config(default='test.json')
        assert config == expect_dict


if __name__ == "__main__":
    test_get_config()

# Generated at 2022-06-24 03:00:16.673132
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    for cls in _PyInfo.__dict__.values():
        if isinstance(cls, type):
            assert isinstance(cls(), cls)

# Generated at 2022-06-24 03:00:19.221312
# Unit test for function configure
def test_configure():
    log = get_logger(__name__)
    configure()
    try:
        # TODO
        assert True
    finally:
        logger_level(log, logging.CRITICAL)

# Generated at 2022-06-24 03:00:21.580690
# Unit test for function getLogger
def test_getLogger():
    configure()
    log = get_logger()
    # Fails on py3.4 if we use pycodestyle (pylama_pylint) and check for E701
    log.info('test')  # noqa



# Generated at 2022-06-24 03:00:25.610444
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    config_values = [
        {},
        {'key': 'value'},
        json.dumps({}),
        json.dumps({'key': 'value'}),
        yaml.dump({}),
        yaml.dump({'key': 'value'})
    ]

    for config in config_values:
        cfg = get_config(config)


# Generated at 2022-06-24 03:00:29.613345
# Unit test for function configure
def test_configure():
    logger = get_logger()
    logger.info('test')

# Generated at 2022-06-24 03:00:39.665430
# Unit test for function configure
def test_configure():
    """
    >>> _ensure_configured()
    """
    pass


# Usage examples...
#   import logging
#   from dpkt.main import configure
#
#   config = {
#       'version': 1,
#       'disable_existing_loggers': False,
#       'formatters': {
#           'colored': {
#               '()': 'colorlog.ColoredFormatter',
#               'format':
#               '%(bg_black)s%(log_color)s'
#               '[%(asctime)s] '
#               '[%(name)s/%(process)d] '
#               '%(message)s '
#               '%(blue)s@%(funcName)s:%(lineno)d '
#               '#%(levelname)s

# Generated at 2022-06-24 03:00:46.086377
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    _info = _PyInfo()
    assert _info.PY2 or _info.PY3, print("Neither PY2 nor PY3")
    if _info.PY2:
        assert _info.string_types == (basestring,)
        assert _info.text_type == unicode
        assert _info.binary_type == str
    elif _info.PY3:
        assert _info.string_types == (str,)
        assert _info.text_type == str
        assert _info.binary_type == bytes



# Generated at 2022-06-24 03:00:52.492070
# Unit test for function configure
def test_configure():
    import logging

    # log = logging.getLogger('python')
    # configure()
    # print(log.level)

    # log = logging.getLogger('testlog')
    # configure()
    # log.info('info')
    # log.debug('debug')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 03:01:01.792381
# Unit test for function get_config
def test_get_config():
    import json
    json_config = '{"version":1,"disable_existing_loggers":false, "formatters":{ "colored": {"()":"colorlog.ColoredFormatter","format":"%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s","datefmt":"%H:%M:%S"}}, "handlers":{"console":{"class":"logging.StreamHandler","formatter":"colored","level":10}}, "root":{"handlers":["console"],"level":10}, "loggers":{"requests":{"level":20}}}'
    config = get_config(json_config, None, None)

# Generated at 2022-06-24 03:01:10.105686
# Unit test for function configure
def test_configure():
    from io import StringIO
    import colorlog

    stream = StringIO()
    cfg = DEFAULT_CONFIG
    configure(cfg)

    log = logging.getLogger(__name__)
    log.info('info message')

    handler = logging.StreamHandler(stream)
    handler.setFormatter(colorlog.ColoredFormatter(
        '%(log_color)s'
        '%(message)s '
        '%(blue)s@%(funcName)s:%(lineno)d '
        '#%(levelname)s'
        '%(reset)s',
    ))

    log = logging.getLogger(__name__)
    log.addHandler(handler)
    log.info('info message')


# Generated at 2022-06-24 03:01:14.563231
# Unit test for function getLogger
def test_getLogger():
    """

    #>>> log = getLogger()
    #>>> log.info('test')

    #>>> log = getLogger('test2')
    #>>> log.info('test2')

    """
    pass



# Generated at 2022-06-24 03:01:20.176389
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3, 'Not PY2 or PY3'
    assert _PyInfo.string_types
    assert _PyInfo.text_type
    assert _PyInfo.binary_type


# Generated at 2022-06-24 03:01:26.859475
# Unit test for function getLogger
def test_getLogger():
    import sys
    import os
    import logging     
    os.chdir("../pulsar")
    #sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

    # define module variable
    MOCK_MODULE_NAME = "mock_module"
    MOCK_ROOT_NAME = "root"
    MOCK_LOGGER_NAME = MOCK_MODULE_NAME
    MOCK_LOGGER_LEVEL = "DEBUG"


# Generated at 2022-06-24 03:01:36.968926
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    fh = logging.StreamHandler()
    fh.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
   

# Generated at 2022-06-24 03:01:41.346770
# Unit test for function configure
def test_configure():
    cfg = get_config(default=DEFAULT_CONFIG)
    try:
        logging.config.dictConfig(cfg)
    except TypeError:
        logging.basicConfig(**cfg)

    logger = logging.getLogger(__name__)
    logger.info('test_configure')


# Generated at 2022-06-24 03:01:44.739068
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert not _PyInfo.PY3


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:01:47.620406
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger(__name__)
    log.info('test')


if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-24 03:01:50.392001
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert logger, "got logger"
    logger.info('test')

    logger = get_logger('test2')
    assert logger, "got logger"
    logger.info('test')

# Generated at 2022-06-24 03:01:55.090728
# Unit test for function get_config
def test_get_config():
    d = {"version": 1}
    assert get_config(config=json.dumps(d))
    assert get_config(config=yaml.dump(d))
    assert get_config(config=d)


if __name__ == '__main__':
    import doctest

    doctest.testmod()
    test_get_config()

# Generated at 2022-06-24 03:01:58.638093
# Unit test for function configure
def test_configure():
    logging.config.dictConfig(DEFAULT_CONFIG)
    logger = logging.getLogger('__name__')
    assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.parent.parent is logging.root
    assert logger.parent.name == '__name__'



# Generated at 2022-06-24 03:02:03.238134
# Unit test for function logger_level
def test_logger_level():
    """Tests that logger_level works as expected."""
    import unittest
    logger = getLogger()

    class TestF(unittest.TestCase):
        def runTest(self):
            with logger_level(logger, logging.WARN):
                logger.info('This is an info')
                logger.warn('This is a warn')

    unittest.main(module="__main__", exit=False, verbosity=0)

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 03:02:05.140016
# Unit test for function getLogger
def test_getLogger():
    if __name__ == '__main__':
        logger = get_logger()
        logger.debug('This is a test message')


# Generated at 2022-06-24 03:02:15.204725
# Unit test for function get_config
def test_get_config():
    # Default
    config = get_config()
    assert config['version'] == 1
    assert config['disable_existing_loggers'] == False
    assert config['formatters']['colored']['format'] == '%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s'
    assert config['formatters']['colored']['datefmt'] == '%H:%M:%S'

# Generated at 2022-06-24 03:02:16.335679
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3



# Generated at 2022-06-24 03:02:22.096777
# Unit test for function get_config
def test_get_config():
    # Config is None
    config = get_config()
    assert config == DEFAULT_CONFIG

    # Config is a bare string
    config = get_config(config="{}")
    assert config == {}

    # Config is a dictionary
    config = get_config(config={"a": 1})
    assert config == {"a": 1}

    # Config is a JSON string
    config = get_config(config='{"a": 1}')
    assert config == {"a": 1}

    # Config is an invalid JSON string
    try:
        config = get_config(config="{a: 1}")
    except ValueError:
        pass
    else:
        assert False, "Should raise ValueError"


# Generated at 2022-06-24 03:02:27.176906
# Unit test for function get_config
def test_get_config():
    assert get_config({'test': 1}) == {'test': 1}

    # json string config
    json_cfg = '{"test": 1}'
    assert get_config(json_cfg) == {'test': 1}

    # yaml string config
    yaml_cfg = 'test: 1'
    assert get_config(yaml_cfg) == {'test': 1}

# Generated at 2022-06-24 03:02:36.258553
# Unit test for function getLogger
def test_getLogger():
    import logging
    import logging.config
    import logging.handlers

    # These two lines enable debugging at httplib level (requests->urllib3->http.client)
    # You will see the REQUEST, including HEADERS and DATA, and RESPONSE with HEADERS but without DATA.
    # The only thing missing will be the response.body which is not logged.
    try:
        import http.client as http_client
    except ImportError:
        # Python 2
        import httplib as http_client

    http_client.HTTPConnection.debuglevel = 1

    # You must initialize logging, otherwise you'll not see debug output.
    logging.basicConfig()
    logging.getLogger().setLevel(logging.DEBUG)
    requests_log = logging.getLogger("requests.packages.urllib3")
    requests

# Generated at 2022-06-24 03:02:42.790158
# Unit test for function logger_level
def test_logger_level():
    # Check that level is correctly set
    with logger_level(logging.getLogger('test'), logging.INFO):
        logging.getLogger('test').debug('Tesing')
        assert(logging.getLogger('test').level==logging.INFO)
    # Check that level is reset correctly
    assert(logging.getLogger('test').level==logging.DEBUG)
    
    

# Generated at 2022-06-24 03:02:48.257629
# Unit test for function get_config
def test_get_config():
    cfg = get_config('{"version":1,"root":{"level":"INFO"}}')
    assert(cfg['root']['level'] == "INFO")


# Generated at 2022-06-24 03:02:51.297457
# Unit test for function configure
def test_configure():
    print("\n=================== Testing configuration ===================")

    configure()
    log = logging.getLogger("test_log")
    log.info("test")


test_configure()



# Generated at 2022-06-24 03:03:01.882968
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    def check(given, expect):
        assert get_config(given) == expect

    check(None, DEFAULT_CONFIG)
    check({}, {})
    check(json.dumps({}), {})
    check(yaml.dump({}), {})
    check('{}', {})
    check('[]', [])
    check(yaml.dump([]), [])
    check('{"abc": "def"}', {'abc': 'def'})
    check(yaml.dump({'abc': 'def'}), {'abc': 'def'})
    check('{abc: def}', {'abc': 'def'})

# Generated at 2022-06-24 03:03:12.097454
# Unit test for function configure
def test_configure():
    from functools import partial

    logger = getLogger(__name__)
    logger.info("Should not see anything")


# Generated at 2022-06-24 03:03:17.844022
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    log.debug('test debug')
    log.info('test info')
    log.warn('test warn')

    with logger_level(log, logging.WARN):
        log.debug('test debug')
        log.info('test info')

    log.debug('test debug')
    log.info('test info')
    log.warn('test warn')


# Generated at 2022-06-24 03:03:22.537832
# Unit test for function logger_level
def test_logger_level():
    """Unit test for the logger_level function."""
    logger = logging.getLogger("test")
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)



# Generated at 2022-06-24 03:03:24.417099
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.string_types == (str, basestring, unicode)
    assert _PyInfo.text_type == str
    assert _PyInfo.binary_type == bytes

# Generated at 2022-06-24 03:03:26.898468
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.FATAL):
        logger.info("This should not print")
    logger.warning("This should print")

# Generated at 2022-06-24 03:03:35.795262
# Unit test for function get_config
def test_get_config():
    # Validate: invalid config param results in exception
    invalid_configs = [
        None,
        1,
        dict()
    ]

    for invalid_config in invalid_configs:
        try:
            return_value = get_config(invalid_config)
        except:
            # TODO: handle exception logging
            pass
        else:
            raise ValueError("get_config for invalid config %s did not raise an exception " % invalid_config)

    # Validate: json input
    json_string = '{"version": 1, "disable_existing_loggers": true}'
    expected_return = {"version": 1, "disable_existing_loggers": True}

    return_value = get_config(json_string)

    assert return_value == expected_return

    # Validate: yaml input
    yaml