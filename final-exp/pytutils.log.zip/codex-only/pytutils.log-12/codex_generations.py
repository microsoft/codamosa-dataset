

# Generated at 2022-06-24 02:53:39.737099
# Unit test for function get_config

# Generated at 2022-06-24 02:53:46.956879
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3
    assert _PyInfo.string_types == (str,)
    assert _PyInfo.text_type == str
    assert _PyInfo.binary_type == bytes


if __name__ == '__main__':
    log = get_logger()
    log.info('test')
    log = get_logger('test2')
    log.info('test2')
    test__PyInfo()

# Generated at 2022-06-24 02:53:49.356398
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    assert logger is not None
    logger.info('test_getLogger')



# Generated at 2022-06-24 02:53:57.246096
# Unit test for function get_config
def test_get_config():
    config = {'handlers': {'console': {'level': 'DEBUG'}}}
    assert get_config(given=config) == config
    assert get_config(
        given='{"handlers":{"console":{"level":"DEBUG"}}}'
    ) == config
    assert get_config(
        given='handlers:\n  console:\n    level: DEBUG'
    ) == config

    # Test for default
    assert get_config() == DEFAULT_CONFIG


if __name__ == '__main__':
    import doctest
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-24 02:54:07.737281
# Unit test for function getLogger
def test_getLogger():
    from tempfile import TemporaryFile
    from contextlib import closing

    with TemporaryFile('w+') as f:
        with closing(file(f, 'w+')) as ff:
            import sys
            sys.stdout = ff
            getLogger().info('test')

    with TemporaryFile('w+') as f:
        with closing(file(f, 'r')) as ff:
            assert 'test' in ff.read()



# Generated at 2022-06-24 02:54:08.904365
# Unit test for function get_config
def test_get_config():
    print(get_config())



# Generated at 2022-06-24 02:54:12.947779
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
        log.debug('logging debug message')

    assert log.level == logging.NOTSET
    log.debug('logging another debug message')
    log.warning('logging warning message')



# Generated at 2022-06-24 02:54:18.610872
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')
    log.error('test2')
    log.error('test2')

    log = get_logger('test2')
    log.info('test')
    log.error('test2')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:54:25.223632
# Unit test for function configure
def test_configure():
    from tempfile import NamedTemporaryFile

    levels = [logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR]
    handlers = ['console']
    loggers = {'test_configure': dict(level=logging.INFO)}
    # debug, info, warning, error
    for level in levels:
        for handler in handlers:
            config = dict(DEFAULT_CONFIG)
            config['root']['level'] = level
            config['handlers'][handler]['level'] = level
            config['loggers']['test_configure']['level'] = level
            with NamedTemporaryFile() as fp:
                fp.write(u'LOGGING={}'.format(config).encode('utf-8'))
                fp.flush()

# Generated at 2022-06-24 02:54:29.226620
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    print(log.getEffectiveLevel())


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:54:38.932232
# Unit test for function get_config

# Generated at 2022-06-24 02:54:43.857269
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.WARNING):
        log.info("info test")
        log.warning("warning test")
        # this must be printed
        log.critical("critical test")
        assert log.level == logging.WARNING
    # this must not be printed
    log.info("info test after resetting logging level")

# Generated at 2022-06-24 02:54:48.430054
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3

    if _PyInfo.PY3:
        assert (_PyInfo.string_types == (str,))
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes

    else:  # PY2
        assert (_PyInfo.string_types == (basestring,))
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str



# Generated at 2022-06-24 02:54:57.017874
# Unit test for function configure
def test_configure():
    import logging
    import tempfile
    with tempfile.NamedTemporaryFile() as tmp:
        tmp.write(b'''
version: 1
formatters:
    message_only:
        format: %(message)s
handlers:
    console:
        class: logging.StreamHandler
        formatter: message_only
        level: INFO
root:
    level: DEBUG
    handlers: [console]
loggers:
    modname:
        level: INFO
''')
        tmp.flush()
        try:
            configure(config=tmp.name, env_var='LOGGING')
            log = logging.getLogger('modname')
            assert log.level == logging.INFO
        finally:
            logging._acquireLock()

# Generated at 2022-06-24 02:54:58.584448
# Unit test for function configure
def test_configure():
    global configure
    logging.getLogger().setLevel(logging.DEBUG)
    configure()

# Generated at 2022-06-24 02:55:06.132935
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print("Testing _PyInfo")
    # Test values
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:  # PY2
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str


# Generated at 2022-06-24 02:55:07.325783
# Unit test for function logger_level
def test_logger_level():
    logger_level(logging.getLogger(""), 10)



# Generated at 2022-06-24 02:55:10.080361
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test')

    logger = getLogger('test2')
    logger.info('test2')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:55:12.297902
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.info('test')
        log.debug('test')
    log.debug('test')

# Generated at 2022-06-24 02:55:17.278604
# Unit test for function getLogger
def test_getLogger():
    """
    >>> test_getLogger()
    """
    logger = get_logger(__name__)
    logger.info("test_getLogger")



# Generated at 2022-06-24 02:55:24.110962
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert isinstance("", _PyInfo.string_types)
        assert isinstance("", _PyInfo.binary_type)
        assert not isinstance("", _PyInfo.text_type)
    else:
        assert isinstance("", _PyInfo.string_types)
        assert isinstance("", _PyInfo.text_type)
        assert not isinstance("", _PyInfo.binary_type)



# Generated at 2022-06-24 02:55:28.041417
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    # logger is None
    assert(logger)
    # logger's level is DEBUG by default
    assert(logger.level == logging.DEBUG)
    
    # set logger's level to INFO
    logger.setLevel(logging.INFO)
    assert(logger.level == logging.INFO)
    # now check if the logger's level will be changed
    logger = getLogger()
    assert(logger.level == logging.INFO)

# Generated at 2022-06-24 02:55:31.104042
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.WARNING):
        logger.debug('yup, this is debug')
        logger.warning('this is a warning')
    logger.info('this should show up normally')



# Generated at 2022-06-24 02:55:33.331383
# Unit test for function configure
def test_configure():
    from colorlog import ColoredFormatter

    assert isinstance(logging.getLogger().handlers[0].formatter,
                      ColoredFormatter)
    assert logging.getLogger().level == logging.DEBUG



# Generated at 2022-06-24 02:55:43.588057
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True or _PyInfo.PY2 == False
    assert _PyInfo.PY3 == True or _PyInfo.PY3 == False
    assert _PyInfo.PY2 != _PyInfo.PY3
    if _PyInfo.PY2:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    else:  # if _PyInfo.PY3
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes


if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 02:55:47.174892
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3


if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 02:55:48.411471
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    assert isinstance(log, logging.Logger)



# Generated at 2022-06-24 02:55:54.984954
# Unit test for function get_config
def test_get_config():
    """A function which tests various inputs for get_config and tests which
    works and which does not work. Also ensures that the expected result is obtained.
    """
    assert get_config(given=None) == DEFAULT_CONFIG
    assert get_config(given='{version=1 disable_existing_loggers=False}') == {'version': 1, 'disable_existing_loggers': False}
    assert get_config(given='{"version": 1, "disable_existing_loggers": false}') == {'version': 1, 'disable_existing_loggers': False}
    assert get_config(given='version: 1 disable_existing_loggers: false') == {'version': 1, 'disable_existing_loggers': False}

# Generated at 2022-06-24 02:56:05.833092
# Unit test for function configure
def test_configure():
    import tempfile
    import io

    logging.shutdown()

    # ------------------------
    # set config by json
    # ------------------------

    # Create a test log file
    path = tempfile.mktemp()

    # Create a config file with a 'filename' property
    config = io.StringIO()

# Generated at 2022-06-24 02:56:09.159945
# Unit test for function getLogger
def test_getLogger():
    # getLogger is nothing more than a wrapper for the logging.getLogger
    # expectsn the same and returns the same
    logger = getLogger('test_getLogger')
    assert logger is not None
    assert isinstance(logger, logging.Logger)


# Generated at 2022-06-24 02:56:17.868591
# Unit test for function getLogger
def test_getLogger():
    with logger_level(getLogger(), logging.DEBUG):
        import tempfile
        import os
        fd, fname = tempfile.mkstemp(prefix='logtest_')
        log = getLogger()
        log.debug('this is a debug message')
        log.info('this is an info message')
        log.warn('this is a warning message')

        # try to rotate the log and make sure it works
        # we have to break stuff to do this, so just make sure we can reset it
        try:
            del log.handlers[-1]
        except:
            pass
        log.addHandler(logging.StreamHandler(fd))
        log.debug('this is a debug message in the rotated log')
        log.info('this is an info message in the rotated log')

# Generated at 2022-06-24 02:56:21.659444
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    print('The logger:', log)
    assert 'getLogger' in repr(log)
    log.info('test')
    assert 'test' in repr(log.handlers)
    assert log.handlers


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:56:25.632000
# Unit test for function get_config
def test_get_config():
    import json
    d = {'a': 1, 'b': 2}
    s = json.dumps(d)
    assert(get_config(s) == d)

# Generated at 2022-06-24 02:56:28.865031
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test-logger_level')
    logger.setLevel(logging.DEBUG)

    with logger_level(logger, logging.CRITICAL):
        logger.debug('This will not print')

    logger.debug('This will print')

# Generated at 2022-06-24 02:56:39.911209
# Unit test for function get_config

# Generated at 2022-06-24 02:56:42.541225
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')
    log.debug('test')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:56:46.217212
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__+".test_logger_level")
    logger.setLevel(logging.WARNING)
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.getEffectiveLevel() == logging.WARNING

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 02:56:52.530331
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == False, '_PyInfo: PY2 should be True for python2'
    assert pyinfo.PY3 == True, '_PyInfo: PY3 should be True for python3'
    assert pyinfo.text_type == str, '_PyInfo: text_type should be str for python3'


# Generated at 2022-06-24 02:56:59.487340
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    assert log.level == logging.NOTSET
    assert log.handlers[0].level == logging.DEBUG


# Generated at 2022-06-24 02:57:02.806852
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py_info = _PyInfo()
    assert py_info.PY2 is True or py_info.PY3 is True

# Generated at 2022-06-24 02:57:12.579700
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert isinstance('s', _PyInfo.string_types)
        assert isinstance(u'u', _PyInfo.string_types)
        assert not isinstance(b'b', _PyInfo.string_types)
        assert isinstance('s', _PyInfo.text_type)
        assert isinstance(u'u', _PyInfo.text_type)
        assert not isinstance(b'b', _PyInfo.text_type)
        assert isinstance(b'b', _PyInfo.binary_type)
        assert not isinstance('s', _PyInfo.binary_type)
        assert not isinstance(u'u', _PyInfo.binary_type)
    else:
        assert isinstance('s', _PyInfo.string_types)

# Generated at 2022-06-24 02:57:20.952854
# Unit test for function logger_level
def test_logger_level():
    logger_1 = get_logger()
    logger_2 = get_logger()
    messages = []
    with logger_level(logger_1, logging.DEBUG):
        logger_1.info('logger_1 message 1')
        with logger_level(logger_2, logging.DEBUG):
            logger_2.info('logger_2 message 1')
            with logger_level(logger_1, logging.ERROR):
                logger_1.info('logger_1 message 2')
            logger_2.info('logger_2 message 2')
        logger_1.info('logger_1 message 3')
    with logger_level(logger_2, logging.WARN):
        logger_2.info('logger_2 message 3')

if __name__ == '__main__':
    test_logger_

# Generated at 2022-06-24 02:57:24.395433
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == (str is bytes)
    assert pyinfo.PY3 == (str is not bytes)
    assert pyinfo.text_type is str
    assert pyinfo.binary_type is bytes

if __name__ == '__main__':
    test__PyInfo()
    configure()
    log = getLogger()
    log.error("Test!")

# Generated at 2022-06-24 02:57:29.965104
# Unit test for function getLogger
def test_getLogger():
    import os, sys
    from tempfile import mkstemp
    from os import close, remove
    from subprocess import Popen, PIPE, STDOUT
    from unittest import TestCase
    from contextlib import closing
    from tempfile import mkdtemp
    from os.path import join, exists, dirname
    from shutil import rmtree
    from pickle import dumps
    from logging import getLogger, ERROR
    from logging.config import dictConfig
    from io import open as io_open

    class Test_getLogger(TestCase):
        def setUp(self):
            (fd, self.tmpfile) = mkstemp()
            close(fd)
            self.test_dir = mkdtemp()

        def tearDown(self):
            remove(self.tmpfile)

# Generated at 2022-06-24 02:57:39.039096
# Unit test for function getLogger
def test_getLogger():
    '''
    test_getLogger is the unittest function for getLogger.
    '''
    import unittest
    class TestGetLogger(unittest.TestCase):
        '''
        TestGetLogger is a class for unittest about getLogger.
        '''
        def test_getLogger_default(self):
            '''
            test_getLogger_default is a instance method for unittest
            about the default value of parameter name in getLogger
            :return:
            '''
            result = getLogger()
            self.assertEqual(result.name, "__main__")


# Generated at 2022-06-24 02:57:44.504552
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test_logger_level')

    try:
        with logger_level(log, logging.INFO):
            log.debug('This should be suppressed')
            log.info('This should make it')
    except:
        log.exception('Logging exception handler test.')
        raise

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:57:53.160350
# Unit test for function logger_level
def test_logger_level():
    import logging
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def test_it(self):
            log = logging.getLogger('test')
            self.assertEqual(log.level, logging.NOTSET)
            with logger_level(log, logging.INFO):
                self.assertEqual(log.level, logging.INFO)
            self.assertEqual(log.level, logging.NOTSET)

    return unittest.defaultTestLoader.loadTestsFromTestCase(TestLoggerLevel)


# Unit tests for function get_logger

# Generated at 2022-06-24 02:58:03.577794
# Unit test for function get_config
def test_get_config():
    # raise ValueError if None is passed
    try:
        get_config()
        assert False
    except ValueError:
        assert True

    # accept a string

# Generated at 2022-06-24 02:58:12.100398
# Unit test for function get_config
def test_get_config():
    import json
    import yaml


# Generated at 2022-06-24 02:58:16.644786
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.text_type == (str,)
    assert _PyInfo.binary_type == (bytes,)


# Generated at 2022-06-24 02:58:20.640274
# Unit test for function configure
def test_configure():
    configure()

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:58:24.215421
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert type(logging) == type(logging.Logger)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:58:30.103126
# Unit test for function logger_level
def test_logger_level():
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)

        def test_lower(self):
            level = logging.INFO
            self.assertTrue(self.logger.level <= level)
            with logger_level(self.logger, level):
                self.assertEqual(self.logger.level, level)
            self.assertTrue(self.logger.level <= level)

        def test_higher(self):
            level = logging.DEBUG
            self.assertTrue(self.logger.level <= level)
            with logger_level(self.logger, level):
                self.assertEqual(self.logger.level, level)

# Generated at 2022-06-24 02:58:34.953106
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("debug")
    log.error("error")
    with logger_level(log, logging.CRITICAL):
        log.debug("debug")
        log.error("error")

# Generated at 2022-06-24 02:58:36.535755
# Unit test for function getLogger
def test_getLogger():
    log = logging.getLogger(__name__)
    log.warning('test')



# Generated at 2022-06-24 02:58:47.332949
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    # bare config
    config = {"test":"test"}
    cfg = get_config(default=config)
    assert config == cfg

    # json config
    config = {"test":"test"}
    test_json = json.dumps(config)
    cfg = get_config(default=test_json)
    assert config == cfg

    # yaml config
    config = {"test":"test"}
    test_yaml = yaml.dump(config)
    cfg = get_config(default=test_yaml)
    assert config == cfg

    # bad yaml config
    test_yaml = 'test'
    with pytest.raises(ValueError) as exc:
        cfg = get_config(default=test_yaml)

# Generated at 2022-06-24 02:58:53.480891
# Unit test for function get_config
def test_get_config():
    cfg = get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)

    assert(cfg == DEFAULT_CONFIG)

    cfg = get_config(config=DEFAULT_CONFIG, env_var='LOGGING', default=DEFAULT_CONFIG)

    assert(cfg == DEFAULT_CONFIG)

    with open('test.json', 'w') as outfile:
        json.dump(DEFAULT_CONFIG, outfile)

    with open('test.json') as json_file:
        cfg_json = json.load(json_file)
        cfg = get_config(config=cfg_json, env_var='LOGGING', default=DEFAULT_CONFIG)
        assert(cfg == DEFAULT_CONFIG)


# Generated at 2022-06-24 02:58:59.203933
# Unit test for function configure

# Generated at 2022-06-24 02:59:01.907438
# Unit test for function getLogger
def test_getLogger():
    """
       >>> log = get_logger()
       >>> log.info('test')
    """
    test = get_logger()
    test.info('test')



# Generated at 2022-06-24 02:59:12.377222
# Unit test for function configure
def test_configure():
    import json
    import yaml
    import os
    my_config = os.environ.get('LOGGING')
    assert my_config == None
    configure()
    my_config = os.environ.get('LOGGING')
    assert my_config == None
    my_config = json.dumps(DEFAULT_CONFIG)
    os.environ['LOGGING'] = my_config
    configure()
    assert os.environ['LOGGING'] == my_config
    my_config = yaml.dump(DEFAULT_CONFIG)
    os.environ['LOGGING'] = my_config
    configure()
    assert os.environ['LOGGING'] == my_config
    os.environ['LOGGING'] = 'a: b'

# Generated at 2022-06-24 02:59:18.217150
# Unit test for function configure
def test_configure():
    # configure()
    # configure(env_var='LOGGING_UNDEFINED')
    # configure(config={})
    configure(default={})

# Generated at 2022-06-24 02:59:19.766652
# Unit test for function get_config
def test_get_config():
    assert type(get_config(default=DEFAULT_CONFIG)) is dict


# Generated at 2022-06-24 02:59:23.531319
# Unit test for function getLogger
def test_getLogger():
    print(get_logger())


# Generated at 2022-06-24 02:59:26.307275
# Unit test for function getLogger
def test_getLogger():
    log = getLogger('test')
    assert isinstance(log, logging.Logger)
    assert log.name == 'test'


# Generated at 2022-06-24 02:59:30.638041
# Unit test for function get_config
def test_get_config():
    cfg = {'foo': 'bar'}
    assert cfg == get_config(cfg)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:59:35.072199
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
    assert logger.level != logging.CRITICAL


if __name__ == '__main__':
    logging.basicConfig()
    log = get_logger()
    log.debug('test')
    test_logger_level()

# Generated at 2022-06-24 02:59:43.252888
# Unit test for function getLogger
def test_getLogger():
    """
    Test module getLogger
    """
    import logging

    root_logger = logging.getLogger()
    #print 'root_logger =', root_logger

    loglevel = logging.DEBUG
    root_logger.setLevel(loglevel)

    formatter = logging.Formatter('%(levelname)s - %(message)s')

    ch = logging.StreamHandler()
    ch.setLevel(loglevel)

    ch.setFormatter(formatter)
    root_logger.addHandler(ch)

    my_logger = logging.getLogger('my_logger')
    print('my_logger =', my_logger)
    my_logger.critical('critical message')
    my_logger.error('error message')

# Generated at 2022-06-24 02:59:46.439607
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

    log = getLogger('test2')
    log.info('test2')


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 02:59:53.881719
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    config = dict(a=1, b=2)  # json
    assert config == get_config(config)

    config = '{"a": 1, "b": 2}'  # json string
    assert config == get_config(config)

    config = json.dumps(dict(a=1, b=2))  # json string
    assert config == get_config(config)

    config = '{a: 1, b: 2}'  # yaml string
    assert config == get_config(config)

    config = yaml.dump(dict(a=1, b=2))  # yaml string
    assert config == get_config(config)

# Generated at 2022-06-24 03:00:01.567601
# Unit test for function get_config

# Generated at 2022-06-24 03:00:03.567052
# Unit test for function configure
def test_configure():
    configure()
    logger = logging.getLogger(__name__)
    logger.info('test')



# Generated at 2022-06-24 03:00:11.094631
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    # Ensure the logger level is initialized properly
    log.debug('TEST DEBUG OUTPUT')
    log.info('TEST INFO OUTPUT')

    # Test that logger_level() is working properly
    with logger_level(log, logging.DEBUG):
        log.debug('TEST DEBUG OUTPUT')
        log.info('TEST INFO OUTPUT')

    with logger_level(log, logging.INFO):
        log.debug('TEST DEBUG OUTPUT')
        log.info('TEST INFO OUTPUT')

    # Ensure the logger level is reset properly
    log.debug('TEST DEBUG OUTPUT')
    log.info('TEST INFO OUTPUT')

# Generated at 2022-06-24 03:00:18.026059
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)

    with logger_level(logger, logging.DEBUG):
        logger.debug('Debugging')
        logger.info('Info')

    with logger_level(logger, logging.INFO):
        logger.debug('Debug')
        logger.info('Info')

# Generated at 2022-06-24 03:00:24.019313
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    _PyInfo.PY2
    _PyInfo.PY3
    _PyInfo.string_types
    _PyInfo.text_type
    _PyInfo.binary_type



# Generated at 2022-06-24 03:00:27.772764
# Unit test for function getLogger
def test_getLogger():

    # use default name
    log = getLogger()
    assert log.name ==  _namespace_from_calling_context()

    # specify name
    log2 = getLogger('test')
    assert log2.name == 'test'



# Generated at 2022-06-24 03:00:30.366256
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger("test")
    log.error("Testing")



# Generated at 2022-06-24 03:00:40.318998
# Unit test for function get_config
def test_get_config():
    import json
    import yaml


# Generated at 2022-06-24 03:00:42.118798
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    assert logger.level == logging.NOTSET

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    assert logger.level == logging.NOTSET

# Generated at 2022-06-24 03:00:45.770679
# Unit test for function get_config
def test_get_config():
    import json, yaml
    test_json_str = json.dumps(DEFAULT_CONFIG)
    test_yaml_str = yaml.dump(DEFAULT_CONFIG, default_flow_style=False)

    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=test_json_str, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:00:47.208731
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    obj = _PyInfo()
    print(obj.PY2)
    print(obj.PY3)
    print(obj.string_types)
    print(obj.text_type)
    print(obj.binary_type)


# Generated at 2022-06-24 03:00:50.818700
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert logger.name == 'log'

# Generated at 2022-06-24 03:00:54.361827
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert(_PyInfo.PY2 is not None)
    assert(_PyInfo.PY3 is not None)
    assert(_PyInfo.string_types is not None)
    assert(_PyInfo.text_type is not None)
    assert(_PyInfo.binary_type is not None)


# Generated at 2022-06-24 03:01:02.121588
# Unit test for function configure
def test_configure():
    saved_config = os.environ.get('LOGGING')
    try:
        os.environ['LOGGING'] = json.dumps(DEFAULT_CONFIG)
        configure()
        logging.getLogger(__name__).info('test')
    finally:
        os.environ['LOGGING'] = saved_config


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:01:07.568161
# Unit test for function get_config
def test_get_config():
    # Unformatted string will be handled by json
    assert isinstance(get_config(default='{"version": 1}'), dict)

    # Formatted string with json
    assert get_config(default='{"version": 1}') == {"version": 1}

    # Formatted string with yaml
    assert get_config(default='version: 1') == {"version": 1}

    # Dictionary
    assert get_config(default={'version': 1}) == {"version": 1}

# Generated at 2022-06-24 03:01:13.495608
# Unit test for function configure
def test_configure():
    logger = getLogger()
    assert logger.getEffectiveLevel() == logging.DEBUG


# Generated at 2022-06-24 03:01:15.561770
# Unit test for function configure
def test_configure():
    # TODO
    print('test_configure ...')
    pass



# Generated at 2022-06-24 03:01:20.460536
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger(__name__)

    print(logger.level)
    with logger_level(logger, logging.WARNING):
        print(logger.level)
        logger.info("Hello!")
        logger.warning("Goodbye!")
    print(logger.level)

test_logger_level()

# Generated at 2022-06-24 03:01:26.834841
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('test')
        logger.info('test2')
    logger.debug('test')
    logger.info('test2')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 03:01:31.353910
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be shown")
        logger.warn("This warning should not be shown!")


# Generated at 2022-06-24 03:01:32.863455
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3 is True


# Generated at 2022-06-24 03:01:36.546740
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    with logger_level(log, logging.DEBUG):
        log.info('test_logger_level')
        assert log.level == logging.DEBUG
    assert log.level == logging.DEBUG


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:01:39.299859
# Unit test for function configure
def test_configure():
    logger = get_logger()
    logger.info('configure test')


if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-24 03:01:46.750824
# Unit test for function get_config
def test_get_config():

    import json
    import yaml

    c1 = get_config(config={'a': 1})
    assert c1 == {'a': 1}

    e1 = json.dumps({'b': 2})
    c2 = get_config(config=e1)
    assert c2 == {'b': 2}

    e2 = yaml.dump(dict(c=3))
    c3 = get_config(config=e2)
    assert c3 == {'c': 3}

# Generated at 2022-06-24 03:01:48.469954
# Unit test for function getLogger
def test_getLogger():
    configure()
    logger = getLogger('test')
    logger.debug('test')



# Generated at 2022-06-24 03:01:52.925490
# Unit test for function getLogger
def test_getLogger():
    # Test for getLogger
    logging.basicConfig(format='%(levelname)s: %(message)s')
    log = getLogger('test')
    log.debug('Logging is disabled')
    log.info('Logging is enabled')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:02:00.711171
# Unit test for function logger_level
def test_logger_level():
    l = get_logger('test_logger_level')

    l.debug('debug message')
    l.info('info message')
    l.warn('warn message')
    l.error('error message')
    l.critical('critical message')

    with logger_level(l, logging.WARN):
        l.debug('debug message')
        l.info('info message')
        l.warn('warn message')
        l.error('error message')
        l.critical('critical message')

    l.debug('debug message')
    l.info('info message')
    l.warn('warn message')
    l.error('error message')
    l.critical('critical message')


# Generated at 2022-06-24 03:02:02.636650
# Unit test for function configure
def test_configure():
    """
    >>> configure()
    >>> logger = logging.getLogger(__name__)
    >>> logger.info('test')

    """



# Generated at 2022-06-24 03:02:06.596220
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test')
    initial = logger.getEffectiveLevel()
    with logger_level(logger, logging.WARN):
        assert initial != logger.getEffectiveLevel()
        logger.info('test')
        logger.warning('test')
        logger.critical('test')
    assert logger.getEffectiveLevel() == initial

# Generated at 2022-06-24 03:02:13.174597
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY3:
        assert(isinstance(u"unicode", _PyInfo.string_types))
        assert(isinstance(u"unicode", _PyInfo.text_type))
        assert(isinstance(b"bytes", _PyInfo.binary_type))
        assert(isinstance(b"bytes", _PyInfo.string_types))
    else:
        assert(isinstance("str,basestring", _PyInfo.string_types))
        assert(isinstance(u"unicode", _PyInfo.text_type))
        assert(isinstance(b"bytes", _PyInfo.binary_type))
        assert(isinstance(b"bytes", _PyInfo.string_types))



# Generated at 2022-06-24 03:02:20.099952
# Unit test for function configure
def test_configure():
    if not _PyInfo.PY3:
        '''
        >>> configure()
        >>> logging.debug('test')
        '''
        assert False, 'test_configure only for Python 3'


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:02:24.378580
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config()
    assert config == DEFAULT_CONFIG

# Generated at 2022-06-24 03:02:31.170530
# Unit test for function logger_level
def test_logger_level():
    global logger
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
        assert logger.level == logging.DEBUG

    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")
    assert logger.level == logging.INFO

# Generated at 2022-06-24 03:02:38.697868
# Unit test for function configure
def test_configure():
    logger = get_logger()

    with logger_level(logger, logging.CRITICAL):
        configure(default={
            'handlers': {
                'console': {
                    'class': 'logging.StreamHandler',
                    'level': logging.DEBUG,
                },
            },
            'root': {
                'handlers': ['console'],
                'level': logging.DEBUG,
            },
        })

        logger.debug("debug")


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 03:02:43.465259
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger')
    with logger_level(logger, logging.DEBUG):
        logger.debug('This is a debug message')
        logger.info('This is a info message')
        logger.warning('This is a warning message')
        logger.error('This is a error message')
        logger.critical('This is a critical message')



# Generated at 2022-06-24 03:02:48.831767
# Unit test for function configure
def test_configure():
    configure()
    logger = logging.getLogger(__name__)
    logger.info('test')
    configure()
    logger.info('test')


# Generated at 2022-06-24 03:02:51.612112
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    configure()
    logger.info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 03:02:55.187789
# Unit test for function getLogger
def test_getLogger():
    log = get_logger();
    log.info("test_info");
    log.warning("test_warning");



# Generated at 2022-06-24 03:02:59.685892
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 is False
    assert pyinfo.PY3 is True
    assert isinstance("", pyinfo.string_types)
    assert isinstance("", pyinfo.text_type)
    assert isinstance(b"", pyinfo.binary_type)
    return True


# Generated at 2022-06-24 03:03:10.395885
# Unit test for function get_config
def test_get_config():
    json = r'{"disable_existing_loggers": "false", "root": {"level": "DEBUG"}}'
    dict = {'disable_existing_loggers': 'false', 'root': {'level': 'DEBUG'}}
    assert get_config(config=json) == dict
    assert get_config(config=dict) == dict
    assert get_config(config=dict, env_var=None, default=None) == dict
    assert get_config(config=json, env_var='LOGGING', default=None) == dict
    assert get_config(config=None, env_var=None, default=dict) == dict
    assert get_config(config=None, env_var='LOGGING', default=dict) == dict
    assert get_config(config=None) is None

# Generated at 2022-06-24 03:03:18.398777
# Unit test for function logger_level
def test_logger_level():
    my_level = 1
    # Create a logger
    logger = logging.getLogger(__name__)
    # Set level to 0
    logger.setLevel(0)
    # Create File handler
    handler = logging.FileHandler('/tmp/test_logger_level.log')
    # set level higher than 0
    handler.setLevel(my_level)
    # Create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # Set formatter to File handler
    handler.setFormatter(formatter)
    # Add file handler to logger
    logger.addHandler(handler)
    # Start context manager

# Generated at 2022-06-24 03:03:21.149678
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')
    log = getLogger('test2')
    log.info('test2')

# Generated at 2022-06-24 03:03:28.668457
# Unit test for function logger_level
def test_logger_level():
    def logging_setup():
        logger = get_logger()
        logger.setLevel(logging.INFO)

    logging_setup()

    def test_basic_logger_level():
        logger = get_logger(__name__)
        # Initial logger level
        assert logger.level == logging.INFO

        # Set logger level to ERROR
        with logger_level(logger, logging.ERROR):
            assert logger.level == logging.ERROR

            # Log a message with level WARNING
            logger.warning('This warning should not be logged')

        # Previous level restored (INFO)
        assert logger.level == logging.INFO

        # Message with level WARNING logged
        logger.warning('This warning should be logged')

    def test_intermediate_logger_level():
        logger = get_logger(__name__)
        # Initial logger level

# Generated at 2022-06-24 03:03:36.461218
# Unit test for function getLogger
def test_getLogger():
    """
    A unit test for the getLogger function.
    """
    # create a memory-based test logger
    import logging
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def captured_output():
        """
        A context manager that captures standard output.
        """
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err
