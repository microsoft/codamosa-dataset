

# Generated at 2022-06-24 02:53:31.567628
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # TODO What is the code to testing a constructor
    assert _PyInfo().PY2 is True
    assert _PyInfo().PY3 is False
    assert _PyInfo().string_types is (basestring,)
    assert _PyInfo().text_type is unicode
    assert _PyInfo().binary_type is str



# Generated at 2022-06-24 02:53:38.259902
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO, logger.level
        logger.debug("debug message 1")
        logger.info("info message 1")
    assert logger.level == logging.DEBUG, logger.level
    logger.debug("debug message 2")
    logger.info("info message 2")
    
if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 02:53:39.441391
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2
    assert _PyInfo().PY3 == False



# Generated at 2022-06-24 02:53:51.309158
# Unit test for function get_config
def test_get_config():
    cfg_str = '{"version":1,"handlers":{"console":{"class":"logging.StreamHandler","formatter":"colored","level":10,"stream":"ext://sys.stdout"}}}'
    cfg_dict = {"version": 1, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "colored", "level": 10, "stream": "ext://sys.stdout"}}}
    cfg_dict_s = '{"version": 1, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "colored", "level": 10, "stream": "ext://sys.stdout"}}}'

# Generated at 2022-06-24 02:53:55.095847
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, bool)
    assert isinstance(pyinfo.binary_type, bool)



# Generated at 2022-06-24 02:53:56.872269
# Unit test for function configure
def test_configure():
    log = get_logger(__name__)
    configure()
    log.info('test')



# Generated at 2022-06-24 02:54:01.132056
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('getLogger')
    logger.info('test_getLogger')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:54:11.423229
# Unit test for function get_config
def test_get_config():
    # Test bare string config
    conf = "foo='bar'"
    if get_config(conf) == {'foo': 'bar'}:
        print("Pass test for bare string config.")
    else:
        print("Fail test for bare string config.")

    # Test json config
    conf = '{"foo": "bar"}'
    if get_config(conf) == {'foo': 'bar'}:
        print("Pass test for json config.")
    else:
        print("Fail test for json config.")

    # Test yaml config
    conf = "foo: bar"
    if get_config(conf) == {'foo': 'bar'}:
        print("Pass test for yaml config.")
    else:
        print("Fail test for yaml config.")

    # Test log level config
    import logging


# Generated at 2022-06-24 02:54:17.469800
# Unit test for function getLogger
def test_getLogger():
    import os
    import logging.handlers
    import sys

    # define logger
    logger = logging.getLogger(__name__)

    if sys.version_info < (2, 7):
        logger.setLevel(logging.INFO)
    else:
        logger.addHandler(logging.NullHandler())

    # define stream handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # define simple formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # tell the handler to use this format
    ch.setFormatter(formatter)

    # add the handler to the logger
    logger.addHandler(ch)

    logger.info('Hi')

# Generated at 2022-06-24 02:54:18.368296
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 or _PyInfo.PY2



# Generated at 2022-06-24 02:54:22.809432
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    instance = _PyInfo()

    assert isinstance(instance.PY2, bool)
    assert isinstance(instance.PY3, bool)
    assert isinstance(instance.string_types, (tuple, list))
    assert isinstance(instance.text_type, str)
    assert isinstance(instance.binary_type, bytes)

    if _PyInfo.PY3:
        assert instance.text_type == str
        assert instance.binary_type == bytes
    else:  # PY2
        assert instance.text_type == unicode
        assert instance.binary_type == str

# Generated at 2022-06-24 02:54:26.177177
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 or _PyInfo.PY2
    assert isinstance("", _PyInfo.text_type)
    assert isinstance("", _PyInfo.string_types)
    assert isinstance(b"", _PyInfo.binary_type)


# Generated at 2022-06-24 02:54:30.693225
# Unit test for function configure
def test_configure():
    import json
    config = json.dumps(DEFAULT_CONFIG)
    configure(config)
    log = logging.getLogger(__name__)
    log.info('test')
    configure()



# Generated at 2022-06-24 02:54:39.948038
# Unit test for function get_config
def test_get_config():
    from textwrap import dedent
    from io import StringIO

    t = lambda x: dedent(x).strip()
    c = get_config

    # Default behavior: string is assumed to be json.
    config = c('{"foo": "bar"}')
    assert config == {'foo': 'bar'}

    # If it's not json, then it's a yaml file.
    config = c(t("""
        foo:
          bar: 1
          baz: 2
        """))
    assert config == {'foo': {'bar': 1, 'baz': 2}}

    # If it's not a yaml file, then it's an error.
    with pytest.raises(ValueError):
        config = c("""I am not yaml or json""")

    # Config can also be provided via a file object.

# Generated at 2022-06-24 02:54:48.233785
# Unit test for function get_config
def test_get_config():
    _CONFIGURED[:] = []
    logger = get_logger(__name__)
    assert logger.level == logging.DEBUG, "Default logging configuration is not loaded"

    # Test empty input
    assert get_config() == DEFAULT_CONFIG, "Empty input should return default configuration"

    # Test support for json config
    json_config = """
    {
        "version": 1,
        "disable_existing_loggers": false
    }
    """
    assert get_config(json_config) == {"version": 1, "disable_existing_loggers": False}, "Json input is not working"

    # Test support for yaml config
    yaml_config = """
    version: 1
    disable_existing_loggers: false
    """

# Generated at 2022-06-24 02:54:49.772453
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

    log = getLogger('test2')
    log.info('test2')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:54:59.492508
# Unit test for function configure
def test_configure():
    configure(config={"version": 1, "disable_existing_loggers": False, "loggers":{}})
    config = get_config(default=None, env_var=None, given={"version": 1, "disable_existing_loggers": False, "loggers":{}})
    assert config == {"version": 1, "disable_existing_loggers": False, "loggers":{}}

    # Create a config file
    f = open("test.json", "w")
    f.write('{"version": 1, "disable_existing_loggers": False, "loggers":{}}')
    f.close()

    # Try to load the config file

# Generated at 2022-06-24 02:55:05.731558
# Unit test for function configure
def test_configure():
    import logging
    logger = logging.getLogger(__name__)
    configure(default=DEFAULT_CONFIG)
    logger.info('This is a test')

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:55:12.104634
# Unit test for function getLogger
def test_getLogger():
    log1 = getLogger('test_getLogger')
    log2 = getLogger('test_getLogger')
    assert log1 == log2
    assert log1.name ==  'test_getLogger'



# Generated at 2022-06-24 02:55:12.574894
# Unit test for function configure
def test_configure():
    configure(config={})

# Generated at 2022-06-24 02:55:13.771514
# Unit test for function configure
def test_configure():
    log = logging.getLogger('test')
    configure()
    log.info('test')


# Generated at 2022-06-24 02:55:15.697761
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    configure(default=DEFAULT_CONFIG)
    logger.info('test')
    assert len(_CONFIGURED) == 1


# Generated at 2022-06-24 02:55:25.650674
# Unit test for function get_config
def test_get_config():
    assert get_config(env_var='TEST_LOGGING_NULL') is None
    assert get_config(env_var='TEST_LOGGING_DICT') == {'test-key': 'test-value'}
    assert get_config(env_var='TEST_LOGGING_JSON') == {'test-key': 'test-value'}
    assert get_config(env_var='TEST_LOGGING_YAML') == {'test-key': 'test-value'}
    assert get_config(env_var='TEST_LOGGING_INVALID_JSON', default={'test-key': 'test-value'}) == {'test-key': 'test-value'}

# Generated at 2022-06-24 02:55:26.310447
# Unit test for function configure
def test_configure():
    logging.info('test')

# Generated at 2022-06-24 02:55:29.701316
# Unit test for function configure
def test_configure():
    # Test LOGGING environment variable
    cfg = get_config(env_var='LOGGING', default=None)
    assert(cfg == DEFAULT_CONFIG)

    # Test dictconfig
    logging.config.dictConfig(cfg)
    logging.getLogger(__name__).debug('test')



# Generated at 2022-06-24 02:55:37.797525
# Unit test for function logger_level
def test_logger_level():
    import sys
    import StringIO

    old_stdout = sys.stdout
    sys.stdout = StringIO.StringIO()
    logger = get_logger(__name__)
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
    sys.stdout.seek(0)
    contents = sys.stdout.readlines()
    sys.stdout = old_stdout
    assert len(contents) == 2, contents
    assert contents[0].endswith('debug message\n')
    assert contents[1].endswith('info message\n')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:55:40.883944
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print("Testing _PyInfo class constructor...")
    
    pyinfo = _PyInfo()
    assert(pyinfo.PY2 == 2 or pyinfo.PY3 == 3), "The _PyInfo object was not created correctly."

# Generated at 2022-06-24 02:55:43.231873
# Unit test for function get_config
def test_get_config():
    # Test if given is string, it should return equivalent dict
    get_config('{"version":1}') == {"version":1}


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:55:50.079568
# Unit test for function configure
def test_configure():
    import sys
    import os
    import json

    config = json.dumps(DEFAULT_CONFIG)
    sys.stderr.write(config)
    os.environ['LOGGING'] = config
    configure()
    sys.stderr.write("configured\n")


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:55:53.544049
# Unit test for function configure
def test_configure():
    # TODO
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:55:54.955941
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.debug('test')



# Generated at 2022-06-24 02:55:59.218704
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.ERROR):
        log.error('test')
        log.info('test')
        log.warn('test')
        log.debug('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:56:01.521161
# Unit test for function logger_level
def test_logger_level():
    assert logging.getLogger().level == logging.NOTSET
    with logger_level(logging.getLogger(), logging.DEBUG):
        assert logging.getLogger().level == logging.DEBUG
    assert logging.getLogger().level == logging.NOTSET

# Generated at 2022-06-24 02:56:05.928179
# Unit test for function configure
def test_configure():
    logger = getLogger(__name__)
    logger.info('test')
    logger.error('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:56:13.954997
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import logging
    from io import StringIO
    import sys

    class LoggerLevelTestCase(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)
            self.stream = StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.logger.addHandler(self.handler)
            self.level = self.logger.level

        def tearDown(self):
            self.logger.removeHandler(self.handler)
            self.logger.level = self.level


# Generated at 2022-06-24 02:56:17.145870
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is not _PyInfo.PY3
    assert isinstance('1', _PyInfo.string_types)
    assert isinstance(b'1', _PyInfo.binary_type)
    assert isinstance(u'1', _PyInfo.text_type)



# Generated at 2022-06-24 02:56:18.818862
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    logger.info('test')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:56:20.288188
# Unit test for function getLogger
def test_getLogger():
    pass

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 02:56:31.167605
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()
    log = get_logger()
    assert log.level == logging.DEBUG

    # test no-op
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG

    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG

    # test exceptions and re-raising
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
        try:
            raise ValueError()
        except ValueError:
            exc_info = sys.exc_info()
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG
    six.reraise(*exc_info)

# Generated at 2022-06-24 02:56:40.912846
# Unit test for function configure
def test_configure():
    import os
    import json
    import yaml
    import sys
    # Create a dictionary of logging config

# Generated at 2022-06-24 02:56:48.171545
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert logger.name == 'km4py'
    assert logger.level == 10
    assert logger.parent.name == 'root'


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: '
               '%(message)s @%(funcName)s:%(lineno)d #%(levelname)s',
        datefmt='%Y-%m-%d %H:%M:%S',
    )
    test_getLogger()
    test_getLogger()

# Generated at 2022-06-24 02:56:52.801409
# Unit test for function configure
def test_configure():
    configure(default={'formatters': {}, 'handlers': {}, 'loggers': {}, 'version': 1})
    configure(config={'formatters': {}, 'handlers': {}, 'loggers': {}, 'version': 1})
    configure()


# Generated at 2022-06-24 02:56:53.987381
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-24 02:56:56.092886
# Unit test for function getLogger
def test_getLogger():
    with logger_level(get_logger(), logging.DEBUG):
        getLogger().debug('Foo')

# Generated at 2022-06-24 02:56:59.897137
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    p = _PyInfo()
    assert p.PY2 or p.PY3
    assert not (p.PY2 and p.PY3)


if __name__ == '__main__':
    import doctest

    doctest.testmod()
    configure()

# Generated at 2022-06-24 02:57:03.138592
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test')
    logger.debug('test')
    logger.warning('test')
    logger.error('test')



# Generated at 2022-06-24 02:57:08.846237
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    >>> test_py_info = _PyInfo()
    >>> test_py_info.PY2 or test_py_info.PY3
    True
    >>> isinstance('foo', test_py_info.string_types) and isinstance(u'foo', test_py_info.string_types)
    True
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:57:17.396562
# Unit test for function get_config

# Generated at 2022-06-24 02:57:20.269012
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("test_logger_level")
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.CRITICAL):
        logger.info("message to show")
    logger.info("message won't show")

test_logger_level()

# Generated at 2022-06-24 02:57:24.475201
# Unit test for function configure
def test_configure():
    configure()
    logger = logging.getLogger("test_configure")
    logger.info("test info message")
    assert logger.level == logging.DEBUG
    logger.warning("test warn message")
    logger.error("test error message")

# Generated at 2022-06-24 02:57:27.691436
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True
    assert _PyInfo.PY3 is False
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str


if __name__ == '__main__':
    configure()
    log = get_logger()
    log.info("test")

# Generated at 2022-06-24 02:57:32.041189
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert _PyInfo.PY3
    assert isinstance('', _PyInfo.string_types)
    assert isinstance('', _PyInfo.text_type)
    assert isinstance(b'', _PyInfo.binary_type)



# Generated at 2022-06-24 02:57:35.588279
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('this should show up')
        log.info('this should not show up')

    log.debug('this should not show up')
    log.info('this should show up')

# Generated at 2022-06-24 02:57:43.103184
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py2 = _PyInfo.PY2
    py3 = _PyInfo.PY3
    text_type = _PyInfo.text_type
    binary_type = _PyInfo.binary_type
    string_types = _PyInfo.string_types

    assert string_types == basestring, '_PyInfo.string_types should be basestring.'
    assert binary_type == str, '_PyInfo.binary_type should be str.'
    assert text_type == unicode, '_PyInfo.text_type should be unicode.'
    assert py2, '_PyInfo.PY2 should be True.'
    assert not py3, '_PyInfo.PY3 should be False.'



# Generated at 2022-06-24 02:57:50.589945
# Unit test for function get_config
def test_get_config():
    config = get_config()
    assert config['version'] == 1

    config = get_config({'version':2})
    assert config['version'] == 2

    config = get_config(env_var='LOGGING', default={'version':3})
    assert config['version'] == 3

    config = get_config({'version':4}, env_var='LOGGING', default={'version':3})
    assert config['version'] == 4

    config = get_config(default={'version':3})
    assert config['version'] == 3

    config = get_config(env_var='LOGGING', default={'version':3})
    assert config['version'] == 3


# Generated at 2022-06-24 02:57:54.671168
# Unit test for function configure
def test_configure():
    configure()
    _logging = logging
    log2 = logging.getLogger("prd.logger")
    log2.info("log2")


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)

    test_configure()

# Generated at 2022-06-24 02:57:58.700294
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.PY2 != _PyInfo.PY3

    assert (_PyInfo.string_types[0] == str) is _PyInfo.PY3


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:58:08.065707
# Unit test for function get_config
def test_get_config():
    # base case
    assert get_config(DEFAULT_CONFIG) == DEFAULT_CONFIG

    # json

# Generated at 2022-06-24 02:58:12.453090
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    assert logger.level == logging.INFO


# Generated at 2022-06-24 02:58:16.644715
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert issubclass(_PyInfo.text_type, _PyInfo.string_types)
    assert issubclass(str, _PyInfo.string_types)

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:58:27.867516
# Unit test for function logger_level
def test_logger_level():
    """Tests that `logger_level` really sets the logger level."""
    # Set up a logger
    logger = get_logger()

    # Make sure that only DEBUG log messages are printed
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)
        assert not logger.isEnabledFor(logging.INFO)

        # Print a DEBUG message
        logger.debug("I am a DEBUG log message")

    # Now check that INFO log messages are printed
    assert logger.isEnabledFor(logging.INFO)

    # Print an INFO message
    logger.info("I am an INFO log message")


if __name__ == '__main__':
    # test_logger_level()
    log = get_logger()
    log.info('test')

# Generated at 2022-06-24 02:58:37.560233
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger('test_logger')
    logger.debug('test_logger_debug')
    logger.info('test_logger_info')
    logger.warning('test_logger_warning')
    logger.error('test_logger_error')

    # Test for print out of Test Logger
    with logger_level(logger, logging.DEBUG):
        logger.debug('test_logger_level_debug')
        logger.info('test_logger_level_info')
        logger.warning('test_logger_level_warning')
        logger.error('test_logger_level_error')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:58:47.550810
# Unit test for function get_config

# Generated at 2022-06-24 02:58:54.731948
# Unit test for function configure
def test_configure():
    from io import StringIO
    import sys

    tmp_stdout = sys.stdout

    try:
        sys.stdout = StringIO()
        configure()
        print('test', file=sys.stdout)

        assert sys.stdout.getvalue()
    finally:
        sys.stdout = tmp_stdout


if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-24 02:59:02.785055
# Unit test for function get_config
def test_get_config():
    # TODO: test with yaml and json files
    default = DEFAULT_CONFIG
    given = default
    assert get_config() == default
    assert get_config(given) == given
    assert get_config(DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(None) == default
    assert get_config(default, None) == default
    assert get_config(default, "LOGGIN") == default
    assert get_config(default, "LOGGING") == default
    assert get_config(None, "LOGGING") == default
    assert get_config(None, "LOGGIN") == default
    assert get_config(None, None) == default
    assert get_config(None, "LOGGING", default) == default

if __name__ == '__main__':
    test

# Generated at 2022-06-24 02:59:12.855801
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager

    original_get_logger = get_logger
    
    def get_logger():
        logger = logging.getLogger()
        return logger

    @contextmanager
    def logger_level(logger, level):
        """Set logger level to `level` within a context block. Don't use this except for debugging please, it's gross."""
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    logger = logging.getLogger()


# Generated at 2022-06-24 02:59:18.256665
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance("", _PyInfo.string_types)
    assert isinstance("", _PyInfo.text_type)
    assert isinstance("", _PyInfo.binary_type)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:59:21.028038
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    with logger_level(log, logging.INFO):
        log.info("Should be no warning")
    log.warning("Should be warning")


# Generated at 2022-06-24 02:59:30.794659
# Unit test for function get_config

# Generated at 2022-06-24 02:59:33.198816
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.CRITICAL):
        log.warn("This should not show in the log")
    log.warn("This should show in the log")

# Generated at 2022-06-24 02:59:39.446196
# Unit test for function logger_level
def test_logger_level():
    """Test function logger_level"""
    logger = get_logger(__name__)
    with logger_level(logger, logging.ERROR):
        logger.debug('This should not print')
        logger.warning('This should not print')
        logger.error('This should print')
        logger.critical('This should print')

    logger.debug('This should print')
    logger.warning('This should print')
    logger.error('This should print')
    logger.critical('This should print')


# TODO Remove this from public API.

# Generated at 2022-06-24 02:59:40.894287
# Unit test for function configure
def test_configure():
    log = get_logger()
    log.info('test')



# Generated at 2022-06-24 02:59:47.256321
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == True or pyinfo.PY2 == False
    assert pyinfo.PY3 == True or pyinfo.PY3 == False
    assert isinstance(pyinfo.string_types, (tuple, list))
    assert isinstance(pyinfo.text_type, type(None))
    assert isinstance(pyinfo.binary_type, type(None))

test__PyInfo()

# Generated at 2022-06-24 02:59:48.864475
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert logger
    logger.info('aaa')


# Generated at 2022-06-24 02:59:58.884000
# Unit test for function get_config
def test_get_config():

    # Test get_config with no parameters
    cfg = get_config()
    assert cfg == DEFAULT_CONFIG

    # Test get_config with string, json but not yaml
    cfg = get_config('{"root":{"level":"WARN"}}')
    assert cfg["root"]["level"] == "WARN"
    assert cfg["loggers"] == DEFAULT_CONFIG["loggers"]

    # Test get_config with string, yaml but not json
    cfg = get_config('root:\n  level: WARN')
    assert cfg["root"]["level"] == "WARN"
    assert cfg["loggers"] == DEFAULT_CONFIG["loggers"]


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:00:03.428895
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3
    assert pyinfo.string_types == (basestring,)
    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str



# Generated at 2022-06-24 03:00:10.002801
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.INFO):
        logger.debug('test')
    logger.debug('test')

# Generated at 2022-06-24 03:00:17.636532
# Unit test for function getLogger
def test_getLogger():
    log_file_name = "test_data/test_getLogger.log"
    if os.path.exists(log_file_name):
        os.remove(log_file_name)

    # creates a hello.log file in the current directory
    log = get_logger("hello")
    log.info("hello")
    # creates a myapp.log file in the /var/log directory
    # log = get_logger('myapp')
    # log.info('myapp')

    assert os.path.exists("test_data/test_getLogger.log")



# Generated at 2022-06-24 03:00:20.533035
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG



# Generated at 2022-06-24 03:00:24.506859
# Unit test for function getLogger
def test_getLogger():
    # Test case with default log config
    log_info = get_logger()
    log_info.info('log_info test')

    # Test case with customized log config
    log_debug = get_logger('log_debug')
    log_debug.debug('log_debug test')

    # Test case with invalid log config
    with pytest.raises(ValueError):
        get_logger('')


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 03:00:28.540557
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test_logger_level')
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    try:
        log.debug('test')
        raise Exception('Should throw exception')
    except:
        pass

# Generated at 2022-06-24 03:00:34.491148
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    # Use with clause to ensure logger level is reset afterwards
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        # Restore previous level
        logger.level = logging.DEBUG

    assert logger.level == logging.DEBUG



# Generated at 2022-06-24 03:00:38.765162
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo().PY3:
        assert _PyInfo().string_types == (str,)
        assert _PyInfo().text_type is str
        assert _PyInfo().binary_type is bytes
    else:
        assert _PyInfo().string_types == (basestring,)
        assert _PyInfo().text_type == unicode
        assert _PyInfo().binary_type is str



# Generated at 2022-06-24 03:00:43.726244
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG, "logger level has not been correctly set to DEBUG"
    assert logger.level == logging.INFO, "logger level has not been correctly reset to INFO"

# Generated at 2022-06-24 03:00:46.252150
# Unit test for function getLogger
def test_getLogger():
    print("Testing getLogger...")
    logger = getLogger(__name__)
    logger.info("Test message from %s" % __name__)
    assert True, "test_getLogger completed successfully"


# Generated at 2022-06-24 03:00:56.212354
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    try:
        assert _PyInfo.PY2 == (sys.version_info[0] == 2)
        assert _PyInfo.PY3 == (sys.version_info[0] == 3)
        if _PyInfo.PY2:
            assert _PyInfo.string_types == (basestring,)
            assert _PyInfo.text_type == unicode
            assert _PyInfo.binary_type == str
        else:
            assert _PyInfo.string_types == (str,)
            assert _PyInfo.text_type == str
            assert _PyInfo.binary_type == bytes
        print("Test _PyInfo passed")
    except:
        print("Test_PyInfo failed")

if __name__ == "__main__":
    test__PyInfo()

# Generated at 2022-06-24 03:01:06.383397
# Unit test for function get_config

# Generated at 2022-06-24 03:01:07.335017
# Unit test for function configure
def test_configure():
    assert DEFAULT_CONFIG == get_config()


# Generated at 2022-06-24 03:01:10.073888
# Unit test for function configure
def test_configure():
    """
    >>> log = logging.getLogger(__name__)
    >>> configure()
    >>> log.info('test')

    """
    log = logging.getLogger(__name__)
    configure()
    log.info('test')



# Generated at 2022-06-24 03:01:16.170453
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert isinstance(logger, logging.Logger)

    logger = getLogger('test')
    assert isinstance(logger, logging.Logger)

    logger = get_logger()
    assert isinstance(logger, logging.Logger)

    logger = get_logger('test')
    assert isinstance(logger, logging.Logger)

# Generated at 2022-06-24 03:01:20.371051
# Unit test for function getLogger
def test_getLogger():
    # Without configuration, getLogger() returns the root logger.
    assert getLogger() is logging.root

    # After configuration, getLogger() returns a named logger.
    configure()
    assert getLogger() is logging.getLogger(_namespace_from_calling_context())

# Generated at 2022-06-24 03:01:23.527762
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert not _PyInfo.PY3
    assert _PyInfo.string_types
    assert _PyInfo.text_type
    assert _PyInfo.binary_type


# Generated at 2022-06-24 03:01:31.907201
# Unit test for function get_config
def test_get_config():
    conf = {'hello': 'world'}

    # Test None as given value
    try:
        get_config(config=None)
    except ValueError:
        pass
    else:
        raise AssertionError('get_config should raise ValueError with "config=None"')

    # Test dict as given value
    assert get_config(config=conf) == conf

    # Test string as given value
    assert 'hello' in get_config(config=json.dumps(conf)).keys()
    assert 'hello' in get_config(config=yaml.dump(conf)).keys()

    # Test invalid json as given value
    try:
        get_config(config='Invalid_JSON')
    except ValueError:
        pass

# Generated at 2022-06-24 03:01:39.057007
# Unit test for function configure
def test_configure():
    import __main__
    __main__.LOGGING = '{"version": 1, "handlers": {"console": { "class": "logging.StreamHandler", "formatter": "colored", "level": "DEBUG"}}, "formatters": {"colored": { "()": "colorlog.ColoredFormatter", "format": "%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s", "datefmt": "%H:%M:%S"}}}'
    configure(env_var='LOGGING')
    log = get_logger('test')
    log.debug('test debug')
   

# Generated at 2022-06-24 03:01:41.476641
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 == True
    assert _PyInfo.PY2 == False
    assert isinstance('foo', _PyInfo.string_types)



# Generated at 2022-06-24 03:01:44.510576
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test')

    logger = getLogger('test2')
    logger.info('test2')

# Generated at 2022-06-24 03:01:53.358240
# Unit test for function get_config
def test_get_config():
    import json
    assert get_config(env_var='LOGGING') == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=None) == None
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=json.dumps({'level': 'debug'})) == {'level': 'debug'}
    assert get_config(config={'level': 'debug'}) == {'level': 'debug'}
    assert get_config(config=[{'level': 'debug'}]) == [{'level': 'debug'}]
    assert get_config(config=False) == False

# Generated at 2022-06-24 03:01:56.589223
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('debug should be ignored')
        logger.info('info should be printed')
    logger.error('error should be printed')



# Generated at 2022-06-24 03:01:59.480838
# Unit test for function get_config
def test_get_config():
    assert dict == type(get_config('{"a": 1}'))
    assert dict == type(get_config('"a": 1'))
    assert dict == type(get_config('a: 1'))


# Generated at 2022-06-24 03:02:03.188251
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('some.logger')
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.WARN):
        assert logging.WARN == logger.getEffectiveLevel()
        logger.debug('this should not appear')
    assert logging.DEBUG == logger.getEffectiveLevel()



# Generated at 2022-06-24 03:02:09.694998
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == sys.version_info[0] == 2
    assert _PyInfo.PY3 == sys.version_info[0] == 3

    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:  # PY2
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str


# Generated at 2022-06-24 03:02:12.548387
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.ERROR):
        log.info('test')
        log.error('test')
    log.info('test')



# Generated at 2022-06-24 03:02:23.437773
# Unit test for function configure
def test_configure():
    import tempfile
    from os.path import dirname
    from os import remove
    from . import configure

    # Testing the json content
    temp_json_file = tempfile.NamedTemporaryFile(delete=False)
    with open(temp_json_file.name, 'w') as outfile:
        outfile.write(
            json.dumps(DEFAULT_CONFIG)
        )

    configure(env_var=temp_json_file.name)
    remove(temp_json_file.name)

    # Testing a bad config
    temp_json_file = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-24 03:02:28.031806
# Unit test for function get_config
def test_get_config():
    given = {'version': 1, 'disable_existing_loggers': False, 'loggers': {'test': {'handlers': ['test_handler'], 'level': 'INFO'}}}
    cfg = get_config(given=given, env_var=None, default=None)
    assert cfg == given



# Generated at 2022-06-24 03:02:31.549271
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.DEBUG

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 03:02:42.262141
# Unit test for function configure
def test_configure():
    try:
        configure('tests/logging.json')
    except Exception as exc:
        if _PyInfo.PY2:
            assert str(exc) == "Invalid logging config: tests/logging.json"
        else:
            assert str(exc) == "Invalid logging config: 'tests/logging.json'"

    if _PyInfo.PY2:
        return


# Generated at 2022-06-24 03:02:51.423612
# Unit test for function getLogger
def test_getLogger():
    # Test that getLogger function is found and called, allowing us to mock it
    from unittest.mock import patch
    from mock import MagicMock
    from contextlib import contextmanager
    from pytest import raises

    @contextmanager
    def _getLogger_mock(name):
        yield MagicMock(name=name)

    @contextmanager
    def _logger():
        raise Exception('should not be called')

    with patch('pan_cnc.logging.getLogger', _getLogger_mock):
        with raises(Exception, match='should not be called'):
            with logger_level(_logger(), logging.DEBUG):
                pass


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:03:01.831477
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import unittest
    class _PyInfoTest(unittest.TestCase):
        def test__PyInfo(self):
            assert _PyInfo.PY2 or _PyInfo.PY3
            assert isinstance('', _PyInfo.string_types)
            assert isinstance(u'', _PyInfo.string_types)
            if _PyInfo.PY2:
                assert isinstance(b'', _PyInfo.binary_type)
                assert not isinstance('', _PyInfo.binary_type)
                assert not isinstance(u'', _PyInfo.binary_type)
                assert not isinstance(b'', _PyInfo.text_type)
                assert isinstance('', _PyInfo.text_type)
                assert isinstance(u'', _PyInfo.text_type)

# Generated at 2022-06-24 03:03:09.552994
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    assert(logger.level == logging.DEBUG)
    with logger_level(logger, logging.INFO):
        assert(logger.level == logging.INFO)
    assert(logger.level == logging.DEBUG)
    logger.setLevel(logging.INFO)
    assert(logger.level == logging.INFO)
    logger.setLevel(logging.DEBUG)
    assert(logger.level == logging.DEBUG)



# Generated at 2022-06-24 03:03:14.535556
# Unit test for function getLogger
def test_getLogger():
    log = getLogger('test')
    assert log is not None
    assert log.name == 'test'

# Generated at 2022-06-24 03:03:21.317890
# Unit test for function get_config
def test_get_config():
    # Test with given, env_var and default as None
    assert get_config() is None

    # Test with given as json value and env_var and default as None

# Generated at 2022-06-24 03:03:22.827998
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == sys.version_info[0] == 2
    assert _PyInfo.PY3 == sys.version_info[0] == 3



# Generated at 2022-06-24 03:03:26.966790
# Unit test for function getLogger
def test_getLogger():
    """
    >>> getLogger()
    <logging.RootLogger object at 0x10d457550>
    >>> getLogger('my_logger')
    <logging.Logger object at 0x108ee5f90>
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()