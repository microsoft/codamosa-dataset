

# Generated at 2022-06-24 02:53:37.713520
# Unit test for function getLogger
def test_getLogger():
    import shutil
    from io import StringIO
    import tempfile

    log = getLogger()
    buf = StringIO()
    hdlr = logging.StreamHandler(buf)
    log.addHandler(hdlr)
    log.info("Hello World") # Log something
    s = buf.getvalue()
    print(s)
    assert 'Hello World' in s
    assert 'test_logging' in s

    # Test with a custom name
    log = getLogger("test_logging.test_getLogger")
    buf = StringIO()
    hdlr = logging.StreamHandler(buf)
    log.addHandler(hdlr)
    log.info("Hello World again") # Log something
    s = buf.getvalue()
    print(s)
    assert 'Hello World again' in s

# Generated at 2022-06-24 02:53:39.472981
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert(isinstance(logger, logging.Logger))
    assert(logger.level == logging.DEBUG)



# Generated at 2022-06-24 02:53:43.552680
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.string_types == (str,), "failed on string_types"
    assert _PyInfo.text_type == str, "failed on text_type"
    assert _PyInfo.binary_type == bytes, "failed on binary_type"


# Generated at 2022-06-24 02:53:55.530996
# Unit test for function configure
def test_configure():
    import json
    import os
    import unittest
    class TestConfigure(unittest.TestCase):
        def test_configure(self):
            configure()
            logging.info('Test configure function')

# Generated at 2022-06-24 02:54:00.113499
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True or _PyInfo.PY3 is True
    test_instance = _PyInfo()
    if test_instance.PY2 is True:
        assert isinstance(test_instance.string_types, tuple)
    else:
        assert isinstance(test_instance.string_types, list)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:54:05.789397
# Unit test for function configure
def test_configure():
    logging.captureWarnings(True)
    logger = getLogger('test_configure')
    logger.info('test')
    logger = getLogger('requests')
    logger.info('test')
    logger.debug('test')
    with logger_level(logger, logging.DEBUG):
        logger.info('test')
        logger.debug('test')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:54:10.349623
# Unit test for function getLogger
def test_getLogger():
    log = get_logger('test_getLogger')
    from datetime import datetime
    import time
    import random
    for i in range(10):
        time.sleep(0.2)
        log.info(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " test_getLogger")


# Generated at 2022-06-24 02:54:20.580672
# Unit test for function get_config
def test_get_config():
    import tempfile
    import os

    # Config as JSON

# Generated at 2022-06-24 02:54:27.556669
# Unit test for function configure

# Generated at 2022-06-24 02:54:32.837659
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert(logger.level == logging.DEBUG)

    assert(logger.level == logging.DEBUG)
    logger.setLevel(logging.INFO)


if __name__ == '__main__':
    import doctest

    # No coverage for doctests
    doctest.testmod()

# Generated at 2022-06-24 02:54:41.822000
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    # Set level to ERROR
    with logger_level(log,logging.ERROR):
        log.debug('debug message, should not appear')
        log.info('info message, should not appear')
        log.warning('warning message, should not appear')
        log.error('error message, should appear')
        log.critical('critical message, should appear')

    # Set level to WARNING
    with logger_level(log,logging.WARNING):
        log.debug('debug message, should not appear')
        log.info('info message, should not appear')
        log.warning('warning message, should appear')
        log.error('error message, should appear')
        log.critical('critical message, should appear')

    # Set level to INFO

# Generated at 2022-06-24 02:54:47.674627
# Unit test for function logger_level
def test_logger_level():
    import logging
    log1 = logging.getLogger("test_logger_level")
    log1.setLevel(logging.DEBUG)
    log1.addHandler(logging.NullHandler())
    with logger_level(log1, logging.WARNING):
        log1.debug("DEBUG")
        log1.info("INFO")
        log1.warning("WARNING")
        log1.error("ERROR")
    log1.debug("DEBUG")
    log1.info("INFO")
    log1.warning("WARNING")
    log1.error("ERROR")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 02:54:51.496498
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info("Hello, Info")
    logger.debug("Hello, Debug")
    logger.warn("Hello, Warn")
    logger.error("Hello, Error")


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:54:55.052852
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance(_PyInfo.PY2, bool)
    assert isinstance(_PyInfo.PY3, bool)
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert isinstance(_PyInfo.string_types, tuple)
    assert isinstance(_PyInfo.text_type, type)
    assert isinstance(_PyInfo.binary_type, type)



# Generated at 2022-06-24 02:54:58.839301
# Unit test for function getLogger
def test_getLogger():
    logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.DEBUG)
    test_logger = getLogger()
    test_logger.warning('test warning')
    test_logger.info('test info')


# Generated at 2022-06-24 02:55:06.933658
# Unit test for function get_config
def test_get_config():
    config = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'standard': {
                'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
            },
        },
        'handlers': {
            'console': {
                'level': 'DEBUG',
                'class': 'logging.StreamHandler',
                'formatter': 'standard'
            },
        },
        'loggers': {
            'root': {
                'handlers': ['console'],
                'level': 'INFO',
            },
        },
    }
    json_config = json.dumps(config)
    yaml_config = yaml.dump(config)

# Generated at 2022-06-24 02:55:07.495980
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo()

# Generated at 2022-06-24 02:55:13.042769
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger()

    # defer debug
    with logger_level(test_logger, logging.DEBUG):
        test_logger.debug("This should show up")

    # this should be deferred
    test_logger.debug("This should not show up")


if __name__ == "__main__":
    configure()
    log = get_logger('test')
    log.debug("debug")
    log.info("info")
    log.warning("warning")
    log.error("error")
    log.critical("critical")

# Generated at 2022-06-24 02:55:21.457623
# Unit test for function get_config

# Generated at 2022-06-24 02:55:31.738018
# Unit test for function configure

# Generated at 2022-06-24 02:55:42.797293
# Unit test for function getLogger
def test_getLogger():
    from unittest import TestCase, main
    import tempfile

    class TestLogger(TestCase):
        def setUp(self):
            configure(default={'root': {'level': 'DEBUG', 'handlers': ['console']}})

        def test_should_return_logger_default_name(self):
            logger = get_logger()
            assert logger.name == '__main__'

        def test_should_return_logger_with_name(self):
            logger = get_logger(name='test')
            assert logger.name == 'test'

        def test_should_write_log_file_with_default_name(self):
            logger = get_logger()
            with tempfile.TemporaryFile() as log_file:
                logging.basicConfig(stream=log_file)
                logger

# Generated at 2022-06-24 02:55:48.563990
# Unit test for constructor of class _PyInfo
def test__PyInfo():
  p = _PyInfo()
  assert p.PY2 == sys.version_info[0] == 2
  assert p.PY3 == sys.version_info[0] == 3
  assert not (p.PY2 and p.PY3)

if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 02:56:00.153345
# Unit test for function getLogger
def test_getLogger():
    import tempfile, os, re

    # Test logging level
    log = get_logger("test")
    log.setLevel(logging.DEBUG)

    # Test logger output
    log = get_logger("test")
    with tempfile.NamedTemporaryFile("r") as f:
        tmpfilename = f.name
    handler = logging.FileHandler(tmpfilename)
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)
    log.addHandler(handler)

    log.info("info")
    log.warning("warning")
    log.error("error")
    log.debug("debug")

    try:
        with open(tmpfilename, "r") as f:
            res = f.read()
    except IOError as e:
        raise e
   

# Generated at 2022-06-24 02:56:08.071979
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    json_config = json.dumps(DEFAULT_CONFIG)
    yaml_config = yaml.dump(DEFAULT_CONFIG)

    assert get_config(given=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING') is None
    assert get_config(json_config) == DEFAULT_CONFIG
    assert get_config(yaml_config) == DEFAULT_CONFIG



# Generated at 2022-06-24 02:56:14.182424
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # True is expected
    assert _PyInfo.PY2 or _PyInfo.PY3

    if _PyInfo.PY2:
        # True is expected
        assert isinstance('str', _PyInfo.string_types)
    else:
        # False is expected
        assert isinstance('str', _PyInfo.string_types)



# Generated at 2022-06-24 02:56:18.085567
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.INFO):
        log.debug('This should not show')
        log.info('This should show')
        log.error('This should show')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:56:20.856136
# Unit test for function get_config
def test_get_config():
    config = get_config(None, 'LOGGING', None)
    assert config['version'] == 1
    config = get_config('{"version":2}', 'LOGGING', None)
    assert config['version'] == 2



# Generated at 2022-06-24 02:56:28.642462
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print('\033[1;35;40m')
    print('### UNIT TEST ###')
    print('\033[1;30;40m')
    print('Test constructor of class _PyInfo')
    print('PY2 =', _PyInfo.PY2)
    print('PY3 =', _PyInfo.PY3)
    print('\033[1;30;40m')
    print('Test end')
    print('\033[0m')


# Generated at 2022-06-24 02:56:31.966626
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    # logger.warning('test')
    # logger.info('test')
    # logger.debug('test')
    log.info('test')


# Generated at 2022-06-24 02:56:37.659520
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3
    assert pyinfo.string_types == (basestring,)
    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str


# Unit tests for function _namespace_from_calling_context()

# Generated at 2022-06-24 02:56:41.591518
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    assert log.name == 'logutil', log.name



# Generated at 2022-06-24 02:56:47.642584
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == sys.version_info[0] == 2
    assert _PyInfo.PY3 == sys.version_info[0] == 3
    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:  # PY2
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
        text_type = unicode



# Generated at 2022-06-24 02:56:52.579029
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True
    assert _PyInfo.PY3 is False
    assert _PyInfo.string_types is basestring
    assert _PyInfo.text_type is unicode
    assert _PyInfo.binary_type is str



# Generated at 2022-06-24 02:56:57.043061
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 is not None
    assert pyinfo.PY3 is not None
    assert pyinfo.string_types is not None
    assert pyinfo.text_type is not None
    assert pyinfo.binary_type is not None


# Generated at 2022-06-24 02:57:02.893742
# Unit test for function get_config
def test_get_config():
    assert get_config(default=None) == {}
    assert get_config(default="") == {}
    try:
        get_config(config=None)
    except ValueError:
        pass
    else:
        assert 0, 'Should raise an exception'
    assert get_config(config='{"a": 1}') == {"a": 1}
    assert get_config(config='a: 1') == {'a': 1}
    try:
        get_config(config='{}')
    except ValueError:
        pass
    else:
        assert 0, 'Should raise an exception'



# Generated at 2022-06-24 02:57:09.260779
# Unit test for function get_config
def test_get_config():
    assert get_config(default = {'a': 2}) == {'a': 2}
    assert get_config('{"a": "2"}') == {'a': "2"}
    assert get_config('a: 2') == {'a': 2}
    os.environ['LOGGING'] = 'a: 2'
    assert get_config(env_var='LOGGING') == {'a': 2}

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:57:15.743621
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)

    # Make sure getLogger has been configured.
    logger.info('test_logger_level')

    # Log a message with a debug level.  This should not be logged.
    logger.debug('this should not be logged')

    # Set logger level to DEBUG
    with logger_level(logger, logging.DEBUG):
        # Log debug message.  This should be logged.
        logger.debug('this should be logged')

    # Log a message with a debug level.  This should not be logged.
    logger.debug('this should not be logged')

# Generated at 2022-06-24 02:57:19.162450
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert logger.level <= logging.DEBUG

    logger2 = getLogger('test_getLogger')
    logger2.debug('test_getLogger')


if __name__ == '__main__':
    configure()
    root = logging.getLogger()
    root.info('hi')
    root.debug('hi')

# Generated at 2022-06-24 02:57:25.993402
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert isinstance('a', _PyInfo.string_types)
        assert isinstance(u'a', _PyInfo.string_types)
        assert not isinstance(b'a', _PyInfo.string_types)
    else:
        assert isinstance('a', _PyInfo.string_types)
        assert not isinstance(b'a', _PyInfo.string_types)



# Generated at 2022-06-24 02:57:28.135370
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')
    log = get_logger('test2')
    log.info('test2')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:57:30.863003
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()

    with logger_level(log, logging.DEBUG):
        log.debug("test")

    log.debug("test")


# Generated at 2022-06-24 02:57:39.831504
# Unit test for function get_config
def test_get_config():
    config1 = '{"version": 1, "formatters": { "simple": {"format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"}}}'
    assert get_config(given=config1) == json.loads(config1)

    config2 = {"version": 1, "formatters": { "simple": {"format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"}}}
    assert get_config(given=config2) == config2

    config3 = '{"version": 1, "formatters": { "simple": {"format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"}}}'
    os.environ['config3'] = config3


# Generated at 2022-06-24 02:57:49.331907
# Unit test for function getLogger
def test_getLogger():
    # Create a logger
    import config
    import logging
    import logging.handlers
    import os
    import os.path
    import tempfile
    import unittest
    import random
    import string

    random = random.SystemRandom()
    filename = ''.join([random.choice(string.ascii_letters) for i in range(7)])
    logname = 'Log'
    logfile = tempfile.mktemp()
    print('Logfile is %s' % logfile)
    logdir = os.path.dirname(logfile)
    if not os.path.exists(logdir) and 0 != len(logfile):
        os.mkdir(logdir)

    # Set configuration for logging
    logging.config.fileConfig(config.filename)

# Generated at 2022-06-24 02:57:56.721084
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    with logger_level(log, logging.INFO):
        log.debug("this debug message should not appear")
        log.info("this info message should appear")
        log.error("this error message should appear")

    log.debug("this debug message should appear")
    log.info("this info message should appear")
    log.error("this error message should appear")

test_logger_level()

# Generated at 2022-06-24 02:58:06.210536
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert type(_PyInfo.PY2) == bool
    assert type(_PyInfo.PY3) == bool
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert type(_PyInfo.string_types) == tuple
    assert _PyInfo.string_types == (basestring,) # for py2
    #assert _PyInfo.string_types == (str,) # for py3
    assert type(_PyInfo.text_type) == type
    assert _PyInfo.text_type == unicode # for py2
    #assert _PyInfo.text_type == str # for py3
    assert type(_PyInfo.binary_type) == type
    assert _PyInfo.binary_type == str # for py2
    #assert _PyInfo.binary_type == bytes # for py3

# Generated at 2022-06-24 02:58:07.629748
# Unit test for function configure
def test_configure():
    configure()
    logger = get_logger()
    assert logger.level == logging.DEBUG



# Generated at 2022-06-24 02:58:12.702031
# Unit test for function logger_level
def test_logger_level():
    import logging
    log = logging.getLogger('test')
    assert log.level == logging.WARNING
    with logger_level(log, logging.ERROR):
        assert log.level == logging.ERROR
    assert log.level == logging.WARNING



# Generated at 2022-06-24 02:58:17.267750
# Unit test for function logger_level
def test_logger_level():
    import time
    import threading
    log = getLogger()
    with logger_level(log, logging.CRITICAL):
        log.info("This message will not be emitted")
    log.info("This message will be emitted")


if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 02:58:20.748085
# Unit test for function getLogger
def test_getLogger():
    assert getLogger()
    assert getLogger('test')

# Generated at 2022-06-24 02:58:24.989700
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import sys
    if sys.version_info.major == 2:
        assert _PyInfo.PY2
        assert not _PyInfo.PY3
    elif sys.version_info.major == 3:
        assert not _PyInfo.PY2
        assert _PyInfo.PY3

# Generated at 2022-06-24 02:58:27.256707
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert isinstance(logger,logging.Logger)


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:58:33.269470
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True
    assert _PyInfo.PY3 is False

    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str

# Generated at 2022-06-24 02:58:39.798885
# Unit test for function getLogger
def test_getLogger():
    import logging
    import logging.config
    import inspect
    import sys
    # Not py3k compat
    # return inspect.currentframe(2).f_globals["__name__"]
    # TODO Does this work in both py2/3?
    NAME = inspect.stack()[1][0].f_globals["__name__"]


# Generated at 2022-06-24 02:58:47.368886
# Unit test for function getLogger
def test_getLogger():
    import sys
    from contextlib import redirect_stdout

    def check_output(logger):
        stdout = sys.stdout
        with redirect_stdout(stdout):
            logger.debug('test debug')
            logger.info('test info')
            logger.warning('test warning')
            logger.error('test error')
            logger.critical('test critical')

    # Check default logger
    check_output(getLogger())

    # Check user-defined logger
    check_output(getLogger('test'))


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:58:49.040847
# Unit test for function get_config
def test_get_config():
    print(get_config(env_var='LOGGING'))

if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-24 02:58:59.328896
# Unit test for function get_config
def test_get_config():
    config = '{"version": 1, "disable_existing_loggers": false,"formatters": {"colored": {"()": "colorlog.ColoredFormatter","format": "%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s","datefmt": "%H:%M:%S"}},"handlers": {"console": {"class": "logging.StreamHandler","formatter": "colored","level": "INFO"}},"root": {"handlers": ["console"],"level": "INFO"},"loggers": {"requests": {"level": "INFO"}}}'
    config = get_config(config)

# Generated at 2022-06-24 02:59:10.591078
# Unit test for function configure
def test_configure():
    # the default logging configuration is the simple formatter
    config = get_config(default=DEFAULT_CONFIG)
    cfg = config['formatters']['simple']
    logging.basicConfig(**cfg)

    # Get a logger
    log = logging.getLogger(__name__)

    # Assert formatted message
    logging_copy = DEFAULT_CONFIG.copy()
    logging_copy['formatters']['simple']['format'] = '%(message)s'
    logging_copy['root']['handlers'] = ['console']
    logging.config.dictConfig(logging_copy)
    assert log.getEffectiveLevel() == 'DEBUG'
    assert log.info('test') == None

    # Assert name of logger
    logging_copy = DEFAULT_CONFIG.copy()
    logging_copy

# Generated at 2022-06-24 02:59:21.637310
# Unit test for function get_config

# Generated at 2022-06-24 02:59:26.815716
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.DEBUG):
        log = get_logger(__name__)
        log.info('test')
        log.debug('test')
        log.critical('test')


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:59:33.363335
# Unit test for function configure
def test_configure():
    import colorlog

    configure()
    assert logging.getLogger().name == 'root'
    assert isinstance(logging.getLogger().handlers[0], logging.StreamHandler)
    handler_formatter = logging.getLogger().handlers[0].formatter
    assert isinstance(handler_formatter, colorlog.ColoredFormatter)
    logging.getLogger().debug('test')



# Generated at 2022-06-24 02:59:41.658188
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    assert get_config(given = json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(given = yaml.dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(given = DEFAULT_CONFIG) == DEFAULT_CONFIG

    assert get_config(given = yaml.dump(DEFAULT_CONFIG), default=None) == DEFAULT_CONFIG
    assert get_config(given = json.dumps(DEFAULT_CONFIG), default=None) == DEFAULT_CONFIG

    try:
        get_config(given='blah', default=None)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-24 02:59:43.257144
# Unit test for function configure
def test_configure():
    configure()

# Generated at 2022-06-24 02:59:44.278258
# Unit test for function configure
def test_configure():
    assert True


# Generated at 2022-06-24 02:59:52.779333
# Unit test for function getLogger
def test_getLogger():

    """test function getLogger, with default parameter
    """
    from importlib import reload
    import colorlog
    reload(colorlog)
    log1 = colorlog.get_logger()
    log2 = colorlog.get_logger()
    try:
        assert log1 is log2
    except AssertionError as e:
        print(e)
    else:
        print('test_getLogger default pass')

    """test function getLogger, with parameter
    """
    log3 = colorlog.get_logger('test_getLogger')
    try:
        assert log3.name == 'test_getLogger'
    except AssertionError as e:
        print(e)
    else:
        print('test_getLogger parameter pass')



# Generated at 2022-06-24 03:00:00.959180
# Unit test for function logger_level
def test_logger_level():
    import sys
    from contextlib import contextmanager
    from io import StringIO

    @contextmanager
    def capture_output():
        saved_stdout = sys.stdout
        saved_stderr = sys.stderr

        try:
            out = StringIO()
            err = StringIO()
            sys.stdout = out
            sys.stderr = err
            yield out, err
        finally:
            sys.stdout = saved_stdout
            sys.stderr = saved_stderr

    logger = get_logger()

    with capture_output() as (out, err):
        logger.debug('debug')
        logger.info('info')
        logger.error('error')

    assert out.getvalue() == ''

    out.truncate(0)
    err.truncate(0)

# Generated at 2022-06-24 03:00:09.996986
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    assert logger.level != logging.DEBUG
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level != logging.DEBUG
    logger.setLevel = logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO

if __name__ == '__main__':
    configure()
    logger = logging.getLogger(__name__)
    logger.info('test')
    logger.debug('test')
    logger = logging.getLogger('test2')
    logger.info('test2')
    test_logger_level()
    print('Test complete')

# Generated at 2022-06-24 03:00:15.122074
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert not _PyInfo.PY2
    assert _PyInfo.PY3
    assert isinstance('a', _PyInfo.string_types)
    assert isinstance(u'a', _PyInfo.string_types)
    assert isinstance('a', _PyInfo.binary_type)
    assert isinstance(b'a', _PyInfo.binary_type)
    assert isinstance(u'a', _PyInfo.text_type)
    assert isinstance('a', _PyInfo.text_type)



# Generated at 2022-06-24 03:00:21.595793
# Unit test for function configure
def test_configure():
    import tempfile
    import pytest
    from textwrap import dedent
    from colorlog import ColoredFormatter

    def check_logger(name, level):
        logger = logging.getLogger(name)
        assert len(logger.handlers) == 1
        handler = logger.handlers[0]
        assert isinstance(handler, logging.StreamHandler)
        assert handler.level == level
        formatter = handler.formatter
        assert isinstance(formatter, ColoredFormatter)

    fd, path = tempfile.mkstemp(suffix='_logging.yaml')

# Generated at 2022-06-24 03:00:30.242560
# Unit test for function logger_level
def test_logger_level():
    import logging
    for name, log in [('logging', logging.getLogger('test_logger_level.logging')), ('get_logger', get_logger('test_logger_level.get_logger'))]:
        print('Testing %s:' % name)

        log.setLevel(logging.DEBUG)
        log.debug('Debug works')
        log.info('Info works')

        with logger_level(log, logging.INFO):
            log.debug('Debug suppressed')
            log.info('Info works')

        log.debug('Debug works')
        log.info('Info works')




# Generated at 2022-06-24 03:00:34.366900
# Unit test for function getLogger
def test_getLogger():

    logger = getLogger('test')
    assert logger.name == 'test'
    with logger_level(logger, logging.INFO):
        logger.debug('test')
        logger.info('test2')

# Generated at 2022-06-24 03:00:42.572594
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True or _PyInfo.PY3 is True
    assert _PyInfo.PY2 is not _PyInfo.PY3
    assert _PyInfo.string_types == (basestring,) or _PyInfo.string_types == (str,)
    assert _PyInfo.binary_type == str or _PyInfo.binary_type == bytes
    assert _PyInfo.text_type == unicode or _PyInfo.text_type == str

if __name__ == "__main__":
    configure()
    log = get_logger()
    try:
        test__PyInfo()
        log.info("All tests passed.")
    except AssertionError as err:
        log.error("Error: %s" % err)

# Generated at 2022-06-24 03:00:49.392588
# Unit test for function getLogger
def test_getLogger():
    """Test get logger with logging module.
    It will generate a log file in the folder where this file is located."""

    import tempfile
    import os

    tmpdir = tempfile.mkdtemp(prefix="test_logger")
    filename = os.path.join(tmpdir, 'test_logger.log')

# Generated at 2022-06-24 03:00:56.154770
# Unit test for function get_config

# Generated at 2022-06-24 03:01:06.341957
# Unit test for function get_config
def test_get_config():
    import tempfile

    def to_tmp_file(data):
        fh = tempfile.NamedTemporaryFile(delete=False)
        fh.write(data)
        fh.close()
        return fh.name

    with open(__file__) as fh:
        data = fh.read()
    fname = to_tmp_file(data)
    default_config = dict(version=1)
    assert get_config(file_name=fname) == get_config(default=default_config)
    os.remove(fname)

    data = '{"version":"1"}'
    fname = to_tmp_file(data)
    assert get_config(file_name=fname) == get_config(default=default_config)
    os.remove(fname)


# Generated at 2022-06-24 03:01:12.812004
# Unit test for function configure
def test_configure():
    # test_configure_no_parameter
    # TODO - doesn't work in py2
    """
    >>> class FakeStream(object):
    ...     def __init__(self):
    ...         self.out = ''
    ...     def write(self, data):
    ...         self.out += data
    ...
    >>> sys.stdout = FakeStream()
    >>> configure()
    >>> log = logging.getLogger('test_configure')
    >>> log.info('test')
    """
    # test_configure_json_string

# Generated at 2022-06-24 03:01:16.262006
# Unit test for function configure
def test_configure():
    """
    >>> logger = getLogger(__name__)
    >>> configure()
    >>> logger.info('test')
    """
    pass

# Generated at 2022-06-24 03:01:21.817674
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    >>> pyinfo = _PyInfo()
    >>> pyinfo.PY2
    True
    >>> pyinfo.PY3
    False
    >>> pyinfo.string_types
    (<type 'basestring'>,)
    >>> pyinfo.text_type
    <type 'unicode'>
    >>> pyinfo.binary_type
    <type 'str'>
    """
    pass



# Generated at 2022-06-24 03:01:31.827033
# Unit test for function get_config
def test_get_config():
    # Check None
    with pytest.raises(ValueError):
        assert get_config(None)

    # Check empty string
    with pytest.raises(ValueError):
        assert get_config('')

    # Check object
    config = {'key': 'value'}
    assert get_config(config) == config

    # Check json
    json_config = '{"key": "value"}'
    assert get_config(json_config) == config

    # Check yaml
    yaml_config = 'key: value'
    assert get_config(yaml_config) == config

    # Check bad json
    bad_json_config = '{"key" value"}'
    with pytest.raises(ValueError):
        assert get_config(bad_json_config)

    # Check bad yaml
   

# Generated at 2022-06-24 03:01:36.671843
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True or _PyInfo.PY3 is True
    assert _PyInfo.PY2 is False or _PyInfo.PY3 is False
    assert _PyInfo.string_types == (basestring,) or _PyInfo.string_types == (str,)
    assert _PyInfo.text_type == unicode or _PyInfo.text_type == str
    assert _PyInfo.binary_type == str or _PyInfo.binary_type == bytes

# Generated at 2022-06-24 03:01:46.148409
# Unit test for function get_config
def test_get_config():
    assert isinstance(get_config(default=DEFAULT_CONFIG), dict)
    assert isinstance(get_config(''), dict)
    assert isinstance(get_config('{}'), dict)
    assert isinstance(get_config(default='{}'), dict)
    assert isinstance(get_config(env_var='LOGGING'), dict)
    assert isinstance(get_config(env_var='LOGGING', default='{}'), dict)
    assert isinstance(get_config(''), dict)
    assert isinstance(get_config(''), dict)

    # TODO Add test for get_config with config file



# Generated at 2022-06-24 03:01:55.616143
# Unit test for function get_config

# Generated at 2022-06-24 03:02:00.970908
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)

    with logger_level(logger, logging.DEBUG):
        logger.debug('debug test')
    logger.info('info test')

    with logger_level(logger, logging.INFO):
        logger.debug('debug test')
    with logger_level(logger, logging.DEBUG):
        logger.info('info test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 03:02:03.921140
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('This is a test.')
        log.info('This is another test')
    log.error('This is a final test.')

# Generated at 2022-06-24 03:02:05.856028
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:02:13.127882
# Unit test for function get_config
def test_get_config():
    assert not get_config(None, None, None)
    assert not get_config(config=None, env_var='LOGGING', default=None)
    assert not get_config(config=None, env_var=None, default=None)
    assert not get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert not get_config(config=None, env_var="LOGGING", default=DEFAULT_CONFIG)
    assert get_config(config=DEFAULT_CONFIG, env_var=None, default=None) is DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, env_var="LOGGING", default=None) is DEFAULT_CONFIG

# Generated at 2022-06-24 03:02:23.459067
# Unit test for function get_config
def test_get_config():
    env_var = 'LOGGING'
    default = '{"handlers": {"console": {"level": "DEBUG"}}}'

    config = get_config(config=None, env_var=env_var, default=default)

    assert config == {'handlers': {'console': {'level': 'DEBUG'}}}

    # Test config as bare string
    config = get_config(config='{"handlers": {"console": {"level": "INFO"}}}', env_var=None, default=None)
    assert config == {'handlers': {'console': {'level': 'INFO'}}}

    # Test config as json string
    config = get_config(config='{"handlers": {"console": {"level": "INFO"}}}', env_var=None, default=None)

# Generated at 2022-06-24 03:02:26.263077
# Unit test for function getLogger
def test_getLogger():
    configure()
    log = get_logger('test2')
    log.info('test2')
    with logger_level(log, logging.DEBUG):
        log.info('debug level')


# Generated at 2022-06-24 03:02:27.903213
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    obj = _PyInfo()
    return True



# Generated at 2022-06-24 03:02:31.406610
# Unit test for function get_config
def test_get_config():
    config = get_config(
        '{"version": 1, "formatters": {"simple": {"format": "test_test_test"}}}'
    )
    assert config['formatters']['simple']['format'] == 'test_test_test'

# Generated at 2022-06-24 03:02:34.491828
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-24 03:02:38.801385
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.debug("This is debug info")
    log.info("This is info")
    log.warning("This is warning info")
    log.critical('This is critical info')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:02:42.222138
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2 is True or _PyInfo().PY3 is True
    assert isinstance(_PyInfo().string_types, tuple)
    assert isinstance(_PyInfo().text_type, type)


# Generated at 2022-06-24 03:02:43.422667
# Unit test for function getLogger
def test_getLogger():
    assert isinstance(getLogger(), logging.Logger)



# Generated at 2022-06-24 03:02:54.604842
# Unit test for function logger_level
def test_logger_level():
    import logging
    import os

    fmt = '%(levelname)s:%(name)s:%(message)s'
    logging.basicConfig(format=fmt)
    log = get_logger('ultron8.utils.log')

    # output to a file, so we can verify the output is correct
    fd, fname = tempfile.mkstemp()
    os.close(fd)

    fh = logging.FileHandler(fname)
    formatter = logging.Formatter(fmt)
    fh.setFormatter(formatter)
    log.addHandler(fh)


    # default level is warning
    log.debug('debug message')
    log.info('info message')
    log.warning('warning message')
    log.error('error message')

# Generated at 2022-06-24 03:02:59.830122
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
    assert logger.level == logging.DEBUG

if __name__ == "__main__":
    # Tests
    logger = getLogger(__name__)
    logger.info('test {}'.format('pyinfo'))
    test_logger_level()

# Generated at 2022-06-24 03:03:04.987551
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.INFO):
        logger.debug('Should not be seen')
        logger.error('This should be seen')
    logger.debug('Should be seen')

# Generated at 2022-06-24 03:03:12.923447
# Unit test for function get_config
def test_get_config():
    cfg = {'handlers': {'console': {'level': 'INFO'}}}
    default_cfg = DEFAULT_CONFIG

    assert get_config(cfg) == cfg

    # Test if str config is parsed
    assert cfg["handlers"]["console"]["level"] == cfg["handlers"]["console"]["level"]
    assert get_config(json.dumps(cfg))["handlers"]["console"]["level"] == cfg["handlers"]["console"]["level"]

    # Test if default config is used
    assert get_config(None, None, default_cfg) == default_cfg
    assert get_config(None, None, default_cfg) == get_config(None, None, default_cfg)

    # Test if env_var is used

# Generated at 2022-06-24 03:03:18.675188
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 is bool(sys.version_info[0] == 3)
    assert _PyInfo.PY2 is bool(sys.version_info[0] == 2)
    assert _PyInfo.string_types is (basestring,) if _PyInfo.PY2 else (str,)
    assert _PyInfo.text_type is unicode if _PyInfo.PY2 else str
    assert _PyInfo.binary_type is str if _PyInfo.PY2 else bytes



# Generated at 2022-06-24 03:03:24.838721
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    nil = object()
    assert get_config(given=None) is nil

    try:
        get_config()
    except ValueError:
        pass

    json_str = json.dumps({})
    assert isinstance(get_config(json_str), dict)

    yaml_str = yaml.dump({})
    assert isinstance(get_config(yaml_str), dict)

if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-24 03:03:26.331898
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 03:03:35.241004
# Unit test for function getLogger
def test_getLogger():
    import textwrap
    from io import BytesIO
    import sys

    conf = """
    version: 1
    disable_existing_loggers: False
    formatters:
      simple:
        format: '%(levelname)s\n%(name)s: %(message)s\n%(asctime)s\n'
        datefmt: '%H:%M:%S'
    handlers:
      console:
        class: logging.StreamHandler
        formatter: simple
        level: DEBUG
        stream: ext://sys.stdout
    loggers:
      test:
        handlers: [console]
        level: DEBUG
    root:
      handlers: [console]
      level: DEBUG
    """
    conf = textwrap.dedent(conf)
    conf = yaml.load(conf)
   