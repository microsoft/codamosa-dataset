

# Generated at 2022-06-24 02:53:34.105733
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    logger.setLevel(logging.WARNING)
    with logger_level(logger, logging.DEBUG):
        logger.info("This should be shown")
    logger.info("This should not be shown")
    logger.setLevel(logging.DEBUG)
    logger.info("This should be shown")

test_logger_level()

# Generated at 2022-06-24 02:53:42.474234
# Unit test for function get_config
def test_get_config():
    """
    Unit test for get_config.

    :return: Nothing.
    """
    import json

    a = {
        'version': 1,
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'colored',
                'level': 'DEBUG',
              },
          },
        'loggers': {
            'tests': {
                'handlers': ['console'],
                'level': 'DEBUG',
                'propagate': True,
              },
          },
      }

    assert json.dumps(get_config(a)) == json.dumps(a)

    b = str(a)
    assert json.dumps(get_config(b)) == json.dumps(a)

    c = json.dumps(a)

# Generated at 2022-06-24 02:53:54.705146
# Unit test for function configure
def test_configure():
    configure()
    logging.getLogger(__name__).debug("test")
    configure(None, 'LOGGING', None)
    logging.getLogger(__name__).debug("test")

# Generated at 2022-06-24 02:54:01.986854
# Unit test for function get_config
def test_get_config():
    cfg = get_config(dict(name='a'))
    assert cfg == {"name": "a"}
    cfg = get_config(json.dumps({'name': 'a'}))
    assert cfg == {"name": "a"}


# Generated at 2022-06-24 02:54:12.867956
# Unit test for function get_config
def test_get_config():
    assert get_config(env_var='LOGGING') is not None

    from io import StringIO
    config_str = StringIO()

# Generated at 2022-06-24 02:54:23.159216
# Unit test for function logger_level
def test_logger_level():
    import tempfile, os
    temp_file_name = tempfile.mktemp()
    logger_name = 'logger_level_test'

# Generated at 2022-06-24 02:54:34.529939
# Unit test for function configure
def test_configure():
    with logger_level(getLogger(__name__), logging.DEBUG):
        assert(logging.getLogger().getEffectiveLevel() == logging.DEBUG)

    with logger_level(getLogger(__name__), logging.DEBUG):
        configure()
        assert(logging.getLogger().getEffectiveLevel() == logging.DEBUG)

    with logger_level(getLogger(__name__), logging.DEBUG):
        configure(default=dict(formatters={'simple': {'format': '%(message)s'}}, handlers={'console': {'stream': sys.stdout, 'formatter': 'simple'}}, root={'handlers': ['console'], 'level': logging.DEBUG}))
        assert(logging.getLogger().getEffectiveLevel() == logging.DEBUG)


# Generated at 2022-06-24 02:54:42.393737
# Unit test for function getLogger
def test_getLogger():
    import json
    import yaml
    import logging
    import logging.config

    cfg = get_config(env_var='LOGGING', default=DEFAULT_CONFIG)
    logging.config.dictConfig(cfg)

    logger = getLogger()

    logger.debug('DEBUG')
    logger.info('INFO')
    logger.warning('WARNING')
    logger.error('ERROR')
    logger.critical('CRITICAL')

    logger = getLogger('test')

    logger.debug('DEBUG')
    logger.info('INFO')
    logger.warning('WARNING')
    logger.error('ERROR')
    logger.critical('CRITICAL')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:54:51.022105
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config(DEFAULT_CONFIG)
    assert DEFAULT_CONFIG == get_config(json.dumps(DEFAULT_CONFIG))
    assert DEFAULT_CONFIG == get_config(yaml.dump(DEFAULT_CONFIG))
    assert DEFAULT_CONFIG == get_config(yaml.dump(DEFAULT_CONFIG), 'LOGGING')
    assert DEFAULT_CONFIG == get_config(yaml.dump(DEFAULT_CONFIG), 'LOGGING', DEFAULT_CONFIG)

if __name__ == '__main__':
    import subprocess
    import os
    import sys

    if sys.version_info[0] != 2:
        print("Only python 2 is supported")
        sys.exit(1)

    # unit test

# Generated at 2022-06-24 02:54:54.024222
# Unit test for function getLogger

# Generated at 2022-06-24 02:55:01.268382
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import sys
    import os
    py_info = _PyInfo()
    assert py_info.PY2 and py_info.PY3 == False
    if sys.version_info[0] == 2:
        assert type(py_info.string_types) == tuple
        assert py_info.text_type == unicode
        assert py_info.binary_type == str
    else:
        assert type(py_info.string_types) == tuple
        assert py_info.text_type == str
        assert py_info.binary_type == bytes


# Generated at 2022-06-24 02:55:03.189552
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.PY3 or _PyInfo.PY2


# Generated at 2022-06-24 02:55:08.525453
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    log = get_logger(__name__)

    with logger_level(log, logging.INFO):
        log.debug('debug')
        assert log.getEffectiveLevel() == logging.INFO
        assert log.level == logging.INFO

    assert log.getEffectiveLevel() == logging.NOTSET
    assert log.level == logging.NOTSET


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:55:13.507774
# Unit test for function get_config
def test_get_config():
    print('logging.get_config({})'.format(get_config()))
    print('logging.get_config(config=None, env_var="LOGGING", default=DEFAULT_CONFIG)')
    print('logging.get_config(env_var="LOGGING")')
    print('logging.get_config(config=None, default=DEFAULT_CONFIG)')
    print('logging.get_config(config=None, env_var="LOGGING")')
    print('logging.get_config(config=None)')
    print('logging.get_config(config=None, env_var=None, default=DEFAULT_CONFIG)')
    print('logging.get_config(config=None, env_var=None)')

# Generated at 2022-06-24 02:55:15.018250
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.info("test")
        assert logging.DEBUG == log.level
    assert logging.INFO == log.level

# Generated at 2022-06-24 02:55:23.860858
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    Instance = _PyInfo()
    PY2 = sys.version_info[0] == 2
    PY3 = sys.version_info[0] == 3


# Generated at 2022-06-24 02:55:31.424659
# Unit test for function logger_level
def test_logger_level():
    full_log_string = """here's a log,
here's another log,
here's a third log"""
    no_log_string = ''
    test_logger = logging.getLogger(__name__)
    test_logger.setLevel(logging.ERROR)
    with logger_level(test_logger, logging.INFO):
        test_logger.info(full_log_string)
    assert (test_logger.handlers[0].buffer == full_log_string)
    test_logger.info(no_log_string)
    assert (test_logger.handlers[0].buffer == full_log_string)


# Generated at 2022-06-24 02:55:36.391237
# Unit test for function get_config
def test_get_config():
    print('======= Unit test for function get_config =======')
    print(get_config())
    print(get_config(default=None))
    print(get_config(default=1.4))
    print(get_config(default='test'))
    print(get_config(default=[]))
    print(get_config(default={'test': 1}))

    logging.basicConfig(level=logging.DEBUG)
    print(get_config())
    print('======= End of Unit test for function get_config =======')



# Generated at 2022-06-24 02:55:39.148959
# Unit test for function logger_level
def test_logger_level():
    setup_logging(debug=True)
    log = get_logger()
    # Before the context block, logging level should be ERROR
    assert log.getEffectiveLevel() == logging.ERROR
    # Inside the context block, logging level should be DEBUG
    with logger_level(log, logging.DEBUG):
        assert log.getEffectiveLevel() == logging.DEBUG
    # After the context block, logging level should be ERROR
    assert log.getEffectiveLevel() == logging.ERROR



# Generated at 2022-06-24 02:55:47.970497
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2 and sys.version_info[0] == 2:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str

    elif _PyInfo.PY3 and sys.version_info[0] == 3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes

    else:
        raise AssertionError("This is not python version 2 or 3.")



# Generated at 2022-06-24 02:55:54.866218
# Unit test for function get_config
def test_get_config():
    from tempfile import NamedTemporaryFile
    import json
    import yaml
    cfg_json = json.dumps(DEFAULT_CONFIG)
    cfg_yaml = yaml.dump(DEFAULT_CONFIG)
    assert get_config(cfg_json) == DEFAULT_CONFIG
    assert get_config(cfg_yaml) == DEFAULT_CONFIG

if __name__ == "__main__":
    import doctest

    doctest.testmod(
        verbose=True,
        # exclude_empty=True,
        optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS,
    )
    test_get_config()

# Generated at 2022-06-24 02:56:05.743589
# Unit test for function configure
def test_configure():
    if 'LOGGING' in os.environ:
        del os.environ['LOGGING']
    log1 = get_logger('log1')
    log1.info("test")
    log2 = get_logger('log2')
    log2.info("test")

    assert log1.level == logging.DEBUG
    assert log2.level == logging.DEBUG

    log1_cfg = dict(root=dict(level=logging.INFO), loggers={'log1': dict(level=logging.INFO)})
    log2_cfg = dict(root=dict(level=logging.INFO), loggers={'log2': dict(level=logging.INFO)})
    log1_cfg_json = json.dumps(log1_cfg)

# Generated at 2022-06-24 02:56:09.085713
# Unit test for function getLogger
def test_getLogger():
    try:
        log = getLogger()
        log.info('test info')
        log.debug('test debug')
        log.warning('test warning')
        log.error('test error')
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-24 02:56:17.234150
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.INFO)
    rootLogger = logging.getLogger()
    level = rootLogger.level
    print('Initial level=' + str(level))

    with logger_level(rootLogger, logging.DEBUG):
        print('Logging with level=' + str(rootLogger.level))
        rootLogger.debug('debug message')
        rootLogger.info('info message')

    print('Logging with level=' + str(rootLogger.level))
    rootLogger.debug('debug message')
    rootLogger.info('info message')


if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 02:56:27.560995
# Unit test for function logger_level
def test_logger_level():
    import time
    import io

    log=logging.getLogger("test_logger_level")
    stream=io.StringIO()
    hdlr = logging.StreamHandler(stream)
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    hdlr.setFormatter(formatter)
    log.addHandler(hdlr)
    log.setLevel(logging.INFO)

    with logger_level(log, logging.DEBUG):
        log.debug("test_logger_level")
        log.info("test_logger_level")
    time.sleep(.05)
    stream.seek(0)
    assert "DEBUG" in stream.read()
    assert "INFO" in stream.read()
    stream.close()

# Generated at 2022-06-24 02:56:31.966037
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test')
    logger.warning('test')

    logger = getLogger('test2')
    logger.info('test2')
    logger.warning('test2')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:56:39.243828
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert isinstance('test', _PyInfo.string_types)
        assert not isinstance(b'test', _PyInfo.string_types)
        assert isinstance(u'test', _PyInfo.string_types)
    else:
        assert isinstance('test', _PyInfo.string_types)
        assert isinstance(b'test', _PyInfo.string_types)
        assert not isinstance(u'test', _PyInfo.string_types)



# Generated at 2022-06-24 02:56:44.390678
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True or _PyInfo.PY2 == False
    assert _PyInfo.PY3 == True or _PyInfo.PY3 == False
    assert (_PyInfo.PY2 == True) ^ (_PyInfo.PY3 == True)
    assert _is_str(_PyInfo.string_types)
    assert _is_str(_PyInfo.text_type)
    assert _is_str(_PyInfo.binary_type)


# Generated at 2022-06-24 02:56:55.527180
# Unit test for function get_config
def test_get_config():
    # test default
    assert get_config() == DEFAULT_CONFIG

    # test given
    cfg = dict(root=dict(level=logging.DEBUG))
    assert get_config(given=cfg) == cfg

    # test env_var
    os.environ['LOGGING'] = json.dumps(cfg)
    assert get_config(env_var='LOGGING') == cfg

    # test json
    cfg = dict(root=dict(level=logging.DEBUG))
    cfg = json.dumps(cfg)
    assert get_config(config=cfg) == json.loads(cfg)

    # test yaml
    cfg = dict(root=dict(level=logging.DEBUG))
    cfg = json.dumps(cfg)

# Generated at 2022-06-24 02:56:59.114230
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    import logging
    assert not logger.disabled
    assert logger.level == logging.DEBUG
    assert logger.name == 'log_setup'

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 02:57:05.430852
# Unit test for function logger_level
def test_logger_level():
    # Tests the logger_level context manager by testing the logger's level is set correctly within and outside of a context
    logger = get_logger() # Just to test if the level of any logger changed
    with logger_level(logger, logging.INFO):
        assert(logger.level == logging.INFO)
    assert(logger.level != logging.INFO)

# Generated at 2022-06-24 02:57:14.405547
# Unit test for function get_config
def test_get_config():
    # Check if we get the right config when giving a dictionary
    config = get_config(given={'version': 1, 'disable_existing_loggers': False})
    assert config == {'version': 1, 'disable_existing_loggers': False}

    # Check if we get the right config when giving a string and it is JSON
    config = get_config(given='{"version": 1, "disable_existing_loggers": false}')
    assert config == {'version': 1, 'disable_existing_loggers': False}

    # Check if we get the right config when giving a string and it is YAML
    config = get_config(given='version: 1\ndisable_existing_loggers: false')
    assert config == {'version': 1, 'disable_existing_loggers': False}

    # Check if we get the right config

# Generated at 2022-06-24 02:57:18.378689
# Unit test for function getLogger
def test_getLogger():
    """
    >>> logger = getLogger()
    >>> try:
    ...     1/0
    ... except:
    ...     logger.exception('Error:')
    Traceback (most recent call last):
      File "<stdin>", line 3, in <module>
    ZeroDivisionError: division by zero

    >>> logger.info('test')
    """
    pass


# Generated at 2022-06-24 02:57:28.231864
# Unit test for function get_config
def test_get_config():
    from logging import DEBUG
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=str(DEFAULT_CONFIG), default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG), default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=yaml.dump(DEFAULT_CONFIG), default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config={'root': {'level': DEBUG}}, default={'root': {'level': logging.DEBUG}})['root']['level'] == DEBUG


# Generated at 2022-06-24 02:57:32.302639
# Unit test for function logger_level
def test_logger_level():
    import logging
    with logger_level(logging.getLogger(), logging.WARNING):
        logger = get_logger()
        logger.info('this should not print')
        logger.warning('this should print')
    logger.info('this should print')



# Generated at 2022-06-24 02:57:35.991491
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, logging.ERROR):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    assert logger.level == logging.NOTSET


# Generated at 2022-06-24 02:57:41.960260
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert isinstance('This is a string', _PyInfo.string_types)
    # The following is only true when the source is UTF-8.
    assert isinstance(
        u'This is a unicode string', _PyInfo.string_types
    )
    # The following is only true when the source is UTF-8.
    assert isinstance(
        b'This is a binary string', _PyInfo.string_types
    )



# Generated at 2022-06-24 02:57:44.503870
# Unit test for function configure
def test_configure():
    import logging
    import logging.config

    logger = logging.getLogger(__name__)
    logger.info('test')

test_configure()


# Generated at 2022-06-24 02:57:51.660803
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance(_PyInfo.PY2, bool)
    assert isinstance(_PyInfo.PY3, bool)
    assert isinstance(_PyInfo.string_types, tuple)
    if _PyInfo.PY3:
        assert isinstance(_PyInfo.string_types[0], type(str()))
        assert isinstance(_PyInfo.text_type, type(str()))
        assert isinstance(_PyInfo.binary_type, type(str().encode()))
    else:
        assert isinstance(_PyInfo.string_types[0], type(str()))
        assert isinstance(_PyInfo.text_type, type(str()))
        assert isinstance(_PyInfo.binary_type, type(str()))


# Generated at 2022-06-24 02:57:55.442658
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug('hello world')
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO
    logger.debug('hello world')

# Generated at 2022-06-24 02:57:59.186009
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True or _PyInfo.PY3 is True
    assert not (_PyInfo.PY2 and _PyInfo.PY3)


if __name__ == '__main__':
    import logging

    _ensure_configured()
    logger = logging.getLogger()
    logger.debug('test')

# Generated at 2022-06-24 02:58:00.225637
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    logger.info("Test")



# Generated at 2022-06-24 02:58:03.261222
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    new_pyinfo = _PyInfo()
    assert new_pyinfo.PY2 is False
    assert new_pyinfo.PY3 is True

# Generated at 2022-06-24 02:58:08.263382
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert isinstance(logger, logging.Logger)

    logger.debug('Test debug')
    logger.info('Test info')
    logger.warning('Test warning')
    logger.error('Test error')
    logger.critical('Test critical')

    assert logger is get_logger()

    assert get_logger('test') is not get_logger()
    assert get_logger('test') is get_logger('test')



# Generated at 2022-06-24 02:58:19.463005
# Unit test for function get_config
def test_get_config():
    assert get_config(env_var="TEST_LOGGING") == None
    assert get_config(config=DEFAULT_CONFIG, env_var="TEST_LOGGING") == DEFAULT_CONFIG

# Generated at 2022-06-24 02:58:20.854656
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')

# Generated at 2022-06-24 02:58:24.779452
# Unit test for function get_config
def test_get_config():
    # Given:
    env_var = 'LOGGING'
    os.environ[env_var] = 'abc'

    # When:
    config = get_config(env_var=env_var)

    # Then:
    assert config == 'abc'



# Generated at 2022-06-24 02:58:30.330246
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.WARN):
        logger.debug('test debug')
        logger.info('test info')
        logger.warn('test warn')
    logger.debug('test debug')
    logger.info('test info')
    logger.warn('test warn')

# Generated at 2022-06-24 02:58:34.025612
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    logger.info('test')
    logger.error('test')
    logger.debug('test')



# Generated at 2022-06-24 02:58:40.247093
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.debug('test - debug')
    log.info('test - info')
    log.warn('test - warn')
    log.error('test - error')
    log.critical('test - critical')

    with logger_level(log, logging.ERROR):
        log.debug('test - debug')
        log.info('test - info')
        log.warn('test - warn')
        log.error('test - error')
        log.critical('test - critical')

    configure(config='{"version": 1, "root": {}, "formatters": {"simple": {"format": "%(levelname)s %(message)s"}}}')
    log = logging.getLogger(__name__)
    log.debug('test - debug')
    log.info

# Generated at 2022-06-24 02:58:48.966947
# Unit test for function get_config
def test_get_config():
    assert get_config(
        '{"root": {"level": "INFO", "handlers": ["console"]}, '
        '"loggers": {"requests": {"level": "INFO"}}}'
    ) == {
        'root': {'level': 20, 'handlers': ['console']},
        'loggers': {'requests': {'level': 20}}
    }

    assert get_config(
        "root:\n level: INFO\n handlers:\n - console\n"
        "loggers:\n requests:\n  level: INFO\n "
    ) == {
        'root': {'level': 20, 'handlers': ['console']},
        'loggers': {'requests': {'level': 20}}
    }

# Generated at 2022-06-24 02:58:56.180369
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = get_logger()
    >>> assert logger.level == logging.DEBUG
    >>> with logger_level(logger, logging.INFO):
    ...     assert logger.level == logging.INFO
    >>> assert logger.level == logging.DEBUG
    """


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:59:02.106449
# Unit test for function logger_level
def test_logger_level():
    """ A unit test that uses the logger_level context manager to change the log level of the test_logger_level logger.
    It sets the level to DEBUG, checks for a DEBUG message to be logged and then resets the level back to the original.
    """
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('Test')
        assert logger.level == logging.DEBUG, 'logger.level==logging.DEBUG failed, got %s' % logger.level
    assert logger.level == logging.NOTSET, 'logger.level==logging.NOTSET failed, got %s' % logger.level



# Generated at 2022-06-24 02:59:07.651501
# Unit test for function getLogger
def test_getLogger():
    """
    >>> import logging
    >>> log = getLogger()
    >>> log.info('test')
    >>> log = getLogger('test2')
    >>> log.info('test2')
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:59:11.580291
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test_getLogger')
    logger.debug('test_getLogger debug')
    logger.info('test_getLogger info')
    logger.warning('test_getLogger warning')
    logger.error('test_getLogger error')
    logger.critical('test_getLogger critical')



# Generated at 2022-06-24 02:59:21.424518
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    '''
    >>> assert _PyInfo.PY2 or _PyInfo.PY3
    >>> assert isinstance(u'a', _PyInfo.text_type)
    >>> assert isinstance(b'a', _PyInfo.binary_type)
    >>> py_info = _PyInfo()
    >>> assert py_info.PY2 or py_info.PY3
    >>> assert isinstance(u'a', py_info.text_type)
    >>> assert isinstance(b'a', py_info.binary_type)
    '''
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:59:27.919102
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    info = _PyInfo()
    assert info.PY2 or info.PY3

    if info.PY2:
        assert info.string_types == (basestring,)
        assert info.binary_type == str
        assert info.text_type == unicode
    elif info.PY3:
        assert info.string_types == (str,)
        assert info.binary_type == bytes
        assert info.text_type == str


# Generated at 2022-06-24 02:59:31.929553
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

    log = getLogger('test')
    log.info('test')


# Generated at 2022-06-24 02:59:40.039948
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter('[%(asctime)s] [%(name)s/%(process)d] ' \
                                  '%(message)s @%(funcName)s:%(lineno)d #%(levelname)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
        logger.error("This is error message")
    assert logger.level == logging.INFO

test_logger_level()

# Generated at 2022-06-24 02:59:43.301302
# Unit test for function configure
def test_configure():
    configure()
    assert logging.basicConfig()
    log = get_logger(__name__)
    # log.info('test')


# Generated at 2022-06-24 02:59:52.144127
# Unit test for function logger_level
def test_logger_level():
    import unittest

    import logging

    class TestLoggerLevel(unittest.TestCase):

        def setUp(self):
            self.logger = logging.getLogger('test_logger_level')
            for handler in self.logger.handlers:
                self.logger.removeHandler(handler)

        def test_logger_level_10(self):
            test_handler = logging.StreamHandler()
            self.logger.addHandler(test_handler)
            self.logger.setLevel(logging.DEBUG)
            with logger_level(self.logger, logging.INFO):
                self.logger.debug('test_debug')
                self.assertEqual(test_handler.stream.getvalue(), '')
                self.logger.info('test_info')
                self.assertEqual

# Generated at 2022-06-24 03:00:00.561563
# Unit test for function configure
def test_configure():
    # test bare dict
    config = dict(
        version=1,
        root=dict(handlers=['console'], level=logging.DEBUG),
    )
    configure(config, env_var='LOGGING', default=None)
    logging.warning('test')

    # test json
    config = dict(
        version=1,
        root=dict(handlers=['console'], level=logging.DEBUG),
    )
    import json
    config = json.dumps(config)
    configure(config, env_var='LOGGING', default=None)
    logging.warning('test')

    # test yaml
    config = dict(
        version=1,
        root=dict(handlers=['console'], level=logging.DEBUG),
    )
    import yaml
    config = yaml

# Generated at 2022-06-24 03:00:05.226183
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be visible.")
        logger.info("This should not be visible.")
    logger.debug("This should be visible.")
    logger.info("This should also be visible.")



# Generated at 2022-06-24 03:00:09.564344
# Unit test for function getLogger
def test_getLogger():
    log1 = get_logger(__name__)
    log2 = getLogger(__name__)
    log3 = getLogger()
    import __main__
    log4 = getLogger(__main__.__name__)
    assert log1 == log2 == log3 == log4

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:00:10.513980
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-24 03:00:13.321455
# Unit test for function getLogger
def test_getLogger():
    try:
        logger = getLogger()
        logger.info("Testing getLogger function")
    except Exception:
        return False
    return True


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:00:22.497573
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

    if _PyInfo.PY2:
        assert _PyInfo.string_types == (basestring,)
        assert isinstance('hello', _PyInfo.string_types)
        assert isinstance(u'hello', _PyInfo.string_types)
        assert not isinstance(b'hello', _PyInfo.string_types)
    else:  # PY3
        assert _PyInfo.string_types == (str,)
        assert isinstance('hello', _PyInfo.string_types)
        assert not isinstance(u'hello', _PyInfo.string_types)

# Generated at 2022-06-24 03:00:28.692548
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    assert log.level == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
        with logger_level(log, logging.ERROR):
            assert log.level == logging.ERROR
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG


# Generated at 2022-06-24 03:00:33.983334
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    log.critical('Before level change')
    with logger_level(log, logging.DEBUG):
        log.critical('In level change context')
        assert log.isEnabledFor(logging.DEBUG)
        assert log.isEnabledFor(logging.DEBUG)
    log.critical('After level change')

# Generated at 2022-06-24 03:00:38.612663
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')
    log = get_logger('test2')
    log.info('test2')
    configure()
    log = get_logger()
    log.info('test')
    log = get_logger('test2')
    log.info('test2')



# Generated at 2022-06-24 03:00:43.370049
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert not _PyInfo.PY3
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str



# Generated at 2022-06-24 03:00:50.604946
# Unit test for function get_config
def test_get_config():
    from pyyaks.context import Context

    ctx = Context('test_get_config')
    ctx.root = os.path.join(os.path.dirname(__file__), 'test_logging')


# Generated at 2022-06-24 03:00:52.588450
# Unit test for function getLogger
def test_getLogger():
    logging.root.setLevel(0)
    log = getLogger()
    log.info('test')
    assert log.name == 'test_log'



# Generated at 2022-06-24 03:01:01.837138
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert(_PyInfo.PY2==True or _PyInfo.PY3==True)
    assert(_PyInfo.PY2==True and _PyInfo.PY3==False) or \
            (_PyInfo.PY2==False and _PyInfo.PY3==True)
    if _PyInfo.PY2:
        assert(isinstance('a', _PyInfo.string_types)==True)
        assert(isinstance(u'a', _PyInfo.string_types)==True)
        assert(isinstance(b'a', _PyInfo.string_types)==False)
        assert(isinstance('a', _PyInfo.text_type)==True)
        assert(isinstance(u'a', _PyInfo.text_type)==False)

# Generated at 2022-06-24 03:01:03.436374
# Unit test for function getLogger
def test_getLogger():
    """
    >>> getLogger('test').info('test')
    """



# Generated at 2022-06-24 03:01:05.237944
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')


# Generated at 2022-06-24 03:01:06.767898
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 == True
    assert _PyInfo.PY2 == False



# Generated at 2022-06-24 03:01:11.236264
# Unit test for function configure
def test_configure():
    from os import environ
    import tempfile

    with tempfile.TemporaryFile() as f:
        f.write('{"version": 1, "formatters": {"simple": {"format": "%(levelname)s %(message)s"}}}'.encode())
        f.seek(0)
        environ['LOGGING'] = f.name
        configure()
        logging.info("Testing configure()")
        del environ['LOGGING']


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 03:01:19.866219
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    info_msg = 'info'
    warn_msg = 'warning'
    initial_level = logger.level
    assert initial_level >= logging.WARNING
    logger.warning(warn_msg)
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        logger.info(info_msg)
    assert logger.level == initial_level
    log_msg = logging.getLogger().handlers[0].stream.getvalue().strip()
    assert log_msg == warn_msg

# Generated at 2022-06-24 03:01:20.531719
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3


# Generated at 2022-06-24 03:01:28.703466
# Unit test for function get_config
def test_get_config():
    default = 'testing'
    assert get_config(default=default) == default

    given = 2
    assert get_config(given) == given
    assert get_config() == given

    given = '{"foo": "bar"}'
    assert get_config(given) == {"foo": "bar"}

    given = 'foo: bar'
    assert get_config(given) == {"foo": "bar"}

    given = 'foo: bar'
    assert get_config(given) == {"foo": "bar"}



# Generated at 2022-06-24 03:01:33.362031
# Unit test for function configure
def test_configure():
    configure()
    assert logging.getLogger().level == logging.DEBUG



# Generated at 2022-06-24 03:01:35.402302
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test message')

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 03:01:38.156689
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance('', _PyInfo.string_types)
    assert isinstance('', _PyInfo.text_type)
    assert not isinstance('', _PyInfo.binary_type)
    assert _PyInfo.PY2 is not _PyInfo.PY3

# Generated at 2022-06-24 03:01:41.899436
# Unit test for function configure
def test_configure():
    import unittest
    class LogConfigTestCase(unittest.TestCase):
        def test_configure(self):
            self.logger = configure()
            self.assertEqual(self.logger.level, 'DEBUG')
    unittest.main()


# Generated at 2022-06-24 03:01:52.886893
# Unit test for function getLogger
def test_getLogger():
    import unittest
    import logging
    from logging import Handler
    from testfixtures import LogCapture
    class MyHandler(Handler):
        def __init__(self):
            super(MyHandler, self).__init__()
            self.records = []
        def emit(self, record):
            self.records.append(record)

    def get_logger(name=None):
        logger = logging.getLogger(name)
        h = MyHandler()
        logger.addHandler(h)
        logger.setLevel(logging.DEBUG)
        return logger, h
    logger, h = get_logger()

    class MyTestCase(unittest.TestCase):
        def test_getLogger(self):
            logger.debug('test')
            assert len(h.records) == 1
            record

# Generated at 2022-06-24 03:01:56.758906
# Unit test for function logger_level
def test_logger_level():
    """
    >>> import logging
    >>> log = logging.getLogger(__name__)
    >>> log.debug('test1')
    >>> with logger_level(log, logging.ERROR):
    ...     log.debug('test2')
    >>> log.debug('test3')
    """
    pass

# Generated at 2022-06-24 03:02:00.861644
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2
    assert isinstance(
        _PyInfo().string_types,
        tuple
    )
    assert isinstance(
        _PyInfo().string_types[0],
        type
    )
    assert isinstance(
        _PyInfo().binary_type,
        type
    )
    assert _PyInfo().text_type == str



# Generated at 2022-06-24 03:02:07.895406
# Unit test for function logger_level
def test_logger_level():
    # Testing log level before changing
    logger = logging.getLogger(__name__)
    assert logger.level == logging.DEBUG

    # Testing log level after setting to another level
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO

    # Testing log level after changing back to original level
    assert logger.level == logging.DEBUG


LOGGING_LEVELS = {
    'CRITICAL': logging.CRITICAL,
    'ERROR': logging.ERROR,
    'WARNING': logging.WARNING,
    'INFO': logging.INFO,
    'DEBUG': logging.DEBUG
}



# Generated at 2022-06-24 03:02:13.332911
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG
    assert get_config(default=None) is None
    assert get_config({}) == {}
    assert get_config({'foo': 'bar'}) == {'foo': 'bar'}
    assert get_config(json.dumps({'foo': 'bar'})) == {'foo': 'bar'}
    assert get_config(yaml.dump({'foo': 'bar'})) == {'foo': 'bar'}

    try:
        get_config(1234)
    except ValueError:
        pass
    else:
        assert False

    try:
        get_config('foo bar')
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-24 03:02:18.126438
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('Test getLogger')


# Generated at 2022-06-24 03:02:19.481316
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG



# Generated at 2022-06-24 03:02:23.991273
# Unit test for function configure
def test_configure():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')

    with logger_level(logger, logging.ERROR):
        logger.debug('test')

# Generated at 2022-06-24 03:02:30.729498
# Unit test for function get_config
def test_get_config():
    cfg1 = '{"version": 1, "disable_existing_loggers": False}'
    cfg2 = 'version: 1\ndisable_existing_loggers: False'
    assert get_config(cfg1) == {'version': 1, 'disable_existing_loggers': False}
    assert get_config(cfg2) == {'version': 1, 'disable_existing_loggers': False}

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:02:41.502738
# Unit test for function getLogger
def test_getLogger():
    root_logger = getLogger()
    assert root_logger == logging.getLogger()
    root_logger.info('Root logger message')

    # root logger ancestry
    assert root_logger.parent == None
    assert root_logger.root == root_logger
    assert root_logger.handlers == [logging.getLogger().handlers[0]]

    # child logger ancestry
    child_logger_name = 'test'
    child_logger = getLogger(child_logger_name)
    assert child_logger != root_logger
    assert child_logger.parent == root_logger
    assert child_logger.root == root_logger
    assert child_logger.handlers != []

    # log level
    assert child_logger.level == logging.DEBUG


# Generated at 2022-06-24 03:02:46.128468
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    assert logger.level == logging.NOTSET

    configure(default=DEFAULT_CONFIG)
    assert logger.level == logging.DEBUG


if __name__ == '__main__':
    import doctest

    results = doctest.testmod(optionflags=doctest.ELLIPSIS)
    print('%s' % (results,))
    if results.failed:
        sys.exit(1)

# Generated at 2022-06-24 03:02:54.771657
# Unit test for function get_config
def test_get_config():
    # Check for Exception when config is None
    with pytest.raises(ValueError):
        get_config()

    # Check for Exception when config cannot be parsed
    with pytest.raises(ValueError):
        get_config('not a string')

    # Check for Exception when config cannot be parsed as JSON
    with pytest.raises(ValueError):
        get_config('{not a json string}')

    # Check for Exception when config cannot be parsed as YAML
    with pytest.raises(ValueError):
        get_config('not: a yaml string')

    # Test passing in YAML
    cfg = get_config('loggers:\n  requests:\n    level: INFO')
    assert cfg['loggers']['requests']['level'] == logging.INFO

    # Test passing in a dict

# Generated at 2022-06-24 03:02:57.731656
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')
    log = getLogger('test2')
    log.info('test2')



# Generated at 2022-06-24 03:02:58.321760
# Unit test for function configure
def test_configure():
    pass

# Generated at 2022-06-24 03:03:08.013437
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    # Check that we can set the level to the same value
    with logger_level(logger, logger.level):
        pass
    # Check that we can change the level temporarily
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level != logging.DEBUG


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    logging.debug('debug')
    logging.info('info')
    logging.warning('warning')
    logging.error('error')
    logging.critical('critical')
    configure()
    logging.debug('debug')
    logging.info('info')
    logging.warning('warning')
    logging.error('error')
    logging.critical('critical')

# Generated at 2022-06-24 03:03:16.456762
# Unit test for function configure
def test_configure():
    """
    >>> import json
    >>> log = get_logger(__name__)
    >>> failures = 0
    >>> for val in [
    ...     None,
    ...     logging.basicConfig,
    ...     '{"foo": "bar"}',
    ...     json.dumps({'foo': 'bar'}),
    ... ]:
    ...     try:
    ...         configure(config=val)
    ...     except Exception as exc:
    ...         failures += 1
    ...         print(exc)
    >>> failures
    0

    """
    pass



# Generated at 2022-06-24 03:03:27.571228
# Unit test for function configure
def test_configure():
    import StringIO
    import io

    buf = StringIO.StringIO()

# Generated at 2022-06-24 03:03:34.556537
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

    if _PyInfo.PY3:
        assert (str, ) == _PyInfo.string_types
        assert str == _PyInfo.text_type
        assert bytes == _PyInfo.binary_type
    else:  # PY2
        assert (basestring, ) == _PyInfo.string_types
        assert unicode == _PyInfo.text_type
        assert str == _PyInfo.binary_type