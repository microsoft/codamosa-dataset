

# Generated at 2022-06-24 02:53:38.312296
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    test_obj = _PyInfo()
    assert test_obj.PY2 == (sys.version_info[0] == 2)
    assert test_obj.PY3 == (sys.version_info[0] == 3)

    # test for PY2
    if test_obj.PY2:
        assert test_obj.string_types == (basestring,)
        assert test_obj.text_type == unicode
        assert test_obj.binary_type == str
    # test for PY3
    elif test_obj.PY3:
        assert test_obj.string_types == (str,)
        assert test_obj.text_type == str
        assert test_obj.binary_type == bytes

    # test for abnormal case

# Generated at 2022-06-24 02:53:49.255738
# Unit test for function configure
def test_configure():
    import json
    import time

    logger = logging.getLogger('test_logger')
    configure()
    logger.info('Hello, config!')
    # Color formatter
    logger.info('Hello, config!')
    logger.debug('Hello, config!')
    logger.warning('Hello, config!')
    logger.error('Hello, config!')
    logger.critical('Hello, config!')

    # Simple formatter

# Generated at 2022-06-24 02:53:59.335337
# Unit test for function getLogger
def test_getLogger():
    #log = getLogger()
    log = get_logger()
    assert log.info('test')
    log = get_logger('test2')
    assert log.info('test2')
    #assert isinstance(log, logging.Logger)

    
    


# Generated at 2022-06-24 02:54:01.722010
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    >>> pyinfo = _PyInfo()
    >>> pyinfo.PY2
    >>> pyinfo.PY3
    >>> pyinfo.string_types
    >>> pyinfo.text_type
    >>> pyinfo.binary_type
    """
    pass


# Generated at 2022-06-24 02:54:03.327388
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test.getLogger')
    logger.debug('test_getLogger')



# Generated at 2022-06-24 02:54:05.911500
# Unit test for function configure
def test_configure():
    class TestLog:
        def __init__(self, name):
            self.name = name

    log = TestLog(__name__)
    assert log.name in repr(log)



# Generated at 2022-06-24 02:54:11.937181
# Unit test for function get_config
def test_get_config():
    a = get_config({"foo": "bar"})
    assert isinstance(a, dict)
    assert a == {"foo": "bar"}

    a = get_config(json.dumps({"foo": "bar"}))
    assert isinstance(a, dict)
    assert a == {"foo": "bar"}

    a = get_config(yaml.dump({"foo": "bar"}))
    assert isinstance(a, dict)
    assert a == {"foo": "bar"}


# Generated at 2022-06-24 02:54:13.821338
# Unit test for function configure
def test_configure():
    """
    >>> configure()
    >>> configure(DEFAULT_CONFIG)

    """



# Generated at 2022-06-24 02:54:16.823225
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not (_PyInfo.PY2 and _PyInfo.PY3)



# Generated at 2022-06-24 02:54:25.365892
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

    if _PyInfo.PY2:
        assert type('') in _PyInfo.string_types
        assert type(u'') not in _PyInfo.string_types
        assert type(b'') not in _PyInfo.string_types
        assert type(u'') in _PyInfo.string_types
        assert type(u'') is _PyInfo.text_type
        assert type(b'') is _PyInfo.binary_type
    else:
        assert _PyInfo.string_types == (str,)
        assert type('') in _PyInfo.string_types
        assert type(u'') not in _PyInfo

# Generated at 2022-06-24 02:54:36.662619
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False
    assert sys.version_info[0] == 2


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: ' '%(message)s @%(funcName)s:%(lineno)d #%(levelname)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    test__PyInfo()

    log = get_logger()
    log.debug('test')

# Generated at 2022-06-24 02:54:44.831447
# Unit test for function get_config
def test_get_config():
    test_config = dict(
        version=1,
        disable_existing_loggers=False,
        formatters={
            'simple': {
                'format': '[%(asctime)s] %(process)d %(thread)d %(name)s: %(message)s',
                'datefmt': '%H:%M:%S',
            }
        },
        handlers={
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
                'level': logging.DEBUG,
            },
        },
        root=dict(handlers=['console'], level=logging.DEBUG)
    )
    test_config_json = json.dumps(test_config)
    test_config_yaml = yaml.dump(test_config)


# Generated at 2022-06-24 02:54:46.854630
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    try:
        configure()
        log.info('test')
    except:
        print('Error: function configure failed')



# Generated at 2022-06-24 02:54:49.284491
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
    assert logger.level == logging.DEBUG

# Generated at 2022-06-24 02:54:56.475108
# Unit test for function configure
def test_configure():
    import colorlog

    # Testing if logger is working with default logging configuration
    # Default configuration is found in DEFAULT_CONFIG dictionary
    configure()
    logger = logging.getLogger(__name__)
    assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.hasHandlers()
    handler = logger.handlers[0]
    assert isinstance(handler, logging.StreamHandler)
    formatter = handler.formatter
    assert isinstance(formatter, colorlog.ColoredFormatter)

    # Testing if logger is working simply with a default config file

# Generated at 2022-06-24 02:54:58.039749
# Unit test for function get_config
def test_get_config():
    from pprint import pprint
    pprint(dict(LOGGING='{"version" : 1}'))



# Generated at 2022-06-24 02:55:05.131812
# Unit test for function configure
def test_configure():
    import os

    # Export LOGGING Environ Variable
    line = "'version': 1"
    os.environ["LOGGING"] = "{ %s }" % line

    configure()

    # Test if configuration was loaded
    assert get_logger().hasHandlers()
    assert logging.getLogger().hasHandlers()

    # Test if configuration was loaded
    line = "'version': %d" % (DEFAULT_CONFIG['version'] + 1)
    os.environ["LOGGING"] = "{ %s }" % line

    try:
        configure()
    except TypeError as error:
        assert "Invalid format 'version'" in str(error)
    else:
        assert False


# Generated at 2022-06-24 02:55:09.632966
# Unit test for function getLogger
def test_getLogger():
    """Unittest for function getLogger

    :rtype: bool
    :return: whether or not the test is passed
    """
    logger = getLogger()
    if logger is not None and logger.name == 'testlog.getLogger':
        return True
    else:
        return False

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:55:10.726144
# Unit test for function configure
def test_configure():
    configure()
    configure(config=DEFAULT_CONFIG)



# Generated at 2022-06-24 02:55:20.474258
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, {}) == {}
    assert get_config(None, None, []) == []
    assert get_config({'foo': 'bar'}, None, None) == {'foo': 'bar'}
    assert get_config([{'foo': 'bar'}], None, None) == [{'foo': 'bar'}]
    assert get_config('{"foo":"bar"}', None, None) == {'foo': 'bar'}
    assert get_config('[{"foo":"bar"}]', None, None) == [{'foo': 'bar'}]
    assert get_config('foo: bar', None, None) == {'foo': 'bar'}
    assert get_config('- foo: bar', None, None) == [{'foo': 'bar'}]
    assert get_

# Generated at 2022-06-24 02:55:28.736706
# Unit test for function get_config
def test_get_config():
    """
    Test of config parsing.
    """

    # Return None if None given
    assert get_config(None) is None


    # Test that valid JSON parses
    json_valid = json.dumps({'foo': 'bar'})
    assert get_config(json_valid) == {'foo': 'bar'}

    # Test that valid YAML parses
    yaml_valid = """
        foo: bar
    """
    assert get_config(yaml_valid) == {'foo': 'bar'}

    # Test that invalid JSON/YAML throws
    json_invalid = '''
        foo": "bar"
    '''
    yaml_invalid = '''
        foo: "bar
    '''


# Generated at 2022-06-24 02:55:35.885675
# Unit test for function logger_level
def test_logger_level():
    # Configure the logger to log everything
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s| %(name)s/%(process)d-%(thread)d: %(message)s',
    )
    # Create the logger
    logger = logging.getLogger('test_logger_level')
    # Log a trace (should be logged)
    logger.trace('TRACE')
    # Log a debug (should be logged)
    logger.debug('DEBUG')
    # Log an info (should be logged)
    logger.info('INFO')
    # Log a warning (should be logged)
    logger.warning('WARNING')
    # Log an error (should be logged)
    logger.error('ERROR')
    # Log a critical (should be logged)
    logger.critical

# Generated at 2022-06-24 02:55:46.545305
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager

    import logging

    # set logger
    logger = logging.getLogger()
    logging.basicConfig(level=logging.INFO)

    # test not working level logging
    with logger_level(logger, logging.WARNING):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")

    # test working level logging
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:55:54.131298
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('hello')
    log.debug('debug message')

    log2 = getLogger('test2')
    log2.info('hello')
    log2.debug('debug message')

#------------------------------------------------------------------------------#
# The above is a copy of the logger.py library from the gunicorn project,
# https://github.com/benoitc/gunicorn
#------------------------------------------------------------------------------#

size_fmt = lambda number, suffix='B': '{0:.1f}{1}'.format(number, suffix)
size_fmt_long = lambda number, suffix='B': '{0:.0f}{1}'.format(number, suffix)


#------------------------------------------------------------------------------#
# API functions
#   These are used by clients of this module.
#------------------------------------------------------------------------------#


# Generated at 2022-06-24 02:55:57.386480
# Unit test for function getLogger
def test_getLogger():
    try:
        import __main__
        __main__.__package__ = "test_getLogger"
    except:
        pass
    result = get_logger()
    assert isinstance(result, logging.Logger)

# Generated at 2022-06-24 02:56:01.051500
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger("test_getLogger")
    logger.info("test")
    logger = getLogger("test_getLogger_new")
    logger.info("test")


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 02:56:06.074347
# Unit test for function configure
def test_configure():
    """
    Unit test for function configure

    >>> configure({'version': 1})
    >>> log = logging.getLogger(__name__)
    >>> log.info('test')
    """
    pass



# Generated at 2022-06-24 02:56:12.018259
# Unit test for function logger_level
def test_logger_level():
    configure()
    log = logging.getLogger(__name__)
    log.error('Should not be printed')
    with logger_level(log, logging.DEBUG):
        log.error('Should be printed')
    log.error('Should not be printed')


if __name__ == '__main__':
    configure()
    logger = logging.getLogger(__name__)
    logger.error('test error')
    logger.info('test info')
    logger.debug('test debug')

    # test_logger_level()
    get_logger().info('test')

# Generated at 2022-06-24 02:56:12.501783
# Unit test for function configure
def test_configure():
    assert True

# Generated at 2022-06-24 02:56:14.559161
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info("Testing configure")

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:56:24.230872
# Unit test for function configure
def test_configure():
    logger = get_logger(__name__)
    # we need to override our default configuration for this test

# Generated at 2022-06-24 02:56:25.614797
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info("logger")


# Generated at 2022-06-24 02:56:36.412450
# Unit test for function configure
def test_configure():
    # test empty config
    configure()
    log = logging.getLogger('test_configure')
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')

    logging.shutdown()

    # test config from yaml

# Generated at 2022-06-24 02:56:41.295081
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.ERROR):
        log.debug('debug message')
        log.info('info message')
        log.warning('warning message')
        log.error('error message')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:56:43.565216
# Unit test for function logger_level
def test_logger_level():
    """
    >>> log = get_logger()
    >>> logger_level(log, logging.DEBUG)
    >>> logger_level(log, logging.INFO)
    """
    pass

# Generated at 2022-06-24 02:56:55.262396
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("test_logger_level")
    configure()
    logger.debug("should not print")
    assert logger.getEffectiveLevel() >= logging.DEBUG
    assert logger.parent.getEffectiveLevel() >= logging.DEBUG
    # Set logger level to INFO
    with logger_level(logger, logging.INFO):
        # Logging level of the logger is INFO now
        assert logger.getEffectiveLevel() == logging.INFO
        assert logger.parent.getEffectiveLevel() >= logging.DEBUG
        logger.debug("should not print")
        logger.info("should print")
        # Set logger level to DEBUG
        with logger_level(logger, logging.DEBUG):
            assert logger.getEffectiveLevel() == logging.DEBUG
            assert logger.parent.getEffectiveLevel() >= logging.DEBUG
            logger.debug("should print")


# Generated at 2022-06-24 02:57:02.292184
# Unit test for function configure
def test_configure():
    log_stream = io.StringIO()
    handler = logging.StreamHandler(log_stream)
    handler.setLevel(logging.DEBUG)
    fmt = logging.Formatter('%(asctime)s %(name)s %(levelname)s: %(message)s')
    handler.setFormatter(fmt)
    logger = logging.getLogger('test_name')
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    configure()
    logger.info('test')
    log_stream.seek(0)
    assert 'test test_name: test' in log_stream.read()


# Generated at 2022-06-24 02:57:07.575730
# Unit test for function configure
def test_configure():
    configure(default=DEFAULT_CONFIG)

    logger = logging.getLogger(__name__ + '.test_configure')
    assert logger.getEffectiveLevel() == logging.DEBUG
    logger.debug('test_configure')
    logger.info('test_configure')
    logger.warning('test_configure')
    logger.error('test_configure')
    logger.critical('test_configure')



# Generated at 2022-06-24 02:57:16.352804
# Unit test for function configure
def test_configure():
    logger = logging.getLogger('test')

    # Base case
    configure()
    assert logger.isEnabledFor(logging.DEBUG)

    # Env var override
    os.environ['LOGGING'] = json.dumps(
        dict(loggers={'test': dict(level=logging.INFO)})
    )
    configure()
    assert logger.isEnabledFor(logging.INFO)

    # Explicitly-given dict override
    configure(
        dict(loggers={'test': dict(level=logging.WARN)}),
        env_var=None,
        default=None,
    )
    assert logger.isEnabledFor(logging.WARN)

    # Explicitly-given string override

# Generated at 2022-06-24 02:57:17.068075
# Unit test for function configure
def test_configure():
    configure()


if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-24 02:57:27.003395
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('LoggerLevelTest')

    # Create a custom root logger
    rootlogger = logging.getLogger()
    rootlogger.setLevel(logging.NOTSET)
    rootlogger.addHandler(logging.NullHandler())

    # Redirect the root logger to stderr
    import sys
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(logging.Formatter('%(name)s - %(levelname)s - %(message)s'))
    rootlogger.addHandler(ch)

    # Test the logger_level context manager
    with logger_level(log, logging.WARNING):
        log.debug('debug')
        log.info('info')
        log.warning('warning')



# Generated at 2022-06-24 02:57:37.515281
# Unit test for function get_config
def test_get_config():
    import yaml
    import json
    from textwrap import dedent

    yaml_config = "\n".join(
        [
            'version: 1',
            'formatters:',
            '  simple:',
            '    format: "%(name)s: %(message)s"',
            'handlers:',
            '  console:',
            '    level: DEBUG',
            '    class: logging.StreamHandler',
            '    formatter: simple',
            'root:',
            '  level: INFO',
            '  handlers: [console]',
        ]
    )

# Generated at 2022-06-24 02:57:46.964734
# Unit test for function logger_level
def test_logger_level():
    import io
    import unittest

    log = getLogger(__name__)

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            self.sio = io.StringIO()
            self.stream = logging.StreamHandler(self.sio)
            log.addHandler(self.stream)
            log.setLevel(logging.DEBUG)
            log.debug("DEBUG MESSAGE")
            self.stream.flush()

        def tearDown(self):
            self.sio.close()
            self.stream.close()
            log.removeHandler(self.stream)

        def test_logger_level(self):
            with logger_level(log, logging.INFO):
                log.info('INFO MESSAGE')

# Generated at 2022-06-24 02:57:51.940607
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    assert isinstance(log, logging.Logger)


# Generated at 2022-06-24 02:57:54.712172
# Unit test for function configure
def test_configure():
    """
    >>> log = logging.getLogger(__name__)
    >>> configure()
    >>> log.info('test')
    """
    pass



# Generated at 2022-06-24 02:58:04.065388
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert set(config.keys()) == {'formatters', 'handlers', 'loggers', 'root'}
    
    config_string = json.dumps(DEFAULT_CONFIG)
    config = get_config(config=config_string)
    assert set(config.keys()) == {'formatters', 'handlers', 'loggers', 'root'}
    
    config_string = yaml.dump(DEFAULT_CONFIG)
    config = get_config(config=config_string)
    assert set(config.keys()) == {'formatters', 'handlers', 'loggers', 'root'}
    
    with pytest.raises(ValueError):
        config = get_config(config='asd')

# Generated at 2022-06-24 02:58:05.084478
# Unit test for function configure
def test_configure():
    logger = getLogger("test_configure")
    logger.info("Test")


# Generated at 2022-06-24 02:58:08.082045
# Unit test for function getLogger
def test_getLogger():
    # We have to assume that configure does what we think it does
    configure()

    logger = get_logger()
    assert logger.name == __name__

    logger = get_logger("testname")
    assert logger.name == "testname"


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)

    test_getLogger()

# Generated at 2022-06-24 02:58:11.361927
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger()
    log.info('test')



# Generated at 2022-06-24 02:58:14.522603
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
    assert logger.level == logging.DEBUG

# Generated at 2022-06-24 02:58:25.523833
# Unit test for function configure

# Generated at 2022-06-24 02:58:34.538348
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug("Debug!")

    with logger_level(logger, logging.INFO):
        logger.info("Info!")
        logger.debug("Should be hidden.")

    with logger_level(logger, logging.WARNING):
        logger.info("Should be hidden.")


if __name__ == "__main__":
    from zope.testrunner.runner import Runner

    runner = Runner(found_suites=[__name__])
    runner.run()

# Generated at 2022-06-24 02:58:40.523698
# Unit test for function getLogger
def test_getLogger():
    import sys
    import logging
    import unittest
    import tempfile

    if sys.version_info[0] == 2:
        import StringIO as io
    else:
        import io

    class TestLogger(unittest.TestCase):

        def setUp(self):
            self.buf = io.StringIO()
            self.fh = logging.StreamHandler(self.buf)
            self.fh.setFormatter(logging.Formatter('[%(asctime)s][%(name)s/%(process)d][%(levelname)s] %(message)s'))

        def test_default(self):
            logger = get_logger()
            logger.addHandler(self.fh)

            logger.debug('test1')

# Generated at 2022-06-24 02:58:49.692923
# Unit test for function logger_level
def test_logger_level():  # test_logger_level()
    log = get_logger(__name__)

    with logger_level(log, logging.ERROR):
        log.debug('should not print from %s', __name__)
        log.error('error from %s', __name__)

    log.debug('Debug from %s', __name__)

    with logger_level(log, logging.DEBUG):
        log.debug('Debug from %s', __name__)
        log.error('warning from %s', __name__)

    try:
        with logger_level(log, logging.DEBUG):
            log.debug('Debug from %s', __name__)
            raise ValueError('logger_level error test')
    except ValueError as exc:
        log.error('Error from %s: %s', __name__, exc)




# Generated at 2022-06-24 02:58:52.871709
# Unit test for constructor of class _PyInfo
def test__PyInfo():

    import sys
    test_py2 = sys.version_info[0] == 2
    test_py3 = sys.version_info[0] == 3
    assert _PyInfo.PY2 == test_py2
    assert _PyInfo.PY3 == test_py3
    return


# Generated at 2022-06-24 02:58:57.635035
# Unit test for function getLogger
def test_getLogger():
  logger = getLogger('test_getLogger')
  logger.debug("A debugging message")

  # Unit test for function logger_level
  with logger_level(logger, logging.DEBUG):
    logger.debug("A debugging message")
  logger.debug("A debugging message")

# Generated at 2022-06-24 02:59:02.501011
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('Logger test')
    logger.debug('Logger test')
    logger.warning('Logger test')
    # logger.error('Logger test')
    # logger.critical('Logger test')
    logger_test = getLogger('test2')
    logger_test.info('Logger test')
    logger_test.debug('Logger test')
    logger_test.warning('Logger test')
    # logger_test.error('Logger test')
    # logger_test.critical('Logger test')

if __name__ == '__main__':
    configure()
    test_getLogger()

# Generated at 2022-06-24 02:59:12.792283
# Unit test for function get_config
def test_get_config():
    from nose.tools import eq_
    from nose.tools import assert_raises

    # test_get_config_default
    config = get_config()
    eq_(config['version'], 1)

    # test_get_config_env
    os.environ['LOGGING'] = '{"version": 2}'
    config = get_config(env_var='LOGGING')
    eq_(config['version'], 2)

    # test_get_config_json
    config = get_config('{"version": 3}')
    eq_(config['version'], 3)

    # test_get_config_yaml
    config = get_config('version: 3')
    eq_(config['version'], 3)

    # test_get_config_errors

# Generated at 2022-06-24 02:59:22.586625
# Unit test for function get_config
def test_get_config():
    import tempfile
    import yaml
    import json

    with tempfile.NamedTemporaryFile(mode='w+t') as f:
        test_dict = dict(
            version=1,
            formatters=dict(
                test='works'
            ),
            loggers=dict(
                test='works'
            )
        )
        json.dump(test_dict, f)
        f.seek(0)
        assert get_config(f.name) == test_dict

    with tempfile.NamedTemporaryFile(mode='w+t') as f:
        test_dict = dict(
            version=1,
            formatters=dict(
                test='works'
            ),
            loggers=dict(
                test='works'
            )
        )

# Generated at 2022-06-24 02:59:30.934797
# Unit test for function logger_level
def test_logger_level():
    from string import printable
    from random import randint, choice
    from unittest import TestCase
    from contextlib import contextmanager

    class TestLogger(logging.Logger):
        @contextmanager
        def record_messages(self):
            self.messages = []
            yield self.messages
            del self.messages

    def random_string():
        '''
        Random string of ASCII codes.
        '''
        return ''.join(choice(printable) for i in range(randint(1, 10)))

    original_logger_class = logging.getLoggerClass()
    logging.setLoggerClass(TestLogger)

    logger = logging.getLogger('test_logger')

    random_logger_name = random_string()
    logger.name = random_logger_name



# Generated at 2022-06-24 02:59:34.716292
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.debug('This should not be logged')
        logger.error('This should be logged')

    logger.debug('This should be logged')
    logger.error('This should be logged')



# Generated at 2022-06-24 02:59:41.246783
# Unit test for function logger_level
def test_logger_level():
    import sys
    logger = getLogger()
    initial = logger.level
    try:
        with logger_level(logger, logging.CRITICAL):
            logger.info('This should not appear in the log')
        logger.info('This should appear in the log')
    finally:
        sys.stdout.flush()
        logger.level = initial

if __name__ == '__main__':
    configure()

    test_logger_level()

# Generated at 2022-06-24 02:59:51.352287
# Unit test for function get_config
def test_get_config():
    config = '''
version: 1
disable_existing_loggers: False
formatters:
    simple:
        format: '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s'
        datefmt: '%Y-%m-%d %H:%M:%S'
handlers:
    console:
        class : logging.StreamHandler
        formatter: simple
        level: DEBUG
root:
    handlers: [console]
    level: DEBUG
loggers:
    requests:
        level: INFO
'''

# Generated at 2022-06-24 02:59:55.354920
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('Should be logged')
        logger.info('Should NOT be logged')

    logger.info('Should be logged again')


if __name__ == '__main__':
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-24 02:59:58.811669
# Unit test for function configure
def test_configure():
    #print os.getcwd()
    #print os.path.dirname(os.path.abspath(__file__))
    configure(config='config.json')
    log = get_logger()
    log.info('test')


if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-24 03:00:05.528953
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger_level_test = logging.getLogger("logger_level_test")
    logger_level_test.setLevel(logging.INFO)
    with logger_level(logger_level_test, logging.DEBUG):
        assert(logger_level_test.isEnabledFor(logging.DEBUG) == True)
    assert(logger_level_test.isEnabledFor(logging.DEBUG) == False)



# Generated at 2022-06-24 03:00:08.125119
# Unit test for function logger_level
def test_logger_level():
    logger, level = get_logger(), logging.INFO
    try:
        with logger_level(logger, level):
            assert logger.level == level
    finally:
        logger.level == initial

# Generated at 2022-06-24 03:00:16.235859
# Unit test for function get_config
def test_get_config():
    assert get_config(config='123', default='abc') == '123'
    assert get_config(env_var='T', default='abc') == 'abc'
    assert get_config({'version': 1}, env_var='T', default='abc') == {'version': 1}





# Generated at 2022-06-24 03:00:23.489186
# Unit test for function get_config
def test_get_config():
    from instana.util import DotDict

    config = get_config()
    assert isinstance(config, dict)

    default = dict(config=dict(a=1, b=2))

    config = get_config(config=DotDict(dict(key="val")))
    assert isinstance(config, dict)
    # TODO: Make this work, it's pretty gross right now
    # assert config["key"] == "val"
    # assert default["config"]["a"] == 1
    # assert default["config"]["b"] == 2

    default = dict(key="val")
    config = get_config(default=default)
    # TODO: Make this work, it's pretty gross right now
    # assert config["key"] == "val"


# Generated at 2022-06-24 03:00:25.922880
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')
    log.debug('test')

# Generated at 2022-06-24 03:00:30.345080
# Unit test for function getLogger
def test_getLogger():
    print('Testing function: getLogger')
    log = getLogger()
    log.setLevel(logging.INFO)
    log.info('test')


# Generated at 2022-06-24 03:00:38.546491
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info("Test logger")
    assert logger.name is not None

    # Test logger.name output
    def get_logger_name(logger):
        if logger.name == '__main__':
            return "getLogger()"
        else:
            return logger.name

    assert get_logger_name(logger) == "getLogger()"
    assert get_logger_name(getLogger()) == "getLogger()"
    assert get_logger_name(getLogger("test")) == "test"


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:00:47.787485
# Unit test for function get_config
def test_get_config():
    # Test with default configuration
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    assert config['loggers']['requests']['level'] == logging.INFO

    # Test with json configuration
    json_config = '{"loggers": {"requests": {"level": "WARN" }}}'
    config = get_config(default=DEFAULT_CONFIG, config=json_config)
    assert config['loggers']['requests']['level'] == logging.WARN

    # Test with yaml configuration
    yaml_config = """
---
loggers:
  requests:
    level: WARN
"""
    config = get

# Generated at 2022-06-24 03:00:54.959752
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(""), logging.INFO):
        with logger_level(get_logger(""), logging.DEBUG):
            log = get_logger()
            log.debug("debug")
            log.info("info")
        with logger_level(get_logger(""), logging.ERROR):
            log = get_logger()
            log.critical("critical")
            log.info("info")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 03:00:57.174148
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3

# Generated at 2022-06-24 03:01:04.714610
# Unit test for function get_config
def test_get_config():
    try:
        get_config()
    except ValueError as e:
        assert str(e) == 'Invalid logging config: None'

    try:
        get_config("{foo: bar}")
    except ValueError as e:
        assert str(e) == "Could not parse logging config as bare, json, or yaml: {foo: bar}"

    assert get_config("foo: bar") == {'foo': 'bar'}
    assert get_config("""{
        "foo": "bar"
    }""") == {'foo': 'bar'}

# Generated at 2022-06-24 03:01:11.944053
# Unit test for function get_config
def test_get_config():
    import json
    import yaml


# Generated at 2022-06-24 03:01:15.201285
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    p = _PyInfo()
    assert p.PY2 or p.PY3


# Generated at 2022-06-24 03:01:17.527089
# Unit test for function configure
def test_configure():
    """
    >>> log = logging.getLogger('test_configure')
    >>> configure()
    >>> log.info('test')
    """



# Generated at 2022-06-24 03:01:25.729266
# Unit test for function logger_level
def test_logger_level():
    import sys
    from logging import StreamHandler, DEBUG, INFO
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output(stream_name):
        """Capture stdout/stderr in a context block"""
        orig_stdout = getattr(sys, stream_name)
        captured_out = StringIO()
        setattr(sys, stream_name, captured_out)
        try:
            yield captured_out
        finally:
            setattr(sys, stream_name, orig_stdout)


# Generated at 2022-06-24 03:01:32.581185
# Unit test for function logger_level
def test_logger_level():
    logger = log = getLogger()
    for level in [logging.INFO, logging.DEBUG, logging.CRITICAL]:
        with logger_level(logger, level):
            log.info('test1')
            log.debug('test2')
            log.critical('test3')

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 03:01:39.507446
# Unit test for function configure
def test_configure():
    import io

    # Test configuration set by function
    sio = io.StringIO()

# Generated at 2022-06-24 03:01:50.258120
# Unit test for function configure
def test_configure():
    """
    >>> test_configure()
    [{'name': 'test'}, {'name': 'test1'}, {'name': 'test2'}, {'name': 'test3'}]
    """
    logging.shutdown()
    logging.Logger.manager.loggerDict.clear()

# Generated at 2022-06-24 03:01:53.210065
# Unit test for function getLogger
def test_getLogger():
    """
    >>> log = get_logger()
    >>> log.info('test')
    """


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:02:01.819166
# Unit test for function get_config
def test_get_config():
    # JSON
    import json
    json_config_str = json.dumps(DEFAULT_CONFIG)
    assert get_config(config=json_config_str) == json.loads(json_config_str)

    # YAML
    import yaml
    yaml_config_str = yaml.dump(DEFAULT_CONFIG, default_flow_style=False)
    assert get_config(config=yaml_config_str) == yaml.load(yaml_config_str)

    # BARE ENCODED
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG

    # ENVVAR
    assert get_config(env_var='TEST_LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG

    # DEFAULT
    assert get_

# Generated at 2022-06-24 03:02:10.337323
# Unit test for function logger_level
def test_logger_level():
    """Tests whether logger_level() works as expected.
    Currently, there is no other way than to look at the generated output."""
    import tempfile
    fd, fname = tempfile.mkstemp('.log', 'log-test-')
    rootlog = logging.getLogger()
    handler = logging.StreamHandler(os.fdopen(fd))
    handler.setLevel(logging.DEBUG)
    rootlog.addHandler(handler)
    log = logging.getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug("This should be visible.")
    log.debug("But this should not be visible.")
    handler.flush()
    rootlog.removeHandler(handler)
    f = open(fname)
    content = f.read()
    f.close()

# Generated at 2022-06-24 03:02:20.946685
# Unit test for function get_config

# Generated at 2022-06-24 03:02:25.944033
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)
        assert not logger.isEnabledFor(logging.INFO)
    assert not logger.isEnabledFor(logging.DEBUG)
    assert logger.isEnabledFor(logging.INFO)



# Generated at 2022-06-24 03:02:28.334558
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('this is a test')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:02:34.715217
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3

    if _PyInfo.PY2:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    else: # PY3
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes



# Generated at 2022-06-24 03:02:39.365202
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('logger is logging.DEBUG')
    logger.info('logger is back to root logger level')

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 03:02:43.699429
# Unit test for function getLogger
def test_getLogger():
    # retrieve the __main__ logger
    log = getLogger()
    log.debug('test')
    log.info('test')

    assert log.level < logging.INFO

    with logger_level(log, logging.DEBUG):
        log.debug('test')
        log.info('test')

    assert log.level < logging.INFO

# Generated at 2022-06-24 03:02:54.629169
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    result = get_config(config="{'version': 1}", default=None)
    assert isinstance(result, dict)

    result = get_config(config=json.dumps(DEFAULT_CONFIG), default=None)
    assert isinstance(result, dict)

    result = get_config(config=yaml.dump(DEFAULT_CONFIG), default=None)
    assert isinstance(result, dict)

    result = get_config(config=None, env_var='LOGGING', default=None)
    assert isinstance(result, dict)

    result = get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    assert isinstance(result, dict)


# Generated at 2022-06-24 03:02:58.318619
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.WARN):
        log = get_logger()
        log.info("info")
        log.debug("debug")
    log.info("info")
    log.debug("debug")

# Generated at 2022-06-24 03:03:07.156115
# Unit test for function getLogger
def test_getLogger():
    """Test function get_logger(name=None)

    :return: success flag
    :rtype: bool
    """

    # Testing function with no name
    try:
        test_logger = getLogger()
        test_logger.info('The message info')
    except Exception as err:
        print(('Error testing getLogger() - ' + str(err)))
        return False

    # Testing function with given name

# Generated at 2022-06-24 03:03:17.238053
# Unit test for function get_config

# Generated at 2022-06-24 03:03:25.961380
# Unit test for function configure
def test_configure():
    log = logging.getLogger('test_log')
    configure(config={'formatters': {'simple': {'format': '[%(name)s][%(levelname)s] %(message)s'}}})
    log.warning('warn')
    log.info('info')
    log.debug('debug')
    log.error('error')
    log.critical('critical')
    try:
        i = 1/0
    except Exception:
        log.exception('exception')

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 03:03:28.718627
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    with logger_level(log, logging.WARN):
        log.warning('foo')
        log.info('bar')
        log.debug('baz')