

# Generated at 2022-06-24 02:53:31.522417
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert isinstance('abc', _PyInfo.string_types)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    print('OK')

# Generated at 2022-06-24 02:53:36.000583
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == False
    assert _PyInfo.PY3 == True
    assert _PyInfo.string_types == (str,)
    assert _PyInfo.text_type == str
    assert _PyInfo.binary_type == bytes



# Generated at 2022-06-24 02:53:43.329036
# Unit test for function get_config
def test_get_config():
    # No config is given.
    config = None
    assert {} == get_config(config)

    # Given a config dict

# Generated at 2022-06-24 02:53:55.337606
# Unit test for function configure
def test_configure():
    import os
    import json

    logger = logging.getLogger(__name__)

    logger.info('test')

    os.environ['LOGGING'] = json.dumps(dict(version=1, formatters={'simple': {'format': '%(message)s', 'datefmt': '%Y-%m-%d %H:%M:%S'}}, handlers={'console': {'class': 'logging.StreamHandler', 'formatter': 'simple', 'level': 'DEBUG'}}, root={'handlers': ['console'], 'level': 'DEBUG'}))
    configure()
    logger.info('test')
    del os.environ['LOGGING']


# Generated at 2022-06-24 02:53:58.714436
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3

# Generated at 2022-06-24 02:54:05.621593
# Unit test for function getLogger
def test_getLogger():
    """Test for the function getLogger"""
    print("Called test_getLogger")
    # Get the logger object
    logger = get_logger("test")
    # Print the name of the logger
    print("Logger Name: %s", logger.name)
    # Print the level of the logger
    print("Logger Level: %s", logger.level)

    # print the error and warning message
    logger.error("This is error message")
    logger.warning("This is warning message")



# Generated at 2022-06-24 02:54:11.934392
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

    log = getLogger('test2')
    log.info('test2')

    # in python 3.5+ use : logging.getLogger("test").getChild('test2')
    log = logging.getLogger("test").getChild('test2')
    log.info('test2')

    log = getLogger()
    with logger_level(log, logging.INFO):
        log.info('test')
        log.debug('test')


test_getLogger()

# Generated at 2022-06-24 02:54:22.294946
# Unit test for function configure
def test_configure():
    # Test that when given JSON string, configure can load from it
    configure(config='{"version": 1}')
    # Test that when given YAML string, configure can load from it
    configure(config='version: 1')
    # Test that when given a dictionary, configure can load from it
    configure(config={'version': 1})
    # Test that when given a file, configure can load from it
    cfg_file_dict = {}
    cfg_file_dict['version'] = 1
    import os
    import tempfile
    fd, cfg_file_path = tempfile.mkstemp()
    fp = os.fdopen(fd, 'w')
    import json
    fp.write(json.dumps(cfg_file_dict))
    fp.close()

# Generated at 2022-06-24 02:54:26.298150
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), 0):
        pass

# TODO: Mock a logger and make sure it's set to the given level within the scope of the context manager
# TODO: Check to see if the level is reset on exception
# See http://pymotw.com/2/unittest/index.html#module-unittest

# Generated at 2022-06-24 02:54:32.528016
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.info('logging.DEBUG')
        logger.debug('logging.DEBUG')
    with logger_level(logger, logging.INFO):
        logger.info('logging.INFO')
        logger.debug('logging.INFO')



# Generated at 2022-06-24 02:54:37.278738
# Unit test for function configure
def test_configure():
    configure()
    logger = logging.getLogger(__name__ + '.test_configure')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')
    logger.setLevel(logging.DEBUG)
    logger.debug('debug')



# Generated at 2022-06-24 02:54:38.195587
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger(__name__)
    logger.info('test')

# Generated at 2022-06-24 02:54:45.490871
# Unit test for function get_config
def test_get_config():
    cfg = {'test': 1, 'test1': 2}
    # parse from string
    assert get_config(str(cfg)) == cfg

    # parse from str with json
    json_str = '{"test": 1, "test1": 2}'
    assert get_config(json_str) == cfg

    # parse from str with yaml
    yaml_str = 'test: 1\ntest1: 2'
    assert get_config(yaml_str) == cfg

# Generated at 2022-06-24 02:54:46.268245
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    a = _PyInfo()

# Generated at 2022-06-24 02:54:51.611875
# Unit test for function getLogger
def test_getLogger():
    """
    Test function getLogger
    """

    log = getLogger()
    assert isinstance(log, logging.Logger), 'getLogger() instance should be logging.Logger'

    name = _namespace_from_calling_context()+'.test_getLogger'
    log = getLogger(name=name)
    assert log.name==name, 'getLogger() instance should be %s' % name



# Generated at 2022-06-24 02:54:57.225863
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"root": {"level": "INFO"}}')
    assert config['root']['level'] == 'INFO'

    config = get_config(config={"root": {"level": "INFO"}})
    assert config['root']['level'] == 'INFO'

# Generated at 2022-06-24 02:54:58.798592
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test_getLogger')


# Generated at 2022-06-24 02:55:04.212098
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG
    assert get_config(default={}) == {}
    assert get_config(default={}, config={}) == {}
    assert get_config(default="{}") == {}
    assert get_config(default='{"foo": "bar"}') == {
        "foo": "bar"
    }
    assert get_config(default='{"foo": "bar"}', config='{"foo": "baz"}') == {
        "foo": "baz"
    }


# Generated at 2022-06-24 02:55:06.114319
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    logger.info('testing get_logger')
    assert isinstance(logger, logging.Logger)

# Generated at 2022-06-24 02:55:15.574652
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    if _PyInfo.PY3:
        assert isinstance('foo', _PyInfo.string_types)
        assert isinstance(b'foo', _PyInfo.binary_type)
        assert not isinstance(b'foo', _PyInfo.text_type)
        assert not isinstance('foo', _PyInfo.binary_type)
        assert isinstance('foo', _PyInfo.text_type)
    else:  # PY2
        assert isinstance('foo', _PyInfo.string_types)
        assert isinstance(b'foo', _PyInfo.binary_type)

# Generated at 2022-06-24 02:55:22.471133
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.WARNING):
        for l in (logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR, logging.CRITICAL):
            log.log(l, 'test')

    # Clean up the log
    logging.shutdown()

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 02:55:27.921786
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-24 02:55:30.305630
# Unit test for function getLogger
def test_getLogger():
    # test_log = getLogger('test')
    # print(test_log)
    print(getLogger())

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 02:55:33.195767
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    try:
        with logger_level(log, logging.ERROR):
            log.info('test')
            assert False, "Did not reach this point because of error level."
    except AssertionError:
        pass



# Generated at 2022-06-24 02:55:36.448866
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log.info('test')
    #assert len(calls) > 0

# Generated at 2022-06-24 02:55:38.581996
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance(_PyInfo.PY2, bool)
    assert isinstance(_PyInfo.PY3, bool)
    assert isinstance(_PyInfo.string_types, tuple)
    assert isinstance(_PyInfo.text_type, text_type)
    assert isinstance(_PyInfo.binary_type, binary_type)


# Generated at 2022-06-24 02:55:41.335378
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger(__name__)

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    assert logger.level == logging.WARNING

# Generated at 2022-06-24 02:55:50.216916
# Unit test for function configure
def test_configure():
    import logging
    import logging.handlers
    import tempfile

    _, test_config_file = tempfile.mkstemp(suffix="cfg")

    def check_config_file(cfg):
        with open(test_config_file, "w") as fp:
            fp.write(cfg)

        configure(config=test_config_file)
        log = logging.getLogger(__name__)
        log.debug("Test logging to file")
        assert len(log.handlers) == 1
        handler = log.handlers[0]
        assert isinstance(handler, logging.handlers.RotatingFileHandler)


# Generated at 2022-06-24 02:55:54.768347
# Unit test for function get_config
def test_get_config():
    assert get_config(None) == logging.getLogger().getEffectiveLevel()  # because
    assert get_config(None, 'LOGGING', {'version': 1}) == logging.getLogger().getEffectiveLevel()  # because



# Generated at 2022-06-24 02:55:59.316803
# Unit test for function get_config
def test_get_config():
    bare_str = 'this is a string'
    json_str = '{"key1":"value1", "key2":"value2"}'
    yaml_str = '''
key1: value1
key2: value2
'''
    assert get_config(bare_str) == {'key1': 'value1', 'key2': 'value2'}
    assert get_config(json_str) == {'key1': 'value1', 'key2': 'value2'}
    assert get_config(yaml_str) == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-24 02:56:06.526442
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()

    assert logger.level == logging.DEBUG

    logger.info("before change level")

    logger.debug("this should not get printed")
    with logger_level(logger, logging.ERROR):
        logger.info("this should get printed")
        logger.debug("this should not get printed")

    logger.debug("this should not get printed")
    logger.info("after change level")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:56:14.559977
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)

    # Test logging messages with different levels
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.WARNING):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
        # Make sure `with` context works if no exception is raised during the
        # context
        assert logger.level == logging.DEBUG

    # Test exception is still raised properly
    try:
        with logger_level(logger, logging.WARNING):
            raise ValueError('test exception')
    except ValueError:
        # Make sure `with` context works if an exception is raised during the
        # context
        assert logger.level == logging.DEBUG

# Generated at 2022-06-24 02:56:24.828642
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert(sys.version_info[0] == 2 and _PyInfo.PY2) or (_PyInfo.PY3)
    assert(_PyInfo.PY2 and isinstance(1, _PyInfo.string_types) and isinstance("a", _PyInfo.string_types)) or \
        (_PyInfo.PY3 and isinstance("a", _PyInfo.string_types) and not isinstance(1, _PyInfo.string_types))
    assert(_PyInfo.PY2 and isinstance("a", _PyInfo.binary_type) and not isinstance("a", _PyInfo.text_type)) or \
        (_PyInfo.PY3 and isinstance("a", _PyInfo.binary_type) and not isinstance("a", _PyInfo.text_type))
    print("Test class _PyInfo pass")

# Generated at 2022-06-24 02:56:27.381938
# Unit test for function getLogger
def test_getLogger():
    configure()
    logger = getLogger(__name__)
    logger.info("test")
    assert logger
    return logger


# Unit testing for function get_logger

# Generated at 2022-06-24 02:56:30.823411
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True or _PyInfo.PY2 == False
    assert _PyInfo.PY3 == True or _PyInfo.PY3 == False



# Generated at 2022-06-24 02:56:38.796202
# Unit test for function logger_level
def test_logger_level():
    """
    >>> from .loggging import get_logger
    >>> logger = get_logger()
    >>> logger.setLevel(logging.WARNING)
    >>> logger.warning('warn')
    >>> with logger_level(logger, logging.INFO):
    ...   logger.info('info')
    ...   logger.debug('debug')
    ...   logger.warning('warn')
    >>> logger.error('error')
    """
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:56:48.184644
# Unit test for function get_config
def test_get_config():
    # Test 1: no config param and no env_var
    cfg1 = get_config()
    assert cfg1 == DEFAULT_CONFIG
    # Test 2: json config param

# Generated at 2022-06-24 02:56:59.556718
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

# Generated at 2022-06-24 02:57:03.731230
# Unit test for function configure
def test_configure():
    configure()
    configure(default=None)
    configure(default=dict())
    configure(config=dict())
    configure(config=dict(), default=dict())


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:57:10.061980
# Unit test for function logger_level
def test_logger_level():
    import io
    import logging
    import sys

    stderr = sys.stderr
    try:
        sys.stderr = io.StringIO()
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        assert 'INFO' in sys.stderr.getvalue()

        with logger_level(logger, logging.DEBUG):
            assert 'DEBUG' in sys.stderr.getvalue()
    finally:
        sys.stderr = stderr



# Generated at 2022-06-24 02:57:18.418575
# Unit test for function get_config
def test_get_config():
    # test for a bare string
    cfg_bare_json = r"""
{
    "version": 1,
    "formatters": {
        "simple": {
            "format": "%(asctime)s %(name)s %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S"
        }
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "simple"
        }
    },
    "root": {
        "handlers": ["console"],
        "level": "INFO"
    }
}
"""
    cfg = get_config(config=cfg_bare_json)
    assert cfg['version'] == 1

# Generated at 2022-06-24 02:57:24.624670
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARN):
        logger.info('this should not print')
        logger.warning('this should print')

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:57:30.114974
# Unit test for function logger_level
def test_logger_level():
    curdir = os.path.dirname(os.path.abspath(__file__))
    logfile = "{}/logs/test_logger_level.log".format(curdir)

# Generated at 2022-06-24 02:57:39.165308
# Unit test for function configure

# Generated at 2022-06-24 02:57:48.726093
# Unit test for function logger_level
def test_logger_level():
    """Unit test for logger_level."""
    logger = logging.getLogger(__name__)

    # DEBUG level logs everything
    with logger_level(logger, logging.DEBUG):
        logger.debug("HELLO WORLD")

    # INFO level only logs INFO, WARNING, ERROR, CRITICAL, FATAL
    with logger_level(logger, logging.INFO):
        logger.debug("HELLO WORLD")
        logger.info("Hello world")
        logger.warning("Warning!")
        logger.error("Error!")
        logger.critical("Critical error!")

    # CRITICAL doesn't log anything
    with logger_level(logger, logging.CRITICAL):
        logger.debug("HELLO WORLD")
        logger.info("Hello world")
        logger.warning("Warning!")

# Generated at 2022-06-24 02:57:59.010447
# Unit test for function configure
def test_configure():
    cfg = {'formatters': {'simple': {'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s', 'datefmt': '%Y-%m-%d %H:%M:%S'}}}
    os.environ['LOGGING'] = json.dumps(cfg)
    configure(config=None, env_var='LOGGING', default=None)
    logger = get_logger(__name__)
    logger.error("Unit test of function configure")



# Generated at 2022-06-24 02:58:08.363421
# Unit test for function get_config
def test_get_config():
    res = get_config(default={})
    assert res == {}

    # config string
    json_str = '{"version":1}'
    yaml_str = 'version: 1'
    res = get_config(config=json_str, default={})
    assert res == {"version": 1}
    res = get_config(config=yaml_str, default={})
    assert res == {"version": 1}

    # config dict
    res = get_config(config={"version": 1}, default={})
    assert res == {"version": 1}
    res = get_config(config={"version": 1}, default={})
    assert res == {"version": 1}

    # config None
    res = get_config(config=None, default={"version": 1})
    assert res == {"version": 1}

# Generated at 2022-06-24 02:58:14.236562
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert not _PyInfo.PY3
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str

if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 02:58:17.133074
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-24 02:58:21.983902
# Unit test for function configure
def test_configure():
    config = DEFAULT_CONFIG
    configure(config)
    log = logging.getLogger(__name__)
    log.info('test configure')


# Generated at 2022-06-24 02:58:22.599198
# Unit test for function configure
def test_configure():
    pass

# Generated at 2022-06-24 02:58:28.368354
# Unit test for function configure
def test_configure():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.info("Don't see this")
        logger.error("See this")
        configure(DEFAULT_CONFIG)
        logger.info("See this")



# Generated at 2022-06-24 02:58:34.230411
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    _pyinfo = _PyInfo()
    if sys.version_info[0] == 2:
        assert _pyinfo.PY2 == True
        assert _pyinfo.PY3 == False
    else:
        assert _pyinfo.PY2 == False
        assert _pyinfo.PY3 == True

# Generated at 2022-06-24 02:58:40.350590
# Unit test for function getLogger
def test_getLogger():
    # Setup pytest logger
    pytest_logger = get_logger()
    # Read python logging doc
    # https://docs.python.org/3/library/logging.html
    # Logging level are defined as follows:
    #    CRITICAL = 50
    #    FATAL = CRITICAL
    #    ERROR = 40
    #    WARNING = 30
    #    WARN = WARNING
    #    INFO = 20
    #    DEBUG = 10
    #    NOTSET = 0

    # Test debug level
    with logger_level(pytest_logger,logging.DEBUG):
        pytest_logger.debug("Debug message")
    # Test info level
    pytest_logger.info("Info message")
    # Test warning level
    pytest_logger.warning("Warning message")
    # Test error level

# Generated at 2022-06-24 02:58:45.773568
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.debug("Debug")
    log.info("Info")
    log.warn("Warn")
    log.warning("Warning")
    log.error("Error")
    log.critical("Critical")
    log.fatal("Fatal")
    log.exception("Exception")



# Generated at 2022-06-24 02:58:54.160481
# Unit test for function configure
def test_configure():
    with logger_level(get_logger(__name__), logging.CRITICAL):
        try:
            configure()
        except ValueError as e:
            assert str(e) == 'Invalid logging config: None'
        else:
            assert False
    with logger_level(get_logger(__name__), logging.CRITICAL):
        try:
            configure(config='hello')
        except ValueError as e:
            assert 'Could not parse logging config as bare, json, or yaml' in str(e)
        else:
            assert False

    configure(config={
        'version': 1,
        'disable_existing_loggers': False
    })

    # Test different logging configurations
    with logger_level(get_logger(__name__), logging.CRITICAL):
        import json


# Generated at 2022-06-24 02:58:58.232105
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print(_PyInfo.PY3)
    assert _PyInfo.PY3 == True
    print(_PyInfo.string_types)
    assert _PyInfo.string_types == (str,)
    print(_PyInfo.text_type)
    assert _PyInfo.text_type == str
    print(_PyInfo.binary_type)
    assert _PyInfo.binary_type == bytes


# Unit Test for function configure

# Generated at 2022-06-24 02:59:09.345379
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

# Generated at 2022-06-24 02:59:11.433216
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.text_type
    assert _PyInfo.string_types



# Generated at 2022-06-24 02:59:22.312220
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warnging message')
    logger.error('error message')
    logger.critical('critical message')

    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warnging message')
        logger.error('error message')
        logger.critical('critical message')

    with logger_level(logger, logging.INFO):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warnging message')
        logger.error('error message')
        logger.critical('critical message')



# Generated at 2022-06-24 02:59:25.589609
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log.info('test')
    try:
        log.warn('test')
    except Exception as exc:
        print('error: %s' % exc)

# Generated at 2022-06-24 02:59:27.918219
# Unit test for function getLogger
def test_getLogger():
    """
    Test getLogger()
    :return: None
    """
    logger = getLogger()
    assert logger is not None

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:59:32.532469
# Unit test for function get_config
def test_get_config():
    config = {'key1': 'value1'}
    assert get_config(config) == config
    assert get_config('{"key1": "value1"}') == config
    assert get_config('key1: value1') == config

# Generated at 2022-06-24 02:59:40.038488
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    if _PyInfo.PY3:
        assert type('string') == _PyInfo.text_type
        assert type(b'bytes') == _PyInfo.binary_type
    else: # PY2
        assert type('string') == _PyInfo.binary_type
        assert type(b'bytes') == _PyInfo.binary_type
        assert type(u'unicode') == _PyInfo.text_type
        assert type(type(u'unicode')()) == _PyInfo.text_type
        assert type(u'unicode') == _PyInfo.string_types[0]



# Generated at 2022-06-24 02:59:45.649677
# Unit test for function logger_level
def test_logger_level():
    # Import System logger
    import sys

    with logger_level(sys.stdout, logging.DEBUG):
        true_value = sys.stdout.isEnabledFor(logging.DEBUG)
    false_value = sys.stdout.isEnabledFor(logging.DEBUG)
    assert(true_value and not false_value)



# Generated at 2022-06-24 02:59:53.553230
# Unit test for function get_config
def test_get_config():
    # test default logging config
    config = get_config()
    assert config['version'] == 1
    assert config['disable_existing_loggers'] == False
    assert config['formatters']['colored']['format'] == '%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s'
    assert config['formatters']['colored']['datefmt'] == '%H:%M:%S'

# Generated at 2022-06-24 02:59:59.067812
# Unit test for function configure
def test_configure():
    configure()
    log1 = logging.getLogger(__name__)
    log1.info('test1')
    log2 = logging.getLogger('test2')
    log2.info('test2')
    log3 = logging.getLogger('test3')
    log3.info('test3')
    log4 = logging.getLogger('test4')
    log4.info('test4')


if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-24 03:00:03.990510
# Unit test for function configure

# Generated at 2022-06-24 03:00:07.143545
# Unit test for function getLogger
def test_getLogger():
    # test getLogger()
    log = getLogger()
    log.info('test')

    # test getLogger(name)
    log = getLogger('test2')
    log.info('test2')



# Generated at 2022-06-24 03:00:10.478890
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    assert logger.level is logging.NOTSET

    with logger_level(logger, logging.DEBUG):
        assert logger.level is logging.DEBUG

    assert logger.level is logging.NOTSET



# Generated at 2022-06-24 03:00:12.150172
# Unit test for function configure
def test_configure():
    configure()  # default config
    log = get_logger()
    log.info('test')

# Generated at 2022-06-24 03:00:18.483677
# Unit test for function getLogger
def test_getLogger():
    import logging
    import logging_util
    
    # Test without log configuration
    logger = getLogger()
    logger.debug('debug message using basic logger')
    
    # Test with log configuration
    logging_util.configure()
    logger = getLogger()
    logger.debug('debug message using configured logger')



# Generated at 2022-06-24 03:00:20.587005
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test')



# Generated at 2022-06-24 03:00:22.645046
# Unit test for function getLogger
def test_getLogger():
    import logging
    import sys
    import os
    logger = get_logger(None)
    logger.info("Hello World!")
    logger.debug("Hello World!")


# Generated at 2022-06-24 03:00:26.733683
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logging.CRITICAL):
        assert logger.level == logging.CRITICAL
        assert False, 'Do not see this message'
    assert logger.level == logging.DEBUG



# Generated at 2022-06-24 03:00:29.947133
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == pyinfo.PY3 == False



# Generated at 2022-06-24 03:00:38.174769
# Unit test for function logger_level
def test_logger_level():
    import time
    import datetime

    logger = get_logger()
    i = 0
    with logger_level(logger, logging.CRITICAL):
        logger.setLevel(logging.DEBUG)
        try:
            logger.debug('DEBUG')
            i = 1
        except Exception:
            assert True
        else:
            logger.error('i={}, should be 1'.format(i))
            assert False
        finally:
            logger.setLevel(logging.INFO)
    logger.info('INFO')
    logger.setLevel(logging.DEBUG)
    logger.debug('DEBUG')
    assert i == 1



# Generated at 2022-06-24 03:00:42.268182
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert logger.name == '__main__'

    logger = getLogger('test')
    assert logger.name == 'test'
    logger.warning('Test')



# Generated at 2022-06-24 03:00:42.900760
# Unit test for function configure
def test_configure():
    configure(DEFAULT_CONFIG)



# Generated at 2022-06-24 03:00:45.850606
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not (
        _PyInfo.PY2 and _PyInfo.PY3
    ), '_PyInfo.PY2 and _PyInfo.PY3 are both True'



# Generated at 2022-06-24 03:00:53.828448
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    cfg = {
        'version': 1,
        'formatters': {
            'simple': {
                '()': 'colorlog.ColoredFormatter',
            },
        },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
            },
        },
        'root': {
            'level': 'DEBUG',
            'handlers': ['console'],
        },
    }
    json_cfg = json.dumps(cfg)
    assert get_config(json_cfg) == cfg
    yaml_cfg = yaml.dump(cfg)
    assert get_config(yaml_cfg) == cfg

    assert get_config(cfg) == cfg



# Generated at 2022-06-24 03:00:58.245965
# Unit test for function logger_level
def test_logger_level():
    import logging
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    log.debug('before')
    with logger_level(log, logging.ERROR):
        log.debug('after')
    log.debug('after after')



# Generated at 2022-06-24 03:01:08.339397
# Unit test for function getLogger

# Generated at 2022-06-24 03:01:10.710755
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    info = _PyInfo()
    assert info.PY2 or info.PY3
    assert isinstance(info.string_types, tuple)
    assert isinstance(info.string_types[0], type)
    assert isinstance(info.text_type, type)
    assert isinstance(info.binary_type, type)


# Generated at 2022-06-24 03:01:14.562830
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger("test")
    logger.info("test")


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:01:24.340776
# Unit test for function get_config
def test_get_config():
    import yaml
    import json
    config = None
    env_var = 'LOGGING'
    default = {
        "version": 1,
        "formatters": {
            "simple": {
                "format": "%(asctime)s %(name)s %(levelname)s %(message)s"
            }
        },
        "handlers": {
            "console": {
                "level": "DEBUG",
                "class": "logging.StreamHandler",
                "formatter": "simple"
            }
        },
        "loggers": {
            "test": {
                "level": "ERROR",
                "handlers": ["console"],
                "propagate": "no"
            }
        }
    }
    assert get_config(config, env_var, default) == default
   

# Generated at 2022-06-24 03:01:30.311470
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.string_types == (basestring,) if _PyInfo.PY2 else (str,)
    assert _PyInfo.text_type == unicode if _PyInfo.PY2 else str
    assert _PyInfo.binary_type == str if _PyInfo.PY2 else bytes


# Generated at 2022-06-24 03:01:33.821941
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    
    # Logger level is not DEBUG
    assert logger.isEnabledFor(DEBUG) == False

    # Set logger level to DEBUG
    with logger_level(logger, DEBUG):
        assert logger.isEnabledFor(DEBUG) == True

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 03:01:36.358203
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        logger.debug("Shouldn't see this")
        logger.critical("Should see this")


# Generated at 2022-06-24 03:01:39.632289
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance(DEFAULT_CONFIG, dict)
    assert _PyInfo.PY2
    assert _PyInfo.PY3
    

# Generated at 2022-06-24 03:01:40.595882
# Unit test for function getLogger
def test_getLogger():
    res = getLogger()
    assert(res)

# Generated at 2022-06-24 03:01:44.280639
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.text_type
    assert _PyInfo.string_types
    assert _PyInfo.binary_type

# Generated at 2022-06-24 03:01:46.750353
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

    log = getLogger('test2')
    log.info('test2')



# Generated at 2022-06-24 03:01:50.657098
# Unit test for function configure
def test_configure():
    import colorlog

    logging.config.dictConfig(DEFAULT_CONFIG)

    log = logging.getLogger(__name__)
    fmt = log.handlers[0].formatter
    assert fmt.__class__ == colorlog.ColoredFormatter

    log.info("test")



# Generated at 2022-06-24 03:02:00.226161
# Unit test for function configure
def test_configure():
    import json
    import os

    logging.disable(logging.NOTSET)


# Generated at 2022-06-24 03:02:08.888637
# Unit test for function getLogger
def test_getLogger():
    from pytest import raises
    from contextlib import contextmanager

    log = get_logger()
    log.info('test')

    log = get_logger('test2')
    log.info('test2')

    with raises(ValueError):
        # Invalid logging config: None
        get_logger(config=None)

    @contextmanager
    def ensure_configured():
        yield

    _CONFIGURED.clear()
    log = get_logger(configure=ensure_configured)
    log.info('test3')

    # Invalid logging config: short
    get_logger(config='short')
    # Could not parse logging config as bare, json, or yaml: short
    get_logger(config=dict(short='short'))

    # Invalid logging config: None
    get_logger

# Generated at 2022-06-24 03:02:10.623281
# Unit test for function logger_level
def test_logger_level():
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=False)

# Generated at 2022-06-24 03:02:15.104680
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log.info('test')


# Generated at 2022-06-24 03:02:18.117416
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert not _PyInfo().PY2
    assert _PyInfo().PY3
    assert _PyInfo.string_types is not None
    assert _PyInfo.text_type is not None
    assert _PyInfo.binary_type is not None



# Generated at 2022-06-24 03:02:21.567803
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('logger_level')
    with logger_level(log, logging.WARNING):
        log.info('Should not see this info')
        log.warning('Should see this warning')
        log.debug('Should not see this debug')
    log.debug('Should see this debug')



# Generated at 2022-06-24 03:02:23.662505
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert logger is not None
    assert isinstance(logger, logging.Logger)



# Generated at 2022-06-24 03:02:33.315911
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    # valid config
    default_config = {'version': 1, 'formatters': {'simple': {'format': '%(levelname)s %(message)s'}}}
    json_config = json.dumps(default_config)
    yaml_config = yaml.dump(default_config)
    assert get_config(default_config) == default_config
    assert get_config(json_config) == default_config
    assert get_config(yaml_config) == default_config

    # invalid config
    invalid_config = None
    try:
        get_config(invalid_config)
    except ValueError as e:
        assert (str(e) == "Invalid logging config: None")

# Generated at 2022-06-24 03:02:43.584780
# Unit test for function get_config
def test_get_config():
    a = get_config(None,'LOGGING', None)
    b = get_config(None,None, None)
    c = get_config('{"version": 1, "disable_existing_loggers": false, "formatters": { "simple": { "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s" } }, "handlers": { "console": { "class": "logging.StreamHandler", "level": "DEBUG", "formatter": "simple", "stream": "ext://sys.stdout" } },"root": { "level": "DEBUG", "handlers": ["console"]}}','LOGGING', None)

    assert a == DEFAULT_CONFIG
    assert b == None

# Generated at 2022-06-24 03:02:51.137743
# Unit test for function logger_level
def test_logger_level():
    LOG = get_logger()
    LOG.warn("Test message")
    with logger_level(LOG, logging.ERROR):
        LOG.warn("Should not print")
        LOG.error("Should print")
    LOG.warn("Test message")
    return True

if __name__ == '__main__':
    if not test_logger_level():
        sys.exit(1)

# Generated at 2022-06-24 03:03:01.804660
# Unit test for function get_config
def test_get_config():
    import json

    jsn = json.dumps(DEFAULT_CONFIG)
    cfg = get_config(jsn)

    assert all([key in cfg for key in DEFAULT_CONFIG.keys()])
    assert all([key in DEFAULT_CONFIG for key in cfg.keys()])

    yaml = "loggers:\n  requests: [level, INFO]"
    cfg = get_config(yaml)
    assert cfg['loggers']['requests'] == dict(level=logging.INFO)

    try:
        get_config('{')
        assert False
    except ValueError:
        pass

    try:
        get_config('-')
        assert False
    except ValueError:
        pass


# Generated at 2022-06-24 03:03:04.188677
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test')

# Generated at 2022-06-24 03:03:10.705670
# Unit test for function getLogger
def test_getLogger():
    import logging
    logging.config.dictConfig({
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'simple': {
                'format': '%(levelname)s %(message)s'
            },
        },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
                'level': logging.DEBUG
            },
        },
        'loggers': {
            '': {
                'handlers': ['console'],
                'level': logging.DEBUG,
            },
        }
    })

    log = get_logger()
    log.warning('test')

# Generated at 2022-06-24 03:03:20.526837
# Unit test for function get_config
def test_get_config():
    # Test the case when given config is None
    assert get_config(given=None) == None

    # Test the case when given config is json

# Generated at 2022-06-24 03:03:24.906968
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        assert logger.isEnabledFor(logging.DEBUG) == False



# Generated at 2022-06-24 03:03:28.024765
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    assert log.name == __name__
    assert log.level == logging.DEBUG

    log = get_logger('test2')
    assert log.name == 'test2'
    assert log.level == logging.DEBUG


if __name__ == '__main__':
    test_getLogger()