

# Generated at 2022-06-24 02:53:35.601785
# Unit test for function getLogger
def test_getLogger():
    test_logger_name = 'test_name'
    test_logger_msg = 'test message'
    test_logger = getLogger(test_logger_name)
    test_logger.info(test_logger_msg)

    return (test_logger.name == test_logger_name) and (test_logger_msg in test_logger.handlers[0].stream.getvalue())



# Generated at 2022-06-24 02:53:45.293720
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert not _PyInfo.PY2
    assert _PyInfo.PY3
    assert isinstance(b'', _PyInfo.binary_type)
    assert isinstance('', _PyInfo.text_type)
    assert isinstance('', _PyInfo.string_types)
    assert not isinstance(1, _PyInfo.binary_type)
    assert not isinstance(1, _PyInfo.text_type)
    assert not isinstance(1, _PyInfo.string_types)


if __name__ == '__main__':
    get_logger().info('test')
    get_logger().info('test2', exc_info=True)
    get_logger('test').debug('test')
    log = get_logger()
    log.info('test info')
    log.warning('test warn')

# Generated at 2022-06-24 02:53:56.701885
# Unit test for function configure
def test_configure():
    assert os.environ.get('LOGGING') == None
    assert logging.config.dictConfig.called == False
    assert logging.basicConfig.called == False
    configure()
    assert logging.config.dictConfig.called == True
    assert logging.basicConfig.called == False
    logging.config.dictConfig.called = False
    logging.config.dictConfig.side_effect = TypeError
    configure()
    assert logging.config.dictConfig.called == True
    assert logging.basicConfig.called == True
    logging.basicConfig.called = False
    logging.config.dictConfig.side_effect = None
    logging.config.dictConfig.called = False
    assert os.environ['LOGGING'] != None
    configure()
    assert logging.config.dictConfig.called == True

# Generated at 2022-06-24 02:53:57.574863
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    _PyInfo()


# Generated at 2022-06-24 02:54:01.130703
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')


# Generated at 2022-06-24 02:54:07.901769
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pi = _PyInfo()

    assert type(pi.PY2) is bool
    assert type(pi.PY3) is bool
    assert type(pi.string_types) is tuple

    if pi.PY2:
        assert type(pi.text_type) is unicode
        assert type(pi.binary_type) is str
    elif pi.PY3:
        assert type(pi.text_type) is str
        assert type(pi.binary_type) is bytes



# Generated at 2022-06-24 02:54:09.601133
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test getLogger')

if __name__ == '__main__':
    # test_getLogger()
    pass

# Generated at 2022-06-24 02:54:11.983603
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log.info('test')


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 02:54:12.679529
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-24 02:54:18.658829
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY2 is False
    assert pyinfo.PY3 is True or pyinfo.PY3 is False
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, str)
    assert isinstance(pyinfo.binary_type, type)



# Generated at 2022-06-24 02:54:25.103916
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str, )
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:  # PY2
        assert _PyInfo.string_types == (basestring, )
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str

# Generated at 2022-06-24 02:54:27.844368
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    logger.debug("Test message")



# Generated at 2022-06-24 02:54:31.412650
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()

    logger = get_logger(__name__)
    with logger_level(logger, logging.CRITICAL):
        logger.info("This should not be shown")
        logger.critical("This should be shown")

# Generated at 2022-06-24 02:54:34.253928
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert isinstance(logger, logging.Logger)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:54:39.947980
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert isinstance('hola', _PyInfo.text_type)
        assert isinstance(u'hola', _PyInfo.text_type)
        assert isinstance(b'hola', _PyInfo.binary_type)
    else:
        # PY3
        assert isinstance('hola', _PyInfo.string_types)
        assert isinstance(u'hola', _PyInfo.string_types)
        assert isinstance(b'hola', _PyInfo.binary_type)

# Generated at 2022-06-24 02:54:43.773472
# Unit test for function configure
def test_configure():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.info('info test')
        logger.debug('debug test')

if __name__ == '__main__':
    configure()
    test_configure()

# Generated at 2022-06-24 02:54:49.593621
# Unit test for function get_config
def test_get_config():
    from io import StringIO

    json_str = '{"version": 1, "formatters": { "simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": "INFO", "stream": "ext://sys.stdout"}}, "root": {"handlers": ["console"], "level": "INFO"}}'
    json_result = get_config(json_str)

# Generated at 2022-06-24 02:54:53.758891
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger_level')
    logger.debug('This should not appear')
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should appear')
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should appear too')
    logger.debug('This should not appear')


# Generated at 2022-06-24 02:55:03.146053
# Unit test for function get_config

# Generated at 2022-06-24 02:55:05.482451
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    try:
        _PyInfo()
    except Exception as e:
        assert False, "constructor of class _PyInfo threw an exception: %s" % e


# Generated at 2022-06-24 02:55:13.284672
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)

    # Test: Configuration by a dict

# Generated at 2022-06-24 02:55:17.294408
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    utinfo = _PyInfo()
    ok = True
    if utinfo.PY2:
        if utinfo.PY3:
            ok = False
        elif sys.version_info[1] > 2:
            ok = False
        elif utinfo.string_types != (basestring,):
            ok = False
        elif utinfo.text_type != unicode:
            ok = False
        elif utinfo.binary_type != str:
            ok = False
    elif utinfo.PY3:
        if sys.version_info[1] > 2:
            ok = False
        elif utinfo.string_types != (str,):
            ok = False
        elif utinfo.text_type != str:
            ok = False

# Generated at 2022-06-24 02:55:26.710952
# Unit test for function get_config
def test_get_config():
    import logging
    import yaml

# Generated at 2022-06-24 02:55:34.410863
# Unit test for function get_config
def test_get_config():
    import json
    import tempfile

    # Test logging config with string
    config = "{ 'version': 1, 'formatters': { 'simple': {'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s','datefmt': '%Y-%m-%d %H:%M:%S'}, }, 'handlers': { 'console': { 'class': 'logging.StreamHandler', 'formatter': 'simple', 'level': 10, } }, 'root': { 'handlers': ['console'], 'level': 10, }, 'loggers': { 'requests': {'level': 20}, } }"

# Generated at 2022-06-24 02:55:39.524344
# Unit test for function get_config
def test_get_config():
    d_config = get_config("", None, DEFAULT_CONFIG)
    d_config = str(d_config)
    if _PyInfo.PY3:
        assert d_config == str(DEFAULT_CONFIG)
    else:
        assert d_config == unicode(DEFAULT_CONFIG)



# Generated at 2022-06-24 02:55:43.156923
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug-1')
        log.info('info-1')
        log.debug('debug-2')
        log.error('error-1')
    log.info('info-2')



# Generated at 2022-06-24 02:55:52.966513
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger('logger_level')

    # Check if the current logger level is logging.WARNING
    assert(logger.level == logging.WARNING)

    # Set the logger level to logging.DEBUG
    with logger_level(logger, logging.DEBUG):
        # Check if the logger level is logging.DEBUG
        assert(logger.level == logging.DEBUG)

        # Set the logger level to logging.INFO
        with logger_level(logger, logging.INFO):
            # Check if the logger level is logging.INFO
            assert(logger.level == logging.INFO)

        # Check if the logger level is logging.DEBUG
        assert(logger.level == logging.DEBUG)

    # Check if the logger level is logging.DEBUG
    assert(logger.level == logging.WARNING)



# Generated at 2022-06-24 02:55:58.396774
# Unit test for function logger_level
def test_logger_level():
    """Unit test for function logger_level

    Create a logger that is only logging messages at level ERROR
    Use with logger_level to temporarily set it to DEBUG
    and expect to see debug messages.
    """
    import sys
    import io
    import logging

    logger = logging.getLogger('mylogger')
    logger.setLevel(logging.ERROR)
    stream = sys.stderr

    # Override stderr so we can test the output.
    sys.stderr = io.StringIO()
    logger.debug('debug message')
    sys.stderr.flush()
    buf = sys.stderr.getvalue()
    expected = ''

# Generated at 2022-06-24 02:56:08.801268
# Unit test for function configure
def test_configure():
    import tempfile

    with tempfile.NamedTemporaryFile(mode='w+t') as f:
        f.write('version: 1\n')
        f.write('formatters:\n')
        f.write('    simple:\n')
        f.write('        format: "%(asctime)s %(levelname)s %(message)s"\n')
        f.write('        datefmt: "%Y-%m-%d %H:%M:%S"\n')
        f.write('handlers:\n')
        f.write('    console:\n')
        f.write('        class: logging.StreamHandler\n')
        f.write('        formatter: simple\n')
        f.write('        level: INFO\n')
        f.write('loggers:\n')
       

# Generated at 2022-06-24 02:56:15.940879
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug('test debug')
        logger.info('test info')
        logger.warn('test warn')
        logger.error('test error')
    assert logger.level == logging.DEBUG
    logger.info('test info')
    logger.warn('test warn')
    logger.error('test error')

# Generated at 2022-06-24 02:56:16.979504
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3


# Generated at 2022-06-24 02:56:27.094350
# Unit test for function get_config

# Generated at 2022-06-24 02:56:33.499783
# Unit test for function get_config
def test_get_config():
    import yaml
    import json

    yaml_cfg = get_config(yaml.dump(DEFAULT_CONFIG), default=None)
    assert yaml_cfg == DEFAULT_CONFIG
    json_cfg = get_config(json.dumps(DEFAULT_CONFIG), default=None)
    assert json_cfg == DEFAULT_CONFIG

if __name__ == '__main__':
    import doctest

    print(doctest.testmod())

# Generated at 2022-06-24 02:56:38.192859
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info("This is a message from default logger")
    log2 = getLogger("test2")
    log2.info("This is a message from test2 logger")

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:56:43.368235
# Unit test for function get_config
def test_get_config():
    d = {"key1": "value1", "key2": "value2"}
    assert(get_config(d) == d)

    s = json.dumps(d)
    assert(get_config(s) == d)

    s = yaml.dump(d)
    assert(get_config(s) == d)

    s ="abc"
    with pytest.raises(ValueError):
        get_config(s)



# Generated at 2022-06-24 02:56:49.847512
# Unit test for function configure

# Generated at 2022-06-24 02:57:00.751598
# Unit test for function logger_level
def test_logger_level():
    def dummy(logger):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")

    msg = "test_logger_level: dummy(logger): %s..."
    logger = getLogger(__name__)

    logger.level = logging.DEBUG

    # logging.log(logging.DEBUG, msg % 'before')
    dummy(logger)
    # logging.log(logging.DEBUG, msg % 'after')

    with logger_level(logger, logging.INFO):
        # logging.log(logging.DEBUG, msg % 'before INFO')
        dummy(logger)
        # logging.log(logging.DEBUG, msg % 'after INFO')

    # logging.log(logging.DEBUG, msg

# Generated at 2022-06-24 02:57:07.314637
# Unit test for function get_config
def test_get_config():
    def test_get_config_basic():
        cfg = get_config(None, None, None)
        assert cfg is None

        cfg = get_config(None, None, default=DEFAULT_CONFIG)
        assert cfg == DEFAULT_CONFIG

    def test_get_config_with_env_var():
        # this test isn't really feasible because we can't unset an env var
        pass

    test_get_config_basic()
    test_get_config_with_env_var()

# Generated at 2022-06-24 02:57:13.009385
# Unit test for function get_config
def test_get_config():
    if _PyInfo.PY2:
        import json
        assert get_config(default='') == ''
        assert get_config(default=json.dumps({'a':1})) == {'a':1}
    else:
        import json
        assert get_config(default=b'') == ''
        assert get_config(default=json.dumps({'a':1}).encode('utf-8')) == {'a':1}

# Generated at 2022-06-24 02:57:16.372014
# Unit test for function configure
def test_configure():
    logging.getLogger().handlers = []

    configure(None, env_var='LOGGING', default=DEFAULT_CONFIG)

    log = logging.getLogger('test_configure')
    log.info('test_configure')

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:57:21.608657
# Unit test for function getLogger
def test_getLogger():
    """
    >>> try:
    ...     getLogger().warning("WARNING")
    ...     getLogger().error("ERROR")
    ...     getLogger().info("INFO")
    ...     getLogger().debug("DEBUG")
    ... except:
    ...     print("This script is not run in the unittest mode")
    """
    return

if __name__ == "__main__":
    configure()
    logging.debug("DEBUG")
    logging.info("INFO")
    logging.warning("WARNING")
    logging.error("ERROR")
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:57:28.407342
# Unit test for function get_config
def test_get_config():
    # test if no config given
    try:
        get_config()
    except ValueError as e:
        assert str(e) == 'Invalid logging config: None'
    # test if invalid config given
    try:
        get_config('test')
    except ValueError as e:
        assert str(e) == "Could not parse logging config as bare, json, or yaml: test"
    # test if json config given
    json_config = get_config('{"test": 1}')
    assert json_config == {'test': 1}
    # test if yaml config given
    yaml_config = get_config('test: 1')
    assert yaml_config == {'test': 1}

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:57:38.002873
# Unit test for function get_config
def test_get_config():
    # Scenario:
    # Given an empty config is given
    # And an environment variable is not set
    # And default value is not given
    # When we call `get_config` function
    # Then an error should be raised
    config = None
    env_var = None
    default = None

    with pytest.raises(ValueError):
        get_config(config, env_var, default)

    # Scenario:
    # Given an empty config is given
    # And an environment variable is set
    # And a default config is given
    # When we call `get_config` function
    # Then the the config should be a dict of the value of the environment variable
    config = None
    env_var = 'LOGGING'
    default = {}

# Generated at 2022-06-24 02:57:39.693157
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()

    logger.info('test')
    logger.debug('test')
    logger.error('test')
    logger.warn('test')



# Generated at 2022-06-24 02:57:49.190019
# Unit test for function get_config

# Generated at 2022-06-24 02:57:53.067354
# Unit test for function getLogger
def test_getLogger():
    # Initialization logger
    logger = getLogger(__name__)
    logger.info('test')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:57:56.257634
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.info("hello")
        logger.debug("world")
    logger.info("goodbye")
    logger.debug("world")



# Generated at 2022-06-24 02:58:00.180819
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # This is py2 compat shit
    assert sys.version_info[0] == 2
    assert _PyInfo.PY2
    assert not _PyInfo.PY3
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str



# Generated at 2022-06-24 02:58:09.252055
# Unit test for function configure
def test_configure():
    import logging, re

    log = configure()
    #
    # def test_configure():
    #     import logging, re
    #
    #     log = configure()
    #
    #
    #     logger_name = 'tests.test_logger'
    #     logger = logging.getLogger(logger_name)
    #
    #     fmt = '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s'
    #     exp = re.compile(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}

# Generated at 2022-06-24 02:58:13.597007
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.text_type in _PyInfo.string_types
    assert _PyInfo.binary_type in _PyInfo.string_types

# Generated at 2022-06-24 02:58:22.012059
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if sys.version_info[0] == 2:
        assert(_PyInfo.PY2)
        assert(not _PyInfo.PY3)
        assert(isinstance(u'test', _PyInfo.string_types))
        assert(isinstance('test', _PyInfo.string_types))
        assert(isinstance(u'test', _PyInfo.text_type))
        assert(isinstance('test', _PyInfo.binary_type))
    else:
        assert(not _PyInfo.PY2)
        assert(_PyInfo.PY3)
        assert(isinstance('test', _PyInfo.string_types))
        assert(isinstance(b'test', _PyInfo.binary_type))
        assert(isinstance('test', _PyInfo.text_type))


# Generated at 2022-06-24 02:58:29.243264
# Unit test for function get_config
def test_get_config():
    from pprint import pprint
    from collections import namedtuple

    # case 1: no config
    cfg = get_config()
    assert cfg == DEFAULT_CONFIG

    # case 2: config as given
    cfg = get_config(given=dict(version=1, hello='world'))
    assert cfg == dict(version=1, hello='world')

    # case 3: config as string
    cfg = get_config(given='{"version": 1, "hello": "world"}')
    assert cfg == dict(version=1, hello='world')

    # case 4: config as string in env var
    os.environ['CFG'] = '{"version": 1, "hello": "world"}'
    cfg = get_config(env_var='CFG')

# Generated at 2022-06-24 02:58:37.034826
# Unit test for function logger_level
def test_logger_level():
    name = 'ctx-log-level'
    logger = logging.getLogger(name)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG, 'Logging level was unchanged'
        logger.debug('This should be logged at debug level')
    assert logger.level != logging.DEBUG, 'Logging level was not reset correctly'

# Generated at 2022-06-24 02:58:40.434733
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test_logger_level')
    with logger_level(log, logging.INFO):
        log.debug('Will be ignored')
    log.debug('Will be logged')



# Generated at 2022-06-24 02:58:45.578456
# Unit test for function getLogger
def test_getLogger():
    import time

    logger = getLogger()
    logger.error("test_getLogger")
    log1 = getLogger("test_getLogger")
    log2 = getLogger("test_getLogger")
    logger.error("test_getLogger")

    assert log1 == log2
    assert log1 is log2

# Generated at 2022-06-24 02:58:46.035380
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    _PyInfo()

# Generated at 2022-06-24 02:58:52.564865
# Unit test for function get_config
def test_get_config():
    # Test json config
    with open('test_logging.json', 'rt') as f:
        logging_config_json = f.read()
    logging_config_json_dict = get_config(logging_config_json)
    assert logging_config_json_dict == DEFAULT_CONFIG
    # Test yaml config
    with open('test_logging.yaml', 'rt') as f:
        logging_config_yaml = f.read()
    logging_config_yaml_dict = get_config(logging_config_yaml)
    assert logging_config_yaml_dict == DEFAULT_CONFIG
    # Test bare config
    logging_config_bare = 'INFO'
    logging_config_bare_dict = get_config(logging_config_bare)
    assert logging_config_bare_dict

# Generated at 2022-06-24 02:58:59.426609
# Unit test for function get_config
def test_get_config():
    from hamcrest import assert_that, equal_to
    import json

    default = dict(foo=1)
    config = dict(bar=2)
    config_str = json.dumps(config)

    assert_that(get_config(), equal_to(None))
    assert_that(get_config(config), equal_to(config))
    assert_that(get_config(config_str), equal_to(config))
    assert_that(get_config(env_var='FOO'), equal_to(None))
    assert_that(get_config(env_var='FOO', default=config), equal_to(config))
    assert_that(get_config(default=default), equal_to(default))

# Generated at 2022-06-24 02:59:05.592180
# Unit test for function configure
def test_configure():
    import logging

    # Create a test logger
    logger = logging.getLogger()

    # Assert the logger has no handlers
    assert len(logger.handlers) == 0

    # Configure the logger
    configure()
    # Assert the logger now has one handler
    assert len(logger.handlers) == 1


# Generated at 2022-06-24 02:59:09.552860
# Unit test for function getLogger
def test_getLogger():
    console_logger = get_logger()
    console_logger.info('test')

    # test namespace from calling context
    from test_logger_util import getLogger

    getLogger.info('test 2')

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 02:59:14.327475
# Unit test for function logger_level
def test_logger_level():

    # set up a logger
    _ensure_configured()
    logger = get_logger()
    logger.info('This is to test the logger level')

    # prove that the logger is working
    assert logger.getEffectiveLevel() == logging.DEBUG
    # prove that we can set the level
    with logger_level(logger, logging.INFO):
        assert logger.getEffectiveLevel() == logging.INFO

    # prove that it returns to normal when we leave the context
    assert logger.getEffectiveLevel() == logging.DEBUG

test_logger_level()

# Generated at 2022-06-24 02:59:22.199609
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    if pyinfo.PY3:
        assert pyinfo.string_types == (str,)
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
    else:
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:59:26.849896
# Unit test for function configure
def test_configure():
    configure(config=DEFAULT_CONFIG)

    # log = logging.getLogger(__name__)
    # log.info('test')
    # log.warn('test')
    # log.error('test')
    # log.critical('test')

    # log = get_logger('lkml')
    # log.info('test')

# Generated at 2022-06-24 02:59:32.695421
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    try:
        with logger_level(logger=log, level=logging.ERROR):
            log.debug('hi')
            raise ValueError('should not be printed')
    except ValueError:
        pass



# Generated at 2022-06-24 02:59:37.741094
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('logger_level')
    config_logging(level=20, dir_log='.', mode_log='w')
    logger.info('Before level is %r' % logger.level)
    with logger_level(logger, 0):
        logger.info('Test level 0')
    logger.info('After level is %r' % logger.level)



# Generated at 2022-06-24 02:59:47.853849
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import sys
    class _PyInfo_test(object):
        PY2 = sys.version_info[0] == 2
        PY3 = sys.version_info[0] == 3

        if PY3:
            string_types = str,
            text_type = str
            binary_type = bytes
        else:  # PY2
            string_types = basestring,
            text_type = unicode
            binary_type = str

    assert _PyInfo_test.PY2 == _PyInfo.PY2
    assert _PyInfo_test.PY3 == _PyInfo.PY3

    assert _PyInfo_test.string_types == _PyInfo.string_types
    assert _PyInfo_test.text_type == _PyInfo.text_type
    assert _PyInfo_test.binary

# Generated at 2022-06-24 02:59:51.016954
# Unit test for function configure
def test_configure():
    os.environ["LOGGING"] = ""
    configure()


# Generated at 2022-06-24 02:59:57.677276
# Unit test for function get_config
def test_get_config():
    try:
        get_config()
    except ValueError:
        pass
    else:
        raise AssertionError('test_get_config failed, no exception thrown')

    assert DEFAULT_CONFIG == get_config(config=DEFAULT_CONFIG)

    import json

    assert DEFAULT_CONFIG == get_config(config=json.dumps(DEFAULT_CONFIG))

    import yaml

    assert DEFAULT_CONFIG == get_config(config=yaml.dump(DEFAULT_CONFIG))



# Generated at 2022-06-24 03:00:02.744822
# Unit test for function logger_level
def test_logger_level():
    import logging
    log = logging.getLogger(__name__)
    assert log.level == logging.WARNING
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.WARNING


# Generated at 2022-06-24 03:00:05.393208
# Unit test for function getLogger
def test_getLogger():
    import pika
    import datetime
    now = datetime.datetime.now()
    log = getLogger('test')
    log.warning('bark')



# Generated at 2022-06-24 03:00:13.980247
# Unit test for function configure
def test_configure():
    import sys
    import warnings


# Generated at 2022-06-24 03:00:17.760757
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.CRITICAL):
        logger.debug("This message should not be displayed")
        logger.warning("This message should not be displayed")
        logger.error("This message should not be displayed")
        logger.critical("This message should be displayed")
    print("Successfully passed unit test test_logger_level!")

# Generated at 2022-06-24 03:00:26.398672
# Unit test for function logger_level
def test_logger_level():
    # create logger
    logger_name = 'test_logger_level'
    log = getLogger(logger_name)
    #
    # check that the debug statement should not be run in this block
    log.setLevel(logging.INFO)
    with logger_level(log, logging.DEBUG):
        log.debug("This debug message should be displayed.")
    # check that the debug statement should be run in this block
    log.setLevel(logging.ERROR)
    with logger_level(log, logging.DEBUG):
        log.debug("This debug message should not be displayed.")



# Generated at 2022-06-24 03:00:31.187145
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    for func_name in ('info', 'debug', 'warning', 'error'):
        getattr(logger, func_name)('Hello World')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:00:37.476118
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger("test"), logging.INFO):
        logging.getLogger("test").debug("debug")
        logging.getLogger("test").info("info1")
        logging.getLogger("test").warning("warning")

    logging.getLogger("test").info("info2")

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    test_logger_level()

# Generated at 2022-06-24 03:00:42.576872
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = logging.getLogger()
    >>> with logger_level(logger, logging.DEBUG):
    ...     logger.debug('debug')
    ...     logger.error('error')
    ...
    >>> with logger_level(logger, logging.ERROR):
        logger.debug('debug')
        logger.error('error')
    """
    pass

# Generated at 2022-06-24 03:00:45.521571
# Unit test for function getLogger
def test_getLogger():
    """
    >>> import logging
    >>> logger = getLogger()
    >>> logger.info('test')
    >>> logger = getLogger('somename')
    >>> logger.info('test')
    """



# Generated at 2022-06-24 03:00:47.222330
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('hello')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:00:54.752536
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    logging.info("Test _PyInfo.py")
    print("PY2, PY3 info: ")
    print(_PyInfo.PY2)
    print(_PyInfo.PY3)

    print("string_types: ")
    print(_PyInfo.string_types)

    print("text_type: ")
    print(_PyInfo.text_type)

    print("binary_type: ")
    print(_PyInfo.binary_type)



# Generated at 2022-06-24 03:00:58.547029
# Unit test for function logger_level
def test_logger_level():
    import logging
    with logger_level(logging.getLogger('test_logger_level'), logging.ERROR):
        assert logging.getLogger('test_logger_level').level == logging.ERROR
    assert logging.getLogger('test_logger_level').level == logging.NOTSET



# Generated at 2022-06-24 03:01:03.563047
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert isinstance(logger, logging.Logger)
    assert logger.name == 'tests.test_logging'

    logger = get_logger('root')
    assert isinstance(logger, logging.Logger)
    assert logger.name == 'root'



# Generated at 2022-06-24 03:01:05.456189
# Unit test for function get_config
def test_get_config():
    print(get_config(env_var='LOGGING'))
    print(get_config(default=DEFAULT_CONFIG))


if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-24 03:01:13.884283
# Unit test for function configure
def test_configure():
    from io import StringIO

    log = logging.getLogger(__name__+'.test_configure')


# Generated at 2022-06-24 03:01:18.199091
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:01:18.701801
# Unit test for function configure
def test_configure():
    assert True


# Generated at 2022-06-24 03:01:21.528946
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL) as l:
        l.error('help')
    # check that the log handler is still set up



# Generated at 2022-06-24 03:01:27.128103
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2 == sys.version_info[0] == 2
    assert _PyInfo().PY3 == sys.version_info[0] == 3

# Generated at 2022-06-24 03:01:36.968938
# Unit test for constructor of class _PyInfo

# Generated at 2022-06-24 03:01:39.890372
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.FATAL):
        log.warning('test')
    log.warning('test')


# Generated at 2022-06-24 03:01:50.258197
# Unit test for function logger_level
def test_logger_level():
    import contextlib
    import logging
    from contextlib import contextmanager

    log = logging.getLogger(__name__)

    @contextmanager
    def logger_level(logger, level):
        "Level-context manager"
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    assert log.level == logging.NOTSET

    with logger_level(log, logging.DEBUG):
        log.debug('should be logged')
        assert log.level == logging.DEBUG
    log.debug('should NOT be logged')

    with logger_level(log, logging.INFO):
        log.debug('should NOT be logged')
        assert log.level == logging.INFO
    log.debug('should NOT be logged')

# Generated at 2022-06-24 03:01:53.855707
# Unit test for function configure
def test_configure():
    log = getLogger()
    log.info('Test1')
    log.error('Test2')
    configure()
    log.info('Test3')
    log.error('Test4')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 03:01:55.132116
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info("Logger name is test")


# Generated at 2022-06-24 03:01:58.007545
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)


# Generated at 2022-06-24 03:02:03.113271
# Unit test for function configure
def test_configure():

    if not logging.config.dictConfig({
            'version':1,
            'disable_existing_loggers': False,
        }):
        raise RuntimeError('logging.config.dictConfig returned unexpected value')

    if not logging.config.dictConfig(DEFAULT_CONFIG):
        raise RuntimeError('logging.config.dictConfig returned unexpected value')

    try:
        logging.config.dictConfig({})
    except TypeError:
        pass
    else:
        raise RuntimeError('logging.config.dictConfig did not throw a TypeError for empty config')



# Generated at 2022-06-24 03:02:11.342795
# Unit test for function get_config
def test_get_config():
    # given: config = None, env_var = None, default = { "key": "value" }
    assert get_config(None, None, { "key": "value" }) == { "key": "value" }
    # given: config = None, env_var = 'LOGGING', default = { "key": "value" }
    assert get_config(None, 'LOGGING', { "key": "value" }) == { "key": "value" }
    # given: config = None, env_var = 'LOGGING', default = None
    with pytest.raises(ValueError):
        get_config(None, 'LOGGING', None)
    # given: config = { "key": "value" }, env_var = 'LOGGING', default = None

# Generated at 2022-06-24 03:02:21.520143
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    if pyinfo.PY3:
        assert isinstance(pyinfo.string_types, tuple)
        assert isinstance(pyinfo.text_type, type)
        assert isinstance(pyinfo.binary_type, type)
        assert isinstance(pyinfo.string_types[0], type)
        assert isinstance(pyinfo.text_type, pyinfo.string_types[0])
        assert isinstance(pyinfo.binary_type, pyinfo.string_types[0])
        assert pyinfo.binary_type != pyinfo.text_type

# Generated at 2022-06-24 03:02:28.041259
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    from cheroot.wsgi import _set_response

    assert _PyInfo.PY2 or _PyInfo.PY3
    assert callable(_set_response)
    assert callable(_namespace_from_calling_context)
    assert callable(configure)
    assert callable(get_config)
    assert callable(get_logger)
    assert callable(getLogger)
    assert callable(logger_level)
    assert callable(test__PyInfo)



# Generated at 2022-06-24 03:02:32.901749
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    if _PyInfo.PY2:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    elif _PyInfo.PY3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:
        raise RuntimeError('what?')


# Generated at 2022-06-24 03:02:37.914971
# Unit test for function getLogger
def test_getLogger():
    """
    >>> from logging import INFO, DEBUG
    >>> log = getLogger()
    >>> log.setLevel(INFO)
    >>> log.info('info')
    >>> log.debug('debug')
    >>> with logger_level(log, DEBUG):
    ...     log.debug('debug2')
    """

    pass



# Generated at 2022-06-24 03:02:42.769428
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = get_logger()
    >>> with logger_level(logger, logging.INFO):
    ...     assert logger.level == logging.INFO
    ...     logger.debug('This should not show')
    ...
    >>> assert logger.level == logging.DEBUG
    >>> logger.debug('This should show')
    """



# Generated at 2022-06-24 03:02:54.576706
# Unit test for function get_config
def test_get_config():
    default = {"version": 1}
    assert get_config(None, None, default) == default
    assert get_config("{}") == {}
    assert get_config("{}", default=default) == default
    assert get_config("{'version': 1}") == {"version": 1}
    assert get_config("{'version': 1}", default=default) == {"version": 1}
    assert get_config("version: 1") == {"version": 1}
    assert get_config("version: 1", default=default) == {"version": 1}
    assert get_config("__does_not_exist") == None
    assert get_config("__does_not_exist", default=default) == default


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:02:59.794187
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    if _PyInfo.PY3:
        assert isinstance('', _PyInfo.string_types)
        assert isinstance(b'', _PyInfo.binary_type)
        assert isinstance('', _PyInfo.text_type)
    else:
        assert isinstance(b'', _PyInfo.string_types)



# Generated at 2022-06-24 03:03:04.577650
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print('Test PyInfo class')
    py = _PyInfo()
    assert py.PY2 and not py.PY3, 'Expecting PY2, but got PY3 instead'
    print('Test Passed')


# Generated at 2022-06-24 03:03:08.385857
# Unit test for function get_config
def test_get_config():
    # Test default
    default_config = {}
    assert DEFAULT_CONFIG == get_config(None, None, default_config)

    # Test config
    config = {}
    assert config == get_config(config, None, default_config)


# Generated at 2022-06-24 03:03:09.551917
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3



# Generated at 2022-06-24 03:03:16.202536
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

    assert _PyInfo.string_types == (basestring, )
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str


# Generated at 2022-06-24 03:03:22.387257
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.CRITICAL):
        log.debug('This log is not expected')

    with logger_level(log, logging.DEBUG):
        log.debug('This log is expected')

# Generated at 2022-06-24 03:03:27.550512
# Unit test for function configure
def test_configure():
    import os
    import logging
    import unittest
    import shutil

    class TestConfigure(unittest.TestCase):
        def setUp(self):
            self.d = 'testdata'
            if not os.path.isdir(self.d):
                os.mkdir(self.d)

        def tearDown(self):
            shutil.rmtree(self.d)


# Generated at 2022-06-24 03:03:35.926551
# Unit test for function get_config
def test_get_config():
    config = {
        'version': 1,
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'colored',
                'level': logging.DEBUG,
            },
        },
        'root': {
            'handlers': ['console'],
            'level': logging.DEBUG,
        },
    }
    assert get_config(default=config) == config
    assert get_config(config=config) == config
    assert get_config(
        config='{"version":1,"handlers":{"console":{"class":"logging.StreamHandler","formatter":"colored","level":"DEBUG"}},"root":{"handlers":["console"],"level":"DEBUG"}}'
    ) == config