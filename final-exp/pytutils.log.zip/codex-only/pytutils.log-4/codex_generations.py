

# Generated at 2022-06-24 02:53:36.888875
# Unit test for function get_config

# Generated at 2022-06-24 02:53:40.218441
# Unit test for function configure
def test_configure():
    # test configure
    configure()
    assert logging.getLogger().level == logging.DEBUG
    # test configure with a logging config file
    configure('./logging.cfg')
    assert logging.getLogger().level == logging.DEBUG
    # test configure with a logging config dict
    configure(DEFAULT_CONFIG)
    assert logging.getLogger().level == logging.DEBUG



# Generated at 2022-06-24 02:53:41.520138
# Unit test for function configure
def test_configure():
    pass



# Generated at 2022-06-24 02:53:52.203174
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.PY2 != _PyInfo.PY3

    if _PyInfo.PY2:
        assert isinstance('foo', _PyInfo.string_types)
        assert isinstance(u'foo', _PyInfo.string_types)
        assert not isinstance(b'foo', _PyInfo.string_types)
    elif _PyInfo.PY3:
        assert isinstance('foo', _PyInfo.string_types)
        assert not isinstance(u'foo', _PyInfo.string_types)
        assert not isinstance(b'foo', _PyInfo.string_types)



# Generated at 2022-06-24 02:53:59.212215
# Unit test for function getLogger
def test_getLogger():
    # Without argument
    log = getLogger()
    assert isinstance(log, logging.Logger)
    # With argument - String
    log = getLogger('test_string')
    assert isinstance(log, logging.Logger)
    # With argument - Logger
    log = logging.getLogger('test_logger')
    log = getLogger(log)
    assert isinstance(log, logging.Logger)
    # With argument - tuple
    log = getLogger(('test', 'tuple'))
    assert isinstance(log, logging.Logger)



# Generated at 2022-06-24 02:54:04.647219
# Unit test for function get_config

# Generated at 2022-06-24 02:54:12.550243
# Unit test for function configure
def test_configure():
    import logging

    # First logging configuration
    configure()
    log = logging.getLogger(__name__)
    log.info('test')
    # Output: [logger.py] [14:32:33] [logger/8678] test  @get_logger:26 #INFO
    # As log level is set to DEBUG

    # Second logging configuration
    configure()
    log = logging.getLogger(__name__)
    log.info('test')
    # Output: [logger.py] [14:32:33] [logger/8678] test  @get_logger:26 #INFO
    # As log level is set to DEBUG



# Generated at 2022-06-24 02:54:16.300289
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3, 'No python version detected.'
    assert _PyInfo.PY2
    assert not _PyInfo.PY3


# Generated at 2022-06-24 02:54:20.941343
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    configure()

    # default level should be INFO
    assert log.level == logging.INFO

    # set it to DEBUG and make sure it did
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG

    # make sure the level is INFO again
    assert log.level == logging.INFO



# Generated at 2022-06-24 02:54:23.737285
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__ + '.test_logger_level')
    logger.setLevel(logging.ERROR)
    logger.error('Error before')
    with logger_level(logger, logging.DEBUG):
        logger.debug('Debug in')
    logger.error('Error after')



# Generated at 2022-06-24 02:54:35.213971
# Unit test for function logger_level
def test_logger_level():
  """ Test logger_level function """
  import logging

  # Set up loggers.
  # Temporarily, print to stdout.
  logger_stdout = logging.getLogger("stdout")
  for handler in logger_stdout.handlers:
    logger_stdout.removeHandler(handler)
  console_handler = logging.StreamHandler()
  console_handler.setFormatter(logging.Formatter('%(message)s'))
  console_handler.setLevel(logging.INFO)
  logger_stdout.addHandler(console_handler)
  logger_stdout.setLevel(logging.INFO)

  # Set up second logger.
  logger_log = logging.getLogger("log")
  for handler in logger_log.handlers:
    logger_log.removeHandler(handler)
  file_

# Generated at 2022-06-24 02:54:36.155039
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-24 02:54:44.368893
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # test _PyInfo.PY2
    if _PyInfo.PY2:
        assert isinstance('', _PyInfo.string_types)
        assert isinstance(u'', _PyInfo.string_types)
        assert isinstance(unicode('', 'UTF-8'), _PyInfo.string_types)
        assert not isinstance(b'', _PyInfo.string_types)
        assert not isinstance(str(b'', 'UTF-8'), _PyInfo.string_types)
        assert isinstance(u'', _PyInfo.text_type)
        assert isinstance(unicode('', 'UTF-8'), _PyInfo.text_type)
        assert not isinstance('', _PyInfo.text_type)

# Generated at 2022-06-24 02:54:47.485347
# Unit test for function configure
def test_configure():
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    configure()
    log = logging.getLogger(__name__)
    log.info('test')
    assert logging.getLevelName(log.getEffectiveLevel()) == 'INFO'


# Generated at 2022-06-24 02:54:52.205607
# Unit test for function getLogger
def test_getLogger():
    log=getLogger()
    log.setLevel(logging.DEBUG)
    log.info("Test info message")
    log.debug("Test debug message")
    log.warning("Test warning message")
    log.error("Test error message")
    log.critical("Test critical message")


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:54:56.673258
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-24 02:55:05.671171
# Unit test for function get_config

# Generated at 2022-06-24 02:55:13.321089
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(config=yaml.safe_dump(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-24 02:55:14.112030
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    _PyInfo().PY2 == True



# Generated at 2022-06-24 02:55:16.125912
# Unit test for function get_config
def test_get_config():
    config = get_config(given="INFO", env_var=None, default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(given={"name": "INFO"}, env_var=None, default=DEFAULT_CONFIG)
    assert config == {"name": "INFO"}

# Generated at 2022-06-24 02:55:26.088564
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config(config=DEFAULT_CONFIG, env_var='LOGGING')
    assert config == DEFAULT_CONFIG

    import json
    import yaml

    config = get_config(
        config=json.dumps(DEFAULT_CONFIG),
        env_var='LOGGING',
        default=DEFAULT_CONFIG,
    )
    assert config == DEFAULT_CONFIG
    try:
        get_config(config='{"version": {"version": 1}}', env_var='LOGGING')
    except ValueError:
        pass

# Generated at 2022-06-24 02:55:32.987784
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, None) == None
    assert get_config({'key':'1', 'key':'2'}, None, None) == {'key':'2'}
    dict_config = {'key':'1', 'key':'2'}
    json_config = json.dumps(dict_config)
    with tempfile.NamedTemporaryFile() as f:
        f.write(json_config.encode('utf-8'))
        f.flush()
        os.environ['LOGGING_CONFIG_FILE'] = f.name
        assert get_config({'key':'3', 'key':'4'}, 'LOGGING_CONFIG_FILE', None) == dict_config


# Generated at 2022-06-24 02:55:36.385105
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert logger is not None


# Generated at 2022-06-24 02:55:37.937856
# Unit test for function configure
def test_configure():
    logger = getLogger(__name__)
    logger.info('test')

# Generated at 2022-06-24 02:55:48.167292
# Unit test for function get_config
def test_get_config():
    config = get_config({"version": 1}, "LOGGING", DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config("{\"version\": 1}", "LOGGING", DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config = get_config("version: 1", "LOGGING", DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    with pytest.raises(ValueError) as excinfo:
        get_config(None, "LOGGING", None)
    assert "Invalid logging config" in str(excinfo.value)

    with pytest.raises(ValueError) as excinfo:
        get_config("bad_config", "LOGGING", DEFAULT_CONFIG)

# Generated at 2022-06-24 02:55:55.602947
# Unit test for function logger_level
def test_logger_level():
    import time
    import numpy as np
    from contextlib import contextmanager
    from multiprocessing import Process
    from multiprocessing.pool import ThreadPool
    from jinja2 import Template
    import traceback
    import networkx as nx
    from itertools import combinations
    from scipy import stats
    from scipy.stats import norm
    import logging
    from six.moves import range
    from six.moves import zip

    logging.getLogger(__name__).addHandler(logging.StreamHandler())
    logger = logging.getLogger(__name__)

    # Create a bunch of simple functions to log
    @logger_level(logger, logging.CRITICAL)
    def f():
        logger.debug('nope')
        return 1


# Generated at 2022-06-24 02:55:57.343593
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')

# Generated at 2022-06-24 02:56:06.899060
# Unit test for function logger_level
def test_logger_level():
    import logging
    import StringIO
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    stream = StringIO.StringIO()
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)
    with logger_level(logger, logging.CRITICAL):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    text = stream.getvalue()
    assert 'debug' not in text
    assert 'info' not in text
    assert 'warning' not in text
    assert 'error' not in text
    assert 'critical' in text

# Generated at 2022-06-24 02:56:12.683727
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is 1 == sys.version_info[0]
    assert _PyInfo.PY3 is 3 == sys.version_info[0]

# Generated at 2022-06-24 02:56:14.114380
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert isinstance(config, dict)
    assert config == DEFAULT_CONFIG

# Generated at 2022-06-24 02:56:24.381721
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()

    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)

    if sys.version_info[0] == 3:
        assert issubclass(pyinfo.string_types[0], str)
        assert issubclass(pyinfo.text_type, str)
        assert issubclass(pyinfo.binary_type, bytes)
    else:  # PY2
        assert issubclass(pyinfo.string_types[0], basestring)
        assert issubclass(pyinfo.text_type, unicode)
        assert issubclass(pyinfo.binary_type, str)



# Generated at 2022-06-24 02:56:26.153438
# Unit test for function getLogger
def test_getLogger():
    """
    >>> logger = getLogger(__name__)
    """
    pass



# Generated at 2022-06-24 02:56:31.458864
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # The following comparison results in false if python3 is still in use, but the test will pass regardless
    if _PyInfo.PY2:
        assert_equal(text_type, unicode)
        assert_equal(binary_type, str)
    else: #PY3
        assert_equal(text_type, str)
        assert_equal(binary_type, bytes)

# Generated at 2022-06-24 02:56:40.935918
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import os


# Generated at 2022-06-24 02:56:48.422102
# Unit test for function configure
def test_configure():
    # Test default logging config
    configure()
    log = get_logger()
    log.info('test')
    log.debug('test')

    # Test custom logging config

# Generated at 2022-06-24 02:56:53.027475
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance('', _PyInfo.string_types)
    assert isinstance(u'', _PyInfo.string_types)
    assert isinstance(b'', _PyInfo.binary_type)
    assert isinstance(u'', _PyInfo.text_type)

# Generated at 2022-06-24 02:56:56.617447
# Unit test for function configure
def test_configure():
    filename = 'logging.json'
    with open(filename, 'w') as f:
        json.dump(DEFAULT_CONFIG, f)
    configure(filename)
    os.remove(filename)

# Generated at 2022-06-24 02:56:59.710049
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = get_logger()
    >>> with logger_level(logger, logging.DEBUG):
    ...     logger.debug('debug')
    ...
    """
    pass


# Generated at 2022-06-24 02:57:07.575861
# Unit test for function get_config
def test_get_config():
    config_none = None
    assert get_config(config_none) == {}

    config_string = "config string"
    assert get_config(config_string) == "config string"

    config_dict = {"a": 1}
    assert get_config(config_dict) == {"a": 1}

    config_json = '{"a":1}'
    assert get_config(config_json) == {"a": 1}

    config_yaml = 'a:1'
    assert get_config(config_yaml) == {"a": 1}

# Generated at 2022-06-24 02:57:09.519377
# Unit test for function getLogger
def test_getLogger():
    logs = logging.getLogger()
    print(logs)
    logs.info('hello world')
    logs.debug('goodbye world')



# Generated at 2022-06-24 02:57:17.886388
# Unit test for function get_config
def test_get_config():
    import json
    import yaml


# Generated at 2022-06-24 02:57:26.220494
# Unit test for function get_config
def test_get_config():
    config1 = get_config(None, None, 'yaml')
    assert isinstance(config1, dict)

    config2 = get_config(None, None, None)
    assert isinstance(config2, dict)

    try:
        config3 = get_config(None, None, 'yaml1')
        assert isinstance(config3, dict)
    except Exception:
        assert True

    config4 = get_config('yaml', None, 'yaml')
    assert isinstance(config3, dict)

# Generated at 2022-06-24 02:57:37.118501
# Unit test for constructor of class _PyInfo
def test__PyInfo():
  assert _PyInfo().PY2 == 2
  assert _PyInfo().PY3 == 3 or _PyInfo().PY3 == 3.0 or _PyInfo().PY3 == 3.1 or _PyInfo().PY3 == 3.2 or _PyInfo().PY3 == 3.3 or _PyInfo().PY3 == 3.4 or _PyInfo().PY3 == 3.5 or _PyInfo().PY3 == 3.6 or _PyInfo().PY3 == 3.7 or _PyInfo().PY3 == 3.8 or _PyInfo().PY3 == 3.9
  assert isinstance(_PyInfo().string_types, tuple)
  assert _PyInfo().text_type == str
  assert _PyInfo().binary_type == bytes


# Generated at 2022-06-24 02:57:46.481304
# Unit test for function configure
def test_configure():
    try:
        import colorlog
    except ImportError:
        print(
            'Skipping test_configure because colorlog module is not installed! '
            'colorlog must be installed to enable colored logging output.'
        )
        return

    from io import StringIO

    log_output = StringIO()

# Generated at 2022-06-24 02:57:55.860292
# Unit test for function get_config
def test_get_config():
    from copy import deepcopy

    default = deepcopy(DEFAULT_CONFIG)
    # json: get_config(None, None, default)
    assert get_config(None, None, default) == default

    # json: get_config(json.dumps(default), None, None)
    cfg_in_json = json.dumps(default)
    assert get_config(cfg_in_json, None, None) == default

    # yaml: get_config(yaml.dump(default), None, None)
    cfg_in_yaml = yaml.dump(default)
    assert get_config(cfg_in_json, None, None) == default

    # bare: get_config(default, None, None)
    assert get_config(default, None, None) == default

    # invalid: get_config

# Generated at 2022-06-24 02:58:05.302079
# Unit test for function get_config
def test_get_config():
    import json
    try:
        get_config('{"config": "foo"}')
    except ValueError:
        pytest.fail("json config failed")

    try:
        get_config('config: foo')
    except ValueError:
        pytest.fail("yaml config failed")

    try:
        get_config({'config': 'foo'})
    except ValueError:
        pytest.fail("dict config failed")

    try:
        get_config(default={'config': 'foo'})
    except ValueError:
        pytest.fail("default dict config failed")

    try:
        get_config(default=json.dumps({'config': 'foo'}))
    except ValueError:
        pytest.fail("default json config failed")


# Generated at 2022-06-24 02:58:14.520975
# Unit test for function get_config
def test_get_config():

    cfg = get_config()
    assert isinstance(cfg, dict)

    cfg = get_config(default={'test': 'this'})
    assert cfg == {'test': 'this'}

    os.environ['LOGGING'] = '{"test": "that"}'
    cfg = get_config(env_var='LOGGING')
    assert cfg == {'test': 'that'}
    del os.environ['LOGGING']

    cfg = get_config(given='{"test": "other"}')
    assert cfg == {'test': 'other'}


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:58:19.302728
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.PY2 == (not _PyInfo.PY3)
    assert _PyInfo.PY3 == (not _PyInfo.PY2)

# Generated at 2022-06-24 02:58:25.302584
# Unit test for function getLogger
def test_getLogger():
    assert getLogger().name == _namespace_from_calling_context()


if __name__ == '__main__':
    configure()
    log = get_logger()
    log.info('test')
    log.debug('test')
    log.error('test')

    log = get_logger('test2')
    log.info('test2')
    log.debug('test2')
    log.error('test2')

# Generated at 2022-06-24 02:58:36.570750
# Unit test for function get_config
def test_get_config():
    from json import loads, dumps

    assert get_config() == DEFAULT_CONFIG

    assert get_config(dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

    config_dict = {'version': 1, 'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'colored'}}}
    assert get_config(dumps(config_dict)) == config_dict


# Generated at 2022-06-24 02:58:39.949076
# Unit test for function configure
def test_configure():
    logging.getLogger(__name__)
    configure()
    log = logging.getLogger(__name__)
    log.warning('test_configure')


# Generated at 2022-06-24 02:58:42.080307
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == True  # noqa
    assert pyinfo.PY3 == False  # noqa



# Generated at 2022-06-24 02:58:47.407217
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('Test Logger')
    log.warning('Test Warn')
    try:
        int(__)
    except Exception as exc:
        log.exception(exc)
    log.error('Test Error')
    log.critical('Test Critical')
    log.debug('Debug Critical')
    print('Everything is ok')



# Generated at 2022-06-24 02:58:53.529089
# Unit test for function get_config
def test_get_config():
    config_dict = {'version': 1, 'disable_existing_loggers': False, 'formatters': {'simple': {'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s', 'datefmt': '%Y-%m-%d %H:%M:%S'}}, 'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'simple', 'level': 10}}, 'root': {'handlers': ['console'], 'level': 10}, 'loggers': {'requests': {'level': 20}}}

# Generated at 2022-06-24 02:58:55.189695
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3


# Generated at 2022-06-24 02:58:58.781658
# Unit test for function getLogger
def test_getLogger():
    try:
        logging.shutdown()
        logging.config.dictConfig(DEFAULT_CONFIG)
    except:
        logging.basicConfig()
    getLogger().warning("GetLogger !")


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:59:10.581280
# Unit test for function getLogger
def test_getLogger():
    import unittest
    import logging

    class TestGetLogger(unittest.TestCase):
        def test_logger_null(self):
            logger = getLogger()
            # logging.info()
            self.assertIsNotNone(logger)

        def test_logger_named(self):
            logger = getLogger('test')
            self.assertIsNotNone(logger)

        def test_change_level(self):
            logger = getLogger()
            logger.setLevel(logging.INFO)
            self.assertEqual(logger.level, logging.INFO)
            with logger_level(logger, logging.DEBUG):
                self.assertEqual(logger.level, logging.DEBUG)
            self.assertEqual(logger.level, logging.INFO)


# Generated at 2022-06-24 02:59:21.636575
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config() is None
    assert get_config('') is None
    assert get_config('', default=42) == 42
    assert get_config({}) is None
    assert get_config('') is None
    assert get_config('', default=42) == 42

    # JSON
    assert get_config(json.dumps({})) == {}
    assert get_config(json.dumps([])) == []
    assert get_config(json.dumps(42)) == 42

    # YAML
    assert get_config(yaml.dump({})) == {}
    assert get_config(yaml.dump([])) == []
    assert get_config(yaml.dump(42)) == 42


if __name__ == '__main__':
    import doct

# Generated at 2022-06-24 02:59:27.394207
# Unit test for function configure
def test_configure():
    import logging
    import StringIO
    import sys

    old_stdout = sys.stdout
    sys.stdout = StringIO.StringIO()
    log = logging.getLogger(__name__)
    configure()
    log.info('test')
    sys.stdout = old_stdout
    assert sys.stdout.getvalue().find('INFO') > 0



# Generated at 2022-06-24 02:59:32.870046
# Unit test for function configure
def test_configure():
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s|%(levelname)s|%(name)s|%(message)s')
    configure()
    logger = get_logger('test')
    logger.debug('Hello')
    logger.info('Hello')


# Generated at 2022-06-24 02:59:34.762073
# Unit test for function getLogger
def test_getLogger():
    assert get_logger()
    assert get_logger('test2')



# Generated at 2022-06-24 02:59:39.305484
# Unit test for function getLogger
def test_getLogger():
    print("GET_LOGGERS:")
    log1 = get_logger()
    log2 = get_logger("test")
    print("LOG1: {}".format(log1))
    print("LOG2: {}".format(log2))
    log1.info("log1")
    log2.info("log2")

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:59:43.796046
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)


# Generated at 2022-06-24 02:59:48.653894
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.setLevel(logging.DEBUG)
        assert log.level == logging.DEBUG
        with logger_level(log, logging.INFO):
            log.setLevel(logging.INFO)
            assert log.level == logging.INFO
    assert log.level == logging.DEBUG
    log.setLevel(logging.INFO)

# Generated at 2022-06-24 02:59:51.840528
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
    assert logger.level == logging.DEBUG

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 02:59:55.475243
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert type(_PyInfo().PY2) == bool
    assert type(_PyInfo().PY3) == bool
    assert type(_PyInfo().string_types) == tuple
    assert type(_PyInfo().text_type) == str
    assert type(_PyInfo().binary_type) == str


# Generated at 2022-06-24 02:59:58.622132
# Unit test for function getLogger
def test_getLogger():
    configure()

    log = getLogger('logger_name')

    assert(log.name == 'logger_name')
    # TODO how do I assert that the log message was printed correctly?

    log.info('test %s', 'message')



# Generated at 2022-06-24 03:00:08.918406
# Unit test for function configure
def test_configure():
    from contextlib import redirect_stdout
    from io import StringIO

    with redirect_stdout(StringIO()) as capture:
        log = configure()

    assert(capture.getvalue()=='')


# Generated at 2022-06-24 03:00:11.953449
# Unit test for function getLogger
def test_getLogger():
    # create logger
    logger = getLogger(__name__)
    logger.debug("debug")
    logger.info("info")
    logger.warning("warning")
    logger.error("error")
    logger.critical("critical")

# Generated at 2022-06-24 03:00:22.371037
# Unit test for function get_config
def test_get_config():
    cfg1 = "{\"handlers\": {\"console\": {\"class\": \"logging.StreamHandler\"}}}"
    cfg2 = "\"handlers\": {\"console\": {\"class\": \"logging.StreamHandler\"}}"
    cfg3 = "handlers: {console: {class: \"logging.StreamHandler\"}}"

    logging_config = get_config(cfg1)
    assert(config == {'handlers': {'console': {'class': 'logging.StreamHandler'}}})
    logging_config = get_config(cfg2)
    assert(config == {'handlers': {'console': {'class': 'logging.StreamHandler'}}})
    logging_config = get_config(cfg3)

# Generated at 2022-06-24 03:00:33.983556
# Unit test for function get_config
def test_get_config():
    config = get_config()
    c = config.get('formatters')
    assert isinstance(c, dict)
    assert c.get('colored'), 'colored formatter was not found'
    c = c.get('colored')
    assert isinstance(c, dict)
    c = c.get('()')
    assert isinstance(c, str)
    assert c == 'colorlog.ColoredFormatter', '() key was not found'
    c = config.get('handlers')
    assert isinstance(c, dict)
    c = c.get('console')
    assert isinstance(c, dict)
    c = c.get('class')
    assert isinstance(c, str)
    assert c == 'logging.StreamHandler', 'console was not found'
    c = config.get('loggers')

# Generated at 2022-06-24 03:00:36.448262
# Unit test for function configure
def test_configure():
    logging.basicConfig(level=logging.ERROR)
    log = get_logger()
    assert log.getEffectiveLevel() == logging.ERROR
    configure()
    assert log.getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-24 03:00:43.286087
# Unit test for function logger_level
def test_logger_level():
    import six  # noqa

    if six.PY2:
        from io import BytesIO as StringIO
    else:
        from io import StringIO

    if six.PY3:
        class_types = tuple
    else:
        class_types = type

    import logging
    import unittest
    import StringIO
    class TestCase(unittest.TestCase):

        def setUp(self):
            self.buffer = StringIO.StringIO()
            self.handler = logging.StreamHandler(self.buffer)
            self.logger = logging.getLogger('pyloggr')
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)


# Generated at 2022-06-24 03:00:45.216579
# Unit test for function getLogger
def test_getLogger():
    with logger_level(logging.getLogger(__name__), logging.NOTSET):
        log = getLogger()
        log.debug("logger created")



# Generated at 2022-06-24 03:00:46.893808
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    configure()
    logger.info("test configure")



# Generated at 2022-06-24 03:00:56.403274
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import os
    import shutil

    # Get a temporary directory and make it the current working directory
    tmp_dir = tempfile.mkdtemp()
    orig_dir = os.getcwd()
    os.chdir(tmp_dir)

# Generated at 2022-06-24 03:01:06.580344
# Unit test for function logger_level
def test_logger_level():

    log = getLogger('logger_level')
    log.setLevel(logging.ERROR)
    log.error("Initial Error Statement")
    log.warning("Initial Warning Statement")

    with logger_level(log, logging.INFO):
        log.info("Info Statement")
        log.warning("Warning Statement")

    log.error("Final Error Statement")
    log.warning("Final Warning Statement")

    # Expected Output
    # 2019-08-27 10:57:23| logger_level/MainProcess-MainThread:[132058] ERROR: Initial Error Statement
    # 2019-08-27 10:57:23| logger_level/MainProcess-MainThread:[132058] INFO: Info Statement
    # 2019-08-27 10:57:23| logger_level/MainProcess-MainThread:[132058] WARNING: Warning Statement


# Generated at 2022-06-24 03:01:12.953890
# Unit test for function getLogger
def test_getLogger():
    import tempfile
    from contextlib import contextmanager
    from datetime import datetime

    capture = tempfile.TemporaryFile(mode='w+')

    with logger_level(logging.getLogger(), logging.DEBUG):
        with open(capture, 'a') as capture_file:
            sys.stdout = capture_file

            log = get_logger()
            log.info('info')
            log.debug('debug')
            log.warning('warning')
            log.error('error')

            log_test = get_logger('test')
            log_test.info('info')
            log_test.debug('debug')
            log_test.warning('warning')
            log_test.error('error')
            capture_file.seek(0)
            file_contents = ''

# Generated at 2022-06-24 03:01:23.252961
# Unit test for function logger_level
def test_logger_level():
    # This test demonstrate logger_level
    logger = logging.getLogger('test_logger_level')
    # Configure logger
    configure()  
    # Test logger with level set to DEBUG
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)
        logger.debug('test_logger_level_debug')
        logger.info('test_logger_level_info')
    # Test logger with level set to INFO
    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.INFO)
        logger.debug('test_logger_level_debug')
        logger.info('test_logger_level_info')

# Generated at 2022-06-24 03:01:28.220955
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('this should get logged')
        log.warning('this should not get logged')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:01:34.403525
# Unit test for function getLogger
def test_getLogger():
    l = getLogger()
    l.info('test')
    l.warning('test')
    l.error('test')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:01:37.428212
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
    if _PyInfo.PY2:
        assert _PyInfo.text_type is unicode
    if _PyInfo.PY3:
        assert _PyInfo.text_type is str


# Generated at 2022-06-24 03:01:42.495754
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)

    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
        log.info("test_logger_level")

    assert log.level == logging.DEBUG

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 03:01:44.648357
# Unit test for function getLogger
def test_getLogger():
    logger_1 = getLogger()
    logger_1.info('test getLogger')



# Generated at 2022-06-24 03:01:46.347589
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')



# Generated at 2022-06-24 03:01:51.695532
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    obj = _PyInfo()
    assert obj.PY2 == True
    assert obj.PY3 == False
    assert obj.string_types == (basestring,)
    assert obj.text_type == unicode
    assert obj.binary_type == str

if __name__ == "__main__":
    test__PyInfo()
    log = getLogger()
    log.info('test')

# Generated at 2022-06-24 03:01:59.272587
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == True or pyinfo.PY3 == True
    assert (pyinfo.PY2 == True and pyinfo.PY3 == False) or (pyinfo.PY2 == False and pyinfo.PY3 == True)
    assert pyinfo.text_type is str or pyinfo.text_type is unicode
    assert pyinfo.binary_type is str or pyinfo.binary_type is bytes


# Generated at 2022-06-24 03:02:01.803637
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)


# Generated at 2022-06-24 03:02:05.471546
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger_level')
    assert(logger.level == logging.DEBUG)
    with logger_level(logger, logging.INFO):
        assert(logger.level == logging.INFO)
    assert(logger.level == logging.DEBUG)



# Generated at 2022-06-24 03:02:13.727468
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger_name = 'test_logger_level'
    >>> logger = logging.getLogger(logger_name)
    >>> logger.info('Before set level, the logger should print here')
    Before set level, the logger should print here
    >>> with logger_level(logger, logging.CRITICAL):
    ...     logger.info('This line should not print')
    >>> logger.info('This line should print')
    This line should print
    """
    pass



# Generated at 2022-06-24 03:02:18.182974
# Unit test for function logger_level
def test_logger_level():
    import doctest
    doctest.run_docstring_examples(logger_level, globals())

# Generated at 2022-06-24 03:02:23.842161
# Unit test for function getLogger
def test_getLogger():
    logger = logging.getLogger('test_getLogger')
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    logger.debug('This is a debug message')
    logger.info('This is an info message')
    logger.warning('This is a warning message')
    logger.error('This is an error message')
    logger.critical('This is a critical message')

    assert(logger)

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:02:34.222208
# Unit test for function get_config

# Generated at 2022-06-24 03:02:38.141591
# Unit test for function getLogger
def test_getLogger():
    logging.basicConfig(level=logging.DEBUG)
    log = getLogger()
    assert log
    log.setLevel(logging.DEBUG)
    log.debug("test")
    log.debug("test")
    log.debug("test")

# Generated at 2022-06-24 03:02:42.302438
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('1')
        logger.info('2')
    #without logger_level, these logs would not show up
    logger.debug('3')
    logger.info('4')



# Generated at 2022-06-24 03:02:48.861714
# Unit test for function getLogger
def test_getLogger():
    """Test function getLogger.
    """
    print('test getLogger')
    configure()
    log = get_logger()
    log.info('test')
    log = get_logger('test2')
    log.info('test2')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:02:56.317064
# Unit test for function logger_level
def test_logger_level():

    logging.basicConfig(level = logging.DEBUG)
    my_log = logging.getLogger(__name__)
    my_log.setLevel(logging.DEBUG)
    my_log.info("before context manager")
    with logger_level(my_log, logging.CRITICAL):
        my_log.info("in context manager")
    my_log.info("after context manager")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 03:02:58.143169
# Unit test for function configure
def test_configure():
    configure()
    get_logger(__name__).info('Test')



# Generated at 2022-06-24 03:03:02.755302
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert logger is not None
    assert logger.name == __name__

    logger = get_logger('test1')
    assert logger is not None
    assert logger.name == logger.name


if __name__ == '__main__':
    from pytest import main

    main([__file__])

# Generated at 2022-06-24 03:03:07.504579
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    p = _PyInfo()
    print(p.PY2)
    print(p.PY3)
    print(p.string_types)
    print(p.text_type)
    print(p.binary_type)


# Generated at 2022-06-24 03:03:13.094797
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    inst = _PyInfo()
    assert inst.PY2 == (sys.version_info[0] == 2)
    assert inst.PY3 == (sys.version_info[0] == 3)
    if sys.version_info[0] == 2:
        assert inst.string_types == (basestring,)
        assert inst.text_type == unicode
        assert inst.binary_type == str
    if sys.version_info[0] == 3:
        assert inst.string_types == (str,)
        assert inst.text_type == str
        assert inst.binary_type == bytes


# Generated at 2022-06-24 03:03:18.431594
# Unit test for function logger_level
def test_logger_level():
    from .. import logger
    # Get a logger
    logger = logger.get_logger()

    # Logger has a level of DEBUG
    assert logger.level == logging.DEBUG

    # We can change it to INFO within the context of logger_level
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO

    # But once we leave the context, the level returns to DEBUG
    assert logger.level == logging.DEBUG



# Generated at 2022-06-24 03:03:26.870110
# Unit test for function configure
def test_configure():
    cfg = {
        'version': 1,
        'formatters': {
            'simple': {'format': '%(asctime)s %(name)s %(message)s'}
        },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
                'level': logging.DEBUG,
            },
        },
        'root': {
            'level': logging.DEBUG,
            'handlers': ['console'],
        },
    }

    configure(cfg)
    log = logging.getLogger(__name__)

    log.info('test')
