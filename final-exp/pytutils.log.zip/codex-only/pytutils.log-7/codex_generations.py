

# Generated at 2022-06-24 02:53:31.768231
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    configure()
    with logger_level(logger, logging.DEBUG):
        logger.debug("Test logger level")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:53:39.088230
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    content = []

    def write(message):
        content.append(message)
    logger.addHandler(logging.StreamHandler(write))
    logger.info('test')
    assert not content
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug('test2')
        assert content[0].endswith('test2\n')
    assert content[1].endswith('test\n')
    assert logger.level == logging.INFO


# Generated at 2022-06-24 02:53:44.606730
# Unit test for function logger_level
def test_logger_level():
    import time
    logger_root = getLogger()
    logger_other = getLogger('other')
    with logger_level(logger_root, logging.WARNING):
        with logger_level(logger_other, logging.INFO):
            logger_root.debug('debug') # Silent
            logger_root.info('info') # Silent
            logger_other.debug('debug') # Silent
            logger_other.info('info')
            logger_root.warning('warning')
            logger_root.error('error')
            logger_other.warning('warning') # Silent
            logger_other.error('error') # Silent
            time.sleep(0.02) # Allow logger to flush
    logger_other.debug('debug')
    logger_root.debug('debug')

# Generated at 2022-06-24 02:53:56.108881
# Unit test for function get_config
def test_get_config():
    conf = """
    version: 1
    formatters:
        simple:
            format: '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s'
            datefmt: '%Y-%m-%d %H:%M:%S'
    handlers:
        console:
            class: logging.StreamHandler
            formatter: simple
            level: DEBUG
    loggers:
        root:
            handlers: [console]
            level: DEBUG
        requests:
            level: INFO
    """
    cfg = get_config(conf)

# Generated at 2022-06-24 02:53:59.012970
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')



# Generated at 2022-06-24 02:54:08.376451
# Unit test for function configure
def test_configure():
    import sys, os

    def test():
        log = logging.getLogger(__name__)

        log.info('test')
        log.debug('test')
        log.error('test')

        log.info(os.getcwd())

    # create a logging config file
    cfg = '/tmp/logging.cfg'

# Generated at 2022-06-24 02:54:17.662485
# Unit test for function get_config
def test_get_config():
    assert get_config(
        default={'test': 'fake_default'}
    ) == {'test': 'fake_default'}

    assert get_config(
        default={'test': 'fake_default'},
        env_var='not-set',
    ) == {'test': 'fake_default'}

    os.environ['__pyinfra_test'] = '{"test_get_config": "test123"}'
    assert get_config(
        env_var='__pyinfra_test',
    ) == {'test_get_config': 'test123'}

    # Clean up
    del os.environ['__pyinfra_test']



# Generated at 2022-06-24 02:54:23.334760
# Unit test for function get_config
def test_get_config():
    # error: no config
    try:
        get_config()
    except ValueError:
        pass

    # error: unknown format
    try:
        get_config(dict(foo = 'bar'))
    except ValueError:
        pass

    # get a dict from a yaml string
    cfg = '{foo: bar}'
    assert get_config(cfg) == {'foo': 'bar'}

    # get a dict from a json string
    cfg = '{"foo": "bar"}'
    assert get_config(cfg) == {'foo': 'bar'}

    # get a dict from a dict
    cfg = {'foo': 'bar'}
    assert get_config(cfg) == {'foo': 'bar'}

# Generated at 2022-06-24 02:54:34.719856
# Unit test for function getLogger
def test_getLogger():
    import logging.config
    import os

    # Setup
    log_conf_file = os.path.join(os.path.dirname(__file__), 'logging.conf')
    logging.config.fileConfig(log_conf_file)
    log = get_logger()

    # --------------------------------------------------------------------------
    # Test cases

    # Case: Normal usage
    try:
        log.info("Test log message")
        print("INFO message is logged to file")
    except Exception as e:
        print("ERROR: INFO message is not logged to file")
        raise e

    # Case: Set log level to info

# Generated at 2022-06-24 02:54:35.305824
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-24 02:54:38.514589
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert type(_PyInfo.string_types) == tuple
    else:
        assert _PyInfo.string_types == str


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:54:47.880502
# Unit test for function configure
def test_configure():
    import io
    import sys
    import logging

    test_logger = 'test_configure'
    test_log = logging.getLogger(test_logger)
    sys.stderr = io.StringIO()

    configure(config=DEFAULT_CONFIG)
    test_log.debug('test')
    assert test_logger in sys.stderr.getvalue()
    sys.stderr.truncate(0)
    sys.stderr.seek(0)

    sys.stderr = io.StringIO()

    config = {
        'loggers': {
            'test_configure': {'level': 'INFO'}
        }
    }
    configure(config=config)
    test_log.debug('test')

# Generated at 2022-06-24 02:54:50.389074
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('hello world!')



# Generated at 2022-06-24 02:54:55.999353
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    from unittest import TestCase
    from unittest import main

    class _TestPyInfo(TestCase):
        @staticmethod
        def test__PY2():
            assert _PyInfo.PY2 == sys.version_info[0] == 2
            assert not _PyInfo.PY3

        @staticmethod
        def test__string_types():
            assert _PyInfo.string_types == (basestring,)

        @staticmethod
        def test__text_type():
            assert _PyInfo.text_type == unicode

        @staticmethod
        def test__binary_type():
            assert _PyInfo.binary_type == str

    main()

# Generated at 2022-06-24 02:54:59.621938
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert getattr(_PyInfo, "string_types", None) is not None
    assert getattr(_PyInfo, "text_type", None) is not None
    assert getattr(_PyInfo, "binary_type", None) is not None



# Generated at 2022-06-24 02:55:09.489098
# Unit test for function get_config
def test_get_config():
    import pytest
    config = {"loggers": {"foo": {"level": "ERROR"}}}
    assert get_config(config) == config
    assert get_config(json.dumps(config)) == config
    assert get_config(yaml.dump(config)) == config

    with pytest.raises(ValueError):
        get_config("")

    with pytest.raises(ValueError):
        get_config('''something
        ''')

    with pytest.raises(ValueError):
        get_config('"invalid_json"')

    with pytest.raises(ValueError):
        get_config('- "invalid_yaml"')


if __name__ == '__main__':
    import doctest
    import sys

    doctest.testmod()

# Generated at 2022-06-24 02:55:11.929226
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    >>> test__PyInfo()
    True
    """
    info = _PyInfo()
    return True if info.PY2 else False if info.PY3 else None



# Generated at 2022-06-24 02:55:21.010147
# Unit test for function get_config
def test_get_config():
    # test_config_given
    config = dict(hello='world')
    assert get_config(config) == config

    # test_config_env_var
    os.environ['CUSTOM_ENV_VAR'] = '{"key": "value"}'
    config = {'key': 'value'}
    assert get_config(env_var='CUSTOM_ENV_VAR') == config
    del os.environ['CUSTOM_ENV_VAR']

    # test_config_default
    default = {'key': 'value'}
    assert get_config(default=default) == default

    # test_config_invalid
    try:
        get_config()
    except ValueError:
        pass
    else:
        raise AssertionError('config is None should raise ValueError')



# Generated at 2022-06-24 02:55:25.590023
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2 is True
    assert _PyInfo().PY3 is False

# Generated at 2022-06-24 02:55:27.273297
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG



# Generated at 2022-06-24 02:55:29.548856
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    log.info('before')

    with logger_level(log, logging.DEBUG):
        log.info('inside')

    log.info('after')


# Generated at 2022-06-24 02:55:34.961166
# Unit test for function configure
def test_configure():
    """
    >>> try:
    ...     logging.shutdown()
    ...     configure()
    ...     log = logging.getLogger(__name__)
    ...     log.info('test')
    ... except:
    ...     pass

    """
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:55:38.966776
# Unit test for function getLogger
def test_getLogger():
    import logging
    logger = getLogger()
    assert logger.name == __name__
    logger.setLevel(logging.DEBUG)
    logger.debug('This is a debug message')


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 02:55:42.616835
# Unit test for function get_config
def test_get_config():
    from py.test import raises

    with raises(ValueError):
        get_config()

    assert get_config(default=None) is None

    assert get_config(default='{"x": "y"}') == dict(x='y')

    assert get_config(default='x: y') == dict(x='y')

# Generated at 2022-06-24 02:55:46.861772
# Unit test for function configure
def test_configure():
    # Test if the function is able to get the log file
    file = 'logging_test.json'
    try:
        configure(config=file)
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-24 02:55:54.691797
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import pickle

    d = dict(a = 1)
    j = json.dumps(d)
    y = yaml.dump(d)
    p = pickle.dumps(d)
    b = bytes(1)

    assert d == get_config(d)
    assert d == get_config(y)
    assert d == get_config(j)
    assert d == get_config(p)

    try:
        get_config(b)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    try:
        get_config(None)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

if __name__ == '__main__':
    import doctest


# Generated at 2022-06-24 02:55:55.671745
# Unit test for function configure
def test_configure():
    assert configure()



# Generated at 2022-06-24 02:55:59.217990
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert _PyInfo.string_types is not None
    assert _PyInfo.text_type is not None
    assert _PyInfo.binary_type is not None



# Generated at 2022-06-24 02:56:05.721332
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    >>> info = _PyInfo()
    >>> assert info.PY3 or info.PY2 # sanity check, either should be true

    >>> # Strings in py2 are of type `unicode` while in py3 they are type `str`
    >>> assert isinstance('', _PyInfo().string_types)
    >>> assert isinstance(u'', _PyInfo().string_types)
    """
    pass



# Generated at 2022-06-24 02:56:11.120594
# Unit test for function getLogger
def test_getLogger():
    # Prepare for test
    logger = getLogger()
    for hnd in logger.handlers:
        if isinstance(hnd, logging.StreamHandler):
            stream = hnd.stream
    logs = stream.readline()

    # Test
    logger.info('test')

    # Clean up
    stream.seek(0)
    stream.truncate()

    # Verify
    assert 'test' in logs
    print('Pass')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:56:14.875403
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True
    assert _PyInfo.PY3 is False
    assert len(_PyInfo.string_types) == 1
    assert _PyInfo.string_types[0] == basestring
    assert _PyInfo.string_types[0] == str
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str

# Generated at 2022-06-24 02:56:18.669314
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert isinstance(pyinfo.PY2, bool)
    assert isinstance(pyinfo.PY3, bool)
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, str)
    assert isinstance(pyinfo.binary_type, type)


# Generated at 2022-06-24 02:56:21.359788
# Unit test for function logger_level
def test_logger_level():
    x = get_logger()
    assert x.level == logging.DEBUG
    with logger_level(x, logging.WARNING):
        assert x.level == logging.WARNING
    assert x.level == logging.DEBUG

# Generated at 2022-06-24 02:56:27.732481
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    assert log.level == logging.DEBUG
    log.setLevel(logging.INFO)
    log.debug('Debug message')
    assert log.level == logging.INFO
    log.info('Info message')
    assert log.level == logging.INFO


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:56:30.834979
# Unit test for function configure
def test_configure():
    logging.config.dictConfig(DEFAULT_CONFIG)
    log = logging.getLogger(__name__)
    log.debug('test')



# Generated at 2022-06-24 02:56:39.781527
# Unit test for function getLogger
def test_getLogger():
    import unittest
    import mock

    class TestGetLogger(unittest.TestCase):
        @mock.patch('logutils.get_logger')
        def test_get_logger(self, mock_get_logger):
            getLogger()
            mock_get_logger.assert_called_once_with()

    suite = unittest.TestLoader().loadTestsFromTestCase(TestGetLogger)
    unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:56:46.182970
# Unit test for function get_config
def test_get_config():
    test_config_None = get_config(None, None, None)
    assert test_config_None == None

    test_config_default = get_config(None, None, DEFAULT_CONFIG)
    assert test_config_default == DEFAULT_CONFIG

    test_config_env_var = get_config(None, 'LOGGING', None)
    assert test_config_env_var == None

    test_config_given = get_config('{"version": 1}', None, None)
    assert test_config_given == {'version': 1}

if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-24 02:56:47.740781
# Unit test for function configure
def test_configure():
    assert not logging.root.handlers
    configure()
    assert logging.root.handlers

# Unit test function get_config

# Generated at 2022-06-24 02:56:50.335456
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()

    with logger_level(logger, logging.CRITICAL):
        raise AssertionError

# Generated at 2022-06-24 02:56:54.214310
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.debug('test')
    log.info('test')
    log.error('test')


# Generated at 2022-06-24 02:57:02.513303
# Unit test for function getLogger
def test_getLogger():
    def test_func(a, b):
        logger = get_logger()
        logger.debug("logger.debug(%s)" % a)
        logger.info("logger.info(%s)" % b)
        logger.warning("logger.warning(%s + %s)" % (a, b))
        logger.error("logger.error(%s + %s)" % (a, b))
        logger.critical("logger.critical(%s + %s)" % (a, b))

    # Test getLogger with no namespace
    print("Testing: getLogger without namespace")
    test_func("logger.debug", "logger.info")

    # Test getLogger with namespace
    print("Testing: getLogger with namespace")
    test_func("logger.debug", "logger.info")

# Generated at 2022-06-24 02:57:06.404050
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3
    assert _PyInfo.PY2 == False
    assert _PyInfo.string_types == (str, )
    assert _PyInfo.text_type == str
    assert _PyInfo.binary_type == bytes


# Generated at 2022-06-24 02:57:09.729066
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger("test_configure")
    log.debug("debug")
    log.info("info")
    log.error("error")
    log.critical("critical")
    log.exception("some exception")


# Generated at 2022-06-24 02:57:18.030517
# Unit test for function configure
def test_configure():
    logger = logging.getLogger()
    assert logger.level == logging.DEBUG

    configure({
        'root': {
            'handlers': ['console'],
            'level': logging.INFO,
        },
    })
    assert logger.level == logging.INFO
    logger.setLevel(logging.DEBUG)

    configure({
        'handlers': {
            'bufferd_stream': {
                'class': 'logging.StreamHandler',
                'formatter': 'colored',
                'level': logging.DEBUG,
            },
        },
        'root': {
            'handlers': ['bufferd_stream'],
            'level': logging.DEBUG,
        },
    })
    assert logger.level == logging.DEBUG

    logger.debug('test 1')
    logger.info('test 2')
    logger.warn

# Generated at 2022-06-24 02:57:23.438658
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    log.info('test')
    configure()
    log.info('test')


# Generated at 2022-06-24 02:57:25.556415
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.PY2 != _PyInfo.PY3


# Generated at 2022-06-24 02:57:28.086160
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(__name__), logging.DEBUG):
        assert getLogger(__name__).level == logging.DEBUG
    assert getLogger(__name__).level != logging.DEBUG


if __name__ == '__main__':
    import doctest

    doctest.testmod()

    # test_logger_level()

# Generated at 2022-06-24 02:57:31.606540
# Unit test for function getLogger
def test_getLogger():
    name = 'test'
    log = getLogger(name)
    assert log.name == name, "Failed to get logger for %s" % name


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:57:41.088815
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    dict_config = {"version": 1}
    json_config = json.dumps(dict_config)
    yaml_config = yaml.dump(dict_config)
    json_config_with_yaml = "{}\n{}".format(json_config, yaml_config)
    yaml_config_with_json = "{}\n{}".format(yaml_config, json_config)
    assert get_config(dict_config) == dict_config
    assert get_config(json_config) == dict_config
    assert get_config(yaml_config) == dict_config
    assert get_config(json_config_with_yaml) == dict_config
    assert get_config(yaml_config_with_json) == dict_config


# Generated at 2022-06-24 02:57:42.967844
# Unit test for function configure
def test_configure():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-24 02:57:51.267084
# Unit test for function get_config
def test_get_config():
    global DEFAULT_CONFIG

# Generated at 2022-06-24 02:57:56.788142
# Unit test for function configure
def test_configure():
    logging.shutdown()

    assert logging.Logger.manager.loggerDict == {}, \
        "logging.Logger.manager.loggerDict is not empty before configure"

    configure()
    log = getLogger()
    assert hasattr(log, 'warning'), \
        "logging.Logger instance does not have 'warning' method"

    logging.shutdown()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:58:04.627537
# Unit test for function logger_level
def test_logger_level():
    level = [None]
    def consume_level(level_):
        level.append(level_)

    log = logging.getLogger('test_logger_level')
    log.addHandler(logging.StreamHandler())
    try:
        with logger_level(log, logging.DEBUG):
            log.debug('this is debug')
            consume_level(log.level)
        log.debug('this is not debug')
        consume_level(log.level)
        # the level should have been reset
        assert level == [None, logging.DEBUG, logging.INFO]
    finally:
        log.level = logging.INFO

# Generated at 2022-06-24 02:58:11.187567
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if not hasattr(_PyInfo, 'PY2'):
        raise ValueError('_PyInfo.PY2 is undefined')
    if not hasattr(_PyInfo, 'PY3'):
        raise ValueError('_PyInfo.PY3 is undefined')
    if not hasattr(_PyInfo, 'string_types'):
        raise ValueError('_PyInfo.string_types is undefined')
    if not hasattr(_PyInfo, 'text_type'):
        raise ValueError('_PyInfo.text_type is undefined')
    if not hasattr(_PyInfo, 'binary_type'):
        raise ValueError('_PyInfo.binary_type is undefined')
    if not isinstance(_PyInfo.PY2, bool):
        raise ValueError('_PyInfo.PY2 is not bool')

# Generated at 2022-06-24 02:58:15.090600
# Unit test for function logger_level
def test_logger_level():
    l = logging.getLogger('test')
    l.setLevel(logging.ERROR)
    with logger_level(log, logging.INFO):
        l.info('Should print')
        l.error('Should not print')
    l.error('Should print')



# Generated at 2022-06-24 02:58:17.759152
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:58:27.951391
# Unit test for function logger_level
def test_logger_level():
    NAME = 'test_logger_level'
    import logging
    import StringIO
    logger = logging.getLogger(NAME)
    level = logging.DEBUG
    string_io = StringIO.StringIO()
    handler = logging.StreamHandler(string_io)
    logger.addHandler(handler)
    logger.setLevel(level)
    with logger_level(logger, logging.INFO):
        logger.info('Hello World')
    assert string_io.getvalue() == ''
    with logger_level(logger, logging.DEBUG):
        logger.info('Hello World')
    assert string_io.getvalue() == '[%s/%d][INFO][Hello World]\n' % (NAME, os.getpid())
    logger.info('Hello World again')

# Generated at 2022-06-24 02:58:36.864363
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    logger.info('This should be shown')

    try:
        with logger_level(logger, logging.CRITICAL):
            logger.info('This should not be shown')
            raise ValueError()
    except Exception:
        pass

    logger.info('This should be shown')


if __name__ == "__main__":
    configure()

    log = get_logger()
    log.info('hello world')

    log = get_logger(__name__)
    log.info('hello world')

    test_logger_level()

# Generated at 2022-06-24 02:58:42.638670
# Unit test for function getLogger
def test_getLogger():
    # type: () -> None
    """
    Test the function get_logger().
    """
    import colorlog

    logger = get_logger("test")
    assert(logger.propagate == logging.getLogger("test").propagate)
    assert(logger.level == logging.getLogger("test").level)
    assert(isinstance(logger.handlers[0], colorlog.StreamHandler))



# Generated at 2022-06-24 02:58:45.499998
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    configure()
    logger.info('test')



# Generated at 2022-06-24 02:58:52.713786
# Unit test for function getLogger
def test_getLogger():
    logPath = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir,'logs/logging.conf'))
    logging.config.fileConfig(logPath)
    log = logging.getLogger()
    log.info("this is a INFO message")
    log.debug("this is a DEBUG message")
    log.error("this is a ERROR message")
    log.warn("this is a WARNING message")
    log.critical("this is a CRITICAL message")


# Generated at 2022-06-24 02:58:56.692729
# Unit test for function logger_level
def test_logger_level():
    import sys
    import StringIO
    s = StringIO.StringIO()
    handler = logging.StreamHandler(s)
    logger = logging.getLogger()
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.WARNING):
        logger.debug('this should not be logged')
    logger.debug('this should be logged')

    assert 'this should be logged' in s.getvalue()
    assert 'this should not be logged' not in s.getvalue()

if __name__ == '__main__':
    test_logger_level()
    print('Tests passed')

# Generated at 2022-06-24 02:58:58.158361
# Unit test for function getLogger
def test_getLogger():
    os.environ['LOGGING'] = 'colored'
    getLogger()

# Generated at 2022-06-24 02:59:03.720596
# Unit test for function logger_level
def test_logger_level():
    with capture_logging() as captor:
        log = getLogger()
        with logger_level(log, logging.ERROR):
            log.info('info')
            log.error('error')
    assert captor.get_logged() == ['error']

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:59:05.818889
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 != _PyInfo.PY3

# Generated at 2022-06-24 02:59:09.433063
# Unit test for function getLogger
def test_getLogger():
    import inspect

    caller = inspect.getframeinfo(inspect.currentframe().f_back)
    current_module = inspect.getmodule(caller[0]).__name__
    log = getLogger(current_module)
    log.info("test")


# Generated at 2022-06-24 02:59:19.959038
# Unit test for function logger_level
def test_logger_level():
    logging.debug("This is a debug message")
    logging.info("This is an info message")
    logging.warning("This is a warning message")
    logging.error("This is an error message")
    logging.critical("This is a critical message")
    with logger_level(logging,logging.INFO):
        logging.debug("This is a debug message")
        logging.info("This is an info message")
        logging.warning("This is a warning message")
        logging.error("This is an error message")
        logging.critical("This is a critical message")
    logging.debug("This is a debug message")
    logging.info("This is an info message")
    logging.warning("This is a warning message")
    logging.error("This is an error message")
    logging.critical("This is a critical message")


# Generated at 2022-06-24 02:59:30.725341
# Unit test for function get_config

# Generated at 2022-06-24 02:59:32.696131
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level != logging.INFO



# Generated at 2022-06-24 02:59:37.403017
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    print(logger.level)
    with logger_level(logger, logging.ERROR):
        print(logger.level)
        logger.warning('this will be printed')
        logger.error('this will not be printed')
    print(logger.level)

# test_logger_level()

# Generated at 2022-06-24 02:59:39.195684
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3


if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 02:59:40.803958
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG



# Generated at 2022-06-24 02:59:48.235260
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print(dir(_PyInfo))
    print('_PyInfo.PY2: ', _PyInfo.PY2)
    print('_PyInfo.PY3: ', _PyInfo.PY3)
    print('_PyInfo.string_types: ', _PyInfo.string_types)
    print('_PyInfo.text_type: ', _PyInfo.text_type)
    print('_PyInfo.binary_type: ', _PyInfo.binary_type)


if __name__ == "__main__":
    test__PyInfo()

# Generated at 2022-06-24 02:59:58.925768
# Unit test for function get_config

# Generated at 2022-06-24 03:00:00.863935
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3


# Generated at 2022-06-24 03:00:10.207604
# Unit test for function get_config
def test_get_config():
    # load json config
    config = '{"version":1,"handlers":{"console":{"class":"logging.StreamHandler"}}}'
    cfg = get_config(config)
    assert cfg['handlers']['console'] is not None

    # load yaml config
    config = "version: 1\nhandlers:\n  console:\n    class: logging.StreamHandler"
    cfg = get_config(config)
    assert cfg['handlers']['console'] is not None

    # fail on bad config
    config = "blah blah blah"
    try:
        get_config(config)
    except ValueError:
        pass
    else:
        raise AssertionError('Should raise ValueError when config is a bad string')

    # test that json can be loaded from env
    config = "{\"version\":1}"

# Generated at 2022-06-24 03:00:14.474485
# Unit test for function getLogger
def test_getLogger():
    configure()
    logger = get_logger()
    logger.debug('test_debug message')
    logger.info('test_info message')
    logger.warning('test_warning message')
    logger.error('test_error message')
    logger.critical('test_critical message')
    logger.exception('test_exception message')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:00:21.052298
# Unit test for function get_config
def test_get_config():
    # config is not given
    config = None
    env_var='LOGGING'
    default=DEFAULT_CONFIG
    expected_config = DEFAULT_CONFIG
    assert get_config(config, env_var, default) == expected_config

    # config is given
    config = '{"version": 1, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "colored", "level": "DEBUG"}}}'
    env_var='LOGGING'
    default=DEFAULT_CONFIG
    expected_config = {"version": 1, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "colored", "level": "DEBUG"}}}
    assert get_config(config, env_var, default) == expected_config

    # config is not given and env_var

# Generated at 2022-06-24 03:00:30.629207
# Unit test for function logger_level
def test_logger_level():
    import pytest
    @pytest.fixture()
    def _get_logger(request):
        """
        Return a logger and a logging.LogRecord object from that logger
        """
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)
        for handler in logger.handlers:
            handler.setLevel(logging.DEBUG)
        logger.debug('test')
        record = logger.handlers[0].buffer[0]
        return record, logger

    def test_logger_level(_get_logger):
        """
        Test the function logger_level
        """
        # Get the logger and LogRecord
        record, logger = _get_logger
        # Change the priority of the logger to INFO

# Generated at 2022-06-24 03:00:40.369050
# Unit test for function configure
def test_configure():
    import os
    import tempfile
    from shutil import rmtree
    from tempfile import mkdtemp
    from os.path import join


# Generated at 2022-06-24 03:00:45.341916
# Unit test for function configure
def test_configure():
    import tempfile
    import yaml

    config = {
        'loggers': {
            'somepackage': {
                'handlers': ['console'],
                'level': 'DEBUG',
            },
            'somepackage.submodule': {
                'handlers': ['console'],
                'level': 'INFO',
            },
        },
    }

    expected_file_handler = {
        'class': 'logging.FileHandler',
        'formatter': 'simple',
        'level': 'INFO',
    }


# Generated at 2022-06-24 03:00:51.318468
# Unit test for function logger_level
def test_logger_level():
    print("Testing function logger_level")
    
    import time
    import logging
    import logging.config
    import inspect
    import sys
    import os
    import test_config
    import sys
    import colorlog
    import json
    import yaml

    test_config.configure("test_config.json")
    log1 = logging.getLogger("__main__")
    log1.debug("test 1")
    with logger_level(log1, logging.INFO):
        log1.debug("test 2")
    log1.debug("test 3")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 03:00:52.772897
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    logger.info("Test getLogger!")
    assert 1



# Generated at 2022-06-24 03:00:56.954689
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    assert(type(log) == logging.RootLogger)
    log.info('test_getLogger')



# Generated at 2022-06-24 03:01:07.116671
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    log_fd, log_path = tempfile.mkstemp()


# Generated at 2022-06-24 03:01:09.428700
# Unit test for function configure
def test_configure():

    assert DEFAULT_CONFIG is not None
    assert get_config() is not None
    assert 'console' in DEFAULT_CONFIG['handlers']
    assert 'colored' in DEFAULT_CONFIG['formatters']


# Generated at 2022-06-24 03:01:11.226817
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test_getLogger')
    assert logger.getEffectiveLevel() == logging.DEBUG


# Generated at 2022-06-24 03:01:22.975666
# Unit test for function configure
def test_configure():

    # Invalid config (not dict or string)
    try:
        configure(42)
        assert False
    except ValueError:
        assert True

    # Invalid config (not valid json or yaml)
    try:
        configure(
            'invalid json 123',
            env_var=None,
        )
        assert False
    except ValueError:
        assert True

    # Invalid config (not valid python dict)
    try:
        configure(
            '{"key": "val", "key": "val"}',
            env_var=None,
        )
        assert False
    except ValueError:
        assert True

    # Invalid config (not valid python dict)
    try:
        configure(
            '''
            key: value
            '''
        )
        assert False
    except ValueError:
        assert True

   

# Generated at 2022-06-24 03:01:29.829851
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 is True
    assert _PyInfo.PY2 is False
    assert _PyInfo.text_type is str
    assert _PyInfo.binary_type is bytes
    assert not isinstance('abc', _PyInfo.text_type)
    assert isinstance(b'abc', _PyInfo.binary_type)
    import json
    assert isinstance(json.dumps('abc'), _PyInfo.binary_type)



# Generated at 2022-06-24 03:01:38.550160
# Unit test for function logger_level
def test_logger_level():
    """
    >>> from logging import basicConfig
    >>> from logging import getLogger, DEBUG, INFO
    >>> from logging import StreamHandler

    >>> basicConfig(level=INFO)
    >>> my_logger = getLogger()
    >>> my_logger.addHandler(StreamHandler())

    >>> with logger_level(my_logger, DEBUG):
    ...     my_logger.debug("This is a debug message!")
    ...
    DEBUG:__main__:This is a debug message!

    >>> my_logger.debug("This should not be seen!")
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# logger = get_logger()
# print logger.handlers

# Generated at 2022-06-24 03:01:40.755827
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    print(log)

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 03:01:47.829077
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pi = _PyInfo()
    assert pi.PY2 and not pi.PY3
    assert string_types == (basestring,)
    assert text_type == unicode
    assert binary_type == str


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    log = get_logger('log')

    log.info('test')

    logger = get_logger(__name__)

    logger.info('test2')

# Generated at 2022-06-24 03:01:51.285279
# Unit test for function get_config
def test_get_config():
    test_config = '{"a":"b"}'
    cfg = get_config(test_config)
    assert cfg == {"a":"b"}



if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-24 03:01:59.018799
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    logger.level = logging.ERROR
    logger.debug("Should not be displayed")
    logger.info("Should not be displayed")
    logger.warning("Should not be displayed")
    with logger_level(logger, logging.DEBUG):
        logger.debug("Should be displayed")
    logger.debug("Should not be displayed")

# Test case for function get_logger

# Generated at 2022-06-24 03:02:03.878324
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY2 is False
    assert pyinfo.PY3 is True or pyinfo.PY3 is False
    assert type(pyinfo.string_types).__name__ == 'tuple'
    assert type(pyinfo.text_type).__name__ == 'type'
    assert type(pyinfo.binary_type).__name__ == 'type'

# Generated at 2022-06-24 03:02:11.906649
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    cfg = get_config(default={'a': 1, 'b': 2})
    assert cfg == {'a': 1, 'b': 2}

    cfg = get_config(default=json.dumps({'a': 1, 'b': 2}))
    assert cfg == {'a': 1, 'b': 2}

    cfg = get_config(default=yaml.dump({'a': 1, 'b': 2}))
    assert cfg == {'a': 1, 'b': 2}

    cfg = get_config(default='{"a": 1, "b": 2}')
    assert cfg == {'a': 1, 'b': 2}

    cfg = get_config(default='a: 1\nb: 2\n')
    assert cfg

# Generated at 2022-06-24 03:02:18.354544
# Unit test for function getLogger
def test_getLogger():
    configure()
    test_logger = getLogger()
    test_logger.info('test')
    test_logger.debug('test debug')
    test_logger.setLevel(logging.ERROR)
    test_logger.info('test error level')
    test_logger.debug('test error level debug')
    test_logger.error('test error level')

# Generated at 2022-06-24 03:02:19.114953
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info("Hello World!")


# Generated at 2022-06-24 03:02:21.177856
# Unit test for function configure
def test_configure():
    logger = logging.getLogger('configure_test')
    logger.info('Testing configure function')
    assert 'configure_test' in DEFAULT_CONFIG['loggers']


# Generated at 2022-06-24 03:02:26.407471
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    if pyinfo.PY3:
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
    else:
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str
    assert isinstance("string", pyinfo.string_types)

if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 03:02:37.517972
# Unit test for function logger_level
def test_logger_level():
    num_runs = 4

    logger = getLogger(__name__)

    print('=== test logger_level() ===')
    logger.setLevel(logging.DEBUG)
    for run in range(num_runs):
        logger.debug('this is debug message %d' % run)

    logger.setLevel(logging.INFO)
    for run in range(num_runs):
        logger.debug('this is debug message %d' % run)
        logger.info('this is information %d' % run)

    with logger_level(logger, logging.DEBUG):
        for run in range(num_runs):
            logger.debug('this is debug message %d' % run)

    for run in range(num_runs):
        logger.debug('this is debug message %d' % run)

# Generated at 2022-06-24 03:02:41.327764
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG


if __name__ == '__main__':
    import logging
    import tests

    print(DEFAULT_CONFIG)
    configure()
    logging.debug('Tried to configure logger')

# Generated at 2022-06-24 03:02:44.166103
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()

    if _PyInfo.PY2:
        assert type(logger) is logging.Logger
    elif _PyInfo.PY3:
        assert type(logger) is logging.Logger



# Generated at 2022-06-24 03:02:48.361749
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger(__name__)
    logger.info("Unit test for function getLogger")


# Generated at 2022-06-24 03:02:51.371955
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert logger.info('test') == None
    logger = get_logger('test2')
    assert logger.info('test2') == None


# Generated at 2022-06-24 03:02:59.760346
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py_info = _PyInfo()
    assert py_info.PY2 is True or py_info.PY2 is False
    assert py_info.PY3 is True or py_info.PY3 is False
    assert py_info.PY2 is not py_info.PY3
    # assert py_info.string_types
    # assert py_info.text_type
    # assert py_info.binary_type
    print("test__PyInfo PASS")

if __name__ == "__main__":
    test__PyInfo()

# Generated at 2022-06-24 03:03:10.810780
# Unit test for function configure

# Generated at 2022-06-24 03:03:17.426716
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('test_logger_level')
    with logger_level(log, logging.CRITICAL):
        assert log.level == logging.CRITICAL
        assert log.getEffectiveLevel() == logging.CRITICAL
    assert log.level == logging.DEBUG
    assert log.getEffectiveLevel() == logging.DEBUG

test_logger_level()

# Generated at 2022-06-24 03:03:21.820803
# Unit test for function getLogger
def test_getLogger():
    __name__ = 'test'
    log = getLogger(__name__)
    log.info('test')


# Generated at 2022-06-24 03:03:24.747293
# Unit test for function getLogger
def test_getLogger():
    log = getLogger('test')
    try:
        log.info('test')
    except Exception:
        print('Test failed')
    print('Test passed')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:03:28.962260
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not (_PyInfo.PY2 and _PyInfo.PY3)
    if _PyInfo.PY2:
        assert isinstance(1, long)
        assert isinstance(unicode('string'), basestring)
        assert isinstance('string', str)
    if _PyInfo.PY3:
        assert isinstance('string', str)
        assert not isinstance(u'unicode', str)
        assert isinstance(1, int)
        assert not isinstance(1, long)
        assert isinstance(b'string', bytes)
        assert not isinstance(u'string', bytes)
        assert not isinstance('string', bytes)
        assert isinstance(u'string', str)