

# Generated at 2022-06-24 02:53:39.737559
# Unit test for function get_config
def test_get_config():
    assert get_config('{"version": 1}') == {'version': 1}
    assert get_config('{"version": 1, "formatters": {"simple": {"format": "simple_format"}}}') == {'version': 1, 'formatters': {'simple': {'format': 'simple_format'}}}
    try:
        get_config('')
        assert False
    except ValueError:
        pass
    try:
        get_config('{"version": 1, "formatters": {"simple": {"format": "simple_format"}}')
        assert False
    except ValueError:
        pass
    try:
        get_config('{"version": 1', 'LOGGING')
        assert False
    except ValueError:
        pass
    # print(get_config(default={'version': 1, 'formatters': {'simple

# Generated at 2022-06-24 02:53:45.304674
# Unit test for function get_config
def test_get_config():
    # just make sure it doesn't crash
    assert get_config()
    assert get_config({})
    assert get_config(default={})
    assert get_config(default="{}")
    assert get_config(default='{"a": 42}')


if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-24 02:53:54.804247
# Unit test for function configure
def test_configure():
    configure()

    from . import new_logger as logger_module
    import logging

    logging.shutdown()

    setattr(logger_module, 'getLogger', get_logger)
    config_file = os.path.join(__file__, 'logging.cfg')
    configure(config=[config_file])

    logger = get_logger(__name__)
    logger.debug('hello')
    logger.info('hi')
    logger.warning('warn')
    logger.error('err')
    logger.critical('crit')

    logging.shutdown()


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:54:07.377822
# Unit test for function get_config
def test_get_config():
    # config is not specified
    with pytest.raises(ValueError):
        get_config()
    # config is valid json
    cfg1 = get_config('{"version":1}')
    assert cfg1.get("version") == 1
    # config is valid yaml
    cfg2 = get_config("version: 1")
    assert cfg2.get("version") == 1
    # config is an invalid string
    with pytest.raises(ValueError):
        get_config("version :1")
    # config is valid json and env_var is set
    cfg3 = get_config(env_var="LOGGING", default='{"version":2}')
    assert cfg3.get("version") == 2
    # config is valid json and env_var is not set
    cfg4 = get_

# Generated at 2022-06-24 02:54:17.662463
# Unit test for function get_config

# Generated at 2022-06-24 02:54:23.961731
# Unit test for function get_config
def test_get_config():
    import yaml, json

    config = yaml.load("""
         version: 1
         formatters:
           simple:
             format: '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s'
             datefmt: '%Y-%m-%d %H:%M:%S'
         handlers:
           console:
             class: logging.StreamHandler
             formatter: colored
             level: DEBUG
         root:
           handlers: ['console']
           level: DEBUG
         loggers:
           requests:
             level: INFO
    """)


# Generated at 2022-06-24 02:54:28.479770
# Unit test for function logger_level
def test_logger_level():
    logger_level(get_logger(), logging.ERROR)
    with logger_level(get_logger(), logging.INFO):
        assert get_logger().level == logging.INFO
    assert get_logger().level == logging.ERROR


# Generated at 2022-06-24 02:54:38.320291
# Unit test for function get_config
def test_get_config():
    import json

    config = get_config(
        given='{"loggers": {"root": {"level": "INFO"}}}',
        env_var='TEST_LOGGING',
        default={'loggers': {'root': {'level': 'DEBUG'}}},
    )

    assert config == {"loggers": {"root": {"level": "INFO"}}}

    config = get_config(
        given=json.dumps({'loggers': {'root': {'level': 'INFO'}}}),
        env_var='TEST_LOGGING',
        default={'loggers': {'root': {'level': 'DEBUG'}}},
    )

    assert config == {"loggers": {"root": {"level": "INFO"}}}


# Generated at 2022-06-24 02:54:47.806043
# Unit test for function configure
def test_configure():
    from io import StringIO, BytesIO
    import sys
    import logging

    # Python 2 only
    _PyInfo.PY2 and setattr(StringIO, 'buffer', BytesIO)

    # stderr capturer
    stderr = sys.stderr
    sys.stderr = BytesIO()

    # Basic configuration
    configure()

    log = get_logger()
    log.debug('test2')
    # print(sys.stderr.getvalue())

    assert sys.stderr.getvalue()

    # Buffer flush
    sys.stderr.truncate(0)
    sys.stderr.seek(0)

    # Basic configuration

# Generated at 2022-06-24 02:54:54.006389
# Unit test for function getLogger
def test_getLogger():
    with logger_level(getLogger(), logging.DEBUG):
        log = getLogger()
        log.debug('debug message')
        log.info('info message')
        log.warning('warning message')
        log.error('error message')
        log.critical('critical message')

    with logger_level(getLogger(), logging.INFO):
        log = getLogger()
        log.debug('debug message')
        log.info('info message')
        log.warning('warning message')
        log.error('error message')
        log.critical('critical message')



# Generated at 2022-06-24 02:55:03.287359
# Unit test for function get_config
def test_get_config():
    # json string
    conf = '{"version": 1, "formatters": {"simple": {"format": "%(levelname)s|%(asctime)s|%(name)s|%(message)s"}}, "handlers": {"console": {"class": "logging.StreamHandler", "level": "DEBUG", "formatter": "simple", "stream": "ext://sys.stdout"}}, "root": {"level": "DEBUG", "handlers": ["console"]}}'
    assert get_config(config=conf) == json.loads(conf)

    # yaml string

# Generated at 2022-06-24 02:55:04.907876
# Unit test for function configure
def test_configure():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.info('test')

# Generated at 2022-06-24 02:55:08.152210
# Unit test for function getLogger
def test_getLogger():

    # create a log message
    log = get_logger()
    log.info('test')

    # create a log message for a different logger
    log2 = get_logger(__name__)
    log2.info('test2')



# Generated at 2022-06-24 02:55:09.680864
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert logger.name == 'kms_credential_cache'



# Generated at 2022-06-24 02:55:16.125926
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)

    # test if log is a logger instance
    assert isinstance(log, logging.Logger)

    # test if the logger name is correct
    assert log.name == __name__
    assert log.name == log.getEffectiveLevel()



# Generated at 2022-06-24 02:55:26.098212
# Unit test for function get_config

# Generated at 2022-06-24 02:55:33.521051
# Unit test for function get_config
def test_get_config():
    conf = get_config(default={'foo':1, 'bar':2})
    assert conf['foo'] == 1
    assert conf['bar'] == 2

    conf = get_config(config={'foo':1, 'bar':2})
    assert conf['foo'] == 1
    assert conf['bar'] == 2

    conf = get_config(config='{"foo":1, "bar":2}')
    assert conf['foo'] == 1
    assert conf['bar'] == 2

    conf = get_config(config="""
foo: 1
bar: 2
""")
    assert conf['foo'] == 1
    assert conf['bar'] == 2

    os.environ['TEST_LOGGING'] = '{"foo":1, "bar":2}'

# Generated at 2022-06-24 02:55:38.722133
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    with logger_level(log, logging.WARNING):
        log.warning('test')
        log.debug('test')
    log.info('test')

# Generated at 2022-06-24 02:55:42.994214
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger')

    # Case 1. Logging is disabled in debug mode.
    with logger_level(logger, logging.DEBUG):
        logger.debug('this message should be displayed')

    # Case 2. Log with level info
    logger.info('this message should be displayed')
    with logger_level(logger, logging.INFO):
        assert True

# Generated at 2022-06-24 02:55:52.597463
# Unit test for function get_config
def test_get_config():
    import json
    import os.path

    default_config = dict(
        version=1,
    )

    # Test plain config
    config = get_config(None, None, default_config)
    assert config == default_config

    # Test from env var
    os.environ['LOGGING'] = json.dumps(default_config)
    config = get_config(None, 'LOGGING', None)
    assert config == default_config

    # Test from file
    config = get_config(os.path.dirname(__file__) + '/logging.json')

    # Test invalid
    try:
        get_config()
        assert False
    except ValueError as e:
        assert str(e) == 'Invalid logging config: None'

# Generated at 2022-06-24 02:55:58.911333
# Unit test for function logger_level
def test_logger_level():
    from .testing import UnitTest

    class TestLoggerLevel(UnitTest):

        def _method(self):
            pass

        def test_something(self):
            with self.assertRaises(Exception):
                with logger_level(self.log, logging.CRITICAL):
                    self._method()
            # Log something after the context block
            self.log.info('test_logger_level')

    TestLoggerLevel().run()

# Generated at 2022-06-24 02:56:06.747666
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str, )
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes
    else:
        assert _PyInfo.string_types == (basestring, )
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str


# Generated at 2022-06-24 02:56:09.373200
# Unit test for function getLogger
def test_getLogger():
    """Test getLogger of LoggingManager."""
    logger = get_logger("test1")
    assert logger.level == logging.DEBUG
    logger.debug("getLogger")



# Generated at 2022-06-24 02:56:12.154725
# Unit test for function configure
def test_configure():
    # if you need a different configuration for your testing,
    # write a test_configure() method and it will be called
    # instead of this one.
    configure()
    logger = getLogger('mytestlogger')
    logger.info('test message')



# Generated at 2022-06-24 02:56:16.188145
# Unit test for function configure
def test_configure():
    if not os.environ.get("LOGGING", None):
        configure()
    log = get_logger("test")
    log.debug("test debug")
    log.info("test info")
    log.warning("test warning")
    log.error("test error")
    log.critical("test critical")


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:56:17.342696
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger("test_logger")
    logger.debug("This is a test message")



# Generated at 2022-06-24 02:56:20.226625
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert issubclass(_PyInfo.string_types, tuple)
    assert isinstance(_PyInfo.text_type(), str)
    assert isinstance(_PyInfo.binary_type(), str)
    assert not isinstance(_PyInfo.text_type(), str)
    assert not isinstance(_PyInfo.binary_type(), str)

# Generated at 2022-06-24 02:56:31.779330
# Unit test for function configure
def test_configure():
    class TestLogger(logging.Logger):
        """Subclass of logging.Logger class with extra attributes to check in tests."""

        def __init__(self, name, level=logging.NOTSET):
            logging.Logger.__init__(self, name, level)
            self.called = False

        def handle(self, record):
            self.called = True

    # get root logger
    root_logger = logging.getLogger()

    # clear handlers
    root_logger.handlers = []
    # remove any configured loggers
    # do not use `configured_loggers` to avoid importing other parts of this module
    # see: https://github.com/mozilla-services/mozetl/pull/3#issuecomment-337823372
    # configured_loggers = []
    configured

# Generated at 2022-06-24 02:56:32.672832
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True

# Generated at 2022-06-24 02:56:34.164462
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')


# Generated at 2022-06-24 02:56:39.061584
# Unit test for function get_config
def test_get_config():
    assert configure(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert configure(config='{"version": 1}') == {'version': 1}
    assert configure(config="""version: 1""") == {'version': 1}
    assert len(get_config()) == len(DEFAULT_CONFIG)

# Generated at 2022-06-24 02:56:48.195408
# Unit test for function get_config

# Generated at 2022-06-24 02:56:54.847394
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    assert log.level == logging.DEBUG
    assert len(log.handlers) == 1
    assert isinstance(log.handlers[0], logging.StreamHandler)
    assert log.handlers[0].level == logging.DEBUG
    assert isinstance(log.handlers[0].formatter, logging.Formatter)



# Generated at 2022-06-24 02:57:02.909291
# Unit test for function get_config
def test_get_config():
    with pytest.raises(TypeError):
        get_config(None, None)

    # given = None, env_var = None, default = None
    with pytest.raises(ValueError):
        get_config(None, None, None)

    # given = None, env_var = None, default = DEFAULT_CONFIG
    config = get_config(None, None, DEFAULT_CONFIG)
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.info('test')
    assert config == DEFAULT_CONFIG

    # given = DEFAULT_CONFIG, env_var = None, default = None
    config = get_config(DEFAULT_CONFIG, None, None)
    log = get_logger()

# Generated at 2022-06-24 02:57:06.134804
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)


# Generated at 2022-06-24 02:57:15.123238
# Unit test for function getLogger
def test_getLogger():
    with logger_level(logging.root, logging.CRITICAL):
        log = get_logger('test')
        assert log.level == logging.DEBUG

        log.debug('working')
        log.debug('crashing')

        try:
            raise Exception('blah')
        except Exception as e:
            log.exception(e)

        # The logger is now disabled because of the exception.
        # We need to clear it so it can be reenabled by the logger_level context manager.
        logging.root.handlers.clear()

        with logger_level(log, logging.CRITICAL):
            log.debug('inactive')
            
        with logger_level(log, logging.DEBUG):
            log.debug('activated')

        with logger_level(logging.root, logging.CRITICAL):
            log.debug

# Generated at 2022-06-24 02:57:22.056358
# Unit test for function get_config

# Generated at 2022-06-24 02:57:28.426554
# Unit test for function get_config

# Generated at 2022-06-24 02:57:33.280197
# Unit test for function logger_level
def test_logger_level():
    """Unit test for function logger_level"""
    log = getLogger('test_function')
    log.info('test_function')
    with logger_level(log, logging.NOTSET):
        log.info('test_function')
        with logger_level(log, logging.INFO):
            log.info('test_function')



# Generated at 2022-06-24 02:57:43.514923
# Unit test for function configure
def test_configure():
    import logging
    import re
    import StringIO
    import io
    import os

    if _PyInfo.PY2:
        file_object = StringIO.StringIO
    else:
        file_object = io.StringIO

    def check_message(msg):
        """
        >>> check_message('test\\n')
        True
        """
        pat = re.compile(r'INFO\s+[-.\d,]+\s+test')
        return bool(pat.match(msg))

    logger = logging.getLogger('mytest')

    with logger_level(logger, logging.DEBUG):
        with file_object() as f:
            stream = logging.StreamHandler(f)
            logger.addHandler(stream)
            logger.info('test %s', 1)
            msg = f.getvalue

# Generated at 2022-06-24 02:57:50.655764
# Unit test for function getLogger
def test_getLogger():
    # If we have not configured the logger for our module, it should be a root logger
    log = get_logger()
    assert logging.getLogger().name == log.name

    # If we pass in a name, it must be that name
    log = get_logger('test')
    assert log.name == 'test'

    # If we don't configure the logger, it must be a root logger
    # If we don't pass in a name, it must be the name of the module that called us
    # We assume that we are in the module `logging_util`
    log = get_logger()
    assert log.name == 'logging_util'

# Generated at 2022-06-24 02:57:55.160291
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug("logging in debug level")

if __name__ == '__main__':
    # Unit test for function get_logger
    get_logger().info('test1')

    # Unit test for function get_logger, passing 'name' in
    get_logger('foo').info('test2')

    # test_logger_level()

# Generated at 2022-06-24 02:57:57.958672
# Unit test for function configure
def test_configure():
    """
    testing configure function
    """
    import logging
    log = logging.getLogger(__name__)
    configure()
    log.info('test')

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:58:00.293748
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger(__name__)
    if logger.name == __name__:
        print('test getLogger ok')
    else:
        print('test getLogger fail')



# Generated at 2022-06-24 02:58:07.307533
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    # The default logging level should be DEBUG
    assert log.level == logging.DEBUG

    with logger_level(log, logging.INFO):
        # Check if the level has been set to INFO
        assert log.level == logging.INFO
        log.debug('This debug message should not be logged')
        log.info('This info message should be logged')

    # Check if the level has been restored after the context block
    assert log.level == logging.DEBUG
    log.debug('This debug message should be logged')



# Generated at 2022-06-24 02:58:13.179034
# Unit test for function getLogger
def test_getLogger():
    from datetime import datetime

    # Replace logger_level with a fake to get the log output
    import logging.config
    logging.config.logging._levelNames = {
        'CRITICAL': 50,
        'ERROR': 40,
        'WARNING': 30,
        'INFO': 20,
        'DEBUG': 10,
        'NOTSET': 0,
    }
    _DUMMY_STREAM = io.StringIO()
    logging.Logger.log = lambda inst, lvl, msg, args: _DUMMY_STREAM.write(msg % args + '\n')
    logging.Logger.addHandler = lambda inst, hdlr: None
    logging.Logger.removeHandler = lambda inst, hdlr: None

    l = getLogger()
    l.info('test')

# Generated at 2022-06-24 02:58:18.794563
# Unit test for function get_config
def test_get_config():
    try:
        get_config('{}')
    except ValueError as error:
        print(error)

    try:
        get_config('["foo", "bar"]')
    except ValueError as error:
        print(error)

    try:
        get_config('- foo\\n  bar:\n  - baz\\n  - qux')
    except ValueError as error:
        print(error)



# Generated at 2022-06-24 02:58:22.200655
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.string_types == (basestring,)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:58:28.341388
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2 is True
    assert _PyInfo().PY3 is False
    assert _PyInfo().string_types == (basestring,)
    assert _PyInfo().text_type == unicode
    assert _PyInfo().binary_type == str



# Generated at 2022-06-24 02:58:33.894952
# Unit test for function logger_level
def test_logger_level():
    """test_logger_level: Just tests that the contextmanager works"""
    logger = get_logger()
    logger.level = logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG

# Generated at 2022-06-24 02:58:34.992947
# Unit test for function getLogger
def test_getLogger():
    assert isinstance(get_logger(),logging.RootLogger)


# Generated at 2022-06-24 02:58:36.604593
# Unit test for function configure
def test_configure():
    print(logger)


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:58:47.332702
# Unit test for function get_config
def test_get_config():
    dict_config = dict(version=1,
                       formatters={'f': {'format': '%(asctime)s %(name)s'}},
                       handlers={'h': {'class': 'logging.NullHandler', 'formatter': 'f'}},
                       root={'handlers': ['h'], 'level': 'DEBUG'})
    string_config = '{"version": 1, "formatters": {"f": {"format": "%(asctime)s %(name)s"}}, "handlers": {"h": {"class": "logging.NullHandler", "formatter": "f"}}, "root": {"handlers": ["h"], "level": "DEBUG"}}'
    assert get_config(dict_config) == dict_config
    assert get_config(string_config) == dict_config



# Generated at 2022-06-24 02:58:48.914125
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    configure()
    logger.info('test')


# Generated at 2022-06-24 02:58:51.123880
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')



# Generated at 2022-06-24 02:58:56.372106
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('Should be printed')
    logger.debug('Should not be printed')

# Generated at 2022-06-24 02:59:00.421134
# Unit test for function get_config
def test_get_config():
    sys.stderr.write("\nRunning test_get_config")
    # Check if returned config is a dict
    if not isinstance(get_config(default = DEFAULT_CONFIG), dict):
        raise Exception("Returned config is not a dict")
    else:
        sys.stderr.write("\nPassed test_get_config")



# Generated at 2022-06-24 02:59:02.196080
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert logger is not None

test_getLogger()

# Generated at 2022-06-24 02:59:10.591816
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    >>> py_info = _PyInfo()
    >>> py_info.PY2
    True

    >>> py_info = _PyInfo()
    >>> py_info.PY3
    False

    >>> py_info = _PyInfo()
    >>> py_info.string_types
    (<class 'basestring'>,)

    >>> py_info = _PyInfo()
    >>> py_info.text_type
    <class 'unicode'>

    >>> py_info = _PyInfo()
    >>> py_info.binary_type
    <class 'str'>
    """

# Generated at 2022-06-24 02:59:15.435280
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)

test__PyInfo()

# Generated at 2022-06-24 02:59:20.864674
# Unit test for function getLogger
def test_getLogger():
    try:
        from contextlib import redirect_stdout
        from io import StringIO
        out = StringIO()
        log = get_logger('test')
        with redirect_stdout(out):
            log.debug('hello world')
            log.error('hello world')
        assert 'DEBUG' in out.getvalue()
        assert 'ERROR' in out.getvalue()
    except ImportError:
        pass

# Generated at 2022-06-24 02:59:25.771552
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    _ = _PyInfo()
    _ = _PyInfo.PY2
    _ = _PyInfo.PY3
    _ = _PyInfo.string_types
    _ = _PyInfo.text_type
    _ = _PyInfo.binary_type

# Generated at 2022-06-24 02:59:28.328477
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert isinstance(logger, logging.Logger)


if __name__ == "__main__":
    print("Running doctest")
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:59:31.898420
# Unit test for function configure
def test_configure():
    configure(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)


# Generated at 2022-06-24 02:59:40.663477
# Unit test for function get_config
def test_get_config():
    # Test loading configuration from file
    config = get_config('tests/config.json')

# Generated at 2022-06-24 02:59:50.696082
# Unit test for function get_config
def test_get_config():
    import json
    import unittest

    json_config = '{"version": 1, "disable_existing_loggers": false}'
    yaml_config = 'version: 1\ndisable_existing_loggers: false'

    class TestGetConfig(unittest.TestCase):
        def test_invalid_config(self):
            with self.assertRaises(ValueError):
                get_config(config=None)

        def test_dict_config(self):
            self.assertEqual(
                get_config(config=DEFAULT_CONFIG), DEFAULT_CONFIG
            )

        def test_json_config(self):
            self.assertEqual(
                get_config(config=json_config), json.loads(json_config)
            )


# Generated at 2022-06-24 02:59:59.108110
# Unit test for function get_config
def test_get_config():
    # Test 1
    result = get_config(None, None, {'a': 1})
    assert result == {'a': 1}

    # Test 2
    result = get_config(None, 'LOGGING', None)
    assert result == None

    # Test 3
    result = get_config('{"a": 1}', None, None)
    assert result == {'a': 1}

    # Test 4
    result = get_config("a: 1", None, None)
    assert result == {'a': 1}

    # Test 5
    try:
        result = get_config("a xx 1", None, None)
    except ValueError:
        pass

    # Test 6
    try:
        result = get_config("a xx 1", None, None)
    except ValueError:
        pass

# Generated at 2022-06-24 03:00:00.241789
# Unit test for function configure
def test_configure():
    configure()
    logging.debug('test')
    # logger_test = logging.getLogger(__name__)



# Generated at 2022-06-24 03:00:04.842579
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert not _PyInfo.PY3

# Generated at 2022-06-24 03:00:13.466246
# Unit test for function get_config
def test_get_config():
    # No config
    assert get_config() == None
    # Invalid config
    assert get_config(config='not a dictionary') == None
    # Valid config

# Generated at 2022-06-24 03:00:17.234945
# Unit test for function getLogger
def test_getLogger():
    log = get_logger('mylogger')
    print(log)
    assert log == logging.getLogger('mylogger')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:00:20.283925
# Unit test for function get_config
def test_get_config():
    assert get_config(default="") == ""
    assert get_config(env_var="LOGGING", default="") == ""
    os.environ['LOGGING'] = "test"
    assert get_config(env_var="LOGGING", default="") == "test"
    assert get_config(env_var="LOGGING", default="") == "test"


# Generated at 2022-06-24 03:00:24.699927
# Unit test for function get_config
def test_get_config():
    import json
    import unittest

    class Test(unittest.TestCase):
        def test_json(self):
            config = get_config(config='{"test": "test"}')
            self.assertEqual(config, {"test": "test"})

        def test_yaml(self):
            config = get_config(config='test: "test"')
            self.assertEqual(config, {"test": "test"})

        def test_none(self):
            with self.assertRaises(ValueError):
                get_config()

        def test_bad_json(self):
            with self.assertRaises(ValueError):
                get_config(config='{bad: "json"!}')

    unittest.main()

# Generated at 2022-06-24 03:00:30.511366
# Unit test for function get_config
def test_get_config():
    import json
    assert get_config() == DEFAULT_CONFIG

    assert get_config("") == {}

    assert get_config("{}") == {}

    assert get_config({}) == {}

    s = json.dumps({"a": 1, "b": 2})
    assert get_config(s) == {"a": 1, "b": 2}


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:00:40.319064
# Unit test for function getLogger
def test_getLogger():
    from logging import CRITICAL, FATAL, ERROR, WARNING, INFO, DEBUG, NOTSET
    import random
    import time
    random.seed()
    logger_list = []
    for i in range(0, 10):
        name = 'test_getLogger.%d.%d' % (i, time.time())
        logger_list.append(logger.getLogger(name))
    print('test_getLogger(): logging.CRITICAL=%d, logging.FATAL=%d, logging.ERROR=%d, logging.WARNING=%d, logging.INFO=%d, logging.DEBUG=%d, logging.NOTSET=%d' % (CRITICAL, FATAL, ERROR, WARNING, INFO, DEBUG, NOTSET))

# Generated at 2022-06-24 03:00:45.760290
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    assert log is not None
    log = getLogger(__name__)
    assert log is not None


test_getLogger()

if __name__ == '__main__':
    #logging.basicConfig()
    log = logging.getLogger(__file__)
    log.setLevel(logging.DEBUG)

    log.info('hello world')

    log.debug('this is a %s %s %s', 'debug', 2, {'message': 3.3})

    log.info('this is an %s %s %s', 'info', 4, {'message': 5.5})

    log.warning('this is a %s %s %s', 'warning', 6, {'message': 7.7})


# Generated at 2022-06-24 03:00:49.673243
# Unit test for function get_config
def test_get_config():
    assert get_config({'test': 'test'}) == {'test': 'test'}
    assert get_config('{"test": "test"}') == {'test': 'test'}
    assert get_config('test: !str test') == {'test': 'test'}
    assert get_config() == DEFAULT_CONFIG
    assert get_config(default={'test': 'test'}) == {'test': 'test'}
    assert get_config(default={'test': 'test'}) == {'test': 'test'}

# Generated at 2022-06-24 03:00:51.999396
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py_info = _PyInfo()
    assert py_info.PY2 is True or py_info.PY3 is True
    assert py_info.PY2 != py_info.PY3


# Generated at 2022-06-24 03:00:58.180312
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config() == DEFAULT_CONFIG

    assert json.loads(str(get_config(json.dumps(DEFAULT_CONFIG)))) == DEFAULT_CONFIG
    assert yaml.load(str(get_config(yaml.dump(DEFAULT_CONFIG)))) == DEFAULT_CONFIG



# Generated at 2022-06-24 03:01:05.675037
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert issubclass(_PyInfo.string_types, str)
    assert not issubclass(_PyInfo.string_types, bytes)
    assert issubclass(_PyInfo.binary_type, bytes)
    assert not issubclass(_PyInfo.binary_type, str)
    assert issubclass(_PyInfo.text_type, str)
    assert not issubclass(_PyInfo.text_type, bytes)


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 03:01:07.170609
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('Hello World')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:01:08.303419
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info("test get logger")


# Generated at 2022-06-24 03:01:09.381732
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:01:12.422857
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger(__name__)
    assert logger is not None
    assert logger.name == __name__

    logger.info('test_getLogger')
    logger.debug('debug_message')


# Generated at 2022-06-24 03:01:15.663998
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert isinstance(logger, logging.Logger)


# Generated at 2022-06-24 03:01:20.970068
# Unit test for function getLogger
def test_getLogger():
    def my_method2():
        return getLogger()

    def my_method():
        try:
            return getLogger()
        except Exception:
            return my_method2()

    log = my_method()

    log.info('testing getLogger')

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 03:01:30.754524
# Unit test for function configure

# Generated at 2022-06-24 03:01:33.525740
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.debug("test")



# Generated at 2022-06-24 03:01:40.125498
# Unit test for function get_config
def test_get_config():
    '''
    Get config with bare string
    '''
    cfg = get_config('{"version": 1}')
    assert(isinstance(cfg, dict))
    assert(cfg == {"version": 1})

    '''
    Get config with json formatted string.
    '''
    cfg = get_config('{"version": 1}\n')
    assert(isinstance(cfg, dict))
    assert(cfg == {"version": 1})

    '''
    Get config with yaml formatted string.
    '''
    cfg = get_config('version: 1\n')
    assert(isinstance(cfg, dict))
    assert(cfg == {'version': 1})

    '''
    Get config with json formatted file-like object.
    '''
    import io


# Generated at 2022-06-24 03:01:41.046960
# Unit test for function getLogger
def test_getLogger():
    getLogger()


# Generated at 2022-06-24 03:01:46.649927
# Unit test for function getLogger
def test_getLogger():
    import inspect
    import logging

    if inspect.stack()[1][0].f_globals["__name__"] != "__main__":
        return

    import os, sys
    import logging

    log = getLogger(__name__)
    log.info("test")
    log.debug("test")



# Generated at 2022-06-24 03:01:56.048051
# Unit test for function get_config
def test_get_config():
    # Test for bare config
    config = get_config(config="DEBUG")
    assert config == "DEBUG"

    # Test for env var for json string
    os.environ['LOGGING'] = '{"version": 1, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "colored", "level": "DEBUG"}}}'
    config = get_config(env_var='LOGGING')
    assert config == {"version": 1, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "colored", "level": "DEBUG"}}}

    # Test for yaml string
    config = get_config(config="""
            version: 1
            handlers:
                console:
                    class: logging.StreamHandler
                    formatter: colored
                    level: DEBUG
            """)


# Generated at 2022-06-24 03:01:57.443913
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    assert logger.name == __name__

# Generated at 2022-06-24 03:02:00.261394
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')
    log = getLogger('test2')
    log.info('test2')
    log.warn('test2')
    log.error('test2')
    log.critical('test2')

# Generated at 2022-06-24 03:02:06.973182
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 ^ _PyInfo.PY3
    assert _PyInfo.text_type in _PyInfo.string_types
    assert _PyInfo.binary_type in _PyInfo.string_types
    assert not isinstance(b'abc', _PyInfo.string_types)
    assert not isinstance(u'abc', _PyInfo.string_types)
    assert isinstance('abc', _PyInfo.string_types)
    assert isinstance(b'abc', _PyInfo.binary_type)
    assert isinstance(u'abc', _PyInfo.text_type)



# Generated at 2022-06-24 03:02:10.350144
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    p = _PyInfo()
    assert p.PY2
    assert not p.PY3


if __name__ == "__main__":
    import doctest

    fail, _ = doctest.testmod()
    if fail:
        sys.exit(1)

    test__PyInfo()

# Generated at 2022-06-24 03:02:15.284657
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    configure(default=DEFAULT_CONFIG)
    logger.info('test')


# Generated at 2022-06-24 03:02:18.426991
# Unit test for function getLogger
def test_getLogger():
    configure()
    assert getLogger('logger_name').level == logging.NOTSET
    assert getLogger().level == logging.NOTSET
    assert getLogger().name == 'logger_name'
    assert getLogger('logger_name_1').name == 'logger_name_1'


# Generated at 2022-06-24 03:02:19.331357
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info("test_getLogger pass")



# Generated at 2022-06-24 03:02:24.736211
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    if sys.version_info[0] == 2:
        unittest.TestCase.assertCountEqual = unittest.TestCase.assertItemsEqual

    class Test_pyinfo(unittest.TestCase):
        def test_string_types(self):
            self.assertCountEqual(_PyInfo().string_types, (basestring,))
            self.assertCountEqual(_PyInfo().binary_type, (str,))
            self.assertCountEqual(_PyInfo().text_type, (unicode,))
            self.assertTrue(_PyInfo().PY2)
            self.assertFalse(_PyInfo().PY3)


# Generated at 2022-06-24 03:02:26.499346
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info("getLogger test")



# Generated at 2022-06-24 03:02:37.616174
# Unit test for function configure
def test_configure():
    from collections import defaultdict
    import logging.config

    file_name = 'basic.log'

# Generated at 2022-06-24 03:02:45.277314
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print("test class _PyInfo")
    info = _PyInfo()
    print("PY2 = {!r}".format(info.PY2))
    print("PY3 = {!r}".format(info.PY3))
    print("string_types = {!r}".format(info.string_types))
    print("text_type = {!r}".format(info.text_type))
    print("binary_type = {!r}".format(info.binary_type))
    assert info.PY2 or info.PY3
    assert info.string_types != None
    assert info.text_type != None
    assert info.binary_type != None



# Generated at 2022-06-24 03:02:54.724844
# Unit test for function logger_level
def test_logger_level():
    """ Usage:
    >>> test_logger_level()
    """
    import logging
    import colorlog
    from picopayments_server.util import logger_level
    from colorlog import ColoredFormatter
    logger = logging.getLogger(__name__)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(ColoredFormatter(
        '%(log_color)s'
        '%(levelname)s:%(name)s:%(message)s'
        '%(reset)s',
        log_colors={
            'DEBUG': 'bold_black',
            'INFO': 'blue',
            'WARNING': 'yellow',
            'ERROR': 'red',
            'CRITICAL': 'bold_red',
        }))


# Generated at 2022-06-24 03:03:02.713290
# Unit test for function get_config
def test_get_config():
    """
    >>> test_get_config()
    """
    config_str = json.dumps({'formatters': {'simple': {
            'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s',
            'datefmt': '%Y-%m-%d %H:%M:%S'
        }}})

    config = get_config(config_str)

    assert isinstance(config, dict)

# Generated at 2022-06-24 03:03:12.456407
# Unit test for function configure
def test_configure():
    import tempfile
    import os
    import json
    import yaml
    from logging.config import dictConfig
    default_config = DEFAULT_CONFIG
    # Test invalid config
    config = '{"version": 1, "foo": "bar"}'
    with pytest.raises(ValueError):
        get_config(config)

    # Test valid json config

# Generated at 2022-06-24 03:03:15.277865
# Unit test for function get_config
def test_get_config():
    # Get default config using function
    config = get_config()
    assert(type(config) == dict)
    assert('version' in config)
    assert('disable_existing_loggers' in config)
    assert('formatters' in config)
    assert('handlers' in config)
    assert('root' in config)
    assert('loggers' in config)

# Generated at 2022-06-24 03:03:17.909843
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()

    #print(log)
    log.info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 03:03:27.670025
# Unit test for function get_config
def test_get_config():
    # given is string
    test_json = '{"version": 1, "disable_existing_loggers": False, "formatters": {"simple": "hello"}}'
    result = get_config(config=test_json)
    assert result == {'version': 1, 'disable_existing_loggers': False, 'formatters': {'simple': 'hello'}}

    # given is json
    test_json = {"version": 1, "disable_existing_loggers": False, "formatters": {"simple": "hello"}}
    result = get_config(config=test_json)
    assert result == {'version': 1, 'disable_existing_loggers': False, 'formatters': {'simple': 'hello'}}

    # given is yaml

# Generated at 2022-06-24 03:03:35.063370
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    test_config = json.dumps(DEFAULT_CONFIG)
    test_config_2 = json.dumps({"version": 1})
    test_config_3 = yaml.dump(DEFAULT_CONFIG)
    test_config_4 = yaml.dump({"version": 1})

    assert(get_config(test_config) == DEFAULT_CONFIG)
    assert(get_config(test_config_2) == {"version": 1})
    assert(get_config(test_config_3) == DEFAULT_CONFIG)
    assert(get_config(test_config_4) == {"version": 1})