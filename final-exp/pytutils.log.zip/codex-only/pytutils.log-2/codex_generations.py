

# Generated at 2022-06-24 02:53:36.702898
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG, 'basic config'
    assert get_config(1) == 1, 'num config'
    assert get_config(default=1) == 1, 'num default'

    DT = dict(test=1)
    assert get_config(default=DT) == DT, 'dict def'

    assert get_config(config=DT) == DT, 'dict config'

    # test env var
    import os
    import json
    import yaml
    import textwrap

    os.environ['LOGGING'] = '1'
    assert get_config(env_var='LOGGING') == 1, 'num env var'

    # Dict
    PY2 = sys.version_info[0] == 2

# Generated at 2022-06-24 02:53:41.987168
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert not _PyInfo.PY3
    assert isinstance('str', _PyInfo.string_types)
    assert isinstance(u'unicode', _PyInfo.string_types)
    assert not isinstance(123, _PyInfo.string_types)
    assert _PyInfo.text_type == type(u'unicode')
    assert _PyInfo.binary_type == type('str')


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-24 02:53:47.426935
# Unit test for function configure
def test_configure():
    """Test Command
    $ py.test -v --cov=saltchannel --cov-report term-missing --pep8 saltchannel/
    """

    log = logging.getLogger(__name__)
    configure()
    log.info('test')
    assert 1 == 1  # to pass the test

# Generated at 2022-06-24 02:53:52.894926
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.text_type == unicode
    assert _PyInfo.binary_type == str


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:54:01.389994
# Unit test for function getLogger
def test_getLogger():
    import unittest

    class GetLoggerTestCase(unittest.TestCase):

        def setUp(self):
            self.logger = get_logger(__name__)

        def test_get_logger_handlers(self):
            self.assertEqual(len(self.logger.handlers), 1)
            self.assertEqual(self.logger.level, logging.DEBUG)

        def test_get_logger_level(self):
            logging.getLogger('requests').setLevel(logging.NOTSET)
            self.assertEqual(logging.getLogger('requests').level, logging.NOTSET)

        def test_get_logger_root_level(self):
            self.assertEqual(logging.getLogger().level, logging.DEBUG)

    # This

# Generated at 2022-06-24 02:54:03.370524
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('logger_level')

# Generated at 2022-06-24 02:54:04.626630
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('log line')

# Generated at 2022-06-24 02:54:09.034649
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    log.setLevel(logging.INFO)

    with logger_level(log, logging.DEBUG):
        log.debug('debug message')
        assert True

    with logger_level(log, logging.INFO):
        log.debug('debug message')
        assert False


# Generated at 2022-06-24 02:54:12.747605
# Unit test for function getLogger
def test_getLogger():
    """
    >>> getLogger()
    <logging.RootLogger object at 0x7f5a68a5e5d0>

    >>> getLogger('test')
    <logging.Logger object at 0x7f5a68a5e610>
    """


# Generated at 2022-06-24 02:54:18.756729
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger("MyLogger")
    assert type(logger) == logging.Logger
    logger.info("test message")
    logger = get_logger("")
    assert type(logger) == logging.Logger
    logger.info("test message")


if __name__ == '__main__':
    raise SystemExit(
        "This library is not meant to be executed directly."
    )

# Generated at 2022-06-24 02:54:25.419199
# Unit test for function configure
def test_configure():
    configure()
    public_logger = get_logger()
    public_logger.info('test')
    configure(None, None, {'version': 1})
    public_logger_1 = get_logger()
    public_logger_1.info('test')

# Generated at 2022-06-24 02:54:29.080640
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    assert log.name == "discover_service.log"

    log.debug("test log getLogger")

# Generated at 2022-06-24 02:54:35.168711
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert "basestring" in dir(sys.modules["__builtin__"])
    assert "basestring" not in dir(sys.modules["builtins"])



# Generated at 2022-06-24 02:54:43.488438
# Unit test for function logger_level
def test_logger_level():
    from io import StringIO
    from contextlib import contextmanager

    cfg = dict(
        version=1,
        disable_existing_loggers=False,
        formatters={
            'colored': {
                '()': 'colorlog.ColoredFormatter',
                'format': '%(log_color)s%(message)s%(reset)s',
            },
        },
        handlers={
            'stringio': {
                'class': 'logging.StreamHandler',
                'formatter': 'colored',
                'stream': 'ext://sys.stdout',
                'level': logging.DEBUG,
            },
        },
        root=dict(handlers=['stringio'], level=logging.DEBUG),
    )

    logging.config.dictConfig(cfg)

# Generated at 2022-06-24 02:54:44.376416
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    _PyInfo()



# Generated at 2022-06-24 02:54:52.389460
# Unit test for function getLogger
def test_getLogger():
    """
    >>> import logging
    >>> logging.getLogger().propagate = False  # So that we don't get logs from other modules
    >>> log = getLogger()
    >>> log.info('test')
    >>> log.handlers[0].stream.getvalue().rstrip()
    '[12:00:00] [logging_utils/1] test  @test_getLogger:32 #INFO'
    """
    pass

if __name__ == '__main__':
    import doctest
    import sys
    result = doctest.testmod(sys.modules[__name__])
    print("-" * 50)
    print("%s tests of %s passed." % (result.attempted - result.failed, result.attempted))

# Generated at 2022-06-24 02:55:01.666938
# Unit test for function get_config
def test_get_config():
    # Test normal dict
    cfg = dict(key = 'value')
    cfg = get_config(cfg)
    assert isinstance(cfg, dict)
    assert cfg['key'] == 'value'

    # Test JSON dict
    cfg = '{"key": "value"}'
    cfg = get_config(cfg)
    assert isinstance(cfg, dict)
    assert cfg['key'] == 'value'

    # Test yaml dict
    cfg = 'key: value\n'
    cfg = get_config(cfg)
    assert isinstance(cfg, dict)
    assert cfg['key'] == 'value'


# Generated at 2022-06-24 02:55:07.513318
# Unit test for function configure
def test_configure():
    logging.shutdown()
    test_config = {'version': 1,
                   'disable_existing_loggers': False,
                   'formatters': {'verbose': {'format': '%(levelname)s %(asctime)s %(module)s %(process)d %(thread)d %(message)s'}},
                   'handlers': {'console': {'level': 'DEBUG',
                                            'class': 'logging.StreamHandler',
                                            'formatter': 'verbose'}},
                   'loggers': {'': {'handlers': ['console'],
                                    'level': 'DEBUG',
                                    'propagate': True}}}
    configure()
    test_logger = get_logger()
    assert test_logger.handlers[0].formatter._fmt == DE

# Generated at 2022-06-24 02:55:09.888223
# Unit test for function getLogger
def test_getLogger():
    f = open('test.txt', 'w')
    sys.stdout = f
    getLogger('test').info('test')
    getLogger('test').error('test')
    getLogger('test').debug('test')
    getLogger('test').warning('test')
    getLogger('test').critical('test')
    f.close()



# Generated at 2022-06-24 02:55:17.624809
# Unit test for function configure
def test_configure():
    """
    >>> configure()
    >>> configure(config=DEFAULT_CONFIG)
    >>> import json
    >>> configure(config=json.dumps(DEFAULT_CONFIG))
    >>> print(os.environ.get('LOGGING'))
    >>> os.environ['LOGGING'] = json.dumps(DEFAULT_CONFIG)
    >>> configure(env_var='LOGGING')
    >>> del os.environ['LOGGING']
    """



# Generated at 2022-06-24 02:55:24.416626
# Unit test for function getLogger
def test_getLogger():
    import logging

    log = getLogger()
    log.setLevel(logging.DEBUG)
    log.info("Test getLogger")

    # Set log output
    log2 = getLogger("output")
    log2.setLevel(logging.DEBUG)
    log2.info("Test getLogger2")

# Generated at 2022-06-24 02:55:28.930738
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert (_PyInfo.PY2 or _PyInfo.PY3), '_PyInfo.PY2 or _PyInfo.PY3'

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:55:37.928815
# Unit test for function get_config
def test_get_config():
    # type: () -> None
    from nose.tools import assert_equal, assert_raises
    from json import loads
    from yaml import load
    from collections import OrderedDict

    cfg_dict = DEFAULT_CONFIG

# Generated at 2022-06-24 02:55:39.127043
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')



# Generated at 2022-06-24 02:55:49.748977
# Unit test for function configure
def test_configure():
    import json
    assert logging.DEBUG == 10
    assert logging.INFO == 20

    # No config given, no logging
    target_config = json.loads(json.dumps(DEFAULT_CONFIG))
    configure(config=None, env_var=None, default=None)
    assert target_config == json.loads(json.dumps(logging.Logger.manager.loggerDict))

    # Given configuration, set desired logging
    configure(config=target_config, env_var=None, default=None)
    assert target_config == json.loads(json.dumps(logging.Logger.manager.loggerDict))

    # Given configuration, override and set desired logging
    target_config['loggers']['requests']['level'] = logging.DEBUG

# Generated at 2022-06-24 02:55:53.125343
# Unit test for function configure
def test_configure():
    logging.shutdown()
    configure(default=None)
    log = logging.getLogger()
    log.info('test')

# Generated at 2022-06-24 02:56:00.334987
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()

    assert isinstance(pyinfo.string_types, tuple)
    if pyinfo.PY2:
        assert pyinfo.string_types == (basestring,)
        assert isinstance(pyinfo.text_type, unicode)
        assert isinstance(pyinfo.binary_type, str)
    if pyinfo.PY3:
        assert pyinfo.string_types == (str,)
        assert isinstance(pyinfo.text_type, str)
        assert isinstance(pyinfo.binary_type, bytes)

# Generated at 2022-06-24 02:56:06.447138
# Unit test for function getLogger
def test_getLogger():
    # Initialize log
    assert (len(_CONFIGURED) == 0)
    # Check get logger without name
    get_logger()
    assert (len(_CONFIGURED) == 1)
    # Check get logger with name
    get_logger('test')
    assert (len(_CONFIGURED) == 2)

# Generated at 2022-06-24 02:56:09.407982
# Unit test for function getLogger
def test_getLogger():
    logging.basicConfig(format='%(asctime)s | %(message)s', level=logging.DEBUG)
    log = get_logger('test_getLogger')
    log.info('test_getLogger()')

# Generated at 2022-06-24 02:56:10.780547
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py = _PyInfo()
    assert py.PY2 or py.PY3



# Generated at 2022-06-24 02:56:15.920411
# Unit test for function logger_level
def test_logger_level():
    import time
    logging.getLogger().setLevel(logging.DEBUG)
    logging.getLogger().info("Should appear")
    with logger_level(logging.getLogger(), logging.WARNING):
        logging.getLogger().info("Should NOT appear")
        time.sleep(0.5)
        logging.getLogger().warning("Should appear")
    time.sleep(0.5)
    logging.getLogger().info("Should appear")
    print("TEST_PASSED")

test_logger_level()

# Generated at 2022-06-24 02:56:17.874893
# Unit test for function get_config
def test_get_config():
    assert get_config(default={'a': 1}) == {'a': 1}
    assert type(get_config(default={'a': 1})) == dict

# Generated at 2022-06-24 02:56:19.115537
# Unit test for function getLogger
def test_getLogger():
    """
    >>> log = get_logger()
    >>> log.info('test')
    """

# Generated at 2022-06-24 02:56:21.160585
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print(inspect.getmembers(_PyInfo))


if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 02:56:26.312915
# Unit test for function get_config
def test_get_config():
    assert get_config({'a': 1}, None, None) == {'a': 1}
    assert get_config('{"a": 1}', None, None) == {'a': 1}
    assert get_config('a: 1', None, None) == {'a': 1}

# Generated at 2022-06-24 02:56:27.732346
# Unit test for function configure
def test_configure():
    assert True

if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-24 02:56:33.455764
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert isinstance('', _PyInfo.string_types)
        assert isinstance(u'', _PyInfo.string_types)
        assert not isinstance(b'', _PyInfo.string_types)
    else:
        assert isinstance('', _PyInfo.string_types)
        assert not isinstance(b'', _PyInfo.string_types)


# Generated at 2022-06-24 02:56:37.826931
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')
    log = getLogger('test2')
    log.info('test2')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:56:48.145650
# Unit test for function configure
def test_configure():
    import tempfile
    import yaml
    from io import StringIO

    config = get_config(default=None)
    assert config is None
    config = get_config(env_var=None, default={'1': 1})
    assert config == {'1': 1}


# Generated at 2022-06-24 02:56:50.916877
# Unit test for function configure
def test_configure():
    """
    >>> configure()

    """
    configure()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:56:55.687025
# Unit test for function getLogger
def test_getLogger():
    """
    Tests:
        >>> from .log import getLogger
        >>> log = getLogger()
        >>> log.info('test')
        >>> log = getLogger('test2')
        >>> log.info('test2')
    
    """
    pass



# Generated at 2022-06-24 02:56:58.259217
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test_getLogger')
    logger.warning('a warning for test getLogger')


# Generated at 2022-06-24 02:57:10.140297
# Unit test for function get_config
def test_get_config():
    # Bare
    config = 'foo'
    result = get_config(config)
    assert result == 'foo'

    # dict
    config = dict(a='foo')
    result = get_config(config)
    assert result == {'a': 'foo'}

    # json
    config = '{"a": "foo"}'
    result = get_config(config)
    assert result == {'a': 'foo'}

    # yaml
    config = 'a: foo'
    result = get_config(config)
    assert result == {'a': 'foo'}

    # json
    config = '{"a": "foo"}'
    result = get_config(config, default='a')
    assert result == 'a'

    # yaml
    config = 'a: foo'
    result = get_

# Generated at 2022-06-24 02:57:14.005427
# Unit test for function getLogger
def test_getLogger():
    """
    >>> log = getLogger()
    >>> log.info('test')
    >>> log = getLogger('test2')
    >>> log.info('test2')
    """

    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:57:19.682725
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    if pyinfo.PY2:
        assert isinstance('foo', pyinfo.string_types)
        assert isinstance(b'foo', pyinfo.binary_type)
    elif pyinfo.PY3:
        assert isinstance('foo', pyinfo.string_types)
        assert isinstance(b'foo', pyinfo.binary_type)
    else:
        raise AssertionError('PyInfo is not neither py2 nor py3')

# Generated at 2022-06-24 02:57:25.587449
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.INFO):
        log.debug('Test')
        log.info('Test')
        log.warning('Test')
        log.error('Test')
        log.critical('Test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:57:33.503751
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('test_logger_level')
    assert log.level == logging.NOTSET

    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
        log.debug('hello')

    assert log.level == logging.NOTSET

if __name__ == '__main__':
    print('Running unit tests')
    configure()
    test_logger_level()
    print('Tests passed')

# Generated at 2022-06-24 02:57:41.160069
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert type(_PyInfo.string_types[0]) == type('string')
    assert type(_PyInfo.text_type) == type('string')
    assert type(_PyInfo.binary_type) == type(b'string')

# Generated at 2022-06-24 02:57:47.873017
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    configure(default=dict(root=dict(level=logging.INFO)))
    assert logger.isEnabledFor(logging.INFO)
    assert not logger.isEnabledFor(logging.DEBUG)
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.INFO)
        assert logger.isEnabledFor(logging.DEBUG)
    assert logger.isEnabledFor(logging.INFO)
    assert not logger.isEnabledFor(logging.DEBUG)



# Generated at 2022-06-24 02:57:55.428904
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert isinstance(u'', _PyInfo.text_type)
        assert isinstance('', _PyInfo.string_types)
        assert isinstance('', _PyInfo.binary_type)
    elif _PyInfo.PY3:
        assert isinstance('', _PyInfo.text_type)
        assert isinstance('', _PyInfo.string_types)
        assert not isinstance('', _PyInfo.binary_type)
        assert isinstance(b'', _PyInfo.binary_type)
    else:
        raise Exception("Unknow case")



# Generated at 2022-06-24 02:57:58.510869
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('test_logger_level')
    with logger_level(log, logging.DEBUG):
        log.debug("This is a test.")
        log.debug("This is a test.")
    log.debug("This is a test.")


# Generated at 2022-06-24 02:58:03.348611
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    _pyinfo = _PyInfo()
    assert type(_pyinfo.PY2) == bool
    assert type(_pyinfo.PY3) == bool
    assert type(_pyinfo.string_types) == tuple
    assert type(_pyinfo.binary_type) == type
    assert type(_pyinfo.text_type) == type



# Generated at 2022-06-24 02:58:08.014899
# Unit test for function getLogger
def test_getLogger():
    """
    Test for getLogger

    >>> log = getLogger()
    >>> log.info('test')

    >>> log = getLogger('test2')
    >>> log.info('test2')

    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:58:17.133894
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == sys.version_info[0] == 2
    assert pyinfo.PY3 == sys.version_info[0] == 3
    if pyinfo.PY3:
        assert pyinfo.string_types == (str,)
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
    else:
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str



# Generated at 2022-06-24 02:58:21.526681
# Unit test for function configure
def test_configure():
    configure(default=DEFAULT_CONFIG)
    log = logging.getLogger(__name__)
    log.info('test')

# Generated at 2022-06-24 02:58:23.930541
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    assert log.name == 'logexample'
    assert log.level == logging.DEBUG


# Generated at 2022-06-24 02:58:31.141955
# Unit test for function get_config
def test_get_config():
    config_dict = get_config(default=DEFAULT_CONFIG)
    assert 'version' in config_dict.keys()
    assert 'disable_existing_loggers' in config_dict.keys()
    assert config_dict['disable_existing_loggers'] is False
    assert 'formatters' in config_dict.keys()
    assert 'colored' in config_dict['formatters'].keys()
    assert 'simple' in config_dict['formatters'].keys()
    assert 'handlers' in config_dict.keys()
    assert 'console' in config_dict['handlers'].keys()
    assert config_dict['handlers']['console']['class'] == 'logging.StreamHandler'
    assert config_dict['handlers']['console']['formatter'] == 'colored'

# Generated at 2022-06-24 02:58:39.658959
# Unit test for function get_config

# Generated at 2022-06-24 02:58:49.041036
# Unit test for function get_config
def test_get_config():
    # json format
    config = get_config(default='{"root":{"level":"DEBUG","handlers":"console"},"loggers":{"root":{"level":"DEBUG","handlers":"console"}}}')
    assert(config['root']['level'] == 'DEBUG')
    assert(config['root']['handlers'] == ['console'])
    assert(config['loggers']['root']['level'] == 'DEBUG')
    assert(config['loggers']['root']['handlers'] == ['console'])

    # yaml format
    config = get_config(default="""root:
  level: DEBUG
  handlers: console
loggers:
  root:
    level: DEBUG
    handlers: console
""")
    assert(config['root']['level'] == 'DEBUG')

# Generated at 2022-06-24 02:58:56.180288
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    inst = _PyInfo()
    print(inst._PyInfo__PY2)
    print(inst._PyInfo__PY3)
    print(inst._PyInfo__string_types)
    print(inst._PyInfo__binary_type)
    print(inst._PyInfo__text_type)


if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 02:59:02.763699
# Unit test for function configure
def test_configure():
    cfg = get_config(
        config='{"version": 1, "formatters": {"simple": {"format": "[%(asctime)s] [%(name)s/%(process)d] %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%H:%M:%S"}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": 10}}, "root": {"handlers": ["console"], "level": 10}, "loggers": {"requests": {"level": 8}}}',
        env_var='LOGGING', default=DEFAULT_CONFIG
    )

    logging.config.dictConfig(cfg)
    log = logging.getLogger(__name__)

# Generated at 2022-06-24 02:59:12.854949
# Unit test for function getLogger
def test_getLogger():
    """
    >>> import os
    >>> import os.path
    >>> test_file = os.path.join(os.getcwd(), 'test_log.txt')
    >>> logger = logging.getLogger('test')
    >>> if os.path.exists(test_file):
    ...     os.remove(test_file)
    >>> test_handler = logging.FileHandler(test_file)
    >>> test_handler.setFormatter(logging.Formatter('%(message)s'))
    >>> logger.addHandler(test_handler)
    >>> logger.setLevel(logging.DEBUG)
    >>> logger.debug('test')
    >>> test_handler.flush()
    >>> with open(test_file, 'r') as f:
    ...     assert f.read() == 'test\\n'
    """
   

# Generated at 2022-06-24 02:59:16.916454
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test')
    with logger_level(log, logging.DEBUG):
        log.info('test logging')



# Generated at 2022-06-24 02:59:19.022876
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3, 'Must be either py2 or py3'
    assert _PyInfo.PY2 != _PyInfo.PY3, 'Must be either py2 or py3'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:59:28.079752
# Unit test for function configure
def test_configure():
    # configure()
    # the logger will be configured in root logger
    log = logging.getLogger()
    log.info('test')
    log.debug('debug')
    # the logger is configured in current module as loggers['__main__']
    log_1 = logging.getLogger(__name__)
    log_1.info('test_1')
    log_1.debug('debug_1')
    # the logger is configured in sub module example.logging.test_logger
    log_2 = logging.getLogger('example.logging.test_logger')
    log_2.info('test_2')
    log_2.debug('debug_2')



# Generated at 2022-06-24 02:59:31.967476
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert logger is not None
    logger.setLevel('DEBUG')
    logger.debug('test')


# Generated at 2022-06-24 02:59:36.344101
# Unit test for function configure
def test_configure():
    import inspect
    import logging
    from logging.handlers import WatchedFileHandler

    def _assert_configured(config=None, env_var=None, default=None):
        logger = logging.getLogger()
        assert len(logger.handlers) == 1
        handler = logger.handlers[0]
        assert isinstance(handler, WatchedFileHandler)
        assert isinstance(handler.formatter, logging.Formatter)

        logger = logging.getLogger('req')
        assert logger.parent is logging.root

    # Default
    configure()
    _assert_configured()

    # Env var

# Generated at 2022-06-24 02:59:40.630512
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert logger.level == 10
    assert not logger.disabled
    assert logger.filters == []
    assert logger.handlers == []
    assert logger.name == "__main__"
    assert logger.parent == None
    assert logger.propagate == True
    assert logger.manager == logging.Logger.manager


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:59:43.752577
# Unit test for function configure
def test_configure():
    import logging
    log = logging.getLogger(__name__)
    configure()
    log.info('test')


# Generated at 2022-06-24 02:59:45.889635
# Unit test for function configure
def test_configure():
    import logging
    configure()
    log = logging.getLogger(__name__)
    log.info("Test")


# Generated at 2022-06-24 02:59:50.731374
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY2 is False
    assert pyinfo.PY3 is True or pyinfo.PY3 is False
    assert pyinfo.PY2 is not pyinfo.PY3
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, type)
    assert isinstance(pyinfo.binary_type, type)

# Generated at 2022-06-24 02:59:53.050447
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    logger_1 = getLogger(__name__)
    assert(logger == logger_1)

# Generated at 2022-06-24 03:00:01.106747
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    config_str = json.dumps(DEFAULT_CONFIG)
    config = get_config(config_str)
    assert config_str != config
    assert config == DEFAULT_CONFIG

    config_str = json.dumps(DEFAULT_CONFIG)
    config = get_config(config_str)
    assert config_str != config
    assert config == DEFAULT_CONFIG

    config = get_config(config=config_str)
    assert config == DEFAULT_CONFIG

    config = get_config(config=config_str, env_var='LOGGING')
    assert config == DEFAULT_CONFIG


# Generated at 2022-06-24 03:00:05.274991
# Unit test for function getLogger
def test_getLogger():
    """
    >>> log = getLogger('testLogger')
    >>> log.info('This is a test message')
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 03:00:13.847236
# Unit test for function get_config
def test_get_config():
    # Assert failure
    assert get_config(None, None, None) is None

    # Assert json

# Generated at 2022-06-24 03:00:20.465235
# Unit test for function get_config

# Generated at 2022-06-24 03:00:24.307365
# Unit test for function configure
def test_configure():
    from logging import LoggerAdapter, logging

    log = logging.getLogger()

    class TestLoggerAdapter(LoggerAdapter):
        def debug(self, msg, *args, **kwargs):
            return self.log(logging.DEBUG, msg, *args, **kwargs)

        def info(self, msg, *args, **kwargs):
            return self.log(logging.INFO, msg, *args, **kwargs)

        def warning(self, msg, *args, **kwargs):
            return self.log(logging.WARNING, msg, *args, **kwargs)

        def error(self, msg, *args, **kwargs):
            return self.log(logging.ERROR, msg, *args, **kwargs)

        def critical(self, msg, *args, **kwargs):
            return self

# Generated at 2022-06-24 03:00:25.971504
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('this should NOT log')
        logger.info('this should log')
    logger.debug('this should log')

# Generated at 2022-06-24 03:00:35.006739
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import os
    import tempfile
    from contextlib import contextmanager


# Generated at 2022-06-24 03:00:40.955612
# Unit test for function get_config
def test_get_config():
    config = get_config(config={'version': 1})
    assert config == {'version': 1}, "config is %s" % config

    config = get_config(config='''
    {
        "version": 1
    }
    ''')
    assert config == {'version': 1}, "config is %s" % config

    config = get_config(config='''
    version: 1
    ''')
    assert config == {'version': 1}, "config is %s" % config

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:00:43.716169
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    json_string = json.dumps(DEFAULT_CONFIG)
    yaml_string = yaml.dump(DEFAULT_CONFIG)

    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(json_string) == DEFAULT_CONFIG
    assert get_config(yaml_string) == DEFAULT_CONFIG

# Generated at 2022-06-24 03:00:51.031800
# Unit test for function logger_level
def test_logger_level():
    """Unit test for the context manager logger_level()"""
    class CapturingHandler(logging.Handler):
        """A logging handler capturing all (raw and formatted) logging output."""
        def __init__(self):
            logging.Handler.__init__(self)
            self.watcher = [(logging.NOTSET, None, None)]

        def emit(self, record):
            self.watcher.append((record.levelno, record.getMessage(), record.args))
            self.watcher.pop(0)

    lib_log = getLogger(__name__)
    lib_log.setLevel(logging.NOTSET)
    cap_handle = CapturingHandler()
    lib_log.addHandler(cap_handle)


# Generated at 2022-06-24 03:00:57.248921
# Unit test for function get_config
def test_get_config():
    config = get_config(default=None)
    assert not config
    config = get_config(env_var=None, default=None)
    assert not config
    config = get_config(env_var=None, default=DEFAULT_CONFIG)
    assert config
    config = get_config(default=DEFAULT_CONFIG)
    assert config

# Generated at 2022-06-24 03:01:06.382151
# Unit test for function get_config
def test_get_config():
    default = {'master': {'host': ('127.0.0.1', 8888),
                          'worker': ('127.0.0.1', 8889)}}
    assert default == get_config(env_var=None, default=default)
    assert default == get_config(config=default, env_var=None, default=None)
    assert default == get_config(
        config=json.dumps(default), env_var=None, default=None)
    assert default == get_config(
        config=yaml.dump(default), env_var=None, default=None)

if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:01:11.991023
# Unit test for function configure
def test_configure():
    from tempfile import NamedTemporaryFile

    log = logging.getLogger(__name__)


# Generated at 2022-06-24 03:01:17.785073
# Unit test for function configure
def test_configure():
    logger = logging.getLogger('test')
    logger.debug('test debug')
    logger.info('test info')
    logger.error('test error')

    logger.debug('test debug')
    logger.info('test info')
    logger.error('test error')

    print('\n')



# Generated at 2022-06-24 03:01:21.358308
# Unit test for function getLogger
def test_getLogger():
    """
    >>> logger = getLogger()
    >>> logger.info('Test')
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 03:01:27.601307
# Unit test for function get_config
def test_get_config():
    assert get_config({}) == {}
    assert get_config('') == {}
    assert get_config('{}') == {}
    assert get_config('"test"') == "test"
    assert get_config('{"foo": "bar"}') == {"foo": "bar"}
    assert get_config('foo: bar') == {'foo': 'bar'}

# Generated at 2022-06-24 03:01:31.483139
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert isinstance('a', _PyInfo.string_types)
    assert isinstance(u'a', _PyInfo.string_types)

# Generated at 2022-06-24 03:01:33.313292
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-24 03:01:34.751432
# Unit test for function getLogger
def test_getLogger():
    log = get_logger('test')
    log.info('test logging success')

# test_getLogger()

# Generated at 2022-06-24 03:01:36.364863
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True or _PyInfo.PY3 is True



# Generated at 2022-06-24 03:01:40.027153
# Unit test for function logger_level
def test_logger_level():
    """Test function logger_level"""
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.WARNING

# Generated at 2022-06-24 03:01:48.916272
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    configure()

    assert log.level == logging.INFO
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG

    assert log.level == logging.INFO
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG

    # Ensure that logger level reverts to its original value
    assert log.level == logging.INFO


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    test_logger_level()

# Generated at 2022-06-24 03:01:58.358351
# Unit test for function logger_level
def test_logger_level():
    level_name = "INFO"
    level_name_error = "NOTALOGLEVEL"
    logger = get_logger()
    initial_level = logger.getEffectiveLevel()
    # assert that we can change the level, and that it reverts properly
    with logger_level(logger, level_name):
        assert logger.getEffectiveLevel() == logging.getLevelName(level_name)
    assert logger.getEffectiveLevel() == initial_level

    # assert that we raise if we pass an invalid level name
    try:
        with logger_level(logger, level_name_error):
            assert False, "Should never get here, exception should be raised"
    except ValueError:
        assert True
    except:
        assert False, "Unrecognized exception was raised"
        
    # assert that a value error is raised if we

# Generated at 2022-06-24 03:01:59.533575
# Unit test for function configure
def test_configure():
    configure()


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 03:02:01.214703
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info("test_getLogger")


# Generated at 2022-06-24 03:02:09.772224
# Unit test for function get_config
def test_get_config():
    import json
    import logging.config
    import unittest

    class TestConfig(unittest.TestCase):
        def test_get_config_0(self):
            """
            The test for the case that the given value is a string.
            """
            config = '{"version": 1, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": "DEBUG"}}}'  # noqa
            logging.config.dictConfig(get_config(config))
            logger = logging.getLogger(name='test_get_config_0')
            logger.debug('test debug')
            logger.info('test info')
            logger.warning('test warning')
            logger.error('test error')
            logger.critical('test critical')

            self.assertTrue(True)

       

# Generated at 2022-06-24 03:02:12.169169
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    with get_logger('test_pyinfo') as log:
        log.info('Testing constructor of class _PyInfo')

        pyinfo = _PyInfo()

        PY2 = pyinfo.PY2
        PY3 = pyinfo.PY3

        assert PY2 != PY3



# Generated at 2022-06-24 03:02:21.094112
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    _PyInfo class should have the correct attributes.
    """
    expected_attrs = ["PY2", "PY3", "string_types", "text_type", "binary_type"]
    attr_diff = set(expected_attrs) - set(dir(_PyInfo))
    assert not attr_diff, attr_diff


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:02:26.407553
# Unit test for function logger_level
def test_logger_level():
    l = logging.getLogger(__name__)
    # This is a test to see if logger_level works
    with logger_level(l,logging.INFO):
        assert l.level == logging.INFO
        l.debug('Test')
    # restore level
    l.setLevel(logging.DEBUG)

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 03:02:33.448979
# Unit test for function logger_level
def test_logger_level():
    # Ensure logger has been configured
    _ensure_configured()

    log = logging.getLogger(__name__)

    # Initial logger level should be INFO
    assert log.level == logging.INFO

    with logger_level(log, logging.DEBUG):
        # Log level should be DEBUG within context manager
        assert log.level == logging.DEBUG
        # Some debug message should print
        log.debug('debug message')

    # Outside context manager, log level should be INFO
    assert log.level == logging.INFO

# Generated at 2022-06-24 03:02:43.701582
# Unit test for function get_config
def test_get_config():
    print(get_config)
    assert get_config('123') == '123'
    assert get_config(123) == 123
    assert get_config([]) == []
    assert get_config({}) == {}
    assert get_config('{"a":123}') == {'a': 123}
    assert get_config('"abc"') == 'abc'
    assert get_config('abc') == 'abc'
    assert get_config(None) == None
    assert get_config() == None
    assert get_config('') == ''
    assert get_config('\n') == '\n'
    os.environ['abcd'] = '123'
    assert get_config(env_var='abcd') == '123'
    assert get_config(env_var='abcd', default=456) == '123'

# Generated at 2022-06-24 03:02:50.846707
# Unit test for function configure
def test_configure():
    logging.basicConfig()
    log = logging.getLogger(__name__)
    log.debug('test')

    # enable logging in this file
    del logging.Logger.manager.loggerDict[__name__]
    configure(DEFAULT_CONFIG)
    log.debug('test2')


# Generated at 2022-06-24 03:02:59.923712
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py2 = _PyInfo.PY2
    py3 = _PyInfo.PY3
    t = _PyInfo.text_type
    b = _PyInfo.binary_type
    s = _PyInfo.string_types
    assert py2 or py3, "Neither py2 nor py3"
    assert not (py2 and py3), "Both py2 and py3"
    # Test string_types
    assert isinstance("", s)
    if py2:
        assert isinstance(u"", s)
        assert not isinstance(b"", s)
    else:
        assert not isinstance(b"", s)
    # Test text_type
    assert isinstance("", t)
    if py2:
        assert isinstance(u"", t)

# Generated at 2022-06-24 03:03:10.832721
# Unit test for function get_config
def test_get_config():
    # Step 1: Get config from given
    cfg_given = dict(hello='world')
    assert get_config(given=cfg_given) == cfg_given

    # Step 2: Get config from env_var
    cfg_env_var = dict(hello='world', foo='bar')
    import json
    import os
    cfg_json = json.dumps(cfg_env_var)
    os.environ['test_logging_var'] = cfg_json
    assert get_config(env_var='test_logging_var') == cfg_env_var

    # Step 3: Get config from default when given is None
    cfg_default = dict(foo='bar')
    assert get_config(default=cfg_default) == cfg_default
    # Clean up the environment

# Generated at 2022-06-24 03:03:17.708528
# Unit test for function logger_level
def test_logger_level():
    root_logger = get_logger()
    root_logger.setLevel(logging.INFO)
    root_logger.debug("This should not show up")
    with logger_level(root_logger, logging.DEBUG):
        root_logger.debug("This should show up")
        root_logger.info("This should show up")
    root_logger.info("This should show up")

# Generated at 2022-06-24 03:03:26.311572
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert callable(_PyInfo)
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not(_PyInfo.PY2 and _PyInfo.PY3)
    if _PyInfo.PY2:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    else:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes

