

# Generated at 2022-06-24 02:53:30.335390
# Unit test for function configure
def test_configure():
    configure()

    log = logging.getLogger(__name__)
    log.info('test')

# Generated at 2022-06-24 02:53:40.665498
# Unit test for function get_config
def test_get_config():
    import json


# Generated at 2022-06-24 02:53:51.647625
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is (sys.version_info[0] == 2)
    assert _PyInfo.PY3 is (sys.version_info[0] == 3)

    if _PyInfo.PY3:
        assert isinstance('abc', _PyInfo.string_types)
        assert isinstance(b'abc', _PyInfo.binary_type)
        assert isinstance('abc', _PyInfo.text_type)
    else:
        assert isinstance(u'abc', _PyInfo.string_types)
        assert isinstance('abc', _PyInfo.binary_type)
        assert isinstance(u'abc', _PyInfo.text_type)

# Unit tests for _namespace_from_calling_context()

# Generated at 2022-06-24 02:53:56.151673
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.CRITICAL):
        log.info('should not appear')
        log.debug('should also not appear')
        log.critical('should appear')
        log.warning('should not appear either')
    log.debug('problem?')

# Generated at 2022-06-24 02:54:06.506294
# Unit test for constructor of class _PyInfo
def test__PyInfo():

    if _PyInfo.PY2:
        assert 'unicode' in _PyInfo.string_types
        assert 'str' not in _PyInfo.string_types
    else: #PY3
        assert 'str' in _PyInfo.string_types
        assert 'unicode' not in _PyInfo.string_types

    if _PyInfo.PY2:
        assert 'str' == _PyInfo.binary_type
        assert 'unicode' == _PyInfo.text_type
    else: #PY3
        assert 'bytes' == _PyInfo.binary_type
        assert 'str' == _PyInfo.text_type


if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 02:54:14.757520
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import mock

    class TestLog(unittest.TestCase):
        def test_log(self):
            with mock.patch('logging.Logger.setLevel') as mock_setLevel:
                mock_logger = mock.Mock()
                mock_logger.setLevel.return_value = None
                mock_logger.level = 10

                with logger_level(mock_logger, 100):
                    self.assertEqual(mock_logger.level, 100)

                self.assertEqual(mock_logger.level, 10)
                mock_setLevel.assert_called_once_with(10)

    unittest.main()

# Generated at 2022-06-24 02:54:24.188032
# Unit test for function logger_level
def test_logger_level():
    logging.config.dictConfig(dict(
        version=1,
        disable_existing_loggers=False,
        formatters={
            'simple': {
                'format': '%(name)s %(levelname)s %(message)s'
            },
        },
        handlers={
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
                'level': logging.DEBUG,
            },
        },
        root=dict(handlers=['console'], level=logging.DEBUG),
        loggers={
            'test': dict(level=logging.INFO),
        },
    ))

    from contextlib import contextmanager
    import logging

    test_logger = logging.getLogger("test")


# Generated at 2022-06-24 02:54:28.737437
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger('test'), logging.DEBUG):
        assert logging.getLogger('test').level == logging.DEBUG
    assert logging.getLogger('test').level != logging.DEBUG



# Generated at 2022-06-24 02:54:38.511406
# Unit test for function get_config
def test_get_config():
    import tempfile

    def check_config(config_object, config_as='json'):
        if config_as == 'json':
            import json

            config_data = json.dumps(config_object)
        else:
            import yaml

            config_data = yaml.dump(config_object)

        assert get_config(config_data) == config_object
        with tempfile.NamedTemporaryFile() as f:
            f.write(config_data.encode('utf8'))
            f.seek(0)
            assert get_config(default=f.name) == config_object

    # Config data as dict
    config_object = dict(DEFAULT_CONFIG)
    assert get_config(config_object) == DEFAULT_CONFIG

    # Config data as json

# Generated at 2022-06-24 02:54:43.122582
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test')
    logger.error('test')
    with logger_level(logger, logging.ERROR):
        logger.info('test')
    logger.info('test')



# Generated at 2022-06-24 02:54:44.931708
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.DEBUG):
        assert log.getEffectiveLevel() == logging.DEBUG



# Generated at 2022-06-24 02:54:47.146677
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    log.info('before')
    with logger_level(log, logging.ERROR):
        log.info('should not be logged')
    log.info('after')



# Generated at 2022-06-24 02:54:52.462824
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        assert logger.isEnabledFor(logging.ERROR)
        assert not logger.isEnabledFor(logging.INFO)
        logger.info('This should not print.')

    assert not logger.isEnabledFor(logging.ERROR)
    assert logger.isEnabledFor(logging.INFO)
    logger.info('This should print.')



# Generated at 2022-06-24 02:55:02.891281
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    fd, fn = tempfile.mkstemp()
    os.close(fd)

    cfg = {
        "handlers": {
            "myfile": {
                "class": "logging.handlers.RotatingFileHandler",
                "filename": fn,
                "maxBytes": 50000,
                "backupCount": 2,
                "formatter": "default",
            },
        },
        "root": {"level": "DEBUG", "handlers": ["myfile"]},
        "loggers": {
            "logger_level": {"propagate": 0, "level": "WARNING"},
        },
    }

    configure(config=cfg)
    logger = get_logger(__name__)


# Generated at 2022-06-24 02:55:07.535885
# Unit test for function logger_level
def test_logger_level():

    log = get_logger()

    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:55:09.743808
# Unit test for function logger_level
def test_logger_level():
    import os
    import sys
    
    log = logging.getLogger(__name__)

    with logger_level(log, logging.WARNING):
        log.info('should not print')
        log.warning('should print')
        assert 0, 'Should not have gotten to this point'
    log.info('should print')
    return True


# Generated at 2022-06-24 02:55:19.687453
# Unit test for function configure
def test_configure():
    log = getLogger(__name__)
    log.info("test")
    log.debug("test")


# Generated at 2022-06-24 02:55:28.575905
# Unit test for function configure
def test_configure():
    import io
    import sys

    test_config = {
        'version': 1,
        'formatters': {
            'simple': {
                'format': 'test_formatter %(message)s',
            }
        },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
                'level': logging.DEBUG,
            },
        },
        'root': {
            'level': logging.INFO,
            'handlers': ['console']
        }
    }

    sys.stdout = io.StringIO()
    configure(config=test_config)

    log = get_logger()
    log.info('test')

    assert sys.stdout.getvalue().rstrip() == 'test_formatter test'

    sys

# Generated at 2022-06-24 02:55:33.336024
# Unit test for function logger_level
def test_logger_level():
    # TODO: make this work with both logging and colorlog.logging
    assert False, "Need to make this work with both logging and colorlog.logging"
    # log = getLogger()
    # with logger_level(log, logging.DEBUG):
    #     assert log.is_debug_enabled()
    #     assert not log.is_info_enabled()
    # assert not log.is_debug_enabled()
    # assert log.is_info_enabled()



# Generated at 2022-06-24 02:55:43.905806
# Unit test for function get_config

# Generated at 2022-06-24 02:55:50.674944
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2 == (sys.version_info[0] == 2) or (sys.version_info[0] == 3)
    assert _PyInfo().PY3 == (sys.version_info[0] == 3) or (sys.version_info[0] == 2)
    # print(sys.version_info[0] == 2)
    # print(sys.version_info[0] == 3)


# Generated at 2022-06-24 02:56:01.301633
# Unit test for function configure
def test_configure():
    """Test for function configure"""
    import tempfile
    from random import randint

    log = logging.getLogger(__name__)
    log.handlers = []


# Generated at 2022-06-24 02:56:06.446645
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test')
    with logger_level(log, logging.WARNING):
        assert log.level == logging.WARNING, log.level
    assert log.level == logging.DEBUG, log.level


# Generated at 2022-06-24 02:56:10.365514
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('example')
    logger.info('hi', extra={'context': 'initial'})
    
    with logger_level(logger, logging.WARN):
        logger.info('hi', extra={'context': 'inside block'})
    logger.info('hi', extra={'context': 'after block'})



# Generated at 2022-06-24 02:56:17.805237
# Unit test for function getLogger
def test_getLogger():
    fp = open(os.devnull, 'w')
    old_stderr = sys.stderr
    sys.stderr = fp
    try:
        getLogger("my_logger")
    except Exception as err:
        sys.stderr = old_stderr
        raise err

    try:
        logger = getLogger("my_logger")
        logger.info("Hello world")
        logger = getLogger("my_logger")
        logger.critical("Hello world")
        logger = getLogger("my_logger")
        logger.debug("Hello world")
    except:
        sys.stderr = old_stderr
        raise
    
    sys.stderr = old_stderr


if __name__ == "__main__":
    test_getLog

# Generated at 2022-06-24 02:56:21.771738
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pi = _PyInfo
    assert pi.PY2 or pi.PY3
    assert not (pi.PY2 and pi.PY3)
    assert isinstance(pi.string_types, tuple)
    assert isinstance(pi.text_type, type)
    assert isinstance(pi.binary_type, type)
    assert isinstance(u'', pi.text_type)
    assert isinstance('', pi.binary_type)

# Generated at 2022-06-24 02:56:26.356809
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert logger.name == "__main__"
    logger = getLogger('test')
    assert logger.name == "test"

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 02:56:29.214786
# Unit test for function getLogger
def test_getLogger():
    assert isinstance(getLogger(), logging.Logger), 'Return non-logger'
    assert isinstance(getLogger('logger'), logging.Logger), 'Return non-logger'



# Generated at 2022-06-24 02:56:32.180809
# Unit test for function getLogger
def test_getLogger():
    _ensure_configured()
    log = getLogger()
    log.info('getLogger')
    assert inspect.ismodule(log)


# Generated at 2022-06-24 02:56:34.463448
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    assert log == logging.getLogger(__name__)



# Generated at 2022-06-24 02:56:38.273534
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log2 = getLogger('test2')
    log.debug("test")
    log.info("test info")
    log2.info("test2")


# Generated at 2022-06-24 02:56:41.671155
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-24 02:56:47.963601
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = get_logger(__name__)
    >>> logger.log(logging.INFO, "test_logger_level: info")
    >>> logger.log(logging.DEBUG, "test_logger_level: debug, ignored")
    >>> with logger_level(logger, logging.DEBUG):
    ...     logger.log(logging.INFO, "test_logger_level: info")
    ...     logger.log(logging.DEBUG, "test_logger_level: debug")
    test_logger_level: debug, ignored
    test_logger_level: info
    test_logger_level: debug

    """

# __END__

# Generated at 2022-06-24 02:56:57.826227
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3, 'Not PY2 nor PY3'
    assert _PyInfo.PY2 != _PyInfo.PY3, 'Should be different'

    if _PyInfo.PY3:
        assert type(_PyInfo.string_types[0]) is str
        assert type(_PyInfo.text_type) is str
        assert type(_PyInfo.binary_type) is bytes
    else:  # PY2
        assert type(_PyInfo.string_types[0]) is str
        assert type(_PyInfo.text_type) is unicode
        assert type(_PyInfo.binary_type) is str


# Generated at 2022-06-24 02:57:06.768821
# Unit test for function get_config
def test_get_config():
    config = '''
    version: 1
    disable_existing_loggers: False
    formatters:
      simple:
        format: '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s'
        datefmt: '%Y-%m-%d %H:%M:%S'
    handlers:
      console:
        class : logging.StreamHandler
        formatter: simple
        level: DEBUG
    root:
      handlers: [console]
      level: DEBUG
    loggers:
      requests:
        level: INFO
    '''

# Generated at 2022-06-24 02:57:15.705923
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3, "PY2 and PY3 cannot both be False"
    if _PyInfo.PY3:
        assert _PyInfo.string_types == (str, ), "string_types for PY3 is not as expected"
        assert _PyInfo.text_type == str, "text_type for PY3 is not as expected"
        assert _PyInfo.binary_type == bytes, "binary_type for PY3 is not as expected"
    else:
        assert _PyInfo.string_types == (basestring, ), "string_types for PY2 is not as expected"
        assert _PyInfo.text_type == unicode, "text_type for PY2 is not as expected"

# Generated at 2022-06-24 02:57:19.100097
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.setLevel(logging.ERROR)
        logger.debug("test debug")
        try:
            logger.error("test error")
        except Exception as e:
            assert(e is None)

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:57:25.585213
# Unit test for function get_config

# Generated at 2022-06-24 02:57:26.897203
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    assert logger.level == logging.NOTSET
    configure()
    assert logger.level == logging.DEBUG

# Generated at 2022-06-24 02:57:27.809810
# Unit test for function configure
def test_configure():
    configure()
    logger = get_logger()
    logger.info('test')


# Generated at 2022-06-24 02:57:37.597727
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.DEBUG):
        log.debug("debug message")
        log.warning("warning message")

    assert not log.isEnabledFor(logging.DEBUG)
    assert not log.isEnabledFor(logging.INFO)
    assert log.isEnabledFor(logging.WARNING)
    assert log.isEnabledFor(logging.ERROR)
    assert log.isEnabledFor(logging.CRITICAL)

    with logger_level(log, logging.CRITICAL):
        log.critical("critical message")
        log.error("error message")

    assert not log.isEnabledFor(logging.DEBUG)
    assert not log.isEnabledFor(logging.INFO)
    assert not log.isEnabledFor(logging.WARNING)
    assert not log.isEnabled

# Generated at 2022-06-24 02:57:47.046399
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import inspect
    import os
    import json

    # set logging config to env variable

# Generated at 2022-06-24 02:57:52.872979
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    assert logger.getEffectiveLevel() == logging.NOTSET
    configure(default=DEFAULT_CONFIG)
    assert logger.getEffectiveLevel() == logging.DEBUG



# Generated at 2022-06-24 02:58:01.113696
# Unit test for function configure
def test_configure():
    import colorlog
    try:
        logging.basicConfig(level=logging.DEBUG)
    except ValueError:
        pass
    logger = logging.getLogger('configure_test')
    logger.info('info')
    logger.debug('debug')
    configure()
    logger2 = logging.getLogger('configure_test2')
    logger2.info('info2')
    logger2.debug('debug2')
    assert logger.level == logging.DEBUG
    assert logger2.level == logging.DEBUG
    # _ensure_configured()
    # logger = logging.getLogger('configure_test')
    # logger.info('info')
    # logger.debug('debug')
    # configure()
    # logger2 = logging.getLogger('configure_test2')
    # logger2.info('

# Generated at 2022-06-24 02:58:06.559029
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    configure()
    
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug("debug message")
        
    assert logger.level == logging.INFO
    logger.info("info message")
    logger.debug("debug message 2")
    
test_logger_level()

# Generated at 2022-06-24 02:58:18.007132
# Unit test for function configure

# Generated at 2022-06-24 02:58:22.495467
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG

# Generated at 2022-06-24 02:58:28.341630
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    p = _PyInfo()
    assert p.PY2 or p.PY3


if __name__ == '__main__':
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 02:58:33.891733
# Unit test for function get_config
def test_get_config():
    import yaml

    yaml_config = yaml.dump(DEFAULT_CONFIG)
    json_config = json.dumps(DEFAULT_CONFIG)
    assert get_config(json_config) == get_config(yaml_config)

# Generated at 2022-06-24 02:58:36.092591
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger(__name__)
    assert logger is not None

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:58:44.865869
# Unit test for function configure

# Generated at 2022-06-24 02:58:51.562399
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logging.root.level = logging.NOTSET
    >>> log = get_logger("test_logger_level")
    >>> log.setLevel(logging.INFO)
    >>> with logger_level(log, logging.DEBUG):
    ...     log.debug("Should be shown")
    Should be shown

    >>> with logger_level(log, logging.DEBUG):
    ...     log.info("Should also be shown")
    Should also be shown

    >>> with logger_level(log, logging.WARN):
    ...     log.info("Should not be shown")
    >>> with logger_level(log, logging.ERROR):
    ...     log.info("Should not be shown")

    >>> log.setLevel(logging.INFO)
    """
    pass



# Generated at 2022-06-24 02:58:58.119696
# Unit test for function logger_level
def test_logger_level():
    # Get a logger
    logger = getLogger()

    # Logs with level above 50 will not be logged
    with logger_level(logger, 80):
        logger.critical('should not be logged')

    # Logs with level below 50 will be logged
    with logger_level(logger, 30):
        logger.info('should be logged')

# Generated at 2022-06-24 02:59:02.147940
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger('test')
    logger.info('test')
    logger.error('test')
    logger.debug('test')
    try:
        1/0
    except:
        logger.exception('test')


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 02:59:09.179001
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    level_before = logger.level
    logger.disable(logging.CRITICAL)
    assert logger.level == logging.CRITICAL
    with logger_level(logger, logging.INFO):
        logger.info("Testing")
        assert logger.level == logging.INFO
    assert logger.level == logging.CRITICAL
    logger.setLevel(level_before)

# Generated at 2022-06-24 02:59:13.693662
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    logger.info("foo")
    logger.debug("bar")

    with logger_level(logger, logging.DEBUG):
        logger.debug("baz")
        logger.info("quux")

    logger.debug("garply")
    logger.info("waldo")

    with logger_level(logger, logging.INFO):
        logger.info("fred")

    logger.info("plugh")
    logger.debug("xyzzy")

# Generated at 2022-06-24 02:59:21.779754
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2 == sys.version_info[0] == 2
    assert _PyInfo().PY3 == sys.version_info[0] == 3

    if _PyInfo().PY3:
        assert _PyInfo().string_types == (str,)
        assert _PyInfo().text_type == str
        assert _PyInfo().binary_type == bytes
    else:  # PY2
        assert _PyInfo().string_types == (basestring,)
        assert _PyInfo().text_type == unicode
        assert _PyInfo().binary_type == str


# Generated at 2022-06-24 02:59:25.775978
# Unit test for function get_config
def test_get_config():
    assert get_config(None) == None
    assert get_config({}) == {}
    assert get_config("{}") == {}
    assert get_config("{'a':'b'}") == {'a': 'b'}
    assert get_config("a: 'b'") == {'a': 'b'}
    assert get_config("a: 1") == {'a': 1}
    assert get_config("a: 1.0") == {'a': 1.0}
    assert get_config("a: False") == {'a': False}

if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-24 02:59:29.583064
# Unit test for function getLogger
def test_getLogger():
    # Test whether getLogger can be initialized properly
    logger = getLogger(__name__)
    assert logger



# Generated at 2022-06-24 02:59:32.668513
# Unit test for function configure
def test_configure():
    logger = None
    try:
        logger = logging.getLogger('test')
    except Exception:
        pass
    assert (logger == None), 'logger should not be initialized'
    configure()
    logger = logging.getLogger('test')
    try:
        logger.info('test')
    except Exception as e:
        print(str(e))
        raise e

if __name__ == '__main__':
    test_configure()

# vim: set ts=4 sw=4 tw=0 et :

# Generated at 2022-06-24 02:59:35.660323
# Unit test for function getLogger
def test_getLogger():
    logging.basicConfig()
    log = get_logger(__name__)
    log.info('test_getLogger passed')
    print('log: %s', log)



# Generated at 2022-06-24 02:59:41.778111
# Unit test for function get_config
def test_get_config():
    example = \
    """\
version: 1
disable_existing_loggers: false
formatters:
  colored:
    () : colorlog.ColoredFormatter
    format: '%(bg_black)s%(log_color)s%(reset)s'
    datefmt: '%H:%M:%S'

handlers:
  console:
    class: logging.StreamHandler
    formatter: colored
    level: DEBUG

root:
  handlers: [console]
  level: DEBUG
  """

    assert get_config(config=example, env_var=False, default=False) == DEFAULT_CONFIG

# Generated at 2022-06-24 02:59:47.690176
# Unit test for function configure
def test_configure():
    logger = logging.getLogger('mylogger')
    logger.setLevel(logging.INFO)
    logger.info('before:configure')
    configure()
    logger.info('after:configure')
    logger.debug('after:configure')
    assert True


if __name__ == '__main__':
    configure()
    logger = logging.getLogger('test')
    logger.info('test')

# Generated at 2022-06-24 02:59:55.307920
# Unit test for function logger_level
def test_logger_level():
    name = _namespace_from_calling_context()

    logger = get_logger(name)
    logger.info('I am info')
    logger.warning('I am warning')

    with logger_level(logger, logging.INFO):
        logger.info('I am info')
        logger.warning('I should not be seen')

    logger.warning('I am warning')


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:00:02.262749
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert isinstance('', _PyInfo.string_types)
        assert not isinstance(b'', _PyInfo.string_types)
        assert isinstance(u'', _PyInfo.string_types)
        assert isinstance('', _PyInfo.text_type)
        assert not isinstance(b'', _PyInfo.text_type)
        assert isinstance(u'', _PyInfo.text_type)
        assert isinstance(b'', _PyInfo.binary_type)
        assert not isinstance('', _PyInfo.binary_type)
        assert not isinstance(u'', _PyInfo.binary_type)
    else:
        assert isinstance('', _PyInfo.string_types)
        assert isinstance(b'', _PyInfo.string_types)
       

# Generated at 2022-06-24 03:00:11.570299
# Unit test for function configure
def test_configure():
    logger = get_logger()
    # Default config
    logger.debug('Default log config')
    # Configure with dict
    config = dict(version=1, disable_existing_loggers=False, loggers={'my_logger': dict(level=logging.DEBUG, handlers=['console'])})
    configure(config=config)
    logger.debug('New log config')
    # Configure with json
    json_config = json.dumps(config)
    configure(config=json_config)
    logger.debug('New json log config')
    # Configure with yaml
    yaml_config = yaml.dump(config)
    configure(config=yaml_config)
    logger.debug('New yaml log config')
    # Test that the wrong config fails
    import tempfile

# Generated at 2022-06-24 03:00:19.376439
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    logger.setLevel(logging.INFO)

    assert logger.isEnabledFor(logging.INFO), "Assert logger is not enabled."

    with logger_level(logger, logging.CRITICAL):
        assert logger.isEnabledFor(logging.CRITICAL), "Assert logger is not in CRITICAL mode."

    assert logger.isEnabledFor(logging.INFO), "Assert logger is not enabled."

# Generated at 2022-06-24 03:00:20.375155
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test log')

# Generated at 2022-06-24 03:00:21.879190
# Unit test for function configure
def test_configure():
    configure()
    configure(default={})
    configure(default={'version': 1})
    configure({'version': 1})
    configure(configure(configure(configure(configure({'version': 1})))))



# Generated at 2022-06-24 03:00:24.893613
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test')
    logger.info('test2')
    #assert True


# Generated at 2022-06-24 03:00:35.466822
# Unit test for function get_config
def test_get_config():
    assert get_config(config={'version': 1}, env_var='LOGGING', default=None) == {'version': 1}
    assert get_config(config=None, env_var='LOGGING', default={'version': 1}) == {'version': 1}
    assert get_config(config='{"version": 1}', env_var='LOGGING', default=None) == {'version': 1}
    assert get_config(config='version: 1', env_var='LOGGING', default=None) == {'version': 1}
    assert get_config(config="version: 1", env_var='LOGGING', default=None) == {'version': 1}

    # TODO: Consider if just raising exception for bad config (instead of None) is better.

# Generated at 2022-06-24 03:00:37.596303
# Unit test for function getLogger
def test_getLogger():
    configure()
    log = get_logger()
    log.info('test')
    log = get_logger('test2')
    log.info('test2')

# Generated at 2022-06-24 03:00:41.666203
# Unit test for function getLogger
def test_getLogger():
    log = getLogger('my_logger')
    log.info('test')
    log.warn('test')
    log.error('test')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:00:43.812261
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.DEBUG):
        log = logging.getLogger()
        log.debug('debug')
        log.error('error')
        log.info('info')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 03:00:47.509865
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """Test for the class _PyInfo."""
    from test.test_json import TestPyInfo
    from unittest import TextTestRunner, TestSuite

    suite = TestSuite()
    suite.addTest(TestPyInfo('test__PyInfo'))
    TextTestRunner().run(suite)


# Unit test
if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 03:00:52.766797
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    logger.info('hello')
    logger.warning('world')
    logger.error('bad things')
    logger.critical('serious things')
    configure()
    logger.info('hello')
    logger.warning('world')
    logger.error('bad things')
    logger.critical('serious things')

# Generated at 2022-06-24 03:00:58.547116
# Unit test for function getLogger
def test_getLogger():
    name = 'test_name'
    logger = get_logger(name)
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warn message')
    logger.error('error message')
    logger.critical('crit message')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:01:08.411034
# Unit test for function get_config
def test_get_config():
    config = get_config()
    assert config == DEFAULT_CONFIG

    raw_json = '{"version": 1}'
    config = get_config(raw_json)
    assert config == json.loads(raw_json)
    assert config != raw_json

    raw_yaml = "version: 1\n"
    config = get_config(raw_yaml)
    assert config == yaml.load(raw_yaml)
    assert config != raw_yaml

    raw_str = '{"version": 1}'
    config = get_config(raw_str)
    assert config == json.loads(raw_str)

    raw_none = None
    with pytest.raises(ValueError):
        get_config(raw_none)



# Generated at 2022-06-24 03:01:10.032901
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False

if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 03:01:21.487514
# Unit test for function configure
def test_configure():
    import json
    import os

    logfile = 'test.log'
    if os.path.exists(logfile):
        os.remove(logfile)


# Generated at 2022-06-24 03:01:27.383361
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config(None, 'LOGGING', DEFAULT_CONFIG)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:01:37.001455
# Unit test for function get_config
def test_get_config():
    cfg_dict = get_config(config='{"version" : 1}')
    if cfg_dict is None:
        raise AssertionError

    cfg_json = get_config(config='{"version" : 1}', default=None)
    if cfg_json is None:
        raise AssertionError

    cfg_yaml = get_config(config="version: 1", default=None)
    if cfg_yaml is None:
        raise AssertionError

    cfg_basic = get_config(env_var='CFG_BASIC', default='{"version" : 1}')
    if cfg_basic is None:
        raise AssertionError

    try:
        get_config()
    except ValueError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-24 03:01:47.941806
# Unit test for function getLogger

# Generated at 2022-06-24 03:01:51.736588
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.info("This shouldn't show up")
        logger.error("This should show up")

    logger.info("This should also show up")



# Generated at 2022-06-24 03:01:55.180635
# Unit test for function getLogger
def test_getLogger():
    test_log = getLogger()
    test_log.debug('test1')


# Generated at 2022-06-24 03:01:57.697764
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()
    log = logger_level(get_logger(), logging.DEBUG)
    with logger_level(log, logging.DEBUG):
        log.warn('wow')

# Generated at 2022-06-24 03:01:58.598041
# Unit test for function getLogger
def test_getLogger():
    getLogger('test')



# Generated at 2022-06-24 03:02:02.053410
# Unit test for function logger_level
def test_logger_level():
    import logging
    import re

    log = logging.getLogger('test_logger_level')

    with logger_level(log, logging.ERROR):
        log.debug('This message should not print')
        log.error('This message should print')

    log.debug('This message should print')
    log.error('This message should print again')


# Generated at 2022-06-24 03:02:10.550163
# Unit test for function configure
def test_configure():
    class MockLogging:
        class dictConfig:
            def __init__(self, config):
                self._config = config

            def __call__(self, config):
                if config == self._config:
                    return True
                return False

    class MockDict:
        def __init__(self, key, value):
            self._dict = {key: value}

        def get(self, key):
            return self._dict.get(key)
    with patch('os.environ', MockDict('LOGGING', 'test')):
        with patch('json.loads', return_value={'foo': 'bar'}):
            with patch('logging.config.dictConfig', MockLogging.dictConfig):
                with patch('logging.basicConfig', MockLogging.dictConfig):
                    configure()


# Generated at 2022-06-24 03:02:19.086710
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config('{"a":"b"}', None, DEFAULT_CONFIG) == {"a":"b"}
    assert get_config('a: b', None, DEFAULT_CONFIG) == {"a": "b"}
    assert get_config('invalid_yaml', None, DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config('invalid_json:b', None, DEFAULT_CONFIG) == DEFAULT_CONFIG



# Generated at 2022-06-24 03:02:20.835736
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert not _PyInfo.PY3
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.binary_type == str
    assert _PyInfo.text_type == unicode



# Generated at 2022-06-24 03:02:29.363357
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG
    assert get_config(default={'foo': 'bar'}) == {'foo': 'bar'}
    assert get_config(given={'foo': 'bar'}) == {'foo': 'bar'}
    assert get_config(default='{"foo": "bar"}') == {'foo': 'bar'}
    assert get_config(given='{"foo": "bar"}') == {'foo': 'bar'}
    assert get_config(given='foo: bar') == {'foo': 'bar'}

if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-24 03:02:32.155306
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    assert type(logger) == logging.Logger
    assert logger.name == "__main__"
    assert logger.getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-24 03:02:33.584306
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info("This is a test")

# Generated at 2022-06-24 03:02:43.816179
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert isinstance('string', _PyInfo.string_types), 'str should be in _PyInfo.string_types'
        assert isinstance(u'unicode', _PyInfo.string_types), 'unicode should be in _PyInfo.string_types'
        assert isinstance(b'bytes', _PyInfo.binary_type), 'bytes should be _PyInfo.binary_type'
        assert isinstance(u'unicode', _PyInfo.text_type), 'unicode should be _PyInfo.text_type'
    if _PyInfo.PY3:
        assert isinstance('string', _PyInfo.string_types), 'str should be in _PyInfo.string_types'

# Generated at 2022-06-24 03:02:52.481149
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger_level')
    logger.setLevel(logging.INFO)
    logger.debug('before')

    with logger_level(logger, logging.DEBUG):
        logger.debug('inside')

    logger.debug('after')

# Unit test __main__
if __name__ == '__main__':
    configure()

    log = getLogger()
    log.debug('test')

    log = getLogger('test2')
    log.info('test2')

    test_logger_level()

# Generated at 2022-06-24 03:02:58.664342
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY2:
        assert type(_PyInfo.text_type) == type(unicode)
        assert type(_PyInfo.binary_type) == type(str)
    elif _PyInfo.PY3:
        assert type(_PyInfo.text_type) == type('str')
        assert type(_PyInfo.binary_type) == type(b'bytes')



# Generated at 2022-06-24 03:03:01.990979
# Unit test for function configure
def test_configure():
    configure()
    logger = logging.getLogger("foo")
    logger.debug("Debug")
    logger.info("Info")
    logger.warning("Warning")



# Generated at 2022-06-24 03:03:10.772847
# Unit test for function getLogger
def test_getLogger():
    """
    >>> import logging
    >>> logging.getLogger("log").handlers
    []

    >>> # This causes a default logger to be created
    ... log = logging.getLogger("log")
    >>> log.setLevel("DEBUG")
    >>> log.debug("Hello")
    >>> log.error("world")
    >>> log.warning("!")

    >>> # This will work even more straightforward
    ... log = getLogger("log2")
    >>> log.setLevel("DEBUG")
    >>> log.debug("Hello")
    >>> log.error("world")
    >>> log.warning("!")
    """
    pass



# Generated at 2022-06-24 03:03:15.567805
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    assert logger.name == __name__

    logger = get_logger('my_logger_name')
    assert logger.name == 'my_logger_name'

# Generated at 2022-06-24 03:03:17.163593
# Unit test for function configure
def test_configure():
    log = logging.getLogger('test')
    configure()
    log.info('test')



# Generated at 2022-06-24 03:03:20.008253
# Unit test for function configure
def test_configure():
    configure()

    logger = logging.getLogger(__name__)
    logger.info('Testing')



# Generated at 2022-06-24 03:03:25.033569
# Unit test for function get_config
def test_get_config():
    from sys import platform

    if platform.startswith('linux'):
        import json
        import tempfile

        with tempfile.NamedTemporaryFile('wb') as tf:
            json_str = str(DEFAULT_CONFIG).replace("'", '"')
            tf.write(json_str.encode())
            tf.flush()
            with open(tf.name) as fp:
                config = get_config(fp)
            assert config == json.loads(json_str)

        with tempfile.NamedTemporaryFile('wb') as tf:
            json_str = str(DEFAULT_CONFIG).replace("'", '"')
            tf.write(json_str.encode())
            tf.flush()
            os.environ['LOGGING'] = '@' + tf.name

# Generated at 2022-06-24 03:03:28.759548
# Unit test for function configure
def test_configure():
    logging.shutdown()
    configure()

test_configure()

if __name__ == '__main__':
    logger = get_logger()
    logger.debug('test')
    logger.debug('test2')
    logger.error('test3')
    logger.info('test4')
    logger.warn('test5')
    logger.critical('test6')