

# Generated at 2022-06-24 02:53:28.855874
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not (_PyInfo.PY2 and _PyInfo.PY3)
    assert _PyInfo.string_types

# Generated at 2022-06-24 02:53:35.469638
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == (sys.version_info[0] == 2)
    assert _PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance(_PyInfo.string_types, tuple)
    assert isinstance(_PyInfo.text_type, type)
    assert isinstance(_PyInfo.binary_type, type)


# Generated at 2022-06-24 02:53:39.925244
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger("test_logger_level")
    log.setLevel(logging.INFO)
    log.info("test_logger_level message before")

    with logger_level(log, logging.DEBUG):
        log.debug("test_logger_level message during")

    log.info("test_logger_level message after")



# Generated at 2022-06-24 02:53:45.555745
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
        logger.critical('critical log')
        logger.warning('warning log')
    assert logger.level == logging.DEBUG
    logger.critical('critical log')
    logger.warning('warning log')

# Generated at 2022-06-24 02:53:53.041999
# Unit test for function logger_level
def test_logger_level():
    check = []
    def f():
        check.append("f")

    logger = logging.getLogger("logger_level")
    logging.basicConfig(level=logging.INFO)
    logger.info("logger_level")
    with logger_level(logger, logging.ERROR):
        logger.info("do not see this")
        logger.error("logger_level")
        f()
    logger.info("logger_level")
    assert check == ["f"]



# Generated at 2022-06-24 02:53:55.576425
# Unit test for function getLogger
def test_getLogger():
    configure()
    assert isinstance(get_logger('testgetLogger'), logging.Logger) == True


# Generated at 2022-06-24 02:54:01.719933
# Unit test for function configure
def test_configure():
    """Test for function configure
    >>> import logging
    >>> logger = logging.getLogger('test_configure')
    >>> configure()
    >>> logger.info('test')
    >>> logger.critical('test')
    """
    pass

# Generated at 2022-06-24 02:54:05.802623
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not (_PyInfo.PY2 and _PyInfo.PY3)


# Generated at 2022-06-24 02:54:07.333302
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger(__name__)
    logger.debug('This is a test')


# Generated at 2022-06-24 02:54:16.554957
# Unit test for function get_config
def test_get_config():
    """
    >>> import logging
    >>> get_config()
    Traceback (most recent call last):
    ...
    ValueError: Invalid logging config: None
    >>> get_config(default=None)
    Traceback (most recent call last):
    ...
    ValueError: Invalid logging config: None
    >>> get_config({'root': {'level': logging.DEBUG}})
    {'root': {'level': 10}}
    >>> get_config('{"root": {"level": "DEBUG"}}')
    {'root': {'level': 10}}
    >>> get_config('root: {level: DEBUG}')
    {'root': {'level': 'DEBUG'}}
    """



# Generated at 2022-06-24 02:54:18.335236
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert log.level == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG

# Generated at 2022-06-24 02:54:24.050191
# Unit test for function logger_level
def test_logger_level():
    """logger_level is true only if logger.level is the same before and after the context manager"""
    logger = get_logger()
    # Set logger.level to logging.DEBUG
    with logger_level(logger, logging.DEBUG):
        logger.debug('DEBUG')
        assert logger.level == logging.DEBUG
    # Set logger.level to logging.INFO
    with logger_level(logger, logging.INFO):
        logger.info('INFO')
        assert logger.level == logging.INFO
        logger.debug('DEBUG')

# Generated at 2022-06-24 02:54:28.634750
# Unit test for function logger_level
def test_logger_level():
   logger = getLogger()
   with logger_level(logger, logging.ERROR):
      logger.info('This should not be output')
      logger.error('This should be output')
   logger.info('This should be output')

# Generated at 2022-06-24 02:54:36.868332
# Unit test for function get_config
def test_get_config():
    assert get_config() is None
    assert get_config({'some': 'config'}) == {'some': 'config'}
    assert get_config(default={'default': 'config'}) == {'default': 'config'}
    assert get_config(config='{"some": "config"}') == {'some': 'config'}
    assert get_config(config='{"some": "config"}') == {'some': 'config'}
    assert get_config(config="some: config\n") == {'some': 'config'}
    assert get_config(config="some:\n  config\n") == {'some': 'config'}

# Generated at 2022-06-24 02:54:41.663905
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(format='%(levelname)s', level=logging.DEBUG)
    log = logging.getLogger(__name__)
    with logger_level(log, logging.INFO):
        log.debug('test')
        log.info('test')
        assert log.level == logging.INFO
    log.debug('test')
    log.info('test')
    assert log.level == logging.DEBUG
    # logging.shutdown()

# Generated at 2022-06-24 02:54:48.225650
# Unit test for constructor of class _PyInfo
def test__PyInfo():

    pyinfo = _PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)

    # Test _PyInfo.string_types
    if pyinfo.PY3:
        assert (str, ) == pyinfo.string_types
        assert str == pyinfo.text_type
        assert bytes == pyinfo.binary_type
    else:  # PY2
        assert (basestring,) == pyinfo.string_types
        assert unicode == pyinfo.text_type
        assert str == pyinfo.binary_type


# Generated at 2022-06-24 02:54:50.725807
# Unit test for function getLogger
def test_getLogger():
    get_logger()


if __name__ == '__main__':
    print('Running logger tests')
    test_getLogger()

# Generated at 2022-06-24 02:54:51.608418
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger()
    logger.info('test')


# Generated at 2022-06-24 02:54:59.251811
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__ + '_test_logger_level')

    log.debug('Test debug message')
    log.info('Test info message')

    with logger_level(log, logging.WARNING):
        log.debug('Test debug message')
        log.info('Test info message')
        log.warning('Test warning message')

    log.debug('Test debug message')
    log.info('Test info message')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:55:05.509800
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    print(log)
    log.info('test_getLogger')

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 02:55:10.257895
# Unit test for function getLogger
def test_getLogger():
    """There is no way to test the output of a logger, but we can at least check that code is run."""
    # Set up a mock logger
    log = Logger()
    logger = get_logger(name='test', root_logger=log)
    # Check that when a new logger is created, it calls the mock logger.
    logger.debug(100)
    assert log.calls['debug'] == [100]



# Generated at 2022-06-24 02:55:12.734596
# Unit test for function get_config
def test_get_config():
    import json
    assert get_config(config='{"version": 1, "disable_existing_loggers": false}') == DEFAULT_CONFIG
    assert get_config(config=json.dumps(DEFAULT_CONFIG)) == DEFAULT_CONFIG

# Generated at 2022-06-24 02:55:15.076178
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.debug('test debug')
    log.error('test error')
    log.info('test info')
    log.warning('test warning')
    log.critical('test critical')


# Generated at 2022-06-24 02:55:22.575768
# Unit test for function get_config
def test_get_config():
    # test for none
    assert get_config() is None
    # test for bare
    assert get_config("debug") is "debug"
    # test for json
    assert get_config("{}") == {}
    # test for yaml
    assert get_config("[]") == []
    # test for invalid
    try:
        get_config("invalid")
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"

# Generated at 2022-06-24 02:55:28.155807
# Unit test for function getLogger
def test_getLogger():
    print("Test getLogger")
    msg = "test"
    test = getLogger()
    test.info(msg)



# Generated at 2022-06-24 02:55:31.812673
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    assert _PyInfo.PY3
    assert _PyInfo.string_types == (str,)
    assert _PyInfo.string_types == (basestring,)
    assert _PyInfo.binary_type == (str,)
    assert _PyInfo.binary_type == (bytes,)


# Generated at 2022-06-24 02:55:36.449284
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()

    with logger_level(log, logging.DEBUG):
        assert log.isEnabledFor(logging.DEBUG)

    assert not log.isEnabledFor(logging.DEBUG)

# Generated at 2022-06-24 02:55:45.384668
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """Unit test for constructor of class _PyInfo"""
    py_info = _PyInfo()
    assert py_info.PY2 == (sys.version_info[0] == 2)
    assert py_info.PY3 == (sys.version_info[0] == 3)

    if py_info.PY3:
        assert py_info.string_types == (str,)
        assert py_info.text_type == str
        assert py_info.binary_type == bytes
    else:  # PY2
        assert py_info.string_types == (basestring,)
        assert py_info.text_type == unicode
        assert py_info.binary_type == str


# Generated at 2022-06-24 02:55:47.783881
# Unit test for function getLogger
def test_getLogger():
    # logger = getLogger(name="test")
    logger = get_logger(name="test")
    print(logger)


# Generated at 2022-06-24 02:55:51.114191
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True or _PyInfo.PY2 is False
    assert _PyInfo.PY3 is True or _PyInfo.PY3 is False
    assert _PyInfo.PY2 ^ _PyInfo.PY3 is True


# Generated at 2022-06-24 02:55:58.998714
# Unit test for function get_config
def test_get_config():
    cfg = get_config(config='test')
    assert cfg == 'test'
    os.environ['LOGGING'] = 'test2'
    cfg = get_config(env_var='LOGGING')
    assert cfg == 'test2'
    assert isinstance(get_config(default=DEFAULT_CONFIG), dict)
    del os.environ['LOGGING']
    with pytest.raises(ValueError):
        get_config()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:56:05.767140
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.INFO):
        logger.debug('A')
        logger.info('B')
        logger.warning('C')
    logger.debug('D')
    logger.info('E')
    logger.warning('F')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:56:12.667118
# Unit test for function get_config

# Generated at 2022-06-24 02:56:14.102471
# Unit test for function getLogger
def test_getLogger():
    log = get_logger('test_getLogger')
    log.info('test_getLogger')

# Generated at 2022-06-24 02:56:20.093642
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')
    assert(log.getEffectiveLevel() == logging.DEBUG)



# Generated at 2022-06-24 02:56:22.184290
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.ERROR):
        log.info('test')  # should not log anything
        log.error('test')  # should log an error message
    log.info('test')  # should log a debug message as per default config

# Generated at 2022-06-24 02:56:30.630195
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False
    assert isinstance('hello', _PyInfo.string_types)
    assert isinstance(u'hello', _PyInfo.string_types)
    assert isinstance('hello', _PyInfo.text_type) == False
    assert isinstance(u'hello', _PyInfo.text_type)
    assert isinstance('hello', _PyInfo.binary_type)
    assert isinstance(b'hello', _PyInfo.binary_type)

if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 02:56:37.275225
# Unit test for function get_config
def test_get_config():
    import yaml


# Generated at 2022-06-24 02:56:45.408420
# Unit test for function getLogger
def test_getLogger():
    import tempfile, sys
    from contextlib import contextmanager
    from io import StringIO
    from logging import StreamHandler
    from os import environ, getpid

    @contextmanager
    def capture_stdout(out_fd):
        import sys
        sys.stdout = out_fd
        yield
        sys.stdout = sys.__stdout__

    with tempfile.NamedTemporaryFile() as output_file:
        stdout = StringIO()
        logger = getLogger()
        with capture_stdout(stdout):
            with logger_level(logger, logging.DEBUG):
                logger.info('test')
                handler = stdout.getvalue()
                assert 'test' in handler
            with logger_level(logger, logging.DEBUG):
                logger.debug('test')
                handler = stdout.get

# Generated at 2022-06-24 02:56:50.475906
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(
        format='%(levelname)s:%(name)s:%(message)s',
        level=logging.INFO
    )
    logger = get_logger(__name__)
    assert logger.level == logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")
    assert logger.level == logging.INFO
    logger.info("info")
    logger.debug("debug")
    logger.error("error")



# Generated at 2022-06-24 02:56:56.130947
# Unit test for function get_config
def test_get_config():
    import json

    test_json = json.dumps('{}')
    logging_config = get_config(default=[1, 2, 3],
                                env_var='LOGGING_CONFIG',
                                given={'LOGGING': test_json})
    assert logging_config == {'LOGGING': test_json}



# Generated at 2022-06-24 02:56:59.313602
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:57:09.602827
# Unit test for function getLogger
def test_getLogger():
    name = 'test'
    log = get_logger(name)
    assert log.name == name

if __name__ == '__main__':
    log = get_logger()
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')

    log_root = logging.getLogger()
    log_root.debug('test')

    logging.basicConfig(datefmt='[%H:%M:%S]', level=logging.DEBUG)
    logging.debug('test')

    log = get_logger('test')
    log.debug('test')

    log = get_logger()
    log.debug('test')

    configure({'version': 1})

# Generated at 2022-06-24 02:57:14.332677
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    assert logger.level == logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO



# Generated at 2022-06-24 02:57:23.057304
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger_level')
    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.INFO):
        logger.info('Test INFO')
        logger.debug('Test DEBUG')
        logger.warning('Test WARNING')
        logger.error('Test ERROR')
        logger.critical('Test CRITICAL')

    logger.info('Test INFO')
    logger.debug('Test DEBUG')
    logger.warning('Test WARNING')
    logger.error('Test ERROR')
    logger.critical('Test CRITICAL')

# Generated at 2022-06-24 02:57:24.157982
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.debug('test')


# Generated at 2022-06-24 02:57:25.020698
# Unit test for function getLogger
def test_getLogger():
    get_logger().info("hello world")



# Generated at 2022-06-24 02:57:37.305051
# Unit test for function get_config
def test_get_config():
    '''Tests the function get_config()'''
    ##### TESTCASE: No given config, no env_var, no default
    config = get_config()
    assert config is None

    ##### TESTCASE: No given config, no env_var, with default
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    ##### TESTCASE: No given config, with env_var, no default
    os.environ['LOGGING'] = '{"test_config": "test_value"}'
    config = get_config(env_var='LOGGING')
    assert config == {'test_config': 'test_value'}

    ##### TESTCASE: No given config, with env_var, with default

# Generated at 2022-06-24 02:57:43.608180
# Unit test for function getLogger
def test_getLogger():
    logging.basicConfig(filename='test_logger_function.log',
                        level=logging.DEBUG,
                        filemode='w')
    log = getLogger('test_function')
    # Check default level root logger
    assert log.level == logging.DEBUG, 'Incorrect default level of root logger'
    log.debug('Test DEBUG message')
    log.info('Test INFO message')
    log.warning('Test WARNING message')
    log.error('Test ERROR message')
    log.critical('Test CRITICAL message')


# Generated at 2022-06-24 02:57:51.687709
# Unit test for function get_config

# Generated at 2022-06-24 02:57:55.759414
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert not _PyInfo.PY2
    assert _PyInfo.PY3
    assert len(_PyInfo.string_types) == 1
    assert _PyInfo.string_types == (str,)
    assert _PyInfo.text_type == str
    assert _PyInfo.binary_type == bytes


# Generated at 2022-06-24 02:57:58.510312
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    def eq(a, b):
        return a == b

    # eq(_PyInfo.PY2, sys.version_info[0] == 2)
    eq(True, sys.version_info[0] == 2)



# Generated at 2022-06-24 02:58:05.465043
# Unit test for function logger_level
def test_logger_level():
    # Make sure the logger is configured to output debug messages
    configure()

    # Create a logger and set the level to DEBUG
    logger = get_logger()
    logger.level = logging.DEBUG

    # Enter a context block that sets the logger level to INFO
    with logger_level(logger, logging.INFO):
        logger.debug("This shouldn't print anything")
        assert logger.level == logging.INFO

    # Make sure the level of the logger is still DEBUG
    assert logger.level == logging.DEBUG
    logger.debug("This should print something")

# Generated at 2022-06-24 02:58:16.027918
# Unit test for function configure
def test_configure():
    import os
    import logging
    import tempfile
    sample_config = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'simple': {
                'format': '%(name)s: %(levelname)s %(message)s'
            },
        },
        'handlers': {
            'file_handler': {
                'class': 'logging.FileHandler',
                'formatter': 'simple',
                'level': 'INFO',
                'filename': '/tmp/configure.log'
            },
        },
        'loggers': {
            'log1': {
                'handlers': ['file_handler'],
                'level': 'ERROR',
            },
        }
    }

    # Configure with given config

# Generated at 2022-06-24 02:58:23.033076
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log.info('test_getLogger')
    log.warn('test_getLogger')
    log.error('test_getLogger')
    log.critical('test_getLogger')



# Generated at 2022-06-24 02:58:28.396233
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY3 is True or _PyInfo.PY2 is True
    assert "test_logging" in _namespace_from_calling_context()
    assert inspect.stack()[0][3] == "test__PyInfo"



# Generated at 2022-06-24 02:58:37.044417
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py_info = _PyInfo()
    assert py_info.PY2 == sys.version_info[0] == 2
    assert py_info.PY3 == sys.version_info[0] == 3
    if py_info.PY3:
        assert py_info.string_types == (str,)
        assert py_info.text_type == str
        assert py_info.binary_type == bytes
    else:
        assert py_info.string_types == (basestring,)
        assert py_info.text_type == unicode
        assert py_info.binary_type == str



# Generated at 2022-06-24 02:58:40.434802
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py_info = _PyInfo()
    assert isinstance(py_info.string_types, tuple)
    assert py_info.text_type == str
    assert py_info.binary_type == bytes



# Generated at 2022-06-24 02:58:49.625424
# Unit test for function get_config
def test_get_config():
    import yaml

    yaml_data = '''\
    version: 1
    formatters:
      simple:
        format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    handlers:
      console:
        class: logging.StreamHandler
        level: DEBUG
        formatter: simple
        stream: ext://sys.stdout
    root:
      level: INFO
      handlers: [console]
    '''

    yaml_data_processed = yaml.load(yaml_data)


# Generated at 2022-06-24 02:58:53.713345
# Unit test for function get_config
def test_get_config():
    assert get_config(env_var='LOGGING') == DEFAULT_CONFIG
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG

    config = dict(
        version=1,
    )
    assert get_config(config=config) == config

    config = '{}'
    assert get_config(config=config) == {}



# Generated at 2022-06-24 02:58:59.597048
# Unit test for function configure
def test_configure():
    # 1. logger default configuration
    logging_cfg = {}
    configure(logging_cfg)
    logger = get_logger()
    logger.info('test 1')

    # 2. logger config in given string using json format
    logging_cfg = '{"version": 1, "loggers": {"requests": {"level": "INFO"}}}'
    configure(logging_cfg)
    logger = get_logger()
    logger.info('test 2')

    # 3. logger config in given string using yaml format
    logging_cfg = 'version: 1 \n loggers:\n   requests:\n     level: INFO'
    configure(logging_cfg)
    logger = get_logger()
    logger.info('test 3')


if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-24 02:59:01.643355
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-24 02:59:04.196104
# Unit test for function configure
def test_configure():
    pass
    # >>> configure()
    # >>> logging.getLogger().info('hello')


# Generated at 2022-06-24 02:59:13.376723
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# TODO: @contextmanager version of get_logger that sets a namespace
# def context_logger(name=None):
#     """
#     >>> with context_logger('test') as log:
#     ...     log.info('test')
#
#     >>> log = get_logger()
#     >>> log.info('test')
#     """
#     _ensure_configured()
#     ns_initial = _namespace_from_calling_context()
#     # set namespace
#     _get_logger(name)
#
#     yield get_logger()
#
#     _namespace_from_calling_context

# Generated at 2022-06-24 02:59:18.269430
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert logging.getLogger(__name__).info('test__PyInfo(): OK')

# Unit tests for function configure()

# Generated at 2022-06-24 02:59:21.027422
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    assert pyinfo.PY2 == (sys.version_info[0] == 2)

# Generated at 2022-06-24 02:59:25.386324
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    log.setLevel(logging.ERROR)
    with logger_level(log, logging.INFO):
        log.info("test_logger_level")


# Generated at 2022-06-24 02:59:32.446897
# Unit test for function logger_level
def test_logger_level():
    l = getLogger()
    l.setLevel(0)
    assert l.level == 0
    with logger_level(l, logging.CRITICAL):
        assert l.level == logging.CRITICAL
    assert l.level == 0


# for python2.7 compat
try:
    from contextlib import redirect_stderr, redirect_stdout
except ImportError:
    class redirect_stderr:
        def __init__(self, target):
            self.target = target

        def __enter__(self):
            self.old_stderr = sys.stderr
            sys.stderr = self.target

        def __exit__(self, _type, value, traceback):
            sys.stderr = self.old_stderr


# Generated at 2022-06-24 02:59:34.805090
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    >>> test__PyInfo()
    """
    assert _PyInfo.PY2 != _PyInfo.PY3


# Generated at 2022-06-24 02:59:37.783098
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert log.getEffectiveLevel() == logging.DEBUG
    with logger_level(log, logging.ERROR):
        assert log.getEffectiveLevel() == logging.ERROR
    assert log.getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-24 02:59:40.034280
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger(__name__)
    logger.debug('test_getLogger')


if __name__ == '__main__':
    logger = get_logger()
    logger.debug('test_getLogger')
    test_getLogger()

# Generated at 2022-06-24 02:59:48.021489
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True or _PyInfo.PY2 == False
    assert _PyInfo.PY3 == True or _PyInfo.PY3 == False
    if _PyInfo.PY2:
        assert isinstance(b'foo', _PyInfo.binary_type)
        assert isinstance(u'foo', _PyInfo.text_type)
    if _PyInfo.PY3:
        assert isinstance(b'foo', _PyInfo.binary_type)
        assert isinstance(u'foo', _PyInfo.text_type)


# Generated at 2022-06-24 02:59:58.736571
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY3:
        assert isinstance('abc', _PyInfo.string_types)
        assert not isinstance(b'abc', _PyInfo.string_types)
        assert isinstance('abc', _PyInfo.text_type)
        assert not isinstance(b'abc', _PyInfo.text_type)
        assert isinstance(b'abc', _PyInfo.binary_type)
        assert not isinstance('abc', _PyInfo.binary_type)
    else:
        assert isinstance('abc', _PyInfo.string_types)
        assert not isinstance(b'abc', _PyInfo.string_types)
        assert isinstance(u'abc', _PyInfo.text_type)
        assert not isinstance('abc', _PyInfo.text_type)

# Generated at 2022-06-24 03:00:08.960704
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()

    assert pyinfo.PY2 is True
    assert pyinfo.PY3 is False
    assert type(pyinfo.string_types) is tuple
    assert pyinfo.string_types == (basestring,)
    assert type(pyinfo.text_type) is str
    assert pyinfo.text_type == unicode
    assert type(pyinfo.binary_type) is str
    assert pyinfo.binary_type == str


if __name__ == '__main__':
    import logging

    configure()

    log = logging.getLogger(__name__)
 
    log.info("Test: info")
    log.debug("Test: debug")
    log.warning("Test: warning")
    log.error("Test: error")
    log.critical("Test: critical")

# Generated at 2022-06-24 03:00:16.834199
# Unit test for function logger_level
def test_logger_level():
    import time
    from contextlib import contextmanager

    def test_logger(msg):
        time.sleep(0.1)
        print('[%s] %s' % (time.time(), msg))

    get_logger().info = test_logger

    @contextmanager
    def set_level(level):
        with logger_level(get_logger(), level):
            yield

    with set_level(logging.ERROR):
        get_logger().info('this should not print')
        get_logger().debug('this should not print')
        with set_level(logging.DEBUG):
            get_logger().info('this should print')
            get_logger().debug('this should print')
        get_logger().debug('this should not print')


# Generated at 2022-06-24 03:00:18.725446
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('testLog')
    logger.info("Info msg")
    logger.warn("Warn msg")
    logger.error("Error msg")
    logger.debug("Debug msg")

# Generated at 2022-06-24 03:00:26.817055
# Unit test for function get_config
def test_get_config():
    config  = get_config(None, None, { "a": 2 })
    assert config["a"] == 2

    config  = get_config('{"a": 3}', None, { "a": 2 })
    assert config["a"] == 3

    config  = get_config('a: 3', None, { "a": 2 })
    assert config["a"] == 3

    with pytest.raises(ValueError):
        config  = get_config('[1, 2, 3]', None, { "a": 2 })
    with pytest.raises(ValueError):
        config  = get_config(None, None, None)



# Generated at 2022-06-24 03:00:31.395094
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert type(text_type("a")) is _PyInfo.text_type
    assert type(binary_type("a")) is _PyInfo.binary_type
    assert type("a") in _PyInfo.string_types
    assert type(u"a") in _PyInfo.string_types

# Generated at 2022-06-24 03:00:37.315586
# Unit test for function get_config
def test_get_config():
    import json
    import logging.config

    json_str = '{"foo":"bar", "baz":"blah"}'
    cfg = get_config(json_str)
    assert cfg == json.loads(json_str)

    # logger = logging.getLogger()
    # while logger.parent is not None:
    #     logger = logger.parent
    #
    # assert logger.level == logging.DEBUG or logger.level == logging.INFO

# Generated at 2022-06-24 03:00:39.699080
# Unit test for function getLogger
def test_getLogger():
    log = getLogger()
    log.info('test')

    log = getLogger('test2')
    log.info('test2')


# Generated at 2022-06-24 03:00:48.818037
# Unit test for function get_config
def test_get_config():
    # case default
    cfg = get_config()
    assert cfg == DEFAULT_CONFIG

    # case given a dict
    cfg = get_config({"test_config": "test"})
    assert cfg == {"test_config": "test"}

    # case given a string
    cfg = get_config("test_config")
    assert cfg == "test_config"

    # case given a json string
    cfg = get_config('{"test_config": "test"}')
    assert cfg == {"test_config": "test"}

    # case given a yaml string
    cfg = get_config("test_config: test")
    assert cfg == {"test_config": "test"}
    

# Generated at 2022-06-24 03:00:50.747491
# Unit test for function getLogger
def test_getLogger():
    logger = logging.getLogger(__name__)
    logger.info("test1")

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:00:52.140458
# Unit test for function getLogger
def test_getLogger():
    logger = getLogger('test')
    assert isinstance(logger, logging.Logger)


# Generated at 2022-06-24 03:01:00.169747
# Unit test for function get_config
def test_get_config():
    import logging
    import logging.config

    logging.basicConfig()

    def get_logger(name=None):
        if not name:
            name = _namespace_from_calling_context()

        return logging.getLogger(name)

    getLogger = get_logger

    config = get_config(env_var="LOGGING")

    logging.config.dictConfig(config)
    log = getLogger("test")
    log.warn("test")

if __name__ == "__main__":
    test_get_config()

# Generated at 2022-06-24 03:01:03.992568
# Unit test for function configure
def test_configure():
    logger = logging.getLogger('test')
    # Use default config, no config file.
    configure()
    logger.info('test')

    # Use a config file for logger.

# Generated at 2022-06-24 03:01:10.174683
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    with tempfile.TemporaryDirectory() as temp_path:
        mylog_path = os.path.join(temp_path, 'mylog.txt')
        with open(mylog_path, 'w') as mylog:
            logger = logging.getLogger('test_logger_level')
            logger.setLevel(logging.DEBUG)
            logger.addHandler(logging.StreamHandler(mylog))

            logger.debug('debug')
            logger.info('info')
            logger.warning('warning')

            with logger_level(logger, logging.WARNING):
                logger.debug('debug')
                logger.info('info')
                logger.warning('warning')

            logger.debug('debug')
            logger.info('info')
            logger.warning('warning')


# Generated at 2022-06-24 03:01:15.920274
# Unit test for function configure
def test_configure():
    logging.shutdown()
    cwd = os.path.dirname(__file__)
    path = os.path.join(cwd, 'test_configure.yml')
    configure(config=path)
    log = logging.getLogger(__name__)
    log.info('test yaml')



# Generated at 2022-06-24 03:01:18.199034
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')

if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 03:01:21.273124
# Unit test for function getLogger
def test_getLogger():

    # Default logger
    logger = getLogger()
    logger.info('test')

    logger = getLogger(name='test2')
    logger.info('test2')


# Generated at 2022-06-24 03:01:25.654483
# Unit test for function getLogger
def test_getLogger():
    # Calls getLogger with no arguments
    log = getLogger()
    log.info("This is a test")

# Generated at 2022-06-24 03:01:30.072752
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    logger.info('test')



# Generated at 2022-06-24 03:01:38.915087
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('This should not appear on INFO')

    with logger_level(logger, logging.DEBUG):
        logger.debug('This should appear on DEBUG')

    logger.debug('This should appear on DEBUG')


__all__ = [
    'configure',
    'get_logger',
    'getLogger',
    'logger_level',
]

# Example to add root logger
# import logging
# logging.getLogger().addHandler(logging.StreamHandler())
# logging.getLogger().setLevel(logging.DEBUG)


# Example to add loggers
# log = logging.getLogger(__name__)
# log.addHandler(logging.StreamHandler())
# log.setLevel(log

# Generated at 2022-06-24 03:01:49.728941
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    if _PyInfo.PY3:
        assert isinstance('a', _PyInfo.string_types)
        assert isinstance('a', _PyInfo.text_type)
        assert isinstance(b'a', _PyInfo.binary_type)
        assert isinstance(str(b'a'), _PyInfo.text_type)
        assert isinstance(b'a', _PyInfo.binary_type)
        assert isinstance(bytes('a', 'ascii'), _PyInfo.binary_type)
        assert not isinstance(bytes('a', 'utf-8'), _PyInfo.text_type)
    else:
        assert isinstance('a', _PyInfo.string_types)
        assert isinstance(u'a', _PyInfo.text_type)
        assert isinstance('a', _PyInfo.binary_type)

# Generated at 2022-06-24 03:01:55.073872
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level is logging.DEBUG
    assert logger.level is logging.NOTSET

# Generated at 2022-06-24 03:02:02.964055
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True or _PyInfo.PY2 is False
    assert _PyInfo.PY3 is True or _PyInfo.PY3 is False
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert _PyInfo.string_types == (basestring,)
    assert isinstance('test', _PyInfo.string_types)
    assert isinstance(u'test', _PyInfo.string_types)
    assert not isinstance(b'test', _PyInfo.string_types)
    assert _PyInfo.string_types == (str,)
    assert isinstance('test', _PyInfo.string_types)
    assert isinstance(u'test', _PyInfo.string_types)
    assert not isinstance(b'test', _PyInfo.string_types)
   

# Generated at 2022-06-24 03:02:06.678489
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    configure()
    assert logger.level == 30
    logger.info('fake')
    with logger_level(logger, 0):
        logger.info('debug')
        logger.debug('fake')
    logger.info('real')


# Generated at 2022-06-24 03:02:07.884605
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    print('test', log)

# Generated at 2022-06-24 03:02:12.117487
# Unit test for function logger_level
def test_logger_level():
    import logging

    logging.basicConfig()

    logger = logging.getLogger('test_logger_level')
    assert logger.level == logging.NOTSET

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    assert logger.level == logging.NOTSET


if __name__ == '__main__':
    import sys

    sys.exit(0 if 'unittest' in sys.argv else 1)

# Generated at 2022-06-24 03:02:22.200244
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    config = get_config(None, env_var='LOGGING', default=DEFAULT_CONFIG)
    print(config)
    config = get_config(None, env_var='LOGGING', default=DEFAULT_CONFIG)
    print(config)
    # json_config = json.loads(json.dumps(DEFAULT_CONFIG))
    # yaml_config = yaml.load(yaml.dump(DEFAULT_CONFIG, default_flow_style=False))


if __name__ == "__main__":
    test_get_config()

# Generated at 2022-06-24 03:02:25.071958
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger();
    with logger_level(logger, logging.ERROR):
        logger.info("This should not print.")
    logger.info("This should print.")




# Generated at 2022-06-24 03:02:32.420897
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.PY2 != _PyInfo.PY3
    if _PyInfo.PY2:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    else:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes

# Generated at 2022-06-24 03:02:34.852811
# Unit test for function getLogger
def test_getLogger():
    log = get_logger(__name__)
    log.info("test")

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 03:02:39.155000
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2
    if not _PyInfo.PY2:
        assert _PyInfo.PY3
    assert _PyInfo.string_types
    assert _PyInfo.text_type
    assert _PyInfo.binary_type



# Generated at 2022-06-24 03:02:41.157525
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 == True
    assert _PyInfo.PY3 == False



# Generated at 2022-06-24 03:02:42.769431
# Unit test for function getLogger
def test_getLogger():
    log = getLogger('test_getLogger')
    log.info('test_getLogger')


# Generated at 2022-06-24 03:02:48.653541
# Unit test for function get_config

# Generated at 2022-06-24 03:02:51.219692
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 + _PyInfo.PY3 == 1


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:02:56.757441
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        log.debug("This should never appear")
        log.info("This should appear")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 03:02:59.348279
# Unit test for function configure
def test_configure():
    """
    >>> test_configure()
    """
    configure()
    log = get_logger()
    log.info('test')



# Generated at 2022-06-24 03:03:09.591624
# Unit test for function logger_level
def test_logger_level():
    # Mute log messages
    logging.getLogger().setLevel(100)
    # Create logger
    logger = logging.getLogger('my-logger-level')
    # First test
    with logger_level(logger, logging.DEBUG):
        assert(logger.getEffectiveLevel() == logging.DEBUG)
        # Second test
        with logger_level(logger, logging.INFO):
            assert(logger.getEffectiveLevel() == logging.INFO)
            assert(logger.debug("test") == None)
        assert(logger.getEffectiveLevel() == logging.DEBUG)
        assert(logger.debug("test") == None)
    # Post-test
    assert(logger.getEffectiveLevel() == 100)



# Generated at 2022-06-24 03:03:20.446119
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    # Test that the PyInfo class contains expected attributes
    assert hasattr(_PyInfo, 'PY2')
    assert hasattr(_PyInfo, 'PY3')
    assert hasattr(_PyInfo, 'string_types')
    assert hasattr(_PyInfo, 'text_type')
    assert hasattr(_PyInfo, 'binary_type')

    # Test that the PyInfo class contains expected values
    if _PyInfo.PY2:
        assert _PyInfo.string_types == (basestring,)
        assert _PyInfo.text_type == unicode
        assert _PyInfo.binary_type == str
    elif _PyInfo.PY3:
        assert _PyInfo.string_types == (str,)
        assert _PyInfo.text_type == str
        assert _PyInfo.binary_type == bytes

# Generated at 2022-06-24 03:03:27.097956
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pi = _PyInfo()
    assert pi.PY2 == (sys.version_info[0] == 2)
    assert pi.PY3 == (sys.version_info[0] == 3)
    if pi.PY3:
        assert pi.string_types == (str,)
        assert pi.text_type == str
        assert pi.binary_type == bytes
    else:
        assert pi.string_types == (str, unicode)
        assert pi.text_type == unicode
        assert pi.binary_type == str