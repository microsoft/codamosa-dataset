

# Generated at 2022-06-24 02:53:38.428489
# Unit test for function configure
def test_configure():
    logging.config.dictConfig({
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'simple': {
                'format': '%(levelname)s %(message)s'
            },
        },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'level': 'INFO',
                'formatter': 'simple',
                'stream': 'ext://sys.stdout'
            },
        },
        'root': {
            'level': 'INFO',
            'handlers': ['console']
        }
    })

    logger = logging.getLogger(__name__)
    logger.info("Test Logging")



# Generated at 2022-06-24 02:53:49.406724
# Unit test for function get_config
def test_get_config():
    import json

    cfg = '{"a": "b"}'
    assert get_config(cfg, env_var=None, default=None) == json.loads(cfg)

    cfg = '{"a": "b"}'
    assert get_config(cfg, env_var='', default=None) == json.loads(cfg)

    cfg = '{"a": "b"}'
    assert get_config(cfg, env_var=None, default='{}') == json.loads(cfg)

    cfg = '{"a": "b"}'
    assert get_config(cfg, env_var='', default='{}') == json.loads(cfg)


if __name__ == '__main__':
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 02:53:57.974398
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import logging

    # Test get_config with json format
    json_config = json.dumps(DEFAULT_CONFIG)
    assert get_config(given=json_config) == DEFAULT_CONFIG

    # Test get_config with yaml format
    yaml_config = yaml.dump(DEFAULT_CONFIG)
    assert get_config(given=yaml_config) == DEFAULT_CONFIG

    # Test get_config with yaml format
    logging.basicConfig(**DEFAULT_CONFIG)
    assert get_config(given=DEFAULT_CONFIG) == DEFAULT_CONFIG


# Generated at 2022-06-24 02:54:08.214708
# Unit test for function configure
def test_configure():
    import os

# Generated at 2022-06-24 02:54:18.611289
# Unit test for function get_config
def test_get_config():
    assert isinstance(DEFAULT_CONFIG, dict)
    assert isinstance(get_config(config=DEFAULT_CONFIG), dict)
    # We can't assert that the default is the default (duh)
    assert isinstance(get_config(), dict)
    # Test json config string

# Generated at 2022-06-24 02:54:26.471081
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager

    import logging
    import sys

    log = getLogger('test')

    # using logging mock to check the level
    @contextmanager
    def logging_mock(level):
        logging.basicConfig(stream=sys.stderr, level=level)

    # Check the function logger_level
    with logging_mock(logging.NOTSET):
        with logger_level(log, logging.NOTSET):
            log.debug('Hello')
            log.info('Hello')
            log.warning('Hello')
            log.error('Hello')
            log.critical('Hello')
    assert(log.isEnabledFor(logging.DEBUG) == False)
    assert(log.isEnabledFor(logging.INFO) == False)

# Generated at 2022-06-24 02:54:29.585361
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()

    # Check if the type of pyinfo object is as expected
    assert type(pyinfo) == type(_PyInfo())

    # Check if the instance variables are set correctly
    if _PyInfo.PY2:
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str
    else:
        assert pyinfo.string_types == (str,)
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes


# Generated at 2022-06-24 02:54:37.958871
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py_info = _PyInfo()
    assert py_info.PY2 == (sys.version_info[0] == 2)
    assert py_info.PY3 == (sys.version_info[0] == 3)

    if py_info.PY3:
        assert py_info.string_types == (str,)
        assert py_info.text_type == str
        assert py_info.binary_type == bytes
    else:  # PY2
        assert py_info.string_types == (basestring,)
        assert py_info.text_type == unicode
        assert py_info.binary_type == str


# Generated at 2022-06-24 02:54:42.392787
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    with logger_level(logger, logging.WARN):
        assert logger.level == logging.WARN
    assert logger.level == logging.DEBUG


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:54:51.021463
# Unit test for function configure
def test_configure():
    import logging.config
    log = logging.getLogger('test1')
    #print(log.root.handlers)
    #print(log.parent)
    configure({"formatters": {"simple": {"format": "%(levelname)s %(message)s", "datefmt": "%Y-%m-%dT%H:%M:%S"}}})
    logging.info('test')
    logging.getLogger('test1').info('test1')
    logging.getLogger('test').info('test')
    logging.getLogger('test2').info('test2')
    logging.getLogger('test3').info('test3')

# Generated at 2022-06-24 02:54:52.959009
# Unit test for function getLogger
def test_getLogger():
    import sys
    import subprocess
    log = getLogger()
    log.info('test')


if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:55:01.522961
# Unit test for function configure
def test_configure():
    import tempfile

    with tempfile.NamedTemporaryFile(mode='w') as f:
        f.write('{"version": 1, "disable_existing_loggers": "false", "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "colored", "level": "debug"}}, "root": {"handlers": ["console"], "level": "DEBUG"}, "loggers": {"requests": {"level": "info"}}}')
        f.flush()
        configure(config=f.name, env_var=None)
    configure(config=None, env_var='LOGGING')



# Generated at 2022-06-24 02:55:03.481508
# Unit test for function getLogger
def test_getLogger():
    user_level = logging.DEBUG
    logger = getLogger('test')
    logger.info('test logging')
    logger.setLevel(user_level)


# Generated at 2022-06-24 02:55:11.481603
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    default = DEFAULT_CONFIG

    # Test the default config
    cfg = get_config(default=default)
    assert cfg == default

    # Test the env var path
    def mock_env(d):
        d['LOGGING'] = yaml.dump(default)

    with mock(os.environ, mock_env):
        cfg = get_config(env_var='LOGGING', default=default)
        assert cfg == default

    # Test the json path
    cfg = get_config(config=json.dumps(default))
    assert cfg == default

    # Test the yaml path
    cfg = get_config(config=yaml.dump(default))
    assert cfg == default

# Generated at 2022-06-24 02:55:21.459153
# Unit test for function get_config

# Generated at 2022-06-24 02:55:31.728518
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    py_info = _PyInfo()
    assert py_info.PY2 == True or py_info.PY3 == True
    assert py_info.PY2 == False or py_info.PY3 == False
    if py_info.PY2:
        assert isinstance(u'hi', py_info.string_types)
        assert type(py_info.binary_type) is str
        assert type(py_info.text_type) is unicode
        assert u'hi' == py_info.text_type('hi')
    else:
        assert isinstance('hi', py_info.string_types)
        assert type(py_info.binary_type) is bytes
        assert type(py_info.text_type) is str
        assert 'hi' == py_info.text_type('hi')



# Generated at 2022-06-24 02:55:36.040386
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger(__name__)
    log.info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:55:36.980454
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-24 02:55:39.445800
# Unit test for function get_config
def test_get_config():
    # Test with invalid config, expect TypeError
    assert_raises(TypeError, get_config, 'test')

    assert_equals(get_config(), DEFAULT_CONFIG)

# Generated at 2022-06-24 02:55:42.756179
# Unit test for function getLogger
def test_getLogger():
    log = get_logger(__name__)
    log.info("Logging Test Info")
    log.debug("Logging Test Debug")
    log.warning("Logging Test Warning")


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 02:55:50.498518
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    >>> _PyInfo().PY2
    >>> not _PyInfo().PY3
    True
    >>> isinstance('', _PyInfo().string_types)
    True
    >>> isinstance(u'', _PyInfo().string_types)
    True
    >>> _PyInfo().text_type
    <type 'unicode'>
    >>> _PyInfo().binary_type
    <type 'str'>
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:55:56.794485
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyInfo = _PyInfo()
    py3 = pyInfo.PY3
    py2 = pyInfo.PY2
    if py2:
        assert py3 == False
        assert py2 == True
        assert sys.version_info[0] == 2
    if py3:
        assert py2 == False
        assert py3 == True
        assert sys.version_info[0] == 3



# Generated at 2022-06-24 02:56:07.010622
# Unit test for function getLogger
def test_getLogger():
    import logging
    import time
    import os

    # DEFAULT LOGGING
    log = getLogger()
    log.debug('test')
    log.info('test')
    log.warning('test')
    log.error('test')
    log.critical('test')

    # Specific logging
    log = getLogger('test2')
    log.debug('test2')
    log.info('test2')
    log.warning('test2')
    log.error('test2')
    log.critical('test2')

    # Logging is set correctly
    # set with environment variable

# Generated at 2022-06-24 02:56:09.444877
# Unit test for function configure
def test_configure():
    log = get_logger(__name__)
    configure()
    log.info('test')
    assert True


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:56:13.690467
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pi = _PyInfo()
    assert pi.PY2 or pi.PY3
    if pi.PY2:
        assert pi.string_types == (basestring,)
        assert pi.text_type == unicode
        assert pi.binary_type == str
    elif pi.PY3:
        assert pi.string_types == (str,)
        assert pi.text_type == str
        assert pi.binary_type == bytes

# Generated at 2022-06-24 02:56:15.919962
# Unit test for function getLogger
def test_getLogger():
    # Get logger which had been configured
    log = getLogger()
    log.info('test')
    log.warn('test')

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:56:21.327853
# Unit test for function getLogger
def test_getLogger():
    import pprint
    import cStringIO
    import logging
    log = getLogger('test_getLogger')
    log.info('This is getLogger test.')

    stream = cStringIO.StringIO()
    logger = logging.getLogger()
    logger.addHandler(logging.StreamHandler(stream))

    with logger_level(logging.getLogger(), logging.DEBUG):
        log = getLogger('test_getLogger2')
        log.info('This is getLogger test.')
        pprint.pprint('%s', stream)

if __name__ == '__main__':
    test_getLogger()

# Generated at 2022-06-24 02:56:33.206538
# Unit test for function get_config
def test_get_config():
    # None
    get_config()
    # None, None, None
    get_config(None, None, None)
    # '', '', ''
    get_config('', '', '')
    # ''
    get_config('')
    # '', '', ''
    get_config('', '', '')
    # '{}'
    get_config('{}')

    # '{}', None, None
    get_config('{}', None, None)
    # '{}', '', None
    get_config('{}', '', None)
    # '{}', '', ''
    get_config('{}', '', '')

    # '{}', None, None
    get_config('{}', None, None)
    # '{}', '', None
   

# Generated at 2022-06-24 02:56:37.908396
# Unit test for function get_config
def test_get_config():
    test_config = get_config()
    assert(test_config != None)
    assert(test_config['version'] == 1)
    assert(test_config['formatters']['colored']['datefmt'] == '%H:%M:%S')

# Generated at 2022-06-24 02:56:48.184628
# Unit test for function configure
def test_configure():
    import tempfile

    # dump config in a temp file
    _, temp_file = tempfile.mkstemp()
    try:
        import json

        with open(temp_file, 'w') as f:
            json.dump(DEFAULT_CONFIG, f)

        configure(config=temp_file)
    finally:
        os.unlink(temp_file)

    # test json

# Generated at 2022-06-24 02:56:50.098824
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger()
    log.info('test')


# Generated at 2022-06-24 02:57:00.883161
# Unit test for function configure
def test_configure():
    logger = logging.getLogger('test_configure')
    configure({
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'simple': {
                'format': '%(asctime)s %(levelname)s %(message)s'
            },
        },
        'handlers': {
            'file_handler': {
                'class': 'logging.FileHandler',
                'formatter': 'simple',
                'filename': 'test.log',
                'mode': 'w',
                'level': logging.INFO
            },
        },
        'loggers': {
            'test_configure': {
                'handlers': ['file_handler'],
                'level': logging.INFO,
            }
        }
    })
    # Log

# Generated at 2022-06-24 02:57:05.196566
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.INFO):
        log.info('testing 1')
        log.debug('testing 2')
        log.warn('testing 3')
        log.error('testing 4')
        log.critical('testing 5')
    log.info('testing 6')
    log.debug('testing 7')
    log.warn('testing 8')
    log.error('testing 9')
    log.critical('testing 10')



# Generated at 2022-06-24 02:57:14.229385
# Unit test for function configure

# Generated at 2022-06-24 02:57:23.430925
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.getEffectiveLevel() == logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
    with logger_level(logger, logging.DEBUG):
        logger.debug('Debug message')
        logger.info('Info message')
    assert logger.getEffectiveLevel() == logging.INFO

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-24 02:57:28.285178
# Unit test for function get_config
def test_get_config():
    config_json = '{"a": 1}'
    config_dict = {'a': 1}

    assert get_config(config_json) == config_dict
    assert get_config(config=config_json) == config_dict
    assert get_config(config=config_dict) == config_dict
    assert get_config(config=json.JSONEncoder().encode(config_dict)) == config_dict

    config_yaml = 'a: 1'
    assert get_config(config=config_yaml) == config_dict

    assert get_config(None, default=config_dict) == config_dict



# Generated at 2022-06-24 02:57:31.750783
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print(_PyInfo().PY2)
    print(_PyInfo().PY3)
    print(_PyInfo().string_types)
    print(_PyInfo().text_type)
    print(_PyInfo().binary_type)


# Generated at 2022-06-24 02:57:35.143228
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('this should show up')
        logger.info('this should not show up')
    logger.debug('this should not show up either')

# Generated at 2022-06-24 02:57:43.590485
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is True or _PyInfo.PY3 is True
    if _PyInfo.PY3 is True:
        assert _PyInfo.PY2 is False
    else:
        assert _PyInfo.PY3 is False
    assert isinstance('', _PyInfo.string_types) is True
    assert isinstance('', _PyInfo.binary_type) is True
    assert isinstance('', _PyInfo.text_type) is True
    assert isinstance(_PyInfo.text_type('test'), _PyInfo.string_types) is True
    assert isinstance(b'test', _PyInfo.string_types) is True
    assert isinstance(b'test', _PyInfo.binary_type) is True

if __name__ == '__main__':
    test__PyInfo()

# Generated at 2022-06-24 02:57:49.935397
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 == sys.version_info[0] == 2
    assert pyinfo.PY3 == sys.version_info[0] == 3
    if pyinfo.PY3:
        assert pyinfo.string_types == (str,)
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
    else:
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str



# Generated at 2022-06-24 02:57:53.153177
# Unit test for function configure
def test_configure():
    logger = get_logger(__name__)
    logger.info('Test if the logger is properly configured')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-24 02:57:59.158626
# Unit test for function get_config
def test_get_config():
    # Test bare given
    assert isinstance(get_config(config='{"a": 1}'), dict)
    # Test json given
    assert isinstance(get_config(config='{"a": 1}'), dict)
    # Test jsonfile given
    assert isinstance(get_config(config='logging.json'), dict)
    # Test bad given
    try:
        get_config('not a json or yaml file or dict')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 02:57:59.923891
# Unit test for function configure
def test_configure():
    # TODO
    pass


# Generated at 2022-06-24 02:58:01.415556
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo().PY2 is True or _PyInfo().PY3 is True


# Generated at 2022-06-24 02:58:06.200592
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert type(_PyInfo.PY2) == bool
    assert type(_PyInfo.PY3) == bool
    assert type(_PyInfo.string_types[0]) == type
    assert type(_PyInfo.text_type) == type
    assert type(_PyInfo.binary_type) == type

# Generated at 2022-06-24 02:58:15.061633
# Unit test for function get_config

# Generated at 2022-06-24 02:58:18.985757
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config['handlers']['console']['class'] == 'logging.StreamHandler'


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:58:25.569804
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 is _PyInfo.string_types == (basestring,)
    assert _PyInfo.PY3 is _PyInfo.string_types == (str,)
    assert _PyInfo.PY2 is _PyInfo.binary_type == str
    assert _PyInfo.PY3 is _PyInfo.binary_type == bytes


if __name__ == '__main__':
    import doctest

    doctest.testmod(raise_on_error=True)

# Generated at 2022-06-24 02:58:36.835511
# Unit test for function getLogger
def test_getLogger():
    from os import devnull
    from contextlib import redirect_stdout
    import unittest

    class Test(unittest.TestCase):
        def test_getLogger(self):
            with redirect_stdout(devnull):
                # Check with no argument
                logger = getLogger()
                logger.info('test')

                # Check with argument
                logger = getLogger('test2')
                logger.info('test2')

        def test_default_config(self):
            self.assertEqual(DEFAULT_CONFIG, get_config())

        def test_env_var_config(self):
            expected = dict(foo='bar')


# Generated at 2022-06-24 02:58:42.156442
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), logging.DEBUG):
        assert getLogger().getEffectiveLevel() == logging.DEBUG
    assert getLogger().getEffectiveLevel() != logging.DEBUG

test_logger_level.__test__ = False  # disable nose test discovery



# Generated at 2022-06-24 02:58:50.884592
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING') == DEFAULT_CONFIG
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=None, env_var='LOGGING') == DEFAULT_CONFIG
    # Default should be a dict
    assert get_config(config={}, env_var='LOGGING') == {}
    assert get_config(config=DEFAULT_CONFIG, env_var=None) == DEFAULT_CONFIG
    # Check the json format is converted
    assert get_config(config=json.dumps(DEFAULT_CONFIG), env_var=None) == DEFAULT_CONFIG
    # Check the yaml format is converted
    assert get_config

# Generated at 2022-06-24 02:58:56.615479
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug("This should work")
        log.info("This shouldn't work")
    log.info("This should work")


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:59:02.659817
# Unit test for function get_config
def test_get_config():
    """
    >>> print(get_config(default={}))
    {}

    >>> print(get_config(given={'a': {'a': 'a'}}))
    {'a': {'a': 'a'}}

    >>> print(get_config(env_var='NOTEXIST'))
    None

    >>> print(get_config(env_var='NOTEXIST', default={'a': 'a'}))
    {'a': 'a'}

    >>> print(get_config(env_var='NOTEXIST', given={'a': 'a'}))
    {'a': 'a'}
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:59:06.503270
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG

# Generated at 2022-06-24 02:59:07.902257
# Unit test for function getLogger
def test_getLogger():
    import doctest
    print(doctest.testmod())

# Generated at 2022-06-24 02:59:12.097039
# Unit test for function logger_level
def test_logger_level():
    from . import TEST_LOGGER_NAME

    # Configuration
    logger = logging.getLogger(TEST_LOGGER_NAME)
    level = logging.INFO

    # Test
    initial_logger_level = logger.level
    with logger_level(logger, level):
        assert logger.level == level
    assert logger.level == initial_logger_level



# Generated at 2022-06-24 02:59:16.886370
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert not (_PyInfo.PY2 and _PyInfo.PY3)

# Generated at 2022-06-24 02:59:21.490886
# Unit test for function getLogger
def test_getLogger():
    logger = get_logger()
    try:
        assert logger.level == logging.DEBUG
    finally:
        with open("logtest.log", "r") as logfile:
            contents = logfile.read()
            assert contents == 'test\n'
        os.remove("logtest.log")


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:59:29.764695
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    obj = _PyInfo()
    assert(obj.PY2 == sys.version_info[0] == 2)
    assert(obj.PY3 == sys.version_info[0] == 3)
    assert(obj.string_types == (basestring, ) or obj.string_types == (str, ))
    assert(obj.text_type == str or obj.text_type == unicode)
    assert(obj.binary_type == str or obj.binary_type == bytes)

if __name__ == '__main__':
    _ensure_configured()
    test__PyInfo()
    log = get_logger('test')
    log.info('test')
    log.warning('test')

# Generated at 2022-06-24 02:59:32.549694
# Unit test for function logger_level
def test_logger_level():
    a = get_logger()
    a.debug("Before")
    with logger_level(a, logging.INFO):
        a.debug("Within")
    a.debug("After")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 02:59:35.619631
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test')

    try:
        with logger_level(logger, logging.ERROR):
            raise Exception('Oh no!')
    except Exception as e:
        pass


# Generated at 2022-06-24 02:59:40.963365
# Unit test for function get_config
def test_get_config():
    assert get_config(given=None, env_var=None, default=None) is None
    assert get_config(given=None, env_var=None, default='{"a": "b"}') == {"a": "b"}
    assert get_config(given=None, env_var='{"a": "b"}', default=None) == {"a": "b"}



# Generated at 2022-06-24 02:59:51.140777
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')
    log.debug('test')

    log = get_logger('test2')
    log.info('test2')
    log.debug('test')


if __name__ == '__main__':
    # py2 compat.
    if '--run-docs' not in sys.argv:
        import doctest
        import sys

        # hack to make doctest play nicely with py3.
        from logging import getLogger

        log = getLogger('doctest')
        old_showwarning = log.showwarning
        log.showwarning = lambda *args, **kw: None
        deficiencies = doctest.testmod(
            name=__name__, verbose=True, report=True, optionflags=doctest.ELLIPSIS
        )
       

# Generated at 2022-06-24 02:59:53.092067
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert _PyInfo.PY2 or _PyInfo.PY3
    assert _PyInfo.PY2 != _PyInfo.PY3


# Generated at 2022-06-24 02:59:54.687091
# Unit test for function configure
def test_configure():
    configure()
    logger = logging.getLogger(__name__)
    logger.error('test error')



# Generated at 2022-06-24 02:59:56.975419
# Unit test for function configure
def test_configure():
    get_logger('test_configure').debug('test_configure')


if __name__ == "__main__":
    configure()
    test_configure()

# Generated at 2022-06-24 03:00:08.743113
# Unit test for function get_config
def test_get_config():
    assert get_config(given={'test': True}) == {'test': True}
    os.environ['LOGGING_UNIT'] = '{"test": true}'
    assert get_config(env_var='LOGGING_UNIT') == {'test': True}
    assert get_config(default={'test': True}) == {'test': True}

    try:
        get_config()
    except ValueError:
        pass
    else:
        assert False, "get_config() must raise a ValueError"

    os.environ['LOGGING_UNIT'] = '{"test": true'
    try:
        get_config(env_var='LOGGING_UNIT')
    except ValueError:
        pass

# Generated at 2022-06-24 03:00:14.451563
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    print("Testing constructor of _PyInfo")
    assert _PyInfo.PY2 == True or _PyInfo.PY2 == False
    assert _PyInfo.PY3 == True or _PyInfo.PY3 == False
    assert _PyInfo.PY2 != _PyInfo.PY3
    assert type(_PyInfo.string_types[0]) == str
    assert type(_PyInfo.text_type) == str
    assert type(_PyInfo.binary_type) == bytes
    print("Test finished")


# Generated at 2022-06-24 03:00:21.021186
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    Test constructor of class ``_PyInfo``

    :return: Returns none if test is passed otherwise return AssertionError
    """
    py_info = _PyInfo()
    assert py_info.PY2 is True

    py_info = _PyInfo()
    assert py_info.PY3 is False

    py_info = _PyInfo()
    assert py_info.string_types == (basestring,)
    assert py_info.text_type == unicode
    assert py_info.binary_type == str

    py_info = _PyInfo()
    py_info.PY2 = False
    py_info.PY3 = True
    assert py_info.string_types == (str,)
    assert py_info.text_type == str
    assert py_info.binary_type == bytes


# Generated at 2022-06-24 03:00:30.630286
# Unit test for function get_config
def test_get_config():
    # No configs given
    try:
        get_config()
    except ValueError as e:
        assert str(e) == 'Invalid logging config: None'
        print('Passed test 1')
    else:
        assert False

    # One config given, equal to default
    try:
        get_config(DEFAULT_CONFIG)
    except ValueError as e:
        assert str(e) == 'Invalid logging config: {' in str(e)
        print('Passed test 2')
    else:
        assert False

    # One config given, not equal to default
    try:
        get_config({'version': 1, 'formatters': {'bad': {'format': '%(message)s'}}})
    except ValueError as e:
        assert str(e) == 'Invalid logging config: {' in str

# Generated at 2022-06-24 03:00:40.370041
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.ERROR):
        logger.debug('Message %s', 'DEBUG')
        logger.info('Message %s', 'INFO')
        logger.warning('Message %s', 'WARNING')
        logger.error('Message %s', 'ERROR')
        logger.critical('Message %s', 'CRITICAL')
    with logger_level(logger, logging.INFO):
        logger.debug('Message %s', 'DEBUG')
        logger.info('Message %s', 'INFO')
        logger.warning('Message %s', 'WARNING')
        logger.error('Message %s', 'ERROR')
        logger.critical('Message %s', 'CRITICAL')
    with logger_level(logger, logging.WARNING):
        logger.debug('Message %s', 'DEBUG')
        logger

# Generated at 2022-06-24 03:00:45.801415
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import tempfile

    config = dict(version=1, formatters=dict(f=dict(format='test')))

    filename = tempfile.mktemp()

    with open(filename, 'w') as fh:
        json.dump(config, fh)

    cfg = get_config(default=filename)

    assert cfg == config

    with open(filename, 'w') as fh:
        yaml.dump(config, fh)

    cfg = get_config(default=filename)

    assert cfg == config

    cfg = get_config(default=json.dumps(config))

    assert cfg == config

    cfg = get_config(default=yaml.dump(config))

    assert cfg == config


# Generated at 2022-06-24 03:00:53.440758
# Unit test for function configure
def test_configure():
    import tempfile
    import json
    import os

    temp_file = tempfile.NamedTemporaryFile(delete=False)


# Generated at 2022-06-24 03:01:00.842044
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('test')
    level = log.level
    with logger_level(log, logging.CRITICAL):
        assert log.level == logging.CRITICAL
        with logger_level(log, logging.ERROR):
            assert log.level == logging.ERROR
            assert log.isEnabledFor(logging.ERROR)
            assert not log.isEnabledFor(logging.CRITICAL)
        assert log.level == logging.CRITICAL
    assert log.level == level

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-24 03:01:03.973707
# Unit test for function getLogger
def test_getLogger():
    import logging
    import tempfile
    logger = getLogger()
    logger.setLevel(logging.DEBUG)
    logger.info("hello there")


if __name__ == "__main__":
    test_getLogger()

# Generated at 2022-06-24 03:01:06.419375
# Unit test for function getLogger
def test_getLogger():
    """
    >>> getLogger().info('test')
    >>> getLogger().debug('test')
    >>> getLogger('test1').info('test')
    >>> getLogger('test2').info('test')
    """
    pass


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:01:12.870142
# Unit test for function getLogger
def test_getLogger():
    logger=get_logger('test.logger.getLogger')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')
    assert logger.name=='test.logger.getLogger'

test_getLogger()

# Generated at 2022-06-24 03:01:24.030157
# Unit test for function configure

# Generated at 2022-06-24 03:01:30.913359
# Unit test for function logger_level
def test_logger_level():
    """Test function logger_level."""
    # Load config file
    logging.config.fileConfig(get_script_dir_plus_file('logging.conf'))

    # Create a logger
    logger = logging.getLogger('test_logger_level')

    # Set logger level to level ERROR
    with logger_level(logger, logging.ERROR):
        assert logger.isEnabledFor(logging.ERROR) is True
        assert logger.isEnabledFor(logging.INFO) is False
        assert logger.isEnabledFor(logging.DEBUG) is False
        logger.debug('Good bye!')
        logger.info('Good bye!')
        logger.error('Hello, logs!')

    # Set logger level to level INFO

# Generated at 2022-06-24 03:01:34.742381
# Unit test for function logger_level
def test_logger_level():
    logger_name = 'test_logger_level'
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.ERROR)
    with logger_level(logger, logging.INFO):
        logger.warning('logger_level_test_warning')
    logger.info('logger_level_test_info')

test_logger_level()

# Generated at 2022-06-24 03:01:41.399695
# Unit test for function get_config
def test_get_config():
    config = get_config(config='[1, 2, 3]', env_var='LOGGING', default='[4, 5, 6]')
    assert config == [1, 2, 3]

    config = get_config(config='[1, 2, 3]', env_var='LOGGING')
    assert config == [1, 2, 3]

    config = get_config(config='[1, 2, 3]')
    assert config == [1, 2, 3]

    config = get_config(config=None, env_var='LOGGING', default='[4, 5, 6]')
    assert config == [4, 5, 6]

    config = get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    assert_

# Generated at 2022-06-24 03:01:45.141618
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger()
    with logger_level(log, logging.ERROR):
        log.info('this should not be logged')
    log.info('this should be logged')



# Generated at 2022-06-24 03:01:49.728753
# Unit test for function getLogger
def test_getLogger():
    """
    >>> getLogger().setLevel(logging.FATAL)
    >>> getLogger().fatal('Test for getLogger')
    :return:
    """
    getLogger().setLevel(logging.FATAL)
    getLogger().fatal('Test for getLogger')



# Generated at 2022-06-24 03:01:54.010377
# Unit test for function getLogger
def test_getLogger():
    log = get_logger()
    log.info('test')
    log.debug('debug')


if __name__ == '__main__':
    configure('logger.yaml')
    logger = get_logger('test')
    logger.info('test')
    logger.debug('debug')
    logger.critical('critical')

# Generated at 2022-06-24 03:02:02.370644
# Unit test for function configure
def test_configure():
    from tempfile import NamedTemporaryFile
    from json import dump
    from sys import stdout
    from colorlog import ColoredFormatter

    tmpfile = NamedTemporaryFile('w')


# Generated at 2022-06-24 03:02:03.961973
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    logger.info('test')



# Generated at 2022-06-24 03:02:09.556842
# Unit test for function configure
def test_configure():
    #
    # Test with a bare string that contains invalid logging config
    #
    with pytest.raises(ValueError):
        configure("test")

    #
    # Test with a bare string that contains valid JSON logging config
    #
    json_config = '{ "version": 1, "disable_existing_loggers": false, "formatters": {"simple" : {"format" : "test"}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": "DEBUG" } }, "loggers": { "requests": { "level": "INFO" } } }'

    configure(json_config)
    logger = get_logger("test_configure")
    logger.info("test")
    # Check the configure function does not overwrite the existing logging config
    configure("test")
   

# Generated at 2022-06-24 03:02:15.273549
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance(_PyInfo.PY3, bool)
    assert isinstance(_PyInfo.PY2, bool)
    assert isinstance(_PyInfo.string_types, tuple)
    assert isinstance(_PyInfo.text_type, type)
    assert isinstance(_PyInfo.binary_type, type)
    assert str(type(_PyInfo.PY3)) == "<class 'bool'>"
    assert str(type(_PyInfo.PY2)) == "<class 'bool'>"
    assert str(type(_PyInfo.string_types)) == "<class 'tuple'>"
    assert str(type(_PyInfo.text_type)) == "<class 'type'>"
    assert str(type(_PyInfo.binary_type)) == "<class 'type'>"



# Generated at 2022-06-24 03:02:18.941814
# Unit test for function get_config
def test_get_config():
    from dictknife import loading
    test_config = {"version": 1, "level": "DEBUG"}
    test_dict = get_config(test_config)
    assert loading.dumpfile(test_dict) == "version: 1\nlevel: DEBUG\n"


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:02:20.410456
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    info = _PyInfo()
    assert info.PY2 is True or info.PY3 is True


# Generated at 2022-06-24 03:02:24.787930
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyinfo = _PyInfo()
    assert pyinfo.PY2 or pyinfo.PY3


if __name__ == '__main__':
    logging.root.handlers = []
    log = get_logger()
    log.debug('test')

# Generated at 2022-06-24 03:02:29.166219
# Unit test for function getLogger
def test_getLogger():
    # check default filename of logs
    log = get_logger()

    # test with custom filename
    log = get_logger('test')
    log.info('test')
    assert 'test' in log.name


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:02:33.663519
# Unit test for function getLogger
def test_getLogger():
    """
    >>> logging.basicConfig(level=logging.DEBUG)
    >>> log = getLogger('test_getLogger')
    >>> log.debug('Debug message')
    >>> log.info('Info message')
    >>> log.warning('Warn message')
    """

# Generated at 2022-06-24 03:02:38.697781
# Unit test for function get_config
def test_get_config():
    assert get_config(default='Not really a config') == 'Not really a config'

    json_str = '{"key": "value"}'
    assert get_config(json_str) == {"key": "value"}

    yaml_str = 'key: value'
    assert get_config(yaml_str) == {"key": "value"}

# Generated at 2022-06-24 03:02:40.718494
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    pyInfo = _PyInfo()
    assert pyInfo.PY3 or pyInfo.PY2

# Generated at 2022-06-24 03:02:42.344852
# Unit test for function getLogger
def test_getLogger():
    log = getLogger(__name__)
    log.info('test')
    log.error('test')

# Generated at 2022-06-24 03:02:51.695631
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    import platform

    py_info = _PyInfo()

    assert py_info.PY2 or py_info.PY3
    if py_info.PY2:
        assert sys.version_info[0] == 2
    else:
        assert sys.version_info[0] == 3

    if py_info.PY2:
        assert isinstance("a", py_info.string_types)
        assert isinstance(u"a", py_info.string_types)
        assert type("a") == str
        assert type(u"a") == unicode
        assert py_info.text_type == unicode
        assert py_info.binary_type == str
        assert isinstance("a", py_info.binary_type)
    else:
        assert isinstance("a", py_info.string_types)

# Generated at 2022-06-24 03:03:01.842915
# Unit test for function logger_level
def test_logger_level():
    lvl = logging.DEBUG
    fname = 'test.log'
    try:
        os.remove(fname)
    except OSError:
        pass

    log = get_logger('test_logger_level')
    log.setLevel(lvl)
    log_h = logging.FileHandler(fname)
    log.addHandler(log_h)

    with logger_level(log, logging.INFO):
        log.debug("Debug this")
        log.info("Info this")
        log.warning("Warning this")

    log.debug("Debug this")
    log.info("Info this")
    log.warning("Warning this")

    with open(fname) as f:
        log_contents = f.read()
        # There should only be one message logged

# Generated at 2022-06-24 03:03:09.553357
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    """
    >>> test__PyInfo()
    """
    d = dict()
    for k, v in inspect.getmembers(_PyInfo()):
        if not k.startswith('_'):
            d[k] = v
    assert d['PY2'] != d['PY3']
    assert d['PY2'] != d['PY3']
    assert isinstance('', d['string_types'])
    assert isinstance(b'', d['binary_type'])


# Generated at 2022-06-24 03:03:16.085443
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    assert log.getEffectiveLevel() == logging.DEBUG
    with logger_level(log, logging.WARNING):
        assert log.getEffectiveLevel() == logging.WARNING
    assert log.getEffectiveLevel() == logging.DEBUG



# Generated at 2022-06-24 03:03:24.669197
# Unit test for constructor of class _PyInfo
def test__PyInfo():
    assert isinstance(DEFAULT_CONFIG, dict)
    assert isinstance(DEFAULT_CONFIG.get('version'), int)
    assert isinstance(DEFAULT_CONFIG.get('disable_existing_loggers'), bool)
    assert isinstance(DEFAULT_CONFIG.get('formatters'), dict)
    assert isinstance(DEFAULT_CONFIG.get('handlers'), dict)
    assert isinstance(DEFAULT_CONFIG.get('root'), dict)
    assert isinstance(DEFAULT_CONFIG.get('loggers'), dict)



# Generated at 2022-06-24 03:03:30.316119
# Unit test for function configure
def test_configure():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.info('test')

    log_file = '/tmp/test_log.file'
