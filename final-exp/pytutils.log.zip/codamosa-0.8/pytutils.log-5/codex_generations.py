

# Generated at 2022-06-12 07:54:40.989173
# Unit test for function configure
def test_configure():
    import json
    import yaml
    from threading import Thread

    def test_config_in_thread(config):
        thread = Thread(target=lambda: configure(config))
        thread.start()
        thread.join()

    config = yaml.dump(DEFAULT_CONFIG)
    config1 = json.dumps(DEFAULT_CONFIG)

# Generated at 2022-06-12 07:54:44.666345
# Unit test for function logger_level
def test_logger_level():
    testLogger = logging.getLogger("testLogger")
    testLogger.setLevel(logging.DEBUG)
    testHandler = logging.StreamHandler()
    testLogger.addHandler(testHandler)
    with logger_level(logging.getLogger("testLogger"), logging.INFO):
        testLogger.debug("test")
        assert True
        testLogger.info("test")
        assert True

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:54:48.442578
# Unit test for function logger_level
def test_logger_level():
    from .test_logger import TestLogger

    logger = TestLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET



# Generated at 2022-06-12 07:54:49.841433
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.NOTSET):
        assert log.level == logging.NOTSET
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.DEBUG


# Generated at 2022-06-12 07:54:56.005147
# Unit test for function logger_level
def test_logger_level():
    # test that the logger level is initially set to level during context
    # then restored when context is exited
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
    assert logger.level == logging.DEBUG


if __name__ == '__main__':
    import json
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:55:06.587600
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    f = tempfile.NamedTemporaryFile(delete=False)
    config = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'file': {
                '()': 'logging.Formatter',
                'format': '%(message)s',
            },
        },
        'handlers': {
            'file': {
                'class': 'logging.FileHandler',
                'filename': f.name,
                'formatter': 'file'
            },
        },
        'root': {
            'handlers': ['file'],
        },
    }
    logging.config.dictConfig(config)
    logger = logging.getLogger('test_logger_level')

# Generated at 2022-06-12 07:55:15.912102
# Unit test for function logger_level
def test_logger_level():

        # Set the level of logger to <info>
        logger = logging.getLogger("logger_level_test")
        logger.setLevel(logging.INFO)
        logger.info("Test_1 logger_level: Before blocking context")

        # Unit test for logger_level.
        with logger_level(logger, logging.DEBUG):
                logger.debug("Test_2 logger_level: Inside blocking context")
                logger.info("Test_3 logger_level: Inside blocking context")

        logger.info("Test_4 logger_level: After blocking context")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:55:20.011639
# Unit test for function logger_level
def test_logger_level():
    name = 'test_logger_level'
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    logger.addHandler(ch)
    logger.info('before')
    with logger_level(logger, logging.CRITICAL):
        logger.info('in')
    logger.info('after')
    assert logger.getEffectiveLevel() == logging.DEBUG
    logger.removeHandler(ch)
    assert True

# Generated at 2022-06-12 07:55:28.893830
# Unit test for function logger_level
def test_logger_level():
    root_logger = logging.getLogger('root')
    # assume this is empty - child logger of 'root'
    test_logger = logging.getLogger('root.test')
    test_logger.propagate = False

    # will output nothing
    test_logger.debug('This should not display')

    # use the function logger_level to change logger level to 'DEBUG'
    with logger_level(logger=test_logger, level=logging.DEBUG):
        # will output 'This should display'
        test_logger.debug('This should display')

    # will output nothing
    test_logger.debug('This should not display either')



# Generated at 2022-06-12 07:55:32.673051
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    with logger_level(logger, logging.ERROR):
        logger.debug('This should not be printed')
    logger.debug('This should be printed')

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:55:41.006068
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    assert logger.level == logging.NOTSET

    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO

    assert logger.level == logging.NOTSET

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:55:47.510115
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    with logger_level(logger, logging.ERROR):
        logger.debug('hello')
        logger.info('hello')
        logger.error('hello')

    # with logger_level(logger, logging.INFO):
    #     logger.debug('hello')
    #     logger.info('hello')

    logger.debug('hello')
    logger.info('hello')
    logger.error('hello')



# Generated at 2022-06-12 07:55:54.574105
# Unit test for function logger_level
def test_logger_level():
    '''
    >>> import logging
    >>> log = get_logger(__name__)

    # log does not write warning messages in the default configuration
    >>> log.warning('should not be logged')

    # temporarily setting level to WARNING makes a difference
    >>> with logger_level(log, logging.WARNING):
    ...   log.warning('must be logged in level WARNING')
    ...

    # reset the level to original value
    >>> log.setLevel(logging.INFO)
    '''
    pass



# Generated at 2022-06-12 07:56:03.129626
# Unit test for function logger_level
def test_logger_level():
    import unittest

    class LoggerLevelTest(unittest.TestCase):
        def test_logger_level(self):
            import logging

            logger = logging.getLogger('test_logger_level')
            logger.setLevel(logging.ERROR)
            with logger_level(logger, logging.DEBUG):
                logger.debug('hello')
            logger.debug('bye')

    unittest.TestCase.__str__ = unittest.TestCase.id
    unittest.main()



# Generated at 2022-06-12 07:56:14.284942
# Unit test for function logger_level
def test_logger_level():
    import logging, traceback
    import unittest
    import sys

    class TestLoggerLevel(unittest.TestCase):
        def test_setting_level(self):
            log = get_logger('test_setting_level')
            with logger_level(log, logging.DEBUG):
                log.debug("Debug Level")
                log.info("Info Level")
                log.warn("Warn Level")
                log.error("Error Level")
                log.critical("Critical Level")
                log.exception("Exception Level")
            log.debug("Debug Level")
            log.info("Info Level")
            log.warn("Warn Level")
            log.error("Error Level")
            log.critical("Critical Level")
            log.exception("Exception Level")

        def test_invalid_level(self):
            log = get

# Generated at 2022-06-12 07:56:24.921358
# Unit test for function logger_level
def test_logger_level():

    from logging import NOTSET, DEBUG, INFO, WARNING, ERROR, CRITICAL, getLogger
    # Capture log records for comparison
    from io import StringIO

    logger = getLogger('logger_level')
    out_str = StringIO()
    hdlr = logging.StreamHandler(out_str)
    logger.addHandler(hdlr)

    logger.setLevel(0)
    # No message is sent to the log (level is too low)
    logger.log(DEBUG, 'logger_level test debug message')
    logger.log(WARNING, 'logger_level test warning message')
    assert 'logger_level test' not in out_str.getvalue()

    # No message is sent to the log (level is too low)
    logger.setLevel(WARNING)

# Generated at 2022-06-12 07:56:31.255619
# Unit test for function logger_level
def test_logger_level():
    import tempfile

    log = getLogger()

    test_logger_level.logs = []
    test_logger_level.file = None

    with tempfile.NamedTemporaryFile(mode='w') as f:
        test_logger_level.file = f
        log_handler = logging.FileHandler(filename=f.name)
        log_handler.setLevel(logging.DEBUG)
        log_handler.setFormatter(logging.Formatter('%(message)s'))
        log.addHandler(log_handler)

        # Test that level is initially DEBUG
        log.debug('Test1')
        assert test_logger_level.file.readline().strip() == 'Test1'

        # Test that level is set to INFO

# Generated at 2022-06-12 07:56:36.938908
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger('testing_logger')
    logger.setLevel(logging.WARNING)
    logger.info('test1')
    #logger.debug('test2')

    with logger_level(logger, logging.DEBUG):
        logger.info('test2')
        logger.debug('test3')

    logger.debug('test4')



# Generated at 2022-06-12 07:56:40.370062
# Unit test for function logger_level
def test_logger_level():
    logging.getLogger('test').setLevel(logging.WARNING)
    l = logging.getLogger('test')
    l.debug('this is debug')
    with logger_level(l, logging.DEBUG):
        l.debug('this is debug')

test_logger_level()

# Generated at 2022-06-12 07:56:51.757644
# Unit test for function logger_level
def test_logger_level():
    # create a logger
    logger = logging.getLogger('test_logger_level')

    # create a handler
    handler = logging.StreamHandler()
    handler.setLevel(logging.INFO)
    logger.addHandler(handler)

    # configure the logger
    logger.setLevel(logging.INFO)

    # enter the context
    with logger_level(logger, logging.DEBUG):
        # check if logger.level == DEBUG
        if logger.isEnabledFor(logging.DEBUG):
            logger.debug('This message should be displayed.')
        # check if logger.level == INFO
        if logger.isEnabledFor(logging.INFO):
            logger.info('This message should NOT be displayed.')
    # check if logger.level == INFO again
    if logger.isEnabledFor(logging.DEBUG):
        logger

# Generated at 2022-06-12 07:56:58.897492
# Unit test for function logger_level
def test_logger_level():
    l = get_logger()
    logger_level(l, logging.CRITICAL)
    assert l.getEffectiveLevel() == logging.CRITICAL



# Generated at 2022-06-12 07:57:04.130245
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.DEBUG
    with logger_level(log, logging.CRITICAL):
        assert log.level == logging.CRITICAL
    assert log.level == logging.DEBUG


# Generated at 2022-06-12 07:57:09.386819
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:57:17.462607
# Unit test for function logger_level
def test_logger_level():
    import io
    import unittest
    import logging


# Generated at 2022-06-12 07:57:28.797432
# Unit test for function logger_level
def test_logger_level():
    from contracts import contract
    from time import sleep
    from tempfile import NamedTemporaryFile

    logger = logging.getLogger(__name__)
    initial = logger.level
    assert logger.level == initial


# Generated at 2022-06-12 07:57:37.660154
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test.logger_level')

    with logger_level(log, logging.DEBUG):
        log.debug("This message should be printed")
        log.info("This message should also be printed")

    log.debug("This message should NOT be printed")
    log.info("This message should be printed")

    with logger_level(log, logging.INFO):
        log.info("This message should be printed")
        log.debug("This message should NOT be printed")

    log.debug("This message should NOT be printed")
    log.info("This message should be printed")



# Generated at 2022-06-12 07:57:43.595503
# Unit test for function logger_level
def test_logger_level():
    import time
    import StringIO

    capture = StringIO.StringIO()
    logger = get_logger()
    handler = logging.StreamHandler(capture)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.info('info msg')
        logger.debug('debug msg')
        time.sleep(1)
        logger.info('info msg again')
    logger.debug('debug msg again')
    capture.seek(0)
    assert capture.read() == "info msg\ndebug msg\ninfo msg again\n"
    capture.close()
    logger.removeHandler(handler)

# Generated at 2022-06-12 07:57:51.761687
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('foo')
        logger.warning('bar')
    with logger_level(logger, logging.WARNING):
        logger.debug('foo')
        logger.warning('bar')
    # Test idempotence (can call repeatedly with same params)
    logger.hasHandlers = lambda: True
    with logger_level(logger, logging.DEBUG):
        logger.debug('baz')
        with logger_level(logger, logging.DEBUG):
            logger.debug('oof')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:58:01.122338
# Unit test for function get_config
def test_get_config():
    assert isinstance(get_config(config='{"version": 1}'), dict)
    assert isinstance(get_config(config='version: 1'), dict)
    assert isinstance(get_config(config=DEFAULT_CONFIG), dict)
    assert isinstance(
        get_config(env_var="LOGGING", config='{"version": 1}'), dict)
    assert isinstance(
        get_config(env_var="LOGGING", config='version: 1'), dict)
    assert isinstance(
        get_config(env_var="LOGGING", config=DEFAULT_CONFIG), dict)
    assert isinstance(get_config(config='{"version": 1}'), dict)
    assert isinstance(get_config(config='version: 1'), dict)

# Generated at 2022-06-12 07:58:04.630224
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("logger_level")
    logger.debug("before")
    with logger_level(logger, logging.ERROR):
        logger.debug("inside context")
        logger.error("inside context")
    logger.debug("after")



# Generated at 2022-06-12 07:58:13.344907
# Unit test for function logger_level
def test_logger_level():
    mylogger = getLogger('test_logger_level')
    with logger_level(mylogger, logging.DEBUG):
        mylogger.debug('with section')
    mylogger.debug('outside')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:58:17.663853
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    level_info = logger.info
    level_error = logger.error
    with logger_level(logger, logging.ERROR):
        level_info("should not be logged")
        level_error("should be logged")
    level_info("should be logged")



# Generated at 2022-06-12 07:58:20.563877
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    assert logger.level == logging.WARNING

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    assert logger.level == logging.WARNING
    logging.warning("Hello %s" % "world")

# Generated at 2022-06-12 07:58:24.124364
# Unit test for function logger_level
def test_logger_level():
    import time

    with logger_level(get_logger("test_logger_level"), logging.WARNING):
        get_logger("test_logger_level").error("Message for logger_level")
        time.sleep(1)
        get_logger("test_logger_level").error("Message for logger_level")

# Generated at 2022-06-12 07:58:34.625673
# Unit test for function configure
def test_configure():
    import os
    import sys
    import json
    import tempfile
    import shutil

    kw = dict(
        env_var = 'TEST_LOGGING',
        default = dict(
            handlers = dict(
                maybe = dict(
                    level = logging.INFO,
                ),
            ),
        ),
    )

    with tempfile.TemporaryDirectory() as tdir:
        tfile = os.path.join(tdir, 'log.json')

# Generated at 2022-06-12 07:58:43.490394
# Unit test for function logger_level
def test_logger_level():
    """ unit test for function logger_level """
    log = logging.getLogger('test.logger_level')
    msg = 'test logger_level'
    with logger_level(log, logging.DEBUG):
        # log.warning(msg + ': debug level')
        log.debug(msg + ': debug level')
    # log.warning(msg + ': initial level')
    log.info(msg + ': initial level')


if __name__ == '__main__':
    print('Testing py-log-utils')

    configure()

    print('Testing logger_level')
    test_logger_level()

    print('Testing get_logger')
    log = get_logger()
    log.info('info message')
    log.warning('warning message')
    log.error('error message')

# Generated at 2022-06-12 07:58:45.555053
# Unit test for function configure
def test_configure():
    configure()
    assert logging.getLogger().getEffectiveLevel() == logging.DEBUG



# Generated at 2022-06-12 07:58:48.671534
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.ERROR):
        assert log.isEnabledFor(logging.ERROR)


# Generated at 2022-06-12 07:58:53.652193
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        logger.info('test')
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:58:55.256536
# Unit test for function get_config
def test_get_config():
    assert get_config(default=dict(a=1)) == dict(a=1)


# Generated at 2022-06-12 07:59:10.269697
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    assert log.level == logging.DEBUG

    with logger_level(log, logging.WARNING):
        log.warning('This message will be logged')
        log.info('This message will NOT be logged')
    log.info('This will be logged')


# Generated at 2022-06-12 07:59:14.906695
# Unit test for function logger_level
def test_logger_level():
    logging.config.fileConfig("test_logging_conf.conf")
    log = getLogger("test_logger_level")
    with logger_level(log, logging.DEBUG):
        log.debug("Unexpected debug statement")
    log.debug("Expected debug statement")
    log.info("Expected info statement")


if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:59:24.160925
# Unit test for function logger_level
def test_logger_level():
    DEF_LOG_LVL = logging.INFO
    log = getLogger('logger_lvl')
    log.setLevel(DEF_LOG_LVL)
    log.propagate = True
    log.handlers[0].setLevel(logging.DEBUG)

    log.info('info1')
    log.debug('debug1')

    assert(log.level == DEF_LOG_LVL)
    assert(log.handlers[0].level == logging.DEBUG)

    with logger_level(log, logging.DEBUG):
        log.info('info2')
        log.debug('debug2')
        assert(log.level == logging.DEBUG)
        assert(log.handlers[0].level == logging.DEBUG)

    log.info('info3')
    log.debug('debug3')

# Generated at 2022-06-12 07:59:30.328941
# Unit test for function configure
def test_configure():
    import logging
    import logging.config

    assert logging.root.handlers == []

    cfg = dict(
        version=1,
        formatters={
            'simple': {
                'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            },
        },
        handlers={
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
                'level': logging.DEBUG,
            },
        },
        root=dict(handlers=['console'], level=logging.INFO),
        loggers={
            'test': dict(level=logging.DEBUG),
        },
    )

    configure(cfg)

    log = logging.getLogger('test')


# Generated at 2022-06-12 07:59:40.587988
# Unit test for function configure
def test_configure():
    with open("logging.conf", "w+") as file:
        file.write('version=1\n')
        file.write('disable_existing_loggers=False\n')
        file.write('formatters={\n')
        file.write('    "colored": {"()": "colorlog.ColoredFormatter", \n')
        file.write('                "format":"%(bg_black)s%(log_color)s[%(asctime)s] ')
        file.write('[%(name)s/%(process)d] %(message)s @%(funcName)s:%(lineno)d #%(levelname)s%(reset)s", \n')
        file.write('                "datefmt":"%H:%M:%S"}, \n')

# Generated at 2022-06-12 07:59:47.188634
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    js_str = '{\n\t"version": 1\n}'
    yaml_str = 'version: 1\n'
    assert get_config(js_str) == json.loads(js_str)
    assert get_config(yaml_str) == yaml.load(yaml_str)


if __name__ == '__main__':
    logging.basicConfig(level='DEBUG')
    log = get_logger()
    log.debug('test')
    log.debug('test22')
    with logger_level(log, 'DEBUG'):
        log.debug('test3')

    test_get_config()

# Generated at 2022-06-12 07:59:53.001598
# Unit test for function get_config
def test_get_config():
    default_config = dict(
        disable_existing_loggers="True"
    )

    # Test with config: None
    assert get_config() == None

    # Test with config: "disable_existing_loggers=True"
    assert get_config(config="disable_existing_loggers=True") == "disable_existing_loggers=True"

    # Test with config: {disable_existing_loggers="True"}
    assert get_config(config=default_config) == default_config



# Generated at 2022-06-12 08:00:02.475093
# Unit test for function get_config
def test_get_config():
    """
    Test case for get_config.
    """
    config = get_config(default='{"version": 1}')
    assert config == {'version': 1}, 'incorrect config, should be a dict.'
    config = get_config('{"version": 1}', None, False)
    assert config == {'version': 1}, 'incorrect config, should be a dict.'

    configure()
    log = get_logger()
    log.info('test')

    log = get_logger('test2')
    log.info('test2')

    with logger_level(log, logging.DEBUG):
        log.debug('debug')


if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-12 08:00:09.219162
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    assert(logger.level == logging.NOTSET)
    with logger_level(logger, logging.DEBUG):
        assert(logger.level == logging.DEBUG)
    assert(logger.level == logging.NOTSET)


if __name__ == '__main__':
    print("Running unit tests")
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:00:12.490273
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('this is a DEBUG statement')
    logger.info('this is an INFO statement')



# Generated at 2022-06-12 08:00:35.288269
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    logging_config_json = str(json.dumps(DEFAULT_CONFIG))
    logging_config_yaml = str(yaml.dump(DEFAULT_CONFIG))
    result_json = DEFAULT_CONFIG
    result_yaml = DEFAULT_CONFIG
    assert get_config(logging_config_json) == result_json
    assert get_config(logging_config_yaml) == result_yaml

# Generated at 2022-06-12 08:00:38.326115
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.info('Test message')
    with logger_level(logger, logging.DEBUG):
        logger.debug('Debug message')
    logger.info('Test message')


__all__ = [
    'get_logger',
    'getLogger',
    'configure',
    'get_config',
    'logger_level',
    'test_logger_level'
]

# Generated at 2022-06-12 08:00:41.856328
# Unit test for function get_config
def test_get_config():
    # given a dictionary
    config = {'key': 1}
    assert config == get_config(config, None, None)

    # given a json string
    config = '{"key": 1}'
    assert json.loads(config) == get_config(config, None, None)

    # given a yaml string
    config = 'key: 1'
    assert yaml.load(config) == get_config(config, None, None)



# Generated at 2022-06-12 08:00:47.171831
# Unit test for function logger_level
def test_logger_level():
    """Unit test for function logger_level"""
    from . import colorlog
    import logging
    configure()
    logger = colorlog.get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    with logger_level(logger, logging.INFO):
        logger.debug('test')
    with logger_level(logger, logging.FATAL):
        logger.debug('test')



# Generated at 2022-06-12 08:00:51.920423
# Unit test for function logger_level
def test_logger_level():
    logger_level(__name__, 'DEBUG')
    log = getLogger(__name__)
    log.debug("debug message")
    log.info("info message")
    assert logger_level.__name__ == 'logger_level'
    with logger_level(log, 'INFO'):
        log.info("info message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:01:00.361453
# Unit test for function get_config
def test_get_config():
    config = {'a': 1, 'b': 2}
    os.environ['LOGGING'] = str(config)

    test_config_1 = get_config(config)
    assert test_config_1 == config

    test_config_2 = get_config(env_var='LOGGING')
    assert test_config_2 == config

    test_config_3 = get_config(default=config)
    assert test_config_3 == config

    test_config_4 = get_config()
    assert test_config_4 == config



if __name__ == "__main__":
    import doctest
    doctest.testmod()

    # python -m mu.logger
    log = get_logger(__name__)
    log.info('test')

    test_get_config()

# Generated at 2022-06-12 08:01:08.128805
# Unit test for function logger_level
def test_logger_level():
    # TODO: Asserts are not included.
    # TODO: Unit test for function configure is not included
    log = get_logger()
    log.info('logging level = %s', log.level)
    with logger_level(log, logging.INFO):
        log.debug('message')
        log.info('message')
    log.info('logging level = %s', log.level)
    with logger_level(log, logging.DEBUG):
        log.debug('message')
        log.info('message')
    log.info('logging level = %s', log.level)


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:01:12.227576
# Unit test for function logger_level
def test_logger_level():
    import logging
    import tempfile

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    handler = logging.FileHandler(tempfile.mktemp())
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')

    logger.debug('debug')
    logger.info('info')

    with open(handler.baseFilename, 'r') as f:
        assert f.read() == 'info\n'  # file should contain only info log



# Generated at 2022-06-12 08:01:18.867568
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('info')
    cfg = get_config()

    try:
        logging.config.dictConfig(cfg)
    except TypeError as exc:
        try:
            logging.basicConfig(**cfg)
        except Exception as inner_exc:
            raise inner_exc from exc

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO

# Generated at 2022-06-12 08:01:23.430532
# Unit test for function logger_level
def test_logger_level():
    from cStringIO import StringIO

    log = getLogger(__name__)
    buf = StringIO()
    handler = logging.StreamHandler(buf)
    log.addHandler(handler)
    with logger_level(log, logging.DEBUG):
        log.debug("Test message")
        assert "Test message" in buf.getvalue()
    log.removeHandler(handler)


# Generated at 2022-06-12 08:02:09.177789
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, logging.CRITICAL):
        logger.critical("This is CRITICAL message")
        logger.error("This is ERROR message")
        logger.warning("This is WARNING message")
        logger.info("This is INFO message")
        logger.debug("This is DEBUG message")

# Generated at 2022-06-12 08:02:16.092506
# Unit test for function logger_level
def test_logger_level():
    logger_1 = logging.getLogger('test_logger_level')
    logger_1.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(
        '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: '
        '%(message)s @%(funcName)s:%(lineno)d #%(levelname)s'))
    logger_1.addHandler(handler)
    logger_1.info('test')
    with logger_level(logger_1, logging.DEBUG):
        logger_1.info('test1')
    logger_1.info('test2')

# Generated at 2022-06-12 08:02:19.950449
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('LoggerLevelTest')
    with logger_level(logger, logging.CRITICAL):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')



# Generated at 2022-06-12 08:02:27.614645
# Unit test for function logger_level
def test_logger_level():
    import logging
    import unittest
    import tempfile
    logger = get_logger()
    with tempfile.NamedTemporaryFile() as f:
        with logger_level(logger, logging.DEBUG):
            log_file_handler = logging.FileHandler(f.name)
            logger.addHandler(log_file_handler)
            logger.info('hello')
        with open(f.name) as f:
            assert f.read().strip().endswith('hello')



# Generated at 2022-06-12 08:02:29.654384
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.info('test')

# Generated at 2022-06-12 08:02:36.027621
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    logfile = tempfile.TemporaryFile()  # or NamedTemporaryFile(\'w\')

    logger = logging.getLogger('my_logger')
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler(logfile))

    # default level (INFO)
    logger.info('info')
    logger.warning('warning')

    # changing level
    with logger_level(logger, logging.WARNING):
        logger.info('no info')
        logger.warning('warning')
        with logger_level(logger, logging.DEBUG):
            logger.info('debug')

    # level is back to INFO
    logger.info('info')
    logger.warning('warning')



# Generated at 2022-06-12 08:02:45.207929
# Unit test for function configure
def test_configure():
    import tempfile

    import json

    with tempfile.NamedTemporaryFile(mode='w+') as fp:
        json.dump(DEFAULT_CONFIG, fp)

        fp.flush()
        fp.seek(0)

        original_config = fp.read()

        configure(json.loads(original_config))

        log = get_logger(__name__)
        log.info('hi')
        log.debug('hi%s', 'bob')
        log.debug('hi%s', 'bob', 'bob')
        log.debug('%d', 1)
        log.debug('%d %d', 1, 2)
        log.debug('%d %d %d', 1, 2, 3)
        log.debug('%r', 'bob')
        log.debug

# Generated at 2022-06-12 08:02:53.517911
# Unit test for function configure
def test_configure():
    from io import StringIO

    from colorlog import ColoredFormatter

    logbuf = StringIO()

    logging.getLogger('requests').setLevel(logging.WARNING)


# Generated at 2022-06-12 08:02:55.892850
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug("Shouldn't log anything")
    logger.info("Should log")
    assert True



# Generated at 2022-06-12 08:02:59.776393
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('test_logger_level')
    configure()
    log.info('ONE')
    with logger_level(log, logging.WARNING):
        log.info('TWO')
        log.warning('THREE')
    log.info('FOUR')
    assert True, 'Succeded test_logger_level'
