

# Generated at 2022-06-12 07:54:35.253190
# Unit test for function logger_level
def test_logger_level():
    """Does logger context block work?"""
    logger = logging.getLogger()
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
    assert logger.level == logging.DEBUG


# Generated at 2022-06-12 07:54:37.783118
# Unit test for function logger_level
def test_logger_level():
    import logging
    with logger_level(logging.getLogger(__name__), logging.NOTSET) as l:
        l.warn('test')



# Generated at 2022-06-12 07:54:49.443895
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io
    import pytest

    output = io.StringIO()
    
    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        stream=output,
    )

    logger_test = logging.getLogger('test')
    with logger_level(logger_test, logging.DEBUG):
        logger_test.debug('hellow')
        assert output.getvalue() == 'hellow\n', 'DEBUG level output is wrong'

    output.truncate(0)
    with logger_level(logger_test, logging.INFO):
        logger_test.debug('hellow')
        assert output.getvalue() == '', 'DEBUG level should not be output when level is INFO'

    output.truncate(0)

# Generated at 2022-06-12 07:54:53.184351
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    with logger_level(logger, logging.INFO):
        logger.debug('test')



# Generated at 2022-06-12 07:54:55.637112
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.INFO):
        log.debug('this should not show up')
    log.debug('this should show up')


# Generated at 2022-06-12 07:54:59.931325
# Unit test for function logger_level
def test_logger_level():

    configure()
    logger = logger_level
    assert logger.level != logging.WARNING

    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING

    assert logger.level != logging.WARNING


# Generated at 2022-06-12 07:55:03.733971
# Unit test for function logger_level
def test_logger_level():
    log = get_logger("from_utest")
    log.debug("This message should not appear")
    with logger_level(log, logging.DEBUG):
        log.debug("where are you?")
    log.debug("how about now?")
    assert True

# Generated at 2022-06-12 07:55:06.900642
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug("hello world")
    assert logger.level != logging.DEBUG



# Generated at 2022-06-12 07:55:11.596395
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:55:16.805884
# Unit test for function logger_level
def test_logger_level():
    # get the logger instance
    logger = getLogger()

    # test whether logger level is DEBUG initially
    assert logger.level == logging.DEBUG

    # set logger level to INFO within a context block
    with logger_level(logger, logging.INFO):
        # test whether logger level is set to INFO within the context block
        assert logger.level == logging.INFO

    # test whether logger level is reset to DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:55:23.404172
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config(
        json.dumps(DEFAULT_CONFIG))
    assert DEFAULT_CONFIG == get_config(
        yaml.dump(DEFAULT_CONFIG))

# Generated at 2022-06-12 07:55:33.197466
# Unit test for function get_config
def test_get_config():
    # Pass
    print('\nTest 1: Test passing bare config')
    config = {
        'loggers': {
            'logger1': {
                'handlers': ['handler1'],
                'level': 'DEBUG',
            },
        },
        'handlers': {
            'handler1': {
                'class' : 'logging.StreamHandler',
                'formatter': 'formatter1',
                'level': 'DEBUG',
            },
        },
        'formatters': {
            'formatter1': {
                'format': '%(levelname)s %(name)s: %(message)s',
            },
        },
    }
    try:
        assert get_config(config) == config
    except AssertionError:
        print('Fail 1')

    # Fail
    print

# Generated at 2022-06-12 07:55:37.304178
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.NOTSET):
        log.debug('Doesnt show up')
    log.debug('Show up1')
    with logger_level(log, logging.DEBUG):
        log.debug('Show up2')
    log.debug('Show up3')


# Generated at 2022-06-12 07:55:41.163206
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    assert logger.level == logging.NOTSET
    configure()
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:55:51.767014
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    from contextlib import contextmanager
    from tempfile import NamedTemporaryFile

    # Get a temp file, write to it contextually, read it.
    @contextmanager
    def with_temp_file(mode=''):
        with tempfile.NamedTemporaryFile(mode=mode, delete=False) as fp:
            yield fp
        with open(fp.name, 'r') as fp:
            yield fp.read()

    def test_logger_level(level, expected_output):
        # Make a logger that's set to debug by default.
        log = logging.getLogger(__name__)
        log.setLevel(logging.DEBUG)

        # Use the logger_level context manager to set the logger level to a different
        # level.

# Generated at 2022-06-12 07:55:58.753654
# Unit test for function logger_level
def test_logger_level():
    # Set a logger object
    logger = logging.getLogger(__name__)
    # Set a level to the logger object
    logger.setLevel(logging.INFO)
    # Set a handler for the logger object
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
    logger.addHandler(stream_handler)

    # Set an initial level, INFO
    logger.info('Initial context level: %s', logger.getEffectiveLevel())

    # Call the logger_level function
    with logger_level(logger, logging.DEBUG):
        logger.info('Context level: %s', logger.getEffectiveLevel())
    # Check that the level has been changed
    assert(logger.getEffectiveLevel() == logging.INFO)

# Generated at 2022-06-12 07:56:06.078858
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    assert log.level == logging.DEBUG
    levels = [logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR, logging.CRITICAL]
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
        with logger_level(log, logging.ERROR):
            assert log.level == logging.ERROR
            with logger_level(log, logging.DEBUG):
                assert log.level == logging.DEBUG
            assert log.level == logging.ERROR
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG



# Generated at 2022-06-12 07:56:14.492938
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    logger = logging.getLogger('test')
    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.setLevel(logging.DEBUG)

    # Logger level is initially at debug
    assert logger.isEnabledFor(logging.DEBUG)

    with logger_level(logger, logging.INFO):
        # Logger level has been raised to info
        assert logger.isEnabledFor(logging.INFO)
        logger.debug('debug')
        logger.info('info')

    # Logger level is back at debug
    assert logger.isEnabledFor(logging.DEBUG)

# Generated at 2022-06-12 07:56:24.730337
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        # logger level is set to INFO
        logger.debug("Debug message")
        logger.error("Error message")
    # logger level is restored to DEBUG
    logger.debug("Debug message")


# Not sure we want this here, might bloat the API
# def get_sublogger(*names):
#     """
#     >>> log = get_sublogger(__name__, 'sub1', 'sub2')
#     >>> log.info('test')
#     """
#     _ensure_configured()
#     return logging.getLogger(
#         '.'.join([_namespace_from_calling_context()] + list(names))
#     )



# Generated at 2022-06-12 07:56:29.440675
# Unit test for function logger_level
def test_logger_level():
    """
        >>> logger = getLogger()
        >>> test_logger_level.i = 0
        >>> with logger_level(logger, logging.DEBUG):
        ...     logger.debug('debug')
        ...     test_logger_level.i += 1
        ...     logger.info('info')
        ...     test_logger_level.i += 1
        ...     logger.warning('warning')
        ...     test_logger_level.i += 1
        >>> test_logger_level.i == 3
        True
    """

# Generated at 2022-06-12 07:56:35.135457
# Unit test for function configure
def test_configure():
    logging.info("Begin to configure the logger")
    configure()
    logging.info("configure the logger successfully")

# Generated at 2022-06-12 07:56:38.190356
# Unit test for function logger_level
def test_logger_level():
    from unittest.mock import Mock
    logger = Mock()

    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR

    assert logger.level == 0


# Generated at 2022-06-12 07:56:48.634036
# Unit test for function logger_level
def test_logger_level():
    from . import logger
    from . import log_level
    from . import test_db
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        logger.configure(
            default={'loggers': {'logfile': {'handlers': ['file']}}},
            log_dir=tmpdir,
            log_name='logfile.log'
        )

        log = logger.get_logger('logfile')

        log_level.DEBUG('This message should be written to the log file.')

        with logger_level(log, log_level.DEBUG):
            log_level.DEBUG('This message should not be written to the log file.')

        test_db.process_log_file(os.path.join(tmpdir, 'logfile.log'))



# Generated at 2022-06-12 07:56:50.345132
# Unit test for function configure
def test_configure():
    try:
        configure()
        assert True
    except:
        assert False

# Generated at 2022-06-12 07:56:55.898949
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test_logger_level')
    assert log.level != logging.DEBUG, "logger level set to debug"
    assert log.level == logging.INFO, "logger level not set to info"
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG, "logger level not set to debug"
    assert log.level == logging.INFO, "logger level not set back to info"


# Generated at 2022-06-12 07:57:04.367052
# Unit test for function logger_level
def test_logger_level():
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def test_logger_level(self):
            logger = logging.getLogger(__name__)
            logger.setLevel('INFO')
            with logger_level(logger, 'DEBUG'):
                self.assertEqual(logger.getEffectiveLevel(), logging.DEBUG)
            self.assertEqual(logger.getEffectiveLevel(), logging.INFO)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestLoggerLevel)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-12 07:57:08.382045
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)

    with logger_level(logger, logging.ERROR):
        assert logger.isEnabledFor(logging.ERROR)



# Generated at 2022-06-12 07:57:16.925929
# Unit test for function get_config
def test_get_config():
    # Test case for invalid config
    assert get_config(None, 'ENV', None) == None

    # Test case for invalid env
    assert get_config(None, None, None) == None

    # Test case for valid config

# Generated at 2022-06-12 07:57:28.150202
# Unit test for function logger_level
def test_logger_level():
    import logging
    import tempfile
    import os
    from ansible.utils.logging_utils import logger_level

    with tempfile.TemporaryDirectory() as logdir:
        logpath = os.path.join(logdir, 'logging_utils.log')
        logfile = open(logpath, 'w')
        logging.basicConfig(filename=logpath, level=logging.DEBUG)
        logger = logging.getLogger('ansible.utils.logging_utils')
        with logger_level(logger, logging.ERROR):
            logger.info('logging_level test, this message should not be written')
        with logger_level(logger, logging.INFO):
            logger.info('logging_level test, this message should be written')
        logfile.close()


# Generated at 2022-06-12 07:57:34.161041
# Unit test for function configure
def test_configure():

    with logger_level(logging.getLogger(), logging.DEBUG):

        log = logging.getLogger('test_configure')
        configure()
        log.info("configure")

        log.info("test_configure unit test starting")

# Generated at 2022-06-12 07:57:43.356331
# Unit test for function logger_level
def test_logger_level():
    # This test uses the logging level to write to stdout.
    # Force stdout so the output goes to the screen
    import sys
    sys.stdout.flush()
    from cStringIO import StringIO
    sys.stdout = StringIO()

    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.info("test_logger_level")
        assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.getEffectiveLevel() == logging.INFO
    logger.debug("test_logger_level")

test_logger_level()

# Generated at 2022-06-12 07:57:52.976171
# Unit test for function get_config
def test_get_config():
    DEFAULT = {
        'version': 1,
        'handlers': {
            'file': {
                'class': 'logging.FileHandler',
                'filename': 'logging.log',
                'level': 'INFO',
            },
        },
        'root': {
            'level': 'DEBUG',
            'handlers': ['file'],
        },
        'loggers': {
            'loggers1': {
                'handlers': ['file'],
                'level': 'INFO',
                'propagate': False,
            },
        },
    }
    config = get_config(config=DEFAULT)
    assert config == DEFAULT, 'test for config == DEFAULT failed!'
    config = get_config(config=json.dumps(DEFAULT))

# Generated at 2022-06-12 07:57:56.480713
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger('test-logger-level')
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level != logging.DEBUG


# Generated at 2022-06-12 07:58:00.150894
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.DEBUG):
        assert logging.getLogger().level == logging.DEBUG
        with logger_level(logging.getLogger(), logging.INFO):
            assert logging.getLogger().level == logging.INFO
        assert logging.getLogger().level == logging.DEBUG

# Generated at 2022-06-12 07:58:05.545935
# Unit test for function logger_level
def test_logger_level():
    log_debug = logging.getLogger('test_logger_level_debug')
    configure()

    def f():
        log_debug.debug('debug message')
        log_debug.info('info message')
        log_debug.error('error message')

    f()
    with logger_level(log_debug, logging.ERROR):
        f()
    f()

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:58:15.968184
# Unit test for function logger_level
def test_logger_level():
    import logging
    import pytest
    import sys

    # Create in-memory log stream
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger = logging.getLogger()
    logger.addHandler(handler)

    # Test warning level
    with logger_level(logger, logging.ERROR):
        logger.debug("Message 1")
        logger.info("Message 2")
        logger.warning("Message 3")
        logger.error("Message 4")
        logger.critical("Message 5")

        # Test level
        assert logger.level == logging.ERROR
        # Test messages
        out = stream.getvalue()
        assert "Message 1" not in out
        assert "Message 2" not in out
        assert "Message 3" not in out
        assert "Message 4" in out

# Generated at 2022-06-12 07:58:22.074319
# Unit test for function logger_level
def test_logger_level():
    test_log = logging.getLogger('test_logger_level')
    test_log.setLevel(logging.ERROR)
    with logger_level(test_log, logging.DEBUG):
        test_log.debug('debug')
        test_log.info('info')
        test_log.warn('warn')
        test_log.warning('warning')
        test_log.error('error')
    test_log.debug('debug')
    test_log.info('info')
    test_log.warn('warn')
    test_log.warning('warning')
    test_log.error('error')


test_logger_level()

# Generated at 2022-06-12 07:58:26.017094
# Unit test for function logger_level
def test_logger_level():
    # First, check that the warning is not emitted
    with logger_level(logging.getLogger(), logging.CRITICAL):
        logging.warning('this should not be emitted')
    # Now, check that the warning is emitted
    with logger_level(logging.getLogger(), logging.WARNING):
        logging.warning('this should be emitted')

# Generated at 2022-06-12 07:58:28.401256
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('this should be printed')
    log.debug('this should not be printed')

# Generated at 2022-06-12 07:58:39.249415
# Unit test for function logger_level
def test_logger_level():
    from mock import patch

    logger = logging.getLogger(__name__)

    with patch.object(logger, 'debug') as mock_method:
        with logger_level(logger, level=logging.DEBUG):
            logger.debug('foo')
        assert mock_method.call_count == 1

    with patch.object(logger, 'debug') as mock_method:
        with logger_level(logger, level=logging.INFO):
            logger.debug('foo')
        assert mock_method.call_count == 0

    with patch.object(logger, 'debug') as mock_method:
        with logger_level(logger, level=logging.DEBUG):
            logger.debug('foo')
        assert mock_method.call_count == 1

# Generated at 2022-06-12 07:58:50.174927
# Unit test for function get_config
def test_get_config():
    '''
    Test for method get_config
    '''
    assert get_config(1) == 1


if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-12 07:58:52.404597
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert log.getEffectiveLevel() == logging.DEBUG
    with logger_level(log, logging.WARN):
        assert log.getEffectiveLevel() == logging.WARN
        log.debug('should not display')
        log.info('should not display')
    assert log.getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-12 07:58:59.928483
# Unit test for function get_config
def test_get_config():
    logging.config.dictConfig(get_config('./logging.json'))
    log = logging.getLogger(__name__)
    log.info('test')

    logging.config.dictConfig(get_config('./logging.yaml'))
    log = logging.getLogger(__name__)
    log.info('test')

    logging.config.dictConfig(get_config(json.dumps(DEFAULT_CONFIG)))
    log = logging.getLogger(__name__)
    log.info('test')

    logging.config.dictConfig(get_config(yaml.dump(DEFAULT_CONFIG)))
    log = logging.getLogger(__name__)
    log.info('test')


if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-12 07:59:06.696744
# Unit test for function logger_level
def test_logger_level():
    """
    >>> import logging
    >>> log = logging.getLogger('testing')
    >>> log.setLevel(10)
    >>> log.level = 10
    >>> log.debug('hello')
    >>> with logger_level(log, logging.INFO):
    ...     log.debug('hello')
    >>> log.info('hello')
    """


# backward compat
# TODO(sshaw): remove this alias. Maybe git-grep and fix all uses?
namespace_logger = get_logger



# Generated at 2022-06-12 07:59:10.538552
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('This should not print')
        logger.info('This should print')
        logger.warn('This should print')
        logger.error('This should print')



# Generated at 2022-06-12 07:59:15.811875
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug("test_logger_level(): Debug level message")
        log.info("test_logger_level(): Info level message")
        log.warning("test_logger_level(): Warning level message")
        log.error("test_logger_level(): Error level message")
        log.critical("test_logger_level(): Critical level message")

# Generated at 2022-06-12 07:59:22.454910
# Unit test for function logger_level
def test_logger_level():
    # Set up the logger with a specific level
    test_logger = logging.getLogger()
    test_logger.setLevel(logging.INFO)

    with logger_level(test_logger, logging.DEBUG):
        assert test_logger.isEnabledFor(logging.DEBUG)
        assert not test_logger.isEnabledFor(logging.INFO)

    assert not test_logger.isEnabledFor(logging.DEBUG)
    assert test_logger.isEnabledFor(logging.INFO)



# Generated at 2022-06-12 07:59:27.780619
# Unit test for function logger_level
def test_logger_level():
    import sys
    from io import StringIO
    log = get_logger()
    buf = StringIO()
    sys.stderr = buf
    log.setLevel(logging.INFO)
    log.debug('I am not logged')
    with logger_level(log, logging.DEBUG):
        log.debug('I am now logged')
    log.debug('I am not logged again')
    assert buf.getvalue() == 'I am now logged\n'
    sys.stderr = sys.__stderr__
    return True

# Generated at 2022-06-12 07:59:37.713852
# Unit test for function logger_level
def test_logger_level():
    """ Test logger_level() with info and debug messages."""
    log = getLogger() # get a logger
    # these should print
    print("BEFORE")
    log.info("log.info(): this message should print")
    log.debug("log.debug(): this message should print")
    # these should not print
    with logger_level(log, logging.DEBUG):
        print("DEBUG")
        log.info("log.info(): this message should print")
        log.debug("log.debug(): this message should print")
        # these should not print
        with logger_level(log, logging.INFO):
            print("INFO")
            log.info("log.info(): this message should print")
            log.debug("log.debug(): this message should print")
        # these should print
        print("BACK TO DEBUG")

# Generated at 2022-06-12 07:59:38.338878
# Unit test for function get_config
def test_get_config():
    pass

# Generated at 2022-06-12 07:59:51.184578
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    configure()  # Make sure logging is configured for the below to work...

    with logger_level(logger, logging.CRITICAL):
        logger.debug('This will not appear')
        logger.critical('This will appear')
    logger.debug('This will also appear')

# Generated at 2022-06-12 07:59:53.464673
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert log.level == logging.DEBUG

    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO

    assert log.level == logging.DEBUG

# Generated at 2022-06-12 07:59:57.926917
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger("test_logger_level")
    log.setLevel(logging.ERROR)
    assert not log.isEnabledFor(logging.DEBUG)
    with logger_level(log, logging.DEBUG):
        assert log.isEnabledFor(logging.DEBUG)
    assert not log.isEnabledFor(logging.DEBUG)

# Generated at 2022-06-12 08:00:05.443155
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)

    # Check that the logger level is at the default value of DEBUG
    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.INFO):
        # Check that the logger level is modified
        assert logger.level == logging.INFO

    # Check that the logger level is reset to DEBUG
    assert logger.level == logging.DEBUG

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:00:09.802086
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    assert logger.level == 10, "The default logging level for a logger should be 10"
    with logger_level(logger, 20):
        assert logger.level == 20, "The logger level should be changed within the context"
    assert logger.level == 10, "The logger level should be reset after the context"

# Generated at 2022-06-12 08:00:20.703863
# Unit test for function logger_level
def test_logger_level():
    import logging
    import colorlog

    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    log.handlers = []
    ch = colorlog.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = colorlog.ColoredFormatter('%(log_color)s%(message)s')
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    log.addHandler(ch)

    with logger_level(log, logging.ERROR):
        log.debug("This should be logged")
        log.info("This too")
        log.warning("And even this")
    log.info("This should all be logged")

# Generated at 2022-06-12 08:00:26.080074
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    info_called = False
    error_called = False

    def info(msg):
        nonlocal info_called
        info_called = True

    def error(msg):
        nonlocal error_called
        error_called = True

    with logger_level(log, level=logging.DEBUG):
        log.debug = info
        log.info("Testing logger_level")
        assert info_called

    with logger_level(log, level=logging.ERROR):
        log.error = error
        log.info("Testing logger_level")
        assert not error_called
        log.error("Testing logger_level")
        assert error_called

# Generated at 2022-06-12 08:00:28.736850
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.WARNING)
    assert logger.level == 30

    with logger_level(logger, logging.DEBUG):
        assert logger.level == 10

    assert logger.level == 30

# Generated at 2022-06-12 08:00:31.270667
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()
    # import ipdb; ipdb.set_trace()
    logger = get_logger('foo')
    with logger_level(logger , logging.INFO):
        logger.debug('debug info')

# Generated at 2022-06-12 08:00:39.382481
# Unit test for function logger_level

# Generated at 2022-06-12 08:01:03.895780
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
        with logger_level(logger, logging.ERROR):
            assert logger.level == logging.ERROR
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 08:01:06.906955
# Unit test for function configure
def test_configure():
    import sys
    import logging
    configure()
    log = logging.getLogger(__name__)
    log.info('test')
    log.warning('test')
    return 0


# Generated at 2022-06-12 08:01:12.538681
# Unit test for function get_config
def test_get_config():
    # test for bare string
    assert get_config('test') == 'test'

    # test for json string
    assert get_config('{"test": "test"}')['test'] == 'test'

    # test for yaml string
    import yaml
    assert get_config(yaml.dump({'test': 'test'}))['test'] == 'test'

    # test for non string
    assert get_config({'test': 'test'})['test'] == 'test'

# Generated at 2022-06-12 08:01:23.043752
# Unit test for function logger_level
def test_logger_level():
    import sys

    logger = logging.getLogger(__name__)

    # Set to DEBUG and confirm messages are logged
    with logger_level(logger, logging.DEBUG):
        logger.info('test')

    assert sys.stdout.getvalue().strip() == 'test'

    # Set to ERROR and confirm no messages are logged
    with logger_level(logger, logging.ERROR):
        logger.info('test2')

    assert sys.stdout.getvalue().strip() == 'test'

    # Set back to DEBUG and confirm messages are logged
    with logger_level(logger, logging.DEBUG):
        logger.info('test3')

    assert sys.stdout.getvalue().strip() == 'test\ntest3'


if __name__ == '__main__':
    import logging
    import io


# Generated at 2022-06-12 08:01:32.385536
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import os
    tmpfile = tempfile.NamedTemporaryFile()
    tmpfile.write(''.encode('utf-8'))
    LOGFILE = tmpfile.name
    configure()
    logger = get_logger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.FileHandler(LOGFILE))
    with logger_level(logger, logging.INFO):
        logger.info('INFO in test_logger_level')
        assert(logger.level == logging.INFO)
    logger.info('INFO in test_logger_level')
    assert(logger.level == logging.DEBUG)
    assert(os.stat(LOGFILE).st_size > 0)

# Generated at 2022-06-12 08:01:36.971689
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.INFO):
        log.debug("debug in logger_level")
        log.info("info in logger_level")
        log.warn("warn in logger_level")
    log.debug("debug out logger_level")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:01:42.740658
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('mock')
    logger.setLevel(logging.ERROR)
    with logger_level(logger, logging.DEBUG):
        # The logger will print logging.DEBUG
        logger.debug('test_logger_level')
        assert logger.level == logging.DEBUG
    # The logger will not print logging.DEBUG after exit context block
    logger.debug('test_logger_level')
    assert logger.level == logging.ERROR

# Generated at 2022-06-12 08:01:49.117095
# Unit test for function logger_level
def test_logger_level():
    config = get_config(default=dict(
        version=1,
        disable_existing_loggers=False,
        handlers={
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'colored',
                'level': logging.DEBUG,
            },
        },
        root=dict(handlers=['console'], level=logging.DEBUG),
    ))

    logging.config.dictConfig(config)
    log = logging.getLogger()

    try:
        with logger_level(log, logging.DEBUG):
            log.info('Debugging 1')
    except:
        pass
    log.info('Info')
    try:
        with logger_level(log, logging.INFO):
            log.info('Debugging 2')
    except:
        pass


# Generated at 2022-06-12 08:01:57.474008
# Unit test for function get_config

# Generated at 2022-06-12 08:02:07.661190
# Unit test for function get_config

# Generated at 2022-06-12 08:02:29.083130
# Unit test for function logger_level
def test_logger_level():
    logging.config.fileConfig('logging.ini')
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.INFO):
        logger.debug('Test message')
    assert logger.level == logging.DEBUG



# Generated at 2022-06-12 08:02:33.033905
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    logger.setLevel(logging.INFO)

    with logger_level(logger, logging.DEBUG):
        logger.debug('this should show up')
        logger.info('this should not show up')

    logger.debug('this should not show up')
    logger.info('this should show up')


# Generated at 2022-06-12 08:02:33.994130
# Unit test for function logger_level
def test_logger_level():
    # TBD
    return



# Generated at 2022-06-12 08:02:41.523805
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("Dummy")
    with logger_level(logger, logging.FATAL):
        logger.debug("Should not show")
        logger.critical("This is fatal")

    with logger_level(logger, logging.INFO):
        logger.debug("Should not show")
        logger.critical("This is fatal")
        logger.info("Info message")

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:02:43.205993
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('Test message')
    log.debug('Test message')

# Generated at 2022-06-12 08:02:49.599556
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    dict_config = dict(root=dict(handlers=['console'], level=logging.DEBUG))
    json_config = json.dumps(dict_config)
    yaml_config = yaml.dump(dict_config)

    assert get_config(default=dict_config) == dict_config
    assert get_config(default=json_config) == dict_config
    assert get_config(default=yaml_config) == dict_config
    assert get_config(config=json_config) == dict_config
    assert get_config(config=yaml_config) == dict_config



# Generated at 2022-06-12 08:02:51.623762
# Unit test for function logger_level
def test_logger_level():
    l = get_logger()
    with logger_level(l, logging.ERROR):
        assert l.level == logging.ERROR
    assert l.level == logging.DEBUG



# Generated at 2022-06-12 08:02:59.766751
# Unit test for function logger_level
def test_logger_level():
    import logging
    import os
    import tempfile

    from .safely import check_output, CalledProcessError

    #
    # Set up the logging
    #
    logger = logging.getLogger()
    # configdir = tempfile.mkdtemp(suffix='logging')

    #
    # Log file to log everything to.
    #
    # logfile = tempfile.NamedTemporaryFile(prefix='test_logger_level', suffix='.log', dir=configdir, delete=False)
    logfile = tempfile.NamedTemporaryFile(prefix='test_logger_level', suffix='.log', delete=False)
    logfile.close()

    #
    # Configure the logger.
    #

# Generated at 2022-06-12 08:03:07.232209
# Unit test for function logger_level
def test_logger_level():
    my_logger = logging.Logger('my_logger')
    my_logger.setLevel(logging.DEBUG)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(message)s')
    console_handler.setFormatter(formatter)
    my_logger.addHandler(console_handler)
    my_logger.debug('this message is at the debug level')
    try:
        with logger_level(my_logger, logging.INFO):
            my_logger.debug('this message is at the info level')
            my_logger.info('this message is at the info level')
        my_logger.debug('this message is at the debug level')
    except Exception:
        raise

# Generated at 2022-06-12 08:03:10.799435
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger(__name__)

    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO

    assert logger.level != logging.INFO

# Generated at 2022-06-12 08:04:00.267099
# Unit test for function get_config

# Generated at 2022-06-12 08:04:02.774797
# Unit test for function get_config
def test_get_config():
    # Test bare
    assert get_config('DEBUG') == 'DEBUG'

    # Test json
    assert get_config('{"DEBUG": true}') == {"DEBUG": True}

    # Test yaml
    assert get_config(
        """
        DEBUG: true
        """
    ) == {"DEBUG": True}

# Generated at 2022-06-12 08:04:07.419721
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    logger.setLevel(logging.NOTSET)
    assert not logger.disabled

    with logger_level(logger, logging.FATAL):
        assert logger.disabled

        with logger_level(logger, logging.ERROR):
            assert not logger.disabled
            logger.error('some error')

        assert logger.disabled

    assert not logger.disabled

# Generated at 2022-06-12 08:04:09.749564
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    assert logger.level == logging.NOTSET

    with logger_level(logger, 10):
        assert logger.level == 10

    assert logger.level == logging.NOTSET

# Generated at 2022-06-12 08:04:12.754790
# Unit test for function logger_level
def test_logger_level():
    import my_logging
    log = my_logging.getLogger()
    with my_logging.logger_level(log, logging.WARNING):
        log.warning("This will be logged")  # This does not generate a log message
    log.info("This will be logged")  # This does generate a log message

# Generated at 2022-06-12 08:04:21.250706
# Unit test for function configure
def test_configure():
    import tempfile

    # with tempfile.NamedTemporaryFile('w', suffix='.json') as f:
    #     f.write('{"version": 1, "disable_existing_loggers": False, "formatters": {"simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": "DEBUG"}}, "root": {"handlers": ["console"], "level": "DEBUG"}}')

# Generated at 2022-06-12 08:04:22.494863
# Unit test for function logger_level
def test_logger_level():
    # TODO
    with logger_level(logging.getLogger(), logging.DEBUG):
        logging.debug('test')

# Generated at 2022-06-12 08:04:25.708167
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.DEBUG)
    log = getLogger()
    with logger_level(log, logging.DEBUG):
        log.info('Below message should not be logged..')
        log.debug('This should be logged.')
    log.info('Below message should be logged.')