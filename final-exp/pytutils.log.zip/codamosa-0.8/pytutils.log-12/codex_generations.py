

# Generated at 2022-06-12 07:54:37.252171
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        with logger_level(logger, logging.DEBUG):
            assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO



# Generated at 2022-06-12 07:54:45.137007
# Unit test for function logger_level
def test_logger_level():
    import conftest
    import logging
    import sys
    logger = logging.getLogger(conftest.__name__)
    logger.setLevel(logging.INFO)
    fh = logging.StreamHandler(sys.stderr)
    logger.addHandler(fh)
    with logger_level(logger, logging.DEBUG):
        logger.debug('a debug message')
    logger.info('an info message')
    logger.removeHandler(fh)
    fh.close()

# Generated at 2022-06-12 07:54:51.619687
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__+"_test_logger_level")
    logger.setLevel(logging.DEBUG)
    logger.info("Before")

    with logger_level(logger,logging.ERROR):
        logger.debug("Should not see this")
        logger.error("This is an error")

    logger.info("After")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:54:54.374896
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    logger.warning('test message')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test message')
    logger.warning('test message')

# Generated at 2022-06-12 07:54:57.446997
# Unit test for function configure
def test_configure():
    """
    >>> configure() # doctest: +ELLIPSIS
    """


# Generated at 2022-06-12 07:55:01.072297
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.ERROR):
        logger.debug('This will not appear')
        logger.error('This will appear')
    logger.debug('This will appear again')



# Generated at 2022-06-12 07:55:04.057709
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.ERROR):
        logger.info("I should not log!")
        logger.error("I should log!")

# Generated at 2022-06-12 07:55:06.858828
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    assert logger.level == 10

    with logger_level(logger, logging.DEBUG):
        assert logger.level == 10

    assert logger.level == 10


# Generated at 2022-06-12 07:55:17.757491
# Unit test for function get_config
def test_get_config():
    import json
    json_config = json.dumps(DEFAULT_CONFIG)

    import yaml
    yaml_config = yaml.dump(DEFAULT_CONFIG)

    config = get_config(json_config)
    assert config.get('version') == 1

    config = get_config(yaml_config)
    assert config.get('version') == 1

    config = get_config(DEFAULT_CONFIG)
    assert config.get('version') == 1

    config = get_config(dict(a=1), 'LOGGING', DEFAULT_CONFIG)
    assert config.get('a') == 1

    os.environ['LOGGING'] = json_config
    config = get_config(None, 'LOGGING')
    assert config.get('version') == 1

    config = get_config

# Generated at 2022-06-12 07:55:27.722418
# Unit test for function logger_level

# Generated at 2022-06-12 07:55:40.694951
# Unit test for function get_config
def test_get_config():
    config_dict = {'version': 1, 'root': {'level': 'DEBUG', 'handlers': ['console']}, 'handlers': {'console': {'class': 'logging.StreamHandler', 'level': 'DEBUG', 'formatter': 'colored'}}, 'formatters': {'colored': {'()': 'colorlog.ColoredFormatter', 'format': '%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s', 'datefmt': '%H:%M:%S'}}}

    cfg = get_config(default=DEFAULT_CONFIG)
    assert cfg

# Generated at 2022-06-12 07:55:50.745380
# Unit test for function logger_level
def test_logger_level():
    """Test the function logger_level"""
    logger = logging.getLogger(__name__)

    # Check that the logger has info level
    assert logger.level == logging.INFO, "logger level should be INFO before changing level"

    # Set the logger level to DEBUG
    with logger_level(logger, logging.DEBUG):
        # Check that the logger level has been changed to DEBUG
        assert logger.level == logging.DEBUG, "logger level should be DEBUG inside context"

    # Check that the logger level has been reverted to INFO
    assert logger.level == logging.INFO, "logger level should be INFO outside context"


__all__ = [
    'configure',
    'get_logger',
    'getLogger',
    'logger_level',
]

# Generated at 2022-06-12 07:55:58.415039
# Unit test for function logger_level
def test_logger_level():
    """Test function logger_level"""
    import logging
    import sys

    # Set up logger
    log = logging.getLogger("test_logger_level")
    # Add NullHandler so messages don't go to the console
    log.addHandler(logging.NullHandler())
    # Assert that no messages are recorded
    assert not log.handlers[0].buffer

    # Within context of logger_level, log message and assert it is logged
    with logger_level(log, logging.DEBUG):
        log.debug("Test message")
        assert log.handlers[0].buffer
        assert log.handlers[0].buffer[-1].getMessage() == "Test message"

    # Assert nothing was logged outside context block
    assert not log.handlers[0].buffer

    # Within context of logger_level, log message and assert it

# Generated at 2022-06-12 07:56:07.161098
# Unit test for function logger_level
def test_logger_level():
    import logging
    import time
    import datetime
    logger = get_logger()
    logger.info("Info before context")
    with logger_level(logger, logging.WARNING):
        logger.debug("This will not be shown")
        logger.info("This will not be shown")
        logger.warning("Warning in context")
        logger.critical("Critical in context")
    logger.info("Info after context")
    # Check that non-warnings were not printed
    # This can be done by checking the log file
    log_file = os.path.join(os.path.dirname(__file__), "test_logger_level.log")
    with open(log_file, "r") as f:
        lines = f.readlines()
    assert("Info before context" in lines[0])

# Generated at 2022-06-12 07:56:12.969937
# Unit test for function logger_level
def test_logger_level():
    """
    >>> import logging
    >>> log = logging.getLogger(__name__)
    >>> log.setLevel(logging.DEBUG)
    >>> log.debug('I should be seen')
    >>> with logger_level(log, logging.INFO):
    ...   log.debug('I should not be seen')
    >>> log.debug('I should be seen also')
    """
    pass



# Generated at 2022-06-12 07:56:15.764186
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert log.level == logging.DEBUG
    with logger_level(log, logging.WARNING):
        assert log.level == logging.WARNING
    assert log.level == logging.DEBUG

# Generated at 2022-06-12 07:56:25.354188
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)

    with logger_level(log, logging.WARN):
        log.debug('foo')
        log.info('bar')
        assert log.isEnabledFor(logging.DEBUG) == False
        assert log.isEnabledFor(logging.INFO) == False
        assert log.isEnabledFor(logging.WARN) == True

    with logger_level(log, logging.INFO):
        log.debug('foo')
        log.info('bar')
        assert log.isEnabledFor(logging.DEBUG) == False
        assert log.isEnabledFor(logging.INFO) == True
        assert log.isEnabledFor(logging.WARN) == True

# vim: set sw=4 ts=4 expandtab :

# Generated at 2022-06-12 07:56:27.284259
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.INFO):
        assert logger.getEffectiveLevel() == logging.INFO, "logger_level doesn't work"

# Generated at 2022-06-12 07:56:30.297359
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)

    with logger_level(logger, logging.DEBUG):
        logger.debug('TEST')

    with logger_level(logger, logging.ERROR):
        logger.error('TEST2')

# Generated at 2022-06-12 07:56:35.468080
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        assert not logger.isEnabledFor(logging.DEBUG)
    assert logger.isEnabledFor(logging.DEBUG)

# Generated at 2022-06-12 07:56:47.340910
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    log.addHandler(ch)
    log.info("Hey")
    with logger_level(log, logging.ERROR) as l:
        log.info("No one will read this")
    log.info("We're back to normal")
    assert True

if __name__ == "__main__":
    # Test the logger_level
    test_logger_level()

# Generated at 2022-06-12 07:56:56.609720
# Unit test for function get_config
def test_get_config():
    from colorlog import ColoredFormatter

    config = get_config('{"version": 1}', default=None)
    assert config['version'] == 1


# Generated at 2022-06-12 07:57:02.165896
# Unit test for function get_config
def test_get_config():
    import pprint
    try:
        config = get_config(config=None, env_var=None, default=None)
    except ValueError as err:
        print(err)
    print("config is: %s" % pprint.pformat(config))
    print("config is: %s" % config['formatters']['colored']['()'])

# Generated at 2022-06-12 07:57:03.130321
# Unit test for function logger_level
def test_logger_level():
    assert 1==1



# Generated at 2022-06-12 07:57:13.302334
# Unit test for function logger_level
def test_logger_level():
    import doctest
    from logging import DEBUG, INFO
    from contextlib import contextmanager
    log = getLogger(__name__)
    def _test_logger_level(log, level):
        """
        >>> log.debug('debug message')
        >>> log.info('info message')
        >>> log.warning('warning message')
        >>> log.error('error message')
        >>> with logger_level(log, logging.DEBUG):
        ...     log.debug('debug message')
        ...     log.warning('warning message')
        ...     log.error('error message')
        ...     log.info('info message')
        ...
        >>> log.debug('debug message')
        >>> log.info('info message')
        >>> log.warning('warning message')
        >>> log.error('error message')
        """

# Generated at 2022-06-12 07:57:18.601230
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This will be logged")
        logger.info("This will be logged")
        logger.warning("This will be logged")
        logger.error("This will be logged")
        logger.critical("This will be logged")
    logger.debug("This won't be logged")
    logger.info("This won't be logged")
    logger.warning("This won't be logged")
    logger.error("This won't be logged")
    logger.critical("This won't be logged")


# A bunch of utility functions stolen from logging.utils in Python 3.3-3.5

# Generated at 2022-06-12 07:57:22.989280
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)
        logger.debug("foo bar baz")
    assert not logger.isEnabledFor(logging.DEBUG)

# Generated at 2022-06-12 07:57:25.528769
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG


if __name__ == '__main__':
    import nose

    nose.runmodule()

# Generated at 2022-06-12 07:57:27.923236
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()

    logger.setLevel(logging.DEBUG)
    assert logger.level == logging.DEBUG
    logger.debug("Debug message.")

    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        logger.debug("Debug message.")

    assert logger.level == logging.DEBUG
    logger.debug("Debug message.")

# Generated at 2022-06-12 07:57:35.375789
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('some_logger')

    # Setting level to WARNING
    logger.setLevel(logging.WARNING)
    logger.info('Some info')
    logger.warning('Some warning')

    assert(logger.level == logging.WARNING)

    # Setting level to INFO
    with logger_level(logger, logging.INFO):
        logger.info('Some info')
        logger.warning('Some warning')

    assert(logger.level == logging.WARNING)

# Generated at 2022-06-12 07:57:42.709282
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("debug")
        log.info("info")
    log.debug("debug")
    log.info("info")

# Generated at 2022-06-12 07:57:46.999717
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    initial_level = logger.getEffectiveLevel()
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.getEffectiveLevel() == initial_level
        


# Generated at 2022-06-12 07:57:51.175833
# Unit test for function logger_level
def test_logger_level():
    from logging import DEBUG, INFO

    log = get_logger()

    with logger_level(log, INFO):
        log.debug("Don't show me")

    with logger_level(log, DEBUG):
        log.debug("Show me")

    log.debug("Don't show me either")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:58:00.588021
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, logging.CRITICAL):
        logger.critical("critical test")
        logger.info("info test")
        logger.debug("debug test")
        logger.error("error test")
        logger.warning("warning test")

    with logger_level(logger, logging.ERROR):
        logger.critical("critical test")
        logger.info("info test")
        logger.debug("debug test")
        logger.error("error test")
        logger.warning("warning test")

    with logger_level(logger, logging.WARNING):
        logger.critical("critical test")
        logger.info("info test")
        logger.debug("debug test")
        logger.error("error test")
        logger.warning("warning test")


# Generated at 2022-06-12 07:58:02.884297
# Unit test for function logger_level
def test_logger_level():
    configure()
    logger = get_logger(__name__)
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:58:10.333396
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    assert log.level == logging.DEBUG
    with logger_level(log, logging.ERROR):
        assert log.level == logging.ERROR
    assert log.level == logging.DEBUG

if __name__ == "__main__":
    import logging
    import doctest
    logging.basicConfig(level=logging.DEBUG)
    (failure_count, test_count) = doctest.testmod()
    if failure_count:
        sys.exit(-1)

# Generated at 2022-06-12 07:58:19.484506
# Unit test for function logger_level
def test_logger_level():
    # create logger
    test_logger = logging.getLogger(__name__)
    # set logger level to 'CRITICAL'
    test_logger.setLevel(30)
    # setting level at criical should not print debug or info logs.
    test_logger.info('This should not be printed as the logger is at critical')
    test_logger.debug('This should not be printed as the logger is at critical')
    # change level to 'DEBUG' within a context block.
    with logger_level(test_logger, logging.INFO):
        assert test_logger.level == 20, 'Logger not at expected level'
        test_logger.info('This should be printed as the logger is at INFO')
    # The logger level should be at critical outside the context block.

# Generated at 2022-06-12 07:58:28.030784
# Unit test for function logger_level
def test_logger_level():
    import unittest
    from cStringIO import StringIO
    from contextlib import contextmanager
    try:
        import mock
    except ImportError:
        import unittest.mock as mock

    @contextmanager
    def captured_logging(*args, **kwargs):
        out, sys.stdout = sys.stdout, StringIO()
        try:
            yield sys.stdout
        finally:
            sys.stdout = out

    @contextmanager
    def asserted_logging(*args, **kwargs):
        expected = kwargs.pop('expected', False)
        with captured_logging(*args, **kwargs) as actual:
            yield actual
        self.assertEqual(expected, actual.getvalue().strip())


# Generated at 2022-06-12 07:58:39.248559
# Unit test for function logger_level
def test_logger_level():
    import sys
    logger = logging.getLogger('test_logger_level')
    out = sys.stdout
    sys.stdout = sys.stderr
    logging.basicConfig(level=logging.DEBUG, stream=sys.stderr)
    logger.setLevel(logging.INFO)
    logger.error('test_1 error')

    with logger_level(logger, logging.DEBUG):
        logger.error('test_2 error')
        with logger_level(logger, logging.INFO):
            logger.error('test_3 error')

    logger.error('test_4 error')
    sys.stderr = out



if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger(__name__)
    log

# Generated at 2022-06-12 07:58:41.822468
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    with logger_level(logger, logging.DEBUG) as _:
        logger.warning('test_logger_level')



# Generated at 2022-06-12 07:58:52.866936
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log,logging.CRITICAL):
        log.info("info")
        log.debug("debug")
        log.critical("critical")
    with logger_level(log,logging.INFO):
        log.info("info")
        log.debug("debug")
        log.critical("critical")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:58:55.057570
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.ERROR):
        logger.info('test')
        logger.debug('test')



# Generated at 2022-06-12 07:58:57.476295
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("Debug message")
    log.error("Should not appear")



# Generated at 2022-06-12 07:59:06.696189
# Unit test for function logger_level
def test_logger_level():
    import logging
    from StringIO import StringIO
    out = StringIO()
    logger = logging.getLogger()
    handler = logging.StreamHandler(out)
    logger.addHandler(handler)
    logger.setLevel(logging.NOTSET)
    with logger_level(logger, logging.DEBUG):
        logging.debug('debug')
        logging.info('info')
        logging.warning('warning')
        logging.error('error')
    assert 'debug' in out.getvalue()
    assert 'info' in out.getvalue()
    assert 'warning' in out.getvalue()
    assert 'error' in out.getvalue()
    out.truncate(0)
    out.seek(0)
    logger.setLevel(logging.WARNING)

# Generated at 2022-06-12 07:59:14.221665
# Unit test for function configure
def test_configure():
    # Test if the logging system has been configured
    try:
        logging.getLogger().handlers
    except:
        configured = False
    else:
        configured = True

    assert configured == False
    configure()
    assert logging.getLogger().handlers  # Check if the system has been configured
    configure()
    logging.getLogger().info('Test')
    # Check if the system has been configured again
    assert logging.getLogger().handlers

    # Test if the system can be configured by dict directly
    configure(config=DEFAULT_CONFIG)
    assert logging.getLogger().handlers



# Generated at 2022-06-12 07:59:18.107659
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    log.setLevel(logging.INFO)
    with logger_level(log, logging.DEBUG):
        log.debug("this should be recorded")
    log.debug("this should not be recorded")
    assert(True)



# Generated at 2022-06-12 07:59:24.081651
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    configure()
    logger_level(log, logging.INFO)
    assert log.level == logging.INFO, 'log.level should be logging.INFO'
    print('Pass logger_level')



logger = get_logger(__name__)
logging.basicConfig(stream=sys.stderr, format='%(levelname)s %(message)s')
logging.getLogger('requests').setLevel(logging.WARNING)
logger.debug('logger created')

# Generated at 2022-06-12 07:59:28.665297
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)

    with logger_level(log, logging.DEBUG):
        assert log.isEnabledFor(logging.DEBUG) is True
        log.debug("debug message")
        with logger_level(log, logging.INFO):
            assert log.isEnabledFor(logging.INFO) is True
            log.info("info message")

    assert log.isEnabledFor(logging.DEBUG) is False
    assert log.isEnabledFor(logging.INFO) is False

# Generated at 2022-06-12 07:59:34.358520
# Unit test for function configure
def test_configure():
    from copy import deepcopy

    config = deepcopy(DEFAULT_CONFIG)
    config['loggers'][__name__] = {
        "handlers": ["console"],
        "level": "DEBUG",
    }

    configure(config)
    log = logging.getLogger(__name__)

    with logger_level(log, logging.DEBUG):
        log.debug('test_configure')



# Generated at 2022-06-12 07:59:39.170504
# Unit test for function logger_level
def test_logger_level():
    """
    Test that calling logger_level() actually sets the log level.
    """
    # Test that a log message can be seen at debug level
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.debug('Test message for logger_level()')


# Generated at 2022-06-12 07:59:47.977649
# Unit test for function logger_level
def test_logger_level():
    import pytest
    from .log import getLogger

    logger = getLogger(__name__ + '.test_logger_level')

    with logger_level(logger, logging.DEBUG):
        logger.info('this should be printed')

    with logger_level(logger, logging.NOTSET):
        logger.info('this should not be printed')

    with pytest.raises(ValueError):
        with logger_level(logger, 'invalid level'):
            pass

# Generated at 2022-06-12 07:59:51.766527
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    level = logger.level
    with logger_level(logger, logging.DEBUG):
        assert level != logger.level, "logger level should be different than the original"
    assert level == logger.level, "logger level should be the same as the original"

# Generated at 2022-06-12 07:59:56.629816
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)
        logger.debug("debug message")
    assert not logger.isEnabledFor(logging.DEBUG)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:59:58.731963
# Unit test for function configure
def test_configure():  # pragma: no cover
    configure()
    logger = get_logger()
    logger.info('test')



# Generated at 2022-06-12 07:59:59.717936
# Unit test for function get_config
def test_get_config():
    pass


# Generated at 2022-06-12 08:00:06.682991
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO) as logger_info:
        assert logger_info.level == logging.INFO
    assert logger.level == logging.DEBUG


if __name__ == '__main__':
    import doctest
    import sys
    doctest.testmod()

# Generated at 2022-06-12 08:00:10.670384
# Unit test for function logger_level
def test_logger_level():
    import logging
    log = logging.getLogger(__name__)
    logging.basicConfig()

    log.setLevel(logging.DEBUG)
    assert log.getEffectiveLevel() == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.getEffectiveLevel() == logging.INFO
    assert log.getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-12 08:00:21.623035
# Unit test for function configure
def test_configure():
    configure(
            default=dict(
                version=1,
                formatters={
                    'colored': {'()': 'colorlog.ColoredFormatter',
                                'format': '%(log_color)s%(name)s:%(message)s'
                                }
                },
                handlers={'console': {'class': 'logging.StreamHandler',
                                      'formatter': 'colored'}},
                root=dict(handlers=['console'], level=logging.DEBUG)
            )
    )
    log = logging.getLogger(__name__)
    log.info("test")

if __name__ == '__main__':
    logging.basicConfig()
    test_configure()

# Generated at 2022-06-12 08:00:27.309435
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    assert log.level == logging.DEBUG

    with logger_level(log, logging.INFO):
        log.info('test_logger_level: 1')
        assert log.level == logging.INFO

        with logger_level(log, logging.ERROR):
            log.error('test_logger_level: 2')
            assert log.level == logging.ERROR

    assert log.level == logging.DEBUG
    log.info('test_logger_level: 3')



# Generated at 2022-06-12 08:00:34.724027
# Unit test for function logger_level
def test_logger_level():
    logging.config.dictConfig(DEFAULT_CONFIG)  # restore default config
    dummylogger = 'dummylogger'
    log = logging.getLogger(dummylogger)
    assert log.level == logging.DEBUG, 'default level is supposed to be DEBUG'
    log.info('Hello world')
    with logger_level(log, logging.WARNING):
        log.info('It should not log this message')
    log.info('It should log this message')

    with logger_level(log, 'WARNING'):
        log.info('It should not log this message')
    log.info('It should log this message')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:00:49.335595
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        assert logger.getEffectiveLevel() == logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:00:53.872951
# Unit test for function logger_level
def test_logger_level():
    import sys
    import io
    import contextlib

    log = get_logger()

    with contextlib.redirect_stdout(io.StringIO()) as stdout:
        log.info("Before context")
        with logger_level(log, logging.WARN):
            log.info("hello")
        log.info("After context")

    assert stdout.getvalue() == "INFO:root:Before context\nINFO:root:After context\n"

# Generated at 2022-06-12 08:01:02.634353
# Unit test for function logger_level
def test_logger_level():
    import sys
    import io
    import colorlog
    from contextlib import redirect_stdout
    buf = io.StringIO()

# Generated at 2022-06-12 08:01:07.595318
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    configure()
    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL

    # Make sure logger level was changed back to original value
    assert logger.level == logging.DEBUG


if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:01:10.214432
# Unit test for function logger_level
def test_logger_level():
    """
    >>> with logger_level(getLogger('test_logger_level'), logging.CRITICAL):
    ...     getLogger('test_logger_level').debug('test')
    """


# partially from http://stackoverflow.com/questions/898669#7936572

# Generated at 2022-06-12 08:01:15.681377
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.info('test')
        assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.level == logging.INFO

if __name__ == '__main__':
    logger = get_logger()
    logger.debug('test')

# Generated at 2022-06-12 08:01:19.356668
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug("this should print")
    log.debug("this should not print")



# Generated at 2022-06-12 08:01:22.258915
# Unit test for function logger_level
def test_logger_level():
    """Logger level change with context"""
    logger = getLogger()
    with logger_level(logger, logging.INFO):
        logger.info("logger_level at INFO level")



# Generated at 2022-06-12 08:01:31.882516
# Unit test for function logger_level
def test_logger_level(): # pragma: no cover
    from sys import stdout
    from io import StringIO

    mylog = StringIO()
    log = get_logger()
    log.parent.handlers[0] = logging.StreamHandler(mylog)

    log.debug('test_debug')
    log.info('test_info')
    with logger_level(log, logging.DEBUG):
        log.debug('test_debug_in_block')
        log.info('test_info_in_block')

    log.debug('test_debug2')
    log.info('test_info2')

    assert mylog.getvalue() == 'test_info\ntest_debug_in_block\ntest_info_in_block\ntest_info2\n'



# Generated at 2022-06-12 08:01:32.996503
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-12 08:01:49.175954
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import time

# Generated at 2022-06-12 08:01:57.494017
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    cfg = {
            'version': 1,
            'disable_existing_loggers': False,
            'formatters': {
                'simple': {
                    'format': '%(levelname)s %(message)s'
                }
            },
            'handlers': {
                'console': {
                    'class': 'logging.StreamHandler',
                    'formatter': 'simple'
                }
            },
            'loggers': {
                '': {
                    'handlers': ['console'],
                    'level': 'INFO',
                    'propagate': True
                }
            }
    }

    assert get_config(given=cfg) == cfg


# Generated at 2022-06-12 08:02:07.661263
# Unit test for function logger_level
def test_logger_level():
    from .test_utils import assert_equal

    logger = get_logger()
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        assert_equal(logger.isEnabledFor(logging.DEBUG), True)
        assert_equal(logger.isEnabledFor(logging.INFO), False)
        with logger_level(logger, logging.INFO):
            assert_equal(logger.isEnabledFor(logging.DEBUG), False)
            assert_equal(logger.isEnabledFor(logging.INFO), True)
        assert_equal(logger.isEnabledFor(logging.DEBUG), True)
        assert_equal(logger.isEnabledFor(logging.INFO), False)
    assert_equal(logger.isEnabledFor(logging.DEBUG), False)

# Generated at 2022-06-12 08:02:11.026589
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        logger.debug('This should not appear')
        logger.info('This should not appear')
        logger.warning('This should not appear')
        logger.error('This should not appear')
        logger.critical('This should appear')

# Generated at 2022-06-12 08:02:14.791781
# Unit test for function logger_level
def test_logger_level():
    import time
    logger = getLogger()
    with logger_level(logger, logging.DEBUG) as debug_level:
        # The idea here is to make sure that no messages from the with
        # statement get sent to the file.
        logger.info("Some message")
        logger.debug("Some debug message")
        logger.warning("Some warning message")



# Generated at 2022-06-12 08:02:24.566097
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import os
    import logging

    with tempfile.NamedTemporaryFile(delete=False) as f:
        name = f.name

# Generated at 2022-06-12 08:02:33.714284
# Unit test for function get_config
def test_get_config():

   print(get_config("""
        version: 1
        disable_existing_loggers: False
        formatters:
            simple:
                format: |
                    %(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]:
                    %(message)s @%(funcName)s:%(lineno)d #%(levelname)s
                datefmt: '%Y-%m-%d %H:%M:%S'

        handlers:
            console:
                class: logging.StreamHandler
                formatter: simple
                level: DEBUG
        root:
            handlers: [console]
            level: DEBUG
        loggers:
            requests:
                level: INFO
    """))



# Generated at 2022-06-12 08:02:38.155317
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.info("Test Logger Level function")
    logger.info("Reverting back to default logger level")


if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:02:41.996642
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.error('error message')
        logger.critical('critical message')
    return True

# Generated at 2022-06-12 08:02:45.923178
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test-logger-override')
    log.setLevel(logging.DEBUG)
    with logger_level(log, logging.INFO):
        assert log.isEnabledFor(logging.INFO)
        assert not log.isEnabledFor(logging.DEBUG)

    assert log.isEnabledFor(logging.DEBUG)
    assert not log.isEnabledFor(logging.INFO)



# Generated at 2022-06-12 08:03:05.276430
# Unit test for function configure
def test_configure():
    # Log message to test
    log_msg = 'Test log message'
    # Logging message level
    log_msg_level = logging.DEBUG

    # Logging configuration with simple format and logging level

# Generated at 2022-06-12 08:03:10.128905
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('This should not log')
        logger.info('This should log')
    logger.debug('This should log')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:03:16.519383
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import sys
    # We don't need a permanent temporary file, just a place to write to (we are not going to read it).
    temp_file = tempfile.TemporaryFile(mode='w+')
    test_logger = logging.getLogger(__name__)
    logging.basicConfig(stream=temp_file)
    test_logger.setLevel(logging.INFO)
    test_logger.info('test_info')
    temp_file.seek(0)
    sys.stdout.write(temp_file.read())
    temp_file.seek(0)
    test_logger.debug('test_debug')
    temp_file.seek(0)
    sys.stdout.write(temp_file.read())
    temp_file.seek(0)

# Generated at 2022-06-12 08:03:18.597213
# Unit test for function configure
def test_configure():
    """
    >>> log = logging.getLogger('test_log')
    >>> configure()
    >>> log.info('test')
    """


# Generated at 2022-06-12 08:03:23.780902
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        logger.debug('Debug message')
        logger.info('Info message')
        logger.warn('Warning message')
        logger.error('Error message')
        logger.critical('Critical message')

if __name__ == '__main__':
    import unittest as ut
    suite = ut.TestLoader().loadTestsFromModule(sys.modules[__name__])
    result = ut.TextTestRunner(verbosity=2).run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)

# Generated at 2022-06-12 08:03:29.457278
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    assert logger.level == 10, 'unexpected logger.level: %s' % logger.level

    with logger_level(logger, 100):
        assert logger.level == 100, 'unexpected logger.level: %s' % logger.level

    assert logger.level == 10, 'unexpected logger.level: %s' % logger.level

if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)

    test_logger_level()

# Generated at 2022-06-12 08:03:38.630847
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import unittest

    logger = logging.getLogger(__name__)

    class Tests(unittest.TestCase):
        def test_normal(self):
            with logger_level(logger, logging.INFO):
                self.assertEqual(logger.level, logging.INFO)

                logger.info('Testing the logger')
                self.assertIn('Testing the logger', sys.stdout.getvalue())
                self.assertEqual(logger.level, logging.INFO)

            self.assertEqual(logger.level, logging.DEBUG)

        def test_error(self):
            try:
                with logger_level(logger, logging.INFO):
                    raise ValueError
            except ValueError:
                pass

# Generated at 2022-06-12 08:03:39.931102
# Unit test for function configure
def test_configure():
    configure()
    logging.info('test')



# Generated at 2022-06-12 08:03:43.630804
# Unit test for function configure
def test_configure():
    try:
        configure(config=None, env_var='', default=DEFAULT_CONFIG)
    except ValueError:
        pass
        # expected

    configure(config='{}', env_var='', default=DEFAULT_CONFIG)

    configure(default=DEFAULT_CONFIG)

    log = get_logger(__name__)
    # TODO: How to assert expected?
    log.info('test')



# Generated at 2022-06-12 08:03:47.316981
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.DEBUG):
        log.debug('DEBUG: This should print')
    log.debug('DEBUG: This should NOT print')



# Generated at 2022-06-12 08:04:11.222494
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG


# Generated at 2022-06-12 08:04:16.771108
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test')

    def log_info():
        log.info('test_info')

    def log_warning():
        log.warning('test_warning')

    # Initial level = INFO
    assert log.level == logging.INFO
    log_info()
    log_warning()

    # Lower level to WARNING
    with logger_level(log, logging.WARNING):
        log_info()
        assert log.level == logging.WARNING
        log_warning()
        assert log.level == logging.WARNING
    assert log.level == logging.INFO

    # Raise level to DEBUG
    with logger_level(log, logging.DEBUG):
        log_info()
        assert log.level == logging.DEBUG
        log_warning()
        assert log.level == logging.DEBUG
    assert log.level == logging.INFO




# Generated at 2022-06-12 08:04:20.491793
# Unit test for function logger_level
def test_logger_level():
    l = get_logger('test')
    assert l.level == logging.DEBUG
    with logger_level(l, logging.ERROR):
        assert l.level == logging.ERROR
    assert l.level == logging.DEBUG


# Generated at 2022-06-12 08:04:23.604261
# Unit test for function configure
def test_configure():
    """Test configure"""
    logger = logging.getLogger(__name__)
    logger_name = "{0}.{1}".format(__name__, inspect.stack()[0][3])
    logger = logging.getLogger(logger_name)
    configure()
    logger.info("Test configure")



# Generated at 2022-06-12 08:04:27.104437
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('test')

    with logger_level(log, logging.ERROR):
        assert log.isEnabledFor(logging.ERROR)
        assert not log.isEnabledFor(logging.DEBUG)

    assert log.isEnabledFor(logging.DEBUG)