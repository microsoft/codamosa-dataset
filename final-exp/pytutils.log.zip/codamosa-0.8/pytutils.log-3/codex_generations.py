

# Generated at 2022-06-12 07:54:35.836410
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert log.level == logging.DEBUG

    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO

    assert log.level == logging.DEBUG

# Generated at 2022-06-12 07:54:43.623376
# Unit test for function get_config

# Generated at 2022-06-12 07:54:48.571907
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.INFO):
        log.info("This should work")
        log.debug("This should NOT work")
    log.info("This should work")
    log.debug("This should NOT work")
    log.error("This should work")



# Generated at 2022-06-12 07:54:56.132745
# Unit test for function logger_level
def test_logger_level():
    """
    If a logger is set to WARNING then a log.info call should not print

    If a logger is set to INFO then a log.info call should print

    >>> import logging
    >>>
    >>> logger = logging.getLogger('function_logger_level')
    >>> logger.setLevel(logging.WARNING)
    >>>
    >>> def test_logger_level():
    ...     with logger_level(logger, logging.INFO):
    ...         logger.info('This should print')
    ...     logger.info('This should not print')
    ...
    >>>
    >>> test_logger_level()
    This should print
    """
    return



# Generated at 2022-06-12 07:55:06.676147
# Unit test for function get_config
def test_get_config():
    # No config should be given
    with pytest.raises(ValueError):
        get_config()
    # Test json config
    config_json = '{"version": 1, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "colored", "level": "DEBUG"}}, "formatters": {"colored": {"()": "colorlog.ColoredFormatter", "format": "%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s", "datefmt": "%H:%M:%S"}}}'
    config = get_config(given=config_json)

# Generated at 2022-06-12 07:55:12.385763
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger(__name__)
    level = logger.level

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    assert logger.level == level

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:55:15.573959
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.NOTSET



# Generated at 2022-06-12 07:55:19.650356
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.isEnabledFor(logging.DEBUG)
        assert log.isEnabledFor(logging.INFO)
        assert log.isEnabledFor(logging.WARNING)
    assert not log.isEnabledFor(logging.DEBUG)
    assert log.isEnabledFor(logging.INFO)
    assert log.isEnabledFor(logging.WARNING)

# Unit tests for module

# Generated at 2022-06-12 07:55:21.295377
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')



# Generated at 2022-06-12 07:55:31.733032
# Unit test for function configure
def test_configure():
    import logging
    import StringIO
    from contextlib import redirect_stdout
    import sys
    import re

    f = StringIO.StringIO()
    with redirect_stdout(f):
        configure()
        logging.getLogger(__name__).info('info test')
        logging.getLogger(__name__).debug('debug test')
        configure(config=DEFAULT_CONFIG)
        logging.getLogger(__name__).info('info test')
        logging.getLogger(__name__).debug('debug test')
        configure(config='INFO')
        logging.getLogger(__name__).info('info test')
        logging.getLogger(__name__).debug('debug test')
        logging.getLogger('requests').info('info test')

# Generated at 2022-06-12 07:55:43.737123
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import StringIO

    # This test is written for Python 2.7
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Ensure logger is configured
    configure()

    # Create stream temporarily
    out = StringIO.StringIO()
    stream_handler = logging.StreamHandler(out)
    logger.addHandler(stream_handler)
    try:
        with logger_level(logger, logging.WARNING):
            logger.debug('foo')
        logger.debug('foobar')
        assert out.getvalue() == 'foobar\n'
    finally:
        logger.removeHandler(stream_handler)

# Generated at 2022-06-12 07:55:54.341581
# Unit test for function get_config
def test_get_config():
    from requests.utils import get_config
    from .test import (
        TmpDir,
        assert_equal,
    )
    import json

    with TmpDir() as tmp:
        filename = tmp.mkfile({ 'key': 'value' })
        j = json.dumps({ 'key': 'value' })

        assert_equal(
            get_config({ 'key': 'value' }),
            { 'key': 'value' },
        )

        assert_equal(
            get_config(j),
            { 'key': 'value' },
        )

        assert_equal(
            get_config(filename),
            { 'key': 'value' },
        )


# Generated at 2022-06-12 07:56:05.291235
# Unit test for function logger_level
def test_logger_level():
    import logging
    import io
    import sys

    logger = logging.getLogger('test')
    old_stdout = sys.stdout
    sys.stdout = virtual_stdout = io.StringIO()

    logger.debug('Foo')
    logger.info('Foo')
    logger.warning('Foo')
    logger.error('Foo')
    logger.critical('Foo')

    expected = 'WARNING:test:Foo\nERROR:test:Foo\nCRITICAL:test:Foo\n'
    assert virtual_stdout.getvalue() == expected

    sys.stdout = old_stdout  # restore stdout


# Generated at 2022-06-12 07:56:14.161347
# Unit test for function logger_level
def test_logger_level():
    import sys
    import StringIO
    my_output = StringIO.StringIO()  # save actual output
    sys.stdout = my_output
    log = get_logger()
    with logger_level(logger=log, level=logging.INFO):
        log.warning('Testing warning output')
        log.info('Testing info output')

    sys.stdout = sys.__stdout__ # print to screen
    my_output.seek(0) # move back to beginning of the file
    out = my_output.readline()
    assert out.startswith('INFO')
    my_output.close()



# Generated at 2022-06-12 07:56:24.843527
# Unit test for function get_config
def test_get_config():
    # testing
    import os
    import yaml


# Generated at 2022-06-12 07:56:33.864881
# Unit test for function get_config
def test_get_config():
    from logging import (
        simple,
        disable,
        getLogger,
        handlers as handlers_module,
    )
    from logging.handlers import (
        SysLogHandler,
        RotatingFileHandler,
    )

    # Test basic config data
    log_data = dict(
        version=1,
        disable_existing_loggers=False,
        handlers={
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'colored',
                'level': logging.DEBUG,
            },
        },
        root=dict(handlers=['console'], level=logging.DEBUG),
        loggers={
            'requests': dict(level=logging.INFO),
        },
    )
    # Use get_config function on log_data to ensure that the
    #

# Generated at 2022-06-12 07:56:39.390342
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger_level')
    # Set logger level to maximum output
    with logger_level(logger, logging.DEBUG):
        # This should output DEBUG message
        logger.debug('test_logger_level')
    # This should not output DEBUG message
    logger.debug('test_logger_level')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:56:49.344890
# Unit test for function logger_level
def test_logger_level():
    import sys
    import threading

    # Use a new logger with a new handler for testing
    lgr = getLogger('test_logger_level')
    lgr.propagate = False

    lgr.handlers.append(logging.StreamHandler(stream=sys.stdout))
    lgr.info('Logger and handler initialized')

    def test_level():
        lgr.info('Should print this')
        with logger_level(lgr, logging.CRITICAL):
            lgr.info('Should not print this')
        lgr.info('Should print this')

    t = threading.Thread(target=test_level)
    t.start()
    t.join()

    lgr.info('Done')

# Generated at 2022-06-12 07:56:54.361067
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    logger.setLevel(logging.DEBUG)

    # logger level was DEBUG, now it should be ERROR
    with logger_level(logger, logging.ERROR):
        assert logger.level < logging.DEBUG

    # logger level is back to DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:57:05.874441
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger()

    # First make sure that the level is not DEBUG
    assert log.level != logging.DEBUG

    # Now use logger_level to set the level to DEBUG
    with logger_level(log, logging.DEBUG) as l:
        # Check that the level was set to DEBUG
        assert l.getEffectiveLevel() == logging.DEBUG

        # Now check that the level is not DEBUG after exiting the context
        assert log.level != logging.DEBUG


if __name__ == "__main__":
    # Make sure that if the level is set to something other than DEBUG, that
    # the logger_level will set it to DEBUG and reset it after exiting the
    # context.
    log = logging.getLogger()
    log.setLevel(logging.ERROR)
    test_logger_level()

# Generated at 2022-06-12 07:57:17.682208
# Unit test for function get_config

# Generated at 2022-06-12 07:57:27.164924
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    level = logging.ERROR
    with logger_level(logger, level):
        assert logger.level == level
    assert logger.level == logging.DEBUG

# TODO: move the following to some test module

if __name__ == '__main__':

    # Uncomment to test logger_level
    test_logger_level()

    log = getLogger()
    log.info('hello')
    log.debug('world')

    with logger_level(log, logging.INFO):
        log.debug('foo')

    with logger_level(log, logging.DEBUG):
        log.debug('foo')

# Generated at 2022-06-12 07:57:30.296137
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("TestLogger")

    with logger_level(logger, logging.DEBUG):
        logger.info("Set the level to DEBUG")
        logger.debug("This is a logger debug message")
        logger.info("This is a logger info message")

# Generated at 2022-06-12 07:57:36.930701
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test')
    log.setLevel(logging.INFO)
    with logger_level(log, logging.DEBUG):
        log.debug('Debug message 1')
        log.info('Info message 1')
    log.debug('Debug message 2')
    log.info('Info message 2')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:57:40.655966
# Unit test for function logger_level
def test_logger_level():
    with pytest.raises(NameError):
        getLogger('logger_level')

    logger = getLogger('logger_level')
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
    assert logger.level != logging.ERROR



# Generated at 2022-06-12 07:57:51.091681
# Unit test for function logger_level
def test_logger_level():
    import random
    import tempfile
    import os
    import logging

    log_dir = os.path.dirname(tempfile.mktemp(prefix='logger_level_test'))

    logger = logging.getLogger(__file__)
    logger.handlers = []


# Generated at 2022-06-12 07:58:00.468733
# Unit test for function logger_level
def test_logger_level():
    import logging
    import tempfile
    import os

    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)

    # Create a file handler
    with tempfile.NamedTemporaryFile(delete=False) as f:
        # f.delete=False so we can read the log file afterwards
        handler = logging.StreamHandler(os.fdopen(f.fileno(), 'w'))

    # Add the file handler to the logger
    logger.addHandler(handler)

    # Log some stuff
    logger.info('Hello, world!')
    # <say goodbye>
    logger.warning('Goodbye, cruel world!')

    # Now, change the logger level to error

# Generated at 2022-06-12 07:58:04.987701
# Unit test for function get_config
def test_get_config():
    print("test_get_config:")

    # None given
    assert get_config() == DEFAULT_CONFIG

    # Given a dict
    assert get_config(config={'foo': 'bar'}) == {'foo': 'bar'}

    # Given a string
    assert get_config(config='{"foo": "bar"}') == {'foo': 'bar'}

    # Given a string with bad json
    try:
        get_config(config='{"foo": "bar}')
    except ValueError:
        pass


if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-12 07:58:14.128236
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger("test_logger_level")
    with logger_level(log, logging.INFO):
        log.debug("this should not be printed")
        log.info("this should be printed")
    log.debug("this should be printed")

    log = logging.getLogger("test_logger_level")
    with logger_level(log, logging.CRITICAL):
        log.warn("this should not be printed")
    with logger_level(log, logging.ERROR):
        log.warn("this should be printed")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:58:22.073580
# Unit test for function get_config
def test_get_config():
    from collections import namedtuple
    import json
    import yaml
    from .utils import assert_raise

    with assert_raise(ValueError, msg="Invalid logging config: %s" % None):
        get_config(config=None)


# Generated at 2022-06-12 07:58:35.315576
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.DEBUG):
        logging.info('hello')
        logging.debug('hello')
    logging.info('hello')
    logging.debug('hello')

# Generated at 2022-06-12 07:58:43.910068
# Unit test for function get_config

# Generated at 2022-06-12 07:58:46.537981
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), logging.WARNING):
        getLogger().debug("hello world; this shouldn't print")


# Generated at 2022-06-12 07:58:49.776798
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        log.debug('This should not appear')
        log.info('This should appear')
    log.debug('This should appear')

# Generated at 2022-06-12 07:58:53.805330
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    logger.setLevel(logging.DEBUG)

    with logger_level(logger, logging.WARNING):
        logger.info('test info')
        logger.debug('test debug')

    assert logger.level == logging.DEBUG


# Generated at 2022-06-12 07:58:54.697361
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-12 07:59:01.173165
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    with open('logging.conf.yaml', 'rt') as fp:
        config = yaml.load(fp)
        assert config == get_config(json.dumps(config))
        assert config == get_config(yaml.dump(config))
        assert config == get_config(yaml.dump(config), default=None)
        assert config == get_config(config)
        assert config == get_config(yaml.dump(config), default=None)
        assert config == get_config(None, 'LOGGING', config)
        assert config == get_config(None, 'LOGGING', None)
        assert config == get_config(config, 'UNDEFINED')
        assert config == get_config(yaml.dump(config), default=config)


# Generated at 2022-06-12 07:59:07.697612
# Unit test for function logger_level
def test_logger_level():
    log = get_logger("test_logger_level")
    with logger_level(log, logging.DEBUG):
        assert(log.level == logging.DEBUG)
        log.debug("this should be printed")
        log.info("this should not be printed")
        log.error("this should not be printed")
    assert(log.level == logging.INFO)
    log.info("this should be printed")
    log.debug("this should not be printed")

# Generated at 2022-06-12 07:59:12.035288
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.warn('This should not be logged. You know why.')


if __name__ == '__main__':

    configure()
    log = get_logger()
    log.warn('test')

    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:59:15.286708
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('This is a test')
    logger.debug('This is not logged')

# Unit tests for function get_logger

# Generated at 2022-06-12 07:59:26.955091
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG



# Generated at 2022-06-12 07:59:33.248427
# Unit test for function logger_level
def test_logger_level():
    """
    >>> import logging
    >>> from contextlib import contextmanager
    >>> from pytest import raises
    >>> log = logging.getLogger()
    >>> assert log.level == logging.NOTSET
    >>> with logger_level(log, logging.DEBUG):
    ...     assert log.level == logging.DEBUG
    ...     raises(RuntimeError, raise, RuntimeError)
    ...
    >>> assert log.level == logging.NOTSET
    """
    pass


# Generated at 2022-06-12 07:59:38.574040
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.ERROR):
        log.debug('wont print')
        log.error('will print')
        log.critical('will print')
    log.debug('will print')
    log.error('will print')
    log.critical('will print')

if __name__ == '__main__':
    log = get_logger()
    log.info('hi')

# Generated at 2022-06-12 07:59:47.160745
# Unit test for function get_config
def test_get_config():
    assert get_config(config="") is not None
    assert get_config(config="") == ""

    assert get_config(config=None) is None

    assert get_config(config="DEFAULT_CONFIG") is not None
    assert get_config(config="DEFAULT_CONFIG") == DEFAULT_CONFIG

    try:
        assert get_config(config="./test/test_file.json") is not None
    except ValueError:
        assert False

    try:
        assert get_config(config="./test/test_file.yaml") is not None
    except ValueError:
        assert False



# Generated at 2022-06-12 07:59:52.295861
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    initial = logger.level
    with logger_level(logger, logging.CRITICAL):
        logger.debug('DEBUG level msg')
        logger.error('ERROR level msg')
        logger.critical('CRITICAL level msg')
    assert logger.level == initial
    logger.debug('DEBUG level msg')
    logger.error('ERROR level msg')
    logger.critical('CRITICAL level msg')

# Generated at 2022-06-12 07:59:58.780023
# Unit test for function logger_level
def test_logger_level():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestSillyLoggerLevel(unittest.TestCase):
        def test_logger_level(self):
            l = get_logger()
            with logger_level(l, logging.CRITICAL):
                l.debug('this should be hidden')
                self.assertTrue(True)

    unittest.main()



# Generated at 2022-06-12 08:00:02.626671
# Unit test for function logger_level
def test_logger_level():
    configure()

    logger = get_logger()
    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING

    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 08:00:06.487339
# Unit test for function logger_level
def test_logger_level():
    expect=logging.DEBUG
    with logger_level(logging.getLogger(), logging.DEBUG):
        assert logging.getLogger().getEffectiveLevel() == expect

# Generated at 2022-06-12 08:00:12.053032
# Unit test for function logger_level
def test_logger_level():
    """Unit test for function `logger_level`.
    """
    import io
    import logging
    logger = logging.getLogger(__name__)
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    logger.setLevel(logging.WARNING)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug('spam')
        assert 'spam' in stream.getvalue()
    assert logger.level == logging.WARNING



# Generated at 2022-06-12 08:00:18.983667
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    logger.info("This should be printed")
    with logger_level(logger, logging.WARNING):
        logger.info("This should not be printed")
    with logger_level(logger, logging.INFO):
        logger.info("This should be printed")
        logger.warning("This should be printed")



# Generated at 2022-06-12 08:00:45.017332
# Unit test for function get_config
def test_get_config():
    json_dict = get_config(given='{"version": 1}', env_var=None, default=None)
    print(json_dict)


if __name__ == "__main__":
    test_get_config()

# Generated at 2022-06-12 08:00:53.565336
# Unit test for function logger_level
def test_logger_level():
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def capture_output():
        old_out, old_err = sys.stdout, sys.stderr
        new_out, new_err = io.StringIO(), io.StringIO()
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield new_out, new_err
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    log = get_logger()
    configure()

    with capture_output() as (stdout, stderr):
        log.info("This should not print because logger level is set to debug")

# Generated at 2022-06-12 08:00:56.828046
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)
        logger.debug('We can see this message in DEBUG level')
    logger.debug('We cannot see this message in DEBUG level')



# Generated at 2022-06-12 08:01:01.305744
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("Hello, world")
    log.info("Goodbye")
    print("Output should include the debug message, but not the info message")
    return True

if __name__ == '__main__':
    sys.exit(not test_logger_level())

# Generated at 2022-06-12 08:01:04.074356
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)

    with logger_level(log, logging.CRITICAL):
        log.debug('debug')
        log.info('info')

    log.debug('debug')
    log.info('info')

# Generated at 2022-06-12 08:01:08.200357
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.info('hi')
        logger.debug('hi')
    logger.debug('hi')


if hasattr(logging, 'captureWarnings'):
    logging.captureWarnings(True)



# Generated at 2022-06-12 08:01:10.191490
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    logger = get_logger()

    with logger_level(logger, logging.DEBUG):
        logger.debug("This message should be printed")

    logger.debug("This message should not be printed")


# Generated at 2022-06-12 08:01:11.750214
# Unit test for function configure
def test_configure():
    pass


# Generated at 2022-06-12 08:01:15.838842
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
    logger.debug("This should NOT be logged")



# Generated at 2022-06-12 08:01:18.637396
# Unit test for function configure
def test_configure():
    def tester():
        configure()
    tester()

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-12 08:02:14.825020
# Unit test for function get_config
def test_get_config():
    import json


# Generated at 2022-06-12 08:02:17.579961
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    configure()
    with logger_level(log, logging.CRITICAL):
        log.debug('check')
        assert 1 == 1
        log.critical('check')
        assert 1 == 2

# Generated at 2022-06-12 08:02:28.380244
# Unit test for function logger_level
def test_logger_level():
    from six import StringIO
    from logging import Logger
    import logging

    stream = StringIO()

    logger = Logger('test')
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    logger_level(logger, logging.ERROR)
    assert logger.level == logging.ERROR

    # This will throw an error.
    try:
        assert logger.debug("a debug message")
    except Exception as e:
        assert 'Logger.debug() is disabled' in str(e)

    assert logger.error("an error message")
    assert stream.getvalue().strip().endswith("an error message")

    stream.truncate(0)

    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging

# Generated at 2022-06-12 08:02:34.221524
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import logging
    import time

    class TestLogger_Level(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger("TestLogger_Level")
            self.logger_level_context = logger_level(self.logger, 30)

        def test_logger_level(self):
            with self.logger_level_context:
                self.logger.error("TEST")
                time.sleep(1)
                self.logger.debug("TEST")



# Generated at 2022-06-12 08:02:43.282628
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger("somename")
    class Something(object):
        def __init__(self):
            self.logger = logger

        def do_stuff(self):
            with logger_level(self.logger, logging.CRITICAL):
                self.logger.info("Will not log!")
                self.logger.warning("Will not log!")
                self.logger.debug("Will not log!")
                self.logger.critical("Will log!")

    s = Something()
    s.do_stuff()

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:02:46.159622
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    message = 'Test logger_level'
    with logger_level(log, logging.INFO):
        log.info(message)
    with logger_level(log, logging.DEBUG):
        log.debug(message)
    with logger_level(log, logging.WARN):
        log.warn(message)

    with logger_level(log, logging.FATAL):
        log.fatal(message)



# Generated at 2022-06-12 08:02:47.034907
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-12 08:02:55.176894
# Unit test for function get_config
def test_get_config():
    # json
    json_config = '{"version": 1,"disable_existing_loggers": False,"formatters": {"simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s","datefmt": "%Y-%m-%d %H:%M:%S"}},"handlers": {"console": {"class": "logging.StreamHandler","formatter": "colored","level": "DEBUG"}},"loggers": {"requests": {"level": "INFO"}},"root": {"handlers": ["console"],"level": "DEBUG"}}'

# Generated at 2022-06-12 08:02:57.488788
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
        log.debug('test')
    assert log.level == logging.DEBUG

# Generated at 2022-06-12 08:03:04.794954
# Unit test for function logger_level
def test_logger_level():
    try:
        logging.getLogger(__name__).debug("TEST")
        raise Exception("TEST SHOULD NOT HAVE PASSED")
    except:
        pass

    logging.getLogger(__name__).setLevel(logging.DEBUG)
    logging.getLogger(__name__).debug("TEST")

    with logger_level(logging.getLogger(__name__), logging.INFO):
        try:
            logging.getLogger(__name__).debug("TEST")
            raise Exception("TEST SHOULD NOT HAVE PASSED")
        except:
            pass

    logging.getLogger(__name__).debug("TEST")

