

# Generated at 2022-06-12 07:54:38.772130
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.DEBUG):
        assert logging.getLogger().isEnabledFor(logging.DEBUG)
        assert not logging.getLogger().isEnabledFor(logging.INFO)
    # Remove logger handlers if present
    for handler in logging.getLogger().handlers:
        logging.getLogger().removeHandler(handler)
    logging.getLogger().addHandler(logging.NullHandler())
    with logger_level(logging.getLogger(), logging.INFO):
        assert logging.getLogger().isEnabledFor(logging.INFO)
        assert not logging.getLogger().isEnabledFor(logging.DEBUG)



# Generated at 2022-06-12 07:54:44.114617
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = getLogger()
    >>> with logger_level(logger, logging.DEBUG):
    ...     logger.debug("hi")
    >>> logger.debug("bye")
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:54:50.081552
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.info("Should not see this")
        logger.error("This message should be seen")
        with logger_level(logger, logging.INFO):
            logger.info("This should be seen too")
    logger.info("Should see this message.")

if __name__ == '__main__':
    configure()
    test_logger_level()

# Generated at 2022-06-12 07:54:54.162291
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('a debug message')
        msg = 'a message'
        logger.info(msg)
    logger.debug('a debug message')
    logger.info('a message')

# Generated at 2022-06-12 07:55:00.048941
# Unit test for function logger_level
def test_logger_level():
    import unittest
    class TestLoggerLevel(unittest.TestCase):
        def test_logger_level(self):
            # Set up the logger
            log = logging.getLogger('test_logger_level')
            log.setLevel(logging.DEBUG)

            # Add a handler (e.g. print to screen)
            ch = logging.StreamHandler()
            ch.setLevel(logging.DEBUG)
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            ch.setFormatter(formatter)
            log.addHandler(ch)

            # Execute the test
            with logger_level(log, logging.INFO):
                log.debug('This should not be printed')

# Generated at 2022-06-12 07:55:02.626309
# Unit test for function configure
def test_configure():
    """
    >>> test_configure()
    """
    log = logging.getLogger(__name__)
    configure()
    log.info('test')

# Generated at 2022-06-12 07:55:06.989257
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARNING):
        logger.info('Result: {0}'.format('should not see this'))
        logger.warning('Result: {0}'.format('should see this'))
        logger.error('Result: {0}'.format('should see this'))



# Generated at 2022-06-12 07:55:17.887436
# Unit test for function get_config
def test_get_config():
    from pyquil.quil import Program
    from pyquil.paulis import sX, sZ, sY, I

    d = {'a': 1, 'b': 2}

    # test with a given dictionary
    assert get_config(given=d) == d

    # test with an environment variable pointing to a dictionary string
    os.environ['LOGGING_TEST'] = '{"a": 1, "b": 2}'
    assert get_config(env_var='LOGGING_TEST') == d
    del os.environ['LOGGING_TEST']

    # test with an environment variable pointing to a json string
    os.environ['LOGGING_TEST_JSON'] = json.dumps(d)
    assert get_config(env_var='LOGGING_TEST_JSON')

# Generated at 2022-06-12 07:55:27.874520
# Unit test for function logger_level
def test_logger_level():
    from tests.test_common import verify_log_lines
    from contextlib import contextmanager
    from StringIO import StringIO
    import logging

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger('test_logger_level')

    log_level2 = logging.DEBUG
    log_level1 = logging.ERROR
    log_message = "A log message"

    log_output = StringIO()

    def test_logger_helper(log_level):
        with logger_level(logger, log_level):
            logger.debug(log_message)

    # Test the case where we set the logger level to the lower level
    log_expected = ""
    test_logger_helper(log_level1)
    verify_log_lines(log_expected, log_output)

   

# Generated at 2022-06-12 07:55:33.036605
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, None) == None

    default = DEFAULT_CONFIG
    assert get_config(None, None, default) == default

    assert get_config("logging.json", None, default) == default
    assert get_config("logging.yaml", None, default) == default


if __name__ == "__main__":
    configure()
    logging.info("Testing default logging")
    test_get_config()

# Generated at 2022-06-12 07:55:41.348955
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    old_level = logger.level
    try:
        with logger_level(logger, logging.DEBUG):
            logger.debug("This should print")
        logger.debug("This should *not* print")
    finally:
        logger.level = old_level


# Generated at 2022-06-12 07:55:49.816485
# Unit test for function logger_level
def test_logger_level():
    import pytest

    log = getLogger()
    log.error('test before')
    logger = getLogger('test_logger_level')

    # Test if logger level is set to DEBUG
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug('Use this world')
        with pytest.raises(Exception):
            with logger_level(logger, 1):
                pass

    # Test if logger level is set to INFO
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO

    log.error('test after')

# Generated at 2022-06-12 07:55:57.993086
# Unit test for function get_config
def test_get_config():
    from contextlib import contextmanager

    @contextmanager
    def env(**env):
        original = dict(os.environ)
        try:
            for k, v in env.items():
                if v is None:
                    del os.environ[k]
                else:
                    os.environ[k] = v
            yield
        finally:
            os.environ.clear()
            os.environ.update(original)

    with env(FOO='bar'):
        assert get_config(default={'FOO': 'baz'}) == {'FOO': 'baz'}

    with env(FOO='1'):
        assert get_config(default={'FOO': 2}) == {'FOO': 2}


# Generated at 2022-06-12 07:56:02.489989
# Unit test for function configure
def test_configure():
    logger = getLogger()
    logger.info("1")
    logger.error("2")
    configure()
    logger.info("1")
    logger.error("2")


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-12 07:56:13.713684
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import os
    import shutil
    logger = get_logger()
    fd, path = tempfile.mkstemp(suffix='.log')
    #todo: use tempfile.TemporaryFile instead of manually removing file

# Generated at 2022-06-12 07:56:24.336376
# Unit test for function get_config
def test_get_config():
    default_config = dict(version=1)
    assert get_config() == default_config, 'No config should be default config'
    assert get_config(config=None) == default_config, 'No config should be default config'
    assert get_config(config=True) == True, 'Valid config should be the sent config'
    assert get_config(config=default_config) == default_config, 'Valid config should be the sent config'

    env_valid_config = dict(env_var='LOGGING', default=default_config)
    assert get_config(**env_valid_config) == default_config, 'No config, with default should be default config'
    with pytest.raises(ValueError):
        get_config(config=None, **env_valid_config)

# Generated at 2022-06-12 07:56:28.113742
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('OK')
        logger.info('OK')
        logger.warn('OK')

    with logger_level(logger, logging.INFO):
        logger.debug('OK')
        logger.info('OK')
        logger.warn('OK')


# Generated at 2022-06-12 07:56:32.912107
# Unit test for function logger_level
def test_logger_level():
    """
    >>> l = logging.getLogger(__name__)
    >>> configure({'loggers': {__name__: {'level': logging.INFO}}})
    >>> l.critical('critical')
    >>> with logger_level(l, logging.DEBUG):
    ...     l.critical('critical')
    >>> l.critical('critical')
    """
    pass

# Generated at 2022-06-12 07:56:41.625611
# Unit test for function get_config
def test_get_config():
    from tests.test_extra import get_config_1
    assert get_config(get_config_1) == get_config_1
    assert get_config("{}") == {}
    assert get_config("{'a':1}") == {'a':1}
    assert get_config("{a:1}") == {'a':1}
    assert get_config("a:1") == {'a':1}
    assert get_config("{'a':1}", default=None) == {'a':1}
    assert get_config("{'a':1}", default=1) == {'a':1}
    assert get_config("{'a':1}") == {'a':1}

if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-12 07:56:46.952276
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.info('info test')
        # you can remove this part if you dont have colorlog in your virtualenv
        try:
            logger.debug('debug test')
        except:
            pass
    logger.info('info test 2')

test_logger_level()

# Generated at 2022-06-12 07:56:58.057317
# Unit test for function logger_level
def test_logger_level():
    # This unit test requires the logging level to be set to DEBUG.
    # It's a unit test for the unit test logger_level.
    # If (or when) it fails, it should provide useful debugging information.
    # However, check that the logging level has been set to DEBUG
    # Otherwise, this test will fail with a spurious failure.
    if not logging.getLogger().getEffectiveLevel() == 10:
        raise Exception('Test test_logger_level requires logging set to debug')
    logger = logging.getLogger('test_logger_level')
    logger.debug('This should be suppressed')
    with logger_level(logger, logging.CRITICAL):
        logger.debug('This should be suppressed')
    logger.debug('This should not be suppressed')


# Generated at 2022-06-12 07:57:02.430920
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("test_logger_level")
    level = logging.DEBUG
    with logger_level(logger, level):
        logger.info("logger_level: info %s", level)
    logger.info("logger_level: info %s", logger.level)

# Generated at 2022-06-12 07:57:08.977788
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    configure()
    with logger_level(log, logging.WARNING):
        log.info("info level message")
        log.warning("warning level message")
    log.info("info level message")


# TODO create convenience handlers for:
#  * rotating file handler
#  * different log levels for different namespaces
#  * file handler with rotating log files by size
#  * file handler with rotating log files by date

# Generated at 2022-06-12 07:57:12.535196
# Unit test for function logger_level
def test_logger_level():
    assert logger_level
    with logger_level(logging.getLogger(), logging.INFO):
        assert logging.getLogger().getEffectiveLevel() == logging.INFO
    assert logging.getLogger().getEffectiveLevel() == logging.NOTSET



# Generated at 2022-06-12 07:57:15.870097
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    assert logger.getEffectiveLevel() == logging.NOTSET
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.getEffectiveLevel() == logging.NOTSET


# Generated at 2022-06-12 07:57:19.129078
# Unit test for function logger_level
def test_logger_level():
    """Test the logger_level context manager."""
    log = getLogger(__name__)
    test_log = logging.getLogger(__name__)
    test_log.level = logging.WARN
    with logger_level(log, logging.DEBUG):
        log.debug('testing logger_level')

# Generated at 2022-06-12 07:57:29.816327
# Unit test for function configure
def test_configure():
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(mode='w') as fp:
        fp.write('''
        {
            "version": 1,
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "formatter": "colored",
                    "level": "DEBUG"
                }
            },
            "root": {
                "handlers": ["console"],
                "level": "DEBUG"
            }
        }
        ''')
        fp.flush()
        configure(config=fp.name)
        logger = getLogger('test_configure')
        logger.debug("Test Passed")


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-12 07:57:39.317970
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('test')
        log.info('test')
        log.warning('test')
        log.error('test')
        log.critical('test')

    with logger_level(log, logging.ERROR):
        log.debug('test')
        log.info('test')
        log.warning('test')
        log.error('test')
        log.critical('test')

    # reset logger level to default.
    log.setLevel(logging.NOTSET)

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:57:45.844701
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("test_logger_level")
    with logger_level(logger, logging.INFO):
        logger.info("info")
        logger.warning("warning")
        logger.debug("debug")
        logger.error("error")
    logger.info("info 2")
    logger.warning("warning 2")
    logger.debug("debug 2")
    logger.error("error 2")



# Generated at 2022-06-12 07:57:50.665045
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, 5):
        logger.debug("foobar")
        logger.warning("foobar")
        logger.error("foobar")
        logger.exception("foobar")
        logger.critical("foobar")

    logger.info("foobar")
    logger.debug("foobar")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:58:08.647898
# Unit test for function get_config

# Generated at 2022-06-12 07:58:12.074139
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.WARN):
        logger.info('some info')
        logger.debug('some debug')
        logger.warn('some warn')

# Generated at 2022-06-12 07:58:19.961012
# Unit test for function get_config
def test_get_config():
    try:
        get_config()
    except ValueError:
        pass
    else:
        assert 0, 'No exception raised'

    config = dict(version=1, disable_existing_loggers=False)
    cfg = get_config(config)
    assert cfg == config, 'Dict should be returned'

    config = json.dumps(config)
    cfg = get_config(config)
    assert cfg == json.loads(config), 'Dict should be read from JSON string'

    config = yaml.dump(config)
    cfg = get_config(config)
    assert cfg == yaml.load(config), 'Dict should be read from YAML string'


# Generated at 2022-06-12 07:58:28.814050
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    import inspect
    import sys

    def _namespace_from_calling_context():
        """
        Derive a namespace from the module containing the caller's caller.

        :return: the fully qualified python name of a module.
        :rtype: str
        """
        return inspect.stack()[2][0].f_globals["__name__"]


# Generated at 2022-06-12 07:58:33.482971
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')

# Generated at 2022-06-12 07:58:40.607592
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.WARNING):
        logger.debug('hello') # Should not appear in the console
        logger.warning('There should be a warning') # Should appear in the console
    with logger_level(logger, logging.DEBUG):
        logger.debug('hello, debug') # Should appear in the console
        logger.warning('hello, warning') # Should appear in the console

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:58:52.135858
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger('test_logger_level')
    test_logger.setLevel(logging.DEBUG)

    @contextmanager
    def set_level_context(logger, level):
        with logger_level(logger, level):
            test_logger.debug('some debug message')
            test_logger.info('some info message')
            test_logger.error('some error message')
            try:
                raise Exception('error was thrown')
            except Exception:
                test_logger.exception('some exception message')

    with set_level_context(test_logger, logging.DEBUG):
        assert test_logger.isEnabledFor(logging.DEBUG)


# Generated at 2022-06-12 07:58:56.051778
# Unit test for function logger_level
def test_logger_level():
    l = get_logger()
    with logger_level(l, logging.WARNING):
        l.warning('logger level set to WARNING')
        l.info('logger level set to WARNING')
        l.debug('logger level set to WARNING')
    l.warning('logger level back to DEBUG')
    l.info('logger level back to DEBUG')

# Generated at 2022-06-12 07:58:58.243490
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    with logger_level(log, logging.INFO):
        log.debug("This should not appear")
        log.info("This should appear")

# Generated at 2022-06-12 07:59:07.950822
# Unit test for function logger_level
def test_logger_level():
    import logging
    from tempfile import TemporaryFile
    from .utils import Condition
    from time import sleep
    from .timeouts import TimeoutError

    l = logging.getLogger(__name__)
    with TemporaryFile() as f:
        h = logging.StreamHandler(stream=f)
        l.addHandler(h)

        with logger_level(l, logging.DEBUG):
            # The logger should log DEBUG messages now
            l.debug("DEBUG")
            l.warning("WARNING")
            l.info("INFO")

        Condition(lambda: "DEBUG" in f.read()).wait()

        # Debug messages should not be logged after the context manager ends

# Generated at 2022-06-12 07:59:20.212380
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.INFO):
        logger.setLevel(logging.INFO)
        logger.info('message')
        logger.debug('message')

    logger.setLevel(logging.DEBUG)
    logger.info('message')
    logger.debug('message')



# Generated at 2022-06-12 07:59:24.632206
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger('test')

    with logger_level(logger, logging.ERROR):
        logger.debug('i should not show up 1')

    logger.debug('i should show up 2')

    logger.setLevel(logging.DEBUG)
    logger.debug('already at debug, just checking against regressions')



# Generated at 2022-06-12 07:59:33.591719
# Unit test for function get_config
def test_get_config():
    import logging

    configure()
    assert logging.getLogger(__name__).getEffectiveLevel() == logging.DEBUG, \
        "logger level should be DEBUG"
    try:
        # Configure logger with non existing environment variable
        configure(env_var='nonexistingenvvar')
        assert False, 'should raise Value error'
    except ValueError:
        pass

    try:
        # Configure logger with invalid logging config
        logging.config.dictConfig('invalid_logging_config')
        assert False, 'should raise Value error'
    except TypeError as exc:
        assert type(exc.__context__) is ValueError
    logging.config.dictConfig(DEFAULT_CONFIG)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    logging.info

# Generated at 2022-06-12 07:59:36.538928
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger_level')

    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG

    assert logger.getEffectiveLevel() == logging.NOTSET



# Generated at 2022-06-12 07:59:41.979551
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), logging.DEBUG):
        getLogger().debug('debug level')
        getLogger().info('info level')
        getLogger().warning('warn level')
    getLogger().debug('debug level')
    getLogger().info('info level')
    getLogger().warning('warn level')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:59:43.291403
# Unit test for function configure
def test_configure():
    configure()
    logging.debug('test')
    assert True


# Generated at 2022-06-12 07:59:47.132348
# Unit test for function get_config
def test_get_config():
    assert type(get_config({})) is dict
    assert get_config(None, None, DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config = DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var = 'LOG_CONFIG', default = DEFAULT_CONFIG) == DEFAULT_CONFIG

# Generated at 2022-06-12 07:59:54.916722
# Unit test for function get_config
def test_get_config():
    given = dict(version=1, disable_existing_loggers=False, formatters={'simple': {'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s', 'datefmt': '%Y-%m-%d %H:%M:%S'}}, handlers={'console': {'class': 'logging.StreamHandler', 'level': 'DEBUG'}}, root={'handlers': ['console'], 'level': 'DEBUG'})

# Generated at 2022-06-12 07:59:58.548543
# Unit test for function logger_level
def test_logger_level():
    conf = configure()
    assert conf == DEFAULT_CONFIG
    logger = getLogger('test_logger_level')
    with logger_level(logger, logging.INFO):
        logger.debug('ignore me')
        logger.info('listen to me')

# Generated at 2022-06-12 08:00:09.840085
# Unit test for function get_config
def test_get_config():
    """ Tests the function get_config
    """
    # gets from environ
    os.environ['LOGGING'] = '{"loggers": {"foo": {"handlers": []}}}'
    assert 'foo' in get_config(env_var='LOGGING')["loggers"]

    # does not get from environ if config is passed
    os.environ['LOGGING'] = '{}'
    assert 'foo' in get_config(env_var='LOGGING', config=DEFAULT_CONFIG)["loggers"]

    # gets from default
    assert 'foo' in get_config(default=DEFAULT_CONFIG)["loggers"]

    # gets from default if config is passed
    assert 'foo' in get_config(config=DEFAULT_CONFIG, default={})["loggers"]

    # does not get

# Generated at 2022-06-12 08:00:27.045717
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), logging.DEBUG):
        getLogger().info('This message should appear')
        with logger_level(getLogger(), logging.ERROR):
            getLogger().info('This message should not appear')
        getLogger().info('This message should appear')
    getLogger().info('This message should not appear')

# Generated at 2022-06-12 08:00:29.226303
# Unit test for function configure
def test_configure():
    logger = get_logger(__name__)
    logger.info('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-12 08:00:29.975789
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-12 08:00:37.636781
# Unit test for function logger_level
def test_logger_level():
    # TODO This needs to be refactored, it's using the global log config
    # and there are no guarantees that the 'root' logger is configured
    # this way in the consuming application.
    logger = logging.getLogger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')
    assert logger.level != logging.CRITICAL
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')
    logger.critical('test')

# Generated at 2022-06-12 08:00:46.430671
# Unit test for function logger_level
def test_logger_level():
    import logging
    import os
    import tempfile
    from contextlib import redirect_stdout
    from os.path import join

    with tempfile.TemporaryDirectory() as cwd:
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)

        fh = logging.FileHandler(join(cwd, "test_logger_level.log"))
        fh.setLevel(logging.DEBUG)

        logger.addHandler(fh)

        with redirect_stdout(open(os.devnull, 'w')):
            with logger_level(logger, logging.INFO):
                logger.debug("This should be logged")
                logger.info("This should be logged")
                logger.warning("This should be logged")
                logger.error("This should be logged")


# Generated at 2022-06-12 08:00:49.922496
# Unit test for function logger_level
def test_logger_level():
    """Unit test for function logger_level"""
    log = get_logger()
    assert log.level == logging.DEBUG
    with logger_level(log, logging.WARNING):
        assert log.level == logging.WARNING
    assert log.level == logging.DEBUG


# Generated at 2022-06-12 08:00:52.305346
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("debug message")
        log.info("info message")
        log.warning("warning message")

# Generated at 2022-06-12 08:01:00.728634
# Unit test for function logger_level
def test_logger_level():
    import logging
    import tempfile
    import os
    import shutil


# Generated at 2022-06-12 08:01:09.380396
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    # logger should not be able to log at DEBUG level
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)
        assert logger.isEnabledFor(logging.INFO)
        assert logger.isEnabledFor(logging.WARNING)
        assert logger.isEnabledFor(logging.ERROR)
        assert logger.isEnabledFor(logging.CRITICAL)

    # logger should not be able to log at INFO level
    with logger_level(logger, logging.INFO):
        assert not logger.isEnabledFor(logging.DEBUG)
        assert logger.isEnabledFor(logging.INFO)
        assert logger.isEnabledFor(logging.WARNING)
        assert logger.isEnabledFor(logging.ERROR)
        assert logger.isEnabledFor

# Generated at 2022-06-12 08:01:21.206428
# Unit test for function logger_level
def test_logger_level():
    import io
    import sys
    import unittest
    import unittest.mock

    class LoggerLevelTest(unittest.TestCase):
        def setUp(self):
            super(LoggerLevelTest, self).setUp()
            self.logger = logging.getLogger(__name__)
            self.handler = logging.StreamHandler(sys.stdout)
            self.handler.setLevel(logging.DEBUG)
            self.logger.addHandler(self.handler)

        def test_logger_level(self):
            level_before = self.logger.getEffectiveLevel()
            with logger_level(self.logger, logging.DEBUG):
                level_during = self.logger.getEffectiveLevel()
            level_after = self.logger.getEffectiveLevel()
            self.assertLess

# Generated at 2022-06-12 08:01:57.358499
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG)

    assert get_config(
        default=DEFAULT_CONFIG,
        env_var='LOGGING',
    )

    assert get_config(
        config='{"version": 1, "disable_existing_loggers": False}',
        env_var='LOGGING',
    )

    assert get_config(
        config='\
              version: 1\n\
              disable_existing_loggers: False',
        env_var='LOGGING',
    )



# Generated at 2022-06-12 08:02:02.016165
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.info('Test INFO')
    with logger_level(logger, logging.DEBUG):
        logger.debug('Test DEBUG')
    logger.info('Test INFO')

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:02:04.372939
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING') == DEFAULT_CONFIG


# Generated at 2022-06-12 08:02:11.391472
# Unit test for function logger_level
def test_logger_level():
    """ Test for function logger_level
    """
    # Create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Create a handler to print all messages
    ch = logging.StreamHandler()
    formatter = logging.Formatter('%(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    with logger_level(logger, logging.INFO):
        logger.debug('this is a DEBUG message')
        logger.info('this is a INFO message')

    logger.debug('this is a DEBUG message')



# Generated at 2022-06-12 08:02:15.564739
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    logger.debug('debug')
    logger.info('info')
    logger.warning('warning')
    logger.error('error')
    logger.critical('critical')



# Generated at 2022-06-12 08:02:21.227277
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')

    with logger_level(logger, logging.INFO):
        assert logger.getEffectiveLevel() >= logging.INFO


# Test default config
DEFAULT_CONFIG['formatters']['colored']['()'] = 'logging.Formatter'
configure(DEFAULT_CONFIG)
test_logger = logging.getLogger('test_logger_level')
assert test_logger.getEffectiveLevel() == logging.DEBUG
logging.shutdown()

# Generated at 2022-06-12 08:02:32.007744
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    expected_min_level = logging.WARNING

    # Test case: logger level is DEBUG (default)
    with logger_level(logger, logging.DEBUG):
        logger.debug('This debug message should be displayed')
        logger.warning('This warning message should be displayed')
    # Test case: logger level is WARNING
    with logger_level(logger, logging.WARNING):
        logger.debug('This debug message should not be displayed')
        logger.warning('This warning message should be displayed')
    # Test case: logger level is CRITICAL
    with logger_level(logger, logging.CRITICAL):
        logger.debug('This debug message should not be displayed')
        logger.warning('This warning message should not be displayed')
        logger.critical('This critical message should be displayed')
    # Test case: logger level

# Generated at 2022-06-12 08:02:36.950190
# Unit test for function logger_level
def test_logger_level():
    import logging
    
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)

    with logger_level(logging.getLogger("logger_test"), logging.INFO):
        logger = logging.getLogger("logger_test")
        assert logger.level != logging.DEBUG
        assert logger.level == logging.INFO

# Generated at 2022-06-12 08:02:43.880069
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler(sys.stderr))

    with logger_level(logger, logging.DEBUG):
        logger.info('info')
        logger.debug('debug')

    logger.info('info')
    logger.debug('debug')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:02:48.153753
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug("This shouldn't print")
        logger.info("This should print")
    logger.debug("This should print")


# This is a pretty generic setup, but it has a few annoyances:
#   - it doesn't allow info to be displayed in the tests

# Generated at 2022-06-12 08:03:23.819726
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.isEnabledFor(logging.DEBUG)
    assert not log.isEnabledFor(logging.DEBUG)



# Generated at 2022-06-12 08:03:26.569196
# Unit test for function configure
def test_configure():
    """Unit test for configure"""
    import pytest
    with pytest.raises(ValueError):
        configure(default=None)
    with pytest.raises(ValueError):
        configure(default='')



# Generated at 2022-06-12 08:03:28.821068
# Unit test for function configure
def test_configure():
    configure()


if __name__ == '__main__':
    import doctest

    doctest.testmod(optionflags=(doctest.ELLIPSIS))

# Generated at 2022-06-12 08:03:37.890939
# Unit test for function get_config
def test_get_config():
    # Test case: no config
    get_config()

    # Test case: string config

# Generated at 2022-06-12 08:03:41.209167
# Unit test for function get_config
def test_get_config():
    import pytest

    assert get_config() == DEFAULT_CONFIG
    assert get_config(123) == 123
    with pytest.raises(ValueError):
        get_config(None)
    with pytest.raises(ValueError):
        get_config('')



# Generated at 2022-06-12 08:03:46.944209
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')

    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')



# Generated at 2022-06-12 08:03:51.060138
# Unit test for function logger_level
def test_logger_level():
    import logging
    import os
    import tempfile
    l = logging.getLogger()
    import time

    with tempfile.NamedTemporaryFile(delete=False) as f:
        n = f.name


# Generated at 2022-06-12 08:03:59.403578
# Unit test for function logger_level
def test_logger_level():
    if sys.version_info.major == 3:
        from unittest import TestCase, mock
    else:
        from mock import TestCase, mock
        from future.utils import with_metaclass
        TestCase.assertRaisesRegex = TestCase.assertRaisesRegexp

    with mock.patch('invenio_logging.logging.config') as mock_config:
        mock_config.dictConfig.return_value = "config"
        mock_config.getLogger.return_value = "logger"

        # Test the logger_level function
        with logger_level("logger", logging.INFO):
            with logger_level("logger", logging.DEBUG):
                assert "logger" == "logger"
            assert logging.INFO == logging.DEBUG

        # Test the get_logger function

# Generated at 2022-06-12 08:04:03.120751
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('logging.DEBUG')
        logger.info('logging.DEBUG')
        with logger_level(logger, logging.INFO):
            logger.debug('logging.INFO')
            logger.info('logging.INFO')
    logger.debug('logging.DEBUG')
    logger.info('logging.DEBUG')



# Generated at 2022-06-12 08:04:05.790253
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), logging.DEBUG):
        getLogger().debug('test1')
        getLogger().info('test2')


if __name__ == '__main__':
    import doctest