

# Generated at 2022-06-12 07:54:40.816536
# Unit test for function logger_level
def test_logger_level():
    # log = get_logger(__name__)
    import logging

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    root_logger.addHandler(console_handler)

    log = logging.getLogger()

    level = log.level
    assert level == logging.DEBUG

    logger_level(log, logging.INFO)
    assert log.level == logging.INFO

    # Run a function with new logger level
    def test_logger():
        assert log.getEffectiveLevel() == logging.INFO
        assert log.isEnabledFor(logging.INFO) == True

    test_logger()

    # Check if logger level is reset to initial level
   

# Generated at 2022-06-12 07:54:52.194167
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import logging
    import sys
    import random

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(__name__)

        def test_logger_level(self):
            import StringIO
            output = StringIO.StringIO()
            handler = logging.StreamHandler(output)
            handler.setLevel(logging.INFO)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
            with logger_level(self.logger, logging.DEBUG):
                self.logger.debug("debug message")
            msg = output.getvalue()
            self.assertEqual(msg, "debug message\n", "output does not match")


# Generated at 2022-06-12 07:54:54.846393
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log,logging.DEBUG):
        log.info('test')
        log.debug('test')
    log.debug('test')


# Generated at 2022-06-12 07:55:04.520424
# Unit test for function logger_level
def test_logger_level():
    import sys
    import StringIO
    output = StringIO.StringIO()
    logger = logging.getLogger(__name__)
    loghandler = logging.StreamHandler(output)
    loghandler.setFormatter(logging.Formatter('%(levelname)s|%(message)s'))
    logger.addHandler(loghandler)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    assert output.getvalue().strip() == 'DEBUG|test'
    with logger_level(logger, logging.WARNING):
        logger.debug('test')
    assert output.getvalue().strip() == 'DEBUG|test'

# Generated at 2022-06-12 07:55:11.324583
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_log_file = os.path.join(tmp_dir, 'test.log')

# Generated at 2022-06-12 07:55:19.338979
# Unit test for function configure
def test_configure():
    import logging
    import logutils.dictconfig

    # Set the env var
    os.environ['LOGGING'] = '{"handlers": {"console": {"formatter": "colored"}}}'
    configure()

    # Try to get the root logger
    root_logger = logging.getLogger()

    # Check that the root logger has a handler
    assert root_logger.handlers is not None
    assert root_logger.handlers[0].formatter.format == '%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s'



# Generated at 2022-06-12 07:55:24.886977
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('test_logger_level')
    assert log.getEffectiveLevel() == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.getEffectiveLevel() == logging.INFO
    assert log.getEffectiveLevel() == logging.DEBUG

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    test_logger_level()

# Generated at 2022-06-12 07:55:32.082116
# Unit test for function logger_level
def test_logger_level():
    """
    >>> import logging
    >>> log = logging.getLogger(__name__)

    >>> from logging import CRITICAL
    >>> from logging import ERROR
    >>> from logging import WARNING
    >>> from logging import INFO
    >>> from logging import DEBUG
    >>> from logging import NOTSET

    >>> log.setLevel(DEBUG)

    >>> with logger_level(log, INFO):
    ...     log.debug('this should not show')
    ...     log.info('this should show')
    INFO:__main__:this should show
    """
    pass


# Generated at 2022-06-12 07:55:35.711904
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
    logger.info('info')
    assert logger.level != logging.DEBUG



# Generated at 2022-06-12 07:55:45.645535
# Unit test for function get_config
def test_get_config():
    logging.basicConfig(
        format='%(levelname)s: %(message)s',
        level=logging.DEBUG)
    log = logging.getLogger(__name__)
    log.info('start')
    try:
        get_config(None, 'LOGGING', None)
        log.info('failed')
    except ValueError as e:
        log.info(e)

# Generated at 2022-06-12 07:55:52.061498
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    assert logger.getEffectiveLevel() == 10
    with logger_level(logger, 100):
        assert logger.getEffectiveLevel() == 100



# Generated at 2022-06-12 07:55:54.287154
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    configure(DEFAULT_CONFIG)
    logger.info('test')

# Generated at 2022-06-12 07:55:59.547882
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    with logger_level(logger, logging.INFO):
        logger.critical('critical')
        logger.error('error')
        logger.warning('warning')
        logger.info('info')
        logger.debug('debug')
        logger.notset('notset')



# Generated at 2022-06-12 07:56:07.656441
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    # Test case 1: Default logger level is DEBUG. Setting custom level to INFO should be printed
    #              and when setting the level back to DEBUG, INFO should not be printed anymore

    with logger_level(logger, level=logging.INFO):
        logger.info('Test case 1: This log should be printed')

    logger.info('Test case 1: This log should NOT be printed')

    # Test case 2: Default logger level is DEBUG. Setting custom level to WARNING should not be printed
    #              and when setting the level back to DEBUG, WARNING should be printed

    with logger_level(logger, level=logging.WARNING):
        logger.info('Test case 2: This log should NOT be printed')

    logger.info('Test case 2: This log should be printed')

    # print('Test case 2: This log should

# Generated at 2022-06-12 07:56:12.299615
# Unit test for function configure
def test_configure():
    os.environ['LOGGING'] = '{"handlers":{"console":{"level":"ERROR"}}}'
    configure()
    assert logging.getLevelName(logging.getLogger().getEffectiveLevel()) == 'ERROR'


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:56:14.494803
# Unit test for function get_config
def test_get_config():
    """
    >>> config = get_config(default='{"version": 1}')
    >>> config['version']
    1
    """
    return



# Generated at 2022-06-12 07:56:18.529248
# Unit test for function configure
def test_configure():
    with logger_level(get_logger(__name__), logging.DEBUG):
        log = get_logger(__name__)
        log.debug('test')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-12 07:56:24.254639
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-12 07:56:32.959734
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("my debug message (should appear)")
        log.info("my info message (should appear)")
        log.error("my error message (should appear)")
    log.debug("my debug message (should not be displayed)")
    log.info("my info message (should not be displayed)")
    log.error("my error message (should not be displayed)")

    with logger_level(log, logging.WARN):
        log.debug("my debug message (should not appear)")
        log.info("my info message (should not appear)")
        log.error("my error message (should appear)")
    log.debug("my debug message (should not be displayed)")

# Generated at 2022-06-12 07:56:37.865935
# Unit test for function logger_level
def test_logger_level():
    import logging
    log = logging.getLogger('test_logger')
    with logger_level(log, logging.DEBUG):
        log.debug("This is debug")
        log.info("This is info")
        log.warning("This is warning")
    log.info("This is info again")
    log.warning("This is warning again")


# Generated at 2022-06-12 07:56:43.969261
# Unit test for function configure
def test_configure():
    log = logging.getLogger('test_configure')
    configure()
    log.info('test complete')

# Generated at 2022-06-12 07:56:54.965787
# Unit test for function logger_level
def test_logger_level():
    import os
    import logging

    try:
        os.remove("test.log")
    except:
        pass

    logger = get_logger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    fh = logging.FileHandler('test.log', mode='w')
    fh.setLevel(logging.DEBUG)
    logger.addHandler(fh)

    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")
    logger.error("error message")
    logger.critical("critical message")

    logger.setLevel(logging.ERROR)

    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")

# Generated at 2022-06-12 07:56:57.609322
# Unit test for function get_config
def test_get_config():
    get_config(1)
    get_config("test")

test_get_config()


# Generated at 2022-06-12 07:57:02.026431
# Unit test for function logger_level
def test_logger_level():
    import logging
    with logger_level(logging.getLogger(__name__), logging.DEBUG):
        log = logging.getLogger(__name__)
        log.info('logger_level is debug')
    log.info('logger_level is back to its original level')

# Generated at 2022-06-12 07:57:06.137114
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__ + '.test_logger_level')
    configure()

    def _test():
        log.info('test')
        log.debug('debug')
        log.warn('warn')

    _test()

    with logger_level(log, logging.WARN):
        _test()

# Generated at 2022-06-12 07:57:10.862031
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('logger level is set to DEBUG from now on')
    logger.debug('now it is not DEBUG anymore')


# TODO this is a terrible hack
_last_logger = None



# Generated at 2022-06-12 07:57:14.361400
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config(default=DEFAULT_CONFIG)
    assert DEFAULT_CONFIG == get_config(config=DEFAULT_CONFIG)
    import json
    assert DEFAULT_CONFIG == get_config(config=json.dumps(DEFAULT_CONFIG))

# Generated at 2022-06-12 07:57:17.895047
# Unit test for function logger_level
def test_logger_level():
    from . import get_logger

    log = get_logger()

    with logger_level(log, logging.INFO):
        log.info("Log message!")
        with logger_level(log, logging.DEBUG):
            log.debug("Debug message!!!")
        log.info("Another log message!")

    with logger_level(log, logging.INFO):
        log.info("Log message!")



# Generated at 2022-06-12 07:57:29.259075
# Unit test for function get_config
def test_get_config():
    from nose.tools import assert_equal, assert_raises
    from contextlib import contextmanager

    def test_json(config):
        @contextmanager
        def temp(key, value):
            old_value = os.environ.get(key)
            os.environ[key] = value
            try:
                yield
            finally:
                if old_value:
                    os.environ[key] = old_value
                else:
                    del os.environ[key]

        with temp('LOGGING', config):
            assert_equal(get_config(env_var='LOGGING'), DEFAULT_CONFIG)

    def test_bare(config):
        @contextmanager
        def temp(key, value):
            old_value = os.environ.get(key)

# Generated at 2022-06-12 07:57:35.617077
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    assert(logger.level == logging.DEBUG)

    with logger_level(logger, logging.WARN):
        assert(logger.level == logging.WARN)
        logger.debug('DEBUG')
        logger.warn('WARN')

    assert(logger.level == logging.DEBUG)
    logger.debug('DEBUG')
    logger.warn('WARN')

test_logger_level()

# Generated at 2022-06-12 07:57:46.537828
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    # Test that logger_level() is callable
    with logger_level(log, logging.INFO):
        log.info("Testing logger_level")
    # Test that logger_level() restores previous state
    with logger_level(log, logging.WARN):
        assert log.level == logging.WARN
    assert log.level == logging.DEBUG

# Generated at 2022-06-12 07:57:55.651804
# Unit test for function logger_level
def test_logger_level():
    import sys
    from io import StringIO
    from contextlib import contextmanager

    f = StringIO()
    old_stdout = sys.stdout
    sys.stdout = f

    @contextmanager
    def capture():
        old_out, sys.stdout = sys.stdout, StringIO()
        try:
            yield sys.stdout
        finally:
            sys.stdout = old_out

    logger = logging.getLogger()

    with logger_level(logger, logging.DEBUG), capture() as stdout:
        logger.debug("Foo")
    assert stdout.getvalue().strip() == "Foo"

    with logger_level(logger, logging.INFO), capture() as stdout:
        logger.debug("Bar")
    assert stdout.getvalue().strip() == ""


# Generated at 2022-06-12 07:57:57.312212
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-12 07:58:00.588067
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.ERROR):
        with logger_level(log, logging.CRITICAL):
            log.error("test")
        log.error("test")
    log.error("test")


# Generated at 2022-06-12 07:58:07.456072
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    logger.setLevel(logging.CRITICAL)

    # For the context block, we set the logger level to 'DEBUG'.
    with logger_level(logger, logging.DEBUG):
        # Set the level of my logger to INFO. Since we are inside the context block,
        # the level is automatically reset to DEBUG.
        logger.setLevel(logging.INFO)
        logger.debug('logger_level test')


# create a logger for module
log = get_logger(__name__)

# Generated at 2022-06-12 07:58:17.704293
# Unit test for function get_config
def test_get_config():
    logger = getLogger()
    logger.info("test_get_config")
    logger.info("default: " + str(get_config(default=DEFAULT_CONFIG)))
    logger.info("default: " + str(get_config(config=DEFAULT_CONFIG)))
    logger.info("empty: " + str(get_config()))
    logger.info("empty: " + str(get_config(config='{"xxoo" : "xxoo"}')))
    logger.info("empty: " + str(get_config(config='{"version" : 1}')))

# Generated at 2022-06-12 07:58:20.369150
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.info("Before change")
    with logger_level(logger, logging.DEBUG):
        logger.info("In context")
    logger.info("After change")


# Generated at 2022-06-12 07:58:22.591003
# Unit test for function logger_level
def test_logger_level():
    root = get_logger()
    with logger_level(root, logging.ERROR):
        assert root.level == logging.ERROR
    assert root.level == logging.DEBUG


# Generated at 2022-06-12 07:58:24.064886
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')



# Generated at 2022-06-12 07:58:29.362978
# Unit test for function configure
def test_configure():
    import os.path
    import inspect
    import json
    import logging
    import logging.config

    with open(os.path.abspath(os.path.join(inspect.getfile(inspect.currentframe()), os.pardir, "test", "logging.json"))) as f:
        logging_config = json.load(f)
        logging.config.dictConfig(logging_config)



# Generated at 2022-06-12 07:58:43.882866
# Unit test for function logger_level
def test_logger_level():
    import unittest

    class LoggerLevelTester(unittest.TestCase):
        def test_logger_level(self):
            """Check that logger_level works in both directions with the default logger"""
            dummy_logger = logging.getLogger(__name__ + '.dummy_logger')
            with logger_level(dummy_logger, logging.WARNING):
                dummy_logger.error('err')
                dummy_logger.warning('warn')
            dummy_logger.info('info')

    unittest.main()



# Generated at 2022-06-12 07:58:48.671240
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.CRITICAL):
        assert log.level == logging.CRITICAL
        with logger_level(log, logging.DEBUG):
            assert log.level == logging.DEBUG
        assert log.level == logging.CRITICAL


# Generated at 2022-06-12 07:58:57.850003
# Unit test for function logger_level
def test_logger_level():
    import pprint
    from time import time, sleep


# Generated at 2022-06-12 07:59:01.182505
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test')
    log.setLevel(logging.DEBUG)
    log.addHandler(logging.StreamHandler(sys.stderr))

    log.debug('test')
    with logger_level(log, logging.INFO) as log:
        log.debug('test')

    log.debug('test')

# Generated at 2022-06-12 07:59:07.698769
# Unit test for function logger_level
def test_logger_level():
    from pyutil.assertutil import _assert
    log = logging.getLogger('test.logger_level')
    configure()
    log.debug('Test')
    log.info('Test')
    with logger_level(log, logging.WARN):
        log.debug('Test')
        log.info('Test')
        log.warn('Test')
    log.debug('Test')
    log.info('Test')


# Generated at 2022-06-12 07:59:17.040460
# Unit test for function get_config
def test_get_config():
    test_json = '{"version": 1, "disable_existing_loggers": false, "formatters": {"simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": "DEBUG"}}, "root": {"handlers": ["console"], "level": "DEBUG"}, "loggers": {"requests": {"level": "INFO"}}}'

# Generated at 2022-06-12 07:59:21.726723
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__+':test_logger_level')
    log.info('before setting level')
    with logger_level(log, logging.WARNING):
        log.info('should not see this')
        log.warning('instead this')
    log.info('after setting level')
    log.warning('as well as this')



# Generated at 2022-06-12 07:59:26.368281
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import logging

    #logging.basicConfig(level=logging.DEBUG)
    l = logging.getLogger("logger_level")

    with logger_level(l, logging.DEBUG):
        l.info("This should be logged")

    with logger_level(l, logging.INFO):
        l.info("This should NOT be logged")

    assert isinstance(logger_level, contextmanager)



# Generated at 2022-06-12 07:59:32.365016
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager

    @contextmanager
    def logger_level(logger, level):
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    logger = logging.getLogger(__name__)

    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
    logger.info('info')



# Generated at 2022-06-12 07:59:36.069078
# Unit test for function get_config
def test_get_config():
    assert get_config(default={1: 2}) == {1: 2}
    assert get_config(json.dumps({1:2})) == {1: 2}
    assert get_config(yaml.dump({1:2})) == {1: 2}

# Generated at 2022-06-12 07:59:59.504753
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    log.setLevel(logging.WARNING)
    assert log.getEffectiveLevel() == logging.WARNING

    with logger_level(log, logging.INFO):
        assert log.getEffectiveLevel() == logging.INFO

    assert log.getEffectiveLevel() == logging.WARNING

# Generated at 2022-06-12 08:00:10.470063
# Unit test for function get_config
def test_get_config():
    # enviroment variable can override the default config
    cfg = get_config(
        config={"version": 2},
        env_var="LOGGING",
        default={"version": 1})
    assert(cfg["version"] == 2)

    # Even if there is no environment variable, the given config should
    # override the default config
    cfg = get_config(
        config={"version": 2},
        env_var=None,
        default={"version": 1})
    assert(cfg["version"] == 2)

    # If no pre-defined config and no given config is provided, the default
    # config should be used
    cfg = get_config(
        config=None,
        env_var=None,
        default={"version": 1})
    assert(cfg["version"] == 1)

    #

# Generated at 2022-06-12 08:00:15.578585
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()
    logger = getLogger("logger_level")
    logger.setLevel(logging.INFO)

    with logger_level(logger, logging.DEBUG):
        logger.debug("debug test")

    logger.debug("debug test")
    logger.info("info test")
    logger.error("error test")



# Generated at 2022-06-12 08:00:24.325955
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        # Test logging.INFO
        log.debug('This should not show up')
        log.info('This should show up')
    log.debug('This should still not show up')
    log.info('This should still show up')
    with logger_level(log, logging.DEBUG):
        # Test logging.DEBUG
        log.debug('This should show up')
        log.info('This should also show up')
    log.debug('This should still not show up')
    log.info('This should still show up')

# Generated at 2022-06-12 08:00:30.109211
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    list_handler = logging.Handler()
    list_handler.createLock()
    logger.addHandler(list_handler)
    with logger_level(logger, logging.WARN):
        logger.debug('FOO')
        assert list_handler.buffer == []
        logger.info('BAR')
        assert list_handler.buffer == []
        logger.warn('BAZ')
        assert list_handler.buffer == ['BAZ']
        logger.error('BAZZ')
        assert list_handler.buffer == ['BAZ','BAZZ']
        logger.critical('BAZZZ')
        assert list_handler.buffer == ['BAZ','BAZZ','BAZZZ']
    logger.debug('FOO')
    assert list_handler.buffer == ['BAZ','BAZZ','BAZZZ']
   

# Generated at 2022-06-12 08:00:38.348378
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    with logger_level(logger=logger, level=logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG) is True
        logger.debug('logging.DEBUG')
        assert logger.isEnabledFor(logging.INFO) is True
        logger.info('logging.INFO')
        assert logger.isEnabledFor(logging.WARNING) is True
        logger.warning('logging.WARNING')
        assert logger.isEnabledFor(logging.ERROR) is True
        logger.error('logging.ERROR')
        assert logger.isEnabledFor(logging.CRITICAL) is True
        logger.critical('logging.CRITICAL')

# Generated at 2022-06-12 08:00:40.892178
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG


# API SHIM
configure_logging = configure

# Generated at 2022-06-12 08:00:48.716809
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger("test_logger_level")

    with logger_level(log, logging.INFO):
        assert log.getEffectiveLevel() == logging.INFO
        log.debug("Log at DEBUG level")
        log.info("Log at INFO level")
        log.warning("Log at WARNING level")
        log.error("Log at ERROR level")
        log.critical("Log at CRITICAL level")


    assert log.getEffectiveLevel() != logging.INFO
    log.debug("Log at DEBUG level")
    log.info("Log at INFO level")
    log.warning("Log at WARNING level")
    log.error("Log at ERROR level")
    log.critical("Log at CRITICAL level")

# Generated at 2022-06-12 08:00:54.039275
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.WARNING):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
    logger.debug("debug message")
    logger.info("info message")
    logger.warning("warning message")


_stream_handler = None
_stream_handler_tee = None



# Generated at 2022-06-12 08:00:58.848227
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("dummy")
    logger.setLevel(logging.DEBUG)
    logger.debug("logger level is initially %d", logger.level)
    with logger_level(logger, logging.INFO):
        logger.debug("logger level is now %d", logger.level)
    logger.debug("logger level is now %d", logger.level)


# Generated at 2022-06-12 08:01:49.464428
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.WARNING):
        logger.debug('debug msg')
    logger.info('info msg')

# Generated at 2022-06-12 08:01:55.352334
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__ + '.test_logger_level')
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        logger.debug('This message is not logged')
        logger.info('This message is logged')

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:02:00.278973
# Unit test for function get_config
def test_get_config():
    cfg = get_config(config='{"version": 1}')
    assert cfg == {"version": 1}
    cfg = get_config(config='version: 1', default={})
    assert cfg == {"version": 1}


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:02:01.445503
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG) as l:
        log.debug('test')

# Generated at 2022-06-12 08:02:04.105864
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('test')
    logger.debug('test')
    logger.info('test')


# Generated at 2022-06-12 08:02:13.020227
# Unit test for function logger_level
def test_logger_level():
    print(logger_level)
    logging.basicConfig()
    log = logging.getLogger(__name__)
    
    with logger_level(log, logging.CRITICAL):
        log.debug('This does NOT show up')
        log.info('This does NOT show up')
        log.error('This does NOT show up')

    with logger_level(log, logging.INFO):
        log.debug('This does NOT show up')
        log.info('This DOES show up')
        log.error('This DOES show up')

    with logger_level(log, logging.DEBUG):
        log.debug('This DOES show up')
        log.info('This DOES show up')
        log.error('This DOES show up')
   
if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:02:21.008363
# Unit test for function get_config

# Generated at 2022-06-12 08:02:22.458289
# Unit test for function logger_level
def test_logger_level():
    raise NotImplementedError



# Generated at 2022-06-12 08:02:27.949387
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__file__)
    configure()

    with logger_level(logger, logging.DEBUG):
        logger.debug("ok1")
        with logger_level(logger, logging.INFO):
            logger.debug("not ok2")
            logger.info("ok2")
        logger.debug("ok3")

# Generated at 2022-06-12 08:02:34.132498
# Unit test for function get_config
def test_get_config():
    cfg = get_config(None, 'NONESENSE', default=None)
    assert cfg is None
    cfg = get_config(None, 'NONESENSE', default={'a':1})
    assert cfg == {'a':1}
    cfg = get_config(None, 'NONESENSE', default={'a':1, 'b':2})
    assert cfg == {'a':1, 'b':2}
    cfg = get_config(None, 'NONESENSE', default=[1,2,3])
    assert cfg == [1,2,3]

# Generated at 2022-06-12 08:04:27.568558
# Unit test for function get_config
def test_get_config():
    import json
