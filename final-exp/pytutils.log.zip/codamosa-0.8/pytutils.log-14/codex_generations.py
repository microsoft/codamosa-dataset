

# Generated at 2022-06-12 07:54:37.567424
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.WARN):
        log.debug('this should not print')
        assert log.level == logging.WARN
    log.debug('pause')
    assert log.level == logging.DEBUG

# Generated at 2022-06-12 07:54:49.220707
# Unit test for function configure

# Generated at 2022-06-12 07:54:57.497521
# Unit test for function get_config
def test_get_config():
    # Given a dict.
    config = dict(version=1, formatters={'simple':{'format': '%(message)s'}})
    cfg = get_config(config)
    assert cfg == config

    # Given a json string.
    config = dict(version=1, formatters={'simple':{'format': '%(message)s'}})
    cfg = get_config(json.dumps(config))
    assert cfg == config

    # Given a yaml string.
    config = dict(version=1, formatters={'simple':{'format': '%(message)s'}})
    cfg = get_config("version: 1\nformatters:\n simple:\n  format:\n   %(message)s")
    assert cfg == config

    # Given a ENV
   

# Generated at 2022-06-12 07:55:00.583291
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.INFO):
        logger.debug('test_debug')
        logger.info('test_info')



# Generated at 2022-06-12 07:55:04.011674
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, logging.WARNING):
        logger.debug('ooh you want to see this?')

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:55:04.977838
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-12 07:55:08.230016
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    logger.debug('This should not print')

    with logger_level(logger, logging.DEBUG):
        logger.debug('This should print')

    logger.debug('This should not print')


# Generated at 2022-06-12 07:55:12.967143
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARNING):
        logger.warning("Test logger_level")
        logger.info("Test logger_level")
    logger.info("Test logger_level")



# Generated at 2022-06-12 07:55:17.335899
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = get_logger()
    >>> with logger_level(logger, logging.WARN):
    ...     logger.debug('This should not be displayed')
    ...     try:
    ...         raise Exception('You shouldn\'t see this either')
    ...     except Exception:
    ...         logger.exception('it\'s working')
    """
    pass

# Generated at 2022-06-12 07:55:19.991793
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()
    log = get_logger()
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG

# Generated at 2022-06-12 07:55:29.699861
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    logger = getLogger()
    logger.debug('Eek, this won\'t show up')
    with logger_level(logger, logging.DEBUG):
        logger.debug('Debug!')
        with logger_level(logger, logging.INFO):
            logger.debug('Boo!')
        logger.debug('Debug!')
    logger.debug('Eek, this won\'t show up either')



# Generated at 2022-06-12 07:55:33.689647
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info("TEST log INFO")
    log.debug("TEST log DEBUG")
    log.warning("TEST log WARNING")
    log.error("TEST log ERROR")
    log.critical("TEST log CRITICAL")

if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-12 07:55:39.876127
# Unit test for function logger_level
def test_logger_level():
    import io
    import logging

    log = logging.getLogger('logger_level')
    log.setLevel(logging.NOTSET)
    with io.StringIO() as f:
        logging.basicConfig(level=logging.NOTSET, stream=f)
        log.debug("Not written")
        with logger_level(log, logging.DEBUG):
            log.debug("Written")
        log.debug("Not written")
        assert f.getvalue() == "Written\n", f.getvalue()

# Generated at 2022-06-12 07:55:42.460707
# Unit test for function logger_level
def test_logger_level():
    TEST_LEVEL = 30
    logger = get_logger()
    with logger_level(logger, TEST_LEVEL):
        assert logger.getEffectiveLevel() == TEST_LEVEL

# Generated at 2022-06-12 07:55:45.778780
# Unit test for function logger_level
def test_logger_level():
    l = logging.getLogger("logger_level_test")
    configure()
    with logger_level(l, logging.DEBUG):
        l.warning("this will not be printed")
        l.debug("this will be printed")



# Generated at 2022-06-12 07:55:55.938581
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.ERROR):
        getLogger().error('This should print. Error > Error')
        getLogger().warn('This should not print. Error > Warn')
        with logger_level(logging.getLogger(), logging.INFO):
            getLogger().info('This should not print. Error > Info')
            with logger_level(logging.getLogger(), logging.WARN):
                getLogger().warn('This should print. Error > Warn > Warn')
                getLogger().error('This should print. Error > Warn > Error')
                getLogger().info('This should not print. Error > Warn > Info')
            getLogger().warn('This should not print. Error > Warn')
        getLogger().info('This should not print. Error > Info')

# Generated at 2022-06-12 07:56:06.161284
# Unit test for function get_config
def test_get_config():
    default_config = '{"version": 1, "disable_existing_loggers": false, "formatters": {}, "handlers": {}, "root": {"handlers": ["console"], "level": "DEBUG"}, "loggers": {}}'

    assert get_config(default=default_config) == {"version": 1, "disable_existing_loggers": False, "formatters": {}, "handlers": {}, "root": {"handlers": ["console"], "level": "DEBUG"}, "loggers": {}}
    assert get_config(default=default_config, env_var=None) == {"version": 1, "disable_existing_loggers": False, "formatters": {}, "handlers": {}, "root": {"handlers": ["console"], "level": "DEBUG"}, "loggers": {}}

# Generated at 2022-06-12 07:56:15.513955
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()

    logger = logging.getLogger(__name__)

    for level in [logging.ERROR, logging.WARNING, logging.INFO, logging.DEBUG]:
        with logger_level(logger, level):
            logger.info('Logging at test level: %s' % level)
            logger.critical('This should always log regardless of the level')

    # logger should be back to the original level
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should always log regardless of the level')
        logger.error('Should always log')
        logger.warning('Should always log')
        logger.info('Should always log')
        logger.debug('Should always log')
    logger.info('Should log at the original log level')

if __name__ == '__main__':
    test_log

# Generated at 2022-06-12 07:56:25.798062
# Unit test for function logger_level
def test_logger_level():
    from . import test_logger
    import logging
    import sys

    logger = test_logger.get_logger()

    # log levels
    DEBUG = logging.DEBUG
    INFO = logging.INFO

    def get_output_stream(stream):
        stream.seek(0)
        return stream.read().decode(sys.stdout.encoding)

    with open(os.devnull, 'w') as devnull:
        logger.handlers = []
        logger.addHandler(logging.StreamHandler(devnull))

        with logger_level(logger, DEBUG): 
            logger.info(1)
            assert logger.level == DEBUG

        with open(os.devnull, 'w') as out_stream, logger_level(logger, INFO): 
            logger.handlers = []

# Generated at 2022-06-12 07:56:28.380382
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.info('should print')
        log.debug('should print')
    log.info('should print')
    log.debug('should not print')



# Generated at 2022-06-12 07:56:38.429349
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        with logger_level(logger, logging.DEBUG):
            assert logger.level == logging.DEBUG

    assert logger.level == logging.DEBUG



# Generated at 2022-06-12 07:56:41.095790
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    log.info('test')


if __name__ == "__main__":
    from .test_util import run_tests

    run_tests(os.path.abspath(__file__))

# Generated at 2022-06-12 07:56:52.363350
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    log.debug("This is a test.")
    logger_level_10 = False
    logger_level_20 = False
    logger_level_30 = False
    with logger_level(log, logging.DEBUG) :
        log.debug("This is a test.")
        logger_level_10 = True
    with logger_level(log, logging.INFO) :
        log.debug("This is a test.")
        log.info("This is a test.")
        logger_level_20 = True
    with logger_level(log, logging.WARNING) :
        log.debug("This is a test.")
        log.info("This is a test.")
        log.warn("This is a test.")
        logger_level_30 = True
    assert logger_level_10 == True
    assert logger

# Generated at 2022-06-12 07:56:58.646990
# Unit test for function logger_level
def test_logger_level():
    import io

    logger = getLogger(__name__)

    # Set logger to debug level, then check that a debug log statement prints
    # to stdout
    logger.setLevel(logging.DEBUG)
    old_stdout = sys.stdout
    new_stdout = io.StringIO()
    sys.stdout = new_stdout
    logger.debug("Test debug")
    sys.stdout = old_stdout
    out = new_stdout.getvalue()
    assert 'Test debug' in out

    # Test logger_level by setting logger back to info level, then
    # logging within a contextblock with a debug level and checking
    # output.
    logger.setLevel(logging.INFO)
    old_stdout = sys.stdout
    new_stdout = io.StringIO()

# Generated at 2022-06-12 07:57:02.206765
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    log.info("test1")
    with logger_level(log, logging.WARN):
        log.info("test2")
        log.warn("test3")


# Generated at 2022-06-12 07:57:09.536217
# Unit test for function logger_level
def test_logger_level():
    import pytest
    import logging

    logger = logging.getLogger('TEST_LOGGER')

    initial_level = logger.level

    with logger_level(logger, logging.INFO):
        logger.debug('testing')
        logger.info('testing')
        with logger_level(logger, logging.DEBUG):
            logger.debug('nested testing')
        logger.info('testing again')

    with pytest.raises(AttributeError) as err:
        logger.info('testing')

    assert initial_level == logger.level

# Generated at 2022-06-12 07:57:13.658150
# Unit test for function configure
def test_configure():
    """
    >>> configure()

    >>> import json
    >>> cfg = json.dumps(DEFAULT_CONFIG)
    >>> configure(cfg)

    >>> import yaml
    >>> cfg = yaml.dump(DEFAULT_CONFIG)
    >>> configure(cfg)

    >>> configure(DEFAULT_CONFIG)

    """



# Generated at 2022-06-12 07:57:17.242987
# Unit test for function logger_level
def test_logger_level():
    p1 = getLogger('test_1')
    p2 = getLogger('test_2')
    p2.level = logging.INFO

    test_message = 'test message'
    with logger_level(p1, logging.INFO):
        p1.info(test_message)
    p2.info(test_message)



# Generated at 2022-06-12 07:57:18.805399
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger(__name__)
    log.info('test')



# Generated at 2022-06-12 07:57:26.784032
# Unit test for function logger_level
def test_logger_level():
    import logging
    # Check that logger level change
    log = logging.getLogger('test')
    log.setLevel(logging.INFO)
    with logger_level(log, logging.DEBUG):
        assert log.isEnabledFor(logging.DEBUG)
    assert not log.isEnabledFor(logging.DEBUG)
    # Check that logger level change back to the initial value
    with logger_level(log, logging.DEBUG):
        pass
    assert log.isEnabledFor(logging.INFO)


# Generated at 2022-06-12 07:57:34.658996
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
        logger.debug('this will not print')
    assert logger.level == logging.DEBUG



# Generated at 2022-06-12 07:57:42.951043
# Unit test for function get_config
def test_get_config():
    from .asserts import assert_equal, assert_raises

    assert_equal(get_config(config=None, env_var=None, default={'test': 'test'}), {'test': 'test'})
    assert_equal(get_config(config={'test': 'test'}, env_var=None, default=None), {'test': 'test'})

    os.environ['TEST_CONFIG_ENV_VAR'] = '{"test": "test"}'
    assert_equal(get_config(config=None, env_var='TEST_CONFIG_ENV_VAR', default=None), {'test': 'test'})

    # Invalid config test
    assert_raises(ValueError, get_config, config=None, env_var=None, default=None)

# Generated at 2022-06-12 07:57:52.529895
# Unit test for function get_config
def test_get_config():
    from io import StringIO
    from tempfile import NamedTemporaryFile
    import logging

    logger = logging.getLogger(__name__)

    # test bare config
    logger.info('test_get_config()')
    config = 'logging.INFO'
    cfg = get_config(config)
    assert cfg == 'logging.INFO'
    logger.info('config: %s', config)
    logger.info('cfg: %s', cfg)

    # test JSON config
    fd = StringIO('{"logging": 30}')
    config = fd.getvalue()
    cfg = get_config(config)
    assert cfg == {"logging": 30}
    logger.info('config: %s', config)
    logger.info('cfg: %s', cfg)

    # test Y

# Generated at 2022-06-12 07:58:01.748334
# Unit test for function get_config
def test_get_config():
    from pprint import pprint


# Generated at 2022-06-12 07:58:12.640403
# Unit test for function logger_level
def test_logger_level():
    import time

    logger = getLogger()
    logger.setLevel(logging.NOTSET)

    def log_level(level, msg):
        logger.setLevel(level)
        logger.debug(msg)
        logger.info(msg)
        logger.warn(msg)
        logger.error(msg)
        logger.critical(msg)
        logger.setLevel(logging.NOTSET)

    with logger_level(logger, logging.DEBUG):
        log_level(logging.DEBUG, 'level  DEBUG')

    with logger_level(logger, logging.INFO):
        log_level(logging.INFO, 'level  INFO')

    with logger_level(logger, logging.WARN):
        log_level(logging.WARN, 'level  WARN')


# Generated at 2022-06-12 07:58:13.558826
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-12 07:58:18.499110
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()

    log = get_logger()

    with logger_level(log, logging.CRITICAL):
        log.critical('logging at critical level')

    assert log.level == logging.INFO

# Make sure that a module can be imported as a submodule of another
# module.
# Probably not the right way to do it, but it works.
test_logger_level()

# Generated at 2022-06-12 07:58:20.474551
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, 10):
        log.debug('test debug')
        log.info('test log')


# Generated at 2022-06-12 07:58:29.435428
# Unit test for function logger_level
def test_logger_level():
    """
    This is a unit test for logger_level function.
    """
    # Set up a logger
    logger = get_logger(__name__)
    # Log
    print(logger.info('logger_level test'))
    # Set the level to be error
    print(logger.error('Log level is set to be error, should print this'))
    # Change the level to debug, should print the log
    with logger_level(logger, level=logging.DEBUG):
        print(logger.info('Log level will not be error anymore, should print this'))


if __name__ == '__main__':

    print(logging.CRITICAL)
    print(logging.FATAL)
    print(logging.ERROR)
    print(logging.WARNING)

# Generated at 2022-06-12 07:58:40.688627
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.handlers

    log = get_logger()

    with logger_level(log, logging.DEBUG):
        log.debug("This should not show up")
    log.info("This should show up")

    # Note: This test requires that the root logger level be set to DEBUG
    log.setLevel(logging.DEBUG)
    with logger_level(log, logging.INFO):
        log.debug("This should show up")
    log.info("This should show up")

    h = logging.StreamHandler()
    h.setLevel(logging.INFO)
    log.addHandler(h)
    log.setLevel(logging.INFO)
    with logger_level(log, logging.DEBUG):
        log.debug("This should show up")
    log.info("This should show up")

# Generated at 2022-06-12 07:58:50.707214
# Unit test for function configure
def test_configure():
    logger = get_logger()

    # test default config
    logger.warning('test log')

    # test given config
    configure(default=dict(
        version=1,
        disable_existing_loggers=False,
        formatters=None,
        handlers=None,
        root=dict(level=logging.DEBUG),
    ))

    logger.info('test log')



# Generated at 2022-06-12 07:58:59.043986
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    assert logger.level == logging.NOTSET

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET

    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.NOTSET

    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
    assert logger.level == logging.NOTSET

    try:
        with logger_level(logger, logging.WARNING):
            assert logger.level == logging.WARNING
            raise Exception("Raised")
    except Exception:
        assert logger.level == logging.NOTSET
        pass

    logger.level = logging.INFO

# Generated at 2022-06-12 07:59:02.872292
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__+'.test_logger_level')
    assert logger.level == 10 # python's default
    with logger_level(logger, 12):
        assert logger.level == 12
        with logger_level(logger, 14):
            assert logger.level == 14
        assert logger.level == 12
    assert logger.level == 10


# Generated at 2022-06-12 07:59:09.552924
# Unit test for function logger_level
def test_logger_level():
    capture = io.StringIO()
    handler = logging.StreamHandler(capture)
    logger = logging.getLogger("foof")
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.WARNING):
        logger.info("foo")
        logger.warning("bar")
    assert capture.getvalue() == "bar\n"



# Generated at 2022-06-12 07:59:12.511309
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    log.setLevel(logging.INFO)
    with logger_level(log, logging.DEBUG):
        log.debug("debug message")
    log.debug("not seen")



# Generated at 2022-06-12 07:59:19.144700
# Unit test for function get_config
def test_get_config():
    config = get_config()
    assert 'version' in config
    assert 'disable_existing_loggers' in config
    json_config = get_config('{"version": 1, "disable_existing_loggers": false}')
    assert 'version' in json_config
    assert 'disable_existing_loggers' in json_config
    yaml_config = get_config('version: 1\ndisable_existing_loggers: false')
    assert 'version' in yaml_config
    assert 'disable_existing_loggers' in yaml_config

# Generated at 2022-06-12 07:59:21.447504
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:59:28.838704
# Unit test for function get_config

# Generated at 2022-06-12 07:59:33.775828
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('logger_level')
    old_level = log.level
    try:
        with logger_level(log, logging.DEBUG):
            log.debug('This should print')
    finally:
        log.level = old_level
    assert log.level == old_level



# Generated at 2022-06-12 07:59:42.234482
# Unit test for function logger_level
def test_logger_level():
    import sys
    import six
    from cStringIO import StringIO
    import logging
    import contextlib

    # Construct StreamHandler
    if six.PY2:
        sio = StringIO()
        handler = logging.StreamHandler(sio)
        logger = logging.getLogger(__name__)
        logger.addHandler(handler)
    else:
        # Make a fake stream.
        sio = six.StringIO()

        class FakeStream(object):
            def write(self, out):
                sio.write(out)

        # Make a fake stream handler.
        class FakeStreamHandler(logging.StreamHandler):
            def __init__(self, fp):
                logging.StreamHandler.__init__(self, fp)

            def stream(self):
                return FakeStream()

        logger = logging

# Generated at 2022-06-12 07:59:55.640792
# Unit test for function get_config
def test_get_config():
    import unittest

    class GetConfigTest(unittest.TestCase):
        """Test for function get_config"""

        def test_get_config_dict(self):
            """Tests for valid configurations given as a dict"""

# Generated at 2022-06-12 08:00:02.989962
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("test_logger_level")
    configure()
    # Test setting level to more restrictive
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG
    # Test setting level to less restrictive
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:00:09.293440
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('sample')
    logger.setLevel(logging.DEBUG)
    logger.warning('Warn')
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        logger.warning('Warn')
        assert logger.level == logging.INFO
    logger.warning('Warn')
    assert logger.level == logging.DEBUG



# Generated at 2022-06-12 08:00:21.036834
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('testing_logger_level')
    print("Checking if logger is logging debug")
    log.debug('this should not be seen')
    print("Checking if logger is logging info")
    log.info('this should be seen')
    print("Checking if logger is logging warning")
    log.warning('this should be seen')
    print("Checking if logger is logging error")
    log.error('this should be seen')
    print("Setting logger level to INFO")
    with logger_level(log, logging.INFO):
        print("Checking if logger is logging debug")
        log.debug('this should not be seen')
        print("Checking if logger is logging info")
        log.info('this should be seen')
        print("Checking if logger is logging warning")

# Generated at 2022-06-12 08:00:25.317924
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.setLevel(logging.ERROR)
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should print')
    logger.debug('This should not print')


if __name__ == '__main__':
    test_logger_level()
    sys.exit(0)

# Generated at 2022-06-12 08:00:27.801756
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, logging.CRITICAL):
        logger.info('This message will not show')
        logger.critical('But this one will show')

    logger.info('back to normal!')



# Generated at 2022-06-12 08:00:30.382825
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    log.setLevel(logging.WARN)
    with logger_level(log, logging.DEBUG):
        log.debug("Debug message")
        log.info("Info message")
        log.warn("Warning message")
    log.info("Info message after")


# Generated at 2022-06-12 08:00:36.154923
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    # Test invalid config
    try:
        get_config('none')
        assert False
    except ValueError:
        assert True

    # Test yaml
    yaml_conf = yaml.dump(DEFAULT_CONFIG)
    assert get_config(yaml_conf) == DEFAULT_CONFIG

    # Test json
    json_conf = json.dumps(DEFAULT_CONFIG)
    assert get_config(json_conf) == DEFAULT_CONFIG


# Generated at 2022-06-12 08:00:40.089608
# Unit test for function logger_level
def test_logger_level():
    import time
    import logging
    logger = logging.getLogger(__name__)

    with logger_level(logger, logging.DEBUG):
        logger.debug("This is debug")
        logger.info("This is info")
        logger.error("This is error")
    time.sleep(2)
    logger.debug("This is debug")
    logger.info("This is info")
    logger.error("This is error")

# Generated at 2022-06-12 08:00:49.610588
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import io

    with io.StringIO as s:
        configure({'formatters': {'simple': {'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s'}}, 'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'simple', 'level': logging.DEBUG}}, 'root': {'handlers': ['console'], 'level': logging.DEBUG}})
        logging.info('test')
        print(s.getvalue())

# Generated at 2022-06-12 08:01:07.683853
# Unit test for function get_config
def test_get_config():
    assert get_config({'a': 123}, env_var='LOGGING_TEST', default={'b': 321}) == {'a': 123}
    assert get_config({'a': 123}, env_var='LOGGING_TEST') == {'a': 123}
    assert get_config(None, env_var='LOGGING_TEST', default={'b': 321}) == {'b': 321}
    assert get_config(None, env_var='LOGGING_TEST', default={'b': 321}) == {'b': 321}
    assert get_config(None, env_var=None, default={'b': 321}) == {'b': 321}

    os.environ['LOGGING_TEST'] = json.dumps({'c': 456})

# Generated at 2022-06-12 08:01:12.760808
# Unit test for function get_config

# Generated at 2022-06-12 08:01:23.212485
# Unit test for function get_config
def test_get_config():
    """
    :return:
    """
    assert get_config(given = None,
                      env_var = None,
                      default = DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(given = None,
                      env_var = 'LOGGING',
                      default = DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(given = "",
                      env_var = 'LOGGING',
                      default = DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config = DEFAULT_CONFIG) == DEFAULT_CONFIG
    import json
    import yaml

    json_val = json.dumps(DEFAULT_CONFIG)
    assert get_config(config = json_val) == DEFAULT_CONFIG

# Generated at 2022-06-12 08:01:31.954812
# Unit test for function logger_level
def test_logger_level():
    import io
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    with logger_level(logger, logging.ERROR):
        logger.debug("Debug message: Testing")
        assert stream.getvalue() == ""
        logger.error("Error message: Testing")
        assert stream.getvalue() == "Error message: Testing\n"
        logger.info("Info message: Testing")
        assert stream.getvalue() == "Error message: Testing\n"

if __name__ == "__main__":
    test_logger_level()
    print("Finished tests")

# Generated at 2022-06-12 08:01:41.871089
# Unit test for function logger_level
def test_logger_level():
    import logging
    import unittest
    from io import BytesIO

    class TestLoggerLevel(unittest.TestCase):

        def setUp(self):
            self._buf = BytesIO()
            # Monkeypatch
            self._real_stream = logging.StreamHandler.stream
            logging.StreamHandler.stream = self._buf

        def tearDown(self):
            # Restore
            logging.StreamHandler.stream = self._real_stream

        def test_logger_level_context(self):
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.INFO)
            logger.addHandler(logging.StreamHandler())

            logger.info('info1')
            self.assertTrue(b'info1' in self._buf.getvalue())


# Generated at 2022-06-12 08:01:44.908431
# Unit test for function get_config
def test_get_config():
    config = get_config(default = DEFAULT_CONFIG)
    print(config)

if __name__ == '__main__':
    test_get_config()
    log = get_logger()
    log.info('test')

# Generated at 2022-06-12 08:01:55.146553
# Unit test for function get_config
def test_get_config():
    from pprint import pprint
    from copy import deepcopy
    from json import dumps, loads
    from yaml import load

    cfg = deepcopy(DEFAULT_CONFIG)

    dcfg = dumps(cfg)
    assert isinstance(dcfg, _PyInfo.text_type)

    c0 = get_config()
    assert c0 == cfg

    cfg_json = loads(dcfg)
    assert isinstance(cfg_json, dict)

    c1 = get_config(cfg_json)
    assert c1 == cfg

    c2 = get_config(dcfg)
    assert c2 == cfg

    cfg_yaml = load(dcfg)
    assert isinstance(cfg_yaml, dict)

    c3 = get_config(cfg_yaml)
    assert c3 == cfg

# Generated at 2022-06-12 08:02:02.456303
# Unit test for function logger_level
def test_logger_level():
    """
    >>> log = getLogger('test')
    >>> with logger_level(log, logging.INFO):
    ...     assert log.isEnabledFor(logging.INFO)
    ...     assert not log.isEnabledFor(logging.DEBUG)
    True
    True
    >>> # Test that setting level is reverted at end of the "with" block
    ... assert not log.isEnabledFor(logging.INFO)
    ... assert log.isEnabledFor(logging.DEBUG)
    False
    True
    """
    pass

# Generated at 2022-06-12 08:02:07.777813
# Unit test for function logger_level
def test_logger_level():
    # Make sure the logger is configured
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        try:
            assert logger.level == logging.ERROR
            raise Exception("testing logger_level")
        except Exception:
            exc_info = sys.exc_info()
            logger.error("", exc_info=exc_info)
            assert logger.level == logging.ERROR



# Generated at 2022-06-12 08:02:14.151981
# Unit test for function logger_level
def test_logger_level():
    l = get_logger()
    with logger_level(l, logging.CRITICAL):
        l.info("Should not see this")
        l.fatal("Should see this")


# def context(logger=None, name=None, level=None):
#     """
#     """
#     if logger is None:
#         logger = get_logger(name)

#     def decorator(func):
#         def func_wrapper(*args, **kwargs):
#             with logger_level(logger, level):
#                 return func(*args, **kwargs)

#         return func_wrapper
#     return decorator



# Generated at 2022-06-12 08:02:35.887249
# Unit test for function logger_level
def test_logger_level():
    from logs.log import getLogger
    import logging
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as tmpdirname:
        logpath = os.path.join(tmpdirname, 'log.txt')
        with open(logpath, 'w') as logfile:
            log = getLogger('test')
            log.addHandler(logging.FileHandler(logpath))

            with logger_level(log, logging.CRITICAL):
                log.debug('this should not write to file')
                log.info('this should not write to file')

                log.fatal('this should write to file')

            # Make sure the logger was restored to its original level
            log.debug('this should not write to file again')
            log.info('this should write to file again')


# Generated at 2022-06-12 08:02:41.565519
# Unit test for function logger_level
def test_logger_level():
    # This test is disabled and needs to be fixed
    pass
    # log = getLogger()
    # with logger_level(log, logging.DEBUG):
    #     assert log.level == logging.DEBUG
    #     log.info('test')
    # assert log.level != logging.DEBUG
    # log.debug('test')



# Generated at 2022-06-12 08:02:44.594238
# Unit test for function get_config
def test_get_config():
    assert get_config('{"a": 1}') == {"a": 1}
    assert get_config('{"a": 1}') == {"a": 1}
    assert get_config('a: 1') == {"a": 1}
    assert get_config('[]') == []
    assert get_config('[1]') == [1]

# Generated at 2022-06-12 08:02:47.148142
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
    assert logger.level != logging.WARNING



# Generated at 2022-06-12 08:02:50.339180
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        import time
        logger.debug('test message 1')
        time.sleep(0.5)
        logger.debug('test message 2')

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:02:53.098844
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    with logger_level(log, logging.DEBUG):
        log.info('Test')



# Generated at 2022-06-12 08:02:58.495069
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG, 'Failed to set log level to DEBUG'
        with logger_level(logger, logging.INFO):
            assert logger.level == logging.INFO, 'Failed to set log level to INFO'
        assert logger.level == logging.DEBUG, 'Failed to restore log level to DEBUG'
    assert logger.level != logging.DEBUG, 'Failed to restore log level back to original level'


# Generated at 2022-06-12 08:03:00.630332
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    logger.info('test')



# Generated at 2022-06-12 08:03:05.306778
# Unit test for function logger_level
def test_logger_level():
    lg = getLogger('test_logging_levels')
    lg.setLevel(logging.DEBUG)

    lg.info('just before')
    with logger_level(lg, logging.ERROR):
        lg.debug('skip me')
        lg.info('ignore me')
        lg.warning('ignore me too')
    lg.debug('just after')



# Generated at 2022-06-12 08:03:10.173026
# Unit test for function logger_level
def test_logger_level():

    log = get_logger('logger_level')

    with logger_level(log, logging.WARNING):
        log.error('I should be seen')
        log.warning('I should be seen')
        log.info('I should NOT be seen')

    log.info('I should be seen')

# Generated at 2022-06-12 08:03:55.621233
# Unit test for function configure
def test_configure():
    from StringIO import StringIO
    from colorlog.escape_codes import escape_codes


# Generated at 2022-06-12 08:03:59.125073
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    # ensure we're at logger level debug
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG

    # ensure we're back at root level
    assert log.level == logging.DEBUG


set_logger_level = logger_level  # so we can be like the stdlib

# Generated at 2022-06-12 08:04:04.429982
# Unit test for function get_config
def test_get_config():
    assert get_config(env_var=None, default=None) == None
    assert get_config(env_var='LOGGING', default=None) == None
    assert get_config(env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config=None, env_var=None, default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config="{'version': 1}", env_var=None, default=DEFAULT_CONFIG) == {"version": 1}
    assert get_config(config="version: 1", env_var=None, default=DEFAULT_CONFIG) == {"version": 1}

# Generated at 2022-06-12 08:04:12.393778
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    # Test basic level context management
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG
    # Test nested level context management
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        with logger_level(logger, logging.WARN):
            assert logger.level == logging.WARN
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG
    # Test that exceptions are propogated through context management
    try:
        with logger_level(logger, logging.INFO):
            assert logger.level == logging.INFO
            raise RuntimeError
    except RuntimeError:
        pass
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 08:04:14.931939
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test')
    with logger_level(logger, logging.CRITICAL):
        logger.debug('Not logged')
        logger.critical('Logged')
    logger.debug('Not logged')
    logger.critical('Logged')

# Generated at 2022-06-12 08:04:16.359018
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test')
    with logger_level(log, logging.WARN):
        log.info('test') # No output should occur

# Generated at 2022-06-12 08:04:22.082085
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    log.info("test_logger_level() initial")
    with logger_level(log, logging.DEBUG):
        log.debug("test_logger_level() debug is logged")
        log.info("test_logger_level() info is logged")
    log.info("test_logger_level() info is logged after leaving with block")


DEFAULT_CONFIG_FILENAME = 'logging.cfg'



# Generated at 2022-06-12 08:04:25.974792
# Unit test for function logger_level
def test_logger_level():
    with logger_level(log, logging.ERROR):
        with logger_level(log, logging.DEBUG):
            log.info('test')
            log.error('test')
            log.debug('test')
            assert log.level == logging.DEBUG, 'Logging level not set to DEBUG within context'
        assert log.level == logging.ERROR, 'Logging level not set to ERROR within context'
    assert log.level == logging.DEBUG, 'Logging level not reset to original value'


# Generated at 2022-06-12 08:04:28.813888
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        logger.info('Test function logger_level')
        logger.critical('Test function logger_level')
    logger.info('Test function logger_level')


# Generated at 2022-06-12 08:04:34.036967
# Unit test for function logger_level
def test_logger_level():
    # Set up test logger
    import random
    log_name = random.randrange(1, 100)
    root_logger = logging.getLogger(log_name)
    level_name = logging.getLevelName(root_logger.level)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        "%(name)s - %(levelname)s - %(message)s"
        )
    handler.setFormatter(formatter)
    root_logger.addHandler(handler)

    # Set up logger_level
    logger_level(root_logger, logging.DEBUG)
    root_logger.info('level DEBUG')
    root_logger.warning('level DEBUG')
    root_logger.error('level DEBUG')
