

# Generated at 2022-06-12 07:54:40.132194
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    # configure first
    configure()
    # test if initial level is DEBUG
    assert log.level == logging.DEBUG
    log.debug('test logger_level')
    with logger_level(log, logging.ERROR):
        assert log.level == logging.ERROR
        log.error('test logger_level error')
    assert log.level == logging.DEBUG
    # test if initial level is ERROR
    log.setLevel(logging.ERROR)
    assert log.level == logging.ERROR
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
        log.debug('test logger_level debug')
    assert log.level == logging.ERROR


# Generated at 2022-06-12 07:54:51.567883
# Unit test for function logger_level
def test_logger_level():
    # Make sure we have a clean slate
    configure(None, None, None)
    logger = get_logger(__name__)
    assert logger.isEnabledFor(logging.INFO)
    assert logger.isEnabledFor(logging.DEBUG)
    assert logger.isEnabledFor(logging.ERROR)

    # Use logger_level to set a lower level.
    with logger_level(logger, logging.ERROR):
        assert not logger.isEnabledFor(logging.INFO)
        assert not logger.isEnabledFor(logging.DEBUG)
        assert logger.isEnabledFor(logging.ERROR)
    # Expect logger to be back to initial state
    assert logger.isEnabledFor(logging.INFO)
    assert logger.isEnabledFor(logging.DEBUG)
    assert logger.isEnabledFor(logging.ERROR)


# Generated at 2022-06-12 07:54:57.688979
# Unit test for function logger_level
def test_logger_level():
    from colorlog import ColoredFormatter
    configure()
    logger = logging.getLogger(__name__)

    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = ColoredFormatter('%(log_color)s%(message)s%(reset)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    assert logger.getEffectiveLevel() == 10

    with logger_level(logger, logging.INFO):
        assert logger.getEffectiveLevel() == 20

    assert logger.getEffectiveLevel() == 10

# Generated at 2022-06-12 07:55:05.110188
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)

    # Change level to INFO, and verify in context block
    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')
        logger.exception('exception')
        logger.error('error')
        logger.critical('critical')

    # Verify level restored
    logger.debug('debug')
    logger.info('info')
    logger.exception('exception')
    logger.error('error')
    logger.critical('critical')

    logger.level = logging.DEBUG



# Generated at 2022-06-12 07:55:08.835604
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('Can you see this?')
        logger.warning('Can you see this?')
    logger.debug('Can you see this?')
    logger.warning('Can you see this?')



# Generated at 2022-06-12 07:55:17.789081
# Unit test for function logger_level
def test_logger_level():
    name = 'test_logger_level'
    log = get_logger(name)
    # The default level for all loggers is `WARNING`.
    # Note that all loggers are named using their fully-qualified module name.
    assert log.getEffectiveLevel() == logging.WARNING

    # Set level to `DEBUG` for the duration of the function,
    # then restore the original level.
    with logger_level(log, logging.DEBUG):
        assert log.getEffectiveLevel() == logging.DEBUG
        log.debug('this message should appear')

    # `DEBUG` log messages are suppressed in the outer scope.
    assert log.getEffectiveLevel() == logging.WARNING
    log.debug('this message should be suppressed')



# Generated at 2022-06-12 07:55:20.241753
# Unit test for function logger_level
def test_logger_level():
    """
    >>> log = getLogger()
    >>> with logger_level(log, logging.ERROR):
    ...     log.error('logged')
    ...     log.warn('not logged')
    """
    pass

# Generated at 2022-06-12 07:55:22.855697
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.DEBUG):
        logging.debug("This log line should appear")
    logging.error("This log line should not appear")

# Generated at 2022-06-12 07:55:27.823453
# Unit test for function get_config
def test_get_config():
    config = {'key': 'value'}

    assert get_config(config) == config
    assert get_config("{\"key\": \"value\"}") == config

    # Test that dict is not modified by default
    config_dict = dict(config)
    assert get_config(config_dict) == config_dict
    assert config_dict == config

# Generated at 2022-06-12 07:55:35.297673
# Unit test for function logger_level
def test_logger_level():
    """
    >>> test_logger_level()
    INFO:__main__:test1
    INFO:__main__:test2
    """
    log = getLogger()
    log.setLevel(logging.INFO)
    log.info("test1")
    with logger_level(log, logging.DEBUG):
        log.debug("test2")
    log.info("test3")



# This needs some work.
#
# see also:
#    http://nedbatchelder.com/code/cog/
#    https://gist.github.com/jameysharp/5810807
#    https://github.com/bskinn/bslogging/blob/master/bslogger.py
#
#
# def setup_logging(name=None, stdout=True, debug=

# Generated at 2022-06-12 07:55:45.051773
# Unit test for function logger_level
def test_logger_level():
    """This is a test for logger_level"""
    test_logger = logging.getLogger("test_logger")
    test_logger.setLevel(logging.INFO)
    assert test_logger.getEffectiveLevel() == logging.INFO
    with logger_level(test_logger, logging.DEBUG):
        assert test_logger.getEffectiveLevel() == logging.DEBUG
    assert test_logger.getEffectiveLevel() == logging.INFO

# Generated at 2022-06-12 07:55:54.483868
# Unit test for function logger_level
def test_logger_level():
    import logging

    if sys.version_info[0] == 3:
        return

    # Using the default logging configuration
    test_logger = logging.getLogger('test_logger_level')
    with logger_level(test_logger, logging.INFO):
        assert test_logger.level == logging.INFO
        # Should do nothing here
        test_logger.debug('This message should not show up')

    with logger_level(test_logger, logging.DEBUG):
        assert test_logger.level == logging.DEBUG
        # Should show up
        test_logger.debug('This message should show up')

    # Should return to the original level
    assert test_logger.level == logging.WARNING

# Generated at 2022-06-12 07:56:05.354941
# Unit test for function get_config

# Generated at 2022-06-12 07:56:13.329861
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.getEffectiveLevel() == logging.CRITICAL
    assert logger.getEffectiveLevel() != logging.CRITICAL


# This is an ugly hack.
_CONFIG_VALUE = os.environ.get('LOGGING', None)
if not _CONFIG_VALUE:
    try:
        configure()
    except Exception:
        pass
else:
    configure(config=_CONFIG_VALUE)

# Generated at 2022-06-12 07:56:15.583193
# Unit test for function logger_level
def test_logger_level():
    l = getLogger(__name__)
    print("GetLogger")
    print(l)
    # i.e. not sure if this is working!
    # with logger_level(l, logging.INFO):
    #     l.info('test')

# Generated at 2022-06-12 07:56:19.882439
# Unit test for function get_config
def test_get_config():
    cfg = get_config()
    assert cfg == DEFAULT_CONFIG, 'Test get_config failed'
    default = dict(version=1)
    cfg = get_config(default=default)
    assert cfg == default, 'Test get_config failed'



# Generated at 2022-06-12 07:56:28.438974
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    fd, filename = tempfile.mkstemp(text=True)
    with os.fdopen(fd, "w") as logfile:
        logger = logging.Logger("tlogger")
        handler = logging.StreamHandler(logfile)
        logger.addHandler(handler)
        debug = logger.debug
        info = logger.info
        with logger_level(logger, logging.DEBUG):
            debug("debug connection")
            info("info connection")
        info("info connection")
        debug("debug connection")

    with open(filename, "r") as logfile:
        lines = logfile.readlines()
    if lines != [
        "debug connection\n",
        "info connection\n",
        "info connection\n",
        "debug connection\n"
    ]:
        assert False

# Generated at 2022-06-12 07:56:30.626090
# Unit test for function configure
def test_configure():
    configure()
    configure(config=DEFAULT_CONFIG)
    log = logging.getLogger(__name__)
    log.info('test')


if __name__ == '__main__':
    test_configure()

    # py.test tests/test_logging.py

# Generated at 2022-06-12 07:56:31.861646
# Unit test for function configure
def test_configure():
    configure()
    assert logging.getLogger().isEnabledFor(logging.DEBUG)

# Generated at 2022-06-12 07:56:34.861806
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARN):
        assert logger.level == logging.WARN

    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:56:43.503516
# Unit test for function logger_level
def test_logger_level():
    l = get_logger()
    with logger_level(l, logging.INFO):
        l.debug("I'm on a tricycle.")
        l.info("You're on a bicycle.")
        l.warning("I can ride one.")
        l.error("We're on a collision course.")
    l.critical("You're gonna miss me when I'm gone.")

# Generated at 2022-06-12 07:56:54.594390
# Unit test for function logger_level
def test_logger_level():
    import io
    import os

    from unittest import TestCase

    logger = logging.getLogger(__name__)
    logger.addHandler(logging.FileHandler(os.devnull))
    logger.setLevel(logging.DEBUG)
    sio = io.StringIO()
    ch = logging.StreamHandler(sio)
    logger.addHandler(ch)
    ch.setLevel(logging.DEBUG)

    logger.info("Hello")
    with logger_level(logger, logging.ERROR):
        logger.info("Info message should not show")
        assert "Info message should not show" not in sio.getvalue()
        logger.error("Error message should show")
        assert "Error message should show" in sio.getvalue()

    logger.info("Hello again")

# Generated at 2022-06-12 07:57:06.180779
# Unit test for function configure
def test_configure():
    import tempfile
    import os

    log = logging.getLogger(__name__)

    filename = os.path.abspath('logging.properties')
    if os.path.exists(filename):
        with open(filename) as fh:
            d = fh.read()
    else:
        d = DEFAULT_CONFIG
    with tempfile.NamedTemporaryFile(delete=False, mode='w') as fh:
        fh.write(d)
    try:
        configure(fh.name, default=None)
        log.info('Should configure file %s', fh.name)
    finally:
        os.unlink(fh.name)


# Generated at 2022-06-12 07:57:13.575955
# Unit test for function logger_level
def test_logger_level():
    l = getLogger(__name__)
    l.debug('debug1')
    l.info('info1')
    original_level = l.level
    try:
        with logger_level(l, logging.DEBUG):
            l.debug('debug2')
            l.info('info2')
        assert True
    except Exception:
        assert False
    assert l.level == original_level
    l.debug('debug3')
    l.info('info3')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:57:16.453654
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level_old = logger.getEffectiveLevel()
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
        logger.info("Logging level is DEBUG")
    assert logger.getEffectiveLevel() == level_old

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:57:20.271157
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.CRITICAL):
        log.debug('this debug should not print')
        log.critical('this critical should print')
    log.debug('this debug should print')
    log.critical('this critical should print')


# Generated at 2022-06-12 07:57:26.428999
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.INFO)
        assert not logger.isEnabledFor(logging.DEBUG)
    assert not logger.isEnabledFor(logging.INFO)
    assert logger.isEnabledFor(logging.DEBUG)



# Generated at 2022-06-12 07:57:30.785839
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    log = _logs_file_via_context_manager()
    with open(log) as f:
        assert 'critical' not in f.read()
    with logger_level(get_logger(), logging.CRITICAL):
        get_logger().critical('critical')
    with open(log) as f:
        assert 'critical' in f.read()



# Generated at 2022-06-12 07:57:41.139526
# Unit test for function get_config
def test_get_config():

    # Testing for a json string
    config_json = "{\"version\": 1, \"disable_existing_loggers\": False, \"formatters\":{\"simple\":{\"format\": \"%(asctime)s %(name)s %(levelname)s %(message)s\", \"datefmt\": \"%Y-%m-%d %H:%M:%S\"}}, \"handlers\":{\"console\":{\"class\": \"logging.StreamHandler\", \"formatter\": \"simple\", \"level\": \"DEBUG\"}}, \"loggers\":{\"root\":{\"handlers\": [\"console\"], \"level\": \"DEBUG\", \"propagate\": True}}}\""
    assert isinstance(get_config(config_json), dict)

    # Testing for a yaml string

# Generated at 2022-06-12 07:57:47.558068
# Unit test for function logger_level
def test_logger_level():
    # logging.basicConfig(level=logging.INFO)
    log = get_logger()
    with logger_level(log, logging.INFO):
        log.info("Logger level is now INFO")
        log.debug("Logger level is now INFO")

    assert log.level == logging.NOTSET
    log.info("Back to normal")
    log.debug("Back to normal")


# Unit test get_logger

# Generated at 2022-06-12 07:58:01.566426
# Unit test for function get_config
def test_get_config():
    # Test string given
    conf = '''
    logger:
      level: DEBUG
      format: '%(name)s: %(message)s'
    '''
    config = get_config(config=conf)
    assert config['logger']['level'] == 'DEBUG'
    assert config['logger']['format'] == '%(name)s: %(message)s'

    # Test directory
    dir_ = os.path.join(os.path.dirname(__file__), 'demo_config')
    os.environ['CONFIG_DIR'] = dir_
    config = get_config(env_var='CONFIG_DIR')
    assert config['logger']['level'] == 'DEBUG'

# Generated at 2022-06-12 07:58:12.436018
# Unit test for function get_config

# Generated at 2022-06-12 07:58:15.514896
# Unit test for function configure
def test_configure():
    logger = getLogger()
    with logger_level(logger, logging.WARN):
        logger.debug("this should not be displayed")
        logger.info("this should not be displayed")
        logger.warn("this should be displayed")

# Generated at 2022-06-12 07:58:22.770897
# Unit test for function logger_level
def test_logger_level():
    """Test for the logger_level context manager"""
    import logging
    import sys
    import StringIO
    import re

    # Setting up a fake logger and capture output to test
    logger = logging.getLogger('test')

    # Creating an output stream and setting logging level to debug
    f = StringIO.StringIO()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler(f))

    # Testing if we can set logger level to INFO as expected
    with logger_level(logger, level=logging.INFO):
        logger.debug('test')
        assert re.search(r'\ttest\n', f.getvalue())

    # Cleaning the stream
    f.close()

    # Setting up a fake logger
    logger = logging.getLogger('test')

    # Creating

# Generated at 2022-06-12 07:58:28.308551
# Unit test for function get_config
def test_get_config():
    # Test default value
    assert get_config() == DEFAULT_CONFIG

    # Test when given value is dict
    test_dict = dict(test=True)
    assert get_config(given=test_dict) == test_dict

    # Test when given value is string
    config = "{ 'test_env': True }"
    test_dict = dict(test_env=True)
    assert get_config(given=config) == test_dict


# Test function get_logger

# Generated at 2022-06-12 07:58:39.493979
# Unit test for function get_config
def test_get_config():
    # test_get_config_string_json
    config = '{"foo": {"bar": "baz"}}'
    result = get_config(config)
    assert result == {'foo': {'bar': 'baz'}}

    # test_get_config_string_yaml
    config = 'foo:\n  bar: baz\n'
    result = get_config(config)
    assert result == {'foo': {'bar': 'baz'}}

    # test_get_config_invalid
    config = 'foo:\n  bar: baz\n'
    try:
        result = get_config(config)
    except ValueError:
        assert True

    return True



# Generated at 2022-06-12 07:58:44.095492
# Unit test for function logger_level
def test_logger_level():
    def test_inner():
        logger = logging.getLogger()
        logger.setLevel(logging.DEBUG)
        with logger_level(logger, logging.WARN):
            logger.warn("warning")
            logger.info("info")

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.info("debug info")
    test_inner()
    logger.info("debug info")
    assert (True)  # passed!



# Generated at 2022-06-12 07:58:44.779662
# Unit test for function logger_level
def test_logger_level():
    pass



# Generated at 2022-06-12 07:58:55.171741
# Unit test for function logger_level
def test_logger_level():
    import logging
    from StringIO import StringIO
    import re

    result = StringIO()
    log = logging.Logger(__name__)
    h = logging.StreamHandler(result)
    h.setLevel(logging.DEBUG)

    f = logging.Formatter('%(levelname)s %(message)s')
    h.setFormatter(f)

    log.addHandler(h)

    log.warning('msg_before')
    with logger_level(log, logging.WARNING):
        log.warning('msg_in')
    log.warning('msg_after')

    result_str = result.getvalue()

    assert re.match('^WARNING msg_before\nWARNING msg_in\nWARNING msg_after\n$', result_str)



# vim:sw=4:ts=4:et

# Generated at 2022-06-12 07:58:58.113204
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL

    assert logger.level == logging.DEBUG


# Unit tests for function get_logger

# Generated at 2022-06-12 07:59:14.022813
# Unit test for function logger_level

# Generated at 2022-06-12 07:59:22.733053
# Unit test for function logger_level
def test_logger_level():
    # Ensure we're at the DEBUG level
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # We expect this log message to be raised and captured
    logger.debug("This message should be captured and printed out")

    # Now we'll use logger_level to suppress
    with logger_level(logger,"ERROR"):
        # We expect this log message to not be raised and not be captured
        logger.debug("This message should not be captured and printed out")

    # Now we should be back to our normal DEBUG level,
    # and log the second message again.
    # We expect this log message to be raised and captured
    logger.debug("This message should be captured and printed out")



# Generated at 2022-06-12 07:59:28.406843
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()

    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.error('ERROR')
        logger.warning('WARNING')
        logger.info('INFO')
        logger.debug('DEBUG')
        with logger_level(logger, logging.INFO):
            logger.error('ERROR')
            logger.warning('WARNING')
            logger.info('INFO')
            logger.debug('DEBUG')
    logger.error('ERROR')
    logger.warning('WARNING')
    logger.info('INFO')
    logger.debug('DEBUG')



# Generated at 2022-06-12 07:59:30.556780
# Unit test for function logger_level
def test_logger_level():
    lvl = logging.INFO
    logger = get_logger()
    with logger_level(logger, lvl):
        assert logger.level == lvl



# Generated at 2022-06-12 07:59:40.800622
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.DEBUG):
        log.debug('This should print.')
        log.info('This should print.')
        log.warning('This should print.')

    log.debug('This will not print.')
    log.info('This will not print.')
    log.warning('This will not print.')


DEFAULT_FORMAT = "[%(asctime)s] [%(name)s] [%(process)d] %(message)s @%(funcName)s:%(lineno)d #%(levelname)s"
DEFAULT_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
DEFAULT_NAME = _namespace_from_calling_context()



# Generated at 2022-06-12 07:59:44.993941
# Unit test for function logger_level
def test_logger_level():
    """

    >>> log = get_logger(__name__)
    >>> with logger_level(log, logging.CRITICAL):
    ...    log.debug('test')
    ...    log.info('test')
    ...    log.warning('test')
    """

__test__ = {"test_logger_level": test_logger_level}



# Generated at 2022-06-12 07:59:54.529072
# Unit test for function logger_level
def test_logger_level():
    import datetime
    from StringIO import StringIO

    test_logger = logging.getLogger('test')
    handler = logging.StreamHandler(StringIO())
    test_logger.addHandler(handler)

    with logger_level(test_logger, logging.INFO):
        test_logger.critical("critical")
        test_logger.error("error")
        test_logger.warning("warning")
        test_logger.info("info")
        test_logger.debug("debug")

    with logger_level(test_logger, logging.DEBUG):
        test_logger.critical("critical")
        test_logger.error("error")
        test_logger.warning("warning")
        test_logger.info("info")
        test_logger.debug("debug")

    assert "critical"

# Generated at 2022-06-12 08:00:00.652321
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')

    with logger_level(log, logging.DEBUG):
        log.debug('test')

    try:
        with logger_level(log, logging.CRITICAL):
            log.debug('test')
    except AssertionError:
        pass

    log.info('done')

if __name__ == '__main__':
    test_logger_level()



# Generated at 2022-06-12 08:00:09.803402
# Unit test for function get_config
def test_get_config():
    class LoggingConfig(object):
        pass
    log_obj = LoggingConfig()
    log_obj.version = 1
    log_obj.disable_existing_loggers = False
    log_obj.formatters = {}
    log_obj.handlers = {}
    log_obj.root = {}
    log_obj.loggers = {}
    assert get_config(log_obj) == log_obj
    assert get_config(log_obj) != log_obj
    assert get_config({'version': 1}) == {'version': 1}

    assert get_config("""
        {
            "version": 1
        }
    """) == {"version": 1}

# Generated at 2022-06-12 08:00:15.262397
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')

if __name__ == '__main__':
    # configure()
    # get_logger('test').debug('test')
    # print(get_config(os.environ.get('LOGGING')))
    test_logger_level()

# Generated at 2022-06-12 08:00:26.798439
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test_logger_level')
    with logger_level(log, logging.INFO):
        assert log.isEnabledFor(logging.INFO)
        assert not log.isEnabledFor(logging.DEBUG)

    assert not log.isEnabledFor(logging.INFO)
    assert log.isEnabledFor(logging.DEBUG)

if __name__ == "__main__":
    configure()
    # test_logger_level()
    log = get_logger()
    import colorlog

    log.info("test")

# Generated at 2022-06-12 08:00:35.256810
# Unit test for function get_config
def test_get_config():
    configs = [
        # ({}, None, None, None),
        # ({}, 'BLAH', None, None),
        # ({}, 'BLAH', {}, None),
        ({}, 'BLAH', {'level': logging.DEBUG}, {'level': logging.DEBUG}),
        # ({}, 'BLAH', {'BLAH': 1}, None),
        ({'level': logging.DEBUG}, 'BLAH', {'level': logging.DEBUG}, {'level': logging.DEBUG}),
        # ({'BLAH': 1}, 'BLAH', {'level': logging.DEBUG}, None),
    ]

    for given, env_var, default, expected in configs:
        assert get_config(given=given, env_var=env_var, default=default) == expected


if __name__ == '__main__':
    sys

# Generated at 2022-06-12 08:00:41.663959
# Unit test for function logger_level
def test_logger_level():
    """ Tests logger_level function. """
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.INFO)
        assert not logger.isEnabledFor(logging.DEBUG)
        assert logger.isEnabledFor(logging.WARNING)
        assert logger.isEnabledFor(logging.ERROR)
        assert logger.isEnabledFor(logging.CRITICAL)

    assert logger.isEnabledFor(logging.DEBUG)
    assert logger.isEnabledFor(logging.INFO)
    assert logger.isEnabledFor(logging.WARNING)
    assert logger.isEnabledFor(logging.ERROR)
    assert logger.isEnabledFor(logging.CRITICAL)

if __name__ == '__main__':
    test

# Generated at 2022-06-12 08:00:43.898110
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger')
    with logger_level(logger, logging.ERROR):
        logger.info('Info')
        logger.error('Error')

# Generated at 2022-06-12 08:00:47.136367
# Unit test for function logger_level
def test_logger_level():
    getLogger().setLevel(logging.DEBUG)

    with logger_level(getLogger(), logging.WARN):
        getLogger().info("This message should not appear.")
    getLogger().info("This message should appear.")

# test_logger_level()

# Generated at 2022-06-12 08:00:51.031684
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    logger.debug('This should not be output')
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should be output')

    logger.debug('This should not be output')

# Generated at 2022-06-12 08:00:55.157335
# Unit test for function logger_level
def test_logger_level():
    """Use pytest.raises to test `logger_level` context manager."""
    import pytest
    log = get_logger()
    with logger_level(log, logging.CRITICAL):
        with pytest.raises(AssertionError):
            log.debug('This should not be shown')
    # Check that the initial logger level goes back to normal
    log.debug('This should be shown')

# Generated at 2022-06-12 08:00:57.954271
# Unit test for function configure
def test_configure():
    # logging.basicConfig(format='%(asctime)s| %(message)s', level=logging.DEBUG)
    configure()
    logging.info('test_configure')



# Generated at 2022-06-12 08:01:02.162729
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    configure()

    with logger_level(logger, logging.DEBUG):
        logger.debug("Test debug")
        logger.info("Test info")
        logger.error("Test error")

    with logger_level(logger, logging.INFO):
        logger.debug("Test debug")
        logger.info("Test info")

# Generated at 2022-06-12 08:01:04.252023
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 08:01:20.148432
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config='null', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(config={}, default=DEFAULT_CONFIG) == {}
    assert get_config(config='{"foo":"bar"}', default=DEFAULT_CONFIG) == {'foo': 'bar'}
    assert get_config(config='foo: bar', default=DEFAULT_CONFIG) == {'foo': 'bar'}


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:01:25.613648
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.WARNING)

    logger.info('This message is not displayed')
    logger.warning('This message is displayed')

    with logger_level(logger, logging.ERROR):
        logger.debug('This message is not displayed')
        logger.info('This message is not displayed')
        logger.warning('This message is not displayed')
        logger.error('This message is displayed')

    logger.debug('This message is not displayed')
    logger.info('This message is not displayed')
    logger.warning('This message is displayed')
    logger.error('This message is displayed')

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:01:33.857938
# Unit test for function get_config
def test_get_config():
    """
    >>> from pprint import pprint
    >>> cfg = get_config(given="""

# Generated at 2022-06-12 08:01:39.553776
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = get_logger()
    >>> with logger_level(logger, logging.WARN):
    ...     logger.debug("this is a debug log")
    ...     logger.warn("this is a warning log")
    >>> with logger_level(logger, logging.INFO):
    ...     logger.debug("this is a debug log")
    ...     logger.info("this is an info log")
    ...     logger.warn("this is a warning log")
    """
    pass

# Generated at 2022-06-12 08:01:47.675072
# Unit test for function logger_level
def test_logger_level():
    import sys
    import io

    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = io.StringIO()
            return self

        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio  # free up some memory
            sys.stdout = self._stdout

    import logging

    with Capturing() as output:
        log = logging.getLogger('test_logger_level')
        with logger_level(log, logging.DEBUG):
            log.debug('first debug line')
            log.info('first info line')
            with logger_level(log, logging.INFO):
                log.debug('second debug line')
                log

# Generated at 2022-06-12 08:01:54.383221
# Unit test for function logger_level
def test_logger_level():
    import logging
    l = logging.getLogger(__name__ + '.test_logger_level')
    with logger_level(l, logging.FATAL):
        assert l.level == logging.FATAL
    assert l.level == logging.NOTSET
    l.setLevel(logging.DEBUG)
    assert l.level == logging.DEBUG
    with logger_level(l, logging.INFO):
        assert l.level == logging.INFO
    assert l.level == logging.DEBUG

# Generated at 2022-06-12 08:02:00.200506
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('This should debug')
    log.debug('This should not debug')
    with logger_level(log, logging.INFO):
        log.debug('This should not debug')
        log.info('This should info')
        log.warn('This should warn')



# Generated at 2022-06-12 08:02:05.260396
# Unit test for function logger_level
def test_logger_level():
    from .constants import DEBUG

    log = getLogger('test_logger_level')

    with logger_level(log, DEBUG):
        log.debug('test')
        
    log.info('test') # this should not be printed


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG, format='%(levelname)s %(message)s')
    logging.debug('test')

# Generated at 2022-06-12 08:02:10.755186
# Unit test for function get_config
def test_get_config():
    assert get_config() is None
    assert get_config(None) is None
    assert get_config({}) == {}
    assert get_config('{}') == {}
    assert get_config('{"x": "y"}') == {"x": "y"}
    assert get_config('{"x": "y}')["x"] == "y}"
    assert get_config('x: y') == {"x": "y"}


# Generated at 2022-06-12 08:02:13.164146
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.DEBUG



# Generated at 2022-06-12 08:02:27.405206
# Unit test for function logger_level
def test_logger_level():
    print('Testing logger_level')
    from contextlib import contextmanager
    from logging import Logger, DEBUG

    logger = Logger(__name__)
    initial_level = logger.level

    @contextmanager
    def __assert(logger, level):
        logger.debug('Debugging')
        logger.info('Infoing')
        logger.warning('Warning')
        logger.error('ERROR')

    with logger_level(logger, DEBUG):
        __assert(logger, DEBUG)


if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:02:31.437176
# Unit test for function get_config
def test_get_config():
    config = {'a': 1}

    assert get_config(config) == config
    assert get_config(str(config)) == config
    assert get_config(json.dumps(config)) == config
    assert get_config(yaml.dump(config)) == config

    with pytest.raises(ValueError):
        get_config(123)

# Generated at 2022-06-12 08:02:33.679198
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG

# Trace logging utility

# Generated at 2022-06-12 08:02:35.693769
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.debug('test')

# Generated at 2022-06-12 08:02:45.035755
# Unit test for function configure
def test_configure():
    import logging
    import io
    import sys
    import json

    log_io = io.StringIO()
    log_handler = logging.StreamHandler(stream=log_io)
    log = logging.getLogger('test_configure')
    log.addHandler(log_handler)
    log.info('1')
    log.info('2')
    log.info('3')

# Generated at 2022-06-12 08:02:52.079825
# Unit test for function configure
def test_configure():
    """
    >>> log = get_logger()
    >>> log.info('test')
    >>> dir(log)
    >>> log.debug('test')
    >>> log.info('test2')
    >>> log = get_logger('test2')
    >>> log.info('test2')
    """
    log = get_logger()
    log.info('test')
    dir(log)
    log.debug('test')
    log.info('test2')
    log = get_logger('test2')
    log.info('test2')


if __name__ == '__main__':
    import doctest

    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-12 08:02:55.613342
# Unit test for function logger_level
def test_logger_level():
    import mock
    logger = get_logger()
    logger.setLevel(logging.INFO)
    assert logger.getEffectiveLevel() == logging.INFO

    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG

    assert logger.getEffectiveLevel() == logging.INFO

# Generated at 2022-06-12 08:03:04.250488
# Unit test for function logger_level
def test_logger_level():
    def _test_logger_level(logger, level):
        with logger_level(logger, level):
            assert logger.level == level

    logger = get_logger()
    _test_logger_level(logger, 10)
    _test_logger_level(logger, logging.CRITICAL)
    _test_logger_level(logger, logging.ERROR)
    _test_logger_level(logger, logging.WARNING)
    _test_logger_level(logger, logging.INFO)
    _test_logger_level(logger, logging.DEBUG)
    _test_logger_level(logger, logging.NOTSET)
    assert logger.level == logging.DEBUG


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:03:14.410560
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import os
    import tempfile

    # Todo: Note that this is not being executed (pytest is run with --capture=no)
    # Todo: We need to find a better way to test context managers
    l = logging.getLogger(__name__)
    level = l.getEffectiveLevel()
    with tempfile.TemporaryFile() as out:
        with logger_level(l, logging.DEBUG):
            assert l.level == logging.DEBUG
            l.debug('test')
            assert l.getEffectiveLevel() == logging.DEBUG
        assert l.level == level
        assert l.getEffectiveLevel() == level

    # b/c this is being called from the command line we have to re-open stdout
    # in order for it to be a proper file object at that point.
   

# Generated at 2022-06-12 08:03:22.054213
# Unit test for function get_config

# Generated at 2022-06-12 08:03:39.002471
# Unit test for function get_config
def test_get_config():
    config = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    assert config['loggers']['requests']['level'] == 20
    assert config['version'] == 1
    assert config['root']['level'] == 10

# Generated at 2022-06-12 08:03:44.612217
# Unit test for function logger_level
def test_logger_level():
    import io
    from logging import StreamHandler, LogRecord, DEBUG

    # Setup a logger and a stream to store the output from the logger
    logger = logging.getLogger(__name__)
    stream = io.StringIO()

    # The base logger level should be DEBUG. If an INFO log message is received,
    # it should be printed
    logger.setLevel(DEBUG)
    handler = StreamHandler(stream)
    logger.addHandler(handler)
    with logger_level(logger, logging.INFO):
        logger.debug('Bar')
        assert 'Bar' in stream.getvalue()
    assert 'Bar' not in stream.getvalue()

    handler.close()
    stream.close()


# Generated at 2022-06-12 08:03:54.495059
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    # Need to reset the logger level to avoid unintended test failure on TravisCI
    # See: https://travis-ci.org/sfloess/silk/jobs/85174007
    logger.setLevel(logging.INFO)

    with logger_level(logger, logging.DEBUG):
        assert not logger.isEnabledFor(logging.INFO)
        assert logger.isEnabledFor(logging.DEBUG)

    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.INFO)
        assert not logger.isEnabledFor(logging.DEBUG)

    with logger_level(logger, logging.WARNING):
        assert not logger.isEnabledFor(logging.INFO)
        assert not logger.isEnabledFor(logging.DEBUG)

# Generated at 2022-06-12 08:03:57.825401
# Unit test for function logger_level
def test_logger_level():
    root = logging.getLogger('')
    initial = root.level

    assert root.level == initial
    try:
        with logger_level(root, logging.DEBUG):
            assert root.level == logging.DEBUG
        assert root.level == initial
    except:
        root.level = initial
        raise



# Generated at 2022-06-12 08:04:00.696791
# Unit test for function logger_level
def test_logger_level():
    from six import StringIO
    level = 'DEBUG'
    stream = StringIO()
    logger = logging.getLogger(__name__)
    handler = logging.StreamHandler(stream)
    logger.addHandler(handler)
    with logger_level(logger, level):
        logger.debug("debug message")
        assert level in stream.getvalue(), "Could not find %s in %s" % (level, stream.getvalue())


# Generated at 2022-06-12 08:04:06.939314
# Unit test for function logger_level
def test_logger_level():
    import unittest

    class LoggerLevelTest(unittest.TestCase):
        def test_logger_level(self):
            from tests import log

            class Filter(logging.Filter):
                def filter(self, record):
                    return record.levelno != logging.WARNING

            log.addFilter(Filter())
            with logger_level(log, logging.WARNING):
                log.info('this should not be logged')
                log.warning('this should be logged')
                log.debug('this should not be logged')

    unittest.main()



# Generated at 2022-06-12 08:04:12.455332
# Unit test for function logger_level
def test_logger_level():
    import sys
    import mock
    import logging

    def get_logger_level(logger):
        return logger.level

    with mock.patch.object(sys, 'stderr', sys.stdout):
        logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert get_logger_level(logger) == logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert get_logger_level(logger) == logging.DEBUG
    assert get_logger_level(logger) == logging.DEBUG

# Generated at 2022-06-12 08:04:15.511459
# Unit test for function logger_level
def test_logger_level():
    # Get a logger
    log = getLogger(__name__)

    # Set the logger level to debug
    with logger_level(log, logging.DEBUG):
        # Log a message
        log.debug('Hello!')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:04:16.537363
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, DEFAULT_CONFIG) == DEFAULT_CONFIG

# Generated at 2022-06-12 08:04:20.391010
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug("Should not be seen")
        logger.info("Should be seen")
    logger.info("Should be seen")

