

# Generated at 2022-06-12 07:54:36.016341
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')
        log.critical('critical')
    try:
        log.debug('debug')
    except Exception as e:
        assert isinstance(e, AttributeError), 'Should have triggered AttributeError'
    log.info('info')

# Generated at 2022-06-12 07:54:43.283339
# Unit test for function get_config
def test_get_config():
    test_config = {'a': 1, 'b': 2}
    cfg = get_config(test_config)
    assert cfg == test_config

    test_string = '{"a": 1, "b": 2}'
    cfg = get_config(test_string)
    assert cfg == test_config

    test_string = '{a: 1, b: 2}'
    cfg = get_config(test_string)
    assert cfg == test_config

    test_string = 'a: 1\nb: 2\n'
    cfg = get_config(test_string)
    assert cfg == test_config

if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-12 07:54:53.723040
# Unit test for function logger_level
def test_logger_level():
    # log = get_logger()
    # print(log.level)
    # print(log.info('test: log.info'))
    # print(log.debug('test: log.debug'))
    # print(log.warning('test: log.warning'))
    # print(log.error('test: log.error'))
    # console handler is a StreamHandler, it uses sys.stderr
    # builtin logging module
    logger = logging.getLogger()
    # Formatter:
    # fmt = '%(asctime)s %(name)s %(levelname)s %(message)s'
    # logging.basicConfig(level=logging.INFO, format=fmt)
    logging.basicConfig(level=logging.INFO)
    # logger.setLevel(logging.DEBUG)

# Generated at 2022-06-12 07:54:57.661538
# Unit test for function logger_level
def test_logger_level():
    """
    >>> import logging
    >>> log = logging.getLogger(__name__)
    >>> log.setLevel(logging.INFO)
    >>> logging.basicConfig()
    >>> log.info('A message')
    >>> with logger_level(log, logging.DEBUG):
    ...     log.info('A message')
    A message
    >>> log.debug('Another message')
    >>>
    """


# Generated at 2022-06-12 07:55:02.745319
# Unit test for function logger_level
def test_logger_level():
    configure()
    _logger = getLogger('test')
    with logger_level(_logger, logging.ERROR):
        _logger.debug('this debug statement should not print')
        _logger.error('this error statement should print')
    # _logger should be reset to original level, so the following debug statement should print
    _logger.debug('this debug statement should print')

# Generated at 2022-06-12 07:55:10.472086
# Unit test for function logger_level
def test_logger_level():
    import logging
    import time
    import queue
    import threading
    from .log.api import getLogger

    logger = getLogger()
    logger.setLevel(logging.DEBUG)
    q = queue.Queue()
    def put_it_out():
        while True:
            msg = q.get()
            logger.debug(msg)

    t = threading.Thread(target=put_it_out)
    t.daemon = True
    t.start()

    with logger_level(logger, logging.INFO):
        q.put("hello world!")

    time.sleep(2)

    q.put("hello world!")

    time.sleep(2)


# NOTE: The code below needs to be reworked.  In particular, the
#       specialized _namespace_from_calling_context()

# Generated at 2022-06-12 07:55:14.397413
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    logexceptions = get_logger('exceptions')
    with logger_level(log, logging.DEBUG):
        log.debug('logger_level test')
        try:
            raise Exception
        except Exception as e:
            logexceptions.exception(e)

# Generated at 2022-06-12 07:55:19.598752
# Unit test for function logger_level
def test_logger_level():
    import StringIO
    import logging

    stream = StringIO.StringIO()
    logger = logging.getLogger('ltest')
    logger.setLevel(logging.CRITICAL)
    logger.addHandler(logging.StreamHandler(stream))

    logger.info('foo')
    assert stream.getvalue().strip() == ''

    with logger_level(logger, logging.INFO):
        logger.info('foo')
        assert stream.getvalue().strip() == 'foo'

    logger.info('bar')
    assert stream.getvalue().strip() == 'foo'

# Generated at 2022-06-12 07:55:22.135969
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.debug('test2')

# Generated at 2022-06-12 07:55:27.463231
# Unit test for function logger_level
def test_logger_level():
    """Test logger_level()"""
    try:
        logger = logging.getLogger(__name__)
        with logger_level(logger, logging.INFO):
            logger.debug('This should not be printed')
            logger.info('This should be printed')
    except Exception as e:
        print(e)
        assert False, "Failed to set logger level within context"



# Generated at 2022-06-12 07:55:39.571188
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)

    # Before the context block, the level is INFO
    assert(logger.level == logging.INFO)

    # Set the level to DEBUG in the context block
    with logger_level(logger, logging.DEBUG):
        # In the block the level is DEBUG
        assert(logger.level == logging.DEBUG)

    # After the block the level is INFO again
    assert(logger.level == logging.INFO)

    # Test setting a non-integer level
    with logger_level(logger, "WARNING"):
        # In the block the level is WARNING
        assert(logger.level == logging.WARNING)



# Generated at 2022-06-12 07:55:49.181355
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    log.debug("Test debug")
    log.info("Test info")
    log.warning("Test warning")
    log.error("Test error")
    log.critical("Test critical")

    with logger_level(log, 30):
        log.debug("Test debug")
        log.info("Test info")
        log.warning("Test warning")
        log.error("Test error")
        log.critical("Test critical")

    log.debug("Test debug")
    log.info("Test info")
    log.warning("Test warning")
    log.error("Test error")
    log.critical("Test critical")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:55:57.669140
# Unit test for function logger_level
def test_logger_level():
    logging.getLogger(__name__).info("A Info")
    logging.getLogger(__name__).debug("B Debug")
    logging.getLogger(__name__).critical("C Critical")
    logging.getLogger(__name__).error("D Error")
    logging.getLogger(__name__).warning("E Warning")

    with logger_level(logging.getLogger(__name__), logging.DEBUG):
        logging.getLogger(__name__).info("F Info")
        logging.getLogger(__name__).debug("G Debug")
        logging.getLogger(__name__).critical("H Critical")
        logging.getLogger(__name__).error("I Error")
        logging.getLogger(__name__).warning("J Warning")

# Generated at 2022-06-12 07:56:02.931706
# Unit test for function logger_level
def test_logger_level():
    import os
    import logging
    import sys

    logger = logging.getLogger(__name__)
    level = logging.DEBUG

    with logger_level(logger, level):
        assert logger.isEnabledFor(level)

    assert not logger.isEnabledFor(level)


# Generated at 2022-06-12 07:56:14.097792
# Unit test for function get_config
def test_get_config():
    config = get_config(default = {'env_var': 'test'})
    assert config == {'env_var': 'test'}

    config = get_config('{"env_var": "test"}')
    assert config == {'env_var': 'test'}

    config = get_config(env_var='test')
    assert config == {'env_var': 'test'}

    config = get_config('{"env_var": "test"}', env_var='test')
    assert config == {'env_var': 'test'}

    config = get_config(config = {'env_var': 'test'}, env_var='test')
    assert config == {'env_var': 'test'}


# Generated at 2022-06-12 07:56:19.700904
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.Logger, logging.DEBUG):
        logging.info('unit test')
    assert logging.getLogger().level == logging.NOTSET


if __name__ == '__main__':
    configure()
    logging.info('test')

    log = logging.getLogger(__name__)
    log.debug('another test')

# Generated at 2022-06-12 07:56:21.207370
# Unit test for function configure
def test_configure():
    log = get_logger(__name__)
    log.info('test')

# Generated at 2022-06-12 07:56:24.532638
# Unit test for function logger_level
def test_logger_level():
    import mock
    logger = mock.MagicMock()
    with logger_level(logger, logging.DEBUG):
        pass
    assert logger.level == logging.INFO


# Annotate a funciton with the level at which it should be logged at.

# Generated at 2022-06-12 07:56:29.067546
# Unit test for function logger_level
def test_logger_level():
    # First, need to configure so that the logs can be captured
    configure()
    forget_logger_level = getLogger('test_logger_level.forget_logger_level')
    with logger_level(forget_logger_level, logging.WARN):
        forget_logger_level.debug('I should be hidden')
        forget_logger_level.warn('I should be shown')
    forget_logger_level.debug('Now I should be shown')


# Generated at 2022-06-12 07:56:39.068843
# Unit test for function get_config
def test_get_config():
    import json
    import yaml


# Generated at 2022-06-12 07:56:47.700734
# Unit test for function logger_level
def test_logger_level():

    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

from unittest.mock import patch
from contextlib import contextmanager
from logging import StreamHandler
from io import StringIO



# Generated at 2022-06-12 07:56:51.044187
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARNING):
        assert(logger.level == logging.WARNING)
    assert(logger.level != logging.WARNING)


# Generated at 2022-06-12 07:56:57.815161
# Unit test for function get_config
def test_get_config():

    import json

    def assert_config(given, expected, env_var=None, default=None):
        config = get_config(given, env_var, default)
        assert config == expected, (config, expected)

    assert_config(None, {}, None, {'foo': 'bar'})
    assert_config({'foo': 'bar'}, {'foo': 'bar'}, None, {'foo': 'baz'})
    assert_config(None, {'foo': 'baz'}, None, {'foo': 'baz'})
    assert_config(json.dumps({'foo': 'bar'}), {'foo': 'bar'},
                  None, {'foo': 'baz'})



# Generated at 2022-06-12 07:57:08.874805
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    import os

    # testing `given`

# Generated at 2022-06-12 07:57:11.794889
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG



# Generated at 2022-06-12 07:57:17.954257
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.ERROR):
        assert logging.getLogger().isEnabledFor(logging.ERROR)
        assert not logging.getLogger().isEnabledFor(logging.INFO)
        assert not logging.getLogger().isEnabledFor(logging.WARN)
        assert not logging.getLogger().isEnabledFor(logging.DEBUG)
    assert logging.getLogger().isEnabledFor(logging.DEBUG)
    assert logging.getLogger().isEnabledFor(logging.INFO)
    assert logging.getLogger().isEnabledFor(logging.WARN)
    assert not logging.getLogger().isEnabledFor(logging.ERROR)

# Generated at 2022-06-12 07:57:25.154696
# Unit test for function get_config
def test_get_config():
    assert get_config(default={}) == {}
    assert get_config(config={}) == {}
    assert get_config(config={'a': 1}) == {'a': 1}

    # test json
    raw = '{"a": 1}'
    assert get_config(config=raw) == {"a": 1}

    # test yaml
    raw = 'a: 1'
    assert get_config(config=raw) == {"a": 1}
    return True

# Generated at 2022-06-12 07:57:29.220844
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    logger.setLevel(100)

    with logger_level(logger, logging.INFO):
        logger.info("Foo")

    with logger_level(logger, logging.DEBUG):
        logger.debug("Foo")

# Generated at 2022-06-12 07:57:40.288392
# Unit test for function get_config

# Generated at 2022-06-12 07:57:46.499900
# Unit test for function logger_level
def test_logger_level():
    """Test logger_level
    >>> log = logger_level(getLogger(__name__), logging.WARNING)
    >>> with log:
    ...     test_logger_level()
    >>> log
    <test.test2.test_logger_level.<locals>.<contextlib._GeneratorContextManager object at 0x10f9fc828>>
    """
    pass



# Generated at 2022-06-12 07:57:58.116897
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.CRITICAL):
        logger.debug('this should not show')
        logger.info('this should not show')
        logger.warning('this should not show')
        logger.error('this should not show')
        logger.critical('this should show')
        logger.log(50, 'this should not show')
        logger.log(40, 'this should not show')
        logger.log(30, 'this should not show')
        logger.log(20, 'this should not show')
        logger.log(10, 'this should not show')

# Generated at 2022-06-12 07:58:03.534241
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    with logger_level(log, logging.INFO):
        log.debug('this should not print, because our level is INFO')
        log.info('this should print')
    log.debug('this should print')
    log.info('this should also print')


__all__ = ["get_logger", "getLogger",
           "configure", "get_config",
           "logger_level"]

# Generated at 2022-06-12 07:58:14.173236
# Unit test for function get_config
def test_get_config():
    def assert_config(given, expected):
        config = get_config(given, default=expected)
        if config != expected:
            raise ValueError(
                "config {0} != {1} (expected)".format(config, expected))
    assert_config(
        '{"version": 1, "disable_existing_loggers": false}',
        {"version": 1, "disable_existing_loggers": False})
    assert_config(
        '''
        version: 1
        disable_existing_loggers: false
        ''',
        {"version": 1, "disable_existing_loggers": False})
    assert_config(
        {"version": 1, "disable_existing_loggers": False},
        {"version": 1, "disable_existing_loggers": False})



# Generated at 2022-06-12 07:58:22.100901
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('test_logger_level')
    # Set up log with max level
    configure(
        {"loggers": {"test_logger_level": {"level": logging.ERROR}}}
    )
    assert logger.isEnabledFor(logging.DEBUG) is False
    assert logger.isEnabledFor(logging.INFO) is False
    assert logger.isEnabledFor(logging.WARNING) is True
    assert logger.isEnabledFor(logging.ERROR) is True
    # Set level to INFO
    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.DEBUG) is False
        assert logger.isEnabledFor(logging.INFO) is True
        assert logger.isEnabledFor(logging.WARNING) is True

# Generated at 2022-06-12 07:58:31.358055
# Unit test for function logger_level
def test_logger_level():
    import threading

    l = get_logger('test_logger_level')
    l.setLevel(logging.INFO)

    with logger_level(l, logging.CRITICAL):
        assert l.level == logging.CRITICAL
        l.info('info')

    assert l.level == logging.INFO
    with logger_level(l, logging.DEBUG):
        with logger_level(l, logging.CRITICAL):
            assert l.level == logging.CRITICAL
        assert l.level == logging.DEBUG
    assert l.level == logging.INFO

    # check that logger level restores across threads. this test can be flaky. :/
    # TODO: try to write a threading.local-based logger_level function that doesn't have this problem.

# Generated at 2022-06-12 07:58:42.054091
# Unit test for function get_config
def test_get_config():
    assert get_config() == None
    assert get_config('') == None
    assert get_config(dict()) == None
    assert get_config('{"a": 1}') == {'a': 1}
    assert get_config(json.dumps({'a': 2})) == {'a': 2}
    assert get_config(yaml.dump({'a': 3})) == {'a': 3}
    assert get_config(str(DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert get_config(json.dumps({'a': 2}), env_var='LOGGING', default=DEFAULT_CONFIG) == {'a': 2}

# Generated at 2022-06-12 07:58:51.295810
# Unit test for function logger_level
def test_logger_level():
    logger1 = getLogger()
    assert logger1.level == 10

    with logger_level(logger1, logging.ERROR):
        assert logger1.level == 40

    assert logger1.level == 10

    logger2 = getLogger(__name__)
    assert logger2.level == 10

    with logger_level(logger2, logging.WARNING):
        assert logger2.level == 30

    assert logger2.level == 10


# Sanity check for main calls
if __name__ == "__main__":
    logger = getLogger(__name__)
    logger.info("Sanity check")
    test_logger_level()

# Generated at 2022-06-12 07:58:52.505125
# Unit test for function logger_level
def test_logger_level():
    logger_level(getLogger(), logging.INFO)

# Generated at 2022-06-12 07:58:59.977959
# Unit test for function configure
def test_configure():
    from io import StringIO
    import sys


# Generated at 2022-06-12 07:59:07.651557
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)

    # Emulate a setup.py install which runs at DEBUG.
    with logger_level(log, logging.DEBUG):
        log.debug("Running at DEBUG")

    # Have the log return to normal.
    log.info("Returned to INFO")

    with logger_level(log, logging.INFO):
        log.info("Still at INFO")

    # Have the log return to normal.
    log.info("Returned to INFO")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:59:15.285809
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    log.info('Before')
    with logger_level(log, logging.WARNING):
        log.warning('During')
    log.info('After')



# Generated at 2022-06-12 07:59:20.286820
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)

    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.DEBUG):
        # no exception, good
        pass

    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        logger.debug('test')

    assert logger.level == logging.DEB

# Generated at 2022-06-12 07:59:27.165558
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    from logging import CRITICAL, FATAL, ERROR, WARNING, WARN, INFO, DEBUG
    logger = get_logger()
    def test_level(level):
        @contextmanager
        def set_level():
            with logger_level(logger, level):
                logger.info("Inside context at level %s" % level)
        logger.info("Outside of context at level %s" % logger.level)
        set_level()
        logger.info("Outside of context at level %s" % logger.level)

    for level in (CRITICAL, FATAL, ERROR, WARNING, WARN, INFO, DEBUG):
        test_level(level)



# Generated at 2022-06-12 07:59:36.796112
# Unit test for function get_config
def test_get_config():
    get_config(
        {'version': 1, 'disable_existing_loggers': False},
        '',
        {'version': 1, 'disable_existing_loggers': False})

    get_config(
        "{\"version\": 1, \"disable_existing_loggers\": false}",
        '',
        {'version': 1, 'disable_existing_loggers': False})

    get_config(
        "version: 1\ndisable_existing_loggers: false",
        '',
        {'version': 1, 'disable_existing_loggers': False})

    get_config(
        "    version: 1\n    disable_existing_loggers: false",
        '',
        {'version': 1, 'disable_existing_loggers': False})

    with pytest.raises(ValueError):
        get

# Generated at 2022-06-12 07:59:41.183292
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')

    logger.debug('debug message')
    logger.info('info message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:59:45.882812
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    logger.info("test logger_level")
    with logger_level(logger, logging.ERROR):
        logger.info("logger.info")
        logger.error("logger.error")
    logger.info("logger.info")
    logger.error("logger.error")

if __name__ == "__main__":
    configure()
    test_logger_level()

# Generated at 2022-06-12 07:59:50.098284
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    configure()

    logger.info('test')
    with logger_level(logger, logging.DEBUG):
        logger.info('test')
    logger.info('test')

# Generated at 2022-06-12 07:59:56.043115
# Unit test for function logger_level

# Generated at 2022-06-12 08:00:00.601072
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    expected = logging.DEBUG
    with logger_level(logger, expected):
        assert logger.level == expected
    # This should be true at the end too
    assert logger.level == expected

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:00:04.757409
# Unit test for function logger_level
def test_logger_level():
    # test logger_level
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('foo')

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:00:20.952260
# Unit test for function get_config
def test_get_config():
    from collections import namedtuple
    from io import StringIO

    DictLike = namedtuple('dictlike', 'get')

    class DictLikeObj(DictLike):
        def __init__(self, value):
            super(DictLikeObj, self).__init__(get=lambda *args: value)

    simple_yaml_string = """
    version: 1
    disable_existing_loggers: False
    """

    assert get_config(DictLikeObj(default=DEFAULT_CONFIG)) == DEFAULT_CONFIG
    assert get_config(DictLikeObj(default=simple_yaml_string)) == DEFAULT_CONFIG
    assert get_config(DictLikeObj(default=simple_yaml_string), default=simple_yaml_string) == DEFAULT_CONFIG
    assert get_config

# Generated at 2022-06-12 08:00:28.545643
# Unit test for function logger_level
def test_logger_level():
    # Setup
    logger = getLogger(__name__)

    # Test 1: Normal usage
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET

    # Test 2: Test with exception
    try:
        with logger_level(logger, logging.DEBUG):
            assert logger.level == logging.DEBUG
            raise Exception("Oops")
    except:
        pass
    assert logger.level == logging.NOTSET

    return


# A convenience method for logging a message only when the logger level is
# DEBUG.
#
# If a logger is passed in, it is used for logging. If no logger is passed
# in, one is retrieved by calling getLogger().

# Generated at 2022-06-12 08:00:31.587441
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__+".test_logger_level")
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        logger.debug("SHOULD NOT BE SHOWN")
        logger.info("SHOULD BE SHOWN")

# Generated at 2022-06-12 08:00:35.827270
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with open('temp.log', 'w') as f:
        with logger_level(logger, logging.INFO):
            logger.info('logging info')
        with logger_level(logger, logging.DEBUG):
            logger.debug('logging debug')
    logger.info('end of test')


# Generated at 2022-06-12 08:00:37.706028
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.warning('Won\'t be logged')
        logger.info('Will be logged')

    logger = get_logger()
    logger.info('Will be logged')
    logger.warning('Will be too')

# Generated at 2022-06-12 08:00:40.201320
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
        logger.info("should not be logged")

    assert logger.level != logging.ERROR
    logger.info("should be logged")

# Generated at 2022-06-12 08:00:43.641301
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test')
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 08:00:50.340574
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')

    # Test INFO level
    with logger_level(logger, logging.INFO):
        logger.info('test_1')
        logger.warning('test_2')
        logger.error('test_3')
    logger.info('test_4')

    # Test WARNING level
    with logger_level(logger, logging.WARNING):
        logger.info('test_1')
        logger.warning('test_2')
        logger.error('test_3')
    logger.info('test_4')



# Generated at 2022-06-12 08:00:53.146116
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.level = logging.DEBUG

    # Shouldn't get message
    logger.debug('bad')

    with logger_level(logger, logging.DEBUG):
        logger.debug('good')



# Generated at 2022-06-12 08:01:01.777226
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import datetime
    import os
    import logging

    # Setup test logging
    logger = logging.getLogger('test_logger')
    logger.setLevel(logging.INFO)

    fh = logging.FileHandler(os.path.join(tempfile.tempdir, datetime.datetime.now().strftime('%Y%m%d%H%M%S') + '.log'))
    fh.setLevel(logging.INFO)

    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)

    logger.addHandler(fh)

    # Test the logger_level context manager

# Generated at 2022-06-12 08:01:17.208250
# Unit test for function logger_level
def test_logger_level():
    import unittest

    log = get_logger()

    class TestLoggerLevel(unittest.TestCase):

        def test_logger_level(self):
            with logger_level(log, logging.WARNING):
                self.assertEqual(log.getEffectiveLevel(), logging.WARNING)
                log.warning('this message should be logged')
                log.debug('this message should NOT be logged')
            self.assertNotEqual(log.getEffectiveLevel(), logging.WARNING)

    unittest.main()


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:01:21.403188
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)

    with logger_level(log, logging.CRITICAL):
        assert log.level == logging.CRITICAL
    assert log.level == logging.DEBUG

if __name__ == "__main__":
    test_logger_level();

# Generated at 2022-06-12 08:01:24.940724
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('foo')
    logger.setLevel(logging.WARNING)
    # simple log before changing the level
    logger.debug('Should not appear')
    # change the level temporarly with 'with'
    with logger_level(logger, logging.DEBUG):
        logger.debug( "Should appear")
        logger.info( "Should appear")
    # simple log after the 'with' block
    logger.debug( "Should not appear")

# Generated at 2022-06-12 08:01:28.240267
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug("Debug")
        log.info("Info")
        log.warning("Warning")
        log.error("Error")
        log.critical("Critical")
    log.info("Done")

# Generated at 2022-06-12 08:01:32.989421
# Unit test for function logger_level
def test_logger_level():
    logger1 = get_logger()
    logger1.setLevel(logging.INFO)
    assert logger1.level == logging.INFO
    with logger_level(logger1, logging.DEBUG):
        assert logger1.level == logging.DEBUG
    assert logger1.level == logging.INFO

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:01:42.666513
# Unit test for function get_config

# Generated at 2022-06-12 08:01:45.573859
# Unit test for function logger_level
def test_logger_level():
    """
    >>> import logging
    >>> log = logging.getLogger(__name__)
    >>> configure()
    >>> with logger_level(log, logging.DEBUG):
    ...   log.debug('cheese')

    """

# Generated at 2022-06-12 08:01:55.715959
# Unit test for function get_config
def test_get_config():
    # test for invalid input
    try:
        get_config()
    except ValueError:
        pass
    else:
        assert False, "Invalid logging config accepted"

    # test for none
    try:
        get_config(None)
    except ValueError:
        pass
    else:
        assert False, "Invalid logging config accepted"

    # test for json
    cfg_dict = {'a': 1}
    cfg_json = json.dumps(cfg_dict)
    cfg_string = "'%s'" % cfg_json
    for cfg in [cfg_dict, cfg_json, cfg_string]:
        assert cfg_dict == get_config(cfg), "Invalid logging config parsed from json"

    # test for yaml

# Generated at 2022-06-12 08:02:05.745852
# Unit test for function get_config

# Generated at 2022-06-12 08:02:06.480281
# Unit test for function logger_level
def test_logger_level():
    logger_level()

# Generated at 2022-06-12 08:02:27.615083
# Unit test for function logger_level
def test_logger_level():
	import unittest
	logger = logging.getLogger(__name__)
	class Test(unittest.TestCase):
		def test_logger_level(self):
			with logger_level(logger, logging.WARNING):
				with self.assertRaises(LoggerError):
					logger.debug("debug message")
				with self.assertRaises(LoggerError):
					logger.info("info message")
				logger.warning("warning message")


# Generated at 2022-06-12 08:02:34.132130
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger("test.logger_level")
    with logger_level(log, logging.ERROR):
        log.debug("This is debug message")
        log.info("This is info message")
        log.warning("This is warning message")
        log.error("This is error message")
        log.critical("This is critical message")
    log.debug("This is debug message")
    log.info("This is info message")
    log.warning("This is warning message")
    log.error("This is error message")
    log.critical("This is critical message")


# Generated at 2022-06-12 08:02:42.035162
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    # ensure logger level is set to warning
    # logger = logging.getLogger()
    previous = logger.getEffectiveLevel()
    logger.setLevel(logging.WARNING)

    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

    # ensure logger level is restored to previous value
    logger.setLevel(previous)

# Generated at 2022-06-12 08:02:47.261167
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger()
    try:
        with logger_level(test_logger, logging.DEBUG):
            assert test_logger.level == logging.DEBUG
    except AssertionError:
        print("test_logger_level failed")
        print("test_logger.level = " + str(test_logger.level))
        print("logging.DEBUG = " + str(logging.DEBUG))

# if __name__ == '__main__':
#     test_logger_level()

# Generated at 2022-06-12 08:02:55.473683
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG
    assert get_config(default={"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert get_config(config={"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert get_config(config={"a": 1, "b": 2}, env_var="aaaa") == {"a": 1, "b": 2}
    assert get_config(config=json.dumps({"a": 3, "b": 4})) == {"a": 3, "b": 4}
    assert get_config(config=json.dumps({"a": 5, "b": 6}), env_var="aaaa") == {"a": 5, "b": 6}



# Generated at 2022-06-12 08:02:59.620244
# Unit test for function logger_level
def test_logger_level():
    configure()
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.isEnabledFor(logging.DEBUG)
        with logger_level(log, logging.INFO):
            assert log.isEnabledFor(logging.INFO)  # INFO is dominant
        assert log.isEnabledFor(logging.DEBUG)
    assert log.level == logging.DEBUG

# Generated at 2022-06-12 08:03:02.935662
# Unit test for function logger_level
def test_logger_level():
    """
    >>> log = get_logger('test_logger_level')
    >>> with logger_level(log, logging.DEBUG):
    ...     log.debug('debug message')
    ...
    """



# Generated at 2022-06-12 08:03:07.795955
# Unit test for function logger_level
def test_logger_level():
    import time

    class FakeLoggingHandler:
        def emit(self, record):
            pass

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    handler = FakeLoggingHandler()
    logger.addHandler(handler)


    def fake_sleep(delay):
        time.sleep(delay)

    with logger_level(logger, logging.DEBUG):
        logger.info('Start real sleep')
        fake_sleep(1)
        logger.info('Done real sleep')
        logger.debug('Start fake sleep')
        fake_sleep(1)
        logger.debug('Done fake sleep')



# Generated at 2022-06-12 08:03:13.329196
# Unit test for function logger_level
def test_logger_level():
    t = get_logger(__name__ + ".test_logger_level")
    t.setLevel(logging.DEBUG)

    with logger_level(t, logging.WARNING):
        t.debug("This log message shouldn't be displayed")
        t.warning("This log message should be displayed")

    t.debug("This log message should be displayed, too")

# Generated at 2022-06-12 08:03:20.905309
# Unit test for function logger_level
def test_logger_level():
    from unittest import TestCase, mock
    from io import StringIO

    class Case(TestCase):
        def setUp(self):
            self.log = mock.Mock()
        def tearDown(self):
            pass

        def test_set_logger_level(self):
            with logger_level(self.log, logging.DEBUG):
                self.log.debug('foo')
                self.assertEqual(self.log.debug.call_count, 1)
            self.log.debug('foo')
            self.assertEqual(self.log.debug.call_count, 1)


# Generated at 2022-06-12 08:03:53.697581
# Unit test for function logger_level
def test_logger_level():
    """
    >>> log = get_logger('test_logger_level')
    >>> with logger_level(log, logging.DEBUG):
    ...     log.debug('I should see this, but not the info')
    ...     log.info('I should not see this')
    """



# Generated at 2022-06-12 08:03:57.677138
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    assert(get_config(config='{"version" : 1}') == json.loads('{"version" : 1}'))
    assert(get_config(config='version: 1') == yaml.load('version: 1'))

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:04:01.515394
# Unit test for function logger_level
def test_logger_level():
    import time
    import logging

    log = logging.getLogger(__file__)
    log.setLevel(logging.DEBUG)
    logging.basicConfig(level=logging.DEBUG)

    log.info("outside the block")
    with logger_level(log, logging.ERROR):
        log.info("in the block")
    log.info("back outside")
    time.sleep(0.1)

# Generated at 2022-06-12 08:04:07.242646
# Unit test for function logger_level
def test_logger_level():
    # Enforce basicConfig
    _CONFIGURED[:] = []
    log = get_logger()
    log.setLevel(logging.DEBUG)
    log.info("This is a test.")
    with logger_level(log, logging.CRITICAL):
        log.critical("This is a CRITICAL test.")
        log.info("This should not be shown here.")
        log.warn("This should not be shown here.")
    log.warn("This is a WARNING test.")
    log.info("This is a test.")



# Generated at 2022-06-12 08:04:11.575200
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    log.setLevel(logging.INFO)
    try:
        with logger_level(log, logging.DEBUG):
            log.debug('before')
            log.info('in ctxt')
            log.debug('after')
        log.debug('after ctxt')
    except Exception:
        import traceback
        traceback.print_exc()
    log.debug('after try')

# Generated at 2022-06-12 08:04:15.485630
# Unit test for function logger_level
def test_logger_level():
    out_str = StringIO()
    log = logging.getLogger(__name__)
    log.addHandler(logging.StreamHandler(out_str))
    log.setLevel(logging.INFO)
    with logger_level(log, logging.DEBUG):
        log.debug("hello there")
    result = out_str.getvalue()
    assert result == "hello there\n"



# Generated at 2022-06-12 08:04:23.605769
# Unit test for function logger_level
def test_logger_level():
    # Test that we can use aliases for logging levels
    log = logging.getLogger('test.logger_level')
    with logger_level(log, 'DEBUG'):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')

    # Test that we can also use numeric levels
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warning('warning')
        log.error('error')


# Monkeypatch the stdlib logging module
logging.get_logger = get_logger
logging.getLogger = get_logger
logging.get_config = get_config
logging.configure = configure