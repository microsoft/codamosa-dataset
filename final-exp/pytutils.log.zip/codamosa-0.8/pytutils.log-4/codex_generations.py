

# Generated at 2022-06-12 07:54:35.650728
# Unit test for function get_config
def test_get_config():
    config = get_config(default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config(config={'hello': 'world'})
    assert config == {'hello': 'world'}

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:54:38.932485
# Unit test for function logger_level
def test_logger_level():
    from logging import CRITICAL, DEBUG
    logger = get_logger('logger_level test')
    logger.setLevel(CRITICAL)
    with logger_level(logger, DEBUG):
        logger.debug('logger level should be DEBUG')

# Generated at 2022-06-12 07:54:40.460624
# Unit test for function logger_level
def test_logger_level():
    x = logger_level(get_logger(), 5)
    assert x is not None

# Generated at 2022-06-12 07:54:51.884924
# Unit test for function logger_level
def test_logger_level():
    # Not py3k compat
    # logger = logging.getLogger(inspect.currentframe().f_code.co_name)
    # TODO Does this work in both py2/3?
    logger = logging.getLogger(inspect.stack()[0][0].f_code.co_name)

    # Case: set logger level to warning and check
    logger.setLevel(logging.DEBUG)
    assert logger.isEnabledFor(logging.DEBUG)
    assert not logger.isEnabledFor(logging.INFO)
    assert not logger.isEnabledFor(logging.WARNING)
    assert not logger.isEnabledFor(logging.ERROR)
    assert not logger.isEnabledFor(logging.CRITICAL)


# Generated at 2022-06-12 07:54:54.250726
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.CRITICAL):
        logger.debug('This shouldn\'t appear')



# Generated at 2022-06-12 07:54:57.393988
# Unit test for function configure
def test_configure():
    logger = logging.getLogger(__name__)
    configure()
    logger.info('test')



# Generated at 2022-06-12 07:55:00.980921
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    assert log.level == logging.DEBUG

    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO

    assert log.level == logging.DEBUG



# Generated at 2022-06-12 07:55:09.570452
# Unit test for function logger_level
def test_logger_level():
    import logging
    import colorlog
    import test_logging
    logger = colorlog.getLogger()

    logger.setLevel(logging.DEBUG)
    test_logging._setup_logger()


    logger.debug('This should be printed.')
    with logger_level(logger, logging.ERROR):
        logger.debug('This should not be printed.')

    logger.debug('This should be printed.')

    # Test get_config for json, yaml and bare logging config

# Generated at 2022-06-12 07:55:17.298360
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = get_logger(__name__)
    logger.setLevel(logging.DEBUG)

    # NOTE: Without the output of the first line, it appears that the second line does not execute.
    #       This is why the first line is here.
    logger.debug("Testing the logger_level function...")

    with logger_level(logger, logging.INFO):
        logger.debug("This debug line should NOT be logged!")
        logger.info("This info line should be logged!")

    logger.debug("This debug line should be logged!")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:55:27.359206
# Unit test for function logger_level
def test_logger_level():
    import logging
    import pprint
    import sys
    import tempfile
    import unittest

    class Test(object):
        def __init__(self):
            self.logger = get_logger(__name__)

        def get_logger(self):
            return self.logger

        def foo(self):
            self.logger.info("foo")
            self.logger.debug("bar")

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.logger = get_logger(__name__)

        def test_logger_level(self):
            with tempfile.TemporaryFile(mode='w+t') as f:
                with logger_level(self.logger, logging.DEBUG):
                    test.foo()

# Generated at 2022-06-12 07:55:34.175588
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('This is a test message at DEBUG level')
    log.info('This is a test message at default level')



# Generated at 2022-06-12 07:55:44.047664
# Unit test for function configure
def test_configure():
    import tempfile

# Generated at 2022-06-12 07:55:54.617733
# Unit test for function logger_level
def test_logger_level():
    import logging
    import os


# Generated at 2022-06-12 07:55:58.288836
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    configure()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:56:03.958454
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger("test_logger_level")
    print("Checking logger_level function:")
    with logger_level(log, logging.INFO):
        log.debug("Logging debug message")
        log.info("Logging info message")
    log.debug("Logging debug message")
    log.info("Logging info message")

test_logger_level()

# Generated at 2022-06-12 07:56:11.716411
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('Debug Message')
        logger.info('Info Message')
        logger.warning('Warning Message')
        logger.error('Error Message')
        logger.critical('Critical Message')
    logger.info('Test Completed')

if __name__ == '__main__':
    logger = get_logger(__name__)
    logger.info('Begin testing')
    test_logger_level()

# Generated at 2022-06-12 07:56:14.493421
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)

    with logger_level(logger, logging.DEBUG):
        logger.debug('%s', 'logger test')

    logger.info('%s', 'logger test')


# Generated at 2022-06-12 07:56:19.296625
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert log.level == logging.DEBUG

    # Turn off logging, check that the log actually doesn't log anything.
    with logger_level(log, logging.CRITICAL):
        log.warning('Shouldn\'t log this')

    log.info('OK')

# Generated at 2022-06-12 07:56:22.863055
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    def test_func():
        logger.warn('hi')

    with logger_level(logger, logging.ERROR):
        test_func()

    logger.error('hi')

# Generated at 2022-06-12 07:56:25.659782
# Unit test for function logger_level
def test_logger_level():
    # Logging is not configured yet
    logger = getLogger()
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET


# Generated at 2022-06-12 07:56:39.321946
# Unit test for function logger_level
def test_logger_level():
    import logging
    l1 = logging.getLogger("test_logger")
    l1.setLevel(logging.INFO)  # Only show INFO messages
    l2 = logging.getLogger("test_logger.test2")
    l2.setLevel(logging.WARN)  # Only show WARN messages
    # We want to keep the level for l1 as INFO and for l2 as WARN.
    # The next statement should not change our desired values.
    with logger_level(l1, logging.WARN):
        assert l1.level == logging.WARN
        assert l2.level == logging.WARN
    assert l1.level == logging.INFO
    assert l2.level == logging.WARN
    # We want to keep the level for l1 as INFO and for l2 as WARN.
    # The next statement should change the level

# Generated at 2022-06-12 07:56:46.167050
# Unit test for function logger_level
def test_logger_level():
    from pytest import raises

    log = get_logger('boggle')
    configure()

    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
        with raises(AttributeError):
            log.debug('logging.DEBUG is not set')

        log.info('logging.INFO is set')

    assert log.level == logging.INFO
    with raises(AttributeError):
        log.info('logging.INFO is not set')

    log.debug('logging.DEBUG is set')



# Generated at 2022-06-12 07:56:50.910145
# Unit test for function logger_level
def test_logger_level():
    # logger = getLogger(__name__)
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.INFO):
        logger.info("Info message")
        logger.debug("Debug message")
    logger.debug("Debug message")

# Generated at 2022-06-12 07:56:57.011596
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = logging.getLogger('test_logger')
    >>> logger.handlers = []
    >>> handler = logging.StreamHandler()
    >>> logger.addHandler(handler)
    >>> logger.setLevel(logging.INFO)
    >>> logger.info('info')
    >>> with logger_level(logger, logging.DEBUG):
    ...     logger.info('debug')
    >>> logger.info('info')
    INFO:test_logger:info
    INFO:test_logger:debug
    INFO:test_logger:info
    """
    pass


import unittest


# Generated at 2022-06-12 07:57:07.927588
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager

    @contextmanager
    def with_logging_configured(config):
        configure(config)
        yield



# Generated at 2022-06-12 07:57:16.669640
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import os

    LOG_FILENAME = tempfile.mktemp(prefix='tmp_log_level')
    h = logging.FileHandler(LOG_FILENAME)
    formatter = logging.Formatter('%(levelname)s')
    h.setFormatter(formatter)
    logger = logging.getLogger('kafka')
    logger.addHandler(h)
    logger.setLevel(logging.DEBUG)

    with logger_level(logger, logging.INFO):
        #Within the context we expect a INFO message, outside the context we expect it to be DEBUG
        logger.info("Test in context")

    logger.debug("Test outside context")

    with open(LOG_FILENAME, 'r') as fp:
        log_contents = fp.read()


# Generated at 2022-06-12 07:57:27.824637
# Unit test for function get_config
def test_get_config():
    config = {'version': 1}
    assert get_config(config) == config
    assert get_config(json.dumps(config)) == config
    assert get_config(yaml.dump(config)) == config
    assert get_config(None, env_var='', default=config) == config
    assert get_config({}) == {}
    assert get_config(json.dumps({})) == {}
    assert get_config(yaml.dump({})) == {}
    assert get_config(None, env_var='', default={}) == {}
    assert get_config(0) == 0
    assert get_config(1) == 1
    assert get_config(None, env_var='', default=0) == 0
    assert get_config(None, env_var='', default=1) == 1
    assert get

# Generated at 2022-06-12 07:57:31.122527
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    
    with logger_level(logger, logging.DEBUG):
        logger.debug('This should print')
        logger.info('and this too')

    logger.debug('But this should not print')

if '--unittest' in sys.argv:
    test_logger_level()

# Generated at 2022-06-12 07:57:41.170461
# Unit test for function configure

# Generated at 2022-06-12 07:57:45.935121
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('DEBUG')
    log.info('INFO')
    with logger_level(log, logging.DEBUG):
        log.info('INFO')
        log.debug('DEBUG')

# Generated at 2022-06-12 07:58:04.109023
# Unit test for function get_config
def test_get_config():
    assert get_config(env_var=None) == DEFAULT_CONFIG
    assert get_config(env_var=None, default=None) == DEFAULT_CONFIG
    assert get_config(env_var=None, default=None, given='{"foo":1}') == { "foo": 1 }

    assert get_config(env_var=None, default=None, given='{"foo":1}') == { "foo": 1 }
    assert get_config(env_var=None, default=None, given='{"foo":2}') == { "foo": 2 }

    os.environ['LOGGING'] = '{"bar":1}'
    assert get_config(env_var='LOGGING') == { "bar": 1 }
    del os.environ['LOGGING']


# Generated at 2022-06-12 07:58:07.405786
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    with logger_level(logger, 30):
        assert logger.level == 30
    assert logger.level != 30



# Generated at 2022-06-12 07:58:13.894264
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.INFO):
        log.debug("Debug message")
        log.info("Info message")
        with logger_level(log, logging.DEBUG):
            log.debug("Debug message")
            log.info("Info message")
        log.debug("Debug message")
        log.info("Info message")
    log.debug("Debug message")
    log.info("Info message")



# Generated at 2022-06-12 07:58:19.182089
# Unit test for function get_config
def test_get_config():
    default_config = {'handlers': {'console': {'class': 'logging.StreamHandler', 'level': 'INFO', 'formatter': 'simple', 'stream': 'ext://sys.stderr'}}, 'formatters': {'simple': {'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'}}}
    assert get_config(default=default_config) == default_config

# Generated at 2022-06-12 07:58:21.973188
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.ERROR):
        log.error('testing error')
        log.info('testing info')
    log.error('testing error')
    log.info('testing info')

# Generated at 2022-06-12 07:58:24.422261
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test')
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:58:31.030207
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    assert logger.level == logging.NOTSET

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        with logger_level(logger, logging.INFO):
            assert logger.level == logging.INFO
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET

# Generated at 2022-06-12 07:58:41.822243
# Unit test for function logger_level
def test_logger_level():
    from contextlib import redirect_stdout
    from io import StringIO
    import logging
    import re

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    # Throw away any stderr messages produced by this test
    with StringIO() as buf:
        with redirect_stdout(buf):
            with logger_level(log, logging.INFO):
                log.debug('This will not be printed')
                log.info('This will be printed')
                log.warning('This will be printed')

    output = buf.getvalue().strip()
    assert re.match(r'.*INFO\:\ This will be printed', output)
    assert re.match(r'.*WARNING\:\ This will be printed', output)

# Generated at 2022-06-12 07:58:49.776154
# Unit test for function logger_level
def test_logger_level():
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.addHandler(logging.StreamHandler())
    test_logger = logging.getLogger('test')
    test_logger.setLevel(logging.INFO)
    with logger_level(test_logger, logging.DEBUG):
        test_logger.debug('debug')
    test_logger.debug('debug')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:58:52.868869
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARN):
        logger.info('This should not be logged')
    logger.info('This should be logged')


# Generated at 2022-06-12 07:59:21.529006
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('test_logger_level')

    assert logger.getEffectiveLevel() == logging.NOTSET
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.getEffectiveLevel() == logging.NOTSET

    logger.setLevel(logging.INFO)
    assert logger.getEffectiveLevel() == logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.getEffectiveLevel() == logging.INFO

    logger.debug('test debug')
    logger.info('test info')


# Run unit tests
if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:59:24.668217
# Unit test for function logger_level
def test_logger_level():
    l = get_logger(__name__)
    with logger_level(l, logging.INFO):
        l.info("log message")
        l.debug("log message")

    with logger_level(l, logging.DEBUG):
        l.debug("log message")


# Generated at 2022-06-12 07:59:33.639679
# Unit test for function logger_level

# Generated at 2022-06-12 07:59:42.161787
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    from io import StringIO
    import traceback

    # Setup logging
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)
    #log.addHandler(logging.StreamHandler(sys.stdout))

    # Get logger
    log.debug('test_logger_level: Begin test')

    # Test that messages are not logged at level INFO
    log.info('test_logger_level: Info message should not appear')
    with logger_level(log, logging.INFO):
        log.info('test_logger_level: Info message should appear')
    log.info('test_logger_level: Info message should not appear')

    # Test that tracebacks are not logged at level INFO

# Generated at 2022-06-12 07:59:45.881923
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    LOG = logger
    with logger_level(logger, logging.WARNING):
        LOG.debug("Hello, World!")
        LOG.info("You won't see this message")
        LOG.warning("But you will see this one!")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:59:51.146104
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.info('hi')
        logger.debug('debug is not printed')
    logger.info('hi again')
    logger.debug('debug')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:59:54.698603
# Unit test for function logger_level
def test_logger_level():
    # The logger_level function is supposed to change the level of the logger
    # logging.basicConfig()
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.WARNING)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.info('test')
    assert logger.level == logging.WARNING



# Generated at 2022-06-12 08:00:05.979624
# Unit test for function logger_level
def test_logger_level():
    import sys
    import warnings

    # If user has already set up log configuration
    # then we can't do this because we don't want output
    # from other code to pollute our output.
    #
    # So we test for this. If a logger has been set up,
    # and it has a root handler, then we bail.
    #
    # Trying to set the logger level on a handler that's
    # been previously configured has no effect, so this
    # test would fail.
    #
    # Note that if the user have set up a logger but not
    # configured it then we probably want our test to
    # ensure that the logger_level function doesn't pollute
    # their logger, so we still want to run this test.
    #
    # If some other part of the program is using logging,
    # and that code is using

# Generated at 2022-06-12 08:00:13.028027
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    configure()
    logger.setLevel(logging.NOTSET)
    print("\nlogger level: NOTSET")
    logger.debug("debug test")
    logger.info("info test")
    logger.warning("warning test")
    logger.error("error test")
    logger.critical("critical test")
    with logger_level(logger, logging.DEBUG):
        print("\nlogger level: DEBUG")
        logger.debug("debug test")
        logger.info("info test")
        logger.warning("warning test")
        logger.error("error test")
        logger.critical("critical test")
    print("\nlogger return to NOTSET")
    logger.debug("debug test")
    logger.info("info test")
    logger.warning("warning test")

# Generated at 2022-06-12 08:00:24.688773
# Unit test for function logger_level
def test_logger_level():
    import tempfile

    log = get_logger()

    with tempfile.NamedTemporaryFile() as f:
        file_name = f.name
        log.debug('Test')

        handler = logging.FileHandler(file_name)
        log.addHandler(handler)

        with logger_level(log, logging.DEBUG):
            log.debug('Test')

        with open(file_name, 'r') as log_file:
            log_contents = log_file.read()

        assert 'Test' in log_contents, 'DEBUG must be in log file'

        log.removeHandler(handler)

        with logger_level(log, logging.INFO):
            log.debug('Test')

        with open(file_name, 'r') as log_file:
            log_contents = log_file.read()



# Generated at 2022-06-12 08:01:22.429999
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    from .compat import StringIO

    @contextmanager
    def capture_stdout(logger):
        _stdout = sys.stdout
        sys.stdout = StringIO()
        try:
            yield
        finally:
            sys.stdout.seek(0)
            value = sys.stdout.read()
            sys.stdout.close()
            sys.stdout = _stdout
            logger._log(logging.INFO, value, (), {})

    with capture_stdout(get_logger()) as l:
        l.info('something goes here')
        assert False, 'logger_level failed'


# Generated at 2022-06-12 08:01:31.472036
# Unit test for function logger_level
def test_logger_level():

    # Create a logger to suppress all messages
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.CRITICAL)

    # Configure
    configure()

    # The logger should currently be at CRITICAL level
    assert logger.getEffectiveLevel() == logging.CRITICAL

    # Test the logger_level contextmanager
    with logger_level(logger, logging.DEBUG):
        # The logger should be at DEBUG level inside the context block
        assert logger.getEffectiveLevel() == logging.DEBUG
        logger.debug("This is a debug statement")

    # The logger should be back to CRITICAL level after the context block
    assert logger.getEffectiveLevel() == logging.CRITICAL

# Generated at 2022-06-12 08:01:39.591802
# Unit test for function get_config
def test_get_config():
    cfg1 = dict(handlers={'hand1': {'class':'hand1_class'}}, loggers={'logger1': {'handlers':['hand1']}})
    cfg2 = "{\"handlers\":{\"hand1\":{\"class\":\"hand1_class\"}},\"loggers\":{\"logger1\": {\"handlers\":[\"hand1\"]}}}"
    cfg3 = "handlers:\n  hand1:\n    class: hand1_class\nloggers:\n  logger1:\n    handlers:\n      - hand1"

    for cfg in (cfg1, cfg2, cfg3):
        assert cfg == get_config(cfg)


# Generated at 2022-06-12 08:01:47.726046
# Unit test for function get_config
def test_get_config():
    given = {'test': 'value'}
    try:
        get_config(given)
    except ValueError:
        assert False, 'Should not fail when given a valid config'

    config = get_config()
    assert isinstance(config, dict), 'Should return default config'

    env_var = 'LOGGING'
    os.environ[env_var] = '{"env_test": "value"}'
    config = get_config(env_var=env_var)
    assert config['env_test'] == 'value', 'Should return config from env var'
    os.environ[env_var] = 'env_test: value'
    config = get_config(env_var=env_var)
    assert config['env_test'] == 'value', 'Should return config from env var'


# Unit test

# Generated at 2022-06-12 08:01:50.910773
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.DEBUG):
        get_logger().warn('logger_level unit test')
    get_logger().warn('logger_level unit test')

# Generated at 2022-06-12 08:01:57.245276
# Unit test for function logger_level
def test_logger_level():
    LOGGER = get_logger(__name__)
    with logger_level(LOGGER, logging.DEBUG):
        LOGGER.debug("In DEBUG context")
    with logger_level(LOGGER, logging.INFO):
        LOGGER.info("In INFO context")
    with logger_level(LOGGER, logging.WARNING):
        LOGGER.warning("In WARNING context")
    with logger_level(LOGGER, logging.ERROR):
        LOGGER.error("In ERROR context")
    with logger_level(LOGGER, logging.CRITICAL):
        LOGGER.critical("In CRITICAL context")

test_logger_level()

# Generated at 2022-06-12 08:02:07.379045
# Unit test for function configure
def test_configure():
    import logging
    from logging import handlers
    import re

    def test_namespace():
        """Tests that the config creates a logger for __name__"""
        configure()
        log = logging.getLogger(__name__)
        assert log.handlers
        assert any([isinstance(x, logging.StreamHandler) for x in log.handlers])

    def test_json():
        """Test configuring with a json string"""
        cfg = '{"version": 1}'
        configure(cfg)
        assert logging.getLogger(__name__).handlers

    def test_config_with_handlers():
        """
        Test configuring with a config object (dict)
        """
        import json

        cfg = json.loads('{"version": 1}')
        configure(cfg)
        assert logging.getLogger

# Generated at 2022-06-12 08:02:13.845164
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        logger.debug("This message is not logged")
        logger.warning("This message is not logged")
        logger.error("This message is logged")

    with logger_level(logger, logging.INFO):
        logger.debug("This message is not logged")
        logger.info("This message is logged")
        logger.error("This message is logged")

    with logger_level(logger, logging.DEBUG):
        logger.debug("This message is logged")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:02:22.730110
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger(__name__)
    # Configure logger

# Generated at 2022-06-12 08:02:32.517652
# Unit test for function logger_level
def test_logger_level():
    """
    >>> test_logger_level()
    """
    logger = getLogger()
    logger.setLevel(logging.INFO)
    logger.info("this is info")
    logger.debug("this is debug")

    with logger_level(logger, logging.DEBUG):
        logger.info("this is info")
        logger.debug("this is debug")
    logger.info("this is info")
    logger.debug("this is debug")


if __name__ == '__main__':
    if "--test" in sys.argv:
        import doctest

        doctest.testmod()
    else:
        configure()
        logger = get_logger(name=__name__)
        logger.info('test')
        logger.warn('test')

# Generated at 2022-06-12 08:03:28.085545
# Unit test for function logger_level
def test_logger_level():
    logging.getLogger(__name__).setLevel(logging.DEBUG)
    log = logging.getLogger(__name__)
    with logger_level(log, logging.ERROR):
        log.info("info")
        log.error("error")
    log.info("info")
    log.error("error")


__all__ = [
    'configure',
    'get_config',
    'get_logger',
    'getLogger',
]


if __name__ == '__main__':
    logging.basicConfig()
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:03:34.886022
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
        log.debug('this is a debug log')
    assert log.level == logging.DEBUG
    log.debug('this is also a debug log')


if __name__ == "__main__":
    configure()
    logging.info('test')

    logging.root.setLevel(logging.DEBUG)
    logging.debug('debug test')
    logging.info('test')

    logging.getLogger('test').debug('test debug test')

# Generated at 2022-06-12 08:03:38.936045
# Unit test for function logger_level
def test_logger_level():
    """
    >>> log = get_logger()
    >>> with logger_level(log, logging.WARN):
    ...     log.warn('You should see this')
    ...     log.debug('You should not see this')
    You should see this
    >>> log.debug('You should see this')
    You should see this
    """

# Generated at 2022-06-12 08:03:44.075860
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.CRITICAL):
        assert log.level == logging.CRITICAL
        log.warning('This should not be visible')
    assert log.level == logging.DEBUG
    assert log.getEffectiveLevel() == logging.DEBUG


# Abstraction to allow a context-based logger.
#
# def foo(a, b):
#   with log.info('foo is running'):
#      return a+b
#
# would result in:
#
# 2013-04-01 00:00:00|foo is running: returning 3


# Generated at 2022-06-12 08:03:53.985288
# Unit test for function configure

# Generated at 2022-06-12 08:03:58.318500
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('testing.logger_level')
    with logger_level(log, logging.ERROR):
        log.debug('Should fail')
        log.error('Should succeed')
        log.info('Should fail')
        log.warning('Should fail')

if __name__ == "__main__":
    get_logger().info('hello')
    test_logger_level()

# Generated at 2022-06-12 08:04:04.029232
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import logging

    # Create temporary file
    f = tempfile.NamedTemporaryFile()
    fn = f.name

    # Add file handler to logger
    log = getLogger()
    log.addHandler(logging.FileHandler(fn))

    # Log messages with different levels
    log.debug("First message")
    log.info("Second message")
    log.warning("Third message")
    log.error("Fourth message")
    log.critical("Fifth message")

    # Default logger level is "DEBUG"
    assert len(f.readlines()) == 5

    # Reset or new file handler
    f.seek(0)

    with logger_level(log,"INFO"):
        # Log messages with different levels
        log.debug("First message")
        log.info("Second message")

# Generated at 2022-06-12 08:04:12.052494
# Unit test for function logger_level
def test_logger_level():
    import io
    import logging
    import sys

    log = logging.getLogger('test.logger_level')
    log.setLevel(logging.DEBUG)

    sio = io.StringIO()
    log_handler = logging.StreamHandler(sio)
    log_handler.setLevel(logging.DEBUG)
    log_formatter = logging.Formatter('%(asctime)s|%(name)s|%(message)s')
    log_handler.setFormatter(log_formatter)
    log.addHandler(log_handler)

    with logger_level(log, logging.INFO):
        log.debug("debug inside logger_level")
        log.info("info inside logger_level")
        log.warn("warn inside logger_level")
        log.error("error inside logger_level")
       

# Generated at 2022-06-12 08:04:14.298207
# Unit test for function configure
def test_configure():
    configure()


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    test_configure()

# Generated at 2022-06-12 08:04:18.611152
# Unit test for function logger_level
def test_logger_level():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG