

# Generated at 2022-06-12 07:54:35.650051
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()

    # test our logger level context manager
    logger = get_logger(__name__)
    with logger_level(logger, logging.CRITICAL):
        logger.warning('should not display')
    logger.warning('should display')



# Generated at 2022-06-12 07:54:40.605225
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO



if __name__ == '__main__':
    from logging import getLogger
    log = getLogger(__name__)
    log.info('test')

# Generated at 2022-06-12 07:54:44.553667
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO



# Generated at 2022-06-12 07:54:51.415502
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('logger_level_test')
    print('Logging level of logger_level_test is %s' % logger.level)
    with logger_level(logger, logging.ERROR):
        logger.debug('This message should be suppressed')
    logger.debug('This message should be printed')

    # Reset logger level to NOTSET to prevent any logging output
    logger.setLevel(logging.NOTSET)

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:54:54.495329
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test')
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    assert logger.level == logging.INFO



# Generated at 2022-06-12 07:55:05.807227
# Unit test for function logger_level
def test_logger_level():
    logger=logging.getLogger("logger_level")
    logger.setLevel(logging.WARNING)
    if logger.getEffectiveLevel()!=logging.WARNING:
        print("Error: logger level is {0}, and not WARNING".format(logger.getEffectiveLevel()))
        raise Exception("logger level is {0}, and not WARNING".format(logger.getEffectiveLevel()))
    #print("Info: logger level is {0}, and WARNING".format(logger.getEffectiveLevel()))
    with logger_level(logger, logging.DEBUG):
        if logger.getEffectiveLevel()!=logging.DEBUG:
            print("Error: logger level is {0}, and not DEBUG".format(logger.getEffectiveLevel()))

# Generated at 2022-06-12 07:55:11.582000
# Unit test for function logger_level
def test_logger_level():
    # The easiest is to test both, but if it's possible to do without
    # one of them, we would rather use only one.
    try:
        log = getLogger()
        log.info('Hello world!')

        with logger_level(log, logging.ERROR):
            log.info('foo')
            log.error('bar')
    except:
        log = getLogger()
        log.info('Hello world!')

        with logger_level(log, logging.ERROR):
            log.info('foo')
            log.error('bar')

if __name__ == "__main__":
    # Running this file is the same as running unittest test for the function logger_level
    test_logger_level()

# Generated at 2022-06-12 07:55:14.534529
# Unit test for function get_config
def test_get_config():
    config = {'loggers': {'root': {'level': 'WARNING', 'handlers': ['console']}}}
    json_value =  '{"loggers": {"root": {"level": "WARNING", "handlers": ["console"]}}}'
    yaml_value = 'loggers:\n  root:\n    handlers: [console]\n    level: WARNING\n'

    assert get_config(config) == config
    assert get_config(json_value) == config
    assert get_config(yaml_value) == config



# Generated at 2022-06-12 07:55:19.862024
# Unit test for function logger_level
def test_logger_level():
    # Set the log level
    logger = get_logger('test_logger_level')
    logger.propagate = False
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        if logger.getEffectiveLevel() != logging.DEBUG:
            raise ValueError('Unexpected effective log level: %s' % logger.getEffectiveLevel())
    # Check that the level has been reset
    if logger.getEffectiveLevel() != logging.DEBUG:
        raise ValueError('Unexpected effective log level outside of context: %s' % logger.getEffectiveLevel())



# Generated at 2022-06-12 07:55:26.419704
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.ERROR):
        # This should be suppressed
        logger.debug('test')

    with logger_level(logger, logging.DEBUG):
        # This should not be suppressed
        logger.debug('test')


if __name__ == '__main__':
    import doctest

    doctest.testmod()
    logging.basicConfig(level=logging.DEBUG)
    test_logger_level()

# Generated at 2022-06-12 07:55:35.320227
# Unit test for function get_config
def test_get_config():
    assert get_config(config="{'vers': 1}") == {'vers': 1}
    assert get_config(config=json.dumps({'vers': 1})) == {'vers': 1}
    assert get_config(config=yaml.dump({'vers': 1})) == {'vers': 1}
    assert get_config(env_var='YUYUYUYU') is None
    assert get_config(env_var='LOGGING', default=DEFAULT_CONFIG) == DEFAULT_CONFIG


if __name__ == '__main__':
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-12 07:55:44.092387
# Unit test for function logger_level
def test_logger_level():
    '''
    Demonstrates how to use context manager logger_level to temporarily set the log level for debugging purposes.
    '''
    log = get_logger(__name__)
    log.setLevel(logging.INFO)
    log.debug("This should not appear in the log")

    # temporarily set the log level to DEBUG
    with logger_level(log, logging.DEBUG):
        log.debug("This should appear in the log")
    log.debug("This should not appear in the log")


if __name__ == '__main__':
    configure()
    log = get_logger(__name__)
    log.info('test')
    log.info('test2')

    test_logger_level()

# Generated at 2022-06-12 07:55:54.657712
# Unit test for function logger_level
def test_logger_level():
    import logging
    import time

    # dummy logger
    log = logging.getLogger(__name__)

    # add a memory handler to the logger
    #
    # we can't use the console handler when running this test, because the
    # logging output may be buffered, and we don't want to flush just because
    # we changed the level of the logger.
    mh = logging.handlers.MemoryHandler(0)
    log.addHandler(mh)

    # make sure we are logging only warnings and errors
    print('We should see only one message with level ERROR:')
    with logger_level(log, logging.ERROR):
        log.info('This will not be logged')
        log.warning('This will not be logged')
        log.error('This will be logged')

    # grab the records from the memory handler
    m

# Generated at 2022-06-12 07:56:05.484122
# Unit test for function get_config
def test_get_config():
    assert get_config(None,None,DEFAULT_CONFIG) == DEFAULT_CONFIG

# Generated at 2022-06-12 07:56:08.925469
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('This is a test debug msg.')
    logger.info('This is an info msg.')

# Generated at 2022-06-12 07:56:14.128409
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test')
    import time

    with logger_level(logger, logging.INFO):
        logger.debug('this wont show up')
        time.sleep(0.1)
        logger.info('this WILL show up')

    logger.info('this will show up')
    time.sleep(0.1)
    logger.debug('this will show up')

# Generated at 2022-06-12 07:56:16.903856
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test')
    with logger_level(logger, logging.CRITICAL):
        pass
    assert logger.level == logging.CRITICAL


# Generated at 2022-06-12 07:56:26.740103
# Unit test for function get_config

# Generated at 2022-06-12 07:56:36.617833
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)

    old_level = logger.level

    logger.debug('This is debug message') # should appear in log
    logger.info('This is info message') # should appear in log
    logger.warning('This is warning message') # should appear in log
    logger.error('This is error message') # should appear in log
    logger.critical('This is critical message') # should appear in log

    with logger_level(logger, logging.CRITICAL):
        logger.debug('debug') # should not appear in log
        logger.info('aa') # should not appear in log
        logger.warning('warning') # should not appear in log
        logger.error('error') # should appear in log
        logger.critical('critical') # should appear in log

    logger.debug('This is debug message 2') # should

# Generated at 2022-06-12 07:56:41.130322
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("test_logger_level")
    log_str = "1"
    with logger_level(logger, logging.DEBUG):
        logger.debug(log_str)
    with logger_level(logger, logging.INFO):
        logger.debug(log_str)
    with logger_level(logger, logging.CRITICAL):
        logger.debug(log_str)



# Generated at 2022-06-12 07:56:50.026368
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    logger = logging.getLogger(__name__)

    with logger_level(logger, 20):
        logger.info('info')
        logger.warning('warning')
        logger.critical('critical')
        logger.debug('debug')

# Generated at 2022-06-12 07:56:52.578738
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("debug message")
    log.debug("debug message again")

# Generated at 2022-06-12 07:56:56.406282
# Unit test for function logger_level
def test_logger_level():
    """Make sure context manager isn't leaking."""
    log = getLogger(__name__)
    log.setLevel(logging.INFO)
    log.info('logging level is INFO')

    with logger_level(log, logging.DEBUG):
        log.debug('logging level is DEBUG')

    log.info('logging level is INFO')


# Utility for inspection

# Generated at 2022-06-12 07:57:07.066030
# Unit test for function logger_level
def test_logger_level():
    import time
    # This logger should be configured already, to test logger_level function.
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    # Check if it is not logging at this point.
    with logger_level(logger, logging.INFO):
        try:
            logger.debug('This should not be logged.')
        except AttributeError:
            logger.debug('AttributeError no longer raised')
    # Check if it is now logging
    with logger_level(logger, logging.DEBUG):
        try:
            logger.debug('This should be logged.')
        except AttributeError:
            logger.debug('AttributeError still raised')

# -------------- aliases -----------------
# Notes:
# 1) I've removed the kwarg-accepting wrappers (e.g.

# Generated at 2022-06-12 07:57:12.575238
# Unit test for function logger_level
def test_logger_level():
    """Test function logger_level.

    Check that logging.DEBUG level is only used within the context block.
    """
    log = get_logger()

    with logger_level(log, logging.DEBUG):
        log.info('This should be logged')
        log.debug('This should be logged too')

    log.debug('This should not be logged')
    log.info('This should be logged too')

# Generated at 2022-06-12 07:57:18.579210
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    num_log_messages = len(log.handlers[0].messages)
    with logger_level(log, logging.ERROR):
        # If there is no exception, this message is not sent to the logger
        log.debug('This should not be logged')
        # If there is an exception, this message is logged
        try:
            assert 1 == 0
        except AssertionError:
            log.exception('This should be logged')
    # After leaving the `with` block, the logger level gets reset to the initial value
    log.debug('This should be logged')
    assert len(log.handlers[0].messages) - num_log_messages == 2



# Generated at 2022-06-12 07:57:29.719595
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("test")
    configure()

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level != logging.DEBUG



# Generated at 2022-06-12 07:57:34.841463
# Unit test for function logger_level
def test_logger_level():
    import sys
    logger = getLogger()
    initial = logger.level
    with logger_level(logger, logging.WARN):
        assert logger.level == logging.WARN
    assert logger.level == initial
    tinySetUp = logger_level(logger, logging.WARN)
    with tinySetUp:
        assert logger.level == logging.WARN

# Generated at 2022-06-12 07:57:39.091830
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
    assert logger.level == logging.DEBUG

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:57:43.031988
# Unit test for function logger_level
def test_logger_level():
    l = getLogger()
    assert l.level == logging.DEBUG
    with logger_level(l, logging.ERROR):
        assert l.level == logging.ERROR
    assert l.level == logging.DEBUG



# Generated at 2022-06-12 07:57:49.188931
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.info('test')


# Generated at 2022-06-12 07:57:53.431749
# Unit test for function logger_level
def test_logger_level():
    try:
        with logger_level(logging.getLogger('test'), logging.DEBUG):
            assert logging.getLogger('test').level == logging.DEBUG
    except AssertionError:
        raise AssertionError("logger_level did not change the level of the logger")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:58:02.712980
# Unit test for function configure
def test_configure():
    from io import StringIO
    from contextlib import redirect_stdout

    # Default config
    f = StringIO()
    with redirect_stdout(f):
        configure()
        logging.getLogger(__name__).info('test')
    assert 'INFO:__main__:test' in f.getvalue()

    # Default config, as json string
    f = StringIO()
    with redirect_stdout(f):
        cfg = get_config(default=DEFAULT_CONFIG)
        import json

        json_config = json.dumps(cfg)
        configure(json_config)
        logging.getLogger(__name__).info('test')
    assert 'INFO:__main__:test' in f.getvalue()

    # Default config, as yaml string
    f = StringIO()

# Generated at 2022-06-12 07:58:13.513487
# Unit test for function get_config

# Generated at 2022-06-12 07:58:17.824943
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.isEnabledFor(logging.CRITICAL)
        with logger_level(logger, logging.DEBUG):
            assert logger.isEnabledFor(logging.DEBUG)
        assert logger.isEnabledFor(logging.CRITICAL)

# Generated at 2022-06-12 07:58:23.700258
# Unit test for function get_config
def test_get_config():
    _config_1 = {'version': '1'}
    assert _config_1 is get_config(_config_1)
    assert _config_1 == get_config(json.dumps(_config_1))
    assert _config_1 == get_config(yaml.dump(_config_1))
    assert _config_1 == get_config(
        json.dumps(_config_1), default=_config_1
    )
    assert _config_1 == get_config(yaml.dump(_config_1), default=_config_1)
    assert _config_1 == get_config(
        json.dumps(_config_1), env_var='TEST', default=_config_1
    )

# Generated at 2022-06-12 07:58:27.366981
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.CRITICAL):
        log.info('The info log should not be visible')
        log.critical('The critical log should be visible')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:58:31.219629
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, 0):
        logger.debug('debug')
        logger.info('info')
        logger.warn('warn')
        logger.error('error')
        logger.critical('critical')

# Generated at 2022-06-12 07:58:41.955016
# Unit test for function get_config

# Generated at 2022-06-12 07:58:53.101047
# Unit test for function logger_level
def test_logger_level():
    n = "fake"
    log_string = "me"
    root_logger = logging.getLogger()
    with logger_level(root_logger, logging.CRITICAL):
        assert root_logger.getEffectiveLevel != logging.CRITICAL
        logger = get_logger(n)
        logger.debug(log_string)
        logger.info(log_string)
        logger.warn(log_string)
        logger.error(log_string)
        logger.critical(log_string)
    with logger_level(root_logger, logging.INFO):
        assert logger.getEffectiveLevel() != logging.CRITICAL
        logger.debug(log_string)
        logger.info(log_string)
        logger.warn(log_string)
        logger.error(log_string)

# Generated at 2022-06-12 07:59:04.814616
# Unit test for function configure
def test_configure():
    logging.shutdown()
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-12 07:59:09.189701
# Unit test for function configure
def test_configure():
    configure()
    logging.debug("This is a debug message")
    logging.info("This is an info message")
    logging.warning("This is a warning message")
    logging.error("This is an error message")
    logging.critical("This is a critical message")



# Generated at 2022-06-12 07:59:14.327895
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    def check_logger_level(level):
        with logger_level(logger, level):
            assert logger.isEnabledFor(level)
        assert not logger.isEnabledFor(level)

    for lvl in [logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR, logging.CRITICAL]:
        check_logger_level(lvl)



# Generated at 2022-06-12 07:59:17.208092
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.info('success')
        try:
            logger.debug('failure')
        except:
            pass

# Generated at 2022-06-12 07:59:26.030593
# Unit test for function logger_level
def test_logger_level():
    from tempfile import mkstemp
    import os
    import logging
    logger = logging.getLogger("test")
    logger.setLevel(logging.DEBUG)
    fd, filename = mkstemp(".log")
    os.close(fd)
    file_handler = logging.FileHandler(filename, "w")
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warn("warning")
        logger.error("error")
        logger.critical("critical")

# Generated at 2022-06-12 07:59:30.812663
# Unit test for function logger_level
def test_logger_level():
    """Test for logger_level()."""
    logger_level(getLogger(), logging.INFO)
    getLogger().debug("Hello")
    getLogger().info("Hello")
    getLogger().error("Error")

    with logger_level(getLogger(), logging.DEBUG):
        getLogger().info("Hello")
        getLogger().debug("Hello")
        getLogger().error("Error")


# Generated at 2022-06-12 07:59:35.446061
# Unit test for function logger_level
def test_logger_level():
    import sys
    logger = logging.getLogger('test_logger_level')
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.NOTSET



# Generated at 2022-06-12 07:59:40.519602
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test.logging.logger_level')
    with logger_level(logger, logging.INFO):
        logger.info('foo')
        logger.debug('bar')


if __name__ == '__main__':
    _ensure_configured()
    logging.info('test log message')

    #logger_level('foo')

# Generated at 2022-06-12 07:59:43.857778
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('Showing logger at DEBUG')
    log.info('Showing logger at INFO')
    with logger_level(log, logging.ERROR):
        log.error('Showing logger at ERROR')

# Generated at 2022-06-12 07:59:49.651177
# Unit test for function logger_level
def test_logger_level():
    import logging
    from pytest import raises
    from pytest import fixture


# Generated at 2022-06-12 08:00:03.201281
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, logging.DEBUG):
        logger.debug('This line should appear')
        logger.info('This line should not appear')

    logger.info('This line should appear')
    logger.debug('This line should not appear')
    


# Generated at 2022-06-12 08:00:06.637773
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG) as l:
        l.info('MESSAGE')

# Generated at 2022-06-12 08:00:10.168562
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    configure()

    with logger_level(log, logging.DEBUG):
        log.debug("Message 1")

    with logger_level(log, logging.WARNING):
        log.debug("Message 2")

    log.debug("Message 3")



# Generated at 2022-06-12 08:00:15.262058
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARNING):
        logger.info("I should not be logged")
        logger.debug("I should not be logged")
        logger.warning("I should be logged")
        logger.error("I should be logged")
        logger.critical("I should be logged")




# Generated at 2022-06-12 08:00:25.937448
# Unit test for function get_config
def test_get_config():
    # config is None
    config = get_config(None, 'LOGGING', DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG

    # config is a string

# Generated at 2022-06-12 08:00:29.119784
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    try :
        with logger_level(logger, logging.CRITICAL):
            raise Exception("Raise exception test")
    except Exception as e :
        if e.message == "Raise exception test":
            print("test_logger_level: pass")
        else:
            raise e


# Generated at 2022-06-12 08:00:34.052673
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.info("This should not be logged")
        logger.debug("This should be logged")
    logger.debug("This should not be logged")
    logger.info("This should be logged")
    logger.setLevel(logging.INFO)
    logger.debug("This should not be logged")
    logger.info("This should be logged")



# Generated at 2022-06-12 08:00:40.965566
# Unit test for function get_config

# Generated at 2022-06-12 08:00:47.837873
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    cfg = json.dumps({'a': 'b'})
    assert isinstance(get_config(given=cfg), dict)
    cfg = yaml.safe_dump({'a': 'b'})
    assert isinstance(get_config(given=cfg), dict)
    cfg = '{"a": "b"}'
    assert isinstance(get_config(given=cfg), dict)
    cfg = '{a: b}'
    assert isinstance(get_config(given=cfg), dict)

# Unit tests for function get_logger

# Generated at 2022-06-12 08:00:51.063601
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    import logging
    with logger_level(log, logging.DEBUG) as log:
        log.debug('logger level is %s', logging.DEBUG)
    log.debug('logger level is %s', logging.DEBUG)

# Generated at 2022-06-12 08:01:06.708084
# Unit test for function logger_level
def test_logger_level():
    configure()
    logger = logging.getLogger('logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test_logger_level: Passed')
    logger.debug('test_logger_level: Passed')


# Generated at 2022-06-12 08:01:09.533376
# Unit test for function logger_level
def test_logger_level():

    import logging
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG  # logger level not affected outside context




# Generated at 2022-06-12 08:01:21.324968
# Unit test for function configure
def test_configure():
    config = {'version': 1, 'formatters': {'simple': {'format': '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s', 'datefmt': '%Y-%m-%d %H:%M:%S'}}, 'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'simple', 'level': 10}}, 'root': {'handlers': ['console'], 'level': 10}, 'loggers': {'requests': {'level': 20}}}

# Generated at 2022-06-12 08:01:24.708327
# Unit test for function logger_level
def test_logger_level():
    import time
    import random
    import sys
    import chai
    from chai import Chai
    chai.config.reset()
    logger = getLogger('chai.test_logger_level')
    logger.debug("This line should not get logged")
    with logger_level(logger, logging.DEBUG):
        logger.debug("This line should get logged")
        assert chai._.logged.length == 1



# Generated at 2022-06-12 08:01:28.619756
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    with logger_level(logger, logging.WARNING):
        logger.info('info')
        logger.warning('warning')
        logger.error('error')

    logger.info('info')
    logger.warning('warning')
    logger.error('error')

# Generated at 2022-06-12 08:01:35.581186
# Unit test for function configure
def test_configure():
    import tempfile
    log = logging.getLogger(__name__)


# Generated at 2022-06-12 08:01:40.121078
# Unit test for function logger_level
def test_logger_level():
    import time

    logger = getLogger('test_logger_level')
    debug_level = logger.level
    logger.setLevel(logging.INFO)

    # This will print nothing because default level was INFO
    logger.debug('This is a debug message')

    with logger_level(logger, logging.DEBUG):
        # This will print because level is temporarily set to DEBUG
        logger.debug('This is a debug message')

    # This will print nothing because level will be reset to INFO
    logger.debug('This is a debug message')

    # This will print because level is INFO
    logger.info('This is an info message')

    # This will print nothing because level is still INFO
    logger.debug('This is a debug message')

    # This will set level to DEBUG and print
    logger.setLevel(logging.DEBUG)
   

# Generated at 2022-06-12 08:01:43.558451
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO


_CONFIGURED_BASE = []



# Generated at 2022-06-12 08:01:48.379055
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test.logger_level')
    with logger_level(log, logging.CRITICAL):
        log.critical('critical message')
        log.error('error message')
        log.warning('warning message')
        log.info('info message')
        log.debug('debug message')
    log.critical('critical message')
    log.error('error message')
    log.warning('warning message')
    log.info('info message')
    log.debug('debug message')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:01:55.002050
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug(1)
        logger.info(2)
        logger.error(3)
        with logger_level(logger, logging.INFO):
            logger.debug(4)
            logger.info(5)
            logger.error(6)
        logger.debug(7)
        logger.info(8)
        logger.error(9)



# Generated at 2022-06-12 08:02:22.690428
# Unit test for function logger_level
def test_logger_level():
    import sys, time
    import tempfile
    from contextlib import contextmanager
    from colorlog import  ColoredFormatter
    from contextlib import contextmanager

    # sys.stderr.write(u'[%s]' % sys.version_info)
    @contextmanager
    def capture_stream(stream):
        oldstream = getattr(sys, stream)
        capture = tempfile.SpooledTemporaryFile()
        setattr(sys, stream, capture)
        capture.seek(0)
        try:
            yield capture
        finally:
            setattr(sys, stream, oldstream)

    @contextmanager
    def logger_level(logger, level):
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    logging.basicConfig

# Generated at 2022-06-12 08:02:28.176820
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("debugging in test_logger_level")
    log.debug("debugging after test_logger_level")

configure()

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:02:32.080554
# Unit test for function logger_level
def test_logger_level():
    # setup
    test_logger = get_logger()
    level = logging.DEBUG
    with logger_level(test_logger, level):
        # should pass
        assert test_logger.level == level
    # should pass
    assert test_logger.level == logging.DEBUG

test_logger_level()



# Generated at 2022-06-12 08:02:40.503832
# Unit test for function logger_level
def test_logger_level():
    import time
    import logging

    logger = logging.getLogger(__name__)

    logger.setLevel(logging.DEBUG)

    logger.info("Start")
    with logger_level(logger,logging.WARN):
        logger.debug("Debug not shown")
        logger.info("Info not shown")
        logger.warn("Warn show")
        logger.error("Error shown")
        logger.critical("critical shown")

    logger.info("Finish")
    time.sleep(1)

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:02:44.685775
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('temp')
    log.setLevel(logging.DEBUG)
    log.debug('initial log message')
    with logger_level(log, logging.INFO):
        log.debug('expected to not be displayed')
        log.info('expected to be displayed')
    log.debug('log message at DEBUG level')

# Uncomment for debugging
# test_logger_level()

# Generated at 2022-06-12 08:02:50.466631
# Unit test for function logger_level
def test_logger_level():
    def logger_level_test():
        log = getLogger(__name__)
        log.debug("Debug message")

    # Check the debug message is not shown
    log = getLogger(__name__)
    log.setLevel(logging.INFO)
    with logger_level(log, logging.DEBUG):
        logger_level_test()
    log.setLevel(logging.DEBUG)
    with logger_level(log, logging.INFO):
        logger_level_test()

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:02:53.242478
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.isEnabledFor(logging.DEBUG)
    assert log.isEnabledFor(logging.INFO)

# Generated at 2022-06-12 08:02:57.722557
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    try:
        with logger_level(logger, logging.ERROR):
            logger.warn('This is warning from %s', __name__)
            logger.error('This is error from %s', __name__)
    finally:
        logger.info('Set Logger level to original')

if __name__ == '__main__':
    configure()
    test_logger_level()

# Generated at 2022-06-12 08:03:01.043841
# Unit test for function logger_level
def test_logger_level():
    configure()
    logger = getLogger()
    with logger_level(logger, 20):
        logger.info('in with')
    logger.info('out of with')
    assert logger.level == logging.DEBUG


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:03:07.926944
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
        logger.debug('message')
        logger.info('message')
        logger.warning('message')
        logger.error('message')
        logger.critical('message')

    assert logger.level == logging.DEBUG
    logger.debug('message')
    logger.info('message')
    logger.warning('message')
    logger.error('message')
    logger.critical('message')


# TODO: allow specifying handlers and levels on a per-logger basis?
# (or maybe this can be done with filtering per logger, but that's not as
# flexible...)
#
# class HandlerLevels(object):
#    

# Generated at 2022-06-12 08:04:02.922954
# Unit test for function logger_level
def test_logger_level():
    from mock import patch, call

    log = get_logger(__name__)
    # We use the get_logger() method to insure an initial configuration of the root logger
    # ( since there's no guarantee the logging library has previously been used. )
    # We then need to make sure to remove any handlers for our logger,
    # since we don't want this test to generate any output.
    del log.handlers[:]

    with patch('logging.Logger.setLevel') as setLevel, \
            patch('logging.Logger.error') as error:
        with logger_level(log, logging.ERROR):
            log.error('happened in block')
            log.info('we should ignore this')


# Generated at 2022-06-12 08:04:11.126043
# Unit test for function logger_level
def test_logger_level():
    from io import StringIO
    from logging import DEBUG, INFO, WARNING, ERROR, CRITICAL
    import sys

    test_messages = [
        ('DEBUG', DEBUG), ('INFO', INFO), ('WARNING', WARNING), ('ERROR', ERROR), ('CRITICAL', CRITICAL)
    ]
    output = {}
    for key, level in test_messages:
        output[key] = StringIO()
        old_stdout = sys.stdout
        sys.stdout = output[key]
        logger = getLogger()
        logger.setLevel(INFO)
        with logger_level(logger, level):
            logger.debug('test')
            logger.info('test')
            logger.warning('test')
            logger.error('test')
            logger.critical('test')
        sys.stdout = old_stdout
   

# Generated at 2022-06-12 08:04:15.612351
# Unit test for function logger_level
def test_logger_level():
    import StringIO
    import logging

    capturedOutput = StringIO.StringIO()
    logger = logging.getLogger(__name__)
    logger.addHandler(logging.StreamHandler(capturedOutput))

    with logger_level(logger, logging.WARNING):
        logger.info('test')
        logger.warning('test')
    assert not capturedOutput.getvalue()

    with logger_level(logger, logging.DEBUG):
        logger.info('test')
        logger.warning('test')
    assert len(capturedOutput.getvalue()) > 0

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:04:21.850413
# Unit test for function logger_level
def test_logger_level():
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        class MockLogger(object):
            def __init__(self):
                self.level = logging.DEBUG

        def test_sets_logger_level(self):
            logger = self.MockLogger()
            with logger_level(logger, logging.ERROR):
                self.assertEqual(logger.level, logging.ERROR)
            self.assertEqual(logger.level, logging.DEBUG)

    unittest.main()

# Generated at 2022-06-12 08:04:25.342535
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("test_logger_level")
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        with logger_level(logger, logging.INFO):
            assert logger.level == logging.INFO
        assert logger.level == logging.DEBUG


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:04:27.390060
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('Debug')
    logger.debug('Debug2')