

# Generated at 2022-06-12 07:54:39.210672
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    # logger_level is a context manager.
    # We must use import code to be able to catch exceptions
    # from within the context block
    code = '''
log.info('This should be the first log message.')
with logger_level(log, logging.CRITICAL):
    log.info('This should be the second log message, hidden by the first.')
    try:
        raise RuntimeError('This should be a runtime error')
    except Exception:
        log.error('This should be the third log message, but it is hidden by the first message.', exc_info=True)
log.info('This should be the fourth message.')
'''
    with logger_level(log, logging.DEBUG):
        import code
        namespace = {'log': log, 'logger_level': logger_level}

# Generated at 2022-06-12 07:54:46.004920
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    log_msg = "This is a test message"
    with logger_level(logger, logging.DEBUG):
        logger.debug(log_msg)

    try:
        logger.debug(log_msg)
    except Exception as e:
        print("Exception: %s" %e)


# Generated at 2022-06-12 07:54:53.678942
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("test_logger_level")
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
        logger.debug("Hello world")
        logger.info("Hello world")
        logger.warning("Hello world")
        logger.error("Hello world")
        logger.critical("Hello world")
    assert logger.level == logging.DEBUG
    logger.debug("Hello world")
    logger.info("Hello world")
    logger.warning("Hello world")
    logger.error("Hello world")
    logger.critical("Hello world")



# Generated at 2022-06-12 07:54:56.734017
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.INFO), 'Should be DEBUG'
    assert logger.isEnabledFor(logging.DEBUG), 'Should be INFO'


# Generated at 2022-06-12 07:55:01.628753
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('logger_level_test_logger')
    logger.propagate = False
    logger.setLevel(99)
    with logger_level(logger, logging.WARN):
        assert logger.getEffectiveLevel() == logging.WARN
    assert logger.getEffectiveLevel() == 99


# Generated at 2022-06-12 07:55:06.454361
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()

    # make sure that the level was actually changed
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    # make sure that the level is reset
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO


# Generated at 2022-06-12 07:55:15.344227
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    # Initial logger level is DEBUG
    assert logger.level == logging.DEBUG

    print("Start set logger level to INFO and then to DEBUG again")
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        logger.debug("This debug message should not display")
        logger.info("This info message should display")
    assert logger.level == logging.DEBUG
    logger.debug("This debug message should display")


if __name__ == '__main__':
    import pytest
    pytest.main()
    print("\n\nAll tests passed")

# Generated at 2022-06-12 07:55:21.134234
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    logger = logging.getLogger('test')
    log = logging.getLogger('test')
    # create file handler
    handler = logging.FileHandler('/tmp/test.log')
    handler.setLevel(logging.DEBUG)
    # create logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    with logger_level(log, logging.DEBUG) as l:
        log.debug('DEBUG log')
        log.info('INFO log')
        log.warning('WARNING log')
        log.error('ERROR log')
        log.critical('CRITICAL log')

# Generated at 2022-06-12 07:55:24.552303
# Unit test for function logger_level
def test_logger_level():
    """Test the logger_level function"""
    logger = get_logger("test_logger_level")
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:55:29.117281
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    logger.warn("This warning should be shown")
    with logger_level(logger, logging.CRITICAL):
        logger.warn("This warning should not be shown")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:55:42.231032
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import sys

    logger = logging.getLogger('test')
    logger.addHandler(logging.StreamHandler(sys.stderr))

    logger.setLevel(logging.NOTSET)
    assert logger.level == logging.NOTSET

    with logger_level(logger, logging.WARN):
        assert logger.level == logging.WARN
        logger.info("Testing info message")
        logger.warn("Testing warn message")
    assert logger.level == logging.NOTSET

# Generated at 2022-06-12 07:55:52.805591
# Unit test for function configure

# Generated at 2022-06-12 07:55:55.833386
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('I\'m a debug statement')
    logger.info('I\'m an info statement')


# Generated at 2022-06-12 07:56:06.159967
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    class SimpleObject(object):
        pass


# Generated at 2022-06-12 07:56:15.513668
# Unit test for function configure

# Generated at 2022-06-12 07:56:22.773538
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    log_output = StringIO()
    with logger_level(logger, logging.DEBUG):
        logger.debug('value')
        with logger_level(logger, logging.INFO):
            logger.debug('value')
            logger.info('value')
        logger.debug('value')
    logger.debug('value')

    assert logger.getEffectiveLevel() == logging.DEBUG
    # shows that logger level is restored outside the with statement.
    assert logger.getEffectiveLevel() == initial

# Generated at 2022-06-12 07:56:28.380703
# Unit test for function logger_level
def test_logger_level():
    import time

    logger = get_logger()
    # Try setting level to INFO and running a block of code
    with logger_level(logger, logging.INFO):
        logger.debug('Should not be logged')
        logger.info('Should be logged')
        logger.warning('Should be logged')

    # Try setting level to WARNING and running a block of code
    with logger_level(logger, logging.WARNING):
        logger.debug('Should not be logged')
        logger.info('Should not be logged')
        logger.warning('Should be logged')


# Generated at 2022-06-12 07:56:32.096810
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger(__name__)
    # The root logger is set to logging.WARN and this prevents from logging
    # with a lower level, so we temporarily set it to INFO
    with logger_level(logging.getLogger(''), logging.INFO):
        with logger_level(logger, logging.DEBUG):
            logger.debug("Here I am")

        try:
            logger.debug("Here I am")
        except:
            pass
        else:
            assert False, 'The logger level should be back to WARN'

# Generated at 2022-06-12 07:56:38.735693
# Unit test for function logger_level
def test_logger_level():
    import time
    logging.basicConfig(level=logging.DEBUG)
    logger = get_logger('test')
    with logger_level(logger, logging.DEBUG):
        logger.info('This is an info message')
        logger.debug('This is a debug message')
        time.sleep(3)
    logger.info('This is an info message')
    logger.debug('This is a debug message')

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:56:49.144424
# Unit test for function get_config
def test_get_config():
    import json


# Generated at 2022-06-12 07:57:06.877323
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    log = get_logger()

    msg = 'test'
    with logger_level(log, logging.DEBUG):
        log.debug(msg)
    # logger level resets back to warning
    with logger_level(log, logging.INFO):
        log.info(msg)
    with logger_level(log, logging.WARNING):
        log.warning(msg)
        log.error(msg)
        log.exception(msg)
    # logger level resets back to warning
    with logger_level(log, logging.ERROR):
        log.error(msg)
        log.exception(msg)
    with logger_level(log, logging.CRITICAL):
        log.critical(msg)

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:57:11.466264
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        assert log.getEffectiveLevel() == logging.DEBUG
    assert log.getEffectiveLevel() != logging.DEBUG


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:57:18.515993
# Unit test for function logger_level
def test_logger_level():
    """
    >>> test_logger_level()
    Enter with log level 20
    Enter with log level 10
    Exit with log level 10
    Enter with log level 10
    Exit with log level 10
    Exit with log level 20
    """
    import logging
    import sys

    logger = logging.getLogger("test")

    # test starts with default level of 20 for root logger
    print("Enter with log level %d" % logger.getEffectiveLevel())

    with logger_level(logger, logging.INFO):
        print("Enter with log level %d" % logger.getEffectiveLevel())

        with logger_level(logger, logging.DEBUG):
            print("Enter with log level %d" % logger.getEffectiveLevel())


# Generated at 2022-06-12 07:57:23.230068
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('toto')
        log.info('toto')
        log.warning('toto')
        log.error('toto')
        log.critical('toto')



# Generated at 2022-06-12 07:57:31.595525
# Unit test for function configure
def test_configure():
    configure(default={'version': 1, 'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'colored', 'level': 'DEBUG'}}})
    logging.debug('debug message')
    logging.info('info message')
    logging.warning('warn message')
    logging.error('error message')

    configure(default={'version': 1, 'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'simple', 'level': 'DEBUG'}}})
    logging.debug('debug message')
    logging.info('info message')
    logging.warning('warn message')
    logging.error('error message')


if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-12 07:57:41.437174
# Unit test for function logger_level
def test_logger_level():
    import tempfile

    # Need to make sure the logger is configured
    _ensure_configured()

    # Create a temp file to write the logs to
    fp = tempfile.NamedTemporaryFile()
    name = tempfile.mktemp()
    logger = logging.getLogger(name)
    logger.addHandler(logging.FileHandler(filename=fp.name))

# Generated at 2022-06-12 07:57:51.349113
# Unit test for function logger_level
def test_logger_level():
    """Unit test for function logger_level."""
    import time
    import random
    import threading

    logging.basicConfig()
    logger = logging.getLogger('test_logger_level')

    # Should log everything
    logger.setLevel(logging.DEBUG)
    assert logger.isEnabledFor(logging.DEBUG)
    assert logger.isEnabledFor(logging.INFO)
    assert logger.isEnabledFor(logging.WARNING)
    assert logger.isEnabledFor(logging.ERROR)
    assert logger.isEnabledFor(logging.CRITICAL)

    # logger_level should temporarily modify log level for the context
    with logger_level(logger, logging.INFO):
        assert not logger.isEnabledFor(logging.DEBUG)
        assert logger.isEnabledFor(logging.INFO)
        assert logger

# Generated at 2022-06-12 07:58:00.783610
# Unit test for function get_config

# Generated at 2022-06-12 07:58:03.528178
# Unit test for function configure
def test_configure():
    import logging
    import logging.config
    import inspect
    import sys

    log = logging.getLogger(__name__)
    log.info('before configuration')

    configure()

    log = logging.getLogger(__name__)
    log.info('after configuration')


# Generated at 2022-06-12 07:58:12.120477
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('test_logger')
    assert logger.level == logging.NOTSET

    # Make sure that messages with level < logging.INFO are not logged
    with logger_level(logger, logging.INFO):
        logger.debug('this message is not logged')
        logger.info('this message is logged')

    # Make sure that messages with level < logging.WARNING are not logged
    with logger_level(logger, logging.WARNING):
        logger.debug('this message is not logged')
        logger.info('this message is not logged')
        logger.warning('this message is logged')

# Generated at 2022-06-12 07:58:23.857032
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.INFO)
    logger = get_logger()
    logger.info("INFO")
    with logger_level(logger, logging.DEBUG):
        logger.debug("DEBUG")
        logger.info("INFO")
    logger.info("INFO")


# Generated at 2022-06-12 07:58:26.229245
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.debug('debug log')
    assert logger.level == logging.DEBUG



# Generated at 2022-06-12 07:58:34.327288
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')

    with logger_level(log, logging.ERROR):
        log.debug('This should not print.')
        log.info('This should not print.')
        log.warning('This should not print.')
        log.error('This should print.')
        log.critical('This should print.')

    log.debug('This should print.')
    log.info('This should print.')
    log.warning('This should print.')
    log.error('This should print.')
    log.critical('This should print.')


# Generated at 2022-06-12 07:58:41.120064
# Unit test for function logger_level
def test_logger_level():
    import time

    log = get_logger()

    def log_foo():
        log.debug('debug')
        log.info('info')
        log.error('error')

    with logger_level(log, logging.DEBUG):
        log_foo()

    time.sleep(0.01)
    with logger_level(log, logging.INFO):
        log_foo()

    time.sleep(0.01)
    with logger_level(log, logging.ERROR):
        log_foo()



# Generated at 2022-06-12 07:58:45.419098
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('Should show because we are in DEBUG mode')
        logger.info('Should also show')
    logger.debug('Should not show because we are in default mode')



# Generated at 2022-06-12 07:58:52.465098
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.debug('It was a dark and stormy night...')

    with logger_level(logger, logging.INFO):
        logger.debug('It was a dark and stormy night...')

    logger.debug('It was a dark and stormy night...')

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:58:55.331605
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    log = logging.getLogger()
    log.info("test")
    with logger_level(log, logging.WARNING):
        log.info("test")
    log.info("test")


# Generated at 2022-06-12 07:58:59.215204
# Unit test for function logger_level
def test_logger_level():
    import logging

    log = logging.getLogger(__name__)

    with logger_level(log, logging.INFO):
        assert log.isEnabledFor(logging.INFO)
        with logger_level(log, logging.DEBUG):
            assert log.isEnabledFor(logging.DEBUG)
        assert log.isEnabledFor(logging.INFO)

    assert not log.isEnabledFor(logging.DEBUG)

# Generated at 2022-06-12 07:59:01.567330
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), logging.DEBUG):
        getLogger().debug('test_logger_level')


if __name__ == '__main__':
    test_logger_level()
    configure()

# Generated at 2022-06-12 07:59:08.855840
# Unit test for function logger_level
def test_logger_level():
    """
    Tests the logger_level context manager.

    The unit test is contained within one function, so that it runs only if the
    function is imported from a python interpreter, and not if the function is
    imported from a test suite.

    >>> logger = get_logger()
    >>> isinstance(logger.level, int)
    True
    >>> with logger_level(logger, logging.DEBUG) as l:
    ...     _ = l.level == logging.DEBUG
    >>> logger.level
    10
    """
    pass

# Generated at 2022-06-12 07:59:34.620315
# Unit test for function logger_level
def test_logger_level():
    def core(level):
        logger = getLogger(__name__)
        initial = logger.level
        logger.level = level
        assert logger.level == level
        try:
            logger.debug('this should be at debug level') # should be logged
            logger.info('this should be logged too') # should be logged
            assert "logger_level" in [x.funcName for x in logger.handlers[0].records]
        finally:
            logger.level = initial
        assert logger.level == initial

    def test_1():
        core(logging.DEBUG)

    def test_2():
        core(logging.INFO)

    def test_3():
        core(logging.WARNING)

    def test_4():
        core(logging.ERROR)


# Generated at 2022-06-12 07:59:44.476382
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import StringIO
    import logging

    class _LoggingTestCase(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            cls._stream = StringIO.StringIO()
            cls._handler = logging.StreamHandler(cls._stream)
            cls._handler.setFormatter(logging.Formatter("%(asctime)s|%(message)s"))
            cls._logger = logging.getLogger("foo")
            cls._logger.addHandler(cls._handler)

        @classmethod
        def tearDownClass(cls):
            cls._stream.close()

        def log(self, level):
            self._logger.log(level, "test logging level %s" % level)


# Generated at 2022-06-12 07:59:51.654846
# Unit test for function logger_level
def test_logger_level():
    configure()
    log = get_logger()
    more = get_logger('more')
    with logger_level(log, logging.ERROR):
        # Only error and critical logging messages should print
        log.info("Nothing should print")
        log.warning("Also nothing should print")
        log.error("This should print")
        more.info("This should also print")
    # Info and warning logging messages should now print
    log.info("This should print")
    log.warning("This should print")

# Generated at 2022-06-12 07:59:56.915939
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    # test logger_level
    with logger_level(log, logging.CRITICAL):
        log.debug("not output")
        log.info("not output")
        log.critical("output")
        assert True # test the exception
    log.debug("output")
    log.info("output")



# Generated at 2022-06-12 07:59:59.459378
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), 10):
        assert get_logger().level == 10
    assert get_logger().level == logging.DEBUG


# Generated at 2022-06-12 08:00:10.441833
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG
    assert get_config(default=None) is None
    assert get_config('{"version": 1}') == {'version': 1}
    assert get_config('version: 1') == {'version': 1}
    assert get_config(env_var='NOT_AN_ENV_VAR') == DEFAULT_CONFIG
    # TODO - Need to figure out how to test os.environ.get
    # a = os.environ.get('TEST_FOO_BAR', 'TEST_FOO_BAR')
    # assert get_config(env_var='TEST_FOO_BAR') == a
    # assert get_config(env_var='TEST_FOO_BAR', default='NOT_FOO_BAR') == a



# Generated at 2022-06-12 08:00:16.407813
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
        log.debug('debug level message')
        log.info('info level message')
        log.warning('warning level message')
        log.error('error level message')
        log.critical('critical level message')

    assert log.level == logging.DEBUG

# Generated at 2022-06-12 08:00:20.996570
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.WARN):
        log.info("Enable WARN logging level")
        log.warn("Logger level is WARN")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:00:24.326435
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    logger_level(log, logging.CRITICAL)
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.critical('should not be printed')

# Generated at 2022-06-12 08:00:25.140034
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-12 08:01:08.610020
# Unit test for function get_config
def test_get_config():
    import json

    assert get_config(default='{}') is not None
    assert get_config(default=json.dumps({})) is not None

    assert get_config(default=json.dumps({})) is not None



# Generated at 2022-06-12 08:01:15.837664
# Unit test for function logger_level
def test_logger_level():
    import logging
    import os
    log = logging.getLogger('my_logger')
    assert log.level == logging.NOTSET, 'Initial log level is not NOTSET'
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG, 'Log level is not DEBUG before yielding'
    assert log.level == logging.NOTSET, 'Log level is not NOTSET after exiting context manager'

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:01:20.195119
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug test')
    with logger_level(logger, logging.INFO):
        logger.info('info test')

# Generated at 2022-06-12 08:01:23.349161
# Unit test for function logger_level
def test_logger_level():
    l = get_logger(inspect.stack()[0][3])
    with logger_level(l, logging.INFO):
        l.debug('This message should be ignored.')
        l.info('This message should be logged.')
    l.debug('This message should also be ignored.')


# Generated at 2022-06-12 08:01:26.349141
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.info('Info')
        logger.debug('Debug')
    assert logger.level == logging.WARNING


# Generated at 2022-06-12 08:01:32.190600
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    log.setLevel(logging.DEBUG)

    # check if the log level is changed
    # inside the context block
    with logger_level(log, logging.INFO):
        log.info('This log should not be displayed')
        assert log.getEffectiveLevel() == logging.INFO

    # check if the log level is restored
    log.info('This log should be displayed')
    assert log.getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-12 08:01:36.214137
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    configure()
    with logger_level(logger, logging.INFO):
        logger.debug('This is a debug message')
        logger.info('This is a info message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:01:45.711123
# Unit test for function get_config
def test_get_config():
    # test for None
    config = None
    assert get_config(config=config) is None

    # test for bare string
    config = 'string'
    assert get_config(config=config) == config

    # test for json string
    json_dict = {'json': 'dict'}
    config = json.dumps(json_dict)
    assert get_config(config=config) == json_dict

    # test for yaml_string
    yaml_dict = {'yaml': 'dict'}
    config = yaml.dump(yaml_dict)
    assert get_config(config=config) == yaml_dict

    try:
        # test for unrecognized string
        config = '{json:}'
        get_config(config=config)
    except ValueError:
        pass

# Generated at 2022-06-12 08:01:55.847367
# Unit test for function get_config
def test_get_config():
    from io import StringIO

    config = get_config(
        {
            "version": 1,
            "handlers": {
                'console': {
                    'class': 'logging.StreamHandler',
                    'formatter': 'colored',
                    'level': logging.DEBUG,
                },
            },
            "root": {
                'handlers': ['console'],
                'level': logging.DEBUG,
            },
            "loggers": {
                "requests": {
                    'level': logging.INFO,
                },
            },
        }
    )

# Generated at 2022-06-12 08:02:05.928249
# Unit test for function logger_level
def test_logger_level():
    import logging
    import tempfile
    log = logging.getLogger(__name__)
    print(log.level)
    print(os.path.realpath(__file__))
    log.setLevel(logging.DEBUG)
    print(log.level)
    filename = tempfile.mktemp()
    print(filename)
    handler = logging.FileHandler(filename)
    print(handler)
    handler.setFormatter(logging.Formatter('%(name)s#%(funcName)s#%(levelname)s#%(message)s'))
    log.addHandler(handler)
    with logger_level(log, logging.INFO):
        log.debug('debug outside')
        log.info('info outside')
        log.warn('warn outside')
        log.error('error outside')
       

# Generated at 2022-06-12 08:03:29.815543
# Unit test for function get_config
def test_get_config():
    # Passing json
    json_str = '{"version": 1, "disable_existing_loggers": false}'
    config = get_config(given=json_str)
    assert config['version'] == 1
    assert 'disable_existing_loggers' in config
    # Passing yaml
    yaml_str = 'version: 1\\ndisable_existing_loggers: false'
    config = get_config(given=yaml_str)
    assert config['version'] == 1
    assert 'disable_existing_loggers' in config

# Generated at 2022-06-12 08:03:36.793707
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import os

    log = get_logger()

    with tempfile.NamedTemporaryFile(mode="wt", delete=False) as file:
        with logger_level(log, level=logging.INFO):
            log.info("This should be logged")
            log.debug("This should not be logged")

    with open(file.name) as opened:
        assert opened.readlines() == ["This should be logged\n"]

    os.remove(file.name)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:03:40.789929
# Unit test for function logger_level
def test_logger_level():
    LOG = logging.getLogger(__name__)
    LOG.info("You shouldn't see me")
    with logger_level(LOG, logging.CRITICAL):
        LOG.debug("You shouldn't see me")
        LOG.info("You shouldn't see me")
        LOG.critical("YOU SHOULD SEE ME")
    LOG.info("You should see me")

# Generated at 2022-06-12 08:03:45.103868
# Unit test for function get_config
def test_get_config():

    # Test empty config
    config = get_config()

    # Subtest pass list as config
    with pytest.raises(ValueError) as excinfo:
        get_config([])
    assert 'Invalid logging config' in str(excinfo.value)

    # Subtest pass dictionary as config
    with pytest.raises(TypeError) as excinfo:
        get_config(dict())
    assert 'not supported' in str(excinfo.value)

    # Subtest pass string as config
    with pytest.raises(ValueError) as excinfo:
        get_config('foo')
    assert 'Could not parse' in str(excinfo.value)

# Generated at 2022-06-12 08:03:52.705429
# Unit test for function logger_level
def test_logger_level():
    from tempfile import NamedTemporaryFile
    from logging import DEBUG, read

    logger = logging.getLogger('foo')

    with NamedTemporaryFile() as out:
        handler = logging.FileHandler(out.name)
        logger.addHandler(handler)

        with logger_level(logger, DEBUG):
            logger.info('bar')
            handler.flush()

        logger.info('baz')
        handler.flush()

        out.seek(0)
        contents = out.read().strip()
        assert contents == 'foo|DEBUG|bar', contents


# Generated at 2022-06-12 08:03:55.909078
# Unit test for function logger_level
def test_logger_level():
    root_logger = logging.getLogger()
    assert root_logger.level != logging.ERROR
    with logger_level(root_logger, logging.ERROR):
        assert root_logger.level == logging.ERROR
    assert root_logger.level != logging.ERROR

# Generated at 2022-06-12 08:03:57.330495
# Unit test for function configure
def test_configure():
    logger = get_logger(__name__)
    logger.info('test_configure')


# Generated at 2022-06-12 08:04:03.284309
# Unit test for function logger_level
def test_logger_level():
    # Test logger_level()
    import unittest
    import logging

    class TestLoggerLevel(unittest.TestCase):
        def test_logger_level(self):
            _logger = logging.getLogger("test")
            self.assertEqual(_logger.level, logging.NOTSET)
            with logger_level(_logger, logging.INFO):
                self.assertEqual(_logger.level, logging.INFO)
            self.assertEqual(_logger.level, logging.NOTSET)
            with logger_level(_logger, logging.DEBUG):
                self.assertEqual(_logger.level, logging.DEBUG)
            self.assertEqual(_logger.level, logging.NOTSET)

    unittest.main()

# Generated at 2022-06-12 08:04:09.482040
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    gp = get_logger(__name__ + '.gp')

    log.debug('debug-1')
    with logger_level(log, logging.DEBUG):
        log.debug('debug-2')
    log.debug('debug-3')

    gp.debug('debug-1')
    with logger_level(gp, logging.DEBUG):
        gp.debug('debug-2')
    gp.debug('debug-3')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:04:13.749926
# Unit test for function logger_level
def test_logger_level():
    import logging
    dummy_logger = logging.getLogger('dummy_logger')
    dummy_logger.addHandler(logging.NullHandler())
    assert dummy_logger.level == logging.NOTSET
    with logger_level(dummy_logger, logging.DEBUG):
        assert dummy_logger.level == logging.DEBUG
    assert dummy_logger.level == logging.NOTSET

## Unit test for function configure