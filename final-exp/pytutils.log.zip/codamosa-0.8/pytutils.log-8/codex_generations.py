

# Generated at 2022-06-12 07:54:39.826354
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.debug("Debug")
    logger.info("Info")

    with logger_level(logger, logging.WARN):
        logger.debug("Debug (should not be shown)")
        logger.info("Info (should not be shown)")
        logger.warn("Warn")
        logger.error("Error")

    logger.info("Info")
    logger.debug("Debug")
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:54:46.180595
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    configure()
    with logger_level(log, logging.INFO):
        log.debug('this is a debug message')
        log.info('this is an info message')
        log.error('this is an error message')
    log.info('your test passed')

test_logger_level()
# import nose; nose.runmodule()

# Generated at 2022-06-12 07:54:54.161783
# Unit test for function logger_level
def test_logger_level():
    # Get a logger
    logger = getLogger()
    # Check if Debug is not disabled
    assert logger.isEnabledFor(logging.DEBUG)
    # Set the logger level to INFO within a context block 
    with logger_level(logger, logging.INFO):
        # Check if Debug is now disabled
        assert not logger.isEnabledFor(logging.DEBUG)
    # Check if Debug is not disabled
    assert logger.isEnabledFor(logging.DEBUG)

if __name__ == '__main__':
    logger = getLogger('mike')
    logger.debug('mike')
    test_logger_level()

# Generated at 2022-06-12 07:55:03.058346
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    json_config = json.dumps(DEFAULT_CONFIG)
    yaml_config = yaml.dump(DEFAULT_CONFIG, default_flow_style=False)
    assert get_config(json_config) == DEFAULT_CONFIG
    assert get_config(yaml_config) == DEFAULT_CONFIG
    config = DEFAULT_CONFIG.copy()
    config['version'] = 2
    assert get_config(config) == config

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:55:07.356297
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.WARN):
        log.info('info')
        log.debug('debug')
        log.error('error')
    log.info('info')
    log.debug('debug')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:55:18.214069
# Unit test for function logger_level
def test_logger_level():
    import logging
    import q
    import q.logger

    def test_logger(records):
        def record_handler(record):
            records.append(record)

        record_handler.records = records

        return record_handler

    # Test that the logger level is info, and thus logging.DEBUG will be ignored.
    records = []
    q.logger.configure()
    test_logger = test_logger(records)
    q.logger.get_logger(__name__).parent.addHandler(test_logger)
    logger = q.logger.get_logger(__name__)
    logger.debug("debug")
    assert len(records) == 0

    # Test that the logger level is debug, and thus logging.DEBUG will be logged.
    records = []

# Generated at 2022-06-12 07:55:20.405754
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:55:24.983016
# Unit test for function get_config
def test_get_config():
    logging.config.dictConfig(DEFAULT_CONFIG)
    assert get_config(config='{"version": 1}') == {'version': 1}
    assert get_config(config='version: 1') == {'version': 1}


if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-12 07:55:34.180132
# Unit test for function logger_level
def test_logger_level():
    import logging
    from contextlib import contextmanager
    import io
    import contextlib
    import sys

    @contextmanager
    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)

# Generated at 2022-06-12 07:55:41.302751
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)

    # Test case 1: Block level is greater than INFO
    with logger_level(log, logging.DEBUG):
        log.debug('Test1 debug')
        log.info('Test1 info')

    # Test case 2: Block level is less than INFO
    with logger_level(log, logging.WARNING):
        log.debug('Test2 debug')
        log.info('Test2 info')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:55:51.811199
# Unit test for function configure
def test_configure():
    import json
    import tempfile

    with tempfile.NamedTemporaryFile(mode='w') as fp:
        json.dump(DEFAULT_CONFIG, fp)
        configure(fp.name)

    l = getLogger('tst')
    l.info('test')

    with logger_level(l, logging.DEBUG):
        l.debug('debug')
        l.info('info')
        l.warning('warning')
        l.error('error')
        l.critical('critical')

# Generated at 2022-06-12 07:55:55.080670
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    assert logger.level == logging.WARNING

    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR

    assert logger.level == logging.WARNING

# Generated at 2022-06-12 07:56:02.931532
# Unit test for function get_config
def test_get_config():
    '''
    >>> get_config('{}')
    {}
    >>> get_config('{ "a": 1, "b": "2" }')
    {'a': 1, 'b': '2'}
    >>> get_config('a: 1\\nb: 2')
    {'a': 1, 'b': 2}
    '''
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:56:14.097330
# Unit test for function get_config
def test_get_config():
    """Test function ``get_config``."""
    # Test for value error
    _config = None
    _env_var = None
    _default = None
    try:
        _config = get_config(_config, _env_var, _default)
    except ValueError:
        # Test for bare string(json)
        _config = '{"foo":"bar"}'
        _env_var = None
        _default = None
        assert isinstance(get_config(_config, _env_var, _default), dict)
        # Test for json string
        _config = '{"foo":"bar"}'
        _env_var = None
        _default = None
        assert isinstance(get_config(_config, _env_var, _default), dict)
        # Test for yaml string
        _config = 'foo: bar'


# Generated at 2022-06-12 07:56:18.969185
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("rabbit")

    @logger_level(logger, logging.WARNING)
    def foo():
        logger.debug("This shouldn't appear")
        logger.info("This shouldn't appear either")
        logger.warning("This should appear")

    foo()


# Generated at 2022-06-12 07:56:21.933008
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.info('You will not see this')
        logger.error('The log level is set to ERROR')


# Generated at 2022-06-12 07:56:25.478344
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.CRITICAL):
        assert log.getEffectiveLevel() == logging.CRITICAL
    assert log.getEffectiveLevel() != logging.CRITICAL


# TODO Is this actually useful?

# Generated at 2022-06-12 07:56:26.565227
# Unit test for function configure
def test_configure():
    log = get_logger()
    log.info('test')



# Generated at 2022-06-12 07:56:36.443423
# Unit test for function get_config
def test_get_config():
    from copy import copy
    from types import ModuleType


# Generated at 2022-06-12 07:56:43.180945
# Unit test for function get_config
def test_get_config():
    test_config1 = '{"version": 1, "disable_existing_loggers": false, "formatters": {"simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": "DEBUG"}}, "root": {"handlers": ["console"], "level": "DEBUG"}, "loggers": {"requests": {"level": "INFO"}}}'
    config1 = get_config(test_config1)

# Generated at 2022-06-12 07:56:51.139507
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('Should be logged')
        logger.info('Should not be logged :( ')

    logger.info('Should be logged!')


# Generated at 2022-06-12 07:56:54.020128
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.ERROR):
        logger.error('ok')
        logger.info('ok')


# Generated at 2022-06-12 07:56:57.699041
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()

    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR

    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:57:06.342653
# Unit test for function logger_level
def test_logger_level():
    log_level = logging.INFO
    msg = "test message"
    old_stdout = sys.stdout
    sys.stdout = open(os.devnull, 'w')
    log = get_logger(__name__)
    log.info(msg)
    sys.stdout.close()
    sys.stdout = old_stdout
    old_log_level = log.level
    log.level = log_level
    with logger_level(log, logging.CRITICAL):
        log.info(msg)
    log.level = old_log_level
    log.info(msg)


# end

# Generated at 2022-06-12 07:57:07.068966
# Unit test for function configure
def test_configure():
    configure()

# Generated at 2022-06-12 07:57:12.245733
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    cur_level = logger.level
    with logger_level(logger, logging.ERROR):
        assert logger.isEnabledFor(logging.ERROR)
        assert not logger.isEnabledFor(logging.WARNING)
        assert not logger.isEnabledFor(logging.DEBUG)
    assert logger.level == cur_level

# Generated at 2022-06-12 07:57:14.710658
# Unit test for function logger_level
def test_logger_level():
    import pytest

    with pytest.warns(DeprecationWarning):
        with logger_level(logging.getLogger(), logging.INFO):
            assert logging.getLogger().level == logging.INFO

# Generated at 2022-06-12 07:57:16.862182
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.isEnabledFor(logging.DEBUG)
    assert not log.isEnabledFor(logging.DEBUG)



# Generated at 2022-06-12 07:57:27.978459
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("test1")
    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO

    assert logger.level == logging.DEBUG
    return True


__all__ = [
    'configure',
    'get_config',
    'get_logger',
    'getLogger',
    'logger_level',
    'test_logger_level',
]


if __name__ == '__main__':
    configure()
    root = get_logger('root')

    logger = get_logger()
    logger.debug('This is a DEBUG message')
    logger.info('This is an INFO message')
    logger.warning('This is a WARNING message')
    logger.error('This is an ERROR message')


# Generated at 2022-06-12 07:57:33.622307
# Unit test for function get_config
def test_get_config():
    assert isinstance(get_config(DEFAULT_CONFIG), dict)

    env_var = 'LOGGING_VAR'
    os.environ[env_var] = "{'version': 1}"
    assert isinstance(get_config(default={}, env_var=env_var), dict)

    assert None is get_config(default=None, env_var=env_var)
    assert None is get_config(default=None)
    assert None is get_config(default=None, config=None)

    # TODO: This is broken until/unless we figure out how to get it to work in py2 AND py3
    # with pytest.raises(ValueError):
    #     get_config(default=None)

# Generated at 2022-06-12 07:57:44.508601
# Unit test for function get_config

# Generated at 2022-06-12 07:57:48.116718
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        assert logger.getEffectiveLevel() == logging.INFO
    assert logger.getEffectiveLevel() == logging.DEBUG



# Generated at 2022-06-12 07:57:57.490934
# Unit test for function get_config
def test_get_config():
    # check if get_config supports json
    json = '{"version": 1, "disable_existing_loggers": false, "formatters": {"simple": {"format": "%(levelname)s %(message)s", "datefmt": "%m-%d-%Y %H:%M:%S"}}}'
    config = get_config(config=json)
    assert config == {'version': 1, 'disable_existing_loggers': False, 'formatters': {'simple': {'format': '%(levelname)s %(message)s', 'datefmt': '%m-%d-%Y %H:%M:%S'}}}

    # check if get_config supports yaml

# Generated at 2022-06-12 07:57:59.175745
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, 50):
        logger.info("Test info level")
        logger.warning("Test warning level")
        logger.error("Test error level")
        logger.critical("Test critical level")


# Generated at 2022-06-12 07:58:01.602295
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(__name__), logging.DEBUG):
        assert getLogger(__name__).level == logging.DEBUG
    assert getLogger(__name__).level == logging.DEBUG



# Generated at 2022-06-12 07:58:10.586297
# Unit test for function logger_level
def test_logger_level():
    import time
    print('[test_logger_level start]')
    test_logger = get_logger(__name__)
    test_logger.info('[info msg]')
    test_logger.debug('[debug msg]')
    with logger_level(test_logger, logging.DEBUG):
        test_logger.info('[info msg]')
        test_logger.debug('[debug msg]')
    test_logger.info('[info msg]')
    test_logger.debug('[debug msg]')
    print('[test_logger_level end]')



# Generated at 2022-06-12 07:58:11.614606
# Unit test for function configure
def test_configure():
    configure()
    # assert
    pass



# Generated at 2022-06-12 07:58:17.375145
# Unit test for function logger_level
def test_logger_level():
    from StringIO import StringIO
    log = get_logger(__name__)
    buf = StringIO()
    ch = logging.StreamHandler(buf)
    log.addHandler(ch)
    with logger_level(log, logging.WARNING):
        log.info("whee")
        log.warning("boo")

    assert "whee" not in buf.getvalue()
    assert "boo" in buf.getvalue()
    log.removeHandler(ch)

# Generated at 2022-06-12 07:58:19.778160
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test_logger_level')
    with logger_level(log, logging.DEBUG):
        log.debug('This line should be visible')
    log.debug('This line should not be visible')

# Generated at 2022-06-12 07:58:27.636755
# Unit test for function logger_level
def test_logger_level():
    from mock import patch

    log = getLogger('test_logger_level')
    with patch.object(log, 'debug') as mock_debug:
        log.setLevel(logging.DEBUG)
        log.debug('debug message')
        assert mock_debug.called
    with patch.object(log, 'debug') as mock_debug:
        # the logger level is set to 10 instead of DEBUG
        log.setLevel(10)
        log.debug('debug message')
        assert not mock_debug.called
    with logger_level(log, logging.DEBUG):
        log.debug('debug message')
        assert mock_debug.called
    with logger_level(log, 10):
        log.debug('debug message')
        assert not mock_debug.called

# Generated at 2022-06-12 07:58:44.198094
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    from tempfile import NamedTemporaryFile

    logger = get_logger('logger_level_test')
    with NamedTemporaryFile(suffix='.log') as f:
        handler = logging.FileHandler(f.name)
        handler.setFormatter(logging.Formatter('%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s'))
        logger.addHandler(handler)

        logger.info('pre-change')

        with logger_level(logger, logging.INFO):
            logger.debug('in-change')

        logger.info('post-change')


# Generated at 2022-06-12 07:58:45.942540
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')



# Generated at 2022-06-12 07:58:50.517657
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.INFO)
        assert not logger.isEnabledFor(logging.DEBUG)
    assert logger.isEnabledFor(logging.DEBUG)

# Generated at 2022-06-12 07:58:55.766218
# Unit test for function logger_level
def test_logger_level():
    import logging

    # Create logger with a custom log level
    log = get_logger('test_logger_level')

    # Check default level
    assert log.level == logging.DEBUG

    # Change log level to INFO within context
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO

    # Check level is unchanged outside of context
    assert log.level == logging.DEBUG


# Generated at 2022-06-12 07:59:01.711079
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    from contextlib import contextmanager

    @contextmanager
    def supress_output():
        """Supress stdout and stderr for the duration of a with block."""
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = map(open, ['os.devnull'] * 2)
            yield
        finally:
            sys.stdout.close()
            sys.stderr.close()
            sys.stdout, sys.stderr = old_out, old_err

    configure()
    logger = get_logger()
    logger.info('initial')

# Generated at 2022-06-12 07:59:07.652695
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.CRITICAL):
        assert logger.getEffectiveLevel() == logging.CRITICAL
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.getEffectiveLevel() == logging.DEBUG


# Generated at 2022-06-12 07:59:10.628385
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)

    with logger_level(log, logging.INFO):
        log.info('level is INFO')
    log.info('level changed back!')


# Generated at 2022-06-12 07:59:20.037724
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    from textwrap import dedent


# Generated at 2022-06-12 07:59:27.232759
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('my-test-log')
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        logger.debug("hello")
        assert len(logger.handlers[0].buffer) == 0
        logger.info("hello")
        assert len(logger.handlers[0].buffer) == 1
        logger.warning("hello")
        assert len(logger.handlers[0].buffer) == 2
        logger.error("hello")
        assert len(logger.handlers[0].buffer) == 3
        logger.critical("hello")
        assert len(logger.handlers[0].buffer) == 4



# Generated at 2022-06-12 07:59:30.350271
# Unit test for function configure
def test_configure():
    logger = get_logger()

    with logger_level(logger, logging.DEBUG):
        logger.debug('test debug')
        logger.info('test info')
        logger.warning('test warning')
        logger.error('test error')
        logger.critical('test critical')

# Generated at 2022-06-12 07:59:54.281440
# Unit test for function logger_level
def test_logger_level():
    import logging
    from contextlib import contextmanager
    from logging import INFO
    from logging import ERROR
    from logging import WARNING
    from logging import DEBUG

    @contextmanager
    def debug_context(logger):
        with logger_level(logger, DEBUG):
            yield

    logger = get_logger(__name__)
    assert logger.level == INFO

    with debug_context(logger):
        assert logger.level == DEBUG

    assert logger.level == INFO

    with logger_level(logger, ERROR):
        assert logger.level == ERROR
        with logger_level(logger, WARNING):
            assert logger.level == WARNING

    assert logger.level == INFO



# Generated at 2022-06-12 08:00:05.597425
# Unit test for function get_config
def test_get_config():
    testcases = [
        {
            "config": {},
            "env_var": None,
            "expected": {},
        },
        {
            "config": None,
            "env_var": "LOGGING",
            "expected": DEFAULT_CONFIG,
        },
        {
            "config": None,
            "env_var": "LOGGING",
            "expected": DEFAULT_CONFIG,
            "default": {},
        }
    ]

    for testcase in testcases:
        config = testcase.get("config")
        env_var = testcase.get("env_var")
        expected = testcase.get("expected")
        default = testcase.get("default")

        result = get_config(config, env_var, default)
        assert result == expected


# Generated at 2022-06-12 08:00:09.953950
# Unit test for function logger_level
def test_logger_level():
    from newt.utils.logger import get_logger, logger_level
    logger = get_logger(__name__)
    logger.setLevel(10)
    assert logger.level == 10

    with logger_level(logger, 20):
        assert logger.level == 20

    assert logger.level == 10



# Generated at 2022-06-12 08:00:21.623580
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()

    # Create and start a thread which will log DEBUG messages
    def func():
        for i in range(3):
            print(logger.level)
            logging.debug('This should be ignored')
            time.sleep(0.1)

    thread = threading.Thread(target=func)
    thread.start()

    # You should see that the DEBUG messages are ignored
    print('With logger level of INFO, you should not see DEBUG messages')
    time.sleep(1)

    # Change the logger level to DEBUG and you should see the DEBUG messages
    with logger_level(logger, logging.DEBUG):
        print('With logger level of DEBUG, you should see DEBUG messages')
        print(logger.level)
        time.sleep(1)

    # You should see that the logger level has been reset to

# Generated at 2022-06-12 08:00:24.366025
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger()
    with logger_level(log, logging.DEBUG):
        log.debug('test')
    log.debug('test2')

# Generated at 2022-06-12 08:00:30.992915
# Unit test for function get_config
def test_get_config():
    cwd = os.path.abspath(os.path.dirname(__file__))
    dir_path = os.path.join(cwd, 'config')
    test_config_path = os.path.join(dir_path, 'test_config.json')
    test_config_path_2 = os.path.join(dir_path, 'test_config.yaml')

    # read config from arg
    config = get_config(config='{"test": "test_config"}')
    assert isinstance(config, dict)
    assert "test" in config
    assert config.get("test") == "test_config"

    # read config from json file
    config = get_config(config=test_config_path)
    assert isinstance(config, dict)
    assert "test" in config
    assert config

# Generated at 2022-06-12 08:00:34.919592
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')

    with logger_level(logger, logging.WARNING):
        logger.debug('this should not be shown')

    logger.info('this should be shown')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:00:38.507268
# Unit test for function logger_level
def test_logger_level():
    import logging
    from contextlib import contextmanager

    with logger_level(logging.getLogger('foo'), logging.INFO) as logger:
        logging.info('should get logged')
        with logger_level(logging.getLogger('foo'), logging.CRITICAL) as logger2:
            logging.info('should not get logged')
        logging.info('should get logged again')

# Generated at 2022-06-12 08:00:43.470456
# Unit test for function logger_level
def test_logger_level():
    """
    Ensure that logger_level sets the logger level properly.
    """
    from tempfile import TemporaryFile
    from logging import getLogger, INFO, DEBUG

    logger = getLogger()

    # Ensure that INFO level messages are not printed
    with logger_level(logger, INFO):
        logger.info('This line should not get printed')

    # Ensure that DEBUG level messages are printed
    with logger_level(logger, DEBUG):
        with TemporaryFile(mode="r") as tfile:
            logger.addHandler(logging.StreamHandler(stream=tfile))
            logger.debug('This line should get printed')
            tfile.seek(0)
            print(tfile.read())
            assert tfile.read() == 'This line should get printed\n'

# Generated at 2022-06-12 08:00:48.927332
# Unit test for function logger_level
def test_logger_level():
    print("Running logger_level test")
    logger = logging.getLogger("test_logger_level")
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug("logger_level test - printing debug message")
    assert logger.level == logging.NOTSET
    print("Logger_level test completed")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:01:40.000683
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler())
    logger.debug("This is a debug message")
    assert logger.level == logging.INFO
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug message")
        assert logger.level == logging.DEBUG
    logger.debug("This is a debug message")
    assert logger.level == logging.INFO

# if __name__ == '__main__':
#     import doctest
#     doctest.testmod()

# Generated at 2022-06-12 08:01:44.065164
# Unit test for function logger_level
def test_logger_level():
    log = get_logger("test")
    with logger_level(log, logging.INFO):
        log.debug("this should be ignored")
        log.info("this should be printed")
    log.debug("this should be printed")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:01:47.852584
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('unit-test')
    with logger_level(log, logging.INFO):
        log.debug('should not log')
        log.info('should log')
    log.debug('should not log')
    log.info('should log')
    return 0


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    exit(test_logger_level())

# Generated at 2022-06-12 08:01:51.701046
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('debug test')
    log.debug('debug test')
    with logger_level(log, logging.INFO):
        log.info('info test')

# Generated at 2022-06-12 08:01:55.576052
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    # Disable logging temporarily
    logger.setLevel(logging.CRITICAL)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.CRITICAL
    pass

# Generated at 2022-06-12 08:02:05.260076
# Unit test for function logger_level
def test_logger_level():
    config = dict(
        version=1,
        disable_existing_loggers=False,
        formatters={
            'simple': {
                'format': '%(message)s'
            },
        },
        handlers={
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
                'level': logging.DEBUG,
            },
        },
        loggers={
            'test': dict(handlers=['console'], level=logging.DEBUG),
        },
    )
    logging.config.dictConfig(config)
    logger = logging.getLogger('test')
    with logger_level(logger, logging.INFO):
        logger.debug('This message should not appear')
        logger.info('This message should appear')

# Generated at 2022-06-12 08:02:08.513237
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logger.level
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == level


# Generated at 2022-06-12 08:02:13.164079
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    import sys, os

    configure()

    logger = getLogger()
    assert logger.level == sys.maxsize, "The logger level should have been set to maxsize."

    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO, "The logger level should have been set to INFO."

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:02:18.390683
# Unit test for function logger_level
def test_logger_level():
    import cStringIO
    import sys
    import logging
    import logging.handlers
    import io

    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # Redirect stdout to a string object
    #old_stdout = sys.stdout
    #redirected_output = stdout = cStringIO.StringIO()
    redirected_output = sys.stdout = io.StringIO()
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    ch = logging.StreamHandler(stream = redirected_output)
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(formatter)

# Generated at 2022-06-12 08:02:21.271347
# Unit test for function configure
def test_configure():
    import logging
    import os
    #test print log to console
    configure()

    logger = logging.getLogger(__name__)
    logger.error('test_configure_error')
    logger.info('test_configure_info')



# Generated at 2022-06-12 08:03:54.345982
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    logging.config.dictConfig(DEFAULT_CONFIG)
    logger = logging.getLogger()

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == DEFAULT_CONFIG['root']['level']


# Generated at 2022-06-12 08:04:01.576513
# Unit test for function logger_level
def test_logger_level():
    l = logging.getLogger("test_logger_level")
    l.setLevel(logging.DEBUG)

    assert l.isEnabledFor(logging.DEBUG) == True
    with logger_level(l, logging.WARNING):
        assert l.isEnabledFor(logging.WARNING) == True
        assert l.isEnabledFor(logging.DEBUG) == False
    assert l.isEnabledFor(logging.DEBUG) == True

    # Also test that exceptions in the with block don't swallow the logger level change
    with pytest.raises(ZeroDivisionError):
        with logger_level(l, logging.WARNING):
            assert l.isEnabledFor(logging.WARNING) == True
            assert l.isEnabledFor(logging.DEBUG) == False
            1 / 0

# Generated at 2022-06-12 08:04:03.972579
# Unit test for function configure
def test_configure():
    configure()
    log = logging.getLogger(__name__)
    log.debug('test debug')
    log.info('test info')
    log.warning('test warning')



# Generated at 2022-06-12 08:04:11.932001
# Unit test for function configure
def test_configure():
    """
    >>> import tempfile, logging.config

    >>> temp_logging_ini_file = tempfile.NamedTemporaryFile(mode='w')
    >>> logging_configuration = """
    ... [loggers]

# Generated at 2022-06-12 08:04:15.262708
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    
    logger = logging.getLogger('test')
    logger.setLevel(logging.INFO)
    assert logger.isEnabledFor(logging.DEBUG) == False
    
    with logger_level(logger,logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG) == True

# Generated at 2022-06-12 08:04:16.794066
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARN):
        logger.debug("debug")
    logger.debug("debug")



# Generated at 2022-06-12 08:04:21.113254
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.CRITICAL):
        logger.debug('this should not be printed')
        logger.critical('this should be printed')
    logger.critical('this should be printed too')

# Generated at 2022-06-12 08:04:24.931989
# Unit test for function logger_level
def test_logger_level():
    import sys
    reload(sys)
    sys.setdefaultencoding('utf8')

    log = getLogger('test_logger_level')
    configure()

    with logger_level(log, 10):
        log.debug('debug - should not show')
        log.info('info - should not show')
        log.error('error - should not show')

    log.debug('debug - should show')
    log.info('info - should show')

# Generated at 2022-06-12 08:04:26.961840
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger("serial"), logging.DEBUG):
        logging.debug("debug level message")
    logging.debug("debug level message")

# Generated at 2022-06-12 08:04:32.717278
# Unit test for function logger_level
def test_logger_level():
    import StringIO
    import time
    import traceback
    from functools import wraps

    # A decorator that reraises exceptions.
    def reraise(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            try:
                fn(*args, **kwargs)
            except Exception as exc:
                print(exc)
                raise
        return wrapper

    class TimedExecution(object):
        """A context manager that times the execution time of its context block.

        This class is used to verify logger_level()

        - `name` is a str used to label the block.
        - `logger` is the logger being tested.
        """
        def __init__(self, name, logger):
            self.name = name
            self.logger = logger
