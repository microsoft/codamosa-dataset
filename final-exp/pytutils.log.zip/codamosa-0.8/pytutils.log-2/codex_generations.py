

# Generated at 2022-06-12 07:54:34.309043
# Unit test for function configure
def test_configure():
    import logging
    configure()
    log = logging.getLogger(__name__)
    log.info('test')



# Generated at 2022-06-12 07:54:42.787314
# Unit test for function get_config
def test_get_config():
    import json
    import os
    import logging

    config_json = '{"version": 1, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "colored", "level": 20}}}'
    config = get_config(config_json)
    assert(config == {'version': 1, 'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'colored', 'level': 20}}})

    config_yaml = 'version: 1\nhandlers:\n  console:\n    class: "logging.StreamHandler"\n    formatter: "colored"\n    level: 20\n'
    config = get_config(config_yaml)

# Generated at 2022-06-12 07:54:47.119181
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 07:54:51.110901
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    level = logger.level

    test_level = logging.INFO
    assert level != test_level

    with logger_level(logger, test_level):
        assert logger.level == test_level

    assert logger.level == level



# Generated at 2022-06-12 07:54:58.419712
# Unit test for function logger_level

# Generated at 2022-06-12 07:55:03.091960
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.info('This logger is set to debug')
        logger.debug('This is a debug log')
        logger.info('This is an info log')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:55:09.010195
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.ERROR):
        logging.info("This should be printed")
        logging.warn("This should not be printed")
    logging.info("This should be printed")
    logging.warn("This should be printed")
    with logger_level(logging.getLogger(), logging.CRITICAL):
        logging.info("This should not be printed")
        logging.warn("This should not be printed")
    logging.info("This should be printed")
    logging.warn("This should be printed")



# Generated at 2022-06-12 07:55:18.496474
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import logging

    config = dict(
        version=1,
        disable_existing_loggers=False,
        formatters={
            'stream': {
                'format': '%(asctime)s %(name)s %(levelname)s %(message)s'
            },
        },
        handlers={
            'file': {
                'class': 'logging.FileHandler',
                'filename': None,
                'formatter': 'stream',
                'level': logging.INFO,
            },
        },
        loggers={
            'root': {
                'handlers': ['file'],
                'level': logging.INFO,
            },
        },
    )

    fh = tempfile.TemporaryFile()
    config['handlers']['file']['filename'] = f

# Generated at 2022-06-12 07:55:22.000828
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(_namespace_from_calling_context())
    with logger_level(logger, logging.ERROR):
        logger.error('Test')
        logger.info('Test')
    logger.info('Test')
    logger.debug('Test')



# Generated at 2022-06-12 07:55:24.933556
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    logger.info('Test Start!')
    with logger_level(logger, logging.DEBUG):
        logger.debug('Just for Test')
    logger.info('Test End!')

# Generated at 2022-06-12 07:55:35.588109
# Unit test for function logger_level
def test_logger_level():
    import logging
    import StringIO

    class TestHandler(logging.Handler):
        def __init__(self):
            super(TestHandler, self).__init__()
            self.logs = StringIO.StringIO()

        def emit(self, record):
            self.logs.write(self.format(record))
            self.logs.write('\n')

    log = logging.getLogger(__name__)
    log.addHandler(TestHandler())

    with logger_level(log, logging.INFO):
        log.info('foo')
        log.debug('debug')
        assert 'foo' in log.handlers[0].logs.getvalue()
        assert 'debug' not in log.handlers[0].logs.getvalue()

    log.debug('debug')

# Generated at 2022-06-12 07:55:45.509918
# Unit test for function get_config
def test_get_config():
    # Config as string
    assert isinstance(get_config('{"a": 1}'), dict)
    assert get_config('{"a": 1}')['a'] == 1
    # Bad config
    assert isinstance(get_config(dict(a=1)), dict)
    assert get_config(dict(a=1))['a'] == 1
    assert isinstance(get_config(dict(a=1)), dict)
    assert get_config(dict(a=1))['a'] == 1
    # Invalid config
    try:
        get_config(1)
    except ValueError:
        pass
    else:
        assert False
    # Bad json
    try:
        get_config('{"a": 1')
    except ValueError:
        pass
    else:
        assert False

    # Yaml
    assert isinstance

# Generated at 2022-06-12 07:55:49.278735
# Unit test for function logger_level
def test_logger_level():
    import time, sys

    log = get_logger()
    log.info('1')
    with logger_level(log, logging.CRITICAL):
        log.info('2')
    log.info('3')


# Generated at 2022-06-12 07:55:56.195477
# Unit test for function logger_level
def test_logger_level():
    # Create a logger
    logger = logging.getLogger("test_logger_level")

    # Test with level set to DEBUG
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)

    # Test with level set to INFO
    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.INFO)

    # Test with level set to ERROR
    with logger_level(logger, logging.ERROR):
        assert logger.isEnabledFor(logging.ERROR)



# Generated at 2022-06-12 07:56:02.537960
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test')
    with logger_level(logger, logging.WARNING):
        # logger.setLevel(logging.WARNING)
        # logger.warning('warning message')
        # logger.debug('debug')
        pass
    # logger.setLevel(logging.DEBUG)
    logger.debug('debug')
    logger.info('info')



# Generated at 2022-06-12 07:56:09.008348
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test debug')
        logger.info('test info')
        logger.critical('test critical')
    logger.debug('test debug2')
    logger.info('test info2')
    logger.critical('test critical2')

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:56:13.638710
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
    logger.debug('debug')
    try:
        logger.info('info')
    except Exception:
        pass


# Generated at 2022-06-12 07:56:24.307830
# Unit test for function logger_level
def test_logger_level():
    import logging
    import tempfile
    logger = logging.getLogger()

    with tempfile.NamedTemporaryFile() as f:
        with logger_level(logger, logging.DEBUG):
            logging.debug('This goes to the debug log')
            logging.info('This goes to the info log')
            logging.warning('This goes to the warning log')

        with logger_level(logger, logging.WARNING):
            logging.debug('This goes nowhere')
            logging.info('This goes nowhere, either')
            logging.warning('This goes to the warning log')

    with open(f.name) as f:
        assert 'This goes to the debug log' in f.read()
        assert 'This goes to the info log' in f.read()
        assert 'This goes nowhere' not in f.read()

# Generated at 2022-06-12 07:56:33.007116
# Unit test for function logger_level
def test_logger_level():
    import unittest

    # Our logger
    logger = get_logger(__name__)
    logger.setLevel(logging.INFO)

    # The logger to be debugged
    test_logger = getLogger('test')

    # A class that tests the level settings
    class TestLoggerLevel(unittest.TestCase):

        def test_debug_logger(self):
            test_logger.setLevel(logging.INFO)
            self.assertEquals(logging.INFO, test_logger.level)

            with logger_level(test_logger, logging.DEBUG):
                self.assertEquals(logging.DEBUG, test_logger.level)

            self.assertEquals(logging.INFO, test_logger.level)


# Generated at 2022-06-12 07:56:41.680359
# Unit test for function logger_level
def test_logger_level():
    """
    Test that the logger_level contextmanager works as advertised.
    """
    default_level = get_logger().level
    with logger_level(get_logger(), logging.DEBUG):
        assert(get_logger().level == logging.DEBUG)
        with logger_level(get_logger(), logging.INFO):
            assert(get_logger().level == logging.INFO)
            with logger_level(get_logger(), logging.WARNING):
                assert(get_logger().level == logging.WARNING)
                with logger_level(get_logger(), logging.ERROR):
                    assert(get_logger().level == logging.ERROR)
            assert(get_logger().level == logging.WARNING)
        assert(get_logger().level == logging.INFO)

# Generated at 2022-06-12 07:56:55.954378
# Unit test for function logger_level
def test_logger_level():
    import io
    import tempfile
    import unittest

    logger = logging.getLogger("test.logger")
    log_file = os.path.join(tempfile.gettempdir(), "test_logger_level.log")
    handler = logging.FileHandler(log_file, mode='w')
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    # Check that log message is written
    logger.debug("This is a test")
    with open(log_file) as stream:
        log_text = stream.read()
        assert "This is a test" in log_text

    # After changing level to WARN, check that log message is NOT written
    with logger_level(logger, logging.WARN):
        logger.debug("This is a test")

# Generated at 2022-06-12 07:56:58.948653
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(__name__), logging.DEBUG):
        logging.getLogger(__name__).debug('Inside logger_level')


# Generated at 2022-06-12 07:57:09.595095
# Unit test for function logger_level
def test_logger_level():
    from unittest import TestCase, main
    import StringIO

    class Test(TestCase):
        def _logger_level(self, level):
            logger = get_logger()
            with logger_level(logger, level):
                # things should log
                logger.debug('debug')
                logger.info('info')
                logger.warning('warn')
                logger.error('error')
                logger.critical('critical')

                # but this shouldn't
                logger.log(logging.FATAL, 'fatal')

        def test_enabled_logger_level(self):
            with patch.object(sys.stderr, 'fileno') as fileno:
                fileno.return_value = -1

# Generated at 2022-06-12 07:57:12.693239
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    print(logger.level)
    with logger_level(logger, logging.DEBUG):
        print(logger.level)
    print(logger.level)



# Generated at 2022-06-12 07:57:15.443744
# Unit test for function configure
def test_configure():
    logging.basicConfig()
    logger = logging.getLogger(__name__)
    # logger.setLevel(logging.DEBUG)
    logger.info('test1')

    configure()
    logger.info('test2')
    assert True



# Generated at 2022-06-12 07:57:25.449700
# Unit test for function logger_level
def test_logger_level():
    # Fixture to be called inside the context manager
    def log_a_few_things():
        logger.info("This should still be logged")
        logger.debug("This should be suppressed by the logger_level context")
        logger.warning("This should still be logged")

    # Create basic config
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()

    # Check the default logging level
    assert logger.level == logging.DEBUG, "Default logging level should be DEBUG"

    # Log a few things
    logger.debug("1. This should be logged")
    log_a_few_things()
    logger.debug("2. This should be logged")

    # Check the logger's messages

# Generated at 2022-06-12 07:57:32.893458
# Unit test for function logger_level
def test_logger_level():
    import os
    import logging
    import unittest

    import contextlib_extras
    from contextlib_extras import logging_config

    class LoggerLevelTestCase(unittest.TestCase):
        def test_logger_level_change(self):
            file_name = '/tmp/logger_level_test_%s.txt' % os.getpid()
            with open(file_name, 'w') as output:
                # Set logging level to debug,
                # in the context of this with block.
                with contextlib_extras.logger_level(logging.root, logging.DEBUG):
                    # Now write some things to the log.
                    logging.debug('testing...')
                    logging.debug('another message')

                # The above messages should NOT be in the log file

# Generated at 2022-06-12 07:57:37.020058
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('print from DEBUG')
        logger.info('print from INFO')
    logger.error('print from ERROR')


# Generated at 2022-06-12 07:57:43.841441
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)

    levels = (
        logging.DEBUG,
        logging.INFO,
        logging.WARNING,
        logging.ERROR,
    )

    for level in levels:
        with logger_level(logger, level):
            logger.debug('this should not show')
            logger.info('this should not show')
            logger.warning('this should not show')
            logger.error('this should not show')

        logger.debug('this should show')
        logger.info('this should show')
        logger.warning('this should show')
        logger.error('this should show')

    with logger_level(logger, logging.DEBUG):
        for level in levels:
            logger.log(level, 'this should show')


if __name__ == '__main__':
    test_logger

# Generated at 2022-06-12 07:57:46.657067
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())
    logger.info('Logger is setup')
    with logger_level(logger, logging.INFO):
        logger.debug('This debug message should not be seen')
        logger.info('This info message should be seen')
    logger.debug('This debug message should be seen')
    logger.info('This info message should be seen')


# Generated at 2022-06-12 07:58:03.659719
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("test")
    with logger_level(logger, 30):
        assert logger.level == 30
    assert logger.level == 20

_LOGGER = get_logger()

debug = _LOGGER.debug
info = _LOGGER.info
warning = _LOGGER.warning
error = _LOGGER.error
exception = _LOGGER.exception
critical = _LOGGER.critical
log = _LOGGER.log


__all__ = [
    'get_logger',
    'getLogger',
    'configure',
    'get_config',
    'logger_level',
    'debug',
    'info',
    'warning',
    'error',
    'exception',
    'critical',
    'log',
]

# Generated at 2022-06-12 07:58:11.521536
# Unit test for function logger_level
def test_logger_level():
    """
    >>> from logging import NOTSET, DEBUG, INFO, WARNING, ERROR, CRITICAL
    >>> logger = getLogger()
    >>> with logger_level(logger, INFO):
    ...     logger.debug('test debug')
    ...     logger.info('test info')
    ...     logger.warning('test warning')
    ...     logger.error('test error')
    ...     logger.critical('test critical')
    test info
    test warning
    test error
    test critical
    >>> assert logger.level == NOTSET
    """



# Generated at 2022-06-12 07:58:20.337710
# Unit test for function logger_level
def test_logger_level():
    import logging
    import time
    import datetime
    logger = logging.getLogger(__name__)
    configure()
    #tests for logger_level()

    #the logging info should not occur because the logger level is set to error
    #within the logger_level context block.
    with logger_level(logger, logging.ERROR):
        logger.info("This is a test")

    #the logging info should occur because the logger level is set to debug
    #within the logger_level context block, and the logger.debug() occurs after
    #the above logger_level() context has been exited.
    with logger_level(logger, logging.DEBUG):
        logger.info("This is also a test")

    #the logging info should not occur because the logger level is set to debug
    #within the logger_level context block, and the logger.

# Generated at 2022-06-12 07:58:29.263603
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    logger.level = logging.INFO


# Generated at 2022-06-12 07:58:40.522945
# Unit test for function logger_level
def test_logger_level():
    import logging
    import tempfile
    import os

    fname = tempfile.mktemp()

    log = logging.getLogger("test_logger_level")
    log.setLevel(logging.DEBUG)

    fh = logging.FileHandler(fname)
    fh.setLevel(logging.DEBUG)

    formatter = logging.Formatter("%(levelname)s - %(message)s")
    fh.setFormatter(formatter)

    log.addHandler(fh)

    with logger_level(log, logging.INFO):
        log.debug("debug")
        log.info("info")

    with open(fname, "r") as fh:
        fstr = fh.read()

    os.remove(fname)

    assert "DEBUG - debug\nINFO - info"

# Generated at 2022-06-12 07:58:46.038855
# Unit test for function logger_level
def test_logger_level():
    import logging
    import unittest
    import collections

    class TestLoggerLevel(unittest.TestCase):
        def setUp(self):
            from io import StringIO
            self.old_stdout = sys.stdout
            sys.stdout = StringIO()
            self.logger = logging.getLogger('test')

        def test_logger_level__debug(self):
            self.logger.setLevel(logging.DEBUG)
            self.logger.debug('debug')
            self.logger.info('info')
            self.logger.warning('warning')
            self.logger.error('error')
            self.logger.critical('critical')
            result = sys.stdout.getvalue()
            self.assertEquals(5, len(result.split('\n')))

       

# Generated at 2022-06-12 07:58:54.618014
# Unit test for function logger_level
def test_logger_level():
    # Note: use log level WARNING here to make sure that other logging
    #       levels are temporarily turned off
    with logger_level(get_logger(), logging.WARNING):
        log = get_logger()
        assert log.level == logging.WARNING
        log.debug('Should not be printed')
        log.warning('Should be printed')
        log.error('Should be printed')

    with logger_level(get_logger(), logging.INFO):
        log = get_logger()
        assert log.level == logging.INFO
        log.debug('Should be printed')
        log.warning('Should be printed')
        log.error('Should be printed')

# Generated at 2022-06-12 07:58:58.468666
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, logging.WARNING):
        # Here we log a message to the file 'test.log'
        logger.debug('This message should go to the log file')
        logger.info('So should this')
        logger.warning('And this, too')
        logger.error('test_logger_level success!')

# Generated at 2022-06-12 07:59:08.332068
# Unit test for function get_config
def test_get_config():
    # Ensure does not raise with no params
    assert get_config()
    assert get_config(None)
    assert get_config(None, None)
    assert get_config(None, None, None)

    # Ensure can parse a json config

# Generated at 2022-06-12 07:59:11.223618
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.DEBUG):
        log.debug('A debug message.')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:59:27.862559
# Unit test for function get_config

# Generated at 2022-06-12 07:59:33.345506
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    configure()
    assert logger.level == logging.DEBUG, "Expected logger.level to be DEBUG"
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING, "Expected logger.level to be WARNING"
    assert logger.level == logging.DEBUG, "Expected logger.level to be DEBUG again"

# Generated at 2022-06-12 07:59:41.991505
# Unit test for function get_config
def test_get_config():
    logger = get_logger()
    logger.setLevel(logging.DEBUG)
    
    ## test config as a bare string
    config = 'test'
    cfg = get_config(given = config)
    assert cfg == 'test'

    ## test config as a json string
    config = '{"a": 1}'
    cfg = get_config(given = config)
    assert cfg == {'a': 1}

    ## test config as a yaml string
    config = 'a: 1'
    cfg = get_config(given = config)
    assert cfg == {'a': 1}
    
    ## test config as a bare string
    config = {'a': 1}
    cfg = get_config(given = config)
    assert cfg == {'a': 1}

# Generated at 2022-06-12 07:59:46.519408
# Unit test for function logger_level
def test_logger_level():
    logger1 = getLogger("test_logger_level")
    with logger_level(logger1, logging.DEBUG):
        assert logger1.isEnabledFor(logging.DEBUG)
        logger1.debug("Enabling the debug log")
    assert logger1.isEnabledFor(logging.INFO)


if __name__ == '__main__':
    import pytest

    pytest.main(__file__)

# Generated at 2022-06-12 07:59:52.120565
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.INFO):
        logger.debug('This message should not be displayed')
        logging.info('This message should be displayed')
    logger.debug('This message should be displayed')


__all__ = [
    'configure',
    'get_logger',
    'getLogger',  # gross, deprecated, backwards compat
    'logger_level',
]

# Generated at 2022-06-12 08:00:02.990020
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG
    # TODO Configure, too
    assert get_config({'a': 3}) == {'a': 3}

    assert get_config(default={'a': 1}) == {'a': 1}

    assert get_config(config=json.dumps({'a': 2})) == {'a': 2}
    assert get_config(config='{"a": 2}') == {'a': 2}

    assert get_config('{"b": 2}') == {'b': 2}
    assert get_config('''{"c":2}''') == {'c': 2}

    assert get_config(yaml.dump({'d': 2})) == {'d': 2}
    assert get_config('''d: 2''') == {'d': 2}

# Generated at 2022-06-12 08:00:12.107987
# Unit test for function get_config
def test_get_config():
    # test with None and should not raise any exceptions
    try:
        get_config(None)
    except Exception as e:
        print('test_get_config1 test failed')
        print(e)
        raise e

    # test with a string that cannot be decoded as json
    try:
        get_config('ss')
    except Exception as e:
        print('test_get_config2 test failed')
        print(e)
        raise e

    # test with a string that can be decoded as json
    try:
        get_config('{"a":"b"}')
    except Exception as e:
        print('test_get_config3 test failed')
        print(e)
        raise e

    # test with a string that is json with invalid value

# Generated at 2022-06-12 08:00:18.095444
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger('test')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test debug')
    with logger_level(logger, logging.ERROR):
        logger.debug('test debug')


_CURRENT_LEVEL = {}
_CURRENT_HANDLERS = {}



# Generated at 2022-06-12 08:00:21.908303
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)

    with logger_level(log, logging.INFO):
        log.error("this *shouldn't* be printed")

    # With this check, the error msg won't appear
    if log.level <= logging.ERROR:
        log.error("this *should* be printed")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:00:29.639576
# Unit test for function logger_level
def test_logger_level():
    # Heavily rely on colorlog to detect whether or not anything was logged.
    import colorlog
    formatter = colorlog.ColoredFormatter('%(reset)s')
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger = logging.getLogger('logger_level')
    logger.addHandler(handler)


# Generated at 2022-06-12 08:00:45.339185
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
        logger.debug('debug')
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 08:00:50.895831
# Unit test for function logger_level
def test_logger_level():
    """
    Random unit test for logger_level
    """
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        # should print
        logger.debug("debug works after setting to DEBUG")
        # should not print
        logger.info("info does not work after setting to DEBUG")
        # should still print
        logger.warning("warning works after setting to DEBUG")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:00:54.304634
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    if logger.level == logging.INFO:
        logging.debug('Test of logger_level starts')
        with logger_level(logger, logging.DEBUG):
            logging.debug('logger_level is working')
    else:
        logging.warning('logger_level is not tested')



# Generated at 2022-06-12 08:00:56.447031
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger()
    print(log.level)
    with logger_level(log, logging.DEBUG):
        print(log.level)
    print(log.level)

# Generated at 2022-06-12 08:01:01.383581
# Unit test for function logger_level
def test_logger_level():
    """
    >>> test_logger_level() # doctest: +ELLIPSIS
    31
    ...
    30

    """
    logger = get_logger()
    print(logger.level)
    with logger_level(logger, logging.CRITICAL):
        print(logger.level)
        return  # avoid printing the test's output
    print(logger.level)
    return

# Generated at 2022-06-12 08:01:08.879437
# Unit test for function logger_level
def test_logger_level():
    """
    >>> test_logger_level()

    """
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.INFO)
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    logger.addHandler(ch)
    logger.info('Foo')
    assert logger.level == logging.INFO
    with logger_level(logger, logging.DEBUG) as l:
        l.debug('Bar')
        assert l.level == logging.DEBUG
    logger.info('Baz')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:01:19.240069
# Unit test for function logger_level
def test_logger_level():
    # create logger
    logger = getLogger(__name__)

    # capture all loggers as list of str
    captured = []
    with captured_output() as (out, err):
        with logger_level(logger, logging.INFO):
            logger.debug("This should not be displayed.")
            logger.info("This should be displayed")

    captured.append(out.getvalue().strip())
    captured.append(err.getvalue().strip())
    assert captured == ["INFO:root:This should be displayed"], "logger_level: Captured output should be\nINFO:root:This should be displayed"


# Replacing stdlib implementation
import builtins
builtins.getLogger = get_logger



# Generated at 2022-06-12 08:01:24.383969
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import unittest

    logger = logging.getLogger('fake_logger')

    class Filter(logging.Filter):
        def filter(self, record):
            nonlocal seen
            seen = record.msg
            return True

    seen = None
    logger.addFilter(Filter())

    with logger_level(logger, logging.DEBUG):
        logger.debug('foo')
        assert seen == 'foo'

    logger.removeFilter(Filter())
    unittest.main()



# Generated at 2022-06-12 08:01:28.375899
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    logger = logging.getLogger('test_logger_level')

    with logger_level(logger, logging.DEBUG):
        logger.debug('Test of logger_level')
        logger.info('Test of logger_level')
        logger.error('Test of logger_level')

    logger.error('Test of logger_level')



# Generated at 2022-06-12 08:01:35.479937
# Unit test for function configure

# Generated at 2022-06-12 08:01:56.226978
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    import logging.handlers
    import random
    import string

    CONFIG = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "default": {
                "format": "[%(name)s] - %(message)s"
            }
        },
        "handlers": {
            "test": {
                "class": "logging.FileHandler",
                "formatter": "default",
                "filename": "test.log"
            }
        },
        "root": {
            "level": "DEBUG",
            "handlers": ["test"]
        }
    }

    log = logging.getLogger("test")
    logging.config.dictConfig(CONFIG)

    times = 10


# Generated at 2022-06-12 08:01:59.586897
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.WARNING



# Generated at 2022-06-12 08:02:06.678511
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger('logger_level')
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.debug('Debug message')
        logger.info('Info message')
        logger.warning('Warning message')
        logger.error('Error message')
        logger.critical('Critical Message')
    logger.debug('Debug message')
    logger.info('Info message')
    logger.warning('Warning message')
    logger.error('Error message')
    logger.critical('Critical Message')


# Generated at 2022-06-12 08:02:10.228751
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.DEBUG):
        # Cannot be used with the 'logging' module
        get_logger().debug("hi")
        with logger_level(get_logger(), logging.ERROR):
            get_logger().debug("hi")

test_logger_level()

# Generated at 2022-06-12 08:02:15.083580
# Unit test for function logger_level
def test_logger_level():
    import sys
    logger = logging.getLogger(__name__)
    logger.level = logging.ERROR
    logger.addHandler(logging.StreamHandler(sys.stdout))
    logger.info("info message when my logger level is ERROR")
    with logger_level(logger, logging.INFO):
        logger.info("info message when my logger level is INFO")
    logger.info("info message again when my logger level is ERROR")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:02:19.378925
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.debug("Before setting the logger level")
    with logger_level(logger, logging.INFO):
        logger.debug("This message is not shown")
        logger.info("This message is shown")
    logger.debug("After setting the logger level")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:02:28.042805
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    # Without this line, the unit test invokes a weird bug.
    log.setLevel(logging.DEBUG)

    log.debug("A")
    with logger_level(log, logging.WARNING):
        log.debug("B")
        log.info("C")
        log.warning("D")
        log.error("E")
        log.critical("F")
    log.debug("G")

    assert log.level == logging.DEBUG
    assert logger_level.__doc__


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:02:31.970511
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.WARNING):
        logger.warning('test warning')
        logger.info('test info')
        logger.debug('test debug')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:02:36.258623
# Unit test for function configure
def test_configure():
    """ Test configure function
    """
    import logging
    import os

    log = logging.getLogger(__name__)
    
    # Test if it is configured with a proper logger level
    configure()
    log.debug("test")
    assert log.level == logging.DEBUG

    # Test if it is configured after logging level changed from an env variable
    os.environ["LOGGING"] = '{"root":{"level":"INFO"}}'
    configure()
    log.debug("test")
    assert log.level == logging.INFO

# Generated at 2022-06-12 08:02:43.075321
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger("test_logger_level")
    configure("tests/config_test.yml")
    with logger_level(test_logger, logging.DEBUG):
        test_logger.debug("test_logger")
    with logger_level(test_logger, logging.INFO):
        test_logger.debug("test_logger")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:03:02.755734
# Unit test for function get_config
def test_get_config():
    config = """
    version: 1
    formatters:
        simple:
            format: '%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s'
            datefmt: '%Y-%m-%d %H:%M:%S'
    handlers:
        console:
            class: logging.StreamHandler
            formatter: simple
            level: DEBUG
    loggers:
        requests:
            level: INFO
    root:
        handlers: [console]
        level: DEBUG
    """
    given = get_config(config, None, None)

# Generated at 2022-06-12 08:03:06.015480
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("I am debug")
        log.info("I am info")
        log.error("I am error")
    log.debug("I am debug")
    log.info("I am info")
    log.error("I am error")


# Generated at 2022-06-12 08:03:15.149037
# Unit test for function logger_level
def test_logger_level():
    from pprint import pformat
    from collections import defaultdict

    log = get_logger(__name__)

    levels = [logging.DEBUG, logging.INFO, logging.WARN, logging.ERROR, logging.CRITICAL]
    messages = defaultdict(list)

    def collect(self, *args, **kwargs):
        messages[self.level].append(args[0])

    log.addHandler(logging.StreamHandler(collect))


# Generated at 2022-06-12 08:03:18.509924
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('logger_level_test')
    logger.debug('Before setting level')
    with logger_level(logger, logging.CRITICAL):
        logger.debug('Within test')
    logger.debug('After test')



# Generated at 2022-06-12 08:03:22.054060
# Unit test for function logger_level
def test_logger_level():
    import logging
    import time
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.WARNING):
        logger.setLevel(logging.DEBUG)
        assert logger.level == logging.DEBUG
        logger.debug('A debug message')
        logger.warning('A warning message')
        logger.error('An error message')

# Generated at 2022-06-12 08:03:25.642498
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)

    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
        logger.debug('Must not be printed')
        logger.critical('Must be printed')
    assert logger.level == logging.DEBUG
    logger.debug('Must be printed')



# Generated at 2022-06-12 08:03:29.595694
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger')
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.WARNING):
        logger.debug('Not seen')
        logger.warning('Seen')

    logger.debug('Seen')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:03:32.030504
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger')
    assert logger.level == 10

    with logger_level(logger, 20):
        assert logger.level == 20

    assert logger.level == 10

# Generated at 2022-06-12 08:03:41.148613
# Unit test for function logger_level
def test_logger_level():
    """Test function logger_level."""
    import time
    import os

    log_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_logger_level.log')


# Generated at 2022-06-12 08:03:48.379378
# Unit test for function configure
def test_configure():
    logger = get_logger("test_configure")
    logger.info("test_configure: info")
    logger.debug("test_configure: debug")
    with logger_level(logger, logging.INFO):
        logger.info("test_configure: info")
        logger.debug("test_configure: debug")

if __name__ == "__main__":
    test_configure()

# vim: et:sw=4:syntax=python:ts=4:sts=4:

# Generated at 2022-06-12 08:04:02.264575
# Unit test for function logger_level
def test_logger_level():
   log = get_logger()
   log.setLevel(logging.WARN)
   log.info('This is a test of logger_level')

   with logger_level(log, logging.DEBUG):
      log.info('Hello World!')
   log.info('Goodbye World!')



# Generated at 2022-06-12 08:04:06.461009
# Unit test for function logger_level
def test_logger_level():
    log = getLogger("pytoolbox.logging")

    def test_log_func():
        log.debug("this is test log")

    with logger_level(log, logging.DEBUG):
        test_log_func()
    with logger_level(log, logging.ERROR):
        test_log_func()
        # Unable to catch the exception, because the log level is ERROR

# Generated at 2022-06-12 08:04:12.582621
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.setLevel(logging.CRITICAL)
    with logger_level(logger, logging.DEBUG):
        logger.debug("DEBUG test")
        logger.info("INFO test")
        logger.warn("WARN test")
        logger.error("ERROR test")
        logger.critical("CRITICAL test")
    logger.debug("DEBUG test")
    logger.info("INFO test")
    logger.warn("WARN test")
    logger.error("ERROR test")
    logger.critical("CRITICAL test")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:04:14.549246
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert(log.level == logging.DEBUG)

    assert(log.level == logging.INFO)

# Generated at 2022-06-12 08:04:22.690781
# Unit test for function get_config
def test_get_config():
    try:
        get_config()
    except Exception as e:
        assert str(e) == 'Invalid logging config: None'

    try:
        get_config(config={})
    except Exception as e:
        assert str(e) == 'Invalid logging config: {}'

    try:
        get_config(config='test')
    except Exception as e:
        assert str(e) == 'Invalid logging config: test'

    test_json = '{"":""}'
    try:
        assert get_config(config=test_json) == {}
    except Exception as e:
        assert False

    test_json = '{"a":1}'
    try:
        assert get_config(config=test_json) == {'a': 1}
    except Exception as e:
        assert False


# Generated at 2022-06-12 08:04:28.589118
# Unit test for function logger_level
def test_logger_level():
    from logging import INFO, DEBUG
    logger = get_logger()
    level = logger.level
    assert(level == INFO)
    try:
        with logger_level(logger, DEBUG):
            assert(logger.isEnabledFor(DEBUG))
            assert(not logger.isEnabledFor(INFO))
            assert(logger.getEffectiveLevel() == DEBUG)
            msg = "This should be DEBUG"
            logger.debug(msg)
            logger.info(msg)
    except AssertionError as e:
        print("Failed: %s" % e)
        raise

if __name__ == '__main__':
    test_logger_level()