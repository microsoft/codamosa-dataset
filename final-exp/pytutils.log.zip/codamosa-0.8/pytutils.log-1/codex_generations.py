

# Generated at 2022-06-12 07:54:42.192199
# Unit test for function get_config
def test_get_config():
    if not _PyInfo.PY2:
        # Skip this test if in py2
        # str in py2 returns bytes
        # and json doesn't accept bytes
        import json

        config = get_config(
            default=DEFAULT_CONFIG,
            given=DEFAULT_CONFIG
        )


# Generated at 2022-06-12 07:54:49.695414
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger('test_logger_level'), logging.DEBUG):
        assert get_logger('test_logger_level').isEnabledFor(logging.DEBUG)
        assert get_logger('test_logger_level').isEnabledFor(logging.INFO)
        assert get_logger('test_logger_level').isEnabledFor(logging.WARNING)
        assert get_logger('test_logger_level').isEnabledFor(logging.ERROR)



# Generated at 2022-06-12 07:54:54.455787
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.CRITICAL):
        log.debug('debug message')
        log.info('info message')
        log.warning('warning message')
        log.error('error message')
        log.critical('critical message')


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:55:00.839262
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug("hello world") # should be emitted
        log.info("hello world")  # should not be emitted
        log.warning("hello world")  # should not be emitted

if __name__ == "__main__":
    configure()
    test_logger_level()

# Generated at 2022-06-12 07:55:03.373719
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET

# Generated at 2022-06-12 07:55:09.805899
# Unit test for function logger_level
def test_logger_level():
    import logging
    import json
    import uuid
    log = getLogger("test_logger_level")
    test_string = uuid.uuid4().hex
    log.setLevel(logging.INFO)
    try:
        with logger_level(log, 10):
            log.debug(test_string)
            log.info(test_string)
    except:
        pass
    else:
        raise Exception("Exception not raised")
    finally:
        log.setLevel(logging.DEBUG)

if __name__ == "__main__":
    # Run unit tests
    test_logger_level()

# Generated at 2022-06-12 07:55:12.058753
# Unit test for function logger_level
def test_logger_level():
    import logging
    import os


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:55:19.747543
# Unit test for function get_config
def test_get_config():
    # Pass in a valid JSON document
    config = get_config(
        default='{"version": 1, "formatters": {"simple": {"format": "%(asctime)s|%(levelname)s|%(message)s"}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": "DEBUG"}}, "root": {"handlers": ["console"], "level": "DEBUG"}, "loggers": {"requests": {"level": "INFO"}}}')
    assert config == DEFAULT_CONFIG
    # Pass a YAML document

# Generated at 2022-06-12 07:55:23.834276
# Unit test for function configure
def test_configure():
    # Clear the root logger
    rootLogger = logging.getLogger()
    for handler in rootLogger.handlers[:]:
        rootLogger.removeHandler(handler)
    # Configure
    configure()
    logger = logging.getLogger(__name__)
    logger.info('test')

# Generated at 2022-06-12 07:55:25.165536
# Unit test for function configure
def test_configure():
    try:
        configure()
    except Exception as e:
        print(e)

# Generated at 2022-06-12 07:55:32.296364
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logging.INFO

    # Set logging level to INFO
    with logger_level(logger, level):
        assert logger.level == level

    # Make sure the logger is back to the original level
    assert logger.level != level

# Generated at 2022-06-12 07:55:41.605753
# Unit test for function get_config
def test_get_config():
    print(get_config(given='{"version": 1, "formatters": {"simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}}, "handlers": {"console": {"class": "logging.StreamHandler", "level": "DEBUG", "formatter": "simple"}}, "loggers": {"requests": {"level": "INFO"}}, "root": {"level": "DEBUG", "handlers": ["console"]}}', default=DEFAULT_CONFIG))

# Generated at 2022-06-12 07:55:51.227554
# Unit test for function logger_level
def test_logger_level():
    footest = getLogger('foo')

    footest.critical('critical level')
    footest.error('error level')
    footest.warn('warn level')
    footest.info('info level')
    footest.debug('debug level')

    with logger_level(footest, 10):
        footest.critical('critical level after setting level with logger_level')
        footest.error('error level after setting level with logger_level')
        footest.warn('warn level after setting level with logger_level')
        footest.info('info level after setting level with logger_level')
        footest.debug('debug level after setting level with logger_level')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:55:57.919786
# Unit test for function logger_level
def test_logger_level():
    import random
    import string

    random.seed(1)

    log = get_logger('logger_level')
    log.setLevel(logging.INFO)
    logging.basicConfig()

    assert log.level == logging.INFO

    with logger_level(log, logging.WARNING):
        assert log.level == logging.WARNING
    assert log.level == logging.INFO

    with logger_level(log, logging.WARNING):
        log.info('Test message %s', ''.join(random.choice(string.ascii_uppercase) for i in range(10)))
        assert log.level == logging.WARNING
    assert log.level == logging.INFO

# Generated at 2022-06-12 07:56:02.004149
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('test')
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.NOTSET



# Generated at 2022-06-12 07:56:04.710742
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('should be logged')

    with logger_level(log, logging.INFO):
        log.debug('should not be logged')

# Generated at 2022-06-12 07:56:08.276978
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.INFO):
        assert logging.getLogger().getEffectiveLevel() == logging.INFO
    assert logging.getLogger().getEffectiveLevel() != logging.INFO

# Generated at 2022-06-12 07:56:13.285863
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.ERROR):
        log.error('something')
        log.warn('something')
        log.info('something')
        log.debug('something')
    log.info('something')


if __name__ == '__main__':
    print(get_logger())

# Generated at 2022-06-12 07:56:16.614244
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('Test')
    configure()
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
        log.info("Some INFO")

    assert log.level == logging.DEBUG



# Generated at 2022-06-12 07:56:21.665037
# Unit test for function configure
def test_configure():
    logging.getLogger(__name__).info('this should not be printed')
    configure()
    logging.getLogger('requests').info('this should not be printed')
    logging.getLogger(__name__).info('this should be printed')


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:56:26.312778
# Unit test for function configure
def test_configure():
    configure()
    assert logging.root.level != logging.NOTSET


# Generated at 2022-06-12 07:56:31.410714
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    log.setLevel(logging.ERROR)

    log.info('test')
    log.debug('test')

    with logger_level(log, logging.INFO):
        log.info('test')
        log.debug('test')

    log.info('test')
    log.debug('test')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:56:40.302743
# Unit test for function logger_level
def test_logger_level():
    my_logger = logging.getLogger('test_logger_level')
    my_logger.setLevel(logging.INFO)
    my_logger.addHandler(logging.StreamHandler())

    with logger_level(my_logger, logging.DEBUG):
        for lvl in (logging.ERROR, logging.WARN, logging.INFO, logging.DEBUG):
            my_logger.log(lvl, 'Message at %s level', lvl)

    # now at INFO level again
    my_logger.log(logging.ERROR, 'Message at ERROR level')
    my_logger.log(logging.INFO, 'Message at INFO level')
    my_logger.log(logging.DEBUG, 'Message at DEBUG level')


# Generated at 2022-06-12 07:56:44.864585
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    for level in ('INFO', 'DEBUG', 'ERROR'):
        with logger_level(logger, level):
            assert level == logging.getLevelName(logger.level)


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:56:50.821235
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('blah')
    with logger_level(logger, logging.WARN):
        logger.info('Yo!')
        assert logger.getEffectiveLevel() == logging.WARN
        logger.warning('Warned!')
        logger.error('Errord!')
    logger.info('Yo!')
    assert logger.getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-12 07:56:56.380679
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.info("Before changing the level")
    with logger_level(logger, logging.INFO):
        logger.nospam("nospam log message")
        logger.debug("debug log message")
        logger.info("info log message")
    logger.debug("After changing the level")
    with logger_level(logger, logging.DEBUG):
        logger.nospam("nospam log message")
        logger.debug("debug log message")
        logger.info("info log message")

# Generated at 2022-06-12 07:57:06.558089
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('testLogger')
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
        logger.debug('This is a debug log message')
        logger.info('This is an info log message')
        logger.error('This is an error log message')
        logger.warning('This is a warning log message')
        logger.critical('This is a critical log message')
    assert logger.level == logging.DEBUG
    logger.debug('This is a debug log message')
    logger.info('This is an info log message')
    logger.error('This is an error log message')
    logger.warning('This is a warning log message')
    logger.critical('This is a critical log message')



# Generated at 2022-06-12 07:57:12.285267
# Unit test for function logger_level
def test_logger_level():
    l = get_logger()
    with logger_level(l, logging.CRITICAL):
        l.debug('debug')
        l.info('info')
        l.warning('warning')
        l.error('error')
        l.critical('critical')

# TODO add tests for get_logger and configure.

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:57:16.479147
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test_logger_level')
    with logger_level(log, logging.DEBUG):
        log.info('test info')
        log.debug('test debug')
        with logger_level(log, logging.INFO):
            log.info('test info 2nd')
            log.debug('test debug 2nd')
        log.info('test info 3rd')
        log.debug('test debug 3rd')

# Generated at 2022-06-12 07:57:27.390806
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import tempfile
    tf = tempfile.NamedTemporaryFile(prefix="logger_level_test_", delete=True)
    log = get_logger(name=__file__)
    log.setLevel(logging.INFO)
    handler = logging.StreamHandler(tf)
    handler.setLevel(logging.INFO)
    log.addHandler(handler)

    with logger_level(logger=log, level=logging.DEBUG):
        log.debug("This should appear in the log but not be printed to stdout.")
    log.info("This should appear in the log and be printed to stdout.")
    tf.seek(0)
    target_string = "This should appear in the log but not be printed to stdout."
    log_contents = tf.read()

# Generated at 2022-06-12 07:57:39.592262
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()
    logger = getLogger('test')
    with logger_level(logger, logging.WARNING):
        logger.debug('I don\'t show up')
        logger.warning('I show up')

# Generated at 2022-06-12 07:57:42.661911
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.WARNING

# Generated at 2022-06-12 07:57:49.527658
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug test.")
    with logger_level(logger, logging.INFO):
        logger.debug("This is a debug test.")
        logger.info("This is an info test.")
    logger.debug("This is a debug test.")
    logger.info("This is an info test.")
    logger.warning("This is a warning test.")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:57:52.479554
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("test_logger_level")
    logger.propagate = False
    logger.setLevel(55)
    with logger_level(logger, 10):
        assert logger.level == 10
    assert logger.level == 55

# Generated at 2022-06-12 07:57:54.785974
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

log = get_logger(__name__)

# Generated at 2022-06-12 07:57:59.705582
# Unit test for function logger_level
def test_logger_level():
    l = logging.getLogger('test')
    l.setLevel(logging.WARNING)
    l.warning('warning')
    l.info('info')
    l.debug('debug')
    
    with logger_level(l, logging.INFO):
        l.info('info')
        l.debug('debug')
    # Back to normal
    l.info('info')
    l.debug('debug')

# Generated at 2022-06-12 07:58:04.802175
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()
    log = getLogger("test")
    with logger_level(log, logging.ERROR):
        with logger_level(log, logging.DEBUG):
            log.debug("test message 1")
            log.info("test message 2")
        log.debug("test message 3")
        log.info("test message 4")
    log.debug("test message 5")
    log.info("test message 6")



# Generated at 2022-06-12 07:58:11.568962
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    with logger_level(logger, logging.DEBUG):
        # Verify that the message is logged
        logger.warning('test_logger_level_1')
    with logger_level(logger, logging.INFO):
        # Verify that the message is not logged
        logger.debug('test_logger_level_2')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:58:15.390886
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()

    with logger_level(logger, logging.CRITICAL):
        logger.debug('DEBUG NOT printed')
        logger.info('INFO NOT printed')
        logger.warning('WARNING NOT printed')
        logger.error('ERROR printed')
        logger.critical('CRITICAL printed')



# Generated at 2022-06-12 07:58:22.704959
# Unit test for function get_config
def test_get_config():
    def f(c, e, d):
        assert get_config(c, e, d) == c

    f({}, '', {})
    f({}, None, {})
    f({}, '', None)
    f({'1': 2}, '', {})
    f({'1': 2}, None, {})
    f({'1': 2}, '', None)

    x = '{"abc": 111}'
    f(json.loads(x), '', {})
    f(json.loads(x), None, {})
    f(json.loads(x), '', None)

    y = 'abc: 111'
    z = {'abc': 111}
    assert get_config(y, None, None) == z
    assert get_config(y, None, DEFAULT_CONFIG) == z
   

# Generated at 2022-06-12 07:58:42.149381
# Unit test for function logger_level
def test_logger_level():
    import sys
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)
        assert logger.isEnabledFor(logging.INFO)
        assert logger.isEnabledFor(logging.WARNING)
        assert logger.isEnabledFor(logging.ERROR)
        assert logger.isEnabledFor(logging.CRITICAL)
        logger.debug('This message should not be printed.')
        logger.info('This message should not be printed.')
        logger.warning('This message should not be printed.')
        logger.error('This message should not be printed.')
        logger.critical('This message should not be printed.')

# Generated at 2022-06-12 07:58:53.255521
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = get_logger('test_logger_level')
    >>> with logger_level(logger, logging.DEBUG):
    ...     logger.info('showing %s', 'info')
    ...     logger.debug('showing %s', 'debug')
    ...
    showing debug
    showing info
    >>> with logger_level(logger, logging.INFO):
    ...     logger.debug('showing %s', 'debug')
    ...     logger.info('showing %s', 'info')
    ...

    showing info

    >>> with logger_level(logger, logging.FATAL):
    ...     logger.info('showing %s', 'info')
    ...     logger.debug('showing %s', 'debug')
    ...

    """



# Generated at 2022-06-12 07:58:56.211841
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    assert log.level == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG


# Generated at 2022-06-12 07:59:03.286926
# Unit test for function logger_level
def test_logger_level():
    import os
    os.environ['LOGGING'] = '{"loggers":{"test.logger_level": {"level":"WARNING"}}}'
    configure()

    logger = logging.getLogger('test.logger_level')

    import sys
    f = sys.stderr
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
    f.seek(0)
    assert f.read() != ''

    f.seek(0)
    f.truncate(0)

    logger.debug('debug message')
    f.seek(0)
    assert f.read() == ''


# TODO what if a module is loaded from a non-script?
# TODO should we log to a default file?

# TODO add support for plugins

# Generated at 2022-06-12 07:59:08.279247
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test_logger_level')
    default_level = log.level
    with logger_level(log, logging.DEBUG):
        assert log.getEffectiveLevel() == logging.DEBUG
    assert log.getEffectiveLevel() == default_level



# Generated at 2022-06-12 07:59:14.592732
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("test_logger_level_logger")
    with logger_level(logger, logging.CRITICAL):
        logger.error("This line should not appear.")

    with logger_level(logger, logging.INFO):
        logger.info("This line should appear.")
        logger.warning("This line should not appear.")

    logger.info("This line should appear.")
    logger.warning("This line should appear.")


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:59:17.611157
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.CRITICAL):
        logger.critical('critical')
        logger.info('info')


# Generated at 2022-06-12 07:59:21.486937
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger("test_logger_level")

    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR

    assert logger.level != logging.ERROR

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:59:24.278406
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()
    logger = get_logger('test_logger_level')

    with logger_level(logger, logging.INFO):
        logger.debug('this should be silent')
        logger.info('this should not be silent')

# Generated at 2022-06-12 07:59:27.340533
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("debug message")
        log.info("info message")
        log.warning("warning message")
        log.error("error message")
        log.critical("critical message")
    log.debug("debug message - not printed")
    log.info("info message - printed")


# Generated at 2022-06-12 07:59:49.017936
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug message')
        log.info('info message')
    log.info('info message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:59:53.745550
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    initial = logger.level
    assert initial == logging.WARNING, initial

    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.INFO)
        assert logger.isEnabledFor(logging.WARN)

    assert logger.level == initial
    assert not logger.isEnabledFor(logging.INFO)
    assert logger.isEnabledFor(logging.WARN)

# Generated at 2022-06-12 07:59:57.469453
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.ERROR):
        log.error('in test context')
        assert log.level == logging.ERROR

    # check if logging level has been restored.
    assert log.level == logging.DEBUG

# Generated at 2022-06-12 08:00:01.403721
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.info('logger_level')
        logger.debug('logger_level')



# Generated at 2022-06-12 08:00:11.189848
# Unit test for function configure
def test_configure():
    assert DEFAULT_CONFIG['formatters']['colored']['format'] == '%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s'
    assert DEFAULT_CONFIG['formatters']['colored']['datefmt'] == '%H:%M:%S'

# Generated at 2022-06-12 08:00:14.704999
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.INFO):
        logger.info('this should be logged')
        logger.debug('this should not be logged')


# Generated at 2022-06-12 08:00:25.630489
# Unit test for function get_config
def test_get_config():
    # Test for config == None
    print(get_config())
    # Test for config == None, but default is not None
    print(get_config(default=DEFAULT_CONFIG))
    # Test for config == None, but env_var is not None
    print(get_config(env_var='LOGGING'))
    # Test for config == a string, but not json or yaml
    print(get_config(DEFAULT_CONFIG))
    # Test for config == a string, but json
    print(get_config(json.dumps(DEFAULT_CONFIG)))
    # Test for config == a string, but yaml
    print(get_config(yaml.dump(DEFAULT_CONFIG)))

if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-12 08:00:28.095041
# Unit test for function logger_level
def test_logger_level():
    # import colorlog
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.info('This should be logged')
    logger.info('This shouldn\'t be logged')


# Generated at 2022-06-12 08:00:30.821353
# Unit test for function logger_level
def test_logger_level():
    l = logging.getLogger("level-test")
    l.setLevel(logging.DEBUG)
    with logger_level(l, logging.INFO):
        assert l.level == logging.INFO
    assert l.level == logging.DEBUG

getLogger.__test__ = False
logger_level.__test__ = False

# Generated at 2022-06-12 08:00:38.020418
# Unit test for function logger_level
def test_logger_level():
    import io
    import sys
    import pytest
    from contextlib import redirect_stdout
    from .configure import configure
    from . import get_logger

    log = get_logger(__name__)
    configure(config=dict(loggers=dict(
        test_logger_level=dict(level='DEBUG')
    )))
    # NOTE: I'm using a StringIO here instead of a StringIO to avoid some PrintCollector issues
    output = io.StringIO()
    with redirect_stdout(output), logger_level(log, logging.DEBUG):
        log.debug('Testing Debug...')
    assert "Testing Debug" in output.getvalue()
    output.close()

# Generated at 2022-06-12 08:01:16.796926
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()

    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
        log.debug('test')
    assert log.level == logging.DEBUG


# Example usage

# Generated at 2022-06-12 08:01:24.797840
# Unit test for function logger_level
def test_logger_level():
    # Configure logging so that we can actually see the logs
    configure()

    # Startup a logger
    log = getLogger()

    # Create a stream handler that we can use to capture the logged output
    import StringIO
    log_capture_string = StringIO.StringIO()
    ch = logging.StreamHandler(log_capture_string)
    log.addHandler(ch)

    # Make sure that the 'logger_level' context manager works
    # First, make sure the logger is set to log INFO
    current_level = logger_level(log, logging.INFO)
    assert log.level == logging.INFO

    # Now let's try the logger_level context manager, and make sure we can see a DEBUG log
    with logger_level(log, logging.DEBUG):
        log.debug("debug_log_is_visible")



# Generated at 2022-06-12 08:01:31.953723
# Unit test for function logger_level
def test_logger_level():
    logger.info("before")
    with logger_level(logger, logging.DEBUG):
        logger.info("during debug")
    logger.info("after")


if __name__ == "__main__":
    logger = get_logger()
    logger.debug("debug")
    logger.info("info")
    logger.warning("warn")
    logger.error("error")
    logger.critical("critical")
    logger.debug("debug")
    logger.info("info")
    logger.warning("warn")
    logger.error("error")
    logger.critical("critical")
    test_logger_level()

# Generated at 2022-06-12 08:01:38.390382
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    with logger_level(logger, logging.INFO):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warning('warning message')
    logger.error('error message')
    logger.critical('critical message')

# Generated at 2022-06-12 08:01:42.211136
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.ERROR):
        log.info("I'm not visible")
        log.error("I am visible")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:01:48.833892
# Unit test for function get_config
def test_get_config():
    cfg = get_config('{"version": 1}')
    assert cfg == {'version': 1}

    cfg = get_config('{"version": 1 }')
    assert cfg == {'version': 1}

    cfg = get_config('{"version": 1}', default={'version': 2})
    assert cfg == {'version': 1}

    cfg = get_config(None, default={'version': 3})
    assert cfg == {'version': 3}

    cfg = get_config(default={'version': 4})
    assert cfg == {'version': 4}

    cfg = get_config(None, default='{"version": 5}')
    assert cfg == {'version': 5}

    cfg = get_config('{"version": 6}', default='{"version": 7}')

# Generated at 2022-06-12 08:01:55.111003
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.info('logger level is INFO')
        assert logger.level == logging.INFO
        with logger_level(logger, logging.WARNING):
            logger.info('logger level is WARNING')
            assert logger.level == logging.WARNING
        logger.info('logger level is INFO again')
        assert logger.level == logging.INFO

# Generated at 2022-06-12 08:02:00.240514
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("logger_lvl")
    logger.setLevel(logging.DEBUG)
    logger.info("Before set to test level")
    # Set the level to test level
    with logger_level(logger, 10):
        logger.info("messge")
    logger.info("After set to original level")


# Generated at 2022-06-12 08:02:02.586095
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.info("test")

test_logger_level()

# Generated at 2022-06-12 08:02:05.193090
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("Hello")
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG


# Generated at 2022-06-12 08:03:10.705717
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    logger.setLevel(logging.INFO)
    logger.debug('this should not be shown')
    with logger_level(logger, logging.DEBUG):
        logger.debug('this should be shown')
    logger.debug('this should not be shown')

# Generated at 2022-06-12 08:03:16.761330
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    # Test that logging.warning is being captured by the logger set to WARNING
    test_log = logging.getLogger('test_logger_level')
    test_log.setLevel(logging.WARNING)
    stream_handler = logging.StreamHandler(sys.stdout)
    test_log.addHandler(stream_handler)

    with logger_level(test_log, logging.DEBUG):
        test_log.debug('debug')
        test_log.warning('warning')

    # We should have printed warning but not debug
    assert 'debug' not in sys.stdout.getvalue()
    assert 'warning' in sys.stdout.getvalue()
    sys.stdout.close()
    sys.stdout = sys.__stdout__



# Generated at 2022-06-12 08:03:22.588125
# Unit test for function logger_level
def test_logger_level():
    """Test logger_level"""
    import logging
    from contextlib import contextmanager
    logger = logging.getLogger(__name__)

    log_level = logger.getEffectiveLevel()
    logger.info("Before first context manager, level is %s.", log_level)
    with logger_level(logger, logging.ERROR):
        log_level = logger.getEffectiveLevel()
        logger.info("Inside first context manager, level is %s.", log_level)
    log_level = logger.getEffectiveLevel()
    logger.info("After first context manager, level is %s.", log_level)


# Generated at 2022-06-12 08:03:24.256573
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('should see')
    log.debug('should not see')

# Generated at 2022-06-12 08:03:32.384037
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    levels = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug("DEBUG")
    logger.level = logging.INFO
    with logger_level(logger, logging.DEBUG):
        for l in levels[0:-1]:
            getattr(logger, l.lower())(l.lower())
        logger.debug("DEBUG")
    assert logger.level == logging.INFO



# Generated at 2022-06-12 08:03:41.605994
# Unit test for function logger_level
def test_logger_level():
    config = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'default': {
                'format': '%(asctime)s %(levelname)s %(message)s'
            }
        },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'default',
                'level': logging.DEBUG
            },
        },
        'root': {
            'handlers': ['console'],
            'level': logging.DEBUG
        },
    }
    logging.config.dictConfig(config)

    log = logging.getLogger(__name__)

    log.info('outside the context block')
    with logger_level(log, 'WARNING'):
        log.info

# Generated at 2022-06-12 08:03:45.446737
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('logger_level')
    logger.info("This is an info message")
    with logger_level(logger, logging.WARN):
        logger.info("This is an info message")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:03:49.297379
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    assert log.level == logging.NOTSET
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.NOTSET

# Generated at 2022-06-12 08:03:53.007093
# Unit test for function logger_level
def test_logger_level():
    """Test function logger_level"""
    log = get_logger()
    with logger_level(log, logging.CRITICAL):
        assert log.getEffectiveLevel() == logging.CRITICAL
    assert log.getEffectiveLevel() == logging.DEBUG


# Generated at 2022-06-12 08:03:58.749178
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.ERROR):
        logger.info('1')
        logger.error('1')
        with logger_level(logger, logging.INFO):
            logger.info('2')
            logger.error('2')
        logger.info('3')
        logger.error('3')
    logger.info('4')
    logger.error('4')

if __name__ == '__main__':
    configure()

    test_logger_level()