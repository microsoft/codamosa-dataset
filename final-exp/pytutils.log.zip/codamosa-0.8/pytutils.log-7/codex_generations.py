

# Generated at 2022-06-12 07:54:31.602012
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    log.setLevel(logging.WARN)
    assert(log.level == logging.WARN)
    with logger_level(log, logging.DEBUG):
        assert(log.level == logging.DEBUG)
    assert(log.level == logging.WARN)

# Generated at 2022-06-12 07:54:41.298780
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    _logging = logging
    _sys = sys

    from contextlib import contextmanager
    from . import _trace
    from . import _util

    def test_logger_level(logger):
        @contextmanager
        def log_level(level):
            orig = logger.level
            logger.level = level
            try:
                yield
            finally:
                logger.level = orig

        levels = [
            (logging.DEBUG, 'debug'),
            (logging.INFO, 'info'),
            (logging.ERROR, 'error'),
            (logging.CRITICAL, 'critical'),
        ]
        for level, log_func in levels:
            with log_level(level):
                logger.debug('foo')
                logger.info('bar')

# Generated at 2022-06-12 07:54:45.659530
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("logger_level_test")
    with logger_level(logger, logging.DEBUG):
        assert(logger.level == logging.DEBUG)
    assert(logger.level != logging.DEBUG)

# Generated at 2022-06-12 07:54:55.282760
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    from contextlib import contextmanager

    # Get log file name
    with tempfile.NamedTemporaryFile('w+') as f:
        logfile = f.name

    # Construct log config
    log_config = dict(
        version=1,
        disable_existing_loggers=False,
        formatters={
            'f': {
                'format':
                    '%(levelname)s %(asctime)s %(name)s %(message)s',
            },
        },
        handlers={
            'file': {
                'class': 'logging.FileHandler',
                'formatter': 'f',
                'filename': logfile,
            },
        },
        root=dict(handlers=['file'], level='WARNING'),
    )
    # Write log

# Generated at 2022-06-12 07:54:58.365074
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug('test')


# Generated at 2022-06-12 07:55:01.860100
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert log.level == logging.DEBUG
    with logger_level(log, logging.CRITICAL):
        assert log.level == logging.CRITICAL
    assert log.level == logging.DEBUG


# Generated at 2022-06-12 07:55:10.062788
# Unit test for function logger_level
def test_logger_level():
    cfg = DEFAULT_CONFIG.copy()  # FIXME
    # Add "testu" logger to the config
    cfg["loggers"]["testu"] = {"handlers": ["logfile"],
                               "level": logging.DEBUG,
                               "propagate": True}
    cfg["handlers"]["logfile"] = {'class': 'logging.FileHandler',
                                  'filename': 'test.log',
                                  'mode': 'w',
                                  'formatter': 'simple',
                                  'level': logging.DEBUG}
    configure(cfg)
    log = logging.getLogger('testu')
    log.info('test info')         # should get logged
    log.debug('test debug')       # should not get logged

    # Now test with the context manager

# Generated at 2022-06-12 07:55:13.937374
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()
    log = get_logger()
    with logger_level(log, logging.DEBUG) as test_log:
        log.debug("This is a test")
    try:
        log.debug("This isn't a test, something is wrong")
    except:
        return True
    return False

# Generated at 2022-06-12 07:55:16.921946
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(__name__), logging.DEBUG):
        logger = get_logger(__name__)
        assert logger.level == logging.DEBUG, "Logger level should have been changed to DEBUG"



# Generated at 2022-06-12 07:55:20.242245
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.WARNING):
        log.debug('test_logger_level should be suppressed')

    with logger_level(log, logging.DEBUG):
        log.debug('test_logger_level should be emitted')

# Generated at 2022-06-12 07:55:34.610548
# Unit test for function logger_level
def test_logger_level():
    # Test for debug messages (not shown)
    logger = get_logger()
    with logger_level(logger, logging.DEBUG) as _:
        logger.debug("Test debug message")

    # Test for info messages (shown)
    logger = get_logger()
    with logger_level(logger, logging.INFO) as _:
        logger.info("Test info message")

    # Test for warning messages (shown)
    logger = get_logger()
    with logger_level(logger, logging.WARNING) as _:
        logger.warning("Test warning message")

    # Test for critical messages (shown)
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL) as _:
        logger.critical("Test critical message")



# Generated at 2022-06-12 07:55:38.199561
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.ERROR):
        log.error('Error message')
        log.info('Not printed')
        log.debug('Not printed')
    log.debug('Not printed')
    log.info('Printed')



# Generated at 2022-06-12 07:55:41.570852
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARN):
        logger.info('This should not be seen')
        logger.warn('This should be seen')
    logger.info('This should be seen')


# Generated at 2022-06-12 07:55:50.842394
# Unit test for function logger_level
def test_logger_level():
    logging.config.fileConfig('logging.conf')
    logger = logging.getLogger('test')
    with logger_level(logger, logging.DEBUG):
        logger.debug('logging.DEBUG')
        logger.info('logging.INFO')
        logger.warn('logging.WARN')
        logger.error('logging.ERROR')
        logger.critical('logging.CRITICAL')

    logger.debug('logging.DEBUG')
    logger.info('logging.INFO')
    logger.warn('logging.WARN')
    logger.error('logging.ERROR')
    logger.critical('logging.CRITICAL')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:55:55.938489
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.WARNING):
        logger.debug('debug')
        logger.info('info')
        assert logger.getEffectiveLevel() == logging.WARNING
        logger.warning('warning')
        logger.error('error')
        logger.critical('critical')

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:56:06.160072
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('test_logger_level')
    configure({'loggers' : {'test_logger_level': {'level': logging.DEBUG}}})
    with logger_level(log, logging.DEBUG):
        assert log.getEffectiveLevel() == logging.DEBUG
    assert log.getEffectiveLevel() == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.getEffectiveLevel() == logging.INFO
    assert log.getEffectiveLevel() == logging.DEBUG
    with logger_level(log, logging.WARNING):
        assert log.getEffectiveLevel() == logging.WARNING
        with logger_level(log, logging.ERROR):
            assert log.getEffectiveLevel() == logging.ERROR
        assert log.getEffectiveLevel() == logging.WARNING
    assert log.getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-12 07:56:13.061166
# Unit test for function logger_level
def test_logger_level():
    import StringIO
    sio = StringIO.StringIO()

    logger = get_logger()
    logger.addHandler(logging.StreamHandler(sio))

    with logger_level(logger, logging.DEBUG):
        logger.info("No")
        assert "No" in sio.getvalue()

    sio.truncate(0)

    logger.info("No")
    assert "No" not in sio.getvalue()



# Generated at 2022-06-12 07:56:16.761409
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config(json.dumps(DEFAULT_CONFIG))
    assert DEFAULT_CONFIG == get_config(yaml.dump(DEFAULT_CONFIG))

    with pytest.raises(ValueError):
        get_config()

# Generated at 2022-06-12 07:56:23.166951
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert log.getEffectiveLevel() == logging.DEBUG
    with logger_level(log, logging.ERROR):
        log.debug("log debug")
        assert log.getEffectiveLevel() == logging.ERROR
        log.error("log error")
        log.warn("log warn")
        log.info("log info")
        log.fatal("log fatal")
    assert log.getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-12 07:56:30.218650
# Unit test for function get_config
def test_get_config():
    given = '{"root": {"level": "notvalid", "handlers": ["console"]}}'
    with pytest.raises(ValueError):
        get_config(given)

    given = '{"version": 1, "root": {"level": 10, "handlers": ["console"]}}'
    cfg = get_config(given)
    assert cfg['root']['level'] == 10

    given = '{"version": 1, "root": {"level": "DEBUG", "handlers": ["console"]}}'
    cfg = get_config(given)
    assert cfg['root']['level'] == 10

    given = '{"version": 1, "root": {"level": "debug", "handlers": ["console"]}}'
    cfg = get_config(given)
    assert cfg['root']['level']

# Generated at 2022-06-12 07:56:39.320445
# Unit test for function configure
def test_configure():
    log = get_logger('test_configure')
    configure(default=DEFAULT_CONFIG)
    log.info('test_configure')

# Generated at 2022-06-12 07:56:50.299813
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('logger_level')
    initial = logger.level
    # This should not be logged.
    logger.debug('test_logger_level(): Initial level = ' + str(initial) +
        ', this was not logged')
    with logger_level(logger, logging.INFO):
        logger.debug('test_logger_level(): Level is ' + str(logger.level) +
            ', this was not logged')
        logger.info('test_logger_level(): Level is ' + str(logger.level) +
            ', this was logged')
        logger.error('test_logger_level(): Level is ' + str(logger.level) +
            ', this was logged')

# Generated at 2022-06-12 07:56:54.289690
# Unit test for function configure
def test_configure():
    import json
    import logging

    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)

    cfg = json.dumps(DEFAULT_CONFIG)
    configure(cfg)

    log.info('test configure')



# Generated at 2022-06-12 07:57:05.784114
# Unit test for function logger_level
def test_logger_level():
    bulk_logger = getLogger('bulk')
    debug_logger = getLogger('debug')
    info_logger = getLogger('info')

    bulk_logger.setLevel(logging.DEBUG)
    debug_logger.setLevel(logging.DEBUG)
    info_logger.setLevel(logging.INFO)    # This is the default

    assert bulk_logger.getEffectiveLevel() == logging.DEBUG
    assert debug_logger.getEffectiveLevel() == logging.DEBUG
    assert info_logger.getEffectiveLevel() == logging.INFO

    with logger_level(info_logger, logging.DEBUG):
        assert info_logger.getEffectiveLevel() == logging.DEBUG
    assert info_logger.getEffectiveLevel() == logging.INFO


# Generated at 2022-06-12 07:57:15.417736
# Unit test for function logger_level
def test_logger_level():
    import time
    import contextlib
    import logging
    import logging.config
    import logging.handlers

    test_log = logging.getLogger(__name__)


# Generated at 2022-06-12 07:57:17.533670
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    # Should be no output from test logger now.
    logger.debug('test')

# Generated at 2022-06-12 07:57:24.991152
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    log.setLevel(logging.DEBUG)
    log.debug('a debug message')

    # The following tells the logger to not bother
    # executing the info logging statement.
    with logger_level(log, logging.WARNING):
        log.info('an info message')

    # The debug message should get logged,
    # and the info message should fail to.
    # Prints:
    # DEBUG:test:a debug message
    # WARNING:test:an info message

# Generated at 2022-06-12 07:57:32.671752
# Unit test for function get_config
def test_get_config():
    """Unit test for function get_config.

    :return:
    """
    # Test None is accepted by get_config
    assert get_config(None) is None

    # Test get_config(dict)
    # Test the dict is returned
    assert get_config({}) == {}

    # Test get_config(str)
    json_str = '{"version": 1, "disable_existing_loggers": false}'
    # Test the dict is returned for json string
    assert get_config(json_str) == {"version": 1, "disable_existing_loggers": False}

    yaml_str = "version: '1'\ndisable_existing_loggers: false"
    # Test the dict is returned for yaml string

# Generated at 2022-06-12 07:57:35.885315
# Unit test for function get_config
def test_get_config():
    print('--- test_get_config ---')
    from pprint import pprint

    logging_config = get_config(default='{}')
    pprint(logging_config)



# Generated at 2022-06-12 07:57:41.492161
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    my_config = json.dumps(dict())
    config = get_config(my_config)
    assert isinstance(config, dict)
    config = get_config(json.dumps(dict(foo=1)))
    assert isinstance(config, dict)

    my_config = yaml.dump(dict())
    config = get_config(my_config)
    assert isinstance(config, dict)



# Generated at 2022-06-12 07:57:54.602096
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.debug('test')

    with logger_level(logger, logging.INFO):
        logger.debug('test') # Shouldn't be logged
        logger.info('test') # Shouldn't be logged

if __name__ == '__main__':
    configure()
    test_logger_level()

# Generated at 2022-06-12 07:57:56.738844
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
    log.debug('debug fail')

# Generated at 2022-06-12 07:57:59.093600
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO

# Generated at 2022-06-12 07:58:01.233017
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("Test debug message")
    log.info("Test info message")

# Generated at 2022-06-12 07:58:04.745303
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)

    # Enable info level
    with logger_level(logger, logging.INFO):
        logger.debug("This should not appear")
        logger.info("This should appear")

    # Enable warn level
    with logger_level(logger, logging.WARN):
        logger.debug("This should not appear")
        logger.info("This should not appear")
        logger.warn("This should appear")

# Generated at 2022-06-12 07:58:10.331493
# Unit test for function get_config
def test_get_config():
    try:
        get_config()
    except ValueError as e:
        assert "Invalid logging config: None" in str(e)
    try:
        get_config('invalid_json')
    except ValueError as e:
        assert "Could not parse logging config as bare, json, or yaml" in str(e)


# Generated at 2022-06-12 07:58:19.485189
# Unit test for function logger_level
def test_logger_level():
    """logger_level() is tested by this unit test.
    """
    test_logger = logging.getLogger(__name__)
    configure()
    test_logger.setLevel(logging.DEBUG)

    try:
        with logger_level(test_logger, logging.INFO):
            test_logger.debug("This should not be printed")
            test_logger.info("This should be printed")
            test_logger.error("This should be printed")
    except:
        test_logger.error("logging context manager failed")

    test_logger.debug("This should be printed")
    test_logger.info("This should be printed")
    test_logger.error("This should be printed")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 07:58:24.867365
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    original_level = logger.level
    logger.debug("Debug message should appear")
    with logger_level(logger, logging.ERROR):
        logger.debug("Debug message should not appear")
        logger.error("Error message should appear")
    logger.debug("Debug message should appear again")
    assert original_level == logger.level, "Logger became level ERROR"

if __name__ == '__main__':
    test_logger_level()
    print("Passed all tests")

# Generated at 2022-06-12 07:58:29.083484
# Unit test for function logger_level
def test_logger_level():
    loggger = getLogger()
    with logger_level(loggger, logging.DEBUG):
        loggger.debug('debug message')
        loggger.info('info message')
        loggger.warning('warning message')
        loggger.error('error message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 07:58:40.229241
# Unit test for function get_config

# Generated at 2022-06-12 07:58:57.442365
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, "INFO"):
        log.info("Test!")
        with logger_level(log, "CRITICAL"):
            log.debug("Test!")
            log.info("Test!")
            log.warning("Test!")
            log.error("Test!")
            log.critical("Test!")
        log.debug("Test!")
        log.info("Test!")
        log.warning("Test!")
        log.error("Test!")
        log.critical("Test!")


if __name__ == '__main__':
    import doctest

    doctest.testmod()
    test_logger_level()

# Generated at 2022-06-12 07:58:59.835561
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.info('Test debug level')
        log.debug('Test debug level')
    log.info('Test info level')
    log.debug('Test debug level')

# Generated at 2022-06-12 07:59:08.548026
# Unit test for function logger_level
def test_logger_level():
    logger1 = get_logger("test_logger_level")
    with logger_level(logger1, logging.DEBUG):
        logger1.debug("test_logger_level: This is a debug message")
        logger1.error("test_logger_level: This is an error message")


_formatter = ' '.join(
    [
        '[%(asctime)s]',
        '[%(name)s/%(process)d]',
        '%(message)s',
        '%(blue)s@%(funcName)s:%(lineno)d',
        '#%(levelname)s',
    ]
)



# Generated at 2022-06-12 07:59:15.532505
# Unit test for function logger_level
def test_logger_level():
    import time
    log = get_logger('test')
    log.setLevel(logging.ERROR)
    assert log.level == logging.ERROR, 'log.level = %s' % log.level
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO, 'log.level = %s' % log.level
        log.info('TEST')
    assert log.level == logging.ERROR, 'log.level = %s' % log.level

if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-12 07:59:20.850862
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET

# unit test for function get_logger

# Generated at 2022-06-12 07:59:27.099109
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    try:
        with logger_level(log, logging.INFO):
            with logger_level(log, logging.DEBUG):
                with logger_level(log, logging.ERROR):
                    log.info('Info')
                    log.debug('Debug')
                    log.error('Error')
                log.info('Info')
                log.debug('Debug')
                log.error('Error')
            log.info('Info')
            log.debug('Debug')
            log.error('Error')
    except Exception as e:
        raise e


# TODO move this back to event

# Generated at 2022-06-12 07:59:29.342848
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        pass
    logger.debug('This message must not show up')



# Generated at 2022-06-12 07:59:33.638718
# Unit test for function logger_level
def test_logger_level():
    """Unit test for function logger_level"""
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be logged")
    logger.debug("This shouldn't be")
test_logger_level()



# Generated at 2022-06-12 07:59:40.976358
# Unit test for function configure
def test_configure():
    import tempfile
    import json
    import logging

    with tempfile.NamedTemporaryFile() as f:
        logging.config.dictConfig(DEFAULT_CONFIG)
        log_before = logging.getLogger(__name__)
        log_before.debug('before')

        f.write(json.dumps(DEFAULT_CONFIG).encode('utf-8'))
        f.flush()

        configure(config=f.name)
        log_after = logging.getLogger(__name__)
        log_after.debug('after')

        assert log_before is not log_after



# Generated at 2022-06-12 07:59:47.189015
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        # Test that level has been set to CRITICAL
        assert logger.level == logging.CRITICAL, "Level has not been set to CRITICAL"
        logger.debug("Some debugging message")
        logger.info("Some informational message")
        logger.critical("Some critical message")
    # Test that level has been restored to the initial value
    assert logger.level == logging.DEBUG, "Level has not been restored to the initial value"


if __name__ == '__main__':
    sys.exit(test_logger_level())

# Generated at 2022-06-12 08:00:04.924270
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should log")
        logger.info("This should log")
        logger.warning("This should log")
        logger.error("This should log")
        logger.critical("This should log")
    logger.debug("This should not log")
    logger.info("This should not log")
    logger.warning("This should not log")
    logger.error("This should not log")
    logger.critical("This should not log")


L = get_logger()

# Generated at 2022-06-12 08:00:12.576465
# Unit test for function get_config
def test_get_config():
    config = get_config(given={'a': 'b'})
    assert config == {'a': 'b'}

    config = get_config(env_var='LOGGING', default={'a': 'b'})
    assert config == {'a': 'b'}

    assert get_config(env_var='') == DEFAULT_CONFIG

    config = get_config(
        given='{"a": "b"}',
        env_var='LOGGING',
        default={'a': 'b'}
    )
    assert config == {'a': 'b'}

    config = get_config(
        given='a: b',
        env_var='LOGGING',
        default={'a': 'b'}
    )
    assert config == {'a': 'b'}


# Unit

# Generated at 2022-06-12 08:00:16.019305
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.DEBUG):
        # do stuff that should fail without raising an exception
        raise Exception('Should not raise exception, logging level is DEBUG.')

# Generated at 2022-06-12 08:00:23.390428
# Unit test for function logger_level
def test_logger_level():
    class FakeLogger(object):
        level = logging.INFO
        def setLevel(self, level):
            self.level = level
        def getEffectiveLevel(self):
            return self.level

    logger = FakeLogger()

    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG

    assert logger.getEffectiveLevel() == logging.INFO



# Note this only tests that the logging module is importable, not that any particular setup will work

# Generated at 2022-06-12 08:00:30.463120
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.info('foo')
    with logger_level(logger, logging.ERROR):
        logger.info('bar')


# class LogLevelTimer(object):
#     name = None
#     logger = None
#     reset_level = None
#
#     def __init__(self, name='logging.timer'):
#         self.name = name
#
#     def __enter__(self):
#         self.logger = getLogger(self.name)
#         self.reset_level = self.logger.level
#         self.logger.level = logging.DEBUG
#         return self.logger
#
#     def __exit__(self, *args):
#         self.log

# Generated at 2022-06-12 08:00:34.360607
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    logger.debug('before')
    with logger_level(logger, logging.ERROR):
        logger.debug('during')
    logger.debug('after')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-12 08:00:36.441167
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG

# Generated at 2022-06-12 08:00:39.382643
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = getLogger('test_logger_level')
    >>> logger.debug('level is DEBUG')
    >>> with logger_level(logger, logging.INFO):
    ...     logger.debug('level is INFO')
    >>> logger.debug('level is DEBUG')
    """



# Generated at 2022-06-12 08:00:43.603161
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging, logging.WARN):
        logging.critical("critical level logging")
        logging.error("error level logging")
        logging.warn("warn level logging")
        logging.info("info level logging")
        logging.debug("debug level logging")



# Generated at 2022-06-12 08:00:46.587470
# Unit test for function logger_level
def test_logger_level():
    from mock import MagicMock
    logger = MagicMock()
    logger.level = logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO



# Generated at 2022-06-12 08:01:04.323850
# Unit test for function logger_level
def test_logger_level():
    # The test logger is configured such that it will not output messages with
    # level less than or equal to logging.WARNING.
    test_logger = getLogger('test_logger_level')

    # The log message below should not be output.
    test_logger.info('fudge')

    # The log message below should be output.
    with logger_level(test_logger, logging.CRITICAL):
        test_logger.info('fudge')


# Generated at 2022-06-12 08:01:08.169474
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"version": 1, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "colored", "level": "DEBUG"}}}', env_var=None, default=None)
    assert(config['version'] == 1)


# Generated at 2022-06-12 08:01:11.032988
# Unit test for function logger_level
def test_logger_level():
    import time
    import random
    import logging

    log = logging.getLogger(__name__)
    log.warning('Warning before context manager')

    with logger_level(log, logging.DEBUG):
        log.warning('Warning in context manager')
        log.info('Info in context manager')

    log.warning('Warning after context manager')


# Generated at 2022-06-12 08:01:22.121101
# Unit test for function get_config
def test_get_config():
    import unittest
    class TestLoggingConfig(unittest.TestCase):
        def test_get_config(self):
            """
            Test get_config function
            """
            import yaml
            yaml_string = '''
                handlers:
                    - class: StreamHandler
            '''
            yaml_dict = yaml.load(yaml_string)
            self.assertEqual(get_config(config=yaml_string), yaml_dict)
            self.assertEqual(get_config(config=yaml_dict), yaml_dict)
            self.assertEqual(get_config(default=yaml_dict), yaml_dict)
            self.assertRaises(ValueError, get_config)
    unittest.main()

# if __name__ == '__main__':


# Generated at 2022-06-12 08:01:28.168644
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.WARNING):
        logger.warning("test warning")
        logger.info("this won't be logged")
    logger.info("this will be logged")
    return True

if __name__ == '__main__':
    test_logger_level()
    get_logger().info('test')
    get_logger('test2').info('test2')
    # import doctest
    # doctest.testmod()

# Generated at 2022-06-12 08:01:35.345425
# Unit test for function get_config
def test_get_config():
    import json
    import yaml
    # invalid config
    invalid_config = None
    doc = "Invalid logging config"
    try:
        get_config(invalid_config)
    except ValueError as e:
        assert str(e) == doc
    # json

# Generated at 2022-06-12 08:01:45.208895
# Unit test for function get_config
def test_get_config():
    # test get_config with given
    assert get_config({"a":"b"}) == {"a":"b"}
    assert get_config({"a": "b"}, env_var="LOGGING") == {"a":"b"}
    assert get_config({"a": "b"}, default={"c":"d"}) == {"a":"b"}
    # test get_config with env_var
    os.environ["LOGGING"] = '{"a":"b"}'
    assert get_config(env_var="LOGGING") == {"a":"b"}
    assert get_config(env_var="LOGGING", default={"c":"d"}) == {"a":"b"}
    # test get_config with default
    assert get_config(default={"a":"b"}) == {"a":"b"}

# Generated at 2022-06-12 08:01:51.699529
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    # set initial level
    log.setLevel(logging.WARNING)
    log.warning('this is a warning')
    log.info('this is an info')
    with logger_level(log, logging.DEBUG):
        log.info('this is an info')
        log.debug('this is a debug')
    log.warning('this is a warning')


if __name__ == '__main__':
    configure()
    test_logger_level()

# Generated at 2022-06-12 08:01:56.582282
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    log.info("this should show up")
    with logger_level(log, logging.ERROR):
        log.debug("this should not show up")
        try:
            raise Exception()
        except Exception:
            log.exception("this should not have a stack trace")
    log.info("this should show up as well")


_DEFAULT_NAMESPACE = None



# Generated at 2022-06-12 08:02:04.719365
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger_level')
    logger.setLevel(logging.DEBUG)
    try:
        logger.info('test')
        assert False, 'test_logger_level must fail'
    except AttributeError as exc:
        pass
    else:
        assert False, 'test_logger_level must fail'
    with logger_level(logger, logging.INFO):
        logger.info('test')
    try:
        logger.info('test')
        assert False, 'test_logger_level must fail'
    except AttributeError as exc:
        pass
    else:
        assert False, 'test_logger_level must fail'

# Generated at 2022-06-12 08:02:19.626534
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    level = logging.DEBUG

    # logger level should be set to logging.DEBUG
    with logger_level(logger, level):
        assert logger.level == level

    # logger level should revert back to initial level
    assert logger.level == logging.DEBUG


# Generated at 2022-06-12 08:02:27.232454
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert log.level == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG

# logging.config doesn't like when we try to override the root logger.
# Since we sort of want to do that, we're going to have to monkeypatch
# that part of it out of existence.
#
# https://stackoverflow.com/questions/19899354/
import logging.config



# Generated at 2022-06-12 08:02:31.893771
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.ERROR):
        with logger_level(log, logging.CRITICAL):
            log.error('This should not print')
            log.critical('This should print')

        log.error('This should print')
        log.critical('This should print')

    log.error('This should print')
    log.critical('This should print')



# Generated at 2022-06-12 08:02:36.387305
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.CRITICAL):
        logger.critical('critical test')
    '''
    This will cause the exception.
    logger.info('info test')
    logger.error('error test')
    logger.warning('warn test')
    '''
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug test')
    logger.info('info test')
    logger.error('error test')


if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-12 08:02:42.905116
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()

    logger.setLevel(logging.DEBUG)
    logger.debug('debug')
    logger.info('info')

    with logger_level(logger, logging.INFO):
        logger.debug('debug')
        logger.info('info')

    logger.setLevel(logging.DEBUG)
    logger.debug('debug')


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:02:46.440745
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("test_logger_level")
    logger.info("test_logger_level")  # test_logger_level should fail without this line
    with logger_level(logger, logging.ERROR):
        logger.info("test_logger_level")  # should not print anything



# Generated at 2022-06-12 08:02:52.117207
# Unit test for function logger_level
def test_logger_level():
    # Check that the logger_level context manager actually works by creating a logger, setting the logger to log critical
    # messages only, and then logging a normal message inside the context manager. We should see the normal message and
    # not an error occurrence.
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.CRITICAL):
        logger.info('test_logger_level')

    # TODO: Add test for the error case, where a non-critical log message is logged inside a context manager where the
    # logger is only setup to log critical errors.



# Generated at 2022-06-12 08:03:00.263637
# Unit test for function logger_level
def test_logger_level():
    import pytest
    from colorlog import ColoredFormatter
    from tempfile import mkdtemp
    from os import path
    from shutil import rmtree
    from time import sleep
    # Set up some logging
    temp_dir = mkdtemp()
    logfile = path.join(temp_dir, 'logfile')
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    file_handler = logging.FileHandler(logfile)
    formatter = ColoredFormatter(
        "%(log_color)s%(levelname)s%(reset)s:%(name)s:%(message)s"
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    # Make assertions

# Generated at 2022-06-12 08:03:02.484434
# Unit test for function logger_level
def test_logger_level():
    LOG = get_logger(__name__)
    with logger_level(LOG, logging.DEBUG):
        assert LOG.level == logging.DEBUG

# Generated at 2022-06-12 08:03:06.846912
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    LOG_NAME = 'test_logger_level'
    log = get_logger(LOG_NAME)
    with tempfile.TemporaryFile() as t:
        with logger_level(log, logging.DEBUG):
            log.debug('debug')
            log.info('info')

        log.info('info')
        t.close()

    with open(t.name, 'r') as f:
        assert f.readlines() == ['debug\n', 'info\n']