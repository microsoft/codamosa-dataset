

# Generated at 2022-06-26 02:26:00.607345
# Unit test for function logger_level
def test_logger_level():
    # test_logger_level_1
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    # test_logger_level_2
    print(log.level)



# Generated at 2022-06-26 02:26:07.055207
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.isEnabledFor(logging.DEBUG)
    assert not log.isEnabledFor(logging.DEBUG)
    with logger_level(log, logging.INFO):
        assert log.isEnabledFor(logging.INFO)
    assert not log.isEnabledFor(logging.INFO)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:26:10.853949
# Unit test for function get_config
def test_get_config():
    var_1 = get_config(None)
    assert var_1 == DEFAULT_CONFIG



# Generated at 2022-06-26 02:26:19.687242
# Unit test for function logger_level
def test_logger_level():
    # nopep8
    import unittest as ut

    class TestCase(ut.TestCase):  # nopep8
        pass

    # nopep8
    def test_case_0():
        logger = get_logger()
        with logger_level(logger, logging.DEBUG) as ctx:
            assert logger.level == logging.DEBUG  # nopep8

        assert logger.level != logging.DEBUG  # nopep8

    # nopep8
    test_case__prefix = "test_"
    locals__ = locals()
    for k, v in locals__.items():
        if k.startswith(test_case__prefix):
            print(k)
            setattr(TestCase, k, v)
    ut.main()  # nopep8



# Generated at 2022-06-26 02:26:23.452461
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger()
    with logger_level(log, logging.DEBUG):
        print(log.level)
        log.debug("debug")
        log.info("info")
    print(log.level)
    log.debug("debug")



# Generated at 2022-06-26 02:26:27.451967
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    logger.level = logging.DEBUG
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
    assert logger.level == logging.DEBUG
    # Test an exception gets swallowed and the level restored
    try:
        with logger_level(logger, logging.ERROR):
            assert logger.level == logging.ERROR
            raise ValueError
    except ValueError:
        pass
    assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:26:29.692319
# Unit test for function get_config
def test_get_config():
    assert var_0 == DEFAULT_CONFIG
    print("Test: get_config PASSED")



# Generated at 2022-06-26 02:26:35.058228
# Unit test for function logger_level
def test_logger_level():
    # Create a test logger
    logger = logging.getLogger(__name__)

    with logger_level(logger, logging.DEBUG):
        # Write log message with DEBUG level
        logger.debug('DEBUG message')

    # Check if logger level is set back to  initial value
    #assert logger.level == logging.INFO, 'Logger level is not set to INFO'


# Generated at 2022-06-26 02:26:38.992702
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger('test_logger'), logging.INFO):
        logging.debug('test')
        logging.info('test')
        logging.warning('test')
        logging.error('test')
        logging.critical('test')
    logging.debug('test')



# Generated at 2022-06-26 02:26:42.862858
# Unit test for function configure
def test_configure():
    configure(logging_config_dict)
    var_0 = logging.getLogger(__name__)
    var_0.info('test')


# Generated at 2022-06-26 02:26:56.709831
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    with logger_level(log, logging.ERROR):
        log.info('test')


# print(get_config(default='{"version": 1, "disable_existing_loggers": False, "loggers": {"__main__": {"level": 10, "handlers": ["console"]}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "colored", "level": 20}}, "formatters": {"simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%

# Generated at 2022-06-26 02:27:02.696627
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    try:
        logging.basicConfig(stream = sys.stdout)
        logger = logging.getLogger()
        logger.setLevel(logging.DEBUG)
        with logger_level(logger, logging.WARNING):
            logger.warning('This is a warning')

    except Exception:
        raise 



# Generated at 2022-06-26 02:27:08.030835
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.DEBUG):
        print('foo')

    print('bar')
    # Expected:
    # 2017-05-29 23:52:34,689| root/MainProcess-MainThread: foo @test_logger_level:23 #DEBUG
    # 2017-05-29 23:52:34,689| root/MainProcess-MainThread: bar @test_logger_level:25 #INFO



# Generated at 2022-06-26 02:27:14.843311
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, 20):
        assert logger.level == 20
    assert logger.level == 10

if __name__ == '__main__':
    configure()
    logger = get_logger()
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, 20):
        assert logger.level == 20
    assert logger.level == 10

# Generated at 2022-06-26 02:27:22.999505
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    import logging
    import logging.config
    import os

    # Assuming we want same configuration for test environment and prod environment
    configure(os.environ['LOGGING_CONF'])
    log = logging.getLogger('test2')

    # Logs by default to level INFO
    log.info('This is an INFO log')
    log.debug('This is a DEBUG log')

    # Using logger_level context manager in case we want to change the level of a logger within a context
    with logger_level(log, logging.DEBUG) as l:
        l.debug('This is an INFO log too')
        l.info('This is an INFO log too')

# Generated at 2022-06-26 02:27:28.717612
# Unit test for function logger_level
def test_logger_level():
    import logging as log
    import unittest
    import tempfile
    import os

    class LoggerLevelTestCase(unittest.TestCase):
        def test_logger_level_mismatch(self):
            """ Does the logger level mismatch function work?
            """
            log.basicConfig(level=log.CRITICAL)
            logger = log.getLogger("test")
            logger.setLevel(log.DEBUG)

            # Check if the level set is DEBUG
            self.assertEqual(logger.level, log.DEBUG)

            # Check if the level returned by getEffectiveLevel() is DEBUG
            self.assertEqual(logger.getEffectiveLevel(), log.DEBUG)


# Generated at 2022-06-26 02:27:32.975365
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('name')
    level = 20

    with logger_level(logger, level):
        assert logger.level == level

    assert logger.level != level

if __name__ == '__main__':
    import sys
    sys.exit(test_case_0())

# Generated at 2022-06-26 02:27:43.833420
# Unit test for function get_config

# Generated at 2022-06-26 02:27:51.859121
# Unit test for function logger_level
def test_logger_level():
    import logging

    with logger_level(logging.getLogger(), logging.DEBUG) as l:
        l.info('test')


if __name__ == '__main__':
    if sys.argv[1] == 'test_logger_level':
        test_logger_level()
    elif sys.argv[1] == 'test_case_0':
        test_case_0()
    else:
        print('Test {} not found'.format(sys.argv[1]))

# Generated at 2022-06-26 02:27:56.064743
# Unit test for function logger_level
def test_logger_level():
    LOGGER = get_logger()
    with logger_level(LOGGER, logging.DEBUG):
        LOGGER.debug("DEBUG")
        LOGGER.info("INFO")
    LOGGER.warning("WARNING")
    LOGGER.error("ERROR")
    LOGGER.critical("CRITICAL")


# Generated at 2022-06-26 02:28:15.625576
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("test")
    logger.level = logging.ERROR
    with logger_level(logger, logging.FATAL):
        assert logger.level == logging.FATAL
    assert logger.level == logging.ERROR

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-26 02:28:18.611012
# Unit test for function logger_level
def test_logger_level():
    a = get_logger()
    with logger_level(a, logging.ERROR):
        a.info("test info")
        a.error("test error")



# Generated at 2022-06-26 02:28:20.491082
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logging.ERROR
    assert(logger.level != level)
    with logger_level(logger, level):
        assert(logger.level == level)
    assert(logger.level != level)



# Generated at 2022-06-26 02:28:24.542655
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    try:
        with logger_level(logger, logging.WARN):
            raise Exception("this exception should not be logged")
    except Exception:
        pass

    logger.debug("this should be logged")


if __name__ == "__main__":
    import __main__
    import doctest

    doctest.testmod(m=__main__)
    test_logger_level()

# Generated at 2022-06-26 02:28:30.110074
# Unit test for function configure
def test_configure():
    import tempfile
    import json

    config_str = json.dumps(DEFAULT_CONFIG)
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(config_str.encode())
    f.close()

    conf = f.name
    configure(conf)
    # configure(conf, "LOGGING", DEFAULT_CONFIG)

    import os
    os.unlink(conf)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:28:31.454209
# Unit test for function configure
def test_configure():
    assert configure()


# Generated at 2022-06-26 02:28:37.586267
# Unit test for function logger_level
def test_logger_level():
    global counter

    def my_fun():
        global counter
        logger = getLogger()
        assert logger.level == logging.INFO
        counter += 1

    logger = getLogger()
    logger.setLevel(logging.DEBUG)
    counter = 0
    my_fun()
    assert counter == 1
    with logger_level(logger, logging.INFO):
        counter = 0
        my_fun()
        assert counter == 0
    my_fun()
    assert counter == 1



# Generated at 2022-06-26 02:28:46.950178
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger_level')
    with logger_level(logger, 30):
        logger.critical('critical with level 30')
        logger.error('error with level 30')
        logger.warning('warning with level 30')
        logger.info('info with level 30')
        logger.debug('debug with level 30')
    logger.critical('critical with level 30')
    logger.error('error with level 30')
    logger.warning('warning with level 30')
    logger.info('info with level 30')
    logger.debug('debug with level 30')


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:28:52.033404
# Unit test for function logger_level
def test_logger_level():
    import logging
    logging.basicConfig()
    log = logging.getLogger()
    log.setLevel(logging.WARNING)
    assert log.level == logging.WARNING
    with logger_level(log, logging.DEBUG):
        log.debug('test')
        assert log.level == logging.DEBUG
    assert log.level == logging.WARNING


# Generated at 2022-06-26 02:29:03.985681
# Unit test for function get_config

# Generated at 2022-06-26 02:29:28.130350
# Unit test for function logger_level
def test_logger_level():
    log0 = get_logger(__name__)
    log0.setLevel(logging.INFO)

    log1 = get_logger('%s.log1' % __name__)
    log1.setLevel(logging.INFO)

    log2 = get_logger('%s.log2' % __name__)
    log2.setLevel(logging.INFO)

    log0.debug('log0 debug')
    log1.debug('log1 debug')
    log2.debug('log2 debug')

    log0.info('log0 info')
    log1.info('log1 info')
    log2.info('log2 info')

    log0.warning('log0 warning')
    log1.warning('log1 warning')
    log2.warning('log2 warning')

    log0.error

# Generated at 2022-06-26 02:29:31.434563
# Unit test for function logger_level
def test_logger_level():
    logger_level(logging.getLogger('mock_logger'), logging.DEBUG)

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:29:40.908463
# Unit test for function logger_level
def test_logger_level():
    def test_func():
        logger = get_logger()
        with logger_level(logger, logging.DEBUG):
            logger.debug('test')
        with logger_level(logger, logging.INFO):
            logger.info('test')
        with logger_level(logger, logging.WARNING):
            logger.warning('test')
        with logger_level(logger, logging.ERROR):
            logger.error('test')
        with logger_level(logger, logging.CRITICAL):
            logger.critical('test')
        with logger_level(logger, logging.FATAL):
            logger.fatal('test')

    print('Start testing logger_level...')
    test_func()
    print('Passed.')

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-26 02:29:51.099165
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG) == True
        assert logger.isEnabledFor(logging.INFO) == True
        assert logger.isEnabledFor(logging.WARN) == True
        assert logger.isEnabledFor(logging.ERROR) == True

    assert logger.isEnabledFor(logging.DEBUG) == False
    assert logger.isEnabledFor(logging.INFO) == True
    assert logger.isEnabledFor(logging.WARN) == True
    assert logger.isEnabledFor(logging.ERROR) == True


if __name__ == '__main__':
    configure(config=DEFAULT_CONFIG)
    logger = get_logger()
    logger

# Generated at 2022-06-26 02:29:54.480436
# Unit test for function logger_level
def test_logger_level():
    class Test(object):
        def __init__(self):
            self.logger = get_logger()

        def test_level_change(self):
            with logger_level(self.logger, logging.DEBUG):
                assert self.logger.level == logging.DEBUG

    logging.basicConfig(level=logging.INFO, format='%(message)s')

    test = Test()
    test.test_level_change()


# Generated at 2022-06-26 02:29:57.274414
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config(None, None, default=DEFAULT_CONFIG)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:30:05.259706
# Unit test for function logger_level
def test_logger_level():
    import os
    import sys
    import logging

    # Get logger
    logger = logging.getLogger(__name__)

    with logger_level(logger, logging.DEBUG):
        logger.debug('This message should be printed.')

        # with logger_level(logger, logging.INFO):
        #     logger.debug('This message should not be printed.')
        #     logger.info('This message should be printed.')
        #
        # logger.info('This message should be printed.')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:30:08.005241
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    level = logging.INFO
    with logger_level(logger, level):
        assert logger.level == level
    assert logger.level != level



# Generated at 2022-06-26 02:30:10.615539
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("This is the debug message")
        log.error("This is the error message")


# Generated at 2022-06-26 02:30:12.138511
# Unit test for function configure
def test_configure():
    """ Test for configure """
    if not configure():
        raise Exception("configure function failed")



# Generated at 2022-06-26 02:30:33.283191
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import logging
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.INFO):
        logger.debug('Hello World')
    with logger_level(logger, logging.DEBUG):
        logger.debug('Hello World')

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:42.959083
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import io

    out_stream = io.StringIO()
    err_stream = io.StringIO()

    root_logger = logging.getLogger()
    # Clear any existing handlers in the root logger
    for handler in root_logger.handlers:
        root_logger.removeHandler(handler)

    ch = logging.StreamHandler(stream=out_stream)
    ch.setLevel(logging.DEBUG)
    root_logger.addHandler(ch)

    logger = logging.getLogger("test.example")

    with logger_level(logger, logging.DEBUG) as debug_context:
        logger.info("During DEBUG: Testing")
        with logger_level(logger, logging.INFO) as info_context:
            logger.info("During INFO: Testing")

# Generated at 2022-06-26 02:30:45.656629
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debugging message")
        logger.info("This is a info message")


# Generated at 2022-06-26 02:30:55.842344
# Unit test for function logger_level
def test_logger_level():
    # Create a new logger
    logger = logging.getLogger('guniflask')
    # Set initial logger level to WARNING
    logger.setLevel(logging.WARNING)
    # Create a new handler that prints stream handler messages to stdout
    stream_handler = logging.StreamHandler(sys.stdout)
    # Add the handler to the logger
    logger.addHandler(stream_handler)

    # Get the current logger level
    initial_level = logger.getEffectiveLevel()
    assert(initial_level == logging.WARNING)

    logger.warning('This is a warning')

    # Execute the code within the context block
    with logger_level(logger, logging.INFO):
        logger.info('This is an info')

    # Get the logger level again
    final_level = logger.getEffectiveLevel()

# Generated at 2022-06-26 02:31:07.085594
# Unit test for function get_config
def test_get_config():
    try:
        get_config()
    except ValueError as e:
        assert str(e) == 'Invalid logging config: None'

    try:
        get_config(config=None)
    except ValueError as e:
        assert str(e) == 'Invalid logging config: None'

    try:
        get_config(env_var='LOGGING', default=DEFAULT_CONFIG)
    except ValueError as e:
        assert str(e) == 'Invalid logging config: '

    get_config(config='{"version": 1}')
    get_config(config='{"version": 2}')


if __name__ == '__main__':
    # get_config(config=None)
    configure()
    log = get_logger()
    log.info('helloworld')

# Generated at 2022-06-26 02:31:13.615584
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger')
    assert logger.level == 10
    logger.debug("test_logger debug LOG")
    with logger_level(logger, 0):
        assert logger.level == 0
        logger.debug("test_logger debug LOG")
    assert logger.level == 10
    logger.debug("test_logger debug LOG")

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-26 02:31:16.265712
# Unit test for function logger_level
def test_logger_level():
    _log = get_logger()

    # set logger level info
    with logger_level(_log, 20):
        assert _log.level == 20



# Generated at 2022-06-26 02:31:21.726971
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.WARNING):
        logger.info('test1')
        logger.warning('test2')

if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:31:36.537070
# Unit test for function logger_level
def test_logger_level():
    import unittest
    class TestCase(unittest.TestCase):
        def test_level_debug(self):
            logger = get_logger(__name__)
            self.assertNotEquals(logger.level, logging.DEBUG)
            with logger_level(logger, logging.DEBUG):
                self.assertEquals(logger.level, logging.DEBUG)
            self.assertNotEquals(logger.level, logging.DEBUG)
    suite = unittest.TestLoader().loadTestsFromTestCase(TestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:31:41.188966
# Unit test for function logger_level
def test_logger_level():

    log = get_logger()

    with logger_level(log, logging.DEBUG):
        print(log.level)
        print(log.isEnabledFor(logging.DEBUG))

    with logger_level(log, logging.INFO):
        print(log.level)
        print(log.isEnabledFor(logging.INFO))


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:32:02.783667
# Unit test for function logger_level
def test_logger_level():
    # logger_level
    ## logger_level_0
    configure()
    with logger_level(logging.getLogger(__name__), logging.ERROR):
        log = get_logger(__name__)
        log.debug('debug')
        log.info('info')
        log.warning('warning')
    log.error('error')
    log.critical('critical')

    ## logger_level_1
    import os
    os.system('clear')


# Generated at 2022-06-26 02:32:09.093717
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        fname = f.name

        logger = getLogger('dummy')
        logger.setLevel(logging.DEBUG)
        handler = logging.FileHandler(fname)
        logger.addHandler(handler)

        with logger_level(logger, logging.INFO):
            logger.debug('debug')
            logger.info('info')
            logger.error('error')

        assert 'debug' not in f.read().decode()
        assert 'info' in f.read().decode()
        assert 'error' in f.read().decode()

        with logger_level(logger, logging.DEBUG):
            logger.debug('debug')
            logger.info('info')
            logger.error('error')


# Generated at 2022-06-26 02:32:09.798712
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-26 02:32:19.824309
# Unit test for function logger_level
def test_logger_level():

    import logging

    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('Message 1')
        with logger_level(logger, logging.INFO):
            logger.debug('Message 2')
            logger.info('Message 3')
        logger.debug('Message 4')

    with logger_level(logger, logging.DEBUG):
        logger.debug('Message 5')
        try:
            with logger_level(logger, logging.INFO):
                logger.debug('Message 6')
                logger.info('Message 7')
                raise ValueError()
        except:
            logger.debug('Exception 8')
        logger.debug('Message 9')

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:32:29.984887
# Unit test for function logger_level

# Generated at 2022-06-26 02:32:40.315497
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config

# Generated at 2022-06-26 02:32:50.813370
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    import logging
    import logging.config

    @contextmanager
    def logger_level(logger, level):
        """Set logger level to `level` within a context block. Don't use this except for debugging please, it's gross."""
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    # Unit test for function logger_level
    def test_logger_level():
        cfg = get_config()

        logging.config.dictConfig(cfg)

        print(logging.getLogger(__name__).name)

        log = logging.getLogger(__name__)

        with logger_level(log, logging.DEBUG):
            try:
                1/0
            except Exception:
                log.exception

# Generated at 2022-06-26 02:32:54.234558
# Unit test for function logger_level
def test_logger_level():
    l = logging.getLogger("test_logger_level")
    l.setLevel(logging.DEBUG)

    with logger_level(l, logging.ERROR):
        l.debug("test")
        assert(l.level == logging.ERROR)
        l.error("test")
        assert(l.level == logging.ERROR)

    assert(l.level == logging.DEBUG)



# Generated at 2022-06-26 02:32:59.244410
# Unit test for function logger_level
def test_logger_level():
    # Tests modification of logger
    log = get_logger()
    assert log.level == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:02.621156
# Unit test for function get_config
def test_get_config():

    assert get_config() == DEFAULT_CONFIG
    assert isinstance(get_config(config='{}'), dict)



# Generated at 2022-06-26 02:33:32.296788
# Unit test for function configure
def test_configure():
    import logging
    import yaml


# Generated at 2022-06-26 02:33:38.411521
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger()
    saved_level = logger.level
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == saved_level
    return


if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:41.779325
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    current_level = logger.level
    with logger_level(logger, 10):
        pass
    assert logger.level == current_level



if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:46.898681
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    with logger_level(var_0, logging.DEBUG):
        var_0.info('test')

    try:
        with logger_level(var_0, 'foobar'):
            pass
    except TypeError:
        pass
    else:
        assert(False)



# Generated at 2022-06-26 02:33:50.873294
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("logger")
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.getEffectiveLevel() == logging.INFO


# Generated at 2022-06-26 02:33:56.760500
# Unit test for function logger_level
def test_logger_level():
    logger_0 = get_logger()
    with logger_level(logger_0, level=logging.DEBUG):
        assert logger_0.level == logging.DEBUG
    assert logger_0.level == logging.NOTSET

# Generated at 2022-06-26 02:33:59.185803
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    logger_level_obj = logger_level(logger, logging.DEBUG)
    assert isinstance(logger_level_obj, ContextManager)



# Generated at 2022-06-26 02:34:02.639060
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        assert logger.getEffectiveLevel() == logging.ERROR
    assert logger.getEffectiveLevel() == logging.DEBUG



# Generated at 2022-06-26 02:34:06.323914
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        log.info('Should be suppressed')
    log.info('Should not be suppressed')

if __name__ == "__main__":
    # test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:34:10.192373
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test case 0')


# Generated at 2022-06-26 02:35:02.181597
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    # create console handler with a higher log level
    ch = logging.StreamHandler()
    ch.setLevel(logging.WARNING)
    # create formatter and add it to the handlers
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    # add the handlers to the logger
    logger.addHandler(ch)

    # logger is still at INFO
    with logger_level(logger, logging.DEBUG):
        logger.debug('This is a test')

    logger.debug('This is a test')



# Generated at 2022-06-26 02:35:08.664074
# Unit test for function logger_level
def test_logger_level():
    log1 = get_logger()
    log2 = get_logger()

    with logger_level(log1, logging.WARNING):
        assert log1.level == logging.WARNING
        assert log2.level == logging.DEBUG

    assert log1.level == logging.DEBUG
    assert log2.level == logging.DEBUG


if __name__ == '__main__':
    test_case_0()
    test_logger_level()
    print("Passed tests")

# Generated at 2022-06-26 02:35:18.816164
# Unit test for function logger_level
def test_logger_level():
    import time
    import logging
    import threading
    import traceback
    log = get_logger()
    def test_log():
      try:
        log.info('This should appear')
        time.sleep(1)
        log.debug('This should not appear')
        time.sleep(1)
        log.debug('This should not appear x2')
        time.sleep(1)
        log.info('This should appear x2')
      except:
        traceback.print_exc()
    t1 = threading.Thread(target=test_log)
    t2 = threading.Thread(target=test_log)
    with logger_level(log, logging.INFO):
        t1.start()
        t2.start()
        t1.join()
        t2.join()

# Generated at 2022-06-26 02:35:21.449938
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger()
    with logger_level(test_logger, logging.DEBUG):
        assert test_logger.level == logging.DEBUG
    assert test_logger.level == logging.DEBUG

# Generated at 2022-06-26 02:35:24.821279
# Unit test for function logger_level
def test_logger_level():
    # Configure logging for the test
    configure()

    # Get the logger (a side effect of the configure call ensures it's configured)
    logger = get_logger()

    # We can verify that the logger is configured to run at the DEBUG level
    assert logger.isEnabledFor(logging.DEBUG)

    # And now with logger_level we can set it to WARN

# Generated at 2022-06-26 02:35:29.297276
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.debug("debug message")
        log.info("info message")
    log.info("info message")

# Generated at 2022-06-26 02:35:34.257419
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.WARNING):
        pass
    log.error('TEST')
    log.warning('TEST')


if __name__ == "__main__":
    configure(default=dict())
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:35:37.809148
# Unit test for function get_config
def test_get_config():
    config = {}
    default = ""

    assert(get_config(config, None, default) == default)


# Generated at 2022-06-26 02:35:45.111426
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.setLevel(logging.INFO)
    assert logger.level == logging.INFO



# Generated at 2022-06-26 02:35:50.627449
# Unit test for function logger_level
def test_logger_level():
    logger_0 = getLogger(__name__)
    logger_0.setLevel(logging.DEBUG)
    # Test with logger_level() as level_0:
    # This is a silly and incomplete test, but the code is not
    # considered critical to the functioning of the module.
    assert logger_0.level == 10
