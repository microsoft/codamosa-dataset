

# Generated at 2022-06-26 02:26:08.023169
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.CRITICAL):
        logger.debug('test')


# Generated at 2022-06-26 02:26:17.215941
# Unit test for function logger_level
def test_logger_level():
    logger=get_logger(__name__)
    with logger_level(logger,logging.INFO):
        logger.debug('blah')
        logger.info('blah')
        logger.warn('blah')
        logger.error('blah')
        logger.critical('blah')
    logger.debug('blah')
    logger.info('blah')
    logger.warn('blah')
    logger.error('blah')
    logger.critical('blah')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:26:20.159984
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    old_level = logger.level

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == old_level

# Generated at 2022-06-26 02:26:25.580697
# Unit test for function configure
def test_configure():
    """
    >>> logger = get_logger(__name__)
    >>> msg = 'blah blah debug'
    >>> logger.debug(msg)
    >>> logger.info(msg)
    >>> logger.error(msg)
    """
    pass


if __name__ == "__main__":
    if '--test' in sys.argv:
        import doctest

        doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-26 02:26:36.723296
# Unit test for function get_config
def test_get_config():
    cfg = get_config(given = None , env_var = 'LOGGING', default = None)
    cfg = get_config(given = None , env_var = 'LOGGING', default = DEFAULT_CONFIG)
    cfg = get_config(given = None , env_var = None, default = DEFAULT_CONFIG)
    cfg = get_config(given = DEFAULT_CONFIG , env_var = 'LOGGING', default = None)
    cfg = get_config(given = DEFAULT_CONFIG , env_var = 'LOGGING', default = DEFAULT_CONFIG)
    cfg = get_config(given = DEFAULT_CONFIG , env_var = None, default = DEFAULT_CONFIG)

# Generated at 2022-06-26 02:26:42.182052
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    l1 = logging.getLogger('test')
    with logger_level(l1, logging.DEBUG):
        l1.info('info message')
        l1.debug('debug message')
    l1.info('info message')
    l1.debug('debug message')



# Generated at 2022-06-26 02:26:46.203593
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger()
    var_1.setLevel(logging.INFO)
    with logger_level(var_1, logging.DEBUG):
        logging.debug('debug message')
    logging.debug('debug message')


# Generated at 2022-06-26 02:26:50.038921
# Unit test for function logger_level
def test_logger_level():
    fmt = '%(name)s: %(levelname)s: %(message)s'
    logging.basicConfig(format=fmt)
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.WARNING)

    # default level is WARNING, so shouldn't print debug
    with logger_level(logger, logging.DEBUG):
        logger.debug('spam')
        logger.info('eggs')
    # level reset to WARNING, so shouldn't print debug
    logger.debug('spam')
    logger.info('eggs')


if __name__ == '__main__':
    import doctest

    doctest.testmod()
    test_logger_level()

# Generated at 2022-06-26 02:26:55.110804
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    # With function as context manager
    with logger_level(logger, logging.INFO):
        logger.debug('debug line')
        assert logger.isEnabledFor(logging.DEBUG) == False
        logger.info('info line')
        assert logger.isEnabledFor(logging.INFO) == True

    # After exiting context manager block logger level is restored to original value
    assert logger.isEnabledFor(logging.INFO) == False


# Generated at 2022-06-26 02:26:56.018150
# Unit test for function get_config
def test_get_config():
    assert get_config(config="") == ""


# Generated at 2022-06-26 02:27:03.698901
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    logger.info('before debug')
    with logger_level(logger, logging.DEBUG):
        logger.info('enter debug')
        logger.debug('debug')
    logger.info('after debug')



# Generated at 2022-06-26 02:27:13.997407
# Unit test for function logger_level
def test_logger_level():
    import logging, colorlog
    from contextlib import contextmanager
    import pytest
    from io import StringIO
    out = StringIO()
    handler = logging.StreamHandler(out)
    logger = logging.getLogger('test')
    logger.addHandler(handler)
    logger.setLevel(logging.CRITICAL)

    @contextmanager
    def logger_level(logger, level):
        """Set logger level to `level` within a context block. Don't use this except for debugging please, it's gross."""
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial
    
    
    with logger_level(logger, logging.DEBUG):
        logger.debug('hello!')
    assert 'hello!' in out.getvalue()

# Generated at 2022-06-26 02:27:23.688925
# Unit test for function logger_level
def test_logger_level():
    from random import randint
    from requests.exceptions import HTTPError
    from six.moves import range
    import pytest
    from .logger import get_logger, logger_level

    test_cases = (
        (randint(0, 1), randint(0, 1), randint(0, 1)) for _ in range(1000)
    )

    @pytest.mark.parametrize('set_loglevel, raise_exception, expect_exception', test_cases)
    def test(*args):
        set_loglevel, raise_exception, expect_exception = args

        log = get_logger()


# Generated at 2022-06-26 02:27:32.734103
# Unit test for function logger_level
def test_logger_level():

    logging.basicConfig(level=logging.INFO)

    logger = logging.getLogger('logger_level')

    # test info
    with logger_level(logger, logging.INFO):
        logger.debug('should appear')
        logger.info('should appear too')

    # test debug
    with logger_level(logger, logging.DEBUG):
        logger.debug('should appear')
        logger.info('should appear too')

    # test warning
    with logger_level(logger, logging.WARNING):
        logger.debug('should appear')
        logger.info('should appear too')

    # test critical
    with logger_level(logger, logging.CRITICAL):
        logger.debug('should appear')
        logger.info('should appear too')

if __name__ == "__main__":
    test_case

# Generated at 2022-06-26 02:27:36.036968
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    new_level = 100
    with logger_level(logger, new_level):
        assert logger.level == new_level
    assert logger.level != new_level

# Generated at 2022-06-26 02:27:39.511867
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test')
    for level in [logging.DEBUG, logging.INFO]:
        with logger_level(logger, level):
            assert logger.level == level
        assert logger.level != level


# Generated at 2022-06-26 02:27:48.176066
# Unit test for function get_config
def test_get_config():
    # clear
    c = get_config("", "", "")
    if c == None:
        assert True
    else:
        assert False

    # json
    c = get_config("{\"root\": {\"level\": \"INFO\"}}", "", "")
    if c == {"root":{"level":"INFO"}}:
        assert True
    else:
        assert False

    # yaml
    c = get_config("root:\n  level: INFO", "", "")
    if c == {"root":{"level":"INFO"}}:
        assert True
    else:
        assert False

    # Error
    c = get_config("", "", None)
    if c == None:
        assert True
    else:
        assert False


# Generated at 2022-06-26 02:27:58.576197
# Unit test for function get_config

# Generated at 2022-06-26 02:28:02.369983
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG


# Generated at 2022-06-26 02:28:05.750297
# Unit test for function configure
def test_configure():
    configure()
    try:
        logging.config.dictConfig(DEFAULT_CONFIG)
    except TypeError:
        logging.basicConfig(**DEFAULT_CONFIG)
    # Assure no exception is raised
    assert True


# Generated at 2022-06-26 02:28:21.232373
# Unit test for function logger_level
def test_logger_level():

    logger = logging.getLogger(__name__)
    configure()

    log1 = logger_level(logger, logging.DEBUG)
    log1.__enter__()
    logger.debug("Test DEBUG log from logger_level")
    log1.__exit__()

    log2 = logger_level(logger, logging.INFO)
    log2.__enter__()
    logger.debug("Test INFO log from logger_level")
    log2.__exit__()

    log3 = logger_level(logger, logging.WARNING)
    log3.__enter__()
    logger.debug("Test INFO log from logger_level")
    log3.__exit__()


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:28:23.661915
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG) as lvl:
        print(lvl)


if __name__ == '__main__':
    test_logger_level()
    test_case_0()

# Generated at 2022-06-26 02:28:28.711498
# Unit test for function logger_level
def test_logger_level():
    global var_0
    var_0 = get_logger()
    with logger_level(var_0, logging.WARN):
        var_0.info('This should not be logged')
        var_0.warn('This should be logged')
        with logger_level(var_0, logging.DEBUG):
            var_0.info('This should be logged')
        var_0.info('This should not be logged')



# Generated at 2022-06-26 02:28:39.000129
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('test')
    log.debug('debug message')
    log.info('info message')
    log.warn('warn message')
    log.error('error message')
    log.critical('critical message')
    print('--------------------')
    with logger_level(log, logging.INFO):
        log.debug('debug message')
        log.info('info message')
        log.warn('warn message')
        log.error('error message')
        log.critical('critical message')
    print('--------------------')
    with logger_level(log, logging.DEBUG):
        log.debug('debug message')
        log.info('info message')
        log.warn('warn message')
        log.error('error message')
        log.critical('critical message')

if __name__ == '__main__':
    test

# Generated at 2022-06-26 02:28:49.497817
# Unit test for function get_config
def test_get_config():
    import json

    x = {'version': 1}

    assert x == get_config(x, 'LOGGING', None)
    assert x == get_config(json.dumps(x), 'LOGGING', None)
    assert x == get_config(json.dumps(x, sort_keys=True), 'LOGGING', None)

    import yaml

    assert x == get_config(yaml.dump(x), 'LOGGING', None)

    assert x == get_config(default=x)

    # with pytest.raises(ValueError):
    #     get_config(default=None)

    # try:
    #     get_config(default=None)
    # except ValueError:
    #     pytest.fail()



# Generated at 2022-06-26 02:29:01.314202
# Unit test for function configure
def test_configure():
    # Instantiate the parser
    parser = argparse.ArgumentParser(
        description='Set configuration and return logger.')
    # Optional arguments
    parser.add_argument(
        "-c",
        "--config",
        dest="config",
        help="Config dictionary, json formatted string, or path to a json config file.",
        default=DEFAULT_CONFIG
    )
    parser.add_argument(
        "-e",
        "--env",
        dest="env",
        help="Environment variable.",
        default=None
    )
    parser.add_argument(
        "-d",
        "--default",
        dest="default",
        help="Default config.",
        default=None
    )
    args = parser.parse_args()

# Generated at 2022-06-26 02:29:11.465663
# Unit test for function logger_level
def test_logger_level():
    import os
    import sys

    from io import StringIO

    io_ = StringIO()
    io_.name = '<string>'
    sys.stdout = io_

    # Test for function logger_level
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    with logger_level(logger, logging.INFO):
        logger.debug('INFO')
        logger.info('INFO')

    test = ''
    for line in io_.getvalue().splitlines():
        test += line
    print(test)


# Generated at 2022-06-26 02:29:12.746315
# Unit test for function configure
def test_configure():
    log = get_logger(__name__)
    configure()
    log.info('test')



# Generated at 2022-06-26 02:29:21.877112
# Unit test for function logger_level
def test_logger_level():
    import os
    import logging.config
    from logging import getLogger, CRITICAL, ERROR, WARNING, INFO, DEBUG, NOTSET
    import re

    test_logger_level.logfile = os.path.join(os.path.dirname(__file__), "test_logger_level.log")
    if os.path.exists(test_logger_level.logfile):
        os.remove(test_logger_level.logfile)

    logging.config.dictConfig(
        {
            "version": 1,
            "handlers": {"file": {"class": "logging.FileHandler", "filename": test_logger_level.logfile}},
            "loggers": {"logger_level_test": {"handlers": ["file"], "level": DEBUG}},
        }
    )

    logger

# Generated at 2022-06-26 02:29:25.609932
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    level = logging.WARNING    # Change PyLogger's level to WARNING
    with logger_level(logger, level):
        assert logger.level == logging.WARNING
    assert logger.level != logging.WARNING


# Generated at 2022-06-26 02:29:33.764546
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.ERROR):
        get_logger().error("test")
    # get_logger().debug("test")
    get_logger().error("test")

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:29:38.582930
# Unit test for function logger_level
def test_logger_level():
    import time
    import logging
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        for i in range(100000):
            logger.debug('debug level')
            logger.info('info level')
            logger.warn('warn level')
            logger.error('error level')
            logger.fatal('fatal level')


# Generated at 2022-06-26 02:29:43.484780
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger()
    initial_level = logger.getEffectiveLevel()
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.getEffectiveLevel() == initial_level
    logger.setLevel(logging.ERROR)
    try:
        with logger_level(logger, logging.DEBUG):
            assert logger.getEffectiveLevel() == logging.DEBUG
    finally:
        logger.setLevel(initial_level)



# Generated at 2022-06-26 02:29:48.742647
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(__name__), logging.DEBUG):
        assert logging.getLogger(__name__).level == logging.DEBUG
    assert logging.getLogger(__name__).level != logging.DEBUG


if __name__ == '__main__':
    configure()
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:29:54.276439
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger("logger_level_test")
    with logger_level(var_0, logging.CRITICAL):
        var_0.warning("Should not be printed")
        var_0.debug("Should not be printed")

# Testing
if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:29:57.712942
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test')
    initial = logger.level
    with logger_level(logger, 'INFO'):
        assert logger.level == logging.INFO
    assert logger.level == initial



# Generated at 2022-06-26 02:30:06.214249
# Unit test for function logger_level
def test_logger_level():
    from unittest import TestCase, main

    class Test1(TestCase):
        def setUp(self):
            self.logger = get_logger()

        def test_case_0(self):
            with logger_level(self.logger, logging.DEBUG):
                self.logger.debug("Message 1")
                self.logger.info("Message 2")
                self.logger.warning("Message 3")

        def test_case_1(self):
            self.logger.debug("Message 1")
            self.logger.info("Message 2")
            self.logger.warning("Message 3")

    main()


# Generated at 2022-06-26 02:30:14.147762
# Unit test for function logger_level
def test_logger_level():
    test_dict = {
        # key: (module_name, log_level, test_log_level)
        'test_0': ('logging_py', logging.DEBUG, logging.INFO),
        'test_1': ('logging_py', logging.INFO, logging.DEBUG),
        'test_2': ('logging_py', logging.ERROR, logging.INFO),
    }

    for key in test_dict.keys():
        logger_name, log_level, test_log_level = test_dict[key]
        logger = get_logger(logger_name)
        logger.setLevel(log_level)

        test_msg = 'test_logger_level: %s' % key
        # Check if logger is working fine
        logger.debug(test_msg)


# Generated at 2022-06-26 02:30:16.694010
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logging.INFO
    initial = logger.level
    logger.level = level
    logger.info('test_logger_level')
    logger.level = initial


# Generated at 2022-06-26 02:30:19.252615
# Unit test for function configure
def test_configure():
    import logging
    import logging.config

    logging.config.dictConfig(DEFAULT_CONFIG)
    test_case_0()
#test_configure()

# Generated at 2022-06-26 02:30:28.469759
# Unit test for function get_config
def test_get_config():
    assert get_config(env_var=None) == DEFAULT_CONFIG
    assert get_config(config="{'key': 'value'}", env_var=None) == {'key': 'value'}
    assert get_config(config='key: value', env_var=None) == {'key': 'value'}
    assert get_config(config=[], env_var=None) == []
    assert get_config(config=1, env_var=None) == 1


# Generated at 2022-06-26 02:30:34.620054
# Unit test for function logger_level
def test_logger_level():
    # initialize the logger
    logger = get_logger(__name__)

    # get current level
    original_level = logger.level

    # use the context manager to set a new level
    with logger_level(logger, logging.DEBUG):
        # ensure the new level is now active
        assert logger.level == logging.DEBUG
        # and that the level is reset to what it was
    assert logger.level == original_level



# Generated at 2022-06-26 02:30:37.613401
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logger.level
    new_level = logging.DEBUG
    with logger_level(logger, new_level):
        assert logger.level == new_level
    assert logger.level == level



# Generated at 2022-06-26 02:30:48.104778
# Unit test for function logger_level
def test_logger_level():
    name_0 = 'mock.test-logger-level'

    logger_0 = get_logger(name_0)
    logger_0.debug('test-debug')
    logger_0.info('test-info')
    logger_0.warning('test-warning')
    logger_0.error('test-error')
    logger_0.fatal('test-fatal')

    assert logger_0.level == logging.DEBUG

    with logger_level(logger_0, logging.INFO):
        assert logger_0.level == logging.INFO
        logger_0.debug('test-debug')
        logger_0.info('test-info')
        logger_0.warning('test-warning')
        logger_0.error('test-error')
        logger_0.fatal('test-fatal')

    assert logger

# Generated at 2022-06-26 02:30:50.829190
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.ERROR):
        assert logger.getEffectiveLevel() == logging.ERROR
    assert logger.getEffectiveLevel() != logging.ERROR

# Generated at 2022-06-26 02:31:02.333496
# Unit test for function get_config
def test_get_config():
    import tempfile
    test_log_config = {
        'handlers': {
            'file': {
                'class': 'logging.FileHandler',
                'level': 'DEBUG',
                'filename': 'testlog.log'
            }
        },
        'root': {
            'level': 'DEBUG',
            'handlers': ['file']
        }
    }
    # test for dict type
    assert get_config(test_log_config) is test_log_config

    # test for json string
    import json
    assert get_config(json.dumps(test_log_config)) == test_log_config

    # test for yaml string
    try:
        test_log_config_yaml = yaml.dump(test_log_config)
    except NameError:
        pass

# Generated at 2022-06-26 02:31:09.649065
# Unit test for function logger_level

# Generated at 2022-06-26 02:31:13.658126
# Unit test for function logger_level
def test_logger_level():
    logger=get_logger()
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
    assert logger.level != logging.WARNING

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:31:21.279903
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.CRITICAL):
        logger.error("error message")
        logger.warning("warning message")
    logger.critical("critical message")
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
    logger.info("info message")

if __name__ == '__main__':
    configure()
    test_logger_level()

# Generated at 2022-06-26 02:31:24.033016
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.debug('Before level change')
    with logger_level(logger, logging.WARNING):
        logger.debug('In level change')
    logger.debug('After level change')



# Generated at 2022-06-26 02:31:30.505744
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger()
    rv = None
    with logger_level(var_1, (1)):
        rv = 1
    var_2 = 1
    assert(rv == var_2)


# Generated at 2022-06-26 02:31:38.244652
# Unit test for function logger_level
def test_logger_level():
    logger = logging.root
    old_level = logger.level
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        with logger_level(logger, logging.INFO):
            assert logger.level == logging.INFO
        assert logger.level == logging.DEBUG
    assert logger.level == old_level


# Module Run tests
if __name__ == '__main__':
    configure()
    test_case_0()
    test_logger_level()

    print('%s: All tests pass' % __file__)

# Generated at 2022-06-26 02:31:50.517747
# Unit test for function logger_level
def test_logger_level():
    import time
    import threading
    import logging
    test_logger = logging.getLogger("test_logger")
    test_logger.setLevel(logging.INFO)

    class LogThread(threading.Thread):
        def __init__(self, thread_name, logger, iterations, level, delay):
            threading.Thread.__init__(self, name=thread_name)
            self.msg_iterations = iterations
            self.msg_delay_time = delay
            self.msg_logger = logger
            self.msg_level = level

        def run(self):
            for iteration in range(1, self.msg_iterations):
                time.sleep(self.msg_delay_time)

# Generated at 2022-06-26 02:31:57.051217
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = getattr(logging, 'DEBUG')
    with logger_level(logger, level):
        assert logger.level == level
        #loop over some property and assert
        #assert
    print('Passed all tests for logger_level.')


# Run all the tests
if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:32:00.288974
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('in debug mode')
        assert log.level == logging.DEBUG
    assert log.level == logging.INFO



# Generated at 2022-06-26 02:32:04.940469
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    # with logger_level(log, 100):
    #     log.error('100')
    log.error('100')
    log.warning('100')
    log.info('100')
    log.debug('100')
    with logger_level(log, 50):
        log.error('50')
        log.warning('50')
        log.info('50')
        log.debug('50')
    log.error('100')
    log.warning('100')
    log.info('100')
    log.debug('100')



# Generated at 2022-06-26 02:32:15.033806
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager

    @contextmanager
    def logger_level(logger, level):
        """Set logger level to `level` within a context block. Don't use this except for debugging please, it's gross."""
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    import logging
    import sys

    # this doesn't work.
    log = logging.getLogger()
    with logger_level(log, logging.WARNING):
        print("This should be logged")
        log.debug("foo")
        log.info("bar")
        log.warning("foo")


# def test_logger(_has_configured=_CONFIGURED):
#     print("Testing logger")
#     # if not _has_configured:
#

# Generated at 2022-06-26 02:32:17.210396
# Unit test for function get_config
def test_get_config():
    config_input = get_config(default=DEFAULT_CONFIG)
    assert config_input == DEFAULT_CONFIG

test_case_0()
test_get_config()

# Generated at 2022-06-26 02:32:28.333693
# Unit test for function logger_level
def test_logger_level():
    try:
        import StringIO
    except ImportError:
        import io as StringIO
    import sys
    import colorlog
    import logging
    import logging.config
    import dolib.logging
    from dolib.logging import logger_level

    saved_stdout = sys.stdout
    saved_stderr = sys.stderr
    saved_stdlog = logging.getLogger().handlers[0].stream
    global logger

    logger = logging.getLogger()
    sys.stdout = StringIO.StringIO()
    sys.stderr = StringIO.StringIO()

# Generated at 2022-06-26 02:32:29.492033
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.WARN):
        log.debug('This should not print')

    log.info('This should print')



# Generated at 2022-06-26 02:32:41.328423
# Unit test for function logger_level
def test_logger_level():
    with logger_level(test_case_0.var_0, 60):
        pass

# following test is for python3.  It should still work for python2.

# Generated at 2022-06-26 02:32:46.439398
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.WARN):
        log = get_logger()
        log.debug('This message is not printed')
        log.info('Neither is this one')
        log.warn('But this one is')
    log.debug('This message is printed')
    log.error('So does this one')


# Generated at 2022-06-26 02:32:47.986571
# Unit test for function configure
def test_configure():
    assert type(test_case_0()) is type(get_logger('test'))


# Generated at 2022-06-26 02:32:55.558232
# Unit test for function logger_level
def test_logger_level():
    print("test_logger_level:")
    def test_logger_level_func():
        print("test_logger_level_func, level")
    def test_logger_level_func_1():
        print("test_logger_level_func, level_1")
    def test_logger_level_func_2():
        print("test_logger_level_func, level_2")
    logger = logging.getLogger("test_logger_level")
    logger.info("Test info 1")
    logger.info("Test info 2")
    with logger_level(logger, logging.INFO):
        logger.info("Test info 1")
        logger.info("Test info 2")
    logger.info("Test info 1")
    logger.info("Test info 2")


# Generated at 2022-06-26 02:32:59.397871
# Unit test for function logger_level
def test_logger_level():
    import mock
    level = mock.Mock()
    logger = logging.getLogger(__name__)
    logger.level = None
    with logger_level(logger, level) as l:
        assert logger.level == level
    assert logger.level is None

# Generated at 2022-06-26 02:33:03.115485
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:33:09.699111
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.CRITICAL):
        logger.debug('this will not be printed')
        logger.info('this will not be printed')
        logger.warning('this will not be printed')
        logger.error('this will not be printed')
        logger.critical('this will be printed')
    logger.debug('again this will be printed')
    assert True



# Generated at 2022-06-26 02:33:14.151542
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    with open(os.devnull, mode='w') as var_1:
        with logger_level(var_0, logging.CRITICAL):
            # var_0.warning('test_logger_level')
            var_0.warning('test_logger_level')

if __name__ == '__main__':
    configure()
    test_logger_level()
    test_case_0()

# Generated at 2022-06-26 02:33:18.378155
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger()
    var_2 = var_1.level
    var_3 = var_2
    with logger_level(var_1, logging.CRITICAL):
        var_3 = var_1.level
    var_4 = var_3


# Generated at 2022-06-26 02:33:31.379536
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import time
    import sys
    import os
    import subprocess
    import logging

    # Build a logger we can test with
    logger = logging.getLogger('test_logger_level')
    log_file = tempfile.NamedTemporaryFile(mode='w+', delete=False)
    handler = logging.FileHandler(log_file.name)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    # Run the tests
    log_file.write('')  # clear the file
    log_file.flush()
    # Keep the file open; we'll check for log output later
    time.sleep(1)  # let any pending writes complete
    with logger_level(logger, logging.INFO):
        logger.debug('debug_line')  # should not

# Generated at 2022-06-26 02:33:43.387852
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    try:
        with logger_level(logger, logging.DEBUG):
            assert logger.level == logging.DEBUG
    except AssertionError:
        assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:33:49.134181
# Unit test for function get_config
def test_get_config():
    # Test the function with a bare string
    assert get_config("foobar") == "foobar"

    # Test the function with a json string
    assert get_config('{"foobar": "barfoo"}') == {"foobar": "barfoo"}

    # Test the function with a yaml string
    assert get_config("foobar: barfoo") == {"foobar": "barfoo"}

# Generated at 2022-06-26 02:33:51.765050
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    var_1 = logging.WARNING
    with logger_level(var_0, var_1):
        var_0.warning('hello world')
        var_0.info('hello world')


# Generated at 2022-06-26 02:33:58.876778
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("test_logger")
    with logger_level(logger=logger, level=logging.INFO) as log:
        assert logger.level == logging.INFO
        # print("a")
    assert logger.level == logging.NOTSET
    with logger_level(logger=logger, level=logging.DEBUG):
        assert logger.level == logging.DEBUG


# Generated at 2022-06-26 02:34:10.240637
# Unit test for function get_config
def test_get_config():
    config_0 = get_config(given=None, env_var=None, default=None)

# Generated at 2022-06-26 02:34:18.759305
# Unit test for function logger_level

# Generated at 2022-06-26 02:34:22.528932
# Unit test for function logger_level
def test_logger_level():
    var_1 = logging.getLogger()
    var_2 = var_1.level
    var_3 = logging.DEBUG
    with logger_level(logger=var_1, level=var_3):
        pass


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:34:30.388442
# Unit test for function logger_level
def test_logger_level():
    # Get the root logger
    root_logger = logging.getLogger("")
    # Get the initial level, save it
    initial = root_logger.level
    # Set the level, using the function under test
    with logger_level(logging.getLogger(""), logging.DEBUG):
        # Check that new level is set, and was reset
        assert root_logger.level == logging.DEBUG
    assert root_logger.level == initial



# Generated at 2022-06-26 02:34:33.751125
# Unit test for function logger_level
def test_logger_level():
    sio = io.StringIO()
    var_0 = get_logger()
    var_1 = logger_level( var_0 , logging.DEBUG)
    with var_1:
        pass
    



# Generated at 2022-06-26 02:34:38.313372
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()

    logger = get_logger('test_logger')
    with logger_level(logger, logging.INFO):
        logger.debug("should not see this in INFO")
        logger.info("this should be in INFO")
        with logger_level(logger, logging.DEBUG):
            logger.debug("this should be in DEBUG")
            logger.info("this should be in DEBUG")
        logger.debug("this should be in INFO")
        logger.info("this should be in INFO")



# Generated at 2022-06-26 02:35:03.317916
# Unit test for function get_config
def test_get_config():

    # Set up logging for test
    import logging
    import logging.config
    import inspect


# Generated at 2022-06-26 02:35:07.463119
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger("__name__")
    with logger_level(log, logging.DEBUG) as lvl:
        assert log.getEffectiveLevel() == 10
    with logger_level(log, logging.INFO) as lvl:
        assert log.getEffectiveLevel() == 20


# Generated at 2022-06-26 02:35:12.976134
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARN):
        logger.info('We should not be able to see this.')
        logger.warn('We should see this.')
    logger.info('We should see this as well.')

if __name__ == '__main__':
    # test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:35:22.045341
# Unit test for function get_config
def test_get_config():
	# parse bare string
	bare_string = 'this is a test'
	out_string = get_config(bare_string)
	if out_string != None:
		assert False

	# parse json string
	json_string = '{"dictionary": "json"}'
	out_dict = get_config(json_string)
	if out_dict['dictionary'] != "json":
		assert False

	# parse yaml string
	yaml_string = 'yaml: content'
	out_dict = get_config(yaml_string)
	if out_dict['yaml'] != 'content':
		assert False

	# parse bare dictionary
	bare_dict = {'bare': 'dict'}
	out_dict = get_config(bare_dict)

# Generated at 2022-06-26 02:35:29.166256
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
    assert logger.level != logging.CRITICAL

# Generated at 2022-06-26 02:35:33.261393
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("test_logger_level")
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
    assert logger.level == logging.NOTSET



# Generated at 2022-06-26 02:35:41.740612
# Unit test for function logger_level
def test_logger_level():
    # Create a logger object
    logger_0 = logging.getLogger(__name__)

    # Store the current logger level
    current_level = logger_0.level

    # Set the logger level to critical
    with logger_level(logger_0, logging.CRITICAL):
        # Assert that the logger level is now critical
        assert logger_0.level == logging.CRITICAL

    # Assert that the logger level was restored to the initial logger level
    assert logger_0.level == current_level


# Generated at 2022-06-26 02:35:45.690796
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level != logging.DEBUG



# Generated at 2022-06-26 02:35:56.131327
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('func_logger_level')
    logger.setLevel(logging.DEBUG)
    logger.debug('before logger_level')
    logger.info('before logger_level')
    logger.warning('before logger_level')
    logger.error('before logger_level')
    logger.critical('before logger_level')

    with logger_level(logger, logging.INFO):
        logger.debug('start logger_level')
        logger.info('start logger_level')
        logger.warning('start logger_level')
        logger.error('start logger_level')
        logger.critical('start logger_level')
    logger.debug('after logger_level')
    logger.info('after logger_level')
    logger.warning('after logger_level')
    logger.error('after logger_level')