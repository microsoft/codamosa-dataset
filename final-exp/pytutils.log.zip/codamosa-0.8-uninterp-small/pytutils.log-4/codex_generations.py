

# Generated at 2022-06-26 02:25:57.726522
# Unit test for function configure
def test_configure():
    assert DEFAULT_CONFIG == test_case_0()



# Generated at 2022-06-26 02:26:08.321949
# Unit test for function get_config
def test_get_config():
    #test case 1: 
    #test case 2: get_config(given = None, env_var = None, default = None)
    config = get_config(None, None, DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG 
    #test case 3: get_config(given = None, env_var = 'LOGGING', default = None)
    config = get_config(given = None, env_var = 'LOGGING', default = None)
    assert config == DEFAULT_CONFIG 
    #test case 4: get_config(given = None, env_var = None, default = DEFAULT_CONFIG)
    config = get_config(given = None, env_var = None, default = DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG 
    #test case 5: get

# Generated at 2022-06-26 02:26:15.805965
# Unit test for function logger_level
def test_logger_level():
    # Setup
    logger = logging.getLogger('test_logger')
    level = logging.DEBUG
    with logger_level(logger, level):
        # Verify
        assert logger.level == level

    # Verify
    assert logger.level != level


if __name__ == '__main__':
    import doctest

    logging.basicConfig(level=logging.DEBUG)

    doctest.testmod()

# Generated at 2022-06-26 02:26:18.872252
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARN):
        # print(logger.level)
        assert logger.level == logging.WARN
        # logger.info('This is a test')
        try:
            logger.info('This is a test')
        except:
            pass
    # print(logger.level)
    assert logger.level == logging.DEBUG
    logger.info('This is a test')


if __name__ == "__main__":
    configure()
    test_case_0()
    test_logger_level()
else:
    configure()

# Generated at 2022-06-26 02:26:23.399382
# Unit test for function get_config
def test_get_config():
    assert get_config({'lol':'test'}) == {'lol': 'test'}
    assert get_config(''' {"lol":"test"} ''') == {'lol': 'test'}
    assert get_config('lol: test') == {'lol': 'test'}
    # assert get_config() == default config



# Generated at 2022-06-26 02:26:25.351357
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:26:32.518498
# Unit test for function get_config
def test_get_config():
    """Test that get_config returns a valid logging format"""
    cfg = get_config()
    assert cfg['version'] == DEFAULT_CONFIG['version']
    assert 'colored' in cfg['formatters']
    assert 'simple' in cfg['formatters']
    assert 'console' in cfg['handlers']
    assert cfg['handlers']['console']['class'] == 'logging.StreamHandler'
    assert 'requests' in cfg['loggers']

# Generated at 2022-06-26 02:26:36.370288
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.root, logging.DEBUG):
        assert logging.root.level == logging.DEBUG

    assert logging.root.level == logging.WARNING


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:26:48.353727
# Unit test for function logger_level
def test_logger_level():
    # Initialise loggers and configure logger first
    # This will run configure() and convert json config string to a dictionary before running logging.config.dictConfig(cfg)
    log = get_logger()
    configure()
    # Try: Capture and return the result of hello()
    # Expect: "hello"
    with logger_level(log, logging.DEBUG):
        # This will only run if level is set to DEBUG
        log.debug("hello")
        assert log.level == logging.DEBUG, "logger's level should be set to DEBUG for this message to be printed"

    # Try: Capture and return the result of hello()
    # Expect: "hello"
    with logger_level(log, logging.ERROR):
        # This will only run if level is set to ERROR
        log.debug("hello")

# Generated at 2022-06-26 02:26:51.981349
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("This message should be printed")
        logger.info("This message should not be printed")
    logger.info("This message should be printed")


# Generated at 2022-06-26 02:27:00.396546
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    level = 100
    with logger_level(logger,level):
        assert logger.level == level
    # Verify level has reset
    assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:27:04.572351
# Unit test for function logger_level
def test_logger_level():
    class test: pass
    test.logger = getLogger('test')
    
    assert test.logger.level == 10
    with logger_level(test.logger, logging.DEBUG): 
        assert test.logger.level == 10
    assert test.logger.level == 10
    
    

# Generated at 2022-06-26 02:27:08.899400
# Unit test for function get_config
def test_get_config():
    config = get_config({'yay': 'yay'}, env_var='LOGGING', default=DEFAULT_CONFIG)
    if config != {'yay': 'yay'}:
        raise AssertionError('Expected {\'yay\': \'yay\'}, got {}'.format(config))

# Generated at 2022-06-26 02:27:13.730567
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    test_log_level = logging.DEBUG
    with logger_level(log, test_log_level):
        assert test_log_level == log.getEffectiveLevel()


if __name__ == "__main__":
    import fire

    fire.Fire()

# Generated at 2022-06-26 02:27:17.546968
# Unit test for function logger_level
def test_logger_level():
    """
    Unit test for function logger_level

    >>> log = get_logger()
    >>> with logger_level(log, logging.ERROR):
    ...     log.debug('test')
    >>> log.debug('test')
    """
    pass



# Generated at 2022-06-26 02:27:22.012331
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.info("This will log with debug level")
        log.debug("This too")


if __name__ == '__main__':
    # configure()
    print('loghog fully functional!')
    raise SystemExit(1)

# Generated at 2022-06-26 02:27:24.522942
# Unit test for function get_config
def test_get_config():
    assert get_config() is not None
    assert get_config(default='{}') == {}
    assert get_config(default='[1,2,3]') == [1, 2, 3]



# Generated at 2022-06-26 02:27:28.676062
# Unit test for function logger_level
def test_logger_level():
    from mock import MagicMock, patch
    from logging import ERROR
    log = get_logger(__name__)
    magicmock = MagicMock()
    with logger_level(log, ERROR):
        magicmock.run()
        assert not magicmock.run.called
    magicmock.run.assert_called_once()



# Generated at 2022-06-26 02:27:39.269945
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, level=logging.DEBUG):
        log.info('Trying to log this message with the set level')
        log.debug('Trying to log this message with the set level')
        log.info('Trying to log this message with the set level')
        log.debug('Trying to log this message with the set level')

    with logger_level(log, level=logging.ERROR):
        log.info('Trying to log this message with the set level')
        log.debug('Trying to log this message with the set level')
        log.error('Trying to log this message with the set level')
        log.critical('Trying to log this message with the set level')


if __name__ == "__main__":
    configure()

# Generated at 2022-06-26 02:27:45.417837
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger()
    with logger_level(test_logger, logging.DEBUG):
        logging.debug('DEBUG', extra={'foo': 'bar'})
        logging.info('INFO', extra={'foo': 'bar'})
        logging.warning('WARNING', extra={'foo': 'bar'})
        logging.error('ERROR', extra={'foo': 'bar'})
        logging.critical('CRITICAL', extra={'foo': 'bar'})


# Generated at 2022-06-26 02:27:54.289898
# Unit test for function get_config
def test_get_config():
    var_1 = get_config()


# Generated at 2022-06-26 02:27:59.887283
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("some_logger")
    logger.error("Error Log")
    logger.info("Info Log")
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        logger.error("Error Log")
        logger.info("Info Log")
        assert logger.level == logging.INFO
    logger.error("Error Log")
    logger.info("Info Log")
    assert logger.level == logging.DEBUG

# Generated at 2022-06-26 02:28:03.360804
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    level = logging.INFO

    with logger_level(logger, level):
        assert logger.level == level


# Generated at 2022-06-26 02:28:10.800626
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.NOTSET):
        log.debug('logging debug level messages')
        log.info('logging info level messages')
        log.warning('logging warning level messages')
        log.error('logging error level messages')
        log.critical('logging critical level messages')


if __name__ == '__main__':
    configure()
    log = get_logger()
    log.info('Info test')
    log.warning('Warning test')
    log.error('Error test')
    log.critical('Critical test')
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:28:21.460998
# Unit test for function logger_level
def test_logger_level():
    import logging
    # Prepare a sample logger
    logger = logging.getLogger("logger_level")
    # First we print out the logger level
    print("Logger level = %d" % logger.level)
    # Now we check that the logger_level context changes the level
    with logger_level(logger, logging.DEBUG):
        print("Logger level = %d" % logger.level)
        assert logger.level == logging.DEBUG
    # And confirms that the logger level changes back to what it was
    print("Logger level = %d" % logger.level)
    assert logger.level == logging.NOTSET
    return 0

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:28:25.405196
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.INFO):
        logger.error('can you see me? (expected)')
    logger.error('can you see me? (expected)')




# Generated at 2022-06-26 02:28:28.117812
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    logger.info('test_logger_level')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:28:35.616307
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.CRITICAL):
        log.debug("logging.debug message")
        log.info("logging.info message")
        log.warning("logging.warning message")
        log.error("logging.error message")
        log.critical("logging.critical message")


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:28:47.146808
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('TestLogger')
    with logger_level(logger, logging.ERROR):
        logger.debug("Debug message")
        logger.info("Info message")
        logger.warn("Warning message")
        logger.error("Error message")
        logger.critical("Critical message")
        logger.exception("Exception message")
    with logger_level(logger, logging.INFO):
        logger.debug("Debug message")
        logger.info("Info message")
        logger.warn("Warning message")
        logger.error("Error message")
        logger.critical("Critical message")
        logger.exception("Exception message")
    with logger_level(logger, logging.DEBUG):
        logger.debug("Debug message")
        logger.info("Info message")
        logger.warn("Warning message")

# Generated at 2022-06-26 02:28:55.142356
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager

    @contextmanager
    def logger_level(logger, level):
        """Set logger level to `level` within a context block. Don't use this except for debugging please, it's gross."""
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    logging.error("This should not be visible")
    logging.debug("This should not be visible")
    logging.info("This should not be visible")

    with logger_level(logging, logging.DEBUG):
        logging.debug("This should be visible")

    logging.error("This should not be visible")
    logging.debug("This should not be visible")
    logging.info("This should not be visible")

if __name__ == '__main__':
    test_case

# Generated at 2022-06-26 02:29:09.802464
# Unit test for function logger_level
def test_logger_level():
    import logging
    def test_func():
        logging.debug('this will be ignored')
        logging.info('this will be shown')
    mylogger = logging.getLogger()
    mylogger.setLevel(logging.INFO)
    with logger_level(mylogger, logging.DEBUG):
        test_func()


if __name__ == '__main__':
    test_case_0()
    test_logger_level()
    # import doctest
    # doctest.testmod()

# Generated at 2022-06-26 02:29:12.774988
# Unit test for function logger_level
def test_logger_level():
    a = logging.getLogger()
    with logger_level(a, logging.INFO):
        assert a.level == logging.INFO

    assert a.level == logging.DEBUG


# vim: set ft=python et ts=4 sw=4:

# Generated at 2022-06-26 02:29:18.785688
# Unit test for function get_config
def test_get_config():
    
    # Variable config is not defined
    try:
        config
    except NameError:
        pass
    else:
        assert False, "Expected NameError"
       
    # Variable config is defined, it is a type of string
    config = "test string"
    assert isinstance(config,str) == True

    # Call the function to test
    result = get_config()

    # If this assert fails, the test has failed
    assert result == "test string", 'Expected "test string", but got "%s"' % result


# Generated at 2022-06-26 02:29:22.107594
# Unit test for function get_config
def test_get_config():
    print('Testing function get_config')
    with pytest.raises(ValueError) as e_info:
        test_case_0()
    assert str(e_info.value) == 'Invalid logging config: None'



# Generated at 2022-06-26 02:29:25.035170
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger()
    with logger_level(test_logger, logging.DEBUG):
        assert test_logger.level == logging.DEBUG
        


# Generated at 2022-06-26 02:29:27.478420
# Unit test for function configure
def test_configure():
    print('Test function configure')
    print('Test case 0')
    test_case_0()


if __name__ == '__main__':
    configure()
    test_configure()

# Generated at 2022-06-26 02:29:29.546974
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        return log.debug('test')



if __name__ == '__main__':
    # test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:29:34.849087
# Unit test for function get_config
def test_get_config():
    # Compare the JSON to the Python object
    import json
    x = get_config()
    y = json.loads(json.dumps(x))
    assert json.dumps(x) == json.dumps(y)


if __name__ == '__main__':
    # TODO Fix this test case
    # test_case_0()
    test_get_config()

# Generated at 2022-06-26 02:29:42.097831
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()

    log = get_logger('level_test')

    with logger_level(log, logging.CRITICAL):
        log.critical('critical at critical')
        log.debug('critical at debug')

    with logger_level(log, logging.ERROR):
        log.error('error at error')
        log.debug('error at debug')

    with logger_level(log, logging.WARNING):
        log.warning('warning at warning')
        log.debug('warning at debug')

    with logger_level(log, logging.INFO):
        log.info('info at info')
        log.debug('info at debug')


# Generated at 2022-06-26 02:29:47.248393
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger(__name__)
    log.info('test')
    with logger_level(log, logging.DEBUG):
        log.debug('Another test')
        assert log.isEnabledFor(logging.DEBUG)
    log.info('test')
    assert not log.isEnabledFor(logging.DEBUG)

# Generated at 2022-06-26 02:30:01.001971
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger('test_logger_level'), logging.DEBUG):
        logging.getLogger('test_logger_level').debug('should print')
    logging.getLogger('test_logger_level').debug('should not print')

if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:06.795043
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)
    with logger_level(log, logging.NOTSET):
        assert log.level == logging.NOTSET
        log.debug("Test DEBUG message before")
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
        log.debug("Test DEBUG message after")


# Generated at 2022-06-26 02:30:13.742874
# Unit test for function logger_level
def test_logger_level():
    test_level = logging.DEBUG

    with logger_level(logging.getLogger("test_logger_level"), test_level) as l:
        l.debug("logger_level test: {}".format("debug"))
        assert(l.getEffectiveLevel() == test_level)
        l.warning("logger_level test: {}".format("warning"))
        assert(l.getEffectiveLevel() == test_level)

    # Check level is set back after block
    assert(l.getEffectiveLevel() != test_level)


if __name__ == '__main__':
    test_case_0()
    test_logger_level()
    print("Tests pass!")

# Generated at 2022-06-26 02:30:16.714964
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    log.info("before level change")

    with logger_level(log, logging.DEBUG):
        log.info("during level change")

    log.info("after level change")



# Generated at 2022-06-26 02:30:24.614153
# Unit test for function configure
def test_configure():
    import inspect
    func = configure
    path = inspect.stack()[1][1]
    code = open(path).read()
    test_code = '\n'.join(
        [i for i in code.split('\n') if 'test_configure' in i]
    )
    assert test_code
    test_code = test_code.split('test_code = """')[1]
    test_code = test_code.split('"""')[0]
    test_code = test_code.replace('\n', '')
    # print(test_code)
    exec(test_code, globals())


# Generated at 2022-06-26 02:30:27.533334
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = logging.getLogger(__name__)
    >>> with logger_level(logger, logging.CRITICAL):
    ...    logger.error('SOME ERROR')
    
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:30:30.473365
# Unit test for function logger_level
def test_logger_level():
    log = get_logger("test")
    log.info("this is an info message")
    log.debug("this is a debug message")

    with logger_level(log, logging.DEBUG):
        log.debug("this is a debug message")
        log.info("this is an info message")


# Generated at 2022-06-26 02:30:37.614101
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.DEBUG)
    logging.getLogger()
    test_logger = logging.getLogger('test_logger_level')
    with logger_level(test_logger,logging.CRITICAL):
        test_logger.info("Testing logger_level function")
        test_logger.warning("Testing logger_level function")
        test_logger.error("Testing logger_level function")
        test_logger.critical("Testing logger_level function")

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:39.800623
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, 40):
        logger.info('test')


# Generated at 2022-06-26 02:30:41.662348
# Unit test for function configure
def test_configure():
    try:
        configure()
    except Exception as e:
        assert type(e) in [ValueError,]



# Generated at 2022-06-26 02:31:04.917682
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.DEBUG):
        assert get_logger().level == logging.DEBUG
        with logger_level(get_logger(), logging.INFO):
            assert get_logger().level == logging.INFO
        assert get_logger().level == logging.DEBUG
    assert get_logger().level == logging.INFO

# Generated at 2022-06-26 02:31:08.186394
# Unit test for function logger_level
def test_logger_level():
    try:
        with logger_level(get_logger('test'), logging.DEBUG):
            get_logger('test').info('Logging enabled.')
    except Exception as e:
        assert False, 'No exception should be thrown: %s' % str(e)
    else:
        assert True


if __name__ == '__main__':
    import nose

    nose.main()

# Generated at 2022-06-26 02:31:13.000820
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    logger.critical("critical before")
    with logger_level(logger, logging.INFO):
        logger.critical("critical during")
        logger.debug("debug during")
    logger.critical("critical after")
    logger.debug("debug after")



# Generated at 2022-06-26 02:31:18.491004
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.ERROR):
        try:
            log.info('test2')
        except TypeError:
            pass

    log.info('test2')


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:31:22.535305
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, 'ERROR'):
        log.error('hello world')
    log.info('this should not show')

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:31:35.622802
# Unit test for function logger_level
def test_logger_level():
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG


if __name__ == '__main__':
    log = getLogger(__name__)
    if _PyInfo.PY2:
        log.warn('Run tests with tox instead.')
    else:
        import doctest
        import colorlog

        colorlog.basicConfig(level=logging.DEBUG)
        doctest.testmod(
            optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE
        )
    sys.exit()

# Generated at 2022-06-26 02:31:37.519216
# Unit test for function logger_level
def test_logger_level():
    a = getLogger(__name__)

    with logger_level(a, 10):
        assert a.getEffectiveLevel() == 10


# Generated at 2022-06-26 02:31:41.377322
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    for i in range(10):
        logger.debug(i)
    with logger_level(logger, logging.INFO):
        for i in range(10):
            logger.debug(i)
    logger = get_logger()
    logger.debug(0)


    pass



# Generated at 2022-06-26 02:31:46.502832
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.CRITICAL):
        log.debug("Message with level DEBUG")
        log.info("Message with level INFO")
        log.warning("Message with level WARNING")
        log.error("Message with level ERROR")
        log.critical("Message with level CRITICAL")


# Generated at 2022-06-26 02:32:00.790866
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import unittest

# Generated at 2022-06-26 02:32:46.310478
# Unit test for function logger_level

# Generated at 2022-06-26 02:32:54.351222
# Unit test for function logger_level
def test_logger_level():
    root = get_logger(__name__)
    root.setLevel(0)
    with logger_level(root, logging.INFO):
        assert root.level == logging.INFO
    assert root.level == 0



if __name__ == '__main__':
    import doctest
    import sys
    import logging

    logger = logging.getLogger('__main__')
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(0)

    if len(sys.argv) > 1:
        result = doctest.testfile(sys.argv[1], globs={'logger': logger})
    else:
        result = doctest.testmod()

    logger.debug('doctest result=%s', result)

# Generated at 2022-06-26 02:32:58.672675
# Unit test for function logger_level
def test_logger_level():
    import logging
    level = logging.DEBUG
    with logger_level(logging.getLogger(), level):
        assert logging.getLogger().level == level
    # logging.getLogger().level = level


if __name__ == '__main__':
    sys.exit(pytest.main(['-s', __file__]))

# Generated at 2022-06-26 02:32:59.580681
# Unit test for function configure
def test_configure():
    var_0 = configure()



# Generated at 2022-06-26 02:33:10.027084
# Unit test for function logger_level
def test_logger_level():
    new_logger = logging.getLogger()
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        filename='test.log',
        filemode='w')

    with logger_level(new_logger, logging.WARNING):
        new_logger.debug("It should not be displayed.")
    new_logger.debug("It should be displayed.")


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:14.745040
# Unit test for function logger_level
def test_logger_level():
    import logging
    import time
    logger1 = logging.getLogger(__name__)
    with logger_level(logger1, logging.INFO):
        logger1.debug("hi")
        logger1.info("hi")
        time.sleep(0.5)
        logger1.error("hi")
        time.sleep(0.5)
    logger1.debug("hi")
    logger1.info("hi")
    time.sleep(0.5)
    logger1.error("hi")



# Generated at 2022-06-26 02:33:17.659783
# Unit test for function get_config
def test_get_config():
    # TODO auto-generate these tests
    test_cases = [
        test_case_0,
    ]
    for test_case in test_cases:
        yield test_case

# Generated at 2022-06-26 02:33:27.505225
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug msg')
        logger.info('info msg')
        logger.warning('warning msg')
        logger.error('error msg')
        logger.critical('critical msg')
    logger.debug('debug msg')
    logger.info('info msg')
    logger.warning('warning msg')
    logger.error('error msg')
    logger.critical('critical msg')



# Generated at 2022-06-26 02:33:31.740485
# Unit test for function logger_level
def test_logger_level():
    self = logger_level
    # AssertionError: 1.23 != 3
    with logger_level(3, 'Test'):
        pass
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

    # test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:39.122418
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)

    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR

    assert logger.level != logging.ERROR


if __name__ == '__main__':
    configure()
    log = get_logger(__name__)
    log.setLevel(logging.DEBUG)
    log.info('test')
    log.error('test')
    log.warning('test')
    log.critical('test')

# Generated at 2022-06-26 02:34:18.858981
# Unit test for function get_config
def test_get_config():
    #  call get_config
    test_get_config_var_env_var = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    #  call get_config
    test_get_config_var_config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    #  call get_config
    test_get_config_var_default = get_config(config=None, env_var=None, default=DEFAULT_CONFIG)
    #  call get_config
    test_get_config_var_config = get_config(config=DEFAULT_CONFIG, env_var=None, default=None)
    #  call get_config

# Generated at 2022-06-26 02:34:20.081042
# Unit test for function get_config
def test_get_config():
    assert (get_config() == DEFAULT_CONFIG)


# Generated at 2022-06-26 02:34:25.228578
# Unit test for function logger_level
def test_logger_level():
    # Tests a simple logger call with logger_level
    with logger_level(get_logger(), logging.WARNING):
        get_logger().warning("Logger level temporarily set to WARNING")
    get_logger().info("Logger level set to INFO")
    # Tests a simple logger call without logger_level
    get_logger().debug("Logger level set to original INFO")


# Generated at 2022-06-26 02:34:31.742339
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test-logger')
    assert logger.getEffectiveLevel() == logging.DEBUG
    logger.info('info message (level 1)')
    logger.warning('warning message (level 1)')

    with logger_level(logger, logging.INFO):
        # logger.info('info message (level 2)')
        logger.warning('warning message (level 2)')

    logger.info('info message (level 1)')



# Generated at 2022-06-26 02:34:38.260789
# Unit test for function get_config
def test_get_config():
    config = dict()
    for elem in DEFAULT_CONFIG.keys():
        config[elem] = DEFAULT_CONFIG[elem]
    assert config == get_config(default=DEFAULT_CONFIG)

    config_string = json.dumps(config)
    assert config == get_config(config_string, default=DEFAULT_CONFIG)

    config_string = yaml.dump(config)
    assert config == get_config(config_string, default=DEFAULT_CONFIG)


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    test_get_config()

# Generated at 2022-06-26 02:34:41.269587
# Unit test for function logger_level
def test_logger_level():
    '''
    >>> log = get_logger()
    >>> with logger_level(log, logging.DEBUG):
    ...     log.debug('should show')
    ...     log.info('should not be seen')
    ...     log.error('should not be seen')
    '''
    pass

# Generated at 2022-06-26 02:34:52.814473
# Unit test for function logger_level
def test_logger_level():
    import os

    (
        log_0, log_1,
    ) = (
        logging.getLogger('log_0'), logging.getLogger('log_1'),
    )
    (
        debug_0, debug_1,
    ) = (
        os.getenv('LOG_0'), os.getenv('LOG_1'),
    )
    if debug_0:
        with open('log_0.txt', 'w') as log_0_txt:
            with logger_level(log_0, level=logging.DEBUG):
                log_0.debug('DEBUG log 0')
            log_0_txt.write(debug_0)
            log_0_txt.close()


# Generated at 2022-06-26 02:34:58.365380
# Unit test for function logger_level
def test_logger_level():
    _has_configured.clear()
    logger_0 = get_logger()
    # Using with statemenst, make sure the logger level is set back to proper level after function call.
    with logger_level(logger_0, logging.INFO):
        logger_0.error("This should not get printed")
        logger_0.info("This is an INFO log message")
        logger_0.debug("This should not get printed")
    logger_0.debug("This should get printed")


# Generated at 2022-06-26 02:35:02.542903
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    from logging import critical, root, WARNING

    log = getLogger()
    with logger_level(log, WARNING):
        assert log.level == WARNING
        assert root.level != WARNING
    assert log.level != WARNING
    assert root.level != WARNING



# Generated at 2022-06-26 02:35:04.697005
# Unit test for function get_config
def test_get_config():
    random_dict = {'key': 'val', 'key1': 'val1'}
    assert get_config(random_dict) == random_dict
