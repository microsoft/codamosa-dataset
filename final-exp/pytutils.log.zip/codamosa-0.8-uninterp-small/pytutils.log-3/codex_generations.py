

# Generated at 2022-06-26 02:26:07.189055
# Unit test for function logger_level
def test_logger_level():
    from io import StringIO

    log = get_logger()
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    log.addHandler(handler)

    log.setLevel(logging.WARNING)
    log.info('LOTS OF INFO')
    assert stream.getvalue() == ''

    log.warning('FOO')
    assert stream.getvalue() == 'FOO\n'
    stream.seek(0)
    stream.truncate(0)

    # Make sure that the logger level resets itself on exit.
    with logger_level(log, logging.INFO):
        log.info('THIS IS INFO')
        assert stream.getvalue() == 'THIS IS INFO\n'
        stream.seek(0)
        stream.truncate(0)

# Generated at 2022-06-26 02:26:18.620028
# Unit test for function get_config
def test_get_config():
    config_1 = get_config(
        given='{"version": 1, "formatters": {"test": {"format": "test", "datefmt": "test"}}}'
    )
    assert isinstance(config_1, dict)
    assert config_1['formatters']['test']['format'] == 'test'
    assert config_1['formatters']['test']['datefmt'] == 'test'

    config_2 = get_config(
        given='''
            version: 1
            formatters:
                test:
                    format: test
                    datefmt: test
        ''',
    )
    assert isinstance(config_2, dict)
    assert config_2['formatters']['test']['format'] == 'test'

# Generated at 2022-06-26 02:26:27.397697
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.INFO


if __name__ == '__main__':
    from pprint import pprint

    configure()
    logger = logging.getLogger()

    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.critical('test')
    logger.error('test')

    pprint(logger.getEffectiveLevel())
    print(logger.level)
    print(logging.DEBUG)
    print(logging.INFO)
    print(logging.WARNING)
    print(logging.ERROR)

# Generated at 2022-06-26 02:26:30.438779
# Unit test for function logger_level
def test_logger_level():
    import mock
    with mock.patch('logging.root') as logger:
        with logger_level(logger, 'info'):
            assert logger.level == 'info'

# Generated at 2022-06-26 02:26:41.235242
# Unit test for function logger_level
def test_logger_level():
    # Logger object
    import logging
    logger = logging.getLogger(__name__)
    test_level = logging.DEBUG

    with logger_level(logger, test_level):
        # Must work with Logger object
        assert logger.getEffectiveLevel() == test_level

    # Not Logger object
    invalid_logger = 5
    try:
        with logger_level(invalid_logger, test_level):
            pass
    except TypeError as e:
        assert str(e) == '{0}'.format(invalid_logger)

    # Test the default level is returned
    default_level = logger.level
    assert logger.getEffectiveLevel() == default_level


# Test case for function get_logger

# Generated at 2022-06-26 02:26:51.930682
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    old_logger = logging.getLogger()
    old_level = old_logger.getEffectiveLevel()
    temp_logger = logging.getLogger("test_logger_level")

    with logger_level(temp_logger, logging.DEBUG):
        assert(temp_logger.getEffectiveLevel() == logging.DEBUG)
        temp_logger.warning("test_logger_level 1")
        assert(temp_logger.getEffectiveLevel() == logging.DEBUG)

    assert(temp_logger.getEffectiveLevel() == old_level)
    temp_logger.warning("test_logger_level 2")
    assert(temp_logger.getEffectiveLevel() == old_level)


if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-26 02:26:58.201003
# Unit test for function get_config
def test_get_config():

    # Testing a config in YAML format
    with open('test_config.yml', 'r') as f:
        config = f.read()
        result = get_config(config, None, None)

# Generated at 2022-06-26 02:27:01.538828
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO


# Generated at 2022-06-26 02:27:05.544376
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.DEBUG


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:27:16.244801
# Unit test for function get_config
def test_get_config():
    random_config = {'key': 'value'}
    random_config_string = json.dumps(random_config)
    default_config = get_config()  # Get default config

    # Test with different input config
    assert get_config(random_config) == random_config
    assert get_config(random_config_string) == random_config
    assert get_config(None) == default_config
    assert get_config('{"key": "value"}') == random_config
    assert get_config('{"key": "value"}', default=random_config) == random_config
    assert get_config(random_config_string, default=random_config) == random_config
    assert get_config(default='{"key": "value"}') == random_config
    assert get_config(default=random_config) == random_

# Generated at 2022-06-26 02:27:23.077340
# Unit test for function configure
def test_configure():
    # Ensure that configure() configures loggers.
    configure()
    test_case_0()
    configure()
    test_case_0()
    configure()
    test_case_0()
    configure()
    test_case_0()


# Generated at 2022-06-26 02:27:28.772018
# Unit test for function logger_level
def test_logger_level():
    import logging
    import contextlib
    import random

    @contextlib.contextmanager
    def logger_level(logger, level):
        """Set logger level to `level` within a context block. Don't use this except for debugging please, it's gross."""
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    logger = logging.getLogger()
    level = random.randint(-1000,1000)
    with logger_level(logger,level):
        assert logger.level == level



# Generated at 2022-06-26 02:27:39.318337
# Unit test for function get_config
def test_get_config():
    # Define variables for the function
    config = None
    env_var = 'LOGGING'
    default = DEFAULT_CONFIG

# Generated at 2022-06-26 02:27:41.985849
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    with logger_level(var_0, 10):
        var_0.debug("Hello world, I'm a debug message")


# Generated at 2022-06-26 02:27:49.929607
# Unit test for function get_config
def test_get_config():
    assert _PyInfo.PY2 == False
    assert _PyInfo.PY3 == True

    import json
    import yaml
    glob_0 = 'requests'
    glob_1 = 'colorlog'
    glob_2 = 'colorlog'
    glob_3 = 'console'
    glob_4 = 'colored'
    glob_5 = 'colored'
    glob_6 = 'colored'
    glob_7 = 'colorlog.ColoredFormatter'
    glob_8 = '%(bg_black)s%(log_color)s'
    glob_9 = '[%(asctime)s] '
    glob_10 = '[%(name)s/%(process)d] '
    glob_11 = '%(message)s '

# Generated at 2022-06-26 02:27:53.527789
# Unit test for function logger_level
def test_logger_level():
    var_1 = logging.getLogger()
    var_2 = None
    with logger_level( var_1, var_2) as var_3:
        var_4 = get_logger()

# Generated at 2022-06-26 02:28:04.018068
# Unit test for function get_config

# Generated at 2022-06-26 02:28:06.155045
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING

# Generated at 2022-06-26 02:28:09.739103
# Unit test for function logger_level
def test_logger_level():
    var_1 = {"aaa" : { "bbb" : { "ccc" : 0 } } }
    var_2 = get_logger(__name__)
    var_3 = {"aaa" : { "bbb" : { "ccc" : 0 } } }


# Generated at 2022-06-26 02:28:14.705636
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logging.INFO
    with logger_level(logger, level):
        assert logger.level == level


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:28:28.584106
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    logger = logging.getLogger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
    assert logger.level == logging.NOTSET
    return logger

if __name__ == "__main__":
    # Run test, if module called directly.
    # Python 3.2.2 (default, Sep  5 2011, 21:17:14)
    # [GCC 4.6.1] on linux2
    # Type "help", "copyright", "credits" or "license" for more information.
    # >>> import loggingconfig
    # >>> loggingconfig.test()

    test_case_0()
    test_logger_level()
    print("TESTS PASSED")

# Generated at 2022-06-26 02:28:32.654561
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:28:37.998145
# Unit test for function get_config
def test_get_config():
    # Test that the function returns the expected output for the given
    # input.
    import json

    test_config = {"version": 1, "formatters": {"simple": {"format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"}}}
    json_config = json.dumps(test_config)

    assert get_config(test_config) == test_config
    assert get_config(json_config) == test_config

# Generated at 2022-06-26 02:28:49.144072
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import unittest
    import io
    import contextlib
    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    class DummyLogger(object):
        def __init__(self):
            self.level = None
        def __repr__(self):
            return "<DummyLogger object>"


# Generated at 2022-06-26 02:28:55.844978
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
    with logger_level(logger, logging.INFO):
        logger.info('test')
    with logger_level(logger, logging.WARNING):
        logger.warning('test')
    with logger_level(logger, logging.ERROR):
        logger.error('test')


# Generated at 2022-06-26 02:29:04.035447
# Unit test for function logger_level
def test_logger_level():
    import logging

    fmt = '%(levelname)s %(message)s'
    logging.basicConfig(format=fmt)

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    logger.info('INFO')
    logger.warning('WARNING')
    logger.error('ERROR')

    with logger_level(logger=logger, level=logging.DEBUG):
        logger.info('INFO')
        logger.warning('WARNING')
        logger.error('ERROR')

test_case_0()
test_logger_level()

# Generated at 2022-06-26 02:29:04.630741
# Unit test for function logger_level
def test_logger_level():
    pass



# Generated at 2022-06-26 02:29:09.217103
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    # assert logger.level == logging.DEBUG

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:29:11.863513
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    initial_level = logger.level
    with logger_level(logger, initial_level):
        assert logger.level == initial_level
    assert logger.level == initial_level

# Generated at 2022-06-26 02:29:19.194988
# Unit test for function logger_level
def test_logger_level():
    
    logger = get_logger('test_logger_level')
    logger.level = 0
    assert logger.level == 0
    logger.debug('DEBUG level', extra={'extra':'123'})
    logger.info('INFO level', extra={'extra':'123'})
    logger.warn('WARN level', extra={'extra':'123'})
    logger.error('ERROR level', extra={'extra':'123'})
    logger.critical('CRITICAL level', extra={'extra':'123'})
    
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        logger.debug('DEBUG level', extra={'extra':'123'})
        logger.info('INFO level', extra={'extra':'123'})

# Generated at 2022-06-26 02:29:26.806497
# Unit test for function logger_level
def test_logger_level():
    """
    >>> log = get_logger()
    >>> old_level = log.level
    >>> with logger_level(log, logging.ERROR) as noop:
    ...     assert log.level == logging.ERROR
    >>> assert old_level == log.level
    """
    pass

# Generated at 2022-06-26 02:29:32.419170
# Unit test for function configure

# Generated at 2022-06-26 02:29:36.371004
# Unit test for function logger_level
def test_logger_level():
    orig_level = logging.INFO
    new_level = logging.DEBUG
    log = get_logger()
    log.setLevel(orig_level)
    with logger_level(log, new_level):
        assert log.level == new_level
    assert log.level == orig_level


# Generated at 2022-06-26 02:29:44.232834
# Unit test for function get_config
def test_get_config():
    assert get_config(config = None, env_var = 'LOGGING') == DEFAULT_CONFIG
    assert get_config(config = None, env_var = None) == DEFAULT_CONFIG
    assert get_config(config = {}, env_var = None, default = None) == {}
    assert get_config(config = '{"loggers": { "test": { "handlers": "console" } } }',
                      env_var = None, default = None) == {'loggers': {'test': {'handlers': 'console'}}}
    assert get_config(config = 'loggers: { test: { handlers: "console" } }',
                      env_var = None, default = None) == {'loggers': {'test': {'handlers': 'console'}}}

# Generated at 2022-06-26 02:29:55.450892
# Unit test for function configure
def test_configure():
    logger = get_logger()
    formatters = {
        'detailed': {
            'format': '%(asctime)s %(name)-15s %(levelname)-8s %(processName)-10s %(message)s',
        },
        'simple': {
            'format': '%(name)-15s %(levelname)-8s %(message)s',
        },
    }
    handlers = {
        'console': {
            'class': 'logging.StreamHandler',
            'level': 'DEBUG',
            'formatter': 'simple',
        },
        'file': {
            'class': 'logging.FileHandler',
            'level': 'DEBUG',
            'formatter': 'detailed',
            'filename': 'app.log',
        },
    }
    loggers

# Generated at 2022-06-26 02:29:59.710776
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger(__name__)
    with logger_level(var_0, logging.DEBUG):
        var_0.debug('test')


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:06.486516
# Unit test for function logger_level
def test_logger_level():
    global count
    var_0 = get_logger()
    with logger_level(var_0, logging.DEBUG):
        var_0.info("Logger Level is set to DEBUG")
        var_0.debug("This is a Debug Message")
    var_0.info("Logger Level is set to INFO")
    var_0.debug("This is a Debug Message")


if __name__ == "__main__":
    configure()
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:08.203534
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log,logging.DEBUG) as level:
        print(level)

test_logger_level()

# Generated at 2022-06-26 02:30:12.905582
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG

    assert logger.getEffectiveLevel() == logging.NOTSET

if __name__ == '__main__':
    # Test Examples:
    test_case_0()

    # Unit Test
    test_logger_level()

    print('Done.')

# Generated at 2022-06-26 02:30:15.978983
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("test")
    with logger_level(logger, logging.INFO):
        logger.debug("Debug")
        logger.info("Info")
        logger.warning("Warning")
        logger.error("error")
        logger.critical("Critical")

# Generated at 2022-06-26 02:30:21.095413
# Unit test for function logger_level
def test_logger_level():
    pass



# Generated at 2022-06-26 02:30:27.526407
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.CRITICAL):
        log.critical('critical example')
        log.error('error example')
        log.debug('debug example')
        log.info('info example')
    log.critical('critical example 2')
    log.error('error example 2')
    log.debug('debug example 2')
    log.info('info example 2')


if __name__ == "__main__":
    configure()
    #test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:29.420954
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    with logger_level(logger, logging.DEBUG):
        logger.debug('TEST')



# Generated at 2022-06-26 02:30:35.608919
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    log_message = "This is to ensure that the logger_level is logging as expected."
    with logger_level(logger, logging.DEBUG):
        logger.debug(log_message)
        logger.debug(log_message)
        logger.debug(log_message)


if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:36.530853
# Unit test for function logger_level
def test_logger_level():
    assert_true(logger_level())


# Generated at 2022-06-26 02:30:46.165854
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys
    import os
    import pytest
    import logging_tools

    logger = logging.getLogger()

    std_out = os.dup(sys.stdout.fileno())
    std_err = os.dup(sys.stderr.fileno())
    devnull_fd = os.open(os.devnull, os.O_WRONLY)
    os.dup2(devnull_fd, sys.stdout.fileno())
    os.dup2(devnull_fd, sys.stderr.fileno())

    logger.setLevel(logging.CRITICAL)
    test_message = "test"

# Generated at 2022-06-26 02:30:50.418499
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger()
    test_logger.setLevel(logging.DEBUG)
    with logger_level(test_logger, logging.INFO):
        assert test_logger.level == logging.INFO
    assert test_logger.level == logging.DEBUG

# Generated at 2022-06-26 02:31:01.794420
# Unit test for function get_config

# Generated at 2022-06-26 02:31:09.387181
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.handlers
    import queue


    # Creating a queue
    q = queue.Queue()

    # Creating a logger and setting log level
    logger = logging.getLogger('my_logger')
    logger.setLevel(logging.INFO)

    # Creating a queue handler and setting formatter
    q_handler = logging.handlers.QueueHandler(q)
    q_format = logging.Formatter('%(levelname)s:%(message)s')
    q_handler.setFormatter(q_format)

    # Adding queue handler to logger
    logger.addHandler(q_handler)

    # Creating console handler and setting level to debug
    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)

    # Creating formatter

# Generated at 2022-06-26 02:31:13.158727
# Unit test for function logger_level
def test_logger_level():
    log = get_logger("test_logger_level")
    with logger_level(log, logging.DEBUG):
        log.info("test_logger_level")


if __name__ == "__main__":
    configure()
    test_logger_level()

# Generated at 2022-06-26 02:31:26.501736
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config

    test_config = {
        'version': 1,
        'formatters': {
            'simple': {
                'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                'datefmt': '%Y-%m-%d %H:%M:%S',
            }
        },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
                'level': logging.DEBUG,
            }
        },
        'loggers': {
            'test': {
                'handlers': ['console'],
                'level': logging.INFO,
            }
        }
    }


# Generated at 2022-06-26 02:31:29.111412
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), logging.INFO):
        test_case_0()



# Generated at 2022-06-26 02:31:38.602132
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARN):
        logger.debug('debug message')
        logger.info('info message')
        logger.warn('warn message')
    logger.debug('debug message')
    logger.info('info message')
    logger.warn('warn message')

if __name__ == '__main__':
    # test_case_0()
    # test_logger_level()
    # get_logger('test').info('test')
    # configure(default={'loggers': {'*': {'level': 'INFO'}}})
    # get_logger('test').debug('test')
    get_logger('test').info('test')

# Generated at 2022-06-26 02:31:45.025770
# Unit test for function get_config
def test_get_config():
    logging_configuration = get_config(given='{"formatters": {"simple": {"format": "%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s", "datefmt": "%Y-%m-%d %H:%M:%S"}}, "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "simple", "level": "DEBUG"}}, "loggers": {"test": {"level": "DEBUG", "handlers": ["console"]}}, "root": {"level": "DEBUG", "handlers": ["console"]}}', env_var=None, default=None)

# Generated at 2022-06-26 02:31:52.906279
# Unit test for function get_config
def test_get_config():
    '''
    Test get_config with config as yaml string.
    '''
    _CONFIG = """
    version: 1
    formatters:
        simple:
            format: '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            datefmt: '%Y-%m-%d %H:%M:%S'
    handlers:
        console:
            class: logging.StreamHandler
            level: DEBUG
            formatter: simple
            stream: ext://sys.stdout
    root:
        level: INFO
        handlers: [console]
    """

    # Test get_config with config as yaml string.
    cfg = get_config(config=_CONFIG)
    assert cfg is not None



# Generated at 2022-06-26 02:32:03.537155
# Unit test for function logger_level
def test_logger_level():
    import inspect

    def validate_context_manager(context_manager, *args, **kwds):
        """Validate a context manager -- borrow from stdlib."""
        if hasattr(context_manager, "__exit__"):
            return all(
                validate_context_manager(context_manager.__exit__, *args, **kwds)
            )
        if not hasattr(context_manager, "__enter__"):
            raise ValueError("Context manager must implement __enter__ and __exit__")
        if inspect.ismethod(context_manager.__enter__):
            if context_manager.__enter__.__self__ is not context_manager:
                raise ValueError("Implementation of __enter__ is not a bound method")

# Generated at 2022-06-26 02:32:14.009097
# Unit test for function logger_level

# Generated at 2022-06-26 02:32:20.282210
# Unit test for function logger_level
def test_logger_level():

    log = get_logger()
    msg = 'This is a test'
    count = 0


    # Test case 0:
    with logger_level(log, logging.CRITICAL):
        test_case_0()
        log.error(msg)
        count = count + 1

    if count == 0:
        print('Unit test for logger_level completed')
    else:
        print('Unit test for logger_level failed')




# Generated at 2022-06-26 02:32:25.084635
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    # The info level should not be logged
    log.setLevel(logging.WARNING)
    with logger_level(log, logging.INFO):
        log.info("This should be logged")
        log.warning("This should be logged as well")
    log.info("This should not be logged")
    log.warning("This should be logged")



# Generated at 2022-06-26 02:32:33.208333
# Unit test for function get_config

# Generated at 2022-06-26 02:32:41.760519
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('logger_level')

    with logger_level(logger, logging.DEBUG):
        logger.debug('test')

# Generated at 2022-06-26 02:32:42.973183
# Unit test for function configure
def test_configure():
    logging_1 = configure()
    assert logging_1 is None


# Generated at 2022-06-26 02:32:45.607883
# Unit test for function configure
def test_configure():
    # log = logging.getLogger(__name__)
    # configure()
    # log.info('test')
    pass



# Generated at 2022-06-26 02:32:51.751930
# Unit test for function logger_level
def test_logger_level():
    # Set logger level to INFO
    logger = logging.getLogger('logger_level')
    with logger_level(logger, logging.INFO):
        logger.setLevel(logging.INFO)
        assert logger.level == logging.INFO

    # Set logger level to DEBUG
    logger = logging.getLogger('logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.setLevel(logging.DEBUG)
        assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:32:55.742475
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    level = logger.level
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == level


if __name__ == '__main__':
    configure()

    log = getLogger()
    log.info('hello')

    from . import pytest_helpers

    pytest_helpers.run_doctests()

# Generated at 2022-06-26 02:32:59.582736
# Unit test for function logger_level
def test_logger_level():
    try:
        assert 2 == (2)
    except:
        logger_level(logging.getLogger('test'), logging.DEBUG)
        logging.exception('AssertionError: %s != %s' % (2, (2)))
        raise



# Generated at 2022-06-26 02:33:03.284225
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, 100):
        logger.critical('Hello World!')



# Generated at 2022-06-26 02:33:13.012000
# Unit test for function logger_level
def test_logger_level():
    with logger_level(test_case_0.var_0, logging.DEBUG):
        with logger_level(test_case_0.var_0, logging.INFO):
            test_case_0.var_0.debug('debug')
            test_case_0.var_0.info('info')
            test_case_0.var_0.warning('warning')
            test_case_0.var_0.error('error')
            test_case_0.var_0.critical('critical')
    with logger_level(test_case_0.var_0, logging.INFO):
        test_case_0.var_0.debug('debug')
        test_case_0.var_0.info('info')
        test_case_0.var_0.warning('warning')
        test_case_0.var

# Generated at 2022-06-26 02:33:25.790607
# Unit test for function get_config
def test_get_config():
    # Test empty argument
    assert get_config(given=None) == DEFAULT_CONFIG

    # Test empty environment variable
    assert get_config(given=None, env_var="TEST_LOGGING", default=None) == None

    # Test given argument with json
    assert get_config(given='{"version": 1}', env_var=None, default=None) == DEFAULT_CONFIG

    # Test given argument with yaml
    assert get_config(given='version: 1', env_var=None, default=None) == DEFAULT_CONFIG

    # Test given argument with bare string

# Generated at 2022-06-26 02:33:29.462030
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("test_logger_level")
    logger.setLevel(logging.WARNING)
    with logger_level(logger, logging.DEBUG):
        logger.debug("This should be visible.")
    logger.debug("This should not be visible.")


# Generated at 2022-06-26 02:33:41.496890
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    logger = get_logger()

    logger.debug("Debug")
    logger.warning("Warning")
    logger.error("Error")

    @contextmanager
    def logger_level(logger, level):
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    with logger_level(logger,logging.ERROR):
        logger.debug("Debug")
        logger.warning("Warning")
        logger.error("Error")
        logger.info("Info")


# Generated at 2022-06-26 02:33:46.214792
# Unit test for function logger_level
def test_logger_level():
    global var_0
    var_0.info("test")
    with logger_level(var_0, logging.DEBUG):
        var_0.info("test2")

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:50.595800
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logger.level
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == level

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:57.354109
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.DEBUG):
        pass
    with logger_level(logging.getLogger(), logging.INFO):
        pass


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:34:06.929593
# Unit test for function get_config
def test_get_config():
    config = dict()

    config['version'] = 1
    config['disable_existing_loggers'] = False

# Generated at 2022-06-26 02:34:14.838863
# Unit test for function logger_level
def test_logger_level():
    name = 'tweepy'
    logger = get_logger(name)
    print('Logging level for %s is %s' % (name, logger.level))
    with logger_level(logger, logging.DEBUG):
        print('Level changed to %s' % logger.level)
        logger.info('test debug')
    print('Level changed to %s' % logger.level)


if __name__ == '__main__':
    print('Testing logger_level')
    test_logger_level()
    print('test_logger_level passed')

# Generated at 2022-06-26 02:34:19.925709
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import logging

    class TestLoggerLevel(unittest.TestCase):
        def test_logger_level(self):
            logger = logging.getLogger(__name__)
            with logger_level(logger, logging.DEBUG):
                self.assertEqual(logger.getEffectiveLevel(), logging.DEBUG)
                logger.error("Hello")
            self.assertEqual(logger.getEffectiveLevel(), logging.DEBUG)

    unittest.main()



# Generated at 2022-06-26 02:34:22.406431
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger('test_logger_level'), logging.DEBUG):
        logging.getLogger('test_logger_level').debug('test_logger_level')


# Generated at 2022-06-26 02:34:34.447291
# Unit test for function get_config
def test_get_config():
    """ testing get_config function """

# Generated at 2022-06-26 02:34:38.193614
# Unit test for function logger_level
def test_logger_level():
    lvl = logging.DEBUG
    """
    >>> test_logger_level()
    """
    with logger_level(logging.getLogger('test_logger_level'), lvl):
        assert logging.getLogger('test_logger_level').getEffectiveLevel() == lvl


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-26 02:34:53.805824
# Unit test for function logger_level
def test_logger_level():
    import uuid
    logger = getLogger()
    log_id = uuid.uuid4()

# Generated at 2022-06-26 02:35:01.315635
# Unit test for function logger_level
def test_logger_level():
    root_logger = logging.getLogger()
    my_logger = logging.getLogger('test_logger_level')

    # check that the root logger level is not set to DEBUG
    assert root_logger.level != logging.DEBUG

    # check that the level of our logger is not set to DEBUG
    assert my_logger.level != logging.DEBUG

    with logger_level(my_logger, logging.DEBUG):
        # check that the level of our logger is set to DEBUG
        assert my_logger.level == logging.DEBUG

    # check that the level of our logger is not set to DEBUG
    assert my_logger.level != logging.DEBUG

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:35:04.620731
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL

    assert logger.level != logging.CRITICAL


# Generated at 2022-06-26 02:35:10.081563
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug("This is a debug message")
        logger.info("This is an info message")
        logger.warning("This is a warning message")
        logger.error("This is an error message")
        logger.critical("This is a critical message")



# Generated at 2022-06-26 02:35:17.420841
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.NOTSET):
        pass

if __name__ == '__main__':
    # test_case_0()
    test_logger_level()
    configure()
    log = getLogger(__name__)

    log.debug('debug message')
    log.info('info message')
    log.warning('warn message')
    log.error('error message')
    log.critical('critical message')

# Generated at 2022-06-26 02:35:19.271922
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.DEBUG):
        assert(get_logger().getEffectiveLevel() == logging.DEBUG)

# Generated at 2022-06-26 02:35:23.457301
# Unit test for function logger_level
def test_logger_level():
    l = get_logger()
    with logger_level(l, logging.WARNING):
        l.debug("I won't be logged")
        l.info("I won't be logged")
    l.debug("Now I will be logged")
    l.info("Now I will be logged")


if __name__ == '__main__':
    import doctest

    doctest.testmod()
    # test_logger_level()

# Generated at 2022-06-26 02:35:30.715830
# Unit test for function logger_level
def test_logger_level():
    test_logger_0 = get_logger()

    with logger_level(test_logger_0, logging.WARNING):
        test_logger_0.debug('Should not show up!')

    with logger_level(test_logger_0, logging.DEBUG):
        test_logger_0.debug('Should show up!')


# Generated at 2022-06-26 02:35:35.915775
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    log.info("Hello world!")
    with logger_level(log, logging.INFO):
        log.info("Hello world!")
    log.info("Hello world!")
    with logger_level(log, logging.DEBUG):
        log.info("Hello world!")
    log.info("Hello world!")


if __name__ == '__main__':
    configure()
    test_logger_level()

# Generated at 2022-06-26 02:35:41.640341
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger()
    assert test_logger.level == logging.DEBUG
    with logger_level(test_logger, logging.INFO):
        assert test_logger.level == logging.INFO
    assert test_logger.level == logging.DEBUG


if __name__ == '__main__':
    import doctest
    doctest.testmod()