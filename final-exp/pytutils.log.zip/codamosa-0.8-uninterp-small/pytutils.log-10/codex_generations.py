

# Generated at 2022-06-26 02:26:01.443832
# Unit test for function logger_level
def test_logger_level():
    test_1 = get_logger()
    test_logger_level_0_context = logger_level(test_1, 20)
    with test_logger_level_0_context:
        test_1.info('Test')
        test_1.debug('Test')
    test_1.debug('Test')
    test_1.info('Test')


# Generated at 2022-06-26 02:26:02.850665
# Unit test for function configure
def test_configure():
    with pytest.raises(ValueError):
        test_case_0()



# Generated at 2022-06-26 02:26:05.999602
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.DEBUG):
        log = get_logger()
        assert log.level == logging.DEBUG
        log.info('test')


# Generated at 2022-06-26 02:26:10.707040
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    old_level = log.level
    with logger_level(log, logging.ERROR):
        log.debug('This is the debug log')
        log.info('This is the info log')
        log.warning('This is the warning log')
        log.error('This is the error log')
        log.critical('This is the critical log')
    assert log.level == old_level


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:26:13.590850
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test')
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG


# TODO make sure this works for py2/3

# Generated at 2022-06-26 02:26:23.995980
# Unit test for function logger_level
def test_logger_level():
    # Test configuring the default logger
    default_log = logging.getLogger()
    assert default_log.level == logging.NOTSET

# Generated at 2022-06-26 02:26:29.553122
# Unit test for function logger_level
def test_logger_level():
    print ('logger_level')
    _ensure_configured()
    log = get_logger()

    with logger_level(log, logging.DEBUG):
        log.debug('test')

    with logger_level(log, logging.INFO):
        log.debug('test2')


# unit test for function configure

# Generated at 2022-06-26 02:26:34.598383
# Unit test for function logger_level
def test_logger_level():
    var_0 = configure()
    var_1 = get_logger(__name__)
    with logger_level(var_1, logging.WARNING):
        assert var_1.getEffectiveLevel() == logging.WARNING
        assert var_1.isEnabledFor(logging.WARNING)
        assert not var_1.isEnabledFor(logging.INFO)

# Generated at 2022-06-26 02:26:38.399681
# Unit test for function logger_level
def test_logger_level():
    """Unit test for logger_level."""
    var_2 = configure()
    var_3 = get_logger()
    var_4 = logger_level(var_3, 10)
    var_5 = var_4.__enter__()
    var_5
    var_11 = var_4.__exit__(None, None, None)
    var_11

if __name__ == '__main__':
    import nose

    nose.main()

# Generated at 2022-06-26 02:26:41.888924
# Unit test for function configure
def test_configure():
    print('Testing configure.py')
    test_case_0()

if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-26 02:26:48.059449
# Unit test for function logger_level
def test_logger_level():

    logger = logging.Logger('foo', level = 100)
    level = 1
    with logger_level(logger, level):
        assert logger.level == level



# Generated at 2022-06-26 02:26:52.879089
# Unit test for function logger_level
def test_logger_level():
    test_logger = getLogger('test')
    test_logger.setLevel(logging.DEBUG)
    initial_level = test_logger.level

    with logger_level(test_logger, initial_level + 10):
        assert test_logger.level == initial_level + 10

    assert test_logger.level == initial_level



# Generated at 2022-06-26 02:27:00.836883
# Unit test for function logger_level
def test_logger_level():
    tests = [
        (None, '', "", ''),
        ('', '', "", ''),
    ]
    for t in tests:
        inp = t[0]
        outp = t[1]
        assert logger_level(inp) == outp


if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:27:04.910386
# Unit test for function get_config
def test_get_config():
    os.environ["MYLOGGING"] = "foo"
    cfg = get_config(config=None, env_var='MYLOGGING', default=DEFAULT_CONFIG)
    assert cfg == 'foo'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:27:07.361431
# Unit test for function configure
def test_configure():
    cfg = get_config(default=DEFAULT_CONFIG)
    assert cfg == DEFAULT_CONFIG
    print("test_configure success")



# Generated at 2022-06-26 02:27:10.129556
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    log.info('test')
    logger_level(log, logging.DEBUG)
    log.debug('this is debug')


# Generated at 2022-06-26 02:27:18.835814
# Unit test for function logger_level
def test_logger_level():
    from io import StringIO

    # Capture stdout to save it from the clutches of ColorFormatter
    saved_stdout = sys.stdout
    sys.stdout = StringIO()

    configure()
    log = get_logger(__name__)

    with logger_level(log, logging.WARN):
        log.info('will not print!')

    log.info('this will print!')

    # Put stdout back where it was
    sys.stdout.flush()
    sys.stdout = saved_stdout

    if 'will not print!' in sys.stdout.getvalue():
        raise Exception('This test should not write any output!')

# Generated at 2022-06-26 02:27:22.176034
# Unit test for function configure
def test_configure():
    try:
        test_case_0()
        assert isinstance(var_0, dict)
    except NameError as e:
        raise Exception(e) from None

if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-26 02:27:24.936733
# Unit test for function logger_level
def test_logger_level():
    name = 'logger_level'

    logger = get_logger(name)
    logger.info('before')

    assert logger.level == logging.DEBUG

    with logger_level(logger, logger.NOTSET):
        logger.info('notset')
        assert logger.level == logging.NOTSET

    logger.info('after')
    assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:27:27.187571
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logging.INFO
    with logger_level(logger, level):
        pass



# Generated at 2022-06-26 02:27:38.655190
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.CRITICAL):
        logger.info("Logging should not run")
    with logger_level(logger, logging.INFO):
        logger.info("Logging should run")



# Generated at 2022-06-26 02:27:48.110249
# Unit test for function logger_level
def test_logger_level():
    # Test with level = 'DEBUG'
    with logger_level(logging.getLogger('test'), 'DEBUG'):
        assert logging.getLogger('test').level == 10

    # Test with level = 'INFO'
    with logger_level(logging.getLogger('test'), 'INFO'):
        assert logging.getLogger('test').level == 20

    # Test with level = 'WARNING'
    with logger_level(logging.getLogger('test'), 'WARNING'):
        assert logging.getLogger('test').level == 30

    # Test with level = 'ERROR'
    with logger_level(logging.getLogger('test'), 'ERROR'):
        assert logging.getLogger('test').level == 40

    # Test with level = 'CRITICAL'

# Generated at 2022-06-26 02:27:49.628308
# Unit test for function configure
def test_configure():
    front_end_logger_0 = configure()



# Generated at 2022-06-26 02:27:53.626122
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__ + '.test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('Debug message')
        logger.info('Info message')



# Generated at 2022-06-26 02:27:55.058878
# Unit test for function get_config
def test_get_config():
    config = get_config()
    assert config is not None



# Generated at 2022-06-26 02:27:59.143323
# Unit test for function logger_level
def test_logger_level():
    root_logger = configure()
    assert_false(root_logger.getEffectiveLevel() == logging.DEBUG)

    with logger_level(root_logger, logging.DEBUG):
        assert_equal(root_logger.getEffectiveLevel(), logging.DEBUG)

    assert_false(root_logger.getEffectiveLevel() == logging.DEBUG)



# Generated at 2022-06-26 02:28:07.572916
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.debug("This message should appear on the console below:")
    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
        logger.debug("This message should NOT be logged.")
        logger.warning("This message should be logged.")

    assert logger.level == logging.DEBUG
    logger.debug("This message should appear once again.")


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:28:19.183964
# Unit test for function logger_level
def test_logger_level():
    # Test for function logger_level
    import logging

    test_logger = logging.getLogger()

    # Test for level: DEBUG
    with logger_level(test_logger, logging.DEBUG):
        assert test_logger.isEnabledFor(logging.DEBUG)

    # Test for level: INFO
    with logger_level(test_logger, logging.INFO):
        assert test_logger.isEnabledFor(logging.INFO)

    # Test for level: WARNING
    with logger_level(test_logger, logging.WARNING):
        assert test_logger.isEnabledFor(logging.WARNING)

    # Test for level: ERROR
    with logger_level(test_logger, logging.ERROR):
        assert test_logger.isEnabledFor(logging.ERROR)

    # Test for level: CRITICAL

# Generated at 2022-06-26 02:28:28.770769
# Unit test for function get_config
def test_get_config():
    logger = get_logger(__name__)
    config1 = get_config(given=None,env_var=None,default=DEFAULT_CONFIG)
    config2 = get_config(given=None, env_var='LOGGING', default=None)
    config3 = get_config(given=None, env_var=None, default=None)
    log_config1 = logging.config.dictConfig(config1)
    log_config2 = logging.config.dictConfig(config2)
    log_config3 = logging.config.dictConfig(config3)
    logger.info(log_config1)
    logger.info(log_config2)
    logger.info(log_config3)


# Generated at 2022-06-26 02:28:30.314505
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')



# Generated at 2022-06-26 02:28:48.928653
# Unit test for function get_config
def test_get_config():
    # Test for config string given
    assert get_config('{"logging":"config"}') == {'logging': 'config'}

    # Test for config as dict given
    assert get_config({'logging': 'config'}) == {'logging': 'config'}

    # Test for config as json string
    assert get_config('{"logging": "config"}') == {'logging': 'config'}

    # Test for config as yaml string
    assert get_config('logging: config') == {'logging': 'config'}

    # Test for config as invalid string
    try:
        get_config('{"logging": "config"')
    except ValueError:
        pass
    else:
        assert False

    # Test for config as yaml string with extra space
    assert get_config(' logging: config')

# Generated at 2022-06-26 02:28:51.461922
# Unit test for function logger_level
def test_logger_level():
    print('Test Case: test_logger_level')
    test_case_0()

if __name__ == '__main__':

    test_logger_level()

# Generated at 2022-06-26 02:29:03.369555
# Unit test for function logger_level
def test_logger_level():
    print("Testing logger_level")
    log = get_logger()
    logger_level(log, logging.DEBUG)  # Sets logger level to DEBUG
    log.debug("Debug level message")  # Should be printed because debug level messages are not filtered
    logger_level(log, logging.WARNING)  # Sets logger level to WARNING
    log.debug("Debug level message")  # Should not be printed because debug level messages are filtered
    log.warning("Warning level message")  # Should be printed because warning level messages are not filtered
    logger_level(log, logging.CRITICAL)  # Sets logger level to CRITICAL
    log.warning("Warning level message")  # Should not be printed because warning level messages are filtered
    log.critical("Critical level message")  # Should be printed because critical level messages are not filtered



# Generated at 2022-06-26 02:29:07.401685
# Unit test for function configure
def test_configure():
    logger = logging.getLogger('test-logger')
    print('\nTesting function configure')
    try:
        configure(default=DEFAULT_CONFIG)
    except ValueError as e:
        return
    logger.info('test')


# Generated at 2022-06-26 02:29:10.923238
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger')
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
    assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:29:15.103030
# Unit test for function logger_level
def test_logger_level():
    """Test for logger_level function."""
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.info("This is a test for the logger_level function.")
        assert logger.level == logging.INFO
    logger.info("This is a test for the logger_level function.")
    assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:29:18.663961
# Unit test for function logger_level
def test_logger_level():
    LOG = logging.getLogger('test_logger_level')
    with logger_level(LOG, logging.CRITICAL):
        LOG.warn('test')

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:29:28.324119
# Unit test for function logger_level
def test_logger_level():
    import io
    import sys
    import logging

    log = logging.getLogger('logger_level')

    # Set up a simple handler and corresponding logger
    out = io.StringIO()
    h = logging.StreamHandler(out)
    log.addHandler(h)
   
    # Make sure the logger has no messages logged
    assert len(out.getvalue()) == 0

    while True:
        # Log a message at the DEBUG level
        with logger_level(log, logging.DEBUG):
            log.debug("debug")
        # Log a message at the INFO level
        with logger_level(log, logging.INFO):
            log.info("info")
        # Log a message at the WARN level
        with logger_level(log, logging.WARN):
            log.warn("warn")
        # Log a message at the ERROR level

# Generated at 2022-06-26 02:29:31.069185
# Unit test for function logger_level
def test_logger_level():

    log = get_logger()

    with logger_level(log, logging.ERROR):
        log.info('test')

    # log.info('test')


# Generated at 2022-06-26 02:29:35.097540
# Unit test for function logger_level
def test_logger_level():
    from unittest import mock
    with mock.patch.object(logging, 'getLogger') as get_logger:
        log = get_logger.return_value
        with logger_level(log, 1):
            assert log.level == 1
        assert log.level != 1


# Generated at 2022-06-26 02:29:48.645485
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.ERROR):
        logger.error("Error")
        logger.info("Info")


if __name__ == '__main__':
    print(test_case_0.__doc__)
    test_case_0()
    test_logger_level()
    print('test end')

# Generated at 2022-06-26 02:29:58.269449
# Unit test for function logger_level
def test_logger_level():
    """Test for logger_level"""
    class Test_Exception(Exception):
        def __init__(self, value):
            self.value = value
        def __str__(self):
            return repr(self.value)

    logging.basicConfig(format='%(asctime)s %(levelname)s: %(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S',
                        level=logging.DEBUG)
    with logger_level(logging.getLogger(), logging.DEBUG) as _logger:
        try:
            raise Test_Exception
        except Test_Exception:
            logging.exception("")


# Generated at 2022-06-26 02:30:03.715174
# Unit test for function configure
def test_configure():
    try:
        test_case_0()
    except TypeError as e:
        if 'test_logging.py' in str(e):
            raise SystemExit('Test failed for:' +
                '\n\tfunction configure' +
                '\n\tfile: test_logging.py' +
                '\n\tfunction: test_case_0')



# Generated at 2022-06-26 02:30:07.665900
# Unit test for function logger_level
def test_logger_level():

    # Variables
    logger = None
    level = None
    initial = None
    level = None

    # Setup
    logger = getLogger()

    # Test
    with logger_level(logger, level):
        assert logger.level == level
    assert logger.level == initial


# Generated at 2022-06-26 02:30:11.421303
# Unit test for function logger_level
def test_logger_level():
    utility_logger = get_logger('utility')
    with logger_level(utility_logger, logging.INFO):
        utility_logger.debug('debug')
        utility_logger.info('info')

    assert utility_logger.level == logging.INFO
    assert logging.getLogger('utility').level == logging.DEBUG



# Generated at 2022-06-26 02:30:13.584754
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logging.DEBUG == logger.level
    assert logging.INFO == logger.level


# Generated at 2022-06-26 02:30:18.154832
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.info("test")
    logger.info("test")

__all__ = [
    'configure',
    'get_logger',
    'getLogger',
    'logger_level',
]

if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:20.979018
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('coyote')
    with logger_level(log, logging.WARNING):
        log.debug('This should not be printed')
    log.info('This should be printed')



# Generated at 2022-06-26 02:30:23.581991
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.DEBUG):
        get_logger().debug('debug level')

    get_logger().debug('debug level')



# Generated at 2022-06-26 02:30:30.624830
# Unit test for function get_config
def test_get_config():
    print("Inside function test_get_config")
    # test function with no input
    assert(get_config()==DEFAULT_CONFIG)

    # test function with json input
    json_config = json.dumps(DEFAULT_CONFIG)
    assert(get_config(json_config)==DEFAULT_CONFIG)

    # test function with yaml input
    yaml_config = yaml.dump(DEFAULT_CONFIG)
    assert(get_config(yaml_config)==DEFAULT_CONFIG)

    # test function with incorrect input
    assert(get_config('}')==DEFAULT_CONFIG)
    print("Leaving function test_get_config")


# Generated at 2022-06-26 02:30:40.504768
# Unit test for function logger_level
def test_logger_level():
    var_0 = logger_level(logger=logging.getLogger(), level=logging.DEBUG)
    with var_0:
        pass



# Generated at 2022-06-26 02:30:43.929511
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO

    assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:30:54.060626
# Unit test for function get_config
def test_get_config():
    # Test with empty config
    config = get_config(config=None, env_var=None, default=None)
    assert isinstance(config, dict)
    assert len(config) == 0

    # Test with json config
    config = get_config(config=None,
                        env_var='LOGGING',
                        default=DEFAULT_CONFIG)
    assert isinstance(config, dict)
    assert len(config) != 0

    # Test with yaml config
    import json
    import yaml
    config_str = json.dumps(DEFAULT_CONFIG)
    config_str = yaml.dump(config_str)
    config = get_config(config=config_str,
                        env_var=None,
                        default=None)
    assert isinstance(config, dict)
    assert len(config)

# Generated at 2022-06-26 02:30:56.502641
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.WARNING):
        assert log.level == logging.WARNING
    assert log.level == logging.DEBUG


# Generated at 2022-06-26 02:30:58.727023
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('testing')
    logger.info('testing info')
    with logger_level(logger, logging.INFO):
        logger.warning('testing warning')
        assert logger.level == logging.INFO


if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-26 02:31:02.188911
# Unit test for function logger_level
def test_logger_level():
    logger=logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG


# Generated at 2022-06-26 02:31:05.420379
# Unit test for function logger_level
def test_logger_level():
    print('Testing logger_level function')
    x=logger_level(logging.getLogger('test'), logging.INFO)
    print(x)
    assert x is None


# Generated at 2022-06-26 02:31:09.029710
# Unit test for function logger_level
def test_logger_level():
    log_level = 5
    logger = logging.getLogger(__name__)

    with logger_level(logger, log_level) as _:
        assert log_level == logger.level
    assert logging.DEBUG == logger.level


# Generated at 2022-06-26 02:31:20.577302
# Unit test for function logger_level
def test_logger_level():
    a = 1
    with logger_level(get_logger(), logging.INFO):
        a = 2
        logging.critical("critical")
        logging.error("error")
        logging.warn("warn")
        logging.info("info")
        logging.debug("debug")
    assert a == 2
    a = 1
    with logger_level(get_logger(), logging.WARNING):
        a = 2
        logging.critical("critical")
        logging.error("error")
        logging.warn("warn")
        logging.info("info")
        logging.debug("debug")
    assert a == 2
    a = 1
    with logger_level(get_logger(), logging.DEBUG):
        a = 2
        logging.critical("critical")
        logging.error("error")
        logging.warn("warn")

# Generated at 2022-06-26 02:31:27.577563
# Unit test for function logger_level

# Generated at 2022-06-26 02:31:39.699945
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.ERROR):
        log.error('This done be logged, yo')
        log.debug('This not logged')
    log.info('This also logged')


if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:31:41.939364
# Unit test for function configure
def test_configure():
    print("Unit test for configure")
    var_0 = configure()


# Generated at 2022-06-26 02:31:48.405635
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.log(logging.INFO, "Test logger_level function")
    with logger_level(logger, logging.DEBUG):
        logger.log(logging.INFO, "Test logger_level function")

if __name__ == "__main__":
    # test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:31:54.010913
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("test")
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug level")
    with logger_level(logger, logging.INFO):
        logger.info("info level")
    with logger_level(logger, logging.WARNING):
        logger.warn("warn level")
    with logger_level(logger, logging.ERROR):
        logger.error("error level")
    with logger_level(logger, logging.CRITICAL):
        logger.critical("critical level")
    print("New Logger")
    print(logger)
    test_logger = logging.getLogger("test2")
    

if __name__ == "__main__":
    import click


# Generated at 2022-06-26 02:32:04.766247
# Unit test for function get_config
def test_get_config():
    # Get the config as dict
    dict_cfg = get_config(config=DEFAULT_CONFIG)
    for k, v in dict_cfg.items():
        assert k in DEFAULT_CONFIG
        assert v == DEFAULT_CONFIG[k]
    # Get the config as yaml
    yaml_cfg = get_config(config=yaml.dump(DEFAULT_CONFIG))
    for k, v in yaml_cfg.items():
        assert k in DEFAULT_CONFIG
        assert v == DEFAULT_CONFIG[k]
    # Get the config as json
    json_cfg = get_config(config=json.dumps(DEFAULT_CONFIG))
    for k, v in json_cfg.items():
        assert k in DEFAULT_CONFIG
        assert v == DEFAULT_CONFIG[k]



# Generated at 2022-06-26 02:32:11.000862
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.DEBUG)
    my_logger = logging.getLogger('my_logger')
    with logger_level(my_logger, logging.FATAL):
        assert my_logger.level == logging.FATAL
    assert my_logger.level != logging.FATAL


if __name__ == '__main__':
    test_case_0()
    test_logger_level()
    sys.exit(0)

# Generated at 2022-06-26 02:32:15.781881
# Unit test for function logger_level
def test_logger_level():
    
    logger = logging.getLogger("logger_level_test")
    
    with logger_level(logger, logging.CRITICAL):
        assert logger.getEffectiveLevel() == logging.CRITICAL
        logger.error("you should not see this")
    assert logger.getEffectiveLevel() != logging.CRITICAL
    logger.error("you should see this")


# Generated at 2022-06-26 02:32:21.334987
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger()
    assert log.getEffectiveLevel() == 10, "logger.level is 10"
    
    with logger_level(log, 30):
        assert log.getEffectiveLevel() == 30, "logger.level is 30"
        
    assert log.getEffectiveLevel() == 10, "logger.level is 10"
    

# Generated at 2022-06-26 02:32:28.162397
# Unit test for function logger_level
def test_logger_level():
    import logging
    import zero.logging
    l = logging.getLogger('zero.logging_test')

    # This should not print
    l.info('blah')
    with logger_level(l, logging.DEBUG):
        # This should print
        l.info('blah')

    # This should not print again
    l.info('blah')


if __name__ == '__main__':
    import sys
    import doctest

    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-26 02:32:30.298408
# Unit test for function logger_level
def test_logger_level():
    config = get_config()
    configure(config)
    log = get_logger()
    logger_level(log, logging.CRITICAL)



# Generated at 2022-06-26 02:32:42.662532
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("Test")

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 02:32:48.060357
# Unit test for function logger_level
def test_logger_level():
    class T(object):
        '''Simulates the logger and associated level.
        '''
        def __init__(self):
            self.logger_level = 'passing value'
    t = T()
    with logger_level(t, 'changed value'):
        assert(t.logger_level == 'changed value')
    assert(t.logger_level == 'passing value')



# Generated at 2022-06-26 02:32:55.615071
# Unit test for function logger_level
def test_logger_level():
    config_0 = get_config()
    var_0 = configure()
    var_1 = get_logger()
    var_0 = configure()
    var_2 = get_logger()
    var_0 = configure()
    var_3 = get_logger()
    var_0 = configure()
    var_4 = get_logger()
    var_0 = configure()
    var_5 = get_logger()
    var_0 = configure()
    var_6 = get_logger()
    var_0 = configure()
    with logger_level() as var_7:
        var_8 = var_7.info()
        var_9 = var_7.info()
        with logger_level() as var_10:
            var_11 = var_10.info()
            var_9 = var_

# Generated at 2022-06-26 02:33:07.600031
# Unit test for function logger_level
def test_logger_level():
    '''
        This function test for the function logger_level
        Steps:
            - Configure a logger with file handler
            - Create a logger_level context block
            - Inside the context block, send a log message and check
            the file if the log is updated
            - After exiting the context block, send a message and check
            the file again
        '''
    import tempfile
    import os

# Generated at 2022-06-26 02:33:11.549566
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('blah')
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level != logging.DEBUG


if __name__ == "__main__":
    configure(default=DEFAULT_CONFIG)
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:13.585457
# Unit test for function logger_level
def test_logger_level():
    mock_logger = Mock()
    with logger_level(mock_logger, logging.DEBUG):
        mock_logger.setLevel.assert_called_with(DEBUG)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:33:26.832666
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import os
    import logging

    tf0 = tempfile.NamedTemporaryFile(suffix='.log', delete=False)
    var_0 = tf0.name
    tf0.close()
    var_1 = logging.basicConfig(filename=var_0, format='%(asctime)s %(message)s')
    var_2 = logging.getLogger(__name__)
    var_3 = var_2.setLevel(logging.DEBUG)
    var_4 = logger_level(var_2, logging.INFO)

# Generated at 2022-06-26 02:33:32.771313
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    import inspect
    import sys
    import os

    logging.basicConfig(level=logging.DEBUG)
    def test_inner():
        var_1 = logger_level(logging.root, logging.INFO)
        var_2 = test_inner2()
        return var_2
    def test_inner2():
        var_3 = logger_level(logging.root, logging.DEBUG)
        var_4 = logging.root.debug('test')
        return var_4
    var_5 = test_inner()


# Generated at 2022-06-26 02:33:36.582146
# Unit test for function logger_level
def test_logger_level():
    LOGGER = get_logger()

    with logger_level(LOGGER, logging.DEBUG):
        print(LOGGER.level)
        assert LOGGER.level == logging.DEBUG

# Generated at 2022-06-26 02:33:40.321425
# Unit test for function configure
def test_configure():
    print(test_case_0())



# Generated at 2022-06-26 02:33:54.344125
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    # test_invalid_config
    with pytest.raises(ValueError):
        get_config()

    # test_from_string_bare
    assert get_config('foo bar baz') == 'foo bar baz'

    # test_from_string_json
    assert get_config('{"foo": "bar"}') == json.loads('{"foo": "bar"}')

    # test_from_string_yaml
    assert get_config('foo: bar') == yaml.load('foo: bar')

    # test_from_dict
    assert get_config({'foo': 'bar'}) == {'foo': 'bar'}

    # test_from_list
    assert get_config(['foo', 'bar']) == ['foo', 'bar']


# Generated at 2022-06-26 02:33:59.017529
# Unit test for function logger_level
def test_logger_level():
    print(sys.path)
    print(os.environ["PYTHONPATH"])
    logger = get_logger()
    logger.debug("debug test:")
    logger.info("info test")
    logger.warning("warning test")
    logger.error("error test")
    
    

# Generated at 2022-06-26 02:34:02.563531
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.CRITICAL):
        get_logger().info("This is not printed")


test_case_0()
test_logger_level()

# Generated at 2022-06-26 02:34:05.344725
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.INFO):
        logger.info("logger_level")
        assert logger.level == logging.INFO


# Generated at 2022-06-26 02:34:06.213623
# Unit test for function configure
def test_configure():

    configure()



# Generated at 2022-06-26 02:34:12.101136
# Unit test for function logger_level
def test_logger_level():
    var_1 = getLogger().level
    assert var_1 == 20
    var_2 = getLogger('test1')
    with logger_level(var_2, 30):
        assert var_2.level == 30
    assert var_2.level == 20


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:34:20.122976
# Unit test for function logger_level
def test_logger_level():
    import logging
    import inspect
    import unittest
    from contextlib import contextmanager

    l = logging.getLogger(__name__)
    log_dict = {logging.DEBUG: 'DEBUG', logging.INFO: 'INFO', logging.ERROR: 'ERROR'}

    def log_level(level):
        """Logs the current calling level. It's weird, but it's OK."""
        l.log(level, log_dict[level])
        return level + 1

    @contextmanager
    def logger_level(logger, level):
        """Set logger level to `level` within a context block. Don't use this except for debugging please, it's gross."""
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial


# Generated at 2022-06-26 02:34:31.427226
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert(log.level == logging.DEBUG)
    assert(log.level == logging.INFO)

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description='Test configuration of python logging.'
    )

    parser.add_argument(
        '--config',
        type=str,
        help='Logging configuration to parse',
    )

    args = parser.parse_args()

    _ensure_configured()

    if args.config:
        configure(args.config)

    # import pytest
    # pytest.main(sys.argv[1:])  # NOQA
    # test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:34:36.996939
# Unit test for function logger_level
def test_logger_level():
    """
    >>> log = getLogger()
    >>> with logger_level(log, logging.ERROR):
    ...    log.error('test')
    >>> with logger_level(log, logging.WARNING):
    ...    log.warning('test')
    >>> with logger_level(log, logging.INFO):
    ...    log.info('test')
    >>> with logger_level(log, logging.DEBUG):
    ...    log.debug('test')
    """



# Generated at 2022-06-26 02:34:39.765390
# Unit test for function logger_level
def test_logger_level():
    # content of test_sample.py
    def func(x):
        return x + 1

    def test_answer():
        assert func(3) == 5



# Generated at 2022-06-26 02:34:53.407970
# Unit test for function logger_level
def test_logger_level():
    logger_test = logging.getLogger(__name__)
    with logger_level(logger_test, logging.DEBUG):
        assert logger_test.getEffectiveLevel() == logging.DEBUG
    assert logger_test.getEffectiveLevel() == logging.NOTSET


# Generated at 2022-06-26 02:34:57.678716
# Unit test for function logger_level
def test_logger_level():
    try:
        # Initialization
        logger = logging.getLogger('name')

        # Execution
        with logger_level(logger, logging.INFO):
            pass

    # Assertions
    except AssertionError:
        raise
    except Exception as e:
        raise AssertionError('Got unexpected exception {}'.format(e))


# Generated at 2022-06-26 02:34:59.918541
# Unit test for function configure
def test_configure():
    logging.config.dictConfig(DEFAULT_CONFIG)
    print("Testing configure")
    test_case_0()


if __name__ == '__main__':
    configure()
    test_configure()

# Generated at 2022-06-26 02:35:04.997794
# Unit test for function logger_level
def test_logger_level():
    # Load logger
    logger = get_logger()

    # Set logger to DEBUG level
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
        # Change log level back to INFO
        logger.setLevel(logging.INFO)


# Generated at 2022-06-26 02:35:15.802579
# Unit test for function get_config
def test_get_config():
    print("\n\nUnit testing for function get_config:")
    # Test sample

# Generated at 2022-06-26 02:35:18.884754
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.info('test')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:35:28.156326
# Unit test for function get_config
def test_get_config():
    print()
    print("---TESTING FOR FUNCTION get_config---")
    # JSON string
    print("JSON String:")
    config = get_config(config = '{"name": "Test"}')
    print(config)
    print()
    # YAML string
    print("YAML String:")
    config2 = get_config(config = '{"name": "Test"}')
    print(config2)
    print()
    # Nested JSON string
    print("Nested JSON String:")

# Generated at 2022-06-26 02:35:34.183505
# Unit test for function get_config
def test_get_config():
    assert get_config(default='test_default') == 'test_default'
    assert get_config(config='test_config') == 'test_config'
    assert get_config(env_var='test_env_var') == 'test_env_var'
    assert get_config(env_var='logging') == 'logging'
    assert get_config(env_var='LOGGING') == 'LOGGING'


# Generated at 2022-06-26 02:35:46.472897
# Unit test for function logger_level
def test_logger_level():
    # TODO: migrate this test (and the others) over to
    #   pytest-mock with the mock.patch decorator.
    from contextlib import contextmanager
    from unittest import TestCase

    import logging
    import sys

    log = logging.getLogger('test_logger_level')
    log.setLevel(logging.INFO)
    log.debug('test this')
    log.debug('test that')

    class TestLoggerLevel(TestCase):
        def test_enable(self):
            captured = []

            @contextmanager
            def capture(stream=sys.stdout):
                stream = getattr(sys, stream)
                old = stream.write
                stream.write = captured.append
                try:
                    yield
                finally:
                    stream.write = old


# Generated at 2022-06-26 02:35:50.949427
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.WARNING):
        logger.info('debug message')
        logger.warning('warning message')
        assert logger.level == logging.WARNING
