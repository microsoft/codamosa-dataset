

# Generated at 2022-06-26 02:26:02.472269
# Unit test for function logger_level
def test_logger_level():
    # Declare logger as local variable in test_logger_level
    logger = getLogger()
    # Set logger level to 40
    logger_level(logger,40)

    # Assign logger level to variable
    logger_level_value = logger.level

    # Use assertEqual to check the actual and expected are equal
    assertEqual(logger_level_value,40)


# Generated at 2022-06-26 02:26:10.822572
# Unit test for function logger_level
def test_logger_level():
    stream = StringIO()

    # Initial logger configuration

# Generated at 2022-06-26 02:26:14.608026
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('foo')
    logger.debug('bar')

    """
    Expected result:
    Level debug: 'foo' | Level default: 'bar'
    """



# Generated at 2022-06-26 02:26:18.042039
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.INFO):
        logging.info('INFO')
        with logger_level(logging.getLogger(), logging.DEBUG):
            logging.debug('DEBUG')
            logging.info('INFO')



# Generated at 2022-06-26 02:26:24.150533
# Unit test for function get_config
def test_get_config():
    dict_config = get_config(default=DEFAULT_CONFIG)
    assert dict_config == DEFAULT_CONFIG

    json_string = '{"version": 1}'
    dict_config = get_config(config=json_string)
    assert dict_config == {"version": 1}

    yaml_string = """
    version: 1
    """
    dict_config = get_config(config=yaml_string)
    assert dict_config == {"version": 1}



# Generated at 2022-06-26 02:26:31.811614
# Unit test for function configure
def test_configure():
    try:
        configure()
    except SystemExit:
        assert False, "Incorrect behaviour"
    except ImportError:
        assert False, "Incorrect behaviour"
    except:
        assert True, "Correct behaviour"

    try:
        configure(env_var='LOG_CFG')
    except SystemExit:
        assert False, "Incorrect behaviour"
    except ImportError:
        assert False, "Incorrect behaviour"
    except:
        assert True, "Correct behaviour"


# Generated at 2022-06-26 02:26:37.248804
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), 10):
        getLogger().info('test')
        assert True


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:26:46.689017
# Unit test for function logger_level
def test_logger_level():
    # Initialize the logger globally
    configure()
    logger = getLogger()
    level = logger.level
    # Inject the logger_level function
    with logger_level(logger, logging.DEBUG):
        # Check if the level is updated
        if logger.level != logging.DEBUG:
            raise AssertionError("logger.level was not updated")
        # End logger_level context block
    # Check if the level is again the same as initially
    if logger.level != level:
        raise AssertionError("logger.level was not set back")



# Generated at 2022-06-26 02:26:55.410299
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    from colorlog import ColoredFormatter

    # Initialize logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    # Create console handler and set level to debug
    ch = logging.StreamHandler()

    # Create formatter
    formatter = ColoredFormatter(
        "%(log_color)s%(levelname)-8s%(reset)s %(white)s%(message)s",
        datefmt=None,
        reset=True,
        log_colors={
            'DEBUG':    'cyan',
            'INFO':     'green',
            'WARNING':  'yellow',
            'ERROR':    'red',
            'CRITICAL': 'red',
        }
    )

    # Add formatter

# Generated at 2022-06-26 02:27:02.487269
# Unit test for function logger_level
def test_logger_level():
    log_level = 3
    with logger_level(logging.getLogger('test_logger_level'), log_level):
        assert logging.getLogger('test_logger_level').level == log_level

if __name__ == '__main__':
    try:
        test_case_0()
        test_logger_level()
        print("Tests passed")
    except AssertionError:
        print("Tests failed")

# Generated at 2022-06-26 02:27:09.470534
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    initial = logger.level
    assert initial == logging.DEBUG
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
    assert logger.level == initial



# Generated at 2022-06-26 02:27:17.161950
# Unit test for function logger_level
def test_logger_level():
    import unittest
    class TestLoggerLevel(unittest.TestCase):
        var_0 = configure()
        def setUp(self):
            self.var_1 = logging.getLogger('testlogger')
            self.var_2 = logger_level(self.var_1, logging.DEBUG)

        def test_logger_level(self):
            self.assertTrue(self.var_2)
    unittest.main()


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:27:24.960422
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    initial_level = logger.level
    logger_level(logger, logging.INFO)
    assert logger.level == logging.INFO, "logger level should be INFO but is %s" % (str(logger.level))
    logger_level(logger, logging.DEBUG)
    assert logger.level == logging.DEBUG, "logger level should be DEBUG but is %s" % (str(logger.level))
    logger.level = initial_level


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:27:26.890442
# Unit test for function configure
def test_configure():
    log = get_logger()
    log.info('test')
    assert True



# Generated at 2022-06-26 02:27:37.083515
# Unit test for function logger_level
def test_logger_level():
    """Check that logger_level sets the logging level"""
    import logging

    # create a logger and set to debug
    logger_0 = logging.getLogger()
    logger_0.setLevel(logging.DEBUG)

    # create a logger and set to info
    logger_1 = logging.getLogger()
    logger_1.setLevel(logging.INFO)

    def get_log_level(logger):
        """Get Log level from logger"""
        lvl = logging.WARNING
        if logger.isEnabledFor(logging.DEBUG):
            lvl = logging.DEBUG
        elif logger.isEnabledFor(logging.INFO):
            lvl = logging.INFO
        elif logger.isEnabledFor(logging.WARNING):
            lvl = logging.WARNING
        return lvl

    # test that logger_0 is debug and logger_1

# Generated at 2022-06-26 02:27:39.645588
# Unit test for function get_config
def test_get_config():
    assert get_config('{"foo": "bar"}') == {"foo": "bar"}
    assert get_config("version: 1") == {'version': 1}


# Generated at 2022-06-26 02:27:48.779076
# Unit test for function configure
def test_configure():
    # noinspection PyUnusedLocal
    def configure_mock(config=None, env_var='LOGGING', default=DEFAULT_CONFIG):
        return config is None and env_var == 'LOGGING' and default == DEFAULT_CONFIG

    sys.modules['logging'] = logging
    sys.modules['logging.config'] = logging.config
    sys.modules['os'] = os
    sys.modules['os.environ'] = os.environ
    sys.modules['json'] = json
    sys.modules['yaml'] = yaml
    sys.modules['colorlog'] = colorlog
    sys.modules['logging'] = logging

    this = lambda: None
    this.exception = exception
    logging.exception = exception
    this.exc_info = exc_info
    logging.exc_info

# Generated at 2022-06-26 02:27:59.188784
# Unit test for function logger_level
def test_logger_level():
    from contextlib import closing
    from logging import getLogger
    from nose.tools import eq_
    from io import StringIO

    logger = getLogger('logger_level_test')
    with closing(StringIO()) as sio:
        with logger_level(logger, logging.INFO):
            with logger_level(logger, logging.DEBUG):
                logger.handlers[0].stream = sio
                logger.debug('foo')
                eq_(sio.getvalue(), 'foo\n', 'should be debug')
                logger.info('bar')
                eq_(sio.getvalue(), 'foo\nbar\n', 'should be debug and info')
    sio.close()
    logger.handlers[0].stream = sys.stdout  # so we don't get warnings



# Generated at 2022-06-26 02:28:07.284969
# Unit test for function get_config
def test_get_config():
    test_config = {
        'version': 1,
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'colored',
                'level': logging.DEBUG,
            },
        },
        'root': {
            'handlers': ['console'],
            'level': logging.DEBUG,
        },
        'loggers': {
            'requests': {
                'level': logging.INFO,
            },
        },
    }
    assert test_config == get_config(test_config)



# Generated at 2022-06-26 02:28:11.421157
# Unit test for function logger_level
def test_logger_level():
    # Simple test to make sure setup is correct
    # Get default logger just to make sure it is configured.
    logger = get_logger()
    # Set logger to warning
    with logger_level(logger, logging.WARNING):
        logger.info('test')
        # This should not print
        logger.debug('test')
    # Should print debug
    logger.debug('test')



# Generated at 2022-06-26 02:28:16.596713
# Unit test for function configure
def test_configure():
    test_case_0()



# Generated at 2022-06-26 02:28:26.746634
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger(__name__)
    # Test that logger_level sets the logger level to 'NOTSET' within a context
    with logger_level(test_logger, logging.NOTSET):
        assert(test_logger.level == logging.NOTSET)
    # Test that the logger level is reset to the appropriate level after the
    # context returns
    assert(test_logger.level == logging.INFO)

if __name__ == '__main__':
    try:
        test_logger_level()
        print('Unit test passed')
    except (NameError, AssertionError, AttributeError) as e:
        print('Unit test failed')
        print(e)

# Generated at 2022-06-26 02:28:28.152077
# Unit test for function logger_level
def test_logger_level():
    var_0 = logger_level(logging.getLogger(__name__))



# Generated at 2022-06-26 02:28:38.704143
# Unit test for function logger_level
def test_logger_level():
    import time
    import threading
    var_1 = test_case_0()
    var_2 = getLogger()
    var_3 = logger_level(var_2, 20)
    var_4 = lambda : var_2.info('This is a test')

    def var_5():
        var_6 = threading.Thread(target=var_4)
        var_7 = var_6.start()
        var_8 = var_6.join()

    var_9 = threading.Thread(target=var_5)
    var_10 = var_9.start()
    var_11 = var_9.join()
    var_12 = time.sleep(0.3)
    var_13 = var_3.__exit__(None, None, None)



# Generated at 2022-06-26 02:28:40.269560
# Unit test for function get_config
def test_get_config():
    var_0 = get_config()


# Generated at 2022-06-26 02:28:46.606391
# Unit test for function logger_level
def test_logger_level():
    log = getLogger('test_logger_level')
    logger_level(log, logging.ERROR)
    try:
        log.info('test')
    except Exception as e:
        assert type(e) == RuntimeError
        assert e.args[0] == 'please use get_logger to get a logger object'
    configure()
    logger_level(log, logging.ERROR)
    log.info('test')



# Generated at 2022-06-26 02:28:57.483558
# Unit test for function get_config
def test_get_config():
    bare_config = {'format': '{message}', 'handlers': {'console': {'class': 'logging.StreamHandler'}}}
    yaml_config = "format: '{message}'\nhandlers:\n  console:\n    class: 'logging.StreamHandler'\n"
    json_config = "{\"format\": \"{message}\", \"handlers\": {\"console\": {\"class\": \"logging.StreamHandler\"}}}"

    expected = bare_config

    assert get_config(bare_config) == expected
    assert get_config(json_config) == expected
    assert get_config(yaml_config) == expected


if __name__ == '__main__':
    test_get_config()
    test_case_0()

# Generated at 2022-06-26 02:29:00.710865
# Unit test for function configure
def test_configure():
    """
    configure()
    """
    assert var_0 is None, \
        "function configure() returned %s, not %s" % (var_0, None)


# Generated at 2022-06-26 02:29:11.007365
# Unit test for function configure
def test_configure():
    import sys
    import io
    import logging
    import logging.config
    import inspect
    try:
        debug_env_var = os.environ["LOGGING"]
        debug_env_var_exists = True
    except KeyError:
        debug_env_var_exists = False
    try:
        debug_env_var = os.environ["LEVEL"]
        level_env_var_exists = True
    except KeyError:
        level_env_var_exists = False
    try:
        debug_env_var = os.environ["DEBUG"]
        debug_env_var_exists = True
    except KeyError:
        debug_env_var_exists = False


# Generated at 2022-06-26 02:29:12.218875
# Unit test for function configure
def test_configure():
    var_0 = configure()
    assert var_0 is None


# Generated at 2022-06-26 02:29:18.983904
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level != logging.DEBUG



# Generated at 2022-06-26 02:29:22.356409
# Unit test for function logger_level
def test_logger_level():
    var_1 = logging.getLogger()
    var_2 = logger_level(var_1, 0)
    var_3 = logging.getLogger()
    var_4 = logger_level(var_3, 0)


# Generated at 2022-06-26 02:29:26.370127
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.WARN) as level_context:
        assert logger.level == logging.WARN
        print(logger.level)
        print(level_context)
    assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:29:36.289032
# Unit test for function logger_level
def test_logger_level():
    """Create a logger and a test handler.

    Then, log at the debug and info levels.

    Next, temporarily set the level of the logger to INFO, so that debug
    messages are suppressed.

    Verify that only the info message is emitted.

    Finally, reset the level to DEBUG, and verify that both messages are
    emitted.

    """

    import logging

    logger = logging.getLogger('logger_level')
    handler = logging.StreamHandler()
    logger.addHandler(handler)

    logger.debug('debug message')
    logger.info('info message')

    # Verify initial state
    assert len(handler.messages['debug']) == 1
    assert len(handler.messages['info']) == 1

    with logger_level(logger, 'INFO'):
        logger.debug('debug message')

# Generated at 2022-06-26 02:29:41.791470
# Unit test for function get_config
def test_get_config():
    given = None
    env_var = "LOGGING"
    default = DEFAULT_CONFIG

    # Test case 1
    try:
        get_config(given, env_var, default)
        assert 1 == 0
    except:
        assert 1 == 1

    # Test case 2
    config = "logging"
    try:
        get_config(config, env_var, default)
        assert 0
    except TypeError:
        assert 1


# Generated at 2022-06-26 02:29:52.531894
# Unit test for function get_config
def test_get_config():
    import yaml

    # Test case 1  # type: dict
    # Case 1 : config is str and config is yaml or json format
    given_0 = yaml.dump({'a': 1})
    expected_0 = {'a': 1}
    assert get_config(given_0) == expected_0
    assert get_config(yaml.dump([1, 2])) == [1, 2]
    assert get_config(yaml.dump(1)) == 1

    # Test case 2  # type: dict
    # Case 2 : config is dict already
    given_1 = dict(test=1)
    expected_1 = given_1
    assert get_config(given_1) == expected_1

    # Test case 3  # type: dict
    # Case 3 : config is NOT str and dict
    given_2

# Generated at 2022-06-26 02:29:54.384393
# Unit test for function configure
def test_configure():
    var_1 = configure()
    # assertEqual(var_1, None)


# Generated at 2022-06-26 02:30:00.442981
# Unit test for function logger_level
def test_logger_level():

    # Get logger
    logger = get_logger()

    # Change level
    logger.level = logging.ERROR;

    # Try to log both INFO and ERROR messages
    try:
        logger.info('INFO')
    except:
        pass
    logger.error('ERROR')

if __name__ == '__main__':

    # Do unit tests
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:10.180359
# Unit test for function logger_level
def test_logger_level():
    import logging, sys
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(logging.Formatter("%(name)s, line %(lineno)d, in %(funcName)s: %(message)s"))
    logger.addHandler(stream_handler)

    with logger_level(logger, logging.DEBUG):
        logger.debug("debug log")
        logger.info("info log")
        logger.error("error log")
    logger.debug("debug log")
    logger.info("info log")
    logger.error("error log")

if __name__ == '__main__':
    # test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:13.359342
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = get_logger()
    >>> with logger_level(logger, logging.DEBUG) as log:
    ...     log.debug('test')
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:30:22.980619
# Unit test for function get_config
def test_get_config():

    var_1 = get_config({})
    var_2 = get_config('{"version": 1}')
    var_3 = get_config('version: "1"')
    var_4 = get_config()

    assert var_1 == {}
    assert var_2 == {'version': "1"}
    assert var_3 == {"version": "1"}
    assert var_4 == DEFAULT_CONFIG

# Generated at 2022-06-26 02:30:24.569255
# Unit test for function configure
def test_configure():
    var_0 = configure()
    assert (var_0 == None), 'var_0 error in test_configure'



# Generated at 2022-06-26 02:30:26.952760
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    level = logging.DEBUG
    a = True
    with logger_level(logger, level):
        assert logger.level == level
        a = False
    assert a is False



# Generated at 2022-06-26 02:30:29.380383
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.CRITICAL):
        logger.debug("test")
    logger.debug("test")


# Generated at 2022-06-26 02:30:33.696637
# Unit test for function logger_level
def test_logger_level():
    try:
        with logger_level(logging.getLogger('hl.log'), logging.DEBUG):
            logging.debug('D')
            logging.info('I')
            logging.warning('W')
            logging.error('E')
    except Exception:
        raise

# Generated at 2022-06-26 02:30:43.365619
# Unit test for function logger_level
def test_logger_level():
    # Derive a logging name from this file.
    _log = get_logger(__file__)

    # logger_level works
    with logger_level(_log, logging.DEBUG):
        _log.debug('test')
        _log.info('test')

    # logger_level works
    with logger_level(_log, logging.INFO):
        _log.debug('test')
        _log.info('test')

    # logger_level works
    with logger_level(_log, logging.WARNING):
        _log.debug('test')
        _log.info('test')

    # logger_level works
    with logger_level(_log, logging.ERROR):
        _log.debug('test')
        _log.info('test')

    # logger_level works

# Generated at 2022-06-26 02:30:53.425544
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    level = logging.INFO
    with logger_level(logger, level):
        level2 = logger.level
        assert level == level2

if __name__ == '__main__':
    import os
    import sys

    from mock import MagicMock, Mock
    from mock import patch

    MOCK_MODULES = ['colorlog']
    for mod_name in MOCK_MODULES:
        sys.modules[mod_name] = MagicMock()

    # USE_STDLIB = False
    # if not USE_STDLIB:
    #     patcher = patch(__name__, MagicMock())
    #     patcher.start()

    # sys.argv = ['', 'Test.test_case_0']

# Generated at 2022-06-26 02:31:05.302813
# Unit test for function get_config
def test_get_config():
    test_config = get_config(given = None,
                             env_var = None,
                             default = None)
    assert test_config == DEFAULT_CONFIG
    test_config = get_config(given = None,
                             env_var = 'LOGGING',
                             default = None)
    assert test_config == DEFAULT_CONFIG
    test_config = get_config(given = None,
                             env_var = None,
                             default = DEFAULT_CONFIG)
    assert test_config == DEFAULT_CONFIG
    test_config = get_config(given = {'test_config'},
                             env_var = 'LOGGING',
                             default = DEFAULT_CONFIG)
    assert test_config == {'test_config'}
    # Ensure that ValueError is thrown when all

# Generated at 2022-06-26 02:31:08.704264
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    with logger_level(logger, logging.CRITICAL):
        initial = logger.level
        assert initial == 50

    logger.level = 5


# Generated at 2022-06-26 02:31:18.083484
# Unit test for function logger_level
def test_logger_level():
    # Mock the global logger
    global logger

    logger_name = "test_logger"
    logger_level_changed = logging.DEBUG
    logger = Mock()
    logger.level = logging.INFO

    # Call the function under test
    with logger_level(logger, logger_level_changed):
        # Assertions inside the context block
        assert logger.level == logger_level_changed
        assert logger.name == logger_name

    # Assertions after the context block
    assert logger.level == logging.INFO
    assert logger.name == logger_name

if __name__ == '__main__':
    configure()
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:31:33.398250
# Unit test for function logger_level
def test_logger_level():
    # set up level from logging module
    DEBUG = logging.DEBUG
    logger = logging.getLogger()
    assert logger.level != DEBUG

    # set level within a context
    with logger_level(logger, DEBUG):
        assert logger.level == DEBUG

    # level is reset once the context manager exits
    assert logger.level != DEBUG


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:31:39.700491
# Unit test for function logger_level
def test_logger_level():
    var_0 = logging.getLogger(__name__)
    var_1 = var_0.level
    var_2 = logging.WARNING
    var_3 = var_0.level
    var_4 = logging.DEBUG
    var_5 = logger_level(var_0, var_4)
    var_6 = var_5.__enter__()
    var_7 = var_5.__exit__(None, None, None)
    var_8 = var_0.level
    return


# Generated at 2022-06-26 02:31:44.561011
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.setLevel(logging.DEBUG)

    result = logger_level(logger, logging.INFO)
    logger.info("test")


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 02:31:48.334474
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    var_1 = configure()
    with logger_level(var_0, logging.CRITICAL):
        var_0.critical('test')



# Generated at 2022-06-26 02:31:52.460099
# Unit test for function logger_level
def test_logger_level():
    # Setup
    import logging
    logger = logging.getLogger()

    # Execute function
    logger.level = logging.INFO
    with logger_level(logger, logging.DEBUG) as _:
        pass

    # Verify
    assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:31:57.095480
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG
    assert get_config(dict(test='test')) == {'test': 'test'}

if __name__ == "__main__":
    configure()
    logging.info('test')
    logging.info('test2')

# Generated at 2022-06-26 02:31:57.963089
# Unit test for function configure
def test_configure():
    t0 = test_case_0()
    print(t0)

# Generated at 2022-06-26 02:32:07.010706
# Unit test for function get_config
def test_get_config():
    def test1():
        var_0 = get_config()
    def test2():
        var_0 = get_config('1')
    def test3():
        var_0 = get_config(logging.DEBUG)
    def test4():
        var_0 = get_config('1', '2')
    def test5():
        var_0 = get_config('1', '2', logging.DEBUG)
    def test6():
        var_0 = get_config(DEFAULT_CONFIG)
    def test7():
        var_0 = get_config(DEFAULT_CONFIG, '1')
    def test8():
        var_0 = get_config(DEFAULT_CONFIG, '1', '2')

# Generated at 2022-06-26 02:32:12.744397
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    # logs, since root level is DEBUG
    with logger_level(log, logging.INFO):
        log.debug('This should not log')

    # logs, since root level is INFO
    with logger_level(log, logging.DEBUG):
        log.debug('This should log')

    #logs, since root level is DEBUG
    log.debug('This should log')


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:32:17.166918
# Unit test for function logger_level
def test_logger_level():
    '''
    TEST: getLogger("TestCase") and put "Test"
    '''
    logger = get_logger("TestCase")
    with logger_level(logger, logging.INFO):
        logger.info("Test")

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:32:25.063851
# Unit test for function logger_level
def test_logger_level():
    try:
        with logger_level(var_0, logging.DEBUG):
            var_0.debug("%s", "Hello world")
    except Exception:
        pass


# Generated at 2022-06-26 02:32:26.250225
# Unit test for function configure
def test_configure():
    configure()
    return


# Generated at 2022-06-26 02:32:33.707156
# Unit test for function logger_level
def test_logger_level():
    logger_level(logging.getLogger(__name__), logging.WARNING)
    logger = logging.getLogger(__name__)
    logger.info("test_case_1")
    logger.warning("test_case_2")


if __name__ == '__main__':
    # test_logger_level()

    # logging.basicConfig(
    #     format=('%(filename)s: %(levelname)s %(message)s'), file=sys.stdout
    # )

    # test_case_0()
    # sys.exit()

    configure()

    log = logging.getLogger(__name__)

    log.debug('Messages will contain the module name')
    log.error("The log level is inherited from the root logger")

# Generated at 2022-06-26 02:32:39.665787
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.WARNING):
        log.info('Hello')
        log.warning('Bye')
        log.debug('Bye')
        # logger_level(log, logging.WARNING)
        # log.info('Hello')
        # log.warning('Bye')
        # log.debug('Bye')


# Generated at 2022-06-26 02:32:43.189742
# Unit test for function logger_level
def test_logger_level():
    l = logging.getLogger()
    with logger_level(l, logging.DEBUG):
        assert l.isEnabledFor(logging.DEBUG)
    assert not l.isEnabledFor(logging.DEBUG)



# Generated at 2022-06-26 02:32:52.925115
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.CRITICAL):
        logger_critical = logger.getEffectiveLevel()
        logger.critical("critical message")
        assert logger.critical
    with logger_level(logger, logging.WARNING):
        logger.warning("warning message")
        assert logger.warning
    with logger_level(logger, logging.INFO):
        logger.info("info message")
        assert logger.info
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        assert logger.debug
    assert logger_critical == logging.CRITICAL

# Generated at 2022-06-26 02:33:02.186979
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.isEnabledFor(logging.DEBUG) is True
    with logger_level(log, logging.INFO):
        assert log.isEnabledFor(logging.DEBUG) is False
        assert log.isEnabledFor(logging.INFO) is True
    assert log.isEnabledFor(logging.DEBUG) is False
    assert log.isEnabledFor(logging.INFO) is True


if __name__ == "__main__":
    import sys
    import pytest

    sys.exit(pytest.main([__file__] + sys.argv[1:]))

# Generated at 2022-06-26 02:33:12.109031
# Unit test for function get_config
def test_get_config():
    # It should fail if no config is given
    with pytest.raises(ValueError):
        get_config()
    
    # Create a config and assert that it is returned
    config = '{"version": 1}'
    cfg = get_config(given=config)
    assert cfg['version'] == 1

    # Create an environment variable and assert that it is returned
    with mock.patch.dict('os.environ', {'LOGGING': '{"version": 2}'}):
        cfg = get_config(env_var='LOGGING')
        assert cfg['version'] == 2

    # An invalid environment variable should raise a value error
    with mock.patch.dict('os.environ', {'LOGGING': '{"version": "'}):
        with pytest.raises(ValueError):
            get

# Generated at 2022-06-26 02:33:16.489982
# Unit test for function logger_level
def test_logger_level():
    """
    >>> case_1 = get_logger()
    >>> case_1.warn('This should print')
    >>> case_1.log(logging.DEBUG, 'This should not print')
    >>> with logger_level(case_1, logging.DEBUG):
    ...     case_1.warn('This should print')
    ...     case_1.log(logging.DEBUG, 'This should print')
    """



# Generated at 2022-06-26 02:33:17.980545
# Unit test for function configure
def test_configure():
    log = get_logger()
    configure()
    print(log.info('test'))


# Generated at 2022-06-26 02:33:26.512658
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger()
    with logger_level(var_1, 'DEBUG'):
        assert var_1.level == logging.DEBUG
        var_1.info('foo')



# Generated at 2022-06-26 02:33:31.892849
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig() # configure default handler
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("should appear")
        log.info("should appear")
    with logger_level(log, logging.INFO):
        log.debug("should not appear")
        log.info("should appear")

if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:37.260154
# Unit test for function logger_level
def test_logger_level():
    arg_0 = get_logger()
    try:
        logger_level(arg_0, 10)
    except Exception:
        raise AssertionError("exception raised in logger_level")
    finally:
        arg_0.level = logging.NOTSET


# Generated at 2022-06-26 02:33:42.592000
# Unit test for function logger_level
def test_logger_level():
    # As the logger_level will change the levels of loggers in a context block,
    # It is difficult to determine if it has worked correctly though unittest.
    # So just print out the message to determine its functionality
    logger_0 = getLogger()
    with logger_level(logger_0, logging.INFO):
        logger_0.debug("This is a debug message")
        logger_0.info("This is a info message")
    logger_0.debug("This is a debug message")
    logger_0.info("This is a info message")

# Generated at 2022-06-26 02:33:46.384324
# Unit test for function logger_level
def test_logger_level():
    # test case for logger_level
    test_case_logger = get_logger()
    with logger_level(test_case_logger, logging.DEBUG):
        assert test_case_logger.level == logging.DEBUG


# Generated at 2022-06-26 02:33:49.768622
# Unit test for function logger_level
def test_logger_level():
    # test case for logger_level function
    var_0 = get_logger()
    with logger_level(var_0, logging.DEBUG):
        var_0.debug("unit test for logger_level")



# Generated at 2022-06-26 02:33:52.586200
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger()
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.INFO)

    with logger_level(logger, logging.DEBUG):
        logger.info("Log line at DEBUG level")

    logger.info("Log line at INFO level")

# Generated at 2022-06-26 02:33:56.485179
# Unit test for function configure
def test_configure():
    log = logging.getLogger(__name__)
    configure()
    log.info('test')


# Generated at 2022-06-26 02:34:02.569496
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger()
    logger_level(var_1, logging.WARNING)
    logger_level(var_1, logging.INFO)


if __name__ == '__main__':
    configure()
    log = get_logger(__name__)
    log.info('test')
    test_case_0()

    log = get_logger('test2')
    log.info('test2')

    test_logger_level()

# Generated at 2022-06-26 02:34:05.640047
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.DEBUG) as l:
        assert l.level == logging.DEBUG
        assert get_logger().level == logging.DEBUG
    assert get_logger().level == logging.INFO



# Generated at 2022-06-26 02:34:15.351270
# Unit test for function logger_level
def test_logger_level():
    var_logger = get_logger()
    var_level = logging.DEBUG
    var_initial = logging.DEBUG
    with logger_level(var_logger, var_level):
        assert var_logger.level == var_level
    assert var_logger.level == var_initial

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:34:21.877799
# Unit test for function get_config
def test_get_config():
    test_input = {}
    expected = None
    actual = get_config(test_input)
    assert actual == expected

    test_input = None
    expected = None
    actual = get_config(test_input)
    assert actual == expected

    expected = DEFAULT_CONFIG
    actual = get_config()
    assert actual == expected

    expected = DEFAULT_CONFIG
    actual = get_config(default=DEFAULT_CONFIG)
    assert actual == expected

    test_input = '{}'
    expected = {}
    actual = get_config(test_input)
    assert actual == expected

    test_input = '{"version": 1, "disable_existing_loggers": false}'
    expected = {"version": 1, "disable_existing_loggers": False}

# Generated at 2022-06-26 02:34:27.026489
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.DEBUG):
        assert logging.getLogger().level == logging.DEBUG


if __name__ == '__main__':
    configure()
    logging.debug('test')
    test_case_0()

# Generated at 2022-06-26 02:34:36.641451
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger("Test")
    test_logger.setLevel(logging.WARNING)
    test_logger.addHandler(logging.StreamHandler(stream=sys.stdout))

    with logger_level(test_logger, logging.INFO):
        test_logger.info("This should print")
        test_logger.warning("This should also print")
        with logger_level(test_logger, logging.DEBUG):
            test_logger.debug("This should print")
        test_logger.warning("This should also print")
        test_logger.info("This should print")
    test_logger.info("This should not print")
    test_logger.warning("This should print")

    assert test_logger.level == logging.WARNING


# Generated at 2022-06-26 02:34:40.451531
# Unit test for function logger_level
def test_logger_level():
    device_logger = getLogger("test_logger_level")
    with logger_level(device_logger, logging.DEBUG):
        device_logger.debug("this test debug")
        device_logger.error("this test error")
        device_logger.info("this test info")



# Generated at 2022-06-26 02:34:44.265267
# Unit test for function logger_level
def test_logger_level():
    import logging
    root = logging.getLogger()
    with logger_level(logging.getLogger(), logging.CRITICAL):
        assert root.level == logging.CRITICAL
    assert root.level == logging.NOTSET



# Generated at 2022-06-26 02:34:45.060839
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-26 02:34:55.721583
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, 100):
        assert logger.getEffectiveLevel() == 100
    assert logger.getEffectiveLevel() == logging.INFO


if __name__ == '__main__':
    configure()
    logger = get_logger(__name__)
    logger.debug('zzz')
    logger.info('foo')
    logger.warning('bar')  # Use warning, not warn, it's deprecated
    logger.error('baz')
    logger.critical('boom')

    # test_logger_level()

    # import doctest
    # doctest.testmod()

    # import unittest

    # class TestCase(unittest.TestCase):

    #     def test_case_0(self):
    #         import logging
   

# Generated at 2022-06-26 02:35:02.845355
# Unit test for function logger_level
def test_logger_level():
    logger_0 = getLogger('test_logger_level')
    logger_level(logger_0, logging.INFO)
    logger_0.debug("Message for debug")
    logger_0.info("Message for info")
    logger_0.warning("Message for warning")
    logger_0.error("Message for error")
    logger_0.critical("Message for critical")
    with logger_level(logger_0, logging.WARNING):
        logger_0.debug("Message for debug")
        logger_0.info("Message for info")
        logger_0.warning("Message for warning")
        logger_0.error("Message for error")
        logger_0.critical("Message for critical")



# Generated at 2022-06-26 02:35:13.616920
# Unit test for function get_config
def test_get_config():
    # Case 1
    given = "{'version': 1, 'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'colored', 'level': 10}}}",
    env_var = "",
    default = "",
    config = get_config(given, env_var, default)
    assert config == "{'version': 1, 'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'colored', 'level': 10}}}"
    # Case 2
    given = "{'version': 1, 'handlers': {'console': {'class': 'logging.StreamHandler', 'formatter': 'colored', 'level': 10}}}",
    env_var = "",
    default = "",
    config = get_config(given, env_var, default)

# Generated at 2022-06-26 02:35:35.921094
# Unit test for function configure
def test_configure():

    import logging


# Generated at 2022-06-26 02:35:40.595727
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)
        logger.debug(u'meow')
        logger.error(u'error')
    assert not logger.isEnabledFor(logging.DEBUG)



# Generated at 2022-06-26 02:35:48.975669
# Unit test for function get_config

# Generated at 2022-06-26 02:35:51.189060
# Unit test for function configure
def test_configure():
    print('Calling configure()')
    configure()
    get_logger().debug('test')
