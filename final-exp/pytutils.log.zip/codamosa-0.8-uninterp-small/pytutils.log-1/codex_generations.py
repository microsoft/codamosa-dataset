

# Generated at 2022-06-26 02:26:07.254079
# Unit test for function configure
def test_configure():
    DEFAULT_CONFIG_TEMP = DEFAULT_CONFIG.copy()
    DEFAULT_CONFIG_TEMP['handlers']['console']['formatter'] = 'simple'
    configure(DEFAULT_CONFIG_TEMP)
    log = get_logger('test_case_1')
    log.info('test')

    DEFAULT_CONFIG_TEMP['loggers']['requests']['level']=logging.WARNING
    configure(DEFAULT_CONFIG_TEMP)
    log = get_logger('test_case_2')
    log.info('test')

    DEFAULT_CONFIG_TEMP['formatters']['colored']['()']='colorlog.ColoredFormatter'
    configure(DEFAULT_CONFIG_TEMP)

# Generated at 2022-06-26 02:26:13.939898
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('logger_level')
    assert logger.level == logging.DEBUG, "default level is DEBUG"

    with logger_level(logger=logger, level=logging.INFO):
        assert logger.level == logging.INFO, "INFO level set by context manager"

    assert logger.level == logging.DEBUG, "return to default level after context"



# Generated at 2022-06-26 02:26:24.269090
# Unit test for function get_config

# Generated at 2022-06-26 02:26:26.914398
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        # Do something
        pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:26:33.867196
# Unit test for function logger_level
def test_logger_level():
    test_logger = getLogger()
    test_logger.setLevel(logging.INFO)
    assert test_logger.getEffectiveLevel() == logging.INFO

    with logger_level(test_logger, logging.DEBUG) as test_level:
        assert test_level == logging.DEBUG
        assert test_logger.getEffectiveLevel() == logging.DEBUG
    assert test_logger.getEffectiveLevel() == logging.INFO


# Generated at 2022-06-26 02:26:37.514896
# Unit test for function logger_level
def test_logger_level():
    from logging import DEBUG
    log = getLogger()
    log.info("TEST LOGGER")
    with logger_level(log, DEBUG):
        log.debug("Hello World!")


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:26:49.647781
# Unit test for function get_config
def test_get_config():
    # config == dict
    config1 = {
        'version': 1,
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
                'formatter': 'colored',
                'level': logging.DEBUG
            }
        },
        'loggers': {
            'requests': {
                'level': logging.INFO
            }
        },
        'root': {
            'handlers': ['console'],
            'level': logging.DEBUG
        }
    }
    assert get_config(given = config1) == config1

    # config == json

# Generated at 2022-06-26 02:26:51.631620
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = 10
    with logger_level(logger, level):
        pass
    assert logger.level == level

# Generated at 2022-06-26 02:26:55.978447
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger()
    with logger_level(var_1, logging.INFO):
        var_1.debug('debug')
        var_1.info('info')
        var_1.warning('warning')
        var_1.error('error')
        var_1.critical('critical')


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:27:00.059238
# Unit test for function logger_level
def test_logger_level():
    """ Test logger_level """
    log = getLogger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level == logging.DEBUG



# Generated at 2022-06-26 02:27:11.953983
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.DEBUG):
        get_logger().debug("This should print")
        get_logger().info("This should also print")
        get_logger().error("This should also print")
    with logger_level(get_logger(), logging.INFO):
        get_logger().info("This should also print")
        get_logger().error("This should also print")
        get_logger().debug("This should not print")
    with logger_level(get_logger(), logging.ERROR):
        get_logger().error("This should also print")
        get_logger().info("This should not print")
        get_logger().debug("This should not print")

# Generated at 2022-06-26 02:27:15.889602
# Unit test for function logger_level
def test_logger_level():
    var_0 = logger_level(logging.getLogger(), 20)
    var_1 = next(var_0)
    var_2 = logger_level(logging.getLogger(), 20)
    var_3 = next(var_2)



# Generated at 2022-06-26 02:27:21.089083
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.CRITICAL):
        log.info("This line is not logged")
        log.critical("This line is logged")
    log.info("This line is logged")
    log.critical("This line is logged")

if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:27:23.979440
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), 10):
        assert getLogger().level == 10
    assert getLogger().level != 10


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:27:33.291175
# Unit test for function get_config

# Generated at 2022-06-26 02:27:37.912292
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    var_0.info('Message')
    with logger_level(var_0, logging.WARN):
        var_0.info('Skipped because of the logger_level')
    var_0.info('Message')

test_case_0()
test_logger_level()

# Generated at 2022-06-26 02:27:47.593192
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.DEBUG):
        assert logging.getLogger().isEnabledFor(logging.DEBUG)
        with logger_level(logging.getLogger(), logging.WARN):
            assert logging.getLogger().isEnabledFor(logging.WARN)
        assert logging.getLogger().isEnabledFor(logging.DEBUG)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--config',
        help='Explicit JSON config to use.')
    parser.add_argument(
        '--env-var',
        help='Environment variable containing logging config.')

# Generated at 2022-06-26 02:27:55.972057
# Unit test for function logger_level
def test_logger_level():
    WARNING = logging.WARNING
    INFO = logging.INFO
    DEBUG = logging.DEBUG

    log = get_logger()

    with logger_level(log, WARNING):
        log.info("this is info")
        log.warning("this is warning")

    with logger_level(log, DEBUG):
        log.debug("this is debug")

    with logger_level(log, INFO):
        log.info("this is info")
        log.debug("this is debug")
        

if __name__ == '__main__':
    configure()
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:28:02.513221
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    # Set logger to the maximum level allowed
    logger.setLevel(logging.CRITICAL)
    assert logger.getEffectiveLevel() == logging.CRITICAL
    # Change logger to debug level and verify that it works
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
    # Verify that logger level changes back after context manager
    assert logger.getEffectiveLevel() == logging.CRITICAL



# Generated at 2022-06-26 02:28:06.911058
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test')
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    # test_case_0()
    pass

# Generated at 2022-06-26 02:28:18.338899
# Unit test for function logger_level
def test_logger_level():
    import contextlib
    logger = logging.getLogger()
    assert isinstance(logger, logging.Logger)
    assert isinstance(logger.level, int)
    with contextlib.ExitStack() as stack:
        tmp = logger_level(logger, logging.DEBUG)
        stack.enter_context(tmp)
        assert isinstance(logger.level, int)
        assert_equal(logger.level, logging.DEBUG)
    assert_equal(logger.level, 20)



# Generated at 2022-06-26 02:28:21.963700
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG


if __name__ == '__main__':
    configure()
    logging.info('test')

# Generated at 2022-06-26 02:28:28.290918
# Unit test for function logger_level
def test_logger_level():
    var_0 = logging.getLogger()
    var_1 = logger_level(var_0,logging.WARN)
    var_2 = next(var_1)
    assert var_2 is None
    var_3 = logger_level(var_0,logging.INFO)
    var_4 = next(var_3)
    assert var_4 is None

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:28:35.412579
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    assert logger.level == 0

    _ensure_configured()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO

    assert logger.level == 0

    _ensure_configured()
    with logger_level(logger, logging.WARN):
        assert logger.level == logging.WARN

    assert logger.level == 0

# Generated at 2022-06-26 02:28:47.145926
# Unit test for function logger_level
def test_logger_level():

    from io import StringIO

    fake_stdout = StringIO()

    logging.basicConfig(stream=fake_stdout)

    log = logging.getLogger("test_logger_level")

    with logger_level(log, logging.ERROR):

        log.error("test_error")
        log.debug("test_debug")
        log.info("test_info")
        log.warn("test_warn")

        assert "test_error" in fake_stdout.getvalue()
        assert "test_info" not in fake_stdout.getvalue()
        assert "test_debug" not in fake_stdout.getvalue()
        assert "test_warn" not in fake_stdout.getvalue()

    log.error("test_error")
    log.debug("test_debug")

# Generated at 2022-06-26 02:28:51.327147
# Unit test for function get_config
def test_get_config():
    # config is a string
    config = get_config('{"version":1}')
    assert config['version'] == 1

    # config is a dict
    config = get_config({'version':1})
    assert config['version'] == 1

if __name__ == '__main__':
    test_case_0()
    test_get_config()
    print('all ok')

# Generated at 2022-06-26 02:28:52.430298
# Unit test for function configure
def test_configure():
    var_0 = configure



# Generated at 2022-06-26 02:29:00.132503
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    assert var_0.level == logging.NOTSET
    with logger_level(var_0, logging.INFO):
        assert var_0.level == logging.INFO
    assert var_0.level == logging.NOTSET

if __name__ == "__main__":
    import doctest
    logging.basicConfig(level=logging.DEBUG)
    doctest.testmod()
    test_logger_level()

# Generated at 2022-06-26 02:29:06.279813
# Unit test for function logger_level
def test_logger_level():
    import colorlog
    logging.basicConfig(level=logging.DEBUG)
    var_0 = get_logger()
    var_0.setLevel(logging.INFO)
    assert var_0.getEffectiveLevel() == logging.INFO
    with logger_level(var_0, logging.DEBUG):
        assert var_0.getEffectiveLevel() == logging.DEBUG
    assert var_0.getEffectiveLevel() == logging.INFO



# Generated at 2022-06-26 02:29:10.330441
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.DEBUG):
        logging.debug('This message should appear')
    logging.info('This should not appear')

    return True

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:29:22.583800
# Unit test for function logger_level
def test_logger_level():
    # create a logger with level DEBUG and set to INFO in a context block.
    # Get a log message at the DEBUG level within a context block
    # and make sure it's not shown.
    logger = get_logger()
    logger.setLevel(logging.DEBUG)

    with logger_level(logger, logging.INFO):
        logger.debug('DEBUG-LEVEL-LOG-MESSAGE-SHOULD-NOT-SHOW')

    # Get a log message at the INFO level within a context block
    # and make sure it is shown.
    with logger_level(logger, logging.INFO):
        logger.info('INFO-LEVEL-LOG-MESSAGE-SHOULD-SHOW')

    # Get a log message at the DEBUG level within a context block
    # and make sure it is shown.

# Generated at 2022-06-26 02:29:27.984664
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    @contextmanager
    def mock_context_manager():
        yield

    logger = logging.getLogger('testing_logger')
    log_level = logger.level
    with logger_level(logger, 100):
        assert logger.level == 100
    assert logger.level == log_level


if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:29:34.246265
# Unit test for function logger_level
def test_logger_level():
    '''
    >>> from dcluster import logger_level, get_logger
    >>> log = get_logger('test')
    >>> log.info('test_logger_level')
    Getting config from LOGGING env var
    >>> logger_level(log, logging.CRITICAL)
    >>> log.info('test_logger_level')
    >>> logger_level(log, logging.DEBUG)
    >>> log.info('test_logger_level')
    '''



# Generated at 2022-06-26 02:29:39.402769
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.INFO) == True
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG) == True
    with logger_level(logger, logging.WARNING):
        assert logger.isEnabledFor(logging.WARNING) == True


# Generated at 2022-06-26 02:29:43.099800
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger('tester')
    var_0.info('test message')

    with logger_level(var_0, 10):
        var_0.info('test message 2')

    var_0.info('test message 3')

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:29:48.353596
# Unit test for function logger_level
def test_logger_level():
    l = get_logger()

    with logger_level(l, logging.CRITICAL):
        l.info("Shouldn't be printed")

    with logger_level(l, logging.DEBUG):
        l.debug("Should be printed")


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    test_logger_level()

# Generated at 2022-06-26 02:29:49.415548
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-26 02:29:52.922427
# Unit test for function logger_level
def test_logger_level():
    mock_logger = Mock()
    mock_logger.level = 0
    with logger_level(mock_logger, 1):
        pass
    assert mock_logger.level == 0


# Generated at 2022-06-26 02:29:55.299514
# Unit test for function logger_level
def test_logger_level():
    var_1 = "global"
    var_2 = "global"
    logger_level(var_1, var_2)



# Generated at 2022-06-26 02:30:05.745964
# Unit test for function logger_level
def test_logger_level():
    test_log = logging.getLogger(__name__)
    test_log.setLevel(logging.DEBUG)
    test_log.info("This is test_log")
    with logger_level(test_log, logging.NOTSET):
        test_log.info("This is test_log within logger_level context")
    test_log.info("This is test_log again")


if __name__ == '__main__':
    configure()
    log = logging.getLogger('test')

    log.debug('test debug')
    log.info('test info')
    log.warning('test warning')
    log.error('test error')
    log.critical('test critical')

    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:17.504350
# Unit test for function get_config

# Generated at 2022-06-26 02:30:26.983076
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-26 02:30:31.276533
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    var_1 = logger_level(var_0, logging.INFO)
    var_2 = logger_level(var_0, logging.DEBUG)
    with var_2:
        pass
    with var_1:
        with var_2:
            pass



# Generated at 2022-06-26 02:30:39.317648
# Unit test for function logger_level
def test_logger_level():
    from tempfile import NamedTemporaryFile

    log = get_logger()
    with NamedTemporaryFile(delete=False) as temp_file:
        with logger_level(log, logging.DEBUG):
            log.debug("Debug message")
            log.info("Info message")
        with logger_level(log, logging.INFO):
            log.info("Info message")
            log.warning("Warning message")
    with open(temp_file.name, "r") as f:
        log_message = f.read()
    assert("INFO" not in log_message)
    assert("WARNING" in log_message)
    os.remove(temp_file.name)



# Generated at 2022-06-26 02:30:45.546620
# Unit test for function logger_level
def test_logger_level():
    def function():
        logging.info("func")
        logging.error("func")

    logging.addLevelName(logging.INFO,'INFO2')
    test_logger = logging.getLogger()
    test_logger.setLevel(logging.INFO)
    with logger_level(test_logger, logging.INFO):
        function()
    with logger_level(test_logger, logging.NOTSET):
        function()


if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-26 02:30:50.120698
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR

    assert logger.level == logging.DEBUG


# Testing function configure in configure.py
# Tests for JSON stringified logging config

# Generated at 2022-06-26 02:30:55.080724
# Unit test for function logger_level
def test_logger_level():
    class MyLogger:
        def __init__(self):
            self.level = 10

    my_logger = MyLogger()
    # We cannot test set_logger_level directly, as logger.level
    # is a property in python 3
    with logger_level(my_logger, 20):
        assert my_logger.level == 20
    assert my_logger.level == 10

# Generated at 2022-06-26 02:30:58.305410
# Unit test for function logger_level
def test_logger_level():
    l = logging.getLogger('logger_test')
    with logger_level(l, logging.WARN):
        # logging.basicConfig(filename='/tmp/test.log', filemode='w', level=logging.WARN)
        l.info("logger info")
        l.debug("logger debug")
        l.error("logger error")
        l.warn("logger warn")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-26 02:31:04.953705
# Unit test for function configure
def test_configure():
    assert test_case_0()
    sys.stderr.write(
        "Unit tests for %s\n" % os.path.basename(sys.argv[0])
    )
    sys.stderr.write("Beginning tests\n")
    sys.stderr.write("End of tests\n")

if __name__ == "__main__":
    test_configure()

# Generated at 2022-06-26 02:31:09.330077
# Unit test for function logger_level
def test_logger_level():
    try:
        with logger_level(getLogger('test'), logging.DEBUG):
            log = getLogger('test')
            assert log.level == logging.DEBUG
    except Exception:
        raise AssertionError('Not able to change the logging level.')



# Generated at 2022-06-26 02:31:17.248384
# Unit test for function logger_level
def test_logger_level():
    log_0 = get_logger()
    with logger_level(log_0, logging.DEBUG) as log:
        assert log_0 == log
        log.debug('test_logger_level()')

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:31:20.884864
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logger, logging.INFO):
        logger.warn('logger.warn should not be visible')
        logger.info('logger.info should be visible')



# Generated at 2022-06-26 02:31:35.896766
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger('test_logger_level')
    test_logger.setLevel(logging.CRITICAL)
    assert test_logger.isEnabledFor(logging.INFO) is False
    with logger_level(test_logger, logging.INFO):
        assert test_logger.isEnabledFor(logging.INFO) is True
    assert test_logger.isEnabledFor(logging.INFO) is False
    test_logger.setLevel(logging.INFO)
    with logger_level(test_logger, logging.CRITICAL):
        assert test_logger.isEnabledFor(logging.INFO) is False
    assert test_logger.isEnabledFor(logging.INFO)



# Generated at 2022-06-26 02:31:37.435695
# Unit test for function get_config
def test_get_config():
    assert get_config(default=None) == None



# Generated at 2022-06-26 02:31:44.284720
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    import inspect
    # Refactor this list to be logger_level_test
    test_cases = [test_case_0]
    logger = logging.getLogger() 
    logger.setLevel(logging.DEBUG)
    for test_name, test_method in [x for x in inspect.getmembers(sys.modules[__name__]) if x[0][:4] == 'test']:
        with logger_level(logger, logging.CRITICAL):
            test_method()
    for test_name, test_method in [x for x in inspect.getmembers(sys.modules[__name__]) if x[0][:4] == 'test']:
        with logger_level(logger, logging.WARNING):
            test_method()

# Generated at 2022-06-26 02:31:49.638633
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    var_1 = logger_level(var_0,logging.WARNING)
    var_2 = logger_level(var_0,logging.INFO)
    var_3 = logger_level(var_0,logging.INFO)
    var_0.info('test')
    var_0.error('test')


# Generated at 2022-06-26 02:31:57.644239
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    var_1 = var_0.level
    var_0.level = 0
    with logger_level(var_0, 1):
        var_0.error('test_logger_level_0')
    var_0.level = var_1
    var_0.info('test_logger_level_1')


if __name__ == '__main__':
    configure()
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:32:04.403497
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('dummy')
    initial = logger.level
    logger_level(logger, logging.INFO)
    assert logger.level == logging.INFO
    logger_level(logger, logging.WARNING)
    assert logger.level == logging.WARNING
    logger_level(logger, initial)
    assert logger.level == initial


if __name__ == '__main__':
    import doctest

    doctest.testmod()
    # test_logger_level()

# Generated at 2022-06-26 02:32:06.000321
# Unit test for function get_config
def test_get_config():
    var_0 = get_config()


# Generated at 2022-06-26 02:32:15.492138
# Unit test for function get_config
def test_get_config():
    # Testing
    cfg = get_config(None)
    assert cfg == DEFAULT_CONFIG
    cfg = get_config(None, env_var=None)
    assert cfg == DEFAULT_CONFIG
    cfg = get_config(default=DEFAULT_CONFIG)
    assert cfg == DEFAULT_CONFIG
    cfg = get_config(env_var=None, default=DEFAULT_CONFIG)
    assert cfg == default
    cfg = get_config(DEFAULT_CONFIG)
    assert cfg == DEFAULT_CONFIG
    cfg = get_config(DEFAULT_CONFIG, env_var=None, default=DEFAULT_CONFIG)
    assert cfg == DEFAULT_CONFIG
    logger = get_logger()
    logger.info("Test get_config passed")


# Generated at 2022-06-26 02:32:28.293868
# Unit test for function logger_level
def test_logger_level():
    import colorlog

    log = get_logger()

    # Ensure that the logger levels are set correctly with the context manager
    with logger_level(log, logging.DEBUG):
        assert(log.level == logging.DEBUG)
    assert(log.level == logging.DEBUG)

    # Ensure that the handler is properly added/removed
    original_handlers = log.handlers
    console_handler = colorlog.StreamHandler()
    log.add_handler(console_handler)
    assert(log.handlers == original_handlers + [console_handler])
    log.remove_handler(console_handler)
    assert(log.handlers == original_handlers)



# Generated at 2022-06-26 02:32:29.600676
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('logger')
    with logger_level(logger, logging.ERROR):
        logger.info("This won't be printed")
    logger.info("This will be printed")


# Generated at 2022-06-26 02:32:32.994682
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    with logger_level(var_0, 10):
        var_0.debug("debug")
        var_0.info("info")
        var_0.warning("warning")
        var_0.error("error")
        var_0.critical("critical")


# Generated at 2022-06-26 02:32:43.524961
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import logging
    from .colorlog import getLogger

    class MockLogger(logging.Logger):
        level_set_to = logging.NOTSET

        def setLevel(self, level):
            self.level_set_to = level

    class TestTest(unittest.TestCase):
        def test_logger_level(self):
            mock_logger = MockLogger('test.logger_level')
            with logger_level(mock_logger, logging.INFO):
                self.assertEqual(mock_logger.level_set_to, logging.INFO)

            self.assertEqual(mock_logger.level_set_to, logging.NOTSET)

    test_logger_level.TestTest = TestTest


# Generated at 2022-06-26 02:32:45.868387
# Unit test for function logger_level
def test_logger_level():
    def foo():
        print(logger_level)

    def bar():
        print(logger_level)

# Generated at 2022-06-26 02:32:51.028847
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger()

    with logger_level(test_logger, logging.DEBUG):
        assert test_logger.getEffectiveLevel() == logging.DEBUG

    assert test_logger.getEffectiveLevel() != logging.DEBUG

if __name__ == "__main__":
    logging.basicConfig()
    logging.root.setLevel(logging.DEBUG)
    test_logger_level()

# Generated at 2022-06-26 02:32:54.892246
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger('logger_level_test')
    test_logger.level = logging.DEBUG
    with logger_level(test_logger, logging.ERROR):
        if test_logger.isEnabledFor(logging.DEBUG):
            assert False
        else:
            assert True
    if test_logger.isEnabledFor(logging.DEBUG):
        assert True
    else:
        assert False


# Generated at 2022-06-26 02:33:05.506461
# Unit test for function logger_level
def test_logger_level():
    import sys
    import re
    from io import StringIO
    from contextlib import redirect_stdout
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.WARNING)

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    with redirect_stdout(StringIO()) as buf:
        # Note this will print to stdout
        logger.debug('test')

    output = buf.getvalue()
    logger.removeHandler(handler)
    assert not output


# Generated at 2022-06-26 02:33:09.031146
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('should print')
    log.debug('should not print')


# Generated at 2022-06-26 02:33:12.526405
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
    assert logger.level == logging.NOTSET


if __name__ == '__main__':

    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:27.389186
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('test_logger')
    with logger_level(logger, logging.CRITICAL):
        logger.debug('debug')
        logger.info('info')
        logger.warn('warn')
        logger.error('error')
        logger.critical('critical')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:33:31.144832
# Unit test for function configure
def test_configure():

    cfg = get_config(default=DEFAULT_CONFIG)
    assert cfg == DEFAULT_CONFIG

    logging.shutdown()

    configure()
    var_0 = get_logger()
    var_0.debug('test')

    logging.shutdown()



# Generated at 2022-06-26 02:33:34.470564
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG


# Generated at 2022-06-26 02:33:50.606325
# Unit test for function logger_level
def test_logger_level():
    #console handler and colored formatter are added if not exist
    logger_0 = get_logger("test")
    var_1 = len([h for h in logger_0.handlers if isinstance(h, logging.StreamHandler)])
    var_2 = len([f for f in logging.getLogger("").handlers[0].formatter._style._styles.keys() if isinstance(f, colorlog.ColoredFormatter)])
    var_3 = len([f for f in logging.getLogger("").handlers[0].formatter._style._styles.keys() if isinstance(f, logging.Formatter)])
    assert var_1 >= 1
    assert var_2 >= 1
    assert var_3 == 0
    logger_1 = get_logger()
    logger_2 = logging.getLogger("test")


# Generated at 2022-06-26 02:34:01.591892
# Unit test for function logger_level
def test_logger_level():
    # Initialize the logger instance
    logger = get_logger()
    with logger_level(logger, logging.WARNING):
        # Use the logger and check output
        logger.debug("Debug Message")
        assert not logger.isEnabledFor(logging.DEBUG)
        logger.info("Information Message")
        assert not logger.isEnabledFor(logging.INFO)
        logger.warning("Warning Message")
        assert logger.isEnabledFor(logging.WARNING)

if __name__ == '__main__':
    configure()
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:34:05.700812
# Unit test for function logger_level
def test_logger_level():
    a = get_logger()
    with logger_level(a, logging.ERROR):
        a.debug('test debug')
    with logger_level(a, logging.DEBUG):
        a.debug('test debug')
    a.debug('test debug')


if __name__ == '__main__':
    configure()
    test_logger_level()

# Generated at 2022-06-26 02:34:10.181415
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger()
    assert test_logger.level == 10
    with logger_level(test_logger, 30):
        assert test_logger.level == 30
    assert test_logger.level == 10



# Generated at 2022-06-26 02:34:14.795606
# Unit test for function logger_level
def test_logger_level():
    print("Unit test for function logger_level\n")
    var_0 = get_logger()
    print(var_0)
    with logger_level(var_0, logging.ERROR):
        var_0.error("Testing Error")
        var_0.debug("Testing debug")
        var_0.warning("Testing warning")
    var_0.info("Testing info")


# Generated at 2022-06-26 02:34:17.739989
# Unit test for function logger_level
def test_logger_level():
    # Setup
    logger = get_logger()
    level = logging.ERROR

    # Exercise
    with logger_level(logger, level):
        pass
    assert logger.getEffectiveLevel() == level

    # Cleanup - none necessary

# Generated at 2022-06-26 02:34:22.868025
# Unit test for function configure
def test_configure():
    import os

    env_var = 'LOG_CONF_TEST_CASE_1'
    name = 'tmp.log'
    with open(name, 'w') as f:
        f.write('[loggers]\nkeys=root')
        f.write('\n\n[logger_root]\nhandlers=console\nlevel=DEBUG')
        f.write('\n\n[handlers]\nkeys=console')
        f.write('\n\n[handler_console]\nclass=StreamHandler\n'
                'formatter=simple\nlevel=DEBUG\n'
                'args=(sys.stdout,)')
        f.write('\n\n[formatters]\nkeys=simple')

# Generated at 2022-06-26 02:34:49.091548
# Unit test for function logger_level
def test_logger_level():
    # GIVEN a logger with level WARNING
    # and a context that sets the level to DEBUG
    test_logger = get_logger()
    test_logger.setLevel(logging.WARNING)
    with logger_level(test_logger, logging.DEBUG):
        # WHEN the logger is called with debug message
        test_logger.debug("Hello")
        # THEN the log message is displayed in console
        assert True
    # WHEN the logger is called with debug message
    test_logger.debug("Hello")
    # THEN the log message is NOT displayed in console
    assert False


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:34:53.020699
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO


if __name__ == '__main__':
    import doctest

    doctest.testmod()
    # import unittest
    #
    # unittest.main()

# Generated at 2022-06-26 02:35:01.049890
# Unit test for function logger_level
def test_logger_level():
    # Create logger
    var_0 = logging.getLogger()
    # Set logger level
    var_0.setLevel(logging.DEBUG)

    # Create file handler
    var_1 = logging.FileHandler('log.txt')
    # Set handler level
    var_1.setLevel(logging.INFO)

    # Create console handler
    var_2 = logging.StreamHandler()
    # Set handler level
    var_2.setLevel(logging.ERROR)

    # Create formatter
    var_3 = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # Set the formatter
    var_1.setFormatter(var_3)
    var_2.setFormatter(var_3)

    # Add the handlers

# Generated at 2022-06-26 02:35:12.724226
# Unit test for function get_config

# Generated at 2022-06-26 02:35:21.307348
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    f = tempfile.NamedTemporaryFile()
    logger = get_logger()
    logger.addHandler(logging.FileHandler(f.name))
    with logger_level(logger, logging.DEBUG):
        logger.debug('DEBUG')
        logger.info('INFO')
        logger.critical('CRITICAL')
        logger.warning('WARNING')
        logger.error('ERROR')
    logger.info('INFO')
    logger.critical('CRITICAL')
    f.flush()
    with open(f.name) as fd:
        assert fd.read() == 'DEBUG\n'

if __name__ == '__main__':
    test_logger_level()
    test_case_0()

# Generated at 2022-06-26 02:35:26.442434
# Unit test for function get_config
def test_get_config():
    assert get_config(given='{"cheese": "cheddar"}') == {'cheese': 'cheddar'}
    assert get_config(env_var='LOGGING', default=None) == DEFAULT_CONFIG

# Generated at 2022-06-26 02:35:28.863502
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.INFO):
        get_logger().info('hello')


# Generated at 2022-06-26 02:35:35.223078
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    log.setLevel(logging.INFO)
    log.info('This is INFO')
    log.debug('This is DEBUG')

    with logger_level(log, logging.DEBUG):
        log.info('This is INFO')
        log.debug('This is DEBUG')

    log.info('This is INFO')
    log.debug('This is DEBUG')

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:35:46.932891
# Unit test for function get_config
def test_get_config():
    default_config = dict(
        version=1,
        disable_existing_loggers=False,
        formatters={
            'colored': {
                '()': 'colorlog.ColoredFormatter',
                'format':
                    '%(bg_black)s%(log_color)s'
                    '[%(asctime)s] '
                    '[%(name)s/%(process)d] '
                    '%(message)s '
                    '%(blue)s@%(funcName)s:%(lineno)d '
                    '#%(levelname)s'
                    '%(reset)s',
                'datefmt': '%H:%M:%S',
            }
        })
    var_0 = get_config(default)
    assert var_0 == default_config



# Generated at 2022-06-26 02:35:51.676783
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger()
    initial_level = var_1.level
    with logger_level(var_1, logging.DEBUG):
        assert var_1.level == logging.DEBUG
    assert var_1.level == initial_level

