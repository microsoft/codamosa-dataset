

# Generated at 2022-06-26 02:26:08.353928
# Unit test for function configure
def test_configure():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    import sys

    backup = sys.stdout
    log_output = StringIO()
    sys.stdout = log_output

    def _test_config(config):
        try:
            configure(config=config)
            log = get_logger()
            log.info('test message')
            return log_output.getvalue()
        finally:
            sys.stdout = backup


# Generated at 2022-06-26 02:26:11.054326
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-26 02:26:16.947942
# Unit test for function logger_level
def test_logger_level():
    def test_func_0():
        test_logger = logging.getLogger(__name__)

        with logger_level(test_logger, logging.DEBUG):
            test_logger.info('test_logger_level')
            test_logger.debug('test_debug')
        test_logger.info('test_logger_level')
        test_logger.debug('test_debug')

    configure()
    test_func_0()

# Generated at 2022-06-26 02:26:20.587899
# Unit test for function logger_level
def test_logger_level():
    # test_case 0
    logger = logging.getLogger('testing')

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    assert logger.level != logging.DEBUG


if __name__ == '__main__':
    pass

# Generated at 2022-06-26 02:26:28.589339
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('debug test')
        log.error('error test')
        log.info('info test')
        log.warning('warning test')
        log.critical('critical test')
    with logger_level(log, logging.ERROR):
        log.debug('debug test')
        log.error('error test')
        log.info('info test')
        log.warning('warning test')
        log.critical('critical test')
    with logger_level(log, logging.CRITICAL):
        log.debug('debug test')
        log.error('error test')
        log.info('info test')
        log.warning('warning test')
        log.critical('critical test')

# Generated at 2022-06-26 02:26:39.221546
# Unit test for function get_config
def test_get_config():
    import logging
    import re
    import json
    try:
        from yaml import load as yamlload
    except ImportError:
        from yaml import Loader as yamlload
    logging.basicConfig(level=logging.DEBUG)
    log = get_logger()

    env_var = '_TEST_LOGGING'
    if env_var in os.environ:
        del os.environ[env_var]

    default = get_config(None, env_var, DEFAULT_CONFIG)
    log.debug("default=%s" % default)

    bare = get_config("foo")
    print("bare=%s" % bare)
    if not re.search("foo$", str(bare)):
        assert False, 'Value of bare should match expected result'

    json_str

# Generated at 2022-06-26 02:26:44.632343
# Unit test for function configure
def test_configure():
    log = getLogger('test_configure')
    log.info('Started')
    try:
        cfg = get_config()
        configure(cfg)
        log.info('Success')
    except:
        log.exception('Failed')
        raise


# Generated at 2022-06-26 02:26:51.857640
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    log.info("test")

    logger = get_logger()
    try:  # assert log == none
        assert(logger == None)
    except AssertionError:
        logger_level(logger, logging.DEBUG)
        log.info('logger_level')
    finally:
        logger_level(logger, logging.DEBUG)
        log.info('logger_level')


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:26:53.470820
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        pass


# Generated at 2022-06-26 02:26:56.484711
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test_logger_level')


# Generated at 2022-06-26 02:27:06.645937
# Unit test for function logger_level
def test_logger_level():

    log = logging.getLogger('log')

    # Make sure config has been set
    _ensure_configured()

    # Make sure log level is not already at DEBUG
    assert log.level is not logging.DEBUG

    # Run logger_level context manager, and make sure log level
    # did in fact change
    with logger_level(log, logging.DEBUG):
        assert log.level is logging.DEBUG

    # Make sure log level changed back once context manager exited
    assert log.level is not logging.DEBUG

# Generated at 2022-06-26 02:27:07.886915
# Unit test for function configure
def test_configure():
    configure(config='abc')
    print("finished testing configure")


# Generated at 2022-06-26 02:27:15.553216
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()

    log = get_logger()
    log.debug('initially')

    with logger_level(log, logging.DEBUG):
        log.debug('while  level is DEBUG')

    log.debug('after  level is DEBUG')

    with logger_level(log, logging.CRITICAL):
        log.debug('while  level is CRITICAL')

    log.debug('after  level is CRITICAL')

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:27:23.867096
# Unit test for function logger_level
def test_logger_level():
    import string
    logger = logging.getLogger('logger_level')
    logger.addHandler(logging.StreamHandler())
    assert logger.level == logging.NOTSET

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG

    letter = string.ascii_letters[0]

    with logger_level(logger, logging.DEBUG):
        logger.debug(letter * 100)

    with logger_level(logger, logging.INFO):
        logger.debug(letter * 100)

    with logger_level(logger, logging.DEBUG):
        logger.debug(letter * 100)

    assert logger.level == logging.NOTSET



# Generated at 2022-06-26 02:27:27.306060
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(__name__), logging.DEBUG):
        assert logging.getLogger(__name__).level == logging.DEBUG
    assert logging.getLogger(__name__).level == logging.INFO


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:27:32.035300
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger('django'), logging.WARNING):
        assert logging.getLogger('django').level == logging.WARNING
    assert logging.getLogger('django').level == DEFAULT_CONFIG['root']['level']

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:27:35.846519
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger()
    with logger_level(logger, logging.ERROR):
        pass


if __name__ == "__main__":

    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:27:41.108782
# Unit test for function logger_level
def test_logger_level():
    with open('log.txt','w') as f:
        f.write('')
    logger = logging.getLogger()
    logger.setLevel(0)
    with logger_level(logger, 1):
        logger.error('Test message')
        with open('log.txt','r') as f:
            assert f.read() == 'Test message\n'


# Generated at 2022-06-26 02:27:49.531349
# Unit test for function get_config
def test_get_config():
    var_0 = get_config()
    assert var_0 == DEFAULT_CONFIG
    var_1 = get_config({'version': 1})
    assert var_1 == {'version': 1}
    var_2 = get_config('{"version": 1}')
    assert var_2 == {'version': 1}
    var_3 = get_config('version: 1', default={'version': 2})
    assert var_3 == {'version': 1}
    var_4 = get_config('version: 1', default=DEFAULT_CONFIG)
    assert var_4 == {'version': 1}
    var_5 = get_config('{"version": 1}', default={'version': 2})
    assert var_5 == {'version': 1}

# Generated at 2022-06-26 02:27:52.722176
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logging.INFO

    with logger_level(logger, level):
        assert logger.level == level



# Generated at 2022-06-26 02:28:02.578323
# Unit test for function logger_level
def test_logger_level():
    """Testing logger_level() function."""

    from logging import getLogger
    from logging import INFO, DEBUG, WARNING

    import sys
    from unittest import TestCase
    from unittest.mock import patch

    log = getLogger(__name__)

    # create a dummy test case for patching sys.stdout
    class DummyTestCase(TestCase):
        @patch.object(sys, 'stdout')
        def test_default_logger_level(self, mock_stdout):
            # Should be INFO level
            log.info('test_default_logger_level')
            mock_stdout.write.assert_called_with('test_default_logger_level\n')
            mock_stdout.reset_mock()

            # Should not show

# Generated at 2022-06-26 02:28:08.094513
# Unit test for function logger_level
def test_logger_level():
    # Case 1:
    # Input:
    #    logger = get_logger()
    #    level = logging.INFO
    # Output:
    #    logger level has been set to logging.INFO
    logger = get_logger()
    level = logging.INFO
    with logger_level(logger, level):
        assert logger.level == level
        print("logger level: %d" %logger.level)


# Generated at 2022-06-26 02:28:12.192061
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    try:
        with logger_level(log, logging.ERROR):
            log.info("This log should print!")
            log.warning("This one too!")
            log.error("How about this one?")
            log.debug("Not this one!")
            log.critical("This one though!")
    except Exception as exc:
        print(exc)
        return False

    return True


# Generated at 2022-06-26 02:28:20.734795
# Unit test for function logger_level
def test_logger_level():
    # Tests the case in which a logger's level is set, and the setting is changed within a context block.
    # Then, the logger's level should be reset once the context block has finished
    print("\nTest Case 1: Seting Logger Level\n")
    log = get_logger()
    expected_level = logging.DEBUG
    log.level = expected_level
    with logger_level(log,logging.DEBUG):
        log.warning("WARNING")
        log.debug("DEBUG")
        assert log.level == logging.DEBUG
    assert log.level == expected_level


# Generated at 2022-06-26 02:28:25.318116
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL
    assert logger.level == logging.DEBUG


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:28:27.448256
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('Test')
    logger_level(log, logging.DEBUG)
    assert log.level == logging.DEBUG

# Generated at 2022-06-26 02:28:31.411839
# Unit test for function get_config
def test_get_config():
    assert isinstance(get_config(default=DEFAULT_CONFIG), dict)
    assert isinstance(get_config(default=DEFAULT_CONFIG), dict)
    assert isinstance(var_0, dict)

# Generated at 2022-06-26 02:28:35.871510
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    # test logger_level inputs
    with logger_level(logger, 'level') as logger_level_:
        logger_level_ == 'level'
    # test logger_level outputs
    assert logger.level == 'level'


# Unit testing for function configure

# Generated at 2022-06-26 02:28:39.408868
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger("test")
    with logger_level(test_logger, logging.INFO):
        assert test_logger.level == logging.INFO
    assert test_logger.level == logging.NOTSET

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:28:44.144849
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test')
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
        # We did not change the level of the root logger
        assert get_logger().getEffectiveLevel() == logging.DEBUG
    # Level of logger has been reset
    assert logger.getEffectiveLevel() == logging.NOTSET



# Generated at 2022-06-26 02:28:51.813904
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger('test_logger')
    with logger_level(test_logger, logging.DEBUG):
        assert test_logger.level == logging.DEBUG
    assert test_logger.level != logging.DEBUG


# Generated at 2022-06-26 02:29:03.764485
# Unit test for function get_config
def test_get_config():
    assert get_config(config='{"a": 1}') == {"a": 1}
    assert get_config(config='{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert get_config(config='{"a": [1, 2]}') == {"a": [1, 2]}

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
        datefmt='%a, %d %b %Y %H:%M:%S',
        filename='l.log',
        filemode='w'
    )

    logging.debug('debug message')

# Generated at 2022-06-26 02:29:04.731337
# Unit test for function logger_level
def test_logger_level():
    pass


# Generated at 2022-06-26 02:29:12.319793
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    LOG_LEVELS = [logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR, logging.CRITICAL]
    random.shuffle(LOG_LEVELS)

    new_level = None
    for level in LOG_LEVELS:
        with logger_level(logger, level):
            if new_level == None:
                new_level = level
            else:
                assert logger.level == level, "Failed to set logger level to level inside context."
    assert logger.level == new_level, "Logger level did not change."


# Generated at 2022-06-26 02:29:16.301617
# Unit test for function logger_level
def test_logger_level():
    print("Testing function logger_level")
    logger = get_logger()
    level = logging.INFO
    with logger_level(logger, level):
        assert logger.level == level
        logger.info("Test message")

        logger.warning("Test warning")

        logger.error("Test error")

        logger.critical("Test critical")

    logger.setLevel(logging.INFO)

# Generated at 2022-06-26 02:29:22.261496
# Unit test for function logger_level
def test_logger_level():
    import time
    import logging
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.info("this is a test for logger_level")
        time.sleep(1)
        logger.info("this is a test for logger_level 1 second later")
    logger.info("this is a test for logger_level")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-26 02:29:27.053436
# Unit test for function logger_level
def test_logger_level():
    from itertools import repeat

    message = "This is info log message"
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.critical(message)
        logger.error(message)
        logger.warning(message)
        logger.info(message)
        logger.debug(message)
    logger.info(message)



# Generated at 2022-06-26 02:29:30.061753
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    # Ensure that logger level is back to normal
    assert logger.level == logging.NOTSET

# Generated at 2022-06-26 02:29:40.132204
# Unit test for function get_config
def test_get_config():
    test_case_0.__name__ = 'test_case_0'

    from pytest import approx

    from nose.tools import assert_equals, assert_dict_equal, assert_list_equal, assert_tuple_equal, assert_true, assert_false, raises
    from nose.plugins.skip import SkipTest

    from itertools import permutations, combinations, combinations_with_replacement, starmap

    # test functions
    # test basic functionality
    def test_case_1():
        var_0 = get_config()
        assert_equals(type(var_0), type(dict()))
        assert_dict_equal(var_0, DEFAULT_CONFIG)

    def test_case_2():
        config = {'test': True}
        var_0 = get_config(config)
        assert_

# Generated at 2022-06-26 02:29:43.817571
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, 10):
        # Currently this test does not do anything but it will be useful once we add more asserts to this test case.
        assert logger.level == 10


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:29:57.812380
# Unit test for function logger_level
def test_logger_level():
    var_1 = logging.getLogger('test_logger_level')
    var_1.setLevel(logging.DEBUG)

    # parametrized by level
    # TODO: somehow count calls to logger and make assertions about this
    for level, msg in [
        (logging.DEBUG, 'a debug message'),
        (logging.INFO, 'an info message'),
        (logging.WARNING, 'a warning message'),
        (logging.ERROR, 'an error message'),
        (logging.CRITICAL, 'a critical message'),
    ]:
        with logger_level(var_1, level):
            var_1.debug(msg)



# Generated at 2022-06-26 02:30:00.278100
# Unit test for function logger_level
def test_logger_level():
    old_value = False
    with logger_level(test_case_0(), False):
        old_value = True
    assert old_value == True

# Generated at 2022-06-26 02:30:10.019975
# Unit test for function get_config
def test_get_config():
    import logging


# Generated at 2022-06-26 02:30:12.963285
# Unit test for function logger_level
def test_logger_level():
    # Set logger level to DEBUG within a context block
    with logger_level(logger, logging.DEBUG):
        assert logger.level is logging.DEBUG
        # Assert that the level is set back to its original level
        assert logger.level is logging.INFO

# Generated at 2022-06-26 02:30:20.781044
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config

    logging.config.dictConfig({
        'version': 1,
        'disable_existing_loggers': True,
        'root': {
            'handlers': ['default'],
            'level': logging.DEBUG,
        },
        'handlers': {
            'default': {
                'class': 'logging.StreamHandler',
                'formatter': 'default',
                'stream': 'ext://sys.stdout',
            }
        },
        'formatters': {
            'default': {
                'format': '%(name)s - %(message)s',
            },
        },
    })
    logger = logging.getLogger()
    logger.debug('outside')

    with logger_level(logger, logging.INFO):
        logger.debug('inside')



# Generated at 2022-06-26 02:30:29.359024
# Unit test for function configure
def test_configure():
    test_config = copy.deepcopy(DEFAULT_CONFIG)
    test_config['loggers'] = {
        'requests': {
            'handlers': ['console'],
            'level': logging.INFO,
        }
    }

    with tempfile.NamedTemporaryFile('w+') as test_config_file:
        try:
            json.dump(test_config, test_config_file)
            test_config_file.flush()

            with mock.patch.dict('os.environ', {'LOGGING': test_config_file.name}):
                configure()
                logger = logging.getLogger('requests')
                assert logger.getEffectiveLevel() == logging.INFO
        finally:
            test_config_file.close()


# Generated at 2022-06-26 02:30:38.887757
# Unit test for function logger_level
def test_logger_level():
    """

    Assert that logger_level is working as expected.

    """
    import unittest
    import logging

    class TestLoggerLevel(unittest.TestCase):
        def test_logger_level(self):
            log = logging.getLogger(__name__)
            with logger_level(log, logging.INFO):
                log.debug('this should not be logged')
                log.info('this should be logged')
                log.warning('this should be logged')
                log.error('this should be logged')

    unittest.main()


if __name__ == '__main__':
    test_case_0()
    test_logger_level()


# module level call
get_logger()

# Generated at 2022-06-26 02:30:48.031316
# Unit test for function logger_level
def test_logger_level():
    #TODO: This test no longer works
    # pass because urllib3 and requests logs INFO level
    # messages.
    return

    with logger_level(var_0, logging.WARN):
        var_0.debug('debug message')
        var_0.info('info message')
        var_0.warn('warn message')
        var_0.warning('warning message')
        var_0.error('error message')
        var_0.critical('critical message')
        var_0.fatal('fatal message')


# This will run when the script's run directly.
if __name__ == '__main__':
    configure()
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:53.712417
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warn message')
        logger.error('error message')
        logger.critical('critical message')


if __name__ == '__main__':
    test_case_0()
    test_logger_level()
    # import doctest
    # doctest.testmod()

# Generated at 2022-06-26 02:30:57.183783
# Unit test for function logger_level
def test_logger_level():
    test_case_0()
    test_case_1()

    # The following cases are not tested since they cannot be run on command line
    #
    # test_case_2()

    print("Test finished. There is nothing to see here. Move along.")



# Generated at 2022-06-26 02:31:11.990741
# Unit test for function logger_level
def test_logger_level():
    """Ensure that logger_level is set correctly."""
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    logger = mock.Mock()
    with logger_level(logger, 'a'):
        assert logger.level == 'a'
    assert logger.level != 'a'

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:31:21.597932
# Unit test for function logger_level
def test_logger_level():
    log_temp = get_logger('test_logger_level')

    with logger_level(log_temp, logging.DEBUG):
        log_temp.debug("debug message")

    with logger_level(log_temp, logging.INFO):
        log_temp.info("debug message")

    with logger_level(log_temp, logging.WARNING):
        log_temp.warning("debug message")

    with logger_level(log_temp, logging.ERROR):
        log_temp.error("debug message")

    with logger_level(log_temp, logging.CRITICAL):
        log_temp.critical("debug message")


test_logger_level()

# Generated at 2022-06-26 02:31:37.296369
# Unit test for function logger_level
def test_logger_level():
    if hasattr(logging, 'getLoggerClass') and sys.version_info[0] == 2:
        logging.setLoggerClass(logging.Logger)

    # Name of function for which logger is created
    fn_name = 'test_logger_level'

    # Name of the logger to be created
    log_name = 'test_logger_level'

    # Get output from logger with level as INFO
    with logger_level(logging.getLogger(log_name), logging.INFO):
        assert logging.getLogger(log_name).isEnabledFor(logging.INFO)

    # Get output from logger with level as DEBUG

# Generated at 2022-06-26 02:31:41.933824
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        logger.error("This should be displayed")
        logger.warning("This should not be displayed")
        logger.info("This should not be displayed")
        logger.debug("This should not be displayed")

if __name__ == "__main__":
    configure(DEFAULT_CONFIG)
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:31:51.569344
# Unit test for function logger_level
def test_logger_level():
    import time
    import io
    import sys
    import logging

    log = logging.getLogger(__name__)
    log.setLevel(logging.ERROR)
    log.addHandler(logging.StreamHandler())

    output = io.StringIO()
    old_stdout = sys.stdout

# Generated at 2022-06-26 02:31:55.508780
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.ERROR):
        logger.info('info message')
        logger.error('error message')
        logger.debug('debug message')


# Generated at 2022-06-26 02:32:00.333233
# Unit test for function logger_level
def test_logger_level():
    configure()
    var_1 = get_logger()
    with logger_level(var_1, 10):
        var_1.info('10')
        var_1.debug('10')
        var_1.warning('10')
    var_1.info('20')
    var_1.debug('20')
    var_1.warning('20')


# Generated at 2022-06-26 02:32:01.023071
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), 10001):
        assert get_logger().level == 10001

# Generated at 2022-06-26 02:32:06.197122
# Unit test for function logger_level
def test_logger_level():

    def assert_level(level, logger=None):
        logger = logger or get_logger()
        assert logger.level == level

    assert_level(logging.DEBUG)

    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        assert_level(logging.ERROR, logger)
    assert_level(logging.DEBUG, logger)

    logger = get_logger()
    with logger_level(logger, logging.INFO):
        with logger_level(logger, logging.ERROR):
            assert_level(logging.ERROR, logger)
        assert_level(logging.INFO, logger)
    assert_level(logging.DEBUG, logger)



# Generated at 2022-06-26 02:32:09.755160
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger_0 = logging.getLogger()
    orig_level = logger_0.level
    with logger_level(logger_0, logging.INFO):
        assert logger_0.level == logging.INFO
    assert logger_0.level == orig_level



# Generated at 2022-06-26 02:32:33.558353
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        assert log.isEnabledFor(logging.INFO)
        assert not log.isEnabledFor(logging.DEBUG)
    assert log.isEnabledFor(logging.DEBUG)
    assert not log.isEnabledFor(logging.INFO)



# Generated at 2022-06-26 02:32:38.147431
# Unit test for function logger_level
def test_logger_level():
    logger, level = logging.getLogger(), logging.DEBUG
    with logger_level(logger, level):
        assert logger.level == level


if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:32:48.254649
# Unit test for function logger_level
def test_logger_level():
    # Create mock loggers to test logger_level function
    logger_initial = get_logger()
    logger_initial_1 = get_logger()

    # Test case with no name provided
    logger_var_0 = get_logger()

    # Test case for logger_level.
    with logger_level(logger_initial, logging.ERROR):
        logger_var_0.debug("Uncaught error")

    # Test case for logger_level with name.
    with logger_level(logger_initial_1, logging.ERROR):
        logger_initial_1.debug("Uncaught error")

    # Test case for logger_level with level name provided.
    with logger_level(logger_initial, "ERROR"):
        logger_initial.debug("Uncaught error")



# Generated at 2022-06-26 02:32:55.338825
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import logging
    class logger_level_TestCase(unittest.TestCase):
        def runTest(self):
            assert True
            logger = logging.getLogger()
            level = logging.DEBUG
            with logger_level(logger, level) as logger_level_result:
                assert True
            assert logger_level_result is None
            assert True

    logger_level_TestSuite = unittest.TestSuite()
    logger_level_TestSuite.addTest(logger_level_TestCase())
    logger_level_TestResult = unittest.TextTestRunner().run(logger_level_TestSuite)
    print("logger_level_TestResult: %s" % logger_level_TestResult)

# Generated at 2022-06-26 02:32:58.823062
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    with logger_level(var_0, logging.ERROR):
        var_0.info("This should not be printed")
        var_0.error("This should be printed")



# Generated at 2022-06-26 02:33:05.280380
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.DEBUG):
        log.info("This should be debug")
        log.debug("This should be debug too")
        log.error("This should be debug too")

    with logger_level(log, logging.INFO):
        log.info("This should be info")
        log.debug("This should not be debug")
        log.error("This should be info too")


# Generated at 2022-06-26 02:33:09.813832
# Unit test for function logger_level
def test_logger_level():

    logger = get_logger()
    value_initial = logger.level
    logger.error('This is an error message')
    logger.warn('This is a warning message')
    logger.info('This is an info message')
    logger.debug('This is a debug message')



# Generated at 2022-06-26 02:33:11.687027
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logging.DEBUG
    logger_level(logger, level)
    assert logger.level == level


# Generated at 2022-06-26 02:33:17.252252
# Unit test for function logger_level
def test_logger_level():
    l = logging.getLogger('test.logger')
    hdl = logging.StreamHandler(sys.stderr)
    hdl.setFormatter(logging.Formatter('%(message)s'))
    l.addHandler(hdl)
    l.setLevel(logging.DEBUG)

    with logger_level(l, logging.WARN):
        l.warn('warning')
        l.info('info')

    l.warn('warning')
    l.debug('debug')

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:21.822727
# Unit test for function configure
def test_configure():
    var_1 = configure(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)


# Generated at 2022-06-26 02:34:05.988956
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger("test_logger")
    with logger_level(test_logger, logging.DEBUG):
        test_logger.debug("logger level DEBUG")
    with logger_level(test_logger, logging.INFO):
        test_logger.info("logger level INFO")
    with logger_level(test_logger, logging.WARNING):
        test_logger.warning("logger level WARNING")



# Generated at 2022-06-26 02:34:08.006146
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARN):
        assert logger.level == logging.WARN


# Generated at 2022-06-26 02:34:18.138257
# Unit test for function logger_level
def test_logger_level():
    import time
    # Set up fake logger, to capture logging output
    class FakeLoggingHandler(logging.Handler):
        """Fake logging handler to check for expected logs."""
        def __init__(self, *args, **kwargs):
            self.reset()
            logging.Handler.__init__(self, *args, **kwargs)

        def emit(self, record):
            self.messages[record.levelname.lower()].append(record.getMessage())

        def reset(self):
            self.messages = {
                'debug': [],
                'info': [],
                'warning': [],
                'error': [],
                'critical': [],
            }

    fake_handler = FakeLoggingHandler()
    fake_logger = logging.getLogger('fake')

# Generated at 2022-06-26 02:34:21.128864
# Unit test for function configure
def test_configure():
    print("*********")
    print("Unit test for:", inspect.stack()[0][3])
    print("*********")

    config = get_config()
    configure(config)


# Generated at 2022-06-26 02:34:26.945075
# Unit test for function logger_level
def test_logger_level():
    # test_case_0
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG, 'assertion error: assert logger.level == logging.DEBUG'
    assert logger.level == logging.INFO, 'assertion error: assert logger.level == logging.INFO'


# Generated at 2022-06-26 02:34:36.609245
# Unit test for function logger_level
def test_logger_level():
    import pytest
    import io

    # Variable definitions for code coverage
    handler_1 = logging.StreamHandler()
    logger_2 = logging.getLogger()
    logger_2.addHandler(handler_1)
    with logger_level(logger_2, logging.INFO):
        logger_2.info('message: test_logger_level')
    out = io.StringIO()
    with handler_1.stream as stream, logger_level(logger_2, logging.INFO):
        stream.truncate(0)
        stream.seek(0)
        # Should cover log below
        logger_2.info('message: test_logger_level')
        out.write(stream.getvalue().strip())
        # Ensure no DEBUG and no INFO
        assert "DEBUG" not in out.getvalue()

# Generated at 2022-06-26 02:34:46.476267
# Unit test for function logger_level
def test_logger_level():
    """For future reference, use with logger_level(logger, level): """
    var_1 = logging.DEBUG

    def test_method_case():
        var_2 = get_logger()

        # Unit test for function logger_level
        with logger_level(var_2, var_1):
            var_2.info('test2')
            var_2.debug('test2')
            var_2.error('test2')
            var_2.warning('test2')
            var_2.info('test2')

        var_2.info('test2')
        var_2.debug('test2')
        var_2.error('test2')
        var_2.warning('test2')
        var_2.info('test2')

    test_method_case()


# Generated at 2022-06-26 02:34:52.303404
# Unit test for function logger_level
def test_logger_level():
    lg = get_logger(__name__)
    with logger_level(lg, logging.DEBUG):
        lg.debug('Debug')
        lg.info('Info')
    lg.debug('Debug again')


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:34:54.839804
# Unit test for function logger_level
def test_logger_level():
    import logging
    root = logging.getLogger()
    with logger_level(root, logging.CRITICAL):
        assert root.level == logging.CRITICAL
    assert root.level != logging.CRITICAL

# Generated at 2022-06-26 02:34:58.924241
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.ERROR):
        log.setLevel(logging.DEBUG)
        assert log.getEffectiveLevel() == logging.ERROR
    with logger_level(log, logging.INFO):
        log.setLevel(logging.DEBUG)
        assert log.getEffectiveLevel() == logging.INFO

