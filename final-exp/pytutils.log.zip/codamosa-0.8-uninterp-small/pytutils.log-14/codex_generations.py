

# Generated at 2022-06-26 02:26:00.258050
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        logger("abc def ghi")

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:26:07.442222
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger(__name__)
    test_logger.setLevel(logging.DEBUG)

    with logger_level(test_logger, logging.ERROR):
        assert(test_logger.isEnabledFor(logging.ERROR))
        assert(not test_logger.isEnabledFor(logging.DEBUG))

    assert(test_logger.isEnabledFor(logging.DEBUG))


if __name__ == '__main__':
    import doctest

    print(doctest.testmod())

# Generated at 2022-06-26 02:26:15.641911
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    log = logging.getLogger('bar')
    with logger_level(log, logging.DEBUG):
        log.error('This is an error')
        log.warning('This is a warning')
        log.info('This is info')
        log.debug('This is DEBUG')
    log.error('This is an error')
    log.warning('This is a warning')
    log.info('This is info')
    log.debug('This is DEBUG')

# Generated at 2022-06-26 02:26:19.000089
# Unit test for function logger_level
def test_logger_level():
    root = logging.getLogger("")
    with logger_level(root, logging.DEBUG):
        assert root.isEnabledFor(logging.DEBUG)
    assert not root.isEnabledFor(logging.DEBUG)



# Generated at 2022-06-26 02:26:27.626902
# Unit test for function logger_level
def test_logger_level():
    import logging
    import StringIO
    import sys
    import unittest

    class LoggerLevelTest(unittest.TestCase):
        def test_logger_level(self):
            out = StringIO.StringIO()
            handler = logging.StreamHandler(out)
            logger = logging.getLogger(__name__)
            logger.addHandler(handler)
            with logger_level(logger, logging.INFO):
                logger.debug('test')
                self.assertEqual(out.getvalue(), '')
                logger.info('test')
                self.assertEqual(out.getvalue(), 'test\n')
                logger.warning('test')
                self.assertEqual(out.getvalue(), 'test\ntest\n')
                logger.error('test')

# Generated at 2022-06-26 02:26:32.469487
# Unit test for function logger_level
def test_logger_level():
    import unittest.mock
    logger = unittest.mock.Mock()
    level = 3
    with logger_level(logger, level):
        logger.assert_called_with()

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:26:37.870632
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    old_level = logger.level
    log_level_list = [logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR]
    for log_level in log_level_list:
        with logger_level(logger, log_level):
            assert logger.level == log_level
    assert logger.level == old_level

# Generated at 2022-06-26 02:26:49.936683
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("logger_level")
    logger.debug("TEST DEBUG log")
    logger.info("TEST INFO log")
    logger.warning("TEST WARNING log")
    logger.error("TEST ERROR log")
    with logger_level(logger, logging.INFO):
        logger.debug("TEST DEBUG log. Should not log")
        logger.info("TEST INFO log. Logs")
        logger.warning("TEST WARNING log. Logs")
        logger.error("TEST ERROR log. Logs")
    logger.debug("TEST DEBUG log")
    logger.info("TEST INFO log")
    logger.warning("TEST WARNING log")
    logger.error("TEST ERROR log")

if __name__ == '__main__':
    test_logger_level()
    pass

# Generated at 2022-06-26 02:26:52.801412
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger('test_logger')
    with logger_level(test_logger, logging.INFO):
        assert test_logger.isEnabledFor(logging.INFO)



# Generated at 2022-06-26 02:27:01.199057
# Unit test for function logger_level
def test_logger_level():
    # Test logger_level's in python 2.x
    if sys.version_info[0] < 3:
        logger = logging.getLogger(__name__)
        assert logger.level == logging.NOTSET
        with logger_level(logger, logging.DEBUG):
            assert logger.level == logging.DEBUG
        assert logger.level == logging.NOTSET


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:27:13.831836
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    logger1 = logging.getLogger('Test')
    with logger_level(logger1, logging.INFO):
        assert logger1.level == logging.INFO
        logger2 = logging.getLogger('Test')
        assert logger2.level == logging.INFO
    logger3 = logging.getLogger('Test')
    assert logger3.level == logging.WARNING
    with logger_level(logger1, logging.ERROR):
        assert logger1.level == logging.ERROR
        logger1.error('test')
        with logger_level(logger1, logging.CRITICAL):
            assert logger1.level == logging.CRITICAL
            logger1.critical('test')

# Generated at 2022-06-26 02:27:19.889241
# Unit test for function get_config
def test_get_config():
    with open('/tmp/logging.json', 'w+') as f:
        f.write('{"a": 1}')
    cfg = get_config(default=None, env_var=None, given='{"a": 2}')
    assert cfg['a'] == 2
    cfg = get_config(default=None, env_var='/tmp/logging.json', given=None)
    assert cfg['a'] == 1



# Generated at 2022-06-26 02:27:26.301150
# Unit test for function logger_level
def test_logger_level():
    import logging.handlers
    log = logging.getLogger('test_logger_level')
    log.setLevel('DEBUG')

    handler = logging.handlers.MemoryHandler(10, level='DEBUG')
    log.addHandler(handler)

    assert log.level == logging.DEBUG
    log.info('Testing log level context manager.')
    assert len(handler.buffer) == 1

    with logger_level(log, 'INFO'):
        assert log.level == logging.INFO
        log.info('Testing log level context manager.')
        assert len(handler.buffer) == 1



# Generated at 2022-06-26 02:27:34.876402
# Unit test for function logger_level
def test_logger_level():
    import sys
    capturer = StringIO()
    stream_handler = logging.StreamHandler(capturer)
    logger = get_logger()
    logger.addHandler(stream_handler)

    with logger_level(logger, logging.WARNING):
        logger.info('info line')
        logger.warning('warning line')
        logger.error('error line')

    assert 'info line' not in capturer.getvalue()
    assert 'warning line' in capturer.getvalue()
    assert 'error line' in capturer.getvalue()

    logger.removeHandler(stream_handler)
    stream_handler.close()
    capturer.close()

    return True

# Generated at 2022-06-26 02:27:45.147676
# Unit test for function get_config
def test_get_config():
    # Unit test for function get_config
    # Given
    import json


# Generated at 2022-06-26 02:27:53.471824
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('root')
    import io
    import sys

    output = io.StringIO()
    log.addHandler(logging.StreamHandler(output))

    with logger_level(log, logging.WARN):
        log.info("Don't see me")
        log.warn("A warning")

        assert "A warning" in output.getvalue()
        assert "Don't" not in output.getvalue()

    log.info("See me again")

    assert "See me" in output.getvalue()



# Generated at 2022-06-26 02:28:03.970715
# Unit test for function logger_level
def test_logger_level():
    print('testing logger_level')
    import mock
    import io
    import logging
    import unittest
    import sys

    # python 2 compatibility, we're not executing this code, just inspecting it
    exc_info = sys.exc_info

    class Test(unittest.TestCase):
        def setUp(self):
            self.handle = io.StringIO()
            self.logger = logging.getLogger()
            self.handler = logging.StreamHandler(self.handle)
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.ERROR)
            self.logger.propagate = False

        def tearDown(self):
            self.logger.removeHandler(self.handler)

        def test_no_change(self):
            context_manager = logger_level

# Generated at 2022-06-26 02:28:06.827932
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
    assert logger.getEffectiveLevel() == logging.WARNING



# Generated at 2022-06-26 02:28:09.316087
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET



# Generated at 2022-06-26 02:28:21.501689
# Unit test for function logger_level
def test_logger_level():
    py_info = _PyInfo()
    if py_info.PY2:
        logger_level(getLogger(), logging.DEBUG)
        getLogger().debug('test_logger_level')
        getLogger().info('test_logger_level')
        getLogger().warn('test_logger_level')
        getLogger().error('test_logger_level')
        getLogger().critical('test_logger_level')
    else:
        getLogger().debug('test_logger_level')
        getLogger().info('test_logger_level')
        getLogger().warn('test_logger_level')
        getLogger().error('test_logger_level')
        getLogger().critical('test_logger_level')


# Generated at 2022-06-26 02:28:29.290717
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager

    var_0 = test_logger_level.__wrapped__()
    with logger_level(var_0, logging.ERROR):
        var_0.info("test")



# Generated at 2022-06-26 02:28:36.641167
# Unit test for function logger_level
def test_logger_level():
    """
    Test logger_level context manager.
    """
    logger = getLogger("kablog")
    logger.info("I'm a logger")

    with logger_level(logger, logging.INFO):
        logger.info("I'm an info logger")
        logger.debug("I'm a debug logger")

    logger.debug("I'm a debug logger")
    logger.info("I'm an info logger")


test_case_0()
test_logger_level()
sys.exit(0)

# Generated at 2022-06-26 02:28:40.143148
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:28:45.358139
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        print(logger.level)
    print(logger.level)

if __name__ == '__main__':
    # Unit test for function get_logger
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:28:51.615892
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('test_logger_level')
    log.info('before level change')
    logging.disable(logging.DEBUG)
    assert log.level == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
        log.info('this will show up')
    assert log.level == logging.DEBUG
    log.info('this won\'t show up')
    logging.disable(logging.NOTSET)

# Generated at 2022-06-26 02:28:57.630067
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    var_1 = var_0.level
    with logger_level(var_0, logging.INFO):
        var_2 = var_0.level
        var_3 = var_0.level
    var_4 = var_0.level


if __name__ == '__main__':
    configure()
    test_logger_level()

# Generated at 2022-06-26 02:29:05.591730
# Unit test for function logger_level
def test_logger_level():
    import logging
    class MockLogger(logging.Logger):
        def __init__(self, name, level=logging.NOTSET):
            self.name = name
            self.level = level

    var_0 = MockLogger('logger0', logging.DEBUG)
    var_0.level
    with logger_level(var_0, logging.DEBUG):
        var_0.level
    with logger_level(var_0, logging.INFO):
        var_0.level
    var_0.level


# Generated at 2022-06-26 02:29:08.994998
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:29:17.289651
# Unit test for function logger_level
def test_logger_level():
    import time
    import datetime

    now = datetime.datetime.now()

    def test_case_0():
        var_0 = get_logger("testing_logger_level")
        var_0.setLevel(logging.INFO)
        logger_0_listen = logging.handlers.BufferingHandler(0)
        logger_1_listen = logging.handlers.BufferingHandler(0)

        var_0.addHandler(logger_0_listen)
        msg = "test_" + str(now)
        var_0.info(msg)
        var_0.warn(msg)
        var_0.debug(msg)
        var_0.error(msg)
        var_0.critical(msg)

        return logger_0_listen

    # Test case 1
    test

# Generated at 2022-06-26 02:29:27.055614
# Unit test for function logger_level
def test_logger_level():
    from io import StringIO
    from os import path

    import unittest
    from unittest.mock import patch

    test_file = path.basename(__file__)
    logger = getLogger(__name__)
    assert logger.level

    output = StringIO()
    handler = logging.StreamHandler(output)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    assert logger.level

    # test INFO
    with logger_level(logger, logging.INFO):
        logger.info('run test')
        assert 'run test' in output.getvalue()

    # test DEBUG level
    logger.removeHandler(handler)
    output_DBG = StringIO()

# Generated at 2022-06-26 02:29:32.169294
# Unit test for function logger_level
def test_logger_level():
    import logging
    with logger_level(logging.getLogger(), logging.DEBUG):
        pass


# Generated at 2022-06-26 02:29:35.792509
# Unit test for function logger_level
def test_logger_level():

    import logging

    log_name = "logger_name"
    logger = logging.getLogger(log_name)

    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO

    assert logger.level == logging.ERROR


# Generated at 2022-06-26 02:29:40.438176
# Unit test for function logger_level
def test_logger_level():
    # logger_level(logger, level)

    var_0 = get_logger()
    var_1 = logging.DEBUG
    test_logger_level_0 = logger_level(var_0, var_1)
    test_logger_level_0.__enter__()
    # test_logger_level_0.__exit__()



# Generated at 2022-06-26 02:29:48.114857
# Unit test for function logger_level
def test_logger_level():
    LOGGER = logging.getLogger('test')
    LOGGER.setLevel(logging.INFO)
    LOGGER.addHandler(logging.StreamHandler())
    BEFORE = LOGGER.isEnabledFor(logging.DEBUG)
    with logger_level(LOGGER, logging.DEBUG):
        AFTER = LOGGER.isEnabledFor(logging.DEBUG)
    FINAL = LOGGER.isEnabledFor(logging.DEBUG)

    assert (BEFORE == False)
    assert (AFTER == True)
    assert (FINAL == False)

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:29:54.887821
# Unit test for function logger_level
def test_logger_level():
    # configure logging
    configure()

    # get logger
    log = get_logger()

    # log something at DEBUG level
    with logger_level(log, logging.DEBUG):
        log.debug('test case 1')

    # log something at INFO level
    with logger_level(log, logging.INFO):
        log.debug('test case 2')

    # log something at ERROR level
    with logger_level(log, logging.ERROR):
        log.debug('test case 3')



# Generated at 2022-06-26 02:29:59.967099
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    logger.setLevel(logging.INFO)

    with logger_level(logger, logging.DEBUG):
        logger.info('This will be printed')
        logger.debug('This will be printed as well')
    logger.info('This will not be printed')
    logger.debug('This will not be printed as well')

    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        logger.info('This will be printed')
        logger.debug('This will be printed as well')
    logger.info('This will be printed')
    logger.debug('This will not be printed as well')


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:09.856678
# Unit test for function logger_level
def test_logger_level():
    # Capture stdout
    temp_stdout = sys.stdout
    out = StringIO()
    sys.stdout = out
    # Capture stderr
    temp_stderr = sys.stderr
    err = StringIO()
    sys.stderr = err

    log = logging.getLogger(__name__)

    with logger_level(log, logging.WARNING):
        log.debug('this should not appear')

    log.warning('this should appear')

    # Release capture
    sys.stdout = temp_stdout
    sys.stderr = temp_stderr

    # Check captured stdout
    out_text = out.getvalue()
    assert 'this should appear' in out_text
    assert 'this should not appear' not in out_text

    # Check captured stderr
    err

# Generated at 2022-06-26 02:30:13.248887
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger("test_name")
    logger.setLevel(logging.WARNING)
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG

    assert logger.getEffectiveLevel() == logging.WARNING

# Generated at 2022-06-26 02:30:16.014313
# Unit test for function logger_level
def test_logger_level():
    print("Testing logger_level")
    log = get_logger()
    with logger_level(log, logging.INFO):
        log.debug("This should not print")
        log.info("This should print")


# Generated at 2022-06-26 02:30:22.608666
# Unit test for function logger_level
def test_logger_level():
    var_0 = logging.Logger('logger')
    var_0.setLevel(logging.INFO)
    var_1 = var_0.getEffectiveLevel()
    assert var_1 == 20
    var_2 = logging.Logger('logger')
    with logger_level(var_2, logging.ERROR):
        var_3 = var_2.getEffectiveLevel()
        assert var_3 == 40
    var_4 = var_2.getEffectiveLevel()
    assert var_4 == 20


# Generated at 2022-06-26 02:30:35.962151
# Unit test for function logger_level

# Generated at 2022-06-26 02:30:36.839213
# Unit test for function configure
def test_configure():
    # TODO
    pass



# Generated at 2022-06-26 02:30:46.512127
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config


# Generated at 2022-06-26 02:30:50.037414
# Unit test for function logger_level
def test_logger_level():
    # Test type of return value
    value = logger_level(logger=logging.getLogger(), level=logging.DEBUG)
    assert isinstance(value, types.GeneratorType)



# Generated at 2022-06-26 02:31:01.406179
# Unit test for function logger_level
def test_logger_level():
    import time


# Generated at 2022-06-26 02:31:04.698993
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    initial = logger.level
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == initial


# Generated at 2022-06-26 02:31:09.330523
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('case_logger_level')
    with logger_level(logger, 100):
        logger.error('test_case_logger_level_0')
    logger.warning('test_case_logger_level_1')


# Generated at 2022-06-26 02:31:10.433172
# Unit test for function logger_level
def test_logger_level():
    logger_level()


# Generated at 2022-06-26 02:31:18.869616
# Unit test for function logger_level
def test_logger_level():
    # Initialize a logger and set the level to debug
    log = get_logger()
    log.setLevel(logging.DEBUG)

    # Use the logger_level function to set the level to INFO within a context block
    with logger_level(log, logging.INFO):
        # Send a log message to see that the level is INFO
        log.debug('Inside the context block')

    # Send a log message to see that the level is back to DEBUG
    log.debug('Back to the normal level')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:31:22.413907
# Unit test for function get_config
def test_get_config():
    assert(get_config('{"version": 1}') == {"version": 1})
    assert(get_config('version: 1') == {"version": 1})
    assert(get_config({ "version": 1}) == {"version": 1})



# Generated at 2022-06-26 02:31:30.723666
# Unit test for function logger_level
def test_logger_level():

    # Configure logging to test function logger_level
    logging.config.dictConfig(DEFAULT_CONFIG)

    logger = getLogger()
    # The initial logger level
    initial_level = logger.level

    # Set the level to DEBUG
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    # Check that the logger level is reset to the initial level
    assert logger.level == initial_level

# Generated at 2022-06-26 02:31:34.618640
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger()
    var_3 = logger_level(var_1, logging.INFO)
    with var_3:
        var_2 = get_logger()
        var_2.info('test')

# Generated at 2022-06-26 02:31:37.227174
# Unit test for function logger_level
def test_logger_level():
    """
    >>> with logger_level(get_logger(), logging.ERROR):
    ...     get_logger().warning('this should not show up')
    """
    pass

# Generated at 2022-06-26 02:31:44.181907
# Unit test for function get_config
def test_get_config():
    # Test that valid JSON and YAML gets processed
    json = '{"version": 1, "formatters": {"simple": {"format": "%(levelname)s %(message)s"}}}'
    yaml = 'version: 1\nformatters:\n  simple:\n    format: "%(levelname)s %(message)s"'
    for config in [json, yaml]:
        cfg = get_config(config)
        assert isinstance(cfg, dict)
        assert cfg['formatters']['simple']['format'] == '%(levelname)s %(message)s'

    # Test that config can be loaded from an env var
    os.environ['LOGGING'] = json

# Generated at 2022-06-26 02:31:52.215059
# Unit test for function logger_level
def test_logger_level():
    global test_logger_level_logger
    global test_logger_level_level
    global test_logger_level_return_value
    global test_logger_level_initial
    global test_logger_level_level_set
    logger = test_logger_level_logger
    level = test_logger_level_level
    return_value = test_logger_level_return_value
    initial = test_logger_level_initial
    level_set = test_logger_level_level_set
    with logger_level(logger, level):
        level_set.append(True)
        assert logger.level is level
        yield return_value
    assert logger.level is initial


# Generated at 2022-06-26 02:31:57.644824
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    configure()

    with logger_level(log, logging.DEBUG):
        log.debug('hi')
        assert log.level == logging.DEBUG

    assert log.level == logging.DEBUG


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:31:59.539535
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logger.level
    with logger_level(logger, logging.DEBUG):
        assert logger.level <= 20
    assert logger.level == level


# Generated at 2022-06-26 02:32:02.541031
# Unit test for function logger_level
def test_logger_level():
    import contextlib

    with logger_level(get_logger(), logging.CRITICAL):
        with contextlib.suppress(Exception):
            assert False


# Generated at 2022-06-26 02:32:07.017460
# Unit test for function get_config
def test_get_config():
    """
    >>> c = {'version': 1,'disable_existing_loggers': False, 'formatters':{'f':{'format':'%(asctime)s %(levelname)s %(message)s','datefmt': '%Y-%m-%d %H:%M:%S'}}, 'handlers':{'h':{'class': 'logging.StreamHandler','formatter': 'f', 'level': 20}}, 'loggers':{'l':{'handlers': ['h'],'level': 10}}}
    >>> c == get_config(c)
    True
    """
    pass


# Generated at 2022-06-26 02:32:16.308698
# Unit test for function get_config

# Generated at 2022-06-26 02:32:28.662036
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('Should be visible')
        logger.info('Should not be visible')


# Generated at 2022-06-26 02:32:30.419361
# Unit test for function get_config
def test_get_config():
    given = None
    env_var = None
    default = None

    config = get_config(given, env_var, default)


# Generated at 2022-06-26 02:32:35.164370
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    with var_0.logger_level(ENUM_0):
        pass

if __name__ == '__main__':
    configure()

    log = get_logger()
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')

    log = get_logger('test.log')
    log.debug('debug')
    log.info('info')
    log.warning('warning')
    log.error('error')
    log.critical('critical')
    # test_case_0()
    # test_logger_level()

# Generated at 2022-06-26 02:32:39.566309
# Unit test for function logger_level
def test_logger_level():
    l = logging.getLogger(__name__)

    with logger_level(l, logging.CRITICAL):
        l.debug('this should not show up')
        l.critical('but this should')

    l.debug('this should show up now')



# Generated at 2022-06-26 02:32:43.089528
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger('my_logger'), logging.DEBUG):
        logger = logging.getLogger('my_logger')
        assert logger.isEnabledFor(logging.DEBUG)


# Generated at 2022-06-26 02:32:50.370242
# Unit test for function logger_level
def test_logger_level():
    import mock
    import contextlib
    import logging

    _mock = mock.Mock()

    with logger_level(_mock, logging.INFO):
        _mock.level = logging.INFO
    _mock.assert_has_calls([
        mock.call.level,
        mock.call.level,
    ])


if __name__ == '__main__':
    test_case_0()
    test_logger_level()
    get_logger().info('You can use this module for logging!')

# Generated at 2022-06-26 02:32:52.594370
# Unit test for function logger_level
def test_logger_level():

    var_0 = logging.getLogger('test')
    with logger_level(var_0, logging.DEBUG):
        var_1 = get_config('{"version":1,"disable_existing_loggers":False}')
    var_2 = logging.getLogger('test2')



# Generated at 2022-06-26 02:32:58.674992
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger('test_logger_level')
    logger.debug('Debug message')
    logger.info('info')

    with logger_level(logger, logging.DEBUG):
        logger.info('DEBUG')
        logger.debug('debug')

    logger.debug('Debug message')
    logger.info('info')
    # logger_level(logger, logging.DEBUG)
    # logger.info('DEBUG')
    # logger.debug('debug')



# Generated at 2022-06-26 02:33:10.203068
# Unit test for function get_config
def test_get_config():
    # test no config, no env, default
    cfg = get_config(config=None, env_var=None, default="none")
    assert cfg == "none"

    # test config, env, default
    cfg = get_config(config="config", env_var="env", default="default")
    assert cfg == "config"

    # test config, env, no default
    cfg = get_config(config="config", env_var="env")
    assert cfg == "config"

    # test no config, env, default
    cfg = get_config(config=None, env_var="env", default="default")
    assert cfg == "env"

    # test no config, env, no default

# Generated at 2022-06-26 02:33:15.231914
# Unit test for function logger_level
def test_logger_level():
    """test case for _logger_level"""
    import sys

    import StringIO

    args = {
        'level': logging.ERROR,
    }

    stdout = sys.stdout
    sys.stdout = StringIO.StringIO()

    with logger_level(get_logger(), **args):
        get_logger().info('this should not be printed')
    assert "this should not be printed" not in sys.stdout.getvalue().strip(
    ), "Error in test_logger_level"

    sys.stdout = stdout



# Generated at 2022-06-26 02:33:28.793590
# Unit test for function logger_level
def test_logger_level():
    console_logger = logging.getLogger().handler
    with logger_level(logging.getLogger(), logging.DEBUG):
        assert console_logger.level == logging.DEBUG
    assert console_logger.level == logging.INFO

# Generated at 2022-06-26 02:33:40.576437
# Unit test for function logger_level
def test_logger_level():
    main_logger = get_logger()
    main_logger.setLevel(logging.INFO)

    with logger_level(main_logger, logging.DEBUG):
        assert main_logger.getEffectiveLevel() == logging.DEBUG
        test_logger = get_logger()
        test_logger.debug('Logging debug data')
        assert test_logger.getEffectiveLevel() == logging.DEBUG

    assert main_logger.getEffectiveLevel() == logging.INFO
    test_logger.warning('Logging warning data')
    assert test_logger.getEffectiveLevel() == logging.INFO


if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:44.058160
# Unit test for function logger_level
def test_logger_level():
    # Test Case 1
    with logger_level():
        assert 1==1

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:48.602890
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    with logger_level(var_0, logging.getLevelName('NOTSET')):
        if(var_0.isEnabledFor(logging.getLevelName('NOTSET'))):
            var_0.critical("critical message")


# Generated at 2022-06-26 02:33:51.963136
# Unit test for function logger_level
def test_logger_level():
    get_logger().info('test')

    with logger_level(get_logger(), logging.FATAL):
        get_logger().info('test 2')

    with logger_level(get_logger(), logging.INFO):
        get_logger().info('test 3')



# Generated at 2022-06-26 02:34:03.923118
# Unit test for function logger_level
def test_logger_level():
    import StringIO

    buf = StringIO.StringIO()

    logger = logging.getLogger(__name__)

    hdlr = logging.StreamHandler(buf)
    formatter = logging.Formatter('%(message)s')
    hdlr.setFormatter(formatter)
    logger.addHandler(hdlr)
    logger.setLevel(logging.DEBUG)

    with logger_level(logger, logging.INFO):
        logger.debug('Debug')
    assert buf.getvalue() == ''

    with logger_level(logger, logging.DEBUG):
        logger.debug('Debug')
    assert buf.getvalue() == 'Debug\n'


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-26 02:34:05.776541
# Unit test for function configure
def test_configure():
    try:
        configure()
        assert True
    except TypeError:
        assert False
    except Exception:
        assert False



# Generated at 2022-06-26 02:34:11.948381
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger()
    assert var_1.getEffectiveLevel() == 10
    with logger_level(var_1, 30):
        assert var_1.getEffectiveLevel() == 30
    assert var_1.getEffectiveLevel() == 10

if __name__ == "__main__":
    sys.exit(test_case_0())
    sys.exit(test_logger_level())

# Generated at 2022-06-26 02:34:16.000521
# Unit test for function logger_level
def test_logger_level():
  import logging
  import contextlib

  logger = logging.getLogger(__name__)

  logger.setLevel(logging.DEBUG)

  with contextlib.closing(logger_level(logger, logging.INFO)):
      assert logger.level == logging.INFO

  logger.debug("test_logger_level")



# Generated at 2022-06-26 02:34:22.108544
# Unit test for function get_config
def test_get_config():

    # test string input
    str_config = get_config(config='{"version":1,"disable_existing_loggers":False,"formatters":{},"handlers":{"console":{"class":"logging.StreamHandler","level":"DEBUG","formatter":"simple","stream":"ext://sys.stdout"}},"loggers":{"root":{"handlers":["console"],"level":"DEBUG"}}}')
    assert str_config == DEFAULT_CONFIG

    # test env var
    os.environ['LOGGING'] = '{"version":1,"disable_existing_loggers":False,"formatters":{},"handlers":{"console":{"class":"logging.StreamHandler","level":"DEBUG","formatter":"simple","stream":"ext://sys.stdout"}},"loggers":{"root":{"handlers":["console"],"level":"DEBUG"}}}'

# Generated at 2022-06-26 02:34:39.766139
# Unit test for function get_config
def test_get_config():
    config = DEFAULT_CONFIG
    assert get_config(default=config) == config
    #assert get_config(given=config) == config

    # TODO: JSON support
    #config = json.dumps(config)
    #assert get_config(given=config) == json.loads(config)

    import tempfile
    from os.path import exists

    with tempfile.NamedTemporaryFile(prefix='log-cfg-',
                                     suffix='.yml',
                                     mode='w',
                                     delete=False) as cfg:
        cfg_filename = cfg.name
        cfg.write(yaml.dump(config))
        cfg.flush()
    
    assert get_config(given=cfg_filename) == config
    os.unlink(cfg_filename)

# Generated at 2022-06-26 02:34:51.028977
# Unit test for function logger_level
def test_logger_level():
    # create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.NOTSET)
    # create console handler and set level to debug
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    # add formatter to handler
    handler.setFormatter(formatter)
    # add handler to logger
    logger.addHandler(handler)
    # start test
    logger.info("Start test")
    with logger_level(logger, logging.DEBUG):
        logger.debug("DEBUG")
        logger.info("DEBUG")
    logger.info("Finish test")



# Generated at 2022-06-26 02:34:59.486513
# Unit test for function logger_level
def test_logger_level():
    debug_logger = get_logger('debug_logger')
    info_logger = get_logger('info_logger')
    with logger_level(debug_logger, logging.DEBUG):
        debug_logger.debug('debug_logger debug message')
        debug_logger.info('debug_logger info message')
        info_logger.debug('info_logger debug message')
        info_logger.info('info_logger info message')
    debug_logger.debug('debug_logger debug message')
    debug_logger.info('debug_logger info message')
    info_logger.debug('info_logger debug message')
    info_logger.info('info_logger info message')

if __name__ == '__main__':
    configure()

    test_logger

# Generated at 2022-06-26 02:35:04.046005
# Unit test for function get_config
def test_get_config():
    logging_config = get_config()
    assert logging_config is not None
    assert type(logging_config) == dict

    logging_config = get_config("")
    assert logging_config is not None
    assert type(logging_config) == dict



# Generated at 2022-06-26 02:35:13.810472
# Unit test for function configure
def test_configure():
    configure()
    print(__name__)
    print(logging.getLogger(__name__))
    logger = logging.getLogger(__name__)
    logger.info('test')

    # with logger_level(logger, logging.DEBUG):
        # logger.debug('debug')
        # logger.info('info')
        # logger.warning('warn')
        # logger.error('error')
        # logger.critical('critical')
        # logging.basicConfig(filename='test.log')

    # with logger_level(logger, logging.DEBUG):
    #     logger.debug('debug')
    #     logger.info('info')
    #     logger.warning('warn')
    #     l

# Generated at 2022-06-26 02:35:22.659130
# Unit test for function logger_level
def test_logger_level():
    import datetime

    _has_configured = []
    _ensure_configured(_has_configured=_has_configured)

    config = get_config()
    verbosity = config.get("handlers", {}).get("console", {}).get("level", logging.INFO)
    console_format = config.get("formatters", {}).get("colored", {}).get("format", "%(message)s")
    console_format = console_format.replace("%(message)s", "%(message)s @%(asctime)s #%(levelname)s")

    logger = logging.getLogger(__name__)
    logger.info("this should be INFO")
    assert logger.level == verbosity

    var_0 = [logger.info("this should be INFO") for _ in range(10)]
   

# Generated at 2022-06-26 02:35:29.961777
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger('debugtest')
    test_logger.setLevel(logging.INFO)
    test_logger.addHandler(logging.StreamHandler(sys.stdout))
    test_logger.debug('This is not shown')
    test_logger.info('This is shown')
    with logger_level(test_logger, logging.DEBUG):
        test_logger.debug('This is shown')
        test_logger.info('This is shown')
    test_logger.debug('This is not shown')
    test_logger.info('This is shown')

if __name__ == '__main__':
    # test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:35:33.883134
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.warning('test')
    with logger_level(logger, logging.DEBUG):
        logger.warning('test')



# Generated at 2022-06-26 02:35:37.491219
# Unit test for function logger_level
def test_logger_level():
    test_case_0()

if __name__ == "__main__":
    test_logger_level()
    test_case_0()

# Generated at 2022-06-26 02:35:47.476984
# Unit test for function logger_level
def test_logger_level():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-d',
        '--debug',
        action='store_true',
        help='Logging level at DEBUG instead of INFO.')
    parser.add_argument('--name', type=str, default=None, help='Logging name')
    args = parser.parse_args()

    log = get_logger(__name__)
    # If debug is set to True, it will change the logging level
    # to DEBUG instead of INFO
    if args.debug:
        with logger_level(log, logging.DEBUG):
            log.info('debug logging is set to %r', args.debug)
            log.debug('debug logging is set to %r', args.debug)
            log.exception('debug logging is set to %r', args.debug)