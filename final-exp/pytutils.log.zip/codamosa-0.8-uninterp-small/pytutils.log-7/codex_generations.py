

# Generated at 2022-06-26 02:25:57.585282
# Unit test for function configure
def test_configure():
    assert configure(None, 'LOGGING', DEFAULT_CONFIG)


# Generated at 2022-06-26 02:26:00.421307
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    logger_level(log, logging.INFO)
    log.info('info')



# Generated at 2022-06-26 02:26:09.726101
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import logging
    import contextlib

    class Logger(object):
        def __init__(self):
            self.level = 0

    logger = Logger()

    with logger_level(logger, 0):
        assert logger.level == 0

    with logger_level(logger, 1):
        assert logger.level == 1

    log = logging.getLogger('test_logger_level')
    with logger_level(log, logging.INFO):
        assert log.getEffectiveLevel() == logging.INFO


if __name__ == '__main__':
    import logging
    import sys

    configure()

    log = logging.getLogger(__name__)
    log.warning('module warning')
    log.error('module error')
    log.info('module info')

# Generated at 2022-06-26 02:26:11.921489
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config(None, None, DEFAULT_CONFIG)

# Generated at 2022-06-26 02:26:22.078335
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    initial = logger.level

    # Check for correct logging output if level is set to INFO
    with logger_level(logger, logging.INFO):
        try:
            logger.debug('Debug message to test logger_level')
        except Exception:
            assert(True)
        finally:
            logger.level = initial
    logger.debug('Debug message to test logger_level')

    # Check for correct logging output if level is set to DEBUG
    with logger_level(logger, logging.DEBUG):
        logger.debug('Debug message to test logger_level')
        try:
            logger.debug('Debug message to test logger_level')
        except Exception:
            assert(False)
        finally:
            logger.level = initial
    logger.debug('Debug message to test logger_level')


# Generated at 2022-06-26 02:26:25.466625
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("logger_level")
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.WARNING):
        assert logger.level == logging.WARNING
        logger.warning("WARNING")
    assert logger.level == logging.INFO

# Generated at 2022-06-26 02:26:35.182832
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    initial = logger.level
    with logger_level(logger, logging.DEBUG):
        assert logging.DEBUG == logger.level
    assert initial == logger.level

if __name__ == "__main__":
    import sys
    import doctest

    doctest.testmod(verbose=0)

    logging.basicConfig(format='%(levelname)s\t%(message)s',
                        level=logging.DEBUG)
    for test_function in (test_case_0, test_logger_level):
        print

# Generated at 2022-06-26 02:26:39.505150
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import logging

    class Test_logger_level(unittest.TestCase):
        def test_case_0(self):
            with logger_level(logging.getLogger(), logging.ERROR):
                pass

        def test_case_1(self):
            pass

    unittest.main()

# Generated at 2022-06-26 02:26:49.977676
# Unit test for function logger_level
def test_logger_level():
    logging.root.setLevel(logging.DEBUG)

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    assert (logger.level == logging.DEBUG)
    with logger_level(logger, logging.INFO):
        assert (logger.level == logging.INFO)

    assert (logger.level == logging.DEBUG)

    with logger_level(logger, logging.ERROR):
        assert (logger.level == logging.ERROR)
        with logger_level(logger, logging.DEBUG):
            assert (logger.level == logging.DEBUG)

    assert (logger.level == logging.DEBUG)



# Generated at 2022-06-26 02:26:52.341227
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG


# Generated at 2022-06-26 02:27:00.253259
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.WARNING):
        #logger.info('Should not be printed')
        print('Info is disabled')
    logger.info('This should be printed')

# Generated at 2022-06-26 02:27:01.735039
# Unit test for function configure
def test_configure():
    py_info_0 = _PyInfo()
    pass



# Generated at 2022-06-26 02:27:11.619160
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import logging

    import jsonlogger

    class TestLogger(unittest.TestCase):
        def test_logger_level_basic(self):
            log = logging.getLogger(__name__)

            with jsonlogger.logger_level(log, logging.DEBUG):
                log.warning(
                    "The 'raise' statement is not a looping statement, so it does not introduce a new scope."
                )
                log.debug("The scope introduced by 'try' is also not a looping scope.")


    suite = unittest.defaultTestLoader.loadTestsFromTestCase(TestLogger)
    unittest.TextTestRunner().run(suite)


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:27:15.107886
# Unit test for function logger_level
def test_logger_level():
    import logging

    with logger_level(logging.getLogger(), logging.INFO):
        logging.info("this is a test")

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-26 02:27:18.325525
# Unit test for function configure
def test_configure():
    env_var = "LOGGING"
    given = None
    config = get_config(given=(given), env_var=(env_var), default=(DEFAULT_CONFIG))
    logging.config.dictConfig(cfg=config)



# Generated at 2022-06-26 02:27:22.419346
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger()
    with logger_level(log, logging.DEBUG):
        assert log.getEffectiveLevel() == logging.DEBUG
    assert log.getEffectiveLevel() != logging.DEBUG

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:27:26.972849
# Unit test for function logger_level
def test_logger_level():
    var_1 = test_case_0.var_0

    var_2 = py_info_0.PY2
    var_3 = py_info_0.PY3
    var_4 = py_info_0.text_type
    var_5 = py_info_0.binary_type
    var_6 = py_info_0.string_types

    if var_2:
        pass
    else:
        if var_3:
            pass
        else:
            pass

# Generated at 2022-06-26 02:27:37.309086
# Unit test for function get_config
def test_get_config():
    # Test config given as a string.
    default = '{"version": 1, "root": {"level": "DEBUG"}}'
    config = get_config(default)
    assert config == {"version": 1, "root": {"level": "DEBUG"}}

    # Test config given in a file.
    default = {"version": 1, "root": {"level": "DEBUG"}}
    with open('temp.txt', "w") as temp:
        temp.write(json.dumps(default))
    config = get_config(None, 'LOGGING', 'temp.txt')
    assert config == {"version": 1, "root": {"level": "DEBUG"}}
    os.remove('temp.txt')

    # Test config given as a dictionary.
    default = {"version": 1, "root": {"level": "DEBUG"}}
    config

# Generated at 2022-06-26 02:27:45.106914
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import io
    import unittest.mock as mock

    test_case = unittest.FunctionTestCase(test_case_0)
    test_case.setUp()
    test_case.runTest()

    with mock.patch('sys.stdout', io.StringIO()) as fake_out:
        var_1 = get_logger()
        var_0 = logger_level(var_1, logging.DEBUG)
        with var_0:
            var_1.debug('some debug message')

    assert 'some debug message' in fake_out.getvalue()


# Generated at 2022-06-26 02:27:56.562128
# Unit test for function logger_level
def test_logger_level():
    example_logger = logging.getLogger(__file__)
    example_logger.setLevel(logging.INFO)

    log_stream = io.StringIO()
    handler = logging.StreamHandler(log_stream)
    formatter = logging.Formatter('%(levelname)s %(asctime)s %(message)s')
    handler.setFormatter(formatter)
    example_logger.addHandler(handler)

    with logger_level(example_logger, logging.WARNING):
        example_logger.debug('Should not appear')
        example_logger.info('Should not appear')
        example_logger.warning('Should appear')
        example_logger.error('Should appear')
        example_logger.critical('Should appear')

    example_logger.debug('Should appear')
   

# Generated at 2022-06-26 02:28:06.871118
# Unit test for function logger_level
def test_logger_level():
    py_info_0 = _PyInfo()
    logging_0 = logging
    log_0 = get_logger()
    assert (log_0.level == logging_0.DEBUG)
    with logger_level(log_0, logging_0.INFO):
        assert (log_0.level == logging_0.INFO)
    assert (log_0.level == logging_0.DEBUG)


# Generated at 2022-06-26 02:28:13.556877
# Unit test for function get_config

# Generated at 2022-06-26 02:28:17.490989
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    assert logger_level(var_0, '0') is not None
    assert logger_level(var_0, '0') is not None
    assert logger_level(var_0, '0') is not None

# Generated at 2022-06-26 02:28:28.117412
# Unit test for function logger_level
def test_logger_level():
    from colorlog import ColoredFormatter, colorlog

    # Create a logging object
    log = get_logger(__name__)

    # Create a format for colored logging
    format = '%(bg_black)s%(log_color)s%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s %(reset)s'
    formatter = ColoredFormatter(fmt=format, log_colors=colorlog.default_log_colors)

    # Create a handler and set level
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)

    # Add the formatter

# Generated at 2022-06-26 02:28:38.669590
# Unit test for function configure
def test_configure():
    if _PyInfo.PY3:
        streams = (sys.stdout, sys.stdin)
    else:
        streams = (sys.stdout, sys.stdin, sys.stdin.fileno())
    for stream in streams:
        try:
            _stdout_klass = type(stream)
        except TypeError:
            continue
        else:
            break
    try:
        _stdout_klass
    except NameError:
        pytest.skip('Could not find a stream to mock!')
    else:
        del streams, stream


# Generated at 2022-06-26 02:28:44.955039
# Unit test for function logger_level
def test_logger_level():
    logger_0 = py_info_0.logger_0
    var_0 = logger_level(logger=logger_0, level=logging.DEBUG)
    with var_0 as var_1:
        pass


if __name__ == '__main__':
    print(dir(logging))

    configure()
    log = get_logger()

    with logger_level(log, logging.DEBUG):
        log.info("foo")

    log.info("bar")
    #
    # get_logger().info("This is a test")

# Generated at 2022-06-26 02:28:48.182299
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    level = logging.INFO
    with logger_level(logger, level):
        assert logger.level == level
        assert logger.propagate is False
    assert logger.level != level
    assert logger.propagate is False


# Generated at 2022-06-26 02:28:52.714444
# Unit test for function get_config
def test_get_config():
    assert get_config(1) == 1
    assert get_config(None, 'LOGGING', '{"1": 1}') == {"1": 1}
    assert get_config(None, 'LOGGING', '{"1": 1}') == {"1": 1}

    os.environ['LOGGING'] = '{"1": 1}'
    assert get_config(None, 'LOGGING') == {"1": 1}



# Generated at 2022-06-26 02:28:57.534782
# Unit test for function get_config
def test_get_config():
    config_0 = None
    env_var_0 = 'LOGGING'
    default_0 = None
    result_0 = get_config(config_0,env_var_0,default_0)
    assert result_0 == default_0


# Generated at 2022-06-26 02:29:00.759155
# Unit test for function logger_level
def test_logger_level():
    _logger = get_logger()
    with logger_level(_logger, logging.INFO):
        _logger.info('Test')


# Generated at 2022-06-26 02:29:07.790699
# Unit test for function get_config
def test_get_config():
    assert get_config(config=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert type(get_config(config=DEFAULT_CONFIG)) == dict



# Generated at 2022-06-26 02:29:11.942469
# Unit test for function logger_level
def test_logger_level():
    import mock
    import logging
    import logging.config

    logger = logging.getLogger('test')
    old_level = logger.level
    with logger_level(logger, 0):
        logger.debug('level:debug')

    with logger_level(logger, logging.DEBUG):
        logger.debug('level:DEBUG')



# Generated at 2022-06-26 02:29:20.499913
# Unit test for function logger_level
def test_logger_level():
    import os
    import logging
    import contextlib
    import io
    import sys

    TEST_LOG_FORMAT = '%(levelname)s %(message)s'

    @contextlib.contextmanager
    def capture_logs(level):
        f = io.StringIO()
        h = logging.StreamHandler(f)
        h.setFormatter(logging.Formatter(TEST_LOG_FORMAT))
        log = logging.getLogger()
        old_level = log.level
        old_handlers = list(log.handlers)
        log.setLevel(level)
        log.addHandler(h)
        try:
            yield log, f
        finally:
            log.handlers = old_handlers
            log.setLevel(old_level)


# Generated at 2022-06-26 02:29:24.016714
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.DEBUG) == False
    assert logger.isEnabledFor(logging.DEBUG) == True



# Generated at 2022-06-26 02:29:33.913337
# Unit test for function logger_level
def test_logger_level():
    import contextlib
    import logging

    class Mock(object):
        pass

    log = Mock()

    log.level = 'orig'

    with contextlib.ExitStack() as stack:
        logger_level = stack.enter_context(
            logging.patch.object(logging, 'logger_level')
        )

        try:
            with logger_level(log, 'target'):
                pass
        except BaseException:
            raise AssertionError

        try:
            logger_level(log, 'target')
        except BaseException:
            raise AssertionError

        try:
            logger_level(log, 'target')
        except BaseException:
            raise AssertionError


# Generated at 2022-06-26 02:29:41.361451
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager

    @contextmanager
    def logger_level(logger, level):
        # Set logger level to ``level`` within a context block. Don't use this
        # except for debugging please, it's gross.
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    def test_inner():
        logger_level(logging.getLogger(__name__), logging.WARNING)
        logging.getLogger(__name__).error("This is an ERROR log")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:29:52.163843
# Unit test for function logger_level
def test_logger_level():
    # Create a logger
    logger = logging.getLogger(__name__)

    # Set the level of the logger to INFO
    logger.setLevel(logging.INFO)

    # Create a file handler
    handler = logging.FileHandler('file.log')

    # Create a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # Add formatter to handler
    handler.setFormatter(formatter)

    # Add handler to the logger
    logger.addHandler(handler)

    with logger_level(logger, logging.WARN):
        logger.info('Info message')
        logger.warn('Warn message')

    logger.info('Info message')
    # logger.warn('Warn message')

# Generated at 2022-06-26 02:30:03.227768
# Unit test for function logger_level
def test_logger_level():
    """Test: Everything except the last two lines in this function should run with no errors."""

    # generate a logger object
    test_logger = log = get_logger()

    # use the logger object with a doctest.
    '%s' % test_logger

    # Test the logger_level contextmanager
    with logger_level(test_logger, logging.DEBUG) as my_level:
        assert my_level == logging.DEBUG

        # Test repr for logger_level
        repr(my_level)

        # Test str for logger_level
        str(my_level)

    # Test get_config() with a string
    get_config(default='1')

    # Test get_config() with a dict
    get_config(default={"test": "1"})

    # Test get_config() with an int
   

# Generated at 2022-06-26 02:30:07.757964
# Unit test for function logger_level
def test_logger_level():
    # check that the logger.level was properly set
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger_level.func_closure[0].cell_contents == logging.INFO

    # check that the logger.level was properly reset
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR

    # now that the context has exited, the original level should be back
    assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:30:10.898416
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    with logger_level(var_0, logging.CRITICAL):
        var_0.debug('Won\'t print')
        var_0.info('Will print')

    py_info_0 = _PyInfo()



# Generated at 2022-06-26 02:30:25.889300
# Unit test for function get_config
def test_get_config():
    # type: () -> None
    """
    >>> config = get_config('{"version": 1, "disable_existing_loggers": False}')
    >>> config == {"version": 1, "disable_existing_loggers": False}
    True

    >>> config = get_config('version: 1\\ndisable_existing_loggers: false')
    >>> config == {"version": 1, "disable_existing_loggers": False}
    True
    """
    pass



# Generated at 2022-06-26 02:30:27.405499
# Unit test for function configure
def test_configure():

    # 1
    log_info_1 = get_logger()
    configure()
    log_info_1.info('test')



# Generated at 2022-06-26 02:30:32.138637
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    cur_level = logger.getEffectiveLevel()
    with logger_level(logger, cur_level + 1):
        assert logger.level is cur_level + 1
        pass

if __name__ == '__main__':
    print(test_case_0())
    test_logger_level()

# Generated at 2022-06-26 02:30:41.904448
# Unit test for function logger_level

# Generated at 2022-06-26 02:30:44.334491
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, "INFO"):
        log.info("HELLO")
        log.error("WORLD")


# Generated at 2022-06-26 02:30:54.390427
# Unit test for function logger_level
def test_logger_level():
    """
    Tests for function logger_level
    """
    # test_case_0
    var_0 = get_logger('test_0')
    var_1 = logger_level(var_0, logging.INFO)
    assert var_0.getEffectiveLevel() == 20
    assert var_0.level == 20
    with var_1:
        var_0.critical('If you see this, something is wrong')
    assert var_0.getEffectiveLevel() == 20
    assert var_0.level == 20
    with var_1:
        var_0.info('If you see this, something is right')
    assert var_0.getEffectiveLevel() == 20
    assert var_0.level == 20
    # test_case_1
    var_0 = get_logger('test_1')
    var_1

# Generated at 2022-06-26 02:31:06.095988
# Unit test for function get_config
def test_get_config():
    print('start of test_get_config')
    config = get_config(default={'level': 1})
    if config['level'] == 1:
        print("test 1 passed.\n")
    else:
        print("test 1 failed.\n")

    config = get_config(env_var='LOGGING', default={'level': 1})
    if config['level'] == 1:
        print("test 2 passed.\n")
    else:
        print("test 2 failed.\n")

    config = get_config(env_var='any', default={'level': 1})
    if config['level'] == 1:
        print("test 3 passed.\n")
    else:
        print("test 3 failed.\n")


# Generated at 2022-06-26 02:31:10.873844
# Unit test for function logger_level
def test_logger_level():
    # Initialize logger
    logger_0 = get_logger()
    # Set level to DEBUG
    with logger_level(logger_0, logging.DEBUG):
        # Log message
        logger_0.debug('This is a debug message')
    # Level set to NOTSET
    logger_0.debug('This is a debug message')


# Generated at 2022-06-26 02:31:21.244698
# Unit test for function logger_level
def test_logger_level():
    # make sure we have an unconfigured logger
    logging.getLogger().handlers = []
    testLogger = getLogger('test_logger_level')
    testLogger.debug('test message')
    # make sure the message was not logged
    assert len(testLogger.handlers[0].buffer) == 0

    with logger_level(testLogger, logging.DEBUG):
        testLogger.debug('test message')
        assert len(testLogger.handlers[0].buffer) == 1

    testLogger.debug('test message')
    assert len(testLogger.handlers[0].buffer) == 1

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:31:28.342910
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.INFO):
        pass

    with logger_level(get_logger(), logging.DEBUG):
        pass



# Generated at 2022-06-26 02:31:44.203538
# Unit test for function logger_level
def test_logger_level():
    import sys, os
    import time
    import unittest
    from copy import deepcopy
    from logging import DEBUG, ERROR, INFO, WARNING
    from functools import partial
    from io import StringIO
    from contextlib import contextmanager

    def collect(log, s):
        log.setLevel(DEBUG)
        for i in range(s):
            log.debug(i)

    @contextmanager
    def check(log, level, expected):
        # Need to make a copy of the list or else the function
        # closure will hold on to the values.
        log.setLevel(level)
        actual = []
        capture = partial(actual.append, level)
        log.debug = capture
        log.info = capture
        log.warning = capture
        log.error = capture
        log.critical = capture

# Generated at 2022-06-26 02:31:52.617770
# Unit test for function get_config
def test_get_config():
    import tempfile
    import six
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-26 02:31:59.125686
# Unit test for function logger_level
def test_logger_level():
    total = 0
    logger = logging.getLogger('test')
    logger.info("test")
    
    with logger_level(logger, logging.ERROR):
        total += 1
        logger.info("this will be skipped")
    with logger_level(logger, logging.INFO):
        total += 1
        logger.info("this will log")
    assert total == 2


if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-26 02:32:07.626246
# Unit test for function get_config

# Generated at 2022-06-26 02:32:16.825403
# Unit test for function logger_level
def test_logger_level():
    """Test function logger_level"""
    # Capture stdout, stderr and restore on exit
    # TODO: Revert to capturer.stdout and capturer.stderr???
    sys.stdout = stdout_capturer = cStringIO.StringIO()
    sys.stderr = stderr_capturer = cStringIO.StringIO()
    try:
        var_0 = get_logger()
        py_info_0 = _PyInfo()
        try:
            with logger_level(var_0, logging.DEBUG):
                var_0.debug("DEBUG")
                var_0.info("INFO")
            var_0.debug("DEBUG")
            var_0.info("INFO")
        except Exception as exc:
            print(exc)
    finally:
        sys.stdout = sys.__

# Generated at 2022-06-26 02:32:26.477617
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger('test_0')
    var_1 = get_logger('test_1')

    var_0.setLevel(logging.DEBUG)
    var_1.setLevel(logging.INFO)

    var_0.debug('test 0 debug')
    var_0.info('test 0 info')
    var_1.debug('test 1 debug')
    var_1.info('test 1 info')

    with var_1.level(logging.DEBUG):
        var_0.debug('test 0 debug')
        var_0.info('test 0 info')
        var_1.debug('test 1 debug')
        var_1.info('test 1 info')



# Generated at 2022-06-26 02:32:33.635034
# Unit test for function logger_level
def test_logger_level():
    '''
    Test logger_level.

    >>> logger = getLogger()
    >>> logger.setLevel(logging.INFO)
    >>> with logger_level(logger, logging.DEBUG):
    ...   logger.debug("Hi")
    ...
    >>> logger.isEnabledFor(logging.DEBUG)
    True
    >>> logger.isEnabledFor(logging.INFO)
    True
    >>> with logger_level(logger, logging.DEBUG):
    ...   logger.isEnabledFor(logging.INFO)
    ...   logger.isEnabledFor(logging.DEBUG)
    ...
    >>> logger.isEnabledFor(logging.INFO)
    True
    >>> logger.isEnabledFor(logging.DEBUG)
    False
    '''



# Generated at 2022-06-26 02:32:40.364750
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('allura')
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET
    with pytest.raises(ValueError):
        with logger_level(logger, 0):
            pass


# Generated at 2022-06-26 02:32:50.815517
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    from tempfile import NamedTemporaryFile
    from colorlog import ColorizingStreamHandler

    import logging
    import os

    import pytest

    __tracebackhide__ = True  # noqa

    @contextmanager
    def logfile(name='colorlog.log', level=logging.DEBUG):
        f = NamedTemporaryFile(
            prefix=name,
            suffix='.log',
            delete=False,
        )
        f.close()
        logger_ = logging.getLogger(name)
        handler = ColorizingStreamHandler()
        handler.setFormatter(
            logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        )
        logger_.addHandler(handler)
        logger_.setLevel(level)


# Generated at 2022-06-26 02:32:53.874820
# Unit test for function logger_level
def test_logger_level():
    py_info_0 = _PyInfo()
    var_0 = get_logger()
    var_1 = var_0.level
    with logger_level(var_0, logging.WARN) as var_2:
        var_3 = var_0.level
        var_2.__exit__()



# Generated at 2022-06-26 02:33:24.685537
# Unit test for function logger_level
def test_logger_level():
    def test_case_0():
        import io
        import sys
        import logging


        def configure():
            # Turn off all logging
            logging.config.dictConfig(dict(disable_existing_loggers=True))


        configure()


        in_out_0 = io.StringIO()
        out_0 = sys.stderr
        sys.stderr = in_out_0

        try:
            get_logger().info("hello")
        finally:
            sys.stderr = out_0

        get_logger().info("hello")

        from .python_snippets import describe_variable
        var_0 = describe_variable(in_out_0.getvalue())


    var_0 = test_case_0()


# Generated at 2022-06-26 02:33:32.380693
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    # log level is DEBUG
    assert(logger.level == 10)
    # set logger level to WARN
    with logger_level(logger, 30):
        assert(logger.level == 30)
    # log level is DEBUG again
    assert(logger.level == 10)
    # set logger level to NOTSET
    with logger_level(logger, 0):
        assert(logger.level == 0)
    # log level is DEBUG again
    assert(logger.level == 10)


if __name__ == '__main__':
    import pytest

    pytest.main(['-vv', '-s', __file__])

# Generated at 2022-06-26 02:33:33.838022
# Unit test for function logger_level
def test_logger_level():
    pass



# Generated at 2022-06-26 02:33:37.142887
# Unit test for function configure
def test_configure():
    py_info_0 = _PyInfo()
    routes_0 = logging.getLogger('routes')


# Generated at 2022-06-26 02:33:50.670484
# Unit test for function logger_level
def test_logger_level():
    test_0 = logger_level
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test_0, "test0"
    assert test

# Generated at 2022-06-26 02:33:57.056013
# Unit test for function logger_level
def test_logger_level():
    cli_logger = get_logger('cli')
    cli_logger.addHandler(logging.NullHandler())
    with logger_level(cli_logger, logging.CRITICAL) as _:
        pass


# Generated at 2022-06-26 02:34:06.645302
# Unit test for function logger_level
def test_logger_level():

    import logging
    import sys
    import colorlog
    import logging_helpers
    import pytest

    def test_case_0():
        py_info_0 = _PyInfo()
        var_0 = py_info_0.PY2
        var_1 = py_info_0.PY3
        var_2 = py_info_0.string_types
        var_3 = py_info_0.text_type
        var_4 = py_info_0.binary_type
        var_5 = _namespace_from_calling_context()
        var_6 = DEFAULT_CONFIG
        var_7 = configure(var_6)
        var_8 = get_config(var_6)
        var_9 = _CONFIGURED

# Generated at 2022-06-26 02:34:11.582123
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.WARN):
        log.info('should not show')
        log.warn('should show')
    log.info('should show again')
    log.warn('should show again')



# Generated at 2022-06-26 02:34:19.815906
# Unit test for function logger_level
def test_logger_level():
    import pytest

    from lib.logging import logger_level

    # Test that context manager can be wrapped in a function call
    def test_func():
        import logging

        # Setup
        logging.basicConfig()
        log = logging.getLogger(__name__)

        # Test
        with logger_level(log, logging.WARNING):
            log.debug("This will not be displayed")
            assert log.getEffectiveLevel() == logging.WARNING

        # Teardown
    test_func()

    # Test that level is set back to original value
    def test_func():
        import logging

        # Setup
        logging.basicConfig()
        log = logging.getLogger(__name__)

        # Test
        with logger_level(log, logging.WARNING):
            pass

            # Teardown
    test_func()

# Generated at 2022-06-26 02:34:22.034168
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET



# Generated at 2022-06-26 02:34:43.974830
# Unit test for function logger_level
def test_logger_level():
    pass

# Generated at 2022-06-26 02:34:46.652528
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    initial = logger.level
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == initial


# Generated at 2022-06-26 02:34:50.450399
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug('should appear')

    log.info('should not appear')


# Generated at 2022-06-26 02:34:55.096888
# Unit test for function logger_level
def test_logger_level():
    import logging
    from contextlib import contextmanager
    var_0 = get_logger()
    py_info_0 = _PyInfo()
    var_0.debug('test')
    with logger_level(var_0, logging.DEBUG):
        var_0.debug('test')
    with logger_level(var_0, logging.WARN):
        var_0.debug('test')



# Generated at 2022-06-26 02:35:00.636764
# Unit test for function logger_level
def test_logger_level():
    class Logger_0(object):
        def __init__(self):
            self.level = logging.WARNING
        def setLevel(self, level):
            self.level = level
    logger_0 = Logger_0()
    with logger_level(logger_0, logging.ERROR):
        assert logger_0.level == logging.ERROR
    assert logger_0.level == logging.WARNING


if __name__ == '__main__':
    print('Testing')
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:35:05.228219
# Unit test for function logger_level
def test_logger_level():
    class MockLogClass(object):
        def __init__(self):
            self.level = logging.INFO
    var_0 = MockLogClass()
    logger_level(var_0, logging.DEBUG)
    logger_level(var_0, logging.DEBUG)


# Generated at 2022-06-26 02:35:12.255457
# Unit test for function logger_level
def test_logger_level():
    logger_0 = logging.getLogger('test_logger_level')
    logger_level_0 = logger_level(logger_0, logging.WARN)
    with logger_level_0:
        var_0 = logger_0.isEnabledFor(logging.WARN)
    var_1 = logger_0.isEnabledFor(logging.WARN)
    assert var_0 == True
    assert var_1 == False


# Generated at 2022-06-26 02:35:16.697180
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    LOG_LEVEL = 'NOTSET'
    assert logger.level == LOG_LEVEL
    with logger_level(logger, 'CRITICAL'):
        assert logger.level == 'CRITICAL'
    assert logger.level == LOG_LEVEL


# Generated at 2022-06-26 02:35:19.487121
# Unit test for function logger_level
def test_logger_level():
    # Initialize test
    logger = None
    level = None
    logger_level_0 = logger_level
    # Execute function
    with logger_level_0(logger, level):
        pass
    # Check for expected result



# Generated at 2022-06-26 02:35:24.860192
# Unit test for function logger_level
def test_logger_level():
    import logging

    LOG = logging.getLogger(__name__)

    var_0 = _PyInfo()
    if var_0.PY3:
        with logger_level(LOG, logging.DEBUG):
            LOG.debug("HELLO WORLD")
    elif var_0.PY2:
        py_info_0 = _PyInfo()
        # this is a 2.7-specific feature.
        # with logger_level(LOG, logging.DEBUG):
        #     LOG.debug("HELLO WORLD")
        assert LOG.level == logging.DEBUG
        LOG.debug("HELLO WORLD")
    else:
        pass