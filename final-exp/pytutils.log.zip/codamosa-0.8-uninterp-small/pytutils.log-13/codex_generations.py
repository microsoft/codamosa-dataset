

# Generated at 2022-06-26 02:25:59.048974
# Unit test for function logger_level
def test_logger_level():
    raise NotImplementedError


# Generated at 2022-06-26 02:26:05.765093
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger=logging.getLogger(__name__)
    with logger_level(logger,100):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")
        logger.critical("critical")


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    import unittest
    unittest.main()

# Generated at 2022-06-26 02:26:17.794321
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    from io import StringIO
    import logging
    try:
        from unittest import mock
    except ImportError:
        import mock

    output = StringIO()

    @contextmanager
    def logger_level(logger, level):
        """Set logger level to `level` within a context block. Don't use this except for debugging please, it's gross."""
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    class TestClass(object):
        def setup(self):
            self.level = logging.getLogger().level

        def teardown(self):
            logging.getLogger().level = self.level
            self.level = None


# Generated at 2022-06-26 02:26:19.615164
# Unit test for function logger_level
def test_logger_level():
    logger_level(logging.getLogger('logger_level'), logging.DEBUG)



# Generated at 2022-06-26 02:26:23.451029
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger.level = logging.WARN
    assert logger.level == logging.WARN

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.WARN



# Generated at 2022-06-26 02:26:29.378872
# Unit test for function configure
def test_configure():
    import logging.config
    import os
    import dotenv
    import sys
    import shutil
    import json

    tmp = '.env.tmp'
    if os.path.exists(tmp):
        shutil.rmtree(tmp)

    dotenv.load_dotenv('.env', dotenv_path=tmp)
    dotenv.set_key(tmp, 'LOGGING_TEST_ENV_VAR', 'test')


# Generated at 2022-06-26 02:26:33.018021
# Unit test for function logger_level
def test_logger_level():
    var = get_logger()

    with logger_level(var, logging.ERROR):
        var.debug("DEBUG")
        var.info("INFO")
        var.warning("WARNING")
        assert var.level == logging.ERROR


# Generated at 2022-06-26 02:26:36.061820
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    level = logger.level
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == level



# Generated at 2022-06-26 02:26:48.099045
# Unit test for function logger_level
def test_logger_level():
    '''Test logger_level'''

    global var_0

    # Stub out get_logger
    get_logger_orig = get_logger
    def get_logger(name=None):
        return var_0

    # Stub out logger.level
    logger_level_orig = logger_level
    def logger_level(logger, level):
        pass

    try:
        with logger_level(var_0, DEBUG):
            test_case_0()

        logger_level.assert_called_once()
        args = logger_level.call_args[0]

        assert len(args) == 2
        assert args[0] == var_0
        assert args[1] == DEBUG
    finally:
        # Restore stubs
        get_logger = get_logger_orig
        logger_level = logger

# Generated at 2022-06-26 02:26:55.147776
# Unit test for function logger_level
def test_logger_level():
    # Create logger with debug level
    var_1 = logging.getLogger(__name__)
    var_1.setLevel(logging.DEBUG)

    # Assert that the logger is at debug level
    assert var_1.getEffectiveLevel() == logging.DEBUG

    # Change the logger level to info within the context block
    with logger_level(var_1, logging.INFO):
        # Assert that the logger is at info level within the context
        assert var_1.getEffectiveLevel() == logging.INFO

    # Assert that the logger is still at debug level after the context block
    assert var_1.getEffectiveLevel() == logging.DEBUG

# Generated at 2022-06-26 02:27:03.205878
# Unit test for function logger_level
def test_logger_level():
    initial_level = logging.getLogger().getEffectiveLevel()
    with logger_level(logging.getLogger(), logging.ERROR):
        assert logging.getLogger().getEffectiveLevel() == logging.ERROR
    assert logging.getLogger().getEffectiveLevel() == initial_level


# Generated at 2022-06-26 02:27:08.477085
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('logging_test')
    logger.setLevel(logging.INFO)
    assert logger.level == logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO

if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    test_logger_level()

# Generated at 2022-06-26 02:27:14.894448
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug("This message should be printed")
        logger.info("This message should not be printed")
    logger.info("This message should be printed")
    logger.debug("This message should not be printed")


if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:27:21.000393
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    h = logging.StreamHandler()
    h.setLevel(logging.DEBUG)
    logger.addHandler(h)
    with logger_level(logger, logging.DEBUG):
        logger.debug("this is debug")
        logger.info("this is info")


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:27:26.614350
# Unit test for function logger_level
def test_logger_level():
    logger_level1 = get_logger(__name__)
    with logger_level(logger_level1, logging.INFO):
        logger_level1.error("this will not show up")
        logger_level1.info("this should show up")
    logger_level1.setLevel(logging.DEBUG)
    logger_level1.debug("this will show up")
    logger_level1.info("this will show up")
    logger_level1.error("this will show up")
    print("logger_level unit test is successful")



# Generated at 2022-06-26 02:27:36.783616
# Unit test for function get_config
def test_get_config():
    assert isinstance(get_config(None, None, None), dict), 'Failed to parse config'
    assert get_config({}, None, None)['version'] == 1, 'Failed to parse config'
    assert isinstance(get_config('{}', None, None), dict), 'Failed to parse config'
    assert get_config('{}', None, None)['version'] == 1, 'Failed to parse config'
    assert isinstance(get_config('version: 1', None, None), dict), 'Failed to parse config'
    assert get_config('version: 1', None, None)['version'] == 1, 'Failed to parse config'
    assert isinstance(get_config(None, None, DEFAULT_CONFIG), dict), 'Failed to parse config'

# Generated at 2022-06-26 02:27:44.745657
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger('logger_level')
    logger.debug('test_logger_level 1')
    with logger_level(logger, logging.INFO):
        logger.debug('test_logger_level 2')
    with logger_level(logger, logging.DEBUG):
        logger.debug('test_logger_level 3')
    with logger_level(logger, logging.ERROR):
        logger.debug('test_logger_level 4')


if __name__ == '__main__':
    configure()
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:27:49.932612
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), 'WARNING'):
        log = getLogger()
        log.warning('test logger_level')
        log.info('Warning level info')

    log.info('Final test')  # must not show

    with logger_level(getLogger(), 'INFO'):
        log.info('Final test')    # must show

# Generated at 2022-06-26 02:28:00.130447
# Unit test for function logger_level
def test_logger_level():
    import StringIO
    import logging
    test_logger = logging.getLogger('test_logger')
    logging.basicConfig()
    test_logger.setLevel(logging.DEBUG)

    # make a fake output string
    output = StringIO.StringIO()

    # make a stream handler for it
    hdlr = logging.StreamHandler(output)

    # make it the only handler in test_logger
    test_logger.handlers = [hdlr]

    # create an error message to test with
    err_msg = 'This is a warning'
    # print it out to make sure we have the right thing

# Generated at 2022-06-26 02:28:10.324150
# Unit test for function logger_level
def test_logger_level():
    import time
    import threading
    from queue import Queue

    class LogQueueHandler(logging.Handler):

        def __init__(self, queue):
            super().__init__(self)
            self.queue = queue

        def emit(self, record):
            self.queue.put(record)

    log = logging.getLogger('my_logger')
    log.setLevel(logging.DEBUG)
    queue = Queue()
    handler = LogQueueHandler(queue)
    log.addHandler(handler)

    with logger_level(log, logging.DEBUG):
        log.debug('debug message1')
        log.info('info message1')
        log.warning('warning message1')
        log.error('error message1')
        log.critical('critical message1')


# Generated at 2022-06-26 02:28:20.836503
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        logger.info('info')
        logger.warning('warning')
        logger.error('error')
        assert logger.getEffectiveLevel() == logging.CRITICAL
    logger.error('error out of context manager')
    assert logger.getEffectiveLevel() == logging.DEBUG


# Generated at 2022-06-26 02:28:24.144405
# Unit test for function logger_level
def test_logger_level():
    import logging
    from contextlib import contextmanager
    from gg.logging import logger_level
    logger = logging.getLogger('test_name')
    # test normal case
    initial = logger.level
    logger.level = 10
    with logger_level(logger, 20):
        assert logger.level == 20
    assert logger.level == 10
    logger.level = initial


# Generated at 2022-06-26 02:28:31.401793
# Unit test for function configure
def test_configure():
    print("In function %s" % inspect.stack()[0][3])

# Generated at 2022-06-26 02:28:37.712888
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logtool
    logger = logtool.get_logger("test_logger_level")
    with logger_level(logger, logging.ERROR):
        logger.error("TEST")
    logger.debug("TEST")
    logger.info("TEST")
    logger.warning("TEST")
    logger.error("TEST")
    logger.critical("TEST")

if __name__ == "__main__":
    configure()
    test_logger_level()

# Generated at 2022-06-26 02:28:42.616243
# Unit test for function logger_level
def test_logger_level():
    test_logger = getLogger('mock_logger')
    test_logger.setLevel(logging.DEBUG)
    with logger_level(test_logger, logging.DEBUG):
        assert test_logger.isEnabledFor(logging.DEBUG)
    assert not test_logger.isEnabledFor(logging.DEBUG)

# Generated at 2022-06-26 02:28:46.136350
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    # Set logger level to DEBUG
    with logger_level(var_0, 10):
        assert var_0.level == 10
    assert var_0.level == 20

# Generated at 2022-06-26 02:28:53.664747
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.debug("test_logger_level_before")
    with logger_level(logger, logging.ERROR):
        logger.debug("test_logger_level_during")
    logger.debug("test_logger_level_after")

if __name__ == '__main__':
    configure()
    logger = get_logger()
    logger.debug("test_case_0:")
    test_case_0()
    
    logger.debug("test_logger_level:")
    test_logger_level()

# Generated at 2022-06-26 02:29:02.347555
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger("Logger_Level")
    log.debug("debug")
    log.info("info")
    log.error("error")
    with logger_level(log, logging.DEBUG):
        log.debug("debug")
        log.info("info")
        log.error("error")
    log.debug("debug")
    log.info("info")
    log.error("error")


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:29:04.288265
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
    assert logger.level == logging.DEBUG

# Generated at 2022-06-26 02:29:08.759117
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger')
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
    assert logger.level == logging.DEBUG


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:29:18.663798
# Unit test for function configure
def test_configure():
    configure()
    var_0 = test_case_0()



# Generated at 2022-06-26 02:29:25.078383
# Unit test for function get_config
def test_get_config():
    # Test case 0
    result = get_config()

    # Test case 1
    result = get_config(default=DEFAULT_CONFIG)

    # Test case 2
    result = get_config(default=None)

    # Test case 3
    result = get_config(default=DEFAULT_CONFIG)

    # Test case 4
    result = get_config(default=DEFAULT_CONFIG)

    # Test case 5
    result = get_config(default=DEFAULT_CONFIG)



# Generated at 2022-06-26 02:29:34.976616
# Unit test for function configure
def test_configure():
    import json


# Generated at 2022-06-26 02:29:43.428865
# Unit test for function logger_level
def test_logger_level():
    import logging
    # This is used to remove log file if it already exists
    try:
        os.remove("test.log")
    except OSError:
        pass
    log = logging.getLogger(__name__)
    log.addHandler(logging.FileHandler("test.log"))
    log.setLevel(logging.DEBUG)
    # Ensure that there is no log file created
    assert os.stat("test.log").st_size == 0
    with logger_level(log, logging.INFO):
        log.debug("This should not be logged")
        log.info("This should be logged")
        log.error("This should be logged")
    log.debug("This should not be logged")
    # Ensure that log file is created and has two lines

# Generated at 2022-06-26 02:29:48.297172
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logger.level
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert level == logger.level


if __name__ == '__main__':
    logging.basicConfig()
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:29:55.173116
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger('testing_logger_level'), logging.DEBUG):
        with logger_level(get_logger('testing_logger_level.nested'), logging.INFO):
            get_logger('testing_logger_level').info('inner')
    get_logger('testing_logger_level').info('outer')


if __name__ == '__main__':
    configure()
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:29:59.510856
# Unit test for function logger_level
def test_logger_level():
    def _fixture():
        log = getLogger("logger_level")
        log.setLevel(100)
        with logger_level(log, logging.DEBUG):
            assert log.getEffectiveLevel() == logging.DEBUG, \
                "logger level is not set to DEBUG when expected"
        assert log.getEffectiveLevel() == 100, \
            "logger level is not set back to initial level"

    _fixture()

if __name__ == '__main__':
    # test_logger_level()
    import doctest
    doctest.testmod()

    logging.basicConfig()

    test_case_0()

# Generated at 2022-06-26 02:30:03.673765
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger('asdf'), logging.DEBUG):
        assert logging.getLogger('asdf').isEnabledFor(logging.DEBUG)
    assert not logging.getLogger('asdf').isEnabledFor(logging.DEBUG)



# Generated at 2022-06-26 02:30:05.826005
# Unit test for function get_config
def test_get_config():
    assert get_config('{"version": 1}') == {"version": 1}
    assert get_config('{"version": 2}') == {"version": 2}

# Generated at 2022-06-26 02:30:11.763436
# Unit test for function logger_level
def test_logger_level():
    import contextlib
    import logging
    log = logging.getLogger()
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    # make sure that the level is reset even on error
    try:
        with logger_level(log, logging.DEBUG):
            assert log.level == logging.DEBUG
            raise Exception
    except:
        pass
    assert log.level == logging.INFO


# Generated at 2022-06-26 02:30:26.010964
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = get_logger()
    >>> with logger_level(logger, logging.DEBUG):
    ...     assert logger.level == logging.DEBUG
    ...
    >>> assert logger.level == logging.NOTSET

    >>> with logger_level(logger, logging.CRITICAL):
    ...     assert logger.level == logging.CRITICAL
    ...
    >>> assert logger.level == logging.NOTSET
    """
    pass



# Generated at 2022-06-26 02:30:27.831364
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(__name__), logging.DEBUG):
        getLogger(__name__).debug('this is a test')

# Generated at 2022-06-26 02:30:31.872288
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        logger.info('info')
        logger.warn('warn')
        logger.error('error')
        logger.critical('critical')



# Generated at 2022-06-26 02:30:33.736439
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger('logger_level'), logging.ERROR):
        test_case_0()

# Generated at 2022-06-26 02:30:36.470749
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, 20):
        assert(logger.level == 20)
    assert(logger.level == 10)


# Generated at 2022-06-26 02:30:46.127636
# Unit test for function configure
def test_configure():
    import json
    import os
    import tempfile
    import shutil
    from logging import getLogger


# Generated at 2022-06-26 02:30:49.286296
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    with logger_level(var_0, 5):
        var_3 = var_0.info('test_logger_level')


# Generated at 2022-06-26 02:30:53.963204
# Unit test for function logger_level
def test_logger_level():
    LOG = get_logger()
    with logger_level(LOG, logging.INFO):
        LOG.info('info')
        LOG.debug('debug')
    LOG.info('info')
    LOG.debug('debug')


if __name__ == "__main__":
    import doctest

    doctest.testmod()

    test_logger_level()

# Generated at 2022-06-26 02:30:56.713821
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger()
    with logger_level(test_logger,40):
        assert test_logger.level != 10
    assert test_logger.level == 10


# Generated at 2022-06-26 02:30:59.747592
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logging.DEBUG

    with logger_level(logger, level):
        assert logger.level == level

    assert initial != logger.level


if __name__ == '__main__':
    configure()
    logger = get_logger()
    print(logger)
    logger.debug('debug')
    logger.info('info')
    logger.warn('warn')
    logger.error('error')
    logger.critical('critical')

# Generated at 2022-06-26 02:31:11.721362
# Unit test for function logger_level
def test_logger_level():
    log = getLogger(__name__)
    with logger_level(log, logging.DEBUG):
        log.info("This will be logged")

if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:31:15.206628
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(name="test")
    logger.setLevel(logging.DEBUG)
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:31:19.590466
# Unit test for function logger_level
def test_logger_level():
    class Test(object):

        def test(self):
            log = get_logger()
            with logger_level(log, logging.ERROR):
                log.info('running err')
            log.info('running info')

    Test().test()



# Generated at 2022-06-26 02:31:24.440325
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger("test_logger_level")
    var_1.setLevel(logging.INFO)
    with logger_level(var_1, logging.DEBUG):
        var_1.debug("Testing with test_logger_level")


if __name__ == "__main__":
    configure()
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:31:29.900015
# Unit test for function logger_level
def test_logger_level():
    print('Testing logger_level')
    import unittest
    import logging

    class Test(unittest.TestCase):
        def test(self):
            logger = logging.getLogger()
            with logger_level(logger, logging.DEBUG):
                print(logger.level)
            print(logger.level)

    unittest.main()


# Generated at 2022-06-26 02:31:33.554873
# Unit test for function logger_level
def test_logger_level():
    var_0 = 1
    get_logger().info(var_0)
    with logger_level(get_logger(), 1):
        get_logger().info(var_0)



# Generated at 2022-06-26 02:31:35.260779
# Unit test for function get_config
def test_get_config():
    result = get_config('log.yaml')
    assert result['version'] == 1


# Generated at 2022-06-26 02:31:37.864665
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logging.DEBUG
    with logger_level(logger, level):
        assert logger.level == level
    assert logger.level != level



# Generated at 2022-06-26 02:31:44.456425
# Unit test for function get_config
def test_get_config():
    logger = get_logger(__name__)

    # Test empty config
    config = get_config(None, None, DEFAULT_CONFIG)
    logger.info("Configuring Logging with " + repr(config))
    configure(config=config)
    test_case_0()

    # Test config with environment variable
    os.environ['LOGGING'] = json.dumps(DEFAULT_CONFIG)
    config = get_config(None, 'LOGGING', None)
    logger.info("Configuring Logging with " + repr(config))
    configure(config=config)
    test_case_0()

    # Test config with json string
    config = get_config(json.dumps(DEFAULT_CONFIG), None, None)
    logger.info("Configuring Logging with " + repr(config))


# Generated at 2022-06-26 02:31:48.950213
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    initial = logger.level
    assert logger.level == 20
    with logger_level(logger, 10):
        assert logger.level == 10
    assert logger.level == initial
    assert logger.level == 20


# Generated at 2022-06-26 02:32:02.231280
# Unit test for function get_config
def test_get_config():
    default_test = get_config(None, None, DEFAULT_CONFIG)
    json_test = get_config('{"formatters": "foo"}', None, None)
    assert(default_test.get('formatters') == DEFAULT_CONFIG.get('formatters'))
    assert(json_test.get('formatters') == 'foo')

# Generated at 2022-06-26 02:32:07.686956
# Unit test for function get_config
def test_get_config():
    assert get_config() == DEFAULT_CONFIG
    assert get_config(None) == DEFAULT_CONFIG
    assert get_config(None, env_var=None) == DEFAULT_CONFIG

    assert get_config(None, env_var='TEST', default=None) == None

    TEST = "logging.basicConfig(level=logging.DEBUG)"
    assert get_config(None, env_var='TEST', default=None) == TEST
    assert get_config(TEST, env_var=None, default=None) == TEST

    TEST = "logging.basicConfig(level=logging.DEBUG)"
    assert get_config(TEST, env_var=None, default=None) == TEST
    assert get_config(TEST, env_var='TEST', default=None) == TEST
    assert get

# Generated at 2022-06-26 02:32:10.348203
# Unit test for function get_config
def test_get_config():
    assert get_config(config="""{"version": 1}""") == {"version": 1}
    assert get_config(config="""
version: 1
""") == {"version": 1}



# Generated at 2022-06-26 02:32:10.884254
# Unit test for function logger_level
def test_logger_level():
    assert(True)

# Generated at 2022-06-26 02:32:13.677451
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger()
    var_2 = logging.INFO
    with logger_level(var_1, var_2):
        var_1.debug('test')


# Generated at 2022-06-26 02:32:20.874938
# Unit test for function logger_level
def test_logger_level():
    import sys
    import tempfile
    import logging
    import logging.config

    logger = logging.getLogger()
    logger.handlers = [logging.StreamHandler(sys.stdout)]


    with logger_level(logger, logging.DEBUG):
        logger.debug('debug')
        with tempfile.NamedTemporaryFile() as OUTPUT:
            with logger_level(logger, logging.ERROR):
                logger.debug('debug')
                logger.error('error')


# Generated at 2022-06-26 02:32:22.857138
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = 10
    with logger_level(logger, level):
        assert logger.level == level



# Generated at 2022-06-26 02:32:28.619933
# Unit test for function logger_level
def test_logger_level():
    import colorlog
    import logging
    import sys

    # Basic test
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        with logger_level(logger, logging.INFO):
            logger.debug('Nested')
            logger.critical('Nested')
        logger.debug('End of nested')
        logger.warning('End of nested')


# Generated at 2022-06-26 02:32:30.114167
# Unit test for function get_config
def test_get_config():
    assert isinstance(
        get_config(
            '{"a": 1, "b": 2}'), dict) == True
    assert isinstance(
        get_config(
            'a: 1\\nb: 2'), dict) == True



# Generated at 2022-06-26 02:32:33.881135
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, logging.WARN):
        assert logger.level == logging.WARN

        logger.debug("Should not print")
        logger.warn("Should print")

    assert logger.level == logging.NOTSET

    logger.debug("Should print")


# Generated at 2022-06-26 02:32:53.367086
# Unit test for function logger_level
def test_logger_level():
    import tempfile as tmp
    # verify that the logger level is set correctly
    with tmp.NamedTemporaryFile("r") as fp:
        logger = logging.getLogger("test_logger_level")
        handler = logging.FileHandler(fp.name)
        formatter = logging.Formatter("%(levelname)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.propagate = False
        with logger_level(logger, logging.INFO):
            logger.debug("This should not appear")
            logger.info("This should appear")
        with logger_level(logger, logging.ERROR):
            logger.debug("This should not appear either")
        logger.removeHandler(handler)
        fp.seek(0)

# Generated at 2022-06-26 02:32:57.899602
# Unit test for function logger_level
def test_logger_level():
    import logging

    log = logging.getLogger('test')
    log.setLevel(logging.ERROR)
    log.error('Error')
    log.info('Info')

    with logger_level(log, logging.INFO):
        log.error('Error')
        log.info('Info')

    log.error('Error')
    log.info('Info')

# Generated at 2022-06-26 02:33:08.300452
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger()
    # Test try except block
    with logger_level(test_logger, logging.INFO) as context:
        # Test if statement
        if test_logger.level == logging.INFO:
            test_logger.debug('This test message should be received')
            return
        return
    with logger_level(test_logger, logging.INFO) as context:
        with logger_level(test_logger, logging.DEBUG) as context:
            # Test if statement
            if test_logger.level == logging.DEBUG:
                test_logger.info('This test message should not be received')
                return
            return
    return


# Generated at 2022-06-26 02:33:13.645793
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    var_1 = logging.DEBUG
    var_2 = logging.INFO
    var_3 = var_0.level
    var_4 = logger_level(var_0,var_1)
    var_5 = var_0.level

# Generated at 2022-06-26 02:33:14.606985
# Unit test for function get_config
def test_get_config():
    # config = get_config()
    pass



# Generated at 2022-06-26 02:33:24.553998
# Unit test for function logger_level
def test_logger_level():
    import time
    logger1 = getLogger("test_logger_level")
    logger1.debug("test debug")
    logger1.info("test info")
    with logger_level(logger1, logging.WARNING):
        logger1.debug("test debug for warning")
        logger1.info("test info for warning")
        logger1.warning("test warning for warning")
    logger1.info("test info for info")

test_case_0()


test_logger_level()



# Generated at 2022-06-26 02:33:30.417943
# Unit test for function logger_level
def test_logger_level():
    from io import StringIO
    import sys

    _log = get_logger()
    log = StringIO()
    old_stdout = sys.stdout
    sys.stdout = log
    try:
        with logger_level(_log, logging.INFO):
            _log.info('Testing logging.')

    finally:
        sys.stdout = old_stdout

    assert 'Testing logging.' in log.getvalue()



# Generated at 2022-06-26 02:33:38.989001
# Unit test for function logger_level
def test_logger_level():
    orig_logger = get_logger()
    logger = get_logger('test')
    if logger.level != logging.DEBUG:
        raise ValueError('Wrong logger level')

    with logger_level(logger, logging.ERROR):
        if logger.level != logging.ERROR:
            raise ValueError('logger level should be ERROR')

    if logger.level != logging.DEBUG:
        raise ValueError('logger level should be DEBUG')

    if orig_logger.level != logging.DEBUG:
        raise ValueError('original logger level should be DEBUG')


# Generated at 2022-06-26 02:33:45.508014
# Unit test for function logger_level
def test_logger_level():
    # Set up a logger
    test_logger = get_logger("test.logger_level")
    # Set the level to warn
    with logger_level(test_logger, logging.WARN):
        # Check if the level is the same
        if test_logger.level == logging.WARN:
            return True
        else:
            return False


# Generated at 2022-06-26 02:33:48.747561
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    with logger_level(var_0, logging.DEBUG):
        var_0.info('test')
        var_0.debug('test')



# Generated at 2022-06-26 02:34:10.884260
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    with logger_level(var_0, logging.DEBUG):
        var_0.warning('Hello')

    var_0.warning('world!')


# Generated at 2022-06-26 02:34:15.125070
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.info('test1')
    logger.setLevel(logging.INFO)
    with logger_level(logger, logging.DEBUG):
        logger.info('test2')
    logger.info('test3')

if __name__ == "__main__":
    # test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:34:19.483020
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    var_1 = var_0.info
    var_1('before')
    var_2 = logger_level(var_0, logging.WARN)
    with var_2:
        var_3 = var_0.info
        var_3('after')
    var_4 = var_0.info
    var_4('out of context')



# Generated at 2022-06-26 02:34:27.216555
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logging.DEBUG
    original_level = logger.getEffectiveLevel()
    logger.info(
        'logging level should be NOTSET before entering the contextmanager'
    )
    with logger_level(logger, level):
        logger.info('logging level set to DEBUG')
    logger.info('logging level back to {level}'.format(level=original_level))


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:34:34.540571
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()
    log = get_logger(__name__ + '.test_logger_level')
    log.critical('critical')
    log.debug('debug')

    with logger_level(log, logging.INFO):
        log.debug('debug (should be skipped)')
        log.critical('critical')
        with logger_level(log, logging.CRITICAL):
            log.debug('debug (should be skipped)')
            log.critical('critical')

    log.debug('debug')
    log.critical('critical')



# Generated at 2022-06-26 02:34:35.737348
# Unit test for function logger_level
def test_logger_level():
    logger_0 = getLogger()
    with logger_level(logger_0, logging.DEBUG):
        var_0 = logger_0


# Generated at 2022-06-26 02:34:39.266308
# Unit test for function configure
def test_configure():
    print(os.environ.get('LOGGING'))
    # configure({'a':1})
    configure()
    log = get_logger()
    log.info('test')

################################################################################
# Main program #
if __name__ == '__main__':
    test_configure()

# Generated at 2022-06-26 02:34:48.424283
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('testlogger')
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    with logger_level(logger, logging.WARNING):
        logger.info('Test info message') # Should not be displayed
        logger.warning('Test warn message') # Should be displayed
    # Test the default effect of logger_level
    logger.debug('Test debug message') # Should be displayed
    logger.info('Test info message') # Should be displayed

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:34:51.980639
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert(log.level == logging.DEBUG)
    
    with logger_level(log, 1):
        assert(log.level == 1)
    # Revert to default
    assert(log.level == logging.DEBUG)


# Generated at 2022-06-26 02:34:55.958443
# Unit test for function get_config
def test_get_config():
    var_0 = get_config(given=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    assert var_0 == DEFAULT_CONFIG

    var_0 = get_config(given=None, env_var=None, default=DEFAULT_CONFIG)
    assert var_0 == DEFAULT_CONFIG



# Generated at 2022-06-26 02:35:45.965555
# Unit test for function get_config
def test_get_config():
    """
    >>> get_config()
    >>> # More test cases
    Traceback (most recent call last):
    ...
    ValueError: Invalid logging config: None
    >>> get_config(1)
    Traceback (most recent call last):
    ...
    ValueError: Invalid logging config: 1
    >>> import yaml
    >>> test_yaml = yaml.dump(dict())
    >>> get_config(test_yaml)
    {}
    >>> import json, yaml
    >>> test_json = json.dumps(dict())
    >>> get_config(test_json)
    {}
    """
    pass



# Generated at 2022-06-26 02:35:46.781311
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-26 02:35:49.537444
# Unit test for function logger_level
def test_logger_level():
    logger_level(logger=get_logger().name, level=logging.DEBUG)
    assert get_logger().level == logging.DEBUG


# Generated at 2022-06-26 02:35:55.303094
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger(__name__)
    logger_level(var_1, logging.DEBUG)
    var_1.info("test message")
    logger_level(var_1, logging.INFO)
    var_1.info("test message")

if __name__ == "__main__":
    # logger_case_0()
    test_logger_level()