

# Generated at 2022-06-26 02:26:07.484937
# Unit test for function logger_level
def test_logger_level():
    import logging
    import tempfile
    from contextlib import contextmanager
    from .log_utils import logger_level

    if _PyInfo.PY2:
        import unittest2 as unittest
    else:
        import unittest

    class Case(unittest.TestCase):
        def setUp(self):
            self.fd, self.fn = tempfile.mkstemp()
            logging.basicConfig(filename=self.fn)

        def tearDown(self):
            os.close(self.fd)
            os.remove(self.fn)

        def test_context_manager(self):
            logger = logging.getLogger('test')

            @contextmanager
            def test_context():
                with logger_level(logger, logging.CRITICAL):
                    logger.info('foo')
                logger

# Generated at 2022-06-26 02:26:12.105545
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    level = 10
    with logger_level(logger, level):
        assert level == logger.level



# Generated at 2022-06-26 02:26:19.712316
# Unit test for function get_config
def test_get_config():

    # Test when config is None
    config = None
    env_var = 'LOGGING'
    default = DEFAULT_CONFIG

    try:
        result = get_config(config, env_var, default)
    except ValueError as e:
        assert str(e) == 'Invalid logging config: None'

    # Test when config is string
    config = ''
    env_var = 'LOGGING'
    default = DEFAULT_CONFIG

    try:
        result = get_config(config, env_var, default)
    except ValueError as e:
        assert str(e) == 'Invalid logging config: '


if __name__ == '__main__':
    test_get_config()

# Generated at 2022-06-26 02:26:28.076212
# Unit test for function logger_level
def test_logger_level():
    # Initialize loggers
    log_0 = get_logger()
    log_1 = get_logger()
    #  Display logger levels
    log_0.debug("log_0 level : %d", log_0.level)
    log_1.debug("log_1 level : %d", log_1.level)

    with logger_level(logger=log_0, level=10):
        log_0.debug("log_0 level : %d", log_0.level)
        log_0.info("log_0 level : %d", log_0.level)
        log_0.critical("log_0 level : %d", log_0.level)

    log_0.debug("log_0 level : %d", log_0.level)

# Generated at 2022-06-26 02:26:34.644925
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    var_0.setLevel(logging.DEBUG)
    with logger_level(var_0, logging.DEBUG):
        var_0.debug("Hello")
    with logger_level(var_0, logging.INFO):
        var_0.info("Hello")


if __name__ == "__main__":

    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:26:38.225952
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("Logging level is set to DEBUG")


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:26:44.399167
# Unit test for function logger_level
def test_logger_level():
    '''Test case: set log level to INFO before and after context block'''
    var_0 = getLogger('Function logger_level')
    with logger_level(var_0, logging.INFO):
        var_0.info('This message should be printed')
    var_0.debug('This message should not be printed')


# Generated at 2022-06-26 02:26:52.015303
# Unit test for function logger_level
def test_logger_level():
    import logging
    import unittest
    class test_logger_level(unittest.TestCase):
        def test_0(self):
            var_0 = get_logger()
            with logger_level(var_0, 40):
                var_0.log(40, 'TEST')
            with logger_level(var_0, 20):
                var_0.log(20, 'TEST')
                var_0.log(10, 'FAIL')

    if __name__ == '__main__':
        unittest.main()


# Generated at 2022-06-26 02:26:57.543887
# Unit test for function logger_level
def test_logger_level():
    import datetime
    import logging
    import colorlog
    import mock

    logger = get_logger()
    # logger = logging.getLogger('foo')
    # logger.addHandler(logging.StreamHandler())
    # print(logger)
    # print(logger.handlers)
    with logger_level(logger, logging.INFO):
        logger.debug("Doh! We shouldn't get this")
        logger.warn("But we should get this")
        logger.error("And this")
        logger.info("But not this")


if __name__ == '__main__':
    # do_log.test_logger_level()
    pass

# Generated at 2022-06-26 02:27:07.992392
# Unit test for function logger_level
def test_logger_level():
    import tempfile

    logpath = tempfile.mktemp()

# Generated at 2022-06-26 02:27:15.698130
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    log.setLevel(logging.INFO)
    with logger_level(log, logging.DEBUG):
        log.debug('this should show')
    log.debug('this should not show')



# Generated at 2022-06-26 02:27:20.020419
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARNING):
        logger.info("this shouldn't be shown")
    logger.info('this should be shown')


if __name__ == '__main__':
    test_logger_level()
    print('-' * 50)
    configure()
    test_case_0()

# Generated at 2022-06-26 02:27:21.817716
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger()
    assert test_logger.level == logging.DEBUG

    with logger_level(test_logger, logging.INFO) as test_logger:
        assert test_logger.level == logging.INFO

    assert test_logger.level == logging.DEBUG

# Generated at 2022-06-26 02:27:24.960298
# Unit test for function logger_level
def test_logger_level():
    logger_0 = get_logger()
    logger_0.error("test_0")
    with logger_level(logger_0, logging.DEBUG):
        logger_0.error("test_1")
    logger_0.error("test_2")


# Generated at 2022-06-26 02:27:35.250767
# Unit test for function logger_level
def test_logger_level():
    import logging
    import re
    import sys
    import tempfile

    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        name = f.name

# Generated at 2022-06-26 02:27:38.760745
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    initial = logger.level
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
    assert logger.level == initial


# Generated at 2022-06-26 02:27:42.199072
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    logger.setLevel(logging.WARNING)
    with logger_level(logger, logging.DEBUG) as _:
        assert logger.level == logging.DEBUG
    assert logger.level == logging.WARNING



# Generated at 2022-06-26 02:27:46.958767
# Unit test for function logger_level
def test_logger_level():
    import logging
    var_0 = logging.getLogger('level')
    var_1 = logging.ERROR
    with logger_level(var_0, var_1):
        var_2 = var_0.level
        assert var_2 == var_1, 'Assertion failed'
    var_3 = var_0.level
    assert var_3 != var_1, 'Assertion failed'


# Generated at 2022-06-26 02:27:53.206948
# Unit test for function get_config
def test_get_config():
    def _test_cfg(given, expected):
        assert expected == get_config(given)

    _test_cfg(None, DEFAULT_CONFIG)
    _test_cfg('{}', {})
    _test_cfg(default='{}', expected={})
    _test_cfg('''{}''', {})

    # Invalid
    with pytest.raises(ValueError):
        get_config('')


# Generated at 2022-06-26 02:27:55.426408
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.WARNING):
        log.error("foo")
    log.error("bar")

# Generated at 2022-06-26 02:28:04.713318
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger()
    var_2 = logging.DEBUG
    with logger_level(var_1, var_2):
        var_3 = var_1.getEffectiveLevel()
        print(var_3)

    print(var_1.getEffectiveLevel())


# Generated at 2022-06-26 02:28:12.568533
# Unit test for function logger_level
def test_logger_level():
    log_0 = get_logger()
    log_1 = get_logger('test')

    with logger_level(log_0, logging.DEBUG):
        pass

    for (level,log) in ((logging.DEBUG,log_0),(logging.INFO,log_1)):
        with logger_level(log, level):
            log.debug('debug')
            log.info('info')



if __name__ == '__main__':
    import sys

    configure()
    log = get_logger(__name__)
    log.debug("debug")
    log.info("info")
    log.warn("warn")
    log.error("error")
    log.fatal("fatal")

    try:
        raise Exception("test")
    except:
        log.exception("exception")

# Generated at 2022-06-26 02:28:14.821787
# Unit test for function logger_level
def test_logger_level():
    import doctest
    doctest.testmod(sys.modules[__name__])


# Generated at 2022-06-26 02:28:17.446739
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logging.DEBUG
    with logger_level(logger, level):
        assert logger.level == level



# Generated at 2022-06-26 02:28:28.081841
# Unit test for function logger_level
def test_logger_level():
    import logging
    from contextlib import contextmanager

    @contextmanager
    def logger_level(logger, level):
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    LOG = logging.getLogger(__name__)
    LOG.setLevel(logging.DEBUG)
    LOG.addHandler(logging.StreamHandler())

    DEBUG_LOG_LINES = []

    @contextmanager
    def capture_stream(stream):
        saved_stream = sys.stdout
        try:
            sys.stdout = stream
            yield stream
        finally:
            sys.stdout = saved_stream


# Generated at 2022-06-26 02:28:31.357890
# Unit test for function configure
def test_configure():
    configure()
    log = get_logger(__name__)
    log.info('test')
    return log


# Generated at 2022-06-26 02:28:34.397396
# Unit test for function logger_level
def test_logger_level():
    var_0 = int()
    logger = var_0
    level = var_0
    with logger_level(logger, level):
        pass


# Generated at 2022-06-26 02:28:40.007277
# Unit test for function logger_level
def test_logger_level():
    config = DEFAULT_CONFIG
    logging.config.dictConfig(config)
    logger = logging.getLogger('test_case_0')
    logger.debug('this should be printed')
    with logger_level(logger, logging.ERROR):
        logger.debug('this should not be printed, ERROR')
        logger.info('this should not be printed, ERROR')
        logger.warning('this should be printed, ERROR')

    logger.debug('this should be printed again')



# Generated at 2022-06-26 02:28:50.838676
# Unit test for function logger_level
def test_logger_level():
    # Create test logger
    log = logging.getLogger('logger_test')
    # Check for default logger level
    assert log.level == 10
    log.warning('unittest warning message')
    # Set logger level to ERROR for context block
    with logger_level(log, 40):
        assert log.level == 40
        # Test that a message with a level above the logger's level is not logged
        log.debug('unittest debug message')
        # Check that the level is set correctly within the context block
        assert log.level == 40
        # Test that a message with a level at or below the logger's level is logged
        log.error('unittest error message')
        # Check that the level is set correctly outside the context block
        assert log.level == 10
    # Cleanup
    logging.shutdown()
    # Check

# Generated at 2022-06-26 02:29:02.822170
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config

    logging.config.dictConfig({
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'test': {
                'format': u'%(levelname)s %(message)s'
            }
        },
        'handlers': {
            'test': {
                 'class': 'logging.StreamHandler',
                 'formatter': 'test',
                 'level': logging.INFO,
            },
        },
        'loggers': {
            'test': {
                'level': logging.INFO,
            },
        },
    })

    logger = logging.getLogger('test')

    raised = False

# Generated at 2022-06-26 02:29:12.743353
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config(None, None, DEFAULT_CONFIG)


# Generated at 2022-06-26 02:29:19.754823
# Unit test for function logger_level
def test_logger_level():
    import sys
    import io
    import unittest

    class TestLoggerLevel(unittest.TestCase):
        def test_case_0(self):
            def inner():
                var_0 = logger_level(logging.getLogger(), logging.DEBUG)
                with var_0:
                    pass
            inner()

        def test_case_1(self):
            def inner():
                var_0 = get_logger()
                var_1 = logger_level(var_0, logging.DEBUG)
                with var_1:
                    pass
            inner()


# Generated at 2022-06-26 02:29:22.441222
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = 20
    with logger_level(logger, level):
        assert logger.level == level
    assert logger.level != level


# Generated at 2022-06-26 02:29:27.559289
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    with logger_level(logger, logging.INFO):
        assert logger.isEnabledFor(logging.INFO)
        with logger_level(logger, logging.ERROR):
            assert logger.isEnabledFor(logging.ERROR)
        assert logger.isEnabledFor(logging.INFO)
    assert logger.isEnabledFor(logging.DEBUG)



# Generated at 2022-06-26 02:29:30.567496
# Unit test for function get_config
def test_get_config():
    assert get_config(env_var="test") == None
    assert get_config(default="test") == "test"
    assert get_config("test", "test", "test") == "test"
    return



# Generated at 2022-06-26 02:29:36.884354
# Unit test for function get_config
def test_get_config():
    # test_get_config_0
    config = get_config(env_var=None)
    assert config == DEFAULT_CONFIG
    # test_get_config_1
    os.environ['LOGGING'] = '{"test":"test"}'
    try:
        config = get_config(env_var='LOGGING')
        assert config == {'test': 'test'}
    finally:
        del os.environ['LOGGING']


# Generated at 2022-06-26 02:29:44.515340
# Unit test for function get_config

# Generated at 2022-06-26 02:29:48.451324
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    var_1 = logger_level(var_0, 10)
    var_2 = var_1.__enter__()
    var_3 = var_1.__exit__(None, None, None)


# Generated at 2022-06-26 02:29:55.792324
# Unit test for function logger_level
def test_logger_level():
    import utils

    # Get the logger
    var_log = get_logger(__name__)
    # Output a message
    var_log.debug('message')
    # Assert the logger level
    assert var_log.level == logging.DEBUG

    # Change the logger level using the context manager
    with logger_level(var_log, logging.INFO):
        assert var_log.level == logging.INFO

    # Check the logger level
    assert var_log.level == logging.DEBUG



# Generated at 2022-06-26 02:30:05.871019
# Unit test for function get_config
def test_get_config():
    config = get_config('happy', env_var=None, default=DEFAULT_CONFIG)
    assert config == 'happy'
    config = get_config(None,
                        env_var='LOGGING',
                        default=DEFAULT_CONFIG)
    assert config == DEFAULT_CONFIG
    config = get_config({
        'format': {
            'format': '%(asctime)s --- %(name)s: %(message)s'
        }
    }, env_var='LOGGING', default=DEFAULT_CONFIG)
    assert config == {
        'format': {
            'format': '%(asctime)s --- %(name)s: %(message)s'
        }
    }



# Generated at 2022-06-26 02:30:23.974370
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    import sys

    logging.basicConfig(level=logging.DEBUG, stream=sys.stdout)
    logger = logging.getLogger(__name__)

    logger.debug("debug")
    logger.info("info")
    logger.error("error")

    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        with logger_level(logger, logging.INFO):
            logger.debug("debug")
            logger.info("info")
            logger.error("error")
        logger.debug("debug")
        logger.info("info")
        logger.error("error")

    logger.debug("debug")
    logger.info("info")
    logger.error("error")



# Generated at 2022-06-26 02:30:25.755420
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    var_1 = logging.WARNING
    with logger_level(var_0, var_1):
        pass


# Generated at 2022-06-26 02:30:28.529019
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.setLevel(logging.CRITICAL)
    assert logger.level == logging.CRITICAL
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.CRITICAL

# Generated at 2022-06-26 02:30:32.288719
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET



# Generated at 2022-06-26 02:30:36.683589
# Unit test for function logger_level
def test_logger_level():
    name = _namespace_from_calling_context()
    test_logger = logging.getLogger(name)
    configure()
    with logger_level(test_logger, logging.INFO):
        assert logging.INFO == test_logger.level
    assert logging.DEBUG == test_logger.level


# Generated at 2022-06-26 02:30:41.206219
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG) is True
    assert logger.isEnabledFor(logging.DEBUG) is False


if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:42.633432
# Unit test for function configure
def test_configure():
    configure()
    logging.info('test')



# Generated at 2022-06-26 02:30:49.040020
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger('test_logger_level')
    expected_var_1 = logging.getLogger('test_logger_level')
    assert var_1 is expected_var_1
    assert var_1.getEffectiveLevel() == logging.DEBUG
    with logger_level(var_1, logging.INFO):
        assert var_1.getEffectiveLevel() == logging.INFO
    assert var_1.getEffectiveLevel() == logging.DEBUG



# Generated at 2022-06-26 02:30:54.015548
# Unit test for function logger_level
def test_logger_level():
    print('test_logger_level')
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('This is a DEBUG message')
        logger.info('This is a INFO message')
        logger.warning('This is a WARNING message')
        logger.error('This is a ERROR message')
        logger.critical('This is a CRITICAL message')


# Generated at 2022-06-26 02:31:05.786477
# Unit test for function logger_level
def test_logger_level():
    var_0 = test_case_0()
    var_0.info('test')
    with logger_level(var_0, logging.ERROR):
        var_0.info('test')

# In python3 this prints 'ERROR'
# In python2, this prints 'INFO'
# with logger_level(logging.getLogger(), logging.ERROR):
#     logging.getLogger().info('test')
#     test()

# In python3 this prints 'INFO'
# In python2 this prints 'INFO'
# with logger_level(logging.getLogger(), logging.INFO):
#     logging.getLogger().info('test')
#     test()

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:31:20.884406
# Unit test for function logger_level
def test_logger_level():
    variable_0 = get_logger()
    variable_1 = logging.INFO
    with logger_level(variable_0, variable_1):
        variable_2 = variable_0.isEnabledFor(variable_0.INFO)
        assert variable_2 == True


# Generated at 2022-06-26 02:31:23.726644
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.WARNING):
        logger.info("This shouldn't print")
        logger.warning("This should print")
    logger.info("This should print")


# Generated at 2022-06-26 02:31:32.242187
# Unit test for function get_config
def test_get_config():
    err_msg = 'Wrong type config'
    # json string
    cfg = '{"version": 1, "loggers": {"my_module": {"level": "INFO"}}}'
    assert isinstance(get_config(cfg), dict), err_msg
    # yaml string
    cfg = 'loggers:\n  my_module: \n    level: INFO'
    assert isinstance(get_config(cfg), dict), err_msg
    # dict
    cfg = {'version': 1, 'loggers': {'my_module': {'level': 'INFO'}}}
    assert isinstance(get_config(cfg), dict), err_msg
    # path
    cfg = 'my_config.yml'
    assert isinstance(get_config(cfg), dict), err_msg



# Generated at 2022-06-26 02:31:41.617032
# Unit test for function get_config
def test_get_config():
    test_string = '{"version": 1,"formatters": {"simple": {"format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s", "datefmt": "%Y-%m-%d %H:%M:%S"},"colored": {"()": "colorlog.ColoredFormatter","format": "%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s","datefmt": "%H:%M:%S"}}}'
    cfg = get_config(test_string)

# Generated at 2022-06-26 02:31:45.899954
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL


# Generated at 2022-06-26 02:31:53.275291
# Unit test for function logger_level

# Generated at 2022-06-26 02:32:00.459215
# Unit test for function logger_level
def test_logger_level():
    import faker
    import logging
    import random

    fake = faker.Faker()
    fake.seed_instance(random.randint(0, 2 ** 32))

    logger = logging.getLogger(fake.name().replace(' ', '_'))
    # By default, a logger with no handlers has a level of WARNING.
    assert logger.level == logging.WARNING

    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.WARNING


# Generated at 2022-06-26 02:32:02.248900
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(),logging.DEBUG):
        assert get_logger().level == logging.DEBUG
    assert get_logger().level == logging.INFO



# Generated at 2022-06-26 02:32:03.053034
# Unit test for function configure
def test_configure():
    configure()


# Generated at 2022-06-26 02:32:06.345574
# Unit test for function logger_level
def test_logger_level():
    import time

    import logging

    logger = logging.getLogger(__name__)

    try:
        with logger_level(logger, logging.WARNING):
            logger.info('This is an info message')
    except Exception as t_exc:
        assert False



# Generated at 2022-06-26 02:32:27.233149
# Unit test for function logger_level
def test_logger_level():
    import logging
    import tempfile
    import os

    logfile = tempfile.NamedTemporaryFile()
    logfile_name = logfile.name


# Generated at 2022-06-26 02:32:33.387558
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    from logging import basicConfig, getLogger, Logger

    import logdude
    from logdude import logger_level

    @contextmanager
    def logger_level(logger, level):
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    log = getLogger('test_logger_level')
    basicConfig()

    with logger_level(log, logging.DEBUG):
        log.debug('debug message within the context')
        log.info('this will not be shown')

    log.debug('this will not be shown either')


# Generated at 2022-06-26 02:32:34.784539
# Unit test for function logger_level
def test_logger_level():
    test_case_0()

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:32:38.515172
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.INFO):
        log.debug('Should not print')
    log.debug('Should print')


# Generated at 2022-06-26 02:32:42.831015
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    # Initial state
    assert logger.level == 20 # Default level is WARNING

    with logger_level(logger, logging.INFO):
        # Level changed within context
        assert logger.level == logging.INFO

    # Level reset to initial value
    assert logger.level == 20

# Generated at 2022-06-26 02:32:47.889205
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("test_logger_level")
    with logger_level(logger, logging.CRITICAL):
        logger.info("Should not log")
        logger.critical("Should log")
    logger.info("Should log")
       
if __name__ == '__main__':
    # Unit test for function logger_level
    test_logger_level()

# Generated at 2022-06-26 02:32:55.510440
# Unit test for function logger_level
def test_logger_level():
    my_logger = logging.getLogger('test')
    my_logger.setLevel(logging.DEBUG)
    my_logger.addHandler(logging.StreamHandler())
    with logger_level(my_logger, logging.DEBUG):
        my_logger.debug('This should be visible')
        with logger_level(my_logger, logging.INFO):
            my_logger.debug('This should not be visible')
            my_logger.info('This should be visible')
        my_logger.debug('This should be visible')

    my_logger.setLevel(logging.DEBUG)
    my_logger.debug('This should be visible')

if __name__ == '__main__':
    test_logger_level()
   # test_case_0()

# Generated at 2022-06-26 02:32:56.630617
# Unit test for function configure
def test_configure():
    return configure(default=DEFAULT_CONFIG)



# Generated at 2022-06-26 02:33:04.086826
# Unit test for function logger_level
def test_logger_level():
    # Check that we can add a handler (and thus the logger has been setup)
    logger = get_logger()
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
    assert logger.level != logging.ERROR
    logger.handlers = []
    assert logger.handlers == []
    # Check that the new handler has the correct level
    handler = logging.StreamHandler()
    logger.addHandler(handler)
    assert handler.level == logging.WARN

# Generated at 2022-06-26 02:33:10.343805
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    level = logging.DEBUG
    logger.setLevel(level)
    initial_logger_level = logger.getEffectiveLevel()
    logging.debug("Debug message.")
    with logger_level(logger, logging.INFO):
        logging.debug("Debug message.")
    logger.setLevel(initial_logger_level)
    logging.debug("Debug message.")


# Generated at 2022-06-26 02:33:24.272819
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), 1) as _:
        assert getLogger().level == 1


# Generated at 2022-06-26 02:33:26.356490
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), 30):
        assert getLogger().level == 30



# Generated at 2022-06-26 02:33:28.882770
# Unit test for function logger_level
def test_logger_level():
    logger_level_var=logger_level(get_logger(),10)
    with logger_level_var:
        print(logger_level_var)


# Generated at 2022-06-26 02:33:34.406462
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.ERROR):
        assert log.level == logging.ERROR
        with logger_level(log, logging.DEBUG):
            assert log.level == logging.DEBUG
        assert log.level == logging.ERROR



# Generated at 2022-06-26 02:33:48.673004
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG



if __name__ == '__main__':
    test_case_0()
    configure()
    var_1 = get_logger()
    var_1.debug('test debug')
    var_1.info('test info')
    var_1.warn('test warn')
    var_1.error('test error')
    var_1.fatal('test fatal')
    test_logger_level()

# Generated at 2022-06-26 02:33:52.200699
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)

    with logger_level(logger, logging.INFO):
        logger.warn('Hey')
        logger.debug('Nope')

    with logger_level(logger, logging.WARNING):
        logger.debug('No')
        logger.warn('Warn')
        logger.error('Hey')


# TODO put this in a skeleton repo

# Generated at 2022-06-26 02:34:01.743417
# Unit test for function logger_level
def test_logger_level():
    def fn_0():
        var_0 = get_logger()
        with logger_level(var_0, 10):
            var_0.info('test')

    # assert_raises(KeyError, fn_0)
    try:
        fn_0()
    except KeyError as e:
        pass


__all__ = [
    'logger_level',
    'test_case_0',
    'test_logger_level',
    'getLogger',
    'get_logger',
    'configure',
    'get_config',
]

# Generated at 2022-06-26 02:34:04.217133
# Unit test for function logger_level
def test_logger_level():
    var_1 = get_logger()
    initial = var_1.level
    logger_level(var_1, 30)
    return var_1.level == 30



# Generated at 2022-06-26 02:34:14.402694
# Unit test for function logger_level
def test_logger_level():
    # Debug Level
    var_logger = getLogger()
    with logger_level(var_logger, logging.DEBUG):
        var_logger.debug('THIS IS A DEBUG MESSAGE')

    # Info Level
    var_logger = getLogger()
    with logger_level(var_logger, logging.INFO):
        var_logger.info('THIS IS A INFO MESSAGE')

    # Warning Level
    var_logger = getLogger()
    with logger_level(var_logger, logging.WARNING):
        var_logger.warning('THIS IS A WARNING MESSAGE')

    # Error Level
    var_logger = getLogger()
    with logger_level(var_logger, logging.ERROR):
        var_logger.error('THIS IS A ERROR MESSAGE')

# Generated at 2022-06-26 02:34:17.692539
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    logger.info('outside context')
    with logger_level(logger, logging.WARN):
        logger.info('inside context')
        assert logger.level == logging.WARN
    logger.info('outside context')



# Generated at 2022-06-26 02:34:31.534094
# Unit test for function logger_level
def test_logger_level():
    get_logger().setLevel(logging.DEBUG)
    with logger_level(get_logger(), logging.DEBUG):
        assert logging.DEBUG == get_logger().getEffectiveLevel()
        get_logger().debug('debug')
    assert logging.DEBUG == get_logger().getEffectiveLevel()


# Generated at 2022-06-26 02:34:35.444248
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    logger.setLevel(logging.DEBUG)

if __name__ == '__main__':
    test_case_0()
    test_logger_level()
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:34:37.430747
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    try:
        with logger_level(log, logging.ERROR):
            assert log.level == logging.ERROR
    except ValueError:
        assert True


# Generated at 2022-06-26 02:34:40.357806
# Unit test for function logger_level
def test_logger_level():
    var = get_logger()
    with logger_level(var, 100):
        assert var.level == 100

if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:34:45.061522
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('test')
    log.setLevel(logging.DEBUG)
    log.info("default log level")
    with logger_level(log, logging.INFO):
        log.info("expected to not see this")
        log.debug("expected to see this")
    log.debug("expected to not see this")

# Generated at 2022-06-26 02:34:49.091794
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level != logging.DEBUG



# Generated at 2022-06-26 02:34:54.688960
# Unit test for function logger_level
def test_logger_level():
    """Test for logger_level in module: logging."""
    logger = get_logger()
    level = 10
    with logger_level(logger, level):
        # Test logger level within context
        assert logger.level == level
    # Test logger level outside context
    assert logger.level == 10


if __name__ == '__main__':
    import logging

    logging.basicConfig(level=logging.DEBUG)

    test_logger_level()
    test_case_0()

# Generated at 2022-06-26 02:34:58.550127
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    assert logger.level == logging.DEBUG
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG


if __name__ == '__main__':
    import pytest
    pytest.main(sys.argv[1:])

# Generated at 2022-06-26 02:35:00.991818
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    with logger_level(logger, logging.INFO):
        assert(logger.level == logging.INFO)
    assert(logger.level == logging.NOTSET)



# Generated at 2022-06-26 02:35:03.647047
# Unit test for function logger_level
def test_logger_level():
    log = get_Logger()
    with logger_level(log, 'DEBUG') as level:
        pass

# Generated at 2022-06-26 02:35:18.523487
# Unit test for function logger_level
def test_logger_level():
    var_0 = test_case_0.__globals__['var_0']
    var_1 = 0
    with logger_level(var_0, 50) as _:
        var_2 = var_0.debug('test')
        var_1 = 1
    var_3 = var_1
    var_4 = 1
    assert var_3 == var_4


# Generated at 2022-06-26 02:35:25.203488
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__file__)
    logger.setLevel(logging.DEBUG)
    stream = logging.StreamHandler(sys.stdout)
    stream.setLevel(logging.INFO)
    logger.addHandler(stream)
    with logger_level(logger, logging.WARNING):
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
    logger.debug('test')
    logger.info('test')
    logger.warning('test')
    logger.error('test')


if __name__ == '__main__':
    getLogger(__file__).setLevel(logging.DEBUG)
    getLogger(__file__).addHandler(logging.StreamHandler(sys.stderr))
    test_logger_level

# Generated at 2022-06-26 02:35:30.677485
# Unit test for function configure
def test_configure():
    from log_config import util
    from log_config.util import DEFAULT_CONFIG

    # Default case

# Generated at 2022-06-26 02:35:36.146745
# Unit test for function logger_level
def test_logger_level():
    # Configuration
    configure(default=DEFAULT_CONFIG)
    logger = get_logger()
    logger.setLevel(logging.ERROR)
    level = logging.DEBUG

    # Case 1: set the logger level to DEBUG and within the context block check its value
    with logger_level(logger, level):
        assert logger.level == level, "Expected logger level to be DEBUG"
    assert logger.level != level, "Expected logger level to be ERROR"



# Generated at 2022-06-26 02:35:47.112967
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import shutil


# Generated at 2022-06-26 02:35:50.900808
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.INFO):
        log.debug("Debug message")
        log.info("Info message")

