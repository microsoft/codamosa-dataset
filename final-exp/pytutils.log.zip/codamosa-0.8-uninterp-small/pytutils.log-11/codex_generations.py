

# Generated at 2022-06-26 02:26:07.955583
# Unit test for function get_config

# Generated at 2022-06-26 02:26:11.102825
# Unit test for function logger_level
def test_logger_level():
    assert logger_level is not None


# Generated at 2022-06-26 02:26:19.827133
# Unit test for function logger_level
def test_logger_level():
    import logging
    import logging.config
    import random
    import os
    import sys
    import re
    if sys.version_info[0] == 3:
        import io as StringIO
    else:
        from StringIO import StringIO

# Generated at 2022-06-26 02:26:22.806881
# Unit test for function logger_level
def test_logger_level():
    lg = get_logger()
    print(lg.level)

    with logger_level(lg, logging.DEBUG):
        print(lg.level)

    print(lg.level)



# Generated at 2022-06-26 02:26:24.110121
# Unit test for function get_config
def test_get_config():
    list_0 = None
    var_0 = get_config()


# Generated at 2022-06-26 02:26:26.858917
# Unit test for function logger_level
def test_logger_level():
    logger_level(None, None)

if __name__ == '__main__':
    get_config()

    # test_case_0()

    test_logger_level()

# Generated at 2022-06-26 02:26:31.951252
# Unit test for function get_config
def test_get_config():
    list_0 = None
    # This exception should be caught:
    #     raise ValueError('Invalid logging config: %s' % config)

    try:
        list_0 = get_config()
    except ValueError as e:
        pass
    else:
        assert 1 == 0


# Generated at 2022-06-26 02:26:43.321243
# Unit test for function configure
def test_configure():
    assert configure(config={'version': 1,
                             'disable_existing_loggers': False}, env_var={'LOGGING': 'LOGGING'}, default={'version': 1,
                                                                                                       'disable_existing_loggers': False}) == None
    assert configure(config={'version': 1,
                             'disable_existing_loggers': False}, env_var=None, default={'version': 1,
                                                                                        'disable_existing_loggers': False}) == None
    assert configure(config=None, env_var={'LOGGING': 'LOGGING'}, default={'version': 1, 'disable_existing_loggers': False}) == None
    assert configure(config=None, env_var=None, default={'version': 1, 'disable_existing_loggers': False}) == None


# Generated at 2022-06-26 02:26:46.564590
# Unit test for function logger_level
def test_logger_level():
    # Input parameters
    _logger = None
    _level = None

    with logger_level(_logger, _level):
        pass


# Generated at 2022-06-26 02:26:49.228819
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager

    log = get_logger().getChild('test_logger_level')

    with logger_level(log, logging.INFO):
        log.debug('info')
        log.info('info')
        log.warning('info')
        log.error('info')

    log.debug('normal')
    log.info('normal')
    log.warning('normal')
    log.error('normal')


# Generated at 2022-06-26 02:26:59.101322
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    level = 20
    initial_level = logger.level
    with logger_level(logger, level):
        assert logger.level == level

    assert logger.level == initial_level


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:27:04.911229
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger()
    assert logger.level == logging.NOTSET, 'logging level is not "NOTSET" by default'
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO, 'logging level is not "INFO" after entering context'
    assert logger.level == logging.NOTSET, 'logging level is not restored to "NOTSET" after exiting context'
    pass


# Generated at 2022-06-26 02:27:07.359482
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)

    with logger_level(log, logging.WARNING):
        log.debug("asdf")


# Generated at 2022-06-26 02:27:10.481897
# Unit test for function logger_level
def test_logger_level():
    var_0 = None
    var_0 = logging.getLogger()
    var_1 = None
    var_1 = logging.DEBUG
    var_0 = logger_level(var_0, var_1)


# Generated at 2022-06-26 02:27:12.154392
# Unit test for function logger_level
def test_logger_level():
    logger_level(1, 2)



# Generated at 2022-06-26 02:27:16.049738
# Unit test for function logger_level
def test_logger_level():

    logger = logging.getLogger(__name__)

    with logger_level(logger, logging.DEBUG):
        print(logger.level)

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:27:21.561497
# Unit test for function logger_level
def test_logger_level():
    def func_0(logger, level):
        initial = logger.level
        logger.level = level
        return initial
    logger_0 = getLogger("")
    level_0 = logging.NOTSET
    with logger_level(logger_0, level_0) as context_0:
        var_0 = func_0(logger_0, level_0)
    assert var_0 == 0


# Generated at 2022-06-26 02:27:27.481178
# Unit test for function logger_level
def test_logger_level():
    import sys
    import tempfile

    try:
        with logger_level(logging.getLogger(), logging.NOTSET):
            with tempfile.TemporaryFile("w+") as tmp:
                with sys.stdout as org_stdout:
                    with sys.stderr as org_stderr:
                        sys.stdout = tmp
                        sys.stderr = tmp
                        get_logger().info("foo")
                        assert sys.stdout is tmp
                        assert sys.stderr is tmp
                        sys.stdout = org_stdout
                        sys.stderr = org_stderr
    except:
        logging.exception("Test failed")
        assert False


# Generated at 2022-06-26 02:27:31.172879
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.ERROR):
        log.debug('this message should not be displayed')
    log.error('this message should be displayed')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:27:36.081050
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')
    log.info('This is test_logger_level')
    log.debug('I am debug')
    with logger_level(log, logging.DEBUG):
        log.debug('I am debug too')
    log.debug('I am debug again')


# Generated at 2022-06-26 02:27:46.772583
# Unit test for function logger_level
def test_logger_level():
    int_0 = 0
    test_logger = getLogger('test_logger_level')
    target_level = logging.WARN
    with logger_level(test_logger, target_level):
        test_logger.debug('Unit test')
        assert test_logger.level == target_level
        test_logger.warn('Unit test')
        int_0 = test_logger.level
    test_logger.debug('Unit test')
    assert test_logger.level == int_0
    assert int_0 == logging.DEBUG


# Generated at 2022-06-26 02:27:49.058341
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger('foo')
    configure(log)
    with logger_level(logger=log, level=logging.DEBUG):
        pass


# Generated at 2022-06-26 02:27:53.975773
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger('test'), logging.WARNING):
        get_logger('test').info('test')

    get_logger('test').info('test')


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:28:03.688809
# Unit test for function get_config
def test_get_config():
    assert get_config(default=DEFAULT_CONFIG) == DEFAULT_CONFIG
    assert (get_config(default=[1, 2, 3]) == [1, 2, 3])
    assert (get_config(default=[1, 2, 3]) == [1, 2, 3])
    assert (get_config(default=[1, 2, 3]) == [1, 2, 3])
    assert (get_config(default=[1, 2, 3]) == [1, 2, 3])
    assert (get_config(default=[1, 2, 3]) == [1, 2, 3])


if __name__ == '__main__':
    logging.getLogger().setLevel(logging.DEBUG)
    test_get_config()

# Generated at 2022-06-26 02:28:07.330048
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('test')

if __name__ == '__main__':
    configure()
    test_logger_level()
    test_case_0()

# Generated at 2022-06-26 02:28:18.777951
# Unit test for function logger_level
def test_logger_level():
    def wrapped_f(x):
        return x * 4

    def test_logger(logger):
        logger('this is a test')

    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        assert log.debug('a debug message')
        assert log.info('an info message')
        assert log.warning('a warning message')
        assert log.error('an error message')

    with logger_level(log, logging.INFO):
        assert log.info('an info message')
        assert not log.debug('a debug message')
        assert log.warning('a warning message')
        assert log.error('an error message')

    with logger_level(log, logging.WARNING):
        assert log.warning('a warning message')
        assert not log.debug('a debug message')


# Generated at 2022-06-26 02:28:19.863768
# Unit test for function logger_level
def test_logger_level():
    test_log = get_logger()

    # TODO: add test
    raise NotImplementedError()


# Generated at 2022-06-26 02:28:20.577058
# Unit test for function logger_level
def test_logger_level():    
    assert logger_level() == 'pass'


# Generated at 2022-06-26 02:28:22.522921
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logger=logging.getLogger(), level=logging.CRITICAL):
        print(logging.getLogger('pytest').level)

if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:28:26.041650
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET


# Generated at 2022-06-26 02:28:31.153031
# Unit test for function logger_level
def test_logger_level():
    logger_0 = logging.getLogger(__name__)
    level_0 = 0
    with logger_level(logger_0, level_0):
        pass



# Generated at 2022-06-26 02:28:35.964110
# Unit test for function logger_level
def test_logger_level():
    # setUp function
    def setUp():
        pass

    # tearDown function
    def tearDown():
        pass

    # Statement to be executed
    int_1 = -832
    var_1 = configure(int_1)

    # Parent method call
    with logger_level(var_1, int_1):
        pass



# Generated at 2022-06-26 02:28:40.748628
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    with logger_level(logger, logging.WARNING):
        # The following line should be suppressed
        logger.debug("Debug message")
        # The following line should not be suppressed
        logger.info("info message")
        logger.warning("Warning message")
        logger.error("Error message")

if __name__ == '__main__':
    configure(DEFAULT_CONFIG)
    test_logger_level()
    logging.shutdown()

# Generated at 2022-06-26 02:28:41.486275
# Unit test for function logger_level
def test_logger_level():
    pass



# Generated at 2022-06-26 02:28:51.402334
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger('logger_levelTest')
    logger.setLevel(logging.INFO)

    with logger_level(logger, logging.NOTSET):
        assert logger.isEnabledFor(logging.NOTSET)
        assert logger.isEnabledFor(logging.DEBUG)

    assert not logger.isEnabledFor(logging.NOTSET)
    assert not logger.isEnabledFor(logging.DEBUG)
    assert logger.isEnabledFor(logging.INFO)

    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)

    assert logger.isEnabledFor(logging.INFO)
    assert not logger.isEnabledFor(logging.DEBUG)



# Generated at 2022-06-26 02:28:54.953297
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    from log_config import logger_level

    import logging
    import traceback

    logger = logging.getLogger()
    try:
        with logger_level(logger, logging.DEBUG):
            raise TypeError("Wat")
    except TypeError:
        traceback.print_exc()


# Generated at 2022-06-26 02:28:58.830283
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.CRITICAL):
        log.debug("This log line will be suppressed")
    assert "This log line will be suppressed" not in log.debug.call_args



# Generated at 2022-06-26 02:29:09.760804
# Unit test for function logger_level
def test_logger_level():
    # Create dummy data
    var_0 = configure(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    int_0 = -832
    int_1 = -832
    int_2 = -832
    int_3 = -832
    int_4 = -832
    int_5 = -832
    int_6 = -832
    int_7 = -832
    int_8 = -832
    int_9 = -832
    int_10 = -832
    int_4 = 874
    int_7 = 987
    int_10 = -832
    var_1 = get_config(given=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    int_3 = -832
    var

# Generated at 2022-06-26 02:29:17.785713
# Unit test for function logger_level
def test_logger_level():

    # Argument 0: By default the logging level is set to 'INFO' but
    #             here it is being set to 'DEBUG' for this function
    #             for logging purpose
    logging.basicConfig(level = logging.DEBUG)

    # This will print the output in 'STDOUT'
    logging.debug("This is DEBUG")
    logging.info("This is INFO")
    logging.error("This is ERROR")

    # Argument 1: This is the logger level being set to 'ERROR' so that
    #             the logging with level 'INFO' and 'DEBUG' will not be
    #             printed
    with logger_level(logging.getLogger(), logging.ERROR):
        logging.debug("This is DEBUG")
        logging.info("This is INFO")
        logging.error("This is ERROR")

test_case_0()
test_logger_

# Generated at 2022-06-26 02:29:27.478558
# Unit test for function logger_level
def test_logger_level():
    root_logger = logging.getLogger()
    # Call logger_level with root_logger and log level as parameters
    with logger_level(root_logger, logging.CRITICAL):
        # Get root logger's log level
        root_logger.critical('logger level should be CRITICAL')

    # Should print true as the log level
    print('logger level is not CRITICAL: ', root_logger.getEffectiveLevel() != logging.CRITICAL)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='Run logging config tests')
    parser.add_argument('--s', help='Run various test configurations for security testing', action='store_true', default=False)

# Generated at 2022-06-26 02:29:35.748093
# Unit test for function logger_level
def test_logger_level():
    # Block setup
    logger = None
    level = 1
    logger = get_logger('test')
    logger.level = logging.DEBUG
    # Test block
    # with logger_level
    with logger_level(logger, level):
        logger.info('test')
    # Test assertions

test_logger_level()

# Generated at 2022-06-26 02:29:38.139922
# Unit test for function get_config
def test_get_config():
    assert get_config(None, None, None) == DEFAULT_CONFIG
    assert get_config(DEFAULT_CONFIG, None, None) == DEFAULT_CONFIG



# Generated at 2022-06-26 02:29:44.104956
# Unit test for function logger_level
def test_logger_level():
    with logger_level(var_0, var_1):
        assert logger_level(var_0, var_1) is None


# Unit tests for function test_case_0
# def test_test_case_0():
#     assert test_case_0() is None


# Unit tests for function test_test_case_0
# def test_test_test_case_0():
#     assert test_test_case_0() is None

# Generated at 2022-06-26 02:29:45.918454
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.DEBUG):
        pass


# Generated at 2022-06-26 02:29:50.892215
# Unit test for function logger_level
def test_logger_level():
    get_logger().info('test')
    with logger_level(getLogger(), logging.CRITICAL):
        getLogger().critical('critical')
        getLogger().debug('*not* debug')
    getLogger().debug('debug')

if __name__ == '__main__':
    import doctest
    doctest.testmod()

    test_logger_level()

# Generated at 2022-06-26 02:29:52.423607
# Unit test for function logger_level
def test_logger_level():
    assert logger_level > 0


# Generated at 2022-06-26 02:29:55.173105
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.WARN):
        log.debug("This won't print")
        log.warn("This will print")



# Generated at 2022-06-26 02:29:59.800591
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    level = 20

    with logger_level(logger, level):
        logger.debug("Logging in a context")
        assert isinstance(logger.level, int) == True
        assert logger.level == level
    assert logger.level != level

# Generated at 2022-06-26 02:30:01.532640
# Unit test for function logger_level
def test_logger_level():
    logger_level(logger, logging.DEBUG)


# Generated at 2022-06-26 02:30:02.872373
# Unit test for function logger_level
def test_logger_level():
    test_0 = logging.getLogger("test_logger_level")
    with logger_level(test_0, 50):
        test_0.warning("This is a warning")



# Generated at 2022-06-26 02:30:11.130990
# Unit test for function get_config
def test_get_config():

    # Setting the arguments
    arg_0 = "LOGGING"

    # Calling the function using the default value of arguments
    str_0 = get_config()
    assert type(str_0) == dict

    # Calling the function using the default value of arguments
    str_1 = get_config(arg_0)
    assert type(str_1) == dict


# Generated at 2022-06-26 02:30:14.541826
# Unit test for function logger_level
def test_logger_level():
    t_0 = logging.getLogger('t_0')
    l_0 = logging.WARNING
    with logger_level(t_0, l_0):
        l_1 = logging.DEBUG
        test_case_0()
    t_0.info('test is done')


# Generated at 2022-06-26 02:30:16.763313
# Unit test for function logger_level
def test_logger_level():

    # Test cases
    assert isinstance(logger_level(0, 0), contextmanager)
    assert isinstance(logger_level(0, int_0), contextmanager)



# Generated at 2022-06-26 02:30:19.674040
# Unit test for function logger_level
def test_logger_level():
    DUMMY_TEST = False
    if DUMMY_TEST:
        logger = getLogger()
        with logger_level(logger, 'DEBUG'):
            test_case_0()


# Generated at 2022-06-26 02:30:22.980519
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.INFO):
        log.info('test')
        log.error('test')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:30:24.302315
# Unit test for function get_config
def test_get_config():
    config = '{"a": "b"}'
    var_0 = get_config(config)

# Generated at 2022-06-26 02:30:33.153788
# Unit test for function get_config
def test_get_config():
    """Test get_config"""
    # given
    case_0_given = "{'key_gz': 'value_gz'}"
    case_1_given = "{'key_z': 'value_z'}"
    case_2_given = "{'key_x': 'value_x'}"
    case_3_given = "{'key_y': 'value_y'}"
    # default
    case_0_default = "{'key_az': 'value_az'}"
    case_1_default = "{'key_bz': 'value_bz'}"
    case_2_default = "{'key_cz': 'value_cz'}"
    case_3_default = "{'key_dz': 'value_dz'}"
    # env_var

# Generated at 2022-06-26 02:30:35.562737
# Unit test for function logger_level
def test_logger_level():
    test_case_0()


if __name__ == "__main__":
    #import doctest
    #doctest.testmod()
    test_logger_level()

# Generated at 2022-06-26 02:30:40.448265
# Unit test for function logger_level
def test_logger_level():
    # Testing the precondition
    # logger argument should be a logger object
    logger = get_logger()
    with logger_level(logger, "logging.DEBUG"):
        assert logger.level is logging.DEBUG
    # should revert back to previous log_level
    assert logger.level is logging.INFO

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:30:42.812257
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.DEBUG):
        assert get_logger().isEnabledFor(logging.DEBUG)


# Generated at 2022-06-26 02:30:52.404598
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)

    with logger_level(log, logging.INFO):
        log.debug('test')
        log.info('test')

    with logger_level(log, logging.DEBUG):
        log.debug('test')
        log.info('test')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:30:53.713958
# Unit test for function configure
def test_configure():
    """
    >>>
    """

    pass


# Generated at 2022-06-26 02:31:05.533627
# Unit test for function get_config
def test_get_config():
    from hamcrest import assert_that, equal_to, is_, none

    # Test 1: Set config to dict

# Generated at 2022-06-26 02:31:10.356290
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    int_0 = -832
    with logger_level(logger, int_0):
        int_1 = -832
        var_0 = logger.info(int_1)
    int_2 = -832
    var_1 = logger.debug(int_2)


# Generated at 2022-06-26 02:31:21.770751
# Unit test for function get_config
def test_get_config():
    # get config via default parameter and assert that we're not using an empty config
    assert get_config(default={'a': 1}) != {}

    # get config via an environment variable and assert that we're not using an empty config
    os.environ['TEST_ENV_VAR'] = {'a': 1}
    assert get_config(env_var='TEST_ENV_VAR') != {}
    os.environ.pop('TEST_ENV_VAR')

    # get config via specific config and assert that we're not using an empty config
    assert get_config(config={'a': 1}) != {}

    # assert that an error is thrown if we're given no config and there is no default config
    try:
        get_config()
        assert False
    except ValueError:
        assert True

    # assert that

# Generated at 2022-06-26 02:31:28.675349
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging.getLogger(), logging.ERROR):
        test_case_0()


# Generated at 2022-06-26 02:31:33.649781
# Unit test for function get_config
def test_get_config():
    inpt = [0, None, {}]
    expct = [{'version': 1, 'disable_existing_loggers': False}, {'version': 1, 'disable_existing_loggers': False}, {}]
    assert [get_config(i) for i in inpt] == expct


# Generated at 2022-06-26 02:31:42.287694
# Unit test for function get_config
def test_get_config():
    # Testing: default
    cfg = get_config(config=None, env_var='LOGGING', default=DEFAULT_CONFIG)
    assert(cfg['version']==1)
    assert(cfg['disable_existing_loggers']==False)
    assert(cfg['formatters']['colored']['format']=='%(bg_black)s%(log_color)s[%(asctime)s] [%(name)s/%(process)d] %(message)s %(blue)s@%(funcName)s:%(lineno)d #%(levelname)s%(reset)s')
    assert(cfg['formatters']['colored']['datefmt']=='%H:%M:%S')

# Generated at 2022-06-26 02:31:48.606236
# Unit test for function logger_level
def test_logger_level():
    # Initialize test
    int_0 = 1
    # Set logger level
    t = logger_level(int_0)
    # Case where everything goes right
    try:
        # Case where everything goes right
        try:
            t
        except:
            assert False
    except:
        # Case where everything goes wrong
        try:
            t
        except:
            assert True


# Generated at 2022-06-26 02:31:50.708171
# Unit test for function logger_level
def test_logger_level():
    int_0 = -832
    var_0 = configure(int_0)
    int_1 = logger_level(var_0, int_0)


# Generated at 2022-06-26 02:31:58.838845
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    log.debug('test1')
    with logger_level(log, logging.INFO):
        log.debug('test2')
        log.info('test3')
    log.debug('test4')


# Generated at 2022-06-26 02:31:59.805953
# Unit test for function logger_level
def test_logger_level():
    assert 2 == 2


# Generated at 2022-06-26 02:32:03.218719
# Unit test for function logger_level
def test_logger_level():
    import logging
    x = logging.getLogger("A")
    x.setLevel(logging.WARNING)
    with logger_level(x, logging.DEBUG):
        assert(x.level == logging.DEBUG)

    with logger_level(x, logging.DEBUG):
        assert(x.level == logging.DEBUG)

    assert(x.level == logging.WARNING)


# Generated at 2022-06-26 02:32:09.266181
# Unit test for function logger_level
def test_logger_level():
    from django.core.management import call_command, CommandError
    from django.test import TestCase
    from django.test.utils import override_settings
    from django.utils import six
    import logging
    import warnings

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    logger.debug('test')

    logger2 = logging.getLogger(__name__+'2')
    logger2.setLevel(logging.DEBUG)
    logger2.debug('test2')

    class TestLoggerLevel(TestCase):
        def test_logger_level(self):
            with logger_level(logger, logging.INFO):
                logger.debug('test')
            logger.debug('test')

# Generated at 2022-06-26 02:32:11.313430
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), "INFO"):
        get_logger().info('test1')
    pass


# Generated at 2022-06-26 02:32:12.181040
# Unit test for function logger_level
def test_logger_level():
    # TODO
    pass


# Generated at 2022-06-26 02:32:22.742283
# Unit test for function get_config

# Generated at 2022-06-26 02:32:26.325674
# Unit test for function logger_level
def test_logger_level():
    # TODO: add tests for logger_level
    with logger_level(test_case_0, "") as TestLoggerLevel:
            TestLoggerLevel.info("Logger level set to: ")
    

# Generated at 2022-06-26 02:32:31.128113
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    with logger_level(log, logging.DEBUG):
        with logger_level(log, logging.WARNING):
            with logger_level(log, logging.CRITICAL):
                log.debug('debug message')
                log.info('info message')
                log.warning('warning message')
                log.error('error message')
                log.critical('critical message')


# Generated at 2022-06-26 02:32:33.559101
# Unit test for function configure
def test_configure():
    input_variable = "test"

    with logger_level(getLogger(), logging.DEBUG):
        configure(input_variable)


# Generated at 2022-06-26 02:32:46.359725
# Unit test for function logger_level
def test_logger_level():
    '''Test that logger level is set and reset to the same level
    '''
    import logging

    import time

    logger = get_logger()
    initial = logger.level

    with logger_level(logging.INFO) as logger:
        assert logger.level == logging.INFO
        time.sleep(1)
        assert logger.level == initial



# vim: set ft=python ts=4 sw=4 expandtab :

# Generated at 2022-06-26 02:32:49.822711
# Unit test for function logger_level
def test_logger_level():
    var_0 = logging.getLogger('Test logger for logger_level')
    with logger_level(var_0, logging.INFO):
        var_0.error('Test log from logger_level')
        pass


# Generated at 2022-06-26 02:32:51.388067
# Unit test for function logger_level
def test_logger_level():
    import unitest

    with logger_level(var_0, var_0):
        test_case_0()



# Generated at 2022-06-26 02:32:52.182709
# Unit test for function get_config
def test_get_config():
    assert get_config(int_0) == int_0


# Generated at 2022-06-26 02:32:54.550730
# Unit test for function configure
def test_configure():
    # Check that every line of code is executed.
    assert test_case_0() == None


if __name__ == '__main__':
    test_configure()
    test_case_0()

# Generated at 2022-06-26 02:32:56.936839
# Unit test for function logger_level
def test_logger_level():

    int_0 = 778
    int_1 = 7
    dict_0 = dict(logger=int_1, level=int_0)

    assert isinstance(dict_0, dict)

# Generated at 2022-06-26 02:33:02.484393
# Unit test for function logger_level
def test_logger_level():
    try:
        signal.signal(signal.SIGINT, signal_handler)
        with logger_level():
            return var_0
    except Exception as _exc:
        _exc_type, _exc_obj, tb = sys.exc_info()
        return obj.text_type()



# Generated at 2022-06-26 02:33:12.381467
# Unit test for function logger_level
def test_logger_level():
    # Logging tests
    import logging
    import time
    import os
    from functools import partial
    from contextlib import contextmanager

    def log_and_wait(logger, level, msg, delay):
        import time
        with logger_level(logger, level):
            logger.log(level, "%s %s", msg, delay)
            time.sleep(delay)

    logger = logging.getLogger("level_test")

    log_and_wait = partial(log_and_wait, logger)

    # This should log with level DEBUG, INFO and wait for 3 seconds.
    log_and_wait(logging.DEBUG, "debug", 3)
    # This should log with level INFO, ERROR and wait for 2 seconds.
    log_and_wait(logging.ERROR, "error", 2)
    # This should

# Generated at 2022-06-26 02:33:14.869037
# Unit test for function logger_level
def test_logger_level():
    try:
        logger_level(logger_level, logger_level)
    except:
        import traceback, sys
        traceback.print_exc()
        sys.stderr.write("A problem occurred in the execution of function logger_level\n")



# Generated at 2022-06-26 02:33:25.676104
# Unit test for function configure
def test_configure():
    # *** Error: configure() missing 1 required positional argument: 'config'

    # func configure()
    # assert that function configure() raises TypeError as exc:
    with pytest.raises(TypeError) as exc:
        configure()
    # assert exc.value

    # should it assert:

    # *** Error: configure() missing 1 required positional argument: 'config'
    # with pytest.raises(TypeError) as excinfo:
    #     configure()
    # assert str(excinfo.value) == "configure() missing 1 required positional argument: 'config'"



# Generated at 2022-06-26 02:33:33.837886
# Unit test for function logger_level
def test_logger_level():
    '''
    Set logger level to `level` within a context block. Don't use this except for debugging please, it's gross.
    '''
    pass


# Generated at 2022-06-26 02:33:42.754438
# Unit test for function logger_level
def test_logger_level():
    test_logger_level.logger.addHandler(logging.NullHandler())

    logged_events = []

    from logging import getLogger
    from logging import DEBUG, INFO, WARNING, ERROR, CRITICAL

    logger = getLogger('test')
    logger.setLevel(WARNING)
    handler = logging.StreamHandler()
    logger.addHandler(handler)

    def log_event(event):
        logged_events.append(event)
        handler.emit(event)

    logger.debug('This should not be logged')
    assert len(logged_events) == 0


# Generated at 2022-06-26 02:33:45.825321
# Unit test for function configure
def test_configure():
    # Error: config must be a string, dict, or None.
    with pytest.raises(ValueError):
        test_case_0()


# Generated at 2022-06-26 02:33:48.671659
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    test_value = 2
    with logger_level(logger, test_value):
        assert logger.level == test_value


# Generated at 2022-06-26 02:33:49.299583
# Unit test for function logger_level
def test_logger_level():
    # noinspection PyUnresolvedReferences
    logger_level()



# Generated at 2022-06-26 02:33:53.231797
# Unit test for function logger_level
def test_logger_level():
    get_logger().setLevel(logging.INFO)
    with logger_level(get_logger(), logging.DEBUG):
        get_logger().debug('test')

test_cases = [
    test_case_0,
    test_logger_level,
]

if __name__ == '__main__':
    from pathlib import Path
    from test_tube.helpers import run_tests

    run_tests(test_cases, Path(__file__).stem)

# Generated at 2022-06-26 02:34:04.290252
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.DEBUG)
    # Create a logger and configure it
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)

    # The logger should be configured to log at level DEBUG
    # Set the level to INFO within a context block
    with logger_level(logger, logging.INFO):
        logger.debug('This will not be logged')
        logger.info('This will be logged')

    # The logger level should now be DEBUG again
    logger.debug('This will be logged again')
    logger.info('This will be logged again')



# Generated at 2022-06-26 02:34:07.888826
# Unit test for function get_config
def test_get_config():
    assert DEFAULT_CONFIG == get_config()
    assert DEFAULT_CONFIG == get_config(DEFAULT_CONFIG)
    assert DEFAULT_CONFIG == get_config(env_var='')
    assert DEFAULT_CONFIG == get_config(default=DEFAULT_CONFIG)


# Generated at 2022-06-26 02:34:13.735344
# Unit test for function get_config
def test_get_config():
    # Mock os.environ
    import mock

    os_environ = dict()

    @mock.patch('loggingutils.os.environ', os_environ)
    def test():
        os_environ['LOGGING'] = '{"version": 1}'
        log = get_logger()
        log.debug('test')

    test()



# Generated at 2022-06-26 02:34:17.658502
# Unit test for function logger_level
def test_logger_level():
    '''
    Attempt to use logger_level as the context manager
    '''
    log = get_logger().info('Test with logger_level')
    try:
        with logger_level(log, 'INFO'):
            int_0 = -832
            var_0 = configure(int_0)
    except Exception as e:
        raise e

# Generated at 2022-06-26 02:34:30.438599
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.INFO):
        logger = get_logger()
        logger.debug("test debug")
        logger.info("test info")
        logger.warning("test warning")

    logger.debug("test debug")
    logger.info("test info")
    logger.warning("test warning")


if __name__ == '__main__':
    sys.exit(test_case_0())
    test_logger_level()

# Generated at 2022-06-26 02:34:31.904304
# Unit test for function configure
def test_configure():
    logger.info('Testing configure')
    var_0 = configure()
    assert var_0



# Generated at 2022-06-26 02:34:34.926754
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.CRITICAL):
        assert logger.level == logging.CRITICAL


# Generated at 2022-06-26 02:34:36.258457
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        assert log.getEffectiveLevel() == logging.DEBUG



# Generated at 2022-06-26 02:34:42.962564
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger('testlogger')
    logger.setLevel(logging.DEBUG)

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)

    with logger_level(logger, logging.INFO):
        logger.debug('Should not get logged')
        logger.info('Should get logged')
        with logger_level(logger, logging.DEBUG):
            logger.debug('Should get logged')
    logger.debug('Should get logged')


# Generated at 2022-06-26 02:34:44.468813
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logger, level):
        assert level == 'DEBUG'
        return



# Generated at 2022-06-26 02:34:54.764535
# Unit test for function logger_level
def test_logger_level():
    # initialize log
    configure()
    logger = get_logger()

    # assert INFO level
    assert logger.isEnabledFor(logging.INFO)

    # change level to DEBUG
    with logger_level(logger, logging.DEBUG):
        assert logger.isEnabledFor(logging.DEBUG)
        assert not logger.isEnabledFor(logging.INFO)

    # change level to WARN
    with logger_level(logger, logging.WARN):
        assert logger.isEnabledFor(logging.WARN)
        assert not logger.isEnabledFor(logging.INFO)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    logger = get_logger()
    # test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:34:57.714318
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger()
    var_0 = test_logger.level
    var_0 = logger_level(test_logger, var_0)
    var_0.next()
    var_0.close()

# Generated at 2022-06-26 02:34:59.057706
# Unit test for function logger_level
def test_logger_level():
    import logging_utils
    assert logger_level


test_case_0()
test_logger_level()

# Generated at 2022-06-26 02:35:01.598180
# Unit test for function get_config
def test_get_config():
    assert get_config('{}','LOGGING',DEFAULT_CONFIG) == ({}, 'LOGGING', DEFAULT_CONFIG)




# Generated at 2022-06-26 02:35:17.036012
# Unit test for function logger_level
def test_logger_level():
    int_0 = -832
    var_0 = configure(int_0)
    int_1 = -832
    int_2 = False
    int_3 = False
    str_0 = logger_level(int_1, int_2, int_3)



# Generated at 2022-06-26 02:35:22.975634
# Unit test for function logger_level
def test_logger_level():
    try:
        with logger_level(getLogger(), 0):
            logger_level(getLogger(), 0)
        with logger_level(get_logger(), 0):
            testCase_0()
    except Exception:
        import sys, traceback
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_tb(exc_traceback, limit=1, file=sys.stdout)
        traceback.print_exception(exc_type, exc_value, exc_traceback,
                              limit=2, file=sys.stdout)



# Generated at 2022-06-26 02:35:35.853350
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    from logging import getLogger
    from time import time

    log = getLogger('test logger_level')

    result = []

    @contextmanager
    def test_logger_level_func_0(logger, level):
        """Set logger level to `level` within a context block. Don't use this except for debugging please, it's gross."""
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    result_0 = -892
    result_0 = configure(result_0)
    result_1 = log
    result_2 = '%'
    result_2 = result_2 % str(0)
    result.append(result_2)
    print(result)


# Generated at 2022-06-26 02:35:38.313600
# Unit test for function logger_level
def test_logger_level():
    # I'm not actually sure how to test a context manager.
    assert True


# Generated at 2022-06-26 02:35:47.180600
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    configure()
    
    with logger_level(log, logging.INFO):
        log.debug('This message should not show')
        log.info('This message should show')
        log.warning('This message should show')
        log.error('This message should show')
        log.critical('This message should show')
        
    log.debug('This message should show')
    log.info('This message should show')
    log.warning('This message should show')
    log.error('This message should show')
    log.critical('This message should show')
    print("test_logger_level clear...")


# Generated at 2022-06-26 02:35:50.901806
# Unit test for function logger_level
def test_logger_level():
    import pytest
    with pytest.raises(NameError):
        with logger_level(var_0, 1):
            var_0 = test_case_0()


# Generated at 2022-06-26 02:35:58.011713
# Unit test for function logger_level
def test_logger_level():
    int_0 = -3230
    int_1 = -7632
    int_2 = -9075
    int_3 = -5705
    int_4 = -18267

    # Test Function signature
    logger_level(int_0, int_1)

    # Test local names exists
    assert locals().get('int_0')
    assert locals().get('int_1')
    assert locals().get('int_2')
    assert locals().get('int_3')
    assert locals().get('int_4')
    assert locals().get('int_5')
    assert locals().get('int_6')
    assert locals().get('int_7')
    assert locals().get('int_8')
    assert locals().get('int_9')
    assert locals().get('int_10')