

# Generated at 2022-06-26 02:26:08.850848
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager

    def get_logger(name=None):
        if not name:
            name = 'test_module_name'
        return logging.getLogger(name)

    @contextmanager
    def logger_level(logger, level):
        """Set logger level to `level` within a context block. Don't use this except for debugging please, it's gross."""
        initial = logger.level
        logger.level = level
        try:
            yield
        finally:
            logger.level = initial

    # Test body
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        pass

if __name__ == '__main__':
    logging.basicConfig()
    test_case_0()

# Generated at 2022-06-26 02:26:19.470752
# Unit test for function configure
def test_configure():

    # This function sets the attributes of the instance calling it from the
    # passed arguments.
    #
    def set_attrs(arg_0, arg_1, arg_2):
        arg_0.__dict__.update({'var_0': arg_1,
                               'var_1': arg_2})

    # Create a named instance to be used as a function closure.
    #
    test_instance = _PyInfo()
    # This function is to be used within a with statement.
    #
    def test_func():
        set_attrs(test_instance,
                  'value_0',
                  'value_1')

        # Assert that the instance attribute has been modified.
        #
        assert 'cfg_0' in test_instance.__dict__

    # Instantiate a class from type()
    #


# Generated at 2022-06-26 02:26:25.625387
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger("test_logger_level")
    with logger_level(logger, logging.INFO):
        pass
    with logger_level(logger, logging.DEBUG):
        pass


if __name__ == '__main__':
    configure()

    logger = get_logger()

    logger.debug("debug")
    logger.info("info")
    logger.error('error')

    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:26:31.951920
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger('test')
    expect_logger_level = logging.INFO
    with logger_level(test_logger, expect_logger_level):
        expect_logger_level_str = logging.getLevelName(test_logger.level)
        assert test_logger.level == expect_logger_level
        assert expect_logger_level_str == 'INFO'

# Generated at 2022-06-26 02:26:38.185109
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    level = logging.DEBUG
    with logger_level(logger, level) as returned:
        assert logger.level == level


if __name__ == '__main__':
    if sys.argv[-1] == 'test_case_0':
        test_case_0()
    elif sys.argv[-1] == 'test_logger_level':
        test_logger_level()

# Generated at 2022-06-26 02:26:46.565581
# Unit test for function logger_level
def test_logger_level():
    logger_0 = get_logger('test_logger_level')
    with logger_level(logger_0, logging.ERROR):
        logger_0.info('This should not print')
        logger_0.warning('This should not print')
        logger_0.error('This should print')
    # This should print
    logger_0.info('This should print')


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:26:49.076275
# Unit test for function logger_level
def test_logger_level():
    _ensure_configured()
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug t')
        logger.info('info t')
        logger.warning('warning t')
        logger.error('error t')
        logger.critical('critical t')
        logger.debug('debug t')
        logger.info('info t')



# Generated at 2022-06-26 02:26:52.179690
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logger.level
    with logger_level(logger=logger, level=logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == level


# Generated at 2022-06-26 02:26:56.877114
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.ERROR):
        assert log.getEffectiveLevel() == logging.ERROR
    assert log.getEffectiveLevel() == logging.DEBUG


# Generated at 2022-06-26 02:26:59.800047
# Unit test for function logger_level
def test_logger_level():
    with logger_level(logging, 10):
        # logging.log(10, 'Test')
        pass


# Generated at 2022-06-26 02:27:13.635796
# Unit test for function logger_level

# Generated at 2022-06-26 02:27:21.360688
# Unit test for function logger_level
def test_logger_level():
    class CaptureHandler(logging.Handler):
        def __init__(self, *args, **kwargs):
            super(CaptureHandler, self).__init__(*args, **kwargs)
            self.records = []

        def emit(self, record):
            self.records.append(record)

    logger = get_logger()
    handler = CaptureHandler()
    logger.addHandler(handler)
    with logger_level(logger, logging.INFO):
        logger.debug('test')
        assert not handler.records
        logger.info('test')
        assert handler.records



# Generated at 2022-06-26 02:27:23.568040
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.ERROR) as _:
        get_logger().info('test')
        get_logger().error('test_error')

# Generated at 2022-06-26 02:27:25.474668
# Unit test for function get_config
def test_get_config():
    """
    >>> import json
    >>> config = json.dumps({'version': 1,})
    >>> config = get_config(config)
    >>> config['version']
    1
    """
    pass

# Generated at 2022-06-26 02:27:29.790369
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(inspect.stack()[0][3])
    initial_level = logger.level
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == initial_level


if __name__ == '__main__':
    import nose

    nose.main()

# Generated at 2022-06-26 02:27:40.482559
# Unit test for function logger_level
def test_logger_level():
    import sys
    import logging
    import logging.config
    import logging.handlers
    import socket
    import time

    import colorlog

    logging.captureWarnings(True)

    configure()

    # set up logger
    logger = logging.getLogger('foo')
    logger.setLevel(logging.INFO)
    # set up console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter('[%(asctime)s] %(name)s - %(levelname)s - %(message)s')
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    logger.addHandler(ch)


# Generated at 2022-06-26 02:27:49.296987
# Unit test for function configure

# Generated at 2022-06-26 02:27:54.503477
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logging.INFO
    pre = logger_level(logger, level)
    print(logger.level)
    assert logger.level == level

if __name__ == "__main__":
    # test_case_0()
    # test_logger_level()
    main()

# Generated at 2022-06-26 02:27:55.907197
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), logging.DEBUG):
        assert getLogger().level == logging.DEBUG
    assert getLogger().level == logging.NOTSET

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:27:56.828469
# Unit test for function configure
def test_configure():
    var_1 = configure()


# Generated at 2022-06-26 02:28:11.756903
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("fake logger")
    with logger_level(logger, logging.ERROR):
        pass
    assert logger.level == logging.ERROR


if __name__ == '__main__':
    import traceback

    try:
        config = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'logging_config.json')
    except TypeError:
        config = ''

    configure(config or None)
    log = get_logger(__name__)
    # log.error("an error message")
    # log.info("a info message")
    # log.warning("a warning message")
    # log.critical("a critical message")
    # log.exception("a exception message")
    # log.debug("a debug message")

    test_

# Generated at 2022-06-26 02:28:22.911819
# Unit test for function configure
def test_configure():
    # Test string
    try:
        configure('some')
    except ValueError as exc:
        if 'Invalid logging config: some' not in str(exc):
            raise AssertionError('{} is wrong'.format(exc))

    # Test dict
    try:
        configure(dict())
    except TypeError as exc:
        if "Logger.manager must be a LogManager instance" not in str(exc):
            raise AssertionError('{} is wrong'.format(exc))

    # Test json string

# Generated at 2022-06-26 02:28:31.151266
# Unit test for function logger_level
def test_logger_level():
    import unittest
    import StringIO
    import sys

    class MockLogger(object):
        def __init__(self):
            self.level = None

    class CaptureOutput(list):
        def __enter__(self):
            self._stdout = sys.stdout
            self._stringio = StringIO.StringIO()
            sys.stdout = self._stringio
            return self

        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            sys.stdout = self._stdout
            self._stringio.close()

    class Test(unittest.TestCase):
        def test_0(self):
            logger = MockLogger()
            with CaptureOutput() as output:
                with logger_level(logger, 10):
                    pass



# Generated at 2022-06-26 02:28:34.644815
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.NOTSET



# Generated at 2022-06-26 02:28:43.656362
# Unit test for function get_config
def test_get_config():
    dict_config = dict(version=1,
                       disable_existing_loggers=True,
                       formatters={
                           'standard': {
                               'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
                           },
                       },
                       handlers={
                           'default': {
                               'level': 'DEBUG',
                               'formatter': 'standard',
                               'class': 'logging.StreamHandler',
                           },
                       },
                       loggers={
                           '': {
                               'handlers': ['default'],
                               'level': 'INFO',
                               'propagate': True
                           }
                       })


# Generated at 2022-06-26 02:28:46.904831
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.CRITICAL):
        get_logger().debug("This should not be printed")
    get_logger().debug("This should be printed")



# Generated at 2022-06-26 02:28:49.231778
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.WARN):
        assert log.level == logging.WARN



# Generated at 2022-06-26 02:29:01.009372
# Unit test for function logger_level

# Generated at 2022-06-26 02:29:11.218497
# Unit test for function configure
def test_configure():
    # Basic immediate configuration
    cfg = dict(basicConfig=dict(filename='bacon', format='%(asctime)s'))
    configure(cfg)
    log = get_logger()
    assert log.handlers[0].formatter._fmt == '%(asctime)s'

    # JSON configuration
    cfg = json.dumps(dict(basicConfig=dict(filename='bacon', format='%(name)s')))
    configure(cfg)
    log = get_logger()
    assert log.handlers[0].formatter._fmt == '%(name)s'

    # Env config
    env_var = 'LOGGING'
    cfg = json.dumps(dict(basicConfig=dict(filename='bacon', format='%(name)s')))

# Generated at 2022-06-26 02:29:14.296903
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    var_1 = 'info'
    # test logger_level
    with logger_level(var_0, var_1):
        var_0.info('Test Log')
    var_0.info('Test Log')

# Generated at 2022-06-26 02:29:32.141369
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    assert logger.level == logging.DEBUG

    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO

    assert logger.level == logging.DEBUG


# Generated at 2022-06-26 02:29:41.475034
# Unit test for function logger_level
def test_logger_level():
    from contextlib import contextmanager
    import logging
    import logging.config


# Generated at 2022-06-26 02:29:48.538443
# Unit test for function get_config
def test_get_config():
    print(__name__ + ' test_get_config')
    import json
    import yaml
    a = json.dumps(DEFAULT_CONFIG)
    b = yaml.dump(DEFAULT_CONFIG)
    c = DEFAULT_CONFIG

    ad = get_config(given=a)
    bd = get_config(given=b)
    cd = get_config(given=c)

    assert ad == bd == cd, "json, yaml, and object versions of DEFAULT_CONFIG should be equivalent"



# Generated at 2022-06-26 02:29:59.846155
# Unit test for function get_config
def test_get_config():
    print('Running test: test_get_config')
    print('')

    config_json = '{"invalid_key": "invalid_value"}'
    config_yaml = '\n'.join(['level: ERROR', 'invalid_key: invalid_value'])
    config_bare = (
        'key1: value1 '
        'key2: value2 '
        # 'invalid_key: invalid_value'
    )

    assert get_config(config_json) == {'invalid_key': 'invalid_value'}
    assert get_config(config_yaml) == {'level': 'ERROR', 'invalid_key': 'invalid_value'}
    assert get_config(config_bare) == {'key1': 'value1', 'key2': 'value2'}

   

# Generated at 2022-06-26 02:30:01.145918
# Unit test for function logger_level
def test_logger_level():
    import logging

    logger = logging.getLogger()
    level = logging.DEBUG
    with logger_level(logger, level):
        assert logger.level == level
    assert logger.level != level



# Generated at 2022-06-26 02:30:02.801092
# Unit test for function get_config
def test_get_config():
    """
    Testing get_config, this test case tests 
    """
    # Check if all the input variables are of correct type
    assert type(get_config(None, "LOGGING", DEFAULT_CONFIG)) == dict, 'The return type is not dict'



# Generated at 2022-06-26 02:30:11.827990
# Unit test for function get_config
def test_get_config():
    # Case 1:
    # config = None
    # env_var = None
    # default = None
    # Expected: ValueError
    try:
        get_config()
    except ValueError:
        pass
    else:
        raise AssertionError("'config' is None, 'env_var' is None and 'default' is None. Expected: ValueError")

    # Case 2:
    # config = None
    # env_var = None
    # default = DEFAULT_CONFIG
    # Expected: config = DEFAULT_CONFIG
    assert get_config(None, None, DEFAULT_CONFIG) == DEFAULT_CONFIG

    # Case 3:
    # config = None
    # env_var = 'LOGGING'
    # default = DEFAULT_CONFIG
    # Expected: config = DE

# Generated at 2022-06-26 02:30:13.323872
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(), logging.ERROR):
        test_case_0()

# Generated at 2022-06-26 02:30:15.815293
# Unit test for function get_config
def test_get_config():
    config = get_config(default={'version': 1})
    assert config == {'version': 1}


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:30:19.673157
# Unit test for function get_config
def test_get_config():
    assert get_config("{}") == {}
    assert get_config("[1, 2, 3]") == [1, 2, 3]
    assert get_config("") is None
    assert get_config("{'foo': 'bar'}") == {'foo': 'bar'}



# Generated at 2022-06-26 02:30:58.852954
# Unit test for function logger_level
def test_logger_level():
    for logger_name in ["a", "b", "c"]:
        logger_entry = logging.getLogger(logger_name)

        logger_entry.setLevel(logging.DEBUG)
        with logger_level(logger_entry, logging.DEBUG):
            assert logger_entry.level == logging.DEBUG
            logger_entry.debug("Hello, world!")

        logger_entry.setLevel(logging.INFO)
        with logger_level(logger_entry, logging.DEBUG):
            assert logger_entry.level == logging.DEBUG
            logger_entry.debug("Hello, world!")

        logger_entry.setLevel(logging.WARNING)
        with logger_level(logger_entry, logging.DEBUG):
            assert logger_entry.level == logging.DEBUG
            logger_entry.debug("Hello, world!")



# Generated at 2022-06-26 02:31:04.266568
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(logger_level.__name__)
    log.info('start')
    with logger_level(log, logging.DEBUG):
        log.debug('should be seen')
    log.info('should be seen')
    log.info('end')



# Generated at 2022-06-26 02:31:10.261374
# Unit test for function logger_level
def test_logger_level():
    import time
    import timeit
    import logging
    l = logging.getLogger()
    l.setLevel(logging.INFO)

    def func_case_0():
        for i in range(1000000):
            var_0 = i
            l.info(str(i))

    def func_case_1():
        for i in range(1000000):
            var_0 = i
            l.debug(str(i))

    # time stamp to collect time
    time_0 = time.time()
    func_case_0()
    time_1 = time.time()
    print('func_case_0 time: {}'.format(time_1 - time_0))

    time_2 = time.time()
    func_case_1()
    time_3 = time.time()

# Generated at 2022-06-26 02:31:17.019943
# Unit test for function logger_level
def test_logger_level():
    # import json
    # print(get_config())
    # print(json.dumps(DEFAULT_CONFIG, indent=2))

    import logging
    import logging.config

    log = logging.getLogger(__name__)
    configure()
    test_string = "This is a test."
    with logger_level(log, logging.DEBUG):
        log.debug("Debug message")
        log.info("Information message")
        log.error("Error message")
        log.info(test_string)



# Generated at 2022-06-26 02:31:26.232496
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    import shutil
    # get temp directory
    test_dir = tempfile.mkdtemp()
    # create logger
    logger = logging.getLogger('logger_level')
    logger.setLevel(logging.DEBUG)
    # create file handler
    fh = logging.FileHandler(test_dir + '/logger_level.log')
    fh.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    # add handler to logger
    logger.addHandler(fh)

    with logger_level(logger, logging.WARNING):
        logger.debug('debug message')
        logger

# Generated at 2022-06-26 02:31:35.459247
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger('test_logger_level')
    logger.info('logger_level: enter')

    with logger_level(logger, logging.WARNING):
        logger.warning('logger_level: warning')
        logger.error('logger_level: error')

        with logger_level(logger, logging.ERROR):
            logger.warning('logger_level: warning')
            logger.error('logger_level: error')

        logger.warning('logger_level: warning')
        logger.error('logger_level: error')

    logger.info('logger_level: exit')



# Generated at 2022-06-26 02:31:43.350067
# Unit test for function configure
def test_configure():
    # default
    configure()
    logger = get_logger()
    assert logger.getEffectiveLevel() == logging.DEBUG

    # string
    cfg = '''
        version: 1
        root:
            level: DEBUG
        handlers:
            console:
                class: logging.StreamHandler
                level: DEBUG
    '''

    configure(config=cfg)
    logger = get_logger()
    assert logger.getEffectiveLevel() == logging.DEBUG

    # dict

# Generated at 2022-06-26 02:31:48.282352
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG

if __name__ == '__main__':
    var_0 = test_case_0()

    var_1 = test_logger_level()

# Generated at 2022-06-26 02:31:57.167190
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.INFO):
        logger.info('INFO')
        logger.debug('DEBUG: should not appear')
    logger.info('back to INFO')
    logger.debug('back to DEBUG')


if __name__ == "__main__":
    logging.config.fileConfig('structlog.conf')
    logging.basicConfig()
    import doctest

    doctest.testmod()
    test_logger_level()

# Generated at 2022-06-26 02:32:00.706701
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('tests')
    with logger_level(logger, logging.INFO):
        assert logger.getEffectiveLevel() == logging.INFO
    assert logger.getEffectiveLevel() == logging.NOTSET
    # raise Exception('Test fails')


# Generated at 2022-06-26 02:33:12.912583
# Unit test for function logger_level
def test_logger_level():
    logger_1 = get_logger()
    with logger_level(logger_1, logging.WARNING):
        logger_1.warning('test')
        logger_1.info('test')
    logger_1.info('test')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:33:22.640738
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.CRITICAL):
        logger.info('this should be hidden')
    logger.info('this should be shown')
    with logger_level(logger, logging.DEBUG):
        logger.info('this should be shown')
        with logger_level(logger, logging.INFO):
            logger.info('this should be shown')
        logger.info('this should be shown')
    logger.info('this should be shown')
    # TODO: assert that each log message was printed


# Generated at 2022-06-26 02:33:26.108575
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    log.info('test')
    with logger_level(log, logging.DEBUG):
        log.debug('hah?')
    log.info('test2')



# Generated at 2022-06-26 02:33:33.759988
# Unit test for function get_config

# Generated at 2022-06-26 02:33:40.868989
# Unit test for function logger_level
def test_logger_level():
    from StringIO import StringIO
    var_2 = StringIO()
    var_3 = logging.StreamHandler(var_2)
    var_4 = get_logger()
    var_4.handlers = [var_3]
    with logger_level(var_4, logging.CRITICAL):
        var_4.info('test')
        assert "test" not in var_2.getvalue()
    var_4.info('test')
    assert "test" in var_2.getvalue()

# Generated at 2022-06-26 02:33:51.617772
# Unit test for function logger_level

# Generated at 2022-06-26 02:33:56.125529
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    with logger_level(var_0, logging.CRITICAL):
        pass


# Generated at 2022-06-26 02:34:05.735525
# Unit test for function logger_level
def test_logger_level():
    test_logger = get_logger('logger_level')
    levels = {
        'DEBUG' : logging.DEBUG,
        'INFO' : logging.INFO,
        'WARNING' : logging.WARNING,
        'ERROR' : logging.ERROR,
        'CRITICAL' : logging.CRITICAL
    }

    for level_1 in levels:
        for level_2 in levels:
            with logger_level(test_logger, levels[level_1]):
                test_logger.info('level_1 (before): ' + level_1)
                if levels[level_1] > levels[level_2]:
                    test_logger.info('level_2 (inside): ' + level_2)
                test_logger.info('level_1 (after): ' + level_1)


# Generated at 2022-06-26 02:34:08.045465
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()

    with logger_level(logger, 5):
        assert logger.level == 5

    assert logger.level == 0



# Generated at 2022-06-26 02:34:13.850886
# Unit test for function logger_level
def test_logger_level():
    test_logger = logging.getLogger()
    with logger_level(test_logger, logging.INFO):
        assert test_logger.getEffectiveLevel() == logging.INFO
    assert test_logger.getEffectiveLevel() != logging.INFO


if __name__ == "__main__":
    test_logger_level()

    import doctest

    doctest.testmod()