

# Generated at 2022-06-26 02:26:07.254435
# Unit test for function logger_level
def test_logger_level():
    getLogger('test_logger_level').setLevel(logging.DEBUG)
    py_info_0 = _PyInfo()
    logger = getLogger('test_logger_level')
    # logger_level should return a context manager
    cm = logger_level(logger, logging.DEBUG)
    # context manager should have a __enter__ method
    assert hasattr(cm, '__enter__')
    # context manager should have a __exit__ method
    assert hasattr(cm, '__exit__')

    # logger level should be DEBUG after entering the context manager
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
    # logger level should be DEBUG after exiting the context manager
    assert logger.getEffectiveLevel() == logging.DEBUG



# Generated at 2022-06-26 02:26:18.686459
# Unit test for function get_config
def test_get_config():
    logger = get_logger()
    logger.debug("Test case for function get_config")
    # Test case where config is a string
    # Test case where config is a json string
    config = "{'test':'test'}"
    logger.debug("Testing for json string: %s" % config)
    cfg = get_config(config)
    if isinstance(cfg,dict):
        logger.debug("Test case passed")
    else:
        logger.error("Test case failed")
    # Test case where config is a yaml string
    logger.debug("Testing for yaml string: %s" % config)
    config = "test:test"
    cfg = get_config(config)
    if isinstance(cfg,dict):
        logger.debug("Test case passed")

# Generated at 2022-06-26 02:26:26.440674
# Unit test for function logger_level
def test_logger_level():
    from pytest import raises
    from unittest import mock
    from logging import DEBUG, INFO

    logger = mock.Mock()

    # dummy example test
    with raises(AttributeError):
        with logger_level(logger, DEBUG):
            logger.bad_attribute

    # assert logger level set/restored
    with logger_level(logger, INFO):
        assert logger.level == INFO
    assert logger.level == DEBUG

    # logger error should be logged at INFO
    with logger_level(logger, INFO):
        logger.error("log at INFO level")
    assert logger.log.call_args[0] == (INFO, "log at INFO level")



# Generated at 2022-06-26 02:26:35.709767
# Unit test for function logger_level
def test_logger_level():
    name='foo'
    root_logger = logging.getLogger(name)
    # logger should have a level of NOTSET
    assert root_logger.level == logging.NOTSET, "logger.level is not logging.NOTSET"
    # set level to INFO
    root_logger.level = logging.INFO
    with logger_level(logger=root_logger, level=logging.DEBUG):
        assert root_logger.level == logging.DEBUG, "logger.level is not logging.DEBUG"
    assert root_logger.level == logging.INFO, "logger.level is not logging.INFO"


# Generated at 2022-06-26 02:26:47.769509
# Unit test for function configure
def test_configure():
    # Test function configure when called with no arguments.
    # No exception should be raised by calling configure().
    # config = None
    env_var = None

    import json
    import logging
    import sys

    if sys.version_info[0] == 2:
        import yaml
    else:
        import yaml_27 as yaml
    config = None
    cfg = get_config(config, env_var, DEFAULT_CONFIG)
    assert cfg == DEFAULT_CONFIG
    # Test function configure when called with arguments config and env_var
    # Test function configure when called with arguments config and env_var
    # and default.

# Generated at 2022-06-26 02:26:53.797265
# Unit test for function logger_level
def test_logger_level():
    # Given
    root_logger = logging.getLogger()
    root_logger_level = root_logger.level
    root_logger.handlers = []

    level = logging.ERROR

    # When
    with logger_level(root_logger, level):
        assert root_logger.level == level

    # Then
    assert root_logger.level == root_logger_level


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:26:58.180556
# Unit test for function logger_level
def test_logger_level():
        with logger_level(getLogger(), logging.CRITICAL):
                logger = getLogger()
                logger.error('A critical error message!')


if __name__ == '__main__':
    # test_logger_level()
    pass

# Generated at 2022-06-26 02:27:01.532578
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('foo')

    with logger_level(logger, logging.FATAL):
        logger.debug('Should be silenced.')

    logger.debug('Debug should work')


# Generated at 2022-06-26 02:27:11.853107
# Unit test for function logger_level
def test_logger_level():
    from io import StringIO
    import sys
    import logging

    test_logger = logging.getLogger('test_logger')
    test_logger.setLevel(logging.ERROR)

    test_output = StringIO()
    stream_handler = logging.StreamHandler(test_output)
    test_logger.addHandler(stream_handler)


    assert_0 = 'No test output written'
    assert_1 = 'Test output written'

    test_logger.info('test message')

    assert test_output.getvalue() == assert_0


    with logger_level(test_logger, logging.INFO):
        test_logger.info('test message')
        assert test_output.getvalue() == assert_1

    test_logger.info('test message')
    assert test_output.getvalue

# Generated at 2022-06-26 02:27:16.243860
# Unit test for function logger_level
def test_logger_level():
    log = get_logger('test_logger_level')

    with logger_level(log, logging.INFO):
        log.info('logging1')
        log.warn('logging2')

    log.info('logging3')
    log.warn('logging4')



# Generated at 2022-06-26 02:27:33.180181
# Unit test for function logger_level
def test_logger_level():
    import logging
    import pytest
    from contextlib import contextmanager

    from .log_utils import logger_level
    from .log_utils import configure
    configure()
    log = logging.getLogger(__name__)

    def log_to_debug_context():
        with logger_level(log, logging.DEBUG):
            log.debug('test')

    def log_to_info_context():
        with logger_level(log, logging.INFO):
            log.debug('test')

    # FIXME: Fluke?
    # The following assertion fails sometimes.
    # Therefore this test is skipped in the CI.
    pytest.skip("This test is skipped because it fails sometimes")

    # logger level is DEBUG
    # assert log.level == logging.DEBUG
    # no WARNING log should be displayed
    log_to_debug_

# Generated at 2022-06-26 02:27:37.357122
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level >= logging.DEBUG
    assert logger.level < logging.DEBUG

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:27:41.671314
# Unit test for function logger_level
def test_logger_level():
    l = get_logger('test_logger_level')

    with logger_level(l, logging.DEBUG):
        assert l.level == logging.DEBUG
        l.info('test_logger_level: Tests if logger_level is working')
    assert l.level != logging.DEBUG


# Generated at 2022-06-26 02:27:44.703769
# Unit test for function configure
def test_configure():
    # test for function configure
    # print('Testing for function configure:')

    configure()
    logger = logging.getLogger()
    # print(logger.level)
    assert logger.level == logging.DEBUG



# Generated at 2022-06-26 02:27:48.934242
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    initial = logger.level
    assert(logger.level == logging.DEBUG)
    with logger_level(logger, logging.ERROR):
        assert(logger.level == logging.ERROR)
    assert(logger.level == initial)


# Generated at 2022-06-26 02:27:59.346305
# Unit test for function configure

# Generated at 2022-06-26 02:28:06.336812
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    log.setLevel(logging.CRITICAL)
    log.debug("Dummy debug test")
    log.info("Dummy info test")
    with logger_level(log, logging.DEBUG):
        log.debug("hello")
        log.info("This critically should not be shown")

if __name__ == '__main__':
    test_case_0()
    test_logger_level()
    configure()

# Generated at 2022-06-26 02:28:13.308003
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    configure()
    with logger_level(log, logging.DEBUG):
        log.debug('debug')
        log.info('info')
        log.warn('warn')
        with logger_level(log, logging.INFO):
            log.debug('debug')
            log.info('info')
            log.warn('warn')
        log.debug('debug')
        log.info('info')
        log.warn('warn')
    log.debug('debug')
    log.info('info')
    log.warn('warn')

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# def test_case_1():
#     py_info_1 = _PyInfo()
#
#     # test att

# Generated at 2022-06-26 02:28:19.355337
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    with logger_level(logger, logging.WARN):
        logger.debug('debug message') # Should print nothing
        logger.warn('warning message') # Should print warning message
    logger.debug('debug message') # Should print debug message

if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:28:24.072151
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.WARN):
        logger.debug('this should not be visible')
    logger.info('this should be visible')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:28:50.727752
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger()
    assert logger.level == logging.DEBUG


# Generated at 2022-06-26 02:29:02.682616
# Unit test for function get_config
def test_get_config():
    print("Test 1: no config given")
    config = get_config() 
    if config != DEFAULT_CONFIG:
        print("Test 1 failed")

    print("Test 2: config is given")
    config = get_config(default = None)
    if config != None:
        print("Test 2 failed")

    print("Test 3: env var is given")
    config = get_config(env_var='LOGGING')
    if config != DEFAULT_CONFIG:
        print("Test 3 failed")

    print("Test 4: config is given")

# Generated at 2022-06-26 02:29:05.888041
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger("test_logger_level")
    with logger_level(logger, logging.DEBUG):
        logger.debug("Setting level to debug")
    logger.info("Exiting logger_level")

# Generated at 2022-06-26 02:29:08.507462
# Unit test for function configure
def test_configure():
    logger_0 = logging.getLogger('test')
    config_0 = get_config()
    configure(config_0)
    logger_0.info('test')


# Generated at 2022-06-26 02:29:16.950051
# Unit test for function logger_level
def test_logger_level():
    import logging
    import sys

    # create logger
    logger = logging.getLogger("test-logger")
    logger.setLevel(logging.DEBUG)
    # create console handler and set level to debug
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    # add formatter to ch
    ch.setFormatter(formatter)
    # add ch to logger
    logger.addHandler(ch)

    logger.info("0. logging message with DEBUG level")

    with logger_level(logger, 10):
        logger.info("1. logging message with DEBUG level")
        logger.error

# Generated at 2022-06-26 02:29:25.991185
# Unit test for function logger_level
def test_logger_level():
    from . import logger
    import logging
    import sys

    py_info_0 = _PyInfo()

    # Test 0: Prints info message to stdout
    def test_0():
        _ensure_configured()
        logger.debug('Debug message')
        logger.info('Info message')

    # Test 1: Prints debug message to stdout
    def test_1():
        with logger_level(logger, logging.DEBUG):
            logger.debug('Debug message')
            logger.info('Info message')

    test_0()
    test_1()



__all__ = [
    'configure',
    'get_logger',
    'logger_level',
    'getLogger'
]

# Generated at 2022-06-26 02:29:33.268257
# Unit test for function logger_level
def test_logger_level():
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger("test_logger_level")
    assert logger.level == logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO

if __name__ == '__main__':
    import doctest
    print("Doctest logger.py...")
    doctest.testmod()
    print("Doctest logger_level...")
    test_logger_level()

# Generated at 2022-06-26 02:29:42.267802
# Unit test for function logger_level
def test_logger_level():
    # Capture output
    import logging
    import os
    import sys
    import tempfile

    dummy_logger = logging.getLogger(__name__)
    dummy_logger.setLevel(logging.DEBUG)
    out = tempfile.TemporaryFile(mode='w+')
    handler = logging.StreamHandler(out)
    dummy_logger.addHandler(handler)

    dummy_logger.info('test_info')
    dummy_logger.warning('test_warning')

    out.seek(0)
    assert out.readlines() == ['test_info\n', 'test_warning\n']

    # Change logging level to WARNING
    with logger_level(dummy_logger, logging.WARNING):
        dummy_logger.info('test_info')

# Generated at 2022-06-26 02:29:46.263748
# Unit test for function logger_level
def test_logger_level():
    import sys

    import pytest

    with pytest.raises(IndexError):
        logger_level(sys.stdout, None)

    with pytest.raises(AttributeError):
        with logger_level(sys.stdout, None):
            pass



# Generated at 2022-06-26 02:29:55.547984
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig(stream=sys.stdout)
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        logger.debug("debug")
        logger.info("info")
        logger.warning("warn")
        logger.error("error")
        logger.critical("critical")
        with logger_level(logger, logging.CRITICAL):
            logger.debug("debug")
            logger.info("info")
            logger.warning("warn")
            logger.error("error")
            logger.critical("critical")


if __name__ == "__main__":
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:21.036800
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG

#######
#
# main
#
#######


# Generated at 2022-06-26 02:30:27.174472
# Unit test for function logger_level
def test_logger_level():
    # Configure logging to output to console
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    # Create context manager with custom log level
    level = logging.ERROR
    with logger_level(logger, level):
        # Log message with custom log level
        logger.debug("Debug message")
        logger.info("Info message")
        logger.error("Error message")
        # Log message with initial log level
        logger.critical("Critical message")



# Generated at 2022-06-26 02:30:29.721547
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger("test_logger")
    with logger_level(logger, logging.ERROR):
        assert logger.level == logging.ERROR
    assert logger.level == logging.WARNING


# Generated at 2022-06-26 02:30:34.741510
# Unit test for function logger_level
def test_logger_level():

    logger = logging.getLogger(__name__)

    with logger_level(logger, logging.DEBUG):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")

    logger.info("After context")

# Generated at 2022-06-26 02:30:37.691407
# Unit test for function logger_level
def test_logger_level():

    log = logging.getLogger(__name__)
    initial = log.level
    assert log.level == logging.WARNING

    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG


# Generated at 2022-06-26 02:30:48.206851
# Unit test for function get_config
def test_get_config():
    config = get_config(config='{"version": 1, "formatters": {"simple": {'
                               '"format":"%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: '
                               '%(message)s @%(funcName)s:%(lineno)d #%(levelname)s","datefmt":"%Y-%m-%d %H:%M:%S"}}},'
                               '"handlers": {"console": {"class": "logging.StreamHandler","formatter": "simple",'
                               '"level": "DEBUG"}},"loggers": {"foo": {"handlers": ["console"],"level": "DEBUG",'
                               '"propagate": "no"}}}')

# Generated at 2022-06-26 02:30:53.861061
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.ERROR):
        assert log.level == logging.ERROR
    assert log.level == logging.DEBUG


if __name__ == '__main__':
    configure()
    log = get_logger(__name__)
    log.critical('critical')
    log.error('error')
    log.warning('warning')
    log.info('info')
    log.debug('debug')

# Generated at 2022-06-26 02:31:05.645745
# Unit test for function get_config

# Generated at 2022-06-26 02:31:09.485832
# Unit test for function logger_level
def test_logger_level():
    log1 = get_logger()
    with logger_level(log1,logging.CRITICAL):
        log1.error('this should be ignored')

    with logger_level(log1,logging.DEBUG):
        log1.error('this should be ignored')

# Generated at 2022-06-26 02:31:15.196997
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.INFO):
        assert logger.level == logging.INFO
    assert logger.level == logging.DEBUG


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    logging.debug("Running tests")

    test_case_0()


# vim: et:sw=4:syntax=python:ts=4:

# Generated at 2022-06-26 02:31:38.132948
# Unit test for function logger_level
def test_logger_level():
    log = getLogger()
    try:
        with logger_level(log, logging.WARNING):
            log.debug("This is a debug log")
            log.info("This is an info log")
            log.warning("This is a warning log")
            log.error("This is an error log")
            log.critical("This is a critical log")
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-26 02:31:42.310963
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    logger_level(logger, logging.WARNING)


# Generated at 2022-06-26 02:31:49.495071
# Unit test for function logger_level
def test_logger_level():
    # for py3k compat
    # log_name = inspect.currentframe(1).f_globals["__name__"]
    # TODO Does this work in both py2/3?
    log_name = inspect.stack()[2][0].f_globals["__name__"]
    log = get_logger(log_name)
    with logger_level(log, logging.INFO):
        log.info('test')
        log.debug('test')
    log.debug('test')


# Generated at 2022-06-26 02:31:56.822012
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        logger.debug('This is a debug message')
        logger.info('This is an info message')
        logger.warning('This is a warning message')
        logger.error('This is an error message')
        logger.critical('This is a critical message')

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:32:05.945488
# Unit test for function logger_level
def test_logger_level():
    test_simple_logger = logging.getLogger('test_simple_logger')
    test_simple_logger.setLevel(logging.DEBUG)
    test_simple_logger.info('Testing info log')
    test_simple_logger.debug('Testing debug log')

    with logger_level(test_simple_logger, logging.INFO):
        test_simple_logger.info('Testing info log from level INFO')
        test_simple_logger.debug('Testing debug log from level INFO')

    with logger_level(test_simple_logger, logging.DEBUG):
        test_simple_logger.info('Testing info log from level DEBUG')
        test_simple_logger.debug('Testing debug log from level DEBUG')




# Generated at 2022-06-26 02:32:11.241475
# Unit test for function logger_level
def test_logger_level():

    logging.root.handlers = []

    # Get a logger
    logger = logging.getLogger()

    # Set logger level to DEBUG and run tests
    with logger_level(logger, logging.DEBUG):

        # Log a message at DEBUG level
        logger.debug("This is a log message at level DEBUG")

    # Check if logger level was reverted
    original_logger_level = logging.root.level

    assert original_logger_level == 20

# Generated at 2022-06-26 02:32:20.641912
# Unit test for function logger_level
def test_logger_level():
    import string
    import random
    logger = get_logger(__name__)
    assert logger.name == __name__
    assert logger.level == logger.DEBUG
    test_string = "".join([random.choice(string.ascii_letters) for _ in range(32)])
    logger.info(test_string)
    with logger_level(logger, logger.WARN):
        logger.info(test_string)
        logger.error(test_string)
    logger.info(test_string)
    with logger_level(logger, logger.ERROR):
        logger.info(test_string)
        logger.error(test_string)
    logger.info(test_string)


# Generated at 2022-06-26 02:32:28.113092
# Unit test for function logger_level
def test_logger_level():
    logging.basicConfig()
    test_logger = logging.getLogger('test_logger')
    test_logger.setLevel(logging.DEBUG)
    test_logger.debug('test_logger_level')

    with logger_level(test_logger, logging.INFO):
        test_logger.debug('test_logger_level')
        test_logger.info('test_logger_level')

    test_logger.debug('test_logger_level')
    test_logger.info('test_logger_level')



# Generated at 2022-06-26 02:32:31.393000
# Unit test for function logger_level
def test_logger_level():
    """
    >>> log = logging.getLogger(__name__)
    >>> with logger_level(log, logging.DEBUG):
    ...     log.debug("Test")
    """
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:32:38.406651
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.WARNING):
        log.info('%s', 'info')
        log.debug('%s', 'debug')

    log.info('%s', 'info')


if __name__ == '__main__':
    configure()
    log = get_logger()
    log.info('test!')

    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:33:00.259477
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level != logging.DEBUG


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:33:11.592572
# Unit test for function get_config
def test_get_config():
    """Test whether the configuration of the logger can be loaded from a dict and a string"""
    import json
    import yaml

# Generated at 2022-06-26 02:33:13.580820
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    with logger_level(log, logging.DEBUG):
        log.debug("Debug message")
        log.info("Info message")



# Generated at 2022-06-26 02:33:15.715815
# Unit test for function logger_level
def test_logger_level():
    """
    >>> log = get_logger()
    >>> log.info('test')

    >>> with logger_level(log, logging.ERROR):
    ...     log.info('test info level')
    """
    pass

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:33:24.876402
# Unit test for function logger_level
def test_logger_level():

    # test code
    # FIXME Disabled test, this depends on get_logger and configure
    return

    logger = get_logger()

    with logger_level(logger, logging.ERROR):
#        logging.debug('test')
        logger.debug('test')
        logger.info('test')
        logger.warning('test')
        logger.error('test')
        logger.critical('test')

    logger.info('test')
    logger.error('test')
    return 0



# Generated at 2022-06-26 02:33:31.752870
# Unit test for function get_config
def test_get_config():
    cfg = get_config(default = {'handlers': {'console': {'level': 'INFO'}}, 'root': {'handlers': ['console'], 'level': 'INFO'}})
    assert cfg['handlers']['console']['level'] == 'INFO'

if __name__ == '__main__':
    # For a full test suite, see `tests/`
    import pytest

    DIR = os.path.dirname(os.path.realpath(__file__))
    pytest.main(['-v', DIR])

# Generated at 2022-06-26 02:33:36.430400
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test')
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET



# Generated at 2022-06-26 02:33:43.298184
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger("logger_level_test")
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.NOTSET


# Generated at 2022-06-26 02:33:52.476343
# Unit test for function logger_level
def test_logger_level():
    import sys
    import io
    import logging
    logger = logging.getLogger()
    logger.level = logging.INFO
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.info("test_logger_level") 

    with logger_level(logging.getLogger(), logging.DEBUG):
        logger.debug("test_logger_level")

    assert "DEBUG" in stream.getvalue()
    stream.close()

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:34:02.944833
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger("test_logger_level")

    # Set logger level to DEBUG
    with logger_level(logger, logging.DEBUG):
        assert logger.getEffectiveLevel() == logging.DEBUG
        logger.debug("Debug")
        logger.info("Info")
        logger.warning("Warning")
        logger.error("Error")

    # Set logger level to WARNING
    with logger_level(logger, logging.WARNING):
        assert logger.getEffectiveLevel() == logging.WARNING
        logger.debug("Debug")
        logger.info("Info")
        logger.warning("Warning")
        logger.error("Error")

# Define unittests

# Generated at 2022-06-26 02:34:34.468658
# Unit test for function get_config
def test_get_config():
    # Testing for when config is None, env_var is None, and default is None
    config = None
    env_var = None
    default = None
    try:
        get_config(config, env_var, default)
    except ValueError as err:
        assert(str(err) == "Invalid logging config: None")
    
    # Testing for when config is not None, env_var is None, and default is None
    config = {"version":1}
    env_var = None
    default = None
    try:
        get_config(config, env_var, default)
    except ValueError as err:
        assert(False)
        
    # Testing for when config is str, env_var is None, and default is None
    config = '{"version":1}'
    env_var = None
    default = None

# Generated at 2022-06-26 02:34:40.120117
# Unit test for function logger_level
def test_logger_level():
    try:
        from io import StringIO as StringIO
    except ImportError:
        from StringIO import StringIO

    max_log_level = logging.CRITICAL
    logger = get_logger(__name__)
    assert 'get_logger_level' not in logger.__dict__
    logger.get_logger_level = lambda: max_log_level

    # set level to max
    with logger_level(logger, max_log_level) as level:
        assert level is None
        assert logger.get_logger_level() == max_log_level

    # set level to max
    with logger_level(logger, max_log_level):
        assert logger.get_logger_level() == max_log_level

    log_output = StringIO()

# Generated at 2022-06-26 02:34:43.204578
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    level = logging.INFO
    with logger_level(logger, level) as l:
        assert logger.level == level


# Generated at 2022-06-26 02:34:53.718243
# Unit test for function get_config
def test_get_config():
    import logging
    import json
    import yaml
    config = get_config(None, 'LOGGING', None)
    logging.config.dictConfig(config)


# Generated at 2022-06-26 02:34:57.975448
# Unit test for function logger_level
def test_logger_level():
    log1 = getLogger("abc")
    print("Before context, the level of logger is: {}".format(log1.level))
    with logger_level(log1, logging.DEBUG):
        print("Within context, the level of logger is: {}".format(log1.level))
    print("After context, the level of logger is: {}".format(log1.level))



# Generated at 2022-06-26 02:35:03.392556
# Unit test for function configure
def test_configure():
    import subprocess
    import os
    # test for logging.config
    with subprocess.Popen('python -m logging.config -c "dictConfig(config=DEFAULT_CONFIG)"'.format(dictConfig=logging.config.dictConfig), stdout=subprocess.PIPE) as process:
        assert process.stdout.read().decode('utf-8') == '\n'
    # test for logging
    with subprocess.Popen('python -m logging -p "{key}:{value}"'.format(key='logging', value=DEFAULT_CONFIG), stdout=subprocess.PIPE) as process:
        assert process.stdout.read().decode('utf-8') == '\n'


# Generated at 2022-06-26 02:35:05.769852
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.INFO):
        logger.setLevel(logging.ERROR)
    assert logger.level == logging.ERROR



# Generated at 2022-06-26 02:35:09.980544
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    with logger_level(log, logging.DEBUG):
        log.info('this should print')

    with logger_level(log, logging.CRITICAL):
        log.info('this should NOT print')



# Generated at 2022-06-26 02:35:20.110142
# Unit test for function get_config
def test_get_config():
    import json
    import yaml

    assert get_config({}) == {}
    assert get_config('{}') == {}
    assert get_config('[]') == []

    assert get_config('{"foo": "bar"}') == {'foo': 'bar'}
    assert get_config('["foo", "bar"]') == ['foo', 'bar']
    assert get_config('a') == 'a'
    assert get_config(1) == 1
    assert get_config(1.0) == 1.0
    assert get_config(True) is True
    assert get_config(False) is False
    assert get_config(None) is None

    try:
        get_config('{')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-26 02:35:23.867854
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger()
    with logger_level(logger, logging.DEBUG):
        logger.debug('logging.DEBUG')
        logger.info('logging.INFO')
        logger.warning('logging.WARNING')
        logger.error('logging.ERROR')
        logger.critical('logging.CRITICAL')

# TODO test_case_1, test_case_2, ...
