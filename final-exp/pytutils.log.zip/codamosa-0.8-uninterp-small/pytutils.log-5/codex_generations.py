

# Generated at 2022-06-26 02:26:02.670637
# Unit test for function logger_level
def test_logger_level():
    logger = logging.Logger('test_logger')
    level = logging.CRITICAL
    with logger_level(logger, level):
        assert logger.level == level
    assert logger.level == logging.NOTSET


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:26:10.930628
# Unit test for function configure
def test_configure():
    s_list = []

    def record_stream(stream):
        buf = stream.getvalue()
        stream.truncate(0)
        stream.seek(0)
        s_list.append(buf)


# Generated at 2022-06-26 02:26:19.742977
# Unit test for function get_config
def test_get_config():
    test_string = "test_string"
    test_dict = {'test_dict': test_string}
    test_json = json.dumps(test_dict)
    test_yaml = yaml.safe_dump(test_dict)
    assert get_config(test_string) == test_string
    assert get_config(test_dict) == test_dict
    assert get_config(test_json) == test_dict
    assert get_config(test_yaml) == test_dict

    try:
        expected = {}
        get_config(None)
        assert False, "Expected ValueError to be raised for None"
    except ValueError:
        pass

    try:
        get_config("")
        assert False, "Expected ValueError to be raised for empty string"
    except ValueError:
        pass

# Generated at 2022-06-26 02:26:25.091286
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert log.level == logging.DEBUG
    with logger_level(log, logging.INFO):
        assert log.level == logging.INFO
    assert log.level == logging.DEBUG

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:26:31.198164
# Unit test for function get_config
def test_get_config():
    assert get_config(1) == 1
    assert get_config(env_var='NOT_ME', default=1) == 1
    assert get_config(default=1) == 1
    assert get_config(config=1, env_var='NOT_ME', default=2) == 1

    import yaml

    yaml_cfg = yaml.dump(dict(a=1))
    assert get_config(config=yaml_cfg) == {'a': 1}

    json_cfg = '{"a": 1}'
    assert get_config(config=json_cfg) == {'a': 1}

    with pytest.raises(ValueError):
        get_config(config='nope')



# Generated at 2022-06-26 02:26:36.370194
# Unit test for function configure
def test_configure():
    """Test configure()"""
    # setup
    config = DEFAULT_CONFIG
    env_var = 'LOGGING'
    default = DEFAULT_CONFIG

    # Test for correct exceptions
    with raises(TypeError):
        configure(config=config)

    # Test for correct output
    configure(config=config, env_var=env_var, default=default)


# Generated at 2022-06-26 02:26:37.386612
# Unit test for function get_config
def test_get_config():
    assert type(get_config()) is dict

# Generated at 2022-06-26 02:26:44.271003
# Unit test for function logger_level
def test_logger_level():
    """
    >>> logger = get_logger('foo.bar')
    >>> logger.warning('x')
    >>> with logger_level(logger, logging.CRITICAL):
    ...     logger.warning('x')
    >>> logger.warning('x')

    """
    pass


_logger = get_logger(__name__)
_LOGGER = getLogger(__name__)



# Generated at 2022-06-26 02:26:47.708815
# Unit test for function logger_level
def test_logger_level():

    unit_test_logger = get_logger()
    logger_level(unit_test_logger, "DEBUG")
    assert unit_test_logger.level == logging.DEBUG



# Generated at 2022-06-26 02:26:56.095017
# Unit test for function logger_level
def test_logger_level():
    import io
    import logging
    import sys
    import unittest
    import warnings

    class TestClass(unittest.TestCase):
        @staticmethod
        def _test_case_0():
            pass

        def setUp(self):
            self.capture = io.StringIO()
            self.stream = sys.stderr
            self.handler = logging.StreamHandler(self.capture)
            logger = logging.getLogger()
            logger.addHandler(self.handler)

        def tearDown(self):
            for handler in logging.getLogger().handlers:
                logging.getLogger().removeHandler(handler)
            sys.stderr = self.stream

        def test_logger_level(self):
            with logger_level(logging.getLogger(), logging.ERROR):
                logging

# Generated at 2022-06-26 02:27:07.005026
# Unit test for function logger_level
def test_logger_level():
    """Test doc-string for logger_level
       :param:
       :return:
       :rtype:
    """
    logger = get_logger('test_logger')
    with logger_level(logger, 10):
        logger.debug('before')
        logger.info('before')
        logger.warn('before')
    logger.debug('after')
    logger.info('after')
    logger.warn('after')


if __name__ == "__main__":

    import doctest

    doctest.test_case_0()
    doctest.test_logger_level()

# Generated at 2022-06-26 02:27:09.379794
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(), logging.INFO):
        assert get_logger().level == logging.INFO
    assert get_logger().level == logging.DEBUG



# Generated at 2022-06-26 02:27:17.081368
# Unit test for function logger_level
def test_logger_level():
    logger_0 = get_logger()
    logger_0_initial_level = logger_0.level
    logger_0.level = logging.NOTSET
    with logger_level(logger_0, logging.WARN):
        logger_0.debug('debug message.')
        logger_0.info('info message.')
        logger_0.warn('warn message.')
        logger_0.error('error message.')
        logger_0.critical('critical message.')
    assert logger_0.level == logging.NOTSET



# Generated at 2022-06-26 02:27:25.954510
# Unit test for function logger_level
def test_logger_level():
    # Set up loggers
    root_logger = get_logger()
    root_logger.setLevel(logging.CRITICAL)
    logger = get_logger('zappa')
    logger.setLevel(logging.INFO)
    root_logger.info("This is a message")
    logger.info("This is a message")
    logger.debug("This is a message")

    # Before context manager, check levels
    assert root_logger.level == logging.CRITICAL
    assert logger.level == logging.INFO

    # In the context manager, set level to DEBUG
    with logger_level(logger, logging.DEBUG):
        assert root_logger.level == logging.CRITICAL
        assert logger.level == logging.DEBUG

    # After the context block, check levels
    assert root_logger.level

# Generated at 2022-06-26 02:27:33.341790
# Unit test for function logger_level
def test_logger_level():
    import io

    handler = io.StringIO()
    logger = get_logger(__name__)

    logger.addHandler(logging.StreamHandler(handler))

    with logger_level(logger, logging.DEBUG):
        logger.info('123')
    assert handler.getvalue().strip() == '123'

    handler.close()

    handler = io.StringIO()
    logger.addHandler(logging.StreamHandler(handler))

    with logger_level(logger, logging.CRITICAL):
        logger.info('456')
    assert not handler.getvalue().strip()



# Generated at 2022-06-26 02:27:41.607379
# Unit test for function logger_level
def test_logger_level():
    import io
    curr_out = sys.stdout
    sys.stdout = io.StringIO()
    import logging
    logger = logging.getLogger('logger_level_test')
    logger.setLevel(logging.INFO)
    logger.info('001')
    with logger_level(logger, logging.DEBUG):
        logger.debug('002')
    logger.info('003')

    test_result = sys.stdout.getvalue()
    sys.stdout = curr_out
    assert test_result == '001\n002\n003\n'

# Generated at 2022-06-26 02:27:49.747752
# Unit test for function logger_level
def test_logger_level():
    import pytest
    import os
    import subprocess
    import logging
    import logging.config


# Generated at 2022-06-26 02:27:53.721524
# Unit test for function configure
def test_configure():
    """

    >>> log = get_logger()
    >>> with logger_level(log, logging.ERROR):
    ...    log.info('test')
    ...    configure()
    ...    log.info('test')

    """



# Generated at 2022-06-26 02:27:56.997374
# Unit test for function logger_level
def test_logger_level():
    logger_test = logging.getLogger("test_logger")
    assert(logger_test.level == 20)
    with logger_level(logger_test, 10):
        assert(logger_test.level == 10)

# Generated at 2022-06-26 02:28:00.637840
# Unit test for function logger_level
def test_logger_level():
    #arrange
    logger = logging.getLogger()
    initial_level = logger.level
    new_level = logging.DEBUG
    result = None
    #act
    with logger_level(logger, new_level):
        result = logger.level
    #assert
    assert initial_level == logger.level
    assert result == new_level


# Generated at 2022-06-26 02:28:05.294044
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.DEBUG):
        # assert logger.level == logging.DEBUG
        assert logger.level == logging.DEBUG

# Generated at 2022-06-26 02:28:07.538271
# Unit test for function logger_level
def test_logger_level():
    with logger_level(get_logger(__name__), logging.ERROR):
        get_logger(__name__).info('should not show')
        get_logger(__name__).error('error')

    get_logger(__name__).info('should show')



# Generated at 2022-06-26 02:28:12.537891
# Unit test for function logger_level
def test_logger_level():
    # Set up
    logger = get_logger()
    initial = logger.level
    level = logging.ERROR

    # Execute
    with logger_level(logger, level):
        assert logger.level == level

    # Cleanup
    logger.level = initial
    assert logger.level == initial



# Generated at 2022-06-26 02:28:18.700428
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger('test_logger_level')
    logger.setLevel(logging.INFO)
    assert logger.level == logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO

if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:28:22.285118
# Unit test for function logger_level
def test_logger_level():
    var_0 = get_logger()
    with logger_level(var_0, 20):
        var_0.log(21, "Test Message")
    var_0.log(20, "Test Message")


# Generated at 2022-06-26 02:28:30.434520
# Unit test for function logger_level
def test_logger_level():
    import tempfile
    fd, fname = tempfile.mkstemp()
    os.close(fd)
    try:
        with open(fname, "w") as f:
            handler = logging.StreamHandler(f)
            handler.setFormatter(DEFAULT_CONFIG['formatters']['simple'])
            log = logging.getLogger(__name__)
            log.addHandler(handler)
            log.setLevel(logging.DEBUG)
            with logger_level(log, logging.DEBUG):
                log.debug("test")
            log.debug("test")

        with open(fname) as f:
            assert f.read() == "test\n"
    finally:
        os.remove(fname)

# Generated at 2022-06-26 02:28:37.410792
# Unit test for function logger_level
def test_logger_level():
    logger = getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')
    with logger_level(logger, logging.INFO):
        logger.debug('debug message')
        logger.info('info message')
        logger.warning('warning message')
        logger.error('error message')
        logger.critical('critical message')


# Generated at 2022-06-26 02:28:47.146265
# Unit test for function get_config
def test_get_config():
    cfg = get_config(config='{"version": 1}')
    assert cfg['version'] == 1

    cfg = get_config(config='{"version": 2}', default={"version": 1})
    assert cfg['version'] == 2

    os.environ['LOGGING'] = '{"version": 3}'
    cfg = get_config(env_var='LOGGING')
    assert cfg['version'] == 3
    del os.environ['LOGGING']

    cfg = get_config(default={"version": 1})
    assert cfg['version'] == 1


if __name__ == '__main__':
    test_case_0()
    test_get_config()

# Generated at 2022-06-26 02:28:51.352801
# Unit test for function get_config
def test_get_config():
    config = get_config()
    assert(config == DEFAULT_CONFIG)

    config = get_config(config = '{"test":"test"}')
    assert(config == {"test":"test"})

    with pytest.raises(ValueError):
        config = get_config(config = "test")


# Generated at 2022-06-26 02:29:03.324897
# Unit test for function get_config
def test_get_config():
    assert isinstance(get_config(), dict)
    assert get_config('{"version": 1, "disable_existing_loggers": false, "formatters": {"": {"": ""}, "": {"": "", "datefmt": ""}}, "handlers": {"": {"class": "", "formatter": "", "level": ""}}, "root": {"handlers": [""], "level": ""}, "loggers": {"": {"": ""}}}'), dict

# Generated at 2022-06-26 02:29:13.657253
# Unit test for function logger_level
def test_logger_level():
    var_2 = getLogger()
    var_3 = logging.DEBUG
    with logger_level(var_2, var_3):
        var_4 = var_2.debug('This is a message')



# Generated at 2022-06-26 02:29:14.665634
# Unit test for function get_config
def test_get_config():
    config = get_config()
    assert config != None


# Generated at 2022-06-26 02:29:24.173972
# Unit test for function logger_level
def test_logger_level():
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.CRITICAL):
      logger.error('Error')
      logger.critical('Critical')
      logger.info('Info')
      logger.debug('Debug')


if __name__ == '__main__':
    logger = logging.getLogger(__name__)
    logger.setLevel('DEBUG')
    ch = logging.StreamHandler()
    ch.setLevel('DEBUG')
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # logger.debug('debug message')
    # logger.info('info message')
    # logger.warning('warn

# Generated at 2022-06-26 02:29:29.435798
# Unit test for function logger_level
def test_logger_level():
    import logging
    logger = logging.getLogger()
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.WARNING


if __name__ == "__main__":
    import sys
    import doctest

    argv = sys.argv[:]
    argv.append("--verbose")
    doctest.testmod(argv=argv)

# Generated at 2022-06-26 02:29:34.331524
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger(__name__)

    with logger_level(logger, 0):
        assert logger.level == 0

    assert logger.level == 10

if __name__ == "__main__":
    logging.getLogger().setLevel(logging.DEBUG)

    # test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:29:36.798058
# Unit test for function configure
def test_configure():
    configure()
    logging.info('test')


if __name__ == '__main__':
    # test_case_0()
    test_configure()

# Generated at 2022-06-26 02:29:43.397538
# Unit test for function get_config
def test_get_config():
    # Test default configuration
    assert isinstance(get_config(None, None, DEFAULT_CONFIG), dict)
    # Should provide a config or env_var or default
    try:
        cfg = get_config(None, None, None)
    except ValueError:
        assert True
    else:
        assert False, "Shouldn't reach here"
    # Test get configuration from os.environ
    assert isinstance(get_config(None, "LOGGING", DEFAULT_CONFIG), dict)
    # Test get configuration from config file
    assert isinstance(get_config(DEFAULT_CONFIG, None, None), dict)


# Generated at 2022-06-26 02:29:48.256176
# Unit test for function logger_level
def test_logger_level():
    dummy_logger = getLogger('test_0')
    level = dummy_logger.level

    with logger_level(dummy_logger, logging.ERROR):
        assert dummy_logger.level == logging.ERROR
    assert dummy_logger.level == level

if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:29:59.592096
# Unit test for function logger_level
def test_logger_level():
    import logging
    import tempfile
    import contextlib

    fd, path = tempfile.mkstemp()
    fp = os.fdopen(fd, 'w')

# Generated at 2022-06-26 02:30:04.877605
# Unit test for function logger_level
def test_logger_level():
    with logger_level(getLogger(__name__), logging.DEBUG) as logger:
        logging.debug("This should be printed")
        logger.debug("This should be printed")
    logging.info("This should not be printed")
    assert True == True


if __name__ == '__main__':
    test_case_0()
    test_logger_level()

# Generated at 2022-06-26 02:30:18.016897
# Unit test for function configure
def test_configure():
    pass


# Generated at 2022-06-26 02:30:20.755584
# Unit test for function logger_level
def test_logger_level():
    import time
    import logging
    import logging.config
    logger = logging.getLogger(__name__)
    with logger_level(logger, logging.DEBUG):
        logger.debug('foo')


# Generated at 2022-06-26 02:30:26.912145
# Unit test for function get_config
def test_get_config():
  json_sample = '{"version":1,"disable_existing_loggers":false,"formatters":{"simple_formatter":{"format":"%(asctime)s| %(name)s/%(processName)s[%(process)d]-%(threadName)s[%(thread)d]: %(message)s @%(funcName)s:%(lineno)d #%(levelname)s","datefmt":"%Y-%m-%d %H:%M:%S"}},"handlers":{"console":{"class":"logging.StreamHandler","formatter":"simple_formatter","level":10}},"root":{"handlers":["console"],"level":10},"loggers":{"requests":{"level":20}}}'

# Generated at 2022-06-26 02:30:33.068290
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    print(logger.level)
    with logger_level(logger, logging.INFO):
        print(logger.level)
    print(logger.level)
    #print(logger)
    #print(logger.handlers)
    logger.debug('Test debug')
    logger.info('Test info')
    logger.warn('Test warn')
    logger.error('Test error')
    logger.critical('Test critical')


# Generated at 2022-06-26 02:30:36.161264
# Unit test for function logger_level
def test_logger_level():
    l = get_logger('test')

    @logger_level(l, logging.INFO)
    def t():
        l.info('t')
        l.debug('t')

    t()
    l.info('t')



# Generated at 2022-06-26 02:30:37.727675
# Unit test for function logger_level

# Generated at 2022-06-26 02:30:41.903866
# Unit test for function get_config
def test_get_config():
    # Negative test case.
    config = None
    env_var = None
    default = None
    try:
        get_config(config, env_var, default)
    except ValueError:
        pass

if __name__ == "__main__":
    test_case_0()
    test_get_config()

# Generated at 2022-06-26 02:30:48.312398
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    log.setLevel(logging.DEBUG)
    with logger_level(log, logging.INFO):
        log.debug("this log message should not appear")
        log.info("This log message should not appear")
        log.error("This log message should appear")
    log.debug("This log message should appear")
    # Test end

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-26 02:30:52.921178
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger()

    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level != logging.DEBUG


__all__ = (
    "DEFAULT_CONFIG",
    "configure",
    "get_config",
    "get_logger",
    "logger_level",
)

# Generated at 2022-06-26 02:30:55.365603
# Unit test for function logger_level
def test_logger_level():
    logging.debug("testing logger_level")
    with logger_level(logging, logging.WARNING):
        assert logging.getLogger().getEffectiveLevel() == logging.WARNING


# Generated at 2022-06-26 02:31:35.896814
# Unit test for function logger_level
def test_logger_level():
    from unittest import TestCase
    from nose.tools import assert_equal
    from random import random
    from logging import DEBUG
    from logging import INFO
    from logging import WARNING
    logging_names = [
        'logging.critical',
        'logging.error',
        'logging.warning',
        'logging.info',
        'logging.debug',
    ]

    class Test(TestCase):
        def __init__(self, *args, **kwargs):
            self.logger_name = str(int(random() * 1E13))
            super(Test, self).__init__(*args, **kwargs)

        def setUp(self):
            configure()
            self._logger = logging.getLogger(self.logger_name)

        def get_logger(self):
            return

# Generated at 2022-06-26 02:31:39.829566
# Unit test for function logger_level
def test_logger_level():
    log = getLogger("logger_level")
    with logger_level(log, logging.ERROR):
        assert log.level == logging.ERROR, "logger level incorrectly changed"
    assert log.level == logging.DEBUG, "logger level not set to previous state ("+str(log.level)+")"



# Generated at 2022-06-26 02:31:43.180737
# Unit test for function configure
def test_configure():
    # Configure the default logger
    config = configure()

    # Call configure again to trigger an assertion
    config = configure()

    assert True


# Generated at 2022-06-26 02:31:48.720785
# Unit test for function logger_level
def test_logger_level():
    logger1 = get_logger()
    logger1.info('Not enough')
    with logger_level(logger1, logging.WARN):
        logger1.debug('Not enough')
        logger1.warn('Enough')
        logger1.error('Enough')
    logger1.info('Enough')


if __name__ == '__main__':
    test_logger_level()

# Generated at 2022-06-26 02:31:51.886868
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()
    assert log.level != logging.DEBUG
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG
    assert log.level != logging.DEBUG



# Generated at 2022-06-26 02:32:02.694969
# Unit test for function logger_level
def test_logger_level():
    test_log = get_logger()
    log_levels = [logging.NOTSET, logging.DEBUG, logging.INFO]
    for test_level in log_levels:
        with logger_level(test_log, test_level):
            assert_equal(test_log.level, test_level)
            test_log.info('test_info')
            test_log.debug('test_debug')
            test_log.warn('test_warn')
            test_log.error('test_error')
            test_log.critical('test_critical')
            test_log.log(1, 'test_log')
            test_log.log(2, 'test_log')
            test_log.log(3, 'test_log')
            test_log.log(4, 'test_log')

# Generated at 2022-06-26 02:32:09.056340
# Unit test for function logger_level
def test_logger_level():
    import io
    import mock
    import os
    import sys
    from contextlib import contextmanager

    # Create a patched stdout
    stdout_patcher = mock.patch('sys.stdout', new_callable=io.StringIO)
    patched_stdout = stdout_patcher.start()

    # Now all calls to sys.stdout.write, sys.stdout.flush, and sys.stdout.close, are redirected to patched_stdout
    # Determine whether the original flush method is available
    flush_available = bool(getattr(sys.stdout, 'flush', None))

    # Print something to stdout. It should be redirected to patched_stdout now
    print('hello')

    # Assert what's been printed
    assert patched_stdout.getvalue() == 'hello\n'

    # Reset stdout

# Generated at 2022-06-26 02:32:13.933901
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    initial = logger.level
    logger.level = logging.INFO
    assert logger.level == logging.INFO
    with logger_level(logger, logging.DEBUG):
        assert logger.level == logging.DEBUG
    assert logger.level == logging.INFO
    logger.level = initial

if __name__ == "__main__":
    test_logger_level()

# Generated at 2022-06-26 02:32:23.658144
# Unit test for function logger_level
def test_logger_level():
    root_logger = get_logger()
    with logger_level(root_logger, logging.WARN):
        root_logger.info("some message")
        child_logger = get_logger("logger_level")
        with logger_level(child_logger, logging.DEBUG):
            child_logger.info("some message")
    assert len(root_logger.handlers) == 1
    logger_handler = root_logger.handlers[0]
    assert len(logger_handler.buffer) == 1
    assert logger_handler.buffer[0].getMessage().endswith("some message")


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:32:29.174857
# Unit test for function logger_level
def test_logger_level():
    var_1 = logging.root
    var_2 = logger_level(var_1, logging.DEBUG)
    var_3 = isinstance(var_2, ContextManager)
    var_4 = var_3 is True
    var_5 = logger_level(var_1, logging.DEBUG)
    var_6 = isinstance(var_5, ContextManager)
    var_7 = var_6 is True


# Generated at 2022-06-26 02:33:33.799036
# Unit test for function logger_level
def test_logger_level():
    import sys
    import logging
    from colorlog import ColoredFormatter
    logger = logging.getLogger(__name__)

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(ColoredFormatter(
        '%(asctime)s %(name)s %(levelname)s %(message)s',
        datefmt='%H:%M:%S',
        reset=True,
        log_colors={
            'DEBUG': 'cyan',
            'INFO': 'green',
            'WARNING': 'yellow',
            'ERROR': 'red',
            'CRITICAL': 'red,bg_white',
        },
        secondary_log_colors={},
        style='%'
    ))
    logger.addHandler(handler)

# Generated at 2022-06-26 02:33:42.732490
# Unit test for function logger_level
def test_logger_level():
    import unittest
    from contextlib import redirect_stdout

    class LoggerLevelTest(unittest.TestCase):

        def test_one(self):
            logger = logging.getLogger()
            logger.setLevel(logging.DEBUG)
            temporary_level = logging.CRITICAL
            with logger_level(logger, temporary_level):
                self.assertEqual(logger.getEffectiveLevel(), temporary_level)
                logger.debug('not going to see this since my level is'
                             'temporarily set to {}'.format(temporary_level))

            self.assertEqual(logger.getEffectiveLevel(), logging.DEBUG)
            with redirect_stdout(sys.stdout):
                logger.debug('going to see this since my level is {}'.format(logging.DEBUG))

# Generated at 2022-06-26 02:33:45.477604
# Unit test for function logger_level
def test_logger_level():
    log = get_logger(__name__)
    with logger_level(log, logging.DEBUG):
        # TODO
        pass



# Generated at 2022-06-26 02:33:46.743337
# Unit test for function get_config
def test_get_config():
    config = get_config()
    assert isinstance(config, dict)


# Generated at 2022-06-26 02:33:53.980536
# Unit test for function get_config

# Generated at 2022-06-26 02:33:57.710605
# Unit test for function logger_level
def test_logger_level():
    logger = get_logger()
    with logger_level(logger, logging.CRITICAL):
        logger.critical('critical')
    logger.critical('critical')


# Generated at 2022-06-26 02:34:07.466300
# Unit test for function logger_level
def test_logger_level():
    log = get_logger()

    # check if the logger has the level of INFO by default
    assert log.level == logging.INFO, "The level of logger was not INFO"
    # Test if setting level to CRITICAL
    with logger_level(log, logging.CRITICAL):
        assert log.level == logging.CRITICAL, "The level of logger was not CRITICAL"
    # Test if setting level to DEBUG
    with logger_level(log, logging.DEBUG):
        assert log.level == logging.DEBUG, "The level of logger was not DEBUG"
    # Test if setting level to ERROR
    with logger_level(log, logging.ERROR):
        assert log.level == logging.ERROR, "The level of logger was not ERROR"
    # Test if setting level to WARNING

# Generated at 2022-06-26 02:34:11.205035
# Unit test for function logger_level
def test_logger_level():
    log = logging.getLogger(__name__)
    with logger_level(log, logging.ERROR):
        log.debug('test')

    log.debug('test')


# Generated at 2022-06-26 02:34:12.098363
# Unit test for function configure
def test_configure():
    configure()



# Generated at 2022-06-26 02:34:20.110702
# Unit test for function logger_level
def test_logger_level():
    import logging
    from logging import Handler, StreamHandler
    from mock import patch

    with patch.object(StreamHandler, 'emit'):
        logger = logging.getLogger('test')
        with logger_level(logger, logging.DEBUG):
            logger.info('test')
            # test DEBUG log is emitted
            assert StreamHandler.emit.called
    with patch.object(StreamHandler, 'emit'):
        logger = logging.getLogger('test')
        with logger_level(logger, logging.INFO):
            logger.debug('test')
            # test DEBUG log is not emitted
            assert not StreamHandler.emit.called


if __name__ == '__main__':
    import sys
