

# Generated at 2022-06-25 14:16:30.497795
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Create a VariableManager object to test
    variable_manager_0 = VariableManager()
    # Set some value for the variables, to be used for testing
    variable_manager_0._vars_cache['host_0'] = dict()
    variable_manager_0._vars_cache['host_0']['hostvars'] = dict()
    variable_manager_0._vars_cache['host_0']['hostvars']['varname_0'] = 'value_0'
    # Create a dict object to be used for testing
    value_1 = dict()
    value_1['value_1'] = 'value_1'
    value_1['value_2'] = 'value_2'
    # Call the method

# Generated at 2022-06-25 14:16:32.214989
# Unit test for constructor of class VariableManager
def test_VariableManager():
    test_case_0()

if __name__ == '__main__':
    test_VariableManager()

# Generated at 2022-06-25 14:16:35.881838
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_1 = VariableManager()
    host = 'localhost'
    facts = {'fact1': 'value1'}
    variable_manager_1.set_nonpersistent_facts(host, facts)
    assert variable_manager_1._nonpersistent_fact_cache[host] == facts


# Generated at 2022-06-25 14:16:36.838226
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test for case 0
    test_case_0()

# Generated at 2022-06-25 14:16:43.466570
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test cases for method get_vars of class VariableManager
    # Setup
    variable_manager_0 = VariableManager()

    # Test #0
    if variable_manager_0.get_vars() is not None:
        raise AssertionError("get_vars #0 failed")

    # Test #1
    if not isinstance(variable_manager_0.get_vars(), dict):
        raise AssertionError("get_vars #1 failed")


# Generated at 2022-06-25 14:16:55.109495
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()  # TODO: Get the vars_cache from the variable_manager
    host_name = "test_host"

# Generated at 2022-06-25 14:17:00.716214
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    host_0 = Mock()
    varname_0 = Mock()
    value_0 = Mock()
    variable_manager_0.set_host_variable(host_0, varname_0, value_0)


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    #test_case_0()
    #test_VariableManager_set_host_variable()

# Generated at 2022-06-25 14:17:08.190649
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()
    variable_manager_1 = VariableManager()
    variable_manager_1.add_globals({"INVENTORY_HOSTS": "localhost"})

    variable_manager_2 = VariableManager()
    variable_manager_2.add_globals({"INVENTORY_HOSTS": "localhost"})
    variable_manager_2.add_globals({"INVENTORY_HOSTS": "localhost, 127.0.0.1"})

    variable_manager_3 = VariableManager()
    variable_manager_3.add_globals({"INVENTORY_HOSTS": "localhost, 127.0.0.1"})

# Generated at 2022-06-25 14:17:12.456532
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    host = '127.0.0.1'
    facts = dict()
    variable_manager_0.set_host_facts(host, facts)
    results = variable_manager_0.get_host_facts(host)
    assert results == facts


# Generated at 2022-06-25 14:17:19.583370
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_variable('host_0', None, None)
    variable_manager_0.set_host_variable('host_1', None, None)
    variable_manager_0.set_host_variable('host_2', None, None)
    variable_manager_0.set_host_variable('host_3', None, None)
    variable_manager_0.set_host_variable('host_4', None, None)
    variable_manager_0.set_host_variable('host_5', None, None)
    variable_manager_0.set_host_variable('host_6', None, None)
    variable_manager_0.set_host_variable('host_7', None, None)
    variable_manager_0.set_host_variable

# Generated at 2022-06-25 14:18:10.733046
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    hostname = 'localhost'

# Generated at 2022-06-25 14:18:12.431175
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()


# Generated at 2022-06-25 14:18:23.157114
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager()
    # test case 1: Argument test
    try:
        variable_manager_1.set_host_variable(host=None, varname="test_variable", value=1)
    except TypeError as e:
        print("TypeError: %s" % e)
    else:
        print("failed")

    # test case 2: Argument test
    try:
        variable_manager_1.set_host_variable(host="test_host", varname=None, value=1)
    except TypeError as e:
        print("TypeError: %s" % e)
    else:
        print("failed")

    # test case 3: Argument test

# Generated at 2022-06-25 14:18:24.927883
# Unit test for constructor of class VariableManager
def test_VariableManager():
    test_case_0()
    pass

if __name__ == "__main__":
    test_VariableManager()

# Generated at 2022-06-25 14:18:26.947878
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    assert 'omit' in variable_manager.get_vars()
    assert 'omit' in variable_manager.get_vars(play=None)
    assert 'omit' in variable_manager.get_vars(play=None, task=None)

# Generated at 2022-06-25 14:18:33.126921
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()

    set_host_facts_host_0 = 'host_0'
    set_host_facts_facts_0 = 'facts_0'
    variable_manager_0.set_host_facts(set_host_facts_host_0, set_host_facts_facts_0)

if __name__ == '__main__':
    test_case_0()
    test_VariableManager_set_host_facts()

# Generated at 2022-06-25 14:18:41.838158
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    host_0 = 'host'
    variable_manager_0.set_host_variable(host_0, 'foo', 'bar')
    print(variable_manager_0._vars_cache[host_0]['foo'] == 'bar')
    variable_manager_0.set_host_variable(host_0, 'foo', 'baz')
    print(variable_manager_0._vars_cache[host_0]['foo'] == 'baz')
    variable_manager_0.set_host_variable(host_0, 'foo', {'a': 'b'})
    print(variable_manager_0._vars_cache[host_0]['foo'] == {'a': 'b'})


# Generated at 2022-06-25 14:18:53.026197
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    variable_manager.set_host_variable("hostA", "var1", 1)
    variable_manager.set_host_variable("hostB", "var2", 2)
    variable_manager.set_host_variable("hostA", "var3", 2)
    if variable_manager._vars_cache["hostA"]["var1"] != 1:
        raise AssertionError("The variable var1 in the hostA host is not equal to 1")
    if variable_manager._vars_cache["hostB"]["var2"] != 2:
        raise AssertionError("The variable var2 in the hostB host is not equal to 2")

# Generated at 2022-06-25 14:18:55.812748
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    host = "test"
    facts = {}
    variable_manager_0.set_host_facts(host, facts)


# Generated at 2022-06-25 14:19:04.645991
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    TODO: implement testing of facts, hostvars=False, include_delegate_to=False
    '''
    variable_manager_0 = VariableManager()
    task_0 = Task()
    play_0 = Play()
    inventory_0 = Inventory(loader=None, variable_manager=None, host_list=[])
    # There are no hosts in the inventory, so the hostvars should be {}
    variables_0 = variable_manager_0.get_vars(play=play_0, host=Host("myhost"), task=task_0,
                                              include_hostvars=True, include_delegate_to=True)
    # We currently don't know what variables are set by default
    assert variables_0 == {u'inventory_hostname': u'myhost'}


# Generated at 2022-06-25 14:19:56.480240
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    variable_manager.set_host_variable('host1', 'var1', 'value')
    assert variable_manager._vars_cache['host1']['var1'] == 'value'



# Generated at 2022-06-25 14:20:03.958467
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_nonpersistent_facts('a',{'my_secret': 'x'})
    variable_manager_0.set_nonpersistent_facts('b',{'my_secret': 'y'})
    variable_manager_0.set_nonpersistent_facts('c',{'my_secret': 'z'})

# Generated at 2022-06-25 14:20:07.470053
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    host_0 = dict()
    varname_0 = dict()
    value_0 = dict()
    variable_manager_0.set_host_variable(host_0, varname_0, value_0)



# Generated at 2022-06-25 14:20:18.632575
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    hostvars = dict()
    hostvars["glu"] = dict()
    hostvars["glu"]["ansible_lo"] = "127.0.0.1"
    hostvars["glu"]["ansible_user"] = "glu"
    hostvars["glu"]["ansible_host"] = "glu"
    hostvars["glu"]["test"] = "test"
    hostvars["glu"]["loc"] = "local"
    hostvars["glu"]["ansible_hostname"] = "glu"

    hostvars["glu-dsk"] = dict()
    hostvars["glu-dsk"]["ansible_lo"] = "127.0.0.1"

# Generated at 2022-06-25 14:20:19.653400
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()



# Generated at 2022-06-25 14:20:21.020828
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()

    assert True is True


# Generated at 2022-06-25 14:20:24.386098
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_1 = VariableManager()

    result_0_0 = variable_manager_0.get_vars()

    assert result_0_0 is not None
    assert result_0_0 is not {}

# Generated at 2022-06-25 14:20:35.437244
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    variable_manager_0._nonpersistent_fact_cache = {}
    variable_manager_0.set_nonpersistent_facts("127.0.0.1", {"ansible_virtualization_type": "123"})
    variable_manager_0.set_nonpersistent_facts("127.0.0.2", {"ansible_virtualization_type": "456"})
    assert variable_manager_0._nonpersistent_fact_cache == {"127.0.0.1": {"ansible_virtualization_type": "123"},
                                                            "127.0.0.2": {"ansible_virtualization_type": "456"}}
    del variable_manager_0

test_case_0() # Calling Unit test case method
test_VariableManager_set_nonpersistent

# Generated at 2022-06-25 14:20:44.703391
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    host_name_0 = 'ansible'

# Generated at 2022-06-25 14:20:50.155413
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test case 0
    variable_manager_0 = VariableManager()
    host_0 = Host()
    variable_manager_0.get_vars(host=host_0)

    # Test case 1
    variable_manager_0 = VariableManager()
    host_0 = Host()
    variable_manager_0.get_vars(host=host_0, play=None, _hosts_all=None, _hosts=None, include_delegate_to=True)

    # Test case 2
    variable_manager_0 = VariableManager()
    host_0 = Host()
    variable_manager_0.get_vars(host=host_0, play=None, _hosts_all=None, _hosts=None, include_delegate_to=False)

    # Test case 3

# Generated at 2022-06-25 14:21:41.450759
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    Test VariableManager.get_vars()
    '''
    variable_manager = VariableManager()
    # Need to create a basic host object, as the VariableManager class
    # expects to be provided with a host object.
    host = Host()

# Generated at 2022-06-25 14:21:45.652491
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    host = 'host0'
    varname = 'varname0'
    value = 'value0'

    # Run the method
    variable_manager_0.set_host_variable(host, varname, value)
    # Check the results
    assert_equal(variable_manager_0._vars_cache[host][varname], value)


# Generated at 2022-06-25 14:21:53.444415
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    ## setup
    play_0 = Play.load(dict(
            name = "An empty play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = []
        ), loader=None, variable_manager=variable_manager_0)

    ## Run
    ## Test get_vars(play=play_0, host=None, task=None, include_delegate_to=False, include_hostvars=False)
    result = variable_manager_0.get_vars(play=play_0, host=None, task=None, include_delegate_to=False, include_hostvars=False)

    # assert result
    assert result == None



# Generated at 2022-06-25 14:22:02.809366
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    host_0 = Host(name='localhost')
    variable_manager_0.set_host_variable(host_0, 'inventory_hostname', 'localhost')
    variable_manager_0.set_host_variable(host_0, 'inventory_hostname_short', 'localhost')
    variable_manager_0.set_host_variable(host_0, 'groups', {'group_1':{'name': 'group_1'}})
    variable_manager_0.set_host_variable(host_0, 'group_names', ['group_1'])
    variable_manager_0.set_host_variable(host_0, 'omit', '__omit_place_holder__')

# Generated at 2022-06-25 14:22:14.382885
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_1 = VariableManager()
    variable_manager_1.set_nonpersistent_facts('localhost', {'ansible_all_ipv4_addresses': ['1.1.1.1', '2.2.2.2']})
    variable_manager_1.set_nonpersistent_facts('localhost', {'ansible_all_ipv6_addresses': ['2001::4860:4860::8888']})
    assert variable_manager_1.get_vars(host=Host('localhost'))['ansible_all_ipv4_addresses'] == ['1.1.1.1', '2.2.2.2']

# Generated at 2022-06-25 14:22:18.141389
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vm = VariableManager()
    vm.set_nonpersistent_facts('localhost', {'foo': 'bar'})
    vm.set_nonpersistent_facts('localhost', {'bar': 'baz'})
    vm.set_nonpersistent_facts('localhost', {'bar': 'fizz'})
    assert vm._nonpersistent_fact_cache['localhost'].get('foo') == 'bar'
    assert vm._nonpersistent_fact_cache['localhost'].get('bar') == 'fizz'


# Generated at 2022-06-25 14:22:29.134521
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    play_1 = MagicMock()
    host_0 = MagicMock()
    task_0 = MagicMock()
    include_delegate_to_0 = MagicMock()
    include_hostvars_0 = MagicMock()

    # call the method
    returned_variables_0 = variable_manager_0.get_vars(play_1, host_0, task_0, include_delegate_to_0, include_hostvars_0)

    # make assertions
    assert returned_variables_0 is None
    assert_equal(play_1.call_count, 0)
    assert_equal(host_0.call_count, 0)
    assert_equal(task_0.call_count, 0)

# Generated at 2022-06-25 14:22:37.424340
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    var_manager_0 = VariableManager()
    var_manager_0.set_nonpersistent_facts('foo', {'a': 'b'})
    var_manager_0.get_vars(loader=DictDataLoader({}), play=None, host=MagicMock(name='host_0'), task=MagicMock(name='task_0'))
    var_manager_0.get_vars(loader=DictDataLoader({}), play=None, host=MagicMock(name='host_0'), task=MagicMock(name='task_0'))


# Generated at 2022-06-25 14:22:38.649328
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()



# Generated at 2022-06-25 14:22:44.664984
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    host_0 = Host(name='testhost')
    task_0 = Task()
    play_0 = Play()
    assert variable_manager_0.get_vars(host=host_0, task=task_0, play=play_0) == dict()



# Generated at 2022-06-25 14:23:35.503219
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    subject = variable_manager_0.get_vars(
        host=TQM(),
        play=Play(),
        task=Task(),
        include_delegate_to=True,
        include_hostvars=True,
    )
    assert subject == dict()

# Generated at 2022-06-25 14:23:46.521819
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()

    host_0 = Host('localhost')

# Generated at 2022-06-25 14:23:51.856986
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    with pytest.raises(AnsibleAssertionError):
        variable_manager_0.get_vars(play=None, host=None, task=None)
    with pytest.raises(AnsibleAssertionError):
        variable_manager_0.get_vars(play=None, host=None, task=None, include_delegate_to=True)


# Generated at 2022-06-25 14:23:58.048471
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():

    # Declare variable_manager of class VariableManager
    variable_manager = VariableManager()

    # Declare variables for method test_set_nonpersistent_facts
    host = u'localhost'
    facts = {u'a': 3, u'b': 5}

    # Call method test_set_nonpersistent_facts
    variable_manager.set_nonpersistent_facts(host, facts)

    # Check the conditions
    if not isinstance(variable_manager._nonpersistent_fact_cache[host], dict):
        raise AssertionError("variable_manager._nonpersistent_fact_cache[host] is not a dict")


# Generated at 2022-06-25 14:24:01.505856
# Unit test for constructor of class VariableManager
def test_VariableManager():
    print('Run test_VariableManager()')
    test_case_0()

if __name__ == '__main__':
    test_VariableManager()

# Generated at 2022-06-25 14:24:05.329437
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    # this method takes 2 params and returns a dict
    # we want to check that the return type is a dict
    assert isinstance(variable_manager_1.get_vars(), dict)


# Generated at 2022-06-25 14:24:11.677403
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    variable_manager_0 = VariableManager()
    host_0 = "test_host"
    facts_0 = {"test_fact_0": "test_value_0", "test_fact_1": "test_value_1"}
    variable_manager_0.set_host_facts(host_0, facts_0)

    test_pass = True
    for k in variable_manager_0._fact_cache[host_0].keys():
        if variable_manager_0._fact_cache[host_0][k] != facts_0[k]:
            test_pass = False

    assert test_pass

    test_pass = True

# Generated at 2022-06-25 14:24:20.935404
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    variable_manager = VariableManager()

    # test_case_0 is the failed test case.
    test_case_0()

    test_case_1 = {'include_delegate_to': False,
                   'include_hostvars': True,
                   'play': None,
                   'task': None,
                   'host': None
                   }
    result_1 = variable_manager.get_vars(**test_case_1)

    # test_case_2 is the failed test case.
    test_case_2 = {'include_delegate_to': 'False',
                   'include_hostvars': True,
                   'play': None,
                   'task': None,
                   'host': None
                   }
    result_2 = variable_manager.get_vars(**test_case_2)

    # test

# Generated at 2022-06-25 14:24:30.559416
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager.set_host_variable("host1", "var1", "value1")
    variable_manager.set_host_facts("host1", {"var1": "value1", "var2": "value2"})
    variable_manager.set_nonpersistent_facts("host1", {"var3": "value3"})
    variable_manager.set_host_variable("host1", "group_names", ["group1", "group2"])
    variable_manager.set_host_variable("host1", "group_names", "value")
    variable_manager.set_host_variable("host2", "var1", "value1")
    variable_manager.set_host_facts("host2", {"var1": "value1", "var2": "value2"})
    variable

# Generated at 2022-06-25 14:24:40.589754
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    variable_manager_0._fact_cache = {}
    variable_manager_0.set_host_facts('localhost', {'ansible_user': 'root'})
    variable_manager_0.set_host_facts('localhost', {'ansible_os_family': 'test'})
    variable_manager_0.set_host_facts('localhost', {'ansible_user': 'test'})
    variable_manager_0.set_host_facts('test_hostname', {'ansible_user': 'root'})

    # Test for exception "the type of 'facts' to set for host_facts should be a Mapping but is a %s" % type(facts)
    with pytest.raises(AnsibleAssertionError):
        variable_manager_0.set_host