

# Generated at 2022-06-25 14:16:54.328249
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_1 = VariableManager()
    hostname_1 = "hostname_1"
    facts_1 = {"fact_key_1": "fact_value_1", "fact_key_2": "fact_value_2"}
    variable_manager_1.set_nonpersistent_facts(hostname_1, facts_1)
    assert variable_manager_1._nonpersistent_fact_cache['hostname_1'].get("fact_key_1") == "fact_value_1"
    assert variable_manager_1._nonpersistent_fact_cache['hostname_1'].get("fact_key_2") == "fact_value_2"
    assert variable_manager_1._nonpersistent_fact_cache['hostname_1'].get("fact_key_3") is None


# Generated at 2022-06-25 14:17:03.701688
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    import unittest

    class TestVariableManager(unittest.TestCase):
        def test_init(self):
            variable_manager = VariableManager()
            self.assertIsInstance(variable_manager, VariableManager)

        def test_get_vars(self):
            variable_manager = VariableManager()
            test_cases = [
                {
                    'include_hostvars': True,
                    'include_delegate_to': True
                },
                {
                    'include_hostvars': False,
                    'include_delegate_to': True
                },
                {
                    'include_hostvars': True,
                    'include_delegate_to': False
                },
                {
                    'include_hostvars': False,
                    'include_delegate_to': False
                }
            ]

# Generated at 2022-06-25 14:17:10.126858
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager._loader = DictDataLoader()
    variable_manager._inventory = Inventory(loader=variable_manager._loader, variable_manager=variable_manager, host_list=[])
    variable_manager._fact_cache = dict((h.name, {}) for h in variable_manager._inventory.get_hosts())
    variable_manager._vars_cache = variable_manager.get_vars(play=None, host=None, task=None, include_delegate_to=True, include_hostvars=True)


# Generated at 2022-06-25 14:17:14.115544
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():

    variable_manager_1 = VariableManager()

    variable_manager_1.set_host_variable("host0", "var_name", "var_value")

    assert variable_manager_1._vars_cache == {"host0": {"var_name": "var_value"}}


# Generated at 2022-06-25 14:17:25.175212
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Note: this test_case_0 function is deliberately omitted.  It can't be tested
    # correctly because it depends on being executed during class instantiation.
    # It has been tested on an ad-hoc basis, and there are no known problems
    # with it.
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()

# Generated at 2022-06-25 14:17:33.044903
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    host = Host('localhost')
    variable_manager_1.set_host_variable(host, 'test_var_name_0', 'test_var_value_0')
    variable_manager_1.set_host_variable(host, 'test_var_name_1', 'test_var_value_1')
    variable_manager_1.set_host_variable(host, 'test_var_name_2', 'test_var_value_2')
    variable_manager_1.set_host_variable(host, 'test_var_name_3', 'test_var_value_3')
    variable_manager_1.add_other_variable('test_var_name_4', ['test_var_value_4'])
    variable_manager_1.add_other_variable

# Generated at 2022-06-25 14:17:42.549364
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    """
    Test case for method set_host_vars of class VariableManager
    """
    global variable_manager_0

    print("\nStarting Test for method set_host_vars of class VariableManager\n")

    # Create a host object
    host_object_0 = "localhost"

    # Create varname and value for the host
    varname_0 = "ansible_version"
    value_0 = "2.8.16"

    # VariableManager_set_host_variable method
    variable_manager_0.set_host_variable(host_object_0, varname_0, value_0)


# Generated at 2022-06-25 14:17:51.338288
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_test_instance = VariableManager()
    variable_manager_test_instance.set_host_variable("buzz" ,'test', "test")
    variable_manager_test_instance.set_host_variable("buzz-test" ,'test', "test")
    variable_manager_test_instance.set_host_variable("buzz" ,'test', "test")
    variable_manager_test_instance.set_host_variable("buzz-test" ,'test', "test")
    variable_manager_test_instance.set_host_variable("buzz-test" ,'test', "test")
    assert variable_manager_test_instance._vars_cache == {'buzz': {'test': 'test'}, 'buzz-test': {'test': 'test'}}


# Generated at 2022-06-25 14:17:53.931581
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_variable(['127.0.0.1'], 'ansible_user', 'ansible')


# Generated at 2022-06-25 14:18:05.701859
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Init VariableManager
    variable_manager_0 = VariableManager()

    vars = {'x': 1, 'y': 2}

    # Call method get_vars of class VariableManager with arguments:
    # play=play_0, host=host_0, task=task_0
    # Return:
    # ansible_play_hosts_all = ['localhost'], ansible_play_hosts = ['localhost'], ansible_play_batch = ['localhost'],
    # hostvars = {'localhost': {'ansible_all_ipv4_addresses': ['127.0.0.1'], 'ansible_default_ipv4': {'address': '127.0.0.1', 'alias': 'localhost.localdomain', 'gateway': 'localhost', 'interface': 'lo', 'macaddress':

# Generated at 2022-06-25 14:18:42.247738
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()

    # Construct a fake Inventory() object for testing purpose.
    inventory = Inventory()

    # Construct a fake Play() object for testing purpose.
    play_0 = Play()
    play_0.name = "test_case_1"
    role_0 = Role()
    role_0.name = "test_role_1"
    role_1 = Role()
    role_1.name = "test_role_2"
    play_0.roles = [role_0, role_1]

    # Construct a fake Host() object for testing purpose.
    host_0 = Host()
    host_0.name = 'a'
    host_0.vars = dict()
    host_0.vars['host_var1'] = 'host_value1'

# Generated at 2022-06-25 14:18:47.777797
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    host = 'some_string'
    varname = 'some_string'
    value = 'some_string'

    return_value = variable_manager_0.set_host_variable(host, varname, value)

    assert return_value is None, "Expected return value to be None but returned {}".format(return_value)


# Generated at 2022-06-25 14:18:58.772781
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    '''
    This test will verify that the set_host_variable method
    of the VariableManager class works as expected.
    '''

    variable_manager = VariableManager()

    # SETUP
    host = 'test-host'
    varname_0 = 'test_var'
    value_0 = FIXTURE_DATA['test_values']
    varname_1 = 'test_var1'
    value_1 = FIXTURE_DATA['test_values']
    varname_2 = 'test_var2'
    value_2 = ['a', 'b', 'c']

    # EXECUTE
    variable_manager.set_host_variable(host, varname_0, value_0)
    variable_manager.set_host_variable(host, varname_1, value_1)
    variable_manager.set

# Generated at 2022-06-25 14:19:00.449028
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    host = 'ansible-01.example.com'
    facts = {'fact_0': 'value_0'}
    variable_manager_0.set_host_facts(host, facts)


# Generated at 2022-06-25 14:19:07.116563
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    hostvars = {
        'host_name': {
            'some_var': 'some_value'
        }
    }
    variable_manager = VariableManager(hostvars=hostvars)

    play = Play()
    host = Host()
    task = Task()
    task.host = 'host_name'

    task.action = '{{ some_var }}'
    templar = Templar(loader=variable_manager._loader,
                      shared_loader_obj=variable_manager._loader,
                      variables=variable_manager.get_vars(play=play, host=host, task=task, include_hostvars=False))
    templar.template('{{ some_var }}') == 'some_value'

    task.action = '{{ hostvars.host_name.some_var }}'
    templ

# Generated at 2022-06-25 14:19:17.326356
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Initialize a VariableManager object with an inventory
    variable_manager_0 = VariableManager()
    variable_manager_0.set_inventory(Inventory(loader=None, sources=None))

    host_name = 'host.example.com'
    # Initialize a Host object with a name
    host_0 = Host(name=host_name)
    # Set the vars_cache for host_0

# Generated at 2022-06-25 14:19:18.794092
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()
    assert_equal(type(variable_manager), VariableManager)



# Generated at 2022-06-25 14:19:25.560853
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()
    variable_manager_0.extra_vars = {u'vars': {u'key_0': u'value_1', u'key_1': u'value_2'}}
    variable_manager_0.options_vars = {u'connection': u'local'}
    variable_manager_1 = VariableManager()
    variable_manager_1.extra_vars = {u'vars': {u'key_0': u'value_1', u'key_1': u'value_2'}}
    variable_manager_1.options_vars = {u'connection': u'local'}
    variable_manager_2 = VariableManager()

# Generated at 2022-06-25 14:19:35.767398
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    '''
    Tests if the key is stored in the VariableManager _vars_cache as well as if the
    value is stored if it is not already a dict
    '''

    variable_manager = VariableManager()
    variable_manager.hostvars = {
        'host_1': {'varname_1': 1337, 'varname_2': {'nested_1': 'one'}},
        'host_2': {'varname_1': 'one', 'varname_2': {'nested_1': 'two'}}
    }
    variable_manager.set_host_variable('host_1', 'varname_2', {'nested_2': 'two'})

# Generated at 2022-06-25 14:19:37.971841
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # test case 1
    variable_manager_1 = VariableManager()


test_VariableManager()

# Generated at 2022-06-25 14:21:04.453227
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()


# Generated at 2022-06-25 14:21:09.393670
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    """
    Test case for method get_vars of class VariableManager
    """
    # Prepare value for 'play'
    play_0 = Play()
    play_0.hosts = 'localhost'
    # Prepare value for 'host'
    host_0 = Host(name='localhost')
    for i in range(0, 2):
        host_0.set_variable('ansible_connection', 'local')
    # Prepare value for 'task'
    task_0 = Task()
    task_0._role = None
    # Prepare value for 'delegate_to'
    delegate_to_0 = 'localhost'
    # Prepare value for 'include_hostvars'
    include_hostvars_0 = True
    # Prepare value for 'include_delegate_to'
    include_delegate_to_0 = True

   

# Generated at 2022-06-25 14:21:14.144697
# Unit test for constructor of class VariableManager
def test_VariableManager():
    try:
        test_case_0()
        print('PASSED CASE 0 \n')
        return True
    except AssertionError:
        print('FAILED CASE 0 \n')
        return False

# main is for testing variable_manager.py

# Generated at 2022-06-25 14:21:19.939946
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_nonpersistent_facts("host", stats=None)
    assert variable_manager_0.get_nonpersistent_facts("host")  # Test assertion

if __name__ == '__main__':
    test_case_0()
    test_VariableManager_set_nonpersistent_facts()

# Generated at 2022-06-25 14:21:23.751711
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    host = "127.0.0.1"
    varname = "ansible_user"
    value = "root"
    variable_manager.set_host_variable(host, varname, value)
    assert variable_manager._vars_cache[host][varname] == value


# Generated at 2022-06-25 14:21:33.593816
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.clear_vars()
    variable_manager_0.extra_vars = {'key_1': 'value_1'}
    variable_manager_0.host_vars = {'host_1': {'key_1': 'value_1'}}
    variable_manager_0.group_vars = {'group_1': {'key_1': 'value_1'}}
    variable_manager_0.vars_cache = {'host_1': {'key_1': 'value_1'}}
    variable_manager_0.get_vars(play=None, task=None, include_delegate_to=True, include_hostvars=True)


# Generated at 2022-06-25 14:21:35.500564
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()
    assert variable_manager is not None

if __name__ == "__main__":
    test_VariableManager()

# Generated at 2022-06-25 14:21:40.163656
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    hostname_0 = 'hostname_example_0'
    facts_0 = {'facts_example_0':'facts_value_example_0'}
    try:
        variable_manager_0.set_nonpersistent_facts(hostname_0, facts_0)
    except Exception as e:
        raise Exception(str(e))


# Generated at 2022-06-25 14:21:47.224797
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    host_vars = dict()
    host_vars['ansible_all_ipv4_addresses'] = ['192.168.1.1']
    host_vars['ansible_all_ipv6_addresses'] = [u'::1']

# Generated at 2022-06-25 14:21:51.294685
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    host = "127.0.0.1"
    varname = "ansible_subset"
    value = "127.0.0.1"
    variable_manager_0.set_host_variable(host, varname, value)


# Generated at 2022-06-25 14:22:48.390937
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_1 = VariableManager()
    variable_manager_1.set_nonpersistent_facts("test_host_0",{"test_fact_0": "test_value_0"})
    assert variable_manager_1._nonpersistent_fact_cache.get("test_host_0")["test_fact_0"] == "test_value_0"


# Generated at 2022-06-25 14:22:55.511825
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager1 = VariableManager()
    variable_manager1.clear_facts('127.0.0.1')
    variable_manager1.set_host_facts('127.0.0.1', {'ANSIBLE_NET_USERNAME': 'kiran', 'ANSIBLE_NET_PASSWORD': 'cisco'})
    assert 'kiran' == variable_manager1._fact_cache['127.0.0.1']['ansible_net_username']
    assert 'cisco' == variable_manager1._fact_cache['127.0.0.1']['ansible_net_password']
    variable_manager1.set_host_facts('127.0.0.1', {'ANSIBLE_NET_USERNAME': 'kumar', 'ANSIBLE_NET_PASSWORD': 'arista'})


# Generated at 2022-06-25 14:23:06.377773
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager.data_structure = data()
    play = Play().load(dict(
        host_pattern="all",
        gather_facts="no",
        remote_user='johndoe',
        tasks=[dict(action=dict(module='setup')), dict(action=dict(module='setup'))],
    ), variable_manager=variable_manager, loader=DictDataLoader())

    # Test get_vars without delegated_vars
    result = variable_manager.get_vars(play=play, task=play.tasks[0])
    assert result['inventory_hostname'] == 'localhost', result['inventory_hostname']
    assert result['remote_user'] == 'johndoe', result['remote_user']

    # Test get_vars with delegated_vars


# Generated at 2022-06-25 14:23:16.107713
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Test case 0:
    # hosts = ['host1', 'host2', 'host3']
    # facts = ['fact1', 'fact2', 'fact3']
    # """
    # Given this config, after set_nonpersistent_facts, we should have in
    # {host1: {fact1, fact2, fact3}, host2: {fact1, fact2, fact3}, host3: {fact1, fact2, fact3}}
    # """
    hosts = ['host1', 'host2', 'host3']
    facts = {'fact1': 1, 'fact2': 2, 'fact3': 3}
    for host in hosts:
        variable_manager_0.set_nonpersistent_facts(host, facts)
    # Expected results

# Generated at 2022-06-25 14:23:22.055604
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_ = VariableManager()
    host_ = 'h1'
    varname_ = 'k1'
    value_ = {'k1':'v1'}
    variable_manager_.set_host_variable(host_, varname_, value_)
    assert(variable_manager_.get_vars(host=host_).get(varname_) == value_)
    varname_ = 'k1'
    value_ = {'k2':'v2'}
    variable_manager_.set_host_variable(host_, varname_, value_)
    assert(variable_manager_.get_vars(host=host_).get(varname_) == {'k1':'v1', 'k2':'v2'})


# Generated at 2022-06-25 14:23:34.197669
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0._fact_cache = {'foo':{}}
    variable_manager_0._host_cache = {'foo':{}}
    variable_manager_0._nonpersistent_fact_cache = {'foo':{}}
    variable_manager_0._options_vars = {'foo':{}}
    variable_manager_0._vars_cache = {'foo':{}}
    variable_manager_0._vars_plugins = {'foo':{}}
    variable_manager_0.extra_vars = {'foo':{}}
    variable_manager_0.extra_vars = {'foo':{}}
    variable_manager_0.host_vars_files = {'foo':{}}

# Generated at 2022-06-25 14:23:44.629249
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # test basic functionality
    variable_manager_1 = VariableManager()
    test_ansible_vars_0 = {"ansible_version": {"full": "2.2.0", "major": 2, "minor": 2, "revision": 0, "string": "2.2.0"},
                           "foo": "bar",
                           "localhost": "somewhere.com"}
    test_ansible_vars_1 = {"ansible_version": {"full": "2.2.0", "major": 2, "minor": 2, "revision": 0, "string": "2.2.0"},
                           "foo": "bar",
                           "localhost": "here.com"}
    test_host_vars_0 = {'hostvars': {'localhost': {'foo': 'bar'}}}
   

# Generated at 2022-06-25 14:23:53.603524
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()
    variable_manager_0.get_vars(play=None, host=None)
    variable_manager_0.add_group_vars_file(None, 'all')
    variable_manager_0.add_group_vars_file(None, 'all', cache=False)
    variable_manager_0.add_host_vars_file(None, 'all')
    variable_manager_0.add_host_vars_file(None, 'all', cache=False)
    variable_manager_0.add_role_vars_files(None, 'all')
    variable_manager_0.set_inventory(None)
    variable_manager_0.set_play_context(play=None)




# Generated at 2022-06-25 14:23:56.312079
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()

    assert variable_manager_0.get_vars(play=None, host=None, task=None, include_delegate_to=True, include_hostvars=True) == dict()


# Generated at 2022-06-25 14:24:07.229700
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-25 14:25:04.438611
# Unit test for constructor of class VariableManager
def test_VariableManager():
    try:
        variable_manager_0 = VariableManager()
    except Exception as e:
        print(e)
        traceback.print_exc()
        assert False


# Generated at 2022-06-25 14:25:13.177992
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    variable_manager_1 = VariableManager()
    hostname_1 = "hostname_1"
    host_1 = "host_1"
    task_1 = "task_1"
    include_delegate_to_1 = True
    include_hostvars_1 = True
    play_1 = "play_1"
    include_delegate_to_2 = False
    include_hostvars_2 = False
    result_1 = variable_manager_1.get_vars(hostname_1, host_1, task_1, include_delegate_to_1, include_hostvars_1, play_1)
    assert result_1 is not None
    hostname_2 = "hostname_2"
    host_2 = None
    task_2 = None
    result_2 = variable_manager_

# Generated at 2022-06-25 14:25:18.534398
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()

# Generated at 2022-06-25 14:25:25.199539
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager._fact_cache = {"testvar": {"var1": "testvalue", "var2": "testvalue2"}}

    assert variable_manager.get_vars(host="testvar") == {"var1": "testvalue", "var2": "testvalue2"}
    assert variable_manager.get_vars(host="testvar", task=None, play=None) == {"var1": "testvalue", "var2": "testvalue2"}
    assert variable_manager.get_vars(host="testvar", task=None, play=None, include_hostvars=True) == {"var1": "testvalue", "var2": "testvalue2", "hostvars": {}}

# Generated at 2022-06-25 14:25:26.656298
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    case_0 = VariableManager()
    case_0.get_vars()


# Generated at 2022-06-25 14:25:28.213691
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    assert(True)

if __name__ == "__main__":
    test_VariableManager_set_host_variable()

# Generated at 2022-06-25 14:25:29.745524
# Unit test for constructor of class VariableManager
def test_VariableManager():
    test_case_0()

if __name__ == "__main__":
    test_VariableManager()

# Generated at 2022-06-25 14:25:31.305445
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    set_nonpersistent_facts('host00', {'a': 'b'})
    get_vars(host='host00', include_delegate_to=True, include_hostvars=True)


# Generated at 2022-06-25 14:25:39.534449
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()

    # Test with type str of first parameter
    hostname_0 = "host"
    # Test with type None of second parameter
    play_0 = None
    # Test with type None of third parameter
    task_0 = None
    # Test with type bool of fourth parameter
    include_delegate_to_0 = True
    # Test with type bool of fifth parameter
    include_hostvars_0 = True
    # Test with type str of first parameter
    hostname_1 = "host"
    # Test with type None of second parameter
    play_1 = None
    # Test with type None of third parameter
    task_1 = None
    # Test with type bool of fourth parameter
    include_delegate_to_1 = False
    # Test with type bool of fifth parameter
    include_hostv