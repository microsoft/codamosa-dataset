

# Generated at 2022-06-25 14:16:52.900066
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    var_mgr = VariableManager()
    host = "test.host.com"
    facts = dict(test_fact=1)

    var_mgr.set_host_facts(host, facts)
    assert var_mgr._fact_cache.get(host) == facts

    # Test that when setting facts, the facts are updated and not replaced
    facts2 = dict(test_fact=2)
    var_mgr.set_host_facts(host, facts2)
    assert var_mgr._fact_cache.get(host) == dict(test_fact=2)

# Generated at 2022-06-25 14:17:02.221832
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    vm.set_host_variable('host1', 'var1', '1')
    vm.set_host_variable('host2', 'var2', '2')
    vm.set_host_variable('host1', 'var3', '3')
    vm.set_host_variable('host1', 'var4', '4')
    cached_vars = vm._vars_cache
    assert 1 == len(cached_vars)
    for key, value in cached_vars.items():
        assert 'host1' == key
        assert '1' == value['var1']
        assert '3' == value['var3']
        assert '4' == value['var4']


# Generated at 2022-06-25 14:17:09.164468
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Create VariableManager objects to test
    vm = VariableManager()
    vm_loader_inventory = VariableManager(loader=DictDataLoader({}), inventory=InventoryManager(loader=DictDataLoader({})))
    vm_options_vars = VariableManager(options_vars={'a': 'b'})
    vm_hostvars = VariableManager(hostvars={'a': 'b'})
    vm_play_play = VariableManager(play=Play().load({'name': 'test'}))
    vm_play_task = VariableManager(play=Play().load({'name': 'test'}), task=Task().load({'name': 'test'}))
    vm_host_host = VariableManager(host=Host(name='test'))

# Generated at 2022-06-25 14:17:13.580335
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()
    variable_manager._vars_from_inventory(None)
    variable_manager._vars_from_playbook(None)
    variable_manager._vars_from_task(None, None)
    variable_manager._vars_from_special_tasks(None)


# Generated at 2022-06-25 14:17:24.752144
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    test_manager_0 = VariableManager(loader=None)
    test_manager_0.set_host_variable('host_0', 'var_0', 'value')
    assert test_manager_0.get_vars(play=None, host=None, task=None)['var_0'] == 'value'

    test_manager_1 = VariableManager(loader=None)
    test_manager_1.set_nonpersistent_facts('host_0', {'var_1': 'value', 'var_2': 'value'})
    test_manager_1.set_nonpersistent_facts('host_0', {'var_3': 'value'})

# Generated at 2022-06-25 14:17:29.884979
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager._fact_cache['host0'] = {'fake_fact_0': 'a', 'fake_fact_1': 'b'}
    variable_manager._fact_cache['host1'] = {'fake_fact_0': 'b', 'fake_fact_1': 'a',
                                        'fake_fact_2': 'c'}
    variable_manager._vars_cache['host2'] = {'fake_var_0': 'd', 'fake_var_1': 'e',
                                             'fake_var_2': 'f'}
    variable_manager._vars_cache['host3'] = {'fake_var_0': 'f', 'fake_var_1': 'g'}

# Generated at 2022-06-25 14:17:30.991329
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    vars_with_sources_0 = VarsWithSources()


# Generated at 2022-06-25 14:17:42.637293
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    failure_message = ""
    variable_manager = VariableManager()

    variable_manager.set_host_facts('localhost', dict(ansible_ssh_host='127.0.0.1'))

    # set_host_facts should accept dict type object
    try:
        variable_manager.set_host_facts('localhost', dict(ansible_ssh_host='127.0.0.1'))
    except Exception:
        failure_message = "Failed to set_host_facts for dict type object"
        raise AssertionError(failure_message)

    # set_host_facts should fail for non-dict type objects.
    try:
        variable_manager.set_host_facts('localhost', ['127.0.0.1'])
    except TypeError:
        pass

# Generated at 2022-06-25 14:17:51.439592
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-25 14:18:02.677011
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts('localhost', {'ansible_facts': {'toto': 'tata'}})
    assert variable_manager._nonpersistent_fact_cache['localhost']['ansible_facts']['toto'] == 'tata'
    variable_manager.set_nonpersistent_facts('localhost', {'ansible_facts': {'tutu': 'tati'}})
    assert variable_manager._nonpersistent_fact_cache['localhost']['ansible_facts']['toto'] == 'tata'
    assert variable_manager._nonpersistent_fact_cache['localhost']['ansible_facts']['tutu'] == 'tati'

# Generated at 2022-06-25 14:18:40.766325
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    ansible_playbook.SETUP_CACHE['ansible_playbook_python_interpreter'] = sys.executable

    def caller(name, result, vars_file):
        temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-25 14:18:51.411672
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    vm = VariableManager()

    # empty input
    facts = dict()
    hostname = 'test_host'
    vm.set_host_facts(hostname, facts)
    assert vm._fact_cache[hostname] == facts

    # overwrite existing facts
    facts = dict(FACTS={
        'interface_id': 'fake_interface',
    })
    vm.set_host_facts(hostname, facts)
    assert vm._fact_cache[hostname] == facts

    # append to existing facts
    facts = dict(FACTS={
        'interface_id': 'other_fake_interface',
    })
    vm.set_host_facts(hostname, facts)

# Generated at 2022-06-25 14:19:01.447987
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test VarsCache class
    vars_with_sources_1 = VarsWithSources()
    vars_with_sources_2 = VarsWithSources()
    # Test VarsCache class with combined_cache
    vars_with_sources_3 = VarsWithSources()
    vars_with_sources_4 = VarsWithSources()
    vars_with_sources_5 = VarsWithSources()
    vars_with_sources_6 = VarsWithSources()
    vars_with_sources_7 = VarsWithSources()
    # Test VarsCache class with set_host_variable
    vars_with_sources_8 = VarsWithSources()
    vars_with_sources_9 = VarsWithSources()
    vars_with_sources_10 = V

# Generated at 2022-06-25 14:19:02.494309
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()
    assert variable_manager is not None


# Generated at 2022-06-25 14:19:08.432720
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vm = VariableManager()
    fake_loader = DictDataLoader({})
    vm._loader = fake_loader

    # Test pre-canned input with no "vars" specified
    test_yaml = load_fixture_to_task_ds('task_ds_0.yaml')
    fake_task = Task(task_ds=test_yaml)

    # Run the function under test
    result = vm.get_vars(task=fake_task, include_delegate_to=False)
    assert result['foo'] == 'bar'

    # Test pre-canned input with a "vars:" section
    test_yaml = load_fixture_to_task_ds('task_ds_1.yaml')
    fake_task = Task(task_ds=test_yaml)

    # Run the function under

# Generated at 2022-06-25 14:19:18.011680
# Unit test for constructor of class VariableManager
def test_VariableManager():
    with pytest.raises(AssertionError):
        VariableManager(loader=None)
    with pytest.raises(AssertionError):
        VariableManager(host_vars=None)
    with pytest.raises(AssertionError):
        VariableManager(group_vars=None)
    with pytest.raises(AssertionError):
        VariableManager(options_vars=None)
    with pytest.raises(AssertionError):
        VariableManager(inventory=None)
    with pytest.raises(AssertionError):
        VariableManager(play=None)
    with pytest.raises(AssertionError):
        VariableManager(fact_cache=None)
    with pytest.raises(AssertionError):
        VariableManager(vars_cache=None)
   

# Generated at 2022-06-25 14:19:23.650173
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vm = VariableManager()
    test_case = None
    vm.get_vars(play=None, host=None, task=None, include_delegate_to=True, include_hostvars=True)
    vm.get_vars(play=None, host=None, task=None, include_delegate_to=True, include_hostvars=False)
    vm.get_vars(play=None, host=None, task=None, include_delegate_to=False, include_hostvars=True)
    vm.get_vars(play=None, host=None, task=None, include_delegate_to=False, include_hostvars=False)

# Generated at 2022-06-25 14:19:33.479483
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # Test for the method get_vars of the base class
    vars_with_sources_0 = VarsWithSources()
    test_case_0(vars_with_sources_0)

    #test_vars = test_case_0()
    test_vars = dict(a=1, b=2)
    vm = VariableManager()

    # test that we get the same dictionary back without any hostvars
    v = vm.get_vars(host=None, include_hostvars=False)
    assert v == vm._vars
    assert v == vm._nonpersistent_fact_cache

    # test that we get back hostvars as well
    v = vm.get_vars(host=None, include_hostvars=True)
    assert v == vm._vars

# Generated at 2022-06-25 14:19:37.922554
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # initialization
    vms = VariableManager()
    # Test case with existing host
    host = Host('test_host')
    assert(vms.get_vars(host) == {})
    # Test case with None host
    assert(vms.get_vars(None) == {})


# Generated at 2022-06-25 14:19:44.970740
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vm = VariableManager()
    host = 'host1'
    facts = {'fact1': 'value1',
             'fact2': 'value2',
             'fact3': 'value3'}
    vm.set_nonpersistent_facts(host=host, facts=facts)
    # Assert that a nonpersistent fact cache was created for the host
    assert host in vm._nonpersistent_fact_cache
    # Assert that the facts were set correctly
    assert vm._nonpersistent_fact_cache[host] == facts


# Generated at 2022-06-25 14:20:21.154789
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    v1 = Host(name='localhost')
    v2 = Host(name='other')
    v3 = Host(name='another')
    v4 = Host(name='test')

    vm = VariableManager()

    # Basic test with no inventory
    vars = vm.get_vars()
    assert vars == {}

    # Test with an inventory that has no hosts
    inv = Inventory()
    vm = VariableManager(loader=DictDataLoader({}), inventory=inv)
    vars = vm.get_vars()
    assert vars == {}

    # Test with an inventory that has hosts but no variables
    inv.add_host(v1)
    inv.add_host(v2)
    vm = VariableManager(loader=DictDataLoader({}), inventory=inv)
    vars = vm.get_vars

# Generated at 2022-06-25 14:20:22.089834
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    assert True



# Generated at 2022-06-25 14:20:30.767947
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Create the test VariableManager object
    vm = VariableManager()
    vm.set_nonpersistent_facts('test_host', {'test1': 'test2'})
    assert vm._nonpersistent_fact_cache.get('test_host') == {'test1': 'test2'}
    vm.set_nonpersistent_facts('test_host', {'test3': 'test4'})
    assert vm._nonpersistent_fact_cache.get('test_host') == {'test1': 'test2', 'test3': 'test4'}


# Generated at 2022-06-25 14:20:33.775237
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Create a VariableManager object
    vm = VariableManager()
    # Call set_host_facts function with host, facts as arguments
    vm.set_host_facts('abc', {'abc': 'xyz'})

# Generated at 2022-06-25 14:20:41.358840
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    variable_manager.set_host_variable('host01', 'varname01', 'value01')
    variable_manager.set_host_variable('host01', 'varname02', 'value02')
    variable_manager.set_host_variable('host01', 'varname03', 'value03')
    assert variable_manager._vars_cache['host01']['varname01'] == 'value01'
    assert variable_manager._vars_cache['host01']['varname02'] == 'value02'
    assert variable_manager._vars_cache['host01']['varname03'] == 'value03'


# Generated at 2022-06-25 14:20:47.459178
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    loader = FakeLoader()
    variable_manager = VariableManager()

    # Test Case 1
    # Get vars on a host with variables set
    host = Host(name="foo",
                address="192.168.0.1",
                variables={"foo": "bar"})
    result = variable_manager.get_vars(host=host)
    assert result['foo'] == "bar"

    # Test Case 2
    # Get vars on a host with no variables set
    host = Host(name="foo")
    result = variable_manager.get_vars(host=host)
    assert result == {}

    # Test Case 3
    # Get vars on a host with variables set, but no inventory
    variable_manager.set_inventory(None)

# Generated at 2022-06-25 14:20:54.857222
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_mgr = VariableManager()
    var_mgr.set_host_variable('host_name', 'var_name', 'value')
    assert var_mgr._vars_cache == {'host_name': {'var_name': 'value'}}
    var_mgr.set_host_variable('host_name', 'var_name', {'sub_var_name': 'sub_value'})
    assert var_mgr._vars_cache == {'host_name': {'var_name': 'value', 'sub_var_name': 'sub_value'}}


# Generated at 2022-06-25 14:21:04.984571
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    hosts_dict = dict()
    temp_host_0 = Host("hostname_0")
    temp_host_1 = Host("hostname_1")

    var_value_0 = dict()
    var_value_0['var_1'] = 1
    var_value_0['var_2'] = 2

    var_value_1 = dict()
    var_value_1['var_3'] = 3
    var_value_1['var_4'] = 4
    var_value_1['var_5'] = 5

    temp_vm = VariableManager()
    # Test normal conditions
    temp_vm.set_host_variable(temp_host_0, 'var_0', 0)
    assert(temp_vm._vars_cache[temp_host_0]['var_0'] == 0)
    temp_vm

# Generated at 2022-06-25 14:21:09.994459
# Unit test for constructor of class VariableManager
def test_VariableManager():
    vars_with_sources = VarsWithSources()
    variable_manager = VariableManager()
    assert (variable_manager.vars_cache is not None)
    assert (variable_manager.vars_cache == {})
    assert (variable_manager.vars_sources_cache is not None)
    assert (variable_manager.vars_sources_cache == {})
    assert (variable_manager.host_vars_files_cache is not None)
    assert (variable_manager.host_vars_files_cache == {})
    assert (variable_manager.group_vars_files_cache is not None)
    assert (variable_manager.group_vars_files_cache == {})
    assert (variable_manager.host_vars_files_dir_cache is not None)

# Generated at 2022-06-25 14:21:21.561829
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vars_with_sources_0 = VarsWithSources()
    variable_manager_0 = VariableManager(loader=None, inventory=None)
    variable_manager_0.add_vars(vars=vars_with_sources_0, include_hostvars=True)

    # Test case internal

# Generated at 2022-06-25 14:21:56.122297
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()
    variable_manager.set_host_variable("host_0", "fact_0", "value_0")
    variable_manager.set_host_variable("host_0", "fact_1", ["value_1"])
    variable_manager.set_nonpersistent_facts("host_0", {"fact_2": "value_2", "fact_3": ["value_3"]})

    nvpf_dict = variable_manager._nonpersistent_fact_cache
    assert nvpf_dict
    assert "host_0" in nvpf_dict
    assert nvpf_dict["host_0"]
    assert "fact_2" in nvpf_dict["host_0"]
    assert nvpf_dict["host_0"]["fact_2"] == "value_2"


# Generated at 2022-06-25 14:21:58.213796
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    test_case_0()

if __name__ == "__main__":
    test_VariableManager_get_vars()

# Generated at 2022-06-25 14:22:06.508730
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager()
    # Test with correct host and correct varname
    args_1 = [Host(name="TestHost1"), "varname", "value"]
    kwargs_1 = { }
    expected_result_1 = None
    actual_result_1 = variable_manager_1.set_host_variable(*args_1, **kwargs_1)
    assert actual_result_1 == expected_result_1
    # Test with correct host and correct varname
    args_2 = [Host(name="TestHost2"), "varname", "value"]
    kwargs_2 = { }
    expected_result_2 = None
    actual_result_2 = variable_manager_1.set_host_variable(*args_2, **kwargs_2)

# Generated at 2022-06-25 14:22:13.158971
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    host = "127.0.0.1"
    varname = "VAR"
    value = "1"
    variable_manager_0.set_host_variable(host, varname, value)
    assert variable_manager_0._vars_cache[host][varname] == value



# Generated at 2022-06-25 14:22:21.110604
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    play_0 = Play().load(
        dict(
            name="Ansible Play 0",
            hosts="some_hosts",
            gather_facts="no",
            roles=[],
            tasks=[
                dict(action=dict(module="ping", args=dict()), register="ping_results")
            ]
        ), variable_manager=variable_manager, loader=None)

# Generated at 2022-06-25 14:22:26.252760
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_1 = VariableManager()
    host = "localhost"
    facts = {"test_fact": "test_fact_value"}
    variable_manager_1.set_nonpersistent_facts(host, facts)

    assert(variable_manager_1._nonpersistent_fact_cache[host]["test_fact"] == facts["test_fact"])


# Generated at 2022-06-25 14:22:28.464025
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_facts('foo', 'bar')


# Generated at 2022-06-25 14:22:29.826430
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    test_case_0()

# Generated at 2022-06-25 14:22:38.132689
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager()
    variable_manager_1.set_host_variable('host', 'ansible_connection', 'paramiko')
    variable_manager_1.set_host_variable('host', 'ansible_ssh_user', 'root')
    variable_manager_1.set_host_variable('host', 'ansible_ssh_pass', 'password')
    
    assert variable_manager_1._vars_cache == {'host': {'ansible_connection': 'paramiko', 'ansible_ssh_user': 'root', 'ansible_ssh_pass': 'password'}}


# Generated at 2022-06-25 14:22:46.044758
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    host_name = 'app-server'
    variable_name = 'ansible_ssh_user'
    value = 'root'
    variable_manager_0.set_host_variable(host_name, variable_name, value)
    host_name = 'app-server'
    variable_name = 'app_port'
    value = '80'
    variable_manager_0.set_host_variable(host_name, variable_name, value)
    return variable_manager_0


# Generated at 2022-06-25 14:23:42.917058
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()

    host_0 = 'test_host'
    varname_0 = 'test_var'
    value_0 = {'test_var': 'test_value'}

    variable_manager_0.set_host_variable(host_0, varname_0, value_0)
    assert host_0 in variable_manager_0._vars_cache
    assert variable_manager_0._vars_cache[host_0] == value_0


# Generated at 2022-06-25 14:23:52.744099
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    variable_manager = VariableManager()

    # This should be fine
    variable_manager.set_host_facts("localhost", dict())

    # Try to add something that isn't a dict
    try:
        variable_manager.set_host_facts("localhost", [])
        raise Exception("add_non_persistent_facts with a non-dict failed")
    except TypeError:
        pass

    # Try to add an existing item

    # Try adding None
    try:
        variable_manager.set_host_facts("localhost", None)
        raise Exception("add_non_persistent_facts with a non-dict failed")
    except TypeError:
        pass

    # Try adding something more complicated
    variable_manager.set_host_facts("localhost", dict(x=dict(a=2, b=3)))
    assert variable_manager._

# Generated at 2022-06-25 14:23:55.019695
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    '''
    This test case is to test the functionality of method set_host_facts of class VariableManager
    '''
    test_case = VariableManager()
    test_case.set_host_facts(None, None)

# Generated at 2022-06-25 14:24:05.806757
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    _host = Host(name='localhost', groups=['group_name'], port=5005)
    _host.set_variable('ansible_var_name', 'ansible_var')
    _host.set_variable('ansible_var_name_0', 'ansible_var_0')
    _host.set_variable('ansible_var_name_1', 'ansible_var_1')
    _host.set_variable('ansible_var_name_2', 'ansible_var_2')
    _host.set_variable('ansible_var_name_3', 'ansible_var_3')
    _host.set_variable('ansible_var_name_4', 'ansible_var_4')

# Generated at 2022-06-25 14:24:15.679114
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    saved_pc = copy.deepcopy(pc)
    saved_ih = copy.deepcopy(ih)

    pc['hostvars'] = dict()
    pc['hostvars']['somehostname'] = dict()
    pc['hostvars']['somehostname']['fqdn'] = 'somehostname.example.com'
    pc['hostvars']['somehostname']['inventory_hostname'] = 'somehostname'

    ih['hosts'] = dict()

    pc['hosts'] = ['somehostname']

    ih['hosts']['somehostname'] = dict()
    ih['hosts']['somehostname']['fqdn'] = 'somehostname.example.com'

# Generated at 2022-06-25 14:24:21.521613
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_set_nonpersistent_facts_0 = VariableManager()
    hostname_set_nonpersistent_facts_0 = 'localhost'
    facts_set_nonpersistent_facts_0 = {"item1": "value1", "item2": "value2"}
    variable_manager_set_nonpersistent_facts_0.set_nonpersistent_facts(hostname_set_nonpersistent_facts_0, facts_set_nonpersistent_facts_0)


# Generated at 2022-06-25 14:24:31.095927
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts('localhost', {'k1': 'v1'})
    variable_manager.set_nonpersistent_facts('localhost', {'k2': 'v2'})
    variable_manager.set_nonpersistent_facts('localhost', {'k3': 'v3'})
    v1 = variable_manager.get_vars(host=None)
    v2 = variable_manager.get_vars(host=None, include_hostvars=True)
    assert v1['k1'] == 'v1'
    assert v1['k2'] == 'v2'
    assert v1['k3'] == 'v3'
    assert v2['hostvars']['localhost']['k1'] == 'v1'

# Generated at 2022-06-25 14:24:33.587237
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_variable(1, 2, 3)
    variable_manager_0.set_host_variable(1, 2, 3)


# Generated at 2022-06-25 14:24:45.434512
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    test_cases = [
        (('localhost', 'ping', 'pong'), {'localhost': {'ping': 'pong'}}, 'localhost'),
        (('localhost', 'ping', 'pong'), {'localhost': {'ping': 'pong'}}, '127.0.0.1'),
        (('localhost', 'ping', 'pong'), {'localhost': {'ping': 'pong'}}, '::1'),
        (('localhost', 'ping', 'pong'), {'localhost': {'ping': 'pong'}}, 'fe80::1'),
    ]
    for test_case in test_cases:
        variable_manager = VariableManager()
        variable_manager.set_host_variable(*test_case[0])
        assert variable_manager._vars_cache == test_case[1]
        assert variable

# Generated at 2022-06-25 14:24:51.068985
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    test_host = 'foobar_host'
    test_facts = {
        'test_fact1': 'test_value1',
        'test_fact2': 'test_value2',
        }
    variable_manager_0.set_nonpersistent_facts(test_host, test_facts)
    
    assert(variable_manager_0._nonpersistent_fact_cache[test_host] == test_facts)
