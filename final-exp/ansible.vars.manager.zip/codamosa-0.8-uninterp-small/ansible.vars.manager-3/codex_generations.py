

# Generated at 2022-06-25 14:16:41.067737
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_test = VariableManager()
    assert isinstance(variable_manager_test, VariableManager)



# Generated at 2022-06-25 14:16:52.156118
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    variable_manager_0 = VariableManager()
    # Testing with key='inventory_hostname' and value='127.0.0.1'
    # Testing with key='inventory_hostname' and value='127.0.0.1'
    # Testing with key='inventory_hostname' and value='127.0.0.1'
    # Testing with key='inventory_hostname' and value='127.0.0.1'
    # Testing with key='inventory_hostname' and value='127.0.0.1'
    # Testing with key='inventory_hostname' and value='127.0.0.1'
    # Testing with key='inventory_hostname' and value='127.0.0.1'
    # Testing with key='inventory_hostname' and value='127.0.0.1'
    # Testing with

# Generated at 2022-06-25 14:16:53.049942
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 14:17:02.960873
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager._fact_cache = fact_cache
    variable_manager._vars_cache = vars_cache
    variable_manager._nonpersistent_fact_cache = nonpersistent_fact_cache
    variable_manager._hostvars = {'host1':{'aa':'11','bb':'22','cc':'33'}}
    variable_manager._options_vars = {'foo':'bar'}
    variables = variable_manager.get_vars(host=host, include_hostvars=True, include_delegate_to=True)

# Generated at 2022-06-25 14:17:05.309549
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'foo': 'bar'})
    v.sources = {'foo': 'baz'}
    assert v['foo'] == 'bar'


# Generated at 2022-06-25 14:17:10.491947
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    variable_manager_0 = VariableManager()
    hosts_0 = 'local'
    facts_0 = dict()

    variable_manager_0.clear_facts(hosts_0)
    variable_manager_0.set_host_facts(hosts_0, facts_0)


# Generated at 2022-06-25 14:17:18.560659
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()
    host = 'test_host'
    facts = {'fact1': 1, 'fact2': 2}
    variable_manager.set_nonpersistent_facts(host, facts)
    assert variable_manager._nonpersistent_fact_cache[host]['fact1'] == 1
    assert variable_manager._nonpersistent_fact_cache[host]['fact2'] == 2
    facts = {'fact2': 3, 'fact3': 3}
    variable_manager.set_nonpersistent_facts(host, facts)
    assert variable_manager._nonpersistent_fact_cache[host]['fact1'] == 1
    assert variable_manager._nonpersistent_fact_cache[host]['fact2'] == 3

# Generated at 2022-06-25 14:17:29.077437
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    hostvars = {}
    roles = []
    play = Play().load(dict(hosts='localhost', roles=roles, gather_facts='no'))
    task = Task().load(dict(action=dict(module='debug', args=dict(msg='my message'))))
    task._role = Role().load(dict(name='role1'), play=play, variable_manager=variable_manager_0())
    play.add_task(task)
    play.handlers = []
    variable_manager_0().add_or_update_vars(hostvars)
    variable_manager_0().add_or_update_vars(play.get_variable_manager().vars)
    variable_manager_0().add_or_update_vars(play.get_variable_manager().extra_vars)
    variable_manager

# Generated at 2022-06-25 14:17:40.598828
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    loader_0 = DataLoader()
    inventory_0 = Inventory(loader=loader_0, variable_manager=variable_manager_0)
    variable_manager_0 = VariableManager(loader=loader_0, inventory=inventory_0)

    # Test args: get_vars(self, play=None, host=None, task=None, include_delegate_to=True, include_hostvars=False)
    # Test Case 0 (Null Inventory)
    play_0 = Play().load(dict(
        name="Ansible Play 0",
        hosts="all",
        gather_facts="no",
        tasks=[
            dict(action=dict(module="shell", args="ls")),
        ]
    ), variable_manager=variable_manager_0, loader=loader_0)
    host_0 = inventory_0.get_host

# Generated at 2022-06-25 14:17:45.083784
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_temp = VariableManager()
    variable_manager_temp.set_host_variable("host", "varname", "value")
    assert variable_manager_temp._vars_cache["host"]["varname"] == "value"

test_case_0()
test_VariableManager_set_host_variable()

# Generated at 2022-06-25 14:18:11.335132
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    test_host = "Test_Host"
    test_varname = "Test_Varname"
    test_value = "Test_Value"
    variable_manager.set_host_variable(test_host, test_varname, test_value)
    assert variable_manager._vars_cache[test_host][test_varname] == test_value


# Generated at 2022-06-25 14:18:13.264458
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_nonpersistent_facts('v1', 'v2')


# Generated at 2022-06-25 14:18:18.902062
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Use the populated VariableManager in test case 0
    test_case_0()
    # Get vars_list of ansible_play_hosts.
    vars_list = VariableManager.get_vars(variable_manager_0)['ansible_play_hosts']
    # Assert that the ansible_play_hosts is populated
    assert len(vars_list) > 0


# Generated at 2022-06-25 14:18:23.944987
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    variable_manager_0 = VariableManager()
    str_arg = ''
    VarsWithSources_0 = VarsWithSources()
    try:
        VarsWithSources_0.__getitem__(str_arg)
    except KeyError as e:
        pass
    else:
        raise AssertionError("Expected KeyError")



# Generated at 2022-06-25 14:18:25.355191
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    test_case_0()

test_VariableManager_get_vars()

# Generated at 2022-06-25 14:18:27.860180
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()

    # Call method set_nonpersistent_facts with parameters: host, facts
    variable_manager_0.set_nonpersistent_facts(host, facts)


# Generated at 2022-06-25 14:18:37.453252
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.add_group_vars('group1', to_add = {})
    variable_manager_0.add_host_vars('host1', to_add = {})
    variable_manager_0.add_play_vars('play1', to_add = {})

    res = variable_manager_0.get_vars(play=None, host=None, task=None, include_hostvars=True)
    assert res == {'omit': '__omit_place_holder__'}
    res = variable_manager_0.get_vars(play=None, host=None, task=None, include_hostvars=False)
    assert res == {'omit': '__omit_place_holder__'}

    res = variable

# Generated at 2022-06-25 14:18:44.133577
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()

# Generated at 2022-06-25 14:18:48.635242
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    set_host_variable_return = variable_manager_0.set_host_variable('localhost', 'a', 1)
    assert set_host_variable_return is None
    assert {'localhost': {'a': 1}} == variable_manager_0._vars_cache


# Generated at 2022-06-25 14:18:59.536507
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_fact_cache()

    variable_manager_0.set_host_variable(host='host_0', varname='varname_0', value='value_0')
    variable_manager_0.set_host_variable(host='host_0', varname='varname_1', value='value_1')
    variable_manager_0.set_host_variable(host='host_0', varname='varname_2', value='value_2')

    variable_manager_0.set_host_variable(host='host_1', varname='varname_0', value='value_0')
    variable_manager_0.set_host_variable(host='host_1', varname='varname_1', value='value_1')

# Generated at 2022-06-25 14:19:48.586577
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager._hostvars = 'hostvars'
    variable_manager._fact_cache = 'fact_cache'
    variable_manager._vars_cache = 'vars_cache'
    variable_manager._nonpersistent_fact_cache = 'nonpersistent_fact_cache'
    variable_manager._options_vars = 'options_vars'
    variable_manager._omit_token = 'omit_token'
    variable_manager._loader = 'loader'
    variable_manager._inventory = 'inventory'
    variable_manager._inventory_hostname_var = 'inventory_hostname_var'

    # pass in None values for host, play and task
    # return all variables
    # fact_cache, hostvars, inventory_hostname_var, loader
    # nonpersistent

# Generated at 2022-06-25 14:19:49.760700
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()


# Generated at 2022-06-25 14:19:56.845551
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'content_type': 'application/json','accept': 'application/json','authorization': 'Basic','content_type': 'application/json','accept': 'application/json','authorization': 'Basic','content_type': 'application/json','accept': 'application/json','authorization': 'Basic','content_type': 'application/json','accept': 'application/json','authorization': 'Basic'}
    host = Host()
    play = Play()
    include_delegate_to = True
    include_hostvars = True
    variable_manager.get_vars(
        play=play,
        host=host,
        include_delegate_to=include_delegate_to,
        include_hostvars=include_hostvars,
    )



# Generated at 2022-06-25 14:20:05.038734
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_1 = VariableManager()
    host = 'host'
    facts = {'fact1': '1', 'fact2': '2'}

    # test method set_host_facts with valid arguments
    variable_manager_1.set_host_facts(host, facts)

    # test method set_host_facts with invalid argument type 'facts'
    try:
        variable_manager_1.set_host_facts(host, 'facts')
        assert False
    except TypeError:
        pass

    # test method set_host_facts with invalid argument 'host'
    try:
        variable_manager_1.set_host_facts(1, facts)
        assert False
    except AssertionError:
        pass


# Generated at 2022-06-25 14:20:06.968979
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()

    assert(variable_manager_0 is not None)


# Generated at 2022-06-25 14:20:09.468660
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    test_case_0()
    print("Unit test finished Function get_vars of class VariableManager")


if __name__ == "__main__":
    test_VariableManager_get_vars()

# Generated at 2022-06-25 14:20:13.631615
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    data_1 = variable_manager_1.get_vars()

    variable_manager_2 = VariableManager()
    data_2 = variable_manager_2.get_vars()

    equal = data_1 == data_2
    print(equal)



# Generated at 2022-06-25 14:20:24.264493
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    host_0 = Host(name = "TestHost")
    host_0.set_variable('ansible_facts', dict())
    play_0 = Play.load(play_ds = {'name': 'TestPlay', 'hosts': 'TestHost'},
                       variable_manager = VariableManager(),
                       loader = DataLoader(),
                       templar = Templar(loader = DataLoader()),
                       )
    task_0 = Task()
    variable_manager_0 = VariableManager()
    variable_manager_0._extra_vars = dict({'ansible_play_batch': [host_0.name]})
    variable_manager_0._vars_cache = dict({'TestHost': dict()})

# Generated at 2022-06-25 14:20:35.380255
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    result = variable_manager_0.get_vars(
      play=None,
      host=None,
      task=None,
      include_delegate_to=None,
      use_cache=None,
      include_hostvars=None,
      )


# Generated at 2022-06-25 14:20:36.241973
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()


# Generated at 2022-06-25 14:21:06.163581
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Test constructor
    test_case_0()


# Generated at 2022-06-25 14:21:09.343002
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # As this is a method test, I need to create a class object to call the tested method of the class
    variable_manager_0 = VariableManager()
    # I define an assertion to verify if the method get_vars of the class VariableManager works properly
    # This assertion do a test for the method get_vars
    assert type(variable_manager_0.get_vars()) == dict, "The method get_vars of the class VariableManager is not returning a dict"


# Generated at 2022-06-25 14:21:16.308969
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager()
    _host="testing host"
    _varname="testing varname"
    _value="testing value"
    variable_manager_1.set_host_variable(_host, _varname, _value)
    if variable_manager_1._vars_cache[_host][_varname] == _value:
        return True
    else:
        return False


# Generated at 2022-06-25 14:21:17.696741
# Unit test for constructor of class VariableManager
def test_VariableManager():
    test_case_0()

# Unit test

# Generated at 2022-06-25 14:21:25.601417
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Create object to test
    v_m = VariableManager()
    # Initialize inventory
    inventory = InventoryManager()
    inventory._inventory = InventoryLoader(loader=DictDataLoader({})).load(inventory_dict=d_invent_v_m)
    v_m._inventory = inventory
    # Get var
    variables = v_m.get_vars(play=None)
    # Test for unexpected variables
    assert variables == d_v_m, "Unexpected values"
    # Test with a real play
    play = Play()
    play._attributes = d_play
    variables = v_m.get_vars(play=play)
    # Test for unexpected variables
    assert variables == d_v_m, "Unexpected values"


# Generated at 2022-06-25 14:21:34.192901
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # set_host_variable(self, host, varname, value):
    # set a value in the vars_cache for a host
    variable_manager_0 = VariableManager()
    # case 0:
    # TypeError: The object retrieved for {0}
    # must be a MutableMapping but was
    # a {1}:
    host = '172.16.20.122'
    varname = 'test_variable_manager_0'
    value = 'test_variable_manager_0'
    try:
        variable_manager_0.set_host_variable(host, varname, value)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 14:21:39.032139
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()

    host_0 = Host()
    host_0.get_name = MagicMock(return_value='host1')
    vars_0 = variable_manager_0.get_vars(
        play=None,
        host=host_0,
        task=None,
        include_delegate_to=True,
        include_hostvars=True,
    )

    #The output of the code we're testing
    output = (
        'host1',
        None,
        None,
        {'omit': '__omit_place_holder__', 'groups': {'ungrouped': ['host1']}},
        {'inventory_hostname': 'host1'},
        None,
        None,
    )

    #The expected output

# Generated at 2022-06-25 14:21:40.050478
# Unit test for constructor of class VariableManager
def test_VariableManager():
    return test_case_0()



# Generated at 2022-06-25 14:21:47.454870
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    #
    # test with option 'use_task_vars' set as True and as False
    #

    def _get_vars_helper(use_task_vars=False):

        # init VariableManager
        plugin_filter_map = {'task_vars_cache': [{'playbook_cache': 'playbook_cache',
                                                  'playbook_path': 'playbook_path',
                                                  'play_uuid': 'play_uuid',
                                                  'playbook_cache': 'playbook_cache',
                                                  'loop_control': 'loop_control'}]}

# Generated at 2022-06-25 14:21:56.567246
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    variable_manager_2 = VariableManager()

    # Make sure that variables are not being reused across variable managers
    variable_manager_1._fact_cache['host_1'] = {'fact': 'value'}
    variable_manager_1._hostvars['host_1'] = {'host': 'value'}
    variable_manager_1._inventory = MagicMock()
    variable_manager_1._inventory.get_host.return_value = Host(name='host_1')

    assert variable_manager_2.get_vars(host=Host(name='host_1'))['fact'] != 'value'
    assert variable_manager_2.get_vars(host=Host(name='host_1'))['host'] != 'value'

# Generated at 2022-06-25 14:22:25.379186
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    assert(isinstance(variable_manager_0.get_vars(),dict))


# Generated at 2022-06-25 14:22:35.149796
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()

    vars_dict = {
        'host_name': 'host_0'
    }

    # Test with None for arguments play, host, and task
    actual_vars_dict_0 = variable_manager_0.get_vars(None, None, None, include_delegate_to=True)
    assert vars_dict == actual_vars_dict_0

    # Test with no argument include_delegate_to
    actual_vars_dict_1 = variable_manager_0.get_vars(None, None, None)
    assert actual_vars_dict_1 == actual_vars_dict_0


# Generated at 2022-06-25 14:22:38.038219
# Unit test for constructor of class VariableManager
def test_VariableManager():
    assert callable(VariableManager)
    variable_manager_0 = VariableManager()
    assert isinstance(variable_manager_0, VariableManager)


# Generated at 2022-06-25 14:22:44.950593
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variables = {'a': 'b', 'c': 'd'}
    inventory = MagicMock(variables=variables)

    variable_manager = VariableManager(inventory=inventory)
    # We can't test here the fact that we return a copy because it will be too complex.
    # So we can only test if the variables returned are exactly the same as the one in inventory
    assert variable_manager.get_vars() == variables


# Generated at 2022-06-25 14:22:47.721709
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager()
    variable_manager_1.set_host_variable('dummy_hostname_0','dummy_varname','dummy_value_0')


# Generated at 2022-06-25 14:22:51.125519
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()

    # The method 'get_vars' is not implemented yet
    # This test is for coverage only
    variable_manager.get_vars()

if __name__ == '__main__':
  test_case_0()
  test_VariableManager_get_vars()

# Generated at 2022-06-25 14:22:57.521719
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    play_0 = Play()
    host_0 = Host()
    task_0 = Task()
    include_hostvars_0 = False
    var_override_vars_0 = {}
    include_delegate_to_0 = False
    test = variable_manager_0.get_vars(play_0, host_0, task_0, include_hostvars_0, var_override_vars_0, include_delegate_to_0)
    assert isinstance(test, dict)


# Generated at 2022-06-25 14:23:07.670036
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager = VariableManager()

    # Test host facts update when host already in cache
    variable_manager.set_host_facts('test_host', {'fact_0': 'value_0'})
    variable_manager.set_host_facts('test_host', {'fact_1': 'value_1'})
    assert variable_manager._fact_cache['test_host']['fact_0'] == 'value_0'
    assert variable_manager._fact_cache['test_host']['fact_1'] == 'value_1'

    # Test host facts are set when host not in cache
    variable_manager.set_host_facts('test_host_2', {'fact_3': 'value_3'})

# Generated at 2022-06-25 14:23:10.737003
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_nonpersistent_facts('name0', {'name1': 'str0'})


# Generated at 2022-06-25 14:23:16.373767
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    host_0 = 'host_0'
    facts_0 = {'host_0': 'host_0'}
    variable_manager_0.set_host_facts(host_0, facts_0)
    facts_1 = {'host_1': 'host_1'}
    variable_manager_0.set_host_facts(host_0, facts_1)
    facts_2 = {'host_2': 'host_2'}
    variable_manager_0.set_host_facts(host_0, facts_2)
    facts_3 = {'host_3': 'host_3'}
    variable_manager_0.set_host_facts(host_0, facts_3)


# Generated at 2022-06-25 14:23:54.318357
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    facts = dict()
    facts['ansible_fqdn'] = 'ansible_fqdn'
    facts['ansible_python_version'] = 'ansible_python_version'
    facts['ansible_user_id'] = 'ansible_user_id'
    facts['gather_subset'] = ['all']
    variable_manager_0.set_nonpersistent_facts('hostvars_0', facts)
    delegated_host_vars = variable_manager_0.get_vars(host=Host(name='hostvars_0'), include_hostvars=True)
    assert delegated_host_vars['ansible_fqdn'] == 'ansible_fqdn'

# Generated at 2022-06-25 14:24:05.120714
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    class FakeHost(object):
        def get_vars(self):
            vars = {'a': 1,
                    'b': '2',
                    'c': 1.0,
                    'd': None}
            return vars

    class FakePlay(object):
        def __init__(self):
            self.hosts = 'all'
            self.roles = []

        def get_name(self):
            return 'test-play'

    fake_host = FakeHost()
    fake_play = FakePlay()

    variable_manager = VariableManager()
    vars = variable_manager.get_vars(host=fake_host, play=fake_play)

    assert vars['a'] == 1
    assert vars['b'] == '2'
    assert vars['c'] == 1.0

# Generated at 2022-06-25 14:24:06.700899
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    print(variable_manager_1.get_vars())


# Generated at 2022-06-25 14:24:16.834572
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # create a fake inventory and setup the inventory plugins
    plugin = InventoryModule(None, ["localhost"], [])
    host = Host(name="localhost", port=0)
    host.set_variable('foo', '1')
    host.set_variable('bar', '2')
    plugin.inventory.add_host(host)
    plugin.inventory.add_group('group_a')
    plugin.inventory.add_child('group_a', host)
    plugin.inventory.get_groups_dict()
    plugin.parse(cache=False, cache_timeout=0, persist_cache=False, vault_password=None)
    plugin.get_hosts(plugin.get_pattern('all'))

    variable_manager_0 = VariableManager()

    # Create a fake play context to initialize the variable manager
    play_context = PlayContext()



# Generated at 2022-06-25 14:24:19.952563
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager()
    variable_manager_1.set_host_variable('testhost001', 'VARIABLE_STRING' , 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')


# Generated at 2022-06-25 14:24:24.207905
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # testing the method get_vars of class VariableManager
    variable_manager = VariableManager()
    variable_manager_4 = VariableManager()
    with pytest.raises(AnsibleError):
        variable_manager_4.get_vars(1)


# Generated at 2022-06-25 14:24:32.593941
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # set data
    variable_manager_0 = VariableManager()

    host_0 = Host(name='default')

    delegate_vars_0 = {u'inventory_hostname': u'default', u'group_names': [u'my_group'], u'test_delegated_var': [1, 2, 3], u'inventory_dir': 'test_data/test_vars/', u'inventory_file': 'test_data/test_vars/test_inventory.yml'}

# Generated at 2022-06-25 14:24:33.764597
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    test_case_0()


# Generated at 2022-06-25 14:24:36.737727
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager.get_vars(loader='loader', play=Play(), host=Host())


# Generated at 2022-06-25 14:24:38.273250
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()

# Generated at 2022-06-25 14:25:37.884859
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_obj = VariableManager()

    variable_manager_obj.get_vars()
    variable_manager_obj.get_vars(host=None)


# Generated at 2022-06-25 14:25:43.478692
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    hosts_0 = 'ansible_host'
    facts_0 = {'my_var': 'my_value'}
    variable_manager_0.set_nonpersistent_facts(hosts_0, facts_0)
    facts_1 = {'my_var': 'my_value'}

    # Check that the correct facts are available in the nonpersistent cache
    assert facts_1 == variable_manager_0._nonpersistent_fact_cache[hosts_0], "Failed to store or retrieve nonpersistent facts correctly"

