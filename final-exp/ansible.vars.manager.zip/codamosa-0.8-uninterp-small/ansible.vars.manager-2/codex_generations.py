

# Generated at 2022-06-25 14:17:18.476753
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vars_with_sources_1 = VarsWithSources()
    variable_manager_1 = VariableManager()
    vars_with_sources_1.set_vars_sources(
        [VarsFromYamlFiles(['test_variable_manager_set_host_variable.yaml', 'test_variable_manager_set_host_variable_1.yaml'])]
    )
    variable_manager_1._vars_cache = vars_with_sources_1
    variable_manager_1.set_host_variable(
        host=Host(name='test_name_0'), varname='test_varname_0', value={'keyname': 'keyvalue'}
    )

# Generated at 2022-06-25 14:17:28.413739
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vars_with_sources_0 = VarsWithSources()
    # Set existing variable
    variable_manager_set_host_variable(vars_with_sources_0, "myvar", "value")
    # Set variable with list as value
    variable_manager_set_host_variable(vars_with_sources_0, "myvar", [1,2,3])
    # Set variable with dict as value
    variable_manager_set_host_variable(vars_with_sources_0, "myvar", {"a":"b"})
    # Set variable with dict as value and an existing variable
    variable_manager_set_host_variable(vars_with_sources_0, "myvar", {"c":"d"})

# Generated at 2022-06-25 14:17:38.609306
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager(loader=None, inventory=None)
    variable_manager_0.extra_vars = dict()
    variable_manager_0._options_vars = dict()
    variable_manager_0._nonpersistent_fact_cache = dict()
    variable_manager_0._vars_cache = dict()
    variable_manager_0._fact_cache = dict()
    variable_manager_0._delegated_vars = dict()
    variable_manager_0._hostvars = dict()
    variable_manager_0._omit_token = '*****'

    test_get_vars_1 = variable_manager_0.get_vars(host=None, play=None, task=None, include_delegate_to=True, include_hostvars=True)
    assert test_get

# Generated at 2022-06-25 14:17:43.794558
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_manager_0 = VariableManager()
    var_manager_0.options_vars['fact_caching_connection'] = None
    var_manager_0.options_vars['fact_caching'] = None
    var_manager_0.options_vars['ansible_connection'] = u'local'
    var_manager_0.options_vars['ansible_python_interpreter'] = u'/usr/bin/python'
    var_manager_0.options_vars['playbook_dir'] = None
    var_manager_0.options_vars['ansible_check_mode'] = False
    var_manager_0.options_vars['become_method'] = u'sudo'
    var_manager_0.options_vars['become'] = False
    var_manager_0.options_

# Generated at 2022-06-25 14:17:52.072791
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Create a fake fact_loader
    fact_loader_mock = mock.MagicMock(spec=FactCache)
    fact_loader_mock.get_facts.return_value = {}
    fact_loader_mock.get_host_facts.return_value = {}
    fact_loader_mock.get_nonpersistent_facts.return_value = {}

    # Create a fake inventory
    inventory_mock = mock.MagicMock()
    inventory_mock.get_host.return_value = None

    # Create an variable manager
    variable_manager = VariableManager(fact_loader=fact_loader_mock, inventory=inventory_mock)

    # Test VariableManager.get_vars without supplying a host
    variable_manager.get_vars()

    # Test VariableManager.get_vars with supplying a fake

# Generated at 2022-06-25 14:18:03.647974
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # result_0
    vars_with_sources_1 = VarsWithSources()
    result_0 = vars_with_sources_1.get_vars()
    assert(result_0 == {})

    # result_1
    variable_manager_1 = VariableManager()
    host_0 = Host(name="test_0")
    task_1 = Task()
    play_0 = Play()
    result_1 = variable_manager_1.get_vars(host=host_0, task=task_1, play=play_0)

    # result_2
    variable_manager_2 = VariableManager()
    host_1 = Host(name="test_1")
    task_2 = Task()
    play_1 = Play()

# Generated at 2022-06-25 14:18:12.567431
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    vms = []
    host = 'testhost'

    # Test 1: Assert host facts are initialized to an empty dict
    vm = VariableManager()
    assert(vm.get_host_facts(host) == {})

    # Test 2: Use set_host_facts to add a new fact and assert
    fact1 = {u'fact1': u'foo'}
    vm.set_host_facts(host, fact1)
    assert(vm.get_host_facts(host) == fact1)

    # Test 3: Use set_host_facts to add an additional fact and assert
    fact2 = {u'fact2': u'bar'}
    vm.set_host_facts(host, fact2)
    expected_facts = {u'fact1': u'foo', u'fact2': u'bar'}
   

# Generated at 2022-06-25 14:18:16.334460
# Unit test for constructor of class VariableManager
def test_VariableManager():
    vm = VariableManager()

    assert vm is not None
    assert vm.host_vars is not None
    assert vm.group_vars is not None
    assert vm.extra_vars is not None
    assert vm.fact_cache is not None



# Generated at 2022-06-25 14:18:26.793392
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test using an empty inventory
    my_loader = DictDataLoader({})
    my_inventory = Inventory(loader=my_loader, variable_manager=VariableManager(loader=my_loader, inventory=my_inventory))
    my_variable_manager = my_inventory.get_variable_manager()
    my_variable_manager.set_inventory(my_inventory)
    my_variable_manager._vars_cache = dict()
    my_variable_manager._vars_cache['hostvars'] = dict()
    my_variable_manager._vars_cache['hostvars']['hostname'] = dict()
    my_variable_manager._vars_cache['hostvars']['hostname']['test1'] = 'testvalue'

# Generated at 2022-06-25 14:18:31.992513
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    """Tests of set_host_facts method of class VariableManager
       """
    set_host_facts_fixture = [
        (1, Mapping(), VarsWithSources)
    ]

    def test_VariableManager_set_host_facts_helper(test_host, test_facts, expected_exception):
        with pytest.raises(expected_exception):
            assert_set_host_facts_case(test_host, test_facts)

    for fixture in set_host_facts_fixture:
        test_VariableManager_set_host_facts_helper(*fixture)


# Generated at 2022-06-25 14:19:02.780625
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test Case 1: host_vars_file contains a dictionary with a child dictionary
    vm_obj_1 = VariableManager()
    assert vm_obj_1.set_host_variable('localhost', 'foo', {'bar': 10}) == None
    assert vm_obj_1.set_host_variable('localhost', 'foo', {'bar': 20}) == None

    # Test Case 2: host_vars_file contains a dictionary with single key
    vm_obj_2 = VariableManager()
    assert vm_obj_2.set_host_variable('localhost', 'bar', {'bar': 10}) == None

    # Test Case 3: host_vars_file contains an empty dictionary
    vm_obj_3 = VariableManager()
    assert vm_obj_3.set_host_variable('localhost', 'foo', {}) == None


# Generated at 2022-06-25 14:19:05.492576
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=None, variable_manager=None))

    assert variable_manager
    assert isinstance(variable_manager, VariableManager)


# Generated at 2022-06-25 14:19:16.805411
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Initialize a VariableManager object
    variable_manager = VariableManager()

    # Set a non-persistent fact for host 'test_nonpersistent_fact'
    variable_manager.set_nonpersistent_facts('test_nonpersistent_fact', dict({'nonpersistent_fact_value': 'nonpersistent_fact_value'}))

    # Save non-persistent facts and hostvars to new_var_db_a
    new_var_db_a = dict()
    new_var_db_a['vars_cache'] = variable_manager._vars_cache
    new_var_db_a['nonpersistent_fact_cache'] = variable_manager._nonpersistent_fact_cache
    new_var_db_a['hostvars'] = variable_manager._hostvars

    # Update the non-pers

# Generated at 2022-06-25 14:19:22.577291
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vars_with_sources_0 = VarsWithSources()
    # vars_with_sources_0.update({'a': 'A', 'b': 'B', 'c': 'C'})
    self = VariableManager(loader=None, inventory=None)
    host = 'localhost'
    varname = 'a'
    value = 'A'
    self.set_host_variable(host=host, varname=varname, value=value)
    assert 'a' in self._vars_cache[host]
    assert 'A' in self._vars_cache[host].values()


# Generated at 2022-06-25 14:19:31.665726
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # Note: this test assumes that all methods it uses are tested
    # thoroughly in the class they are defined

    # Create a loader, inventory, cache and playbook
    loader = DictDataLoader({})
    inventory = Inventory(loader=loader)
    cache = FakeFactCache()
    playbook = dict()

    # Create a VariableManager instance
    variable_manager = VariableManager()

    # Test that the get_vars method works as expected
    # with an empty playbook
    result = variable_manager.get_vars(loader=loader, inventory=inventory,
                                       cache=cache, play=playbook)

    assert(isinstance(result, dict))
    assert(len(result) == 13)
    assert('omit' in result)
    assert(result['omit'] == '')
    assert('inventory_hostname' in result)
   

# Generated at 2022-06-25 14:19:42.224747
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vars_with_sources_1 = VarsWithSources()

    # test_get_vars_1
    # test with setup_cache = False
    setup_cache = False
    host_cache = HostVars(dict(), setup_cache)
    fact_cache = FactCache(dict())
    variables = VariableManager(loader=None, inventory=None, host_cache=host_cache, fact_cache=fact_cache)
    play = Play.load(dict(hosts='localhost', gather_facts='no'), loader=None, variable_manager=variables)
    delegated_vars = {'localhost': vars_with_sources_1.get_vars()}
    host = 'localhost'
    task = None
    include_delegate_to = True
    include_hostvars = True
    result = variables.get

# Generated at 2022-06-25 14:19:51.014661
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vars_0 = VariableManager()

    vars_1 = VariableManager()
    vars_1.host_vars_from_top = True
    vars_1.host_vars_from_group = True
    vars_1.host_vars_from_inventory = True
    vars_1.settings = dict()
    vars_1.settings["HOST_VARS_PATTERN"] = '{{playbook_dir}}/host_vars/{{inventory_hostname}}'
    vars_1.settings["GROUP_VARS_PATTERN"] = '{{playbook_dir}}/group_vars/{{inventory_group_name}}'
    vars_1.settings["YAML_FILENAME_PATTERN"] = '{{inventory_dir}}/{{inventory_file}}'
    v

# Generated at 2022-06-25 14:19:53.760771
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    assert variable_manager_0._vars_cache == {}
    assert variable_manager_0._fact_cache == {}
    assert variable_manager_0._nonpersistent_fact_cache == {}


# Generated at 2022-06-25 14:20:01.600143
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    ############################################################################
    #### Unit test configuration ###############################################
    ############################################################################

    ############################################################################
    #### Unit test code ########################################################
    ############################################################################

    # Create a new VariableManager object and validate its attributes
    # (1) - Validate the attributes that were set by the constructor
    varMgr0 = VariableManager()


    ############################################################################
    #### Validation phase ######################################################
    ############################################################################

    print("\n---------- Unit test 1 ----------")
    print("\nDescription: Validate the attributes that were set by the constructor")
    print("input: varMgr0 = VariableManager()")
    print("output:")
    print("        varMgr0.vars: %s" % varMgr0.vars)
   

# Generated at 2022-06-25 14:20:05.819720
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test simple case
    vm = VariableManager()
    test_host = 'test_host'
    test_varname = 'foo'
    test_value = 'bar'
    vm.set_host_variable(test_host, test_varname, test_value)
    assert vm._vars_cache[test_host][test_varname] == test_value

    # Now test with existing item
    test_value2 = 'test2'
    vm.set_host_variable(test_host, test_varname, test_value2)
    assert vm._vars_cache[test_host][test_varname] == test_value2


# Generated at 2022-06-25 14:20:33.493958
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vm = VariableManager()
    vm.get_vars(host=None, include_hostvars=True)



# Generated at 2022-06-25 14:20:42.012087
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # initialize the VariableManager and set its options
    option_vars = dict()
    option_vars['http_proxy'] = 'http://proxy01:8080/'
    option_vars['https_proxy'] = 'http://proxy01:8080/'
    option_vars['ansible_check_mode'] = True
    option_vars['ansible_verbosity'] = 2
    option_vars['ansible_show_custom_stats'] = False
    option_vars['ansible_module_name'] = 'ping'
    option_vars['ansible_no_log'] = True
    option_vars['ansible_become'] = True
    option_vars['ansible_become_method'] = 'sudo'
    option_vars['ansible_become_user'] = 'root'

# Generated at 2022-06-25 14:20:51.987495
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # Test Case 1:
    # Test behavior of get_vars with a simple empty variable dictionary
    variable_manager_1 = VariableManager()

    host_1 = None
    play_1 = None
    task_1 = None

    variable_manager_1.get_vars(
        play=play_1,
        host=host_1,
        task=task_1,
        include_delegate_to=False,
        include_hostvars=False
    )

    # Test Case 2:
    # Test behavior of get_vars with a slightly more complicated set of variables
    variable_manager_2 = VariableManager()

    host_2 = Mock()
    host_2.get_vars.return_value = dict()

    play_2 = Mock()

# Generated at 2022-06-25 14:20:53.600792
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    assert variable_manager.get_vars() == {}, "get_vars failed"

# Generated at 2022-06-25 14:21:03.683314
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var = VariableManager()

    var.set_host_facts(host='test1', facts={'var1': 'value1'})
    var.set_host_variable(host='test1', varname='var2', value='value2')

    # Test for fetching host_vars
    assert var.get_vars(play=None, host=Host(name='test1'), task=None) == {'var1': 'value1', 'var2': 'value2'}

    # Test for fetching host_vars merged with passed vars
    assert var.get_vars(play=None, host=Host(name='test1'), task=None, additional_vars={'var3': 'value3'}) == {'var1': 'value1', 'var2': 'value2', 'var3': 'value3'}

# Generated at 2022-06-25 14:21:07.091292
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()

    variable_manager.get_vars(
        play=None,
        host=MagicMock(name='host'),
        task=None,
        include_delegate_to=False,
        include_hostvars=True)


# Generated at 2022-06-25 14:21:12.146405
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vars_with_sources_0 = VarsWithSources()
    inventory_0 = BaseInventory()
    loader_0 = DataLoader()
    variable_manager_0 = VariableManager(loader=loader_0, inventory=inventory_0)
    host_0 = Host(name=u'host_0')
    task_0 = Task()
    play_0 = Play()
    # Note that this value is not currently used in get_vars()
    _hosts_0 = None
    # Note that this value is not currently used in get_vars()
    _hosts_all_0 = None

# Generated at 2022-06-25 14:21:14.796943
# Unit test for constructor of class VariableManager
def test_VariableManager():
    test_case_0()

if __name__ == "__main__":
    test_VariableManager()

# Generated at 2022-06-25 14:21:21.164172
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    results = []
    results.append(test_case_0())

    if len(results) > 0 and False in results:
        return False
    else:
        return True

if __name__ == '__main__':
    # The following is a simple test to ensure that get_vars(), which is used
    # in ansible-playbook for templating, does not fail the unit test.
    print(test_VariableManager_get_vars())

# Generated at 2022-06-25 14:21:23.495105
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # initializes object
    vm = VariableManager()
    # assert function with expected results
    assert vm



# Generated at 2022-06-25 14:21:55.691124
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    class TaskDS(object):
        _role = Mock()

        def __init__(self, delegate_to):
            self.delegate_to = delegate_to

        def _get_role_implicit_dependencies(self):
            return []

    class Play(object):
        def __init__(self):
            self.roles = []

        def get_name(self):
            return 'test_play'

    class Role(object):
        def __init__(self, name):
            self.name = name

        def get_name(self, include_role_fqcn=False):
            return self.name

    class Host(object):
        def __init__(self, name):
            self.name = name

# Generated at 2022-06-25 14:22:04.412165
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test for case when a host is passed as argument
    host_1 = Host('host_1')
    vm_1 = VariableManager(loader=None, inventory=None)
    vm_1.clear_facts(host=host_1)
    result = vm_1.get_vars(host=host_1)

# Generated at 2022-06-25 14:22:16.443439
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import string_types

    # Test the error raising if VariableManager._fact_cache is empty
    vms = VariableManager()
    hostname = 'host-01'
    facts = {'hostname': to_bytes(hostname)}
    expected_exception = KeyError
    expected_msg = '{0}'.format(hostname)
    try:
        vms.set_host_facts(hostname, facts)
    except expected_exception as e:
        assert expected_msg in str(e)
    else:
        raise AssertionError('Expected {0} not raised'.format(expected_exception))

    # Test the error raising if hostname is not a (unicode or string) type
    hostname = 1


# Generated at 2022-06-25 14:22:20.912950
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    r = Runner(module_name='ping')
    r._ds = {'args': {'data': 'pong'}}
    r.module_name = 'ping'
    r.connection = 'smart'
    r.become = None
    r.no_log = False
    r.run()


# Generated at 2022-06-25 14:22:31.706664
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vars_with_sources_0 = VarsWithSources()

    my_tag = dict()
    # my_hostname = 'host_0'
    # my_hostname = 'host_1'
    # my_hostname = 'bad_host'
    my_hostname = None
    my_task = None
    my_play = None
    include_hostvars = True
    include_delegate_to = True

    vars_with_sources_0.get_vars(play=my_play,
                                 host=my_hostname,
                                 task=my_task,
                                 include_hostvars=include_hostvars,
                                 include_delegate_to=include_delegate_to,
                                 tag=my_tag)


# Generated at 2022-06-25 14:22:40.804125
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Ensure that get_vars is able to handle inventory objects that support no groups
    # (which can happen during dry runs)
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    class _InventoryManager(InventoryManager):
        def __init__(self, *args, **kwargs):
            super(_InventoryManager, self).__init__(*args, **kwargs)

        def get_groups_dict(self):
            # Ensure that get_groups_dict, is handled
            # If this doesn't raise an exception, the test is successful
            raise RuntimeError('get_groups_dict() should not have been called.')

    class _Host(Host):
        def __init__(self, name, inventory):
            super(_Host, self).__

# Generated at 2022-06-25 14:22:47.082614
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vm = VariableManager()
    facts = {
        'ansible_env': {
            'yes': True,
        },
        'ansible_all_ipv4_addresses': [
            '192.0.2.1',
        ],
    }
    vm.set_nonpersistent_facts('localhost', facts)
    print(vm._nonpersistent_fact_cache)
    # TODO: assert expected output


# Generated at 2022-06-25 14:22:54.631030
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    This is a test for method get_vars of class VariableManager
    '''
    # Test case 0:
    try:
        vm = VariableManager(loader=Mock(), inventory=Mock(groups={}))
        vm.get_vars(play=None, task=None, include_delegate_to=True, include_hostvars=True)
    except Exception as e:
        raise AnsibleError(to_text(e, nonstring='simplerepr'))

    # Test case 1:

# Generated at 2022-06-25 14:22:59.951380
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    inventory = InventoryManager(loader=DictDataLoader({
        'host_vars/host1': [],
        'host_vars/host2.yaml': "weird_fact: we see this in host2_vars",
    }))
    host1 = inventory.get_host(u'host1')
    host2 = inventory.get_host(u'host2')
    vm = VariableManager(loader=None, inventory=inventory)

    # test the basic case
    vm.extra_vars = {u'test_var': u'test_value'}
    vars_dict = vm.get_vars(play=None, host=host1)
    assert vars_dict[u'test_var'] == u'test_value'

    # test that host1 doesn't have the strange fact
    vars_

# Generated at 2022-06-25 14:23:08.831833
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    user_password = dict(password="password0")
    inventory = Inventory("inventory")
    host0 = "host0"
    host = inventory.get_host(host0)
    assert(host is not None)
    task0 = "task0"
    play = "play0"
    vars_with_sources = VarsWithSources()
    vars_with_sources.set_nonpersistent_facts(host0, user_password)
    vars_with_sources._vars_cache[host0] = dict(vars_cache_host0="vars_cache_host0")
    vars_with_sources._hostvars[host0] = dict(hostvars_host0="hostvars_host0")

# Generated at 2022-06-25 14:23:38.763986
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()

    host_0 = "localhost"

# Generated at 2022-06-25 14:23:43.719730
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    sut = VariableManager()
    host = "test_host"
    facts = {"fact1": "value1", "fact2": "value2"}
    sut.set_nonpersistent_facts(host, facts)
    assert sut.get_nonpersistent_facts(host) == facts


# Generated at 2022-06-25 14:23:45.539480
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()


# Generated at 2022-06-25 14:23:54.425694
# Unit test for constructor of class VariableManager
def test_VariableManager():
    module_args = dict()
    module_args['host_list'] = "hosts"
    module_args['subset'] = "subset"
    module_args['module_name']= "debug"
    module_args['module_path'] = "library"
    module_args['module_args'] = "args"
    module_args['task_name'] = "a_task"
    module_args['verbosity'] = 0
    module_args['forks'] = 10
    module_args['become'] = None
    module_args['become_method'] = None
    module_args['become_user'] = None
    module_args['check'] = False
    module_args['listhosts'] = None
    module_args['listtasks'] = None
    module_args['listtags'] = None


# Generated at 2022-06-25 14:23:55.978942
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()


if __name__ == "__main__":
    test_VariableManager()

# Generated at 2022-06-25 14:24:04.849187
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    host = Host('test_host')
    host = Host('test_host')
    play = Play.load(dict(
        name = 'test_play',
        roles = [],
    ))
    task = None
    include_hostvars = True
    variables = None
    new_vars = variable_manager_0.get_vars(host=host, play=play, task=task,
                                           include_hostvars=include_hostvars,                                           variables=variables)
    assert new_vars


# Generated at 2022-06-25 14:24:11.419322
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Variables for test_VariableManager_get_vars
    class MockObject(object):
        pass
    mock_obj_0 = MockObject()
    mock_obj_0._ds = MockObject()
    mock_obj_0._ds.get_search_path = MockObject()
    mock_obj_0._ds.get_search_path.return_value = None
    mock_obj_0.delegate_to = 'delegated_host_name'
    mock_obj_0.loop = [None]
    mock_obj_0.loop_control = MockObject()
    mock_obj_0.loop_control.loop_var = 'item'
    mock_obj_0.action = 'template'
    mock_obj_0.action = 'template'
    mock_obj_0.action = 'template'
   

# Generated at 2022-06-25 14:24:17.510988
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager() #Succeded

    #Calling get_vars with no parameters
    try:
        variable_manager_0.get_vars()
    except Exception as e:
        print(e)

    #Calling get_vars with args
    try:
        variable_manager_0.get_vars(UUID(int=0), Play(), Host(name='localhost'))
    except Exception as e:
        print(e)

test_VariableManager_get_vars()

# Generated at 2022-06-25 14:24:19.282507
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.get_vars()


# Generated at 2022-06-25 14:24:29.021929
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''
    Creates a new object of VariableManager class and prints its data members and
    calls the methods of class VariableManager
    '''
    variable_manager_0 = VariableManager()

# Generated at 2022-06-25 14:25:25.030329
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_variable('host1', 'varname1', 'value1')
    variable_manager_0.set_host_variable('host1', 'varname2', 'value2')
    variable_manager_0.set_host_variable('host2', 'varname1', 'value1')
    variable_manager_0.set_host_variable('host2', 'varname2', 'value2')

    # Test for case hostname is not None
    variables_0 = variable_manager_0.get_vars(host=FakeHost('host1'))
    assert variables_0['varname1'] == 'value1'
    assert variables_0['varname2'] == 'value2'

    # Test for case hostname is None

# Generated at 2022-06-25 14:25:26.473263
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()
    return variable_manager_0


# Generated at 2022-06-25 14:25:29.003817
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variables = variable_manager_0.get_vars()
    # assert all(['OmitToken' == o  for o in variables.keys()])


# Generated at 2022-06-25 14:25:36.196463
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    inventory_0 = Inventory(loader=None, variable_manager=None, host_list=[])
    play_0 = Play().load(dict(
        name = 'test_play_0',
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action = dict(module = 'debug', args = dict(msg = '{{ var_0 }}')))
        ]
    ), variable_manager=None, loader=None)
    variable_manager_0 = VariableManager(loader=None, inventory=inventory_0)
    variable_manager_1 = VariableManager(loader=None, inventory=inventory_0)
    # Verify that method get_vars returns the correct values