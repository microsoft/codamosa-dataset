

# Generated at 2022-06-25 14:16:38.098704
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_manager_0 = VariableManager()
    var_manager_0.set_host_variable("host_0", "varname_0", "value_0")
    var_manager_0.set_host_variable("host_0", "varname_1", "value_1")


# Generated at 2022-06-25 14:16:47.402433
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():

    # Setup
    variable_manager = VariableManager(loader=None, inventory=None)
    facts_0 = dict()
    facts_0["hostname"] = "test_hostname"
    host_0 = "test_host"
    variable_manager.set_nonpersistent_facts(host=host_0, facts=facts_0)

    # Test
    variable_manager.set_nonpersistent_facts(host=host_0, facts=facts_0)

    # Assert the expected results
    assert variable_manager._nonpersistent_fact_cache["test_host"]["hostname"] == "test_hostname"


# Generated at 2022-06-25 14:16:56.430528
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    host_0 = 'host_0'
    facts_0 = dict()
    facts_0['facts'] = dict()
    facts_0['facts']['hostvars'] = dict()
    facts_0['facts']['hostvars'][host_0] = dict()
    facts_0['ansible_facts'] = dict()
    facts_0['ansible_facts']['hostvars'] = dict()
    facts_0['ansible_facts']['hostvars'][host_0] = dict()
    vm = VariableManager()
    vm.set_host_facts(host_0, facts_0)


# Generated at 2022-06-25 14:17:05.345743
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Testing case 0
    vars_with_sources_0 = VarsWithSources()
    var_0 = preprocess_vars(vars_with_sources_0)
    # Testing case 1
    inventory_1 = Host(name='localhost')
    tasks_1 = list()
    tasks_1.append(Task())
    vars_with_sources_1 = VarsWithSources(tasks=tasks_1)
    var_1 = preprocess_vars(vars_with_sources_1)
    # Testing case 2
    inventory_2 = Host(name='localhost')
    tasks_2 = list()
    tasks_2.append(Task())
    vars_with_sources_2 = VarsWithSources(tasks=tasks_2)
    var_2 = preprocess_vars

# Generated at 2022-06-25 14:17:10.924037
# Unit test for constructor of class VariableManager
def test_VariableManager():
    vars_with_sources_0 = VarsWithSources()
    var_0 = VariableManager(vars_with_sources_0)
    assert var_0 is not None
    # print()
    # print(type(var_0))
    # print(dir(var_0))
    # print()


# Generated at 2022-06-25 14:17:18.787362
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test with simple inventory, play, and task
    inventory = get_inventory(inventory_file_0)
    play_0 = get_play(play_file_0)
    task_0 = get_task('include_tasks', {'with_items': [
        'asdf',
        [1,2],
        {'asdf': 'asdf'}
    ]})

    # Test with VariableManager that has no fact cache
    variable_manager_0 = VariableManager(
        loader=get_loader(),
        inventory=inventory,
        variable_manager=None,
        use_fact_cache=False
    )
    variable_manager_0.vars_cache = get_vars_cache_0()
    expected_vars_0 = get_expected_vars_0()
    actual_vars_0 = variable

# Generated at 2022-06-25 14:17:28.618028
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # TODO: Add more test cases for VariableManager.get_vars
    vars_with_sources_0 = VarsWithSources()
    var_0 = preprocess_vars(vars_with_sources_0)
    vars_with_sources_1 = VarsWithSources()
    var_1 = preprocess_vars(vars_with_sources_1)
    var_2 = preprocess_vars(vars_with_sources_1)
    # Example: Assert that 'vars_with_sources_0' is same as 'vars_with_sources_1'
    # assert(vars_with_sources_0 == vars_with_sources_1)


# Generated at 2022-06-25 14:17:35.400630
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test 0
    host_0 = 'hostname'
    varname_0 = 'domain_name'
    value_0 = 'domain.name'
    var_0 = {'hostname': {'domain_name': value_0}}
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host_0, varname_0, value_0)
    if variable_manager._vars_cache != var_0:
        # Unit test failed
        return False
    return True


# Generated at 2022-06-25 14:17:40.599594
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    vars_with_sources_0 = VarsWithSources()
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_facts('host_0', vars_with_sources_0.get_vars())


# Generated at 2022-06-25 14:17:44.367848
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()
    host = "localhost"
    facts = {"test_key":"test_value"}
    variable_manager.set_nonpersistent_facts(host, facts)
    assert variable_manager._nonpersistent_fact_cache[host] == facts


# Generated at 2022-06-25 14:18:20.402618
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    Unit test for method get_vars of class VariableManager.
    '''
    # Test the case when ``host`` is a string (host name)
    print("\nTest the case when 'host' is a string ...")
    variable_manager_0 = VariableManager()
    host_0 = 'localhost'
    results_0 = variable_manager_0.get_vars(host=host_0)
    print("\nresults_0: {}".format(results_0))
    print("len(results_0): {}".format(len(results_0)))
    print("type(results_0): {}".format(type(results_0)))


# Generated at 2022-06-25 14:18:29.341899
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()

    host_0 = Host(name='test_host_0')
    host_1 = Host(name='test_host_1')

    host_0_vars = dict()
    host_1_vars = dict()

    inventory_hostname = 'host_name'
    play_hosts = ['foo']
    ansible_play_hosts_all = ['foo']
    ansible_play_hosts = ['foo']
    ansible_play_batch = ['foo']
    ansible_play_role_names = ['foo']
    ansible_play_name = 'foo'
    ansible_role_names = ['foo']
    hostvars = {'host_name': 'foo'}
    groups = {'group_name': 'bar'}
    role_names

# Generated at 2022-06-25 14:18:38.957970
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    loader = DictDataLoader({
        'varfile1.yml': """
---
a: 1
b: 2
c:
  d: 3
  e: 4
""",
        'varfile2.yml': """
---
c:
  f: 5
  g: 6
"""
    })
    variable_manager_1 = VariableManager(loader=loader)

    # Test play_context
    play_context_1 = PlayContext()
    play_context_1.setup_cache=True
    play_context_1.setup_cache_path = 'setup_cache_path_1'
    play_context_1.user = 'user_1'
    play_context_1.remote_addr = 'remote_addr_1'
    play_context_1.network_os = 'network_os_1'


# Generated at 2022-06-25 14:18:49.473361
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    t_play_0 = Play()
    t_play_0._role_name = 'role_name_0'
    t_play_0._parent = 'parent_0'
    t_play_0._uuid = 'uuid_0'
    t_host_0 = Host()
    t_host_0._name = 'host_name_0'
    t_host_0._options = 'host_options_0'
    t_host_0._variables = 'host_variables_0'
    t_host_0._priority = 'host_priority_0'

# Generated at 2022-06-25 14:19:00.222487
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    host_0 = Host('host_0_name')
    host_0._data = {'hostvars': {'host_0_name': {'host_0_var': 'host_0_value'}}}
    play_0 = Play()
    task_0 = Task()
    play_0.hosts = 'all'
    task_0.register = 'host_var'
    task_0.set_loader(DictDataLoader({'host_var': "{'host_var': 'value'}"}))
    task_0.action = 'host_var'
    play_0.add_task(task_0)

# Generated at 2022-06-25 14:19:03.204625
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    variable_manager_1.get_vars(play=None, host=None, task=None)
    variable_manager_1.get_vars(play=None, host=None, task=None, include_hostvars=True)



# Generated at 2022-06-25 14:19:14.651935
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()

    # Set some variables
    variable_manager_1._extra_vars = {u'var1': u'somevalue', u'var2': u'othervalue', u'var3': u'yetanothervalue'}

    # Set some options variables
    variable_manager_1._options_vars = {u'ansible_foo': u'foovalue', u'ansible_bar': u'barvalue'}

    # Set some host variables
    variable_manager_1._vars_cache['somehost'] = {u'var1': u'value1', u'var2': u'value2'}

# Generated at 2022-06-25 14:19:22.117063
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    hostname = "localhost"
    facts_1 = {'ansible_os_family': 'RedHat', 'ansible_distribution': 'RedHat'}
    facts_2 = {'ansible_os_family': 'CentOS', 'ansible_distribution': 'CentOS'}
    variable_manager_1 = VariableManager()
    variable_manager_1.clear_facts(hostname)
    variable_manager_1.set_nonpersistent_facts(hostname, facts_1)
    variable_manager_1.set_nonpersistent_facts(hostname, facts_2)
    assert variable_manager_1.host_nonpersistent_vars[hostname]['ansible_os_family'] == 'CentOS'

# Generated at 2022-06-25 14:19:30.910690
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0._omit_token = 'omit_token'
    variable_manager_0._options_vars = {'a': 1}
    variable_manager_0._hostvars = None
    variable_manager_0._fact_cache = {'b': 2}
    variable_manager_0._nonpersistent_fact_cache = {'c': 3}
    variable_manager_0._vars_cache = {'d': 4}

    args = [
        'args_0',
        'args_1',
        'args_2',
        'args_3',
        'args_4',
        'args_5'
    ]

    # get_vars(play=None, host=None, task=None, include_delegate_to=False,

# Generated at 2022-06-25 14:19:38.593169
# Unit test for constructor of class VariableManager
def test_VariableManager():
    try:
        loader = DataLoader()
        play_0 = Play.load(dict(
                name = "Test Play",
                hosts = "127.0.0.1",
                gather_facts = "no",
                tasks = [
                    dict(action=dict(module='ping'))
                ]
            ),
            variable_manager=variable_manager_0,
            loader=loader
        )
        variable_manager_0 = VariableManager(play=play_0)
        assert True
    except:
        assert False, 'Failed to create a Variable Manager'


# Generated at 2022-06-25 14:21:21.897512
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    host_name = 'localhost'
    # Create a variable manager.
    variable_manager = VariableManager()
    # Create a facts dict.
    facts = {'fact1': 1, 'fact2': 2}
    # Set the nonpersistent facts.
    variable_manager.set_nonpersistent_facts(host_name, facts)
    # Check the correctness of nonpersistent fact cache.
    assert variable_manager._nonpersistent_fact_cache['localhost'] == {'fact1': 1, 'fact2': 2}


# Generated at 2022-06-25 14:21:29.701459
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager()
    host = '127.0.0.1'
    varname = 'ssh_port'
    value = 22
    variable_manager_1.set_host_variable(host, varname, value)
    if variable_manager_1._vars_cache[host][varname] != value:
        raise AssertionError('Failed to set variable {0}:{1}'.format(host, varname))

if __name__ == "__main__":
    test_case_0()
    test_VariableManager_set_host_variable()

# Generated at 2022-06-25 14:21:36.167925
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    set_host_variable_host = ""
    set_host_variable_varname = ""
    set_host_variable_value = ""
    try:
        set_host_variable_0 = variable_manager_0.set_host_variable(set_host_variable_host, set_host_variable_varname, set_host_variable_value)
    except Exception as exception:
        print(exception)

if __name__ == '__main__':
    test_VariableManager_set_host_variable()

# Generated at 2022-06-25 14:21:41.245115
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager()
    test_host = 'test_host'
    test_varname = 'test_varname'
    test_value = 'test_value'
    variable_manager_1.set_host_variable(test_host, test_varname, test_value)
    assert variable_manager_1._vars_cache[test_host][test_varname] == test_value


# Generated at 2022-06-25 14:21:49.313791
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    host = 'AWS_0'

# Generated at 2022-06-25 14:21:51.787074
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():

    variable_manager_1 = VariableManager()
    variable_manager_1.set_host_variable("host1", "VAR_NAME", "VAR_VALUE")


# Generated at 2022-06-25 14:21:54.058406
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()
    assert(isinstance(variable_manager_0, VariableManager))


# Generated at 2022-06-25 14:21:58.689996
# Unit test for constructor of class VariableManager
def test_VariableManager():
    try:
        test_case_0()
        ansible_util.logger.info("Executing test case 0 succeeded.")
    except Exception as ex:
        ansible_util.logger.error("Executing test case 0 failed. Reason: {0}".format(str(ex)))
        sys.exit(1)

if __name__ == "__main__":
    test_VariableManager()

# Generated at 2022-06-25 14:22:02.924636
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    variable_manager.set_host_variable('localhost', 'ansible_ssh_host', 'localhost')
    try:
        assert variable_manager._vars_cache['localhost']['ansible_ssh_host'] == 'localhost'
    except Exception as e:
        raise Exception(e)


# Generated at 2022-06-25 14:22:14.467715
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()

    # get_vars parameters
    play = None
    host = None
    task = None
    include_delegate_to = True
    include_hostvars = False
    include_constructed = True

    # get_vars execution
    variables_0 = variable_manager_0.get_vars(play=play, host=host, task=task, include_delegate_to=include_delegate_to, include_hostvars=include_hostvars, include_constructed=include_constructed)

    # Test invocation 1
    play = None
    host = None
    task = None
    include_delegate_to = False
    include_hostvars = True
    include_constructed = True

# Generated at 2022-06-25 14:23:14.294514
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()

    task = Task()
    task.host = 'host'
    task.task_vars = {'task_var1': 'value1', 'task_var2': 'value2'}
    play = Play()
    play.hosts = 'host1'

    # test 1
    #   Input:
    #     - task.host = 'host1'
    #     - task.task_vars = None
    #     - play.hosts = 'host1'
    #   Expected result:
    #     - variables = {}
    #     - include_delegate_to = False
    #     - include_hostvars = True
    variables = variable_manager_1.get_vars(task=task, play=play)

# Generated at 2022-06-25 14:23:17.727679
# Unit test for constructor of class VariableManager
def test_VariableManager():
    try:
        test_case_0()
    except:
        print("Unit test for constructor of class VariableManager in file '%s' FAILED" % __file__)
        raise
    else:
        print("Unit test for constructor of class VariableManager in file '%s' PASSED" % __file__)

if __name__ == '__main__':
    test_VariableManager()

# Generated at 2022-06-25 14:23:25.450594
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    random_hostname = random_alphanumeric()
    random_host = Host(name=random_hostname)
    #Set a random host var
    fact_name = random_alphanumeric()
    fact_value = random_alphanumeric()
    # Call method
    variable_manager_0.set_host_variable(random_hostname, fact_name, fact_value)
    # Check the results
    variables = variable_manager_0.get_vars(host=random_host)
    assert fact_value == variables.get(fact_name)
    # Check that machine facts are not returned by default
    machine_fact_name = "ansible_machine"
    assert machine_fact_name not in variables
    # Check that we can explicitly request machine facts
    variables = variable_manager

# Generated at 2022-06-25 14:23:28.722155
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()
    assert issubclass(VariableManager, object)
    assert isinstance(variable_manager, VariableManager)


# Generated at 2022-06-25 14:23:34.488962
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    task_0 = Task()
    host_0 = Host()
    with pytest.raises(SystemExit):
        variable_manager_0.get_vars(play=None,
                                    host=host_0,
                                    task=task_0,
                                    include_delegate_to=True,
                                    include_hostvars=True)


# Generated at 2022-06-25 14:23:38.299735
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()

    # Test the success case
    variable_manager_0.set_host_facts(host="host", facts={'a':1})


if __name__ == "__main__":
    test_case_0()
    test_VariableManager_set_host_facts()

# Generated at 2022-06-25 14:23:39.809129
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    assert variable_manager.get_vars() == {}


# Generated at 2022-06-25 14:23:48.564782
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    inventory_0 = InventoryManager(loader=Loader(), sources=None)
    variable_manager_0 = VariableManager()
    variable_manager_0.add_inventory(inventory_0)
    variable_manager_0.set_inventory(inventory_0)
    variable_manager_0.set_options_vars(20)
    variable_manager_0.extra_vars = dict()
    inventory_host_0 = inventory_0.get_host("host-1.example.com")
    variable_manager_0.get_vars(host=inventory_host_0, include_hostvars=True)



# Generated at 2022-06-25 14:23:56.496235
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # Unit test for get_vars
    variable_manager_1 = VariableManager()
    fd, fname = tempfile.mkstemp(prefix='ansible_test_')
    args = {"host_list": fname}
    Inventory(loader=None, variable_manager=variable_manager_1, host_list=args['host_list'])
    variable_manager_1.set_inventory(Inventory(loader=None, variable_manager=variable_manager_1, host_list=args['host_list']))
    assert set(variable_manager_1.get_vars().keys()) == set(['groups', 'inventory_file',
                                                             'inventory_hostname', 'inventory_basedir'])
    os.close(fd)
    os.unlink(fname)
    return True


# Generated at 2022-06-25 14:24:07.480776
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    Tests get_vars() on a VariableManager that is not linked to any hostvars
    or inventory.
    '''
    variable_manager = VariableManager()


# Generated at 2022-06-25 14:25:08.997186
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    variable_manager.set_host_variable('acme.co', 'ansible_version', '2.1')
    variable_manager.set_host_variable('acme.co', 'ansible_ssh_host', '127.0.0.1')
    variable_manager.set_host_variable('acme.co', 'ansible_user', 'root')
    variable_manager.set_host_variable('acme.co', 'ansible_connection', 'local')
    variable_manager.set_host_variable('acme.co', 'ansible_python_interpreter', '/usr/bin/env python3')
    variable_manager.set_host_variable('acme.co', 'extra_var_a', 'A')

# Generated at 2022-06-25 14:25:10.259738
# Unit test for constructor of class VariableManager
def test_VariableManager():
    test_case_0()

# Generated at 2022-06-25 14:25:19.453655
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-25 14:25:26.259225
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test case 1
    # Note: the hostvars arg is not used in the method
    hosts_array = ['host1', 'host2']
    test_hostvars = { "host1": [],
                      "host2": []
                    }
    host_0 = Mock()
    host_0.name = 'host1'
    host_1 = Mock()
    host_1.name = 'host2'
    variable_manager_1 = VariableManager()
    play_0 = Mock()
    play_0.hosts = 'host1'
    task_0 = Mock()
    task_0.host = 'host1'

    variable_manager_1.add_host_variable(host=host_0, varname="answer", value=42)

# Generated at 2022-06-25 14:25:31.576391
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    #setup
    variable_manager_0 = VariableManager()
    variable_manager_0.options_vars = {}
    variable_manager_0.extra_vars = {}
    variable_manager_0.default_vars = {}

    #test
    assert variable_manager_0.get_vars() == {'omit': None, 'ansible_search_path': [], 'vars': {}}, "Returned value for method get_vars of class VariableManager is wrong."



# Generated at 2022-06-25 14:25:39.901417
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test class instance of a PlayContext
    play_context_0 = PlayContext()

    # Test class instance of a Host
    host_0 = Host(name='test_host_0')

    # Test class instance of a TaskExecutor class
    task_executor_0 = TaskExecutor()

    # Test class instance of class VariableManager
    variable_manager_0 = VariableManager()

    # Test method call
    variable_manager_0.get_vars(host=host_0, include_hostvars=True)

    # Test method call
    variable_manager_0.get_vars(play=play_context_0, host=host_0, task=task_executor_0, include_delegate_to=True)

# if __name__ == "__main__":
#     test = TestVariableManager()
#