

# Generated at 2022-06-25 14:17:11.381020
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # test when inventory is None
    vm = VariableManager()
    assert vm._fact_cache == dict()
    assert vm._vars_cache == dict()
    assert vm._nonpersistent_fact_cache == dict()
    assert vm._fact_cache_lock == RLock()
    assert vm._vars_cache_lock == RLock()

    # test when inventory is not None
    inventory = MagicMock()
    vm = VariableManager(inventory)
    assert vm._fact_cache == dict()
    assert vm._vars_cache == dict()
    assert vm._nonpersistent_fact_cache == dict()
    assert vm._fact_cache_lock == RLock()
    assert vm._vars_cache_lock == RLock()



# Generated at 2022-06-25 14:17:23.041103
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Basic test
    test_case_0()

    # Create a VariableManager object
    var_mgr_0 = VariableManager()

    # Create a ansible.parsing.dataloader.DataLoader object with a path
    loader_0 = DataLoader()
    """Make `loader_0` an object of class `DataLoader` with a path."""

    # Create a ansible.inventory.manager.InventoryManager object with a path
    inv_mgr_0 = InventoryManager(loader=loader_0, sources='/usr/local/src/ansible-repo-git/test/ansible_test/inventory_manager/inventory.ini')

    # Set inventory to the created object
    var_mgr_0._inventory = inv_mgr_0

    # Create a ansible.parsing.vault.VaultSecret

# Generated at 2022-06-25 14:17:30.889070
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Test for supported param types for 'facts'
    vars_with_sources_0 = VarsWithSources()
    # Test for unsupported param types for 'facts'
    vars_with_sources_1 = VarsWithSources()

    # test available_variables
    vars_with_sources_0 = VarsWithSources()
    vars_with_sources_0.set_nonpersistent_facts('test_value_0', {'test_value_1': 'test_value_2'})
    vars_with_sources_0.set_nonpersistent_facts('test_value_0', {'test_value_1': 'test_value_2'})


# Generated at 2022-06-25 14:17:36.811839
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-25 14:17:47.737758
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    test_VariableManager_get_vars - test for method get_vars in class VariableManager
    '''
    # Test case 0:
    # Test with empty variable manager
    # Test with valid parameter values
    # Test with hostvars = False
    # Test with include_delegate_to = False
    # Test with task is None
    # Test with play is None
    # Expecting
    # Return value defaults to None
    vars_with_sources_0 = VarsWithSources()
    inventory_0 = InventoryManager(loader=None)
    variable_manager_0 = VariableManager(loader=None, inventory=inventory_0)
    hostvars_0 = False
    include_delegate_to_0 = False
    task_0 = None
    play_0 = None
    result_0 = variable_

# Generated at 2022-06-25 14:17:54.639375
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()

    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    play = Play().load(dict(name="test_play", hosts=['localhost'], gather_facts='no'), loader=loader, variable_manager=variable_manager)
    variable_manager._play = play

    included_file = IncludedFile()
    variable_manager._included_files = [included_file]

    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager._inventory = inventory
    variable_

# Generated at 2022-06-25 14:17:59.712880
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    vm.set_host_variable('host', 'var', 'value')
    assert vm.get_vars(play=None, host=None, task=None, include_delegate_to=True)['hostvars']['host']['var'] == 'value'



# Generated at 2022-06-25 14:18:02.784490
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    host = TestHost()
    fact_cache = dict()
    fact_cache[host.name] = dict()

    facts = dict()
    facts['ansible_test_fact'] = 'test'

    vm = VariableManager()
    vm._fact_cache = fact_cache
    vm.set_host_facts(host, facts)

    assert(vm._fact_cache[host.name]['ansible_test_fact'] == 'test')


# Generated at 2022-06-25 14:18:11.907565
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    VariableManager._vars_cache = dict()
    inventory = InventoryManager(loader=None, sources='localhost,')
    host = Host(name="localhost")
    play = Play().load(dict(
        name="Ansible Play ad-hoc",
        hosts='localhost',
        tasks=[
            dict(action=dict(module='ping', args=dict())),
        ]
    ), variable_manager=VariableManager(loader=None, inventory=inventory), loader=None)
    task = play.get_task(0)
    task.action = 'ping'
    variable_manager = VariableManager(loader=None, inventory=inventory)
    res = variable_manager.get_vars(play=play, host=host, task=task, include_delegate_to=False, include_hostvars=True)

# Generated at 2022-06-25 14:18:22.282176
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    global _hosts_all, _hosts
    inv = load_data_from_file(os.path.join("test_data", "hostvars_inventory.yml"))
    vm = VariableManager(loader=DictDataLoader(), inventory=inv)
    vm._vars_plugins = MagicMock()
    vm._vars_plugins.get_vars.return_value = {}
    vm._vars_plugins.run.return_value = []
    play_context = MagicMock()
    host_vars = vm.get_vars(play=MagicMock(), host=MagicMock(), task=MagicMock(), play_context=play_context)

# Generated at 2022-06-25 14:19:46.531596
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    cache_filepath = os.path.join(tempfile.mkdtemp(), "test_VariableManager_get_vars")
    if os.path.exists(cache_filepath):
        os.remove(cache_filepath)
    variable_manager._fact_cache = FSCache(cache_filepath)
    variable_manager.set_nonpersistent_facts('localhost', dict(gather_subset=['network'], ansible_facts={'ansible_network_resources': {}}))
    # Test case 1: Cache disabled
    variable_manager._cache_dir = None
    variable_manager.get_vars(host=Host(name='localhost'), include_cache=True)
    # Test case 2: Cache enabled (default)
    variable

# Generated at 2022-06-25 14:19:54.066428
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vars_with_sources_0 = VarsWithSources()
    var_0 = 'test'
    var_1 = 'bar'
    var_2 = 'baz'
    var_3 = 'qux'
    value_0 = 43
    value_1 = 52
    value_2 = 47
    value_3 = 97
    hostname_0 = 'foo.com'
    hostname_1 = 'bar.com'
    varmanager_0 = VariableManager()

    varmanager_0.set_host_variable(hostname_0, var_0, value_0)
    varmanager_0.set_host_variable(hostname_1, var_1, value_1)
    varmanager_0.set_host_variable(hostname_0, var_1, value_2)

# Generated at 2022-06-25 14:19:57.927086
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    my_vm = VariableManager()
    my_host = 'localhost'
    my_varname = 'my_variable_name'
    my_value = 'my_value'
    my_vm.set_host_variable(my_host, my_varname, my_value)
    vars_cache = my_vm.vars_cache
    assert vars_cache[my_host][my_varname] == my_value

# Generated at 2022-06-25 14:20:06.889297
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    var_man = VariableManager()

    # Set some facts for foo
    var_man.set_host_facts('foo', {'bar': 'baz'})

    # Ensure foo's facts are available
    assert var_man.get_vars(host=Host(name='foo'))['bar'] is 'baz'

    # Set an empty dict of facts for foo
    var_man.set_host_facts('foo', {})

    # Ensure foo's facts are still available
    assert var_man.get_vars(host=Host(name='foo'))['bar'] is 'baz'

    # Set an empty dict of facts for bar
    var_man.set_host_facts('bar', {})

    # Ensure bar's facts are not available

# Generated at 2022-06-25 14:20:08.440434
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''
    Test the constructor of class VariableManager
    '''
    test_case_0()

# Generated at 2022-06-25 14:20:19.789344
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Build a mock inventory_manager
    inventory_manager = mock.Mock()

    # Build a mock host with a name
    host = mock.Mock()
    host.name = "test_host"

    # Build a mock play object with a roles attribute
    play = mock.Mock()
    role1 = mock.Mock()
    role1.name = "foo"
    role1.get_name.return_value = role1.name
    role2 = mock.Mock()
    role2.name = "bar"
    role2.get_name.return_value = role2.name
    play.roles = [role1, role2]

    # Create a mock task object, with a role and dependency_role_names
    task = mock.Mock()
    task._role = mock.Mock()
    task

# Generated at 2022-06-25 14:20:27.125336
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    vm.set_host_variable('www.example.com', 'var3', 'The third var')
    assert vm._vars_cache['www.example.com']['var3'] == 'The third var'

    vm.set_host_variable('www.example.com', 'var4', 'The fourth var')
    assert vm._vars_cache['www.example.com']['var3'] == 'The third var'
    assert vm._vars_cache['www.example.com']['var4'] == 'The fourth var'

    vm.set_host_variable('www.example.com', 'var5', {'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-25 14:20:37.225858
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    '''
    Ensures that VariableManager.set_host_facts properly updates the fact cache
    for the given host.
    '''
    vm = VariableManager()

    # Host foo should be empty initially
    host = 'foo'
    assert vm.get_host_facts(host) == dict()

    # Set some facts for foo
    facts = dict(bar='baz')
    vm.set_host_facts(host, facts)
    assert vm.get_host_facts(host) == facts

    # Set some more facts for foo
    more_facts = dict(bar2='baz2')
    vm.set_host_facts(host, more_facts)
    assert vm.get_host_facts(host) == dict(bar='baz', bar2='baz2')

    # Try to set an integer for a host,

# Generated at 2022-06-25 14:20:41.268710
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()


# Generated at 2022-06-25 14:20:43.827070
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()
    try:
        variable_manager_1 = VariableManager(loader=None)
    except AnsibleError:
        pass



# Generated at 2022-06-25 14:21:44.187294
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # make a new variable manager and populate it with some data
    vm = _get_variable_manager()

# Generated at 2022-06-25 14:21:52.838131
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():

    vm = VariableManager()

    # test 1:
    # test with valid host and facts
    facts = {'key': 'value'}
    host = 'example-host'
    vm.set_nonpersistent_facts(host, facts)
    assert vm._nonpersistent_fact_cache[host] == facts

    # test 2:
    # test with an invalid facts
    with pytest.raises(AnsibleAssertionError) as exc:
        vm.set_nonpersistent_facts(host, None)
    assert "the type of 'facts' to set for nonpersistent_facts should be a Mapping but is a NoneType" in to_text(exc.value)
    assert exc.value.message == "the type of 'facts' to set for nonpersistent_facts should be a Mapping but is a NoneType"


# Generated at 2022-06-25 14:22:02.126707
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    v = VariableManager()
    v.clear_facts('localhost')
    assert 'localhost' not in v._fact_cache

    # Set one fact
    v.set_host_facts('localhost', {'fact_key_one': 'fact_value_one'})
    assert 'localhost' in v._fact_cache
    assert 'fact_key_one' in v._fact_cache['localhost']
    assert 'fact_value_one' == v._fact_cache['localhost']['fact_key_one']
    assert 'fact_key_one' in v.get_vars(play=None, host=None, task=None)['hostvars']['localhost']

# Generated at 2022-06-25 14:22:08.459032
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Prepare the scenario
    host = '1.1.1.1'
    varname = 'var1'
    value = {'a': 'A', 'b': 'B'}
    expected_vars_cache = {host: {varname: value}}

    # Run unit test
    vm = VariableManager()
    vm.set_host_variable(host, varname, value)

    # Validate results
    result = vm._vars_cache

    # Make sure that the results are the same
    assert_equals(expected_vars_cache, result)


# Generated at 2022-06-25 14:22:14.384558
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    x = VariableManager()
    x.set_host_variable("test_host", "test_varname", "test_value")
    assert x._vars_cache["test_host"]["test_varname"] == "test_value"


# Generated at 2022-06-25 14:22:21.864925
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    '''
    VariableManager: set nonpersistent facts

    test that nonpersistent facts are set in fact cache and
    cleared during clear fact cache
    '''
    fact_cache = dict()
    nonpersistent_fact_cache = dict()
    cache = dict() # empty vars cache
    inventory = None
    loader = None
    variable_manager = VariableManager(loader=loader, inventory=inventory,
                                       fact_cache=fact_cache,
                                       nonpersistent_fact_cache=nonpersistent_fact_cache,
                                       vars_cache=cache)
    assert len(variable_manager._fact_cache) == 0
    assert len(variable_manager._nonpersistent_fact_cache) == 0
    assert len(variable_manager._hostvars) == 0
    facts = {"key":"value"}

    variable_manager

# Generated at 2022-06-25 14:22:33.578307
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    empty_vm = VariableManager()

    # Initially the host facts cache should be empty
    assert empty_vm._fact_cache == {}

    # Setting non-dict facts should fail
    with pytest.raises(AnsibleAssertionError):
        empty_vm.set_host_facts('host_1', ['wrong_type', 'of', 'facts'])

    # Setting facts with a non-string key should fail
    with pytest.raises(AnsibleAssertionError):
        empty_vm.set_host_facts(['non_string_key'], {'fact_1': 'fact_1'})

    # Host facts should be retrievable after being set

# Generated at 2022-06-25 14:22:41.262280
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    vars_with_sources_0 = VarsWithSources()
    vm = VariableManager(loader=None, inventory=None)
    hostname = 'test_host'
    facts = {'test_factname': 'test_factvalue'}
    vm.set_host_facts(hostname, facts)
    assert vm._fact_cache.get(hostname, None) == facts
    vm._fact_cache[hostname] = vars_with_sources_0
    try:
        vm.set_host_facts(hostname, facts)
        assert False, 'Expected AnsibleAssertionError'
    except TypeError:
        pass
    except Exception as e:
        assert False, 'Expected AnsibleAssertionError but got %s' % e


# Generated at 2022-06-25 14:22:43.208675
# Unit test for constructor of class VariableManager
def test_VariableManager():
    test_case_0()

# Generated at 2022-06-25 14:22:47.329786
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    vm.set_host_variable("test", "variable", "new value")
    assert(vm._vars_cache["test"]["variable"] == "new value")

if __name__ == "__main__":
    test_case_0()
    test_VariableManager_set_host_variable()

# Generated at 2022-06-25 14:24:47.212187
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vars_with_sources_1 = VarsWithSources()
    vars_with_sources_1.set(_host_name, 'key1', 'val1', {'source': 'source'})
    vars_with_sources_1.set(_host_name, 'key2', 'val2', {'source': 'source'})
    vars_with_sources_1.set(_host_name, 'key3', 'val3', {'source': 'source'})
    vars_with_sources_1.extend(_host_name, {'key3': 'val3_1', 'key4': 'val4_1'}, {'source': 'source'})

# Generated at 2022-06-25 14:24:50.577634
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variableManager = VariableManager()
    all_vars_0 = variableManager.get_vars()
    # Check that get_vars returns a dictionary with at least one key
    assert len(all_vars_0) > 0


# Generated at 2022-06-25 14:24:57.248439
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test 1: Test, when two dictionaries are not composed of contents
    vars_with_sources_1 = VarsWithSources()
    vars_with_sources_1._vars_cache = {'ansible_fact': {'ansible_local': {'ansible_local_fact': True}}}
    vm = VariableManager()
    vm.set_host_variable('ansible_fact', 'ansible_local', {'ansible_local_fact_nested': False})
    assert vm._vars_cache['ansible_fact']['ansible_local'] == vars_with_sources_1._vars_cache['ansible_fact']['ansible_local']

    # Test 2: Test, when two dictionaries are composed of contents
    vars_with_sources_2 = VarsWithSources

# Generated at 2022-06-25 14:25:09.309689
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    default_var = 1
    default_var_type = 'int'
    host = ''
    host_with_var = 'test_host'
    host_var = 2
    host_var_type = 'int'
    host_vars = {'host_var': host_var}
    hostvars_type = 'dict'
    omit_token = '__omit_place_holder__'
    var_manager = 'var_manager'
    var_manager_type = 'VariableManager'

    #TestCase 1
    var_manager = VariableManager()
    var_manager.extra_vars = {'default_var': default_var}
    var_manager._vars_cache[host_with_var] = host_vars

# Generated at 2022-06-25 14:25:14.100547
# Unit test for constructor of class VariableManager
def test_VariableManager():

    vars_with_sources_0 = VarsWithSources()
    assert isinstance(vars_with_sources_0, VarsWithSources)

    loader_0 = DataLoader()
    vars_manager_0 = VariableManager(loader=loader_0)
    assert isinstance(vars_manager_0, VariableManager)



# Generated at 2022-06-25 14:25:21.923902
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # Test case 1: simplest vars_cache
    vars_cache = {
        'host1': {
            'var1': u'ValueA',
            'var2': 5,
            'var3': [u'ValueC', u'ValueD'],
            'var4': u'ValueE'
        },
        'host2': {
            'var1': u'ValueA',
            'var2': 5,
            'var3': [u'ValueC', u'ValueD'],
            'var4': u'ValueE'
        }
    }
    vm = VariableManager()
    vm._vars_cache = vars_cache
    host = Host('host1')
    assert vm.get_vars(host=host) == vars_cache['host1']
    # Test case 2: with cache

# Generated at 2022-06-25 14:25:27.545245
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    VariableManager.internal_instance = None
    ansible_vars = {
        'test1': 'testval1',
        'test2': 'testval2',
        'test3': 'testval3'
    }
    ansible_vars_2 = {
        'test2': 'testval2',
        'test3': 'testval3',
        'test4': 'testval4'
    }
    om = VarsModule()
    om.set_all({
        'test3': 'testval3',
        'test4': 'testval4',
        'test5': 'testval5'
    })

    for i in range(0, 2):
        vm = VariableManager()
        vm.extra_vars = ansible_vars
        vm.options_vars = ansible_vars

# Generated at 2022-06-25 14:25:31.323668
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    """
    Verifies a MutableMapping object is stored if the
    facts object passed in is a Mapping.
    """
    vm = VariableManager()
    host = 'localhost'
    facts = dict()
    vm.set_host_facts(host, facts)

    assert id(facts) != id(vm._fact_cache[host])


# Generated at 2022-06-25 14:25:37.347382
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():

    vm = VariableManager()

    # set a value without overwrite
    vm.set_nonpersistent_facts('test_host1', {'test_var1' : 1})
    assert vm._nonpersistent_fact_cache['test_host1']['test_var1'] == 1

    # set a value without overwrite
    vm.set_nonpersistent_facts('test_host1', {'test_var1' : 2})
    assert vm._nonpersistent_fact_cache['test_host1']['test_var1'] == 2


# Generated at 2022-06-25 14:25:45.575463
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    vars_with_sources = VarsWithSources()
    facts = dict()
    facts['os_family'] = 'Linux'
    facts['first_fact'] = 'first_fact_value'
    facts['nested_fact'] = dict()
    facts['nested_fact']['inner_fact'] = 'inner_fact_value'
    vars_with_sources.set_host_facts('localhost', facts)
    assert vars_with_sources._fact_cache['localhost']['os_family'] == 'Linux'
    assert vars_with_sources._fact_cache['localhost']['first_fact'] == 'first_fact_value'
    assert vars_with_sources._fact_cache['localhost']['nested_fact']['inner_fact'] == 'inner_fact_value'