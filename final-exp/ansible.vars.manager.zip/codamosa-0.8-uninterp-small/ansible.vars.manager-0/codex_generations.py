

# Generated at 2022-06-25 14:16:52.049969
# Unit test for method set_host_variable of class VariableManager

# Generated at 2022-06-25 14:16:53.324070
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()

    assert variable_manager._inventory is None
    assert variable_manager._options_vars is None


# Generated at 2022-06-25 14:17:03.156315
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Setup test
    inventory = InventoryManager(host_list=[])
    variable_manager_1 = VariableManager(loader=DictDataLoader({}), inventory=inventory)
    inventory.set_variable('foo', {'bar': 'baz'})
    inventory.set_variable('fizz', 'buzz')
    inventory.set_variable('password', 'hunter2')
    inventory.set_variable('foo_bar', 'foo_bar')
    host = inventory.get_host('foo')
    host.set_variable('bar', 'foo')
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_host(host=host, group='all')
    inventory.add_host(host=host, group='ungrouped')

# Generated at 2022-06-25 14:17:09.830806
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_variable('host_0', 'varname_0', 'value_0')
    variable_manager_0.set_host_variable('host_0', 'varname_1', 'value_1')
    variable_manager_0.set_host_variable('host_0', 'varname_2', 'value_2')
    variable_manager_0.set_host_variable('host_0', 'varname_3', 'value_3')
    variable_manager_0.set_host_variable('host_0', 'varname_4', 'value_4')
    variable_manager_0.set_host_variable('host_0', 'varname_5', 'value_5')
    variable_manager_0.set

# Generated at 2022-06-25 14:17:14.156024
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_get_vars = VariableManager()
    # Add parameters as an object of class Host
    host = Host(name="localhost")
    # call the get_vars method of the object variable_manager_get_vars
    variable_manager_get_vars.get_vars(host=host)


# Generated at 2022-06-25 14:17:25.220879
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    variable_manager_2 = VariableManager()
    variable_manager_3 = VariableManager()

    variable_manager_1.extra_vars = {
        'a': '1',
        'b': '2',
        'c': '3',
    }

    variable_manager_1.options_vars['d'] = '4'

    variable_manager_2.extra_vars = {
        'a': '1',
        'b': [1, 2, 3],
        'c': '3',
        'e': '5',
    }

    host = MockHost('localhost')

    # Case 1: For normal situation
    # First, we get self.extra_vars and self.options_vars
    # Second, we get the variables form self.get_host/

# Generated at 2022-06-25 14:17:26.973430
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()
    assert(variable_manager is not None)



# Generated at 2022-06-25 14:17:34.177233
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Make sure that the method works when vars_cache is empty
    variable_manager_0 = VariableManager()
    host_0 = 'host_0'
    varname_0 = 'varname_0'
    value_0 = {}
    variable_manager_0.set_host_variable(host_0, varname_0, value_0)
    assert variable_manager_0._vars_cache[host_0][varname_0] == value_0
    # Make sure that the method works when vars_cache has a host in it
    variable_manager_1 = VariableManager()
    host_1 = 'host_1'
    varname_1 = 'varname_1'
    value_1 = {}
    variable_manager_1._vars_cache[host_1] = {}
    variable_manager

# Generated at 2022-06-25 14:17:39.955835
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager()
    variable_manager_1.set_host_variable('localhost', 'ansible_connection', 'local')
    var_value = variable_manager_1.get_vars(host=Host('localhost'))
    assert var_value['ansible_connection'] == 'local'


# Generated at 2022-06-25 14:17:46.312594
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    variable_manager_1 = VariableManager()
    host_1 = Host("host")
    play_1 = Play()
    task_1 = Task()

    vars_1_result = variable_manager_1.get_vars(
        play=play_1,
        host=host_1,
        task=task_1,
        include_delegate_to=False,
        include_hostvars=True
    )
    assert vars_1_result == {}


# Generated at 2022-06-25 14:18:50.188798
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager(loader=None, inventory=None)
    variable_manager_2 = VariableManager(loader=None, inventory=None)

    variable_manager_1.set_host_variable(
        host='host_1',
        varname='varname_1',
        value='value_1'
    )
    variable_manager_1.set_host_variable(
        host='host_2',
        varname='varname_2',
        value='value_2'
    )

    variable_manager_2.set_host_variable(
        host='host_3',
        varname='varname_3',
        value='value_3'
    )

    # Variables that are set on variable_manager_1

# Generated at 2022-06-25 14:18:56.478567
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test for case 0 (get_vars)
    variable_manager_0 = VariableManager()
    play_0 = Play()
    host_0 = Host()
    task_0 = Task()
    inventory_0 = Inventory()
    result_0 = variable_manager_0.get_vars(play=play_0, host=host_0, task=task_0)
    assert result_0 == dict()

# Generated at 2022-06-25 14:19:04.347734
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    variable_manager_1.get_vars()

    variable_manager_2 = VariableManager()
    variable_manager_2.get_vars(play='')

    variable_manager_3 = VariableManager()
    variable_manager_3.get_vars(play='', host='')

    variable_manager_4 = VariableManager()
    variable_manager_4.get_vars(play='', host='', task='')

    variable_manager_5 = VariableManager()
    variable_manager_5.get_vars(play='', host='', task='', include_delegate_to='')

    variable_manager_6 = VariableManager()

# Generated at 2022-06-25 14:19:15.748750
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Pass
    vars_cache = {'hostvars': {'host0': {'vars': {'ansible_host': '192.168.0.1', 'ansible_user': 'test_user', 'ansible_password': 'test_password'}}}}
    inventory = BaseHost()
    play = BaseTask()
    task = BaseTask()
    loader = BaseLoader()
    variable_manager = VariableManager(vars_cache=vars_cache, inventory=inventory, loader=loader)
    res = variable_manager.get_vars(play=play, host=play, task=task, include_delegate_to=False, include_hostvars=False)
    assert res['ansible_play_hosts_all'] == ['host0']

# Generated at 2022-06-25 14:19:20.756736
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    host_0 = Host(name="hostname")
    play_0 = Play()
    task_0 = Task()
    include_hostvars_0 = True

    # The function to test
    variable_manager_0.get_vars(host_0, play_0, task_0, include_hostvars_0)

    # This test needs to be extended
    print("VariableManager_get_vars test needs to be extended")


# Generated at 2022-06-25 14:19:22.232215
# Unit test for constructor of class VariableManager
def test_VariableManager():
    constructor_test = TestCaseWithCleanup(setup=test_case_0)
    constructor_test.runTest()


# Generated at 2022-06-25 14:19:31.073760
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    variable_manager.set_host_variable('abc', 'x', '3')
    variable_manager.set_host_variable('abc', 'y', '5')
    variable_manager.set_host_variable('def', 'a', '1')
    variable_manager.set_host_variable('def', 'b', '2')
    variable_manager.set_host_variable('def', 'c', '3')
    variable_manager.set_host_variable('def', 'd', '4')
    variable_manager.set_host_variable('def', 'e', '5')
    variable_manager.set_host_variable('ghi', 'a', '1')
    variable_manager.set_host_variable('jkl', 'b', '3')


# Generated at 2022-06-25 14:19:41.673471
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    path = '/home/hpeng7/Workspace/ansible/lib/ansible/vars'
    module_utils_path = '/home/hpeng7/Workspace/ansible/lib/ansible/module_utils'
    variable_manager_0 = VariableManager(loader=DataLoader())
    # print("variable_manager_0._vars_cache:", variable_manager_0._vars_cache)
    # print("variable_manager_0._vars_plugins:", variable_manager_0._vars_plugins)
    # print("variable_manager_0._fact_cache:", variable_manager_0._fact_cache)
    # print("variable_manager_0._omit_token:", variable_manager_0._omit_token)
    # print("variable_manager_0._options_vars:", variable_

# Generated at 2022-06-25 14:19:47.682288
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_variable('test_host', 'test_varname', 'test_value')
    assert variable_manager_0._vars_cache['test_host']['test_varname'] == 'test_value'

test_cases = [
    test_case_0,
    test_VariableManager_set_host_variable,
]

if __name__ == '__main__':
    for test_case in test_cases:
        test_case()

# Generated at 2022-06-25 14:19:55.040708
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()

# Generated at 2022-06-25 14:20:47.512041
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    variable_manager = VariableManager()

    # Test if we can set facts for a host
    host1 = "host1"
    host2 = "host2"
    host3 = "host3"
    host4 = "host4"
    host5 = "host5"
    host6 = "host6"
    host7 = "host7"
    host8 = "host8"
    facts1 = dict(a=1, b=dict(b1=1,b2=2))
    facts2 = dict(a=1, b=dict(b2=2,b1=1))
    facts3 = dict(b=dict(b1=1,b2=2), a=1)
    facts4 = {'a': 1, 'b': {'b1': 1, 'b2': 2}}

# Generated at 2022-06-25 14:20:57.267027
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    v_m_0 = VariableManager()
    host_0 = 'host0'
    varname_0 = 'varname0'
    value_0 = {'key0': 'value0', 'key1': 'value1'}
    v_m_0.set_host_variable(host_0, varname_0, value_0)
    assert v_m_0._vars_cache == {'host0': {'varname0': {'key0': 'value0', 'key1': 'value1'}}}
    varname_1 = 'varname1'
    value_1 = {'key2': 'value2'}
    v_m_0.set_host_variable(host_0, varname_1, value_1)

# Generated at 2022-06-25 14:20:59.049277
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vm = VariableManager()
    write_vars_to_file(vm.get_vars())


# Generated at 2022-06-25 14:21:03.455308
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    print("\n\nVariableManager_get_vars:")
    try:
        print(variable_manager_0.get_vars())
    except AssertionError as e:
        print("{0}\n".format(e))
#

# Generated at 2022-06-25 14:21:11.606709
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():

    variable_manager = VariableManager()
    variable_manager.set_host_variable("host0", "varname0", "value0")
    assert variable_manager._vars_cache["host0"] == {'varname0': 'value0'}
    variable_manager.set_host_variable("host0", "varname0", "value1")
    assert variable_manager._vars_cache["host0"] == {'varname0': 'value1'}
    variable_manager.set_host_variable("host0", "varname1", {"key0": "value0"})
    assert variable_manager._vars_cache["host0"] == {'varname0': 'value1', 'varname1': {'key0': 'value0'}}

# Generated at 2022-06-25 14:21:22.764419
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Get the host object
    host0 = Host(name='test_host_0')

    # Create a trivial playbook
    play_source =  dict(
            name = "Ansible Play 0",
            hosts = 'test_host_0',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{hostvars[host_0].omit}}')))
            ]
        )
    play = Play().load(play_source, variable_manager=variable_manager_0, loader=loader_0)

    # Create a task
    task0 = Task()

# Generated at 2022-06-25 14:21:33.007442
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    host_0 = Host(name='host_0')
    host_0.set_variable('hostvars_0', {'hostvars_0_k0': 'hostvars_0_v0', 'hostvars_0_k1': 'hostvars_0_v1'})
    options_vars_0 = {'inventory_hostname': 'inventory_hostname_0', 'something': {'x': 'y'}}


# Generated at 2022-06-25 14:21:35.589919
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # can we get a variable manager to return a dictionary
    # for a specified host
    variable_manager_0 = VariableManager()
    variable_manager_0.get_vars(host='host_0')

# Generated at 2022-06-25 14:21:39.224726
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager = VariableManager()
    variable_manager.set_host_facts("192.1.1.11", {"test": "success"})
    _facts  = variable_manager._fact_cache["192.1.1.11"]
    assert _facts["test"] == "success"


# Generated at 2022-06-25 14:21:46.909845
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()

    test_host_0 = Host('test_host_0')
    test_host_1 = Host('test_host_1')

    test_host_0.vars['test_var_0_host'] = 'test_value_0_host'
    test_host_0.vars['test_var_1_host'] = 'test_value_1_host'
    test_host_0.vars['test_var_2_host'] = 'test_value_2_host'

    test_host_0.groups[0].vars['test_var_0_group'] = 'test_value_0_group'
    test_host_1.groups[0].vars['test_var_0_group'] = 'test_value_0_group_host_1'

# Generated at 2022-06-25 14:23:19.282765
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()
    assert_equals(variable_manager_0.get_vars(), {})


# Generated at 2022-06-25 14:23:28.818625
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_1 = VariableManager()
    var_host_obj_1 = 'win2012r2'
    var_facts_1 = {'win_path': 'c:\Windows\System32', 'ps2': 'c:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'}
    variable_manager_1.set_nonpersistent_facts(var_host_obj_1, var_facts_1)
    var_host_obj_2 = 'win2016'
    var_facts_2 = {'win_path': 'c:\Windows\System32', 'ps2': 'c:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'}
    variable_manager_1.set_nonpersistent_facts(var_host_obj_1, var_facts_2)


# Generated at 2022-06-25 14:23:37.528687
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    # Copied from playbook_executor.py
    # gather_facts == 'no'
    play_0_vars = {'gather_facts': 'no', 'name': 'Test Play'}
    play_0_host = Host('test_host_name')
    play_0_play = Play().load(play_0_vars, variable_manager=variable_manager_0, loader=None)
    variables_0 = variable_manager_0.get_vars(play=play_0_play, host=play_0_host, task=None)
    # The test case here is to ensure the dict returned by get_vars method
    # is not empty.
    assert variables_0
    # print(variables_0)


# Generated at 2022-06-25 14:23:48.196303
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    var = YAML().load("""
        foo: myvar
        bar: "myvar2"
        play:
          host: "{{ var_in_play }}"
        """)

    # when the optional argument "include_hostvars" is not specified,
    # the default value is False
    actual_result_0 = variable_manager_0.get_vars(host=None, include_hostvars=True)
    assert actual_result_0 == dict()

    actual_result_1 = variable_manager_0.get_vars(host=None, include_hostvars=False)
    assert actual_result_1 == dict()

    actual_result_2 = variable_manager_0.get_vars(host=None, include_hostvars=True)


# Generated at 2022-06-25 14:23:56.335118
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    assert not hasattr(variable_manager_0, 'host_vars')
    assert not hasattr(variable_manager_0, 'group_vars')
    assert not hasattr(variable_manager_0, 'extra_vars')
    assert not hasattr(variable_manager_0, 'playbook_basedirs')
    assert not hasattr(variable_manager_0, 'playbook_dir')
    assert not hasattr(variable_manager_0, '_inventory')
    assert not hasattr(variable_manager_0, '_loader')
    assert not hasattr(variable_manager_0, '_inventory_basedir')
    assert not hasattr(variable_manager_0, '_nonpersistent_fact_cache')

# Generated at 2022-06-25 14:24:02.786053
# Unit test for constructor of class VariableManager

# Generated at 2022-06-25 14:24:10.780066
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    '''
    Test case for the method set_host_variable of class VariableManager
    '''
    test_host = Host('test_host')
    test_host.vars = {'var_1': 'my_value'}
    test_host.set_variable('var_2', 'my_other_value')
    variable_manager_0 = VariableManager()
    variable_manager_0._vars_cache[test_host.name] = test_host.vars
    variable_manager_0._hostvars = hostvars = {'test_host': {'var_2': 'my_other_value'}}
    variable_manager_0._nonpersistent_fact_cache = {'test_host': {'var_3': 'third_value'}}
    # check that there are no changes made to hosvars

# Generated at 2022-06-25 14:24:20.073263
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    hosts = ['host1', 'host2']
    variables = {'variable1': 'value_1'}
    variable_manager_1 = VariableManager()
    variable_manager_1.set_host_variable(hosts[0], variables.keys()[0], variables[variables.keys()[0]])
    assert variable_manager_1._vars_cache[hosts[0]][variables.keys()[0]] == variables[variables.keys()[0]]
    for var in variables.keys():
        variable_manager_1.set_host_variable(hosts[0], var, variables[var])
    assert variable_manager_1._vars_cache[hosts[0]] == variables


# Generated at 2022-06-25 14:24:23.555314
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    assert {} == variable_manager_1.get_vars()
    assert {} == variable_manager_1.get_group_vars('all')


# Generated at 2022-06-25 14:24:27.271158
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    host = 'atest_host'
    facts = {}
    # Set it
    variable_manager_0.set_host_facts(host, facts)
    # Make sure it got set
    assert variable_manager_0._fact_cache[host] == facts

