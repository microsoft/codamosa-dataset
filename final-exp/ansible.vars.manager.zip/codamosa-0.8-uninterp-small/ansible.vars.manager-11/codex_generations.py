

# Generated at 2022-06-25 14:16:43.603039
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_variable("localhost", "a", "A_TEST_VALUE" )
    assert(variable_manager_0.get_vars()["hostvars"]["localhost"]["a"] == "A_TEST_VALUE")


# Generated at 2022-06-25 14:16:47.163234
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    host = Host(name='host')
    facts = {}
    variable_manager_0.set_host_facts(host, facts)


# Generated at 2022-06-25 14:16:48.685505
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()


# Generated at 2022-06-25 14:16:54.223188
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager = VariableManager()
    hostname = 'localhost'
    variable_manager.set_host_facts(hostname, dict())
    variable_manager.clear_facts(hostname)
    variable_manager.set_host_facts(hostname, dict())

if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-25 14:16:58.826369
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_1 = VariableManager()
    variable_manager_1.set_host_facts("test_host_name", {"test_fact_name": "test_fact_value"})
    assert variable_manager_1._fact_cache["test_host_name"] == {"test_fact_name": "test_fact_value"}

# Generated at 2022-06-25 14:17:06.660395
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    Test the method get_vars of the VariableManager class.
    '''

    # Test case 0
    # set up
    play_0 = Play()
    task_0 = Task(action=dict())
    task_0.action['__ansible_module__'] = 'command'
    play_0.add_task(task_0)
    variable_manager_0 = VariableManager()
    variable_manager_0._fact_cache = dict()

    # test
    variables_0 = variable_manager_0.get_vars(
        play=play_0,
        host=None,
        task=task_0,
        include_delegate_to=True,
        include_hostvars=True
    )
    return variables_0


# Generated at 2022-06-25 14:17:16.114434
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_1 = VariableManager()
    set_host_facts_1_facts = {
        'ansible_swapfree_mb': 0,
        'ansible_swaptotal_mb': 0,
        'ansible_processor_cores': 1,
    }
    set_host_facts_1_host = 'localhost'
    variable_manager_1.set_host_facts(set_host_facts_1_host, set_host_facts_1_facts)
    if variable_manager_1._fact_cache[set_host_facts_1_host] != set_host_facts_1_facts:
        raise ValueError('test_VariableManager_set_host_facts_1 failed')

# Generated at 2022-06-25 14:17:20.117593
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    host_0 = "host_0"
    facts_0 = dict()
    variable_manager_0.set_host_facts(host_0, facts_0)


# Generated at 2022-06-25 14:17:30.174644
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    host = Host(name="localhost")
    play = Play().load({
        'name': "Ansible Play",
        'hosts': "localhost",
        'gather_facts': "no",
        'tasks': [
            {
                'name': "Test task",
                'action': {
                    'module': "shell",
                    'args': "ls -la"
                }
            }
        ]
    })
    play.post_validate(variable_manager=variable_manager_1, loader=None)
    task = play.get_initial_task_list()[0]
    result = variable_manager_1.get_vars(play=play, host=host, task=task)
    assert 'omit' in result

# Generated at 2022-06-25 14:17:37.746638
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager()
    host_2 = 'ansible-simplified-test-host'
    varname_3 = 'ansible_connection'
    value_10 = 'ssh'
    variable_manager_1.set_host_variable(host_2, varname_3, value_10)
    print(variable_manager_1._vars_cache)
    assert variable_manager_1._vars_cache == {'ansible-simplified-test-host': {'ansible_connection': 'ssh'}}


# Generated at 2022-06-25 14:18:03.248461
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.get_vars()
    variable_manager_0.get_vars()


# Generated at 2022-06-25 14:18:12.274845
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    nonpersistent_facts_hostname = 'hostname'
    nonpersistent_facts_facts = {'key': 'value'}

    nonpersistent_facts_host_cache_hostname = 'hostname'
    nonpersistent_facts_host_cache = {'key': 'value'}

    nonpersistent_facts_fact_cache_hostname = 'hostname'
    nonpersistent_facts_fact_cache = {'key': 'value'}

    # store data for method set_nonpersistent_facts of class VariableManager
    nonpersistent_facts_set_nonpersistent_facts_data = {'hostname': 'value'}
    # store data for method get_nonpersistent_facts of class VariableManager

# Generated at 2022-06-25 14:18:14.567270
# Unit test for constructor of class VariableManager
def test_VariableManager():
    """ See above """
    variable_manager_1 = VariableManager()

if __name__ == "__main__":
    # Construct a basic and test
    test_VariableManager()

# Generated at 2022-06-25 14:18:25.355272
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    assert_equals(variable_manager_0._fact_cache, {})

    host_0 = 'host_0'
    facts_0 = {'ansible_facts': {'file_systems_0': 'file_systems_0'}}

    with pytest.raises(AnsibleAssertionError) as excinfo:
        variable_manager_0.set_host_facts(host_0, facts_0)

    host_1 = 'host_1'
    facts_1 = [{'ansible_facts': {'file_systems_0': 'file_systems_0'}}]

    with pytest.raises(TypeError) as excinfo:
        variable_manager_0.set_host_facts(host_1, facts_1)

    host

# Generated at 2022-06-25 14:18:29.161523
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    """
    Function that tests the set_host_facts method.
    """
    host = 'test'
    facts = {'test_facts': 'test_facts'}
    var_man = VariableManager()
    var_man.set_host_facts(host, facts)
    assert var_man._fact_cache[host] == facts

# Generated at 2022-06-25 14:18:35.004011
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    print("test_VariableManager_set_host_variable")
    host = "localhost"
    varname = "var"
    value = 1
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_variable(host = host, varname = varname, value = value)
    print("variable_manager_0._vars_cache:")
    pprint.pprint(variable_manager_0._vars_cache)
    print("")


# Generated at 2022-06-25 14:18:42.950188
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()

    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    hostvars_instance = HostVars(loader=DataLoader())
    variable_manager_1.set_host_variable("ip-10-10-10-10.ec2.internal", "ansible_facts", hostvars_instance.get_vars(play=None, host=None, task=None, include_delegate_to=False, include_hostvars=False, use_cache=True))
    variable_manager_1.set_host_variable("ip-10-10-10-10.ec2.internal", "ansible_inventory", {})

# Generated at 2022-06-25 14:18:48.910770
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Case 0
    variable_manager_0 = VariableManager()
    play = dict()
    host = dict()
    task = dict()
    variables = dict()
    include_delegate_to = True
    include_hostvars = True

    res = variable_manager_0.get_vars(play, host, task, variables, include_delegate_to, include_hostvars)
    assert res != None


# Generated at 2022-06-25 14:18:56.659486
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    play_0 = Play()
    result_0 = variable_manager_0.get_vars(play_0)
    assert result_0 is not None
    assert result_0.get(u'play_hosts') == []
    assert result_0.get(u'groups') == {}
    assert result_0.get(u'omit') == u''
    assert result_0.get(u'ansible_play_name') == u''


# Generated at 2022-06-25 14:19:05.422128
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    variable_manager_1.extra_vars['a'] = '1'
    variable_manager_1.extra_vars['b'] = '2'
    variable_manager_1.extra_vars['c'] = '3'
    variable_manager_1.hostvars['host_0'] = {'d': '4'}
    variable_manager_1.hostvars['host_1'] = {'d': '5'}
    variable_manager_1.hostvars['host_2'] = {'d': '6'}
    variable_manager_1.hostvars['host_3'] = {'d': '7'}

    variable_manager_1.hostvars['host_2']['a'] = '66'

# Generated at 2022-06-25 14:20:10.554563
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()

    # test that get_vars without host returns the 'global' variables from the variable manager
    assert variable_manager_1.get_vars() == {
        'omit': '__omit_place_holder__',
        'ansible_play_name': 'all'
    }

    host_1 = Host(name='test_host_1')

    # test that get_vars with host returns the variables for that host
    assert variable_manager_1.get_vars(host=host_1)['inventory_hostname'] == 'test_host_1'

    play_1 = Play(name='play_1')

    # test that get_vars with play returns the variables for that play

# Generated at 2022-06-25 14:20:13.631234
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_facts('local', dict())
    variable_manager_0.set_host_facts('local', dict())


# Generated at 2022-06-25 14:20:24.264098
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    """
    Test that a specific host variable can be set using set_host_variable.
    """
    # Test 1: for a host that does not exist and a host that does exist
    cs_host1 = 'host1.example.org'
    cs_host2 = 'host2.example.org'
    cs_host3 = 'host3.example.org'
    cs_host_variable = 'my_special_variable'
    cs_value = 'my_special_value'

    vm = VariableManager()

    # Add the special variable to host1
    vm._vars_cache[cs_host1] = {cs_host_variable: cs_value}

    if cs_host_variable in vm._vars_cache[cs_host1]:
        return True
    else:
        return False

    # Add the special variable to

# Generated at 2022-06-25 14:20:35.355890
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    variable_manager_2 = VariableManager()
    variable_manager_3 = VariableManager()
    variable_manager_1.extra_vars = {'var1': 'foo', 'var2': 42, 'var3': 'bar', 'var4': 'baz'}
    variable_manager_2.extra_vars = {'var1': 'foo', 'var2': 42, 'var3': 'bar', 'var4': 'baz'}
    variable_manager_3.extra_vars = {'var1': 'foo', 'var2': 42, 'var3': 'bar', 'var4': 'baz'}

    variable_manager_2.extra_vars['var1'] = 'foo'

# Generated at 2022-06-25 14:20:44.623766
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    test_host_0 = Host("test_inventory_host_name")
    test_task_0 = Task("test_task_name")
    test_play_0 = Play(name="test_play_name")
    test_play_0.add_task(task=test_task_0)
    include_hostvars = True
    test_variable_manager_get_vars_0 = variable_manager_0.get_vars(
        play=test_play_0,
        host=test_host_0,
        task=test_task_0,
        include_hostvars=include_hostvars,
    )
    assert test_variable_manager_get_vars_0

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 14:20:54.209078
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    host_0 = Host('localhost')
    play_1 = Play().load(dict(
        name = 'ping',
        hosts = 'localhost',
        gather_facts = False,
        tasks = [dict(action=dict(module='ping', args=''))]
    ), variable_manager=variable_manager_0, loader=DictDataLoader())
    task_0 = play_1.get_task_by_name('ping')
    result_0 = variable_manager_0.get_vars(play=play_1, host=host_0, task=task_0)

# Generated at 2022-06-25 14:20:58.780037
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    # Pass
    variable_manager_0.set_nonpersistent_facts('some_host', {'ansible_system': 'Linux'})
    # Pass
    variable_manager_0.set_nonpersistent_facts('a_host', {'a_var': 'a_value'})

# Generated at 2022-06-25 14:21:03.862844
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.extra_vars = {'key': 'value'}
    result = variable_manager_0.get_vars(host=None, play=None, include_delegate_to=False, include_hostvars=False)
    assert result == {'key': 'value'}


# Generated at 2022-06-25 14:21:11.854234
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.add_task_facts = MagicMock()
    variable_manager_0.extract_nested_facts = MagicMock()
    variable_manager_0.get_fact_cache = MagicMock()
    variable_manager_0.get_options_vars = MagicMock()
    variable_manager_0.get_vars_config_files = MagicMock()
    variable_manager_0.get_vars_files = MagicMock()
    variable_manager_0.get_vars_from_include = MagicMock()
    variable_manager_0.get_vars_from_inventory = MagicMock()
    variable_manager_0.get_vars_from_playbook = MagicMock()
    variable_manager_0.get_

# Generated at 2022-06-25 14:21:16.878066
# Unit test for constructor of class VariableManager
def test_VariableManager():
    em = 'VariableManager() raise an exception'
    try:
        variable_manager_0 = VariableManager()
        print("VariableManager class instance creation succeeded\n")
    except Exception as e:
        print("{0}:\n\t{1}".format(em, str(e)))



# Generated at 2022-06-25 14:22:19.034385
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_variable("ansible-host1", "hostvars", "10.20.30.40")
    variable_manager_0.set_host_variable("ansible-host1", "ansible_ssh_host", "10.20.30.41")
    expected = {
        "ansible-host1": {
            "hostvars": "10.20.30.40",
            "ansible_ssh_host": "10.20.30.41",
        }
    }
    assert(variable_manager_0._vars_cache == expected)


# Generated at 2022-06-25 14:22:23.021813
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_variable("testcase_host", "testcase_varname", "testcase_value")

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-25 14:22:34.649194
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    # Test case to check whether facts are stored properly,
    # when set through VariableManager.set_host_facts.
    # Some facts are stored in this class and dictionary is returned,
    # when get_vars() method is called with host as parameter.
    # set_host_facts() method is used to store those facts.
    # This is used mostly when facts are changed or when facts are
    # gathered by any other source than ansible (through push mechanism).
    # So, this test case is to check whether facts are stored properly
    # in set_host_facts() method.

    # This test case also check for the error handling of set_host_facts()
    # method.

    # create a new object of VariableManager class
    variable_manager_1 = VariableManager()

    # create a new object of Host class

# Generated at 2022-06-25 14:22:42.105825
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()

    # Instantiate an instance of class Host
    host_0 = Host('TEST_HOSTNAME')
    host_0.vars = dict()
    host_0.vars['TEST_VARNAME'] = 'TEST_VALUE'
    host_0.vars['TEST_VARNAME_2'] = 'TEST_VALUE_2'

    # Instantiate an instance of class Task
    # I don't understand why this task is needed.
    task_0 = Task()

    # Assign values to the attributes of task_0
    task_0.action = 'TEST_ACTION'
    task_0.args = dict()
    task_0.args['TEST_ARGNAME'] = 'TEST_ARGVALUE'

# Generated at 2022-06-25 14:22:51.053150
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vars_manager = VariableManager()
    host = 'localhost'
    facts = {
        "fact1": "value1"
    }

    vars_manager.set_nonpersistent_facts(host, facts)
    assert vars_manager._nonpersistent_fact_cache == {
        "localhost": {
            "fact1": "value1"
        }
    }

    facts = {
        "fact2": "value2"
    }
    vars_manager.set_nonpersistent_facts(host, facts)
    assert vars_manager._nonpersistent_fact_cache == {
        "localhost": {
            "fact1": "value1",
            "fact2": "value2"
        }
    }

    new_host = "127.0.0.1"

# Generated at 2022-06-25 14:22:51.780666
# Unit test for constructor of class VariableManager
def test_VariableManager():
    test_case_0()


# Generated at 2022-06-25 14:23:01.946536
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    host = 'localhost'
    varname = 'FACTS['

# Generated at 2022-06-25 14:23:10.178195
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    assert repr(variable_manager_0).startswith("<ansible.vars.manager.VariableManager")

    # Test with some default arguments
    # Let's create a fake play and task
    play_0 = Play()
    task_0 = Task()
    # Let's set the delegate_to field of the task to be some readable value
    task_0.delegate_to = 'mydelegatedhost'

    # Let's create a fake host
    host_0 = Host(name='myhost')
    # Let's create a fake inventory and add the fake host to it
    # We need that because we need the inventory to set the variables in the host
    inventory_0 = Inventory()
    inventory_0.add_host(host_0)
    # Let's set the inventory in the variable manager

# Generated at 2022-06-25 14:23:19.361428
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()
    # Create a sample host object and set some facts
    host_obj_1 = Host(name='example')
    host_obj_1.vars["ansible_all_ipv4_addresses"] = ["192.168.0.1", "192.168.0.2", "192.168.0.3"]
    host_obj_1.vars["ansible_hostname"] = "hostname1"
    host_obj_1.vars["ansible_default_ipv4"] = "192.168.0.1"
    host_obj_1.vars["ansible_default_ipv6"] = "2001:db8::1"
    host_obj_1.vars["ansible_devices"] = dict()

# Generated at 2022-06-25 14:23:28.818896
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    '''
    VariableManager: Test set host varaiable method of class VariableManager
    '''
    variable_manager_0 = VariableManager()

# Generated at 2022-06-25 14:24:30.280980
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    var_str = variable_manager.get_vars()
    expected_str = {}
    assert_equal(expected_str, var_str)


# Generated at 2022-06-25 14:24:36.542706
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    play = None
    host = None
    task = None
    include_delegate_to = None
    ansible_vars = variable_manager_0.get_vars(play, host, task, include_delegate_to)
    assert isinstance(ansible_vars, dict)
    assert len(ansible_vars) == 0
    assert id(ansible_vars) == id(variable_manager_0._vars)
    assert ansible_vars is not None


# Generated at 2022-06-25 14:24:43.035496
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()

    host = '127.0.0.1'
    varname = 'ansible_connection'
    value = 'local'

    variable_manager_0.set_host_variable(host, varname, value)
    assert variable_manager_0.get_host_vars(host)[varname] == value
    assert variable_manager_0._vars_cache[host][varname] == value


# Generated at 2022-06-25 14:24:52.519502
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    variable_manager_1 = VariableManager()

    facts1 = {'one': 1}
    facts2 = {'two': 2}
    facts3 = '3'

    variable_manager_1.set_host_facts('host1', facts1)
    variable_manager_1.set_host_facts('host2', facts2)
    try:
        variable_manager_1.set_host_facts('host3', facts3)
    except TypeError:
        pass
    else:
        assert False, "Expected assertion failure, didn't get it."

    assert variable_manager_1._fact_cache['host1'] == {'one': 1}
    assert variable_manager_1._fact_cache['host2'] == {'two': 2}


# Generated at 2022-06-25 14:24:56.146242
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    host = 'test'
    varname = 'test_varname'
    value = 'test_value'
    variable_manager.set_host_variable(host, varname, value)
    assert variable_manager._vars_cache[host][varname] == value
    assert variable_manager._vars_cache[host] != None


# Generated at 2022-06-25 14:24:59.344846
# Unit test for constructor of class VariableManager
def test_VariableManager():
    try:
        variable_manager_0 = VariableManager()
    except KeyError:
        print("KeyError for constructor of VariableManager")

test_case_0()
test_VariableManager()

# Generated at 2022-06-25 14:25:02.987664
# Unit test for constructor of class VariableManager
def test_VariableManager():
    print("# Unit test for constructor and get_vars of class VariableManager")
    test_case_0()
    print("Successfully testing for constructor and get_vars of class VariableManager")


# Generated at 2022-06-25 14:25:04.096890
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()



# Generated at 2022-06-25 14:25:09.264092
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager()
    host = 'host'
    varname = 'varname'
    value = 'value'
    variable_manager_1.set_host_variable(host, varname, value)
    assert variable_manager_1._vars_cache[host][varname] == value


# Generated at 2022-06-25 14:25:15.397259
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    play_0 = Play()
    host_0 = Host("localhost")
    task_0 = Task()
    test_get_vars = variable_manager_0.get_vars(play=play_0, host=host_0, task=task_0, include_delegate_to=False, include_hostvars=False)
    assert('ansible_playbook_python' in test_get_vars)
