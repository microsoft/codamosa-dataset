

# Generated at 2022-06-25 14:16:56.975474
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Get a loader...
    loader = DataLoader()

    # Get a vars manager
    vars_mgr = VariableManager()

    # Create an inventory
    inv = Inventory(
        loader=loader,
        variable_manager=vars_mgr,
        host_list=['localhost']
    )
    vars_mgr.set_inventory(inv)

    # Create a play
    play = Play()

    # Create a task
    task = Task()

    # Create a host
    host = Host('127.0.0.1')

    # Create a template
    task2 = Task()
    task2._role = Role()
    task2._role.name = 'test'
    task2._role._role_path = '/home/test/roles/test'

    # Set a default unique_id for each task

# Generated at 2022-06-25 14:17:00.389526
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vm = VariableManager()
    vm.set_nonpersistent_facts('test', {'test_key': 'test_value'})
    assert vm._nonpersistent_fact_cache.get('test').get('test_key') == 'test_value'

# Generated at 2022-06-25 14:17:02.387362
# Unit test for constructor of class VariableManager
def test_VariableManager():
    vars_with_sources = VarsWithSources()
    assert isinstance(vars_with_sources, VarsWithSources)


# Generated at 2022-06-25 14:17:07.372922
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    vm.set_host_variable("test_host", "ansible_test_key", "test_value")
    assert vm.get_vars(host=Host("test_host"))["ansible_test_key"] == "test_value"



# Generated at 2022-06-25 14:17:16.598758
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(key3='value3', key4='value4')
    variable_manager.options_vars = dict(key5='value5', key6='value6')

    host = Host(name='test_host')

    vars_with_sources_0 = variable_manager.get_vars(host=host)
    vars_with_sources_0.add_or_update_vars({'key3': 'value3',
                                            'key4': 'value4',
                                            'key5': 'value5',
                                            'key6': 'value6',
                                            'omit': variable_manager.omit_token})


# Generated at 2022-06-25 14:17:27.778451
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict(
        host1=dict(
            ansible_facts=dict(
                ansible_distribution='BlahBlah',
                ansible_os_family='RedHat'
            )
        ),
        host2=dict(
            ansible_facts=dict(
                ansible_distribution='BlahBlah',
                ansible_os_family='RedHat',
            )
        )
    )

# Generated at 2022-06-25 14:17:38.521979
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # test with one host, one variable
    vm = VariableManager()
    host = Host('host1')
    vm.set_host_variable(host, 'var1', 'value1')
    assert vm.get_vars(host=host, include_hostvars=True) == {'var1': 'value1'}

    # test with one host, multiple variables
    vm = VariableManager()
    host = Host('host1')
    vm.set_host_variable(host, 'var1', 'value1')
    vm.set_host_variable(host, 'var2', 'value2')
    vm.set_host_variable(host, 'var3', 'value3')

# Generated at 2022-06-25 14:17:49.025948
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    vm = VariableManager()
    assert not vm._fact_cache
    vm.set_host_facts('testhost', {'var': 'value'})
    assert vm._fact_cache == {'testhost': {'var': 'value'}}
    vm.set_host_facts('testhost', {'var2': 'value2'})
    assert vm._fact_cache == {'testhost': {'var': 'value', 'var2': 'value2'}}
    assert vm._fact_cache['testhost']['var'] == 'value'
    assert vm._fact_cache['testhost']['var2'] == 'value2'
    vm.set_host_facts('testhost', 'a string')

# Generated at 2022-06-25 14:17:56.469142
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Setup
    vars_with_sources_0 = VarsWithSources()
    vars_with_sources_1 = VarsWithSources()
    vars_with_sources_2 = VarsWithSources()
    vars_with_sources_3 = VarsWithSources()
    vars_with_sources_4 = VarsWithSources()
    vars_with_sources_5 = VarsWithSources()
    vars_with_sources_6 = VarsWithSources()
    vars_with_sources_7 = VarsWithSources()

# Generated at 2022-06-25 14:18:02.765623
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vars_with_sources = VarsWithSources()
    # test case 0
    host = "localhost"
    varname = "ansible_local"
    value = "some_value"
    vars_with_sources.set_host_variable(host, varname, value)
    assert  vars_with_sources._vars_cache[host][varname] == value


# Generated at 2022-06-25 14:18:28.376274
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vars_with_sources = VarsWithSources()
    vars_with_sources.set_nonpersistent_facts('local', dict(foo='bar'))
    assert vars_with_sources.get_vars(host=Host('local'))['foo'] == 'bar'


# Generated at 2022-06-25 14:18:30.226163
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # test case 0
    test_case_0()

if __name__ == "__main__":
    # test case 0
    test_case_0()

# Generated at 2022-06-25 14:18:35.801186
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Test normal case: create an object
    vars_with_sources_0 = VarsWithSources()
    vars_with_sources_0._add_new_variable('foo', 'bar', 'conf_file')
    # Test if all variables are assigned correctly
    if vars_with_sources_0._data['foo'] != 'bar':
        print("The _data attribute 'foo' is not assigned correctly.")
    if vars_with_sources_0._vars_sources['foo'] != 'conf_file':
        print("The _vars_sources attribute 'foo' is not assigned correctly.")
    # Test normal case: create an object with existed variable
    vars_with_sources_1 = VarsWithSources(vars_with_sources_0)
    # Test if all variables are assigned correctly


# Generated at 2022-06-25 14:18:37.624999
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vm = VariableManager()
    assert vm.get_vars() is not None


# Generated at 2022-06-25 14:18:40.764658
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vars_with_sources_0 = VarsWithSources()
    obj = VariableManager()
    host = ""
    varname = ""
    value = vars_with_sources_0

    obj.set_host_variable(host, varname, value)


# Generated at 2022-06-25 14:18:51.410884
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    vars_with_sources_1 = VarsWithSources()
    inventory = None
    variables = dict()
    host = None
    play = None
    task = None
    include_delegate_to = True
    include_hostvars = True

    # Case 1: Without VariableManager object
    vm_obj = None
    v1 = vm_obj.get_vars(host=host, play=play, task=task, use_cache=True, include_hostvars=include_hostvars, include_delegate_to=include_delegate_to)
    v1_expect = dict()
    assert v1 == v1_expect, 'Returned dictionary is not empty'
    print("All assertions passed - test_VariableManager_get_vars()")

    # Case 2: With VariableManager and without Inventory object


# Generated at 2022-06-25 14:19:01.398782
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vars_with_sources = VarsWithSources()
    vars_with_sources.set_host_variable('test_host', 'test_varname', 'test_value')

    assert vars_with_sources._vars_cache['test_host']['test_varname'] == 'test_value'

    vars_with_sources.set_host_variable('test_host', 'test_varname', {'key1': 'value1', 'key2': 'value2'})
    assert vars_with_sources._vars_cache['test_host']['test_varname']['key1'] == 'value1'

# Generated at 2022-06-25 14:19:02.552520
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    test_set_host_variable_0()



# Generated at 2022-06-25 14:19:13.561701
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    try:
        VariableManager.set_host_facts('aa', 'bb')
        raise "Incorrect input should result in exception"
    except:
        pass

    # We need to provide an actual fact name and value for this to work
    test_fact_name = 'some_fact'
    test_fact_value = 'value'

    # Init VariableManager
    varman = VariableManager()
    # Lets set facts for a host
    varman.set_host_facts('test001', facts={test_fact_name: test_fact_value})
    # Lets see if we are getting the correct value
    test_fact_dict = varman.get_vars(host=Host('test001'))
    assert test_fact_dict[test_fact_name] == test_fact_value
    # Lets add to the fact dictionary
    test

# Generated at 2022-06-25 14:19:21.334382
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Create an instance of VariableManager class
    vm = VariableManager()

    # Get the vars from instance of VariableManager class
    host1_vars = vm.get_vars(play=None, host=Host(name="host1"), task=None, include_delegate_to=True, include_hostvars=True)

    # Check that there is a key for 'inventory_hostname'
    assert 'inventory_hostname' in host1_vars

    # Check that there is a key for 'role_path'
    assert 'role_path' in host1_vars

    # Check that there is a key for 'omit'
    assert 'omit' in host1_vars

    # Check that there is a key for 'hostvars'
    assert 'hostvars' in host1_vars

    # Get the

# Generated at 2022-06-25 14:20:24.552129
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Setup the arguments that would be passed to the method
    host = 'testhost'
    include_hostvars = False
    include_delegate_to = True  # Had to add this parameter to the method signature
    play=None
    task=None

    # Create a variable manager object
    variable_manager = VariableManager()

    # Call the method
    variable_manager.get_vars(
        host=host,
        include_hostvars=include_hostvars,
        include_delegate_to=include_delegate_to,
        play=play,
        task=task
    )


# Generated at 2022-06-25 14:20:35.585348
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    class FakePlay(object):
        def __init__(self):
            self._roles = list()
            self._role = FakeRole()

    class FakeRole(object):
        def __init__(self):
            self._role_name = "fakerole"
            self._role_path = "/fake/path/fakerole"
            self._role_collection = "fake"


    class FakeTask(object):
        def __init__(self):
            self._ds = dict()
            self.loop_with = None
            self.loop = None
            self.loop_control = FakeLoopControl()

    class FakeLoopControl(object):
        def __init__(self):
            self.loop_var = "item"


# Generated at 2022-06-25 14:20:36.990632
# Unit test for constructor of class VariableManager
def test_VariableManager():
    new_vm = VariableManager()
    assert isinstance(new_vm, VariableManager)


# Generated at 2022-06-25 14:20:44.442010
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    print(test_VariableManager_get_vars.__doc__)
    vars_with_sources_0 = VarsWithSources()
    variable_manager_0 = VariableManager()
    vars_with_sources_0.add('a', 'b', source='source 0')
    vars_with_sources_0.add('a', 'b', source='source 1')
    vars_with_sources_0.add('a', 'b', source='source 2')
    vars_with_sources_0.add('a', 'b', source='source 3')
    vars_with_sources_0.add('a', 'b', source='source 4')
    vars_with_sources_0.add('a', 'b', source='source 5')
    vars_with_sources_

# Generated at 2022-06-25 14:20:45.760073
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager(loader=None, inventory=None)


# Generated at 2022-06-25 14:20:52.637930
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    mgr = VariableManager()
    facts_dict = {'foo': 'bar'}
    facts_not_dict = 'foobar'
    mgr.set_host_facts('host1', facts_dict)
    assert mgr._fact_cache['host1']['foo'] == 'bar'
    try:
        mgr.set_host_facts('host1', facts_not_dict)
    except AnsibleAssertionError:
        assert 'TypeError correctly thrown'
    finally:
        del mgr


# Generated at 2022-06-25 14:20:57.356112
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Create a test object
    variable_manager = test_case_0()
    # Call the function
    play = None
    host = None
    task = None
    include_delegate_to = None
    return variable_manager.get_vars(play=play, host=host, task=task, include_delegate_to=include_delegate_to)

# Generated at 2022-06-25 14:21:07.092693
# Unit test for constructor of class VariableManager
def test_VariableManager():
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="[fake.hosts]")
    host1 = "host1"
    host2 = "host2"
    host3 = "host3"
    all = "all"
    test_value1 = "a"
    test_value2 = "b"
    test_value3 = "c"
    test_value4 = "d"
    test_value5 = "e"
    test_value6 = "f"
    test_value7 = "g"
    test_value8 = "h"
    test_value9 = "i"
    test_value10 = "j"

    assert variables is not None
    assert vars_cache is not None
    assert fact_cache is not None


# Generated at 2022-06-25 14:21:12.189595
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Create a test data
    connection_loader = ConnectionLoader()
    connection_loader.add_connection('smart', 'ssh', {})
    factory = connection_loader._factories['ssh']
    new_ssh_conn = factory()

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost')
    inventory_host = inventory.get_host('localhost')
    inventory_host.set_variable('ansible_connection', 'ssh')

    delegate_to = 'localhost'
    task_vars = dict(my_var='my_value')

    delegate_to_vars = dict(my_delegate_var='my_delegate_value')

    # Create a test VariableManager
    vm = VariableManager(loader=loader, inventory=inventory, version_info=ansible_version)
    vm.clear_facts

# Generated at 2022-06-25 14:21:23.177825
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # Test whether the returned value is a dictionary
    def test_is_dict(result):
        assert isinstance(result, dict)

    # Test whether the returned key set is a set
    def test_is_set(keyset):
        assert isinstance(keyset, set)

    # Test whether the key set of the returned value is a subset of the key set of the input
    def test_is_subset(result, hostvars):
        result_keyset = set(result.keys())
        hostvars_keyset = set(hostvars.keys())
        assert result_keyset.issubset(hostvars_keyset)

    # Test whether the returned value is a subset
    def test_is_subdict(result, extra_vars):
        assert extra_vars.items() <= result.items()


# Generated at 2022-06-25 14:22:14.341336
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # This case test get_vars()
    variable_manager_0 = VariableManager()
    variable_manager_0.extra_vars = {'foo': 'bar'}
    inventory = InventoryManager()
    hosts = [Host('example1'), Host('example2')]
    groups = [Group('example')]
    group = groups[0]
    group.set_variable('group_var', 'group_val')
    for host in hosts:
        host.set_variable('host_var', 'host_val')
    for host in hosts:
        group.add_host(host)
    for group in groups:
        inventory.add_group(group)
    return_value = variable_manager_0.get_vars(inventory, groups[0], None)

# Generated at 2022-06-25 14:22:21.890557
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    '''
    Tests setting nonpersistent facts.
    Tests that the facts are not loaded from a file when set.
    Tests that the facts do not overwrite facts previously set.
    '''
    tmp = tempfile.mkdtemp()
    filename = tmp + os.sep + 'facts.json'
    with open(filename, 'w') as fd:
        fd.write(json.dumps({'hostname': 'bogus', 'value': 'old'}))
    facts = dict()
    with open(filename, 'r') as fd:
        facts = json.loads(fd.read())
    assert(facts != {})
    # set some nonpersistent facts
    vm = VariableManager()
    assert(vm._nonpersistent_fact_cache == dict())

# Generated at 2022-06-25 14:22:33.625929
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    variable_manager_0 = VariableManager()

    variable_manager_0.set_host_variable('hostvarname', 'myhost')
    variable_manager_0.set_host_variable('myhost', 'my_test_var', 'my_test_value')

    variable_manager_0.set_host_variable('myhost', 'ansible_play_hosts_all', ['test_play_host_all'])
    variable_manager_0.set_host_variable('myhost', 'ansible_play_hosts', ['test_play_host'])
    variable_manager_0.set_host_variable('myhost', 'ansible_play_batch', ['test_play_batch'])

    # print("Hostvars: %s" % variable_manager_0.get_host_vars('hostvarname

# Generated at 2022-06-25 14:22:44.581016
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    variable_manager_1._fact_cache = {}
    variable_manager_1._host_specific_vars_files = {}
    variable_manager_1._options_vars = {}
    variable_manager_1._vars_cache = {}
    variable_manager_1._inventory = {}
    variable_manager_1.register_host_variable(host='host_0',variable='vars_files')
    variable_manager_1.register_host_variable(host='host_0',variable='nonpersistent_facts')
    variable_manager_1.register_host_variable(host='host_0',variable='fact_cache')
    variable_manager_1.register_host_variable(host='host_0',variable='vars_cache')
    variable_manager_1.register_host

# Generated at 2022-06-25 14:22:52.747957
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    hostname_0 = "test"
    hostname_1 = "test"
    hostname_2 = "test"
    hostname_3 = "test"
    from ansible.playbook.play_context import PlayContext
    playcontext_0 = PlayContext()
    loaders_0 = []
    loaders_0.append("")
    loaders_0.append(loader_0)
    variable_manager_0._set_group_vars(None, None, loaders_0)
    variable_manager_0._set_host_variable("", "", "")
    variable_manager_0._set_host_variable("", "", "")
    variable_manager_0._set_host_variable("", "", "")
    variable_manager_0._set_host_

# Generated at 2022-06-25 14:22:58.923871
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    ''' unit test for method set_host_variable of class VariableManager '''
    set_host_variable(VariableManager(), 'localhost', 'test_var', 'test')

# This is used to test that the ignore error functionality in get_vars is working correctly
# with an error in a role's vars/main.yml

# Generated at 2022-06-25 14:23:01.854043
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_test_instance = VariableManager()
    assert_true(isinstance(variable_manager_test_instance, VariableManager))


# Generated at 2022-06-25 14:23:10.150239
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager()
    variable_manager_1.set_host_variable("abc", "a", "b")
    variable_manager_1.set_host_variable("def", "d", ["e", "f"])
    if variable_manager_1.get_vars(loader=None, play=None, host=Host("abc"))["a"] != "b":
        raise AssertionError("VariableManager.get_vars(loader=None, play=None, host=Host(\"abc\"))[\"a\"] returns {}, instead of b".format(variable_manager_1.get_vars(loader=None, play=None, host=Host("abc"))["a"]))

# Generated at 2022-06-25 14:23:12.850562
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    test_case_0()


if __name__ == '__main__':
    test_VariableManager_get_vars()

# Generated at 2022-06-25 14:23:21.177713
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()

# Generated at 2022-06-25 14:24:44.666917
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_obj = VariableManager()
    variable_manager_obj.set_nonpersistent_facts("host", {"test": "test"})
    assert variable_manager_obj._nonpersistent_fact_cache["host"]["test"] == "test"



# Generated at 2022-06-25 14:24:51.371362
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    test_VariableManager_set_host_variable_arg_0 = None
    test_VariableManager_set_host_variable_arg_1 = None
    test_VariableManager_set_host_variable_arg_2 = None
    try:
        variable_manager_0.set_host_variable(test_VariableManager_set_host_variable_arg_0, test_VariableManager_set_host_variable_arg_1, test_VariableManager_set_host_variable_arg_2)
    except TypeError:
        pass


# Generated at 2022-06-25 14:24:55.237259
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    get_vars_0 = VariableManager()
    get_vars_1 = get_vars_0.get_vars(get_vars_0)
    get_vars_2 = get_vars_0.get_vars(get_vars_0, get_vars_1)
    get_vars_3 = get_vars_0.get_vars(None)


# Generated at 2022-06-25 14:24:57.365333
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()
    host = 'host1'
    facts = {}
    variable_manager.set_nonpersistent_facts(host, facts)


# Generated at 2022-06-25 14:25:00.835968
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vars_0 = VariableManager()
    #
    # Test for function get_vars for case 1.
    #
    test_case_0()


# Generated at 2022-06-25 14:25:11.518891
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # we need to do a bunch of setup to mimic loading up a play
    fake_loader = DictDataLoader({
        "test_play.yml": """
        - hosts: all
          vars:
             foo: bar
        """,
        "roles/test_role/vars/main.yml": """
        role_var: role_var_value
        """,
        "roles/test_role/tasks/main.yml": """
        - name: test task
          debug:
             var: role_var
        """,
        "roles/test_role/meta/main.yml": """
        dependencies:
           - { role: other_role }
        """
    })

    fake_inventory = InventoryManager(loader=fake_loader, sources="localhost")

# Generated at 2022-06-25 14:25:20.557856
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    TODO:
    * test get_vars with 'host' present
    * test get_vars with 'host' absent
    * test get_vars with 'host' having 'groups' attribute
    * test get_vars with 'host' having 'vars' attribute
    * test get_vars with 'host' having '_fact_cache' attribute
    * test get_vars with 'host' having '_vars_cache' attribute
    * test get_vars with 'task' present
    * test get_vars with 'task' absent
    * test get_vars with 'play' present
    * test get_vars with 'play' absent
    '''
    variable_manager_0 = VariableManager()

    # basic test
    #host = mock.Mock()
    #host.get_

# Generated at 2022-06-25 14:25:27.196275
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.extra_vars = dict()
    variable_manager_0.extra_vars = {'all': {}, 'ansible_play_name': 'test_play_name', 'play_hosts': []}
    variable_manager_0.extra_vars = {'play_hosts': []}
    variable_manager_0.extra_vars = {'ansible_play_name': 'test_play_name'}
    play_0 = Play()
    variable_manager_0.set_inventory(inventory=Inventory())
    variable_manager_0.set_inventory(inventory=Inventory(host_list=['test_host_list']))

# Generated at 2022-06-25 14:25:31.275666
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # test simple empty case
    variable_manager_0 = VariableManager()
    host_0 = Host(name=u'localhost')
    variables_0 = variable_manager_0.get_vars(host=host_0)
    assert(isinstance(variables_0, MutableMapping))
    assert(len(variables_0.keys()) > 30)


# Generated at 2022-06-25 14:25:32.658144
# Unit test for constructor of class VariableManager
def test_VariableManager():
    test_case_0()


if __name__ == '__main__':
    test_VariableManager()