

# Generated at 2022-06-25 14:16:31.011259
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager = VariableManager()
    variable_manager.set_host_facts('test_host', {'test_fact': 'test_fact_value'})
    assert variable_manager._fact_cache['test_host']['test_fact'] == 'test_fact_value'



# Generated at 2022-06-25 14:16:39.038987
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Build the variables manager
    option_spec = {}
    options_vars = {}
    inventory = None

    variable_manager = VariableManager(loader=None, inventory=inventory, version_info=ansible_version_info,
                                       host_vars=None, group_vars=None, play_vars=None, play_vars_files=None)

    # Set a loop variable
    variable_manager.set_nonpersistent_facts('***', {'ansible_loop': {'var2': ['val2', 'val3'], 'var1': 'val1'}})

    # Set a super loop variable
    variable_manager.set_nonpersistent_facts('***', {'ansible_super_loop': {'var2': ['val2', 'val3'], 'var1': 'val1'}})



# Generated at 2022-06-25 14:16:41.228265
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_manager = VariableManager()
    var_manager.get_vars()


# Generated at 2022-06-25 14:16:44.192153
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    get_vars_0 = variable_manager.get_vars()
    get_vars_1 = variable_manager.get_vars(host=None)


# Generated at 2022-06-25 14:16:49.421147
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    host = '127.0.0.1'
    varname = 'ansible_os_family'
    value = 'RedHat'
    # import pdb; pdb.set_trace()
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host, varname, value)


# Generated at 2022-06-25 14:17:00.300983
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_1 = VariableManager()
    variable_manager_2 = VariableManager()
    variable_manager_3 = VariableManager()
    variable_manager_4 = VariableManager()
    variable_manager_3.set_inventory(variable_manager_4.__getattribute__('_inventory'))
    variable_manager_2.set_inventory(variable_manager_4.__getattribute__('_inventory'))
    variable_manager_1.set_inventory(variable_manager_4.__getattribute__('_inventory'))
    variable_manager_0.set_inventory(variable_manager_4.__getattribute__('_inventory'))

# Generated at 2022-06-25 14:17:04.495157
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    inventory_0 = Inventory()
    my_variable_manager_0 = VariableManager(loader=None, inventory=inventory_0)
    my_variable_manager_0.get_host_variables(host=None, include_hostvars=None)
    my_variable_manager_0.get_host_vars_of_class(host=None, class_name=None)

# Generated at 2022-06-25 14:17:08.935110
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vars_with_sources_1 = VarsWithSources()
    var_1 = vars_with_sources_1.__len__()
    test_obj = VariableManager()
    # test_obj.set_nonpersistent_facts(host, facts=)


# Generated at 2022-06-25 14:17:12.511187
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    VariableManager.get_vars()
    '''
    play = Play()
    host = Host(name="localhost")
    task = None
    include_hostvars = True

    var_manager = VariableManager()

    # test before setting up
    result = var_manager.get_vars(play=play, host=host, task=task, include_hostvars=include_hostvars)
    assert result['inventory_hostname'] == 'localhost'


# Generated at 2022-06-25 14:17:17.907711
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Initialize VariableManager object
    vm = VariableManager()
    # Create a new facts dictionary
    facts = dict(a=0, b=1)
    # Set host facts
    vm.set_host_facts('dummy_host', facts)
    # Test if facts are set
    assert(vm.get_vars(host=Host(name='dummy_host'))['a'] == 0)
    assert(vm.get_vars(host=Host(name='dummy_host'))['b'] == 1)


# Generated at 2022-06-25 14:17:57.366552
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_0 = None


# Generated at 2022-06-25 14:18:08.196749
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 14:18:18.132781
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # create an object of the class "VariableManager"
    obj = VariableManager()
    # test the case when the 2nd argument is None
    var = obj.get_vars(play={}, include_delegate_to=True)
    assert isinstance(var, dict)
    # test the case when the 3rd argument is None
    var = obj.get_vars(play={}, include_hostvars=True)
    assert isinstance(var, dict)
    # test the case when the 4th argument is None
    var = obj.get_vars(play={}, include_delegate_to=True, include_hostvars=True)
    assert isinstance(var, dict)
    # test the case when the 5th argument is None

# Generated at 2022-06-25 14:18:27.972562
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test that the method correctly updates a variable cache entry.
    input_symbols = [
        ('localhost', 'ansible_foo', True),
        ('localhost', 'ansible_foo', 'bar'),
        ('localhost', 'ansible_foo_bar', {'foo': 'bar'}),
        ('localhost', 'ansible_foo', {'foo': 'bar'}),
        ('localhost', 'ansible_foo', {'bar': 'foo'}),
        ('localhost', 'ansible_foo', {'bar': {'foo': 'bar'}}),
        ('localhost', 'ansible_foo', {'bar': {'foo': 'bar'}, 'foo': 'bar', 'baz': 'foo'}),
    ]

# Generated at 2022-06-25 14:18:29.521813
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variablemanager = VariableManager()
    variablemanager.test_case_0()


# Generated at 2022-06-25 14:18:32.586127
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test variables
    var_0 = None

    # Prepare test

    # Test method
    test_case_0()

    # Check results

# Execute module
if __name__ == "__main__":
    main()

# Generated at 2022-06-25 14:18:41.654296
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_0 = VariableManager()
    var_1 = Play()
    var_2 = Play()
    var_3 = Play()
    var_4 = Play()
    var_5 = Play()
    var_6 = Host()
    var_7 = Host()
    var_8 = Host()
    var_9 = Host()
    var_10 = Host()
    var_11 = Task()
    var_12 = Task()
    var_13 = Task()
    var_14 = Task()
    var_15 = Task()
    var_16 = __opts__
    var_17 = __opts__
    var_18 = __opts__
    var_19 = __opts__
    var_20 = __opts__
    var_21 = __opts__
    var_22 = None
    var_

# Generated at 2022-06-25 14:18:51.559049
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_0 = variable_manager(loader = None, inventory = None, version_info = None, variable_manager = None)
    play = ansible.playbook.play_context.PlayContext(play = None, options = None, variable_manager = None, loader = None, passwords = None, run_id = None, new_stdin = None)
    task = ansible.vars.hostvars.HostVars(host = None, task = None)
    include_delegate_to = None
    include_hostvars = True
    expected_result = {}
    result = var_0.get_vars(play, task, include_delegate_to, include_hostvars)
    assert result == expected_result


# Generated at 2022-06-25 14:18:53.816976
# Unit test for constructor of class VariableManager
def test_VariableManager():
    var = VariableManager()
    assert var != None


# Generated at 2022-06-25 14:19:02.651875
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Try to clone into a directory that already exists.
    # var_0 = _VariableManager(loader=None, inventory=None, play=None)
    # var_0.get_vars(host=None, include_delegate_to=None, include_hostvars=None, include_fact_cache=None, include_cache=None, include_play_vars=None, include_task_vars=None, possible_task_vars=None, play=None, task=None)
    # test_case_0()

    var_0 = _VariableManager(loader=None, inventory=None, play=None)

# Generated at 2022-06-25 14:19:37.876762
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_0 = VariableManager(loader=None, inventory=None)
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None


# Generated at 2022-06-25 14:19:47.444858
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # Create a mock
    mock_0 = Mock()

    # Create a mock
    mock_1 = Mock()

    # Create a mock
    mock_2 = Mock()

    # Create a mock
    mock_3 = Mock()

    # Create a mock
    mock_4 = Mock()

    # Create a mock
    mock_5 = Mock()

    # Create a mock
    mock_6 = Mock()

    # Create a mock
    mock_7 = Mock()

    # Create a mock
    mock_8 = Mock()
    mock_8.is_template.side_effect = test_utils.CallableBool(True)

    # Create a mock
    mock_9 = Mock()

    # Create a mock
    mock_10 = Mock()

    # Create a mock
    mock_11 = Mock()

    # Create a mock


# Generated at 2022-06-25 14:19:54.845848
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variablemanager_0 = VariableManager()
    play_0 = None
    host_0 = None
    task_0 = None
    variablemanager_0.get_vars(play_0, host_0, task_0)
    play_1 = None
    host_1 = None
    task_1 = None
    include_hostvars = None
    variablemanager_0.get_vars(play_1, host_1, task_1, include_hostvars)
    play_2 = None
    host_2 = None
    task_2 = None
    include_hostvars = None
    include_delegate_to = None
    variablemanager_0.get_vars(play_2, host_2, task_2, include_hostvars, include_delegate_to)
    play_3 = None


# Generated at 2022-06-25 14:19:56.256350
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    with pytest.raises(TypeError):
        assert VariableManager.set_host_variable(var_0)

# Generated at 2022-06-25 14:19:58.928103
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_0 = VariableManager()

    # Test with valid arguments:
    host = '127.0.0.1'
    varname = 'ansible_check_mode'
    value = False

    var_0.set_host_variable(host, varname, value)


# Generated at 2022-06-25 14:20:01.616831
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    global var_0
    var_0 =  VariableManager()
    if (var_0.get_vars()):
        print('Test passed!')
        return 0
    else:
        print('Test failed!')
        return -1


if __name__ == '__main__':
    import sys
    sys.exit(test_VariableManager_get_vars())

# Generated at 2022-06-25 14:20:04.425088
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    var_0 = VariableManager()
    var_1 = None
    var_2 = None
    # Call the function
    var_0.set_nonpersistent_facts(var_1, var_2)



# Generated at 2022-06-25 14:20:13.934192
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_0 = VariableManager()
    var_0.set_host_variable("foo", "bar", "baz")
    var_0.set_host_variable("foo", "bat", {"lol": "wut"})
    var_0.set_host_variable("foo", "bat", {"wut": "lol"})
    var_0.set_host_variable("foo3", "var3", "val3")
    var_1 = var_0._vars_cache
    var_2 = var_0._nonpersistent_fact_cache
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var

# Generated at 2022-06-25 14:20:24.426557
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    var_0 = VariableManager()

    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    var_6 = dict()
    var_7 = dict()
    var_8 = host_4
    var_9 = play_1
    var_10 = task_4
    var_11 = False
    var_12 = True
    var_13 = None
    var_14 = None
    var_15 = None

# Generated at 2022-06-25 14:20:31.239892
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # assert the validity of method set_host_facts of class VariableManager
    var_3 = VariableManager()
    var_0 = "test_facts"
    var_1 = var_3.get_vars()
    # This assertion fails, the value of var_2 is not "test_facts"
    assert var_1 == "test_facts", '''The value of var_2 is not "test_facts"'''


# Generated at 2022-06-25 14:21:11.905914
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    testcase_0 = FixtureTestCase(
        method_name='get_vars')
    test_case_0()


# Generated at 2022-06-25 14:21:14.521603
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    #assert test_case_0(var_0) == expected_result_0
    assert False


# Generated at 2022-06-25 14:21:21.255181
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test for the 'include_hostvars' flag, first setting the appropriate
    # inventory and hostvars values
    v = VariableManager()
    # There are no assertions on this method, since it has a lot of irregular behaviors.
    # This test simply ensures that it is callable
    v.get_vars()
    # This test should fail without being run, since it is missing a required parameter
    v.get_vars(include_hostvars=None)



# Generated at 2022-06-25 14:21:30.228499
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    print('=== Test: test_VariableManager_get_vars() ===')
    var_0 = VariableManager(loader=test_case_0(), inventory=test_case_0())
    var_1 = test_case_0()
    var_2 = test_case_0()
    var_3 = False
    var_4 = test_case_0()
    try:
        VariableManager.get_vars(var_0, var_1, var_2, var_3, var_4)
        print('The get_vars method passed the test')
    except:
        print('The get_vars method failed the test')


# Generated at 2022-06-25 14:21:33.094054
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager = VariableManager(loader=None, inventory=None)
    host = None
    facts = {}
    variable_manager.set_host_facts(host, facts)


# Generated at 2022-06-25 14:21:37.307115
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_0 = None
    var_1 = None

    # No assert statements
    # Tests supposed to make a call to get_vars method of VariableManager class
    # We cannot test this method because it calls methods with side effects like get_host and set_host_variable
    # Cannot mock these objects as this method is not intended to be a library method
    return


# Generated at 2022-06-25 14:21:43.843273
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_0 = VariableManager(loader=None, inventory=None, version_info=None, options_vars=None)
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = True
    # Calling method get_vars of class VariableManager
    var_6 = var_0.get_vars(
        host=var_1,
        include_hostvars=var_2,
        include_delegate_to=var_3,
        play=var_4,
        task=var_5
    )


# Generated at 2022-06-25 14:21:44.598407
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    var_0 = None


# Generated at 2022-06-25 14:21:46.707241
# Unit test for constructor of class VariableManager
def test_VariableManager():
    constructor_var_manager = VariableManager()
    assert_equal(constructor_var_manager.__class__.__name__, 'VariableManager')


# Generated at 2022-06-25 14:21:50.969549
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    print("\n\tTesting get_vars\n")
    variable_manager = VariableManager()
    variable_manager.get_vars(play=None, host=None, task=None, include_delegate_to=None, include_hostvars=None, _hosts_all=None, _hosts=None)


# Generated at 2022-06-25 14:22:27.968011
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    import json
    import os
    import tempfile
    import sys

    temp_fd, temp_file = tempfile.mkstemp()
    os.close(temp_fd)
    sys.path.insert(0, temp_file)
    os.environ['ANSIBLE_MODULE_UTILS'] = temp_file


# Generated at 2022-06-25 14:22:38.851753
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()

    # Set up inventory
    inventory = InventoryManager(loader=DataLoader())
    host_0 = Host(name='ansible')
    host_1 = Host(name='test_host')
    host_2 = Host(name='test_host')
    host_3 = Host(name='test_host')
    host_1.vars = {'var': 'value'}
    inventory.add_host(host_0)
    inventory.add_host(host_1)
    inventory.add_host(host_2)
    inventory.add_host(host_3)
    variable_manager_0.set_inventory(inventory)

    # Set up some data
    play_0 = Play()
    play_0._hosts_cache = {host_1}

# Generated at 2022-06-25 14:22:48.654076
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():

    variable_manager = VariableManager()

    host1 = 'www.example.com'
    facts1 = {'foo': 'bar'}
    variable_manager.set_nonpersistent_facts(host1, facts1)
    assert variable_manager.get_nonpersistent_facts(host1) == facts1

    host2 = 'www.example.org'
    facts2 = {'foo': 'baz'}
    variable_manager.set_nonpersistent_facts(host2, facts2)
    assert variable_manager.get_nonpersistent_facts(host2) == facts2

    assert variable_manager.get_nonpersistent_facts(host1) == facts1


# Generated at 2022-06-25 14:22:54.410926
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()

# Generated at 2022-06-25 14:23:05.310486
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    host = '192,168.0.1'
    facts = {'ansible_distribution':'Fedora', 'ansible_distribution_version':'19'}
    variable_manager_0 = VariableManager()
    variable_manager_0.set_nonpersistent_facts(host, facts)
    if variable_manager_0._nonpersistent_fact_cache[host]['ansible_distribution'] != 'Fedora':
       raise AssertionError('variable_manager_0._nonpersistent_fact_cache[host][\'ansible_distribution\'] = %s; expected: %s' % (variable_manager_0._nonpersistent_fact_cache[host]['ansible_distribution'], 'Fedora'))

# Generated at 2022-06-25 14:23:14.921493
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    play_0 = Play()
    task_0 = Task()
    delegated_host_name = None
    hostvars_0 = None
    delegated_host_vars_0 = None


# Generated at 2022-06-25 14:23:16.775570
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    variable_manager_1.get_vars(include_hostvars=True)


# Generated at 2022-06-25 14:23:18.512105
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    variable_manager = VariableManager()

    assert variable_manager.get_vars() == {}



# Generated at 2022-06-25 14:23:27.358061
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    '''
    Test for method VariableManager.set_nonpersistent_facts
    '''
    variable_manager_1 = VariableManager()
    assert variable_manager_1.vars_cache
    assert 'host_local' in variable_manager_1.vars_cache
    assert variable_manager_1.vars_cache['host_local'] == {'groups': {'ungrouped': ['127.0.0.1']}, 'inventory_hostname': '127.0.0.1'}
    assert variable_manager_1.get_vars_cache()
    assert variable_manager_1.get_vars_cache(True)
    assert 'host_local' in variable_manager_1.get_vars_cache(True)

# Generated at 2022-06-25 14:23:31.504173
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_facts("ansible", {"ansible": "item0"})
    assert variable_manager_0._fact_cache == {"ansible": {'ansible': 'item0'}}


# Generated at 2022-06-25 14:24:33.710992
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    host_vars_string = """
        ---
        host_level_var: "host level value"
        """

    host_vars = yaml.safe_load(host_vars_string)

    hostvars = {'host_level_var': 'host level value'}
    options_vars = {}


# Generated at 2022-06-25 14:24:45.522746
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts("test_host", {"fact_1": "nonpersistent_fact"})
    variable_manager.set_host_variable("test_host", "var_1", "host_variable")
    variable_manager.set_host_facts("test_host", {"fact_1": "persistent_fact"})
    variable_manager.get_vars(host=Host("test_host"))
    assert variable_manager._vars_cache == {"test_host": {"var_1": "host_variable",
                                                          "fact_1": "persistent_fact"}}
    assert variable_manager._fact_cache == {"test_host": {"fact_1": "persistent_fact"}}

# Generated at 2022-06-25 14:24:50.268990
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # given
    variable_manager_0 = VariableManager()
    host_0 = 'localhost'
    facts_0 = {'variable_manager': 'variable_manager'}

    # when
    variable_manager_0.set_nonpersistent_facts(host_0, facts_0)

    # then
    # TODO: Check values
    pass


# Generated at 2022-06-25 14:24:57.065590
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # create a mock inventory
    inventory = MagicMock()
    inventory.hosts = list()

    # create a mock of a host in the inventory
    host_0 = MagicMock()
    host_0.name = 'host_0'
    host_0.vars = dict(host_0_var_0 = 'host_0_val_0',
                       host_0_var_1 = 'host_0_val_1')

    # create another mock of a host in the inventory
    host_1 = MagicMock()
    host_1.name = 'host_1'
    host_1.vars = dict(host_1_var_0 = 'host_1_val_0',
                       host_1_var_1 = 'host_1_val_1')

    # create yet another mock of a host in the

# Generated at 2022-06-25 14:25:02.737314
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    host = None
    facts = dict()
    try:
        variable_manager_0.set_host_facts(host, facts)
    except AnsibleAssertionError as e:
        print("Expected error: %s" % e)


# Generated at 2022-06-25 14:25:06.391170
# Unit test for constructor of class VariableManager
def test_VariableManager():
    try:
        test_case_0()
    except Exception:
        return False

    return True

if __name__ == "__main__":
    test = test_VariableManager()
    if test == False:
        exit(1)

# Generated at 2022-06-25 14:25:12.183138
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_1 = test_case_0()
    host_1 = {
        'key1':'value1',
        'key2':'value2',
        'key3':'value3'
    }
    facts_1 = {
        'key1':'value1',
        'key2':'value2',
        'key3':'value3'
    }
    variable_manager_1.set_nonpersistent_facts(host=host_1,facts=facts_1)



# Generated at 2022-06-25 14:25:18.821823
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    host = "i1"
    facts = {"a": 4, "b": 4}
    variable_manager_0.set_host_facts(host, facts)
    if variable_manager_0._fact_cache["i1"] != {"a": 4, "b": 4}:
        print("set_host_facts failed, variable_manager_0._fact_cache[i1] is not {'a': 4, 'b': 4}")
        return 1
    return 0


# Generated at 2022-06-25 14:25:25.509695
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    """
    This test case contains following tests for VariableManager.get_vars():
    1. 'variable_manager' is None
    2. 'variable_manager' is not None and invalid
    3. 'variable_manager' is not None and 'host' is not None and 'host.name' is not None
    4. 'variable_manager' is not None and 'host' is None
    5. 'variable_manager' is not None and 'host' is not None and 'host.name' is None
    6. 'variable_manager' is not None and 'host' is None and 'host.name' is None
    """

    # Test Case 1
    print("\nTest Case 1: 'variable_manager' is None")
    variable_manager_1 = None
    host_1 = None


# Generated at 2022-06-25 14:25:27.978014
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()
    assert variable_manager_0.ansible_version == __version__, "variable_manager_0 instance attribute 'ansible_version' failed"
