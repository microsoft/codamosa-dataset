

# Generated at 2022-06-25 14:16:33.773024
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    host = None
    facts = {}
    var_man = VariableManager()
    result = var_man.set_nonpersistent_facts(host, facts)
    assert result is None


# Generated at 2022-06-25 14:16:40.800011
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_1 = VariableManager()
    variable_manager_2 = VariableManager()
    variable_manager_3 = VariableManager()
    variable_manager_4 = VariableManager()
    variable_manager_5 = VariableManager()
    variable_manager_6 = VariableManager()

    variable_manager_0.set_inventory(inventory_0)
    variable_manager_1.set_inventory(inventory_1)
    variable_manager_2.set_inventory(inventory_2)
    variable_manager_3.set_inventory(inventory_3)
    variable_manager_4.set_inventory(inventory_4)
    variable_manager_5.set_inventory(inventory_5)
    variable_manager_6.set_inventory(inventory_6)

    vars_0 = variable_manager_

# Generated at 2022-06-25 14:16:47.928439
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    list_0 = []
    vars_with_sources_0 = VarsWithSources(*list_0)
    variable_manager_0 = VariableManager()
    variable_manager_0.extra_vars = {}
    variable_manager_0.options_vars = {}
    variable_manager_0.set_inventory(None)
    variable_manager_0.set_loader(None)
    variable_manager_0.get_vars(None, None, vars_with_sources_0, True, False)

# Generated at 2022-06-25 14:16:50.483916
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Execute the test program
    test_case_0()


if __name__ == '__main__':
    test_VariableManager()

# Generated at 2022-06-25 14:17:01.027356
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    source = 'test_source'
    key = 'test_key'
    value = 'test_value'
    mock_vars_cache = dict()
    mock_vars_cache['test_host'] = dict()
    mock_vars_cache['test_host'][key] = value
    mock_vars_with_sources = dict()
    vars_with_sources = VarsWithSources(source, mock_vars_with_sources)
    var_manager = VariableManager()
    var_manager._vars_cache = mock_vars_cache
    var_manager._vars_with_sources['test_host'] = vars_with_sources
    host = 'test_host'
    varname = 'test_varname'

# Generated at 2022-06-25 14:17:06.029336
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # ensure that the loader kwarg is supplied to the constructor
    assert VariableManager()._loader is None
    assert VariableManager(loader=DataLoader())._loader is not None

    # ensure that the inventory kwarg is supplied to the constructor
    assert VariableManager()._inventory is None
    inv = Inventory(loader=DataLoader(), host_list=[])
    assert VariableManager(inventory=inv)._inventory is not None



# Generated at 2022-06-25 14:17:08.384494
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    VariableManager(loader=None, inventory=InventoryManager(loader=None, sources=None))


# Generated at 2022-06-25 14:17:12.635690
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test with args: host=host, varname=varname, value=value
    test_var_manager = VariableManager()
    host = Host(name='host')
    test_var_manager.set_host_variable(host=host, varname='varname', value='value')


# Generated at 2022-06-25 14:17:23.521641
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    dict_0 = dict()
    dict_0['play'] = None
    dict_0['host'] = None
    dict_0['task'] = None
    dict_0['include_delegate_to'] = True
    dict_0['include_hostvars'] = True
    dict_0['include_nonpersistent_facts'] = True
    vars_0 = VariableManager(dict_0)
    play_0 = Play(task_name='Test Play', task_vars=dict())
    task_0 = Task(name='Test Task', vars=dict())
    include_delegate_to_0 = True
    include_hostvars_0 = True

# Generated at 2022-06-25 14:17:28.578671
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    list_0 = []
    vars_with_sources_0 = VarsWithSources(*list_0)
    variable_manager_0 = VariableManager(loader=None, inventory=None)
    str_0 = "host"
    dict_0 = {"dict_0": 0}
    variable_manager_0.set_nonpersistent_facts(host=str_0, facts=dict_0)


# Generated at 2022-06-25 14:17:54.567902
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    """
    Test of method set_host_variable of class VariableManager
    """
    var_0 = VariableManager()
    var_1 = None
    var_0.set_host_variable(var_1, var_1, var_1)


# Generated at 2022-06-25 14:17:58.505060
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # if you give play or host, you must give task too
    # if you give play and task, you must give host too
    # task is optional
    var_0 = None
    get_vars_1 = None
    return True


# Generated at 2022-06-25 14:18:02.389916
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_0 = VariableManager()
    var_1 = None
    var_2 = None
    var_3 = None
    var_0.set_host_variable(var_1, var_2, var_3)


# Generated at 2022-06-25 14:18:11.598160
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_manager = VariableManager(loader=None, inventory=None)
    var_manager._hostvars = {'host': '10.0.0.2', 'port': 22}
    var_manager._nonpersistent_fact_cache = {'host': '10.0.0.3', 'name': 'target_host'}
    var_manager._vars_cache = {'host': '10.0.0.4', 'name': 'target_host'}
    var_manager._options_vars = {'app': 'app_0', 'url': 'url_0'}
    var_manager._fact_cache = {'host': {'ip': '10.0.0.2', 'port': 22}, 'name': 'target_host'}


# Generated at 2022-06-25 14:18:15.837187
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    try:
        var_0 = VarsWithSources({'a': 'b'}).__getitem__('a')
        if 'AssertionError' in str(var_0):
            var_1 = True
    except AssertionError as var_2:
        var_1 = False
    assert var_1


# Generated at 2022-06-25 14:18:26.347478
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Configure the instance
    var_manager = VariableManager()
    var_manager.extra_vars = {}
    var_manager._omit_token = "OMIT"
    var_manager._options_vars = {}
    var_manager._vars_cache = {}
    var_manager._nonpersistent_fact_cache = {}

    # Test the inherited constructor
    # in ansible.utils.context_objects.ContextManager
    assert hasattr(var_manager, '_init_contexts')
    assert hasattr(var_manager, '_current_context')
    assert hasattr(var_manager, '_context_cache')

    # Test the inherited constructor
    # in ansible.utils.context_objects.ModuleMagicVars
    assert hasattr(var_manager, '_magics')

    # Test the inherited constructor


# Generated at 2022-06-25 14:18:29.778981
# Unit test for method set_host_facts of class VariableManager

# Generated at 2022-06-25 14:18:30.623596
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    var_1 = None


# Generated at 2022-06-25 14:18:33.086853
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    var_0 = None
    assert VariableManager(inventory=var_0).set_nonpersistent_facts(host='{"": {}}', facts='{{}}')


# Generated at 2022-06-25 14:18:42.046498
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_0 = VariableManager()
    # set_host_variable(self, host, varname, value)
    # 
    # Sets a value in the vars_cache for a host.
    # 
    # Arguments:
    #   host(str):
    #   varname(str):
    #   value():
    # 
    # Returns:
    #   None
    # 

    # TEST CASE:
    var_0 = VariableManager()
    var_1 = None
    try:
        var_1 = var_0.set_host_variable(host=var_0, varname=var_0, value=var_0)
    except Exception as e:
        print(e)
        assert False

    # TEST CASE:


# Generated at 2022-06-25 14:19:09.062364
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    var_0 = VariableManager()
    var_1 = set_host_facts(var_0, test_case_0, test_case_0)


# Generated at 2022-06-25 14:19:11.980802
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    var_0 = VarsWithSources({0:'abc'},{0:'abc'})
    test_case_0(var_0)


# Generated at 2022-06-25 14:19:15.117443
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    
    # Test 1
    key = None
    var_0 = VarsWithSources()
    var_0.data = {}
    var_0.sources = {}
    var_0.data[key] = None
    var_0.__getitem__(key)

# Generated at 2022-06-25 14:19:18.200828
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    # item = None
    # var_sources = None
    # 
    # 
    # instance = VarsWithSources(item, var_sources)
    # test = instance.__getitem__(key)
    raise Exception('Test not implemented!')


# Generated at 2022-06-25 14:19:21.249842
# Unit test for constructor of class VariableManager
def test_VariableManager():
    var_manager = None
    try:
        var_manager = VariableManager()
    except Exception as ex:
        raise AssertionError("An exception was raised when constructing a VariableManager object")

    test_case_0()

if __name__ == "__main__":
    test_VariableManager()

# Generated at 2022-06-25 14:19:24.048242
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_0 = None

    # Test case
    test_var_manager = VariableManager()
    test_var_manager.get_vars(
        play=None,
        host=None,
        task=None,
        include_delegate_to=True,
        include_hostvars=True)


# Generated at 2022-06-25 14:19:29.029447
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vsm = VariableManager()
    test_data_0 = ("test_value",)
    test_data_1 = ("test_value",)
    test_data_2 = ("test_value",)
    test_data_3 = ("test_value",)
    vsm.set_nonpersistent_facts(test_data_0, test_data_1)
    vsm.set_nonpersistent_facts(test_data_2, test_data_3)


# Generated at 2022-06-25 14:19:36.478902
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variablemanager = VariableManager()
    variablemanager.set_host_variable('host', 'test_vars', {})
    variablemanager.get_vars(host=Host(name='host'))
    variablemanager.get_vars()
    variablemanager.set_host_variable('host', 'test_vars', {})
    variablemanager.get_vars(host=Host(name='host'))
    variablemanager.get_vars()


# Generated at 2022-06-25 14:19:45.274282
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # Declare objects and Variables for test case

    variable_manager = VariableManager()

    play =  Play()

    task =  Task()

    existing_variables =  dict()

    include_delegate_to = True

    include_hostvars = True

    filter_tagged_tasks = False

    # Call the method
    result = variable_manager.get_vars(play=play, task=task, existing_variables=existing_variables, include_delegate_to=include_delegate_to, include_hostvars=include_hostvars, filter_tagged_tasks=filter_tagged_tasks)
    assert result is None


# Generated at 2022-06-25 14:19:52.567051
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_0 = None

# Generated at 2022-06-25 14:20:46.479174
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    test_case_0()

# Generated at 2022-06-25 14:20:56.414349
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_0 = None
    var_1 = VariableManager()
    var_2 = None
    var_3 = None
    var_4 = None

# Generated at 2022-06-25 14:20:59.337196
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    """
    Method set_host_variable of class VariableManager
    """
    var_0 = VariableManager()
    var_0.set_host_variable("test_name", "test_varname", 35)


# Generated at 2022-06-25 14:21:00.695659
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    result = VariableManager().get_vars()
    assert result


# Generated at 2022-06-25 14:21:05.679745
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_0 = VariableManager()
    var_1 = dict()
    try:
        var_0.set_host_variable('var_1', 'var_1', var_1)
    except:
        pass
    try:
        var_0.set_host_variable('var_1', 'var_1', 'var_1')
    except:
        pass


# Generated at 2022-06-25 14:21:06.636739
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    var_0 = None


# Generated at 2022-06-25 14:21:13.445849
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-25 14:21:16.877212
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    if var_0 is None:
        var_0 = VariableManager()
    host = "dummy"
    facts = None
    var_0.set_nonpersistent_facts(host, facts)

# Generated at 2022-06-25 14:21:18.998677
# Unit test for constructor of class VariableManager
def test_VariableManager():
    var_0 = VariableManager()
    var_0.get_vars()


# Generated at 2022-06-25 14:21:23.782492
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    global_vars = dict(fact_1 = "fact_1")
    host_vars = dict(host_1 = dict(fact_1 = "fact_1"))
    var_0 = VariableManager(host_vars, global_vars)
    assert var_0.get_vars(host = host_vars) == [global_vars, host_vars]


# Generated at 2022-06-25 14:23:04.091928
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_0 = None


# Generated at 2022-06-25 14:23:04.811472
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_0 = None
    var_1 = 0


# Generated at 2022-06-25 14:23:06.433718
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    try:
        var_0 = None
    except ValueError:
        print("No value for variable: var_0")


# Generated at 2022-06-25 14:23:10.525729
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    foo = None
    vars_with_sources_0 = VarsWithSources()
    vars_with_sources_0['foo'] = foo
    with pytest.raises(KeyError):
        var_0 = vars_with_sources_0['foo']


# Generated at 2022-06-25 14:23:16.106983
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    var_0 = host_0 = task_0 = play_0 = loader = host = self = VariableManager()
    include_hostvars = include_delegate_to = False

    self.setup_cache()
    self.set_host_variables(host_0, dict())
    self.get_vars(play_0, host_0, task_0, include_hostvars, include_delegate_to)



# Generated at 2022-06-25 14:23:18.454049
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_0 = VariableManager()
    with pytest.raises(AnsibleError):
        assert var_0.get_vars()


# Generated at 2022-06-25 14:23:23.615555
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    data_0 = {}
    sources_0 = {}
    var_0 = VarsWithSources.new_vars_with_sources(data_0, sources_0)
    key_0 = None
    # <<<<<<< HEAD
    # val = var_0[key_0]
    # =======
    val = None
    # >>>>>>> 6a96d7f1216ca0f8e1c66d0fff18848dbc4067e7
    assert val == None


# Generated at 2022-06-25 14:23:28.331341
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    target_0 = VariableManager(loader=loader_0, inventory=inventory_0, version_info=version_info_0)
    play_0 = Play()
    host_0 = Host(name='localhost', port=22)
    target_0.set_host_variable(host=host_0, varname=var_0, value=var_1)
    target_0.get_vars(play=play_0, host=host_0, task=task_0, include_delegate_to=False, include_hostvars=True)


# Generated at 2022-06-25 14:23:31.057363
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    args_0 = *()
    # Run method
    test_obj.set_host_variable(*args_0)
    assert True


# Generated at 2022-06-25 14:23:33.911963
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    variable_manager = new_variable_manager()

    facts = {}
    host = ""
    variable_manager.set_host_facts(host, facts)



# Generated at 2022-06-25 14:25:33.101335
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_1 = VariableManager()
    value = None
    var_1.set_host_variable(str(value), 'ansible_check_mode', value)
    assert var_1.get_vars(host=Host('localhost')) == {'ansible_check_mode': None}
    value = 10
    var_1.set_host_variable(str(value), 'ansible_check_mode', value)
    assert var_1.get_vars(host=Host('localhost')) == {'ansible_check_mode': None}
    value = 'string'
    var_1.set_host_variable(str(value), 'ansible_check_mode', value)
    assert var_1.get_vars(host=Host('localhost')) == {'ansible_check_mode': None}
    value

# Generated at 2022-06-25 14:25:35.324754
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_0 = VariableManager()
    host = None
    varname = None
    value = None
    var_0.set_host_variable(host, varname, value)
