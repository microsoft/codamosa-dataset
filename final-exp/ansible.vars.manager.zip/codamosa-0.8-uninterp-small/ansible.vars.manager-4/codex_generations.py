

# Generated at 2022-06-25 14:16:30.042921
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-25 14:16:38.424413
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_0 = VariableManager()
    int_0 = -3096
    play_0 = Play()
    task_0 = Task()
    bool_3 = False
    bool_4 = True
    var_1 = var_0.get_vars(play_0, task_0, bool_3, bool_4)
    int_1 = -3252
    int_2 = -3174
    int_3 = -2598
    int_4 = 11711
    int_5 = -28038
    tuple_0 = (int_1, int_2, int_3, int_4, int_5)
    tuple_1 = (int_5, int_1, int_2, int_3, int_4)
    var_3 = sorted(tuple_0) == sorted(tuple_1)



# Generated at 2022-06-25 14:16:42.270244
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_0 = VariableManager()
    int_0 = 0
    str_0 = test_case_0()
    var_1 = var_0.get_vars(int_0, str_0)
    pass


# Generated at 2022-06-25 14:16:53.832101
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    int_0 = -1980
    dict_0 = dict()
    dict_0['_host'] = int_0
    dict_0['include_hostvars'] = int_0
    dict_0['include_delegate_to'] = int_0
    dict_0['_fact_cache'] = dict()
    dict_0['_vars_cache'] = dict()
    dict_0['_nonpersistent_fact_cache'] = dict_0
    dict_0['_omit_token'] = int_0
    dict_0['_options_vars'] = dict()
    dict_0['_inventory'] = int_0
    dict_0['_loader'] = int_0
    dict_0['_hostvars'] = dict()
    dict_0['_play_context'] = int_0
    dict_

# Generated at 2022-06-25 14:16:56.522722
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # setup
    var_manager = VariableManager()

    # execute
    var_manager.get_vars('', [])

    # verify
    assert True is True

# Generated at 2022-06-25 14:17:00.617175
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
        var = VariableManager()
        assert var.set_host_variable("var_0", "value0") == None
        assert var.set_host_variable("var_1", "value1") == None
        assert var.set_host_variable("var_2", "value2") == None



# Generated at 2022-06-25 14:17:06.261855
# Unit test for constructor of class VariableManager
def test_VariableManager():
    ds = (
        'name: "{{ inventory_hostname }}"\n'
        'changed_when: false'
    )
    obj = Task.load(ds, file_name=None)
    obj._parent = 'fake'
    obj._role = 'fake'
    obj._loader = Mock()
    task = obj

    play = Play.load(dict(
        name="test play",
        hosts="local",
        gather_facts="no",
        tasks=[
            {
                'name': 'test task',
                'action': 'fake'
            }
        ]
    ))
    host = Host("example.com")

    # test for constructor
    VariableManager("inventory", "playbook_basedir")

    # test for _get_delegated_vars

# Generated at 2022-06-25 14:17:16.037669
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    int_0 = 2
    str_0 = "test_VariableManager_set_host_variable"
    str_1 = str_0[-1]
    str_2 = str_1 + str_1
    str_3 = str_2 + str_2
    str_4 = str_3 + str_2
    str_5 = str_4 + str_4
    str_6 = str_5 + str_5
    str_7 = str_6 + str_6
    str_8 = str_7 + str_7
    str_9 = str_8 + str_8
    str_10 = str_9 + str_9
    str_11 = str_10 + str_10
    str_12 = str_11 + str_11
    str_13 = str_12 + str_12

# Generated at 2022-06-25 14:17:20.878081
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Testing for KEY_ERROR
    try:
        var_0 = VariableManager()
        var_0.get_vars(play=None, host=None, task=None)
    except KeyError:
        # Expected behavior
        pass

# Testing for DYNAMIC_TYPE_ERROR

# Generated at 2022-06-25 14:17:22.448519
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()



# Generated at 2022-06-25 14:17:48.586387
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    host = 'localhost'
    varname = 'somevar'
    value = 42
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host, varname, value)
    assert variable_manager._vars_cache[host][varname] == value

# Generated at 2022-06-25 14:17:55.155124
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test case 1: Raise the exception of not being the parameter Inventory
    variable_manager_1 = VariableManager()
    inventory_1 = Play()
    task_1 = BaseTask()
    play_1 = BaseTask()
    ansible_runner = Runner()
    play_1.post_validate(ansible_runner, templar=None)
    # AssertionError: VariableManager instance need an Option and Inventory instance.
    try:
        variable_manager_1.get_vars(play=play_1,
                                    host=inventory_1,
                                    task=task_1)
    except AssertionError:
        print("Test case 1: Pass")
    else:
        print("Test case 1: Fail")

    # Test case 2: Raise the exception of not being the parameter Option
    variable_manager_2 = Variable

# Generated at 2022-06-25 14:17:59.418018
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    host = 'test_host'
    facts = {'test_fact': 'test_value'}
    variable_manager_0.set_host_facts(host, facts)


# Generated at 2022-06-25 14:18:01.509489
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Instantiate the VariableManager class with no parameters
    variable_manager_0 = VariableManager()


# Generated at 2022-06-25 14:18:07.663872
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    host = Host(name="host1")
    host_name = host.get_name()
    varname = 'test_variable'
    value = 'test_value'
    variable_manager.set_host_variable(host_name, varname, value)
    if variable_manager._vars_cache[host_name][varname] != value:
        raise AssertionError("test_VariableManager_set_host_variable failed")


# Generated at 2022-06-25 14:18:13.745593
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    variable_manager_0 = VariableManager()

    play_0 = Play()
    play_0._finalize_callbacks = deque()
    play_0._post_validation_callbacks = deque()
    play_0._handler_callbacks = deque()
    play_0._task_blocks = deque()
    play_0._tqm = None
    # Try to set this attribute of play_0 to a bad value
    try:
        play_0._tqm = -1
    except AssertionError:
        pass

    play_0._dep_chain = deque()
    play_0._variable_manager = variable_manager_0
    play_0._basedir = u'/home/mikhail/ansible/test/integration'
    play_0._roles = deque()

    play_

# Generated at 2022-06-25 14:18:14.879031
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    pass


# Generated at 2022-06-25 14:18:25.666092
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()

    # 1. Test with valid params.
    host_0 = Host('127.0.0.1')
    play_0 = Play()
    task_0 = Task()

    variables_0 = variable_manager_0.get_vars(play_0, host_0, task_0)
    assert type(variables_0) == dict
    assert all([len(variable_0) == 1 for variable_0 in variables_0.keys()])
    assert all([type(variable_0) == str for variable_0 in variables_0.keys()])
    assert all([type(variable_0) == list for variable_0 in variables_0.values()])

    # 2. Test when 'host' is None.

# Generated at 2022-06-25 14:18:34.954973
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # variables A defined in source A
    source_A = {'A': {'hostvars': {'host_A': {'ansible_host': 'host_A', 'var_A': 'var_A'}}}}
    # variables B defined in source B
    source_B = {'B': {'hostvars': {'host_B': {'ansible_host': 'host_B', 'var_B': 'var_B'}}}}

    variable_manager_1 = VariableManager()
    # variable_manager_1 should have variables from source A
    variable_manager_1.add_dictionary(source_A['A'])
    # variable_manager_1 should have variables from source B
    variable_manager_1.add_dictionary(source_B['B'])
    # variable_manager_1 should have variables

# Generated at 2022-06-25 14:18:37.889254
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_1 = VariableManager()

    facts = {"a": "1", "b": "2"}
    variable_manager_1.set_host_facts("test_0", facts)


# Generated at 2022-06-25 14:19:01.637395
# Unit test for constructor of class VariableManager
def test_VariableManager():
    try:
        test_case_0()
    except BaseException as exception:
        print(exception)
        print("VariableManager test has failed")
    else:
        print("VariableManager test successful")



# Generated at 2022-06-25 14:19:04.292295
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    print(variable_manager_0.get_vars(host=None, include_hostvars=False))
    print(variable_manager_0.get_vars(host=None, include_hostvars=True))


# Generated at 2022-06-25 14:19:11.153586
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    test_cases = [test_case_0]
    for i, test_case in enumerate(test_cases):
        print("test_case %d: " % (i+1))
        test_case()
        print("")


if __name__ == "__main__":
    test_VariableManager_set_host_variable()

# Generated at 2022-06-25 14:19:19.363791
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_1 = VariableManager()
    variable_manager_1.set_nonpersistent_facts('host1', {'fact1': 'value1', 'fact2': 'value2'})
    variable_manager_1.set_nonpersistent_facts('host2', {'fact3': 'value3', 'fact4': 'value4'})
    variable_manager_1.set_nonpersistent_facts('host3', {'fact5': 'value5', 'fact6': 'value6'})
    assert variable_manager_1._nonpersistent_fact_cache['host1']['fact1'] == 'value1'
    assert variable_manager_1._nonpersistent_fact_cache['host1']['fact2'] == 'value2'

# Generated at 2022-06-25 14:19:20.158548
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    test_case_0()


# Generated at 2022-06-25 14:19:24.672973
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts("server1",{"ansible_os_type":"redhat"})
    variable_manager.set_nonpersistent_facts("server2",{"ansible_os_family":"redhat"})
    variable_manager.set_nonpersistent_facts("server1",{"ansible_os_type":"redhat"})
    variable_manager.set_nonpersistent_facts("server3",{"ansible_os_type":"ubuntu"})

    assert variable_manager._nonpersistent_fact_cache["server1"] == {"ansible_os_type":"redhat"}
    assert variable_manager._nonpersistent_fact_cache["server2"] == {"ansible_os_family":"redhat"}

# Generated at 2022-06-25 14:19:28.885172
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_1 = VariableManager()
    hostname = 'test_host'
    facts = dict()
    facts['test_fact'] = 'test_value'
    variable_manager_1.set_nonpersistent_facts(hostname, facts)
    assert variable_manager_1._nonpersistent_fact_cache[hostname]['test_fact'] == 'test_value'


# Generated at 2022-06-25 14:19:34.264938
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_variable('127.0.0.1', 'AnsibleHost', '127.0.0.1')
    print(variable_manager_0._vars_cache['127.0.0.1'])


# Generated at 2022-06-25 14:19:44.754248
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    :return:
    '''
    #
    # Stage 1: set up the test case
    #
    # Create the object to test
    variable_manager_0 = VariableManager()
    #
    # Stage 2: assert preconditions
    #
    #
    # Stage 3: execute the test
    #
    # Get the expected result
    expected_vars_0 = {
        'hostvars': {},
        'groups': {},
        'omit': '__omit_place_holder__',
    }
    #
    # Get the actual result
    actual_vars_0 = variable_manager_0.get_vars()
    #
    # Stage 4: assert postconditions
    #
    assert actual_vars_0 == expected_vars_0
    #
    #

# Generated at 2022-06-25 14:19:48.769184
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()
    vm0 = {'local': {'gid': 1000, 'username': 'root', 'uid': 0, 'path': '/'},
           'ansible_local': {'username': 'root', 'uid': 0, 'gid': 1000, 'shell': '/bin/sh'}}
    variable_manager.set_nonpersistent_facts('localhost', vm0)


# Generated at 2022-06-25 14:20:35.731868
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    play_0 = { 'hosts': UUID('8a1e3c58-67af-11e9-b876-acde48001122'), }
    host_0 = None
    task_0 = Task()
    variable_manager_0.get_vars(play=play_0, host=host_0, task=task_0)


# Generated at 2022-06-25 14:20:43.591093
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    hostvars = {}
    hostvars['localhost'] = {}
    hostvars['localhost']['ansible_all_ipv4_addresses'] = ['192.168.1.1',  '172.16.1.1']
    hostvars['client1'] = {}
    hostvars['client1']['ansible_all_ipv4_addresses'] = ['192.168.1.2',  '172.16.1.2']
    variable_manager_1 = VariableManager(hostvars=hostvars)

    # Test case 0: empty play
    play_0 = Play()
    # Test case 1: empty task
    task_0 = Task()
    # Test case 2: empty variables
    variables_0 = {}
    # Test case 3: not empty task and variables

# Generated at 2022-06-25 14:20:53.245032
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    print("\n")
    test_case_0()
    host_0 = "localhost"
    varname_0 = "ansible_user"
    value_0 = "root"

# Generated at 2022-06-25 14:20:54.560201
# Unit test for constructor of class VariableManager
def test_VariableManager():
    test_case_0()
    
# test_VariableManager()

# Generated at 2022-06-25 14:21:03.546947
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    '''
    Test set_host_facts method of class VariableManager.
    '''
    variable_manager_1 = VariableManager()

    host_1 = 'host_1'
    facts_1 = { 'a':'a' }

    variable_manager_1.set_host_facts(host_1, facts_1)

    facts_2 = variable_manager_1._fact_cache[host_1]

    # check that facts_2 is a copy of facts_1
    facts_1['a'] = 'new_a'

    if facts_2['a'] != 'a':
        raise AssertionError('set_host_facts should make a copy of given facts')


# Generated at 2022-06-25 14:21:08.645708
# Unit test for constructor of class VariableManager
def test_VariableManager():
    test_case_0()

if __name__ == '__main__':
    import os
    import sys

    if not os.path.exists('/tmp/results'):
        os.mkdir('/tmp/results')
    sys.stdout = open('/tmp/results/test_VariableManager.txt', 'w')
    print('TESTING FOR CLASS VariableManager')
    test_VariableManager()
    print('FINISHED')

# Generated at 2022-06-25 14:21:13.343928
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Create test variables
    play_0 = Play()
    play_0.name = "Play_name"
    
    host_0 = Host("localhost")
    host_0.name = "Host_name"
    host_0.address = "127.0.0.1"
    host_0.port =  2222
    
    task_0 = Task()
    task_0.name = "Task_name"
    task_0.action = "Action_name"
    task_0.args = "Action_args"
    task_0.async_val = 42
    task_0.delegate_to = "localhost"
    task_0.environment = dict()
    task_0.first_available_file = "First_available_file"
    task_0.local_action = "Local_action"


# Generated at 2022-06-25 14:21:17.497080
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    assert hasattr(variable_manager_1, 'get_vars')
    assert callable(getattr(variable_manager_1, 'get_vars', None))


# Generated at 2022-06-25 14:21:22.222992
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    facts = {
        "a": "b",
        "n": 1
    }

    hostname = "test_case_0"
    test_case_0 = VariableManager()
    test_case_0.set_host_facts(hostname, facts)
    assert test_case_0.fact_cache[hostname] == facts


# Generated at 2022-06-25 14:21:27.269638
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    host = 'myhost'
    varname = 'myvarname'
    value = 'myvalue'
    variable_manager.set_host_variable(host, varname, value)
    assert variable_manager._vars_cache[host][varname] == value


# Generated at 2022-06-25 14:22:58.831188
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_nonpersistent_facts(host='test1', facts={'test1_key': 'test1_value'})
    variable_manager_0.set_nonpersistent_facts(host='test2', facts={'test2_key': 'test2_value'})
    assert variable_manager_0.get_vars(play=None, host=None, task=None)['test1_key'] == 'test1_value'
    assert variable_manager_0.get_vars(play=None, host=None, task=None)['test2_key'] == 'test2_value'

# Generated at 2022-06-25 14:23:08.625768
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Setup
    variable_manager_0 = VariableManager()
    variable_manager_0._vars_cache = {'foo': 'bar', 'baz': 'quz'}

    # Exercise
    value_0 = variable_manager_0.get_vars(host=str())

    # Verify
    assert value_0 == {}, 'Failed to get variable value'

    # Setup
    variable_manager_0 = VariableManager()
    variable_manager_0._vars_cache = {'foo': 'bar', 'baz': 'quz'}

    # Exercise
    value_0 = variable_manager_0.get_vars(host=str())

    # Verify
    assert value_0 == {}, 'Failed to get variable value'

    # Setup
    variable_manager_0 = VariableManager()
    variable_manager

# Generated at 2022-06-25 14:23:15.198193
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    host_0 = 'host'
    varname_0 = 'varname'
    value_0 = 'value'
    variable_manager_0.set_host_variable(host=host_0, varname=varname_0, value=value_0)
    assert variable_manager_0.vars_cache[host_0][varname_0] == value_0


# Generated at 2022-06-25 14:23:18.836588
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    host_0 = 'host_0'
    varname_0 = 'varname_0'
    value_0 = 'value_0'
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_variable(host_0, varname_0, value_0)


# Generated at 2022-06-25 14:23:23.124662
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    host_0 = Host('host_0')
    varname_0 = 'varname_0'
    value_0 = 'value_0'
    variable_manager_0.set_host_variable(host_0, varname_0, value_0)

if __name__ == '__main__':
    test_VariableManager_set_host_variable()

# Generated at 2022-06-25 14:23:27.661666
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    test_hostname_0 = 'test_hostname_0'
    test_facts_0 = 'test_facts_0'
    variable_manager_0 = VariableManager()
    variable_manager_0.set_host_facts(test_hostname_0, test_facts_0)
    test_host_0 = 'test_host_0'
    test_facts_1 = 'test_facts_1'
    variable_manager_0.set_host_facts(test_host_0, test_facts_1)


# Generated at 2022-06-25 14:23:29.097845
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    test_case_0()

if __name__ == '__main__':
    test_VariableManager_get_vars()

# Generated at 2022-06-25 14:23:35.022518
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    play_0 = Play()
    host_0 = Host()
    task_0 = Task()
    playbook = Playbook()
    playbook.set_variable_manager(variable_manager_0)
    play_0.set_playbook(playbook)
    test_var = variable_manager_0.get_vars(host=host_0, play=play_0, task=task_0, include_hostvars=True,
                                           include_delegate_to=False)
    assert test_var is not None
    assert test_var.get('inventory_hostname') is not None
    assert test_var.get('inventory_hostname_short') is not None
    assert test_var.get('groups') is not None

# Generated at 2022-06-25 14:23:38.528749
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    variable_manager_1.set_inventory(InventoryManager())
    variable_manager_1.set_globals({'a': 1})
    variable_manager_1.get_vars(host=Host('a'))


# Generated at 2022-06-25 14:23:40.261622
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager.get_vars()
