

# Generated at 2022-06-25 14:16:19.619110
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    vars_with_sources = VarsWithSources()
    vars_with_sources[u'foo'] = u'bar'
    assert vars_with_sources[u'foo'] == u'bar'


# Generated at 2022-06-25 14:16:26.787518
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-25 14:16:28.280367
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    test_case_0()



# Generated at 2022-06-25 14:16:30.535444
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    vars_with_sources = VarsWithSources()
    vars_with_sources.data = dict(a='test a')
    vars_with_sources.sources = dict(a='test source a')
    assert vars_with_sources['a'] == 'test a'


# Generated at 2022-06-25 14:16:38.748785
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # Note - we use the VarsWithSources functionality only to allow us to pass hostvars into the
    # VariableManager when it is instantiated
    vm = VariableManager(loader=None, inventory=Inventory(host_list=['']), hostvars=VarsWithSources())
    vm.set_inventory(Inventory(host_list=['localhost', 'testhost1', 'testhost2']))
    vm.set_host_variable('testhost1', 'testing_var', 'test1')
    vm.set_host_variable('testhost2', 'testing_var', 'test2')
    vm.set_host_variable('localhost', 'testing_var', 'test3')
    vm.set_host_variable('localhost', 'inventory_hostname', 'localhost')

    vars_with_sources_hostvars_1 = Vars

# Generated at 2022-06-25 14:16:41.888909
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    vars_with_sources_0 = VarsWithSources()
    key = None
    vars_with_sources_0.__getitem__(key)


# Generated at 2022-06-25 14:16:51.518366
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    vm._vars_cache = {'host1':{'test_var1':'test_val1'}, 'host2':{'test_var2':'test_val2'}}
    vm.set_host_variable('host1', 'test_var1', 'test_val1_new')
    assert vm._vars_cache['host1']['test_var1'] == 'test_val1_new'
    vm.set_host_variable('host2', 'test_var3', 'test_val3')
    assert vm._vars_cache['host2']['test_var3'] == 'test_val3'


# Generated at 2022-06-25 14:16:56.566972
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    host_name = 'host name'
    var_name = 'var name'
    value = 'some value'
    vm.set_host_variable(host_name, var_name, value)
    assert(vm._vars_cache[host_name][var_name] == value)


# Generated at 2022-06-25 14:16:57.968453
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # @todo: implement this test
    pass



# Generated at 2022-06-25 14:17:01.728816
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    manager = VariableManager()
    manager.set_host_variable('test_host', 'ansible_foo', 'bar')
    assert manager.get_vars(host=Host(name='test_host'))['ansible_foo'] == 'bar'


# Generated at 2022-06-25 14:17:47.655482
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    play_0 = Play()
    host_0 = Host('localhost')
    task_0 = None
    include_hostvars_0 = True

    variables_0 = variable_manager_0.get_vars(
        play=play_0,
        host=host_0,
        task=task_0,
        include_delegate_to=False,
        include_hostvars=include_hostvars_0,
    )


# Generated at 2022-06-25 14:17:50.405152
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    variable_manager.set_host_variable('fake_host', 'test', 'value')
    assert variable_manager._vars_cache['fake_host']['test'] == 'value'


# Generated at 2022-06-25 14:17:56.235517
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    # simple host
    host_0 = Host(name='test')
    # play
    play_0 = Play().load(dict(
        name="test play",
        hosts="localhost,127.0.0.1",
        gather_facts="no",
        roles=["test_role"],
    ), variable_manager=variable_manager_0, loader=DictDataLoader())
    play_0.post_validate(variable_manager=variable_manager_0)
    # task
    task_0 = Task().load(dict(
        name="test task",
        action={
            "module": "setup",
        },
    ), variable_manager=variable_manager_0, loader=DictDataLoader())

# Generated at 2022-06-25 14:17:59.627002
# Unit test for constructor of class VariableManager
def test_VariableManager():
    """
    test for the constructor of class VariableManager
    """
    variable_manager = VariableManager()
    assert not variable_manager._fact_cache



# Generated at 2022-06-25 14:18:09.562640
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager(loader=None, inventory=None, version_info=None, nonpersistent_facts=dict(), fact_cache=dict())
    hostname = 'hostname'
    facts = dict()
    facts['ansible_architecture'] = 'x86_64'
    facts['ansible_bios_date'] = '05/01/2006'
    facts['ansible_bios_version'] = '1.13'
    facts['ansible_date_time'] = '2017-01-24T20:48:34Z'
    facts['ansible_machine'] = 'x86_64'
    facts['ansible_memfree_mb'] = 976
    facts['ansible_memtotal_mb'] = 10231
    facts['ansible_processor_count'] = 2

# Generated at 2022-06-25 14:18:20.540485
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    set_loader_templar(VariableManager)

    # Initialize test
    test_case_0()

    # Method call we are testing
    args = {"host": None, "task": None, "include_hostvars": True, "include_delegate_to": True}
    kwargs = {}
    try:
        variable_manager_0.get_vars(**args)
    except Exception:
        pass

    # Assertions
    # Check if method returned anything
    if variable_manager_0.get_vars(**args) is not None:
        pass

    # Check if method returned the correct type (dictionary)
    if not isinstance(variable_manager_0.get_vars(**args), dict):
        pass

    # Check if method asserts on invalid arguments (invalid or null host)
   

# Generated at 2022-06-25 14:18:24.038411
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.extra_vars = {'foo': 'bar'}
    test = variable_manager_0.get_vars()
    assert test['foo'] == 'bar'


# Generated at 2022-06-25 14:18:31.578664
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_nonpersistent_facts(host='esxi0', facts={})
    variable_manager_0.set_host_variable(host='esxi0', varname='ansible_user', value='root')
    variable_manager_0.set_host_variable(host='esxi0', varname='ansible_password', value='')
    variable_manager_0.set_host_variable(host='esxi0', varname='ansible_port', value=22)
    variable_manager_0.set_host_variable(host='esxi0', varname='ansible_host', value='localhost')
    variable_manager_0.set_host_variable(host='esxi0', varname='ansible_connection', value='ssh')
    variable_

# Generated at 2022-06-25 14:18:40.939195
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()

    # test if the nonpersistent facts dict of host is empty
    # before setting any facts to it
    host_1 = 'host_1'
    host_2 = 'host_2'
    host_3 = 'host_3'

    assert variable_manager_0._nonpersistent_fact_cache[host_1] == dict(),\
            "The nonpersistent facts dict of host_1 is not empty"
    assert variable_manager_0._nonpersistent_fact_cache[host_2] == dict(),\
            "The nonpersistent facts dict of host_2 is not empty"
    assert variable_manager_0._nonpersistent_fact_cache[host_3] == dict(),\
            "The nonpersistent facts dict of host_3 is not empty"

    # test the set

# Generated at 2022-06-25 14:18:48.004833
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_1 = VariableManager()
    variable_manager_1.set_host_variable(u'foo', u'varname', u'value')
    assert variable_manager_1._vars_cache[u'foo'][u'varname'] == u'value'
    variable_manager_1.set_host_variable(u'foo', u'varname', u'value2')
    assert variable_manager_1._vars_cache[u'foo'][u'varname'] == u'value2'


# Generated at 2022-06-25 14:20:04.242648
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-25 14:20:08.397258
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_1 = VariableManager()
    variable_manager_2 = VariableManager(loader=DictDataLoader(), inventory=Inventory(host_list=[]))
    variable_manager_3 = VariableManager(loader=DictDataLoader(), inventory=Inventory(host_list=[]), version_info=__version__)


# Generated at 2022-06-25 14:20:12.804920
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    try:
        variable_manager_0.set_host_facts(host='host_0', facts={'var_var_0': 'val_var_0'})
    except Exception as e:
        print("set_host_facts() test failed: %s" % str(e))


# Generated at 2022-06-25 14:20:23.734635
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    play_0 = Play()
    host_0 = Host()
    task_0 = Task()
    variable_manager_0._inventory = None
    variable_manager_0._hostvars = None
    variable_manager_0._options_vars = {}
    variable_manager_0._omit_token = '__omit_place_holder__'
    variable_manager_0._host_cache = {}
    variable_manager_0._fact_cache = {}
    variable_manager_0._vars_cache = {}
    variable_manager_0._nonpersistent_fact_cache = {}
    variable_manager_0._delegated_vars_cache = {}
    variable_manager_0._loader = None
    variable_manager_0._extra_vars = {}
    variable_

# Generated at 2022-06-25 14:20:30.447587
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    var = variable_manager_0.get_vars(play=None, host=None, task=None, include_hostvars=False, include_delegate_to=True)
    assert 'ansible_play_hosts' in var
    assert 'ansible_play_batch' in var
    assert 'ansible_play_hosts_all' in var


# Generated at 2022-06-25 14:20:36.239182
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    # Test missing required params
    with pytest.raises(AnsibleError) as excinfo:
        variable_manager.get_vars()
    assert "argument 'play' is required" in str(excinfo.value)
    with pytest.raises(AnsibleError) as excinfo:
        variable_manager.get_vars(play=Play())
    assert "argument 'host' is required" in str(excinfo.value)
    with pytest.raises(AnsibleError) as excinfo:
        variable_manager.get_vars(play=Play(), host=Host())
    assert "argument 'task' is required" in str(excinfo.value)
    # Test if param play is not an instance of Play

# Generated at 2022-06-25 14:20:43.907742
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test the case when play is None and host is not None.
    # Test the case when play is not None and host is not None.
    # Test the case when play is not None and host is None.
    # Test the case when play is None and host is None.

    # Test the case when play is None and host is not None.
    _loader = DataLoader()
    _inventory = Inventory(_loader, host_list="localhost")
    _play_context = PlayContext(play=None)
    _variable_manager = VariableManager(loader=_loader, inventory=_inventory)
    _variable_manager.get_vars(play=None, host=_inventory.get_host('localhost'), task=None)

    # Test the case when play is not None and host is not None.

# Generated at 2022-06-25 14:20:51.856024
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    host_0 = Host('localhost')
    get_vars_1 = variable_manager_0.get_vars(host=host_0)

    # test assertion of AnsibleAssertionError: 
    #   get_vars should return a dictionary of variables to use
    from ansible.errors import AnsibleAssertionError
    try:
        assert type(get_vars_1) is not dict
    except AssertionError:
        raise AssertionError(AnsibleAssertionError)

if __name__ == "__main__":
    test_VariableManager_get_vars()

# Generated at 2022-06-25 14:21:01.335023
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.load_extra_vars(dict())
    variable_manager_0.set_inventory(inventory=None)
    variable_manager_0.extra_vars = dict()
    variable_manager_0.play_context = PlayContext(vault_password=None)
    variable_manager_0.options_vars = dict()
    variable_manager_0.options = Options(connection='ssh', module_path='/Users/ds/.ansible/roles/ansible-swiftclient/library', forks=5, become=None, become_method=None, become_user=None, check=False, private_key_file=None, listhosts=None, listtasks=None, listtags=None, syntax=None, diff=False, tags=[])
    variable_

# Generated at 2022-06-25 14:21:10.465222
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    if not os.path.exists(HOST_FILE):
        return
    variable_manager_1 = VariableManager()
    # Test 1
    variable_manager_1.add_host_filter(HOST_FILE)
    variables = variable_manager_1.get_vars(host=Host())
    assert variables['groups'] == {'ungrouped': [u'local', u'xt1032']}
    assert variables['inventory_dir']
    assert variables['inventory_dirname']
    assert variables['inventory_file'] == HOST_FILE
    assert variables['inventory_filename'] == os.path.basename(HOST_FILE)
    assert variables['inventory_hostname']
    assert variables['inventory_hostname_short']
    assert variables['omit']
    assert variables['play_hosts'] == [u'local']

# Generated at 2022-06-25 14:22:04.696918
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    host_0 = Host(name='localhost', port=None)
    assert(isinstance(variable_manager_0.get_vars(host=host_0, include_hostvars=False)['ansible_facts'], MutableMapping))
    variable_manager_0.set_nonpersistent_facts(host_0, {'test_var':'test_val'})
    assert(variable_manager_0.get_vars(host=host_0, include_hostvars=False)['ansible_facts']['test_var'] == 'test_val')


# Generated at 2022-06-25 14:22:10.702733
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    variable_manager_1.set_inventory(_inventory_get_vars)
    variable_manager_1.set_host_variable("localhost", "test-var-1", "test-var-value-1")
    # test with no hosts
    vars_1 = variable_manager_1.get_vars(host=None, include_hostvars=False)
    assert "test-var-1" not in vars_1.keys()
    assert "test-var-2" in vars_1.keys()
    assert "test-var-3" in vars_1.keys()
    assert "test-var-4" in vars_1.keys()
    # test with host, and include_hostvars=True

# Generated at 2022-06-25 14:22:20.095833
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    # 1.
    host_0 = Host('0.0.0.0')
    variable_manager_1.set_host_variable(host_0, 'ansible_connection', 'local')
    variable_manager_1.set_host_variable(host_0, 'ansible_python_interpreter', '/usr/bin/python')
    variable_manager_1.set_host_facts(host_0, {'ansible_python_version': '2.7.15'})
    variable_manager_1.set_host_facts(host_0, {'ansible_device_links': {'test': {'test': 'test'}}})

# Generated at 2022-06-25 14:22:30.837246
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()

    host_0 = Host('host_0')
    host_0.vars = dict((('var', "''"),))

    result = variable_manager_0.get_vars(host=host_0)


# Generated at 2022-06-25 14:22:34.751749
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    host_0 = None
    facts_0 = {}
    variable_manager_0.set_nonpersistent_facts(host_0, facts_0)
    return


# Generated at 2022-06-25 14:22:42.145488
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    host_1 = Host(name='host_0')
    host_1.vars = dict()
    host_1.vars['ansible_connection'] = 'local'
    host_1.vars['ansible_user'] = os.environ['USER']
    host_1.vars['ansible_python_interpreter'] = sys.executable
    host_1_1 = Host(name='host_0')
    host_1_1.vars = dict()
    host_1_1.vars['ansible_connection'] = 'local'
    host_1_1.vars['ansible_user'] = os.environ['USER']
    host_1_1.vars['ansible_python_interpreter'] = sys.executable
    variable

# Generated at 2022-06-25 14:22:44.075484
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    (a1,b1) = (10,20)
    a2 = {'a':a1 , 'b':b1}
    variable_manager_1 = VariableManager()
    variable_manager_1.set_nonpersistent_facts(a1,a2)


# Generated at 2022-06-25 14:22:46.474762
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''
    Test to verify VariableManager constructor
    '''

    variable_manager_0 = VariableManager()
    assert isinstance(variable_manager_0, VariableManager)



# Generated at 2022-06-25 14:22:54.234925
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # dummy object for host
    host = DummyClass()

    # create an inventory file
    hosts = "localhost"
    group  = "foo"
    group_vars = {"group_var_1": "group_value_1"}
    host_vars = {"host_var_1": "host_value_1"}
    inventory = Inventory(loader=DictDataLoader(dict(host_list=[hosts], group_list=[group],
                                                        group_vars_list=[group_vars], host_vars_list=[host_vars])))

    # create a variable manager
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # create a play
    play_name = "test-play"
    play_hosts = ["localhost"]

# Generated at 2022-06-25 14:23:05.086921
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # Create a VariableManager object
    variable_manager_1 = VariableManager()

    # Test the default value of class attribute _vars_cache
    assert variable_manager_1._vars_cache == dict()

    # Test the default value of class attribute _fact_cache
    assert variable_manager_1._fact_cache == dict()

    # Test the default value of class attribute _nonpersistent_fact_cache
    assert variable_manager_1._nonpersistent_fact_cache == dict()

    # Test the default value of class attribute _loader
    assert variable_manager_1._loader == None

    # Test the default value of class attribute _inventory
    assert variable_manager_1._inventory == None

    # Test the default value of class attribute _options_vars
    assert variable_manager_1._options_vars == dict()

    # Test the

# Generated at 2022-06-25 14:23:59.287940
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    host = 'test_host'
    facts = {'some_fact': 'some_value'}
    variable_manager_0 = VariableManager()
    variable_manager_0.set_nonpersistent_facts(host, facts)
    expected_result = {host: {'some_fact': 'some_value'}}
    assert(variable_manager_0._nonpersistent_fact_cache == expected_result)


# Generated at 2022-06-25 14:24:09.111021
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    _host = namedtuple('_host', ('name', 'vars'))
    _play = namedtuple('_play', ('vars_prompt', 'vars_files', 'tasks'))
    _task = namedtuple('_task', ('vars_prompt', 'vars_files', 'loop', 'loop_with'))

    # Test of get_vars for _host = None, _task = None
    variable_manager = VariableManager()
    variables = variable_manager.get_vars(host=None, task=None)
    assert variables == {}

    # Test of get_vars for _host = namedtuple, _task = None
    variable_manager = VariableManager()

# Generated at 2022-06-25 14:24:19.002429
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_nonpersistent_facts('test_host', {"ansible_test_variable0": "test_value_0"})
    variable_manager_0.set_host_variable('test_host', 'test_variable', "test_value")
    variable_manager_0.set_host_facts('test_host', {"ansible_test_variable1": "test_value_1"})

    variable_manager_0.extra_vars = {"ansible_test_variable2": "test_value_2"}

    variable_manager_0.set_host_variable('test_host', 'test_variable_0', "test_value_0")

# Generated at 2022-06-25 14:24:24.630578
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    variable_manager_1.extra_vars = dict()
    variable_manager_1.set_inventory(Inventory("") )

    # Test for zero argument
    variable_manager_1.get_vars()

    variable_manager_2 = VariableManager()
    variable_manager_2.extra_vars = dict()
    variable_manager_2.set_inventory(Inventory("") )

    # Test for one argument
    variable_manager_2.get_vars( _hostvars=dict() )

    variable_manager_3 = VariableManager()
    variable_manager_3.extra_vars = dict()
    variable_manager_3.set_inventory(Inventory("") )

    # Test for two argument

# Generated at 2022-06-25 14:24:32.949189
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    set_hostvars = {'webservers': {'inventory_hostname': 'web1', 'ansible_ssh_host': '192.168.1.1'},
                    'dbservers': {'inventory_hostname': 'db1', 'ansible_ssh_host': '192.168.1.2'},
                    'all': {'ansible_connection': 'local'}}
    set_hostvars['webservers']['group_names'] = ['webservers']
    set_hostvars['dbservers']['group_names'] = ['dbservers']
    set_hostvars['all']['group_names'] = []
    set_host = Host(name='web1')

# Generated at 2022-06-25 14:24:33.798400
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    test_case_0()


# Generated at 2022-06-25 14:24:38.568957
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    host_0 = 'host_0'
    facts_0 = dict()
    variable_manager_0.set_nonpersistent_facts(host_0, facts_0)


# Generated at 2022-06-25 14:24:48.763221
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    host_0 = Host('test0')
    #  set host facts
    host_facts = dict()
    host_facts['server_id'] = 'ser1'
    host_facts['mem_total'] = 8589934592
    host_0.set_host_facts(host_facts)
    variables_0 = {'ansible_play_hosts': ['test1', 'test2']}
    #  test with the fields store the all info of host_0
    result_0 = variable_manager_0.get_vars(host=host_0)

# Generated at 2022-06-25 14:24:56.259972
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager = VariableManager()
    host = "my_host"
    facts = {"fact1": "value1", "fact2": "value2"}

    variable_manager.set_host_facts(host, facts)
    facts_from_cache = variable_manager.get_facts(host)
    assert facts == facts_from_cache

    facts = {"fact3": "value3"}
    variable_manager.set_host_facts(host, facts)
    facts_from_cache = variable_manager.get_facts(host)
    assert facts == facts_from_cache

    import os
    import tempfile
    tempdir = tempfile.TemporaryDirectory()
    fact_cache_directory = os.path.join(tempdir.name, 'fact_cache_1')

# Generated at 2022-06-25 14:25:01.051529
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():

    variable_manager_1 = VariableManager()
    variable_manager_1.set_nonpersistent_facts("test_host", {'test_variable': 'test_value'})
    assert variable_manager_1._nonpersistent_fact_cache["test_host"]['test_variable'] == 'test_value'
