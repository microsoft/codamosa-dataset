

# Generated at 2022-06-25 14:16:23.431098
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Setup
    variable_manager_0 = VariableManager()

    # Testing
    variable_manager_0.get_vars()


# Generated at 2022-06-25 14:16:24.580271
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variableManager = VariableManager()
    assert variableManager.get_vars() == variableManager._extra_vars


# Generated at 2022-06-25 14:16:33.607187
# Unit test for constructor of class VariableManager
def test_VariableManager():
    vars_with_sources_0 = VarsWithSources()
    variable_manager_0 = VariableManager()
    assert variable_manager_0.vars is not None
    assert variable_manager_0.vars_cache is not None
    assert variable_manager_0.vars_plugins is not None
    assert variable_manager_0.default_vars is None
    assert variable_manager_0.play_context is None
    assert variable_manager_0.extra_vars is None
    assert variable_manager_0.second_pass_vars is None
    assert variable_manager_0.hostvars is None
    assert variable_manager_0._fact_cache is None
    assert variable_manager_0._nonpersistent_fact_cache is None
    assert variable_manager_0._delegated_vars is None
   

# Generated at 2022-06-25 14:16:44.550422
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vars_with_sources_1 = VarsWithSources()
    vars_with_sources_1.set_host_variable(host = 'host1', varname = 'host_vars_var1', value = 'host_vars_var1_value')
    vars_with_sources_1.set_host_variable(host = 'host1', varname = 'host_vars_var1', value = 'Modified_host_vars_var1_value')
    vars_with_sources_1.set_host_variable(host = 'host1', varname = 'host_vars_var2', value = 'host_vars_var2_value')

# Generated at 2022-06-25 14:16:51.360310
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    vars_with_sources_0 = VarsWithSources({'a': 1})
    vars_with_sources_0.sources = {'a': 'test_VarsWithSources_getitem'}
    vars_with_sources_0.data = {'a': 1}
    # Run getitem
    a = vars_with_sources_0.__getitem__('a')
    assert a == 1


# Generated at 2022-06-25 14:17:01.721385
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vars_with_sources_0 = VarsWithSources()
    vars_with_sources_1 = VarsWithSources()
    vars_with_sources_2 = VarsWithSources()
    vars_with_sources_3 = VarsWithSources()
    vars_with_sources_4 = VarsWithSources()
    vars_with_sources_5 = VarsWithSources()
    vars_with_sources_6 = VarsWithSources()
    vars_with_sources_7 = VarsWithSources()
    vars_with_sources_8 = VarsWithSources()
    vars_with_sources_9 = VarsWithSources()
    vars_with_sources_10 = VarsWithSources()

# Generated at 2022-06-25 14:17:08.868904
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.inventory import MockInventory
    from units.mock.options import MockOptions
    from units.mock.executor import MockTaskExecutor

    fake_loader = DictDataLoader({})

    # Set up a test inventory, options, loader and a task executor
    mock_inventory = MockInventory(loader=fake_loader)
    mock_options = MockOptions(connection='local', forks=10, become=False,
                               become_method=None, become_user=None, check=False,
                               diff=False, listhosts=None, module_path=None,
                               remote_user='test', verbosity=3)
    mock_executor = MockTask

# Generated at 2022-06-25 14:17:17.657324
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-25 14:17:28.578611
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from collections import namedtuple

# Generated at 2022-06-25 14:17:38.692983
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # even though we don't have a host or task, we still need to mock vars from other sources
    # so that code which constructs the dict doesn't fail
    loader = DictDataLoader(dict())

    my_dict = dict()
    my_dict['hostvars'] = dict()
    my_dict['ansible_play_hosts_all'] = []
    my_dict['ansible_play_hosts'] = []

    my_dict['groups'] = dict()
    my_dict['role_names'] = []
    my_dict['ansible_role_names'] = []
    my_dict['ansible_play_role_names'] = []

    my_dict['omit'] = '__omit_place_holder__'

    my_dict['ansible_play_batch'] = []

# Generated at 2022-06-25 14:18:14.623430
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Set up the variables to input in the method.
    host = 'foobar'
    facts = {'apache': {'port': '80'}}
    if facts == facts:
        print("Test Case 0 Passed")
    else:
        print("Test Case 0 Failed")

if __name__ == '__main__':
    test_VariableManager_set_nonpersistent_facts()

# Generated at 2022-06-25 14:18:25.405301
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    #####################################################################
    # Test Setup
    #####################################################################
    class Play(object):
        def __init__(self):
            pass

    class Role(object):
        def __init__(self, fqcn):
            self.fqcn = fqcn
            self.name = fqcn.split(':')[-1]

        def get_name(self, include_role_fqcn=True):
            return self.fqcn if include_role_fqcn else self.name

    class Task(object):
        def __init__(self, role):
            self._role = role

    class Host(object):
        def __init__(self, name, vars=None):
            self.name = name
            self.vars = vars


# Generated at 2022-06-25 14:18:34.389752
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    VariableManager: get_vars
    '''
    host_0 = Host('host_0')
    hostvars = {}
    play_0 = Play()
    task_0 = Task()
    inventory_hostname = 'inventory_hostname'
    include_hostvars = True

    variable_manager_0 = VariableManager()
    vars_0 = variable_manager_0.get_vars(play=play_0, host=host_0, task=task_0, include_hostvars=include_hostvars)


# Generated at 2022-06-25 14:18:38.068693
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():

    ####
    # Test setup
    from ansible.vars.manager import VariableManager
    variables = VariableManager()


    ####
    # Test execution
    result = variables.__getitem__({})

    ####
    # Test verification
    assert result is None



# Generated at 2022-06-25 14:18:39.376481
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    assert VariableManager.set_host_variable('test_VariableManager_set_host_variable') == None

# Generated at 2022-06-25 14:18:41.855696
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    result_1 = variable_manager_1.get_vars()
    assert result_1 != None


# Generated at 2022-06-25 14:18:47.778168
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager_0 = VariableManager()
    facts = dict()
    host = "192.168.0.0"

    # Execute method
    variable_manager_0.set_host_facts(host, facts)

    # Assert with method get_host_variables
    facts = variable_manager_0.get_host_variables(host)
    assert_that(facts, is_not(empty()))


# Generated at 2022-06-25 14:18:58.772609
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # tests loading variables from inventory and setting ansible_play_hosts
    # and ansible_play_batch
    inventory = InventoryManager(loader=Loader())
    inventory.add_host(Host('dummy'))

    variable_manager_1 = VariableManager(host_list=inventory.hosts, inventory=inventory)

    # Set a few vars
    variable_manager_1._vars_cache = {
        'dummy': {
            'foo': 'bar',
            'empty_val': '',
        },
    }
    # Set a few fact_cache
    variable_manager_1._fact_cache = {
        'dummy': {
            'fact_foo': 'fact_bar',
            'empty_val': '',
        },
    }

    # Set a few nonpersistent_fact_cache
    variable

# Generated at 2022-06-25 14:19:06.411034
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    inventory = Inventory("examples/hosts.ini")
    variable_manager = VariableManager()
    play = Play()
    play.inventory = inventory
    play.roles = []
    play.name = "TEST"
    play.hosts = "all"
    play._hosts_cache = inventory.get_hosts()
    play._dependency_manager = DependencyManager()
    play._variable_manager = variable_manager
    task = Task()
    task.action = "dummy"
    task.play = play
    task.task_vars = dict()
    task.loop_control = {'loop_var':'item'}
    task._role = None
    task._ds = dict()
    task.loop = None
    task.delegate_to = None
    task.raw_arguments = None

   

# Generated at 2022-06-25 14:19:09.061328
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.get_vars()


# Generated at 2022-06-25 14:20:21.742414
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_test1 = VariableManager()
    variable_manager_test1.extra_vars = dict(test_extra_var="test_extra_var_value")
    variable_manager_test1.options_vars = dict(test_options_vars="test_options_vars_value")
    variable_manager_test1.set_host_variable("test_hostname", "test_variable_name", "test_variable_value")
    variable_manager_test1.set_host_facts("test_hostname", "test_fact_value")
    variable_manager_test1.set_nonpersistent_facts("test_hostname", "test_nonpersistent_fact_value")
    variable_manager_test1.set_host_facts("test_hostname", "test_fact_value")
    vars_

# Generated at 2022-06-25 14:20:29.834191
# Unit test for method set_host_variable of class VariableManager

# Generated at 2022-06-25 14:20:32.164037
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():

    variable_manager_0 = VariableManager()

    variable_manager_0.set_host_variable('localhost', 'abc', 'abc')


# Generated at 2022-06-25 14:20:33.961565
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.get_vars()


# Generated at 2022-06-25 14:20:43.056931
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # test class type coverage
    variable_manager_0 = VariableManager()
    var_getvars_0 = get_vars(variable_manager_0)
    # test ABC type coverage
    variable_manager_1 = VariableManager()
    var_getvars_1 = get_vars(variable_manager_1)
    # test dict type coverage
    variable_manager_2 = VariableManager()
    with pytest.raises(KeyError):
        var_getvars_2 = get_vars(variable_manager_2)
    # test dict type coverage
    variable_manager_3 = VariableManager()
    with pytest.raises(KeyError):
        var_getvars_3 = get_vars(variable_manager_3)


# Generated at 2022-06-25 14:20:45.758710
# Unit test for constructor of class VariableManager
def test_VariableManager():
    try:
        variable_manager_0 = VariableManager()
    except:
        pass
    else:
        assert False



# Test that the a host has at least the variables declared in the base_class

# Generated at 2022-06-25 14:20:48.424751
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_nonpersistent_facts("host_0","facts_0")


# Generated at 2022-06-25 14:20:58.030750
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    target_1 = variable_manager_1.get_vars('target_1')
    assert(target_1 == {'ansible_version': {'full': '2.1.0.0', 'major': 2, 'minor': 1, 'revision': 0, 'string': '2.1.0.0'}, 'groups': {}, 'omit': u'__omit_place_holder__'})
    target_2 = variable_manager_1.get_vars('target_2')

# Generated at 2022-06-25 14:21:07.669273
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Parameters
    play=DummyClass()
    host=DummyClass()
    task=DummyClass()
    args={}
    include_delegate_to=True
    include_hostvars=True
    # Passing a number
    play.hosts = "all"
    play.finalized = False
    play.get_name = DummyClass()
    play.get_name.return_value = "test_play_name"
    play.roles = [DummyClass()]
    play.roles[0].get_name = DummyClass()
    play.roles[0].get_name.return_value = "test_role_name"
    play.roles[0]._role_name = "role_name"
    host.name = "test_host_name"
    # host.get_

# Generated at 2022-06-25 14:21:08.524274
# Unit test for constructor of class VariableManager
def test_VariableManager():
    test_case_0()
    return True


# Generated at 2022-06-25 14:22:07.864297
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-25 14:22:14.123533
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()
    host_0 = 'h0'
    varname_0 = 'v0'
    value_0 = 'v0'
    variable_manager_0.set_host_variable(host_0, varname_0, value_0)


# Generated at 2022-06-25 14:22:21.685387
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # TODO: add assertion
    variable_manager_0 = VariableManager()
    host_0 = None
    play_0 = None
    task_0 = None
    variables_0 = None
    include_delegate_to_0 = True
    include_hostvars_0 = True
    include_fact_cache_0 = True
    fact_cache_expiration_0 = 3600
    include_nonpersistent_0 = False
    from ansible.parsing.dataloader import DataLoader
    loader_0 = DataLoader()
    variable_manager_0 = VariableManager(loader=loader_0, inventory=None)
    host_1 = Host(name='localhost', port=None, vars=None)
    variable_manager_0 = VariableManager()

# Generated at 2022-06-25 14:22:23.564914
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager_0 = VariableManager()
    variable_manager_0.__init__()


# Generated at 2022-06-25 14:22:35.195964
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0.extra_vars = { 'ansible_verbosity': 3, 'ansible_check_mode': False, 'ansible_inventory_sources': [ '/etc/ansible/hosts', '/etc/ansible/hosts'], 'ansible_host_pattern': '*'}
    variable_manager_0.options_vars = { 'verbosity': 3, 'check': False, 'inventory': [ '/etc/ansible/hosts', '/etc/ansible/hosts'], 'host_pattern': '*'}

# Generated at 2022-06-25 14:22:46.628562
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager(loader=None, inventory=None, version_info=None, any_vars=False)
    play = Play()
    host = Host(name='kvjb')
    task = Task()
    include_hostvars = True
    include_delegate_to = True

# Generated at 2022-06-25 14:22:50.201742
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    test_host = "test_host"
    test_varname = "test_varname"
    test_value = "test_value"
    variable_manager.set_host_variable(test_host, test_varname, test_value)


# Generated at 2022-06-25 14:22:52.587541
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager_0 = VariableManager()

    variable_manager_0.set_host_variable("host_name", "var_name", "value")


# Generated at 2022-06-25 14:22:54.662008
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()

    # return a list
    result = variable_manager_1.get_vars()
    assert result is not None


if __name__ == "__main__":
    test_VariableManager_get_vars()

# Generated at 2022-06-25 14:23:05.624370
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()

    variable_manager_0.set_nonpersistent_facts(host='localhost', facts={'ansible_python_interpreter': '/usr/bin/python'})
    variable_manager_0.set_host_variable(host='localhost', varname='/home/kevin/Hostname', value=dict())
    variable_manager_0.set_host_facts(host='localhost', facts=dict())
    variable_manager_0.set_host_variable(host='localhost', varname='/home/kevin/Hostname', value=dict())
    facts_0 = {'ansible_python_interpreter': '/usr/bin/python', 'ansible_python_version': '2.7.6'}

# Generated at 2022-06-25 14:24:08.994833
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_1 = VariableManager()
    variable_manager_1.add_play_block_vars_files(play_block=None)
    variable_manager_1.add_play_block_vars_files(play_block=None)
    variable_manager_1.add_play_block_vars_files(play_block=None)
    variable_manager_1.add_play_block_vars_files(play_block=None)
    variable_manager_1.add_play_block_vars_files(play_block=None)
    variable_manager_1.add_play_block_vars_files(play_block=None)
    variable_manager_1.add_play_block_vars_files(play_block=None)
    variable_manager_1.add_play_block_

# Generated at 2022-06-25 14:24:18.875915
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    variable_manager_0._inventory = ansible.parsing.dataloader.DataLoader()

    variable_manager_0._vars_plugins = [{'path': 'setup.ps1', 'name': 'windows', '_has_run': True, '_has_run_once': True, '_loaded': True, '_failed': False, '_host_filters': [], '_play_filters': [], '_task_filters': [], '_role_filters': []}]
    variable_manager_0._nonpersistent_fact_cache = {}
    variable_manager_0._fact_cache = {}
    variable_manager_0._vars_cache = {}
    variable_manager_0._omit_token = '__omit_place_holder__'

# Generated at 2022-06-25 14:24:21.309564
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager_0 = VariableManager()
    variable_manager_0.set_nonpersistent_facts(host='test_host', facts=None)


# Generated at 2022-06-25 14:24:23.831478
# Unit test for constructor of class VariableManager
def test_VariableManager():
    global variable_manager_0
    variable_manager_0 = VariableManager()

test_VariableManager()

# Generated at 2022-06-25 14:24:32.334473
# Unit test for constructor of class VariableManager
def test_VariableManager():

    variable_manager_0 = VariableManager()
    variable_manager_1 = VariableManager()

    # Inject vars
    variable_manager_0.extra_vars = { 'a': '1' }
    variable_manager_1.extra_vars = { 'a': '2' }

    # Inject inventory
    inventory = InventoryManager(loader=DataLoader())
    inventory.add_host('host_0')
    inventory.add_host('host_1')
    variable_manager_0.set_inventory(inventory)
    variable_manager_1.set_inventory(inventory)

    # Test variables for a non-existing host
    host_0_vars = variable_manager_0.get_vars(host=Host('non-existing'))
    host_1_vars = variable_manager_1.get_vars

# Generated at 2022-06-25 14:24:42.947566
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    with patch.object(VariableManager, '_get_delegated_vars', return_value=(dict(), None)):
        # Test if it returns a dict when _get_delegated_vars is mocked and doesn't raise any exception
        variable_manager_1 = VariableManager()
        assert isinstance(variable_manager_1.get_vars(), dict)

        # Test if it raises an exception when _inventory is None, with a
        # specific "inventory is None" message
        variable_manager_2 = VariableManager()
        variable_manager_2._inventory = None
        with pytest.raises(AnsibleError, match="Unable to find inventory for hosts"):
            variable_manager_2.get_vars()

        # Test if it raises an exception when _loader is None, with a
        # specific "loader is None"

# Generated at 2022-06-25 14:24:52.751851
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()

    # Testing default values and the case where no host is provided.
    vars = variable_manager.get_vars()
    assert vars['omit'] == variable_manager._omit_token

    # Testing the case where host is provided.
    vars = variable_manager.get_vars(host=Host('test2'))
    assert 'ansible_play_hosts_all' in vars
    assert vars['omit'] == variable_manager._omit_token

    # Testing the case where some variables have been set.
    variable_manager._fact_cache['test'] = {'fact1': 'value1'}
    vars = variable_manager.get_vars(host=Host('test'))
    assert 'fact1' in vars


# Generated at 2022-06-25 14:25:01.740845
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    inventory_0 = Inventory(loader=None, variable_manager=variable_manager_0, host_list= ('localhost', ))
    variable_manager_0.add_inventory(inventory_0)
    variable_manager_0.set_inventory(inventory_0)
    variable_manager_0.set_hostvars_from_inventory(inventory_0)
    variable_manager_0.set_host_variable(host='localhost', varname='inventory_hostname', value='localhost')
    variable_manager_0.set_host_variable(host='localhost', varname='ansible_all_ipv4_addresses', value=['127.0.0.1'])

# Generated at 2022-06-25 14:25:11.323827
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager_0 = VariableManager()
    host_0 = Host(name='localhost')
    play_1 = Play()
    task_1 = Task()

    # Set of parameters to test
    include_hostvars = True
    include_delegate_to = True

    # Test call to the function
    try:
        variable_manager_0.get_vars(host=host_0, task=task_1, play=play_1, include_hostvars=include_hostvars, include_delegate_to=include_delegate_to)
    except Exception as e:
        raise Exception("Call to method 'get_vars' of class VariableManager threw unexpected error")



# Generated at 2022-06-25 14:25:20.350346
# Unit test for method get_vars of class VariableManager