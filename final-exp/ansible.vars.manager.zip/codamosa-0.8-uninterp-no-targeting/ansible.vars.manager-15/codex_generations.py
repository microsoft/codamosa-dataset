

# Generated at 2022-06-21 09:38:59.419494
# Unit test for function preprocess_vars
def test_preprocess_vars():
    test_vars = [{'k1' : 'v1'}]
    assert preprocess_vars(test_vars) == test_vars

_FEATURES = ('command', 'shell', 'win_shell', 'powershell', 'raw',
             'script', 'win_command', 'win_package')


# Generated at 2022-06-21 09:39:09.346897
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    # Create an instance of VarsWithSources with empty dicts
    Vars = VarsWithSources()
    # Assert that dicts are empty
    assert Vars.data == {} and Vars.sources == {}
    # Assert default value of __setitem__
    assert Vars.data == {} and Vars.sources == {}
    # Set dict Vars.data with name "ansible", and dict Vars.sources with name "ansible"
    Vars["ansible"] = "awesome"
    # Assert that dicts have been set with name "ansible"
    assert Vars.data == {"ansible": "awesome"} and Vars.sources == {"ansible": None}
    # Assert default value of __setitem__

# Generated at 2022-06-21 09:39:21.993044
# Unit test for constructor of class VariableManager
def test_VariableManager():
    path = 'lib/ansible/playbook/test_data/vardata'

    v = VariableManager()

    # set inventory
    i = InventoryManager(loader=DataLoader(), sources=[path + '/inventory'])
    v._set_inventory(i)

    vars_files = [path + '/varsfile']
    # set vars_files
    for vars_file in vars_files:
        v.extra_vars.update(v.vars_from_file(vars_file))

    # add vars_file
    v.add_vars_file(path + '/varsfile2')

    # get fact_cache
    assert isinstance(v._fact_cache, dict)

    # get vars_cache
    assert isinstance(v._vars_cache, dict)

    # get cache


# Generated at 2022-06-21 09:39:30.854579
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    # Arrange
    # - Create a test function

    facts = dict()

    # - Create a class that can be used to create mock objects.
    class Mock(object):

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        @classmethod
        def __getattr__(cls, name):
            return Mock()

    class mock_MutableMapping:

        def __init__(self):
            pass

        def update(self, facts):
            facts.update(facts)

    # - replace the dictionary that is used to store the fact cache
    #   with a Mock(), which is a class that can be used to create mock objects.
    cache_mock = Mock()
    cache_mock.__setitem__.return_value = None
    cache_mock.__

# Generated at 2022-06-21 09:39:39.115678
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    variable_manager = VariableManager()
    assert(variable_manager.__getstate__() == {'fact_cache': {}, 'extra_vars': {}, 'hostvars': {}, 'loader': None, 'nonpersistent_fact_cache': {}, 'options_vars': {}, 'variable_manager': None, 'vars_cache': {}, 'vars_plugins': [], '_omit_token': '__omit_place_holder__'})
    assert(variable_manager.get_vars() == {})


# Generated at 2022-06-21 09:39:42.905795
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    source_list = ['a', 'b', 'c']
    v = VarsWithSources({'a': 1, 'b': 2, 'c': 3})
    v.sources = {k: 'test' for k in source_list}
    for k in source_list:
        assert v[k] == v.data[k]

# Generated at 2022-06-21 09:39:45.964040
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    variable_manager = VariableManager()
    variable_manager.set_host_facts('test', {})
    assert variable_manager._fact_cache['test']
    variable_manager.clear_facts('test')
    assert variable_manager._fact_cache.get('test') is None


# Generated at 2022-06-21 09:39:51.687777
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    '''
    method get_source of class VarsWithSources

    returns VarsWithSources.sources[key] or None
    '''
    sources = {'a': 1, 'b': 2, 'c': 3}
    vws = VarsWithSources({'a': 2, 'c': 3, 'd': 4}, sources)
    assert vws.get_source('d') is None
    assert vws.get_source('a') is 1
    assert vws.get_source('b') is 2
    assert vws.get_source('c') is 3


# Generated at 2022-06-21 09:40:05.082477
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    d = {'a': 1, 'b': 2}
    vws = VarsWithSources(d)
    vws.sources = {'a': 'file'}
    vws2 = VarsWithSources.new_vars_with_sources(d, {'a': 'file'})
    assert vws == vws2
    assert vws.sources == vws2.sources
    assert vws.get_source('a') == vws2.get_source('a')
    assert vws.get_source('b') == vws2.get_source('b')

    vws3 = vws.copy()
    assert vws == vws3
    assert vws.sources == vws3.sources

# Generated at 2022-06-21 09:40:08.621704
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    '''
    Unit test for method __setstate__ of class VariableManager
    '''
    obj = VariableManager()
    obj.__setstate__()




# Generated at 2022-06-21 09:40:33.437954
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    dict = VarsWithSources({'key1': 'value1', 'key2': 'value2'})
    assert len(dict) == 2



# Generated at 2022-06-21 09:40:42.732618
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    variable_manager = VariableManager(loader=DictDataLoader({}), inventory=InventoryManager(loader=None, sources=''))
    variable_manager.set_host_facts("foo", {'a': 1})
    variable_manager.set_host_facts("foo", {'b': 2})
    variable_manager.set_host_facts("bar", {'c': 3})
    assert variable_manager._fact_cache['foo']['a'] == 1
    assert variable_manager._fact_cache['foo']['b'] == 2
    assert variable_manager._fact_cache['bar']['c'] == 3
    assert variable_manager._fact_cache['foo'] == {'a': 1, 'b': 2}
    assert variable_manager._fact_cache['bar'] == {'c': 3}


# Generated at 2022-06-21 09:40:52.193067
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources()
    v.data = {'x': 42, 'y': 99}
    v.sources = {'x': 'foo', 'y': 'bar'}

    assert(v['x'] == 42)
    assert(v.get_source('x') == 'foo')
    assert(v['y'] == 99)
    assert(v.get_source('y') == 'bar')

    try:
        v['unknown']
        assert False, "Expected an exception"
    except KeyError:
        pass
    except:
        assert False, "Expected a KeyError"


# Generated at 2022-06-21 09:40:56.360134
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    obj = VariableManager()
    # 1st test:
    with pytest.raises(AnsibleError):
        obj.get_vars()

    # 2nd test:
    with pytest.raises(AnsibleError):
        obj.get_vars(host=None, play=None)



# Generated at 2022-06-21 09:41:09.457004
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vars_cache={}
    _nonpersistent_fact_cache={}
    _fact_cache={}

    inventory = InventoryManager(loader=None, sources=[])

# Generated at 2022-06-21 09:41:13.256797
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    v = VarsWithSources({'a':1, 'b':2})
    for k in v:
        assert k in ['a', 'b']



# Generated at 2022-06-21 09:41:20.048183
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    # NOTE: automatically generated. DO NOT EDIT MANUALLY
    '''
    Test __setstate__ of VariableManager
    '''
    # Create instances of the class
    obj = VariableManager()
    # Check if the object raises an exception when called
    with pytest.raises(NotImplementedError):
        result = obj.__setstate__()
    # Check with NotImplementedError



# Generated at 2022-06-21 09:41:24.887006
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    v = VarsWithSources({'key1': 'val1', 'key2': 'val2'})
    x = [y for y in v]
    assert x == ['key2', 'key1'], "VarsWithSources failed to iterate properly."


# Generated at 2022-06-21 09:41:29.821663
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    ''' VarsWithSources.__iter__() Unit test'''
    v = VarsWithSources()
    v['a'] = 4
    v['b'] = 5
    v['c'] = 6
    result = list(v.__iter__())
    assert result == ['a', 'b', 'c']



# Generated at 2022-06-21 09:41:36.585029
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    # Set up
    mock_hostname = 'fake_hostname'
    mock_host = {'name': 'fake_host'}
    v = VariableManager()
    v._fact_cache = {'fake_hostname': {'fact': 'fake_fact'}}

    # Run method
    v.clear_facts(mock_hostname)

    # Check results
    # Check method calls
    # Check attributes
    assert dict() == v._fact_cache['fake_hostname']



# Generated at 2022-06-21 09:42:31.320673
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    def _check(obj, key, value, source):
        '''Test that a VarsWithSources object contains a given key/value pair with a given source'''
        assert key in obj
        assert isinstance(obj[key], type(value))
        assert obj[key] == value
        assert isinstance(obj.get_source(key), type(source))
        assert obj.get_source(key) == source

    # Basic functionality test
    v = VarsWithSources(dict(a=1, b=2))
    v.sources = dict(a="foo", b="bar")
    v_copy = v.copy()

    assert isinstance(v_copy, VarsWithSources)
    assert v_copy.data == v.data
    assert v_copy.sources == v.sources

    # Adding to the original does

# Generated at 2022-06-21 09:42:41.971430
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    my_vm = VariableManager()
    my_host = Host(name="localhost")
    my_host.set_variable('ansible_ssh_port', 2222)
    my_host.set_variable('ansible_ssh_host', 'example.org')
    my_play = Play()
    my_play.set_loader(my_vm._loader)
    my_play.set_variable_manager(my_vm)
    my_task = Task()
    my_task.set_loader(my_vm._loader)
    my_task.action = 'setup'

    my_host.set_variable('foo', 'bar')
    my_host.set_variable('ansible_fact', 'baz')

# Generated at 2022-06-21 09:42:54.204690
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    print('Test set_inventory')
    # Set up a variable manager.
    # The variable manager needs an inventory to get variables from.
    # Here we are just hacking in a fake inventory, but we could be
    # filling it with data from a real inventory source.
    # Now create a variable manager, and add the inventory to it.
    vm = VariableManager()
    # Set up a fake inventory with just one host.
    # This is needed to get an inventory object with a get_vars() method.
    fake_inventory = FakeInventory({'all': {'hosts': {'localhost': {
        # Add some variables to the localhost host.
        'ansible_fact_var': 'a fact',
        'var': 'a var'}}}})
    vm.set_inventory(fake_inventory)
    # Add some variables to the manager

# Generated at 2022-06-21 09:43:03.673667
# Unit test for function preprocess_vars
def test_preprocess_vars():
    a = [
        {'a': '1', 'b': '2'},
        {'c': '3', 'd': '4'}
    ]

    # Testing a = None
    assert preprocess_vars(None) == None

    # Testing a = <List of dictionaries>
    assert preprocess_vars(a) == a

    # Testing a = <Dictionary>
    assert preprocess_vars(a[0]) == a

    # Testing a = < value 1 >
    try:
        preprocess_vars('1')
    except AnsibleError as e:
        assert "variable files must contain either a dictionary of variables" in str(e)
        assert "or a list of dictionaries" in str(e)
        assert "Got: '1' (<type 'str'>" in str(e)



# Generated at 2022-06-21 09:43:09.163708
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    #Data
    vars_with_sources_instance = VarsWithSources({"a": 1})
    key = "a"
    value_expected = 1
    #Action
    value_actual = vars_with_sources_instance.__getitem__(key)
    #Assert
    assert value_actual == value_expected, "value_actual (%s) != value_expected (%s) " %(value_actual, value_expected)

# Generated at 2022-06-21 09:43:18.713947
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    _host = 'host_cache'
    _facts = {
        'key': 'value',
    }
    manager = VariableManager()
    manager.set_host_facts(_host, _facts)
    assert _host in manager._fact_cache
    assert manager._fact_cache[_host] == _facts

    _facts2 = {
        'key2': 'value2',
    }
    manager.set_host_facts(_host, _facts2)
    assert len(manager._fact_cache[_host]) == 2
    assert set(manager._fact_cache[_host].keys()) == set(['key', 'key2'])
    assert manager._fact_cache[_host]['key'] == 'value'
    assert manager._fact_cache[_host]['key2'] == 'value2'

# Generated at 2022-06-21 09:43:23.873542
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    vm = VariableManager()
    # Test without raising errors

    sample_host = 'localhost'
    vm.set_host_facts(sample_host, {})
    # Test with raising errors

    with pytest.raises(AnsibleAssertionError):
        vm.set_host_facts(sample_host, 42)
    with pytest.raises(TypeError):
        vm.set_host_facts(sample_host, {'message': 42})

# Generated at 2022-06-21 09:43:24.779880
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    pass


# Generated at 2022-06-21 09:43:29.891175
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'key1': 'val1', 'key2': 'val2'})
    v.sources = {'key1': 'source1', 'key2': 'source2'}
    assert v['key1'] == 'val1', 'Failed to return value for key1'
    assert v['key2'], 'Failed to return value for key2'
    assert v.get_source('key1') == 'source1', 'Failed to return source for key1'
    assert v.get_source('key2') == 'source2', 'Failed to return source for key2'

# Generated at 2022-06-21 09:43:33.514076
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    from collections import MutableMapping
    from units.mock.vars import VariableManager

    x = VariableManager()
    y = VarsWithSources()
    assert isinstance(y, MutableMapping)
    assert len(x) == len(y)


# Generated at 2022-06-21 09:44:27.946602
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    v = VariableManager()
    v.set_host_variable('host1', 'var', 'value')
    v.set_host_variable('host1', 'var', 'new_value')
    v.clear_facts('host1')
    if not 'host1' in v._vars_cache:
        return 'fail'
    else:
        return 'success'

# Generated at 2022-06-21 09:44:30.093145
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    
    v = VariableManager()
    v.set_inventory("some_value")
    assert v._inventory == "some_value"


# Generated at 2022-06-21 09:44:33.677608
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    obj = VarsWithSources({'a': 1, 'b': 2})
    obj['c'] = 3
    assert obj.data['c'] == 3

# Generated at 2022-06-21 09:44:38.074389
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    vari = VarsWithSources()
    vari.data = {'key': 'val'}
    vari.sources = {'key': "source"}
    assert vari['key'] == 'val'
    # Cleaning
    del vari

# Generated at 2022-06-21 09:44:42.044405
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    inventory = Mock()
    variable_manager = VariableManager()

    assert variable_manager._inventory is None
    variable_manager.set_inventory(inventory)
    assert variable_manager._inventory is not None
    assert variable_manager._inventory == inventory

# Generated at 2022-06-21 09:44:48.834925
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    print("##### In method set_host_variable of class VariableManager")
    v = VariableManager()
    vars_cache = {'host1': {'varname': 'value'}}
    v.vars_cache = vars_cache
    varname = 'varname'
    value = {'key': 'val'}
    v.set_host_variable('host1', varname, value)
    print("v.vars_cache: " + str(v.vars_cache))

# Generated at 2022-06-21 09:44:51.976997
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():

    # Create instance of VarsWithSources
    v = VarsWithSources({'a':'b'})

    # Test __iter__
    assert isinstance(v.__iter__(), types.GeneratorType)

# Generated at 2022-06-21 09:45:00.836339
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    # Test the Dict-compatible constructor
    x = VarsWithSources({'a': 'b'}, c='d')
    assert x.__dict__ == {'data': {'a': 'b', 'c': 'd'}, 'sources': {}}

    # Test the alternate constructor method
    y = VarsWithSources.new_vars_with_sources({'e': 'f'}, {'e': 'from_source'})
    assert y.__dict__ == {'data': {'e': 'f'}, 'sources': {'e': 'from_source'}}


# Generated at 2022-06-21 09:45:07.075962
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():

    # Create a mock object of the class
    mock_variable_manager = MagicMock(spec=VariableManager)

    # Mock method __getstate__
    def __getstate__(self):

        return {}

    # Set mocked method return value
    mock_variable_manager.__getstate__.side_effect = __getstate__

    # Call method
    state = mock_variable_manager.__getstate__()

    assert state == {}
    assert mock_variable_manager.__getstate__.call_count == 1



# Generated at 2022-06-21 09:45:14.043325
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v1 = VarsWithSources()
    v1["foo"] = "bar"
    v1.sources["foo"] = "baz"
    assert(v1["foo"] == "bar")
    assert(v1.get_source("foo") == "baz")
    v2 = VarsWithSources()
    v2["foo"] = "bar"
    v2.sources["foo"] = "baz"
    assert(v1 == v2)
    assert(v1["foo"] == v2["foo"])


# Generated at 2022-06-21 09:46:22.101945
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    import random
    facts = {}
    for k, v in [('a', 1), ('b', 2), ('c', 3), ('d', 4)]:
        facts[k] = v
        assert VariableManager.get_fact_cache() == facts
        assert facts == VariableManager.get_fact_cache()
    hostname = random.choice(facts.keys())
    assert VariableManager.clear_facts(hostname) is None
    # clean up leftovers
    VariableManager.clear_facts('localhost')
    assert VariableManager.get_fact_cache() == {}

# Generated at 2022-06-21 09:46:31.529586
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    var_man = VariableManager()
    var_man._vars_cache = dict()
    var_man._nonpersistent_fact_cache = dict()
    var_man._fact_cache = dict()
    host1 = 'host1'
    facts1 = {'var1': 'val1'}
    var_man.set_host_facts(host1, facts1)
    assert var_man._vars_cache == dict()
    assert var_man._nonpersistent_fact_cache == dict()
    assert var_man._fact_cache == {'host1': {'var1': 'val1'}}

    facts2 = {'var2': 'val2'}
    var_man.set_host_facts(host1, facts2)
    assert var_man._vars_cache == dict()
    assert var

# Generated at 2022-06-21 09:46:34.802684
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    # VariableManager,clear_facts(hostname)
    # NOTE: This function is not implemented
    raise NotImplementedError()
    # return True



# Generated at 2022-06-21 09:46:40.239570
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    v = VarsWithSources({'a': '1', 'b': '2'})
    v.sources = {'a': 'a', 'b': 'b'}
    v.__delitem__('b')
    assert v.data == {'a': '1'}
    assert v.sources == {'a': 'a'}

# Generated at 2022-06-21 09:46:47.253822
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    d = VarsWithSources({ 'a': 1, 'b': 2 }, { 'a': 'file', 'b': 'file'})
    assert sorted(d.keys()) == [ 'a', 'b' ]
    assert sorted(d.values()) == [ 1, 2 ]
    assert d.get_source('a') == 'file'
    assert d.get_source('b') == 'file'
    assert d.get_source('c') == None
    assert 'a' in d
    assert 'c' not in d
    assert d['a'] == 1
    assert d['b'] == 2
    try:
        d['c']
    except KeyError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 09:46:56.012777
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    from ansible.inventory.manager import InventoryManager

    # setup test
    inventory = InventoryManager('localhost,')
    host = inventory.get_host('localhost')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # setup data
    facts = dict(a=1, b=2, c=3)

    # test method
    variable_manager.set_host_facts(host, facts)

    # test if results are correct
    assert variable_manager._fact_cache['localhost'] == facts


# Generated at 2022-06-21 09:47:01.430503
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources()
    v["foo"] = 1
    v["bar"] = 2
    v.sources["foo"] = "fake"
    v.sources["bar"] = "test"
    assert (v["foo"] == 1 and v["bar"] == 2 and v.sources["foo"] == "fake" and v.sources["bar"] == "test")

# Generated at 2022-06-21 09:47:11.093699
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    f = VarsWithSources({'key1': 'value1', 'key2': 'value2'})
    f.sources = {'key2': 'cmd line'}
    c = f.copy()
    c['key3'] = 'value3'
    c.sources['key3'] = 'group vars'
    assert f.data == {'key1': 'value1', 'key2': 'value2'}
    assert f.sources == {'key2': 'cmd line'}
    assert c.data == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    assert c.sources == {'key2': 'cmd line', 'key3': 'group vars'}

# Generated at 2022-06-21 09:47:17.047057
# Unit test for function preprocess_vars
def test_preprocess_vars():
    from ansible.vars import preprocess_vars
    assert preprocess_vars(None) is None
    assert preprocess_vars(dict(a=1)) == [ dict(a=1) ]
    assert preprocess_vars([ dict(a=1), dict(b=2) ]) == [ dict(a=1), dict(b=2) ]
    try:
        preprocess_vars("bad")
        assert False
    except AnsibleError:
        pass
    try:
        preprocess_vars([ dict(a=1), "bad" ])
        assert False
    except AnsibleError:
        pass


# Generated at 2022-06-21 09:47:21.062429
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    """Unit test for method VariableManager.set_nonpersistent_facts of class VariableManager.
    """
    vm = VariableManager()
    facts = {'fact1': "value1"}
    host = "test_host"

    vm.set_nonpersistent_facts(host, facts)
    assert vm._nonpersistent_fact_cache[host] == facts