

# Generated at 2022-06-21 09:38:49.848883
# Unit test for function preprocess_vars
def test_preprocess_vars():
    assert preprocess_vars([{}, {}, {}]) == [{}, {}, {}]
    assert preprocess_vars({}) == [{}]
    assert preprocess_vars(None) is None
    assert preprocess_vars([]) == []



# Generated at 2022-06-21 09:38:59.999713
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    mock_loader = DictDataLoader({
        "some_playbook.yaml": """
        - name: play1
          hosts: localhost
          tasks:
          - debug:
              msg: hello world
            vars:
              ansible_network_os: ios
        """})
    mock_loader.set_basedir("some_playbook.yaml")

    inventory = InventoryManager(loader=mock_loader, sources="localhost")

# Generated at 2022-06-21 09:39:01.313884
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    VarsWithSources.__setitem__(VarsWithSources, 'key', 'value')

# Generated at 2022-06-21 09:39:08.934316
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    v = VarsWithSources({"foo":"bar", "bar":"baz"})

    # Not set
    assert v.get_source("not a key") is None

    # Setting to value
    assert v.get_source("foo") is None
    assert v.get_source("bar") is None

    v.sources["foo"] = "file"
    v.sources["bar"] = "vault"

    # Checking for value
    assert v.get_source("foo") == "file"
    assert v.get_source("bar") == "vault"

# Generated at 2022-06-21 09:39:21.404012
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    # Create a temporary file an write to it
    handle, path = tempfile.mkstemp()
    os.close(handle)


# Generated at 2022-06-21 09:39:30.592149
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():

    # set up object
    variable_manager = VariableManager()
    variable_manager._hostvars = None
    variable_manager._inventory = None
    variable_manager._vars_cache = None
    variable_manager._nonpersistent_fact_cache = None
    variable_manager._fact_cache = None
    variable_manager._loader = None

    # set up expected (what I want)

# Generated at 2022-06-21 09:39:33.318003
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    v = VarsWithSources({'a': 1, 'b': 2})
    assert len(v) == 2


# Generated at 2022-06-21 09:39:39.422737
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    data = {'key': 'value'}
    sources = {'key': 'value'}
    v = VarsWithSources.new_vars_with_sources(data, sources)
    v2 = VarsWithSources.new_vars_with_sources(data, sources)
    assert v.copy() == v2  # do not use VarsWithSources.data but VarsWithSources.__eq__

# Generated at 2022-06-21 09:39:47.788902
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    test_inst_obj = VarsWithSources({"key1":"val1", "key2":"val2"})
    test_inst_obj.sources = { "key1":"source1", "key2":"source2" }
    test_inst_obj.__delitem__("key2")
    assert isinstance(test_inst_obj, VarsWithSources)
    assert test_inst_obj.get_source("key1") == "source1"
    assert test_inst_obj.data == {"key1":"val1"}

# Generated at 2022-06-21 09:39:59.815202
# Unit test for method set_nonpersistent_facts of class VariableManager

# Generated at 2022-06-21 09:40:35.503360
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    variable_manager = VariableManager()
    variable_manager.__setstate__(None)


# Generated at 2022-06-21 09:40:38.121382
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    fake_loader = MagicMock()
    fake_inventory = MagicMock(spec=Inventory)
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    fake_variable_manager.clear_facts("hostname")


# Generated at 2022-06-21 09:40:49.828980
# Unit test for function preprocess_vars
def test_preprocess_vars():
    assert preprocess_vars([{'a': 1, 'b': 2}]) == [{'a': 1, 'b': 2}]
    assert preprocess_vars([]) == []
    assert preprocess_vars({'a': 3, 'b': 4}) == [{'a': 3, 'b': 4}]
    assert preprocess_vars(None) is None

    try:
        preprocess_vars(set([1, 2]))
        assert False, "preprocess_vars did not raise an exception when given the wrong type"
    except AnsibleError:
        pass


# Generated at 2022-06-21 09:40:51.877462
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    obj = VariableManager()
    obj.set_host_facts("host", "facts")


# Generated at 2022-06-21 09:40:56.135177
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    vws = VarsWithSources({'a': 1, 'b': 2, 'c': 3})
    vws.sources = {'a': 'a', 'b': 'b', 'c': 'c'}
    assert vws['a'] == 1
    assert vws['b'] == 2
    assert vws['c'] == 3

# Generated at 2022-06-21 09:40:57.961802
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    v = VarsWithSources()
    v['ok'] = 1
    assert('ok' in v)


# Generated at 2022-06-21 09:41:11.045167
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():

    # Test changing the key does not change the result
    play_context_obj = PlayContext()
    obj = VarsWithSources()
    obj['key'] = 'value'
    obj.sources['key'] = 'source'
    display.debug_value = "value"
    result = obj.__getitem__("key")
    if result != 'value' or display.debug_value != 'value':
        raise AssertionError("for VarsWithSources obj: %s, result: %s, debug_value: %s" % (obj, result, display.debug_value))
    result = obj.__getitem__("")

# Generated at 2022-06-21 09:41:13.318639
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
	variable_manager = VariableManager()
	assert variable_manager.__getstate__() == variable_manager._parameters

# Generated at 2022-06-21 09:41:17.412504
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'a': 'b'}, sources={'a': 'c'})
    assert v['a'] == 'b'


# Generated at 2022-06-21 09:41:19.249837
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    vv = VarsWithSources()
    assert vv['a_new_var'] == {}


# Generated at 2022-06-21 09:41:51.674061
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    variable_manager = VariableManager(
        loader=None,
        inventory=None,
    )
    variable_manager._fact_cache = dict(
        key_01='value_01',
        key_02='value_02',
    )
    variable_manager._vars_cache = dict(
        key_01='value_01',
        key_02='value_02',
    )
    variable_manager._hostvars = dict(
        key_01='value_01',
        key_02='value_02',
    )
    variable_manager._nonpersistent_fact_cache = dict(
        key_01='value_01',
        key_02='value_02',
    )

    result = variable_manager.__getstate__()

    assert isinstance(result, dict)

# Generated at 2022-06-21 09:41:53.228944
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    assert False, 'Test Not Implemented'

# Generated at 2022-06-21 09:41:55.668139
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources()
    key = 'sample_key'
    value = 'sample_value'
    v['sample_key'] = value
    assert v[key] == value


# Generated at 2022-06-21 09:42:00.716694
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    s = set()
    s.add("test_value")
    v = VarsWithSources({"test_key": s})
    assert("test_key" in v)
    assert("test_value" not in v)
    assert("test_key" in v.data)
    assert("test_value" in v.data["test_key"])


# Generated at 2022-06-21 09:42:05.639458
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    mock_host = mock.MagicMock()
    mock_facts = mock.MagicMock()
    vm = VariableManager()

    vm.set_nonpersistent_facts(host=mock_host, facts=mock_facts)

    assert mock_host in vm._nonpersistent_fact_cache
    assert vm._nonpersistent_fact_cache[mock_host] == mock_facts

# Generated at 2022-06-21 09:42:08.718331
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    v=VarsWithSources()
    v['a']='b'
    assert v.get_source('a') is None


# Generated at 2022-06-21 09:42:21.940855
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    from collections import MutableMapping
    a = VarsWithSources()
    a['abc'] = 'abc'
    test_cases = [
        {'data': {'abc': 'abc'}, 'pre': False, 'data_key': 'xyz', 'post': True, 'value': 'xyz', 'exp_value': 'xyz'},
        {'data': {'abc': 'abc'}, 'pre': True, 'data_key': 'abc', 'post': True, 'value': 'xyz', 'exp_value': 'xyz'},
        {'data': {'abc': 'abc'}, 'pre': False, 'data_key': 'abc', 'post': True, 'value': 'xyz', 'exp_value': 'xyz'},
    ]

    for test_case in test_cases:
        a

# Generated at 2022-06-21 09:42:28.183451
# Unit test for function preprocess_vars
def test_preprocess_vars():
    '''
    Ensures that preprocess_vars returns consistent results.
    '''
    assert preprocess_vars(None) == None
    assert preprocess_vars({}) == [{}]
    assert preprocess_vars([{}]) == [{}]

    # Test for exception
    try:
        preprocess_vars("not a dict")
    except:
        pass
    else:
        assert False


# Generated at 2022-06-21 09:42:34.249886
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    var_dic = {'test': 1}
    test = VarsWithSources(var_dic)
    test.sources = {'test': 'test source'}
    test_copy = test.copy()
    assert test.data == test_copy.data
    assert test.sources == test_copy.sources
    assert test is not test_copy
    assert test.data is not test_copy.data
    assert test.sources is not test_copy.sources


# Generated at 2022-06-21 09:42:37.796473
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources({"foo": "bar", "baz": "boo"})
    v["new_key"] = "new_value"
    v.pop("baz")
    assert "foo" in v
    assert "baz" not in v
    assert type(v.copy()) is VarsWithSources

# Generated at 2022-06-21 09:43:35.064694
# Unit test for method copy of class VarsWithSources

# Generated at 2022-06-21 09:43:37.467493
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    from nose.tools import assert_true
    v = VarsWithSources({'a': 1})
    assert_true('a' in v)

# Generated at 2022-06-21 09:43:44.314631
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
  vm = ansible.vars.VariableManager()
  vm.set_host_variable('host1', 'contact', {'name': 'foo', 'age': 30})
  vm.set_host_facts('host1', {'name': 'host1', 'age': 30})
  print(vm.get_vars(host=ansible.inventory.host.Host('host1'), include_hostvars=True))


# Generated at 2022-06-21 09:43:46.182203
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources({}, {})
    assert isinstance(v, VarsWithSources)

# Generated at 2022-06-21 09:43:52.676728
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Create a VariableManager object
    obj = VariableManager()
    test_host = 'abc'
    test_varname = 'abc'
    test_value = 'abc'
    assert obj._vars_cache == {}, "Expected empty dict for _vars_cache."
    obj.set_host_variable(test_host, test_varname, test_value)
    assert obj._vars_cache == {test_host: {test_varname: test_value}}, "Expected _vars_cache to be {test_host: {test_varname: test_value}}."
    test_varname = 'abc'
    test_value = {'abc': 'abc'}
    obj.set_host_variable(test_host, test_varname, test_value)
    assert obj._

# Generated at 2022-06-21 09:43:59.042030
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    '''
    Unit test for method __len__ of class VarsWithSources
    '''
    def __len__(_self):
        '''
        __len__()
        '''
        return 0
    class VarsWithSources_class:
        __len__ = __len__
        def __init__(self):
            pass
    vws = VarsWithSources_class()
    assert(vws.__len__() == 0)


# Generated at 2022-06-21 09:44:03.049588
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    host = 'some_host'
    facts = {}

    vm = VariableManager()

    assert not hasattr(vm, '_nonpersistent_fact_cache')

    vm.set_nonpersistent_facts(host, facts)

    assert host in vm._nonpersistent_fact_cache
    assert vm._nonpersistent_fact_cache[host] is facts

# Generated at 2022-06-21 09:44:05.539811
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    '''
    Unit test for method __setstate__ of class VariableManager
    '''

    # test VariableManager.__setstate__

    try:
        # Pickling was not enabled
        VariableManager.__setstate__
        raise AssertionError('VariableManager.__setstate__ was enabled in the class, but we expected it to be absent.')
    except AttributeError:
        pass

# Generated at 2022-06-21 09:44:10.079818
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    v = VarsWithSources({'a':1})
    assert(len(v) == 1)
    v['b'] = 10
    assert(len(v) == 2)
    del v['a']
    assert(len(v) == 1)


# Generated at 2022-06-21 09:44:11.429678
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    pass


# Generated at 2022-06-21 09:44:50.080607
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    run_integration_tests = os.path.isdir("tests/integration")
    if run_integration_tests:
        # skip unit tests in integration test environment
        return

    facts = dict(test_key = "test_value")
    hostname = "test_host"

    # Initialize VariableManager object
    v = VariableManager(loader=None, inventory=None)

    # Test if objects are of the correct type
    assert isinstance(v, VariableManager)

    # Test if function returns None
    assert v.clear_facts(hostname) == None

    # Test if facts in fact_cache have been cleared
    assert hostname not in v._fact_cache
    assert 'test_key' not in v._fact_cache

    # Set the host facts

# Generated at 2022-06-21 09:44:52.517542
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''Unit test the constructor of class VariableManager'''
    variable_manager = VariableManager()
    assert variable_manager.extra_vars is empty



# Generated at 2022-06-21 09:44:55.609124
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    var_name = 'test_variable'
    var_value = 'test_value'
    test_variable = var_name in VarsWithSources({var_name: var_value})
    assert test_variable is True


# Generated at 2022-06-21 09:44:57.687456
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    variable_manager = VariableManager()
    variable_manager.__getstate__()

# Generated at 2022-06-21 09:45:02.007056
# Unit test for constructor of class VariableManager
def test_VariableManager():
    vm = VariableManager()
    assert isinstance(vm._vars_cache, dict)
    assert isinstance(vm._vars_persist, dict)
    assert isinstance(vm._vars_cache['hostvars'], dict)



# Generated at 2022-06-21 09:45:11.335571
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    # We need to instantiate a plugin manager, so that the VarsWithSources can be instantiated
    pm = MockPluginManager()
    # instantiate a VarsWithSources object (we don't care about the underlying data)
    vars_with_sources = VarsWithSources({})
    # check that the __getitem__ method raises KeyError on a non-existing var
    with pytest.raises(KeyError):
        vars_with_sources[X]

    # check that the __getitem__ method raises KeyError on a non-existing var
    with pytest.raises(KeyError):
        vars_with_sources.get_source(X)
    # add some simple vars to the underlying data
    vars_with_sources.data[X] = Y

# Generated at 2022-06-21 09:45:14.397393
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    a = VarsWithSources({"a": "b"})
    assert "a" in a
    # Test that unit test works by asserting on something unlikely to be true in production
    assert "b" not in a



# Generated at 2022-06-21 09:45:17.121164
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    v1 = VarsWithSources({"a":"b"})
    v2 = v1.copy()
    v1["a"] = "c"
    assert v2["a"] == "b"


# Generated at 2022-06-21 09:45:21.907208
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    # Initialize the class
    v = VarsWithSources({'a': 'b', 'c': 'd'})
    v.sources = {'a': 'source_a', 'c': 'source_c'}

    # Test the function
    v.__delitem__('a')

    # Check the results
    assert len(v.data) == 1
    assert len(v.sources) == 1



# Generated at 2022-06-21 09:45:27.525758
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    '''Tests VarsWithSources constructor'''
    v = VarsWithSources()
    assert v is not None
    assert v == dict()
    v = VarsWithSources({"foo":"bar"})
    assert v is not None
    assert v == {"foo":"bar"}
    v = VarsWithSources(foo="bar")
    assert v is not None
    assert v == {"foo":"bar"}
    v = VarsWithSources(foo=["bar"])
    assert v is not None
    assert v == {"foo":["bar"]}

# Generated at 2022-06-21 09:46:34.124535
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager as VariableManager_
    # 1. Instantiate a VariableManager instance
    vm = VariableManager(loader=None, inventory=None)

    # 2. Instantiate a host
    host_name = "localhost"
    host = host_name

    # 3. Instantiate a facts object
    facts = dict()
    facts["test_facts"] = "test_data"

    # 4. Invoke the method on the class
    vm.set_nonpersistent_facts(host=host, facts=facts)

    # 5. Check if the object contains the facts object
    assert not VariableManager_.is_non_persistent_fact(host=host, fact=facts["test_facts"], vm=vm)

# Generated at 2022-06-21 09:46:44.394066
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    hostvars = HostVars(loader=None, variables=None)
    hostvars._data = {'my_host': {}}

    vm = VariableManager(loader=None, inventory=None, version_info=dict( major=2 ))
    vm._vars_cache = {'my_host': {}}
    vm._nonpersistent_fact_cache = {'my_host': {}}
    vm._fact_cache = hostvars

    test_facts = {'test_fact': 'test_value'}
    vm.set_nonpersistent_facts('my_host',test_facts)

    assert vm._nonpersistent_fact_cache == {'my_host': test_facts}

# Generated at 2022-06-21 09:46:48.626081
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    ''' constructor test for class VarsWithSources '''
    v = VarsWithSources(foo='bar')
    assert v
    assert 'foo' in v
    assert v['foo'] == 'bar'
    assert len(v) == 1

# Generated at 2022-06-21 09:47:00.059480
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    fact_cache = dict()
    vars_cache = dict()
    nonpersistent_fact_cache = dict()
    variable_manager = VariableManager(fact_cache=fact_cache,
                                       vars_cache=vars_cache,
                                       nonpersistent_fact_cache=nonpersistent_fact_cache)

    host = 'localhost'
    facts = dict(a=1, b=2)
    variable_manager.set_host_facts(host, facts)
    assert fact_cache[host] == facts

    # Ensure that we do not do a deep merge with this function
    facts = dict(a=dict(b=1, c=2))
    variable_manager.set_host_facts(host, facts)

# Generated at 2022-06-21 09:47:09.632847
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    vars = VariableManager()
    # ensure we don't save thread local state
    vars._vars_cache = 'invalid'
    vars._nonpersistent_fact_cache = 'invalid'
    vars._fact_cache = 'invalid'
    vars._hostvars = 'invalid'
    vars._hostvars_external = 'invalid'

    state = vars.__getstate__()

    assert '_vars_cache' not in state
    assert state['_nonpersistent_fact_cache'] == {}
    assert state['_fact_cache'] == {}
    assert state['_hostvars'] == {}
    assert state['_hostvars_external'] == {}

# Generated at 2022-06-21 09:47:17.167405
# Unit test for function preprocess_vars
def test_preprocess_vars():
    # Testing type list of dictionaries
    assert preprocess_vars([{'uno': 'one'}, {'dos': 'two'}]) == [{'uno': 'one'}, {'dos': 'two'}]
    # Testing type dictionary
    assert preprocess_vars({'uno': 'one', 'dos': 'two'}) == [{'uno': 'one', 'dos': 'two'}]
    # Testing type None
    assert preprocess_vars(None) is None
    # Testing type string
    try:
        preprocess_vars("i am a string")
        assert False
    except AnsibleError:
        assert True
    # Testing type int
    try:
        preprocess_vars(123)
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-21 09:47:20.789118
# Unit test for function preprocess_vars
def test_preprocess_vars():
    assert preprocess_vars("FOO") == ["FOO"]
    assert preprocess_vars({"FOO":"BAR"}) == [{"FOO":"BAR"}]
    assert preprocess_vars([{"FOO":"BAR"}]) == [{"FOO":"BAR"}]


# Generated at 2022-06-21 09:47:31.563071
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    host = "dummy"
    varname = "dummy_var"
    vm.set_host_variable(host, varname, "dummy_value")
    assert(vm._vars_cache[host][varname] == "dummy_value")
    vm._vars_cache[host][varname] = "dummy_value2"
    vm.set_host_variable(host, varname, {})
    assert(vm._vars_cache[host][varname] == {})
    vm._vars_cache[host][varname] = "dummy_value2"
    vm.set_host_variable(host, varname, {"dummy_key": "dummy_value3"})

# Generated at 2022-06-21 09:47:38.546638
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():

    original = VarsWithSources({'a': 1, 'b': 2}, {'a': 'A', 'c': 'C'})

    # Must return a new instance
    assert original.copy() is not original

    # Must be a VarsWithSources instance
    assert type(original.copy()) is VarsWithSources

    # Must be a copy of the original, containing the same data
    assert original.copy().data == original.data

    # Must be a copy of the original, containing the same sources
    assert original.copy().sources == original.sources

#
# The rest of the unit testing is contained in test_context.py
#