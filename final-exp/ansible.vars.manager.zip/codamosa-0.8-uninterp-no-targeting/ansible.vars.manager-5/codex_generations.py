

# Generated at 2022-06-21 09:38:37.297648
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    '''
    Unit test for method __setstate__
    of class ansible.vars.manager.VariableManager
    '''
    #pylint: disable=attribute-defined-outside-init
    #pylint: disable=unsupported-membership-test,no-member
    #pylint: disable=ungrouped-imports
    try:
        from unittest.mock import call, patch, MagicMock
    except ImportError:
        from mock import call, patch, MagicMock

    from ansible.vars import VariableManager

    from ansible.vars.host_cache import _HostCache

    from ansible.vars.host_cache import _get_subclass_dict
    from ansible.vars.host_cache import CACHEABLE_VALUES

# Generated at 2022-06-21 09:38:44.802540
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Make an instance of a VariableManager class and pass a test inventory object to use
    # for getting variables for the host.
    v = VariableManager()

    # make a test host
    h = Host('h1')
    # set some facts for the host
    h.set_variable('my_fact', 'my_fact_value')
    h.set_variable('my_address_fact', '127.0.0.1')

    # Now that we have a test host, we'll create a TestInventory object to use to get variables
    # for the host
    i = TestInventory()

    # We'll add the host to the TestInventory object (this is the same as adding it to an inventory
    # file)
    i.add_host(h)

    # Now we'll setup the VariableManager object to use the TestInventory object that

# Generated at 2022-06-21 09:38:46.851626
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    variable_manager = VariableManager()
    variable_manager.set_inventory(['a'])
    assert variable_manager._inventory_vars is None


# Generated at 2022-06-21 09:38:48.461265
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    v = VarsWithSources({'a': 1, 'b': 2, 'c': 3})
    assert sorted(list(iter(v))) == ['a', 'b', 'c']


# Generated at 2022-06-21 09:38:59.099591
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    v = VariableManager()
    v.__getstate__()
    
    v.set_host_facts(u'127.0.0.1', {u'foo': u'bar'})
    v.__getstate__()
    
    v.set_nonpersistent_facts(u'127.0.0.1', {u'baz': u'bat'})
    v.__getstate__()
    
    v.set_host_variable(u'127.0.0.1', u'faz', u'foz')
    v.__getstate__()
    
    v.set_host_variable(u'127.0.0.1', u'key', {u'foo': u'bar'})
    v.__getstate__()
    
    v.add_group_vars_

# Generated at 2022-06-21 09:39:09.095548
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # assert VariableManager.set_nonpersistent_facts() usage
    _loader = DictDataLoader({})
    _loader.set_basedir(os.path.join(os.path.dirname(__file__), 'fixtures', 'test_playbooks'))
    _hostvars = Mapping({"host": {}})
    _vm = VariableManager(loader=_loader, inventory=None, version_info=ansible_version_info())
    mock_host = Mock()
    mock_host.name = 'host'
    mock_host.vars = {}
    mock_host.get_vars.return_value = mock_host.vars
    mock_host.get_vars.side_effect = lambda: mock_host.vars

# Generated at 2022-06-21 09:39:21.839937
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # creates new object of class VariableManager
    mock = VariableManager()
    # create new mock objects to set value of mock
    # calls method set_host_variable of class VariableManager
    mock.set_host_variable('host', 'varname', 'value')
    # checks value of mock is equal to expected value or not
    assert mock.vars_cache == {'host': {'varname': 'value'}}
    # create new mock objects to set value of mock
    # calls method set_host_variable of class VariableManager
    mock.set_host_variable('host', 'varname', {'value': 'value'})
    # checks value of mock is equal to expected value or not
    assert mock.vars_cache == {'host': {'varname': {'value': 'value'}}}
test_VariableManager_

# Generated at 2022-06-21 09:39:24.334858
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    varm = VariableManager()
    assert getattr(varm, "clear_facts", None) is not None


# Generated at 2022-06-21 09:39:27.267552
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    v = VariableManager()
    v.set_host_facts('server1', dict(a=1))
    assert v._fact_cache['server1'] == dict(a=1)


# Generated at 2022-06-21 09:39:32.159655
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    test_dict = VarsWithSources({"a":2, "b":3, "c":4})
    test_dict.sources = {"a":"fileA"}
    if test_dict.get_source("a") == "fileA":
        return True
    else:
        return False



# Generated at 2022-06-21 09:39:58.956792
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    obj = VarsWithSources({'key':'value'})
    assert 'key' in obj
    assert 'foo' not in obj


# Generated at 2022-06-21 09:40:03.903254
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    from ansible.playbook.play_context import VarsWithSources
    vars = [('key' + str(i), 'value' + str(i)) for i in range(10)]
    v = VarsWithSources(vars)
    assert len(v) == 10

# Generated at 2022-06-21 09:40:06.704505
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    ''' unit tests for "__iter__" of class VarsWithSources '''
    # TODO
    pass

# Generated at 2022-06-21 09:40:16.450602
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    # instantiate the class directly
    variable_manager = VariableManager()
    
    # set the values of the class attribute
    variable_manager.set_inventory(inventory)
    
    # get a value of the class attribute
    inventory = variable_manager.get_inventory()
    
    # get the value of the instance attribute of the class
    loader = variable_manager._loader
    
    # get the value of the instance attribute of the class
    play_context = variable_manager._play_context
    
    # get the value of the instance attribute of the class
    fact_cache = variable_manager._fact_cache
    
    # get the value of the instance attribute of the class
    nonpersistent_fact_cache = variable_manager._nonpersistent_fact_cache
    
    # get the value of the instance attribute of the class
    vars

# Generated at 2022-06-21 09:40:20.713956
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    v = VariableManager()
    assert v._inventory is None
    v.set_inventory(object())
    assert v._inventory is not None
    v.set_inventory(None)
    assert v._inventory is None

# Generated at 2022-06-21 09:40:26.272848
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    vws = VarsWithSources({'a' : 0, 'b' : 1, 'c' : 2, 'd' : 3, 'e' : 4})
    del vws['c']
    del vws['d']
    assert vws == {'a' : 0, 'b' : 1, 'e' : 4}


# Generated at 2022-06-21 09:40:30.901343
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variableManager = VariableManager()
    variableManager.set_host_variable('test_host','test_varname','test_value')
    assert variableManager._vars_cache.get('test_host').get('test_varname') == 'test_value'

# Generated at 2022-06-21 09:40:32.853392
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # TODO: unit test for
    #       method set_host_variable of class VariableManager
    pass

# Generated at 2022-06-21 09:40:35.556335
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    vws = VarsWithSources({'a': 1})
    assert 'a' in vws
    assert 'b' not in vws



# Generated at 2022-06-21 09:40:43.847143
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.reserved import Reserved
    from ansible.vars.manager import VariableManager
    v = VariableManager()
    v.hostvars = dict()
    v.hostvars = dict()
    v.hostvars = dict()
    v.hostvars = dict()
    v.hostvars = dict()
    v.hostvars = dict()
    v.hostvars = dict()
    v.hostvars = dict()
    v.hostvars = dict()
    v.hostvars = dict()
    vars = dict(a = "hello")
    v.hostvars = dict()
    v.hostvars = dict()
    v.hostvars = dict()
    v.hostvars = dict()
    v

# Generated at 2022-06-21 09:41:11.253494
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    '''
    Test __delitem__ of class VarsWithSources
    '''
    my_VarsWithSources = VarsWithSources()
    x = my_VarsWithSources.__delitem__('key')
    assert x is None



# Generated at 2022-06-21 09:41:22.732277
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    variable_manager = VariableManager()

    ##################################################
    # Testing with default args
    ##################################################

    # Test with default args
    argspec = inspect.getargspec(variable_manager.__getstate__)
    assert argspec.args == []
    assert argspec.varargs is None
    assert argspec.keywords is None
    assert argspec.defaults is None

    ##########################
    # Testing __getstate__() #
    ##########################

    with pytest.raises(NotImplementedError) as excinfo:
        variable_manager.__getstate__()
    assert 'Not implemented in base class' in str(excinfo.value)


# Generated at 2022-06-21 09:41:27.871280
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    from ansible.inventory.host import Host

    # Test when VarsWithSources receives a string instead of a variable name
    with pytest.raises(KeyError):
        v = VarsWithSources({'ansible_ssh_host': '10.0.0.1'})
        return v['ansible_ssh_host']

    # Test when VarsWithSources receives a variable name with a
    # value for the variable
    return_value = VarsWithSources({'ansible_ssh_host': '10.0.0.1'})['ansible_ssh_host']
    assert return_value == '10.0.0.1'

    # Test when VarsWithSources receives a variable name with no
    # value for the variable
    return_value = VarsWithSources({})['ansible_ssh_host']

# Generated at 2022-06-21 09:41:32.056989
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    '''
    check the get_source method of class VarsWithSources
    '''
    obj = VarsWithSources({'testkey': 'testvalue'}, {'testkey': 'testsource'})
    assert obj.get_source('testkey') == 'testsource'
    assert obj.get_source('testkey2') is None

# Generated at 2022-06-21 09:41:35.555351
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    x = VarsWithSources()
    x['a'] = 5
    assert x['a'] == 5
    x['b'] = {'c': 7}
    assert x['b'] == {'c': 7}



# Generated at 2022-06-21 09:41:38.906474
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    my_inv = "this is my inventory"
    vm = VariableManager(loader=MagicMock())
    assert vm._inventory is None
    vm.set_inventory(my_inv)
    assert vm._inventory == my_inv


# Generated at 2022-06-21 09:41:42.819305
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    """VariableManager: set_nonpersistent_facts"""
    m = MagicMock(spec=VariableManager)
    m.set_nonpersistent_facts.return_value = None

    ansible.utils.assert_equal(m.set_nonpersistent_facts(host="", facts={}), None)
    m.set_nonpersistent_facts.assert_called_with(host="", facts={})


# Generated at 2022-06-21 09:41:53.373319
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # create an instance of class VariableManager
    vm = VariableManager()
    # create an instance of class PlayContext
    pc = PlayContext()
    # call method get_vars of class VariableManager
    vm.get_vars(pc)
# import modules for unit testing
from ansible.errors import AnsibleError
from ansible.plugins.loader import lookup_loader
from ansible.parsing.splitter import parse_kv
from ansible.template import Templar
from ansible.vars.clean import combine_vars
from ansible.vars.hostvars import HostVars
from ansible.vars.manager import VariableManager, implicit_subgroup_vars
from ansible.vars.unsafe_proxy import AnsibleUnsafeText
from ansible.vars.hostvars import HostVars

# Generated at 2022-06-21 09:42:00.273137
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    class TestClass():
        display = display

    class Store():
        def __init__(self):
            self.messages = []

        def get_message(self):
            return self.messages.pop()

        def debug(self, value):
            self.messages.append(value)

    v = VarsWithSources({'a': 'b'}, {'a': 'c'})
    tc = TestClass()
    s = Store()
    tc.display = s
    assert v.get_source('a') == 'c'
    assert v['a'] == 'b'
    assert s.get_message() == "variable 'a' from source: c"
    assert 'a' in v


# Generated at 2022-06-21 09:42:07.557299
# Unit test for function preprocess_vars
def test_preprocess_vars():
    a = {'a':1}
    assert preprocess_vars(a) == [{'a': 1}]

    a = [ {'a':1, 'b':2}, {'c':3, 'd':4} ]
    assert preprocess_vars(a) == [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]

    try:
        a = [ {'a':1, 'b':2}, 3 ]
        assert preprocess_vars(a) == [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    except AnsibleError:
        pass



# Generated at 2022-06-21 09:42:59.178716
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    my_variable = VarsWithSources(data={'k1': 'v1'}, sources={'k1': 'v1_source'})
    my_variable.__delitem__('k1')
    assert 'k1' not in my_variable.data
    assert 'k1' not in my_variable.sources
    assert len(my_variable.data) == 0
    assert len(my_variable.sources) == 0


# Generated at 2022-06-21 09:43:06.801412
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    test_cases = [({}, '{"ansible_python_version": "2.7.5"}', True),
        (MutableMapping(), '{"ansible_python_version": "2.7.5"}', True)]

    for (facts, value_to_set, result) in test_cases:
        variable_manager = VariableManager()
        variable_manager.set_host_facts(Host(name='localhost'), json.loads(value_to_set))
        assert variable_manager._fact_cache == {'localhost': {'ansible_python_version': '2.7.5'}}



# Generated at 2022-06-21 09:43:14.187238
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    fixture_loader, testsubs = setup_loader()
    variable_manager = VariableManager()

    target_host = 'testhost'

    test_facts = dict(
        test_fact_1=True,
        test_fact_2=1,
        test_fact_3=None,
        test_fact_4='testing',
        test_fact_5={
            'test_fact_5_key_1': 'test_fact_5_value_1',
            'test_fact_5_key_2': 'test_fact_5_value_2',
        },
        test_fact_6=[
            'test_fact_6_value_1',
            'test_fact_6_value_2',
        ],
    )

    variable_manager.set_host_facts(target_host, test_facts)


# Generated at 2022-06-21 09:43:17.347971
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    v = VarsWithSources()
    v.sources = {'a': 'a'}
    v['a'] = '1'
    assert v.data == {'a': '1'}
    assert v.sources == {'a': 'a'}
    pass


# Generated at 2022-06-21 09:43:21.523380
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    data = {'a': 'b', 'c': 'd'}
    sources = {'a': 'play', 'c': 'inventory'}
    v = VarsWithSources.new_vars_with_sources(data, sources)
    del v['a']
    assert_equal(v, {'c': 'd'})


# Generated at 2022-06-21 09:43:24.869131
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():

    vm = VariableManager()

    host = 'testhost'
    facts = dict()
    vm.set_nonpersistent_facts(host, facts)

    facts = vm.get_host_variables(host)
    assert not facts, "expected empty facts dict"

test_VariableManager_set_nonpersistent_facts()

# Generated at 2022-06-21 09:43:31.320224
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    myVarManager = VariableManager()
    myVarManager._vars_cache = dict()
    myVarManager.set_host_variable("myHost", "myVariable", "myValue")
    assert myVarManager._vars_cache['myHost']['myVariable'] == "myValue"
    myVarManager.set_host_variable("myHost", "myVariable", "myNewValue")
    assert myVarManager._vars_cache['myHost']['myVariable'] == "myNewValue"
    myVarManager.set_host_variable("myHost", "myVariable", dict(mySubVariable="mySubValue"))
    assert myVarManager._vars_cache['myHost']['myVariable']['mySubVariable'] == "mySubValue"

# Generated at 2022-06-21 09:43:36.258398
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    args = dict(
        loader=dict(),
        inventory=Mock(),
        host_vars=dict(),
        group_vars=dict(),
        extra_vars=Mock(),
    )
    variable_manager = VariableManager(**args)
    variable_manager.populate_facts = False
    variable_manager.__setstate__(dict(fact_cache=dict()))
    assert variable_manager



# Generated at 2022-06-21 09:43:42.998133
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()

    with pytest.raises(AnsibleAssertionError) as exc_info:
        variable_manager.set_nonpersistent_facts('dummy host', [])
    assert "the type of 'facts' to set for nonpersistent_facts should be a Mapping but is a <class 'list'>" == str(exc_info.value)
# Test set_host_facts of class VariableManager

# Generated at 2022-06-21 09:43:44.580864
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    v = VarsWithSources()
    assert v['a'] == 0

# Generated at 2022-06-21 09:45:37.288255
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    # Set up
    v = VarsWithSources()
    v['test_key'] = 'test_value'

    # Verify
    assert v.__contains__('test_key')
    assert not v.__contains__('another_test_key')
    assert v.__contains__(u'test_key')
    assert not v.__contains__(u'another_test_key')
    assert type(v.__contains__('test_key')) is bool
    assert type(v.__contains__('another_test_key')) is bool
    assert type(v.__contains__(u'test_key')) is bool
    assert type(v.__contains__(u'another_test_key')) is bool

    # Tear down
    del v


# Generated at 2022-06-21 09:45:41.074407
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    # Create instance of VarsWithSources class
    vars_with_sources = VarsWithSources()
    # Check that __iter__ returns iterable items
    assert list(vars_with_sources) == []


# Generated at 2022-06-21 09:45:50.766474
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    # Set up mock objects
    mock_self = MagicMock()
    mock_self.host_group_vars = dict()
    mock_self.host_group_vars_files = dict()
    mock_self.task_group_vars = dict()
    mock_self.task_group_vars_files = dict()
    mock_self._omit_token = object()
    mock_self.set_options_variables = MagicMock()

    # Perform the test
    result = VariableManager._getstate__(mock_self)

    # Verify the results

# Generated at 2022-06-21 09:45:53.260261
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():

    obj = VarsWithSources()
    obj["foo"] = "bar"

    # Assert the assignment worked
    assert obj["foo"] == "bar"


# Generated at 2022-06-21 09:45:58.083310
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    '''
    Unit test for method __setstate__ of class VariableManager
    '''

    # From Ansible 2.12 NULL byte injection was fixed and the test was updated
    # accordingly.
    # This test is now disabled because it is a duplicate, so it can be removed
    # in a future Ansible release.
    pass



# Generated at 2022-06-21 09:46:09.235006
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    Unit test for method get_vars of class VariableManager
    '''

    vm = VariableManager()
    vm.set_host_variable("host1", "myvar", "myvalue")
    # with persistent facts
    assert vm.get_vars(host=None, include_hostvars=True)['hostvars']['host1']['myvar'] == "myvalue"

    vm.set_nonpersistent_facts("host2", dict(myvar="myvalue2"))
    assert "myvar" not in vm.get_vars(host=None, include_hostvars=True)['hostvars']['host1']
    # with nonpersistent facts

# Generated at 2022-06-21 09:46:19.687844
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    #self._fact_cache = dict()
    #self._vars_cache = dict()
    #self._nonpersistent_fact_cache = dict()
    #self._host_extra_vars = dict()
    variable_manager = VariableManager()
    #self._extra_vars = dict()
    #self._options_vars = dict()
    #self._inventory = None
    #self._loader = None
    state = variable_manager.__getstate__()
    assert len(state) == 2
    # test that all fields have been saved
    assert '_extra_vars' in state
    assert '_options_vars' in state
    assert '_inventory' in state
    assert '_loader' in state
    # test that not fields have been saved
    assert '_fact_cache' not in state

# Generated at 2022-06-21 09:46:27.551893
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    vars_with_sources = VarsWithSources({'book':'Ansible: Up and Running'})
    vars_with_sources.sources = {'book':'file:/home/local/my_var_files/my_vars.yml'}
    result = vars_with_sources.__getitem__('book')
    assert result == 'Ansible: Up and Running'
    result = vars_with_sources.sources.get('book')
    assert result == 'file:/home/local/my_var_files/my_vars.yml'


# Generated at 2022-06-21 09:46:30.578998
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    varmgr = VariableManager()
    facts = {'fact1': 'value1'}
    varmgr.set_nonpersistent_facts('host', facts)
    assert varmgr._nonpersistent_fact_cache['host'] == facts

# Generated at 2022-06-21 09:46:32.869516
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    vars = VarsWithSources()
    assert vars == {}
    vars['key1'] = 'value1'
    assert vars == {'key1': 'value1'}
