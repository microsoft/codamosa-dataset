

# Generated at 2022-06-21 09:38:12.051853
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    hostname = 'test'
    variable_manager = VariableManager()
    variable_manager.clear_facts(hostname=hostname)
    assert True

# Generated at 2022-06-21 09:38:18.156642
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    args = (
        )
    eager_dict = dict(
        _options_vars = {},
        _hostvars = {},
        _vars_cache = {},
        _nonpersistent_fact_cache = {},
        _fact_cache = {},
        _type_validation_rules = {},
        _loader = None,
        _inventory = None,
        _run_validation = False,
        _omit_token = '__omit_place_holder__'
    )
    eager_keys = list(eager_dict.keys())
    eager_dict['_eager_fields'] = eager_keys
    return_value = VariableManager.__getstate__(args)
    assert eager_keys == list(return_value.keys())
    expected = eager_dict
    actual = return_value

# Generated at 2022-06-21 09:38:27.575264
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vm = VariableManager()

    nonpersistent_facts = dict(os_family='RedHat', os_major_version=7, os_minor_version=3)
    vm.set_nonpersistent_facts('myhost', nonpersistent_facts)
    assert vm._nonpersistent_fact_cache.get('myhost') is nonpersistent_facts

    # Try updating the facts
    nonpersistent_facts = dict(os_family='RedHat', os_major_version=7, os_minor_version=3, added='value')
    vm.set_nonpersistent_facts('myhost', nonpersistent_facts)
    assert vm._nonpersistent_fact_cache.get('myhost') is nonpersistent_facts

    # Check that an exception is raised when setting an invalid fact type

# Generated at 2022-06-21 09:38:35.075096
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    from ansible.vars.vars_with_sources import VarsWithSources
    test_cases = [
        ({}, 0),
        ({'foo': True}, 1),
        ({'foo': True, 'bar': False}, 2),
    ]
    for test_case in test_cases:
        (data, n) = test_case
        v = VarsWithSources(data)
        assert len(v) == n, "len(VarsWithSources(%s)) == %s" % (data, n)

# Generated at 2022-06-21 09:38:44.575081
# Unit test for function preprocess_vars
def test_preprocess_vars():
    # Test a single variable passed in, should get a list with one dict
    assert preprocess_vars({'Test': True}) == [{'Test': True}]
    assert preprocess_vars(['Test']) == ['Test']

    # Test that a list of dicts is returned as a list of dicts
    assert preprocess_vars([{'Test': True},{'Test2': False}]) == [{'Test': True},{'Test2':False}]

    # Test that a list of dicts with a string in it, raises an error
    try:
        preprocess_vars([{'Test': True},'Test'])
    except AnsibleError:
        pass
    else:
        assert 0, "Unexpected pass!"
# Done unit testing preprocess_vars



# Generated at 2022-06-21 09:38:46.887173
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources()
    v['test_var'] = 'test_val'

    v_copy = VarsWithSources.new_vars_with_sources(v.data, v.sources)
    assert v_copy['test_var'] == 'test_val'
    assert v_copy.get_source('test_var') is None

# Generated at 2022-06-21 09:38:57.650545
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    hostname = 'some_hostname'
    # Setup our datastructs
    ansible_vars = {'some_key': 'some_value_1', 'some_other_key': 'some_value_2'}
    ansible_facts = {'some_fact_key': 'some_fact_value_1', 'some_other_fact_key': 'some_other_fact_value_2'}
    VariableLoader = collections.namedtuple('VariableLoader', ['vars', 'facts'])
    loader = VariableLoader(vars=ansible_vars, facts=ansible_facts)
    fact_cache = {'some_host': {'fact_cache_key': 'fact_cache_value'}}
    inventory = FakeInventory()

    vm = VariableManager()

# Generated at 2022-06-21 09:39:04.729079
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    array_cases = [
        ([1, 2, 3], [4, 5, 6]),
        (['a', 'b', 'c'], ['d', 'e', 'f']),
    ]
    for orig_array, orig_array_copy in array_cases:
        source = ['some source']
        kwargs = {'array': orig_array}
        vars_with_sources = VarsWithSources(kwargs)
        vars_with_sources.sources = {'array': source}
        copied = vars_with_sources.copy()
        assert copied['array'] == orig_array
        assert copied.sources['array'] == source
        assert copied['array'] == vars_with_sources['array']
        assert copied.sources['array'] == vars_with_sources.s

# Generated at 2022-06-21 09:39:12.080411
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    # mock a host for testing
    host = mock.MagicMock()
    host_name = 'mocked_host'

    # initialize variables to use for testing
    d = dict()
    fact_cache = dict()
    fact_cache[host_name] = d

    # inputs
    host_name = 'test_host'

    # mock the host as 'test_host'
    host.get_name.return_value = host_name

    # test the scenario
    vm = VariableManager()
    vm._fact_cache = fact_cache
    vm.clear_facts(host_name)

    # ensure that the host was removed from the cache
    try:
        fact_cache[host_name]
        assert False, "Failed to remove facts for host: %s" % host_name
    except KeyError:
        pass



# Generated at 2022-06-21 09:39:16.067882
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    d = VarsWithSources()
    d['key1'] = 'val1'
    d2 = d.copy()
    assert d2 == d
    assert id(d2) != id(d)


# Generated at 2022-06-21 09:40:10.197252
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    varsmgr = VariableManager()
    varsmgr2 = VariableManager()
    varsmgr.hostvars['host1'] = {'var1': 1}
    varsmgr2.hostvars['host1'] = {'var2': 2}
    varsmgr.set_host_variable('host1', 'var3', 3)
    varsmgr2.set_host_variable('host1', 'var4', 4)
    varsmgr.set_fact_cache({'host1': {'var5': 5}})
    varsmgr2.set_fact_cache({'host1': {'var6': 6}})
    assert varsmgr._getstate() == varsmgr2._getstate()


# Generated at 2022-06-21 09:40:10.970141
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    assert VariableManager() is not None

# Generated at 2022-06-21 09:40:13.538530
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    test_inst = VarsWithSources({"a": 1, "b": 2, "c": 3})
    assert(list(iter(test_inst))) == ["a", "b", "c"]

# Generated at 2022-06-21 09:40:15.833991
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    vars_with_sources = VarsWithSources('a', a=1, b=2)
    assert len(vars_with_sources) == 2


# Generated at 2022-06-21 09:40:28.033572
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    ansible_path = '/usr/local/share/ansible/'
    jinja_extensions = ['jinja2.ext.do']
    ansible_playbook_path = '/Users/liangqian/works/ansible/ansible2.x/data/playbooks'
    include_task_vars = True
    inventory = InventoryManager(loader=DataLoader())
    options = Options()
    inventory.parse_inventory(host_list='/Users/liangqian/works/ansible/ansible2.x/data/hosts')
    print(inventory.hosts)
    print(inventory.groups)
    vm = VariableManager(loader=DataLoader(), inventory=inventory, options=options)
    print(vm.get_vars(host='zhoujian', include_hostvars=False))

# Generated at 2022-06-21 09:40:36.966563
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    a = VarsWithSources()
    assert a.__contains__('a') == False
    assert 'a' in a == False
    a['a'] = 1
    assert a.__contains__('a') == True
    assert 'a' in a == True
    b = a.copy()
    assert b.__contains__('a') == True
    assert 'a' in b == True
    a.__setitem__('a',2)
    assert b.__contains__('a') == True
    assert 'a' in b == True


# Generated at 2022-06-21 09:40:44.533116
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    global _hosts_all
    _hosts_all = None

    global _hosts
    _hosts = None

    from ansible.playbook.play_context import PlayContext

    vm = VariableManager()
    pc = PlayContext()

    _st = vm.__getstate__()
    vm.__setstate__(_st)

    # coverage.py hits all branches if we instantiate from a class
    assert type(vm) == VariableManager

    # coverage.py hits this path if we instantiate from a class
    assert vm.omit_token == ''

    # coverage.py hits this path if we instantiate from a class
    assert vm.vars_cache == {}

    # coverage.py hits this path if we instantiate from a class
    assert vm.hostvars == {}

    # coverage.py hits this path if we instant

# Generated at 2022-06-21 09:40:49.190773
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    host = 'foo'
    varname = 'bar'
    value = 'test'
    vm = VariableManager()
    vm.set_host_variable(host, varname, value)
    assert vm._vars_cache['foo']['bar'] == 'test'




# Generated at 2022-06-21 09:40:58.289306
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    v = VarsWithSources(dict(a='b'))
    assert 'a' in v


# Generated at 2022-06-21 09:41:11.334226
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    def test_vm_set_nonpersistent_facts_method(host, facts):
        # make sure that the host and facts parameters are passed as expected
        assert host == 'ansible_vm'
        assert facts == 'ansible_facts'
        # modify the proxy object (self._nonpersistent_fact_cache) so that we can verify that the
        # data has been updated
        proxy['ansible_vm'] = 'ansible_facts'

    ansible_vm = MagicMock()
    proxy = MagicMock()
    vars_cache = MagicMock()
    fact_cache = MagicMock()
    loader = MagicMock()
    inventory = MagicMock()

    vm = VariableManager(loader=loader, inventory=inventory)
    vm._nonpersistent_fact_cache = proxy

    vm.set_nonpersistent_

# Generated at 2022-06-21 09:41:55.237757
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
	"""
	__getstate__(...)
	 Test the ability to serialize the object
	"""
	ve_msg = "Failed to serialize VariableManager"
	try:
		v = VariableManager()
		serialized_obj = pickle.dumps(v)
		assert serialized_obj is not None, ve_msg
		assert len(serialized_obj) > 0, ve_msg
	except Exception as e:
		assert False, ve_msg + "\n" + str(e)

# Generated at 2022-06-21 09:42:04.974256
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    # pylint: disable=protected-access
    # Ignore protected access since this is a unit test
    vws = VarsWithSources({'a': 1}, b=2)
    assert vws.data['a'] == 1
    assert vws.data['b'] == 2

    vws['c'] = 3
    assert vws.data['c'] == 3

    del vws['c']
    assert vws.data.get('c') is None

    vws = VarsWithSources.new_vars_with_sources({'a': 1}, {'a': 'source'})
    assert vws.get_source('a') == 'source'

    vws2 = vws.copy()
    assert vws2.data == vws.data
    assert vws2.get_source('a') == 'source'

# Generated at 2022-06-21 09:42:11.399337
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    '''
    Ensure that VariableManager.__setstate__ works as expected
    '''
    host_name = b'myhost.example.org'
    var_name = b'myvar'
    var_value = b'myvalue'

    # Test invoking without the host_cache property
    with pytest.raises(TypeError):
        VariableManager(play_context=None)

    # Test invoking with an empty host_cache
    fact_cache = {}
    vars_manager = VariableManager(play_context=None)
    vars_manager.set_fact_cache(fact_cache)
    vars_manager.__setstate__({'_fact_cache': fact_cache})

    # Test invoking with a non-empty fact_cache
    fact_cache = {host_name: {var_name: var_value}}


# Generated at 2022-06-21 09:42:22.989964
# Unit test for constructor of class VariableManager
def test_VariableManager():
    v = VariableManager()

    # Test instance variables
    assert v._fact_cache == dict()
    assert v._nonpersistent_fact_cache is None
    assert v._inventory is None
    assert v._loader is None
    assert v._omit_token == '__omit_place_holder__'
    assert v._vars_cache == dict()
    assert v._vars_from_main is None
    assert v._vars_from_inventory is None
    assert v._vars_from_files is None
    assert v._vars_from_playbook is None
    assert v._vars_from_task is None
    assert v._extra_vars == dict()
    assert v._options_vars == dict()



# Generated at 2022-06-21 09:42:33.558732
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.six import iteritems
    from ansible.plugins.loader import callback_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import replace_dynamic_vars
    import os
    import yaml
    import unittest
    import sys
    import shutil
    import subprocess as sp
    import pwd
    import platform
    from fnmatch import fnmatch
    from collections import namedtuple
    import tempfile



# Generated at 2022-06-21 09:42:37.568466
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    var = VarsWithSources()
    var.sources = {'foo': 'bar'}
    assert var.get_source('foo') == 'bar'
    assert var.get_source('bar') is None

# Generated at 2022-06-21 09:42:40.009410
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    # create an instance of class VarsWithSources
    vars_with_sources = VarsWithSources()



# Generated at 2022-06-21 09:42:41.583957
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    assert False, "No tests for this class yet"



# Generated at 2022-06-21 09:42:53.874532
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    variable_manager.set_host_variable('ip-172-31-88-114.ec2.internal', 'ansible_host', '172.31.88.114')
    variable_manager.set_host_variable('ip-172-31-88-114.ec2.internal', 'ansible_ssh_common_args', '-o StrictHostKeyChecking=no')
    assert 'ip-172-31-88-114.ec2.internal' in variable_manager._vars_cache
    assert 'ansible_host' in variable_manager._vars_cache['ip-172-31-88-114.ec2.internal']

# Generated at 2022-06-21 09:43:00.872532
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    v = VariableManager()
    a = {'a': 1}
    b = {'b': 2}
    assert v._nonpersistent_fact_cache == {}
    # set_nonpersistent_facts
    v.set_nonpersistent_facts("localhost", a)
    assert v._nonpersistent_fact_cache == {'localhost': {'a': 1}}
    v.set_nonpersistent_facts("localhost", b)
    assert v._nonpersistent_fact_cache == {'localhost': {'a': 1, 'b': 2}}

# Generated at 2022-06-21 09:43:39.523610
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    myVariableManager = VariableManager()
    myVariableManager._vars_cache['myhost'] = {'myvar1': 'myvar1_value'}
    # Case:1: Set a value for a variable for a host
    myVariableManager.set_host_variable('myhost', 'myvar1', 'myvar1_value')
    assert myVariableManager._vars_cache['myhost']['myvar1'] == 'myvar1_value'
    # Case:2: Set a different value for the same variable of a host
    myVariableManager.set_host_variable('myhost', 'myvar1', 'myvar1_value2')
    assert myVariableManager._vars_cache['myhost']['myvar1'] == 'myvar1_value2'
    # Case:3: Set a value for a new variable

# Generated at 2022-06-21 09:43:49.591471
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    v = VariableManager()

# Generated at 2022-06-21 09:44:00.174855
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # VariableManager is a callable, so we just test its constructor
    from ansible.template import Templar
    from ansible.vars import AllHostsUnvariable
    from ansible.vars.manager import HostVars, IncludeVars
    from ansible.vars.persistent_fact_cache import PersistentFactCache
    from ansible.vars.unsafe_proxy import wrap_var
    # A class for testing the VariableManager constructor
    class AllHostsVariable(object):
        def __getitem__(self):
            return list(["127.0.0.1", "192.168.1.1"])
    class Options(object):
        verbosity = 1
        host_key_checking = False
    # All of the arguments to the VariableManager constructor are optional,
    # so create an instance to test that.  We need

# Generated at 2022-06-21 09:44:12.266215
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    import collections
    import pytest
    import yaml
    from ansible.errors import AnsibleAssertionError
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    # The following lines test the first if branch.
    vm = VariableManager()
    host = 'host1'
    varname = 'varname1'
    value = dict(a=1)
    vm.set_host_variable(host, varname, value)
    assert vm._vars_cache[host] == dict(varname1=dict(a=1))
    host = 'host1'
    varname = 'varname1'
    value = dict(b=2)
   

# Generated at 2022-06-21 09:44:17.447003
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    v = VarsWithSources({'a': 'b', 'c': 'd'}, sources={'a': 'cache', 'c': 'cache'})
    v['c'] = 'e'
    assert v.get_source('c') is 'cache'


# test for method copy of class VarsWithSources

# Generated at 2022-06-21 09:44:19.951858
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    a = VarsWithSources()
    assert len(a) == 0

    a["foo"] = 1
    assert len(a) == 1


# Generated at 2022-06-21 09:44:21.618760
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    v = VariableManager()
    pass

# Generated at 2022-06-21 09:44:25.598130
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    v = VariableManager(loader=None, inventory=None)
    assert v.__getstate__() == {'_fact_cache': {}, '_vars_cache': {}, '_omit_token': '__omit_place_holder__'}

# Generated at 2022-06-21 09:44:32.867864
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # VariableManager unit test setup
    variable_manager = VariableManager()
    variable_manager._fact_cache = {'test_host': {'test_var': 'test_val'}}
    variable_manager._vars_cache = {'test_host': {'test_var_2': 'test_val_2'}}

    # Get vars for test host
    vars_results = variable_manager.get_vars(host=Host('test_host'))

    assert vars_results['test_var'] == 'test_val'
    assert vars_results['test_var_2'] == 'test_val_2'
    assert vars_results['inventory_hostname'] == 'test_host'

    # VariableManager unit test setup
    variable_manager = VariableManager()

# Generated at 2022-06-21 09:44:44.677707
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    # test a regular VariableManager
    vm = VariableManager()
    vm.set_host_variable("localhost", "test_var", 42)
    assert vm.get_vars(host=vm.get_vars_by_path("localhost")["inventory_hostname"])["test_var"] == 42
    state_dictionary = vm.__getstate__()
    assert state_dictionary["_vars_cache"] == {"localhost": {"test_var": 42}}
    assert state_dictionary["_nonpersistent_fact_cache"] == {}
    assert state_dictionary["_fact_cache"] == {}
    assert state_dictionary["_inventory"] == None
    assert state_dictionary["_delegated_vars_cache"] == {}
    assert state_dictionary["_hostvars"] == None
    assert state_d

# Generated at 2022-06-21 09:46:25.193180
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    variable_manager = ansible_module_runner.VariableManager()
    variable_manager.clear_facts("localhost")
    # TODO: Add some asserts

# Generated at 2022-06-21 09:46:34.034285
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    # check results of the get_source method for some corner cases
    V = VarsWithSources
    v = VarsWithSources()
    # check get_source for non existent key
    assert v.get_source('test') is None
    # check get_source for single value
    v.sources['test']='value'
    assert v.get_source('test') == 'value'
    # check get_source for list
    v.sources['test']=['item1', 'item2']
    assert v.get_source('test') == ['item1', 'item2']
    # check get_source for dict
    v.sources['test']={'k': 'v'}
    assert v.get_source('test') == {'k': 'v'}
    # check get_source for non primitive type
   

# Generated at 2022-06-21 09:46:44.271008
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    # Patch the debug method so that it doesn't actually print anything
    # mock.patch('ansible.utils.display.debug')
    display.debug = mock.MagicMock(return_value=None)
    # Set up test data
    test_data = {"key1": "value1", "key2": "value2"}
    test_sources = {"key1": "source1", "key2": "source2"}
    # Set up an instance of the class under test with the test data
    v = VarsWithSources.new_vars_with_sources(test_data, test_sources)
    # Run the code under test

# Generated at 2022-06-21 09:46:47.014618
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    v = VariableManager()
    i = InventoryManager()
    v.set_inventory(i)

    assert v._inventory == i
    return None


# Generated at 2022-06-21 09:46:54.699416
# Unit test for function preprocess_vars
def test_preprocess_vars():
    assert preprocess_vars(None) is None
    assert preprocess_vars([{'a':'b'}]) == [{'a':'b'}]
    assert preprocess_vars({'a':'b'}) == [{'a':'b'}]
    try:
        preprocess_vars(1)
    except AnsibleError:
        pass
    else:
        assert False, "We should never reach here"


# Generated at 2022-06-21 09:46:58.154364
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    from collections import Mapping
    assert issubclass(VarsWithSources, Mapping)
    assert VarsWithSources({1: 2, 3: 4}, {3: "3_source"}).__len__() == 2

# Generated at 2022-06-21 09:47:07.233705
# Unit test for function preprocess_vars
def test_preprocess_vars():
    '''
    Return the correct list of dictionaries given the input
    :return:
    '''
    assert preprocess_vars(None) is None
    assert preprocess_vars([]) == []
    assert preprocess_vars({}) == [{}]
    assert preprocess_vars([{}]) == [{}]
    assert preprocess_vars(['string']) == ['string']
    assert preprocess_vars([1]) == [1]
    assert preprocess_vars([{'foo': 'bar'}]) == [{'foo': 'bar'}]
    assert preprocess_vars(['dict']) == ['dict']



# Generated at 2022-06-21 09:47:09.004587
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    # TODO: name method better.
    # TODO: make all methods chainable

    # Arrange
    inventory = 22

    # Act
    VariableManager().set_inventory(inventory)

    # Assert
    # TODO: get parameter value and assert expected value
    assert True


# Generated at 2022-06-21 09:47:10.184638
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources()



# Generated at 2022-06-21 09:47:11.808674
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    variable_manager = VariableManager()
    variable_manager.__getstate__()