

# Generated at 2022-06-21 09:38:19.035391
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    argument1 = dict()

    instance = VariableManager()
    instance.__setstate__(argument1)


# Generated at 2022-06-21 09:38:27.141412
# Unit test for function preprocess_vars
def test_preprocess_vars():
    '''
    function preprocess_vars() is used by the module post_validate()
    the function is isolated here for the purpose of testing
    '''
    # preprocess_vars expects a list so [{}] is a valid entry
    assert preprocess_vars([{}]) == [{}]
    # preprocess_vars should return a default if no params are passed
    assert preprocess_vars(None) == None
    # preprocess_vars will convert a dictionary to a list of length one
    assert preprocess_vars({}) == [{}]
    # preprocess_vars will convert a list to a list of length one
    assert preprocess_vars(['item1','item2','item3']) == None



# Generated at 2022-06-21 09:38:28.366984
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    pass


# Generated at 2022-06-21 09:38:39.031356
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    # Create an instance of VarsWithSources with two vars
    testVar = VarsWithSources()
    testVar.data['foo'] = 'bar'
    testVar.data['hello'] = 'world'
    # testVar.data should be a mutable mapping
    assert isinstance(testVar.data, MutableMapping)
    # testVar.data should contain two elements
    assert len(testVar.data) == 2
    # testVar.data should have 'foo' as a key
    assert 'foo' in testVar.data
    # testVar.data should have 'hello' as a key
    assert 'hello' in testVar.data
    # testVar.data['foo'] should be 'bar'
    assert testVar.data['foo'] == 'bar'
    # testVar.data['hello'] should be 'world'


# Generated at 2022-06-21 09:38:47.905906
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # read vars of host with registered plugins
    mocker = Mocker()
    mock_loader = mocker.mock(Loader)
    mock_playbook = mocker.mock(Playbook)
    mock_host = mocker.mock(Host)
    mock_host2 = mocker.mock(Host)
    mock_host2.get_vars(mocker.ANY)
    mocker.result(dict())
    mock_host_vars = dict()
    mock_host_vars['host1_var'] = 'bar'
    mock_host.get_vars(mocker.ANY)
    mocker.result(mock_host_vars)
    mock_playbook.get_variable_manager()
    mocker.result(mock_host2)
    mock_host2.get_v

# Generated at 2022-06-21 09:38:52.335089
# Unit test for function preprocess_vars
def test_preprocess_vars():
    """
    :return:
    """
    vars_list = preprocess_vars(['vars_list'])
    print(vars_list)
    return vars_list

test_preprocess_vars()


# Generated at 2022-06-21 09:38:59.620700
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    v = VarsWithSources({'a':1}, b=2)
    v.sources['a'] = 'source for a'
    v.sources['b'] = 'source for b'
    w = v.copy()
    assert w.data == {'a': 1, 'b': 2}
    assert w.sources == {'a': 'source for a', 'b': 'source for b'}
    assert id(w) != id(v)
    assert id(w.data) != id(v.data)
    assert id(w.sources) != id(v.sources)


# Generated at 2022-06-21 09:39:00.869294
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()
    assert variable_manager is not None


# Generated at 2022-06-21 09:39:03.573683
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    v = VarsWithSources({"foo": "bar"})
    assert len(v) == 1



# Generated at 2022-06-21 09:39:11.374462
# Unit test for function preprocess_vars
def test_preprocess_vars():
    # test normal list of dictionaries
    data = [{'a':1}, {'b':2}]
    assert preprocess_vars(data) == data
    # test list of list, it should be converted to list of dictionaries
    data = [[{'a':1}, {'b':2}]]
    assert preprocess_vars(data) == [{'a':1}, {'b':2}]
    # test list of non-dictionaries
    data = [{'a':1}, 2, 3, 'foo']
    try:
        preprocess_vars(data)
        raise AssertionError('preprocess_vars() did not fail on data=%s' % data)
    except AnsibleError as e:
        pass
    # test simple dictionary
    data = {'a':1}
   

# Generated at 2022-06-21 09:39:36.147486
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    vws = VarsWithSources()
    vws['foo'] = 'bar'
    assert vws['foo'] == 'bar'


# Generated at 2022-06-21 09:39:38.756910
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    target = VarsWithSources()
    target['key'] = 'value'
    del target['key']
    assert not target.__contains__('key')


# Generated at 2022-06-21 09:39:45.708724
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources({"foo": "bar"})
    assert v == {"foo": "bar"}
    assert v.get_source("foo") == None
    v["foo"] = "baz"
    assert v == {"foo": "baz"}
    assert v.get_source("foo") == None
    v.sources = {"foo": "inventory"}
    v["foo"] = "baz2"
    assert v == {"foo": "baz2"}
    assert v.get_source("foo") == "inventory"
    v.sources["foo"] = "contrived example"
    assert v == {"foo": "baz2"}
    assert v.get_source("foo") == "contrived example"

# Generated at 2022-06-21 09:39:52.992413
# Unit test for constructor of class VariableManager
def test_VariableManager():
    loader = DictDataLoader({
        'constants': dict(
            foo='bar',
            FOO='BAR',
        ),
        'vars': dict(
            name='VAR_NAME',
            dict_var={'key1': 'val1', 'key2': 'val2'},
            list_var=['list1', 'list2', 'list3'],
        ),
    })
    constants = loader.get_basedir() + '/constants'
    vars_files = []
    vars_files.append(loader.get_basedir() + '/vars')

# Generated at 2022-06-21 09:39:53.689676
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    pass

# Generated at 2022-06-21 09:40:06.902213
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=['test/ansible/inventory/test_dynamic_inventory.py'])
    variable_manager.set_inventory(inventory)
    print(variable_manager.get_host_vars('host1'))
    print(variable_manager.get_vars())
    print(variable_manager.get_vars(play=None, host=inventory.get_host('host2'), task=None, include_delegate_to=False, include_hostvars=False))


# Generated at 2022-06-21 09:40:11.383712
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    x = VarsWithSources({})
    x.data['a'] = 1
    assert x.__iter__() == x.data.__iter__()
    x.data['b'] = 2
    assert x.__iter__() == x.data.__iter__()


# Generated at 2022-06-21 09:40:17.586937
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()
    host = "test_host"
    facts = {"test_fact": "test_fact_value", "test_fact2": "test_fact_value2"}
    assert variable_manager.get_vars(host=host) == {}
    variable_manager.set_nonpersistent_facts(host=host, facts=facts)
    assert variable_manager.get_vars(host=host) == facts
    variable_manager.set_nonpersistent_facts(host=host, facts=facts)
    assert variable_manager.get_vars(host=host) == facts


# Generated at 2022-06-21 09:40:29.347185
# Unit test for method set_host_facts of class VariableManager

# Generated at 2022-06-21 09:40:33.437063
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Will throw an exception if __init__ method does not accept
    # jinja_context as a parameter
    VariableManager(loader=None, inventory=None, jinja_context=None)



# Generated at 2022-06-21 09:41:18.753912
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    variable_manager = VariableManager()
    variable_manager.__setstate__({'test': 1})

    assert variable_manager.test == 1


# Generated at 2022-06-21 09:41:22.680258
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    myvar = VarsWithSources()
    myvar['abc'] = 'xyz'
    assert 'abc' in myvar
    del myvar['abc']
    assert 'abc' not in myvar


# Generated at 2022-06-21 09:41:25.546414
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({"foo": "bar"})
    v.sources["foo"] = "foo_source"
    assert v["foo"] == "bar"

# Generated at 2022-06-21 09:41:28.440000
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # fixture
    vm = VariableManager()
    host, facts = 'host', 'facts'
    # test
    vm.set_nonpersistent_facts(host,facts)

# Generated at 2022-06-21 09:41:37.391275
# Unit test for function preprocess_vars
def test_preprocess_vars():
    ''' unit tests for function preprocess_vars '''
    # Valid cases
    assert preprocess_vars(None) is None
    assert preprocess_vars({}) == [{}]
    assert preprocess_vars([{}]) == [{}]

    # Invalid cases
    try:
        preprocess_vars([])
        assert False, "preprocess_vars() with empty list should raise exception"
    except AnsibleError:
        pass

    try:
        preprocess_vars([None])
        assert False, "preprocess_vars() with invalid item in list should raise exception"
    except AnsibleError:
        pass

    try:
        preprocess_vars(1)
        assert False, "preprocess_vars() with integer should raise exception"
    except AnsibleError:
        pass



# Generated at 2022-06-21 09:41:38.829246
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    v = VariableManager()
    v.__getstate__()

# Generated at 2022-06-21 09:41:42.858285
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    a = VarsWithSources({'a': '1'})
    b = VarsWithSources(a)
    assert a == b
    a['b'] = '2'
    assert b == {'a': '1'}
    a['c'] = ['1', '2']
    a['c'].append('3')
    assert b == {'a': '1'}

# Generated at 2022-06-21 09:41:53.334177
# Unit test for function preprocess_vars
def test_preprocess_vars():
    '''
    Tests for verifies that preprocess_vars works properly
    '''

    # validate that a None is passed as None
    assert preprocess_vars(None) is None

    # validate that a dict is returned as a list of dicts
    rval = preprocess_vars({"a": "b"})
    assert rval == [{"a": "b"}]

    # validate that a list is returned as a list
    rval = preprocess_vars([{"a": "b"}])
    assert rval == [{"a": "b"}]

    # validate that a list of dicts is returned as a list
    rval = preprocess_vars([{"a": "b"}, {"b": "c"}])
    assert rval == [{"a": "b"}, {"b": "c"}]

    # validate

# Generated at 2022-06-21 09:42:00.856530
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    with pytest.raises(KeyError):
        VarsWithSources()['unknown']
    with pytest.raises(KeyError):
        VarsWithSources().get_source('unknown')

    v = VarsWithSources({ 'known' : 1 })
    assert v['known'] == 1
    assert v.get_source('known') is None
    v.sources = {'known': 'known_source' }
    assert v['known'] == 1
    assert v.get_source('known') == 'known_source'

    v = VarsWithSources({ 'known' : 1 })
    assert v['known'] == 1
    assert v.get_source('known') is None
    v.sources = {'known': 'known_source' }
    assert v['known'] == 1

# Generated at 2022-06-21 09:42:02.133624
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    var_manager = VariableManager()
    var_manager.set_inventory(None)


# Unit tests for the method get_vars of class VariableManager

# Generated at 2022-06-21 09:44:48.521907
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''
    Test if VariableManager object is created.
    '''
    vm = VariableManager()
    # Check if object is created or not
    assert vm is not None

# Generated at 2022-06-21 09:44:52.330768
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    # Test get_source of class VarsWithSources
    p = VarsWithSources()
    p['foo'] = 'bar'
    p.sources['foo'] = 'test'
    assert p.get_source('foo') == 'test', "get_source is not working"



# Generated at 2022-06-21 09:45:03.261617
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    # Mocks
    mockvals  = { 'key1': 'val1', 'key2': 'val2', 'key3': 'val3' }
    mocksrcs  = { 'key1': 'src1', 'key3': 'src3' }
    sources   = VarsWithSources.new_vars_with_sources(mockvals, mocksrcs)
    assert len(sources) == len(mockvals)
    assert len(sources.sources) == len(mocksrcs)
    assert sorted(sources) == sorted(mockvals)
    assert sorted(sources.sources) == sorted(mocksrcs)
    # Test
    copy = sources.copy()
    assert len(copy) == len(sources)

# Generated at 2022-06-21 09:45:05.568237
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    c = VarsWithSources()
    c[1] = 1
    c[2] = 1
    c[4] = 1
    assert len(c) == 3


# Generated at 2022-06-21 09:45:12.895906
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    import pytest
    from collections import defaultdict
    from types import MethodType

    def test(a, b, **kwargs):
        return kwargs

    def default():
        return defaultdict(MethodType, {'test': test})

    data = defaultdict(default)
    data['group']['host']['vars']['test']['test'].__defaults__ = ('group', 'host')

    v = VarsWithSources.new_vars_with_sources(data, {})
    assert 'group' in v

    # This assertion will fail without the special-case __contains__ in VarsWithSources
    with pytest.raises(Exception):
        'group' in v['group']['host']



# Generated at 2022-06-21 09:45:17.278182
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    # test with default source
    v = VarsWithSources({'a': 'b'})
    assert v['a'] == 'b'
    # test with sources
    v = VarsWithSources.new_vars_with_sources({'a': 'b'}, {'a': 'inventory'})
    assert v['a'] == 'b'

# Generated at 2022-06-21 09:45:20.064944
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    v1 = VarsWithSources()
    v1[u'test_key'] = u'test_value'
    assert u'test_key' in v1
    del v1[u'test_key']
    assert u'test_key' not in v1

# Generated at 2022-06-21 09:45:26.453652
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    import nose.tools as nt
    v = VarsWithSources({"a":"b"})
    v.sources = {"a":"c"}
    # Test that the sources dictionary is not modified, even if the VarsWithSources object is
    nt.assert_dict_equal(v.data, {"a":"b"})
    nt.assert_dict_equal(v.sources, {"a":"c"})
    # Test that get_source works and returns the right value
    nt.assert_equal(v.get_source("a"), "c")
    # Test that get_source does not modify the sources dictionary
    nt.assert_dict_equal(v.data, {"a":"b"})
    nt.assert_dict_equal(v.sources, {"a":"c"})
    # Test that get_source returns

# Generated at 2022-06-21 09:45:29.993921
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    data = {'foo':'bar'}
    sources = {'foo':'playbook'}
    v = VarsWithSources.new_vars_with_sources(data, sources)
    assert 'foo' in v
    assert 'bar' not in v



# Generated at 2022-06-21 09:45:41.030138
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    v = VariableManager()
    v.__setstate__({'_fact_cache': {}, '_nonpersistent_fact_cache': {}, '_vars_cache': {}, '_extra_vars': {}, '_options_vars': {}, '_hostvars': {},
                    '_omit_token': '******', '_loader': '', '_defer_anchors': False, '_all_hosts': '', '_inventory': ''})