

# Generated at 2022-06-21 09:38:13.059417
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
	s = VarsWithSources()
	# the length of an empty VarsWithSources should be 0
	assert len(s) == 0
	s = VarsWithSources({'a':1})
	# the length of a VarsWithSources of one element should be 1
	assert len(s) == 1



# Generated at 2022-06-21 09:38:14.500495
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    '''
    Unit test for method clear_facts of class VariableManager
    '''


# Generated at 2022-06-21 09:38:24.230366
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    variable_manager = VariableManager(loader=None, inventory=None, version_info=None)
    variable_manager.cache = None
    variable_manager._fact_cache = None
    variable_manager._vars_cache = None
    variable_manager._nonpersistent_fact_cache = None
    variable_manager._host_cache = None
    variable_manager._option_cache = None
    variable_manager._extra_vars = None
    variable_manager._options_vars = None
    variable_manager._omit_token = None
    variable_manager._hostvars = None

    res = variable_manager.__getstate__()

    assert (res == {'_play_context': None, '_loader': None, '_inventory': None})



# Generated at 2022-06-21 09:38:25.642896
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    a = vm.set_host_variable('hello', 'nice', 'world')
    assert a == None


# Generated at 2022-06-21 09:38:37.298306
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # this is a unit test for VariableManager class set_host_facts method

    # creation of a temp file
    temp_dir = tempfile.mkdtemp()
    testvars = os.path.join(temp_dir, 'testvars.yml')
    testhosts = os.path.join(temp_dir, 'testhosts')
    test_data = dict(
        hostvars=dict(
            testhost=dict(
                testvar1='test var1 value',
                testvar2='test var2 value')),
        _meta=dict(
            hostvars=dict(
                testhost=dict(
                    testvar3='test var3 value'))),
    )

# Generated at 2022-06-21 09:38:41.898946
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    """
    Test that VariableManager.set_host_facts() works when setting new or
    updating existing host facts.
    """
    var_mgr = VariableManager()
    host = 'host_name'
    facts_before = dict()
    facts_after = {'new_fact': 'fact_value'}
    var_mgr.set_host_facts(host, facts_before)
    assert var_mgr._fact_cache == {host: facts_before}
    var_mgr.set_host_facts(host, facts_after)
    assert var_mgr._fact_cache == {host: facts_after}



# Generated at 2022-06-21 09:38:44.776967
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    v = VarsWithSources({"a":1, "b":2, "c":3})
    assert len(v) == 3
    elements = [el for el in v]
    assert all(el in ["a", "b", "c"] for el in elements)
    assert len(elements) == len(v)

# Generated at 2022-06-21 09:38:45.559121
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    pass



# Generated at 2022-06-21 09:38:47.705134
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    # FIXME: what should the arguments for __setstate__ be?
    #vm =  VariableManager()
    #vm.__setstate__([], [])
    pass


# Generated at 2022-06-21 09:38:49.709832
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    data = {}
    sources = {}
    v = VarsWithSources(data, sources)
    v['a'] = 'b'
    v.sources['a'] = 's'
    assert v.get_source('a') == 's'


# Generated at 2022-06-21 09:39:30.420106
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import wrap_var

    data_loader = DataLoader()
    variable_manager = VariableManager(loader=data_loader)

    play_context = PlayContext()

    # input
    data = {"key1": "value1", "key2": "value2"}
    sources = {"key1": "value1", "key2": "value2"}
    # output
    out_data = {"key1": "value1", "key2": "value2"}
    out_sources = {"key1": "value1", "key2": "value2"}

    # this will create wrap_var with _ansible_no_log=True, which we do not want for this

# Generated at 2022-06-21 09:39:35.923373
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():

    variable_manager = ansible.vars.VariableManager()
    variable_manager.__setstate__(state = None)
    variable_manager.__setstate__(state = {'_fact_cache': {}, '_vars_cache': {}, '_extra_vars': {}})


# Generated at 2022-06-21 09:39:44.547085
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    from ansible.context_objects import VarsWithSources
    import re
    
    test1 = VarsWithSources({'a': 1, 'b': 2, 'c': 3})
    assert sorted(test1.__iter__()) == ['a', 'b', 'c']
    
    test2 = {'a': 1, 'b': 2, 'c': 3}
    assert sorted(test2.__iter__()) == ['a', 'b', 'c']
    
    test3 = {'a': 1, 'b': 2, 'c': 3}
    assert len(test3.__iter__()) == 3
    
    test4 = VarsWithSources({'a': 1, 'b': 2, 'c': 3})
    
    assert test4
    
    del test4['b']
    
    assert test4

# Generated at 2022-06-21 09:39:52.378983
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # This is a UnitTester created with the right parameters by the test suite
    # pylint: disable=protected-access
    vars_manager = PlayContext(loader=None, options=None, passwords=None, connection=None)
    # pylint: enable=protected-access
    assert isinstance(vars_manager, PlayContext)

    assert vars_manager.get_vars(host=None, task=None, play=None) == {}

    vars_manager._extra_vars = dict(name2='value2', name3='value3')

    vars_manager.set_host_variable(host="test", varname="name1", value="value1")

    #TODO: implement this test
    #assert vars_manager.get_vars(host="test", task=None, play=None) ==

# Generated at 2022-06-21 09:40:01.151000
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    v = VariableManager()
    v.__setstate__({'_vars_cache': {'_nonpersistent_fact_cache': {}, '_fact_cache': {}}})
    v.__setstate__({'_vars_cache': {'_nonpersistent_fact_cache': {}, '_fact_cache': {}}})
    v.__setstate__({'_vars_cache': {'_nonpersistent_fact_cache': {}, '_fact_cache': {}}})


# Generated at 2022-06-21 09:40:13.166492
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Instantiate mock objects
    mock_loader_obj = MagicMock(name='loader')
    mock_inventory_obj = MagicMock(name='inventory')
    mock_options_obj = MagicMock(name='options')

    # Create variable manager
    var_mgr = VariableManager(loader=mock_loader_obj, inventory=mock_inventory_obj, options=mock_options_obj)
    var_mgr._fact_cache['host'] = {}
    var_mgr._nonpersistent_fact_cache['host'] = {}

    # Run tests
    var_mgr.set_nonpersistent_facts('host', {'abc': 123})
    assert var_mgr._nonpersistent_fact_cache['host'] == {'abc': 123}


# Generated at 2022-06-21 09:40:19.883149
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    dict_of_args = {
        'host_vars': {},
        'group_vars': {},
        'inventory': None,
        'options_vars': {},
        'version_info': {},
        'extra_vars': {},
        'play': None,
        'play_vars': {},
        'play_context': None,
        'task_vars': {},
        'host': None,
        'task': None,
        'loader': None,
        'variable_manager': None,
        'onlyif_vars': {},
        'when_vars': {},
        'omit_token': '__omit_place_holder__',
        'hash_behaviour': 'replace',
    }
    obj = VariableManager(**dict_of_args)
   

# Generated at 2022-06-21 09:40:25.225890
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    # create instance
    obj = VariableManager()

    # create arg
    arg = {}

    # test the call
    try:
        obj.__setstate__(arg)
        raise Exception('Expected a NotImplementedError')
    except NotImplementedError:
        pass


# Generated at 2022-06-21 09:40:37.071738
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources({"var1": 1, "var2": 2}, var1="var1 from __init__", var2="var2 from __init__")
    assert v.get_source("var1") == "var1 from __init__"
    assert v.get_source("var2") == "var2 from __init__"
    v["var3"] = 3
    assert v.get_source("var3") is None
    v2 = VarsWithSources.new_vars_with_sources(v, {"var1": "new source1", "var2": "new source2", "var3": "new source3"})
    assert v2.get_source("var1") == "new source1"
    assert v2.get_source("var2") == "new source2"

# Generated at 2022-06-21 09:40:48.338375
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # test case #1, with one host and one varname
    #
    # Prepare test
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    host = Host("testhost")
    group = Group("testgroup")
    group.add_host(host)
    fact_cache = dict()
    fact_cache["testhost"] = {"ansible_python_interpreter": "/usr/bin/python3", "ansible_facts": {"fact1": "value1"}}
    vars_cache = dict()
    loader = DataLoader()

    # Run test and verify results

# Generated at 2022-06-21 09:41:52.540647
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    '''
    Unit test for method clear_facts of class VariableManager
    '''
    import ansible_collections.ansible.community.plugins.module_utils.facts.system.distribution as distribution
    import ansible_collections.ansible.community.plugins.module_utils.facts.system.platform as platform
    import ansible_collections.ansible.community.plugins.module_utils.facts.system.machine as machine

    hostname = 'hostname'

    target = VariableManager()

    target.clear_facts(hostname)
    assert target.get_host_facts(hostname) == {}

    target._fact_cache[hostname] = {
        'distribution': distribution.DistributionFact(),
        'platform': platform.PlatformFact(),
        'machine': machine.MachineFact(),
    }
    target.clear_

# Generated at 2022-06-21 09:42:02.018952
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources({"a": 1, "b": 2})
    assert len(v.data) == 2
    assert v["a"] == 1
    assert v["b"] == 2
    assert len(v.sources) == 0
    assert v.get_source("a") == None

    v = VarsWithSources.new_vars_with_sources({"a": 1, "b": 2}, {"a": "a_source"})
    assert len(v.data) == 2
    assert v["a"] == 1
    assert v["b"] == 2
    assert len(v.sources) == 1
    assert v.get_source("a") == "a_source"

    v2 = v.copy()
    assert v2["a"] == 1
    assert v2["b"] == 2
   

# Generated at 2022-06-21 09:42:06.319155
# Unit test for function preprocess_vars
def test_preprocess_vars():
    # Valid input
    assert preprocess_vars(dict(foo='bar')) == [dict(foo='bar')]

    # Invalid input
    try:
        preprocess_vars(dict(foo=1, bar=2))
    except AnsibleError:
        pass
    else:
        assert False, "ansible.errors.AnsibleError was not raised"


# Generated at 2022-06-21 09:42:11.769302
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    x = VarsWithSources({'a': 1, 'b': 2, 'c': 3})
    values = x.data.values()
    i = iter(x)
    while True:
        try:
            x = next(i)
        except StopIteration:
            break
        else:
            assert x in values

# Generated at 2022-06-21 09:42:23.933400
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    host = "test_host"
    varname = "test_varname"
    value1 = "test_value1"
    value2 = "test_value2"

    # Setting a scalar variable
    vm.set_host_variable(host, varname, value1)
    assert vm._vars_cache[host][varname] == value1

    # Setting a variable already set to a scalar variable
    vm.set_host_variable(host, varname, value2)
    assert vm._vars_cache[host][varname] == value2

    # Setting a variable that is already set to a dict
    vm.set_host_variable(host, "dict", {"one": "two"})

# Generated at 2022-06-21 09:42:28.233862
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vmanager = VariableManager()
    host = "myhost"
    var_name = "var1"
    value1 = 1
    vmanager.set_host_variable(host, var_name, value1)
    assert vmanager._vars_cache[host][var_name] == "1"


# Generated at 2022-06-21 09:42:34.595584
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    dl = DataLoader()
    vm = VariableManager()
    with pytest.raises(AssertionError):
        vm.set_inventory(object())
    #TODO: setup test inventory content, see inventory/manager.py

    inventory = InventoryManager(loader=dl, sources=['localhost'])
    vm.set_inventory(inventory)
    #TODO: check results


# Generated at 2022-06-21 09:42:44.195089
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    my_loader = DictDataLoader({'host_vars/foo.yml': '---\nfoo: []'})
    my_inventory = InventoryManager(loader=my_loader, sources=['localhost,'])
    my_play = Play().load({'name': 'test_play', 'hosts': 'all', 'gather_facts': 'no'}, loader=my_loader, variable_manager=None)

    my_variable_manager = VariableManager(loader=my_loader, inventory=my_inventory)
    my_variable_manager.set_inventory(my_inventory)

    assert my_inventory.get_host('localhost') is not None

# Generated at 2022-06-21 09:42:47.016222
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    obj = VarsWithSources({"a":"1"})
    assert len(obj) == len({"a":"1"})

# Generated at 2022-06-21 09:42:57.155789
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    v = VariableManager()
    playbook = Playbook()
    playbook.vars = dict(foo='abc', bar=dict(key='value'))
    host = Host('localhost')
    host.vars = dict(foo='def', baz='xyz')
    task = Task()
    task.vars = dict(foo='ghi')
    task.action = dict(__ansible_module__='fake_module')
    fake_loader = DictDataLoader({
        'fake_module': 'some python'
    })
    fake_hostvars = dict(hostvar='hostvar_value', hostvar_override=dict(key='hostvar_override_value'))
    v.add_or_overwrite_vars(hostvars=fake_hostvars)
    v.add_or_overwrite_v

# Generated at 2022-06-21 09:43:57.467967
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    obj = VarsWithSources()
    data = dict()
    sources = dict()
    obj.sources = sources
    key = 0
    value = 1
    obj[key] = value
    assert data == obj.data


# Generated at 2022-06-21 09:44:05.171795
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    '''
    Unit test for method set_inventory of class VariableManager
    '''
    VariableManager = ansible.vars.VariableManager

    def test_add_host_to_cache(self, host):
        ''' mock '''

    # initialize a variable manager
    vms = VariableManager()
    vms.add_host_to_cache = MagicMock(name='add_host_to_cache', side_effect=test_add_host_to_cache)
    vms._need_host_fact_cache = True
    # initialize an inventory
    inv = ansible.inventory.Inventory('/dev/null')
    # initialize a host
    h = ansible.inventory.Host('test_host', port=22)
    h.set_variable('test_var', 'test_value')
    # add host to inventory

# Generated at 2022-06-21 09:44:17.540993
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    from copy import deepcopy
    data = dict(a=1, b=2, c=3)
    sources = dict(a='a', b='b', c='c')
    v = VarsWithSources.new_vars_with_sources(data, sources)
    assert v.sources == sources
    assert v.data == data
    v2 = v.copy()
    assert v2.sources == sources
    assert v2.data == data
    v.sources['zz'] = 'zz'
    v.data[1] = 'zz'
    assert v2.sources == sources
    assert v2.data == data
    v2.sources['yy'] = 'yy'
    v2.data['yy'] = 'yy'

# Generated at 2022-06-21 09:44:22.081465
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # set up required objects for the constructor
    loader = DictDataLoader(dict())
    variable_manager = VariableManager()
    options_vars = dict()

    # call the constructor
    variable_manager = VariableManager(loader=loader, inventory=None, options_vars=options_vars)

    # create a new host object
    host = Host(name="test_host")

    # create a new task object
    task = Task()

    # create a new dict to use as a play object
    play = dict(hosts="test_host")

    # call the function with args
    retval = variable_manager.get_vars(host=host, task=task, play=play)

    # assert that the return value is correct

# Generated at 2022-06-21 09:44:24.897308
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    v1 = VariableManager()
    v2 = VariableManager()
    v1.__setstate__(v2.__getstate__())
    assert v1 == v2



# Generated at 2022-06-21 09:44:31.456494
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    from collections import deque
    from collections import Counter

    input_data = {'a':1, 'b':2, 'c':3}
    input_sources = {'a':'cache', 'b':'inventory', 'c':'set_host_var'}
    vws = VarsWithSources.new_vars_with_sources(input_data, input_sources)

    expected_order = deque(['a', 'b', 'c'])
    actual_order = deque()

    for k in vws:
        actual_order.append(k)

    assert expected_order == actual_order


# Generated at 2022-06-21 09:44:33.122143
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    v = VariableManager()
    r = v.__getstate__()

# Generated at 2022-06-21 09:44:44.911461
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():

    v1 = VarsWithSources()
    v1['a'] = {'b': {'c': '1'}}
    v1['d'] = 'd'
    v1['e'] = {'f': {'g': []}}
    v1.sources['a'] = 'a.yml'
    v1.sources['d'] = 'd.yml'
    v1.sources['e'] = 'e.yml'

    # Test iter of VarsWithSources
    assert sorted(list(v1.__iter__())) == sorted(['a', 'd', 'e'])

    # Test iter of dict
    v2 = v1.copy()
    del v2['e']
    assert sorted(list(v2.__iter__())) == sorted(['a', 'd'])
   

# Generated at 2022-06-21 09:44:47.203383
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    var_mgr = VariableManager()
    var_mgr.set_inventory()
    assert var_mgr._inventory == None


# Generated at 2022-06-21 09:44:53.384785
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    v = VarsWithSources()
    v["key1"] = "value1"
    assert "key1" in v
    assert "value1" == v["key1"]
    v["key2"] = "value2"
    assert "key2" in v
    assert "value2" == v["key2"]
    del v["key1"]
    assert "key1" not in v
    assert "key2" in v
    assert "value2" == v["key2"]

# Generated at 2022-06-21 09:45:54.842978
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    datum = dict(
        k1=dict(
            a=1,
            b='b',
            c='c'
        )
    )
    sources = dict(
        k1=dict(
            a='s1',
            b='s1',
            c='s2'
        )
    )
    vws = VarsWithSources.new_vars_with_sources(datum, sources)
    assert vws.get_source('k1') is None
    assert vws.get_source('k1.a') == 's1'
    assert vws.get_source('k1.b') == 's1'
    assert vws.get_source('k1.c') == 's2'

# Generated at 2022-06-21 09:46:05.699272
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources({'a': 1, 'b': 2, 'c': 3})
    v['a'] = 4
    assert v['a'] == 4
    assert 'a' in v
    v['d'] = 5
    assert v['d'] == 5
    assert 'd' in v
    del v['d']
    assert not 'd' in v
    keys = list(v)
    assert sorted(keys) == ['a', 'b', 'c']
    assert len(v) == 3
    v2 = v.copy()
    assert v == v2
    assert v2 is not v
    v2['e'] = 6
    assert v2['e'] == 6
    assert 'e' in v2
    assert not 'e' in v
    assert v.get('a') == 4
    assert v

# Generated at 2022-06-21 09:46:10.510993
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():

    # Arrange
    # Create a variable manager
    variable_manager = VariableManager()

    # Act
    # Set the nonpersistent facts
    variable_manager.set_nonpersistent_facts('localhost', {'my_fact': 'my_fact_value'})

    # Assert
    # Make sure the nonpersistent facts exist
    assert variable_manager.get_vars(host=Host('localhost'))['my_fact'] == 'my_fact_value'


# pylint: disable=no-member

# Generated at 2022-06-21 09:46:17.798700
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    # Given
    data = {'name': 'vaulted'}
    sources = {'name': 'ansible-vault'}
    v = VarsWithSources.new_vars_with_sources(data, sources)
    
    # When
    v2 = v.copy()

    # Then
    assert v2 is not v
    assert v2.data is not v.data
    assert v2.sources is not v.sources


# vim:set expandtab shiftwidth=4 tabstop=4:

# Generated at 2022-06-21 09:46:26.274891
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    v = VariableManager() # what is the init?
    h = Host(name = 'localhost')
    v.set_host_variable(host=h, varname="test", value=['a', 1, {'b': 2}])
    vars = v.get_vars(host=h)
    assert vars['test'] == ['a', 1, {'b': 2}]
    vars = v.get_vars(host=h, include_hostvars=True)
    assert v.get_host_vars(host=h) == ['a', 1, {'b': 2}] # get_host_vars method exists?
    #TODO: test more, test with play
    #return  is this required?
    return True



# Generated at 2022-06-21 09:46:28.582988
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    vmanager = VariableManager()
    vmanager.__setstate__(VariableManager.__newobj__())


# Generated at 2022-06-21 09:46:29.997282
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    data = dict()
    assert len(VarsWithSources(data)) == len(data)

# Generated at 2022-06-21 09:46:35.058176
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources()
    v['x'] = 'y'
    v['a'] = 'b'
    v.sources['x'] = 'test'
    v.sources['a'] = 'othertest'
    v.__setitem__('z', 'w')
    v.__delitem__('x')
    assert v['a'] == 'b'
    assert 'a' in v
    assert len(v) == 2
    v = v.copy()
    assert v.get_source('a') == 'othertest'


# Generated at 2022-06-21 09:46:40.106413
# Unit test for method __setstate__ of class VariableManager

# Generated at 2022-06-21 09:46:46.002675
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    key = 'test'
    value = 'value'
    source = 'somesource'
    v = VarsWithSources.new_vars_with_sources({key: value}, {key: source})
    assert isinstance(v, VarsWithSources)
    assert isinstance(v.data, dict)
    # test that the __getitem__ gives us the correct key and value
    assert v[key] == value
    assert v.data[key] == value
    assert v.get_source(key) == source
