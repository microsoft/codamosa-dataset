

# Generated at 2022-06-21 09:38:28.264496
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''
    test to check the construction of the VariableManager object
    '''
    v = VariableManager()

# Generated at 2022-06-21 09:38:38.947721
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    from collections import Counter
    from io import StringIO
    from ansible.errors import AnsibleError
    # Test function for method __getitem__ of class VarsWithSources
    class TestVarsWithSources(VarsWithSources):
        def __init__(self):
            self.data = {}
            self.sources = {}

        def __getitem__(self, key):
            val = self.data[key]
            return val

        def __setitem__(self, key, value):
            self.data[key] = value

    capture_stdout = StringIO()
    display.debug = lambda x: capture_stdout.write(x + u'\n')

    testobj = TestVarsWithSources()

# Generated at 2022-06-21 09:38:40.339987
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-21 09:38:42.262948
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    # TODO: create mock objects for use in the following unit tests
    raise NotImplementedError

# Generated at 2022-06-21 09:38:50.127755
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext

    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # Create a host object and set host_name as it is done in ansible
    host = Host(name="test_host")
    host.set_variable("ansible_host", "127.0.0.1")

    # Create a data loader object and use it to create a templar object
    data_loader = DataLoader()
    templar = Templar(loader=data_loader)

    # Create a VariableManager object and set the templar object as it is done in ansible
    variable_manager = VariableManager()


# Generated at 2022-06-21 09:38:57.498890
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    # Test creating and clearing of facts
    # Due to the size of the module and the dependency on inventory and loader,
    # we mock out the module here and require that all the methods get called by
    # the dependent module.

    # create a loader
    fake_play_source = dict(
        name='fake_play',
        hosts=['host1', 'host2'],
        gather_facts='no',
        connection='smart',
        vars=dict(a=1, b=2),
        tasks=[
            dict(action=dict(module='setup'))
        ]
    )
    loader = DataLoader()
    loader.set_basedir(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))

# Generated at 2022-06-21 09:38:59.064670
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    variable_manager = VariableManager()
    variable_manager.clear_facts('test_host')


# Generated at 2022-06-21 09:39:00.312816
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    variable_manager = VariableManager()
    variable_manager.clear_facts()

# Generated at 2022-06-21 09:39:06.328469
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    a = VarsWithSources({'a': '1'})
    a['b'] = '2'
    a.get_source('a')
    a.get_source('b')
    assert a.get_source('c') is None
    assert a == {'a': '1', 'b': '2'}


# Tests for the combined vars function

# Generated at 2022-06-21 09:39:08.419082
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager.get_vars()

# Generated at 2022-06-21 09:39:35.407172
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
	# Testing VariableManager.clear_facts()

	# Create a fixture for the VariableManager class
	varManager = VariableManager()

	# TODO: Catch any exceptions that may be thrown by this method
	varManager.clear_facts()


# Generated at 2022-06-21 09:39:36.671077
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    v = VarsWithSources()
    assert v.get_source('boo') == None

# Generated at 2022-06-21 09:39:44.540869
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    v1 = VarsWithSources()
    v1.data = {'a': '1'}
    v1.sources = {'a': 'VarFile'}
    v2 = v1.copy()
    assert (v1 == v2)
    v1['a'] = '2'
    v2['a'] = '3'
    assert (v1['a'] == '2')
    assert (v2['a'] == '3')


# Generated at 2022-06-21 09:39:45.964186
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    vm = VariableManager()
    args = {}
    vm.__getstate__(args)

# Generated at 2022-06-21 09:39:53.118427
# Unit test for constructor of class VariableManager
def test_VariableManager():

    groups = dict(
        group1=set(['host1', 'host2']),
        group2=set(['host3'])
    )
    inventory = Inventory(host_list=[])
    inventory.add_group(Group('group1'))
    inventory.add_group(Group('group2'))
    inventory.get_group('group1').add_host(Host(name='host1'))
    inventory.get_group('group1').add_host(Host(name='host2'))
    inventory.get_group('group2').add_host(Host(name='host3'))
    # set host-vars
    inventory.get_group('group1').get_host('host1').vars = {'var1': 'val1'}

# Generated at 2022-06-21 09:39:59.986059
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    import pytest
    from ansible.vars import VariableManager

    vm = VariableManager()

    # Test with too few args
    with pytest.raises(TypeError):
        vm.clear_facts()

    # Test with insufficient values for args
    with pytest.raises(AnsibleAssertionError):
        vm.clear_facts('')


# Generated at 2022-06-21 09:40:11.126230
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    #  make test variables
    ansible = Ansible()

    #  make test objects
    host = ansible.inventory.get_host("localhost")
    variable_manager = VariableManager(loader=ansible.loader)

    #  add facts to cache
    facts = dict()
    facts['test_fact'] = 'test_fact_value'
    variable_manager.set_host_facts(host.name, facts)
    assert(variable_manager._fact_cache['localhost']['test_fact'] == 'test_fact_value')

    #  clear facts from cache
    variable_manager.clear_facts("localhost")
    assert('localhost' not in variable_manager._fact_cache)



# Generated at 2022-06-21 09:40:17.392165
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    from ansible.vars import VariableManager
    from collections import MutableMapping

    varManager = VariableManager()
    host = 'hostname'
    facts = dict(foo="bar")
    varManager.set_nonpersistent_facts(host, facts)
    nonPersistentFactCache = varManager._nonpersistent_fact_cache
    assert host in nonPersistentFactCache
    assert nonPersistentFactCache[host] is not None
    assert isinstance(nonPersistentFactCache[host], MutableMapping)
    assert nonPersistentFactCache[host]["foo"] == "bar"


# Generated at 2022-06-21 09:40:19.557309
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    # This is a fake method with no real code.  It is purely to pass pylint.
    assert True


# Generated at 2022-06-21 09:40:31.854485
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():

    # Create new instance
    v = VariableManager()

    # Default state
    state = {'_fact_cache': {}, '_host_cache': {}, '_nonpersistent_fact_cache': {}, '_inventory': None, '_loader': None, '_options_vars': {}, '_vars_cache': {}, '_hostvars': {}, '_omit_token': None}

    # Check v._fact_cache is same as state['_fact_cache']
    assert v._fact_cache == state['_fact_cache']

    # Check v._host_cache is same as state['_host_cache']
    assert v._host_cache == state['_host_cache']

    # Check v._nonpersistent_fact_cache is same as state['_nonpersistent_fact_cache']
    assert v._

# Generated at 2022-06-21 09:41:29.508492
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    class FakeSource(object):
        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return self.name

    class FakeProxy(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __repr__(self):
            return repr((self.args, self.kwargs))

    # Test construction with dict
    v = VarsWithSources({ 'foo': 'bar' })
    assert v['foo'] == 'bar'
    assert v['foo'] == 'bar'
    assert 'foo' in v

    # Test construction with kwargs
    v = VarsWithSources(foo='bar')
    assert v['foo'] == 'bar'
    assert v['foo']

# Generated at 2022-06-21 09:41:33.344085
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    argspec = inspect.getargspec(VariableManager.set_nonpersistent_facts)
    assert len(argspec.args) == 3
    assert argspec.defaults == (None,)
    assert argspec.varargs == None
    assert argspec.keywords == None

# Generated at 2022-06-21 09:41:36.489612
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    inventory_obj = Mock()
    variable_manager_obj = VariableManager()
    variable_manager_obj.set_inventory(inventory_obj)
    assert variable_manager_obj._inventory == inventory_obj


# Generated at 2022-06-21 09:41:39.701403
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    assert VarsWithSources({'x':2}, {'x':'hostvars'})['x'] == 2,\
        ''' method __setitem__ of class VarsWithSources
            should assign '''


# Generated at 2022-06-21 09:41:50.038967
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    display.debug("")
    display.debug("TESTING: VarsWithSources.__setitem__()")

    var = VarsWithSources()
    var.data["X"] = "Y"
    if var.data["X"] != "Y":
        raise AssertionError("Expected 'X' to be equal to 'Y' but they aren't")

    # Test that passing a mapping to the constructor works
    var = VarsWithSources({"foo": "bar"})
    if var.data["foo"] != "bar":
        raise AssertionError("Expected 'foo' to be equal to 'bar' but they aren't")

    # Test the alternate constructor
    sources = {"source": "this module"}
    var = VarsWithSources.new_vars_with_sources({"foo": "bar"}, sources)
   

# Generated at 2022-06-21 09:41:55.936309
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts('foo', {'ansible_local': {'existing_data': 1}})
    variable_manager.set_nonpersistent_facts('foo', {'ansible_local': {'new_data': 2}})
    assert variable_manager.get_nonpersistent_facts('foo') == {'ansible_local': {'existing_data': 1, 'new_data': 2}}


# Generated at 2022-06-21 09:41:58.159631
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():

    vws = VarsWithSources({'k1': 'v1'})
    assert(list(vws) == ['k1'])


# Generated at 2022-06-21 09:42:07.270641
# Unit test for function preprocess_vars
def test_preprocess_vars():
    # Test with None
    assert preprocess_vars(None) is None

    # Test with a dictionary
    d = {'foo': 'bar'}
    assert preprocess_vars(d) == [d]

    # Test with a list
    l = [d, d]
    assert preprocess_vars(l) == l

    # Test with a int
    assert preprocess_vars(1) == [1]

    # Test with a string
    assert preprocess_vars("") == [""]

    # Test with something else (should raise an error)
    from ansible.errors import AnsibleError
    try:
        preprocess_vars(object)
        assert not "Does not raise AnsibleError"
    except AnsibleError:
        # Needed, since the code must raise something to work
        pass




# Generated at 2022-06-21 09:42:20.917222
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    host = 'localhost'
    fact_cache = {'localhost' : {'fact_key' : 'fact_value'}}
    fact_cache_populated = {'localhost' : {'fact_key_populated' : 'fact_value_populated'}}
    nonpersistent_fact_cache = {'localhost' : {'nonpersistent_key' : 'nonpersistent_value'}}
    nonpersistent_fact_cache_populated = {'localhost' : {'nonpersistent_key_populated' : 'nonpersistent_value_populated'}}
    variable_manager = VariableManager()
    variable_manager.set_host_facts(host, fact_cache)
    variable_manager.set_nonpersistent_facts(host, nonpersistent_fact_cache)

# Generated at 2022-06-21 09:42:28.462821
# Unit test for function preprocess_vars
def test_preprocess_vars():
    assert preprocess_vars(None) is None
    assert preprocess_vars(dict()) == [dict()]
    assert preprocess_vars([dict()]) == [dict()]
    try:
        preprocess_vars(dict(a=1, b=2))
        raise Exception('should have raised error')
    except AnsibleError:
        pass
    try:
        preprocess_vars([dict(a=1, b=2), 'test'])
        raise Exception('should have raised error')
    except AnsibleError:
        pass



# Generated at 2022-06-21 09:44:49.874951
# Unit test for constructor of class VariableManager
def test_VariableManager():
    from ansible.plugins import vars
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars


    v = VariableManager()
    assert isinstance(v.get_vars(loader=None, play=None, host=None, task=None), dict)

    plugin_vars = vars.__all__
    assert plugin_vars == v.vars_plugins

    assert isinstance(v._vars_cache, dict)
    assert isinstance(v._fact_cache, HostVars)
    assert isinstance(v._nonpersistent_fact_cache, HostVars)

    assert v._inventory is None
    assert v._loader is None
    assert v._omit_token is None

    assert v._options_vars is None
    assert v._extra

# Generated at 2022-06-21 09:44:53.181946
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources(
        hello='world',
        abc='def',
        foo='bar',
    )
    v.sources = {
        'hello': 'foobar',
        'abc': 'baz',
    }



# Generated at 2022-06-21 09:44:54.395298
# Unit test for constructor of class VariableManager
def test_VariableManager():
    assert VariableManager() is not None


###############################################################################


# Generated at 2022-06-21 09:45:05.455017
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from collections import MutableMapping
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault_password_file = os.path.join(DATA_PATH, 'test_vault.key')
    loader = DataLoader()
    vault_secrets = VaultLib(vault_password_file)
    inventory = InventoryManager(loader=loader, sources=[os.path.join(DATA_PATH, 'inventory_with_vault')])

# Generated at 2022-06-21 09:45:10.560921
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    # Test for method copy.
    # Creation of the object
    v = VarsWithSources({'a':'b'}, c = 'd')
    v.sources = {'a':'b'}
    v.sources['c'] = 'd'

    # Execution of the method to be tested
    clone_v = v.copy()

    # Tests
    assert v.data == clone_v.data
    assert v.sources == clone_v.sources


# Generated at 2022-06-21 09:45:14.002346
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    var_mgr = VariableManager()
    inv = Inventory(loader=None,host_list=['host1','host2'])
    var_mgr.set_inventory(inv)
    assert(var_mgr.inventory == inv)

# Generated at 2022-06-21 09:45:19.070170
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    instance = VarsWithSources({'one':1, 'two':2})
    instance.sources = {'one':'sources', 'two':None}
    result = instance.copy()
    assert result == {'one':1, 'two':2}
    assert result.sources == {'one':'sources', 'two':None}
    assert result.get_source('one') == 'sources'
    assert result.get_source('two') == None


# Generated at 2022-06-21 09:45:27.461559
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    vars = dict(a=1, b='b', c=[1, 2, 3]) # data, stores values
    sources = dict(a='group_vars/all', b='playbook/roles/rolename/vars/main.yml') # sources, stores sources of variables
    vars_with_sources = VarsWithSources.new_vars_with_sources(vars, sources)
    assert vars_with_sources['a'] == 1, '__getitem__ should return the value of the key from data'
    assert vars_with_sources['b'] == 'b', '__getitem__ should return the value of the key from data'
    assert vars_with_sources['c'] == [1, 2, 3], '__getitem__ should return the value of the key from data'
   

# Generated at 2022-06-21 09:45:30.187184
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    test_data = {"foo": "bar", "baz": "qux"}
    Vars = VarsWithSources.new_vars_with_sources(test_data, None)
    try:
        for key in Vars:
            assert key in test_data
    except:
        assert False

# Generated at 2022-06-21 09:45:38.242548
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''Unit test for constructor of class VariableManager'''

    v = VariableManager()
    assert v is not None

    # Test invalid inventory
    with pytest.raises(AssertionError):
        v = VariableManager(inventory=1)
    v = VariableManager(inventory=Inventory("localhost"))
    assert v is not None

    # Test invalid loader
    with pytest.raises(AssertionError):
        v = VariableManager(loader=1)
    v = VariableManager(loader=DictDataLoader())
    assert v is not None
