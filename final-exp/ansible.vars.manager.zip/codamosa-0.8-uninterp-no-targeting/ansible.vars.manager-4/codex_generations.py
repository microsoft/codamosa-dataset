

# Generated at 2022-06-21 09:38:22.889432
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources({1:2, 3:4}, {1: 'from top level', 3: 'from top level'})
    assert v.get_source(1) == 'from top level'
    assert v.get_source(3) == 'from top level'
    v[5] = 6
    assert v.get_source(5) is None
    assert v[1] == 2
    assert v[3] == 4
    assert v[5] == 6
    assert v.data[1] == 2
    assert v.data[3] == 4
    assert v.data[5] == 6
    v1 = v.copy()
    assert v1 is not v
    assert v1.data is not v.data
    assert v1.sources is not v.sources
    assert v1.data == v

# Generated at 2022-06-21 09:38:30.306307
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    """
    Make sure that a VarsWithSources instance is properly copied with all its data.

    We create a simple VarsWithSources, clone it, modify the cloned instance, then check
    that the original instance is unmodified, which would be the case if a "real" copy
    had been made.
    """
    initial_data = {'foo': 'bar'}
    initial_sources = {'foo': 'vault'}
    vs = VarsWithSources.new_vars_with_sources(initial_data, initial_sources)

    cloned_vs = vs.copy()

    cloned_vs['foo'] = 'baz'

    assert vs['foo'] == 'bar'
    assert vs.sources['foo'] == 'vault'



# Generated at 2022-06-21 09:38:37.577498
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    v = VarsWithSources({'host1': {'foo': 'bar'}})
    c = v.copy()
    c['host1']['foo'] = 'baz'
    assert v['host1']['foo'] == 'bar'
    v['host1']['foo'] = 'baz'
    assert c['host1']['foo'] == 'baz'
    v['host1'] = 'bar'
    assert c['host1']['foo'] == 'baz'



# Generated at 2022-06-21 09:38:40.273192
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    s = VarsWithSources()
    c = s.copy()
    assert len(s) == len(c)
    assert s.get("foo") == c.get("foo")
    s["foo"] = "bar"
    c = s.copy()
    assert s.get("foo") == c.get("foo")
    c = s.copy()
    assert s is not c
    assert s.data is not c.data
    assert s.sources is not c.sources



# Generated at 2022-06-21 09:38:45.558882
# Unit test for constructor of class VariableManager
def test_VariableManager():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    source = dict(foo='bar', some_file='my_file')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    assert variable_manager._vars == dict(foo='bar', some_file='my_file')

# Generated at 2022-06-21 09:38:47.119618
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    variable_manager = VariableManager()
    variable_manager.set_inventory(None)


# Generated at 2022-06-21 09:38:52.230270
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    """
    Test case for copy() of VarsWithSources
    """
    v = VarsWithSources()
    v['a']='A'
    v['b']='B'
    v.sources['a']='source_a'
    v.sources['b']='source_b'
    v2 = v.copy()
    assert v2.data == v.data
    assert v2.sources == v.sources
    v2['a']='a'
    v.sources['c']='source_c'
    assert v.data != v2.data
    assert v2.sources != v.sources


# Generated at 2022-06-21 09:38:58.890124
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    '''
    Unit test for method __len__ of class VarsWithSources
    '''
    obj = VarsWithSources()
    assert len(obj) == 0
    obj["a"] = 1
    assert len(obj) == 1
    obj["b"] = 2
    assert len(obj) == 2
    obj["a"] = 3
    assert len(obj) == 2
    del obj["b"]
    assert len(obj) == 1
    del obj["a"]
    assert len(obj) == 0

# Generated at 2022-06-21 09:39:00.660604
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()
    assert variable_manager is not None

# Unit Test for add_host_variables of class VariableManager

# Generated at 2022-06-21 09:39:07.927264
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    # Empty dict
    t = VarsWithSources()
    assert t.get_source('toto') is None

    # Uses sources dict
    t = VarsWithSources.new_vars_with_sources(dict(var1=1,var2=2), dict(var1='inventory'))
    assert t.get_source('var1') == 'inventory'
    assert t.get_source('var2') is None
    assert t.get_source('var3') is None


# Generated at 2022-06-21 09:40:03.797192
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    vars = dict(a=1, b=2, c=3)
    sources = dict(a='a_source', b='b_source', c='c_source')
    v = VarsWithSources.new_vars_with_sources(vars, sources)
    assert v.get_source('b') == 'b_source'



# Generated at 2022-06-21 09:40:12.766290
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    vars = VarsWithSources({'a': 1, 'b': 2}, {'a': 'task'})
    assert vars['a'] == 1
    assert vars['b'] == 2
    assert vars.get_source('a') == 'task'
    assert vars.get_source('b') is None
    # The dict-like constructor should not allow specifying sources
    vars = VarsWithSources({'a': 1, 'b': 2}, {'a': 'task'}, {'a': 'other source'})
    assert vars.get_source('a') is None


# Generated at 2022-06-21 09:40:24.595913
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''
    This function is a unit test for the constructor of the class VariableManager()
    '''

    # pylint: disable=unused-argument,redefined-outer-name,unused-variable
    @mock.patch.object(VariableManager, '_set_inventory')
    @mock.patch.object(VariableManager, '_set_play_basedir')
    def test_constructor(self, mock_set_play_basedir, mock_set_inventory):
        '''
        This function is a unit test for the constructor of the class VariableManager()
        '''

        # pylint: disable=unused-variable
        loader = DictDataLoader({})
        inventory = mock.Mock()
        play = mock.Mock()

        # Constructor of class VariableManager()
        my_var_mgr

# Generated at 2022-06-21 09:40:27.851284
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    v = VarsWithSources()
    for a in range(0, 100):
        v['a'] = a
    for i in v:
        assert i == 'a'


# Generated at 2022-06-21 09:40:32.540248
# Unit test for constructor of class VariableManager
def test_VariableManager():
    a = VariableManager(loader=BaseLoader())
    assert isinstance(a._fact_cache, MutableMapping)
    assert a._fact_cache == dict()
    assert isinstance(a._vars_cache, MutableMapping)
    assert a._vars_cache == dict()

# Generated at 2022-06-21 09:40:36.607032
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    v = VarsWithSources({'a': '1'})
    assert 'a' in v
    assert 'b' not in v

    v.data['b'] = '2'
    assert 'b' in v


# Generated at 2022-06-21 09:40:38.805052
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    var = VarsWithSources({'one':1})
    assert [i for i in var] == ['one']



# Generated at 2022-06-21 09:40:47.754997
# Unit test for function preprocess_vars
def test_preprocess_vars():
    assert preprocess_vars(None) is None
    assert preprocess_vars({'a': 1}) == [{'a': 1}]
    assert preprocess_vars([{'a': 1}, {'b': 2}]) == [{'a': 1}, {'b': 2}]
    raises(AnsibleError, preprocess_vars, 1)
    raises(AnsibleError, preprocess_vars, [1, 2])
    raises(AnsibleError, preprocess_vars, ['a', 1])



# Generated at 2022-06-21 09:40:51.022513
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():

    variable_manager = VariableManager()

    variable_manager.__setstate__()

    # No return value
    raise AnsibleAssertionError("__setstate__ has no return value")

# Generated at 2022-06-21 09:40:58.106402
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
	# Set up test environment
	variableManager = VariableManager(loader=None, inventory=None)
	_inventory = None

	# Execute the method with valid arguments
	variableManager.set_inventory(_inventory)

	# Execute the method with invalid arguments
	assert_raises(AnsibleAssertionError, variableManager.set_inventory, None)

	# Execute the method with invalid arguments
	assert_raises(AnsibleAssertionError, variableManager.set_inventory, 1)

	# Execute the method with invalid arguments
	assert_raises(AnsibleAssertionError, variableManager.set_inventory, "")


# Generated at 2022-06-21 09:41:47.053419
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    vm = VariableManager()
    inventory = dict()

    vm.set_inventory(inventory)
    assert vm._inventory == dict()


# Generated at 2022-06-21 09:41:55.858701
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Instantiate VariableManager
    vm = VariableManager()

    # Define test variables
    host = "localhost"
    varname = "XYZ"
    value = {'a':'b', 'c': 'd'}

    # Code to execute
    vm.set_host_variable(host, varname, value)

    # Assertions
    assert vm._vars_cache[host][varname] == value


    # Instantiate VariableManager
    vm2 = VariableManager()

    # Define test variables
    host2 = "localhost"
    varname2 = "XYZ"
    value2 = ['a','b','c','d']

    # Code to execute
    vm2.set_host_variable(host2, varname2, value2)

    # Assertions
    assert vm2._vars_cache

# Generated at 2022-06-21 09:41:57.375260
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    assert_raises(AssertionError, VariableManager().clear_facts)


# Generated at 2022-06-21 09:42:06.770002
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    import unittest
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.inventory import Inventory

    inventory = Inventory()

    inventory.add_host(inventory.Host('localhost', port=0))
    inventory.add_host(inventory.Host('127.0.0.1'))
    inventory.add_host(inventory.Host('test.example.com'))
    inventory.add_host(inventory.Host('example.com'))
    inventory.add_host(inventory.Host('test.example.com', port=1234))

    vm = VariableManager()
    vm.set_inventory(inventory)
    assert len(vm._vars_per_host) == 5

    assert len(vm.get_vars(host='localhost')) == 2

# Generated at 2022-06-21 09:42:20.727821
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    a = VarsWithSources()
    b = a.copy()
    assert a.data == b.data
    assert a.sources == b.sources

    a.data["k"] = "value"
    a.sources["k"] = "sources"
    b = a.copy()
    assert a.data == b.data
    assert a.sources == b.sources

    b.data["k"] = "value-b"
    b.sources["k"] = "sources-b"
    assert a.data != b.data
    assert a.sources != b.sources

    c = VarsWithSources({"k-c": "value-c"})
    d = c.copy()
    c.sources["k-c"] = "sources-c"

# Generated at 2022-06-21 09:42:27.974405
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    '''
    [running_tests][running_tests][running_tests][running_tests][running_tests][running_tests]
    '''
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    variable_manager = VariableManager()
    variable_manager.add_group_vars(group = "all", vars = {'ansible_group_vars': {'my_var': 'my_value'}})
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    host = Host('host_test')

# Generated at 2022-06-21 09:42:37.453216
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    from ansible.vars.manager import VariableManager
    from ansible.vars.manager import VariableManagerError
    import mock

    # A test oracle to decide if we are working on mutable mapping or not
    def _is_mutable_mapping(host):
        if host == 'host1':
            return True
        else:
            return False

    # A test oracle for combine_vars method
    def _combine_vars(a, b):
        if b['var'] == 'test':
            a['test1'], a['test2'] = b['test1'], b['test2']
        else:
            a[b['var']] = b[b['var']]
        return a

    # validate default behaviour of the set_host_variable method
    # Defaults:
    # _vars_

# Generated at 2022-06-21 09:42:49.534872
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    vars = dict(one=1, two=2)
    sources = dict(one='foo')
    v = VarsWithSources.new_vars_with_sources(vars, sources)
    vcopy = v.copy()

    assert vars is not vcopy
    assert vars == vcopy
    assert vars.keys() == vcopy.keys()
    assert vars.values() == vcopy.values()
    assert vars.items() == vcopy.items()

    # Even though sources is a reference to a dict, we expect it to be copied
    # as a new dict when copying VarsWithSources
    sources['one'] = 'changed'
    assert 'changed' == sources['one']
    assert 'foo' == vcopy.get_source('one')

    vars['one'] = 'one'

# Generated at 2022-06-21 09:42:56.484824
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    v = VariableManager()
    v._vars_cache = {'test':{'test2':{'test3':{'test4':'test5'}}}}
    v.set_host_variable('test', 'test2', {'test3':{'test6':'test7'}})
    v.set_host_variable('test', 'test2', {'test9':'test8'})
    v.set_host_variable('testtt', 'testtt', 'testttt')
    print(v._vars_cache)



# Generated at 2022-06-21 09:43:06.266871
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    host = 'localhost'
    varname = 'environment'
    valuemap = {'foo': 'bar', 'boo': 'far'}
    vm.set_host_variable(host, varname, valuemap)
    assert vm._vars_cache['localhost'] == valuemap


    valuemap = {'foo': 'boo'}
    vm.set_host_variable(host, varname, valuemap)
    # only keys that are common between value and valuemap are updated
    assert vm._vars_cache['localhost'] == {'foo': 'boo', 'boo': 'far'}


    vm.set_host_variable(host, varname, 'foo')

# Generated at 2022-06-21 09:44:25.553356
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    result = VarsWithSources()
    assert result.data == {}

    result = VarsWithSources({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'},
                             {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    assert result.data == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    assert result.sources == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

    del result['key2']
    assert result.data == {'key1': 'value1', 'key3': 'value3'}

# Generated at 2022-06-21 09:44:37.152127
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    Test get_vars method of class VariableManager
    TODO: Test all the paths through this method (should be fairly easy)
    '''
    # Setup
    variable_manager = VariableManager()
    variable_manager._vars_cache = {'hostname': {'var': 'value'}}
    variable_manager._inventory = MagicMock()
    variable_manager._inventory.get_host.return_value = host = MagicMock()
    host.get_name.return_value = 'hostname'
    variable_manager._loader = MagicMock()
    variable_manager._options_vars = {'option_var': 'option_value'}
    variable_manager._omit_token = '__omit_place_holder__variablemanager'

# Generated at 2022-06-21 09:44:45.696126
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    v = VarsWithSources({"blah": "blah"}, {"blah": "something"})
    v2 = v.copy()
    v2.data["blah"] = "something_else"
    assert v.data["blah"] == "blah"
    assert v2.data["blah"] == "something_else"
    v2.sources["blah"] = "something_else"
    assert v.sources["blah"] == "something"
    assert v2.sources["blah"] == "something_else"
    assert isinstance(v2, VarsWithSources)



# Generated at 2022-06-21 09:44:51.335279
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    """ Tests "get_vars" method of the class "VariableManager" """
    print("Test 1: //- get_vars -//")
    loader = Loader()
    inventory = InventoryManager(loader=loader, sources='localhost')
    play1 = Play.load(dict(
        hosts=['localhost'],
        name='test play'
    ), loader=loader, variable_manager=VariableManager(loader=loader, inventory=inventory))
    task1 = Task()
    result = VariableManager().get_vars(play=play1, task=task1)

# Generated at 2022-06-21 09:44:59.123150
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    """
    Check if get_source function in class VarsWithSources works correct
    """
    m = VarsWithSources({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    m.sources = {'a': "hostvars", 'c': "task"}
    assert m.get_source('a') == "hostvars"
    assert m.get_source('b') == None
    assert m.get_source('c') == "task"
    assert m.get_source('d') == None

# Generated at 2022-06-21 09:45:08.382738
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources({'a': 1, 'b': 2, 'c': 3}, {'a': 'source1', 'd': 'source2'})

    # Make sure constructor set keys and values as expected
    assert ['a', 'b', 'c'] == sorted(v.keys())
    assert [1, 2, 3] == sorted(v.values())

    # Make sure sources were set as expected
    assert v.sources == {'a': 'source1', 'd': 'source2'}

    # Make sure non-existent keys return None as source
    assert v.get_source('x') is None

    # Make sure accessing a key returns the correct value, and makes debug message
    with patch.object(display, 'debug') as mock_debugger:
        assert v['a'] == 1

# Generated at 2022-06-21 09:45:10.369505
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # This method has no unit tests at this time
    pass

# Generated at 2022-06-21 09:45:17.200607
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    v = VariableManager(loader=DictDataLoader({}))
    h = 'fakehost'
    f = {'test1':1}
    v.set_host_facts(host=h, facts=f)
    assert v.get_vars(host=None)['hostvars'][h] == f
    f2 = {'test2':2}
    v.set_host_facts(host=h, facts=f2)
    assert v.get_vars(host=None)['hostvars'][h] == f2



# Generated at 2022-06-21 09:45:22.229889
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    my_vars = VarsWithSources({"ak":"av"})
    ak_vars = my_vars.get("ak")
    # _vars_with_sources_test_temp_value = ak_vars._vars_with_sources_test_temp_value
    # assert _vars_with_sources_test_temp_value == 'av'
    assert ak_vars == 'av'

# Generated at 2022-06-21 09:45:24.710561
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vm = VariableManager()
    facts = dict(a=1, b=2)
    host = 'host1'
    vm.set_nonpersistent_facts(host, facts)
    assert vm.nonpersistent_fact_cache == {'host1': {'a': 1, 'b': 2}}

# Generated at 2022-06-21 09:47:18.514557
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    myvar_manager = VariableManager()
    myvar_manager.clear_facts()


# Generated at 2022-06-21 09:47:28.972960
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
# Expect None
    # testing for map being of the correct class
    assert issubclass(class_to_test , MutableMapping) , "class_to_test does not inherit from MutableMapping"
# Expect None
    # testing for map being of the correct class
    assert issubclass(class_to_test , Mapping) , "class_to_test does not inherit from Mapping"
# Expect None
    # testing for map being of the correct class
    assert issubclass(class_to_test , MappingView) , "class_to_test does not inherit from MappingView"
# Expect None
    # testing for map being of the correct class
    assert issubclass(class_to_test , ItemsView) , "class_to_test does not inherit from ItemsView"
# Expect None
    # testing for map being of the correct

# Generated at 2022-06-21 09:47:37.316737
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    '''
    Make sure the .copy() method makes a deep copy of the underlying data
    '''
    v = VarsWithSources({'a': 1})
    v['b'] = 2
    v2 = v.copy()
    v['a'] = 3
    # Make sure the copy is unaffected by the change to the original
    assert v['a'] == 3
    assert v2['a'] == 1
    # Make sure the copy behaves like the original
    assert len(v) == 2
    assert len(v2) == 2
    # Make sure changing the copy doesn't change the original
    v2['b'] = 3
    assert v['b'] == 2
    assert v2['b'] == 3

