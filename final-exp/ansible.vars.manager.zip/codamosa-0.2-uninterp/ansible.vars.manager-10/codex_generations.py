

# Generated at 2022-06-17 16:07:40.136240
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test with default values
    v = VariableManager()
    assert v.get_vars() == {}
    assert v.get_vars(include_hostvars=True) == {}
    assert v.get_vars(include_delegate_to=True) == {}
    assert v.get_vars(include_hostvars=True, include_delegate_to=True) == {}
    assert v.get_vars(host=None) == {}
    assert v.get_vars(host=None, include_hostvars=True) == {}
    assert v.get_vars(host=None, include_delegate_to=True) == {}
    assert v.get_vars(host=None, include_hostvars=True, include_delegate_to=True) == {}
    assert v.get

# Generated at 2022-06-17 16:07:48.644975
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Test constructor of class VariableManager
    vm = VariableManager()
    assert vm._fact_cache == dict()
    assert vm._vars_cache == dict()
    assert vm._nonpersistent_fact_cache == dict()
    assert vm._hostvars == dict()
    assert vm._options_vars == dict()
    assert vm._omit_token == '__omit_place_holder__'
    assert vm._inventory == None
    assert vm._loader == None
    assert vm._tqm == None


# Generated at 2022-06-17 16:07:51.224160
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # TODO: write unit test for method get_vars of class VariableManager
    pass


# Generated at 2022-06-17 16:08:00.585504
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Test with no inventory and no loader
    vm = VariableManager()
    assert vm._inventory is None
    assert vm._loader is None
    assert vm._fact_cache == dict()
    assert vm._vars_cache == dict()
    assert vm._nonpersistent_fact_cache == dict()
    assert vm._host_cache == dict()
    assert vm._omit_token == '__omit_place_holder__'
    assert vm._options_vars == dict()

    # Test with inventory and loader
    inventory = InventoryManager(loader=DictDataLoader())
    loader = DataLoader()
    vm = VariableManager(loader=loader, inventory=inventory)
    assert vm._inventory == inventory
    assert vm._loader == loader
    assert vm._fact_cache == dict()
    assert vm._vars_cache == dict()

# Generated at 2022-06-17 16:08:09.666153
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    '''
    Unit test for method set_host_facts of class VariableManager
    '''
    # Create a mock object
    mock_host = MagicMock()
    mock_facts = MagicMock()
    # Create an instance of VariableManager
    variable_manager = VariableManager()
    # Call the method with the mock objects
    variable_manager.set_host_facts(mock_host, mock_facts)
    # Check if the method set_host_facts of class VariableManager was called with the mock objects
    variable_manager.set_host_facts.assert_called_with(mock_host, mock_facts)

# Generated at 2022-06-17 16:08:14.134236
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vm = VariableManager()
    vm.set_nonpersistent_facts('host1', {'fact1': 'value1'})
    vm.set_nonpersistent_facts('host1', {'fact2': 'value2'})
    assert vm._nonpersistent_fact_cache['host1'] == {'fact1': 'value1', 'fact2': 'value2'}


# Generated at 2022-06-17 16:08:21.976139
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Test with a valid host and facts
    vm = VariableManager()
    host = 'test_host'
    facts = {'test_fact': 'test_value'}
    vm.set_nonpersistent_facts(host, facts)
    assert vm._nonpersistent_fact_cache[host] == facts
    # Test with an invalid host
    vm = VariableManager()
    host = 'test_host'
    facts = {'test_fact': 'test_value'}
    vm.set_nonpersistent_facts(host, facts)
    assert vm._nonpersistent_fact_cache[host] == facts
    # Test with an invalid facts
    vm = VariableManager()
    host = 'test_host'
    facts = 'test_value'

# Generated at 2022-06-17 16:08:33.148126
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Setup
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsV2
    from ansible.vars.hostvars import HostVarsV1
    from ansible.vars.hostvars import HostVarsV0
    from ansible.vars.hostvars import HostVarsLegacy
    from ansible.vars.hostvars import HostVarsFile
    from ansible.vars.hostvars import HostVarsFileV2
    from ansible.vars.hostvars import HostVarsFileV1

# Generated at 2022-06-17 16:08:39.823211
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    '''
    Unit test for method set_host_facts of class VariableManager
    '''
    # Create a mock inventory
    inventory = create_autospec(InventoryManager)

    # Create a mock loader
    loader = create_autospec(DataLoader)

    # Create a mock options
    options = create_autospec(Options)

    # Create a mock host
    host = create_autospec(Host)

    # Create a mock facts
    facts = create_autospec(Mapping)

    # Create a mock host_cache
    host_cache = create_autospec(MutableMapping)

    # Create a mock host_cache
    host_cache = create_autospec(MutableMapping)

    # Create a mock host_cache
    host_cache = create_autospec(MutableMapping)

# Generated at 2022-06-17 16:08:49.962948
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Test with no inventory
    vm = VariableManager()
    assert vm._inventory is None
    assert vm._loader is None
    assert vm._fact_cache == dict()
    assert vm._vars_cache == dict()
    assert vm._nonpersistent_fact_cache == dict()
    assert vm._host_vars_files == dict()
    assert vm._group_vars_files == dict()
    assert vm._omit_token == '__omit_place_holder__'
    assert vm._options_vars == dict()
    assert vm._hostvars == dict()
    assert vm._extra_vars == dict()
    assert vm._play_vars == dict()
    assert vm._play_context is None
    assert vm._task_vars == dict()
    assert vm._task_include_vars == dict()


# Generated at 2022-06-17 16:09:24.181091
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVarsVarsVarsVars

# Generated at 2022-06-17 16:09:34.402184
# Unit test for constructor of class VariableManager
def test_VariableManager():
    v = VariableManager()
    assert v._fact_cache == dict()
    assert v._vars_cache == dict()
    assert v._nonpersistent_fact_cache == dict()
    assert v._omit_token == '__omit_place_holder__'
    assert v._options_vars == dict()
    assert v._inventory is None
    assert v._loader is None
    assert v._hostvars is None
    assert v._extra_vars == dict()
    assert v._play_context is None
    assert v._task_vars == dict()
    assert v._run_context is None
    assert v._run_context_vars == dict()
    assert v._run_context_vars_cache == dict()
    assert v._delegated_vars == dict()
    assert v._delegated_

# Generated at 2022-06-17 16:09:36.553672
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    vm.set_host_variable("host", "varname", "value")
    assert vm._vars_cache["host"]["varname"] == "value"


# Generated at 2022-06-17 16:09:49.869505
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test with a host that is not in the vars_cache
    vm = VariableManager()
    vm.set_host_variable('host1', 'varname1', 'value1')
    assert vm._vars_cache['host1']['varname1'] == 'value1'

    # Test with a host that is in the vars_cache
    vm = VariableManager()
    vm._vars_cache['host1'] = {'varname1': 'value1'}
    vm.set_host_variable('host1', 'varname2', 'value2')
    assert vm._vars_cache['host1']['varname1'] == 'value1'
    assert vm._vars_cache['host1']['varname2'] == 'value2'

    # Test with a host that is

# Generated at 2022-06-17 16:09:56.309076
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test with no arguments
    v = VariableManager()
    assert v.get_vars() == {'omit': '__omit_place_holder__'}
    # Test with a host
    h = Host(name='testhost')
    assert v.get_vars(host=h) == {'omit': '__omit_place_holder__', 'inventory_hostname': 'testhost', 'inventory_hostname_short': 'testhost'}
    # Test with a host and a task
    t = Task()
    assert v.get_vars(host=h, task=t) == {'omit': '__omit_place_holder__', 'inventory_hostname': 'testhost', 'inventory_hostname_short': 'testhost'}
    # Test with a host and a task and a play
   

# Generated at 2022-06-17 16:09:59.440568
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''
    Unit test for constructor of class VariableManager
    '''
    variable_manager = VariableManager()
    assert variable_manager is not None


# Generated at 2022-06-17 16:10:03.743964
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Create a new instance of VariableManager
    variable_manager = VariableManager()

    # Create a new instance of Host
    host = Host()

    # Create a new instance of dict
    facts = dict()

    # Call the method set_nonpersistent_facts of VariableManager
    variable_manager.set_nonpersistent_facts(host, facts)


# Generated at 2022-06-17 16:10:10.789116
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Test with a non-mapping type for facts
    # This should raise an exception
    v = VariableManager()
    facts = 'not a mapping'
    host = 'test_host'
    with pytest.raises(AnsibleAssertionError):
        v.set_nonpersistent_facts(host, facts)

    # Test with a mapping type for facts
    # This should not raise an exception
    facts = dict()
    v.set_nonpersistent_facts(host, facts)
    assert v._nonpersistent_fact_cache[host] == facts


# Generated at 2022-06-17 16:10:15.747127
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test with no args
    v = VariableManager()
    assert v.get_vars() == {}

    # Test with args
    v = VariableManager()
    assert v.get_vars(play=None, host=None, task=None, include_delegate_to=False, include_hostvars=True) == {}


# Generated at 2022-06-17 16:10:23.292070
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Create a mock inventory
    inventory = mock.MagicMock()
    inventory.get_groups_dict.return_value = dict()
    inventory.get_hosts.return_value = []
    inventory.get_host.return_value = None

    # Create a mock loader
    loader = mock.MagicMock()
    loader.get_basedir.return_value = '.'

    # Create a mock play
    play = mock.MagicMock()
    play.get_name.return_value = 'test_play'
    play.hosts = 'all'
    play.roles = []
    play.finalized = False

    # Create a mock task
    task = mock.MagicMock()
    task.loop = None
    task.loop_with = None
    task.delegate_to = None
    task.action

# Generated at 2022-06-17 16:11:02.147160
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # setup
    vm = VariableManager()
    vm._vars_cache = {'host1': {'var1': 'val1'}}
    vm._nonpersistent_fact_cache = {'host1': {'var2': 'val2'}}
    vm._fact_cache = {'host1': {'var3': 'val3'}}
    vm._hostvars = {'host1': {'var4': 'val4'}}
    vm._options_vars = {'var5': 'val5'}
    vm._omit_token = 'omit'
    vm._loader = DictDataLoader({'host1': {'var6': 'val6'}})
    vm._inventory = MagicMock()

# Generated at 2022-06-17 16:11:05.852839
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test for method set_host_variable(self, host, varname, value)
    # Returns: None
    # Raises: None
    # This method is not tested as it is a setter method
    pass


# Generated at 2022-06-17 16:11:15.002985
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Test with no inventory
    vm = VariableManager()
    assert vm._inventory is None
    assert vm._loader is None
    assert vm._fact_cache == dict()
    assert vm._vars_cache == dict()
    assert vm._nonpersistent_fact_cache == dict()
    assert vm._omit_token == '__omit_place_holder__'
    assert vm._options_vars == dict()
    assert vm._hostvars == dict()

    # Test with inventory
    inventory = InventoryManager(loader=None, sources=None)
    vm = VariableManager(loader=None, inventory=inventory)
    assert vm._inventory == inventory
    assert vm._loader is None
    assert vm._fact_cache == dict()
    assert vm._vars_cache == dict()
    assert vm._nonpersistent_fact_cache == dict

# Generated at 2022-06-17 16:11:26.806622
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Test with no inventory
    vm = VariableManager()
    assert vm._inventory is None
    assert vm._loader is None
    assert vm._fact_cache == dict()
    assert vm._vars_cache == dict()
    assert vm._nonpersistent_fact_cache == dict()
    assert vm._hostvars == dict()
    assert vm._options_vars == dict()
    assert vm._omit_token == '__omit_place_holder__'

    # Test with inventory
    inventory = Inventory(host_list=[])
    vm = VariableManager(inventory=inventory)
    assert vm._inventory == inventory
    assert vm._loader is None
    assert vm._fact_cache == dict()
    assert vm._vars_cache == dict()
    assert vm._nonpersistent_fact_cache == dict()
    assert vm._hostv

# Generated at 2022-06-17 16:11:37.586974
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Create a mock object for the inventory
    inventory = mock.Mock()
    inventory.get_host.return_value = None
    inventory.get_hosts.return_value = []
    inventory.get_groups_dict.return_value = {}

    # Create a mock object for the loader
    loader = mock.Mock()
    loader.get_basedir.return_value = 'basedir'

    # Create a mock object for the options
    options = mock.Mock()
    options.vars = []

    # Create a mock object for the play
    play = mock.Mock()
    play.hosts = None
    play.finalized = False
    play.roles = []
    play.get_name.return_value = 'play_name'

    # Create a mock object for the task

# Generated at 2022-06-17 16:11:50.118264
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Test the constructor of class VariableManager
    #
    # create a variable manager
    variable_manager = VariableManager()
    #
    # check that the variable manager is empty
    assert len(variable_manager._fact_cache) == 0
    assert len(variable_manager._vars_cache) == 0
    assert len(variable_manager._extra_vars) == 0
    assert len(variable_manager._hostvars) == 0
    assert len(variable_manager._nonpersistent_fact_cache) == 0
    assert len(variable_manager._options_vars) == 0
    assert variable_manager._inventory is None
    assert variable_manager._loader is None
    assert variable_manager._omit_token is None
    assert variable_manager._use_fact_cache is True
    assert variable_manager._use_task_facts is True

# Generated at 2022-06-17 16:11:58.247577
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test with a simple inventory
    inventory = InventoryManager(loader=None, sources=['localhost,'])
    host = inventory.get_host(hostname='localhost')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variables = variable_manager.get_vars(host=host)
    assert variables['inventory_hostname'] == 'localhost'
    assert variables['inventory_hostname_short'] == 'localhost'
    assert variables['group_names'] == ['all']
    assert variables['groups'] == {'all': {'hosts': ['localhost'], 'vars': {}}}
    assert variables['omit'] == '__omit_place_holder__'
    assert variables['play_hosts'] == ['localhost']
    assert variables['ansible_play_hosts'] == ['localhost']

# Generated at 2022-06-17 16:12:09.672505
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Test with empty inventory
    variable_manager = VariableManager()
    assert variable_manager._inventory is None
    assert variable_manager._loader is None
    assert variable_manager._fact_cache == dict()
    assert variable_manager._vars_cache == dict()
    assert variable_manager._nonpersistent_fact_cache == dict()
    assert variable_manager._omit_token == '__omit_place_holder__'
    assert variable_manager._options_vars == dict()

    # Test with inventory
    inventory = Inventory(loader=DictDataLoader())
    variable_manager = VariableManager(loader=None, inventory=inventory)
    assert variable_manager._inventory == inventory
    assert variable_manager._loader is None
    assert variable_manager._fact_cache == dict()
    assert variable_manager._vars_cache == dict()


# Generated at 2022-06-17 16:12:12.030390
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager.get_vars()


# Generated at 2022-06-17 16:12:23.051803
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Create a mock object for the inventory
    inventory = mock.Mock()
    inventory.get_hosts.return_value = []
    inventory.get_groups_dict.return_value = {}
    # Create a mock object for the loader
    loader = mock.Mock()
    loader.get_basedir.return_value = '.'
    # Create a mock object for the play
    play = mock.Mock()
    play.hosts = 'all'
    play.get_name.return_value = 'test_play'
    play.roles = []
    # Create a mock object for the task
    task = mock.Mock()
    task.loop = None
    task.loop_with = None
    task.loop_control = None
    task.delegate_to = None

# Generated at 2022-06-17 16:13:21.662519
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test with no parameters
    vm = VariableManager()
    vm.get_vars()
    # Test with a host
    vm = VariableManager()
    vm.get_vars(host=Host(name='testhost'))
    # Test with a play
    vm = VariableManager()
    vm.get_vars(play=Play())
    # Test with a task
    vm = VariableManager()
    vm.get_vars(task=Task())
    # Test with a host, play, and task
    vm = VariableManager()
    vm.get_vars(host=Host(name='testhost'), play=Play(), task=Task())
    # Test with a host, play, and task, and include_hostvars
    vm = VariableManager()

# Generated at 2022-06-17 16:13:23.267941
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 16:13:34.143379
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test with no args
    v = VariableManager()
    v.get_vars()
    # Test with args
    v = VariableManager()
    v.get_vars(play=None, host=None, task=None, include_delegate_to=False, include_hostvars=False)
    # Test with kwargs
    v = VariableManager()
    v.get_vars(play=None, host=None, task=None, include_delegate_to=False, include_hostvars=False)
    # Test with args and kwargs
    v = VariableManager()
    v.get_vars(play=None, host=None, task=None, include_delegate_to=False, include_hostvars=False)

# Generated at 2022-06-17 16:13:35.343030
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # TODO: Implement test
    pass


# Generated at 2022-06-17 16:13:49.281520
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test with host not in vars_cache
    vm = VariableManager()
    vm.set_host_variable('host1', 'varname1', 'value1')
    assert vm._vars_cache['host1']['varname1'] == 'value1'
    # Test with host in vars_cache
    vm = VariableManager()
    vm._vars_cache['host1'] = dict()
    vm.set_host_variable('host1', 'varname1', 'value1')
    assert vm._vars_cache['host1']['varname1'] == 'value1'
    # Test with host in vars_cache and varname in vars_cache[host]
    vm = VariableManager()
    vm._vars_cache['host1'] = dict()
    vm._vars_cache

# Generated at 2022-06-17 16:13:56.742344
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Create a variable manager
    variable_manager = VariableManager()

    # Create a host
    host = Host(name='testhost')

    # Create a play
    play = Play()

    # Create a task
    task = Task()

    # Create a role
    role = Role()

    # Create a variable
    variable = Variable()

    # Get the variables
    variables = variable_manager.get_vars(host=host, play=play, task=task, role=role, variable=variable)

    # Check that the variables are correct

# Generated at 2022-06-17 16:14:03.147280
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test with host not in vars_cache
    vm = VariableManager()
    vm.set_host_variable('host1', 'varname1', 'value1')
    assert vm._vars_cache == {'host1': {'varname1': 'value1'}}

    # Test with host in vars_cache, varname not in vars_cache[host]
    vm = VariableManager()
    vm._vars_cache = {'host1': {'varname2': 'value2'}}
    vm.set_host_variable('host1', 'varname1', 'value1')
    assert vm._vars_cache == {'host1': {'varname2': 'value2', 'varname1': 'value1'}}

    # Test with host in vars_cache, varname in

# Generated at 2022-06-17 16:14:08.471570
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test with a host that is not in the vars_cache
    vm = VariableManager()
    vm.set_host_variable('host1', 'varname1', 'value1')
    assert vm._vars_cache['host1']['varname1'] == 'value1'

    # Test with a host that is in the vars_cache
    vm = VariableManager()
    vm._vars_cache['host2'] = {'varname2': 'value2'}
    vm.set_host_variable('host2', 'varname2', 'value3')
    assert vm._vars_cache['host2']['varname2'] == 'value3'

    # Test with a host that is in the vars_cache and a varname that is not
    vm = VariableManager()
    vm._v

# Generated at 2022-06-17 16:14:11.830519
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test for method set_host_variable(host, varname, value)
    # Returns: None
    # Raises: None
    # This method is not tested because it is not used by any other method.
    pass


# Generated at 2022-06-17 16:14:17.125809
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test with no arguments
    # Test with a single argument
    # Test with multiple arguments
    # Test with a single argument and a single keyword argument
    # Test with multiple arguments and a single keyword argument
    # Test with a single argument and multiple keyword arguments
    # Test with multiple arguments and multiple keyword arguments
    pass


# Generated at 2022-06-17 16:16:21.352505
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Create a mock object for the class 'Host'
    mock_host = mock.Mock(spec=Host)
    # Create a mock object for the class 'VariableManager'
    mock_variable_manager = mock.Mock(spec=VariableManager)
    # Create a mock object for the class 'Mapping'
    mock_mapping = mock.Mock(spec=Mapping)
    # Create a mock object for the class 'MutableMapping'
    mock_mutable_mapping = mock.Mock(spec=MutableMapping)
    # Create a mock object for the class 'MutableMapping'
    mock_mutable_mapping_2 = mock.Mock(spec=MutableMapping)
    # Create a mock object for the class 'Mapping'

# Generated at 2022-06-17 16:16:30.833720
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Create a mock object for the inventory
    mock_inventory = MagicMock()
    mock_inventory.get_host.return_value = None
    mock_inventory.get_hosts.return_value = []

    # Create a mock object for the loader
    mock_loader = MagicMock()
    mock_loader.get_basedir.return_value = None

    # Create a mock object for the options
    mock_options = MagicMock()
    mock_options.connection_plugins = []
    mock_options.shell_executable = None
    mock_options.module_lang = None
    mock_options.module_set_locale = None
    mock_options.module_compression = None
    mock_options.module_preferred_cache = None
    mock_options.module_preferred_new_cache = None
    mock