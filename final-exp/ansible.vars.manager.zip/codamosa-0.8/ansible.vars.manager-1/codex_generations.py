

# Generated at 2022-06-11 19:04:04.152644
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_mgr = VariableManager()
    var_mgr.set_host_variable("127.0.0.1", "foo", "bar")
    assert var_mgr.get_vars(host=None, include_hostvars=True)["hostvars"]["127.0.0.1"]["foo"] == "bar"


    foo_bar_target = {"host": "127.0.0.1", "path": "baz/bar"}
    var_mgr.set_host_variable("127.0.0.1", "foo_bar_target", foo_bar_target)
    assert var_mgr.get_vars(host=None, include_hostvars=True)["hostvars"]["127.0.0.1"]["foo_bar_target"] == foo_

# Generated at 2022-06-11 19:04:15.377152
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    v = VariableManager()
    v.set_host_variable('hostname','ansible_connection','ssh')
    v.set_host_variable('hostname','ansible_user','root')
    v.set_host_variable('hostname','ansible_ssh_pass','123456')
    v.set_host_variable('hostname','ansible_become_pass','123456')
    v.set_host_variable('hostname','ansible_ssh_port','22')
    v.set_host_variable('hostname','ansible_ssh_host','127.0.0.1')
    v.set_host_variable('hostname','ansible_python_interpreter','/usr/bin/python')

# Generated at 2022-06-11 19:04:25.817948
# Unit test for constructor of class VariableManager
def test_VariableManager():

    from ansible.plugins.loader import vault_manager
    vault_pass = vault_manager.get_vault_secret('foobar')

    # Test the creation of a VariableManager object
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}

    # Test defaults
    assert variable_manager.options_vars == dict()
    assert variable_manager.options_vars_files is None

    variable_manager.options_vars_files = []
    variable_manager.vault_password = vault_pass

    assert 'ansible_playbook_python' in variable_manager.options_vars
    assert variable_manager.options_vars['ansible_playbook_python'] == sys.executable

    # Test the __repr__() method

# Generated at 2022-06-11 19:04:28.738627
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    vm = VariableManager()
    factsdict = dict()
    set_nonpersistent_facts(host,factsdict)
    set_host_facts(host,factsdict)

# Generated at 2022-06-11 19:04:34.800639
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    ''' Check the behaviour of method __getitem__ of VarsWithSources '''
    data = {'a_key': 'a_value'}
    sources = {'a_key': 'a_source'}
    vars_with_sources = VarsWithSources.new_vars_with_sources(data, sources)
    assert vars_with_sources.data['a_key'] == 'a_value'
    assert vars_with_sources['a_key'] == 'a_value'


# Generated at 2022-06-11 19:04:46.937747
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Assumes that the VariableManager class is not implemented.
    # It will fail if the class is implemented, but doesn't have a get_vars() method.
    VariableManager.get_vars
    # TODO: write this test.
    # We need to test everything except the "cache" side of the method.  That is:
    # - the setting of ansible_* variables
    # - the setting of the 'hostvars' variable
    # - the setting of the 'groups' variable
    # - the setting of the 'role_names' variable
    # - the setting of the 'omit' variable
    # - the setting of the 'role_path' variable
    # - the setting of the 'role_uuid' variable
    # - the setting of the 'ansible_colleciton_name' variable
    # - the setting of

# Generated at 2022-06-11 19:04:57.683534
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    class MockHost(object):

        def __init__(self, name, facts=None, vars=None):
            self.name = name
            self.vars = vars or {}
            self.facts = facts or {}
            self.get_vars = self.get_vars_dict
            self.get_name = self.get_host_name

        get_host_name = getattr(Host, 'get_name')

        def set_variable(self, varname, value):
            self.vars[varname] = value

        def get_vars_dict(self):
            return self.vars

        def get_vars_files(self):
            return []

    class MockInventory(object):

        def __init__(self, groups_dict):
            self.groups = groups_dict

       

# Generated at 2022-06-11 19:05:06.575308
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_manager=VariableManager()
    host = 'host'
    varname = 'varname'
    value = 'value'
    var_manager.set_host_variable(host, varname, value)
    assert var_manager._vars_cache[host][varname] == value

    var_manager._vars_cache[host][varname] = {'key': 'value'}
    value = {'key1': 'value1'}
    var_manager.set_host_variable(host, varname, value)
    assert var_manager._vars_cache[host][varname] == {'key': 'value', 'key1': 'value1'}


# Generated at 2022-06-11 19:05:11.009179
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    d = dict()
    v = VariableManager(loader=None)
    v.set_host_facts(host=None, facts=d)

    assert v.get_fact_cache() == d

    d['foo'] = 1
    v.set_host_facts(host=None, facts=d)

    assert v.get_fact_cache() == d


# Generated at 2022-06-11 19:05:19.865101
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    from collections import MutableMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import combine_vars
    from ansible.vars.manager import VariableManager

    manager=VariableManager()
    manager._vars_cache = {'remote': {'var1': {'var11': 'test11'}, 'var2': 'test2'}}
    host = 'remote'
    varname = 'var1'
    value = {'var12': 'test12'}
    # combine_vars is called
    manager.set_host_variable(host, varname, value)
    assert manager._vars_cache['remote']['var1']['var11'] == 'test11'

# Generated at 2022-06-11 19:05:56.893105
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from collections import defaultdict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.json_query import AnsibleJSONQuery
    from ansible.vars.clean import strip_internal_keys
    from ansible.vars.reserved import DEFAULT_ARGS, RESERVED_HASH_VALUES, ANSIBLE_NESTED_VARS_CONFIG, RES

# Generated at 2022-06-11 19:06:02.084684
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    pass

    # The variable host already exists in the variable cache, but shouldn't be set
    # because it is not a dict
    vm = VariableManager()
    vm._vars_cache = {'host': 'test_value'}
    vm.set_host_variable('host', 'test_varname', {'test':'dict'})
    assert vm._vars_cache['host'] == 'test_value'

    # The variable host already exists in the variable cache, and should be updated with the value as a dict
    vm = VariableManager()
    vm._vars_cache = {'host': 'test_value'}
    vm.set_host_variable('host', 'test_varname', {'test':'dict'})
    assert vm._vars_cache['host'] == 'test_value'

    vm = Variable

# Generated at 2022-06-11 19:06:03.341229
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # This is a test manual function
    pass



# Generated at 2022-06-11 19:06:07.429496
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    # ensure that __getitem__ works properly when get_source is called after __getitem__
    foo = VarsWithSources({'bar': 'baz'})
    foo.sources = {'bar': 'sample_source'}
    assert foo['bar'] == 'baz'
    assert foo.get_source('bar') == 'sample_source'


# Generated at 2022-06-11 19:06:08.552134
# Unit test for constructor of class VariableManager
def test_VariableManager():
    v = VariableManager()
    assert isinstance(v, VariableManager)

# Generated at 2022-06-11 19:06:15.592378
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    vars_cache_value = {'b': '2'}
    vm._vars_cache = {'a': vars_cache_value}

    # Test set_host_variable without traverse
    vm.set_host_variable('a', 'c', '3')
    assert vm._vars_cache['a']['c'] == '3'

    # Test set_host_variable with traverse
    vm.set_host_variable('a', 'c', {'d': '4'})
    assert vm._vars_cache['a']['c'] == {'d': '4'}

    # Test set_host_variable with traverse and nesting
    vm.set_host_variable('a', 'c', {'d': {'e': '5'}})
    assert vm._vars

# Generated at 2022-06-11 19:06:19.605884
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Verify that an object of class 'VariableManager' can be
    # instantiated with the following parameter values:
    # (1) inventory object, (2) play context object,
    # (3) variable manager object
    # The object being instantiated should be an object of class
    # 'VariableManager'.

    vmp = VariableManager()
    assert isinstance(vmp, VariableManager)
    assert vmp._fact_cache == {}
    assert vmp._nonpersistent_fact_cache == {}
    assert vmp._vars_cache == {}
    assert vmp._hostvars is None
    assert vmp._extra_vars == {}
    assert vmp._options_vars == {}
    assert vmp._omit_token == '__omit_place_holder__'

# Generated at 2022-06-11 19:06:28.361069
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    '''
    Unit test for method set_host_variable of class VariableManager
    '''
    vm = VariableManager()
    vm._fact_cache = {'localhost': {}}
    vm._nonpersistent_fact_cache = {'localhost': {}}
    vm._vars_cache = {'localhost': {}}
    vm.set_host_variable('localhost', 'varname', 'value')
    assert vm._vars_cache['localhost']['varname'] == 'value'



# Generated at 2022-06-11 19:06:31.779215
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # initialization
    var_manager = VariableManager()
    host = "host"
    facts = {
        "fact1": "value1"
    }
    # test
    var_manager.set_host_facts(host, facts)
    # assert
    assert var_manager._fact_cache[host] == facts



# Generated at 2022-06-11 19:06:34.061878
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'a': 'b'}, a='b')
    assert v['a'] == 'b'


# Generated at 2022-06-11 19:07:01.012715
# Unit test for constructor of class VariableManager
def test_VariableManager():
    pass


# Generated at 2022-06-11 19:07:06.843511
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-11 19:07:11.753032
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'a': 1, 'b': 2})
    v.sources = {'a': 'a source', 'b': 'b source'}
    with mock.patch('ansible.vars.hostvars.display.debug') as mock_debug:
        v['a']
        assert mock_debug.call_count == 1
        v['b']
        assert mock_debug.call_count == 2
        with pytest.raises(KeyError):
            v['c']

# Generated at 2022-06-11 19:07:23.441914
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    #########
    # Tests if get_vars returns a proper result when inventory is defined
    # 
    # testee = Method Under Test
    #   function entry point.
    # args = Arguments
    #   function arguments.
    # expected = Expected
    #   expected result.
    #
    # return value = Return
    #   expected == 
    #     Return == True
    #       test result.
    #     Return == False
    #       test result.
    #########

    # Setting up environment.
    testee = AnsibleModuleFake(
    ).get_instance(
        'ansible.plugins.action.copy',
        class_args=[
            'action',
            {
                'use_execute_instead_of_run': True,
            },
        ],
    )
    testee = testee

# Generated at 2022-06-11 19:07:30.656364
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    '''
    [ansible.vars.variable_manager#L225]
    :param facts: the facts to set
    :type  facts: dict
    '''
    test_manager = VariableManager()

    # first use the method to set some facts in the fact cache
    facts = dict(
        ansible_all_ipv4_addresses=[
            '192.168.1.1', '172.16.25.4'],
        ansible_all_ipv6_addresses=[
            'fe80::be70:dbff:fe96:4a3b', '2a01:4f8:171:1e7::2'],
        ansible_architecture='x86_64',
        ansible_date_time=dict(
            epoch='1522685632',
        ),
    )

# Generated at 2022-06-11 19:07:39.725903
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    from ansible.playbook.play_context import PlayContext
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from units.mock.path import mock_unfrackpath_noop
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.reserved import Reserved
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 19:07:49.137832
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    _fact_cache = dict()

    variable_manager = VariableManager()
    variable_manager._fact_cache = _fact_cache
    variable_manager.set_host_facts('host', {'ansible_all_ipv4_addresses': ['1.1.1.1']})
    variable_manager.set_host_facts('host', {'ansible_all_ipv4_addresses': ['2.2.2.2']})
    
    assert _fact_cache == {'host': {'ansible_all_ipv4_addresses': ['2.2.2.2']}}
    _fact_cache.clear()
    

# Generated at 2022-06-11 19:07:54.218576
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # When: set_nonpersistent_facts is invoked
    # Then: nonpersistent facts are stored
    v = VariableManager()
    v.set_nonpersistent_facts("host", {"key": "value"})
    assert v._nonpersistent_fact_cache["host"]["key"] == "value"

# Generated at 2022-06-11 19:07:59.319376
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources()
    v["foo"] = "bar"
    # Check that __getitem__ returns the value
    assert v["foo"] == "bar"

    # Check that __getitem__ does not modify other data
    assert v.sources == {}


# Generated at 2022-06-11 19:08:05.901509
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    varmanager= VariableManager()
    _hosts=[Host(name="host1")] #class Host
    _hostvars = varmanager._get_hostvars(_hosts=_hosts)

    _ds1 = from_yaml("""
    - hosts:
            - host1
    roles: []
    vars_files:
            - ../vars/common.yml
            - ../vars/common2.yml
    """)

    _ds = from_yaml("""
    - hosts:
            - host1
    roles: []
    """)

# Generated at 2022-06-11 19:09:04.547289
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    test the get_vars function of class VariableManager
    '''

    # create an instace of VariableManager
    variable_mgr = VariableManager()
    
    # create a variable named 'y'
    variable_mgr._vars = {'y': {'x': 10}}
    variable_mgr._omit_token = 'OMIT'
    variable_mgr._options_vars = {'z': 20}
    variable_mgr._hostvars = {'v1': {'x': 100}}
    
    # get the variable value by invoke get_vars function
    y_value = variable_mgr.get_vars(host=None)
    
    # check the value of variable y
    assert y_value['y'] == {'x': 10}


# Generated at 2022-06-11 19:09:06.586008
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    v = VariableManager()
    assert v.get_vars() == {}
test_VariableManager_get_vars()

# Generated at 2022-06-11 19:09:17.527109
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    options = dict(a='a', b='b')

    play = Play()
    play.set_loader(None)
    play.set_variable_manager(VariableManager(loader=None, inventory=None))
    play._hostvars = HostVars(loader=None, inventory=None)

    task = Task()
    task._role = None
    task._ds = dict()

    variable_manager = VariableManager(loader=None, inventory=None)

    variable_manager.set_inventory(inventory=Inventory(loader=None, variable_manager=variable_manager))
   

# Generated at 2022-06-11 19:09:26.639404
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Initialize a VariableManager object to test
    vm = VariableManager()
    def test(vm, host, task, play, include_delegate_to):
        # vm: the VariableManager object to test
        # host: a Host object
        # task: a Task object
        # play: a Play object
        # include_delegate_to: a boolean
        #
        # returns: the result of vm.get_vars() on the parameters
        return vm.get_vars(host, task, play, include_delegate_to)

    def test_host_vars_included(vm, host, task, play):
        return test(vm, host, task, play, True)


# Generated at 2022-06-11 19:09:32.895303
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    ansible_playbook = {
        "all": {
            "hosts": "all",
            "name": "all",
            "tasks": [
                {
                    "name": "test_playbook_task",
                    "tags": [],
                    "when": "test_playbook_fact != 'test'",
                    "with_items": [
                        "test_playbook_var1",
                        "test_playbook_var2"
                    ]
                }
            ]
        },
        "hosts": "all",
        "name": "test_playbook",
        "roles": [],
        "vars": {
            "test_playbook_var1": "test1",
            "test_playbook_var2": "test2"
        }
    }

# Generated at 2022-06-11 19:09:41.940702
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    # Create an instance of VarsWithSources
    vars_with_sources_obj = VarsWithSources()

    # Create a var
    var = "ansible_eth0"

    # This should just return None
    val = vars_with_sources_obj[var]
    assert val == None

    # This should display a debug message
    var_with_source = vars_with_sources_obj[var]
    assert var_with_source == None


if __name__ == '__main__':
    # Unit test area

    test_VarsWithSources___getitem__()

# Generated at 2022-06-11 19:09:48.354312
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-11 19:10:00.204714
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-11 19:10:03.070729
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager.get_vars()

# Generated at 2022-06-11 19:10:14.107331
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    variable_manager.set_host_variable('abc', 'abc', 'abc')
    assert variable_manager._vars_cache['abc']['abc'] == 'abc'
    variable_manager._vars_cache['abc'] = {}
    variable_manager.set_host_variable('abc', 'abc', {'abc': 'abc'})
    assert variable_manager._vars_cache['abc']['abc']['abc'] == 'abc'
    variable_manager._vars_cache['abc'] = {}
    variable_manager.set_host_variable('abc', 'abc', {'abc': {'abc': 'abc'}})
    assert variable_manager._vars_cache['abc'] == {'abc': {'abc': {'abc': 'abc'}}}



# Generated at 2022-06-11 19:11:48.770319
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-11 19:11:59.648651
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager.set_fact_cache(dict())
    variable_manager.set_vars_cache(dict())
    variable_manager.set_host_variable('localhost', 'ansible_connection', 'local')
    variable_manager.set_nonpersistent_facts('localhost', dict(ansible_facts=dict(ansible_all_ipv4_addresses=['127.0.0.1'])))
    variable_manager.set_nonpersistent_facts('localhost', dict(ansible_facts=dict(ansible_distribution='Ubuntu')))
    variable_manager.set_host_variable('localhost', 'ansible_python_interpreter', '/usr/bin/python3')

# Generated at 2022-06-11 19:12:04.846707
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    vm.set_host_variable("test-host", "ansible_distribution", "Ubuntu")
    result = vm.get_vars(host=Host("test-host"))
    if result['ansible_distribution'] == "Ubuntu":
        return True
    else:
        return False



# Generated at 2022-06-11 19:12:13.810805
# Unit test for constructor of class VariableManager
def test_VariableManager():

    #test_vms_init()

    # invalid options test
    #options = ImmutableDict(is_j2=True,vvv=True)
    #with pytest.raises(AnsibleAssertionError):
    #    VariableManager(loader=None, inventory=None, options=options)

    # invalid inventory test
    #with pytest.raises(AnsibleAssertionError):
    #    VariableManager(loader=None, inventory=1, options=None)

    # invalid loader test
    #with pytest.raises(AnsibleAssertionError):
    #    VariableManager(loader=1, inventory=None, options=None)

    with pytest.raises(AssertionError):
        VariableManager()

    # invalid options test

# Generated at 2022-06-11 19:12:25.048393
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    my_VariableManager = VariableManager()

    my_facts = dict()
    my_facts['my_fact1'] = 'my_fact1_value'
    my_facts['my_fact2'] = 'my_fact2_value'
    my_facts['my_fact3'] = 'my_fact3_value'
    my_facts['my_fact4'] = 'my_fact4_value'

    my_host = 'my_host_name'
    my_VariableManager.set_host_facts(my_host, my_facts)

    my_key = 'inventory_hostname_short'
    assert my_key in my_VariableManager._fact_cache[my_host]
    assert my_VariableManager._fact_cache[my_host][my_key] == 'my_host_name'


# Generated at 2022-06-11 19:12:35.038148
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    host_facts_dict = {
        "foo": "bar",
        "baz": "boo"
    }
    host_vars_dict = {
        "foo": "bar",
        "baz": "boo"
    }
    delegated_host_vars_dict = {
        "foo": "bar",
        "baz": "boo"
    }

    hostname = 'localhost'
    host = FakeHost(hostname)
    delegate_to = '127.0.0.1'
    delegated_host = FakeHost(delegate_to)
    delegated_host_name = delegated_host.get_name()
    delegated_host_variable_manager = FakeVariableManager(delegated_host_name, delegated_host_vars_dict)

# Generated at 2022-06-11 19:12:38.344743
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():                                 
    test_obj = VariableManager()                                    
                                                                    
                                                                    
    assert test_obj is not None

# Generated at 2022-06-11 19:12:45.495955
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''
    Test the constructor of the VariableManager class.
    :return:
    '''

    class AnsibleLoaderMock(BaseLoader):
        '''
        Mock loader class used in place of AnsibleLoader
        '''

    class HostMock(object):
        '''
        Mock host class used instead of Host.
        '''
        def __init__(self, name, address=''):
            '''
            The constructor for the Mock Host object.
            :param name: Name of the host.
            :param address: The address of the host.
            '''
            self.name = name
            self.address = address

    class InventoryMock(object):
        '''
        Mock inventory class used in place os Inventory.
        '''
        def __init__(self):
            self._hosts = dict()


# Generated at 2022-06-11 19:12:47.168128
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    v = VariableManager()
    # test count assertion


# Generated at 2022-06-11 19:12:53.195745
# Unit test for constructor of class VariableManager
def test_VariableManager():
    v = VariableManager()
    v.set_inventory(Inventory("localhost"))
    assert('inventory_hostname' in v.get_vars())
    assert(v.get_vars()['inventory_hostname'] == 'localhost')
    assert(v.get_vars(host=Host("localhost")) is v.get_vars())

    assert('inventory_hostname' not in v.get_vars(play=Play().load(dict(hosts='localhost'))))

# Unit tests for variable merging