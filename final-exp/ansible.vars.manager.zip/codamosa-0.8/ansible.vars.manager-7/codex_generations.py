

# Generated at 2022-06-11 19:03:31.474554
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
  host = "" 
  facts = "" 
  res = VariableManager.set_host_facts()
  assert res == ""




# Generated at 2022-06-11 19:03:39.247707
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    variable_manager.set_host_variable("localhost", "var1", {"a": 1, "b": 2})
    variable_manager.set_host_variable("localhost", "var1", {"c": 3})
    hostvars = variable_manager.get_vars(host=Host("localhost"))
    assert hostvars["var1"]['a'] == 1
    assert hostvars["var1"]['b'] == 2
    assert hostvars["var1"]['c'] == 3
    assert len(hostvars["var1"]) == 3


# Generated at 2022-06-11 19:03:46.331157
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    """Check the get_vars function of the variable manager."""
    variable_manager = VariableManager()
    variable_manager._nonpersistent_fact_cache = {
        'hostname': {
            'nonpersistent_var': 'nonpersistent_var'
        },
        # pylint: disable=bad-whitespace
        'hostname2': {
            'nonpersistent_var': 'nonpersistent_var'
        }
        # pylint: enable=bad-whitespace
    }
    variable_manager._vars_cache = {
        'hostname': {
            'other_var': 'other_var'
        },
        'hostname2': {
            'other_var': 'other_var'
        }
    }


# Generated at 2022-06-11 19:03:57.632667
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_manager = VariableManager(loader={}, inventory={}, version_info={})

    # Test with play = None, task = None, host = None,
    vars1 = var_manager.get_vars()
    assert vars1['omit'] == '__omit_place_holder__'
    assert vars1['ansible_version']['string'] == 'unknown'
    assert vars1['ansible_version']['full'] == 'unknown'

    # Test with task = None, host = None,
    play1 = C.Play()
    vars2 = var_manager.get_vars(play=play1)
    assert vars2['ansible_play_name'] == 'Pseudo Play'
    assert vars2['ansible_play_role_names'] == []

    # Test with host

# Generated at 2022-06-11 19:04:02.015278
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Arguments
    #constants.ZOMBIEHOST = 'ZOMBIEHOST'
    host = constants.ZOMBIEHOST
    facts = {'ZOMBIE': 'DEAD'}

    # Expansion
    vm = VariableManager()
    vm.set_nonpersistent_facts(host, facts)

    # Test
    assert vm._nonpersistent_fact_cache[host] == facts

# Generated at 2022-06-11 19:04:04.243725
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    assert True
    # raise NotImplementedError()


# Generated at 2022-06-11 19:04:15.451578
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    variable_manager._hostvars = {
        u"hostname": {
            u"var1": {
                u"1": 1,
                u"2": 2,
            },
            u"var2": {
                u"3": 3,
                u"4": 4,
            },
        }
    }

    variable_manager.set_host_variable("hostname", "var1", {
        u"2": 3,
        u"4": 4,
    })


# Generated at 2022-06-11 19:04:26.231547
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    mgr = VariableManager()
    try:
        mgr.set_host_facts(None, None)
        assert False
    except TypeError:
        pass

    try:
        mgr.set_host_facts('localhost', dict())
        assert False
    except TypeError:
        pass

    try:
        mgr.set_host_facts(None, dict())
        assert False
    except TypeError:
        pass

    try:
        mgr.set_host_facts('localhost', None)
        assert False
    except TypeError:
        pass

    try:
        mgr.set_host_facts('localhost', 5)
        assert False
    except TypeError:
        pass

    try:
        mgr.set_host_facts('localhost', 5)
        assert False
    except TypeError:
        pass

# Generated at 2022-06-11 19:04:31.398547
# Unit test for constructor of class VariableManager
def test_VariableManager():
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    assert variable_manager._inventory == inventory

    facts = {'a': 'b'}
    variable_manager.set_host_facts(host='localhost', facts=facts)
    assert variable_manager._fact_cache['localhost'] == facts



# Generated at 2022-06-11 19:04:38.006275
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test that Method VariableManager.set_host_variable can successfully set the value of variables in the self._vars_cache dictionary
    # GIVEN: A VariableManager object
    var_manager = VariableManager()
    # WHEN: I call the set_host_variable method to set the value of a variable in the self._vars_cache dictionary
    var_manager.set_host_variable("192.168.1.1", "foo", "bar")
    # THEN: The value of the variable is correctly set in the self._vars_cache dictionary
    assert var_manager._vars_cache == dict([("192.168.1.1", dict([("foo", "bar")]))])
# END - Unit test for method set_host_variable of class VariableManager


# Generated at 2022-06-11 19:05:15.785869
# Unit test for constructor of class VariableManager
def test_VariableManager():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    vm = VariableManager(loader=loader, inventory=inventory)
    play = Play.load(dict(hosts='all', roles='all'), variable_manager=vm, loader=loader)
    vm = VariableManager(loader=loader, inventory=inventory)
    vm.set_inventory(inventory)
    vm.setup_inventory(host_list='all', play=play)
    vars = vm.get_vars(host=inventory.get_host('testhost'))

# Generated at 2022-06-11 19:05:22.681152
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Check without facts, inventory and with_dict
    inventory = mock.MagicMock()
    inventory.get_groups_dict.return_value = {}
    fact_cache = {}
    vars_cache = {}
    hostvars = {}
    var_manager = VariableManager(loader=None, inventory=inventory, fact_cache=fact_cache, vars_cache=vars_cache,
                                  hostvars=hostvars, options_vars={})
    play = mock.MagicMock()
    play._included_files = []
    play.get_vars.return_value = {'play': 'vars'}
    play.get_roles.return_value = []
    play.roles = []
    play.dep_chain = []
    task = mock.MagicMock()

# Generated at 2022-06-11 19:05:23.629383
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    pass



# Generated at 2022-06-11 19:05:29.446119
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'x':1})
    v.sources['x'] = 'play'
    assert v['x'] == 1
    assert v.get_source('x') == 'play'
    # Note that this doesn't update the source
    v['x'] = 2
    assert v['x'] == 2
    assert v.get_source('x') == 'play'


# Generated at 2022-06-11 19:05:33.991718
# Unit test for constructor of class VariableManager
def test_VariableManager():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    inventory = Inventory(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    assert variable_manager

# Generated at 2022-06-11 19:05:45.104115
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():  # pylint: disable=too-many-locals
    # We start with creating a mock inventory, this is done in the test class
    inv = MockInventory()
    inv.add_host(MockHost('host1', 'host1'))
    inv.add_host(MockHost('host2', 'host2'))

    # Then we create a mock loader
    loader = MockLoader()

    # And a mock OptionsManager
    options = MockOptionsManager()

    # And we create a VariableManager using this options
    vm = VariableManager(loader=loader, inventory=inv, options_vars=options.as_dict())
# We also need to mock an object to which facts will be attributed.
    obj = Mock()
# Now we can set the facts
    facts = {'foo': 'bar'}
    vm.set_host_

# Generated at 2022-06-11 19:05:55.690945
# Unit test for constructor of class VariableManager
def test_VariableManager():
    from ansible.playbook import Play

    myplaybook = Play()
    myscreenplay = VariableManager(loader=None, inventory=None)

    assert hasattr(myscreenplay, '_fact_cache')
    assert hasattr(myscreenplay, '_vars_cache')
    assert isinstance(myscreenplay._fact_cache, dict)
    assert isinstance(myscreenplay._vars_cache, dict)
    assert myscreenplay.loader is None
    assert myscreenplay._inventory is None

    myscreenplay = VariableManager(loader=None, inventory=None, play=myplaybook)

    assert hasattr(myscreenplay, '_fact_cache')
    assert hasattr(myscreenplay, '_vars_cache')
    assert isinstance(myscreenplay._fact_cache, dict)

# Generated at 2022-06-11 19:05:57.881289
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    v = VariableManager()
    item = {'key': 'val'}

#### EOF #######################################################################

# Generated at 2022-06-11 19:06:00.971729
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    VariableManager: get_vars
    '''
    # Create the object under test
    vm = VariableManager()



# Generated at 2022-06-11 19:06:07.512430
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variableManager = VariableManager()
    variableManager.set_host_variable(None, 'x', 'y')
    variableManager.set_host_facts(None, 'x', 'y')
    variableManager._get_vars()

####################################################################################
# class Host:
#
# The Host class is used to interface with a particular host, by name.
# Hosts are matched via the pattern, which supports host globbing and
# can also be a host alias.  This allows us to use host patterns to define
# groups of hosts, which is one of the basic building blocks of an Inventory.
####################################################################################

# Generated at 2022-06-11 19:06:43.112978
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    from ansible.playbook.play import Play

    # Test the happy path
    inventory = InventoryManager(host_list=[])
    vars_manager = VariableManager(loader=None, inventory=inventory)
    play = Play().load(dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[dict(action=dict(module='setup', args=dict()))],
    ), variable_manager=vars_manager, loader=None)
    vars_manager.set_host_variable(host=inventory.get_host("all"), varname="ansible_play_batch", value=["all"])
    vars = vars_manager.get_vars(play=play, host=inventory.get_host("all"))

# Generated at 2022-06-11 19:06:50.863605
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Create VariableManager, test if ansible_facts_cache is empty.
    vm = VariableManager()
    assert isinstance(vm, VariableManager)
    assert vm._fact_cache == dict()

    # Test if we can set ansible_facts_cache from empty to non-empty, and then back to empty.
    vm._fact_cache = {'test_host' : 'test_value'}
    assert vm._fact_cache != dict()
    vm._fact_cache = dict()
    assert vm._fact_cache == dict()

    # Test if we get a TypeError when we try to set _fact_cache with a non-dict object.
    with pytest.raises(TypeError):
        vm._fact_cache = 'not a dict'

# Generated at 2022-06-11 19:06:54.665529
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    vws = VarsWithSources({'a': 1, 'b': 2} , {'a': 'a source', 'b': 'b source'})
    assert vws['a'] == 1
    assert vws.get_source('a') == 'a source'
    assert vws['b'] == 2
    assert vws.get_source('b') == 'b source'
    assert vws['c'] == None
    assert vws.get_source('c') == None

# Generated at 2022-06-11 19:06:55.901828
# Unit test for constructor of class VariableManager
def test_VariableManager():
    vm = VariableManager()
    assert vm is not None


# Generated at 2022-06-11 19:07:05.057800
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    from ansible.context import AnsibleContext
    from ansible.playbook.play_context import PlayContext
    from ansible.template.vars import AnsibleHostVars
    from ansible.template.vars import AnsibleHostVarsVars
    from ansible.vars.reserved import DEFAULT_HASH_BEHAVIOUR
    from ansible.vars.reserved import DEFAULT_MULTI_VARS_BEHAVIOUR
    from ansible.vars.reserved import HASH_BEHAVIOUR
    from ansible.vars.reserved import MULTI_VARS_BEHAVIOUR
    from ansible.vars.reserved import RESERVED_VARS
    from ansible.vars.manager import VariableManager
    vm = VariableManager()
    play_context = PlayContext()
   

# Generated at 2022-06-11 19:07:09.408798
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({"foo": "bar", "baz": "quux"})
    v.sources = {"foo": "from_inventory", "baz": "from_play"}
    assert v["foo"] == "bar"
    assert v["baz"] == "quux"



# Generated at 2022-06-11 19:07:16.964386
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # test fixture inventory is empty
    inventory = InventoryManager(loader=None, sources='')

    # test fixture options_vars is empty
    options_vars = {}

    # test fixture inventory
    inventory = InventoryManager(loader=None, sources='')

    # test fixture hostvars are empty
    local_host_vars = {}

    # test fixture hostvars are empty
    hostvars = {}

    # test fixture inventory_manager
    inventory_manager = InventoryManager(loader=None, sources='')

    # test fixture loader is None
    loader = None

    # test fixture variable_manager
    variable_manager = VariableManager(loader=None, inventory=None, variable_manager=None)

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_inventory(inventory_manager)

# Generated at 2022-06-11 19:07:26.775873
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():

    # Create an instance of VariableManager without any required arguments
    x = ansible_collections.ansible.misc.plugins.vars.VariableManager()
    # Create an instance of class 'AnsibleAssertionError' (defined in ansible.module_utils.common.exceptions) with 'message' initialized to 'the type of 'facts' to set for nonpersistent_facts should be a Mapping but is a <type 'bool'>'

# Generated at 2022-06-11 19:07:33.934296
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    '''
    Test method __getitem__ of class VarsWithSources
    '''
    print(VarsWithSources._doc_())
    v = VarsWithSources({'a':1, 'b':2})
    v.sources = {'a': 'A', 'b': 'B'}
    # Get value of 'a'
    print(v['a'])
    # Check that 'a' is still in the dict
    assert('a' in v)
    # Get value of 'b'
    print(v['b'])
    # Check that 'b' is still in the dict
    assert('b' in v)
    print(v.get_source('a'))
    print(v.get_source('b'))
    print(v.get_source('c'))


# Generated at 2022-06-11 19:07:40.242716
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    tmpdir = pytest.ensuretemp('test_set_nonpersistent_facts')
    p='test_set_nonpersistent_facts'
    inventory_file = tmpdir.ensure(p, 'hosts')
    inventory_file.write(b'')
    variable_manager = VariableManager()
    variable_manager._nonpersistent_fact_cache = dict()
    variable_manager.set_nonpersistent_facts('localhost', dict(new_fact='Facts'))
    #assert variable_manager._nonpersistent_fact_cache['localhost']['new_fact'] == 'Facts'

# Generated at 2022-06-11 19:09:15.697018
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-11 19:09:23.902656
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    h = Host('test_hostname')
    h.set_variable('my_var', 42)
    h.set_variable('my_other_var', 'my_value')
    h.set_variable('my_complex_var', {'a': 'b', 'c': 42, 'd': ['e', 'f', 'g']})


    v = VariableManager(loader=None)
    v.add_host_vars(h, {'my_var': 'my_new_value'})

    assert v._vars_cache == {'test_hostname': {'my_var': 'my_new_value', 'my_other_var': 'my_value',
                                               'my_complex_var': {'a': 'b', 'c': 42, 'd': ['e', 'f', 'g']}}}

# Generated at 2022-06-11 19:09:31.760706
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    class Play:
        def __init__(self, name, finalize=False):
            self.name = name
            self.finalized = finalize
    play = Play("test")
    loader = DictDataLoader({
        os.path.join("defaults", "main.yml"): """
            ---
            test: "test"
        """,
    })
    inv_src = BaseInventory("localhost ansible_connection=local", loader=loader, variable_manager=VariableManager)
    inv = inv_src.get_inventory()
    v = VariableManager(loader=loader, inventory=inv)
    vars = v.get_vars(play=play)
    print(vars)
    assert vars['test'] == 'test'

test_VariableManager_get_vars()

 

# Generated at 2022-06-11 19:09:36.223713
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Test the constructor of the class
    # This currently does not test anything, but if we do add checks, make sure
    # to assert the results
    v = VariableManager()
    assert v is not None

# Generated at 2022-06-11 19:09:40.048725
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vm = VariableManager()
    facts = dict()
    host = "localhost"
    vm.set_nonpersistent_facts(host=host, facts=facts)
    
    assert vm._nonpersistent_fact_cache[host] == facts

# Generated at 2022-06-11 19:09:47.238865
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Given
    sources = [
        DataLoader(),
        InventoryManager(loader=None, sources=None),
        Options(connection='ssh'),
        None,
    ]
    pending_deprecations_parser = ConfigParser()

    # When
    vmanager = VariableManager(*sources, pending_deprecations_parser=pending_deprecations_parser)

    # Then
    assert vmanager._loader == sources[0]
    assert vmanager._inventory == sources[1]
    assert vmanager._options == sources[2]
    assert vmanager._hostvars == sources[3]
    assert vmanager._pending_deprecations_parser == pending_deprecations_parser
    assert vmanager._extra_vars == dict()
    assert vmanager._nonpersistent_fact_cache == dict()
    assert vmanager._fact_

# Generated at 2022-06-11 19:09:59.793371
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    """
    Test get_vars of class VariableManager
    """
    # Initialize inventory
    inventory = Inventory()
    # Initialize loader
    loader = DataLoader()
    # Initialize host
    host = Host()
    # Initialize task execution
    task = TaskExecution()
    # Init variables
    variables = dict()

    # Initialize play
    play = Play()

    # Initialize option vars
    options_vars = dict()
    # Initialize host_vars
    hostvars = dict()
    # Initialize VariableManager
    variable_manager = VariableManager(loader, inventory)

    # Test get_vars

# Generated at 2022-06-11 19:10:03.313720
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # TODO: create real tests here
    # https://github.com/ansible/ansible/issues/55786
    pass


# Generated at 2022-06-11 19:10:14.229685
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    print("Testing method get_vars of class VariableManager")

    a = Ansible()
    a.options = Options()
    a.options.inventory = 'test/unit/files/inventory'
    from ansible.inventory.ini import InventoryParser

    # Get the ansible InventoryParser object
    inventory_parser = InventoryParser(a,[], None, [])
    # Get the inventory object
    inventory = inventory_parser.inventory
    
    
    b = VariableManager()
    # Set the inventory to the variable.
    b.set_inventory(inventory)
    # set _hostvars
    b._hostvars = {}

    # fetching the value of ansible_play_hosts_all

# Generated at 2022-06-11 19:10:15.862668
# Unit test for constructor of class VariableManager
def test_VariableManager():
    pass


# Generated at 2022-06-11 19:12:03.894712
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    from ansible.module_utils.six import iteritems
    from ansible.inventory.host import Host
    from ansible.inventory.host import host_list
    from ansible.vars.manager import VariableManager
    from ansible.vars.manager import VariableManager
    import os
    import sys
    import unittest

    #
    # Unit test setup and teardown
    #

    class MockHost(object):
        def __init__(self, hostname):
            self.name = hostname

    class MockTask(object):
        def __init__(self):
            self.action = dict()
            self.loop_with = None
            self.loop = None


    class MockInventory(object):
        def __init__(self, hostname):
            self.hosts = [host_list(hostname)]

# Generated at 2022-06-11 19:12:06.196557
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    """
        VariableManager.get_vars()
    """
    v = VariableManager()
    assert v

# Generated at 2022-06-11 19:12:14.338867
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    Unit test for method get_vars of class VariableManager
    '''
    vmanager = VariableManager()

    # First check that it fails if we don't specify a loader
    try:
        vmanager.get_vars(play=None)
        assert(False)
    except TypeError as te:
        assert(True) # We expect this to happen

    # Now let's create a loader, but let's not populate it and check that we get an error
    vmanager = VariableManager()
    loader = DataLoader()

    # Check that we get an error if we don't specify a play
    try:
        vmanager.get_vars(play=None, loader=loader)
        assert(False)
    except ValueError as ve:
        assert(True) # This is expected behaviour

    # Create a play for our tests


# Generated at 2022-06-11 19:12:25.081217
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vars_manager = VariableManager()

    assert vars_manager.get_vars() == {}

    vars_manager.extra_vars = {'key': 'value'}
    assert vars_manager.get_vars() == vars_manager.extra_vars

    vars_manager.options_vars = {'options_vars': 'dummy'}
    assert vars_manager.get_vars() == vars_manager.extra_vars

    play = Play()
    assert vars_manager.get_vars(play=play) == vars_manager.play_vars

    play.vars = {'play_vars': 'dummy'}
    assert vars_manager.get_vars(play=play) == vars_manager.play_vars


# Generated at 2022-06-11 19:12:27.513821
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Get a instance of the class
    variable_manager = VariableManager()
    assert True

# Generated at 2022-06-11 19:12:33.964807
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    """
    Test for method get_vars of class VariableManager
    """

    # We're just kind of testing the function of this method from Interface,
    # this could use more testing.
    mgr = VariableManager()
    fake_play = FakeTask(play=FakePlay())
    fake_task = FakeTask(task=FakeTask(play=fake_play))
    variables = mgr.get_vars(play=fake_play, task=fake_task)

    assert isinstance(variables, dict)
    assert 'omit' in variables

# Generated at 2022-06-11 19:12:43.821973
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test with a play that has no explain or role_names set (old-style play)
    play = Play.load(dict(
        name="test play",
        hosts="somehost",
        tasks=[]
    ), variable_manager=None, loader=None)
    variable_manager = VariableManager()
    variable_manager.set_globals(dict(
        global_var="global value"
    ))
    variable_manager.extra_vars = dict(
        extra_var="extra value"
    )
    expected_vars = dict(
        global_var="global value",
        extra_var="extra value"
    )
    variables = variable_manager.get_vars(host=None, play=play, task=None, include_delegate_to=False,
                                          include_hostvars=False)

# Generated at 2022-06-11 19:12:53.458724
# Unit test for constructor of class VariableManager
def test_VariableManager():
    v = VariableManager(loader=None, inventory=None)
    assert v.extra_vars == dict()
    assert v._nonpersistent_fact_cache == dict()
    assert v._fact_cache == dict()
    assert v._host_vars_files == dict()
    assert v._vars_cache == dict()
    assert v._omit_token == '__omit_place_holder__'
    assert v._options_vars == dict()
    assert not v._is_parsed
    assert v._loader is None
    assert v._basedir is None
    assert v._inventory is None

    v = VariableManager(loader=DictDataLoader({}), inventory=None)
    assert v._loader is not None
    assert v._basedir is None
    assert v._inventory is None
    assert v._loader._

# Generated at 2022-06-11 19:13:03.862977
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Create a test playbook which contains 'all' hosts
    playbook_dir = tempfile.mkdtemp()
    playbook_dir_path = os.path.join(playbook_dir, 'test_playbook.yml')
    with open(playbook_dir_path, 'w') as f:
        f.write("""
---
hosts: all
""")
    mock_loader = DictDataLoader({
        os.path.abspath(playbook_dir_path): """
---
hosts: all
""",
    })
    mock_inventory = InventoryManager(loader=mock_loader, sources='{0}')

    mock_options = C.Options()
    mock_options.verbosity = 0
    mock_options.no_log = False
    mock_options.connection = 'local'
    mock_options