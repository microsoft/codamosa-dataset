

# Generated at 2022-06-11 19:03:38.051506
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    vars_manager = VariableManager()

    assert vars_manager.get_vars(play=None, host=None, task=None, include_delegate_to=False, include_hostvars=False)['play_hosts'] == []
    assert vars_manager.get_vars(play=None, host=None, task=None, include_delegate_to=False, include_hostvars=False)['role_path'] == None
    assert vars_manager.get_vars(play=None, host=None, task=None, include_delegate_to=False, include_hostvars=False)['role_names'] == []

    assert vars_manager.get_vars(play=None, host=None, task=None, include_delegate_to=False, include_hostvars=False)

# Generated at 2022-06-11 19:03:45.776675
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    """Unit tests for module ansible.vars.variable_manager"""

    vm = VariableManager()

    # tests for the default parameters
    assert vm.get_vars() == {'omit': '__omit_place_holder__'}

    # tests for the include_delegate_to parameter
    host1 = Host('host1')
    host1.vars = {}

    vm.set_host_variable(host=host1, varname='myfact1', value='value1')
    # should be empty host.vars, so we should get the default variables
    assert vm.get_vars(host=host1) == {'omit': '__omit_place_holder__'}

    # Now we set a nonpersistent fact, and we should get it back

# Generated at 2022-06-11 19:03:48.553558
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'a': 1, 'b': 2})
    v.sources = {'a': 'foo'}
    assert v['a'] == 1


# Generated at 2022-06-11 19:04:00.032013
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Arrange
    varmgr = VariableManager()
    host = 'host1'
    varname = 'varname'
    value = 'value'

    # Act
    varmgr.set_host_variable(host, varname, value)

    # Assert
    assert varmgr._vars_cache[host][varname] == value

    # Arrange
    varmgr = VariableManager()
    host = 'host1'
    varname = 'varname'
    value = { 'name' : 'value'}

    # Act
    varmgr.set_host_variable(host, varname, value)

    # Assert
    assert varmgr._vars_cache[host][varname] == value

    # Arrange
    varmgr = VariableManager()

# Generated at 2022-06-11 19:04:02.764157
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    Test the get_vars method of class VariableManager
    '''
    test_vars = dict()
    vm = VariableManager()
    test_vars = vm.get_vars()
    assert test_vars == dict()



# Generated at 2022-06-11 19:04:14.604360
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()

# Generated at 2022-06-11 19:04:17.114866
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    pass

# Generated at 2022-06-11 19:04:18.678628
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    ret = VariableManager.get_vars()
    assert isinstance(ret, dict)

# Generated at 2022-06-11 19:04:29.032216
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    fake_collection_loader = FakeCollectionLoader()
    fake_loader = FakeDataLoader()
    fake_var_manager = VariableManager(loader=fake_loader, inventory=InventoryManager(loader=fake_loader, sources='localhost'))

    test_cases = []
    # test_case format:
    #       args: (play, host, task, include_delegate_to=False, include_hostvars=True)
    #       expected_result: expected result of the function call
    #
    #       Currently the test is only checking if get_vars method returns a dictionary or not.
    #       So, the test cases are not covering the test cases which are actually not returning a dictionary.

    # test_case 1
    test_case_1 = TestCase()

# Generated at 2022-06-11 19:04:36.794564
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from ansible.vars.hostvars import HostVars

    v = VariableManager()
    v.set_host_variable(host='test_host', varname='test_varname', value='test_value')
    ret = v.get_vars(host=None, play=None, task=None, include_hostvars=False)
    assert ret['test_varname'] == 'test_value'
    v.set_host_variable(host='test_host', varname='test_varname2', value='test_value2')
    ret = v.get_vars(host=None, play=None, task=None, include_hostvars=False)
    assert ret['test_varname'] == 'test_value'

# Generated at 2022-06-11 19:05:35.204526
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # this is the canonical data structure that represents variables in a playbook
    debug = dict()
    debug['hostvars'] = dict()
    debug['vars'] = dict()
    debug['group_vars'] = dict()
    debug['group_vars']['all'] = dict()
    debug['group_vars']['all']['global1'] = 'global1'
    debug['group_vars']['all']['global2'] = 'global2'
    debug['group_vars']['all']['global3'] = 'global3'
    debug['group_vars']['all']['include_fail'] = '{{ other_var }}'
    debug['group_vars']['all']['unconverted'] = '{{ unconverted_var }}'

# Generated at 2022-06-11 19:05:45.833529
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Set up inventory
    inventory = InventoryManager(
        loader=None,
        sources=[],
    )

    # Set up play
    play = Play()
    play._playbook = None
    play.file_name = None
    play.name = None
    play.hosts = 'all'
    play.setup_cache = None
    play.tasks = []
    play.post_validate = lambda self: None

    # Set up task
    task = Task()
    task._role = None
    task._task_include = None
    task._parent = None
    task._play = play
    task._ds = dict()
    task.action = 'action'
    task.async_val = 0
    task.args = dict()
    task.block = None
    task.become = False
    task.bec

# Generated at 2022-06-11 19:05:56.200906
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.include import Include
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 19:06:06.504931
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    facts1 = {"foo": "bar"}
    vm.set_host_facts("testhost", facts1)
    assert vm.get_vars(host=Host("testhost"))["foo"] == "bar"
    vm.set_host_variable("testhost", "foo", "foobar")
    assert vm.get_vars(host=Host("testhost"))["foo"] == "foobar"
    vm.set_host_variable("testhost", "bar", "baz")
    assert vm.get_vars(host=Host("testhost"))["bar"] == "baz"
    vm.set_host_variable("testhost", "foo", "bar")

# Generated at 2022-06-11 19:06:16.756745
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from ansible.template import Templar
    
    host = Mock()
    host.get_vars.return_value = "host_vars_dummy"

    play = Mock()
    play.get_vars.return_value = "play_vars_dummy"

    task = Mock()
    task.get_vars.return_value = "task_vars_dummy"

    _loader = Mock()
    _loader.list_collection_roles.return_value = {"namespace.collection.role_1": "/fake/path/role_1", "namespace.collection.role_2": "/fake/path/role_2"}

    var_manager = VariableManager()
    var_manager._inventory = Mock()
    var_manager._inventory.get_host.return_value = host

# Generated at 2022-06-11 19:06:27.197385
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    manager = VariableManager()
    assert manager.get_vars() == {'ansible_facts': {}, 'ansible_local': {}, 'ansible_play_hosts_all': [], 'ansible_play_hosts': [], 'omit': '__omit_place_holder__', 'role_names': [], 'groups': {}, 'ansible_play_batch': [], 'play_hosts': []}


# FIXME: this is an ugly hack, but required for AnsibleModule tests
# FIXME: this entire function should be made private, probably

# Generated at 2022-06-11 19:06:34.117737
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    mock_loader = Mock()
    mock_inventory = Mock()
    mock_loader.get_basedir.return_value = '/some/path'
    vmanager = VariableManager(loader=mock_loader, inventory=mock_inventory, version_info=C.DEFAULT_SYSTEM_INFO)
    vmanager.set_nonpersistent_facts('host1', {'one': 1, 'two': 2})
    vmanager.set_host_variable('host1', 'one', 3)
    assert vmanager._vars_cache['host1']['one'] == 3
    assert vmanager._nonpersistent_fact_cache['host1']['one'] == 1
    vmanager.set_nonpersistent_facts('host1', {'one': 1, 'two': 2})

# Generated at 2022-06-11 19:06:45.208647
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    '''
    Test for set_host_facts
    '''
    v = VariableManager()
    playbook_path = '/test/test_playbook.yml'
    inventory = Inventory('127.0.0.1,')
    loader = DataLoader()
    v._loader = loader
    v._options_vars = dict()
    v._inventory = inventory
    v._playbook_vars_files = [playbook_path]
    v._vars_cache = dict()
    v._nonpersistent_fact_cache = dict()
    v._fact_cache = dict()
    v._omit_token = '<omit>'
    v._hostvars = dict()
    host = '127.0.0.1'
    facts = dict()
    v.set_host_facts(host, facts)


# Generated at 2022-06-11 19:06:53.061471
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    varManager = VariableManager()
    # set up the env vars, so the varmanager will use them
    os.environ['HOME'] = '/home/test'
    os.environ['USER'] = 'test'
    os.environ['USERNAME'] = 'test'
    os.environ['LOGNAME'] = 'test'
    os.environ['PWD'] = '/home/test'

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    i = InventoryManager(loader=None)
    h = i.add_host(host="host")
    varManager.clear_facts(hostname="host")

# Generated at 2022-06-11 19:07:02.886333
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # make sure ansible.cfg is loaded
    config.reload()
    # Initialize object VariableManager with a host
    kwargs = dict(
            loader=DictDataLoader({}),
            inventory=InventoryManager(loader=DictDataLoader({})),
            variables=dict(),
            )
    vm = VariableManager(**kwargs)
    host = 'ansible.cfg'
    varname = '127.0.0.1'
    value = '127.0.0.1'
    vm.set_host_variable(host, varname, value)
    # Test if our dict is in the vars_cache
    assert varname in vm._vars_cache[host]
    # Test for set_host_variable method of class VariableManager
    vm.set_host_variable(host, varname, value)

# Generated at 2022-06-11 19:07:34.811423
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # First part of VariableManager.get_vars()
    
    # 1: '_get_parent_vars_of_type' returns a list of objects (aka Task or Play)
    #    which have non-filtered variables defined
    # 2: '_get_parent_vars_of_type' uses _get_parent_of_type function
    #    which returns a list of tasks and/or plays containing the parent_type
    
    pass


# Generated at 2022-06-11 19:07:37.553211
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    mgr = VariableManager()
    with pytest.raises(AnsibleError):
        mgr.get_vars(play=None, host=None, task=None)

# Generated at 2022-06-11 19:07:44.220223
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    loader = DataLoader()
    vm = VariableManager(loader=loader)
    vm.set_nonpersistent_facts(host='dummy_host', facts={'dummy_fact': 'dummy_val'})
    assert vm._nonpersistent_fact_cache == {'dummy_host': {'dummy_fact': 'dummy_val'}}
    assert vm._nonpersistent_fact_cache.get('dummy_host').get('dummy_fact') == 'dummy_val'

# Generated at 2022-06-11 19:07:52.176362
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # This test is used to check if the method get_vars of class VariableManager
    # returns the proper value
    VariableManager = ansible.vars.VariableManager

    # Create the mocks of the objects needed
    inventory_hostname = MagicMock(spec=str)
    host = MagicMock(spec=Host)
    loader = MagicMock(spec=DataLoader)
    hostvars = MagicMock(spec=dict)
    groupvars = MagicMock(spec=dict)
    task = MagicMock(spec=Task)
    play = MagicMock(spec=Play)
    option_vars = MagicMock(spec=dict)

    # Set the attributes of the object
    VariableManager.vars_cache = dict()
    VariableManager._inventory = MagicMock(spec=InventoryManager)
    VariableManager

# Generated at 2022-06-11 19:07:54.953879
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    '''
    Unit test of method:
    ansible.vars.VariableManager.set_host_facts
    '''

    yaml.safe_load('{test1: 123, test2: 234}')

# Generated at 2022-06-11 19:08:04.464426
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    mock_loader = MagicMock()
    mock_loader.path_exists.return_value = True
    mock_loader.is_file = MagicMock(return_value=True)
    mock_loader.is_directory = MagicMock(return_value=True)
    mock_loader.list_directory = MagicMock(return_value=['file1', 'file2'])
    mock_loader.path_exists.return_value = True
    mock_loader.file_exists.return_value = True

    mock_inventory = MagicMock()
    mock_inventory.get_groups_dict.return_value = {'group1': {'hosts':['host1', 'host2'], 'children': ['group2']}, 'group2': {'hosts': ['host3']}}

    mock_task = MagicM

# Generated at 2022-06-11 19:08:14.745841
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    def get_vars(play_context, playbook, host=None, include_hostvars=True, include_delegate_to=True):
        """
        Returns variables sourced from inventory, playbooks and facts,
        and the vars cache, for the given host.

        :arg host: host for which variables are requested
        :kwarg include_hostvars: when False, don't include host variables
        :kwarg include_delegate_to: when False, don't include delegated_to host vars
        """
        variables = dict()

        # start with the per-play variables
        variables.update(play_context.vars)

        # then add facts, which are host-specific and override per-play vars
        if host is not None:
            variables.update(self.get_host_variables(host))

        # then add

# Generated at 2022-06-11 19:08:26.602301
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    '''
    Test for method set_host_variable of class VariableManager
    '''
    variable_manager = VariableManager()
    variable_manager.set_host_variable('localhost', 'ansible_lsb', 'lsb')
    variable_manager.set_host_variable('localhost', 'ansible_lsb', {'distributor_id': 'Ubuntu', 'description': 'Ubuntu 18.04.4 LTS', 'release': '18.04', 'codename': 'bionic'})
    assert variable_manager._vars_cache['localhost']['ansible_lsb'] == {'codename': 'bionic', 'description': 'Ubuntu 18.04.4 LTS', 'distributor_id': 'Ubuntu', 'release': '18.04'}


# Generated at 2022-06-11 19:08:33.578766
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # We will test this method on the following input data:
    #

    # host: str
    #     hostname we are setting a variable on
    # varname: str
    #     the name of the variable we are setting
    # value: Any
    #     the value we are setting for the variable
    #
    #
    # VariableManager.set_host_variable returns None
    #
    # Return type: None

    print("\n\nTESTING: VariableManager.set_host_variable\n")

    from ansible.vars.manager import VariableManager

    manager = VariableManager()

    host = "TEST_HOST"
    varname = "TEST_VAR"
    value = "TEST_VALUE"

    manager._vars_cache = dict()  # type: dict

    # single host set


# Generated at 2022-06-11 19:08:35.267561
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    assert True


# Generated at 2022-06-11 19:09:36.537315
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # FIXME: This is a stub, please implement
    raise NotImplementedError()


# Generated at 2022-06-11 19:09:44.534836
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Tests if the method correctly updates the fact cache

    vm = VariableManager()

    host_facts = {'ansible_python_interpreter': '/usr/bin/python'}
    vm.set_host_facts('test_host', host_facts)
    assert vm._fact_cache['test_host'] == host_facts

    host_facts = {'ansible_python_interpreter': '/usr/bin/python2'}
    vm.set_host_facts('test_host', host_facts)
    assert vm._fact_cache['test_host'] == {'ansible_python_interpreter': '/usr/bin/python2'}



# Generated at 2022-06-11 19:09:57.428004
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Setup the object for varmanager.py
    # Instance attributes
    _play_context = None  # vars_cache dictionaries keyed by hostname
    _vars_cache = {}
    _fact_cache = {}
    _nonpersistent_fact_cache = {}
    _option_vars = None
    _hostvars = None
    _loader = None
    _omit_token = '<omit>'
    _inventory = None
    # Unit test for method get_vars of class VariableManager
    # Setup the object for varmanager.py
    # Instance attributes
    _play_context = None  # vars_cache dictionaries keyed by hostname
    _vars_cache = {}
    _fact_cache = {}
    _nonpersistent_fact_cache = {}

# Generated at 2022-06-11 19:10:03.546829
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''
    Test constructor of class VariableManager
    '''
    mock_inventory = MagicMock()
    mock_loader = MagicMock()

    variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)

    assert variable_manager._inventory == mock_inventory
    assert variable_manager._loader == mock_loader
    assert variable_manager._extra_vars == {}
    assert variable_manager._hostvars == {}
    assert variable_manager._options_vars == {}
    assert variable_manager._fact_cache == {}
    assert variable_manager._vars_cache == {}
    assert variable_manager._nonpersistent_fact_cache == {}
    assert variable_manager._omit_token == '__omit_place_holder__'

# Generated at 2022-06-11 19:10:07.117300
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # TODO: enabling this test will require refactoring of the other tests.
    #       for now, we just test the method signature
    assertFalse(True)

# Generated at 2022-06-11 19:10:17.316450
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # We don't know exactly how this is going to be used in the future, so while we could create a complete inventory
    # with hosts and groups in it, we don't want/need to do that.  We're just going to make sure we're actually
    # getting the type of data back we expect, so we'll use a couple of simple dictionaries instead.

    inventory = {'_meta': {'hostvars': {}}, 'my_group': {'hosts': ['somehost1', 'somehost2']}}
    vars1 = {'group_var': 'group var value'}
    vars2 = {'host_var': 'host var value'}
    hostvars = {'somehost1': vars1, 'somehost2': vars2}

    # Create a variable manager.
    vm = variable_manager.VariableManager()

# Generated at 2022-06-11 19:10:26.047964
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Assume that we have a valid VariableManager instance
    vm = VariableManager()
    assert isinstance(vm, VariableManager)
    # Assume that we have an empty list of hosts
    play_hosts = []
    # Assume that we have a valid Play instance
    play = Play()
    # Assume that we have a valid Task instance
    task = Task()
    # Assume that we have a valid Host instance
    host = Host()
    # Call the method
    vm.get_vars(play=play, host=host, task=task)

# Generated at 2022-06-11 19:10:27.630240
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # TODO: Implement this test
    pass


# Generated at 2022-06-11 19:10:38.646929
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-11 19:10:41.459371
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # create a VariableManager without passing any values to __init__
    # so we test the defaults
    vm = VariableManager()



# Generated at 2022-06-11 19:11:41.652066
# Unit test for constructor of class VariableManager
def test_VariableManager():

    # Returning the result of VariableManager should not fail
    assert VariableManager()



# Generated at 2022-06-11 19:11:45.274632
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    get_vars = variable_manager.get_vars()
    assert_equal(get_vars, {})


# Generated at 2022-06-11 19:11:51.418364
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    my_loader = DictDataLoader({})
    tasks_executor = TaskExecutor(my_loader)
    my_inventory = Inventory(my_loader)
    my_playbook = Playbook(my_loader, my_inventory)
    my_playbook._load_playbook_data(playbook_data=dict())
    my_play = my_playbook._playbook[0]
    my_play._load_play_data(play_data=dict(name='my_play', roles=[NamedRole(data=dict(), defname='my_role')]))
    my_jid = JID('1234567890')
    my_task = Task(loader=my_loader, role=my_play.roles[0])
    my_host = Host(name='localhost')

# Generated at 2022-06-11 19:11:52.044348
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    pass

# Generated at 2022-06-11 19:11:53.058315
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vm = VariableManager()


# Generated at 2022-06-11 19:12:02.560348
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from ansible.vars.hostvars import HostVars
    now = datetime.datetime.now
    env = {'foo': 'bar', 'ansible_test1': 'test1'}
    varmgr = VariableManager()
    varmgr.extra_vars = {'ansible_test2': 'test2'}
    varmgr._fact_cache = {'host1': {'ansible_test3': 'test3'}}
    varmgr._vars_cache = {'host1': {'ansible_test4': 'test4'}}
    varmgr._nonpersistent_fact_cache = {'host1': {'ansible_test5': 'test5'}}
    varmgr._omit_token = 'OMIT'

# Generated at 2022-06-11 19:12:12.747766
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    assert variable_manager.get_vars() == {}
    
    variable_manager._fact_cache = {
        'test' : {
            'hello' : 'world'
        }
    }
    
    variable_manager._nonpersistent_fact_cache = {
        'test' : {
            'hello' : 'not world'
        }
    }
    
    variable_manager._vars_cache = {
        'test' : {
            'hello' : 'hello world'
        }
    }
    
    assert variable_manager.get_vars(host=Host('test')) == {
        'hello': 'hello world'
    }

# Generated at 2022-06-11 19:12:24.912162
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():

    my_mock = {}
    my_mock['_vars_cache'] = {}
    my_mock['_vars_cache']['hostname'] = {}
    my_mock['_vars_cache']['hostname']['key1'] = 1
    my_mock['_vars_cache']['hostname']['key2'] = 2
    my_mock['_vars_cache']['hostname']['key3'] = 3
    my_mock['_vars_cache']['hostname']['key4'] = 4


# Generated at 2022-06-11 19:12:34.956958
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # initialize class
    g_params = ['hostvars', '_fact_cache']
    vars_manager = VariableManager(loader=None, inventory=None, version_info=None, options_vars=None)
    # assert set_local_fact
    fact = 'test fact'
    fact_dict = {'foo': fact}
    vars_manager.set_nonpersistent_facts(host='localhost', facts=fact_dict)
    fact_dict_ret = vars_manager._nonpersistent_fact_cache['localhost']
    assert fact_dict_ret['foo'] == fact, f'assert set_local_fact'
    # assert clear_facts
    vars_manager.clear_facts(hostname='localhost')
    assert 'localhost' not in vars_manager._fact_cache, f'assert clear_facts'

# Generated at 2022-06-11 19:12:40.331167
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = None
    host = None
    play = None
    task = None
    # Check the variable manager get_vars
    variable_manager.get_vars(host = host, task = task, play = play)
