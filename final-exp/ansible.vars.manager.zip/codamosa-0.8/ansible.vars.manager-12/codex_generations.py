

# Generated at 2022-06-11 19:03:47.399254
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Ensure that the constructor asserts with no params
    assert_raises(AnsibleAssertionError, VariableManager)



# Generated at 2022-06-11 19:03:58.889056
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # setup some objects
    variable_manager = VariableManager(loader=DictDataLoader({}))

    variable_manager._inventory = Inventory(host_list=[Host(name='hostname')])
    variable_manager._hostvars = dict()
    # test get_vars
    assert isinstance(variable_manager.get_vars(host=Host(name='hostname'), include_hostvars=True), dict)
    assert isinstance(variable_manager.get_vars(host=Host(name='hostname'), task=Task(), include_hostvars=True), dict)
    assert isinstance(variable_manager.get_vars(host=Host(name='hostname'), play=Play(), include_hostvars=True), dict)

# Generated at 2022-06-11 19:03:59.444607
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    pass

# Generated at 2022-06-11 19:04:06.026445
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    import unittest
    import mock

    class MockDisplay(object):
        def debug(self, *args,**kwargs):
            pass

    class MockDisplayModule(object):
        Display = MockDisplay

    mock_display = mock.patch('ansible.vars.manager.display', MockDisplayModule)

    class MockVarsWithSources(VarsWithSources):
        def __init__(self, data, sources):
            self.data = data
            self.sources = sources

    class TestVarsWithSources(unittest.TestCase):
        def test_without_source(self):
            s = {'x':1}
            v = MockVarsWithSources(s, {})
            self.assertEqual(v.get('x'), 1)


# Generated at 2022-06-11 19:04:16.831750
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    Unit test for method get_vars of class VariableManager
    '''
    loader_mock = mock.Mock()
    inventory_mock = mock.Mock()
    inventory_mock.get_groups_dict = lambda: {'group_name': 'group_object'}
    inventory_mock.groups = 'group_object'
    inventory_mock.get_hosts = lambda x: ['host1', 'host2']
    inventory_mock.get_host = lambda x: 'host var'
    
    variable_manager = VariableManager(loader=loader_mock, inventory=inventory_mock)
    
    # test 1
    action = mock.Mock()
    action.action = 'test_action'
    action.deprecate_action = True

# Generated at 2022-06-11 19:04:26.909071
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Test case inputs for VariableManager.set_host_facts()
    host = "test_host"
    facts = {}

    # Test case methods that will be invoked prior to calling target method
    mock_self = Mock(spec_set=VariableManager)
    mock_self.set_host_facts.__class__.__name__ = "VariableManager"
    mock_self.set_host_facts.__self__ = mock_self

    # Test case method that will invoke target method with test case inputs
    mock_ansible_assertion_error = Mock(spec_set=AnsibleAssertionError)
    mock_ansible_assertion_error.__class__.__name__ = "AnsibleAssertionError"

    mock_mapping = Mock(spec_set=Mapping)

# Generated at 2022-06-11 19:04:31.515127
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # create a fake runner to pass in, so the plugin loaders work
    runner = Runner(connection=None, module_name='setup')

    # create a fake inventory to pass in
    host = Host(name="testhost")
    inv_source = InventorySource(name="testhost",
                                 hosts=[host],
                                 vars={'hostvars1': True})
    inv = Inventory(host_list=[])
    inv.add_source(inv_source, None)

    # create two basic variables
    host_vars = dict()
    host_vars['testhost'] = dict(
        hostvar1=dict(key1='value1'),
        hostvar2=dict(key2='value2'),
    )

# Generated at 2022-06-11 19:04:34.003535
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    v = VariableManager()
    result = v.get_vars(play=None, host=None, task=None, include_delegate_to=True)
    assert isinstance(result, dict)


# Generated at 2022-06-11 19:04:36.371501
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    assert True

# Generated at 2022-06-11 19:04:42.522060
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    host = '172.16.1.1'
    vm.set_host_variable(host, 'ansible_host', '172.16.1.1')

    assert vm.get_vars(host=Host('172.16.1.1'))['ansible_host'] == '172.16.1.1'

# Generated at 2022-06-11 19:05:14.354056
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    v = VariableManager()
    assert not v._fact_cache
    v.set_host_facts("example",dict(a=5))
    assert len(v._fact_cache) == 1
    assert v._fact_cache['example']['a'] == 5
    v.set_host_facts("example",dict(a=6))
    assert len(v._fact_cache) == 1
    assert v._fact_cache['example']['a'] == 6

# Generated at 2022-06-11 19:05:21.767170
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-11 19:05:32.669772
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    args = collections.namedtuple('args', ['connection', 'host_pattern'])
    args.connection = 'ssh'
    args.host_pattern = '*'
    display = Display()
    options = collections.namedtuple('options', ['connection', 'module_path', 'forks', 'become', 'become_method',
                                                 'become_user', 'check', 'diff', 'syntax'])
    options.connection = 'ssh'
    options.module_path = None
    options.forks = 10
    options.become = None
    options.become_method = None
    options.become_user = None
    options.check = 2
    options.diff = False
    options.syntax = None


# Generated at 2022-06-11 19:05:33.884904
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    v = VariableManager()
    assert v.get_vars() == {}

# Generated at 2022-06-11 19:05:37.708986
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({"a": "b"})
    v.sources["a"] = "hostvars"
    assert v["a"] == "b"

# Generated at 2022-06-11 19:05:48.048493
# Unit test for method set_host_variable of class VariableManager

# Generated at 2022-06-11 19:05:57.113944
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test set_host_variable
    vmanager = VariableManager()
    vmanager.set_host_variable('hosta', 'varname', 'value')
    assert vmanager._vars_cache['hosta']['varname'] == 'value'
    # Test set_host_variable are preserved after get_vars()
    vmanager.get_vars()
    assert vmanager._vars_cache['hosta']['varname'] == 'value'
    # Test set_host_variable with a dict value
    vmanager.set_host_variable('hostb', 'varname', {'key1': 'item1'})
    assert vmanager._vars_cache['hostb']['varname']['key1'] == 'item1'
    # Test set_host_variable with a dict value overw

# Generated at 2022-06-11 19:06:02.298430
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Create a minimal test fixture
    v = VariableManager()
    v._vars_cache = {}

    hosts = ['host1', 'host2']
    varnames = ['ansible_facts', 'vars']

    # The values to set are different combinations of Mapping and non-Mappings
    # Value 1 is a non-Mapping
    value1 = 'ansible'
    # Value 2 is a non-Mapping
    value2 = 'rocks'
    # Value 3 is a Mapping
    value3 = {'reason': 'because it does'}

    # We need to test what happens when the first variable set is either a Mapping or not

# Generated at 2022-06-11 19:06:10.376895
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    set_host_variable = VariableManager.set_host_variable
    # exists (1)
    inventory = Inventory('/path/to/inventory')
    # Setup host
    host = Host()
    host.name = "test.host"
    host.address = "1.2.3.4"
    inventory.get_hosts()["test.host"] = host
    # Setup VariableManager
    vm = VariableManager(inventory=inventory)
    # Setup argument 'host'
    host = "test.host"
    # Setup argument 'varname'
    varname = "ansible_host"
    # Setup argument 'value'
    value = "1.2.3.4"
    set_host_variable(host, varname, value)
    set_host_variable(host, varname, value)
    # exists (

# Generated at 2022-06-11 19:06:20.339635
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-11 19:06:48.526358
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources()
    v.sources["test"] = "test"
    v.data["test"] = 1
    assert v["test"] == 1
    v["test"] = 1
    # test __getitem__ by getting item
    v.__getitem__("test") == 1


# Generated at 2022-06-11 19:06:49.565513
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()


# Generated at 2022-06-11 19:06:50.946178
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Note: the methods of this class are tested in tests/unit/test_vars.py
    pass

# Generated at 2022-06-11 19:06:56.377918
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    var_mgr = VariableManager()
    host = '127.0.0.1'
    varname = 'foo'
    value = 'bar'
    var_mgr.set_host_variable(host, varname, value)
    print(var_mgr._vars_cache)
    assert var_mgr._vars_cache[host][varname] == value



# Generated at 2022-06-11 19:07:05.414537
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    print("Testing get_vars")

    # If a VariableManager instance is created it is None by default
    # test this case first
    vm = VariableManager()

    # check that a KeyError is raised when trying to access a key
    # that does not exist
    with pytest.raises(KeyError):
        vm.get_vars(play=None)

    # check that the _get_vars method is called
    vm._get_vars = Mock()
    vm.get_vars(play=None)
    vm._get_vars.assert_called_with(play=None, host=None, task=None, include_delegate_to=True,
                                    include_hostvars=False)

    # if the cache is not set, the _get_vars method should be called again
    # when the key is

# Generated at 2022-06-11 19:07:09.863743
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    ansible_vars = VarsWithSources()
    ansible_vars['a'] = 1
    ansible_vars.sources['a'] = 'source_a'
    assert ansible_vars['a'] == 1
    assert ansible_vars.get_source('a') == 'source_a'

# Generated at 2022-06-11 19:07:13.624347
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vM = VariableManager()
    assert vM._vars_cache == {}
    assert vM._vars_cache[0] == {}
    assert vM._vars_cache[1] == {}
    assert vM._vars_cache[2] == {}


# Generated at 2022-06-11 19:07:20.280441
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    check_value = {'omit': '<omit>', 'role_names': [], 'ansible_play_hosts_all': [], 'ansible_collection_name': 'testing_collection_123'}
    assert VariableManager().get_vars(host=Host('host01'), include_hostvars=True) == check_value
 

# Generated at 2022-06-11 19:07:29.448293
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    vm = VariableManager()
    host1 = 'host1'
    var1 = 'var1'
    var2 = 'var2'
    value1 = 'value1'
    value2 = 'value2'
    value3 = 'value3'
    vm.set_host_variable(host1, var1, value1)
    assert vm._vars_cache[host1][var1] == value1

    vm.set_host_variable(host1, var1, value2)
    assert vm._vars_cache[host1][var1] == value2

    vm.set_host_variable(host1, var2, value3)
    assert vm._vars_cache[host1][var1] == value2
    assert vm._vars_cache[host1][var2] == value3

# Generated at 2022-06-11 19:07:33.101361
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({"key": "val"}, sources={"key": "filesystem"})
    assert v["key"] == "val"
    assert v.get_source("key") == "filesystem"


# Generated at 2022-06-11 19:08:05.216265
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    variableManager = VariableManager()

    variableManager.set_host_variable('host1', 'fact1', 'value1')
    variableManager.set_host_facts('host1', {'fact2': 'value2'})
    variableManager.set_nonpersistent_facts('host1', {'fact3': 'value3'})

    variableManager.set_host_variable('host2', 'fact1', 'value1')
    variableManager.set_host_facts('host2', {'fact2': 'value2'})
    variableManager.set_nonpersistent_facts('host2', {'fact3': 'value3'})

    variableManager.set_host_variable('host3', 'fact1', 'value1')
    variableManager.set_host_facts('host3', {'fact2': 'value2'})
   

# Generated at 2022-06-11 19:08:13.563783
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    v = VariableManager(loader=None, inventory=None)
    v.set_nonpersistent_facts('localhost', dict(ansible_ssh_host='127.0.0.1', ansible_host='127.0.0.1'))
    vars = v.get_vars(host=Host('localhost'), include_hostvars=True)
    assert vars['ansible_ssh_host'] == '127.0.0.1'
    assert vars['ansible_host'] == '127.0.0.1'

from collections import MutableMapping



# Generated at 2022-06-11 19:08:25.910571
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    '''
    Unit test for method set_host_variable of class VariableManager
    '''
    print('Testing method set_host_variable of class VariableManager')

    inventory = InventoryManager(loader=None, sources=None)
    host = inventory.get_host(name=None)
    hostname = '12.34.56.78'
    host_cache = dict(varname='value')
    facts = dict(varname1='value1', varname2='value2')

    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.set_host_facts(host=hostname, facts=host_cache)
    variable_manager.set_host_facts(host=hostname, facts=facts)

# Generated at 2022-06-11 19:08:35.553163
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.managedobjects import MagicVars

    play_context = PlayContext()
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')

    variables = VariableManager(loader=DataLoader(), inventory=inventory, version_info=MagicVars(gitinfo=False))

# Generated at 2022-06-11 19:08:44.389071
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v1 = VarsWithSources()
    v1['ansible_version'] = '2.0.0'
    v1.sources['ansible_version'] = 'facts'

    # test the get_source function
    assert v1.get_source('ansible_version') == 'facts'

    # test the __getitem__ function and the debug message
    old_display = display.Display
    display.Display = MockDisplay()
    try:
        assert v1['ansible_version'] == '2.0.0'
        assert display.Display.debug_out[0] == "variable 'ansible_version' from source: facts"
    finally:
        display.Display = old_display
        display.Display.debug_out = []



# Generated at 2022-06-11 19:08:53.878104
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Run unit tests for method get_vars of class VariableManager
    pwd = os.path.dirname(__file__)
    loader = DataLoader()
    locations = C.DEFAULT_LOAD_CALLBACK_PLUGINS_PATH.split(os.pathsep) + C.DEFAULT_CALLBACK_PLUGINS_PATH.split(os.pathsep)
    callback_loader = CallbackModuleLoader(locations=locations, package_name='ansible.plugins.callback', class_suffix='')
    hostvars = {}
    hostvars['host1'] = {'ansible_host': '127.0.0.1'}
    hostvars['host2'] = {'ansible_host': '127.0.0.1'}

# Generated at 2022-06-11 19:09:04.191507
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    dl = DataLoader()
    vm = VariableManager(loader=dl)
    vm._vars_cache['test_host'] = {'ansible_all_ipv4_addresses': '1.1.1.1'}
    vm._options_vars['test_option_vars'] = True
    assert vm.get_vars(host='test_host') == {'ansible_all_ipv4_addresses': '1.1.1.1', 'test_option_vars': True}
    vm.clear_facts('test_host')
    assert vm._fact_cache == {}


# Generated at 2022-06-11 19:09:15.806802
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    Unit test for the method VariableManager.get_vars of the class VariableManager
    '''
    def _load_inventory_file(loader, path):
        '''
        Loads an inventory file
        '''
        return InventoryFile(loader=loader, path=path)

    vmanager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    inventory_file = _load_inventory_file(loader=loader, path=inventory_file_path)
    inventory.add_inventory(inventory_file)
    vmanager._inventory = inventory
    options_vars = {'hostvars': {}}
    vmanager._options_vars = options_vars
    # Variable manager has _hosts_cache and _hosts_patterns_cache
    # The _hosts

# Generated at 2022-06-11 19:09:16.356510
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    pass

# Generated at 2022-06-11 19:09:23.604483
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    with patch('ansible.playbook.debug.display') as mock_display:
        v = VarsWithSources({'a': 1, 'b': 2}, {'a': 'source a', 'b': 'source b', 'c': 'source c'})
        assert v['a'] == 1
        assert v.get_source('a') == 'source a'
        mock_display.debug.assert_called()
        v['a'] = 3
        assert v['a'] == 3
        assert v.get_source('a') == 'source a'
        # New items do not get sources
        v['c'] = 4
        assert v['c'] == 4
        assert v.get_source('c') is None


# Generated at 2022-06-11 19:10:12.307500
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    pass



# Generated at 2022-06-11 19:10:13.972995
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'hello': 'world', 'foo': 'bar'}, {'hello': 'inventory', 'foo': 'play'})
    assert v['hello'] == 'world'
    assert v['foo'] == 'bar'

# Generated at 2022-06-11 19:10:21.297905
# Unit test for constructor of class VariableManager
def test_VariableManager():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Constructor of class VariableManager tests
    vm = VariableManager()
    # test __init__()
    assert vm is not None
    assert vm.get_vars() is not None

    # test _get_delegated_vars() and get_vars()
    play_ds = dict(
        name="test_play",
        hosts='webservers',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=''), register='setup_result'),
            dict(action=dict(module='shell', args='ls'), register='shell_result', delegate_to='localhost')
        ]
    )
    play = Play().load(play_ds, variable_manager=vm)

# Generated at 2022-06-11 19:10:33.497933
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

# Generated at 2022-06-11 19:10:40.408276
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.utils.color import stringc

    class MockHost(object):
        '''
            A mock host object
        '''
        def __init__(self, name, port=None):
            self.name = name
            self.port = port

    mock_loader = Mock()


# Generated at 2022-06-11 19:10:50.433072
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    print("Test 1: Creating a new VariableManager class for test_VariableManager_get_vars")
    # Setup test
    var_manager = VariableManager()
    var_manager.set_nonpersistent_facts(host='localhost', facts=dict(ansible_local=dict(test_var='HELLO WORLD')))
    var_manager.set_host_facts(host='localhost', facts=dict(ansible_local=dict(test_var2='HELLO WORLD2')))
    print("Test 1: Should return the following dictionary because the test_var and test_var2 are both set")
    print(var_manager.get_vars(play=dict(), host=dict(), task=dict(), include_delegate_to=False))


# Generated at 2022-06-11 19:10:58.902706
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    variable_manager._vars_cache['host1'] = {
        'foo': 1,
        'bar': 2,
        'baz': 3,
    }
    variable_manager._vars_cache['host2'] = {
        'foo': ['bar'],
    }
    variable_manager._vars_cache['host3'] = {
        'ansible_ssh_host': '127.0.0.1',
        'ansible_ssh_port': 9000,
    }
    variable_manager.set_host_variable('host1', 'baz', {'bar': {'baz': 3}})
    variable_manager.set_host_variable('host2', 'foo', {'bar': ['baz']})

# Generated at 2022-06-11 19:11:01.099271
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'a':'a', 'b':'b'})
    v['a']

# Generated at 2022-06-11 19:11:10.595151
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Initialize the class object
    vm_object = VariableManager()

    # Set the facts to a host
    vm_object.set_host_facts('host10', {'Key1': 'Value1'})

    # Display the current fact value of host10
    print("The current fact value of host10 is %s" % vm_object.get_host_facts('host10'))

    # Update the fact for host10 with new set of facts
    vm_object.set_host_facts('host10', {'Key2': 'Value2'})

    # Display the updated fact value of host10
    print("The updated fact value of host10 is %s" % vm_object.get_host_facts('host10'))


# Generated at 2022-06-11 19:11:12.423698
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test with defaults
    inventory = InventoryManager('localhost')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.get_vars()

