

# Generated at 2022-06-11 19:03:43.802967
# Unit test for constructor of class VariableManager
def test_VariableManager():
    v = VariableManager()
    assert isinstance(v._vars_cache, MutableMapping)
    assert isinstance(v._vars_persistent, MutableMapping)
    assert isinstance(v._nonpersistent_fact_cache, MutableMapping)
    assert isinstance(v._fact_cache, MutableMapping)
    assert isinstance(v._hostvars, MutableMapping)
    assert isinstance(v._options_vars, MutableMapping)
    assert isinstance(v._inventory, Inventory)

# Generated at 2022-06-11 19:03:46.060920
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Test the method with specific arguments.
    instance = globals()['VariableManager']()
    instance.set_host_variable(host=1, varname=1, value=1)
    assert instance._vars_cache is not None

# Generated at 2022-06-11 19:03:47.265669
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    pass



# Generated at 2022-06-11 19:03:52.003026
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Variables to be set for this test
    m = {}
    m['a'] = 1
    m['b'] = 2
    # VariableManager instance to be tested
    vm = VariableManager()
    vm.set_host_facts('a', m)
    assert vm._fact_cache['a'] == {
        'a': 1,
        'b': 2
    }

# Generated at 2022-06-11 19:03:59.501231
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    vars_with_sources = VarsWithSources({
        'a': 1,
        'b': 2,
        'c': 3
    })

    assert vars_with_sources['a'] == 1
    assert vars_with_sources['b'] == 2
    assert vars_with_sources['c'] == 3
    try:
        vars_with_sources['d']
    except KeyError:
        pass

# Generated at 2022-06-11 19:04:02.251086
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'a': 1, 'b': 2})
    assert v['a'] == 1
    assert v['b'] == 2
    v.sources = {'a': 'foo'}
    assert v['a'] == 1

# Generated at 2022-06-11 19:04:06.852052
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    args = []
    kwargs = {}
    v = VarsWithSources(*args, **kwargs)
    assert v.data == dict(*args, **kwargs)
    assert v.sources == {}
    key = u'key'
    value = u'value'
    v.data[key] = value
    v.sources[key] = u'key_value'
    assert v.get_source(key) == u'key_value'
    assert v.sources.get(key) == u'key_value'
    val = v[key]
    assert val == value


# Generated at 2022-06-11 19:04:17.209468
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    v_m = VariableManager()
    v_m.set_host_variable(host="127.0.0.1", varname="ansible_ssh_port", value=22)
    v_m.set_host_variable(host="127.0.0.2", varname="ansible_ssh_port", value=22)


# Generated at 2022-06-11 19:04:23.810395
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    vms = VariableManager()
    # set_host_facts() missing required argument `host`
    from ansible.errors import AnsibleAssertionError
    try:
        vms.set_host_facts()
    except TypeError as e:
        assert 'set_host_facts() missing 1 required positional argument: \'host\'' in str(e)
    else:
        raise Exception('Expected TypeError was not raised')

    # set_host_facts() missing required argument `facts`
    from ansible.errors import AnsibleAssertionError
    try:
        vms.set_host_facts('host')
    except TypeError as e:
        assert 'set_host_facts() missing 1 required positional argument: \'facts\'' in str(e)
    else:
        raise Exception('Expected TypeError was not raised')

   

# Generated at 2022-06-11 19:04:29.206321
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
	variablemanager = VariableManager()
	variablemanager.set_host_facts("ansible-node1", {'fact1': 'val1', 'fact2': 'val2'})
	variablemanager.set_host_facts("ansible-node2", {'fact1': 'val1', 'fact2': 'val2'})
	variablemanager.set_host_facts("ansible-node3", {'fact1': 'val1', 'fact2': 'val2'})
	assert variablemanager._fact_cache["ansible-node1"]['fact1'] == 'val1'
	assert variablemanager._fact_cache["ansible-node2"]['fact2'] == 'val2'
	assert variablemanager._fact_cache["ansible-node3"]['fact1'] == 'val1'


# Generated at 2022-06-11 19:05:19.672017
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    var_mgr =  VariableManager()
    fake_loader = DictDataLoader({
        'plays/playbook.yml': """
- name: playbook
  hosts: localhost
  gather_facts: false
  vars:
    a: 1
  tasks:
    - name: task
      vars:
        b: 2
      meta:
        end_play: true
""",
    })
    fake_inventory = HostsParser(loader=fake_loader).parse_inventory([])

# Generated at 2022-06-11 19:05:26.501255
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Set up test data
    options_vars = dict()
    # TODO: sort out how to test this properly
    #it = iter(self._dependent_host_vars[host].values())
    #host_variables = next(it)

    # Construct the object
    vm = VariableManager(loader=None, inventory=None, options_vars=options_vars)

    # Run the method
    host_variables = vm.get_vars(host=None)

    # Check the result
    assert host_variables is not None



# Generated at 2022-06-11 19:05:29.531769
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    response = object()
    print(response)

test_VariableManager_get_vars()


# Generated at 2022-06-11 19:05:36.624088
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Build a fixture for the test
    mock_host = sentinel.mock_host
    mock_facts = sentinel.mock_facts

    vm = VariableManager()

    vm.set_host_facts(mock_host, mock_facts)

    # This should have set the host name in the cache with the facts,
    # so grab it back so we can mock it.
    with patch('ansible.vars.host_cache.HostCache.set_host_facts') as mock_set_host_facts:
        vm.set_host_facts(mock_host, mock_facts)
        mock_set_host_facts.assert_called_once_with(mock_host, mock_facts)


# Generated at 2022-06-11 19:05:46.545844
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # using so-called 'classic' session v1
    display.verbosity = 3

    # Instantiate a new variable manager
    variable_manager = VariableManager()

    # Set a group vars file
    group_file = 'group_vars/group1'

    # Set a host vars file
    host_file = 'host_vars/host1'

    # Create a fake inventory
    inventory = Inventory(
        loader=DataLoader(),
        variable_manager=variable_manager,
        host_list=['fake_host'],
    )
    variable_manager.set_inventory(inventory)

    # Create a fake options
    options = Options()

    # Set some options
    options.connection = 'local'
    options.module_path = '/fake/path/ansible/modules'

    # Set the variable manager's options


# Generated at 2022-06-11 19:05:54.936540
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Ensure that set_host_facts doesn't change the original data since we are
    # updating the backing store
    original_facts = dict(a=1, b=2)

    fake_host = Host(name="bogus")
    vm = VariableManager()

    vm.set_host_facts(fake_host, original_facts)

    assert original_facts == vm.get_vars(host=fake_host)
    assert original_facts != vm._fact_cache[fake_host]


# Unit tests for method set_nonpersistent_facts of class VariableManager

# Generated at 2022-06-11 19:05:59.486746
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Declare all the test variables for this method
    variable_manager = VariableManager()
    host, facts = '', {}
    variable_manager.set_nonpersistent_facts(host, facts)
    return True


# Generated at 2022-06-11 19:06:08.158308
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()
    assert variable_manager.extra_vars == {}
    variable_manager.extra_vars = {'foo': 'bar'}
    assert variable_manager.extra_vars == {'foo': 'bar'}
    variable_manager.add_extra_vars({'baz': 'quux'})
    assert variable_manager.extra_vars == {'foo': 'bar', 'baz': 'quux'}
    variable_manager.update_extra_vars({'baz': 'quux_r'})
    assert variable_manager.extra_vars == {'foo': 'bar', 'baz': 'quux_r'}

# Generated at 2022-06-11 19:06:10.809161
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    v = VariableManager()
    v.set_nonpersistent_facts('host1', {"facts": "foo"})
    assert v._nonpersistent_fact_cache['host1'] == {"facts": "foo"}

# Generated at 2022-06-11 19:06:20.596068
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # initialize the variable manager object
    variable_manager = VariableManager()
    variable_manager._options_vars = {'option': 'value'}
    variable_manager.extra_vars = {'extra': 'var'}
    variable_manager.options_vars = {'option': 'vars'}

    inventory = MagicMock(spec=Inventory)
    inventory.get_groups_dict.return_value = {'group': 'name'}

    templar = MagicMock()
    templar.is_template.return_value = True
    templar.template.return_value = 'rendered_template'

    loader = MagicMock()
    loader.path_dwim.return_value = 'dwimmed_path'

    play = MagicMock(spec=Play)
    play.roles

# Generated at 2022-06-11 19:07:16.964175
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()

    varname = "foo"
    value = "xxx"

    host = "localhost"
    variable_manager.set_host_variable(host, varname, value)
    var_cache = variable_manager._vars_cache
    assert var_cache[host][varname] == value
    assert var_cache[host] == {varname: value}

    host = "localhost"
    new_value = "yyy"
    variable_manager.set_host_variable(host, varname, new_value)
    var_cache = variable_manager._vars_cache
    assert var_cache[host][varname] == new_value
    assert var_cache[host] == {varname: new_value}

    host = "localhost"

# Generated at 2022-06-11 19:07:19.501832
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vm = VariableManager()
    assert vm.get_vars() == {}



# Generated at 2022-06-11 19:07:28.347060
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # VariableManager is a helper function for playbooks, and is intended to be used
    # instead of accessing the variables dictionary directly.
    # It provides additional methods to aid in the use of variables
    #
    # Ansible uses a very simple YAML parser which is not a full YAML parser.
    # It expects that the first key in a series of maps is a string.
    # This just happens to work for the vast majority of cases where variables are used
    # but in rare cases, this can be a problem.

    # Setting up mock
    mod_mocked = mock.Mock()
    # Accessing the mocked classes and methods
    mocked_class = mod_mocked.VariableManager
    mocked = mocked_class.return_value

    # Declaring the test input data
    host = "127.0.0.1"

# Generated at 2022-06-11 19:07:38.746587
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    :return: A list of tests
    '''
    return [
        {
            "params": [
                "test_host"
            ],
            "method": "get_vars",
            "instance_method": True,
            "set_up": [
                {
                    "method": "set_host_facts",
                    "params": [
                        "test_host",
                        {
                            "test_fact": "test_fact_value"
                        }
                    ],
                    "set_up": []
                }
            ],
            "results": {
                "test_host": {
                    "test_fact": "test_fact_value",
                    "inventory_hostname": "test_host"
                }
            }
        }
    ]

# Generated at 2022-06-11 19:07:49.703165
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    class TestPlay(object):
        def __init__(self, *args, **kwargs):
            self.hosts = kwargs.get('hosts')
            self.roles = kwargs.get('roles')
            self._removed_hosts = kwargs.get('removed_hosts', list())
            self.finalized = True

        def get_name(self):
            return 'play'

    class TestRole(object):
        def __init__(self, *args, **kwargs):
            self.name = kwargs.get('name')
            self._role_path = kwargs.get('role_path')

        def get_name(self, include_role_fqcn=False):
            return self.name


# Generated at 2022-06-11 19:07:54.218293
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    variable_manager.set_host_variable('testhost', 'testvarname', 'testvalue')
    assert variable_manager._vars_cache['testhost']['testvarname'] == 'testvalue'

# Generated at 2022-06-11 19:08:00.419166
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Parameterized test case to test_set_nonpersistent_facts method of VariableManager class
    facts = {'test':'test'}
    host = 'localhost'
    vm = VariableManager()
    vm.set_nonpersistent_facts(host, facts)
    assert vm._nonpersistent_fact_cache[host].get('test') == 'test'

# Generated at 2022-06-11 19:08:08.754067
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Setup required variables
    host, varname, value = "test", "test", "test"
    var_manager = VariableManager(loader)
    # Start test
    var_manager.set_host_variable(host, varname, value)
    # Make assertions
    # TODO Create assertions
    # Teardown
    # TODO
    return


# Generated at 2022-06-11 19:08:16.846604
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    def get_fake_vm():
        vm = FakeVariableManager()
        vm.set_host_variable('local_host', 'var1', 'val1')
        vm._vars_cache = set_host_variable(vm._vars_cache, 'local_host', {'var_a': 'val_a'})
        vm._vars_cache = set_host_variable(vm._vars_cache, 'remote_host', {'var_b': 'val_b'})
        return vm

    def set_host_variable(vars_cache, host, value):
        if host not in vars_cache:
            vars_cache[host] = dict()
        vars_cache[host].update(value)
        return vars_cache

    vm = get_fake_vm()

# Generated at 2022-06-11 19:08:27.746169
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    inventory = Host('localhost')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager._vars_cache = dict()

    variable_manager.set_host_variable(host='localhost', varname='ansible_ssh_host', value='127.0.0.1')

    assert variable_manager._vars_cache['localhost']['ansible_ssh_host'] == '127.0.0.1'

    variable_manager._vars_cache['localhost'] = dict(ansible_ssh_host='127.0.0.2', ansible_ssh_user='root')
    variable_manager.set_host_variable(host='localhost', varname='ansible_ssh_host', value='127.0.0.1')


# Generated at 2022-06-11 19:09:27.167542
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Set up mock objects
    # TODO: Use unittest.mock.Mock when we use Python 3.
    mock_host = MagicMock()
    mock_task = MagicMock()
    mock_play = MagicMock()

    # Set up a VariableManager object
    var_mgr = VariableManager()

    # Set up the default arguments
    kwargs = {"play": mock_play, "task": mock_task, "host": mock_host, "include_delegate_to": False, "include_hostvars": True}

    # Try calling the get_vars method with no arguments
    var_mgr.get_vars(**kwargs)


# Generated at 2022-06-11 19:09:32.834074
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    """Parse inventory and get host variables."""
    vars_manager = VariableManager()
    vars_manager.extra_vars = {'test_key': 'test_value'}
    res = vars_manager.get_vars(play=None, host=None, task=None, include_delegate_to=False, include_hostvars=False)
    assert 'test_key' in res
    assert res['test_key'] == 'test_value'
    
# VariableManager

# store all of the host specific and variable data
#
# Note: this is not thread-safe, and should not be accessed outside the main
#  'fetch_file' thread
_HOSTVAR_CACHE = dict()


# Generated at 2022-06-11 19:09:38.905027
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''
    function: test_VariableManager
    Unit test for constructor of class VariableManager
    '''
    # Constructor test
    with pytest.raises(AnsibleError):
        VariableManager(host_cache=dict())
    with pytest.raises(AnsibleError):
        VariableManager(fact_cache=dict())

# Generated at 2022-06-11 19:09:45.405474
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vm = VariableManager()
    host = "host1"
    nonpersistent_facts = {"fact1":"value1"}
    vm.set_nonpersistent_facts(host, nonpersistent_facts)
    assert vm._nonpersistent_fact_cache[host] == nonpersistent_facts
    nonpersistent_facts2 = { "fact2" : "value2"}
    vm.set_nonpersistent_facts(host, nonpersistent_facts2)
    assert vm._nonpersistent_fact_cache[host] == {"fact1":"value1", "fact2": "value2"}
    

# Generated at 2022-06-11 19:09:58.570648
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    with pytest.raises(AnsibleError) as exc:
        VariableManager(loader=None, inventory=None, version_info=dict(major=1, minor=2, micro=3, releaselevel='final', serial=0)).get_vars(play=None, task=None, host=None)
    assert exc.value.args[0] == "'host' is required to load variables"

    variable_manager = VariableManager(loader=None, inventory=None, version_info=dict(major=1, minor=2, micro=3, releaselevel='final', serial=0))

    # host is None, exception thrown
    with pytest.raises(AnsibleError) as exc:
        variable_manager.get_vars(play=None, task=None, host=None)

# Generated at 2022-06-11 19:09:59.916373
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # TODO: add unit tests
    pass

# Generated at 2022-06-11 19:10:08.256191
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    v = {'some_key': 'some_value'}
    vm = VariableManager()
    vm.set_nonpersistent_facts('host', v)
    assert vm._nonpersistent_fact_cache['host'] == v
    vm.set_nonpersistent_facts('host', {'some_key': 'new values'})
    assert vm._nonpersistent_fact_cache['host'] == {'some_key': 'new values'}



# Generated at 2022-06-11 19:10:18.176933
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # test setup
    v = VariableManager()
    h = Host('name')
    options = Options()
    options.connection = 'smart'
    options.module_path = '/some/path'
    options.private_key_file = "some file"
    options.remote_tmp = 'some path'
    options.forks = 5
    options.become = True
    options.become_method = 'sudo'

    # get_vars() before setup
    with pytest.raises(AssertionError):
        v.get_vars()

    # setup
    v.set_inventory(Inventory(loader=DictDataLoader()))
    v.set_playbook_basedir('/test')
    v.set_options(options)

# Generated at 2022-06-11 19:10:30.339798
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    import pandas as pd
    import pymysql as mdb
    import csv
    import json
    import os
    import sys

    db_host = 'localhost'
    db_user = 'root'
    db_pass = ''
    db_name = 'ansible_qa'

    con = mdb.connect(db_host, db_user, db_pass, db_name)

    sql_Command1 = "SELECT DISTINCT(path) FROM ansible_qa.ansible_task_vars;"

    with con:
        cursor = con.cursor()
        cursor.execute(sql_Command1)
        print('Execute sql command 1 - succeeded')
        results1 = cursor.fetchall()
        results1 = list(result[0] for result in results1)

# Generated at 2022-06-11 19:10:36.922879
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test simple creation of VariableManager

    # Test VariableManager with valid Input
    # Test with loop

    # Test Error reporting
    # Test with missing options_vars
    # Test with missing inventory
    # Test with missing loader
    # Test with missing all
    # Test with missing options_vars and inventory
    # Test with missing options_vars, inventory and loader
    # Test with missing options_vars and loader
    pass


# Generated at 2022-06-11 19:11:26.310931
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    pass

    # TODO: write unit test

# Generated at 2022-06-11 19:11:27.810159
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # TODO: test get_vars
    pass



# Generated at 2022-06-11 19:11:35.641051
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    """
    Test set_host_variable method
    """

    class FakeFactCache:
        def __init__(self):
            self._fact_cache = {'test': None}

    class FakeVarsCache:
        def __init__(self):
            self._vars_cache = {'test': None}

    class FakeOptionsVars:
        pass

    class FakeInventory:
        pass

    class FakeLoader:
        pass

    class FakeTask:
        def __init__(self):
            self.vars = dict()

    class FakeOptions:
        def __init__(self):
            self.connection_plugins = dict()

    vm = VariableManager()
    vm._fact_cache = FakeFactCache()
    vm._vars_cache = FakeVarsCache()
    vm._nonpersistent_fact_cache

# Generated at 2022-06-11 19:11:47.230029
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Create variable manager instance
    v = variable_manager.VariableManager()

    # Create a dummy inventory
    inventory = inventory_manager.InventoryManager(loader=None, sources='')

    # Create a dummy options object
    options = Options()

    # Create a dummy loader instance
    loader = DataLoader()

    # Create a dummy play
    play = Play().load(dict(
            name = 'test play',
            hosts = 'all',
            tasks = [
                dict(action=dict(module='shell', args='ls')),
                dict(action=dict(module='debug', args=dict(msg='{{bar}} is {{baz}}')))
            ]
        ),
        variable_manager=v,
        loader=loader
    )

    # Load variables into variable manager
    v.add_group_vars_from_files

# Generated at 2022-06-11 19:11:59.062915
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    mock_options_vars = {'foo': 'bar'}
    mock_task = mock.MagicMock()
    mock_task.delegate_to = None
    mock_task.loop_with = None
    mock_task.loop = None
    mock_inventory = mock.MagicMock()
    mock_inventory.get_groups_dict.return_value = {}
    mock_loader = mock.MagicMock()
    mock_play = mock.MagicMock()
    mock_play.hosts = 'fake_host'
    mock_host = mock.MagicMock()
    mock_host.name = 'fake_host'
    mock_host.get_vars = mock.MagicMock()
    mock_host.get_vars.return_value = {}

# Generated at 2022-06-11 19:12:10.513696
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Static params
    file_name = 'test_variable_manager.yml'
    file_name_invalid = 'test_variable_manager_invalid.yml'
    file_name_jinja = 'test_variable_manager_jinja.yml'
    file_name_omit = 'test_variable_manager_omit.yml'
    file_name_deprecated = 'test_variable_manager_deprecated.yml'

    # Setup context

# Generated at 2022-06-11 19:12:16.111768
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    Test
    '''
    # Test variables
    inventory = mock.MagicMock(spec_set=InventoryManager)
    loader = mock.MagicMock(spec_set=DataLoader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test steps and expected results
    with pytest.raises(AnsibleError, message="Error: Missing required variable: 'var_name' is undefined"):
        variable_manager.get_vars(var_name=None)
    with pytest.raises(AnsibleError, message="Error: Missing required variable: 'var_name' is undefined"):
        variable_manager.get_vars()



# Generated at 2022-06-11 19:12:26.497400
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    class FakeHost(object):
        def __init__(self, name):
            self.name = name
            self.vars = dict()

    class FakePlay(object):
        def __init__(self, name, delegate_to=None):
            self.name = name
            self.delegate_to = delegate_to
            self.hosts = 'all'

    class FakeTask(object):
        def __init__(self, play, delegate_to=None):
            self.play = play
            self.delegate_to = delegate_to

    class FakeInventory(object):
        def __init__(self):
            pass

    class FakeLoader(object):
        def __init__(self):
            pass

    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-11 19:12:35.411087
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # VariableManager.__init__
    vm = VariableManager()
    assert isinstance(vm, VariableManager)
    vm = VariableManager(loader=None)
    assert isinstance(vm, VariableManager)
    vm = VariableManager(inventory=None)
    assert isinstance(vm, VariableManager)
    vm = VariableManager(loader=None, inventory=None)
    assert isinstance(vm, VariableManager)
    vm = VariableManager(loader=None, inventory=None, use_fact_cache=False)
    assert isinstance(vm, VariableManager)
    vm = VariableManager(loader=None, inventory=None, use_fact_cache=False, fact_cache=None)
    assert isinstance(vm, VariableManager)

# Generated at 2022-06-11 19:12:41.106334
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vm = VariableManager()
    hostname = 'test_host'
    facts = {'key': 'value'}
    vm.set_nonpersistent_facts(hostname, facts)
    result = vm._nonpersistent_fact_cache[hostname]
    assert result == facts