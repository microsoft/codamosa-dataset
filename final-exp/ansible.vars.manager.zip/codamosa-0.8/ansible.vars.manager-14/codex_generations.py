

# Generated at 2022-06-11 19:04:24.599906
# Unit test for constructor of class VariableManager
def test_VariableManager():
    v = VariableManager()
    assert not v.extra_vars
    assert not v._hostvars
    assert not v._vars_cache

    # Add an option var
    v.set_options_vars({"module_setup": "True"})
    assert v._options_vars is not None
    assert len(v._options_vars) == 1

    # Test the get_options_vars method
    options_vars_get = v.get_options_vars()

    assert options_vars_get is not None
    assert len(options_vars_get) == 1
    assert options_vars_get["module_setup"] == "True"



# Generated at 2022-06-11 19:04:34.470340
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Test setup
    sample_vars_cache = {'test_host': {'test_fact_1': 'value1'}}
    sample_fact_cache = {'test_host': {'test_fact_2': 'value2'}}
    sample_host_1 = 'host1'
    sample_host_2 = 'host2'
    sample_var = 'test_fact_1'
    sample_value_1 = 'value1'
    sample_value_2 = ['value2']
    sample_value_3 = {'key1':'value1', 'key2':'value2'}

    # Unit test
    test_VariableManager = VariableManager(loader=None, inventory=None, version_info=None)
    test_VariableManager.set_vars_cache(sample_vars_cache)
    test

# Generated at 2022-06-11 19:04:46.938646
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    v = VariableManager()

    # test exception
    with pytest.raises(AnsibleAssertionError) as error:
        v.set_host_facts('', 'some fact')
    assert "the type of 'facts' to set for host_facts should be a Mapping but is a " in error.value

    # test exception
    host_cache = {'a': 'b'}
    v._fact_cache[''] = host_cache
    with pytest.raises(TypeError) as error:
        v.set_host_facts('', {'c': 'd'})
    assert "The object retrieved for  must be a MutableMapping but was a" in error.value

    # test simple facts
    host_cache = {}
    v.set_host_facts('', {'c': 'd'})


# Generated at 2022-06-11 19:04:51.313523
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    '''
    Test for VariableManager.set_host_variable
    '''
    mock_var = {'varname': 'testvar', 'value': 'testvalue'}
    vm = VariableManager()
    vm.set_host_variable(mock_var['varname'], mock_var['value'])
    assert vm._vars_cache[mock_var['varname']] == mock_var['value']



# Generated at 2022-06-11 19:04:52.683829
# Unit test for constructor of class VariableManager
def test_VariableManager():
    v = VariableManager()
    assert v is not None


# Generated at 2022-06-11 19:05:02.577513
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-11 19:05:11.745171
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    vm = VariableManager()

    loader = DictDataLoader({
        'role1': dict(
            defaults=dict(
                default_var='role1_default',
            ),
            meta=dict(
                role_var='role1_role',
            ),
            vars=dict(
                role_var='role1_local',
            ),
        ),
        'role2': dict(
            defaults=dict(
                default_var='role2_default',
            ),
            meta=dict(
                role_var='role2_role',
            ),
            vars=dict(
                role_var='role2_local',
            ),
        ),
    })
    vm._

# Generated at 2022-06-11 19:05:20.462542
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # 1: set_host_variable(self, host, varname, value)
    # 2: set_host_variable(self, host, varname, value):
    #
    # 1: Ensure that VariableManager.set_host_variable() sets a value in the variable manager's vars_cache.
    # 2: Ensure that VariableManager.set_host_variable() updates a vars_cache value if that value is a dictionary
    #    and the value to be set is a dictionary.

    # Test 1
    # Setup
    var_man = VariableManager()
    var_man._vars_cache = {}
    host = "localhost"
    varname = "dummy_variable"
    value = "dummy_value"

    # Exercise
    var_man.set_host_variable(host, varname, value)

    # Verify

# Generated at 2022-06-11 19:05:30.575917
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    variable_manager = VariableManager()
    variable_manager._vars_cache = {'host': {'a': 1, 'b': 2}}
    variable_manager.extra_vars = {'a': 2, 'c': 3}
    variable_manager._options_vars = {'ansible_ssh_user': 'root', 'ansible_ssh_pass': 'pass'}
    variable_manager._omit_token = '~'

    # Do NOT include hostvars
    variables = variable_manager.get_vars(host=Host())
    assert variables == {'omit': '~', 'ansible_ssh_user': 'root', 'ansible_ssh_pass': 'pass'}

    # Include hostvars
    variables = variable_manager.get_vars(host=Host(), include_hostvars=True)

# Generated at 2022-06-11 19:05:36.062744
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # TODO: write a useful unit test for this method
    # This must be a method
    for i in [ 'string',
                      10,
                      1.0,
                      u'unicode',
                      [1,2,3],
                      { 'a': 1 },
                      (1,2),
                      True,
                      False,
                      None
                      ]:
        assert type(i) == type(VariableManager().set_host_variable(host='host', varname='varname', value='value'))



# Generated at 2022-06-11 19:06:06.585805
# Unit test for method set_host_facts of class VariableManager

# Generated at 2022-06-11 19:06:16.791072
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # create varmanager
    VariableManager = _VariableManager()
    # mock source_vars
    source_vars = {}
    VariableManager.source_vars = source_vars
    # mock loader
    loader = MagicMock()
    VariableManager.loader = loader
    # mock fact_cache
    fact_cache = {}
    VariableManager.fact_cache = fact_cache
    # mock host
    host = "host"
    # mock facts
    facts = {}
    VariableManager.set_host_facts(host, facts)
    assert VariableManager._fact_cache == {'host': {}}
    # assert set_host_facts calls init_cache
    assert VariableManager.init_cache.call_count == 1
    # mock host_cache 
    host_cache = {}

# Generated at 2022-06-11 19:06:29.695554
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Verify that the expected changes are made to the vars_cache when set_host_variable is called with valid input.
    from ansible.vars.hostvars import HostVars
    import ansible.vars.manager as vm

    my_vars_cache = HostVars(loader=None)
    my_vars_cache[None] = {"foo": "bar"}
    my_var_manager = vm.VariableManager(loader=None, inventory=None, version_info=ansible_version)
    my_var_manager._vars_cache = my_vars_cache

    my_var_manager.set_host_variable(None, "foo", "baz")
    assert my_var_manager._vars_cache[None]["foo"] == "baz"


# Generated at 2022-06-11 19:06:32.881801
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    def test_function():
        # Setup
        v = VariableManager()
        # Test
        v.get_vars()
        # Verify

    test_function()



# Generated at 2022-06-11 19:06:44.327526
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    fixture = {
        'ansible_search_path': [],
        'ansible_play_hosts': [],
        'ansible_play_hosts_all': [],
        'ansible_play_batch': [],
        'ansible_play_role_names': [],
        'ansible_dependent_role_names': [],
        'ansible_role_names': [],
        'ansible_play_name': [],
        'ansible_play_uuid': [],
        'ansible_play_path': [],
        'play_hosts': [],
        'groups': [],
        'omit': []
    }
    vm = VariableManager(loader=None, inventory=None, play_context=None)
    result = vm.get_vars()
    assert result == fixture

# Generated at 2022-06-11 19:06:46.312342
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
  manager = VariableManager()
  assert manager.get_vars() == {}

  # TODO: Test with a real inventory, play, host and task

# Generated at 2022-06-11 19:06:53.702847
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    from ansible.inventory.host import Host
    v = VariableManager()
    h = Host(name='test')
    assert v.set_host_variable(h, 'test_var', 'test_value') == None
    assert v.get_vars(host=h)['test_var'] == 'test_value'
    assert v.set_host_variable(h, 'test_var2', dict(a=1)) == None
    assert v.get_vars(host=h)['test_var2']['a'] == 1
    assert v.set_host_variable(h, 'test_var', dict(b=2)) == None
    assert v.get_vars(host=h)['test_var']['a'] == 1

# Generated at 2022-06-11 19:07:03.425867
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    '''
    This method test the functionality of set_host_variable()
    of VariableManager class.
    
    set_host_variable() method sets the given value to the varname
    of host in the _vars_cache
    '''

    # Puppet, manager = _setup_mocks(dict(foo='bar'))
    # Puppet.assert_called_with()

    # manager.get_vars(host=mock.ANY).AndReturn({})
    # manager.set_host_variable(host, '_ansible_no_log', True)

    # manager.set_host_variable(host, '_ansible_no_log', False)
    # manager.get_vars(host).AndReturn({})
    # manager.set_host_variable(host, '_ansible_no_log', True)



# Generated at 2022-06-11 19:07:12.332639
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    inventory = InventoryManager(loader=None, sources=None, 
                                              vault_password=None, 
                                              use_vault_over_ssh=False)
    variableManager = VariableManager(loader=None, inventory=inventory, use_vault=False, vault_password=None)

    assert variableManager.get_vars() == {}
    variableManager.extra_vars = {"a": "b"}
    assert variableManager.get_vars() == {"a": "b"}
    assert variableManager.get_vars(play=None) == {"a": "b"}
    assert variableManager.get_vars(play=None, include_hostvars=True) == {'inventory_hostname': None, 'a': 'b', 'hostvars': {}}

# Generated at 2022-06-11 19:07:23.663534
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    
    # Named Variable manager 'vm'
    # Args: loader=loader, inventory=inventory, version_info=version_info
    vm = VariableManager(loader=None, inventory=None, version_info=None)

    # Args: play=None, host=None, task=None, task_vars=dict(), include_delegate_to=True
    # include_hostvars=True, include_role_vars=True
    vm.get_vars(play=None, host=None, task=None, task_vars=dict(), include_delegate_to=True,
    include_hostvars=True, include_role_vars=True)

    # Args: play=None, host=None, task=None, include_delegate_to=True
    # include_hostvars=True
    vm

# Generated at 2022-06-11 19:08:13.963470
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    from itertools import chain
    from ansible.errors import AnsibleAssertionError
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    # Test object attributes
    data = {'foo': ['bar', 'baz']}
    variable_manager = VariableManager()
    variable_manager._vault_password = VaultLib(None)._password

    # Test method attributes
    host = 'test_host'
    facts = {'hello': 'world', 'foo': {'bar': 'baz'}}

    # Test exception handling
    with pytest.raises(AnsibleAssertionError):
        variable_manager.set_host_facts('test_host', ['foo', 'bar'])

# Generated at 2022-06-11 19:08:14.913993
# Unit test for constructor of class VariableManager
def test_VariableManager():
    v = VariableManager()
    assert v

# Generated at 2022-06-11 19:08:26.939597
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # We will test this method for all the following cases:
    #   1. no play, no task, no host
    #   2. play but no task, no host
    #   3. task but no play, no host
    #   4. host but no play, no task
    #   5. task and play, but no host
    #   6. task and host, but no play
    #   7. play and host, but no task
    #   8. play, task and host
    #   9. play, task and host with hostvars

    class FakePlay:
        name = 'fakeplay'
        hosts = 'fakehost'
        _removed_hosts = list()

        def get_name(self):
            return self.name

        def get_hosts(self):
            return self.hosts


# Generated at 2022-06-11 19:08:30.111404
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    if __name__ == '__main__':
        print(VariableManager().get_vars())

# Generated at 2022-06-11 19:08:36.511460
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # We will test if the method raises the error it is supposed to raise
    # in case of the unexpected datatype of its arguments.
    # To test this, we prepare a fake argument for the `host` argument for the method.
    # The `host` argument is required to be of type `Host`, and is defined as accepting a
    # single value. Therefore, it raises an error if we pass a datatype other than `Host`.
    from ansible.inventory.host import Host
    from ansible.errors import AnsibleAssertionError
    from six import string_types
    import os
    import pytest

    # A list of fake values that are not of type `Host`, and are passed to the `host` argument

# Generated at 2022-06-11 19:08:45.070041
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars

    variable_manager = VariableManager()

    hostvars = HostVars()
    variable_manager.set_host_variable('localhost', 'foo_bar', 'baz')
    variable_manager.set_host_variable('localhost', 'baz', 1)
    variable_manager.set_hostvars(hostvars)

    inventory_manager = InventoryManager(host_list=['localhost'])
    variable_manager.set_inventory(inventory_manager)

    context = PlayContext()
    play = Play()

# Generated at 2022-06-11 19:08:54.402643
# Unit test for method get_vars of class VariableManager

# Generated at 2022-06-11 19:09:04.216795
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Test all combinations of arguments:
    # play, host, task, include_delegate_to, include_hostvars

    # play, host, task, include_delegate_to, include_hostvars
    # test parameters
    my_host = Host('myhost')
    my_host.vars = dict(
        item = 'value',
        item2 = {'key2': 'value2'}
    )
    my_host.set_variable('ansible_connection', 'local')
    my_host.set_variable('ansible_python_interpreter', 'value')
    my_host.set_variable('ansible_host', 'value')
    my_host.set_variable('ansible_port', 'value')
    my_host.set_variable('ansible_user', 'value')
    my

# Generated at 2022-06-11 19:09:15.805578
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    def test():
        import ansible.playbook.play_context
        import ansible.plugins.loader
        import ansible.template
        import ansible.vars.manager
        import ansible.vars.hostvars
        import ansible.vars.unsafe_proxy
        import ansible.utils.unsafe_proxy
        import unit_tests.utils as utils
        _ = ansible.playbook.play_context.PlayContext()
        _ = ansible.plugins.loader.__loader__
        _ = ansible.template.__loader__
        _ = ansible.vars.manager.__loader__
        _ = ansible.vars.hostvars.__loader__
        _ = ansible.vars.unsafe_proxy.__loader__
        _ = ansible.utils.unsafe_proxy.__loader

# Generated at 2022-06-11 19:09:20.841177
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts('host', {'a': 'b'})
    variable_manager.set_nonpersistent_facts('host', {'c': 'd'})
    variable_manager.set_nonpersistent_facts('host', {'c': 'x'})
    assert variable_manager.get_vars(host=Host(name='host'), include_hostvars=True).get('c') == 'x'


# Generated at 2022-06-11 19:10:01.398404
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from ansible.module_utils import basic
    from ansible.module_utils.common.removed import removed_module

    module_loader = DictDataLoader({})
    module_manager = basic.AnsibleModuleManager(module_loader=module_loader)
    templar = Templar(loader=module_loader)

    inventory = InventoryManager(loader=module_loader, sources='localhost,')
    inventory.add_host(host='localhost')
    inventory_sources = ','.join(inventory.sources)
    inventory_hosts = [h.name for h in inventory.get_hosts(pattern='all')]
    vars_manager = VariableManager(loader=module_loader, inventory=inventory)

    # Now create a task so we can test that vars are available.

# Generated at 2022-06-11 19:10:13.205394
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager()
    variable_manager._fact_cache = {'test_fact_cache': {'key': 'value'}}
    assert variable_manager.get_vars() == {}
    assert variable_manager.get_vars(host=Host(name='test_name')) == {}
    assert variable_manager.get_vars(host=Host(name='test_name'), include_hostvars=True) == {'hostvars': {'test_name': {'ansible_facts': {'key': 'value'}}}}
    assert variable_manager.get_vars(host=Host(name='test_name'), task=Task(), include_hostvars=True) == {'hostvars': {'test_name': {'ansible_facts': {'key': 'value'}}}}
    # TOD

# Generated at 2022-06-11 19:10:20.905477
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Set up mock objects
    fact_cache = MagicMock()
    tqm = MagicMock()
    loader = MagicMock()

    # Instantiate object
    vm = VariableManager(tqm=tqm, loader=loader, fact_cache=fact_cache)


    # This code path is not tested by Ansible
    if False:
        vm.set_nonpersistent_facts('host', 'facts')
        vm._nonpersistent_fact_cache = {'host': 'facts'}
        vm.set_nonpersistent_facts('host', 'facts')

    # This code path is not tested by Ansible
    if False:
        vm.set_nonpersistent_facts('host', 'facts')
        vm._nonpersistent_fact_cache = {}

# Generated at 2022-06-11 19:10:22.234198
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    run_unit_test(VariableManager, 'get_vars')


# Generated at 2022-06-11 19:10:27.716261
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    variable_manager = VariableManager(loader=None, inventory=None)
    args = []
    kwargs = {}
    retval1 = variable_manager.get_vars(*args, **kwargs)
    assert isinstance(retval1, dict)


# Generated at 2022-06-11 19:10:38.646035
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext, CLIContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.module_utils.six import iteritems

    host_1 = Host(name=u"server1.domain.tld", port=22)
    host_1.vars = dict(ansible_host=u"1.2.3.4", ansible_connection='local', other_var=u"foo")

    host_2 = Host(name=u"server2.domain.tld", port=22)
   

# Generated at 2022-06-11 19:10:49.398880
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    host = Host(name='localhost')
    facts = {}
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    # Case 1: Set facts for existing host
    existing_facts = {'foo': 'bar'}
    variable_manager.set_host_facts(host, existing_facts)
    facts = variable_manager.get_host_facts(host)
    assert isinstance(facts, MutableMapping)
    assert facts.get('foo') == 'bar'

    # Case 2: Set facts for new host
    variable_manager.clear_facts(host.name)
    new_facts = {'bar': 'foo'}
   

# Generated at 2022-06-11 19:10:50.578752
# Unit test for constructor of class VariableManager
def test_VariableManager():
    v = VariableManager()
    assert v is not None, 'Unable to create VariableManager'

# Generated at 2022-06-11 19:10:52.313821
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Test set_host_facts method of VariableManager class
    # assert VariableManager.set_host_facts(host, facts) == expected

    # assert type_error_message(VariableManager.set_host_facts, host, facts) == expected
    pass # TODO: implement your test here


# Generated at 2022-06-11 19:10:54.928376
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Initializing a VariableManager without arguments
    # should fail without an inventory
    with pytest.raises(AnsibleError):
        VariableManager()



# Generated at 2022-06-11 19:12:03.103277
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Test with a bare inventory
    v = VariableManager()
    assert not v._fact_cache
    assert not v._nonpersistent_fact_cache
    assert not v._vars_cache
    assert not v._hostvars
    assert not v._omit_token

    # Test with an inventory and with _fact_cache and _vars_cache
    i = InventoryManager(Loader())
    v = VariableManager(loader=None, inventory=i)
    assert not v._fact_cache
    assert not v._nonpersistent_fact_cache
    assert not v._vars_cache
    assert v._hostvars == {}
    assert not v._omit_token

    # Test with an inventory  _hostvars and omit_token
    i = InventoryManager(Loader())

# Generated at 2022-06-11 19:12:13.153903
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import Inventory

    def get_mgr_class():
        from lib.ansible.playbook.play_context import PlayContext
        from lib.ansible.vars.manager import VariableManager
        return VariableManager

    def get_mgr(inventory=None, loader=None, play_context=None):
        return get_mgr_class()(
            loader=loader,
            inventory=inventory,
            play_context=play_context
        )


# Generated at 2022-06-11 19:12:15.857844
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    '''
    Unit test for VariableManager.get_vars
    '''
    obj = VariableManager()
    assert False # TODO


# Generated at 2022-06-11 19:12:26.375946
# Unit test for constructor of class VariableManager
def test_VariableManager():
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Test that both UnsafeProxy or simple dictionaries will be accepted as _vars_cache
    assert VariableManager(vars_cache=None)._vars_cache == dict()
    assert VariableManager(vars_cache=UnsafeProxy(dict()))._vars_cache == dict()

    # Test that the vars_cache passed in is not modified during construction
    vars_cache = {'foo': 'bar'}
    vars_cache_copy = vars_cache.copy()
    assert VariableManager(vars_cache=vars_cache)._vars_cache == vars_cache
    assert vars_cache == vars_cache_copy

    # The following test is required because the fact_cache and nonpersistent_fact_cache
    # variables could

# Generated at 2022-06-11 19:12:35.408773
# Unit test for method set_nonpersistent_facts of class VariableManager

# Generated at 2022-06-11 19:12:40.547375
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vm = VariableManager()
    vm.set_inventory(None)
    facts = vm.get_vars()
    assert facts == {'omit': None, 'inventory_dir': None, 'playbook_dir': None}, facts

# Generated at 2022-06-11 19:12:51.946840
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    _load_recursive_roles()
    _init_vars_cache()
    '''Test case for the get_vars method of VariableManager
    '''
    global _vars_cache
    global _play_context
    global _nonpersistent_fact_cache
    vars_manager = VariableManager()
    global _fact_cache
    vars_manager._fact_cache = _fact_cache
    vars_manager._vars_cache = _vars_cache
    vars_manager._nonpersistent_fact_cache = _nonpersistent_fact_cache
    vars_manager._play_context = _play_context
    vars_manager._all_vars = defaultdict(dict)
    vars_manager._host_specific_vars = defaultdict(dict)

    # First test where we should load the

# Generated at 2022-06-11 19:12:52.704859
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    pass

# Generated at 2022-06-11 19:12:54.060550
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # TODO:
    pass


# Generated at 2022-06-11 19:12:56.080734
# Unit test for constructor of class VariableManager
def test_VariableManager():
    inventory = Inventory(host_list=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    assert variable_manager._inventory == inventory

