

# Generated at 2022-06-23 15:09:22.998792
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    '''
    Tests that the VarsWithSources class behaves as a dict-like object with a dict constructor
    '''
    # dict constructor
    v = VarsWithSources({"foo": "bar"})
    assert isinstance(v, MutableMapping)
    assert isinstance(v.data, MutableMapping)
    assert len(v) == 1
    assert list(v) == ["foo"]
    assert v["foo"] == "bar"
    assert v.get_source("foo") is None
    assert "foo" in v
    assert "bar" not in v
    v["bar"] = "foo"
    assert "bar" in v
    v["bar"] = "bar"
    assert "bar" in v
    del v["foo"]
    assert len(v) == 1

# Generated at 2022-06-23 15:09:32.681984
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    fact_cache = dict()
    fact_cache['host1'] = {'ansible_fact1': 'value1', 'ansible_fact2': 'value2'}
    fact_cache['host2'] = {'ansible_fact1': 'value1', 'ansible_fact2': 'value2'}

    nonpersistent_fact_cache = {'host1': {'ansible_loop_var1': 'value1', 'ansible_loop_var2': 'value2'},
                            'host2': {'ansible_loop_var1': 'value1', 'ansible_loop_var2': 'value2'}}
    vars_cache = fact_cache.copy()

    inventory = MagicMock()
    inventory.get_host.return_value = inventory

    options_vars = dict()
    options

# Generated at 2022-06-23 15:09:35.596378
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    '''Unit test for method VariableManager.__setstate__'''
    pass


# Generated at 2022-06-23 15:09:37.848801
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    v = VarsWithSources({'a':1})
    assert('a' in v)
    assert('b' not in v)


# Generated at 2022-06-23 15:09:41.979953
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    "VarsWithSources.__contains__ works as expected"
    # VarsWithSources as a dict behaves not quite as expected
    vws = VarsWithSources({'a': 'b'})
    assert 'a' in vws


# Generated at 2022-06-23 15:09:50.892516
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():

    # Setup
    ansible = Ansible()
    ansible.vars_cache.set_host_variable('test_host', 'vars_with_sources_test',
                                         VarsWithSources(dict(a='old_value')))
    vws = ansible.vars_cache.get_host_vars('test_host')['vars_with_sources_test']

    # Test
    assert vws.data['a'] == 'old_value'
    vws['a'] = 'new_value'

    # Verify
    assert vws.data['a'] == 'new_value'


# Generated at 2022-06-23 15:09:52.108100
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    VarsWithSources(dict(a=2, b=3)).__iter__()

# Generated at 2022-06-23 15:10:03.238345
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    loader = DictDataLoader({})
    inventory = Hosts()
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    options = Options()

    variable_manager._file_vars_cache = {'host1': {'file1': [{'foo': 'bar'}]}}
    variable_manager._fact_cache = {'host1': {'fact1': 'value1'}}
    variable_manager._vars_cache = {'host1': {'var1': 'value1'}}
    variable_manager.extra_vars = {'extra1': 'value1'}
    variable_manager.extra_vars_files = ['foo', 'bar']
    variable_manager.options_vars = {'baz': 'qux'}
    variable_manager.options = Options()
    variable_

# Generated at 2022-06-23 15:10:13.787102
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # The following lines are a workaround the fact that Ansible2.8 doesn't
    # support the filename attribute of NamedTemporaryFile
    from ansible.utils.hashing import hash_local_file
    # hash_local_file doesn't return the same hash for a file object as for a path
    # for Ansible 2.7
    mock_hash = lambda x: 'mocked'
    path = os.path.join(tempfile.mkdtemp(prefix='tmp-ansible-test-artifact-'), 'test.yml')
    with open(path, 'w') as f:
        # This is the code from the NamedTemporaryFile object that I'm trying to mock
        # f.name = name
        # f.filename = name
        f.write("input: var1: 'value1' var2: 'value2'")



# Generated at 2022-06-23 15:10:24.767211
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    import pytest
    data_vars_with_sources = {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}
    vars_with_sources = VarsWithSources(data_vars_with_sources)
    assert type(vars_with_sources.__iter__()).__name__ == 'dict_keyiterator'
    assert next(vars_with_sources.__iter__()) == 'k1'
    assert next(vars_with_sources.__iter__()) == 'k2'
    assert next(vars_with_sources.__iter__()) == 'k3'
    with pytest.raises(StopIteration):
        next(vars_with_sources.__iter__())

# Generated at 2022-06-23 15:10:28.814546
# Unit test for constructor of class VariableManager
def test_VariableManager():
    inventory = Inventory("tests/test_inventories/inventory1")
    options = Options()
    loader = DataLoader()
    vmanager = VariableManager(loader=loader, inventory=inventory, options=options)
    assert vmanager is not None


# Generated at 2022-06-23 15:10:34.631710
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    os.environ['ANSIBLE_VAR_PLUGINS'] = 'plugins/variables'
    os.environ['ANSIBLE_VAR_PLUGINS_STRICT'] = 'False'
    inventory = Inventory('localhost')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.__setstate__(None)

# Generated at 2022-06-23 15:10:36.586904
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'a': 'b'})
    v['a']

# Generated at 2022-06-23 15:10:40.499344
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    instance = VarsWithSources({'1':'2', '3':'4'}, {'1':'top', '3':'top'})

    result = instance.__len__()

    assert result == 2


# Generated at 2022-06-23 15:10:47.357703
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    args = [{'a': 1, 'b': 2, 'c': 3}]
    kwargs = {}
    x = VarsWithSources(*args, **kwargs)
    assert x['a'] == 1
    assert x['b'] == 2
    assert x['c'] == 3
    del x['b']
    assert x['a'] == 1
    assert x['c'] == 3
    with pytest.raises(KeyError):
        x['b']


# Generated at 2022-06-23 15:10:53.899980
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # VariableManager.set_host_facts() with non-Mapping facts
    vm = VariableManager()
    hn = 'host'
    facts = 'non-Mapping facts'
    try:
        vm.set_host_facts(host=hn, facts=facts)
    except AnsibleAssertionError as e:
        assert "the type of 'facts' to set for host_facts should be a Mapping but is a " in str(e)


# Generated at 2022-06-23 15:11:02.507894
# Unit test for function preprocess_vars
def test_preprocess_vars():
    from ansible.errors import AnsibleError
    assert preprocess_vars(None) is None
    assert preprocess_vars({'a':1}) == [{'a':1}]
    assert preprocess_vars([{'a':1},{'b':2}]) == [{'a':1},{'b':2}]
    assert preprocess_vars([{'a':1},{'b':2},{'c':None}]) == [{'a':1},{'b':2},{'c':None}]
    assert preprocess_vars({'a':1,'b':2}) == [{'a':1,'b':2}]

# Generated at 2022-06-23 15:11:05.470617
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    v = VarsWithSources({'a': 1, 'b': 2, 'c': 3})
    assert len(v) == 3
    v['d'] = 4
    assert len(v) == 4
    del(v['a'])
    assert len(v) == 3
    len(v)

# Generated at 2022-06-23 15:11:09.507339
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    host = 'host_name'
    varname = 'var_name'
    value = 'var_value'
    vm = VariableManager()

    print('Setting values ...')
    vm.set_host_variable(host, varname, value)
    print('Printing values ...')
    print(vm._vars_cache)


# Generated at 2022-06-23 15:11:12.082157
# Unit test for constructor of class VariableManager
def test_VariableManager():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    variable_manager.set_inventory(None)

# Generated at 2022-06-23 15:11:17.402454
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    '''
    Test set_inventory
    '''
    v = VariableManager()
    i = Inventory(loader=None, variable_manager=None, host_list=[])
    v.set_inventory(i)
    assert v._inventory == i


# Generated at 2022-06-23 15:11:27.145439
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    varm = VariableManager(loader=DictDataLoader)

# Generated at 2022-06-23 15:11:39.425032
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Create a "canned" inventory, a loader, and some hosts to work with
    inv = Inventory(loader=None, variable_manager=None, host_list=['test1', 'test2'])
    loader = DataLoader()
    host = Host(name='test1')
    host2 = Host(name='test2')

    vm = VariableManager(loader=loader, inventory=inv)

    # Simple test to make sure the variable manager doesn't crash when asking for
    # variables that aren't present
    vm.get_vars(host, play=None, task=None, include_hostvars=True)

    # Add some variables and make sure we get them back, replacing them as we go
    # Also test that variables can resolve to other variables in the same set

# Generated at 2022-06-23 15:11:43.634159
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    
    var = VarsWithSources({1:1, 2:2, 3:3})
    var.__delitem__(3)
    assert len(var) == 2
    assert 1 in var
    assert 2 in var
    assert 3 not in var


# Generated at 2022-06-23 15:11:53.553437
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    v = VariableManager(loader=None, inventory=None, version_info=cmdline.version_info(gitinfo=False))
    v.vars_cache = None
    v.fact_cache = None
    v.extra_vars = None
    v.options_vars = None
    v.hostvars = None
    v.omit_token = None
    v.__setstate__(dict(vars_cache='_vars_cache', fact_cache='_fact_cache', extra_vars='_extra_vars', options_vars='_options_vars', hostvars='_hostvars', omit_token='_omit_token'))
    assert v.vars_cache == '_vars_cache'
    assert v.fact_cache == '_fact_cache'
    assert v.extra

# Generated at 2022-06-23 15:11:56.099201
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vm = VariableManager()
    vm.set_nonpersistent_facts('foo', dict(a=1))
    assert vm._nonpersistent_fact_cache['foo']['a'] == 1
    


# Generated at 2022-06-23 15:12:03.701183
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources({'a': 'b'})
    assert v == {'a': 'b'}

    v = VarsWithSources.new_vars_with_sources({'a': 'b'}, {'a': 'v'})
    assert v == {'a': 'b'}
    assert v.get_source('a') == 'v'

    assert v.copy() == {'a': 'b'}
    assert v.copy() != {'a': 'c'}
    assert v.copy().sources == {'a': 'v'}

# Generated at 2022-06-23 15:12:12.612914
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    a = VarsWithSources.new_vars_with_sources({'a':1, 'b':2}, {'a':'s'})
    b = a.copy()
    assert a is not b
    assert a.data is not b.data
    assert a.sources is not b.sources
    assert a.data == b.data
    assert a.sources == b.sources
test_VarsWithSources_copy.unittest = ['.vars_with_sources']



# Generated at 2022-06-23 15:12:13.760487
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    # Specify the parameters
    inventory = None
    # Executing the method
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 15:12:24.707685
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Initializing below host_var_value,
    # vars_cache with host_var_value,
    # varname,hostname,value and VariableManager Object
    host_var_value = {'common_var': 'common_var_value'}
    vm = VariableManager()
    vm._vars_cache = host_var_value
    varname = 'varname'
    hostname = 'hostname'
    value = 'value'
    # set_host_variable method called with varname,
    # hostname, value and vm
    vm.set_host_variable(hostname, varname, value)
    # Asserting whether _vars_cache is equal to expected_vars_cache

# Generated at 2022-06-23 15:12:29.289003
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    v = VarsWithSources({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    for k, vl in zip(['a', 'b', 'c', 'd'], [1, 2, 3, 4]):
        assert v[k] == vl

# Generated at 2022-06-23 15:12:34.882481
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    obj = VarsWithSources(dict(a="b", c="d"))
    obj.__contains__("a")
    obj.__contains__("b")
    obj.__contains__("c")
    obj.__contains__("d")
    obj.__contains__("e")
    obj.__contains__("f")


# Generated at 2022-06-23 15:12:43.131076
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    data = {'a': 'a_value', 'b': 'b_value'}
    sources = {'a': 'a_source', 'b': 'b_source'}

    vws = VarsWithSources.new_vars_with_sources(data.copy(), {'a': 'a_source',
                                                               'b': 'b_source'})
    vws['c'] = 'c_value'
    vws['d'] = 'd_value'
    vws.sources['c'] = 'c_source'
    vws.sources['d'] = 'd_source'

    vws_copy = vws.copy()

    # data dictionary should be deep copied
    assert_not_equals(id(vws.data), id(vws_copy.data))

    # sources dictionary

# Generated at 2022-06-23 15:12:53.001675
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    import os
    loader = DataLoader()
    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    group_name = 'test_VarsWithSources___delitem___group'
    host_name = 'test_VarsWithSources___delitem___host'

# Generated at 2022-06-23 15:12:56.052277
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    # get the class object
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory='inventory')
    # TODO: implement test
    assert False


# Generated at 2022-06-23 15:12:59.360313
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    w = VarsWithSources()
    assert len(w) == 0

###############################################################################
# Cacheable dict, backed by a dict.
###############################################################################

# Generated at 2022-06-23 15:13:01.823425
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    assert VariableManager().set_host_facts('', '') == None


# Generated at 2022-06-23 15:13:09.516006
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    # Get info about the directory that contains the module being tested
    mod_dir = os.path.dirname(sys.modules[__name__].__file__)

    # Load the fixtures for this test
    test_data, test_vars = load_fixture_data(mod_dir, "VarsWithSources_get_source")

    # Create the variables cache
    vars_cache = {}

    # Create instance of class VarsWithSources
    v = VarsWithSources.new_vars_with_sources(test_data, test_vars)

    # Iterate the test cases
    for test_case in test_data['test_cases']:
        # Get the last_key for the test case
        last_key = test_case['last_key']

        res = v.get_source(last_key)

       

# Generated at 2022-06-23 15:13:19.877418
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    loader = DictDataLoader({
        'file1.yml': textwrap.dedent("""
        foo:
          item1: 1
          item2: 2
        """),
        'file2.yml': textwrap.dedent("""
        bar:
          - key1: val1
        """)
    })

    playbook = Playbook.load('', loader, variable_manager=VariableManager())
    play1 = Play.load({'name': 'play1'}, loader=loader, variable_manager=playbook.get_variable_manager())
    play2 = Play.load({'name': 'play2'}, loader=loader, variable_manager=playbook.get_variable_manager())
    play1.register_loader(loader)
    play2.register_loader(loader)

# Generated at 2022-06-23 15:13:23.442641
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    ''' method VarsWithSources.get_source should return None if no source is provided '''
    v = VarsWithSources()
    assert v.get_source('foo') is None


# Generated at 2022-06-23 15:13:31.931220
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    inventory = InventoryManager(loader=NullLoader(), sources=[])
    v = VarsWithSources({"a":1,"b":2,"c":3})
    v.sources["a"] = "inventory"
    v.sources["b"] = "command line"
    v.sources["c"] = "some test"
    ansible_vars = AnsibleVars(v, None, inventory, None, None)
    del ansible_vars._vars_cache["a"]
    assert len(v.data) == 2
    assert "a" not in v.data

# Generated at 2022-06-23 15:13:40.476408
# Unit test for function preprocess_vars
def test_preprocess_vars():
    # Test no vars
    assert preprocess_vars(None) is None

    # Test list of dictionaries
    vars_list = [{'a': 'foo'}, {'b': 'bar'}]
    assert preprocess_vars(vars_list) == vars_list

    # Test list of non-dictionaries
    with pytest.raises(AnsibleError):
        assert preprocess_vars([{'a': 'foo'}, 'b'])

    # Test dictionary
    vars_dict = {'a': 'foo', 'b': 'bar'}
    assert preprocess_vars(vars_dict) == [vars_dict]


# Generated at 2022-06-23 15:13:45.668049
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    '''
    Test that VarsWithSources can be instantiated
    '''
    v = VarsWithSources({'a': 1}, b=2)
    assert isinstance(v, VarsWithSources)
    assert v.get('a') == 1
    assert v.get('b') == 2



# Generated at 2022-06-23 15:13:47.587850
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    vws = VarsWithSources({"a": 1, "b": 2})
    assert vws["a"] == 1
    assert vws["b"] == 2
    assert vws["c"] == KeyError
    del vws["a"]
    assert vws["a"] == KeyError


# Generated at 2022-06-23 15:13:49.143021
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    h = VariableManager()


# Generated at 2022-06-23 15:13:52.326938
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    data = dict()
    sources = dict()
    v = VarsWithSources.new_vars_with_sources(data, sources)
    class Foo:
        pass
    vars = Foo()
    vars.abc = 77
    vars.foo = 'bar'
    vars.data = 'baz'
    data['vars'] = vars
    sources['vars'] = 'playbook'
    v['data'] = data
    v['sources'] = sources


# Generated at 2022-06-23 15:13:56.058288
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    v = VarsWithSources({'a': 1, 'b': 2})
    assert 'a' in v
    assert 'b' in v
    assert 'c' not in v

# Generated at 2022-06-23 15:14:02.911519
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    v = VarsWithSources({'a': 1, 'b': 2})
    v.sources = {'a': 'source1', 'b': 'source2'}
    assert v.get_source('a') == 'source1'
    assert v.get_source('b') == 'source2'
    assert v.get_source('c') is None



# Generated at 2022-06-23 15:14:14.817861
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    '''
    This function will perform unit test for method __contains__ of class VarsWithSources.
    '''
    from ansible.module_utils.basic import AnsibleModule
    # Declare the argument specification for the method __contains__ of class VarsWithSources
    fields = {
        "word": {"required": True, "type": "str"},
    }
    # Declare the module, including argument specification
    module = AnsibleModule(argument_spec=fields)
    # Get the input parameter(s)
    word = module.params['word']
    # Get the method to be tested
    VarsWithSources_ = VarsWithSources()
    # Perform the test

# Generated at 2022-06-23 15:14:16.252952
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    assert False

# Generated at 2022-06-23 15:14:26.029708
# Unit test for method set_host_variable of class VariableManager

# Generated at 2022-06-23 15:14:35.202291
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    MYVARS = dict(A="1", B="2", C="3")
    SRC = dict(A="A", B="B", C="C")
    v = VarsWithSources(MYVARS)
    assert v.data == MYVARS
    assert v.sources == {}

    v = VarsWithSources.new_vars_with_sources(MYVARS, SRC)
    assert v.data == MYVARS
    assert v.sources == SRC

    v = VarsWithSources.new_vars_with_sources(MYVARS, SRC).copy()
    assert v.data == MYVARS
    assert v.sources == SRC



# Generated at 2022-06-23 15:14:46.756218
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    testvars = {'testvar': 'testvalue'}
    testvars_new = {'testvar': 'testvalue_new', 'testvar2': 'testvalue2'}
    testhost = 'testhost'
    hostvars = {testhost: testvars}
    hostvars_new = {testhost: testvars_new}
    vm = VariableManager(loader=None, inventory=None)
    vm._vars_cache = hostvars.copy()
    vm.set_host_variable(testhost, 'testvar', testvars_new['testvar'])
    if vm._vars_cache != hostvars_new:
        raise AssertionError('VariableManager set_host_variable test 1 failed, value got: %s' % vm._vars_cache)
    vm._vars_

# Generated at 2022-06-23 15:14:52.737023
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
   import random
   import string
   random_string = ''.join([random.choice(string.printable) for n in range(32)])
   vars_with_sources = VarsWithSources()
   vars_with_sources['answer'] = 42
   vars_with_sources['abc'] = random_string
   assert vars_with_sources['answer'] == 42
   assert vars_with_sources['abc'] == random_string

# Generated at 2022-06-23 15:14:55.928574
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    v1 = VarsWithSources(dict(var1="foo", var2="bar"))
    assert len(v1) == 2

# Generated at 2022-06-23 15:14:57.958615
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    """
    Test for the VariableManager method set_nonpersistent_facts.
    """
    pass



# Generated at 2022-06-23 15:15:03.910440
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    '''
    Unit test for method __setstate__ of class VariableManager
    '''
    # Check that method __setstate__.
    # The return type will be checked in other tests.
    # We are mainly checking that the method exists.
    v_manager = VariableManager()
    v_manager.__setstate__({})

    v_manager._fact_cache = {'a': 'b'}
    v_manager.__setstate__({})

# Generated at 2022-06-23 15:15:06.287949
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    variable_manager = VariableManager()

# Generated at 2022-06-23 15:15:12.355811
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    # See https://github.com/ansible/ansible/issues/63371
    # Create a new variable list
    args = ['1', 2]
    kwargs = {'a':'3', 'b':4}
    vws = VarsWithSources(*args, **kwargs)
    assert len(vws) == 4, 'The list should contain 4 variables.'

# Generated at 2022-06-23 15:15:15.810042
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    varsWithSources = VarsWithSources({'a': 1, 'b': 2})
    assert 2 == varsWithSources.__len__()

# Generated at 2022-06-23 15:15:27.084471
# Unit test for constructor of class VariableManager
def test_VariableManager():
    def cmp_result(obj1, obj2):
        return (obj1.__class__ is obj2.__class__ and
                cmp(obj1.__dict__, obj2.__dict__))

    # Setup
    inventory = Inventory('hosts')
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Exercise get_vars()
    vars_all = variable_manager.get_vars()

    # Verify
    assert(vars_all['groups'] == {})
    assert(vars_all['omit'] == '__omit_place_holder__')

    # Setup
    host = Host(name='testhost')
    hostname = 'testhost'

# Generated at 2022-06-23 15:15:33.732101
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    '''
    Unit test function to test set_host_variable() of class VariableManager
    '''
    var_man = VariableManager()
    host = 'hostname'
    varname = 'test'
    value = 'value'
    var_man.set_host_variable(host, varname, value)
    expected_results = {host: {varname: value}}
    results = var_man._vars_cache
    assert expected_results == results

# Generated at 2022-06-23 15:15:37.236572
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    v = VarsWithSources()
    assert v.get_source('test') is None

    v = VarsWithSources()
    v.sources = dict(test='test source')
    assert v.get_source('test') == 'test source'

# Generated at 2022-06-23 15:15:40.210604
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    v = VariableManager()
    h = Host('localhost')
    v.set_host_facts('localhost', dict())
    v.clear_facts(hostname='localhost')
    truth = dict()
    truth = truth



# Generated at 2022-06-23 15:15:44.540714
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    """
    Class method VarsWithSources.__iter__
    """
    import yaml
    d = yaml.load("""{a: 1, b: 2, c: 3}""")
    v = VarsWithSources(d)
    l = list(v)
    assert l == ['a', 'b', 'c']
    return

# Generated at 2022-06-23 15:15:52.163507
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    x = VariableManager()
    x.set_host_facts("a", {})
    x.set_host_facts("a", {"b": "c"})
    x.set_host_facts("a", {"b": "d"})
    x.set_host_facts("b", {})
    x.set_nonpersistent_facts("c", {})
    x.set_nonpersistent_facts("c", {"d": "e"})
    x.set_nonpersistent_facts("c", {"d": "g"})
    x.set_nonpersistent_facts("d", {})
    return True

# Generated at 2022-06-23 15:15:55.932479
# Unit test for method __getstate__ of class VariableManager

# Generated at 2022-06-23 15:15:59.268185
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources({"a": 1, "b": 2})
    assert v == {"a": 1, "b": 2}
    assert v.sources == {}


# Generated at 2022-06-23 15:16:08.299055
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    # AnisbleFacts._get_ansible_facts returns a dict with the key "ansible_all_ipv4_addresses",
    # which is different from the above test for the key "ansible_ipv4_address"
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory())
    host = Host('myhost')
    variable_manager.set_host_variable(host, 'ansible_all_ipv4_addresses', ['192.168.4.4', '192.168.4.5'])

    new_hostvars = variable_manager.get_host_vars(host)
    expected = dict(ansible_all_ipv4_addresses=['192.168.4.4', '192.168.4.5'])
    assert new_hostvars

# Generated at 2022-06-23 15:16:13.404653
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # Setup
    v = VariableManager()
    v._nonpersistent_fact_cache = dict()
    host = "foo"
    facts = {}

    # Test Execution
    v.set_nonpersistent_facts(host, facts)

    # Assertions
    assert len(v._nonpersistent_fact_cache) == 1
    assert v._nonpersistent_fact_cache[host] == facts



# Generated at 2022-06-23 15:16:16.848829
# Unit test for function preprocess_vars
def test_preprocess_vars():
    assert preprocess_vars(None) == None
    assert preprocess_vars([1,2,3]) == [1,2,3]
    assert preprocess_vars({"key": "value"}) == [{"key": "value"}]



# Generated at 2022-06-23 15:16:17.850023
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():

    # Make function call
    pass

# Generated at 2022-06-23 15:16:21.236759
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    # Arrange
    vars_with_sources = VarsWithSources()
    # Act
    vars_with_sources['key'] = 'value'
    # Assert
    assert vars_with_sources == {'key': 'value'}


# Generated at 2022-06-23 15:16:25.753620
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # TODO: Create tests for:
    #    VariableManager.get_vars(self, loader, play=None, host=None, task=None, include_delegate_to=True, use_cache=True, include_hostvars=True)
    #    VariableManager.set_nonpersistent_facts(self, host, facts)
    pass

# Generated at 2022-06-23 15:16:33.672445
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    '''
    Tests if the constructor of class VarsWithSources is compatible with the
    built-in dict
    '''
    v1 = VarsWithSources(a=1, b=2)
    v2 = VarsWithSources({'a': 1, 'b': 2})
    # The comparison of the above two variables requires a custom __eq__ method in
    # class VarsWithSources, which is not implemented. So just check if the values are the same.
    assert v1['a'] == v2['a']
    assert v1['b'] == v2['b']

# Generated at 2022-06-23 15:16:38.961728
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    instance = VarsWithSources({'a':1, 'b':2})
    instance.sources = {'a': 'source_a'}
    assert instance.get_source('a') == 'source_a'
    assert instance.get_source('b') is None


# Generated at 2022-06-23 15:16:41.823362
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    v = VarsWithSources()
    v['a'] = 1
    assert v['a'] == 1
    assert v.get_source('a') is None


# Generated at 2022-06-23 15:16:53.518644
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():

    # create a host
    myhost = Host(name='localhost')
    myhost.vars = dict(ansible_all_ipv4_addresses=['8.8.8.8'])

    # create a play
    myplay = Play()
    myplay.vars = dict(ansible_all_ipv4_addresses=['192.168.101.1'])

    # create a task
    mytask = Task()
    mytask.vars = dict(ansible_all_ipv4_addresses=['192.168.1.1'])

    # create a VariableManager and provide some data
    vm = VariableManager()
    vm.set_inventory(Inventory([myhost]))

# Generated at 2022-06-23 15:16:55.651062
# Unit test for constructor of class VariableManager
def test_VariableManager():
    v = VariableManager()
    assert v is not None


# Generated at 2022-06-23 15:17:05.291212
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():

    # Initialize the object
    vm = VariableManager()

    # Call the method
    # (1) Set facts with a valid input
    host = 'test'
    facts = {
        'testfact': 'testvalue'
    }
    vm.set_host_facts(host, facts)
    # (2) Update facts with a valid input
    facts = {
        'testfact': 'testvalue-updated'
    }
    vm.set_host_facts(host, facts)
    assert vm.get_vars(host=host, include_hostvars=True)['hostvars'][host]['testfact'] == 'testvalue-updated'

    # (3) Raise assertion error with an invalid input
    facts = ['testvalue']

# Generated at 2022-06-23 15:17:10.709475
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    vars_with_sources = VarsWithSources()
    key = 'key_1'
    value = 'value_1'
    vars_with_sources.__setitem__(key, value)
    assert vars_with_sources[key] == 'value_1'


# Generated at 2022-06-23 15:17:15.380856
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    v = VarsWithSources({"a": 1, "b": 2, "c": 3})
    v.sources = {"a": "test", "b": "test1", "c": "test2"}

# Generated at 2022-06-23 15:17:26.090840
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources({ 'key': 'value' }, { 'key': 'test_source' })

    # Add some more variables and sources, then check that they have been stored
    v['test2'] = 'value2'
    v.sources['test2'] = 'test_source2'

    assert v['test2'] == 'value2', 'The variable \'test2\' was not stored successfully'
    assert v.get_source('test2') == 'test_source2', 'The source for \'test2\' was not stored successfully'
    assert 'test2' in v.sources, 'The variable \'test2\' does not appear to be stored in the sources dict'

    # Test the created sources for the variable 'key'
    assert v['key'] == 'value', 'The variable \'key\' was not stored successfully'

# Generated at 2022-06-23 15:17:36.574757
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    vws = VarsWithSources({'a':1, 'b':2})
    # Check that del removes the key from the underlying data
    del vws['a']
    assert 'a' not in vws
    assert 'a' not in vws.data
    # Check that del removes the key from the underlying sources
    vws['a'] = 1
    vws.sources['a'] = 'somewhere'
    del vws['a']
    assert 'a' not in vws.data
    assert 'a' not in vws.sources
    # Check that del silently passes when the key is not in the data
    del vws['z']


# Generated at 2022-06-23 15:17:39.937380
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    test_vars_with_sources = VarsWithSources()
    expected_output = True
    actual_output =  test_vars_with_sources.__contains__(1)
    assert actual_output == expected_output

# Generated at 2022-06-23 15:17:50.615546
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    vars = {
        'a': '111',
        'b': '222',
        'c': '333'
    }
    sources = {
        'a': 'hostA-varA-sourceA',
        'b': 'hostB-varB-sourceB',
        'c': 'hostC-varC-sourceC'
    }
    v1 = VarsWithSources.new_vars_with_sources(vars, sources)
    v2 = v1.copy()
    assert v1 is not v2
    assert v1 == v2
    assert v1.data is not v2.data
    assert v1.sources is not v2.sources
    assert v1.data == v2.data
    assert v1.sources == v2.sources


# ------------------------------------------------------------------------------
#


# Generated at 2022-06-23 15:17:59.763576
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():

    variable_manager = VariableManager()
    variable_manager.set_host_variable("test_host", "test_var", "test_value")
    assert variable_manager._vars_cache['test_host']['test_var'] == "test_value"
    variable_manager.set_host_variable("test_host", "test_var", {'test_nested_var': "test_nested_value"})
    assert variable_manager._vars_cache['test_host']['test_var'] == "{'test_nested_var': 'test_nested_value'}"
    variable_manager.set_host_variable("test_host", "test_var", "new_value")
    assert variable_manager._vars_cache['test_host']['test_var'] == "new_value"


   

# Generated at 2022-06-23 15:18:09.621739
# Unit test for function preprocess_vars
def test_preprocess_vars():
    # Input is string
    input_string = "YWRtaW46cGFzc3dvcmQ="
    output_string = preprocess_vars(input_string)
    assert type(output_string) is list
    assert output_string[0] == "YWRtaW46cGFzc3dvcmQ="

    # Input is string
    input_string = "SGVsbG8gV29ybGQ="
    output_string = preprocess_vars(input_string)
    assert type(output_string) is list
    assert output_string[0] == "SGVsbG8gV29ybGQ="

    # Input is a list

# Generated at 2022-06-23 15:18:18.884413
# Unit test for constructor of class VariableManager

# Generated at 2022-06-23 15:18:21.613098
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({"A": "a"})
    # key A is present in the actual data
    v["A"]


# Generated at 2022-06-23 15:18:26.524465
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    v = VarsWithSources.new_vars_with_sources({'a': 'val1', 'b': 'val2'}, {'a': 'src1', 'b': 'src2'})
    v1 = v.copy()

    # verify that v1 is a copy of v
    assert(v1['a'] == 'val1')
    assert(v1['b'] == 'val2')
    assert(v1.get_source('a') == 'src1')
    assert(v1.get_source('b') == 'src2')

    # verify that the copy is deep. if it wasn't, this next line would change v
    v1['a'] = 'new1'
    v1['b'] = 'new2'
    v1.sources['a'] = 'newsrc'

# Generated at 2022-06-23 15:18:33.753409
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    # Initialize obj with a test data
    obj = VarsWithSources({"var": "value"})
    # Test
    with mock.patch(
        'ansible.vars.manager.display.debug'
    ) as mock_display_debug:
        res = obj["var"]
        # Assertions
        assert res == obj.data["var"]
        mock_display_debug.assert_called_with("variable 'var' from source: unknown")
    # Clean up - nothing to do


# Generated at 2022-06-23 15:18:43.015617
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    manager = VariableManager()
    setattr(manager, '_vars_cache', {'host': {'var': 'value'}})
    setattr(manager, '_nonpersistent_fact_cache', {'host': {'var': 'value'}})
    pickled = pickle.dumps(manager)
    unpickled = pickle.loads(pickled)
    assert unpickled._vars_cache == {'host': {'var': 'value'}}
    assert unpickled._nonpersistent_fact_cache == {'host': {'var': 'value'}}



# Generated at 2022-06-23 15:18:55.145816
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()
    
    assert variable_manager._nonpersistent_fact_cache == {}
    variable_manager.set_nonpersistent_facts('hostname', 'facts')
    assert variable_manager._nonpersistent_fact_cache['hostname'] == 'facts'
    variable_manager.set_nonpersistent_facts('hostname', {'one': 'two'})
    assert variable_manager._nonpersistent_fact_cache['hostname'] == {'one': 'two'}
    variable_manager.set_nonpersistent_facts('hostname', {'one': 'three'})
    assert variable_manager._nonpersistent_fact_cache['hostname'] == {'one': 'three'}

# Generated at 2022-06-23 15:18:59.817537
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    vars_with_sources = VarsWithSources(data={'a': 1,'b': 2,'c': 3,'d': 4}, sources={'a': 'A'})
    assert len(vars_with_sources) == 4


# Generated at 2022-06-23 15:19:10.590105
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    # test normal behaviour
    vars_with_sources = VarsWithSources({"A": 1, "B": 2})
    vars_with_sources.sources = {"A": "sourceA", "C": "sourceC"}
    assert vars_with_sources.get_source("A") == "sourceA"
    assert vars_with_sources.get_source("B") is None

    # test with an empty "sources"
    vars_with_sources.sources = {}
    assert vars_with_sources.get_source("A") is None

    # test with a None "sources"
    vars_with_sources.sources = None
    assert vars_with_sources.get_source("A") is None

# Generated at 2022-06-23 15:19:14.013266
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'a': 1})
    v['a']
    v.get_source('a')

    assert v.get_source('a') == None


# Generated at 2022-06-23 15:19:16.491150
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    v = VarsWithSources({"a": 1, "b": 2})
    assert "a" in v
    assert "c" not in v


# Generated at 2022-06-23 15:19:22.439735
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    import sys
    import re
    __tracebackhide__ = True
    d = {'a': 1,'b': 2,'c': 3}
    v = VarsWithSources(d)
    v.sources = {'a': 'src1','b': 'src2','c': 'src3','d': 'src4'}
    v.sources['d'] = 'missing'
    v.sources['e'] = 'missing'
    assert 'a' in v
    assert 'a' in v.data

