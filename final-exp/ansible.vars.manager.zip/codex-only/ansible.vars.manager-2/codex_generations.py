

# Generated at 2022-06-23 15:09:28.431284
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''
    VariableManager  unit tests
    '''

    # Constructor test
    import sys
    import os

    class TestOptions(object):
        module_path = os.path.join(os.path.dirname(sys.modules[__name__].__file__), '..', 'lib')

    # constructor test: inventory, loader and variables
    inventory = Inventory(host_list=[])
    loader = DataLoader()
    options = TestOptions()
    passwords = dict()
    vm = VariableManager(loader=loader, inventory=inventory)
    vm = VariableManager(loader=loader, inventory=inventory, options=options)
    vm = VariableManager(loader=loader, inventory=inventory, extra_vars=dict())
    vm = VariableManager(loader=loader, inventory=inventory, options=options, extra_vars=dict())
   

# Generated at 2022-06-23 15:09:32.291893
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    fixture = VarsWithSources({'a': 1, 'b': 2})
    fixture.__delitem__('b')
    expected = VarsWithSources({'a': 1})
    assert fixture == expected

# Generated at 2022-06-23 15:09:36.399756
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    test_list = ["a","b","c"]
    for i in test_list:
        if i in VarsWithSources({"a":"b"}):
            return False
    return True


# Generated at 2022-06-23 15:09:43.475769
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    opt = '<VALUE>'
    runas_opts = dict()
    fake_loader = '<VALUE>'
    _play_context = '<VALUE>'
    password_opts = dict()
    inventory = '<VALUE>'
    vars_plugins = dict()
    jinja2_extensions = dict()

    x = VariableManager(loader=fake_loader)
    setattr(x, '_options_vars', opt)
    setattr(x, '_runas_opts', runas_opts)
    setattr(x, '_play_context', _play_context)
    setattr(x, '_password_opts', password_opts)
    setattr(x, '_inventory', inventory)
    setattr(x, '_vars_plugins', vars_plugins)

# Generated at 2022-06-23 15:09:47.013400
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources()
    v.data['key1'] = 'value1'
    v.sources['key1'] = 'mypath'
    assert v['key1'] == 'value1'

# Generated at 2022-06-23 15:09:49.145308
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    '''
    Unit test for method __setstate__ of class VariableManager
    '''
    pass


# Generated at 2022-06-23 15:09:56.385214
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()
    variable_manager._vars_cache = dict()
    variable_manager._fact_cache = dict()
    variable_manager._nonpersistent_fact_cache = dict()
    variable_manager._hostvars = dict()
    variable_manager._vars_plugins = dict()
    variable_manager._omit_token = str()
    variable_manager._options_vars = dict()
    variable_manager._play_context = PlayContext()

    # test __getstate__
    variable_manager.__getstate__()

    # test __setstate__
    result = dict()
    result['_fact_cache'] = dict()
    result['_ignored_facts'] = list()
    result['_nonpersistent_fact_cache'] = dict

# Generated at 2022-06-23 15:10:00.759062
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    v = VarsWithSources()
    assert len(v) == 0
    v['test_key'] = 'test_val'
    assert len(v) == 1
    assert v['test_key'] == 'test_val'

# Generated at 2022-06-23 15:10:11.704008
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Arrange
    import os
    import json
    import tempfile
    from collections import Mapping
    from ansible.vars import VariableManager
    data_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'unit', 'data')
    json_data = json.load(open(os.path.join(data_path, 'host_vars.json')))
    vars_file = tempfile.NamedTemporaryFile(delete=False)
    vars_file.close()
    json.dump(json_data, open(vars_file.name, 'w'))
    var_manager = VariableManager()
    var_manager.extra_vars = {'ansible_version': '2.6.2'}

    # Act
    result

# Generated at 2022-06-23 15:10:16.703858
# Unit test for constructor of class VariableManager
def test_VariableManager():
    v = VariableManager()
    v.set_host_variable("foo", "bar", ["baz", "bam"])
    assert v.get_host_variables("foo") == {u"foo": {u"bar": [u"baz", u"bam"]}}
    assert v.get_vars(play=None, host=None, task=None) == {'bar': [u'baz', u'bam']}
    v.set_host_variable("foo", "bar", "baz")
    assert v.get_host_variables("foo") == {u"foo": {u"bar": u"baz"}}
    assert v.get_vars(play=None, host=None, task=None) == {u'bar': u'baz'}

# Generated at 2022-06-23 15:10:22.591190
# Unit test for constructor of class VariableManager
def test_VariableManager():
    inventory = Inventory(host_list=['localhost', 'host2'])
    inventory.add_group('worker')
    inventory.add_host(host='localhost', groups='worker',
                       vars={'var1': 'value1', 'var2': 'value2'})
    inventory.add_host(host='host2',
                       # not setting var2
                       vars={'var1': 'value1'})
    variable_manager = VariableManager(loader=None, inventory=inventory)
    assert variable_manager.get_vars(host=inventory.get_host('localhost')) == {'var1': 'value1', 'var2': 'value2'}
    assert variable_manager.get_vars(host=inventory.get_host('host2')) == {'var1': 'value1'}
    assert variable_manager

# Generated at 2022-06-23 15:10:31.143670
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    vars_with_sources = VarsWithSources()
    vars_with_sources["key"] = "value"
    assert_equal(len(vars_with_sources), 1)
    del vars_with_sources["key"]
    assert_equal(len(vars_with_sources), 0)
    assert_not_in("key", vars_with_sources)
    assert_raises(KeyError, lambda: vars_with_sources["key"])


# Generated at 2022-06-23 15:10:40.577178
# Unit test for constructor of class VariableManager
def test_VariableManager():
    variable_manager = VariableManager()
    assert variable_manager.extra_vars == dict()
    assert variable_manager.options_vars == dict()
    assert variable_manager.vars_cache == dict()
    assert variable_manager.vars_plugins == dict()
    assert variable_manager.definitions == dict()
    assert variable_manager.extra_vars == dict()
    assert variable_manager._hostvars == dict()
    assert variable_manager.nonpersistent_fact_cache == dict()
    assert variable_manager.fact_cache == dict()
    assert variable_manager.loader is None
    assert variable_manager.inventory is None
    assert variable_manager.play is None
    assert variable_manager.task is None
    assert variable_manager.omit_token == '__omit_place_holder__'

# Generated at 2022-06-23 15:10:44.596422
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    vws = VarsWithSources()
    vws['test1']=1
    assert 'test1' in vws.data
    assert vws['test1']==1


# Generated at 2022-06-23 15:10:50.137525
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    test_dict = {'string': 'test', 'int': 5, 'list': [1, 2, 3]}
    v = VarsWithSources(test_dict)
    for key in test_dict:
        assert key in v
    assert 'not_in' not in v
    assert 'string' in v
    assert 'int' in v
    assert 'list' in v



# Generated at 2022-06-23 15:10:53.638404
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    '''
    Unit test for "clear_facts" method of class "VariableManager"
    '''
    # Check object initialisation
    variable_manager = VariableManager()
    variable_manager.clear_facts('')

# Generated at 2022-06-23 15:11:02.297292
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    vm = VariableManager()
    host = 'the_host'

    # cannot use the set_host_facts method directly
    with pytest.raises(AnsibleAssertionError):
        vm.set_host_facts(host, ['a_list'])

    # cannot use the set_host_facts method directly
    with pytest.raises(AnsibleAssertionError):
        vm.set_host_facts(host, 'a_string')

    # cannot use the set_host_facts method directly
    with pytest.raises(AnsibleAssertionError):
        vm.set_host_facts(host, 10)

    # cannot use the set_host_facts method directly

# Generated at 2022-06-23 15:11:02.971076
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    pass

# Generated at 2022-06-23 15:11:09.507124
# Unit test for function preprocess_vars
def test_preprocess_vars():
    assert preprocess_vars(None) is None
    assert isinstance(preprocess_vars(dict(a=1)), list)
    assert isinstance(preprocess_vars([dict(b=2)]), list)
    assert len(preprocess_vars([dict(b=2)])) == 1
    assert isinstance(preprocess_vars(dict(b=2)), list)
    assert len(preprocess_vars([dict(c=3), dict(d=4)])) == 2


# Generated at 2022-06-23 15:11:11.576485
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    a = VarsWithSources()
    a['a'] = 1
    a['a']
    a['b'] = 2
    a['c'] = 3


# Generated at 2022-06-23 15:11:19.255663
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    """
    Test to return the variables (by name) that are available within the variable manager
    """
    min_args = 2
    max_args = 4
    everything = object()

    # The first argument is a simple one to test
    args = (AnsibleOptions(connection='ssh', verbosity=3, sudo_user='root'), None)

    # Create a set of 3 variables that can be used as the second argument
    var_set_1 = dict(var1='var1', var2='var2', var3='var3')
    var_set_2 = dict(var4='var4', var5='var5', var6='var6')
    var_set_3 = dict(var7='var7', var8='var8', var9='var9')

    # Iterate through all possible number of arguments including variable sets
   

# Generated at 2022-06-23 15:11:26.376597
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    # Setup
    my_inventory = InventoryManager(host_list=[])
    loader = DataLoader()
    my_variablemanager = VariableManager(loader=loader, inventory=my_inventory)
    my_variablemanager.clear_facts("name")
    # Note: We do not test the return value,
    # because we do not know what it will be.
    # Assertions



# Generated at 2022-06-23 15:11:39.050364
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Input Params
    host = 'host'
    varname = 'varname'
    value = 'value'

    # Default Variable Manager initialization
    var_mgr = VariableManager()

    # Test for set_host_variable to set/update the given value for a host in the vars cache
    # Verifying with the host present in vars_cache
    var_mgr._vars_cache[host] = dict()
    previous_value = var_mgr._vars_cache[host][varname] = 'previous_value'
    var_mgr.set_host_variable(host, varname, value)
    assert var_mgr._vars_cache[host][varname] == value

    # Verifying with the host not present in vars_cache

# Generated at 2022-06-23 15:11:44.818413
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    # Generate the data
    data = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    # Instantiate the object
    vws = VarsWithSources(data)
    # Check that the object is iterable
    list(vws)
    # Check that the length is correct
    assert len(data) == len(vws)

# Generated at 2022-06-23 15:11:49.502320
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    variable_manager = VariableManager()

    output = variable_manager.__getstate__()

    assert output == {"_fact_cache": {}, "_host_cache": {}, "_inventory": None, "_vars_cache": {}, "_loader": None}


# Generated at 2022-06-23 15:11:57.427297
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    '''
    Test instantiation, dict-like functions and source creation/retrieval
    '''
    # Initialize empty
    vars_with_sources = VarsWithSources()
    assert len(vars_with_sources) == 0

    # Test adding and retrieving vars
    test_vars = {'key1': 'value1', 'key2': 'value2'}
    vars_with_sources.update(test_vars)
    assert len(vars_with_sources) == len(test_vars)
    assert vars_with_sources['key1'] == 'value1'
    assert vars_with_sources['key2'] == 'value2'

    # Test editing/updating vars
    vars_with_sources['key1'] = 'updated_value'

# Generated at 2022-06-23 15:12:03.862355
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    def set_host_facts(host, facts):
        return play_context.vars._fact_cache.get(host)

    def set_nonpersistent_facts(host, facts):
        return play_context.vars._nonpersistent_fact_cache.get(host)

    play_context = PlayContext()
    host_name ='some.host.name'

# Generated at 2022-06-23 15:12:07.954529
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    data = dict()
    sources = dict()
    v = VarsWithSources(data, sources)

    key = "key"
    expected = None

    actual = v.get_source(key)

    assert actual == expected

# Generated at 2022-06-23 15:12:17.788589
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    global args
    global module_args
    args = parse_args([])
    module_args = dict()

    v = VariableManager()
    v.load_from_file("/home/ubuntu/TEST_VAR_FILE")
    v.update_vars({"test_arg1": "test_value1"})
    v.update_vars({"test_arg2": "test_value2"})
    v.update_vars({"test_arg3": "test_value3"})

# Generated at 2022-06-23 15:12:21.465448
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    # Set up test data
    args = [{}]
    kwargs = {}

    # Invoke method
    vars_with_sources = VarsWithSources(*args, **kwargs)
    result = vars_with_sources.__iter__()

    # Verify results
    assert isinstance(result, types.GeneratorType)
    for entry in result:
        assert isinstance(entry, str)


# Generated at 2022-06-23 15:12:29.341435
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    # Test VarsWithSources.__setitem__
    # 1 test with an existing key
    # 2 test with a new key
    # 3 check if item is correctly set
    # 4 check if VarsWithSources is still dict-like

    with pytest.raises(Exception) as e:
        v = VarsWithSources()
        v['test'] = 'test'
        assert v['test'] == 'test'
        assert len(v) == 1
        assert list(v)[0] == 'test'
    assert "Not implemented" in str(e)


# Generated at 2022-06-23 15:12:33.646099
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # the first test is to verify that the constructor will accept a dictionary
    # with a key of 'vault_password'
    fixture = {'vault_password': 'test'}
    assert VariableManager(loader=None, inventory=None,
                           version_info=ansible_version)._vault_password == 'test'


# Generated at 2022-06-23 15:12:39.668331
# Unit test for constructor of class VariableManager
def test_VariableManager():

    ########################################################################
    # Constructor tests
    ########################################################################

    assert VariableManager(loader=DictDataLoader(dict()))
    assert VariableManager(loader=DictDataLoader(dict()), inventory= InventoryManager(loader=DictDataLoader(dict())))
    assert VariableManager(loader=DictDataLoader(dict()), inventory= InventoryManager(loader=DictDataLoader(dict())), version_info=dict(a=1, b=2, c=3))
    assert VariableManager(loader=DictDataLoader(dict()), version_info=dict(a=1, b=2, c=3))

# Generated at 2022-06-23 15:12:50.762199
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import Inventory
    from ansible.utils.vars import combine_vars
    from collections import MutableMapping
    import copy

    def test_case_empty():
        loader = DictDataLoader({})
        inv = Inventory(loader)
        vM = VariableManager(loader=loader, inventory=inv)

        vM.set_host_variable(host='127.0.0.1', varname='x', value={1: 'one'})
        assert vM._vars_cache['127.0.0.1'] == {'x': {1: 'one'}}

        vM.set_host_variable(host='127.0.0.1', varname='x', value={2: 'two'})
        assert vM

# Generated at 2022-06-23 15:12:51.309348
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    pass

# Generated at 2022-06-23 15:12:59.543998
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources()
    assert v == {}
    v = VarsWithSources({1: 1})
    assert v == {1: 1}
    v = VarsWithSources({1: 1}, {1: 'test'}, a=1)
    assert v == {1: 1, 'a': 1}
    assert v.get_source(1) == 'test'

    try:
        v.get_source('a')
        assert False
    except:
        pass

# Test function for constructor of class VarsWithSources

# Generated at 2022-06-23 15:13:00.336570
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    pass

# Generated at 2022-06-23 15:13:09.201137
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    facts = {'a': '!a!'}
    host = 'myhost'
    # test under perfect conditions
    _play = Play()
    _play.vars = dict()
    _play.vars['a'] = '!b!'
    _play.vars['b'] = '!c!'
    
    _task = Task()
    _task.vars = dict()
    _task.vars['a'] = '!b!'
    _task.vars['b'] = '!c!'
    _task.vars['c'] = '!d!'
    _inventory = Inventory()

    vars_cache = {}
    vars_cache[host] = {'a': '!b!'}
    nonpersistent_fact_cache = {host: facts}


# Generated at 2022-06-23 15:13:19.639490
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    # runclass: create VarsWithSources with no data, make sure __init__ handles it
    empty_vws = VarsWithSources()
    assert empty_vws == {}
    # runclass: check copy with no data
    empty_copy_vws = empty_vws.copy()
    assert empty_copy_vws == {}
    assert empty_copy_vws.sources == {}

    # runclass: create VarsWithSources with data, make sure __init__ handles it
    some_vws = VarsWithSources()
    some_vws['foo'] = 'bar'
    assert some_vws == {'foo': 'bar'}
    assert some_vws.sources == {}
    # runclass: check copy with data
    some_copy_vws = some_vws.copy()
    assert some_

# Generated at 2022-06-23 15:13:23.115507
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v = VarsWithSources({"a": 1, "b": 2, "c": 3})
    assert v["a"] == 1
    assert v["b"] == 2
    assert v["c"] == 3


# Generated at 2022-06-23 15:13:29.058999
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    '''
    Test method __setitem__ of class VarsWithSources
    '''
    d = VarsWithSources()
    try:
        d.__setitem__('key', 'value')
        assert eq(d['key'], 'value')
    except Exception as e:
        print('Exception raised: ' + str(e))
        raise e

# Generated at 2022-06-23 15:13:37.440356
# Unit test for function preprocess_vars
def test_preprocess_vars():
    # function return None if input is None
    assert preprocess_vars(None) is None

    # function return list if input is MutableMapping
    assert isinstance(preprocess_vars(dict()), list)
    assert isinstance(preprocess_vars(dict(a = 1)), list)
    assert isinstance(preprocess_vars(dict(b = 2)), list)

    # function return list if input is list contains MutableMapping
    assert isinstance(preprocess_vars([dict(a = 1)]), list)
    assert isinstance(preprocess_vars([dict(b = 2)]), list)
    assert isinstance(preprocess_vars([dict(a = 1), dict(b = 2)]), list)

    # function raise AnsibleError if input isn't MutableMapping or list contains MutableMapping

# Generated at 2022-06-23 15:13:44.861831
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    import pytest
    from ansible.plugins.loader import variable_manager
    
    variable_manager_obj = variable_manager.VariableManager()
    
    x = variable_manager_obj.get_vars()
    print (x)
    assert x == {}
    assert isinstance(x,dict)

if __name__ == '__main__':
    # Unit test for get_vars method
    # pytest.main(["-s", "VariableManager.py"])
    test_VariableManager_get_vars()

# Generated at 2022-06-23 15:13:55.370266
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    # fixture for self._vars_cache
    vars_cache = {
        u'fake_host': {
            u'fake_varname1': u'fake_value1',
            u'fake_varname2': u'fake_value2'
        }
    }
    # fixture for self._nonpersistent_fact_cache
    nonpersistent_fact_cache = {
        u'fake_host': {
            u'fake_factname1': u'fake_factvalue1',
            u'fake_factname2': u'fake_factvalue2'
        }
    }
    # fixture for self._fact_cache

# Generated at 2022-06-23 15:14:06.506444
# Unit test for function preprocess_vars
def test_preprocess_vars():
    a = {'a': '1', 'b': '2'}
    b = preprocess_vars(a)
    assert b == [a]

    a = [{'a': '1', 'b': '2'}]
    b = preprocess_vars(a)
    assert b == a

    a = [{'a': '1', 'b': '2'}, {'c': '3', 'd': '4'}]
    b = preprocess_vars(a)
    assert b == a

    a = [1, 2, 3]
    b = preprocess_vars(a)
    assert b == a

    a = ''
    b = preprocess_vars(a)
    assert b == [a]



# Generated at 2022-06-23 15:14:09.719673
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    v = VarsWithSources({'hello': 'goodbye'})
    assert 'hello' in v
    assert 'not' not in v



# Generated at 2022-06-23 15:14:10.917430
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    assert False



# Generated at 2022-06-23 15:14:16.637258
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    set_module_args({'inventory_hostname': 'localhost', 'playbook_dir': 'playbook_dir'})
    module = AnsibleModule(
        argument_spec=dict(
            inventory_hostname=dict(default=None),
            playbook_dir=dict(default=None),
        ),
        supports_check_mode=True,
    )
    module.exit_json(changed=False)

# Generated at 2022-06-23 15:14:20.536480
# Unit test for function preprocess_vars
def test_preprocess_vars():
    a = dict(foo="bar")
    assert preprocess_vars(a) == [a]

    a = [ dict(foo="bar") ]
    assert preprocess_vars(a) == a

    a = 42
    assert preprocess_vars(a) == [a]

    # Should fail with:
    #  AnsibleError: variable files must contain either a dictionary of variables, or a list of dictionaries. Got: ['foo', 'bar'] (<type 'list'>)
    #a = ['foo','bar']
    #assert preprocess_vars(a) == a


# Generated at 2022-06-23 15:14:23.023733
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
  # Instantiate class
  v = VarsWithSources()
  # Call method
  # No exception expected
  v.__delitem__("something")

# Generated at 2022-06-23 15:14:29.241202
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    vm = VariableManager(loader=DataLoader())
    hostname = 'test_host'
    vm.get_vars(host=Host(name=hostname))
    vm.clear_facts(hostname)
    assert hostname not in vm._fact_cache
    assert vm.get_vars(host=Host(name=hostname)) == {}

# Generated at 2022-06-23 15:14:39.644803
# Unit test for function preprocess_vars
def test_preprocess_vars():
    from ansible.module_utils.six import PY3
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    import sys
    if PY3:
        # Python 3.x has no cStringIO and unicode is str
        binary_type = bytes
        string_type = str
        unicode_type = str
    else:
        import cStringIO

        class binary_type(str):
            def encode(self, *args, **kwargs):
                return binary_type(super(binary_type, self).encode(*args, **kwargs))

        class string_type(str):
            def decode(self, *args, **kwargs):
                return string_type(super(string_type, self).decode(*args, **kwargs))

        unicode_type

# Generated at 2022-06-23 15:14:48.246655
# Unit test for function preprocess_vars
def test_preprocess_vars():
    ''' test preprocess_vars '''

    assert preprocess_vars({'hello': 'world'}) == [{'hello': 'world'}]
    assert preprocess_vars([{'hello': 'world'}]) == [{'hello': 'world'}]

    try:
        assert preprocess_vars(['hello', 'world']) == None
        assert False
    except AnsibleError:
        assert True

    try:
        assert preprocess_vars('hello') == None
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-23 15:14:52.172033
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    # Setup
    expected_result = {'a': 'test', 'b': 'test2'}
    context = VarsWithSources()
    # Test
    context['a'] = 'test'
    context['b'] = 'test2'
    # Verify
    assert context.data == expected_result

# Generated at 2022-06-23 15:15:03.596825
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    data = dict()
    data['ansible_facts']['os_version'] = '2.6.32-573.26.1.el6.x86_64'
    data['ansible_facts']['os_family'] = 'RedHat'
    data['ansible_facts']['python_version'] = '2.6.6'
    data['ansible_facts']['distribution_version'] = '6.7'
    data['ansible_facts']['distribution_release'] = 'Final'
    data['ansible_facts']['distribution'] = 'CentOS'
    data['ansible_facts']['path'] = '/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin'

# Generated at 2022-06-23 15:15:06.656289
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    V = VarsWithSources()
    V["a"] = 1
    del V["a"]

    assert len(V) == 0


# Generated at 2022-06-23 15:15:13.947282
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    v = PlayContext()
    v.vars = VarsWithSources()
    for k in v.vars:
        assert False, "Expected an error"

    v.vars = VarsWithSources({'a':1, 'b':2, 'c':3})
    for k in v.vars:
        assert k in ['a', 'b', 'c']


# Generated at 2022-06-23 15:15:16.134344
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    v = VarsWithSources({'foo':'bar'})
    for k in v:
        assert k == 'foo'

# Generated at 2022-06-23 15:15:21.683388
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    sources = dict(a='src1', b='src2', c='src3')
    v = VarsWithSources.new_vars_with_sources({'a': 1, 'b': 2, 'c': 3}, sources)
    assert sorted(v.keys()) == ['a', 'b', 'c']


# Generated at 2022-06-23 15:15:24.803963
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    args = ()
    kwargs = {}
    b = VarsWithSources(*args, **kwargs)
    # TODO: Update tests for __delitem__
    assert False



# Generated at 2022-06-23 15:15:33.981296
# Unit test for function preprocess_vars
def test_preprocess_vars():
    test_values = [None,
                   {"a": "b"},
                   [{"a": "b"}, {"c": "d"}],
                   "abc"]
    expected_values = [None,
                       [{"a": "b"}],
                       [{"a": "b"}, {"c": "d"}],
                       [{"abc": None}]]

    for i, test_value in enumerate(test_values):
        result = preprocess_vars(test_value)
        if result != expected_values[i]:
            raise AssertionError("assertion failed while testing preprocess_vars() with input %s" % test_value)
# Check unit test
test_preprocess_vars()



# Generated at 2022-06-23 15:15:40.236306
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    #check __copy__ return value is a new instance and the source is the same after copy
    source = {'a': 1, 'b': 2, 'c': 3}
    a = VarsWithSources(source)
    b = a.copy()
    assert b is not a
    assert b.sources is not a.sources
    assert b.data is not a.data
    assert a.sources == b.sources
    assert a.data == b.data

# Generated at 2022-06-23 15:15:51.079766
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory

    loader = DictDataLoader({
        "vars.yml": """
                ansible_source: vars.yml
                foo: bar
        """,
        "vars2.yml": """
                ansible_source: vars2.yml
                bar: foo
        """})

    inventory = MockInventory(loader=loader, variables={"ansible_source": "inventory"})
    inventory.add_host(host=Host("foohost"))
    play = Play.load(dict(
        name="test play",
       ), loader=loader, inventory=inventory)

    pc = PlayContext()
    pc._play = play


# Generated at 2022-06-23 15:16:01.452777
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    """
    Test get_source(key) of class VarsWithSources
    """
    # create a VarsWithSources object
    vars_with_sources = VarsWithSources()
    # add an item to the VarsWithSources object
    vars_with_sources['test_key'] = 'test_value'
    # add a source to the VarsWithSources object
    vars_with_sources.sources['test_key'] = 'test_source'
    # test get_source with the key used previously
    assert vars_with_sources.get_source('test_key') == 'test_source'

# Generated at 2022-06-23 15:16:09.363452
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    '''Unit test for method __delitem__ of class VarsWithSources '''
    # Init
    v = VarsWithSources()
    v.data = {'a':'a'}
    key = 'a'

    # Try to delete data from both data and source

    try :
        del v[key]
    except KeyError:
        # Key not present
        pass
    except:
        # Other exception
        raise
    else:
        # Normal execution
        pass

    # Try to delete key that is not in data
    key = 'b'
    try :
        del v[key]
    except KeyError:
        # Key not present
        pass
    except:
        # Other exception
        raise
    else:
        # Normal execution
        pass



# Generated at 2022-06-23 15:16:18.965331
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    vm = VariableManager()
    vm._hostvars = dict()
    vm._vars_cache = dict()
    vm.set_nonpersistent_facts('hostname', {'x': 'y'})
    vm.set_nonpersistent_facts('othername', {'x': 'y'})
    vm.set_nonpersistent_facts('othername2', {'x': 'y'})
    vm.set_host_facts('hostname', {'y': 'z'})
    vm.set_host_facts('othername', {'y': 'z'})
    vm.set_host_facts('othername2', {'y': 'z'})
    vm.set_host_variable('hostname', 'a', 'b')
    vm.set_host_variable('othername', 'a', 'b')

# Generated at 2022-06-23 15:16:29.782989
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    simpleItem = {
        "hosts": [
            "localhost",
            "127.0.0.1",
            "::1"
        ],
        "vars": {
            "ansible_connection": "local"
        }
    }
    # Test with an Inventory with only 1 host
    host = Host(name = 'testHost')
    inventory1 = Inventory(loader = DictDataLoader({
        'localhost': simpleItem,
        '127.0.0.1': simpleItem,
        '::1': simpleItem,
        'testHost': simpleItem,
    }))
    inventory1.add_host(host)
    variableManager1 = VariableManager()
    variableManager1.set_inventory(inventory1)
    assert variableManager1._inventory is not None

# Generated at 2022-06-23 15:16:32.826891
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    # Testing for nonexisting key
    v = VarsWithSources({'key1': 'value1'})
    # Testing for existing key
    assert v.get_source('key1') is None


# Generated at 2022-06-23 15:16:36.287789
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
        a= VariableManager()
        a.set_host_facts(host=None, facts=None)
        # print "Finish"

# Generated at 2022-06-23 15:16:43.457848
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources()
    v['a'] = 1
    v['a'] = 2
    assert('a' in v)
    assert(v['a'] == 2)
    #getitem calls get_source, do not raise error
    assert(v.get_source('a') is None)
    v.sources['a'] = 'b'
    #getitem calls get_source, do not raise error
    assert(v.get_source('a') == 'b')


# Generated at 2022-06-23 15:16:45.799415
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    VarsWithSources({'k1': 'v1', 'k2': 'v2'}, {'k1': 'inventory'})


# Generated at 2022-06-23 15:16:46.926747
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # TODO: write unit test
    pass

# Generated at 2022-06-23 15:16:57.448689
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    """
    Unit test for method get_vars of class VariableManager

    """
    _loader = DataLoader()
    _inventory = InventoryManager(loader=_loader)
    _play = Play().load({
                    'name': "Ansible Play from Ansible Classic.py",
                    'hosts': 'localhost',
                    'gather_facts': 'no',
                    'tasks': [
                        {
                            'action': {
                                'module': 'setup',
                                'args': {}
                            },
                            'register': 'setup_facts'
                        }
                    ]
                }, loader=_loader, variable_manager=None)
    _variable_manager = VariableManager()
    _variable_manager._inventory = _inventory
    _variable_manager._loader = _loader

    #Source and destination host ip
    host = _

# Generated at 2022-06-23 15:17:02.794628
# Unit test for constructor of class VariableManager
def test_VariableManager():

    # Create a variable manager and return it
    def create_variable_manager(loader, inventory, play=None, extra_vars=None, options_vars=None, hostvars=None, all_unset_vars_linkage=True, omit_token=None):
        return VariableManager(loader=loader, inventory=inventory, play=play, extra_vars=extra_vars, options_vars=options_vars, hostvars=hostvars, all_unset_vars_linkage=all_unset_vars_linkage, omit_token=omit_token)

    # Create a variable data structure and return it
    def create_variable(name, value, delimiter="."):
        variable = dict()
        variable[name] = dict()
        variable[name]["value"] = value

# Generated at 2022-06-23 15:17:10.351057
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    print('Create an instance of class VariableManager with default params')
    vm = VariableManager()
    print('Create an instance of class Inventory with default params')
    inventory = Inventory()
    print('Create an instance of class Host with default params')
    host = Host()
    print('Create an instance of class Playbook with default params')
    playbook = Playbook()
    print('Call method set_inventory of class VariableManager')
    vm.set_inventory(inventory)
    print('Call method get_variable of class VariableManager')
    print('Result: ')
    print(vm.get_vars(play=playbook, host=host, include_delegate_to=True))

# Generated at 2022-06-23 15:17:19.008204
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    # Direct test of VarsWithSources __getitem__() method

    # import basic modules
    import copy
    import threading
    # import our own tested module
    from ansible.vars.manager import VarsWithSources
    # For data structure definition
    from ansible.vars.manager import DataLoader, InventoryManager
    # For host and inventory definition
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # define some variables to be used in the test
    test_inventory = InventoryManager(loader=DataLoader())

    # import test data
    from test.units.vars.manager import VarsWithSourcesData
    test_data = VarsWithSourcesData()

    # create vars object
    vars_with_sources = VarsWithSources()
    #

# Generated at 2022-06-23 15:17:22.537018
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    # Check that the number of items in a VarsWithSources object is the same
    # as the number of items in the underlying dict of the data attribute
    v = VarsWithSources()
    data_len_dict = len(v.data)
    v_len = len(v)
    assert v_len == data_len_dict



# Generated at 2022-06-23 15:17:30.982380
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    '''
    Unit test for method __getstate__ of class VariableManager
    '''
    variable_manager = VariableManager()

    variable_manager._fact_cache = dict()
    variable_manager._nonpersistent_fact_cache = dict()
    variable_manager._vars_cache = dict()
    variable_manager._play_context = dict()

    assert variable_manager.__getstate__() == {'_fact_cache': {}, '_nonpersistent_fact_cache': {}, '_vars_cache': {}, '_play_context': {}}


# Generated at 2022-06-23 15:17:39.413759
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    # Instantiate a VarsWithSources object and set the variable 'var_name' to value 'var_value' and with source 'var_source'
    vars_with_sources = VarsWithSources({'var_name' : 'var_value'})
    vars_with_sources.sources = {'var_name' : 'var_source'}
    # Create a mock for method 'debug'
    debug_mock = MagicMock()
    # Call method '__getitem__' with parameter 'var_name' and return the value 'var_value'
    vars_with_sources.__getitem__ = MagicMock(return_value = 'var_value')
    # Verify that method 'debug' has been called with parameter 'variable '%s' from source: %s'

# Generated at 2022-06-23 15:17:45.901756
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    ''' test method VarsWithSources.__delitem__ '''
    V = VarsWithSources
    v = V()
    v.data = {'a': 1, 'b': 2, 'c': 3}
    v.sources = {'a': 1, 'b': 2, 'c': 3}

    v.__delitem__('a')
    assert v.data == {'b': 2, 'c': 3}
    assert v.sources == {'b': 2, 'c': 3}


# Generated at 2022-06-23 15:17:51.543024
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vm = VariableManager()
    assert(vm.get_vars() == {'omit': '__omit_place_holder__'})

    vm = VariableManager()
    vm._fact_cache = {'a': 1, 'b': 2}
    vm._vars_cache = {'a': 1, 'b': 2}
    assert(vm.get_vars() == {'omit': '__omit_place_holder__', 'a': 1, 'b': 2})

    vm = VariableManager()
    vm._fact_cache = {'a': 1, 'b': 2}
    vm._vars_cache = {'a': 1, 'b': 2}
    assert(vm.get_vars(include_hostvars=False) == {'omit': '__omit_place_holder__'})

# Generated at 2022-06-23 15:18:00.335701
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    # Test empty VarsWithSources
    v = VarsWithSources()
    assert v.get_source("foo") is None

    # Test VarsWithSources with default constructor
    data = dict({"a": 1})
    v2 = VarsWithSources(data)
    assert v2.get_source("foo") is None

    # Test VarsWithSources with new_vars_with_sources constructor
    data = dict({"a": 1})
    sources = dict(a="playbook")
    v3 = VarsWithSources.new_vars_with_sources(data, sources)
    assert v3.get_source("a") == "playbook"
    assert v3.get_source("foo") is None

    # Test VarsWithSources with new_vars_with_sources constructor

# Generated at 2022-06-23 15:18:10.010475
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    variable_manager = VariableManager()
    variable_manager._vars_cache = dict()
    variable_manager._vars_cache['localhost'] = dict()
    variable_manager._vars_cache['localhost']['b'] = dict()
    variable_manager._vars_cache['localhost']['b']['b1'] = 'b1'
    variable_manager._vars_cache['localhost']['b']['b2'] = 'b2'
    variable_manager._vars_cache['localhost']['c'] = 'c'
    host = 'localhost'
    varname = 'a'
    value = dict()
    value['a1'] = 'a1'
    value['a2'] = 'a2'
    variable_manager.set_host_variable(host, varname, value)

# Generated at 2022-06-23 15:18:19.237223
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    varMgr = VariableManager(loader = DictDataLoader({}), inventory = Inventory(loader = DictDataLoader({})))
    hostname = u'test_VariableManager_clear_facts'
    varMgr.set_host_variable(hostname, u'var1', u'value1')
    varMgr.set_host_variable(hostname, u'var2', u'value2')
    varMgr.set_host_facts(hostname, {u'fact1': u'value1', u'fact2': u'value2'})
    varMgr.set_nonpersistent_facts(hostname, {u'nfact1': u'value1', u'nfact2': u'value2'})
    pprint(varMgr._vars_cache)

# Generated at 2022-06-23 15:18:23.110444
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    vmanager = VariableManager()
    vmanager._vars_cache = {}
    inventory = MagicMock()
    vmanager.set_inventory(inventory)


    assert vmanager._vars_cache == inventory.get_hosts()



# Generated at 2022-06-23 15:18:34.134631
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    v0 = VarsWithSources({'a': 1, 'b': 2, 'c': 3})
    v1 = VarsWithSources(a=1, b=2, c=3)
    v2 = VarsWithSources(**{'a': 1, 'b': 2, 'c': 3})
    v3 = VarsWithSources.new_vars_with_sources(
            {'a': 1, 'b': 2, 'c': 3},
            {'a': 'a', 'b': 'b', 'c': 'c'},
        )
    assert v0 == v1
    assert v0 == v2
    assert v1 == v2
    assert v1 != v3
    assert v0 != v3
    assert v2 != v3

# Generated at 2022-06-23 15:18:36.822498
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    v = VarsWithSources({1: "one", 2: "two"})
    assert set(v) == {1, 2}



# Generated at 2022-06-23 15:18:46.923390
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    """
    Basic test case for method '__getstate__' of class 'VariableManager'
    """

    # create a VariableManager object
    variable_manager = VariableManager()

    # test the method and check if it returns the expected output
    assert variable_manager.__getstate__() == {
        '_fact_cache': {},
        '_hostvars': None,
        '_inventory': None,
        '_loader': None,
        '_nonpersistent_fact_cache': {},
        '_omit_token': '__omit_place_holder__',
        '_options_vars': {},
        '_vars_cache': {},
        '_vars_plugins': {},
    }


# Generated at 2022-06-23 15:18:56.018217
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    # The test methods must begin with the prefix "test_"
    # The methods run in the order they are defined in this file
    # The # indicates a comment until the end of the line
    # Variables "vm" and "host" are initialized in test_VariableManager_init()
    facts1 = {"fact1": "value1", "fact2": "value2"}
    vm.set_nonpersistent_facts(host, facts1)
    # Each method runs in its own fresh environment.
    assert vm.get_vars(host)["nonpersistent_facts"] == facts1
    

# Generated at 2022-06-23 15:19:00.166846
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    vws = VarsWithSources.new_vars_with_sources({'a': 'a_value'}, {'a': 'config_file'})
    lst = list(vws)
    assert lst == ['a']

# Generated at 2022-06-23 15:19:06.524740
# Unit test for function preprocess_vars
def test_preprocess_vars():

    assert preprocess_vars([]) == []
    assert preprocess_vars({}) == [{}]
    assert preprocess_vars([{}]) == [{}]
    assert preprocess_vars(dict()) == [{}]

    try:
        preprocess_vars("foo")
    except AnsibleError as e:
        assert "variable files must" in to_text(e)

    try:
        preprocess_vars([1])
    except AnsibleError as e:
        assert "variable files must" in to_text(e)



# Generated at 2022-06-23 15:19:17.414941
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    """
    Test set_host_variable()
    """

    var_manager = VariableManager()
    var_manager._vars_cache = dict()
    var_manager._nonpersistent_fact_cache = dict()
    host = 'localhost'
    varname = 'testing_var'
    value = 'awesome_value'

    # Test without any vars_cache set
    var_manager._vars_cache = dict()
    var_manager.set_host_variable(host, varname, value)
    assert var_manager._vars_cache[host][varname] == value

    # Test with var already set in vars_cache
    var_manager._vars_cache = dict()
    var_manager._vars_cache[host] = dict()

# Generated at 2022-06-23 15:19:18.770941
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    assert list(VarsWithSources(dict(a='b', c='d'))) == ['a', 'c']