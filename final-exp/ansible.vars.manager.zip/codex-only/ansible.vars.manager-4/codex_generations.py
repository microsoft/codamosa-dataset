

# Generated at 2022-06-23 15:09:26.427221
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    """
    Test for ensuring _vars_cache is updated correctly when it has to update nested dict
    """
    var_manager = VariableManager()
    host = 'test01'
    varname = 'varname'
    value = OrderedDict()
    value['a'] = 'b'
    value['c'] = OrderedDict({'d':'e'})
    var_manager.set_host_variable(host, varname, value)
    assert var_manager._vars_cache[host][varname] == value
    update_value = OrderedDict()
    update_value['a'] = 'b'
    update_value['c'] = OrderedDict({'f':'g'})
    var_manager.set_host_variable(host, varname, update_value)
    assert var_

# Generated at 2022-06-23 15:09:27.752284
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    # FIXME:
    pass



# Generated at 2022-06-23 15:09:38.699246
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    variable_manager = VariableManager()

    variable_manager.set_host_variable(host="host", varname="varname", value="value")

    variable_manager.__setstate__()

    assert variable_manager._vars_cache == {}

    variable_manager.set_host_variable(host="host", varname="varname", value="value")

    variable_manager.__setstate__(
        get_vars={
            "host": {
                "varname": "value"
            }
        }
    )

    assert variable_manager._vars_cache == {
        "host": {
            "varname": "value"
        }
    }

# Generated at 2022-06-23 15:09:50.535889
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    v1 = VarsWithSources({'key1_del': 'val1_del', 'key2_del': 'val2_del', 'key3_del': 'val3_del'})
    v1.sources = {'key1_del': 's1_del', 'key2_del': 's2_del', 'key3_del': 's3_del'}
    del v1['key1_del']
    assert v1.data == {'key2_del': 'val2_del', 'key3_del': 'val3_del'}
    assert v1.sources == {'key2_del': 's2_del', 'key3_del': 's3_del'}

# Generated at 2022-06-23 15:09:57.194828
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    import ansible.inventory

    class TestInventory(ansible.inventory.Inventory):
        def __init__(self, host_list=[]):
            self.host_list = host_list

        def get_groups_dict(self):
            return []

        def get_hosts(self, pattern=None, ignore_restrictions=False, ignore_errors=False, ignore_limit=False):
            return self.host_list

    class TestHost(ansible.inventory.Host):
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    class TestPlay(object):
        def __init__(self, name, roles, hosts, removed_hosts):
            self.name = name
            self.roles = roles
            self.hosts

# Generated at 2022-06-23 15:10:00.500234
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    v = VarsWithSources()
    assert len(v) == 0

    v['z'] = 1
    assert len(v) == 1


# Generated at 2022-06-23 15:10:09.607444
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    objects = [
        dict(one=1),
        dict(two=2),
        dict(three=3),
    ]

    sources = dict(one='a', two='b', three='c')

    v = VarsWithSources.new_vars_with_sources(objects, sources)

    assert v == dict(one=1, two=2, three=3)

    vcopy = v.copy()

    v[4] = 4
    v[5] = 5
    v[6] = 6

    assert v != vcopy

    vcopy['one'] = 'a'
    vcopy['two'] = 'b'
    vcopy['three'] = 'c'

    vcopy[7] = 7
    vcopy[8] = 8
    vcopy[9] = 9


# Generated at 2022-06-23 15:10:17.495500
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    def test_set_host_variable_failure_1():
        """
        Failure case of test_set_host_variable method with :
         - host, ''
         - varname, 'any string'
         - value, None
        """
        host, varname, value = '', 'any string', None
        # set_host_variable(self, host, varname, value)
        test_object = create_VariableManager_object()
        expected = {}
        result = test_object._vars_cache
        assert result == expected

    def test_set_host_variable_failure_2():
        """
        Failure case of test_set_host_variable method with :
         - host, ''
         - varname, 'any string'
         - value, None
        """

# Generated at 2022-06-23 15:10:19.865312
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    testobj = VariableManager()
    testobj.set_inventory(inventory)
    expected = inventory
    actual = testobj.inventory
    assert actual == expected, 'test_VariableManager_set_inventory assertion error: expected: %s, actual: %s' % (expected, actual)


# Generated at 2022-06-23 15:10:23.281400
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    source = VarsWithSources()
    source.__setitem__('test_key', 'test_value')
    assert source == {'test_key': 'test_value'}


# Generated at 2022-06-23 15:10:25.784741
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    vars_with_sources = VarsWithSources()
    assert not vars_with_sources

    # Add item
    vars_with_sources['item'] = 'item_value'

    # Check item exists
    assert vars_with_sources['item'] == 'item_value'


# Generated at 2022-06-23 15:10:30.500834
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    v = VariableManager()
    h = Host(name="test")
    v.set_host_variable(h, "var1", "value1")
    assert v.get_vars(host=h)['var1'] == "value1"



# Generated at 2022-06-23 15:10:31.668625
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    v = VariableManager()
    v.set_host_facts("testhost", {"test": "value"})

# Generated at 2022-06-23 15:10:34.727348
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    '''
    Unit test method __setitem__ of class VarsWithSources.
    '''
    vws = VarsWithSources()
    vws['a'] = 1
    assert vws == {'a': 1}
    assert vws.sources == {'a': 'unknown'}

# Generated at 2022-06-23 15:10:46.336915
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    x = VarsWithSources({'a': 1}, b=2, c=3)
    assert x.get_source('a') is None
    assert x.get_source('b') is None
    assert x.get_source('c') is None
    assert x.data['a'] == 1
    assert x.data['b'] == 2
    assert x.data['c'] == 3
    assert x.get_source('a') is None
    assert x.get_source('b') is None
    assert x.get_source('c') is None
    assert x.data['a'] == 1
    assert x.data['b'] == 2
    assert x.data['c'] == 3

    # test the alternate constructor method

# Generated at 2022-06-23 15:10:53.418487
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    hostname = 'hostname_example'
    # create instance of the class with mandatory args
    module = AnsibleModule(argument_spec=dict())
    # create instance of the class with mandatory args
    # TODO: try and make it so that this can be tested without a positional argument
    vm = VariableManager(loader=DictDataLoader(), inventory=None)
    result = vm.clear_facts(hostname)
    assert result is None
    expected_result = None
    assert result == expected_result


# Generated at 2022-06-23 15:11:03.913933
# Unit test for function preprocess_vars
def test_preprocess_vars():
    assert preprocess_vars(None) is None
    assert preprocess_vars([]) == []
    assert preprocess_vars(dict()) == [dict()]
    assert preprocess_vars([{}]) == [{}]
    assert preprocess_vars([dict()]) == [dict()]
    assert preprocess_vars([{'foo': 'bar'}]) == [{'foo': 'bar'}]
    assert preprocess_vars(dict(foo='bar')) == [dict(foo='bar')]
    raises(AnsibleError, preprocess_vars, '{}')
    raises(AnsibleError, preprocess_vars, 'foo')

# Generated at 2022-06-23 15:11:12.992353
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    # Test for method __iter__(self: VarsWithSources) -> Iterator[str]
    # edge case to test for no items
    empty_vars = VarsWithSources()
    assert(len(empty_vars) == 0)
    assert(not any(k for k in empty_vars))

    # Test for method __iter__(self: VarsWithSources) -> Iterator[str]
    # Test for method __iter__(self: VarsWithSources) -> Iterator[str]
    # Test for method __iter__(self: VarsWithSources) -> Iterator[str]
    # Test for method __iter__(self: VarsWithSources) -> Iterator[str]
    # Test for method __iter__(self: VarsWithSources) -> Iterator[str]
    # Test for method __iter__(

# Generated at 2022-06-23 15:11:23.779093
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'key1':'val1','key2':'val2','key3':'val3'},{'key1':'d1','key2':'d2'})
    assert v['key1'] == 'val1'
    assert v['key2'] == 'val2'
    assert v['key3'] == 'val3'
    try:
        v['key4']
        assert False
    except KeyError:
        assert True
    assert v.get_source('key1') == 'd1'
    assert v.get_source('key2') == 'd2'
    assert v.get_source('key3') is None
       

# Generated at 2022-06-23 15:11:33.002508
# Unit test for function preprocess_vars
def test_preprocess_vars():
    # Empty parameter
    assert preprocess_vars(None) is None

    # List of dictionaries
    data = [{'k1': 'v1'},{'k2': 'v2'},{'k3': 'v3'}]
    assert preprocess_vars(data) == data

    # Dictionary
    data = {'k1': 'v1', 'k2': 'v2'}
    assert preprocess_vars(data) == [data]

    # Text
    data = 'k1=v1'
    assert preprocess_vars(data) == [data]


# Generated at 2022-06-23 15:11:37.904478
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    v = VarsWithSources()
    v['a'] = 'avalue'
    v['b'] = 'bvalue'
    items = list(iter(v))
    assert len(items) == 2
    assert sorted(items) == ['a', 'b']

# Generated at 2022-06-23 15:11:41.723246
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    # Setup
    varmgr = VariableManager()

    # Exercise
    varmgr.set_inventory(None)

    # Verify
    expected = None
    assert varmgr._inventory == expected


# Generated at 2022-06-23 15:11:44.856278
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts({'key': 'var'})


# Generated at 2022-06-23 15:11:48.417035
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    v = VarsWithSources({'key1': 'value1', 'key2': 'value2'})
    assert 'key1' in v
    assert 'badkey' not in v



# Generated at 2022-06-23 15:11:50.231091
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    '''
    Unit test for method VariableManager.setstate
    '''
    pass

# Generated at 2022-06-23 15:11:53.296442
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    v = VarsWithSources({'a': 'A', 'b': 'B'}, {'a': 'from-a', 'b': 'from-b'})
    vc = v.copy()
    assert vc is not v
    assert vc == v.data
    assert vc.sources == v.sources



# Generated at 2022-06-23 15:11:56.493644
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    vm = VariableManager()
    hostname = 'example.com'
    vm.clear_facts(hostname)
    assert vm._fact_cache.get(hostname, None) is None, \
        "should clear the facts for a host"


# Generated at 2022-06-23 15:11:59.895945
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    v = VarsWithSources({'a': 'A'})
    v['a'] = 'B'
    v.__delitem__('a')
    assert('a' not in v)

# Generated at 2022-06-23 15:12:02.462044
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({"A": 1, "B":2})
    v.sources["A"] = "a", "b"
    assert v["A"] == 1

# Generated at 2022-06-23 15:12:11.502675
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    v = VariableManager()
    inv = Inventory(hosts=['host1'], vars={'a': 'x'}, groups=dict(all=['host1']))
    v.set_inventory(inv)
    # TODO: fix the above test so it isn't checking what vars() returns
    #assert v.get_vars()['a'] == 'x'
    #assert v.get_vars()['inventory_hostname'] == 'host1'
    #assert v.get_vars()['groups']['all'][0] == 'host1'


# Generated at 2022-06-23 15:12:15.772601
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    '''
    Ensures the __len__ method returns the correct number of variables in a VarsWithSources object
    '''
    v = VarsWithSources({'a':1, 'b':2, 'c':3})
    assert len(v) == 3
    v = VarsWithSources({})
    assert len(v) == 0


# Generated at 2022-06-23 15:12:17.552445
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    vars = VarsWithSources({'1':1})
    assert 1 in list(vars)


# Generated at 2022-06-23 15:12:28.122418
# Unit test for constructor of class VariableManager
def test_VariableManager():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_warn


# Generated at 2022-06-23 15:12:32.890682
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    a = VarsWithSources()
    a['a'] = 6
    a['b'] = 7
    a['c'] = 8
    assert list(a.__iter__()) == ['a', 'b', 'c']
    assert a.__iter__().__class__.__name__ == 'dict_keyiterator'



# Generated at 2022-06-23 15:12:41.336798
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    data = { 'key1': 1, 'key2': 2 }
    sources = { 'key1': 'foo', 'key2': 'bar' }
    v = VarsWithSources.new_vars_with_sources(data, sources)
    assert v == data
    assert v.get_source('key1') == 'foo'
    assert v.get_source('key2') == 'bar'
    assert v.get_source('key3') is None
    v['key1'] = 3
    assert v['key1'] == 3

if __name__ == "__main__":
    import unittest
    class TestInventory(unittest.TestCase):
        def test_VarsWithSources(self):
            data = { 'key1': 1, 'key2': 2 }

# Generated at 2022-06-23 15:12:43.458170
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vm = VariableManager()
    hostname = 'test_host1'
    mock_facts = {}
    vm.set_nonpersistent_facts(hostname, mock_facts)

    result = vm._nonpersistent_fact_cache

    assert result == {hostname: mock_facts}
    assert result['test_host1'] == mock_facts


# Generated at 2022-06-23 15:12:44.433294
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    pass


# Generated at 2022-06-23 15:12:46.862839
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    v = VarsWithSources()
    v['test'] = 123
    del v['test']

# Generated at 2022-06-23 15:12:52.812554
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    # Test to see if VarsWthSources overrides __contains__, so that it works as expected
    # This is a simple test to see if __contains__ calls __contains__ on the underlying data
    class Test():
        def __contains__(self, key):
            raise Exception('Should not be called')
    t = Test()
    v = VarsWithSources({'a':1}, {'b':2})
    v.data = t
    assert 'a' in v


# Generated at 2022-06-23 15:12:59.010098
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    def check(s, l):
        if len(s) != l:
            raise AssertionError("len(%s) != %d" % (s, l))
    v = VarsWithSources()
    check(v,0)
    v[1] = 1
    check(v,1)
    del v[1]
    check(v,0)

import copy, pickle



# Generated at 2022-06-23 15:12:59.543413
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    pass

# Generated at 2022-06-23 15:13:07.045698
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    v = VariableManager()
    facts = dict(asdf="test")
    v.set_host_facts("testhost", facts)
    # the facts should have been added to the v._fact_cache dict()
    assert "testhost" in v._fact_cache
    assert v._fact_cache["testhost"] == facts
    # retrieve the facts and make sure they match
    assert v.get_vars(host=Host("testhost"))["ansible_facts"] == facts
    # set new facts, check the results
    facts = dict(new="new facts")
    v.set_host_facts("testhost", facts)
    # the facts should have been added to the v._fact_cache dict()
    assert "testhost" in v._fact_cache
    assert v._fact_cache["testhost"] == facts
    # retrieve the

# Generated at 2022-06-23 15:13:10.981625
# Unit test for method __setitem__ of class VarsWithSources
def test_VarsWithSources___setitem__():
    v = VarsWithSources({"a": 1, "b": 2})
    assert v["a"] == 1
    assert v["b"] == 2
    v["c"] = 3
    assert v["c"] == 3
    assert v["b"] == 2

# Generated at 2022-06-23 15:13:20.951799
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    vm = VariableManager()
    vm.set_nonpersistent_facts("test_host_name",{"a":1})
    vm.set_host_facts("test_host_name",{"b":2})
    vm.set_host_variable("test_host_name","c",3)

    vm.set_nonpersistent_facts("another_host_name", {"e":5})

    pickled = vm.__getstate__()

    unpickled = pickle.loads(pickled)


    assert isinstance(unpickled,VariableManager)

    assert set(unpickled._nonpersistent_fact_cache.keys()) == {"test_host_name", "another_host_name"}
    assert set(unpickled._fact_cache.keys()) == {"test_host_name"}

    assert unpickled._nonpers

# Generated at 2022-06-23 15:13:24.267412
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    vws = VarsWithSources({'a': 1, 'b': 2, 'c': 3})
    assert 3 == vws.__len__()

# Generated at 2022-06-23 15:13:26.456462
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vman = VariableManager()
    assert vman.get_vars() == {}


# Generated at 2022-06-23 15:13:37.728472
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    foo = {'a': 'a'}
    bar = {'b': 'b'}
    var = VarsWithSources.new_vars_with_sources(foo, bar)
    assert var is not None
    assert var.data == foo
    assert var.sources == bar
    assert var.get_source('b') == 'b'
    assert var['a'] == 'a'
    baz = var.copy()
    assert baz is not None
    assert baz.data == foo
    assert baz.sources == bar
    assert baz.get_source('b') == 'b'
    assert baz['a'] == 'a'
    foo['a'] = 'b'
    assert var['a'] == 'b'
    assert baz['a'] == 'a'
    bar['b']

# Generated at 2022-06-23 15:13:49.040378
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    # Test copy and copy() from same-type
    vws1 = VarsWithSources({"key1": "value1", "key2": "value2"})
    vws1.sources = {"key1": "source1"}
    vws2 = vws1.copy()
    vws2["key1"] = "value1b"
    # Check that original is not modified
    assert vws1.data == {"key1": "value1", "key2": "value2"}
    assert vws1.sources == {"key1": "source1"}
    assert vws2.data == {"key1": "value1b", "key2": "value2"}
    assert vws2.sources == {"key1": "source1"}
    vws3 = vws1.copy()
    vws3.sources

# Generated at 2022-06-23 15:13:57.790035
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # testing with a dummy role and inventory,
    # and calling get_vars with a host that is contained in the inventory
    from ansible.vars import VariableManager

    vars_manager = VariableManager()
    vars_manager.add_group_vars_file("/Users/tjones/projects/ansible/group_vars/all", "yaml")
    vars_manager.add_host_vars_file("/Users/tjones/projects/ansible/host_vars/ad0s3.home.lan", "yaml")
    vars_manager.add_host_vars_file("/Users/tjones/projects/ansible/host_vars/ad0s3.home.lan", "yaml")

# Generated at 2022-06-23 15:14:00.478240
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory, loader=None)
    assert variable_manager.inventory == inventory

# Generated at 2022-06-23 15:14:05.451495
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    # Given
    test_data = VarsWithSources({'key1': 'value1', 'key2': 'value2'})

    # When
    result1 = ('key1' in test_data)
    result2 = ('key3' in test_data)

    # Then
    assert result1
    assert not result2

# Generated at 2022-06-23 15:14:14.549984
# Unit test for function preprocess_vars
def test_preprocess_vars():
    assert preprocess_vars([{'foo': 'bar'}, {'bar': 'baz'}]) == [{'foo': 'bar'}, {'bar': 'baz'}]
    assert preprocess_vars(10) == [10]
    assert preprocess_vars({'foo': 'bar'}) == [{'foo': 'bar'}]
    assert preprocess_vars(None) == None
    try:
        assert preprocess_vars('asdf') == [{'foo': 'bar'}]
    except AnsibleError:
        pass


# Generated at 2022-06-23 15:14:19.471756
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():

    # Test with arg that is None
    # test with a arg that is not a dict
    # test with a arg where the dict has a invalid key
    # test with a arg where the dict has a invalid value
    # test with a arg where the dict has a invalid value
    pass



# Generated at 2022-06-23 15:14:24.042728
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    host = 'hostname'
    inventory = Inventory('/path/to/inventory')
    manager = VariableManager(loader=None, inventory=inventory)
    manager.clear_facts(host)
    # assert if the value of the facts is none
    assert host not in manager._fact_cache



# Generated at 2022-06-23 15:14:34.381834
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    vm = VariableManager()
    host = FakeHost('localhost')
    facts = dict(a=1, b=2)
    vm.set_nonpersistent_facts(host, facts)
    assert dict(a=1, b=2) == vm._nonpersistent_fact_cache[host]
    facts2 = dict(c=3)
    vm.set_nonpersistent_facts(host, facts2)
    assert dict(a=1, b=2, c=3) == vm._nonpersistent_fact_cache[host]
    facts2 = dict()
    vm.set_nonpersistent_facts(host, facts2)
    assert dict(a=1, b=2, c=3) == vm._nonpersistent_fact_cache[host]

# Generated at 2022-06-23 15:14:41.647729
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.vault import VaultSecret
    def get_loader(vault_password=None):
        loader = DataLoader()
        if vault_password:
            loader.set_vault_secrets([(VaultSecret('secret', vault_password))])
        return loader


    inventory = InventoryManager(loader=get_loader(), sources='localhost,')

# Generated at 2022-06-23 15:14:52.562372
# Unit test for method copy of class VarsWithSources
def test_VarsWithSources_copy():
    var_test = {'test1': 1, 'test2': 2}
    sources_test = {'test1': 'source 1', 'test2': 'source 2'}
    vws = VarsWithSources.new_vars_with_sources(var_test, sources_test)
    vws_copy = vws.copy()
    assert vws_copy.data == var_test
    assert vws_copy.sources == sources_test
    assert vws_copy.get_source('test1') == 'source 1'
    assert vws_copy.get_source('test2') == 'source 2'
    assert vws_copy.get_source('test3') == None
    # Test that update is still working
    vws_copy.update({'test1': 11, 'test3': 3})

# Generated at 2022-06-23 15:14:56.151837
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    obj = variable_manager.VariableManager(
        inventory = 'inventory'
    )
    # state = obj.__getstate__()
    assert True == True


# Generated at 2022-06-23 15:15:01.070847
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    data = dict(a=1,b=2,c=3)
    v = VarsWithSources(data)
    del v['b']
    if 'b' in data:
        raise AssertionError()
    if 'b' in v:
        raise AssertionError()

# Generated at 2022-06-23 15:15:03.428235
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    vars_with_sources = VarsWithSources({'foo':'bar'}, {'foo':'inventory'})
    assert vars_with_sources['foo'] == 'bar'

# Generated at 2022-06-23 15:15:16.408011
# Unit test for function preprocess_vars
def test_preprocess_vars():
    assert preprocess_vars(None) == None
    assert preprocess_vars({}) == [{}]
    try:
        preprocess_vars([{}, {}])
    except AnsibleError:
        pytest.fail("did not expect an error from preprocess_vars")
    assert preprocess_vars([{}]) == [{}]
    with pytest.raises(AnsibleError):
        preprocess_vars([])
    with pytest.raises(AnsibleError):
        preprocess_vars([[]])
    with pytest.raises(AnsibleError):
        preprocess_vars([[], []])
    with pytest.raises(AnsibleError):
        preprocess_vars([[], {"foo": "bar"}])

# Generated at 2022-06-23 15:15:21.198723
# Unit test for method __contains__ of class VarsWithSources
def test_VarsWithSources___contains__():
    v = VarsWithSources({'a':1, 'b':2, 'c':3}, {'a':'a', 'b':'b'})
    assert 'a' in v
    assert 'A' not in v


# Generated at 2022-06-23 15:15:29.111301
# Unit test for constructor of class VariableManager
def test_VariableManager():
    '''
    unit test for constructor of class VariableManager
    '''
    vm = VariableManager()
    assert vm._fact_cache is not None
    assert vm._vars_cache is not None
    assert vm._omit_token is not None
    assert vm._fact_cache == dict()
    assert vm._vars_cache == dict()
    assert vm._nonpersistent_fact_cache == dict()
    assert vm._nonpersistent_vars_cache == dict()
    assert vm._extra_vars == dict()
    assert vm._options_vars == dict()
    assert vm._inventory is None
    assert vm._loader is None



# Generated at 2022-06-23 15:15:35.489819
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    # Note: This test handler is not automatically generated and has to be manually added
    # This test tests the method VarsWithSources.__delitem__()
    # of the class VarsWithSources

    # Since the method is called by the interpreter as VarsWithSources.__delitem__(self, key),
    # the parameters are self and key.
    # You can add parameters, but it is not recommended.
    # Uncomment the following line to get the parameters
    #key = None

    # Create object
    obj = VarsWithSources()

    # Test the method and verify the result
    ret = obj.__delitem__(key)
    assert ret == None, 'Unable to test method __delitem__ of class VarsWithSources'
    # no return value expected

# Generated at 2022-06-23 15:15:47.490978
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    # Make an instance of a class for testing
    variable_manager = VariableManager()

    # Make an instance of ArgumentSpec
    argument_spec = dict(
        host_list=dict(type='list', elements='dict', options=dict(
            hostname=dict(type='str'),
            port=dict(type='int'),
            username=dict(type='str'),
            password=dict(type='str', no_log=True),
            ssh_keyfile=dict(type='path'),
            connect_pass=dict(type='str', no_log=True),
        )),
        group_name=dict(type='str'),
        group_vars=dict(type='dict'),
        host_vars=dict(type='dict'),
    )


# Generated at 2022-06-23 15:15:48.789013
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    variable_manager = VariableManager()
    variable_manager.set_inventory('')

# Generated at 2022-06-23 15:16:01.265443
# Unit test for method __getstate__ of class VariableManager

# Generated at 2022-06-23 15:16:06.781053
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    vm = VariableManager()
    host1 = Host('test1')
    host2 = Host('test2')

    task = Task()
    task.become = False
    task._role = None
    task._priority = 0
    task._ds = {
        'name': 'test',
        'become': False,
    }

    play = Play()
    play.hosts = 'all'
    play.become = False
    play.ignore_unreachable = True
    play.ignore_errors = True
    play._ds = {
        'name': 'test',
        'hosts': 'all',
    }


# Generated at 2022-06-23 15:16:13.204830
# Unit test for method __delitem__ of class VarsWithSources
def test_VarsWithSources___delitem__():
    '''
    Unit test for method __delitem__ of class VarsWithSources
    '''
    # Test for method __delitem__ of class VarsWithSources

    # Arrange
    vars_with_sources = VarsWithSources()

    # Act
    vars_with_sources['testkey'] = 'testval'
    del vars_with_sources['testkey']

    # Assert
    assert not vars_with_sources.__contains__('testkey')


# Generated at 2022-06-23 15:16:15.221446
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    vars_with_sources = VarsWithSources({"key1": "value1", "key2": "value2"})


# Generated at 2022-06-23 15:16:24.303511
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # Just testing VariableManager.get_vars with no parameters
    # Testing with actual parameters would require creating the objects
    # referenced by them.
    loader = None
    inventory = None
    play = None
    host = None
    task = None
    shared_loader_obj = None
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    options = {}
    results = variable_manager.get_vars(play=play, host=host, task=task, options=options, all_vars=dict(),
                                        include_hostvars=True, include_delegate_to=True)
    print(results)

# Generated at 2022-06-23 15:16:30.149255
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    data = { 'a' : 1, 'b' : 2, 'c' : 3}
    sources = {'a' : 1, 'c' : 3}
    vars_with_sources = VarsWithSources.new_vars_with_sources(data, sources)
    assert len(vars_with_sources) == len(data)


# Generated at 2022-06-23 15:16:39.155116
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    # Make an instance of a class for which we know the __getstate__ method
    # works

    vm_instance = VariableManager()

    # This method call should return a dictionary
    returned_dict = vm_instance.__getstate__()

    # Assert the return type
    assert isinstance(returned_dict, dict)

    # Assert the contents
    assert '_fact_cache' in returned_dict
    assert '_vars_cache' in returned_dict
    assert '_omit_token' in returned_dict


# Generated at 2022-06-23 15:16:46.711559
# Unit test for function preprocess_vars
def test_preprocess_vars():
    '''
    Check if preprocess_vars return a list of dictionaries.
    '''
    assert isinstance(preprocess_vars(None), type(None))
    assert isinstance(preprocess_vars({'a': 1}), list)
    assert isinstance(preprocess_vars({'a': 1})[0], MutableMapping)

    try:
        preprocess_vars("string")
        raise AssertionError("should have raised an exception")
    except AnsibleError:
        pass



# Generated at 2022-06-23 15:16:47.613674
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    pass

# Generated at 2022-06-23 15:16:57.820743
# Unit test for constructor of class VarsWithSources
def test_VarsWithSources():
    class InventedVar(object):
        def __init__(self, value, source='unknown'):
            self.value = value
            self.source = source

    vws = VarsWithSources(a=InventedVar(1, 'playbook'), b=InventedVar(2, 'host var'))
    vws.sources = dict(a='host var', b='host var')

    # Constructor from dict, with 'sources' dict given
    assert vws.data == dict(a=1, b=2)
    assert vws.sources == dict(a='host var', b='host var')

    # New dict data with assigned sources

# Generated at 2022-06-23 15:17:06.464830
# Unit test for constructor of class VariableManager
def test_VariableManager():
    # Create a loader to load fake role fqcns from
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import combine_vars

    loader = DataLoader()
    role_fqcn = 'ansible.builtin.test_role'
    loader.set_basedir('/test/path')
    loader._add_directory(loader.get_basedir(), 'roles')
    loader.set_role_path(['/test/path/roles'])
    # Add fake entry to loader to make the role_fqcn resolution succeed
    loader.path_dwim_cache[role_fqcn] = '/test/path/roles/test_role/tasks/main.yaml'

    # Fake inventory
    from ansible.inventory.manager import InventoryManager

   

# Generated at 2022-06-23 15:17:13.812430
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    from ansible.vars.hostvars import HostVars
    vws = VarsWithSources({'a':1,'b':4,'c':3})
    info = dict(a=dict(source='one',bar='baz'),c=dict(source='three'))
    vws.sources['a'] = info['a']
    vws.sources['c'] = info['c']
    assert vws.get_source('a') == info['a']
    assert vws.get_source('c') == info['c']
    hv = HostVars(vws)
    assert hv.get_source('a') == info['a']
    assert hv.get_source('c') == info['c']

# Generated at 2022-06-23 15:17:17.495166
# Unit test for method __getstate__ of class VariableManager
def test_VariableManager___getstate__():
    # This unit test is not so much a test as a way to exercise the code
    # to get code coverage
    var_manager = VariableManager()
    var_manager.__getstate__()


# Generated at 2022-06-23 15:17:22.856476
# Unit test for constructor of class VariableManager
def test_VariableManager():
    varmanager = VariableManager()
    assert varmanager._omit_token == '__omit_place_holder__'
    assert varmanager._fact_cache == dict()
    assert varmanager._vars_cache == dict()
    assert varmanager._nonpersistent_fact_cache == dict()

# unit test for method '_create_omit_place_holder' of class VariableManager

# Generated at 2022-06-23 15:17:26.792793
# Unit test for method set_nonpersistent_facts of class VariableManager
def test_VariableManager_set_nonpersistent_facts():
    v = VariableManager()
    v.set_nonpersistent_facts('host1', {'foo': 'bar'})
    assert v._nonpersistent_fact_cache['host1']['foo'] == 'bar'

# Generated at 2022-06-23 15:17:29.300697
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    m = MagicMock(name='_VariableManager__setstate__()')
    VariableManager.__setstate__(m, 1)



# Generated at 2022-06-23 15:17:40.510525
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    vars_manager = VariableManager()
    assert vars_manager.get_vars() == {'omit': ''}
    vars_manager = VariableManager(
        loader=DictDataLoader({
            'playbook.yml': True,
            'test-play.yml': """
                name: test
                hosts: localhost
                gather_facts: no
                connection: local
                pre_tasks:
                tasks:
                roles:
                """,
            'test-role/tasks/main.yml': """
                - debug:
                    msg: "Run as {{ ansible_user_dir }}"
                """
        }),
        inventory=InventoryManager(loader=None),
    )

# Generated at 2022-06-23 15:17:51.432175
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    # VariableManager_get_vars() return value tests
    variable_manager = VariableManager()
    variable_manager._vars_cache = {
        'localhost': {
            'hostvars': {
                'a': {
                    'b': 1,
                },
            },
        },
    }
    variable_manager._inventory = None
    variable_manager._hostvars = None
    variable_manager._omit_token = None
    variable_manager._options_vars = {
        'option1': True,
        'option2': False,
        'option3': None,
        'option4': 123,
        'option5': 'string',
    }

# Generated at 2022-06-23 15:18:00.277030
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    mock_self = create_autospec(VariableManager)

    class TestResult(object):
        def __init__(self, arg):
            self.test_result = arg

    mock_self.__init__.return_value = None


# Generated at 2022-06-23 15:18:09.709965
# Unit test for method set_host_variable of class VariableManager
def test_VariableManager_set_host_variable():
    # Given:
    inventory = dict(
        host_list=["host1", "host2"],
        host_vars=dict(
            host1={'hostvar1': 'hostvarone'},
            host2={'hostvar2': 'hostvartwo'}
        )
    )
    loader = DictDataLoader({})
    variables = VariableManager(loader=loader, inventory=Inventory(loader=loader, variable_manager=None, host_list=inventory['host_list']))
    host = "host1"
    varname = "varname"
    value = "value"

    # When
    variables.set_host_variable(host, varname, value)
    # Then
    assert variables._vars_cache[host][varname] == value



# Generated at 2022-06-23 15:18:12.005612
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    '''
    Unit test for method clear_facts of class VariableManager
    '''
    print()
    print("TestClass: " + 'VariableManager')
    print("Method: " + 'clear_facts')


# Generated at 2022-06-23 15:18:14.111884
# Unit test for function preprocess_vars
def test_preprocess_vars():
    '''
    Unit test for function preprocess_vars
    '''
    assert preprocess_vars([1]) == [1]
    assert preprocess_vars(None) == None



# Generated at 2022-06-23 15:18:16.202796
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    vm = VariableManager()
    assert isinstance(vm, VariableManager)

    vm.clear_facts("foo")


# Generated at 2022-06-23 15:18:28.441412
# Unit test for method set_inventory of class VariableManager
def test_VariableManager_set_inventory():
    varmgr = VariableManager()
    set_inventory(varmgr,
                  {
                      "group": {
                          "hosts": ["host2", "host1"],
                          "vars": {"group_var": "group_value"}
                      },
                      "host1":{
                          "hostname": "host1",
                          "vars": {"host1_var": "host1_value"},
                      },
                      "host2":{
                          "hostname": "host2",
                          "vars": {"host2_var": "host2_value"},
                      }
                  })

# Generated at 2022-06-23 15:18:37.875566
# Unit test for method get_vars of class VariableManager
def test_VariableManager_get_vars():
    #  Setup all objects for an invocation of method, and assert that
    #  correct results are returned by that invocation
    #  Assert that VariableManager.get_vars returns the correct result
    #  when called with the following valid parameters:
    #
    #  play: None,
    #  host: None,
    #  task: None,
    #  include_delegate_to: None,
    #  include_hostvars: None,
    VariableManager.get_vars(play=None, host=None, task=None, include_delegate_to=None, include_hostvars=None)

    #  Assert that VariableManager.get_vars returns the correct result
    #  when called with the following valid parameters:
    #
    #  play: mock.create_autospec(Play),
    #

# Generated at 2022-06-23 15:18:44.698867
# Unit test for method __iter__ of class VarsWithSources
def test_VarsWithSources___iter__():
    a = VarsWithSources()
    # testing with empty object
    assert len(a) == 0
    a['key1'] = 'value1'
    a['key2'] = 'value2'
    a['key3'] = 'value3'
    a.sources['key2'] = 'testing'
    a.sources['key3'] = 'testing'
    # testing with populated object
    assert len(a) == 3

# Generated at 2022-06-23 15:18:50.789740
# Unit test for method __getitem__ of class VarsWithSources
def test_VarsWithSources___getitem__():
    v = VarsWithSources({'a': 'a', 'b': {'c': 'c'}})
    v.sources = {'a': 'b'}
    assert v['a'] == 'a'
    assert v.get_source('a') == 'b'



# Generated at 2022-06-23 15:18:58.039621
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    # Initialization
    variable_manager = VariableManager()
    variable_manager._fact_cache = {}

    # We initialize the cache with a non mutable Mapping
    variable_manager._fact_cache['host'] = {'test': 1}

    # We try to set facts
    facts = {'test2': 2}
    variable_manager.set_host_facts('host', facts)

    # We test that facts are set
    assert variable_manager._fact_cache['host'] == {'test': 1, 'test2': 2}


# Generated at 2022-06-23 15:19:04.195301
# Unit test for method __len__ of class VarsWithSources
def test_VarsWithSources___len__():
    # Test direct call
    v = VarsWithSources({'a': 1})
    assert len(v) == 1

    # Test inheritance/call to super
    class VarsWithSourcesSub(VarsWithSources):
        def __init__(self, *args, **kwargs):
            super(VarsWithSourcesSub, self).__init__(*args, **kwargs)
    v = VarsWithSourcesSub({'a': 1, 'b': 2})
    assert len(v) == 2


# Generated at 2022-06-23 15:19:10.586465
# Unit test for method __setstate__ of class VariableManager
def test_VariableManager___setstate__():
    obj = VariableManager()
    instance = VariableManager(loader=None, variables={})
    hostvars = {}
    _vars_cache = {}
    options_vars = {}
    new_instance = obj.__setstate__(instance, hostvars, _vars_cache, options_vars)
    assert isinstance(new_instance, VariableManager)


# Generated at 2022-06-23 15:19:12.654574
# Unit test for method set_host_facts of class VariableManager
def test_VariableManager_set_host_facts():
    if sys.version_info[0] < 3:
        assertEqual()
    else:
        assertEqual(1, 1)

# Generated at 2022-06-23 15:19:14.376856
# Unit test for method clear_facts of class VariableManager
def test_VariableManager_clear_facts():
    assert False, "No test for clear_facts"


# Generated at 2022-06-23 15:19:20.098183
# Unit test for method get_source of class VarsWithSources
def test_VarsWithSources_get_source():
    vws = VarsWithSources()
    assert vws.get_source('key1') is None
    vws.sources = {'key1':'source1', 'key2':'source2'}
    assert vws.get_source('key1') == 'source1'
    assert vws.get_source('key2') == 'source2'
    assert vws.get_source('key3') is None
