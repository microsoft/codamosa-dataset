

# Generated at 2022-06-21 20:32:58.179128
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    assert True


# Generated at 2022-06-21 20:33:00.641998
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "None"
    check()



# Generated at 2022-06-21 20:33:06.432065
# Unit test for function semaphore
def test_semaphore():
    """
    Test function semaphore, the function should be passed if
    environment variable SEMAPHORE is set to true, BRANCH_NAME is
    set to "master" and PULL_REQUEST_NUMBER is set to None.
    In case the variable SEMAPHORE is not set to true, the test
    will fail.
    Also, in case environment variable BRANCH_NAME is not set to
    "master", the test will fail.
    In case PULL_REQUEST_NUMBER is set to 1, the test will fail.
    """

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None

    semaphore("master")


# Generated at 2022-06-21 20:33:11.745850
# Unit test for function jenkins
def test_jenkins():
    env = {}
    env['JENKINS_URL'] = "test"
    env['BRANCH_NAME'] = "master"
    os.environ = env
    check()
    env['CHANGE_ID'] = "true"
    try:
        check()
        raise Exception("should have failed")
    except CiVerificationError:
        pass
    del os.environ['CHANGE_ID']
    env['GIT_BRANCH'] = "master"
    check()

# Generated at 2022-06-21 20:33:22.842794
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")

    os.environ["BRANCH_NAME"] = "next"
    os.environ["PULL_REQUEST_NUMBER"] = "2"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")


# Generated at 2022-06-21 20:33:31.121444
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
    except CiVerificationError as e:
        assert(str(e) == "The verification check for the environment did not pass.")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert(check() == False)



# Generated at 2022-06-21 20:33:34.103840
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()

# Generated at 2022-06-21 20:33:40.100917
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    assert(travis("master"))
    try:
        travis("dev")
    except CiVerificationError:
        assert True


# Generated at 2022-06-21 20:33:42.433555
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()



# Generated at 2022-06-21 20:33:48.712459
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'

    check()

    # Delete the environment variable CIRCLE_BRANCH which will result in the circle check to fail
    del os.environ['CIRCLE_BRANCH']

    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("circle check should have failed")


# Generated at 2022-06-21 20:34:06.716288
# Unit test for function circle
def test_circle():
    ci_env = {
        'CIRCLECI': 'true',
        'CIRCLE_BRANCH': 'master'
    }
    os.environ = ci_env
    try:
        check()
    except CiVerificationError as exc:
        assert False, f"CircleCI environment with master branch raised {exc}"

    ci_env = {
        'CIRCLECI': 'true',
        'CIRCLE_BRANCH': 'develop',
        'CI_PULL_REQUEST': 'true'
    }
    os.environ = ci_env
    try:
        check(branch='develop')
    except CiVerificationError as exc:
        assert False, f"CircleCI environment with develop branch raised {exc}"


# Generated at 2022-06-21 20:34:12.775461
# Unit test for function check
def test_check():
    try:
        os.environ["TRAVIS"] = "true"
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"

        check()
    finally:
        del os.environ["TRAVIS"]
        del os.environ["TRAVIS_BRANCH"]
        del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-21 20:34:16.094514
# Unit test for function bitbucket
def test_bitbucket():
    test_env = {
        "BITBUCKET_BRANCH": "master",
        "BITBUCKET_PR_ID": "false",
    }
    assert bitbucket("master") is True, "Bitbucket test did not pass"

# Generated at 2022-06-21 20:34:19.117277
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")


# Generated at 2022-06-21 20:34:27.450837
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "test_branch_name"
    assert check() is None
    os.environ["BRANCH_NAME"] = "master"
    assert check() is None
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    try:
        check()
    except CiVerificationError:
        pass


# Generated at 2022-06-21 20:34:31.025956
# Unit test for function checker
def test_checker():
    from semantic_release.errors import CiVerificationError

    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-21 20:34:34.216649
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'

    assert travis('master') == True


# Generated at 2022-06-21 20:34:35.684712
# Unit test for function semaphore
def test_semaphore():
    semaphore(branch="master")



# Generated at 2022-06-21 20:34:47.225855
# Unit test for function frigg
def test_frigg():
    print("-- frigg")
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_TASK_ID"] = "1234"
    os.environ["FRIGG_BUILD_ID"] = "12345"
    os.environ["FRIGG_PROJECT"] = "my_project"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_COMMIT"] = "bfdc8b71a3a4c1d676e3869a6889e9460fe6b573"

    frigg("master")
    # TODO: raise assert error in checker
    #frigg("not_master")
    #frigg(None)


# Generated at 2022-06-21 20:34:53.506075
# Unit test for function gitlab
def test_gitlab():
    """
    Test gitlab checker
    """
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_IID'] = '1'
    try:
        gitlab('master')
    except CiVerificationError:
        pass  # Expected
    else:
        assert False, "CiVerificationError not raised"
    del os.environ['CI_COMMIT_REF_NAME']
    del os.environ['CI_MERGE_REQUEST_IID']


# Generated at 2022-06-21 20:35:07.791384
# Unit test for function circle
def test_circle():
    """
    Test the Circlechecker function.

    :return: A list of all tests that were performed.
    """

    tests = []

    def test(name, value, expected):
        try:
            assert len(value) == 2
            assert value[0] == name
            assert value[1] == expected
        except AssertionError:
            value.append(expected)
            tests.append(value)

    test(
        "circle",
        circle("master"),
        True,
    )
    test(
        "not circle",
        circle("master"),
        False,
    )
    test(
        "not circle",
        circle("master"),
        False,
    )
    test(
        "not circle",
        circle("master"),
        False,
    )

# Generated at 2022-06-21 20:35:12.706692
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = 0

    try:
        gitlab('master')
    except CiVerificationError:
        pass
    else:
        assert False, "Unexpected success"

# Generated at 2022-06-21 20:35:19.684479
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    assert os.environ.get("CIRCLECI") == 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    assert os.environ.get("CIRCLE_BRANCH") == 'master'
    os.environ['CI_PULL_REQUEST'] = 'False'
    assert os.environ.get("CI_PULL_REQUEST") == 'False'
    circle('master')


# Generated at 2022-06-21 20:35:24.914608
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    del os.environ["GITLAB_MERGE_REQUEST_ID"] # not present

    try:
        gitlab("master")
    except CiVerificationError:
        assert False
    
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["GITLAB_MERGE_REQUEST_ID"] = "1234" # present

    try:
        gitlab("master")
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-21 20:35:36.429301
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert checker(circle)("master")
    os.environ.pop("CIRCLE_BRANCH")
    os.environ.pop("CI_PULL_REQUEST")
    os.environ["CIRCLE_BRANCH"] = "develop"
    os.environ["CI_PULL_REQUEST"] = "https://github.com/relekang/python-semantic-release/pull/33"
    with raises(CiVerificationError):
        assert checker(circle)("master")
    os.environ.pop("CIRCLE_BRANCH")
    os.environ.pop("CI_PULL_REQUEST")

# Unit test

# Generated at 2022-06-21 20:35:47.866065
# Unit test for function semaphore
def test_semaphore():
    assert checker(semaphore)("master") is True
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    assert checker(semaphore)("master") is True
    del os.environ["BRANCH_NAME"]
    assert checker(semaphore)("master") is False
    os.environ["BRANCH_NAME"] = "master"
    del os.environ["PULL_REQUEST_NUMBER"]
    assert checker(semaphore)("master") is False
    os.environ["PULL_REQUEST_NUMBER"] = "3"
    assert checker(semaphore)("master") is False

# Generated at 2022-06-21 20:35:52.443703
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "https://jenkins.com"
    os.environ['GIT_BRANCH'] = "master"
    os.environ['CHANGE_ID'] = None
    assert jenkins(branch="master") == True
    os.environ['JENKINS_URL'] = None
    assert jenkins(branch="master") == False
    os.environ['JENKINS_URL'] = "https://jenkins.com"
    os.environ['GIT_BRANCH'] = "dev"
    assert jenkins(branch="master") == False
    del os.environ['JENKINS_URL']
    del os.environ['GIT_BRANCH']
    del os.environ['CHANGE_ID']

#

# Generated at 2022-06-21 20:35:54.112803
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-21 20:36:00.194075
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "test_branch"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("test_branch")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-21 20:36:04.169159
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CI_PULL_REQUEST"] = "None"
    circle("master")


# Generated at 2022-06-21 20:36:21.337175
# Unit test for function check
def test_check():
    # Test for correct branch
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS"] = "true"
    check()

    # Test for incorrect branch
    os.environ["TRAVIS_BRANCH"] = "develop"
    try:
        check()
    except CiVerificationError:
        pass  # This is what we want

    # Test for pull request
    os.environ.pop("TRAVIS_BRANCH")
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
    except CiVerificationError:
        pass  # This is what we want

    # Test for correct branch
    del os

# Generated at 2022-06-21 20:36:25.736851
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    assert frigg("master")
    os.environ['FRIGG_PULL_REQUEST'] = "42"
    assert not frigg("master")
    del os.environ['FRIGG']
    del os.environ['FRIGG_BUILD_BRANCH']
    del os.environ['FRIGG_PULL_REQUEST']


# Generated at 2022-06-21 20:36:36.836036
# Unit test for function circle
def test_circle():

    # The following tests assume that the function circle runs locally
    # and that the environment variables are not set.
    # The test circle() will be true if the environment variables are set
    # and it will fail if the environment's variables are not set

    # Assert that the function circle returns a CiVerificationError
    # because the environment variables are not set.
    try:
        circle()
    except CiVerificationError:
        assert True
    except:
        assert False

    # Set the environment variables
    os.environ["CIRCLE_BRANCH"] = "develop"
    os.environ["CI_PULL_REQUEST"] = "1000"


# Generated at 2022-06-21 20:36:41.540893
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    assert check()


# Generated at 2022-06-21 20:36:54.837215
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_BUILD_BRANCH"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "true"

    # assert frigg("master")

    os.environ["FRIGG_PULL_REQUEST"] = "1"
    try:
        frigg("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Should raise a CiVerificationError"
    
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        frigg("master")
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:36:58.158338
# Unit test for function jenkins
def test_jenkins():
    assert os.environ.get("JENKINS_URL") is None
    assert os.environ.get("BRANCH_NAME") is None
    assert os.environ.get("GIT_BRANCH") is None
    assert os.environ.get("CHANGE_ID") is None

# Generated at 2022-06-21 20:37:01.593629
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] ="feature/TEST"
    os.environ["JENKINS_URL"] = "http://localhost:8080/"
    os.environ["CHANGE_ID"] = "1234"
    c = check(branch="feature/TEST")
    assert c == None

# Generated at 2022-06-21 20:37:06.081095
# Unit test for function frigg
def test_frigg():
    vars = {"FRIGG": "true", "FRIGG_BUILD_BRANCH": "feature", "FRIGG_PULL_REQUEST": "false"}
    for key, value in vars.items():
        os.environ[key] = value
    frigg('feature')

# Generated at 2022-06-21 20:37:13.822192
# Unit test for function checker
def test_checker():
    """Test checker function"""
    # Create function test function that returns true
    @checker
    def test_true():
        """Test function"""
        return True

    # Create function test function that raises an AssertionError
    @checker
    def test_false():
        """Test function"""
        assert False

    # Call test functions
    assert test_true()
    try:
        test_false()
    except AssertionError:
        pass
    except CiVerificationError:
        assert True
    except Exception:
        assert False



# Generated at 2022-06-21 20:37:15.948361
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMIT_REF_NAME"] = "master"
    assert gitlab("master") is True



# Generated at 2022-06-21 20:37:39.908392
# Unit test for function circle
def test_circle():
    assert circle("master")

# Generated at 2022-06-21 20:37:44.087433
# Unit test for function frigg
def test_frigg():
    """
    Unit test for function frigg
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    assert os.environ.get("FRIGG_PULL_REQUEST")



# Generated at 2022-06-21 20:37:48.952267
# Unit test for function travis
def test_travis():
    assert not travis("master")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-21 20:37:54.512306
# Unit test for function semaphore
def test_semaphore():
    os.environ['SEMAPHORE'] = 'true'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    os.environ['PULL_REQUEST_NUMBER'] = None
    assert semaphore('master')
    os.environ['BRANCH_NAME'] = 'do not work'
    with pytest.raises(CiVerificationError):
        semaphore('master')
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'
    with pytest.raises(CiVerificationError):
        semaphore('master')

# Generated at 2022-06-21 20:37:58.574351
# Unit test for function checker
def test_checker():
    def testfunc():
        raise AssertionError

    def testfunc2():
        return True

    assert checker(testfunc)() is True
    assert checker(testfunc2)() is True

# Generated at 2022-06-21 20:38:05.354395
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "true"
    try:
        check()
        assert False
    except CiVerificationError:
        assert True
    finally:
        del os.environ["JENKINS_URL"]
        del os.environ["GIT_BRANCH"]
        del os.environ["CHANGE_ID"]

# Generated at 2022-06-21 20:38:09.366964
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = "null"
    assert check("master") == True



# Generated at 2022-06-21 20:38:18.770592
# Unit test for function travis
def test_travis():
    """
    Unit test for function travis
    """

    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
    except Exception:
        assert False

    os.environ["TRAVIS_BRANCH"] = "non-master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
        assert False
    except CiVerificationError:
        assert True

    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "42"

# Generated at 2022-06-21 20:38:21.032140
# Unit test for function checker
def test_checker():
    @checker
    def test_true_assertion():
        assert True

    assert test_true_assertion()

    @checker
    def test_false_assertion():
        assert False

    try:
        test_false_assertion()
    except CiVerificationError:
        return True

    assert False

# Generated at 2022-06-21 20:38:25.802739
# Unit test for function checker
def test_checker():
    @checker
    def test_checker_inner():
        assert False

    from semantic_release.errors import CiVerificationError

    try:
        test_checker_inner()
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:39:14.585250
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check()
    del os.environ["CI_COMMIT_REF_NAME"], os.environ["CI_MERGE_REQUEST_ID"]

# Generated at 2022-06-21 20:39:16.265343
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    gitlab("master")



# Generated at 2022-06-21 20:39:23.117039
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert bitbucket("master") is True
    os.environ["BITBUCKET_BRANCH"] = "develop"
    assert bitbucket("master") is False
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1234"
    assert bitbucket("master") is False



# Generated at 2022-06-21 20:39:25.975332
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-21 20:39:36.084853
# Unit test for function check
def test_check():
    for key in ("TRAVIS", "SEMAPHORE", "FRIGG", "CIRCLECI", "GITLAB_CI", "JENKINS_URL"):
        os.environ[key] = "true"
    os.environ["BITBUCKET_BUILD_NUMBER"] = "asc"

    try:
        check()
    except:
        raise
    finally:
        for key in ("TRAVIS", "SEMAPHORE", "FRIGG", "CIRCLECI", "GITLAB_CI", "JENKINS_URL"):
            del os.environ[key]
        del os.environ["BITBUCKET_BUILD_NUMBER"]

# Generated at 2022-06-21 20:39:39.126990
# Unit test for function gitlab
def test_gitlab():
    """
    Unit test for checking gitlab environ var
    """
    os.environ["CI_COMMIT_REF_NAME"] = "Testbranch"
    check(branch="Testbranch")


# Generated at 2022-06-21 20:39:45.023173
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "TEST"
    os.environ["BITBUCKET_BRANCH"] = "master"

    try: #test the function with correct input
        bitbucket("master")
        assert 1
    except AssertionError:
        assert 0 #should work
    except Exception:
        assert 0 #should raise AssertionError

    try: #test the function with incorrect input
        bitbucket("dev")
        assert 0 #should not work
    except Exception as e:
        assert 1
        assert isinstance(e, CiVerificationError)

    os.environ["BITBUCKET_PR_ID"] = "1"

# Generated at 2022-06-21 20:39:47.740447
# Unit test for function frigg
def test_frigg():
    assert frigg("master") == True
    assert frigg("develop") == False


# Generated at 2022-06-21 20:39:56.592184
# Unit test for function bitbucket
def test_bitbucket():
    """ test_bitbucket """
    os.environ['BITBUCKET_BRANCH'] = 'test_branch'
    os.environ['BITBUCKET_PR_ID'] = '123'
    bitbucket('test_branch')
    os.environ['BITBUCKET_PR_ID'] = ''
    bitbucket('test_branch')
    os.environ['BITBUCKET_BRANCH'] = 'some_other_branch'
    assert os.environ['BITBUCKET_BRANCH'] != 'test_branch'
    os.environ['BITBUCKET_PR_ID'] = '123'
    assert os.environ['BITBUCKET_PR_ID'] != ''

# Generated at 2022-06-21 20:40:05.929279
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = True
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = None
    assert jenkins("master") is True
    os.environ["BRANCH_NAME"] = "other-branch"
    
    try:
        jenkins("master")
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."
    


# Generated at 2022-06-21 20:41:55.973673
# Unit test for function circle
def test_circle():
    """
    Verifies that the CircleCI check passes if all conditions are met.
    Also verifies that the CircleCI check raises an error on incorrect settings.
    """
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle()
    os.environ["CI_PULL_REQUEST"] = "true"
    assert not circle()
    os.environ.pop("CI_PULL_REQUEST")
    os.environ.pop("CIRCLE_BRANCH")
    assert not circle()
    os.environ.pop("CIRCLECI")
    assert not circle()

# Generated at 2022-06-21 20:41:56.466976
# Unit test for function check
def test_check():
    check()

# Generated at 2022-06-21 20:42:02.612153
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_PULL_REQUEST'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'

    try:
        frigg('master')
        raised = False
    except CiVerificationError:
        raised = True
    assert raised

    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    os.environ['FRIGG_BUILD_BRANCH'] = 'dev'

    try:
        frigg('master')
        raised = False
    except CiVerificationError:
        raised = True
    assert raised

    os.environ['FRIGG_PULL_REQUEST'] = 'false'

# Generated at 2022-06-21 20:42:07.644180
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PROJECT_URL"] = "http://gitlab.com"
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_PROJECT_URL"]


# Generated at 2022-06-21 20:42:16.450005
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        check()
    except CiVerificationError:
        assert False
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        check()
        assert False
    except CiVerificationError:
        pass
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    try:
        check()
        assert False
    except CiVerificationError:
        pass
    del os.environ["PULL_REQUEST_NUMBER"]

# Generated at 2022-06-21 20:42:22.542208
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert frigg("master")


if __name__ == '__main__':
    test_frigg()

# Generated at 2022-06-21 20:42:23.822079
# Unit test for function circle
def test_circle():
    assert len(locals()["circle"](branch="master")) == 1

# Generated at 2022-06-21 20:42:28.469631
# Unit test for function checker
def test_checker():
    @checker
    def a_function(*args):
        pass
    assert a_function() == True
    try:
        @checker
        def another_function(*args):
            raise AssertionError("a")
        another_function()
        assert False
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."

# Generated at 2022-06-21 20:42:31.913627
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]



# Generated at 2022-06-21 20:42:36.644525
# Unit test for function gitlab
def test_gitlab():
    """
    Unit test for function gitlab
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    gitlab("master")