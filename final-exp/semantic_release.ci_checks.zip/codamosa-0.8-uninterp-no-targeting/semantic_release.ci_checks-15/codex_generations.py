

# Generated at 2022-06-21 20:32:59.747528
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    print("Done travis")



# Generated at 2022-06-21 20:33:02.076136
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = 'value'
    os.environ["BRANCH_NAME"] = 'master'
    os.environ["CHANGE_ID"] = ''
    check()

# Generated at 2022-06-21 20:33:08.965789
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "some_branch"
    os.environ["CI_PULL_REQUEST"] = "123"
    check("some_branch")
    assert os.environ["CIRCLE_BRANCH"] == "some_branch"
    assert os.environ["CI_PULL_REQUEST"] == "123"



# Generated at 2022-06-21 20:33:13.907481
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["SEMAPHORE"] = "true"
    os.environ["FRIGG"] = "true"
    os.environ["CIRCLECI"] = "true"
    os.environ["GITLAB_CI"] = "true"
    os.environ["BITBUCKET_BUILD_NUMBER"] = "true"
    os.environ["JENKINS_URL"] = "true"
    check()

# Generated at 2022-06-21 20:33:18.520301
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = None

    check()

# Generated at 2022-06-21 20:33:23.527889
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ.pop("CI_MERGE_REQUEST_IID", None)
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = "1"
    check()

# Generated at 2022-06-21 20:33:25.196593
# Unit test for function check
def test_check():
    assert check("testBranch")



# Generated at 2022-06-21 20:33:29.807159
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = False
    frigg("master")



# Generated at 2022-06-21 20:33:38.493442
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle("master")
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]

    os.environ["CI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle("master")
    del os.environ["CI"]
    del os.environ["CIRCLE_BRANCH"]


# Generated at 2022-06-21 20:33:43.543637
# Unit test for function check
def test_check():
    """
    Unit test for function check
    """

    branch_name_default = "master"
    branch_name = "test"

    # ----------------------------------------------------------------------------
    # check without CI environment
    # ----------------------------------------------------------------------------
    check(branch=branch_name_default)

    # ----------------------------------------------------------------------------
    # travis environment
    # ----------------------------------------------------------------------------
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = branch_name_default
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check(branch=branch_name_default)

    with open("/tmp/test_semantic_release_log", "w") as f:
        os.environ["SEMANTIC_RELEASE_LOG_FILE"] = f.name

    #

# Generated at 2022-06-21 20:33:57.927338
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "feature/branch"
    os.environ["CI_PROJECT_NAME"] = "dir"
    try:
        gitlab("master")
        assert False
    except CiVerificationError:
        assert True
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    try:
        gitlab("master")
        assert True
    except CiVerificationError:
        assert False


# Generated at 2022-06-21 20:34:08.780132
# Unit test for function check
def test_check():

    def env(name, value=None):
        os.environ[name] = value

    branch = "master"

# Generated at 2022-06-21 20:34:18.246174
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://localhost:8000"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = None
    jenkins("master")

    os.environ["JENKINS_URL"] = "http://localhost:8000"
    os.environ["BRANCH_NAME"] = "foo-branch"
    os.environ["CHANGE_ID"] = None
    jenkins("master")

    os.environ["JENKINS_URL"] = "http://localhost:8000"
    os.environ["BRANCH_NAME"] = "foo-branch"
    os.environ["CHANGE_ID"] = "123"
    jenkins("master")

# Generated at 2022-06-21 20:34:20.683350
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["GITLAB_CI"] = "true"
    assert check()

# Generated at 2022-06-21 20:34:33.441177
# Unit test for function check
def test_check():
    """
    Check that all the checks are called.
    """
    def semantic_release_travis(branch: str):
        return True

    def semantic_release_semaphore(branch: str):
        return True

    def semantic_release_frigg(branch: str):
        return True

    def semantic_release_circle(branch: str):
        return True

    def semantic_release_gitlab(branch: str):
        return True

    def semantic_release_jenkins(branch: str):
        return True

    def semantic_release_bitbucket(branch: str):
        return True

    # mock the original functions
    import semantic_release.ci_checks

    semantic_release.ci_checks.travis = semantic_release_travis
    semantic_release.ci_checks.semaphore

# Generated at 2022-06-21 20:34:44.771315
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "feature/test_branch"
    os.environ["CI_ALL_COMMIT_REF_NAMES"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "None"
    os.environ["CI_COMMIT_REF_NAME"] = "feature/test_branch"
    try:
        gitlab("master")
    except CiVerificationError:
        assert True
    else:
        assert False
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    try:
        gitlab("master")
    except CiVerificationError:
        assert False
    else:
        assert True
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ

# Generated at 2022-06-21 20:34:50.122230
# Unit test for function semaphore
def test_semaphore():
    branch = "master"
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = branch
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore(branch)

# Generated at 2022-06-21 20:34:53.134647
# Unit test for function checker
def test_checker():
    """Test the checker function works correctly."""
    @checker
    def mock_func():
        """Mock function of checker decorator"""
        raise AssertionError()

    with pytest.raises(CiVerificationError):
        mock_func()

# Generated at 2022-06-21 20:34:58.504719
# Unit test for function semaphore
def test_semaphore():

    assert checker(semaphore)() is True

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "False"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    assert checker(semaphore)() is True

    os.environ["PULL_REQUEST_NUMBER"] = "True"
    assert checker(semaphore)() is False

    del os.environ["PULL_REQUEST_NUMBER"]
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert checker(semaphore)() is False



# Generated at 2022-06-21 20:35:02.711221
# Unit test for function checker

# Generated at 2022-06-21 20:35:11.477262
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert check() is None

# Generated at 2022-06-21 20:35:21.312671
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG"] = "false"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    os.environ["FRIGG_TASK_ID"] = "2"
    try:
        frigg()
    except:
        pass
    try:
        frigg("test")
    except:
        pass
    os.environ["FRIGG_BUILD_BRANCH"] = "test"

# Generated at 2022-06-21 20:35:22.411726
# Unit test for function check
def test_check():
    """
    Ensure that check method runs without exceptions
    """
    check()

# Generated at 2022-06-21 20:35:29.122722
# Unit test for function checker
def test_checker():
    """
    Tests that the checker functions properly.

    :return: True if test is successful, False if not.
    """

    def raise_error():
        raise AssertionError

    def return_true():
        return True

    assert checker(raise_error)() is False
    assert checker(return_true)() is True

# Generated at 2022-06-21 20:35:33.437197
# Unit test for function check
def test_check():
    # Set up the test environment
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    # Actually run the check
    check()

# Generated at 2022-06-21 20:35:36.350380
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")



# Generated at 2022-06-21 20:35:47.777807
# Unit test for function travis
def test_travis():

    # Test for success
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")

    # Test for failure because of wrong branch
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
    except CiVerificationError:
        assert True
    else:
        assert False

    # Test for failure because of pull request
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"

# Generated at 2022-06-21 20:35:50.930302
# Unit test for function jenkins
def test_jenkins():
    def check(branch: str = None):
        assert branch == "master"
    branch = "master"
    os.environ["JENKINS_URL"] = "some-url"
    jenkins(check, branch)

# Generated at 2022-06-21 20:35:52.332064
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = 'master'
    os.environ["TRAVIS_PULL_REQUEST"] = 'false'
    travis('master')



# Generated at 2022-06-21 20:35:56.318630
# Unit test for function travis
def test_travis():
    try:
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        travis("master")
    finally:
        os.environ.pop("TRAVIS_BRANCH", None)
        os.environ.pop("TRAVIS_PULL_REQUEST", None)


# Generated at 2022-06-21 20:36:09.810636
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "True"
    os.environ["BRANCH_NAME"] = "master"
    
    check()
    
    os.environ["JENKINS_URL"] = "True"
    os.environ["BRANCH_NAME"] = "release"
    
    check()
    
    os.environ["JENKINS_URL"] = "True"
    os.environ["GIT_BRANCH"] = "master"

    check()
    
    os.environ["JENKINS_URL"] = "True"
    os.environ["GIT_BRANCH"] = "release"

    check()



# Generated at 2022-06-21 20:36:16.902985
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "test"

    assert gitlab("test") is True

    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert gitlab("test") is False

    del os.environ['CI_COMMIT_REF_NAME']
    del os.environ['GITLAB_CI']



# Generated at 2022-06-21 20:36:21.624485
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('master')
    assert os.environ['TRAVIS_BRANCH'] == 'master'
    assert os.environ['TRAVIS_PULL_REQUEST'] == 'false'


# Generated at 2022-06-21 20:36:25.125631
# Unit test for function checker
def test_checker():
    @checker
    def check_1():
        """
        trivial check function
        """
        raise AssertionError()

    def check_2():
        """
        trivial check function
        """
        raise AssertionError()

    try:
        check_1()
    except CiVerificationError:
        pass
    
    try:
        check_2()
    except AssertionError:
        pass

# Generated at 2022-06-21 20:36:29.626887
# Unit test for function checker
def test_checker():
    import pytest

    @checker
    def success():
        pass

    @checker
    def failure():
        assert False

    try:
        success()
    except Exception:
        pytest.fail("success() should not raise an exception")

    with pytest.raises(CiVerificationError):
        failure()

# Generated at 2022-06-21 20:36:39.245283
# Unit test for function semaphore
def test_semaphore():

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore(branch="master")

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "feature-1"
    os.environ["PULL_REQUEST_NUMBER"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore(branch="master")

# Generated at 2022-06-21 20:36:43.155318
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("branch") is True
    assert jenkins("master") is False
    os.environ["GIT_BRANCH"] = "master"
    assert jenkins("master") is True

# Generated at 2022-06-21 20:36:48.870423
# Unit test for function frigg
def test_frigg():
    """
    A unit test for function frigg.
    :return: None
    """
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "travis"
    assert frigg("master") == False

# Generated at 2022-06-21 20:36:55.835518
# Unit test for function travis
def test_travis():
    os.environ.update(
        {"TRAVIS_BRANCH": "master", "TRAVIS_PULL_REQUEST": "false"}
    )
    travis("master")
    assert os.environ.get("TRAVIS_BRANCH")


travis = checker(travis)
semaphore = checker(semaphore)
frigg = checker(frigg)



# Generated at 2022-06-21 20:36:58.982582
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = None
    os.environ["JENKINS_URL"] = "https://jenkins.com/"

    check()

# Generated at 2022-06-21 20:37:07.502501
# Unit test for function semaphore
def test_semaphore():
    assert os.environ.get("SEMAPHORE") == "true"
    assert semaphore("master") == True


# Generated at 2022-06-21 20:37:17.682891
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"

    try:
        bitbucket(branch="master")
        assert False
    except AssertionError:
        assert True

    del os.environ["BITBUCKET_BRANCH"]
    try:
        bitbucket(branch="master")
        assert False
    except AssertionError:
        assert True

    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket(branch="master")
        assert False
    except AssertionError:
        assert True

# Generated at 2022-06-21 20:37:29.700297
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master") == True
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master") == False
    os.environ["SEMAPHORE_THREAD_RESULT"] = None
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    assert semaphore("master") == False
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["BRANCH_NAME"] = "test"
    assert semaphore("master") == False
    os.environ["BRANCH_NAME"] = None

if __name__ == "__main__":
    test_semaphore()

# Generated at 2022-06-21 20:37:34.905449
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    assert frigg("test")
    assert not frigg("not-test")
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG"]


# Generated at 2022-06-21 20:37:45.126632
# Unit test for function bitbucket
def test_bitbucket():
    """
    Tests bitbucket's checker function.
    """
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"

    # Check if it succeeds as it should if everything is correct
    assert bitbucket(branch="master")

    # Check if checker raises if the branch isn't correct
    os.environ["BITBUCKET_BRANCH"] = "notmaster"
    try:
        bitbucket(branch="master")
    except CiVerificationError:
        pass
    else:
        assert False, "bitbucket CI verification did not raise"

    # Check if checker raises if this is a pull request
    del os.environ["BITBUCKET_BRANCH"]

# Generated at 2022-06-21 20:37:48.380445
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    check()



# Generated at 2022-06-21 20:37:54.221090
# Unit test for function jenkins
def test_jenkins():
    # Setting the environment variable if not set by the CI environment
    os.environ["JENKINS_URL"] = "https://jenkins.test.com"
    os.environ["BRANCH_NAME"] = "4.0"
    os.environ["GIT_BRANCH"] = "4.0"
    os.environ["CHANGE_ID"] = ""
    check()
    # Setting the environment variable if not set by the CI environment
    os.environ["JENKINS_URL"] = "https://jenkins.test.com"
    os.environ["BRANCH_NAME"] = "4.0"
    os.environ["GIT_BRANCH"] = "4.0"
    os.environ["CHANGE_ID"] = "42"
    # Checking case if branch is wrong


# Generated at 2022-06-21 20:37:58.267890
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    del os.environ["CI_PULL_REQUEST"]
    assert circle(os.environ["CIRCLE_BRANCH"])

# Generated at 2022-06-21 20:38:02.114341
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_BRANCH"] = "master"
    check()



# Generated at 2022-06-21 20:38:05.039124
# Unit test for function checker
def test_checker():
    def right_branch():
        assert True

    def wrong_branch():
        assert False

    assert checker(right_branch)()
    assert checker(wrong_branch)()

# Generated at 2022-06-21 20:38:15.300526
# Unit test for function semaphore
def test_semaphore():
    assert os.environ.get("PULL_REQUEST_NUMBER") != "1"
    assert os.environ.get("SEMAPHORE_THREAD_RESULT") != "failed"
    assert os.environ.get("BRANCH_NAME") == "test"

# Generated at 2022-06-21 20:38:18.069995
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert gitlab("master") is True
    os.environ["CI_COMMIT_REF_NAME"] = "development"
    assert gitlab("master") is False

# Generated at 2022-06-21 20:38:20.875792
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "True"
    os.environ["BRANCH_NAME"] = "master"
    assert jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    try:
        jenkins("master")
    except CiVerificationError:
        return True
    assert False


# Generated at 2022-06-21 20:38:24.353683
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    circle()


# Generated at 2022-06-21 20:38:29.189522
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "jenkinsURL"
    os.environ["BRANCH_NAME"] = "master"
    jenkins("master")
    os.environ["BRANCH_NAME"] = None
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")

# Generated at 2022-06-21 20:38:39.835639
# Unit test for function check
def test_check():
    # Test for valid
    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    check()

    # Test for invalid
    os.environ['TRAVIS_PULL_REQUEST'] = "true"
    try:
        check()
        assert False
    except CiVerificationError:
        pass

    # Test for invalid
    os.environ['TRAVIS_BRANCH'] = "beta"
    try:
        check("master")
        assert False
    except CiVerificationError:
        pass

    # Test for invalid
    os.environ['TRAVIS_PULL_REQUEST'] = "false"

# Generated at 2022-06-21 20:38:42.252970
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")

# Generated at 2022-06-21 20:38:45.377231
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    travis("master")
    os.environ['TRAVIS_BRANCH'] = "development"
    travis("master")


# Generated at 2022-06-21 20:38:49.605605
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master") is True
    os.environ["TRAVIS_BRANCH"] = "develop"
    assert travis("master") is False
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    assert travis("master") is False
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]



# Generated at 2022-06-21 20:38:59.342444
# Unit test for function check
def test_check():
    # Setup
    os.environ['TRAVIS'] = "ture"
    os.environ['SEMAPHORE'] = "ture"
    os.environ['FRIGG'] = "ture"
    os.environ['CIRCLECI'] = "ture"
    os.environ['GITLAB_CI'] = "true"
    os.environ['JENKINS_URL'] = "www.github.com"
    os.environ['BITBUCKET_BUILD_NUMBER'] = "ture"

    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"

    os.environ['BRANCH_NAME'] = "master"

# Generated at 2022-06-21 20:39:09.678892
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["BRANCH_NAME"] = "master"
    os.environ.pop("PULL_REQUEST_NUMBER", None)

    semaphore(branch="master")

# Generated at 2022-06-21 20:39:13.690654
# Unit test for function semaphore
def test_semaphore():
    branch = "master"
    os.environ["BRANCH_NAME"] = branch
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore(branch)

# Generated at 2022-06-21 20:39:18.851692
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_IID'] = None
    assert check() == True
    os.environ['CI_COMMIT_REF_NAME'] = 'staging'
    os.environ['CI_MERGE_REQUEST_IID'] = 5
    try:
        check()
    except :
        assert True
    else:
        assert False



# Generated at 2022-06-21 20:39:24.116910
# Unit test for function jenkins
def test_jenkins():
    branch = "master"
    os.environ["BRANCH_NAME"] = branch
    os.environ["JENKINS_URL"] = "whatever"
    os.environ["GIT_BRANCH"] = branch
    os.environ["CHANGE_ID"] = None
    jenkins(branch)

# Generated at 2022-06-21 20:39:26.769928
# Unit test for function checker
def test_checker():
    @checker
    def raise_exception():
        raise AssertionError
    try:
        raise_exception()
        assert False
    except CiVerificationError:
        pass


# Unit tests for function check

# Generated at 2022-06-21 20:39:30.476120
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")



# Generated at 2022-06-21 20:39:34.983407
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    branch = "feature/test_ci_checks"
    os.environ['CIRCLE_BRANCH'] = branch
    os.environ['CI_PULL_REQUEST'] = None
    circle(branch)

# Generated at 2022-06-21 20:39:39.550719
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = "true"
    os.environ['CI_PULL_REQUEST'] = "true"
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    check("master")

# Generated at 2022-06-21 20:39:41.601494
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    circle('master')


# Generated at 2022-06-21 20:39:52.823853
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "testing"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = ""
    assert jenkins("master") == True
    os.environ["GIT_BRANCH"] = "develop"
    assert jenkins("master") == False
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "testing"
    assert jenkins("master") == False
    os.environ["JENKINS_URL"] = ""
    assert jenkins("master") == False

# Generated at 2022-06-21 20:40:10.575289
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "10"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")

# Generated at 2022-06-21 20:40:12.599173
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check(branch="master")

# Generated at 2022-06-21 20:40:18.156706
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = "124"
    try:
        check(branch="master")
    except CiVerificationError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 20:40:22.541909
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "branch_name"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    check(branch="branch_name")

# Generated at 2022-06-21 20:40:27.942642
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "hello"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "1"

    try:
        jenkins("abc")
        assert False
    except CiVerificationError:
        assert True

    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "1"
    try:
        jenkins("master")
        assert False
    except CiVerificationError:
        assert True

    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = None

# Generated at 2022-06-21 20:40:37.293343
# Unit test for function check
def test_check():
    # check the branch variable and if it's not master we will throw an exception
    branch = "master"

    # Test Travis CI
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = branch
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check(branch)

    # Test Semaphore CI
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = branch
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check(branch)

    # Test Frigg CI
    os.environ["FRIGG"] = "true"

# Generated at 2022-06-21 20:40:42.217580
# Unit test for function checker
def test_checker():
    @checker
    def check_1():
        raise AssertionError

    @checker
    def check_2():
        pass

    try:
        check_1()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("check_1 failed to raise CiVerificationError")

    assert check_2()

# Generated at 2022-06-21 20:40:47.988383
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    with pytest.raises(CiVerificationError):
        check()

    os.environ["TRAVIS"] = "false"
    os.environ["SEMAPHORE"] = "true"
    with pytest.raises(CiVerificationError):
        check()

    os.environ["SEMAPHORE"] = "false"
    os.environ["FRIGG"] = "true"
    with pytest.raises(CiVerificationError):
        check()

    os.environ["FRIGG"] = "false"
    os.environ["CIRCLECI"] = "true"
    with pytest.raises(CiVerificationError):
        check()

    os.environ["CIRCLECI"] = "false"

# Generated at 2022-06-21 20:40:50.072018
# Unit test for function gitlab
def test_gitlab():
    assert gitlab("master")
    assert not gitlab("development")

# Generated at 2022-06-21 20:40:55.478293
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test for bitbucket detector
    """
    os.environ["BITBUCKET_BRANCH"] = 'master'
    assert os.environ.get("BITBUCKET_BRANCH") == 'master'
    assert not os.environ.get("BITBUCKET_PR_ID")


# Generated at 2022-06-21 20:41:11.559458
# Unit test for function checker
def test_checker():
    def test_func():
        if os.environ.get("TRAVIS") != "true":
            raise AssertionError("Not in travis environment")

    try:
        checker(test_func)()
    except CiVerificationError:
        assert False
    else:
        assert True



# Generated at 2022-06-21 20:41:14.388676
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "other"
    try:
        frigg("master")
    except CiVerificationError as error:
        # This is an intended behavior
        assert error


# Generated at 2022-06-21 20:41:22.969934
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        frigg("test")
        raise AssertionError
    except AssertionError:
        pass
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")



# Generated at 2022-06-21 20:41:26.046135
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "https://"
    os.environ["CHANGE_ID"] = "false"
    check()

# Generated at 2022-06-21 20:41:31.260673
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    check()
#EOF

# Generated at 2022-06-21 20:41:39.000312
# Unit test for function bitbucket
def test_bitbucket():
    # checker function
    assert checker(bitbucket)("release/1.2.3")
    assert checker(bitbucket)("release/1.2.3")
    # test Bitbucket
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    assert checker(bitbucket)("master")
    # test with no environment
    os.environ.pop("BITBUCKET_BRANCH", None)
    os.environ.pop("BITBUCKET_PR_ID", None)
    assert checker(bitbucket)("master") == True
    # test on pull-request
    os.environ["BITBUCKET_BRANCH"] = "master"

# Generated at 2022-06-21 20:41:39.834456
# Unit test for function check
def test_check():
    assert check()

# Generated at 2022-06-21 20:41:42.043587
# Unit test for function circle
def test_circle():
    try:
        circle(branch="develop")
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:41:43.766849
# Unit test for function checker
def test_checker():
    """Test checker"""
    @checker
    def func():
        assert 1 == 2

    try:
        func()
    except CiVerificationError:
        pass # expected

# Generated at 2022-06-21 20:41:52.623601
# Unit test for function semaphore
def test_semaphore():
    from unittest import mock
    import sys
    import os
    from typing import Callable
    from semantic_release.errors import CiVerificationError
    from semantic_release.ci_checks import checker
    def func_wrapper(*args, **kwargs):
        try:
            checker(semaphore)(*args, **kwargs)
            return True
        except CiVerificationError:
            return False
    with mock.patch.dict(os.environ):
        os.environ["BRANCH_NAME"] = "master"
        assert func_wrapper()
        os.environ["BRANCH_NAME"] = "develop"
        assert not func_wrapper()


# Generated at 2022-06-21 20:42:09.474876
# Unit test for function checker
def test_checker():
    @checker
    def failed_checker():
        assert 1 == 0

    try:
        failed_checker()
    except CiVerificationError:
        pass
    else:
        assert False, "Should raise CiVerificationError"

# Generated at 2022-06-21 20:42:12.609107
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Expecting a CiVerificationError")

# Generated at 2022-06-21 20:42:15.054642
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "dev"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"


# Generated at 2022-06-21 20:42:22.712627
# Unit test for function bitbucket
def test_bitbucket():
    import os
    os.environ['BITBUCKET_BRANCH']="master"
    os.environ['BITBUCKET_PR_ID']="false"
    bitbucket(branch="master")
    os.environ['BITBUCKET_BRANCH']="develop"
    os.environ['BITBUCKET_PR_ID']="true"
    try:
        bitbucket(branch="master")
        assert False
    except AssertionError:
        assert True

# Generated at 2022-06-21 20:42:26.747220
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket("master") == True
    os.environ["BITBUCKET_BRANCH"] = "dev"
    assert bitbucket("master") == False
    os.environ["BITBUCKET_PR_ID"] = "123"
    assert bitbucket("master") == False

# Generated at 2022-06-21 20:42:30.164540
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert True
    test_func()

    @checker
    def test_false_func():
        assert False
    try:
        test_false_func()
    except CiVerificationError:
        pass
    else:
        raise RuntimeError("test failed")

# Generated at 2022-06-21 20:42:33.855604
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("test")

    os.environ["JENKINS_URL"] = "test_url"
    assert jenkins("test")

    os.environ["JENKINS_URL"] = "test_url"
    os.environ["CHANGE_ID"] = "change_id"
    try:
        jenkins("test")
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-21 20:42:37.390899
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for function bitbucket
    """
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")



# Generated at 2022-06-21 20:42:38.774033
# Unit test for function semaphore
def test_semaphore():
    assert semaphore.__name__ == 'semaphore'

# Generated at 2022-06-21 20:42:42.297254
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")