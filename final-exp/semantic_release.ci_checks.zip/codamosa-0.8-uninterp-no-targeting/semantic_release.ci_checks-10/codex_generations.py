

# Generated at 2022-06-21 20:33:00.374985
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "test"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("test") == True

# Generated at 2022-06-21 20:33:06.185795
# Unit test for function semaphore
def test_semaphore():
    os.environ['SEMAPHORE_THREAD_RESULT'] = "passed"
    os.environ['BRANCH_NAME'] = "develop"
    semaphore("develop")
    del os.environ['SEMAPHORE_THREAD_RESULT']
    del os.environ['BRANCH_NAME']
    os.environ['SEMAPHORE_THREAD_RESULT'] = "failed"
    os.environ['BRANCH_NAME'] = "develop"
    semaphore("develop")
    del os.environ['SEMAPHORE_THREAD_RESULT']
    del os.environ['BRANCH_NAME']
    os.environ['SEMAPHORE_THREAD_RESULT'] = "passed"

# Generated at 2022-06-21 20:33:10.353147
# Unit test for function checker
def test_checker():
    def passing_func():
        pass

    def failing_func():
        assert False

    passing_func = checker(passing_func)
    passing_func()

    failing_func = checker(failing_func)
    try:
        failing_func()
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."
    else:
        raise AssertionError("CiVerificationError not raised on AssertionError")

# Generated at 2022-06-21 20:33:13.001697
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    check()



# Generated at 2022-06-21 20:33:14.124330
# Unit test for function check
def test_check():
    assert check()

# Generated at 2022-06-21 20:33:17.577452
# Unit test for function checker
def test_checker():
    """
    Test for function checker.
    """
    def function_test():
        """
        Function that raises an AssertionError.
        """
        assert False

    try:
        checker(function_test)()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:33:27.958061
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    assert True == frigg("develop")
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    assert False == frigg("develop")
    os.environ["FRIGG_PULL_REQUEST"] = "1"
    assert False == frigg("develop")
    os.environ.pop("FRIGG")
    os.environ.pop("FRIGG_BUILD_BRANCH")
    os.environ.pop("FRIGG_PULL_REQUEST")


# Generated at 2022-06-21 20:33:32.936128
# Unit test for function check
def test_check():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS"] = "false"
    assert check("master")

# Generated at 2022-06-21 20:33:44.361272
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    assert frigg("develop")
    assert not frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "1"
    assert not frigg("master")
    os.environ.pop("FRIGG_PULL_REQUEST")


# Generated at 2022-06-21 20:33:48.824436
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "feature/branch"
    check("feature/branch")
    del os.environ["CI_COMMIT_REF_NAME"]
    with pytest.raises(CiVerificationError):
        check()


# Generated at 2022-06-21 20:34:06.186846
# Unit test for function gitlab
def test_gitlab():
    """
    Unit test for function gitlab
    """

    # CASE 1: Gitlab
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = False
    gitlab(branch='master')

    # CASE 2: Gitlab (branch failure)
    os.environ['CI_COMMIT_REF_NAME'] = 'develop'
    with pytest.raises(CiVerificationError) as exc_info:
        gitlab(branch='master')

    # CASE 3: Gitlab (PR failure)
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = True

# Generated at 2022-06-21 20:34:12.163103
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    assert frigg('master')
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]

# Generated at 2022-06-21 20:34:15.204833
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] ='master'
    os.environ['TRAVIS_PULL_REQUEST'] ='false'
    travis('master')


# Generated at 2022-06-21 20:34:20.937425
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "test_branch"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("test_branch")

    os.environ["CI_PULL_REQUEST"] = "123"
    try:
        assert circle("test_branch")
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-21 20:34:24.973067
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

# Generated at 2022-06-21 20:34:27.706955
# Unit test for function circle
def test_circle():
    assert circle.__name__ == "circle"



# Generated at 2022-06-21 20:34:33.921076
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    os.environ["CI_PROJECT_NAME"] = "example"

    gitlab("develop")

    assert os.environ.get("GITLAB_CI") == "true"
    assert os.environ.get("CI_PROJECT_NAME") == "example"


# Generated at 2022-06-21 20:34:37.368971
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    travis("master")



# Generated at 2022-06-21 20:34:42.568692
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://example.com"
    os.environ["BRANCH_NAME"] = "master"
    assert check() is None
    del os.environ["BRANCH_NAME"]
    os.environ["GIT_BRANCH"] = "master"
    assert check() is None


# Generated at 2022-06-21 20:34:50.081255
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = 'false'
    # will not raise any exception
    check()
    os.environ['CIRCLE_BRANCH'] = 'dev'
    # will raise an exception
    try:
        check()
    except CiVerificationError as e:
        assert 'The verification check for the environment did not pass.' in str(e)



# Generated at 2022-06-21 20:34:59.255748
# Unit test for function checker
def test_checker():
    @checker
    def do_test():
        raise AssertionError()

    try:
        do_test()
    except CiVerificationError:
        return True

    assert False



# Generated at 2022-06-21 20:35:04.166224
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "http://localhost"
    os.environ["CHANGE_ID"] = "DUMMY"
    assert jenkins("master")

# Generated at 2022-06-21 20:35:07.874145
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")



# Generated at 2022-06-21 20:35:11.032201
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()
    assert True

# Generated at 2022-06-21 20:35:18.289654
# Unit test for function jenkins
def test_jenkins():
    """
    Unit test for the function jenkins

    :return:
    """
    os.environ["JENKINS_URL"] = "jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"

    jenkins("master")

    del os.environ["JENKINS_URL"]
    del os.environ["BRANCH_NAME"]
    del os.environ["GIT_BRANCH"]



# Generated at 2022-06-21 20:35:20.924970
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    os.environ['CI_PIPELINE_SOURCE'] = "push"
    assert gitlab("master")



# Generated at 2022-06-21 20:35:23.949581
# Unit test for function checker
def test_checker():
    def test_func():
        raise AssertionError()
    with pytest.raises(CiVerificationError):
        test_func = checker(test_func)
        test_func()

# Generated at 2022-06-21 20:35:28.649228
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = 'true'
    os.environ["CIRCLE_BRANCH"] = 'master'
    os.environ["CI_PULL_REQUEST"] = ''
    assert circle() == True

# Generated at 2022-06-21 20:35:32.582555
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "False"

    check()


# Generated at 2022-06-21 20:35:35.661571
# Unit test for function checker
def test_checker():
    @checker
    def assert_true():
        assert True
    try:
        assert_true()
    except CiVerificationError:
        assert False, 'checker function failed to ignore assertion error'
    
    @checker
    def assert_false():
        assert False
    try:
        assert_false()
    except CiVerificationError as e:
        assert True
    else:
        assert False, 'checker function failed to raise CiVerificationError exception'

# Generated at 2022-06-21 20:35:53.509288
# Unit test for function semaphore
def test_semaphore():
    """
    Test function semaphore for checking whether the build is successful,
    is on the correct branch and not a pull-request.

    :return: error if the environment does not pass the check.
    """
    import os
    from semantic_release.errors import CiVerificationError

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("master")
    except CiVerificationError:
        assert False


# Generated at 2022-06-21 20:36:01.025942
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "something"
    os.environ["CHANGE_ID"] = ""
    try:
        check()
    except:
        raise Exception("jenkins function failed")

    os.environ.pop("CHANGE_ID")
    os.environ.pop("BRANCH_NAME")
    os.environ.pop("JENKINS_URL")


# Generated at 2022-06-21 20:36:04.378307
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    assert circle('master')
    assert not circle('develop')

# Generated at 2022-06-21 20:36:07.977414
# Unit test for function jenkins
def test_jenkins():
    os.environ['BRANCH_NAME'] = "master"
    os.environ['JENKINS_URL'] = "http://url"
    os.environ['CHANGE_ID'] = ""
    jenkins("master")
    # TODO - need more tests for failures

# Generated at 2022-06-21 20:36:19.449718
# Unit test for function frigg
def test_frigg():
    """
    Tests the checks performed by the frigg CI environment
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""

    assert frigg("master")

    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    with pytest.raises(CiVerificationError):
        frigg("master")

    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "123"
    with pytest.raises(CiVerificationError):
        frigg("master")



# Generated at 2022-06-21 20:36:21.589487
# Unit test for function check
def test_check():
    try:
        check(os.environ.get("GIT_BRANCH"))
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:36:26.097000
# Unit test for function travis
def test_travis():
    try:
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        travis(branch="master")
    except:
        raise
    finally:
        if "TRAVIS_BRANCH" in os.environ:
            del os.environ["TRAVIS_BRANCH"]
        if "TRAVIS_PULL_REQUEST" in os.environ:
            del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-21 20:36:29.625741
# Unit test for function checker
def test_checker():
    def mockFunc():
        raise AssertionError

    assert callable(checker(mockFunc))

    try:
        checker(mockFunc)()
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-21 20:36:34.594067
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    gitlab("master")
    os.environ["CI_COMMIT_REF_NAME"] = "feature-branch"
    gitlab("feature-branch")
    del os.environ["CI_COMMIT_REF_NAME"]



# Generated at 2022-06-21 20:36:37.811732
# Unit test for function frigg
def test_frigg():
    branch = "master"
    ret = 1
    try:
        frigg(branch)
    except CiVerificationError:
        ret = 0
    assert ret == 1


# Generated at 2022-06-21 20:37:03.215353
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    frigg()



# Generated at 2022-06-21 20:37:14.594801
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    check()
    os.environ["FRIGG_BUILD_BRANCH"] = "not master"
    with pytest.raises(CiVerificationError):
        check()
    os.environ["FRIGG_PULL_REQUEST"] = "123"
    with pytest.raises(CiVerificationError):
        check()
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    check()
    os.environ.pop("FRIGG")

# Generated at 2022-06-21 20:37:21.674527
# Unit test for function check
def test_check():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS"] = "true"
    assert check() is True
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]
    del os.environ["TRAVIS"]

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["SEMAPHORE"] = "true"
    assert check() is True

# Generated at 2022-06-21 20:37:25.286783
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'

    travis('master')


# Generated at 2022-06-21 20:37:30.408493
# Unit test for function circle
def test_circle():
    test_branch = "master"
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = test_branch
    os.environ["CI_PULL_REQUEST"] = ""
    circle(test_branch)


# Generated at 2022-06-21 20:37:41.211157
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "some-other-branch"
    os.environ["CI_PULL_REQUEST"] = "some-pull-request"
    try:
        circle("master")
        assert False
    except Exception:
        pass
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = None
    try:
        circle("master")
    except Exception:
        assert False
    os.environ["CIRCLE_BRANCH"] = "some-other-branch"
    os.environ["CI_PULL_REQUEST"] = None

# Generated at 2022-06-21 20:37:45.120033
# Unit test for function checker
def test_checker():
    from semantic_release.errors import CiVerificationError
    from semantic_release.checks import checker

    @checker
    def test():
        raise AssertionError("Error")

    try:
        test()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Error")

# Generated at 2022-06-21 20:37:52.653666
# Unit test for function circle
def test_circle():
    with open(os.devnull, "w") as devnull:
        eget = os.environ.get
        for test_var in ["CIRCLECI"]:
            try:
                os.environ["CIRCLE_BRANCH"] = "master"
                os.environ["CI_PULL_REQUEST"] = None
                del os.environ[test_var]
                circle("master")
            except CiVerificationError:
                pass
            else:
                raise AssertionError(
                    "CiVerificationError should be raised when %s is not set" % test_var
                )


# Generated at 2022-06-21 20:38:04.115308
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_BUILD_NUMBER'] = '2'
    os.environ['BITBUCKET_BUILD_LINK'] = 'https://bitbucket.org/a_repo/a_project'
    os.environ['BITBUCKET_COMMIT'] = 'f711de99bc63'
    os.environ['BITBUCKET_PR_ID'] = '0'
    os.environ['BITBUCKET_REPO_OWNER'] = 'a_repo'
    os.environ['BITBUCKET_REPO_SLUG'] = 'a_project'
    os.environ['BITBUCKET_WORKSPACE'] = '/tmp/cicd_tests'


# Generated at 2022-06-21 20:38:06.524917
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('master')



# Generated at 2022-06-21 20:38:57.262907
# Unit test for function checker
def test_checker():
    def pass_func():
        pass

    def fail_func():
        assert False

    assert checker(pass_func)() is True
    try:
        checker(fail_func)()
    except CiVerificationError as e:
        assert e.args[0] == "The verification check for the environment did not pass."

# Generated at 2022-06-21 20:39:03.112178
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = "true"
    os.environ['CIRCLE_BRANCH'] = "master"
    os.environ['CI_PULL_REQUEST'] = ""
    os.environ['CIRCLECI_PULL_REQUEST'] = ""
    assert check()



# Generated at 2022-06-21 20:39:08.482377
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    assert not semaphore("test")
    del os.environ["BRANCH_NAME"]
    assert not semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    assert not semaphore("master")
    del os.environ["PULL_REQUEST_NUMBER"]
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore("master")

# Generated at 2022-06-21 20:39:11.639020
# Unit test for function gitlab
def test_gitlab():
    assert os.environ.get("GITLAB_CI") == "true"
    assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
    assert not os.environ.get("CI_MERGE_REQUEST_ID")

# Generated at 2022-06-21 20:39:15.601788
# Unit test for function checker
def test_checker():
    """ Ensure all CI environments are checked and up-to-date. """
    # expected to raise CiVerificationError
    travis(branch='dev')
    semaphore(branch='dev')
    frigg(branch='dev')
    circle(branch='dev')
    gitlab(branch='dev')
    jenkins(branch='dev')
    bitbucket(branch='dev')

# Generated at 2022-06-21 20:39:24.282037
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    assert bitbucket("master") == True

    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "test"
    assert bitbucket("master") == False

    os.environ["BITBUCKET_BRANCH"] = "test"
    os.environ["BITBUCKET_PR_ID"] = None
    assert bitbucket("master") == False

# Generated at 2022-06-21 20:39:31.021782
# Unit test for function gitlab
def test_gitlab():
    """Test gitlab function in package semantic_release.ci_checks"""
    ci_url = 'https://gitlab.com/user/test/test'
    os.environ['CI_PROJECT_URL'] = ci_url
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    assert gitlab('master')


if __name__ == "__main__":
    test_gitlab()

# Generated at 2022-06-21 20:39:36.530667
# Unit test for function gitlab
def test_gitlab():
    os.environ['GITLAB_CI'] = 'true'
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    assert check() is None
    os.environ['CI_COMMIT_REF_NAME'] = 'other'
    try:
        assert check() is None
    except Exception as e:
        assert isinstance(e, CiVerificationError)

# Generated at 2022-06-21 20:39:43.905259
# Unit test for function jenkins
def test_jenkins():
    """
    Test function jenkins
    """
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    os.environ["BRANCH_NAME"] = "master"
    jenkins("master")
    del os.environ["BRANCH_NAME"]
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")
    del os.environ["GIT_BRANCH"]
    os.environ["CHANGE_ID"] = "PR-ID-1234"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Should be a pull-request and should raise CiVerificationError"
    os.environ["CHANGE_ID"] = ""
   

# Generated at 2022-06-21 20:39:48.809687
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = ''
    check()



# Generated at 2022-06-21 20:41:31.263444
# Unit test for function check
def test_check():
    check()

# Generated at 2022-06-21 20:41:33.704288
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    frigg('master')


# Generated at 2022-06-21 20:41:35.239738
# Unit test for function checker
def test_checker():
    @checker
    def test_function(foo):
        assert foo == "bar"

    test_function("foo")

# Generated at 2022-06-21 20:41:37.909486
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check("master")
    assert True


# Generated at 2022-06-21 20:41:44.014280
# Unit test for function frigg
def test_frigg():
    """Test if the frigg checker is working"""
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"

    check()

    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-21 20:41:48.343681
# Unit test for function checker
def test_checker():
    @checker
    def func():
        assert 1 == 2

    try:
        func()
    except CiVerificationError as e:
        assert "CI" in e.message, e.message
    else:
        assert False, "An exception should have been raised."

# Generated at 2022-06-21 20:41:56.956620
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert os.environ["CIRCLECI"] == "true"
    assert os.environ["CIRCLE_BRANCH"] == "master"
    assert os.environ["CI_PULL_REQUEST"] == ""
    try:
        circle("master")
    except CiVerificationError:
        assert False

    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "45"
    assert os.environ["CIRCLECI"] == "true"

# Generated at 2022-06-21 20:42:02.837973
# Unit test for function circle
def test_circle():
    assert os.environ.get("CIRCLECI") == "true"
    assert os.environ.get("CIRCLE_BRANCH") == "master"
    circle("master")



# Generated at 2022-06-21 20:42:09.761999
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    assert frigg("test") is True
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-21 20:42:14.526846
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    assert frigg("develop") == True
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert frigg("develop") == False
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    assert frigg("develop") == True
