

# Generated at 2022-06-21 20:33:04.964762
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    os.environ["CIRCLE_BRANCH"] = "master"
    check("master")
    os.environ["GIT_BRANCH"] = "test"
    os.environ["CI_PULL_REQUEST"] = ""
    os.environ["CIRCLE_BRANCH"] = "test"
    check("test")
    os.environ["GIT_BRANCH"] = "test"
    os.environ["CI_PULL_REQUEST"] = "1"
    os.environ["CIRCLE_BRANCH"] = "test"
    check("test")

# Generated at 2022-06-21 20:33:09.449330
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = branch
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] != "failed"
    assert semaphore(branch)
    branch = "master"
    assert semaphore(branch)



# Generated at 2022-06-21 20:33:16.113752
# Unit test for function check
def test_check():
    """CI Checks: Check should pass for all valid CI environments."""

# Generated at 2022-06-21 20:33:27.289693
# Unit test for function check
def test_check():
    # Checking if function raises an error if environment is not found
    os.environ.pop("TRAVIS", None)
    os.environ.pop("SEMAPHORE", None)
    os.environ.pop("FRIGG", None)
    os.environ.pop("CIRCLECI", None)
    os.environ.pop("GITLAB_CI", None)
    os.environ.pop("JENKINS_URL", None)
    os.environ.pop("BITBUCKET_BUILD_NUMBER", None)
    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False, "CiVerificationError not raised"

    # Checking travis with default value
    os.environ["TRAVIS"] = "true"
    os.environ

# Generated at 2022-06-21 20:33:32.253094
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "0"
    bitbucket("master")


# Generated at 2022-06-21 20:33:33.792671
# Unit test for function checker
def test_checker():
    def foo(a, b):
        assert False

    assert not checker(foo)(1, 2)



# Generated at 2022-06-21 20:33:37.268326
# Unit test for function check
def test_check():
    assert check('master') == None

# Generated at 2022-06-21 20:33:46.453495
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "foo"
    os.environ["PULL_REQUEST_NUMBER"] = "42"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("foo")
    except CiVerificationError:
        pass
    else:
        raise Exception("should raise a verification error here")
    os.environ["BRANCH_NAME"] = "foo"
    os.environ["PULL_REQUEST_NUMBER"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("foo")
    except CiVerificationError:
        raise Exception("should not raise a verification error here")

# Generated at 2022-06-21 20:33:48.461185
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")



# Generated at 2022-06-21 20:33:54.521207
# Unit test for function check
def test_check():
    """
    Test the check function
    """
    import os
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    assert 1  # No exception raised

# Generated at 2022-06-21 20:34:01.732703
# Unit test for function circle
def test_circle():
  assert circle("master")


# Generated at 2022-06-21 20:34:11.908106
# Unit test for function frigg
def test_frigg():
    # Confirm correct True values - should not raise exceptions
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_BUILD_NUMBER'] = '1'
    os.environ['FRIGG_BUILD_REPO'] = 'https://github.com/frigg/frigg-worker.git'
    os.environ['FRIGG_BUILD_STATUS'] = 'passed'
    os.environ['FRIGG_BUILD_ID'] = '1'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    os.environ['FRIGG_RELEASE'] = '0'

# Generated at 2022-06-21 20:34:21.480444
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    bitbucket('master')
    os.environ['BITBUCKET_BRANCH'] = 'develop'
    bitbucket('develop')
    os.environ['BITBUCKET_BRANCH'] = 'develop'
    bitbucket('master')
    os.environ['BITBUCKET_BRANCH'] = 'master'
    bitbucket('develop')
    del os.environ['BITBUCKET_BRANCH']
    assert bitbucket('master') is False
    os.environ['BITBUCKET_PR_ID'] = '1'
    assert bitbucket('master') is False
    del os.environ['BITBUCKET_PR_ID']


# Generated at 2022-06-21 20:34:31.645862
# Unit test for function checker
def test_checker():
    """
    Asserts that checker correctly raises CiVerificationError
    when AssertionError is raised and that it passes normally when
    no exception is raised.
    """
    # Test passing function
    @checker
    def pass_func():
        pass

    # Test failing function
    @checker
    def fail_func():
        assert False

    # Test passing function
    pass_func()

    # Test failing function
    try:
        fail_func()
        assert False, "A CiVerificationError should have been raised."
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:34:32.609865
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master")

# Generated at 2022-06-21 20:34:44.063794
# Unit test for function jenkins
def test_jenkins():
    branch = "master"
    os.environ["BRANCH_NAME"] = branch
    os.environ["GIT_BRANCH"] = branch
    os.environ["JENKINS_URL"] = "https://google.com"
    os.environ["CHANGE_ID"] = None
    branch = "master"
    jenkins(branch)
    os.environ["BRANCH_NAME"] = branch
    os.environ["GIT_BRANCH"] = branch
    os.environ["JENKINS_URL"] = "https://google.com"
    os.environ["CHANGE_ID"] = "1234"
    branch = "master"
    try:
        jenkins(branch)
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-21 20:34:48.278550
# Unit test for function checker
def test_checker():
    """
    Decorator to convert errors to ci verification error
    """
    @checker
    def foo():
        raise AssertionError()
    try:
        foo()
        assert False
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-21 20:34:49.697789
# Unit test for function check
def test_check():
    assert check("master") is None
    assert check("develop") is None

# Generated at 2022-06-21 20:34:57.184244
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "true"

    try:
        check("master")
        assert False
    except CiVerificationError:
        pass

    os.environ["FRIGG_PULL_REQUEST"] = ""
    check("master")

    # Teardown
    os.environ.pop("FRIGG")
    os.environ.pop("FRIGG_BUILD_BRANCH")
    os.environ.pop("FRIGG_PULL_REQUEST")

# Generated at 2022-06-21 20:34:59.701622
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert gitlab("master")



# Generated at 2022-06-21 20:35:16.755374
# Unit test for function bitbucket
def test_bitbucket():
    import pytest

    from semantic_release.errors import CiVerificationError

    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None

    assert bitbucket("master")

    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = None
    with pytest.raises(CiVerificationError):
        assert bitbucket("master")

    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "100"
    with pytest.raises(CiVerificationError):
        assert bitbucket("master")


# Generated at 2022-06-21 20:35:22.112791
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_IID'] = ''
    os.environ['GITLAB_CI'] = 'true'
    check()
    os.environ['CI_MERGE_REQUEST_IID'] = '123'
    check()
    os.environ['CI_COMMIT_REF_NAME'] = 'release'
    check('release')

# Generated at 2022-06-21 20:35:34.645388
# Unit test for function check
def test_check():
    """
    Unit test for function check
    """
    os.environ["TRAVIS"] = "true"
    os.environ["SEMAPHORE"] = "true"
    os.environ["FRIGG"] = "true"
    os.environ["CIRCLECI"] = "true"
    os.environ["GITLAB_CI"] = "true"
    os.environ["BITBUCKET_BUILD_NUMBER"] = "true"
    os.environ["JENKINS_URL"] = "http://jenkins.com"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["BRANCH_NAME"] = "master"
    os.environ

# Generated at 2022-06-21 20:35:46.175974
# Unit test for function travis
def test_travis():
    # Test that enviroment repo is set to master
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    # Test that the check will pass
    assert(check("master"))

    # Test that enviroment repo is set to a nother branch
    os.environ["TRAVIS_BRANCH"] = "branch"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    # Test that the check will raised CiVerificationError
    try:
        check("master")
        assert False
    except CiVerificationError:
        assert True

    # Test that enviroment repo is a pull-request

# Generated at 2022-06-21 20:35:48.768324
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = ''
    bitbucket('master')

# Generated at 2022-06-21 20:35:55.810536
# Unit test for function semaphore
def test_semaphore():
    """
    Verifies that the checks for semaphore work correctly
    """
    os.environ["BRANCH_NAME"] = 'branchA'
    os.environ["SEMAPHORE_THREAD_RESULT"] = 'passed'
    os.environ["PULL_REQUEST_NUMBER"] = None
    semaphore('branchA')
    os.environ["PULL_REQUEST_NUMBER"] = ''
    semaphore('branchA')
    os.environ["PULL_REQUEST_NUMBER"] = '0'
    with pytest.raises(CiVerificationError):
        semaphore('branchA')
    os.environ["BRANCH_NAME"] = 'branchB'
    with pytest.raises(CiVerificationError):
        semaph

# Generated at 2022-06-21 20:36:05.385121
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test `bitbucket` function
    """
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        bitbucket("master")
        raise AssertionError("Did not raise assertion")
    except CiVerificationError:
        pass
    os.environ["BITBUCKET_PR_ID"] = ""
    try:
        bitbucket("master")
    except CiVerificationError:
        raise AssertionError("Raised assertion")



# Generated at 2022-06-21 20:36:18.852574
# Unit test for function travis
def test_travis():
    # os.environ["TRAVIS_BRANCH"] = "master"
    # os.environ["TRAVIS_PULL_REQUEST"] = "false"
    # travis("master")

    os.environ["TRAVIS_BRANCH"] = "dev"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")

    os.environ["TRAVIS_BRANCH"] = "dev"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("dev")

    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    travis("dev")



# Generated at 2022-06-21 20:36:26.002428
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'
    os.environ['PULL_REQUEST_NUMBER'] = '123'
    try:
        semaphore('master')
    except Exception:
        pass

    os.environ['BRANCH_NAME'] = 'master'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'
    os.environ['PULL_REQUEST_NUMBER'] = None
    try:
        semaphore('master')
    except Exception:
        pass

    os.environ['BRANCH_NAME'] = 'master'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'succeded'
    os

# Generated at 2022-06-21 20:36:29.219044
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_BRANCH"] = "master"
    check()



# Generated at 2022-06-21 20:36:44.409349
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.example.com"
    jenkins("master")
    os.environ["CHANGE_ID"] = "1"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["CHANGE_ID"] = "0"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-21 20:36:50.877873
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()
    os.environ["CIRCLE_BRANCH"] = "notmaster"
    check("notmaster")



# Generated at 2022-06-21 20:36:58.780159
# Unit test for function jenkins
def test_jenkins():
    assert os.environ.get("JENKINS_URL") is None
    assert os.environ.get("BRANCH_NAME") == None
    assert os.environ.get("GIT_BRANCH") == None
    assert os.environ.get("CHANGE_ID") == None
    os.environ["JENKINS_URL"] = "http://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "origin/master"
    os.environ["CHANGE_ID"] = "1"
    jenkins("master")

# Generated at 2022-06-21 20:37:01.911270
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL']='https://github.com/hendrikweimers/semantic-release-jenkins'
    os.environ['BRANCH_NAME']='master'
    os.environ['CHANGE_ID']='false'
    jenkins('master')

# Generated at 2022-06-21 20:37:05.340383
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    

# Generated at 2022-06-21 20:37:09.750315
# Unit test for function checker
def test_checker():
    # pylint: disable=invalid-name
    def good():
        return True

    def bad():
        return False

    assert checker(good)()
    try:
        checker(bad)()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:37:19.114651
# Unit test for function circle
def test_circle():
    env = {'CIRCLECI': 'true', 'CIRCLE_BRANCH': 'master', 'CI_PULL_REQUEST': 'false'}  # type: Dict
    with mock.patch.dict('os.environ', env):
        check()
    # case by case testing
    env = {'CIRCLECI': 'true', 'CIRCLE_BRANCH': 'develop', 'CI_PULL_REQUEST': 'false'}  # type: Dict
    with mock.patch.dict("os.environ", env):
        with pytest.raises(CiVerificationError):
            check()
    env = {'CIRCLECI': 'true', 'CIRCLE_BRANCH': 'master', 'CI_PULL_REQUEST': 'true'}  # type: Dict

# Generated at 2022-06-21 20:37:20.872528
# Unit test for function check
def test_check():
    os.environ["BRANCH_NAME"] = "master"
    check()

# Generated at 2022-06-21 20:37:32.814234
# Unit test for function jenkins
def test_jenkins():
    """
    Unit test for function jenkins
    """
    os.environ["FRIGG"] = "true"
    os.environ["SEMAPHORE"] = "true"
    os.environ["TRAVIS"] = "true"
    os.environ["JENKINS_URL"] = "http://jenkins.host.local"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = None
    os.environ["CI_PULL_REQUEST"] = "False"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "False"

# Generated at 2022-06-21 20:37:36.623525
# Unit test for function checker
def test_checker():
    def func():
        raise AssertionError("Test")

    wrapped = checker(func)
    try:
        wrapped()
    except CiVerificationError:
        pass
    else:
        assert False



# Generated at 2022-06-21 20:37:45.001123
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = ""
    os.environ["BRANCH_NAME"] = "master"

    check()

    del os.environ["JENKINS_URL"]
    del os.environ["BRANCH_NAME"]

# Generated at 2022-06-21 20:37:48.546798
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "master"
    os.environ["CHANGE_ID"] = None
    check()

# Generated at 2022-06-21 20:37:50.730969
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "true"
    os.environ["BITBUCKET_BRANCH"] = "branch"
    check("branch")


# Generated at 2022-06-21 20:37:55.512804
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()

    os.environ["CI_COMMIT_REF_NAME"] = "v1.0.0-dev.1"
    check()

    with pytest.raises(CiVerificationError):
        os.environ["CI_COMMIT_REF_NAME"] = "v1.0.0.1"
        check()

    with pytest.raises(CiVerificationError):
        os.environ["CI_COMMIT_REF_NAME"] = "v1.0.0"
        check()

    with pytest.raises(CiVerificationError):
        os.environ["CI_COMMIT_REF_NAME"] = "v1.0.0-dev.0"
        check()

# Generated at 2022-06-21 20:37:59.328475
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = "master"
    assert os.environ.get("BRANCH_NAME") == semaphore("master")

# Generated at 2022-06-21 20:38:03.352947
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"

    try:
        check(branch="master")
        assert True
    except CiVerificationError:
        assert False



# Generated at 2022-06-21 20:38:09.396890
# Unit test for function bitbucket
def test_bitbucket():
    # Check when Bitbucket environment variables are not set
    assert bitbucket(branch="master") == True

    # Check when Bitbucket environment variables are set,
    # but are for a Pull Request
    os.environ['BITBUCKET_PR_ID'] = "1"
    os.environ['BITBUCKET_BRANCH'] = "master"
    with pytest.raises(CiVerificationError):
        bitbucket(branch="master")

    # Check when Bitbucket environment variables are set,
    # but are for a Pull Request
    os.environ['BITBUCKET_PR_ID'] = None
    os.environ['BITBUCKET_BRANCH'] = "develop"

# Generated at 2022-06-21 20:38:15.341503
# Unit test for function checker
def test_checker():
    """
    Test the use of the checker decorator.
    """

    @checker
    def check_branch(branch):
        assert False

    try:
        check_branch("master")
        assert False
    except CiVerificationError:
        pass

    @checker
    def check_branch_2(branch):
        assert branch == "master"

    assert check_branch_2("master") is True

# Generated at 2022-06-21 20:38:18.409228
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert check() is True



# Generated at 2022-06-21 20:38:22.773269
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS"] = "true"
    check()



# Generated at 2022-06-21 20:38:34.646669
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "test"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("test")
    assert travis("not test") is False
    os.environ["TRAVIS_PULL_REQUEST"] = "not false"
    assert travis("test") is False



# Generated at 2022-06-21 20:38:36.461359
# Unit test for function check
def test_check():
    try:
        check()
    except Exception:
        pass
    else:
        assert False

# Generated at 2022-06-21 20:38:40.557066
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    frigg('master')
    del os.environ['FRIGG']
    del os.environ['FRIGG_BUILD_BRANCH']

# Generated at 2022-06-21 20:38:41.156009
# Unit test for function check
def test_check():
    assert check() is None

# Generated at 2022-06-21 20:38:47.953688
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "456"
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        pass

    del os.environ["BITBUCKET_PR_ID"]
    try:
        bitbucket("master")
        assert True
    except CiVerificationError:
        assert False

    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        pass


# Generated at 2022-06-21 20:38:52.846753
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")


# Generated at 2022-06-21 20:38:54.062598
# Unit test for function jenkins
def test_jenkins():
    assert True == jenkins("master")

# Generated at 2022-06-21 20:38:58.376947
# Unit test for function check
def test_check():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()

# Generated at 2022-06-21 20:39:10.591874
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    circle("master")
    # Raise exception for non-master branch
    os.environ["CIRCLE_BRANCH"] = "dev"
    try:
        circle("master")
    except AssertionError:
        pass
    else:
        raise AssertionError("AssertionError not raised")
    # Raise exception for pull request
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "true"
    try:
        circle("master")
    except AssertionError:
        pass
    else:
        raise AssertionError("AssertionError not raised")

# Unit

# Generated at 2022-06-21 20:39:15.819943
# Unit test for function bitbucket
def test_bitbucket():
    assert not os.environ.get("BITBUCKET_BUILD_NUMBER")
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "develop"
    bitbucket("develop")
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")
    os.environ["BITBUCKET_PR_ID"] = "1"
    assert bitbucket("master") == None



# Generated at 2022-06-21 20:39:24.237200
# Unit test for function gitlab
def test_gitlab():
    assert os.environ.get("GITLAB_CI") == "true"

__all__ = ["check"]

# Generated at 2022-06-21 20:39:25.508778
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket("master") == True

# Generated at 2022-06-21 20:39:29.859866
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-21 20:39:35.941337
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = 'false'
    check()
    del os.environ['CIRCLECI']
    del os.environ['CIRCLE_BRANCH']
    del os.environ['CI_PULL_REQUEST']

# Generated at 2022-06-21 20:39:41.771347
# Unit test for function checker
def test_checker():
    with open("tmp_file.txt", "w") as file:
        file.write("Hello")
    with open("tmp_file.txt", "r") as file:
        assert file.read() == "Hello"
    try:
        os.remove("tmp_file.txt")
    except FileNotFoundError:
        pass

    @checker
    def do_stuff():
        assert False

    try:
        do_stuff()
    except CiVerificationError:
        assert True


# Generated at 2022-06-21 20:39:45.474907
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert travis('master')


# Generated at 2022-06-21 20:39:52.715393
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG_BUILD_BRANCH"] = "release-test"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    with pytest.raises(CiVerificationError):
        frigg("release-test")
    del os.environ["FRIGG_PULL_REQUEST"]
    frigg("release-test")



# Generated at 2022-06-21 20:39:54.141391
# Unit test for function semaphore
def test_semaphore():
        assert checker(semaphore)('test-branch')

# Generated at 2022-06-21 20:39:59.536308
# Unit test for function semaphore
def test_semaphore():
    """
    Tests if the semaphore function works as it should
    """
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    return_value = semaphore("master")
    assert return_value


# Generated at 2022-06-21 20:40:07.533483
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")

    try:
        os.environ["TRAVIS_PULL_REQUEST"] = "true"
        assert travis("master") == False
    except CiVerificationError:
        return True
    except Exception as e:
        print(e)
        return False


# Generated at 2022-06-21 20:40:25.491966
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_PIPELINE_ID'] = '1'
    os.environ['CI_EXTERNAL_PULL_REQUEST_IID'] = '2'
    os.environ['CI_EXTERNAL_PULL_REQUEST_ID'] = '3'
    os.environ['CI_COMMIT_REF_NAME'] = 'branch'

    try:
        
        gitlab(branch="branch1")
    except CiVerificationError:
        pass
    os.environ['CI_COMMIT_REF_NAME'] = 'branch1'
    try:    
        gitlab(branch="branch")
    except CiVerificationError:
        pass
    os.environ['CI_EXTERNAL_PULL_REQUEST_ID'] = '0'
    assert gitlab

# Generated at 2022-06-21 20:40:29.586110
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "False"
    check()

# Generated at 2022-06-21 20:40:33.450587
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS_BRANCH"] = "master"
    check(branch="master")

# Generated at 2022-06-21 20:40:44.890631
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = "finished"
    assert semaphore("master")

    # Test Assertion Errors
    os.environ["BRANCH_NAME"] = "test"
    with pytest.raises(CiVerificationError):
        assert semaphore("master")

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    with pytest.raises(CiVerificationError):
        assert semaphore("master")

    os.environ["BRANCH_NAME"] = "master"

# Generated at 2022-06-21 20:40:58.115827
# Unit test for function jenkins
def test_jenkins():
    """
    A unit test for the jenkins function in this module

    The jenkins function tests that the variable JENKINS_URL is set and
    that the variable BRANCH_NAME or GIT_BRANCH is the same as branch.

    An error is raise in case one of the variable are not present or different
    than branch.

    """
    branch = "branchname"
    os.environ["JENKINS_URL"] = "http://127.0.0.1:8080"
    os.environ["BRANCH_NAME"] = branch
    jenkins(branch)
    os.environ.pop("BRANCH_NAME", None)
    os.environ["GIT_BRANCH"] = branch
    jenkins(branch)

# Generated at 2022-06-21 20:41:03.134554
# Unit test for function frigg
def test_frigg():
    """
    Checks the frigg function by mocking the env variables of the frigg build environment.

    :assert: Checks if the frigg function raises any error or not.
    """
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    del os.environ["FRIGG_PULL_REQUEST"]
    assert frigg("master")


# Generated at 2022-06-21 20:41:10.997241
# Unit test for function frigg
def test_frigg():
    """
    test_frigg - test frigg environment check

    """
    os.environ.update({"FRIGG": "true", "FRIGG_BUILD_BRANCH": "master", "FRIGG_PULL_REQUEST": False})

    frigg("master")

    os.environ.update({"FRIGG": "true", "FRIGG_BUILD_BRANCH": "master", "FRIGG_PULL_REQUEST": True})

    try:
        frigg("master")
    except CiVerificationError as verification_error:
        assert {'FRIGG': 'true', 'FRIGG_BUILD_BRANCH': 'master', 'FRIGG_PULL_REQUEST': True} in verification_error.message

# Generated at 2022-06-21 20:41:13.778115
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CI_PULL_REQUEST'] = 'false'
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CIRCLE_NODE_INDEX'] = '1'
    os.environ['CIRCLE_NODE_TOTAL'] = '1'
    assert circle('master')

# Generated at 2022-06-21 20:41:22.587375
# Unit test for function jenkins
def test_jenkins():
    path = os.getcwd()
    os.environ["JENKINS_URL"] = "True"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")
    os.chdir(path)
    os.environ["JENKINS_URL"] = "True"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "development"
    jenkins("master")
    
    

# Generated at 2022-06-21 20:41:27.065340
# Unit test for function circle
def test_circle():
    os.environ.update(
        {
            "CIRCLECI": "true",
            "CIRCLE_BRANCH": "master",
            "CIRCLE_BUILD_NUM": "1",
            "CI_PULL_REQUEST": "",
        }
    )
    check()
    del os.environ["CI_PULL_REQUEST"]
    check()



# Generated at 2022-06-21 20:41:38.590158
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    check()

    os.environ["FRIGG_PULL_REQUEST"] = "1"
    try:
        check()
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-21 20:41:43.512689
# Unit test for function jenkins
def test_jenkins():
    """
    The function jenkins should fail if the branch doesn't match.
    """

    os.environ['JENKINS_URL'] = 'True'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['CHANGE_ID'] = 'False'
    os.environ['GIT_BRANCH'] = 'develop'
    jenkins(branch='master')

# Generated at 2022-06-21 20:41:53.351308
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "5"

    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        assert True

    os.environ["BITBUCKET_PR_ID"] = None

    try:
        bitbucket("master")
        assert True
    except CiVerificationError:
        assert False

    os.environ["BITBUCKET_BRANCH"] = "develop"

    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-21 20:42:00.244360
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_PULL_REQUEST"] = "1"
    os.environ["FRIGG_BUILD_BRANCH"] = 'master'
    check()
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    os.environ["FRIGG_BUILD_BRANCH"] = 'master'
    check()
    os.environ["FRIGG_PULL_REQUEST"] = "False"
    os.environ["FRIGG_BUILD_BRANCH"] = 'master'
    check()
    os.environ["FRIGG_BUILD_BRANCH"] = 'feature'
    check()


# Generated at 2022-06-21 20:42:11.406171
# Unit test for function bitbucket
def test_bitbucket():
    """
    Ensures that the bitbucket function raises an error
    on incorrect values.
    """
    os.environ["BITBUCKET_BRANCH"] = "branch"
    os.environ["BITBUCKET_PR_ID"] = "pull_request"
    try:
        bitbucket("master")
        raise Exception("bitbucket did not raise an exception when it should have")
    except CiVerificationError:
        pass
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    try:
        bitbucket("master")
    except CiVerificationError:
        raise Exception("bitbucket raised an unexpected exception when it should not have")

# Generated at 2022-06-21 20:42:13.559724
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()



# Generated at 2022-06-21 20:42:18.076900
# Unit test for function bitbucket
def test_bitbucket():
    """
    Tests the bitbucket function.
    """
    environ_copy = os.environ.copy()
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")
    os.environ["BITBUCKET_PR_ID"] = "something"
    try:
        bitbucket("master")
    except CiVerificationError:
        os.environ = environ_copy
        return
    os.environ = environ_copy
    raise Exception("Test case failed")


# Generated at 2022-06-21 20:42:22.454366
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    assert True == check()



# Generated at 2022-06-21 20:42:24.164341
# Unit test for function frigg
def test_frigg(): 
    assert frigg("master") == True
    assert frigg("develop") == True


# Generated at 2022-06-21 20:42:32.018126
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    try:
        check('master')
    except CiVerificationError:
        assert False
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    try:
        check('master')
        assert False
    except CiVerificationError:
        pass
    del os.environ['TRAVIS_PULL_REQUEST']
    del os.environ['TRAVIS']
    del os.environ['TRAVIS_BRANCH']


# Unit tests for function travis

# Generated at 2022-06-21 20:42:50.035481
# Unit test for function semaphore
def test_semaphore():
    # Test failure by setting wrong branch name
    os.environ["BRANCH_NAME"] = "feature"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]

    # Test failure by setting failing pipeline
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "123"