

# Generated at 2022-06-21 20:32:56.779050
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master") == True

# Generated at 2022-06-21 20:32:58.974529
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()



# Generated at 2022-06-21 20:33:01.403123
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    jenkins(branch="master")

# Generated at 2022-06-21 20:33:05.371188
# Unit test for function gitlab
def test_gitlab():
    """
    Tests the checking of the current CI environment.
    """

    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()

# Generated at 2022-06-21 20:33:11.674669
# Unit test for function gitlab
def test_gitlab():
    """
    Test to make sure that the gitlab environment variables
    are correctly setup.
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = "1"
    r = gitlab("master")
    assert not r
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = "None"
    r = gitlab("master")
    assert r

# Generated at 2022-06-21 20:33:22.411414
# Unit test for function checker
def test_checker():
    test_val = 5
    def test_func():
        raise AssertionError

    def test_func2():
        return True

    checker_func = checker(test_func)
    checker_func2 = checker(test_func2)

    try:
        checker_func(test_val)
    except CiVerificationError as err:
        assert isinstance(err, CiVerificationError)

    try:
        checker_func2(test_val)
    except CiVerificationError as err:
        assert False



# Generated at 2022-06-21 20:33:26.810196
# Unit test for function checker
def test_checker():
    import pytest
    from semantic_release.errors import CiVerificationError

    @checker
    def check_test():
        raise AssertionError("Failed")

    with pytest.raises(CiVerificationError):
        check_test()


# Generated at 2022-06-21 20:33:33.604466
# Unit test for function semaphore
def test_semaphore():
    """
    Tests the semaphore function
    """
    os.environ["BRANCH_NAME"] = "not-master"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    semaphore("master")

# Generated at 2022-06-21 20:33:39.113153
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    branch = 'master'
    travis(branch)

# Generated at 2022-06-21 20:33:45.801257
# Unit test for function check
def test_check():
    # Assert that the following combination of checks should work
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert check()

    # Assert that the following combination of checks should fail
    os.environ["TRAVIS_BRANCH"] = "develop"
    try:
        check()
    except CiVerificationError as e:
        assert e is not None

# Generated at 2022-06-21 20:34:01.440785
# Unit test for function checker
def test_checker():
    """
    The checker should ensure that AssertionErrors raised by the function
    it decorates are converted to CiVerificationErrors.
    """
    def func(arg1: str, arg2: str):
        assert arg1 == arg2

    @checker
    def func_wrapper(arg1: str, arg2: str):
        func(arg1, arg2)

    # Should not raise exception
    func_wrapper("foo", "foo")

    raised = False
    try:
        func_wrapper("foo", "bar")
    except CiVerificationError:
        raised = True
    assert raised is True

# Generated at 2022-06-21 20:34:10.762182
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS"] = "true"
    assert travis(os.environ.get("TRAVIS_BRANCH"))
    #os.environ["TRAVIS_BRANCH"] = "release/v0.0.0"
    #assert travis(os.environ.get("TRAVIS_BRANCH"))
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-21 20:34:17.632807
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('master')
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    try:
        travis('master')
    except CiVerificationError as err:
        assert str(err) == 'The verification check for the environment did not pass.'


# Generated at 2022-06-21 20:34:23.853172
# Unit test for function gitlab
def test_gitlab():
    os.environ['GITLAB_CI'] = 'true'
    os.environ['CI_COMMIT_REF_NAME'] = 'test_branch'
    res = gitlab('test_branch')
    assert res == True
    os.environ['GITLAB_CI'] = 'false'
    os.environ['CI_COMMIT_REF_NAME'] = ''


# Generated at 2022-06-21 20:34:30.296405
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    assert circle(os.environ["CIRCLE_BRANCH"])
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-21 20:34:38.346009
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test function bitbucket.
    """
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")

    os.environ["BITBUCKET_BRANCH"] = "master1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass

    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        bitbucket("master1")
    except CiVerificationError:
        pass



# Generated at 2022-06-21 20:34:41.805258
# Unit test for function frigg
def test_frigg():
    os.environ.update({"FRIGG": "true",
                       "FRIGG_BUILD_BRANCH": "master",
                       "FRIGG_PULL_REQUEST": "false"})
    frigg("master")



# Generated at 2022-06-21 20:34:46.411227
# Unit test for function circle
def test_circle():
    checker(circle)(branch="test")
    os.environ["CIRCLE_BUILD_NUM"] = "test"
    checker(circle)(branch="test")
    del os.environ["CIRCLE_BUILD_NUM"]
    checker(circle)(branch="test")



# Generated at 2022-06-21 20:34:51.902713
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = 'test'
    assert circle(branch='test')
    os.environ["CI_PULL_REQUEST"] = 'true'
    assert circle(branch='test') is False
    # Test that bad branch is detected
    os.environ["CIRCLE_BRANCH"] = 'test2'
    assert circle(branch='test') is False



# Generated at 2022-06-21 20:34:54.813856
# Unit test for function frigg
def test_frigg():
    """
    Test that the frigg function will raise a CiVerificationError if the environment
    is not set to frigg.
    """
    try:
        frigg("master")
    except CiVerificationError:
        assert True

# Generated at 2022-06-21 20:35:16.690872
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = 'master'
    os.environ["TRAVIS_PULL_REQUEST"] ="false"
    try:
        travis(branch = "master")
    except CiVerificationError:
        assert 0
    os.environ["TRAVIS_BRANCH"] = 'test_branch'
    try:
        travis(branch = "master")
        assert 0
    except CiVerificationError:
        pass
    os.environ["TRAVIS_PULL_REQUEST"] = "hello"
    try:
        travis(branch = "master")
        assert 0
    except CiVerificationError:
        pass


# Generated at 2022-06-21 20:35:21.463457
# Unit test for function jenkins
def test_jenkins():
    """This is a unit test for jenkins.
    I've made some assumptions here as well.
    """

    os.environ["JENKINS_URL"] = "https://jenkins_server:8080"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = None

    check("master")



# Generated at 2022-06-21 20:35:26.871530
# Unit test for function check
def test_check():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS"] = "true"
    check()
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]
    del os.environ["TRAVIS"]
    check()

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["SEMAPHORE"] = "true"
    check()

# Generated at 2022-06-21 20:35:34.017739
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"

    check()
    del os.environ["GITLAB_CI"]
    del os.environ["CI_COMMIT_REF_NAME"]

    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    try:
        check()
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:35:41.414835
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "TEST"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "dev"
    bitbucket("master")
    del os.environ["BITBUCKET_BUILD_NUMBER"]
    bitbucket("master")


# Generated at 2022-06-21 20:35:46.085559
# Unit test for function checker
def test_checker():
    @checker
    def ok_function():
        pass

    @checker
    def bad_function():
        assert False

    ok_function()
    try:
        bad_function()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:35:53.179138
# Unit test for function circle
def test_circle():

    # Check if the circle environment variables are set correctly
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_BRANCH"] = "master"
    try:
        circle("master")
    except CiVerificationError:
        raise AssertionError("The circle environment variables are not set correctly")
    else:
        os.environ.pop("CIRCLECI")
        os.environ.pop("CI_PULL_REQUEST")
        os.environ.pop("CIRCLE_BRANCH")


# Generated at 2022-06-21 20:35:58.038668
# Unit test for function travis
def test_travis():
    # Test travis with correct environment
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")

    # Test travis with wrong branch
    os.environ["TRAVIS_BRANCH"] = "feature"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
    except CiVerificationError:
        assert True
    else:
        assert False

    # Test travis with wrong pull request
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"

# Generated at 2022-06-21 20:36:01.515949
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "develop"
    os.environ["CI_PULL_REQUEST"] = False
    check()

# Generated at 2022-06-21 20:36:07.950142
# Unit test for function gitlab
def test_gitlab():
    os.environ.clear()
    # Check os.environment is empty
    assert not os.environ

    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = branch = "master"
    gitlab(branch)

    # Clear os.environment
    os.environ.clear()
    # Check os.environment is empty
    assert not os.environ

test_gitlab()


# Generated at 2022-06-21 20:36:43.955598
# Unit test for function semaphore
def test_semaphore():
    env = {}
    env['SEMAPHORE'] = 'true'
    env['BRANCH_NAME'] = 'master'
    env["PULL_REQUEST_NUMBER"] = None
    env["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ = env
    assert semaphore('master')
    env = {}
    env['SEMAPHORE'] = 'true'
    env['BRANCH_NAME'] = 'develop'
    env["PULL_REQUEST_NUMBER"] = '1'
    env["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ = env
    assert not semaphore('master')


# Generated at 2022-06-21 20:36:46.401479
# Unit test for function jenkins
def test_jenkins():
    assert jenkins(branch = "master") == True
    assert jenkins(branch = "branch") == True

# Generated at 2022-06-21 20:36:50.696097
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    branch_number = "new-feature"
    os.environ["TRAVIS_BRANCH"] = branch_number

    check(branch_number)



# Generated at 2022-06-21 20:37:00.614757
# Unit test for function semaphore
def test_semaphore():
    proper_result = ['PR-101', 'PR-102', 'PR-103']
    correct_test_env = [
        ['PR-101', 'PR-102', 'PR-103'], ['PR-101', 'PR-102', 'PR-103'],
        ['PR-101', 'PR-102', 'PR-103']
    ]
    incorrect_test_env = [
        ['PR-101', 'PR-102', 'PR-103'], ['PR-101', 'PR-102', 'PR-10'],
        ['PR-101', 'PR-102', 'PR-10']
    ]
    os.environ["BRANCH_NAME"] = 'master'
    os.environ["PULL_REQUEST_NUMBER"] = 'None'

# Generated at 2022-06-21 20:37:03.217255
# Unit test for function checker
def test_checker():
    def test_func():
        assert True

    @checker
    def test_func_fail():
        assert False

    assert test_func()
    assert not test_func_fail()

# Generated at 2022-06-21 20:37:08.850841
# Unit test for function semaphore
def test_semaphore():
    """
    Performs unit testing for the semaphore function
    """
    assert os.environ.get("SEMAPHORE") == "true"
    assert os.environ.get("PULL_REQUEST_NUMBER") is None
    assert os.environ.get("SEMAPHORE_THREAD_RESULT") != "failed"
    assert semaphore("master") == True

# Generated at 2022-06-21 20:37:14.846401
# Unit test for function jenkins
def test_jenkins():
    # Set up
    os.environ["JENKINS_URL"] = "Fake_Jenkins_URL"
    os.environ["BRANCH_NAME"] = "master"

    # Call function
    jenkins("master")

    # Teardown
    del os.environ["JENKINS_URL"]
    del os.environ["BRANCH_NAME"]


# Generated at 2022-06-21 20:37:26.080591
# Unit test for function check
def test_check():
    # NOTE: Once we get better testing setup in place, we'll move these
    #       tests out of __init__.
    #
    #       Also, this test is only used to test the function, it is unit
    #       test, not an integration test.
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert check() is None

    del os.environ["TRAVIS"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

# Generated at 2022-06-21 20:37:31.201332
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check(branch="master")
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    assert check(branch="master") == False

# Generated at 2022-06-21 20:37:38.424493
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"]="master"
    r=gitlab("master")
    assert r
    os.environ["CI_COMMIT_REF_NAME"]="feature"
    r=gitlab("master")
    assert r is None
    os.environ["CI_COMMIT_REF_NAME"]="master"
    os.environ["CI_MERGE_REQUEST_ID"]="12"
    r=gitlab("master")
    assert r is None

# Generated at 2022-06-21 20:38:34.527220
# Unit test for function gitlab
def test_gitlab():
    # Test on the correct branch
    os.environ["CI_COMMIT_REF_NAME"] = "master"

    assert check() is None

    # Test on the wrong branch
    os.environ["CI_COMMIT_REF_NAME"] = "dev"

    try:
        check()
    except CiVerificationError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 20:38:35.205604
# Unit test for function check
def test_check():
    assert check(branch="TRAVIS") is None

# Generated at 2022-06-21 20:38:40.931775
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    check()
    assert 'true'
    os.environ['TRAVIS_BRANCH'] = 'dev'
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    check()
    assert 'false'

# Generated at 2022-06-21 20:38:43.031080
# Unit test for function jenkins
def test_jenkins():
    if os.environ.get("JENKINS_URL") is not None:
        jenkins(branch)

# Generated at 2022-06-21 20:38:46.617225
# Unit test for function semaphore
def test_semaphore():
    """
    Unit test for function semaphore
    """
    # Set correct environment variables and execute test
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"

    # Execute
    assert semaphore("master")



# Generated at 2022-06-21 20:38:52.052226
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "my_branch"
    os.environ["CI_PULL_REQUEST"] = "false"
    check(branch="my_branch")



# Generated at 2022-06-21 20:38:58.166886
# Unit test for function frigg
def test_frigg():
    for key, value in [
        ("BRANCH_NAME", "master"),
        ("FRIGG_BRANCH", "master"),
        ("FRIGG_BUILD_BRANCH", "master"),
        ("FRIGG_PULL_REQUEST", "false"),
    ]:
        os.environ[key] = value
    assert check()
    assert os.environ.get("FRIGG") == "true"

# Generated at 2022-06-21 20:38:58.994159
# Unit test for function travis
def test_travis():
    # TODO: write test
    pass

# Generated at 2022-06-21 20:39:05.822884
# Unit test for function jenkins
def test_jenkins():
    assert not jenkins("master")
    assert not bitbucket("feature_branch")
    assert not gitlab("feature_branch")
    assert not travis("feature_branch")
    assert not semaphore("feature_branch")
    assert not frigg("feature_branch")
    assert not circle("feature_branch")

# Generated at 2022-06-21 20:39:11.108517
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") is True
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master") is False

# Generated at 2022-06-21 20:40:58.115765
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert "" == "False"

    assert callable(test_func)
    try:
        test_func()
    except CiVerificationError:
        assert True
    else:
        assert False, "checker decorator did not wrap AssertionErrors as a CiVerificationError in test_func"

# Generated at 2022-06-21 20:40:59.343720
# Unit test for function check
def test_check():
    """
    Test to validate check function
    """
    check()

# Generated at 2022-06-21 20:41:08.417094
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore() == True
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        assert semaphore() == True
    except CiVerificationError as e:
        assert e.msg == "The verification check for the environment did not pass."
    del os.environ["BRANCH_NAME"]
    os.environ["BRANCH_NAME"] = "notmaster"

# Generated at 2022-06-21 20:41:09.530961
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")

# Generated at 2022-06-21 20:41:12.540008
# Unit test for function gitlab
def test_gitlab():
    assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
    assert not os.environ.get("CHANGE_ID")  # pull request id
    gitlab()
    assert os.environ.get("CHANGE_ID")  # pull request id
    gitlab()


# Generated at 2022-06-21 20:41:21.048801
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "branch"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    semaphore("branch")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("branch")
    except CiVerificationError:
        print("Semaphore test passed")

if __name__ == "__main__":
    test_semaphore()

# Generated at 2022-06-21 20:41:23.354856
# Unit test for function check
def test_check():
    """ Unit test for function check
    """
    os.environ.update({"GITLAB_CI": True, "CI_COMMIT_REF_NAME": "master"})
    check()

# Generated at 2022-06-21 20:41:25.839316
# Unit test for function checker
def test_checker():
    @checker
    def test():
        assert False

    try:
        test()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-21 20:41:32.641206
# Unit test for function gitlab
def test_gitlab():
    """
    Testing for the gitlab ci environment.
    """
    os.environ["CI_COMMIT_REF_NAME"] = "feature/joe"
    try:
        gitlab("master")
        assert False, "Environment check should have failed"
    except CiVerificationError:
        assert True



# Generated at 2022-06-21 20:41:36.615319
# Unit test for function jenkins
def test_jenkins():
    assert jenkins(branch="xyz") is True
    assert jenkins(branch="master") is True
    assert jenkins(branch="develop") is True
    assert jenkins(branch="blub") is True
    assert jenkins(branch="Test_Branch") is True