

# Generated at 2022-06-21 20:33:00.838909
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    assert not frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = ""
    assert not frigg("master")

# Generated at 2022-06-21 20:33:05.273936
# Unit test for function checker
def test_checker():
    @checker
    def failure_check():
        assert False

    def success_check():
        assert True

    assert failure_check() is False
    assert success_check() is True

# Generated at 2022-06-21 20:33:13.785644
# Unit test for function frigg
def test_frigg():
    # Testing that the function frigg works when the variables are correct
    os.environ["FRIGG_BUILD_BRANCH"] ="master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    assert frigg("master") == True

    # Testing that the function frigg works when the variables are correct
    os.environ["FRIGG_BUILD_BRANCH"] ="master"
    assert frigg("master") == True


    # Testing that the function frigg works when the variables are noy correct
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    os.environ["FRIGG_PULL_REQUEST"] = "true"

# Generated at 2022-06-21 20:33:21.983993
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    try:
        gitlab(branch="master")
    except CiVerificationError:
        raise AssertionError("Test failed")
    os.environ["CI_COMMIT_REF_NAME"] = "dev"
    try:
        gitlab(branch="master")
        raise AssertionError("Test failed")
    except CiVerificationError:
        return

# Generated at 2022-06-21 20:33:29.434194
# Unit test for function circle
def test_circle():
    for env in ('CIRCLECI', 'CIRCLE_BUILD_NUM', 'CI_PULL_REQUEST'):
        os.environ[env] = 'foo'

        try:
            circle()
            assert False
        except CiVerificationError as e:
            assert "The verification check for the environment did not pass." in str(e)

    del os.environ['CIRCLECI']
    del os.environ['CIRCLE_BUILD_NUM']
    del os.environ['CI_PULL_REQUEST']



# Generated at 2022-06-21 20:33:35.496514
# Unit test for function bitbucket
def test_bitbucket():
    """
    Performs necessary checks to ensure that the bitbucket build is one
    that should create releases.
    """
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket(branch="master")
    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        bitbucket(branch="master")
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-21 20:33:46.232288
# Unit test for function check
def test_check():
    """
    Unit test for function check
    """
    import sys
    import unittest

    class TestCheck(unittest.TestCase):
        """
        Unit test class to test check()
        """

        def test_good_branch(self):
            """
            test_good_branch
            """
            os.environ["TRAVIS"] = "true"
            os.environ["SEMAPHORE"] = "true"
            os.environ["FRIGG"] = "true"
            os.environ["CIRCLECI"] = "true"
            os.environ["GITLAB_CI"] = "true"
            os.environ["JENKINS_URL"] = "www.example.com"
            os.environ["BITBUCKET_BUILD_NUMBER"] = "12"

# Generated at 2022-06-21 20:33:48.578854
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-21 20:33:55.108297
# Unit test for function semaphore
def test_semaphore():
    import os
    # Create the environment variables
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'success'
    # Ensure the function is true
    assert(semaphore('master') == True)

# Generated at 2022-06-21 20:34:06.442081
# Unit test for function semaphore
def test_semaphore():
    os.environ['SEMAPHORE'] = 'true'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    semaphore('master')
    os.environ['SEMAPHORE'] = 'true'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = '1'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    from semantic_release.errors import CiVerificationError
    try:
        semaphore('master')
    except CiVerificationError:
        pass
    os.environ

# Generated at 2022-06-21 20:34:14.734965
# Unit test for function gitlab
def test_gitlab():
    branch = "master"
    os.environ['CI_COMMIT_REF_NAME'] = branch
    check(branch)


# Generated at 2022-06-21 20:34:22.352460
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    try:
        circle("develop")
    except CiVerificationError as err:
        assert err.args[0] == "The verification check for the environment did not pass."
        os.environ.pop("CIRCLECI")
        os.environ.pop("CIRCLE_BRANCH")
    else:
        raise Exception("Expected a CiVerificationError")


if __name__ == "__main__":
    test_circle()

# Generated at 2022-06-21 20:34:29.843276
# Unit test for function semaphore
def test_semaphore():
    # Use os.environ as a mock
    os.environ = {
        "BRANCH_NAME": "branch",
        "PULL_REQUEST_NUMBER": None,
        "SEMAPHORE_THREAD_RESULT": "success",
    }
    assert semaphore("branch")
    os.environ = {}
    assert semaphore("branch") is True



# Generated at 2022-06-21 20:34:31.234453
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "www.jenkins.com"
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["CHANGE_ID"] = None
    check(branch="develop")

# Generated at 2022-06-21 20:34:32.220579
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("master")



# Generated at 2022-06-21 20:34:33.243306
# Unit test for function frigg
def test_frigg():
    assert frigg("master") == True

# Generated at 2022-06-21 20:34:42.044027
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    frigg("master")
    assert True
    os.environ.pop("FRIGG_PULL_REQUEST")
    os.environ.pop("FRIGG_BUILD_BRANCH")
    os.environ.pop("FRIGG")
    try:
        frigg("feature/test")
    except Exception as e:
        assert e is not None


# Generated at 2022-06-21 20:34:49.657536
# Unit test for function frigg
def test_frigg():
    assert os.getenv("FRIGG") != "true"
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = None
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = None
    os.environ["FRIGG_PULL_REQUEST"] = "12"
    frigg("master")


# Generated at 2022-06-21 20:34:52.149575
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = ""
    os.environ["JENKINS_URL"] = "https://jenkins.semantic-release.testing"
    check()

# Generated at 2022-06-21 20:34:54.379943
# Unit test for function checker
def test_checker():
    from semantic_release.errors import CiVerificationError

    @checker
    def func():
        raise AssertionError

    try:
        func()
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-21 20:35:06.674961
# Unit test for function bitbucket
def test_bitbucket():
    test_env = {}
    test_env["BITBUCKET_BRANCH"] = "master"
    test_env["BITBUCKET_BUILD_NUMBER"] = 1
    test_env["BITBUCKET_PR_ID"] = "1"
    os.environ.update(test_env)
    assert not bitbucket("master")
    os.environ.pop("BITBUCKET_PR_ID")
    assert bitbucket("master")



# Generated at 2022-06-21 20:35:17.884908
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert bitbucket("master") == True
    assert bitbucket("develop") == False
    os.environ["BITBUCKET_BRANCH"] = "develop"
    assert bitbucket("develop") == True
    assert bitbucket("master") == False
    os.environ["BITBUCKET_PR_ID"] = ""
    assert bitbucket("master") == False
    del os.environ["BITBUCKET_PR_ID"]
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert bitbucket("master") == True
    assert bitbucket("develop") == False
    os.environ["BITBUCKET_BRANCH"] = "develop"

# Generated at 2022-06-21 20:35:21.502339
# Unit test for function checker
def test_checker():
    """
    Test checker raises the correct error.
    """

    @checker
    def test_func():
        raise AssertionError

    try:
        test_func()
    except CiVerificationError:
        return
    raise AssertionError("Function did not raise the correct error")

# Generated at 2022-06-21 20:35:26.889486
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    check("master")
    del os.environ["TRAVIS"]
    os.environ["SEMAPHORE"] = "true"
    check("master")
    del os.environ["SEMAPHORE"]
    os.environ["FRIGG"] = "true"
    check("master")
    del os.environ["FRIGG"]
    os.environ["CIRCLECI"] = "true"
    check("master")
    del os.environ["CIRCLECI"]
    os.environ["GITLAB_CI"] = "true"
    check("master")
    del os.environ["GITLAB_CI"]
    os.environ["JENKINS_URL"] = "http://ci.example.com"
    check

# Generated at 2022-06-21 20:35:31.131169
# Unit test for function checker
def test_checker():
    @checker
    def func():
        return False

    assert func() == True

    @checker
    def func():
        raise AssertionError()

    try:
        func()
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-21 20:35:34.259005
# Unit test for function checker
def test_checker():
    branch = "irrelevant"

    def fails():
        assert False

    def passes():
        assert True

    assert checker(fails)(branch) is False
    assert checker(passes)(branch) is True

# Generated at 2022-06-21 20:35:43.857260
# Unit test for function gitlab
def test_gitlab():
    def reset_environ():
        os.environ['GITLAB_CI'] = ''
        os.environ['CI_COMMIT_REF_NAME'] = ''
        os.environ['GITLAB_USER_ID'] = ''

    reset_environ()

    try:
        gitlab('foobar')
        assert False
    except CiVerificationError:
        assert True

    reset_environ()

    os.environ['GITLAB_CI'] = 'true'
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['GITLAB_USER_ID'] = '0'

    assert gitlab('master')

# Generated at 2022-06-21 20:35:50.431382
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "True"
    os.environ["GIT_BRANCH"] = "master"
    check(branch="master")
    try:
        check(branch="develop")
    except CiVerificationError:
        assert True
    else:
        assert False
    try:
        os.environ["BITBUCKET_PR_ID"] = "1000"
        check()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:35:53.855204
# Unit test for function checker
def test_checker():
    """
    Make sure the checker decorator works as intended.
    """
    @checker
    def checker_test():
        """
        Method used in the checker unit test
        """
        raise AssertionError

    try:
        checker_test()
    except CiVerificationError:
        return True

    assert False

# Generated at 2022-06-21 20:35:56.603113
# Unit test for function checker
def test_checker():
    """
    Tests that the checker function decorator works.
    """

    @checker
    def assert_raises(*args, **kwargs):
        raise AssertionError("This is an assertion error.")

    try:
        assert_raises()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("This should have raised a CiVerificationError.")



# Generated at 2022-06-21 20:36:03.946552
# Unit test for function bitbucket
def test_bitbucket():
    bitbucket(branch='master')

# Generated at 2022-06-21 20:36:07.796948
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = "master"
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = "passed"
    semaphore("master")

# Generated at 2022-06-21 20:36:12.282486
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "true"
    assert bitbucket("master")
    del os.environ["BITBUCKET_BUILD_NUMBER"]
    assert not bitbucket("master")



# Generated at 2022-06-21 20:36:19.812491
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket("master")

    os.environ["BITBUCKET_PR_ID"] = "abc"
    bitbucket_caught_exception = False
    try:
        bitbucket("master")
    except CiVerificationError:
        bitbucket_caught_exception = True
    assert bitbucket_caught_exception == True


# Generated at 2022-06-21 20:36:26.483135
# Unit test for function check
def test_check():
    check()
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"


# Generated at 2022-06-21 20:36:37.556250
# Unit test for function jenkins
def test_jenkins():
    """
    Unit test for function jenkins
    """

    # Unsuccessful checks
    os.environ["JENKINS_URL"] = "123"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "123"

    try:
        jenkins("master")
        raise Exception("ValueError should be raised if CHANGE_ID exists")
    except CiVerificationError:
        pass

    os.environ["CHANGE_ID"] = None
    os.environ.pop("BRANCH_NAME")
    os.environ["GIT_BRANCH"] = "master1"


# Generated at 2022-06-21 20:36:45.854299
# Unit test for function gitlab
def test_gitlab():
    """
    Test that the `gitlab` function raises a `CiVerificationError` if
    the environment variables are not set as expected.
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert gitlab("master")
    del os.environ["CI_COMMIT_REF_NAME"]
    os.environ["CI_COMMIT_REF_NAME"] = "feature/foo"
    try:
        gitlab("master")
    except CiVerificationError:
        del os.environ["CI_COMMIT_REF_NAME"]
        assert True
    else:
        del os.environ["CI_COMMIT_REF_NAME"]
        assert False



# Generated at 2022-06-21 20:36:56.059664
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    assert check() == True
    del os.environ["CIRCLE_BRANCH"]
    assert check() == False
    os.environ["CIRCLE_BRANCH"] = "develop"
    assert check() == False
    os.environ["CIRCLE_BRANCH"] = "master"
    assert check() == True
    os.environ["CI_PULL_REQUEST"] = "true"
    assert check() == False



# Generated at 2022-06-21 20:37:00.941136
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    circle("master")
    os.environ["CIRCLE_BRANCH"] = "other"
    try:
        circle("master")
        assert False
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CIRCLECI"]



# Generated at 2022-06-21 20:37:02.252338
# Unit test for function circle
def test_circle():
    assert checker(circle)("master")
    assert checker(circle)("develop")

# Generated at 2022-06-21 20:37:18.719264
# Unit test for function gitlab
def test_gitlab():
    existing_environment = os.environ.copy()

    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "value"

    try:
        gitlab("master")
    except CiVerificationError:
        assert True
    finally:
        os.environ.clear()
        os.environ.update(existing_environment)

    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None


# Generated at 2022-06-21 20:37:22.573355
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    check()

# Generated at 2022-06-21 20:37:27.924959
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "http://jenkins.local"
    os.environ["CHANGE_ID"] = None

    jenkins("master")

# Generated at 2022-06-21 20:37:31.877366
# Unit test for function checker
def test_checker():
    @checker
    def func():
        assert False

    from semantic_release.errors import CiVerificationError
    try:
        func()
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-21 20:37:38.141837
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = None
    check()
    del os.environ["CI_PULL_REQUEST"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CIRCLECI"]


# Generated at 2022-06-21 20:37:39.772882
# Unit test for function frigg
def test_frigg():
    assert checker(frigg)("master")



# Generated at 2022-06-21 20:37:43.582633
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    assert frigg("master") is True
    assert frigg("release") is True
    assert frigg("main") is True



# Generated at 2022-06-21 20:37:48.501944
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    try:
        gitlab('master')
    except CiVerificationError:
        print("test failed")
    os.environ['CI_COMMIT_REF_NAME'] = 'develop'
    try:
        gitlab('develop')
    except CiVerificationError:
        print("test failed")



# Generated at 2022-06-21 20:37:52.072871
# Unit test for function travis
def test_travis():
    env = {}
    env['BRANCH'] = 'master'
    env['PULL_REQUEST'] = 'false'
    os.environ = env
    env = {}
    env['SEMAPHORE'] = 'true'
    os.environ = env
    try:
        travis('master')
    except AssertionError:
        print("Failed: test_travis")


# Generated at 2022-06-21 20:38:03.548775
# Unit test for function semaphore
def test_semaphore():
    """
    Check to make sure semaphore returns an error when given the incorrect branch
    check to make sure semaphore returns an error when given a pull request
    check to make sure semaphore returns an error when given a failed build
    """

    import pytest

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "false"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    try:
        semaphore("master")
    except CiVerificationError:
        pytest.fail(
            "Semaphore returned an error when given the correct branch and parameters"
        )

# Generated at 2022-06-21 20:38:14.747101
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    assert frigg('master') == True


# Generated at 2022-06-21 20:38:19.180296
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "01"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "false"
    bitbucket(branch="master")
    os.environ["BITBUCKET_PR_ID"] = "true"
    bitbucket(branch="master")

# Generated at 2022-06-21 20:38:24.178789
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "myjenkins"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "1"
    assert jenkins("master")

# Generated at 2022-06-21 20:38:31.707958
# Unit test for function travis
def test_travis():
    """
    Test the travisCI checker.
    """

    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
        assert False
    except CiVerificationError:
        pass

    del os.environ["TRAVIS_PULL_REQUEST"]
    try:
        travis("master")
        assert False
    except CiVerificationError:
        pass

    os.environ["TRAVIS_BRANCH"] = "master"
    assert travis("master") is True


# Generated at 2022-06-21 20:38:34.477825
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    os.environ['CI_MERGE_REQUEST_IID'] = None
    gitlab("master")

# Generated at 2022-06-21 20:38:35.500254
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket("master")



# Generated at 2022-06-21 20:38:42.749849
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = ""
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "url"
    os.environ["CHANGE_ID"] = ""
    assert jenkins("master") is True
    del os.environ["JENKINS_URL"]
    del os.environ["BRANCH_NAME"]
    del os.environ["GIT_BRANCH"]
    del os.environ["CHANGE_ID"]



# Generated at 2022-06-21 20:38:45.762480
# Unit test for function checker
def test_checker():
    @checker
    def return_true():
        return True

    assert return_true()

    @checker
    def raise_assertion_error():
        raise AssertionError

    try:
        raise_assertion_error()
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-21 20:38:46.615546
# Unit test for function checker

# Generated at 2022-06-21 20:38:58.342147
# Unit test for function gitlab
def test_gitlab():
	##
	# Case:
	# - BRANCH_NAME = "master"
	# - CI_PULL_REQUEST = False
	# Expect:
	# - JENKINS_URL = True

	os.environ["CI_COMMIT_REF_NAME"] = "master"
	os.environ["CI_PULL_REQUEST"] = False

	assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
	assert not os.environ.get("CI_PULL_REQUEST")

	del os.environ["CI_COMMIT_REF_NAME"]
	del os.environ["CI_PULL_REQUEST"]

	##
	# Case:
	# - BRANCH_NAME = "master"
	# - CI_PULL_REQUEST = True
	#

# Generated at 2022-06-21 20:39:08.952190
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "9999"
    os.environ["BITBUCKET_BRANCH"] = "feature/test"
    os.environ["BITBUCKET_PR_ID"] = ""

    check(branch="feature/test")

# Generated at 2022-06-21 20:39:16.607524
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://my-jenkins.com"
    os.environ["CHANGE_ID"] = None
    os.environ["GIT_BRANCH"] = "master"

    check()

    with raises(CiVerificationError) as e:
        os.environ["CHANGE_ID"] = "123"
        check()

    assert e.value.message == "The verification check for the environment did not pass."

    with raises(CiVerificationError) as e:
        os.environ["GIT_BRANCH"] = "feature-branch"
        check()

    assert e.value.message == "The verification check for the environment did not pass."

# Generated at 2022-06-21 20:39:17.822019
# Unit test for function semaphore
def test_semaphore():
    assert semaphore('master')
    os.environ['BRANCH_NAME'] = 'test'
    assert semaphore('master')

# Generated at 2022-06-21 20:39:20.575098
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'release-candidate'
    branch = 'release-candidate'
    gitlab(branch)

# Generated at 2022-06-21 20:39:24.598234
# Unit test for function gitlab
def test_gitlab():
    mock_env = {"CI_COMMIT_REF_NAME": "master",
                "CI_MERGE_REQUEST_ID": ""}
    with mock.patch.dict(os.environ, mock_env):
        assert gitlab("master")

# Generated at 2022-06-21 20:39:33.020335
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "feature/123-important-feature"

    # test if the function bitbucket passes the correct branch
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Expected CiVerificationError for invalid branch")

    os.environ["BITBUCKET_BRANCH"] = "master"
    try:
        bitbucket("master")
    except CiVerificationError:
        raise AssertionError("CiVerificationError raised for valid branch")

# Generated at 2022-06-21 20:39:41.379971
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_BUILD_ID"] = "1"
    os.environ["FRIGG_REPO_OWNER"] = "owner"
    frigg("master")
    # Revert changes to environment variables
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_BUILD_ID"]
    del os.environ["FRIGG_REPO_OWNER"]



# Generated at 2022-06-21 20:39:45.542374
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = ""
    os.environ["CIRCLE_BRANCH"] = "master"
    circle("master")



# Generated at 2022-06-21 20:39:49.576930
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('master')


# Generated at 2022-06-21 20:39:51.249605
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert check("master") is None


# Generated at 2022-06-21 20:40:03.175039
# Unit test for function semaphore
def test_semaphore():
    os.environ["CI_PULL_REQUEST"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    assert semaphore("master")


# Generated at 2022-06-21 20:40:06.964912
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    try:
        travis()
    except Exception:
        assert False



# Generated at 2022-06-21 20:40:08.229447
# Unit test for function check
def test_check():
    try:
        check()
        assert 1
    except CiVerificationError:
        assert 0

# Generated at 2022-06-21 20:40:11.113592
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    print("I was called")

    semaphore("master")
    assert True

# Generated at 2022-06-21 20:40:14.983841
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = False
    frigg('master')



# Generated at 2022-06-21 20:40:18.264514
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "develop"

    check("develop")

# Generated at 2022-06-21 20:40:24.858129
# Unit test for function checker
def test_checker():
    """
    Unit test for function checker
    """
    @checker
    def verify_test(x):
        """
        Raise exception if x is not True
        """
        assert x


    # AssertionError should raise a CiVerificationError
    try:
        verify_test(False)
    except CiVerificationError:
        pass

    # No exception should be raised
    try:
        verify_test(True)
    except CiVerificationError:
        assert False

# Generated at 2022-06-21 20:40:31.636857
# Unit test for function circle
def test_circle():
    # TODO: Update this test case once we have a way to mock environmental variables
    assert False
    # os.environ["CIRCLECI"] = "true"
    # os.environ["CIRCLE_BUILD_NUM"] = "1"
    # os.environ["CIRCLE_BRANCH"] = "master"
    # os.environ["CI_PULL_REQUEST"] = ""
    # circle("master")



# Generated at 2022-06-21 20:40:34.271435
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = "10"
    os.environ['BITBUCKET_BRANCH'] = "master"

    bitbucket("master")

# Generated at 2022-06-21 20:40:40.237374
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "something"
    os.environ["CHANGE_ID"] = None

    jenkins("master")

# Generated at 2022-06-21 20:40:59.665950
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for function bitbucket
    """
    os.environ["BITBUCKET_BUILD_NUMBER"] = str(1)
    os.environ["BITBUCKET_BRANCH"] = str("master")
    bitbucket("master")
    os.unsetenv("BITBUCKET_BRANCH")
    os.environ["BITBUCKET_PR_ID"] = str(1)
    try:
        bitbucket(branch="master")
    except CiVerificationError:
        pass
    else:
        raise Exception("Should have raised CiVerificationError")
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]

if __name__ == "__main__":
    import sys

   

# Generated at 2022-06-21 20:41:05.553946
# Unit test for function frigg
def test_frigg():
    """
    Unit test for function frigg
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    frigg("test")
    os.environ["FRIGG_BUILD_BRANCH"] = "not_test"
    try:
        frigg("test")
    except CiVerificationError:
        assert True
        return

    assert False



# Generated at 2022-06-21 20:41:08.631306
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"]="123"
    os.environ["BRANCH_NAME"]="master"
    os.environ["GIT_BRANCH"]="master"
    os.environ["CHANGE_ID"]="123"
    check('master')

# Generated at 2022-06-21 20:41:11.503234
# Unit test for function checker
def test_checker():
    def raiseAssertionError():
        assert False

    def raiseOtherError():
        raise AttributeError()

    assert checker(raiseOtherError)() is None
    try:
        checker(raiseAssertionError)()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:41:12.299632
# Unit test for function semaphore
def test_semaphore():
    assert semaphore(os.environ.get("BRANCH_NAME"))

# Generated at 2022-06-21 20:41:14.003137
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "http://localhost:8080"
    os.environ["CHANGE_ID"] = " "
    check()

# Generated at 2022-06-21 20:41:19.446341
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    os.environ["GIT_BRANCH"] = "master"
    jenkins(branch="master")
    del os.environ["JENKINS_URL"]
    del os.environ["GIT_BRANCH"]


# Generated at 2022-06-21 20:41:25.645099
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_PR_ID'] = None
    assert bitbucket("master") == True
    os.environ['BITBUCKET_BRANCH'] = "dev"
    assert bitbucket("master") == False
    os.environ['BITBUCKET_PR_ID'] = "1"
    assert bitbucket("master") == False


# Generated at 2022-06-21 20:41:28.078849
# Unit test for function gitlab
def test_gitlab():
    """
    Test to see if gitlab variables are set
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert check() == True



# Generated at 2022-06-21 20:41:38.409930
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = ''
    assert circle('master') == True
    os.environ['CI_PULL_REQUEST'] = 'http://github.com/jhilbert/semantic-release/pull/9'
    assert circle('master') == False
    os.environ['CIRCLE_BRANCH'] = 'release'
    assert circle('master') == False
    os.environ['CI_PULL_REQUEST'] = ''
    assert circle('release') == True
    os.environ['CIRCLE_BRANCH'] = 'test'
    assert circle('release') == False

# Generated at 2022-06-21 20:41:59.949978
# Unit test for function frigg
def test_frigg():
    """
    Tests the frigg checker function.

    :return: Nothing
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    assert check("master") == True

    os.environ["FRIGG_BUILD_BRANCH"] = "dev"
    assert check("master") == False

    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "1"
    assert check("master") == False

    del os.environ["FRIGG"]

# Generated at 2022-06-21 20:42:11.532703
# Unit test for function jenkins
def test_jenkins():
    """
    Test function jenkins
    """
    # test not jenkins
    os.environ["FRIGG"] = "true"
    # test if jenkins_url is not None
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    # test if BRANCH_NAME = branch or GIT_BRANCH = branch
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    # test if CHANGE_ID is None
    os.environ["CHANGE_ID"] = None
    jenkins("master")
    # test not jenkins
    os.environ["FRIGG"] = "true"
    # test if jenkins_url is not None
    os

# Generated at 2022-06-21 20:42:13.225398
# Unit test for function checker
def test_checker():
    def test_function():
        assert False

    check_fn = checker(test_function)

    try:
        check_fn()
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:42:22.269516
# Unit test for function semaphore
def test_semaphore():
    assert semaphore(branch="master")
    os.environ['BRANCH_NAME'] = 'develop'
    assert not semaphore(branch="master")
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = '5'
    assert not semaphore(branch="master")
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'
    assert not semaphore(branch="master")
    os.environ['SEMAPHORE_THREAD_RESULT'] = ''
    assert semaphore(branch="master")


# Generated at 2022-06-21 20:42:27.455555
# Unit test for function checker
def test_checker():
    @checker
    def foo(assert_me):
        assert assert_me

    assert foo(True) is True  # no exception

    failed = False
    try:
        foo(False)
    except CiVerificationError as e:
        failed = True
        assert str(e) == "The verification check for the environment did not pass."
    assert failed is True


# Unit tests for function travis

# Generated at 2022-06-21 20:42:32.670452
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "12"
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check()
    del os.environ["CI_MERGE_REQUEST_ID"]
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    check()

# Generated at 2022-06-21 20:42:45.337217
# Unit test for function checker
def test_checker():
    @checker
    def raise_error():
        raise AssertionError()

    @checker
    def return_error():
        return True

    @checker
    def return_false():
        return False

    @checker
    def no_return():
        pass

    try:
        raise_error()
        raise AssertionError("Expected CiVerificationError")
    except CiVerificationError:
        pass

    try:
        no_return()
        raise AssertionError("Expected CiVerificationError")
    except CiVerificationError:
        pass

    try:
        return_error()
    except CiVerificationError:
        raise AssertionError("Expected no exception")


# Generated at 2022-06-21 20:42:48.998905
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    check()
