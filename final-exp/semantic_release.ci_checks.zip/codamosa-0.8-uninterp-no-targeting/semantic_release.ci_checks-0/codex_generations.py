

# Generated at 2022-06-21 20:33:01.730893
# Unit test for function jenkins
def test_jenkins():
    """
    Ensure that function jenkins checks the environment correctly.
    """
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins-ci.org/"
    os.environ["CHANGE_ID"] = "1234"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Expected an error to be raised.")

    del os.environ["CHANGE_ID"]
    jenkins("master")

# Generated at 2022-06-21 20:33:08.195183
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("develop")


# Generated at 2022-06-21 20:33:10.959495
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "1234"
    os.environ['BRANCH_NAME'] = "master"
    os.environ['CHANGE_ID'] = "123"
    assert jenkins("master") is True

# Generated at 2022-06-21 20:33:17.275097
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    del os.environ["CI_PULL_REQUEST"]
    assert check()
    os.environ["CI_PULL_REQUEST"] = "1"
    del os.environ["CIRCLE_BRANCH"]
    assert check()


# Generated at 2022-06-21 20:33:22.390173
# Unit test for function frigg
def test_frigg():
    #   Test for checking frigg false
    os.environ["FRIGG"] = "false"
    assert check()

    #   Test for checking frigg true
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert check(branch="master")

    #   Test for checking frigg exception
    del os.environ["FRIGG_BUILD_BRANCH"]
    os.environ["FRIGG_PULL_REQUEST"] = ""
    try:
        assert check(branch="master") 
    except CiVerificationError:
        pass

    #   Test for checking frigg exception
    os.environ["FRIGG_BUILD_BRANCH"] = "master1"
    os.environ

# Generated at 2022-06-21 20:33:30.677123
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = False
    check()
    os.environ.pop("CI_PULL_REQUEST", None)
    os.environ["CIRCLE_BRANCH"] = "random"
    check(branch="random")
    os.environ["CI_PULL_REQUEST"] = True
    os.environ.pop("CIRCLE_BRANCH", None)
    os.environ.pop("CIRCLECI", None)
    check(branch="random")


# Generated at 2022-06-21 20:33:41.459775
# Unit test for function check
def test_check():
    """
    Unit test for function check
    """

    # testing Travis CI
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    assert check() is True

    os.environ["TRAVIS_BRANCH"] = "not_master"
    assert check() is False

    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    assert check() is False

    os.environ.pop('TRAVIS_PULL_REQUEST', None)
    os.environ.pop('TRAVIS_BRANCH', None)
    os.environ.pop('TRAVIS', None)

    # testing Semaphore


# Generated at 2022-06-21 20:33:47.493438
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '1234'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    assert bitbucket()
   
    os.environ['BITBUCKET_BRANCH'] = 'not-master'
    assert not bitbucket()

    os.environ['BITBUCKET_PR_ID'] = 'pull-request'
    assert not bitbucket()


# Generated at 2022-06-21 20:33:52.727760
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check("master")

    # test pr
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "pr-develop"
    os.environ["CI_PULL_REQUEST"] = "junk"
    with raises(CiVerificationError):
        check("master")

    # test wrong branch
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "not-master"

# Generated at 2022-06-21 20:33:56.839356
# Unit test for function circle
def test_circle():
    os.environ.update(
        {
            "CIRCLECI": "true",
            "CIRCLE_BRANCH": "master",
            "CI_PULL_REQUEST": "false",
        }
    )
    circle("master")



# Generated at 2022-06-21 20:34:12.114150
# Unit test for function jenkins
def test_jenkins():
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.io/"
    os.environ["CHANGE_ID"] = "1"

    jenkins("master")
    os.environ["GIT_BRANCH"] = "develop"

    with pytest.raises(CiVerificationError):
        jenkins("master")

    os.environ["CHANGE_ID"] = None
    jenkins("develop")

    del os.environ["GIT_BRANCH"]
    del os.environ["JENKINS_URL"]
    del os.environ["CHANGE_ID"]



# Generated at 2022-06-21 20:34:18.028694
# Unit test for function check
def test_check():
    """
    ensure it doesn't fail if there is no CI.
    """
    # We have no CI
    del os.environ["TRAVIS"]
    del os.environ["SEMAPHORE"]
    del os.environ["CIRCLECI"]
    del os.environ["GITLAB_CI"]
    del os.environ["BITBUCKET_BUILD_NUMBER"]
    del os.environ["JENKINS_URL"]

    check()

# Generated at 2022-06-21 20:34:20.892832
# Unit test for function checker
def test_checker():
    with checker(lambda: 1 / 0):
        pass
    try:
        with checker(lambda: 1 / 0):
            raise AssertionError
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:34:22.712527
# Unit test for function check
def test_check():
    """
    Unit test for the function `check`.
    """
    assert check()

# Generated at 2022-06-21 20:34:29.009939
# Unit test for function checker
def test_checker():
    @checker
    def assert_okay():
        assert True is True

    assert_okay()

    @checker
    def assert_not_okay():
        assert True is False

    try:
        assert_not_okay()
    except CiVerificationError:
        assert True is True

# Generated at 2022-06-21 20:34:33.341844
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = "42"
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_PR_ID'] = ""

    check("master")

    assert True


# Generated at 2022-06-21 20:34:37.370060
# Unit test for function checker
def test_checker():
    @checker
    def t():
        assert False
    try:
        t()
    except CiVerificationError:
        pass
    else:
        assert False
    @checker
    def f():
        assert True
    assert f() is True

# Generated at 2022-06-21 20:34:45.482124
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") is None
    # Check branch
    os.environ["BRANCH_NAME"] = "foobar"
    assert semaphore("master") is False
    # Check pull request
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    assert s

# Generated at 2022-06-21 20:34:52.686502
# Unit test for function check
def test_check():
    # Set necessary env variable for test
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS_EVENT_TYPE"] = "push"
    check()
    # Test failure case
    os.environ["TRAVIS_EVENT_TYPE"] = "pull_request"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-21 20:34:56.899903
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    bitbucket("master")

    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    passed = False
    try:
        bitbucket("master")
    except CiVerificationError:
        passed = True
    assert passed


# Generated at 2022-06-21 20:35:07.633249
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME']='master'
    os.environ['CI_MERGE_REQUEST_SOURCE_BRANCH_NAME']="pr-branch"
    os.environ['CI_MERGE_REQUEST_TARGET_BRANCH_NAME']="target-branch"
    os.environ['CI_MERGE_REQUESTS']="12"
    try:
        assert gitlab("master")
    except CiVerificationError as e:
        assert len(e.args) == 1

# Generated at 2022-06-21 20:35:18.601402
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_IID'] = 'None'
    gitlab('master')
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_IID'] = ''
    gitlab('master')
    os.environ['CI_COMMIT_REF_NAME'] = 'dev'
    os.environ['CI_MERGE_REQUEST_IID'] = 'None'
    gitlab('master')
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_IID'] = '1'
    gitlab('master')


# Generated at 2022-06-21 20:35:25.423502
# Unit test for function bitbucket
def test_bitbucket():
    from os import environ
    # If a branch name is specified, it should be equal to the BITBUCKET_BRANCH environment variable.
    # The pull request id should be none.
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = None
    bitbucket('master')
    # If the branch name is not specified, it should be equal to the BITBUCKET_BRANCH environment variable.
    # The pull request id should be none.
    bitbucket()
    # If the branch name is not equal to the BITBUCKET_BRANCH environment variable, the check should fail.
    # The pull request id should be none.
    with pytest.raises(CiVerificationError):
        bitbucket('XXX')
   

# Generated at 2022-06-21 20:35:26.621328
# Unit test for function circle
def test_circle():
    assert True
    # TODO

# Generated at 2022-06-21 20:35:31.081053
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = 'True'
    os.environ['BRANCH_NAME'] = 'master'
    #os.environ['CHANGE_ID'] = 'True'
    assert check()

# Generated at 2022-06-21 20:35:41.744061
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.example.com"
    os.environ["CHANGE_ID"] = None

    # Should not raise an error
    jenkins("master")

    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.example.com"
    os.environ["CHANGE_ID"] = "10"

    # Should raise an error
    try:
        jenkins("master")
    except AssertionError:
        pass

# Generated at 2022-06-21 20:35:52.064440
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["PULL_REQUEST_NUMBER"] = None
    assert semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    assert not semaphore("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]

# Generated at 2022-06-21 20:35:54.137635
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "111"
    bitbucket("master")

# Generated at 2022-06-21 20:36:01.660705
# Unit test for function frigg
def test_frigg():
    """
    frigg function test
    """
    os.environ["FRIGG"] = "true"
    print('  Funtions test.')
    print('  frigg function test.')
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    del os.environ["FRIGG_BUILD_BRANCH"]
    print('  frigg function test passed.')


# Generated at 2022-06-21 20:36:09.860466
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "testing"
    os.environ['FRIGG_PULL_REQUEST'] = "not pull request"
    check()
    assert "FRIGG" in os.environ
    assert "FRIGG_BUILD_BRANCH" in os.environ
    assert "FRIGG_PULL_REQUEST" in os.environ
    assert os.environ['FRIGG'] == "true"
    assert os.environ['FRIGG_BUILD_BRANCH'] == "testing"
    assert os.environ['FRIGG_PULL_REQUEST'] == "not pull request"


# Generated at 2022-06-21 20:36:33.625663
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_PROJECT_NAMESPACE"] = "semantic-release"
    os.environ["CI_PROJECT_NAME"] = "semantic-release"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_COMMIT_REF_SLUG"] = "master"
    os.environ["CI_COMMIT_REF_PATH"] = "refs/heads/master"
    os.environ["GITLAB_USER_ID"] = "1"
    os.environ["GITLAB_USER_EMAIL"] = "joe@example.com"
    os.environ["GITLAB_USER_LOGIN"] = "joe@example.com"
    os

# Generated at 2022-06-21 20:36:43.195077
# Unit test for function semaphore
def test_semaphore():
    os.environ['SEMAPHORE'] = 'true'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    os.environ['BRANCH_NAME'] = 'master'
    assert semaphore('master')
    assert not semaphore('develop')

    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'
    assert not semaphore('master')

    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    os.environ['PULL_REQUEST_NUMBER'] = 'not_none'
    assert not semaphore('master')


# Generated at 2022-06-21 20:36:51.554986
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "test-branch"
    assert gitlab("test-branch")

    os.environ["CI_COMMIT_REF_NAME"] = "test-branch"
    assert gitlab("te-branch") is False

    del os.environ["CI_COMMIT_REF_NAME"]
    try:
        gitlab("test-branch")
        assert False
    except CiVerificationError as e:
        pass
    except:
        assert False

# Generated at 2022-06-21 20:37:00.998751
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "test"
    os.environ["BITBUCKET_BRANCH"] = "test"
    os.environ["BITBUCKET_PR_ID"] = "test"
    assert bitbucket("test")
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ.pop("BITBUCKET_PR_ID", None)
    assert bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "test_bitbucket"
    os.environ["BITBUCKET_PR_ID"] = "test"
    try:
        bitbucket("test_bitbucket")
    except CiVerificationError:
        pass
    else:
        raise Assert

# Generated at 2022-06-21 20:37:10.870691
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = "testbranch"
    os.environ['BITBUCKET_PR_ID'] = "1"
    with pytest.raises(CiVerificationError):
        bitbucket("master")
    del os.environ['BITBUCKET_BRANCH']
    del os.environ['BITBUCKET_PR_ID']

    os.environ['BITBUCKET_BRANCH'] = "master"
    bitbucket("master")
    del os.environ['BITBUCKET_BRANCH']

if __name__ == "__main__":
    import sys

    sys.exit(check())

# Generated at 2022-06-21 20:37:19.670701
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = ""
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis(branch="")
    os.environ["TRAVIS_BRANCH"] = "master"
    assert travis(branch="master")
    os.environ["TRAVIS_BRANCH"] = "not master"
    assert travis(branch="not master")
    os.environ["TRAVIS_BRANCH"] = ""
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    assert travis(branch="")
    os.environ["TRAVIS_BRANCH"] = "master"
    assert travis(branch="master")

# Generated at 2022-06-21 20:37:24.528962
# Unit test for function frigg
def test_frigg():
    os.environ.update({"FRIGG": "true", "FRIGG_BUILD_BRANCH": "master"})
    frigg("master")
    os.environ.update({"FRIGG_BUILD_BRANCH": "testing"})
    assert frigg("master") is False

# Generated at 2022-06-21 20:37:27.827048
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = 'master'
    os.environ["CI_MERGE_REQUEST_ID"] = None

    check(branch="master")


# Generated at 2022-06-21 20:37:39.651138
# Unit test for function check

# Generated at 2022-06-21 20:37:43.212580
# Unit test for function semaphore
def test_semaphore():
    os.environ.update(
        {
            "PULL_REQUEST_NUMBER": None,
            "SEMAPHORE_THREAD_RESULT": "passed",
            "BRANCH_NAME": "master"
        }
    )
    semaphore('master')



# Generated at 2022-06-21 20:38:09.551968
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG_BUILD_BRANCH'] = 'feature/test'
    os.environ['FRIGG_PULL_REQUEST'] = '45'
    frigg('feature/test')



# Generated at 2022-06-21 20:38:10.491862
# Unit test for function check
def test_check():
    assert not check()

# Generated at 2022-06-21 20:38:19.234519
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""

    try:
        circle("master")
    except:
        pass
    try:
        os.environ["CI_PULL_REQUEST"] = "1234"
        circle("master")
    except CiVerificationError:
        pass
    finally:
        del os.environ["CI_PULL_REQUEST"]
    try:
        os.environ["CIRCLE_BRANCH"] = "develop"
        circle("master")
    except:
        pass
    finally:
        os.environ["CIRCLE_BRANCH"] = "master"

# Generated at 2022-06-21 20:38:24.222336
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-21 20:38:28.821557
# Unit test for function travis
def test_travis():

    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'

    try:
        travis('master')
    except CiVerificationError as e:
        raise e
    except Exception:
        assert False


# Generated at 2022-06-21 20:38:32.904402
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert frigg("master") is True
    assert frigg("development") is False



# Generated at 2022-06-21 20:38:37.894845
# Unit test for function checker
def test_checker():
    """
    Test the decorator checker.
    """
    @checker
    def dummy_function():
        """
        An example dummy function.
        """
        assert False

    try:
        dummy_function()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError was not raised")

# Generated at 2022-06-21 20:38:39.258584
# Unit test for function jenkins
def test_jenkins():
    assert os.environ.get("JENKINS_URL") is not None

# Generated at 2022-06-21 20:38:45.221191
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = True
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = False
    assert circle("master") == True
    del os.environ["CIRCLE_BRANCH"]
    assert circle("master") == False
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = True
    assert circle("master") == False

# Generated at 2022-06-21 20:38:56.778725
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    check()
    os.environ["TRAVIS"] = None

    os.environ["SEMAPHORE"] = "true"
    check()
    os.environ["SEMAPHORE"] = None

    os.environ["FRIGG"] = "true"
    check()
    os.environ["FRIGG"] = None

    os.environ["CIRCLECI"] = "true"
    check()
    os.environ["CIRCLECI"] = None

    os.environ["GITLAB_CI"] = "true"
    check()
    os.environ["GITLAB_CI"] = None

    os.environ["JENKINS_URL"] = "true"
    check()

# Generated at 2022-06-21 20:39:49.578747
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"

    check()
    assert "FRIGG" in os.environ
    del os.environ["FRIGG"]
    assert "FRIGG" not in os.environ


# Unit tests for function travis

# Generated at 2022-06-21 20:39:53.855892
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert check(branch="master") is None


# Generated at 2022-06-21 20:39:57.834809
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
        assert False, "Should not be here"
    except CiVerificationError:
        assert True

    os.environ["BITBUCKET_PR_ID"] = ""
    assert bitbucket("master")



# Generated at 2022-06-21 20:40:02.730202
# Unit test for function circle
def test_circle():
    assert os.environ.get("CIRCLECI") == "true"
    circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    try:
        circle("master")
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-21 20:40:08.272739
# Unit test for function checker
def test_checker():
    def foo():
        assert False

    def bar():
        raise AssertionError("this is an error")

    checker_foo = checker(foo)
    checker_bar = checker(bar)

    checker_foo()
    try:
        checker_bar()
    except CiVerificationError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-21 20:40:09.556298
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert bitbucket("master")
    assert not bitbucket("develop")

# Generated at 2022-06-21 20:40:15.039255
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    assert True == True
    os.environ["CIRCLECI"] = "true"
    os.environ["SEMAPHORE"] = "true"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["GITLAB_CI"] = "true"
    os.environ["FRIGG"] = "true"
    os.environ["CI_PULL_REQUEST"] = "true"
    os.environ["BITBUCKET_PR_ID"] = "true"

# Generated at 2022-06-21 20:40:25.385627
# Unit test for function jenkins
def test_jenkins():
    """
    Unit test for function jenkins
    """
    os.environ["JENKINS_URL"] = "some_url"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = None
    assert jenkins("master") == True
    del os.environ["JENKINS_URL"]
    assert jenkins("master") == False
    os.environ["JENKINS_URL"] = "some_url"
    os.environ["BRANCH_NAME"] = "test"
    assert jenkins("master") == False
    os.environ["CHANGE_ID"] = "1"
    assert jenkins("master") == False

# Generated at 2022-06-21 20:40:26.153426
# Unit test for function bitbucket
def test_bitbucket():
    assert checker(bitbucket)("test") is True

# Generated at 2022-06-21 20:40:30.021751
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch="master")

# Generated at 2022-06-21 20:42:14.556985
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = "true"
    os.environ['TRAVIS_BRANCH'] = "mybranch"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    try:
        check()
        assert True
    except:
        assert False

# Generated at 2022-06-21 20:42:19.130869
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert check() is None
    del os.environ["CI_COMMIT_REF_NAME"]
    assert check() is None
    del os.environ["GITLAB_CI"]


# Generated at 2022-06-21 20:42:26.625631
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""

    check()
    os.environ["FRIGG_PULL_REQUEST"] = "1"

    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False

    del os.environ["FRIGG_PULL_REQUEST"]



# Generated at 2022-06-21 20:42:30.063452
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    assert check() is None
    os.environ.pop("CIRCLECI")
    os.environ.pop("CIRCLE_BRANCH")


# Generated at 2022-06-21 20:42:31.708561
# Unit test for function checker
def test_checker():
    def test_func():
        assert 15 == 10
    with pytest.raises(CiVerificationError):
        test_checker(test_func)

# Generated at 2022-06-21 20:42:36.433514
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = "true"
    os.environ['CIRCLE_BRANCH'] = "master"
    os.environ['CI_PULL_REQUEST'] = ""
    assert circle('master') is True
    try:
        assert circle('development') is True
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."
    os.environ['CI_PULL_REQUEST'] = "123"
    try:
        assert circle('master') is True
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."



# Generated at 2022-06-21 20:42:47.936886
# Unit test for function bitbucket
def test_bitbucket():
    # GIVEN
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PULLREQUEST_ID"] = "pull_request_id"
    # WHEN
    # THEN
    assert bitbucket("master") == True
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PULLREQUEST_ID"] = ""
    # WHEN
    # THEN
    assert bitbucket("master") == True
    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PULLREQUEST_ID"] = "pull_request_id"
    # WHEN
    # THEN
    assert bitbucket("master") == False
   