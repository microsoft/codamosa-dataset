

# Generated at 2022-06-21 20:33:01.730356
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "test"
    check(branch="master")


# Generated at 2022-06-21 20:33:08.195304
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "12"
    os.environ["BITBUCKET_BRANCH"] = "Rev_20"
    os.environ["BITBUCKET_BRANCH_2"] = "Rev_20"
    os.environ["BITBUCKET_PR_ID"] = "12"
    bitbucket("Rev_20")

# Generated at 2022-06-21 20:33:11.656665
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '1234'
    os.environ['BITBUCKET_REPO_SLUG'] = 'test_repo'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    bitbucket(branch="master")



# Generated at 2022-06-21 20:33:23.235703
# Unit test for function checker
def test_checker():
    # Test function raising exception
    @checker
    def find_error():
        assert False

    found_error = False
    try:
        find_error()
    except CiVerificationError:
        found_error = True

    assert found_error

    # Test passing function
    class NoneException(Exception):
        """
        Used to simulate an exception
        """
        pass

    @checker
    def find_none():
        raise NoneException()

    found_none = False
    try:
        find_none()
    except NoneException:
        found_none = True

    assert found_none


# Generated at 2022-06-21 20:33:25.605026
# Unit test for function checker
def test_checker():
    def foo():
        pass

    assert callable(checker(foo))

# Generated at 2022-06-21 20:33:31.270608
# Unit test for function gitlab
def test_gitlab():
    """
    Test whether Gitlab environment variables are correctly read.
    """
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = '0'

    try:
        check()
    except AssertionError:
        raise AssertionError("The gitlab variables were not correctly parsed.")

    try:
        check(branch = 'wrong branch')
    except AssertionError:
        raise AssertionError("The gitlab variables were not correctly parsed.")


# Generated at 2022-06-21 20:33:32.975855
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()

# Generated at 2022-06-21 20:33:38.403431
# Unit test for function gitlab
def test_gitlab():
    assert gitlab('master') is True
    assert gitlab('master') is 'a'
    assert gitlab('a') is True


# Generated at 2022-06-21 20:33:42.149751
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]

# Generated at 2022-06-21 20:33:47.648808
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master") == True
    assert travis("develop") == False
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-21 20:33:58.670358
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()



# Generated at 2022-06-21 20:34:09.292925
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
        travis("something else")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["TRAVIS_BRANCH"]
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["TRAVIS_PULL_REQUEST"]



# Generated at 2022-06-21 20:34:12.072224
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()

# Generated at 2022-06-21 20:34:17.593348
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    try:
        gitlab("master")
    except CiVerificationError:
        raise AssertionError()

    # Reset environment variables
    os.environ["CI_COMMIT_REF_NAME"] = None
    os.environ["CI_MERGE_REQUEST_ID"] = None

# Generated at 2022-06-21 20:34:21.520830
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "test"
    os.environ["GIT_BRANCH"] = "test"
    os.environ["CHANGE_ID"] = ""
    check(branch = "test")

# Generated at 2022-06-21 20:34:28.711583
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-21 20:34:40.023256
# Unit test for function gitlab
def test_gitlab():
    os.environ['GITLAB_CI'] = "true"
    os.environ['CI_COMMIT_REF_NAME'] = "develop"
    os.environ['CI_MERGE_REQUEST_IID'] = "1"
    assert gitlab("develop") == False, "should return false due to pull request"
    assert gitlab("master") == True, "should return true"

    del os.environ['CI_MERGE_REQUEST_IID']
    assert gitlab("develop") == True, "should return true"

    del os.environ['GITLAB_CI']
    assert gitlab("master") == False, "should return false due to no GITLAB_CI"

    os.environ['GITLAB_CI'] = "false"

# Generated at 2022-06-21 20:34:50.525423
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "http://localhost:8080"
    os.environ['GIT_BRANCH'] = "feature-branch"
    os.environ['CHANGE_ID'] = "1"
    assert jenkins("feature-branch") == True
    os.environ['JENKINS_URL'] = "http://localhost:8080"
    os.environ['GIT_BRANCH'] = "feature-branch"
    os.environ['BRANCH_NAME'] = "feature-branch"
    os.environ['CHANGE_ID'] = "1"
    assert jenkins("feature-branch") == True
    os.environ['JENKINS_URL'] = "http://localhost:8080"

# Generated at 2022-06-21 20:34:53.990986
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    check("master")

# Generated at 2022-06-21 20:34:59.403509
# Unit test for function frigg
def test_frigg():  # pylint: disable=invalid-name
    from unittest.mock import patch
    from semantic_release import ci_checks
    with patch.dict(os.environ, {"FRIGG": "true", "FRIGG_BUILD_BRANCH": "master"}):
        ci_checks.frigg("master")



# Generated at 2022-06-21 20:35:10.243725
# Unit test for function bitbucket
def test_bitbucket():
    """

    """
    assert os.environ.get("BITBUCKET_BRANCH") == "master"
    assert not os.environ.get("BITBUCKET_PR_ID")
    print("Pass test_bitbucket")


# Generated at 2022-06-21 20:35:12.706485
# Unit test for function jenkins
def test_jenkins():
    assert hasattr(jenkins, "__call__")
    assert hasattr(jenkins, "__name__")



# Generated at 2022-06-21 20:35:18.939096
# Unit test for function circle
def test_circle():
    for key in os.environ.keys():
        os.environ.pop(key)
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'

    # does not throw error
    circle('master')
    
    os.environ['CIRCLE_BRANCH'] = 'beta'
    # throws error
    try:
        circle('master')
    except CiVerificationError:
        assert True

# Generated at 2022-06-21 20:35:24.866241
# Unit test for function frigg
def test_frigg():
    assert checker(frigg)("master")
    os.environ['FRIGG_BUILD_BRANCH'] = 'develop'
    assert checker(frigg)("master") is False
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = '1'
    assert checker(frigg)("master") is False
    del os.environ['FRIGG_PULL_REQUEST']
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    assert checker(frigg)("master")


# Generated at 2022-06-21 20:35:36.389178
# Unit test for function bitbucket
def test_bitbucket():
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as dirpath:
        with open(os.path.join(dirpath, '.env'), 'w') as env_file:
            env_file.write("BITBUCKET_REPO_OWNER=repo_owner\n")
            env_file.write("BITBUCKET_REPO_SLUG=repo_slug\n")
            env_file.write("BITBUCKET_BRANCH=master\n")
            env_file.write("BITBUCKET_TAG=none\n")
            env_file.write("BITBUCKET_COMMIT=073d0b03db9d926eb769bcf22a8a7c1b88be1c2e\n")

# Generated at 2022-06-21 20:35:44.097992
# Unit test for function checker
def test_checker():
    def true_func(*args, **kwargs):
        return True

    def false_func(*args, **kwargs):
        raise AssertionError(
            "This function should raise an assertion error."
        )

    assert checker(true_func)() == True

    try:
        checker(false_func)()
    except CiVerificationError as exc:
        assert str(exc) == (
            "The verification check for the environment did not pass."
        )
    else:
        assert False



# Generated at 2022-06-21 20:35:53.280654
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = False

# Generated at 2022-06-21 20:36:00.069479
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        pass



# Generated at 2022-06-21 20:36:03.600144
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-21 20:36:06.334256
# Unit test for function checker
def test_checker():
  @checker
  def function(): assert False
  try:
    function()
  except CiVerificationError:
    assert True
  else:
    assert False

# Generated at 2022-06-21 20:36:16.131539
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master")
    assert not semaphore("develop")
    assert semaphore("releases/0.2")
    assert not semaphore("develop")
    assert not semaphore("develop")

# Generated at 2022-06-21 20:36:19.223965
# Unit test for function checker
def test_checker():
    @checker
    def raise_assert(bool):
        assert bool

    try:
        raise_assert(False)
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-21 20:36:19.774266
# Unit test for function check
def test_check():
    assert check('master')

# Generated at 2022-06-21 20:36:23.515424
# Unit test for function gitlab
def test_gitlab():
    assert os.environ.get("GITLAB_CI") is None
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()
    assert os.environ.get("GITLAB_CI") is None


# Generated at 2022-06-21 20:36:26.827055
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check('master')
    assert(True)



# Generated at 2022-06-21 20:36:37.773592
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "test build number"
    os.environ["BITBUCKET_BRANCH"] = "test branch"
    os.environ["BITBUCKET_PR_ID"] = "test pull request id"
    # noinspection PyBroadException
    try:
        bitbucket("test branch")
    except Exception:
        assert False
    os.environ["BITBUCKET_BRANCH"] = "other branch"
    try:
        bitbucket("test branch")
        assert False
    except CiVerificationError:
        pass
    os.environ["BITBUCKET_BRANCH"] = "test branch"
    os.environ["BITBUCKET_PR_ID"] = None
    # noinspection PyBroadException

# Generated at 2022-06-21 20:36:45.575349
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "FIXME"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        frigg("FIXME")
    except CiVerificationError:
        pass
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]
    try:
        frigg("FIXME")
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:36:53.143416
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch="master")
    assert os.environ.get("TRAVIS") == "true"
    assert os.environ.get("TRAVIS_BRANCH") == "master"
    assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"


# Generated at 2022-06-21 20:37:01.838521
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis(branch="master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["TRAVIS_BRANCH"] = "not_master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis(branch="master")
    except CiVerificationError:
        pass

    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-21 20:37:08.973722
# Unit test for function check
def test_check():
    """Test CI non-detection"""
    os.environ["TRAVIS"] = "false"
    os.environ["SEMAPHORE"] = "false"
    os.environ["FRIGG"] = "false"
    os.environ["CIRCLECI"] = "false"
    os.environ["GITLAB_CI"] = "false"
    os.environ.pop("JENKINS_URL", None)
    os.environ.pop("BITBUCKET_BUILD_NUMBER", None)
    check()

# Generated at 2022-06-21 20:37:19.012197
# Unit test for function travis
def test_travis():
    branch = "master"
    os.environ["TRAVIS_BRANCH"] = branch
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch)
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]



# Generated at 2022-06-21 20:37:31.088207
# Unit test for function check
def test_check():
    """
    Performs unit testing for the check() function.
    """
    def assert_raises(func: Callable, error: Callable, msg: str, **kwargs) -> None:
        """
        A quick assertion to test that a function will raise an error and
        with the correct message.

        :param func: The function that should raise an error
        :param error: The error to expect
        :param msg: The message to expect in the error
        :param **kwargs: Optional keyword arguments to pass to the function
        """
        def test_func():
            func(**kwargs)

        try:
            test_func()
        except error as e:
            assert str(e) == msg
        else:
            raise AssertionError("Function did not raise {0}".format(error))


# Generated at 2022-06-21 20:37:37.009994
# Unit test for function checker
def test_checker():
    def test_func():
        assert False

    test_decorated = checker(test_func)
    try:
        test_decorated()
    except AssertionError:
        pass
    except CiVerificationError as cve:
        assert cve.args[0] == "The verification check for the environment did not pass."
    else:
        raise AssertionError('Should have raised CiVerificationError')

# Generated at 2022-06-21 20:37:43.304416
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert frigg("master")

    os.environ["FRIGG_BUILD_BRANCH"] = "release"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        frigg("master")
        assert False
    except CiVerificationError:
        assert True



# Generated at 2022-06-21 20:37:51.654788
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    with pytest.raises(CiVerificationError):
        frigg('master')

    os.environ['FRIGG'] = 'false'
    with pytest.raises(CiVerificationError):
        frigg('master')

    os.environ['FRIGG_BUILD_BRANCH'] = 'frigg_branch'
    with pytest.raises(CiVerificationError):
        frigg('master')

    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    with pytest.raises(CiVerificationError):
        frigg('master')

    os.environ['FRIGG_PULL_REQUEST'] = 'true'

# Generated at 2022-06-21 20:38:00.447516
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert travis('master') is True
    os.environ['TRAVIS_BRANCH'] = 'develop'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert travis('master') is False
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    assert travis('master') is False

# Generated at 2022-06-21 20:38:06.314310
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-21 20:38:08.056391
# Unit test for function travis
def test_travis():
    assert checker(travis)('master')


# Generated at 2022-06-21 20:38:18.259945
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "1234"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("1234")
    os.environ["TRAVIS_BRANCH"] = "1234"
    os.environ["TRAVIS_PULL_REQUEST"] = "1"
    os.environ["TRAVIS"] = "true"
    try:
        travis("1234")
        assert 0
    except CiVerificationError:
        pass
    except Exception:
        assert 0
    os.environ["TRAVIS_BRANCH"] = "12345"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS"] = "true"

# Generated at 2022-06-21 20:38:20.013827
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis("master")


# Generated at 2022-06-21 20:38:31.591341
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    check()
    os.environ["SEMAPHORE"] = "true"
    check()
    os.environ["FRIGG"] = "true"
    check()
    os.environ["CIRCLECI"] = "true"
    check()
    os.environ["GITLAB_CI"] = "true"
    check()
    os.environ["BRANCH_NAME"] = "master"
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    check()

# Generated at 2022-06-21 20:38:36.413477
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    assert check() == True


# Generated at 2022-06-21 20:38:41.658110
# Unit test for function checker
def test_checker():
    def checker_test_func(func):
        def func_wrapper(*args, **kwargs):
            try:
                func(*args, **kwargs)
                return True
            except AssertionError as e:
                print(e)
        return func_wrapper

    @checker_test_func
    def test_function(a, b):
        assert a == b

    test_function(1, 1)

# Generated at 2022-06-21 20:38:48.203889
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = 'true'
    try:
        check(branch='master')
    except CiVerificationError:
        assert False
    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    try:
        check(branch='master')
    except CiVerificationError:
        assert False
    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    try:
        check(branch='master')
    except CiVerificationError:
        assert False

# Generated at 2022-06-21 20:38:51.757270
# Unit test for function gitlab
def test_gitlab():
    os.environ['GITLAB_CI'] = 'true'
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    check()

# Generated at 2022-06-21 20:38:55.691385
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = True
    os.environ['GIT_BRANCH'] = 123
    os.environ['CHANGE_ID'] = None
    check()



# Generated at 2022-06-21 20:38:58.896650
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    check(branch="master")

# Generated at 2022-06-21 20:39:03.957467
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    assert True


# Generated at 2022-06-21 20:39:14.027628
# Unit test for function check
def test_check():
    # Default checks
    check()

    # Travis
    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    check()
    os.environ['TRAVIS_BRANCH'] = 'dev'
    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False

    # Semaphore
    os.environ['SEMAPHORE'] = 'true'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    os.environ.pop('PULL_REQUEST_NUMBER', None)

# Generated at 2022-06-21 20:39:18.127259
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = 'jenkins'
    os.environ["BRANCH_NAME"] = 'master'
    os.environ["GIT_BRANCH"] = 'master'
    os.environ["CHANGE_ID"] = 'not exist'
    testCheck = check()
    assert testCheck == True

# Generated at 2022-06-21 20:39:36.433594
# Unit test for function jenkins
def test_jenkins():
    # Expect "master" as the current branch
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "http://example.com"
    os.environ["CHANGE_ID"] = None
    jenkins("master")
    # Expect "develop" as the current branch
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["GIT_BRANCH"] = "develop"
    os.environ["JENKINS_URL"] = "http://example.com"
    os.environ["CHANGE_ID"] = None
    jenkins("develop")
    # Expect "staging" as the current branch

# Generated at 2022-06-21 20:39:42.054653
# Unit test for function checker
def test_checker():
    class FakeClass:
        @checker
        def get_a(self):
            return 1

        def get_b(self):
            return 1

        @checker
        def get_c(self):
            raise AssertionError

    a = FakeClass()

    assert a.get_a() == 1
    assert a.get_b() == 1

    try:
        a.get_c()
    except CiVerificationError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-21 20:39:45.191836
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis()

# Generated at 2022-06-21 20:39:47.012403
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket.__name__ == "bitbucket"

# Generated at 2022-06-21 20:39:50.552768
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "1"
    os.environ["GIT_BRANCH"] = "master"
    check()


# Generated at 2022-06-21 20:39:58.023361
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "semaphore"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    semaphore("semaphore")
    os.environ["PULL_REQUEST_NUMBER"] = 3
    try:
        semaphore("semaphore")
        assert False, "Failed to raise exception for pull_request"
    except CiVerificationError:
        pass
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("semaphore")
        assert False, "Failed to raise exception for failed thread"
    except CiVerificationError:
        pass


# Generated at 2022-06-21 20:39:59.903560
# Unit test for function check
def test_check():
    """
    Make sure we don't raise an error in any of the checks.
    """
    check()

# Generated at 2022-06-21 20:40:10.064396
# Unit test for function semaphore
def test_semaphore():
    # GIVEN-WHEN-THEN
    # Testing successful scenario
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") is True
    # Testing unsuccessful scenario
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1234"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("master")
    except CiVerificationError:
        assert True

# Generated at 2022-06-21 20:40:15.350887
# Unit test for function jenkins
def test_jenkins():
    # Unit test for function jenkins
    def test_jenkins():
        # GIT_BRANCH=master CHANGE_ID=123 JENKINS_URL=http://1.1.1.1:8080
        os.environ["JENKINS_URL"] = "http://1.1.1.1:8080"
        os.environ["CHANGE_ID"] = "123"
        os.environ["GIT_BRANCH"] = "master"
        assert not jenkins("master")

        # GIT_BRANCH=dev CHANGE_ID=123 JENKINS_URL=http://1.1.1.1:8080
        os.environ["JENKINS_URL"] = "http://1.1.1.1:8080"

# Generated at 2022-06-21 20:40:25.692880
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    try:
        gitlab("master")
    except:
        assert False
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    try:
        gitlab("master")
        assert False
    except:
        pass
    os.environ["CI_COMMIT_REF_NAME"] = ""
    try:
        gitlab("")
    except:
        assert False
    try:
        gitlab("master")
        assert False
    except:
        pass
    os.environ["CI_COMMIT_REF_NAME"] = None
    try:
        gitlab("")
        assert False
    except:
        pass


# Generated at 2022-06-21 20:40:35.245726
# Unit test for function checker
def test_checker():
    def dummy():
        raise AssertionError

    decorated_function = checker(dummy)
    try:
        decorated_function()
    except CiVerificationError:
        assert True


# Generated at 2022-06-21 20:40:40.809883
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] =  "testbranch"
    assert frigg("testbranch")
    del os.environ['FRIGG']
    del os.environ['FRIGG_BUILD_BRANCH']


# Generated at 2022-06-21 20:40:42.154718
# Unit test for function check
def test_check():
    """
    Unit test for function check()
    """
    with pytest.raises(CiVerificationError):
        check()

# Generated at 2022-06-21 20:40:43.971429
# Unit test for function bitbucket
def test_bitbucket():
    import os

    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = ''

    bitbucket('master')

# Generated at 2022-06-21 20:40:49.262857
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    check()
    os.environ["BITBUCKET_BRANCH"] = "test"
    check("test")
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        check("test")
    except CiVerificationError:
        pass
    else:
        raise Exception(
            "bitbucket() should raise an exception"
            "when the environment is not correct."
        )
    del os.environ["BITBUCKET_PR_ID"]
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        check("test")
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:40:54.408037
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    assert not bitbucket("master")

# Generated at 2022-06-21 20:41:04.525475
# Unit test for function jenkins
def test_jenkins():

    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "http://localhost:8080"
    jenkins(branch="master")

    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "http://localhost:8080"
    os.environ["CHANGE_ID"] = "test"
    try:
        jenkins(branch="master")
        assert False
    except AssertionError as e:
        assert str(e) == "False is not true"

    os.environ["BRANCH_NAME"] = "dev"
    os.environ["JENKINS_URL"] = "http://localhost:8080"

# Generated at 2022-06-21 20:41:07.277406
# Unit test for function checker
def test_checker():
    """Test checker function."""
    @checker
    def function_to_test(arg):
        """Function to test."""
        assert False

    try:
        function_to_test(None)
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:41:11.661690
# Unit test for function checker
def test_checker():
    def func():
        pass

    def assert_func():
        assert False

    def error_func():
        raise AssertionError()

    wrapped = checker(func)
    assert wrapped()
    wrapped = checker(assert_func)
    try:
        wrapped()
        assert False
    except CiVerificationError:
        pass
    wrapped = checker(error_func)
    try:
        wrapped()
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:41:16.427925
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    assert 1 == 1

# Generated at 2022-06-21 20:41:38.930612
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = 'true'
    assert check()
    os.environ['TRAVIS_BRANCH'] = 'develop'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert check('develop')
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    assert check() != True
    del os.environ['TRAVIS']
    os.environ['SEMAPHORE'] = 'true'
    assert check()
    os.environ['BRANCH_NAME']  = 'develop'
    os.environ['PULL_REQUEST_NUMBER'] = 'false'
    assert check('develop')
    os.environ['PULL_REQUEST_NUMBER'] = 'true'
    assert check('develop')

# Generated at 2022-06-21 20:41:44.615685
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    os.environ["FRIGG_PULL_REQUEST"] = "1"
    try:
        frigg("test")
    except CiVerificationError:
        pass

    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "0"
    frigg("master")



# Generated at 2022-06-21 20:41:52.037450
# Unit test for function semaphore
def test_semaphore():

        os.environ["BRANCH_NAME"] = "master"
        os.environ["PULL_REQUEST_NUMBER"] = None
        os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
        semaphore("master")

        os.environ["BRANCH_NAME"] = "master"
        os.environ["PULL_REQUEST_NUMBER"] = None
        os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
        semaphore("master")


# Generated at 2022-06-21 20:41:57.393663
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("test")
    # Test fails
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    try:
        frigg("test")
    except CiVerificationError:
        pass
    del os.environ["FRIGG"]


# Generated at 2022-06-21 20:42:03.189811
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("develop")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError as err:
        assert str(err) == (
            "The verification check for the environment did not pass."
        )
    else:
        assert False, "Exception expected"


# Generated at 2022-06-21 20:42:08.161419
# Unit test for function gitlab
def test_gitlab():
    vars = ['CI_COMMIT_REF_NAME']
    for env_var in vars:
        assert env_var in os.environ
    assert os.environ.get("CI_COMMIT_REF_NAME") != "test"
    assert os.environ.get("CI_MERGE_REQUEST_ID") == None



# Generated at 2022-06-21 20:42:15.339939
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "111"
    try:
        bitbucket(branch="master")
        assert False
    except CiVerificationError:
        assert True

    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    try:
        bitbucket(branch="master")
        assert True
    except CiVerificationError:
        assert False



# Generated at 2022-06-21 20:42:26.466011
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "test"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    os.environ["TRAVIS_BRANCH"] = "master"
    check()

    os.environ["TRAVIS_BRANCH"] = "test"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    with pytest.raises(CiVerificationError):
        check()

    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    os.environ["FRIGG_PULL_REQUEST"] = "false"


# Generated at 2022-06-21 20:42:32.730012
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test bitbucket environment variable checking.
    """
    os.environ["BITBUCKET_BUILD_NUMBER"] = "10"

    # Test when it is pull request
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("branch")
    except CiVerificationError:
        pass
    else:
        assert False

    # Test when it is not pull request
    os.environ.pop("BITBUCKET_PR_ID")
    try:
        bitbucket("branch")
    except CiVerificationError:
        assert False
    else:
        pass

# Generated at 2022-06-21 20:42:38.727761
# Unit test for function checker
def test_checker():
    def assert_fail():
        assert False

    def assert_pass():
        assert True

    try:
        assert_fail = checker(assert_fail)
        assert_fail()
    except CiVerificationError:
        pass
    else:
        assert False

    assert_pass = checker(assert_pass)
    assert assert_pass()