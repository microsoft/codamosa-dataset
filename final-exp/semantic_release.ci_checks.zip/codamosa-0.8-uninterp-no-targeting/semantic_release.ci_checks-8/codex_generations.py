

# Generated at 2022-06-21 20:33:01.694330
# Unit test for function checker
def test_checker():
    def func():
        raise AssertionError

    decorated_func = checker(func)
    try:
        decorated_func()
    except CiVerificationError: # pylint: disable=try-except-raise
        raise
    except AssertionError:
        pass


if __name__ == "__main__":
    import pytest

    pytest.main()

# Generated at 2022-06-21 20:33:05.381834
# Unit test for function circle
def test_circle():
    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_BRANCH"] = "master"
    check()


# Generated at 2022-06-21 20:33:06.617525
# Unit test for function frigg
def test_frigg():
    assert frigg("master") == True



# Generated at 2022-06-21 20:33:14.487898
# Unit test for function semaphore
def test_semaphore():
    """
    Unit test for function semaphore
    """
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    assert semaphore("dev") == False
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master") == False
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    assert semaphore("master") == False
    del os.environ["PULL_REQUEST_NUMBER"]
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaph

# Generated at 2022-06-21 20:33:17.700011
# Unit test for function travis
def test_travis():
    assert travis("master")
    assert travis("branch")

# Generated at 2022-06-21 20:33:26.518461
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "testing"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("testing")
    os.environ["TRAVIS_BRANCH"] = "testing"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    assert travis("testing") is False
    os.environ["TRAVIS_BRANCH"] = "testing"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("testing2") is False


# Generated at 2022-06-21 20:33:31.448755
# Unit test for function circle
def test_circle():
    try:
        circle('master')
    except Exception as e:
        assert(type(e) == CiVerificationError)


# Generated at 2022-06-21 20:33:41.795865
# Unit test for function checker
def test_checker():
    pass

    # TODO
    @checker
    def somefunction():
        return True

    assert somefunction() == True

    def func_raise_assert():
        raise AssertionError

    @checker
    def func_raise_assert2():
        raise AssertionError

    try:
        func_raise_assert()
    except AssertionError:
        pass
    else:
        raise AssertionError("Tested function did not raise AssertionError")

    try:
        func_raise_assert2()
    except AssertionError:
        pass
    else:
        raise AssertionError("Tested function did not raise AssertionError")

    try:
        func_raise_assert2()
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:33:45.959066
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "dev"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError as excep:
        assert str(excep) == "The verification check for the environment did not pass."
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        try:
            travis("master")
        except CiVerificationError as excep:
            assert str(excep) == "The verification check for the environment did not pass."
        else:
            assert True
    else:
        assert False


# Generated at 2022-06-21 20:33:56.793037
# Unit test for function frigg
def test_frigg():
    # Given that the CI is Frigg
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""

    # When we check with a branch that doesn't match
    try:
        frigg("bad")
        raise AssertionError("frigg check unexpectedly passed")
    except CiVerificationError:
        # Then the environment check should fail
        pass

    # When we check with a branch that matches
    assert frigg("master")

    # Cleanup
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]




# Generated at 2022-06-21 20:34:11.906642
# Unit test for function semaphore
def test_semaphore():
    # happy path
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")

    # bad branch
    os.environ["BRANCH_NAME"] = "develop"
    try:
        semaphore("master")
        raise AssertionError("Expected semaphore('master') to fail")
    except CiVerificationError:
        assert True

    # pull request
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "123"

# Generated at 2022-06-21 20:34:13.870340
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    gitlab("master")

# Generated at 2022-06-21 20:34:24.447814
# Unit test for function check
def test_check():
    """
    Test function check.
    """
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "next_release_branch"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "next_release_branch"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()

    os.environ["FRIGG"] = "true"

# Generated at 2022-06-21 20:34:36.878121
# Unit test for function semaphore
def test_semaphore():
    """
    Quick unit test for the semaphore function.
    """
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
        assert False, "This should not be reached"
    except CiVerificationError:
        assert True
    del os.environ["PULL_REQUEST_NUMBER"]
    try:
        semaphore("master")
        assert False, "This should not be reached"
    except CiVerificationError:
        assert True
    os.environ["SEMAPHORE_THREAD_RESULT"]

# Generated at 2022-06-21 20:34:38.606236
# Unit test for function check
def test_check():                
    try:
        check()
    except:
        assert False
    assert True

# Generated at 2022-06-21 20:34:49.384675
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = ""
    try:
        semaphore("master")
    except CiVerificationError as err:
        assert False
    os.environ["PULL_REQUEST_NUMBER"] = "any_non_empty_value"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
        assert False
    except CiVerificationError as err:
        assert True
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"



# Generated at 2022-06-21 20:34:53.158091
# Unit test for function jenkins
def test_jenkins():
    global os
    import unittest.mock
    
    try:
        os = unittest.mock.Mock()
        os.environ = {
            "JENKINS_URL": "not_none",
            "GIT_BRANCH": "master",
        }
        jenkins("master")
    except Exception as e:
        assert False

# Generated at 2022-06-21 20:35:04.253306
# Unit test for function check
def test_check():
    """Unit test for CI checks.
    """
    def set_env_var(variable, value):
        """Set an environment variable to a specific value.
        """
        os.environ[variable] = value

    def remove_env_var(variable):
        """Remove an environment variable.
        """
        del os.environ[variable]

    # Test that no CI service was detected.
    assert check() is None

    # Test Travis CI check.
    set_env_var("TRAVIS", "true")
    set_env_var("TRAVIS_BRANCH", "master")
    set_env_var("TRAVIS_PULL_REQUEST", "false")
    assert check()
    remove_env_var("TRAVIS_PULL_REQUEST")
    assert check()

    # Test Semaphore CI

# Generated at 2022-06-21 20:35:05.138577
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket("master")

# Generated at 2022-06-21 20:35:08.146956
# Unit test for function bitbucket
def test_bitbucket():
    try:
        bitbucket()
    except CiVerificationError as e:
        assert "The verification check for the environment did not pass." in str(e)

# Generated at 2022-06-21 20:35:13.368252
# Unit test for function check
def test_check():
    """Test function check"""
    assert check.__name__ == "check"

# Generated at 2022-06-21 20:35:16.091428
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()
    assert os.environ.get("CI_COMMIT_REF_NAME") == "master"

# Generated at 2022-06-21 20:35:19.724949
# Unit test for function jenkins
def test_jenkins():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['JENKINS_URL'] = 'True'
    os.environ['GIT_BRANCH'] = 'master'
    assert jenkins('master') == True

# Generated at 2022-06-21 20:35:24.700818
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = os.environ.get("BITBUCKET_BRANCH")
    os.environ["BITBUCKET_PULLREQUEST_ID"] = os.environ.get(
        "BITBUCKET_PULLREQUEST_ID")
    bitbucket(os.environ.get("BITBUCKET_BRANCH"))

# Generated at 2022-06-21 20:35:25.352579
# Unit test for function gitlab
def test_gitlab():
    gitlab("master")

# Generated at 2022-06-21 20:35:31.324564
# Unit test for function semaphore
def test_semaphore():
    """
    Test function semaphore
    """
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master")



# Generated at 2022-06-21 20:35:34.729509
# Unit test for function check
def test_check():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()

if __name__ == "__main__":
    test_check()

# Generated at 2022-06-21 20:35:40.060936
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = 'true'
    os.environ["FRIGG_BUILD"] = '321'
    os.environ["FRIGG_BUILD_BRANCH"] = 'master'
    os.environ["FRIGG_PULL_REQUEST"] = 'false'
    frigg('master')


# Generated at 2022-06-21 20:35:50.817166
# Unit test for function jenkins
def test_jenkins():

    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")

    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    os.environ["CHANGE_ID"] = "123"

    try:
        jenkins("master")
    except CiVerificationError:
        pass

    os.environ["BRANCH_NAME"] = "master"
    os.environ

# Generated at 2022-06-21 20:35:54.672164
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "branch"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    frigg("branch")
    assert os.environ["FRIGG"] == "true"
    del os.environ["FRIGG"]


# Generated at 2022-06-21 20:36:09.073725
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore("next")
    assert semaphore("master")

    os.environ["BRANCH_NAME"] = "next"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore("master")
    assert not semaphore("next")

    os.environ["BRANCH_NAME"] = "next"
    os.environ["PULL_REQUEST_NUMBER"] = None

# Generated at 2022-06-21 20:36:10.866233
# Unit test for function checker
def test_checker():
    @checker
    def throwing_func():
        raise AssertionError

    throwing_func()

# Generated at 2022-06-21 20:36:19.726931
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master")
    os.environ["CIRCLE_BRANCH"] = "test"
    assert circle("test")
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "1"
    try:
        circle("master")
    except CiVerificationError:
        return True
    return False

# Generated at 2022-06-21 20:36:22.388964
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")



# Generated at 2022-06-21 20:36:26.914088
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '1'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = '123'
    checker(bitbucket)('master')
    os.environ['BITBUCKET_BRANCH'] = 'branch'
    with pytest.raises(CiVerificationError):
        checker(bitbucket)('master')
    os.environ['BITBUCKET_PR_ID'] = ''
    checker(bitbucket)('branch')

# Generated at 2022-06-21 20:36:37.847218
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_TARGET_BRANCH_NAME"] = "feature"
    jenkins("master")

    os.environ["GIT_BRANCH"] = "master"
    os.environ["CI_MERGE_REQUEST_TARGET_BRANCH_NAME"] = "feature"
    jenkins("master")

    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "I-123"
    jenkins("master")

    os.environ["GIT_BRANCH"] = "master"

# Generated at 2022-06-21 20:36:42.674432
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master")
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'master'
    semaphore("master")
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'
    assert semaphore("master")

# Generated at 2022-06-21 20:36:47.696817
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["GIT_BRANCH"] = "develop"
    os.environ["CHANGE_ID"] = "1"
    check("develop")

# Generated at 2022-06-21 20:36:48.401138
# Unit test for function check
def test_check():
    assert check()

# Generated at 2022-06-21 20:36:58.908063
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = 123
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("master")
        assert False
    except CiVerificationError:
        pass
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None

# Generated at 2022-06-21 20:37:10.384425
# Unit test for function semaphore
def test_semaphore():
    """
    Unit test for function semaphore.
    """
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1000"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    checker = semaphore("master")
    assert not checker



# Generated at 2022-06-21 20:37:13.204046
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "true"
    os.environ["CHANGE_ID"] = None
    check()

# Generated at 2022-06-21 20:37:21.035777
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    check()
    check("master")

    os.environ["TRAVIS_BRANCH"] = "test"
    try:
        check("master")
    except CiVerificationError:
        pass
    else:
        raise Exception()

    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check("master")
    except CiVerificationError:
        pass
    else:
        raise Exception()

    os.environ["TRAVIS"] = "false"

    os.environ["SEMAPHORE"] = "true"

# Generated at 2022-06-21 20:37:30.752865
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    try:
        gitlab("master")
    except:
        assert(False)

    os.environ["CI_COMMIT_REF_NAME"] = "master"
    try:
        gitlab("master")
    except:
        assert(False)

    os.environ["CI_COMMIT_REF_NAME"] = "usr"
    try:
        gitlab("master")
        assert(False)
    except:
        pass
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["GITLAB_CI"]


# Generated at 2022-06-21 20:37:36.361427
# Unit test for function jenkins
def test_jenkins():
    assert os.environ.get("JENKINS_URL") is not None
    test_env = {'JENKINS_URL': 'https://jenkins.io',
                'BRANCH_NAME': 'master',
                'GIT_BRANCH': 'master',
                'CHANGE_ID': ''}
    assert jenkins(branch='master')

# Generated at 2022-06-21 20:37:41.722751
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "develop"
    with pytest.raises(CiVerificationError):
        frigg("master")
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    frigg("master")
    
    

# Generated at 2022-06-21 20:37:47.606175
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = 'test_branch'
    os.environ["CI_PULL_REQUEST"] = None
    assert gitlab("test_branch") == True
    # Gitlab is actually expected to fail if CI_PULL_REQUEST is set
    os.environ["CI_PULL_REQUEST"] = 'merge'
    try:
        gitlab("test_branch")
    except CiVerificationError:
        assert True
    except:
        assert False
    # Gitlab is actually expected to fail if wrong branch
    os.environ["CI_COMMIT_REF_NAME"] = 'master'
    try:
        gitlab("test_branch")
    except CiVerificationError:
        assert True
    except:
        assert False


# Generated at 2022-06-21 20:37:50.586833
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert check() is None

# Generated at 2022-06-21 20:38:01.497541
# Unit test for function circle
def test_circle():
    """Unit test for function circle.

    :return: None
    """
    import os
    import unittest
    import unittest.mock as mock
    import semantic_release.ci_checks as ci_checks


    os.environ["CIRCLECI"] = "true"

    # Test 1: correct branch
    mock_env = {}
    mock_env["CIRCLE_BRANCH"] = "master"
    mock_env["CI_PULL_REQUEST"] = None
    with mock.patch("os.environ", mock_env):
        ci_checks.circle("master")

    # Test 2: incorrect branch
    mock_env = {}
    mock_env["CIRCLE_BRANCH"] = "staging"
    mock_env["CI_PULL_REQUEST"] = None

# Generated at 2022-06-21 20:38:04.709956
# Unit test for function checker
def test_checker():
    def func():
        raise AssertionError

    try:
        checker(func)()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Did not raise")

# Generated at 2022-06-21 20:38:10.927505
# Unit test for function frigg
def test_frigg():
    pass

# Generated at 2022-06-21 20:38:13.718218
# Unit test for function gitlab
def test_gitlab():
    """
    Test gitlab
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    gitlab("master")



# Generated at 2022-06-21 20:38:17.272321
# Unit test for function circle
def test_circle():
    """
    Test correct ci check for circle
    """

    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = ""
    os.environ["CIRCLE_BRANCH"] = "master"

    check("master")



# Generated at 2022-06-21 20:38:20.061864
# Unit test for function checker
def test_checker():
    # check that no exceptions are raised
    checker(lambda x: x)(1)
    # check that the decorator behaves correctly

# Generated at 2022-06-21 20:38:23.217573
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["PULL_REQUEST_NUMBER"] = None
    assert semaphore("master")

    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    assert semaphore("master")


# Generated at 2022-06-21 20:38:31.815259
# Unit test for function check
def test_check():
    """Unit test for function check"""
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        check()
        assert True
    except:
        assert False
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        check()
        assert True
    except:
        assert False
    os.environ["FRIGG"] = "true"

# Generated at 2022-06-21 20:38:38.928524
# Unit test for function travis
def test_travis():
    check(branch="1.2.3")
    os.environ["TRAVIS_BRANCH"] = "1.2.3"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch="1.2.3")
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis(branch="1.2.3")
    except CiVerificationError as e:
        assert e



# Generated at 2022-06-21 20:38:41.783324
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS_BRANCH"] = "master"

    check(branch="master")

# Generated at 2022-06-21 20:38:44.924077
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "True"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "False"
    jenkins("master")


# Generated at 2022-06-21 20:38:45.322441
# Unit test for function check
def test_check():
    assert check() == None

# Generated at 2022-06-21 20:38:56.124538
# Unit test for function circle
def test_circle():
    assert checker(circle)("master")
    assert checker(circle)("test")
    os.environ["CIRCLE_BRANCH"] = "dev"
    try:
        assert not checker(circle)("master")
    except CiVerificationError:
        pass


# Generated at 2022-06-21 20:38:58.724381
# Unit test for function travis
def test_travis():
    import os
    os.environ['TRAVIS_BRANCH']='master'
    os.environ['TRAVIS_PULL_REQUEST']="false"
    travis(branch="master")


# Generated at 2022-06-21 20:39:01.482350
# Unit test for function travis
def test_travis():
    try:
        travis(None)
    except CiVerificationError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 20:39:05.740445
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "test"
    check()



# Generated at 2022-06-21 20:39:11.830556
# Unit test for function jenkins
def test_jenkins():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins"
    
    try:
        jenkins("master")
    except:
        print("You are not in jenkins environment, or you are not in master branch")

# Generated at 2022-06-21 20:39:15.993352
# Unit test for function semaphore
def test_semaphore():
    try:
        os.environ["BRANCH_NAME"] = "master"
        os.environ["PULL_REQUEST_NUMBER"] = None
        os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
        assert semaphore("master") is True
    except AssertionError:
        assert False, "Semaphore Test Failed"

# Generated at 2022-06-21 20:39:16.692974
# Unit test for function frigg
def test_frigg():
    assert frigg("master")


# Generated at 2022-06-21 20:39:18.247374
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'success'
    assert semaphore('master') == True



# Generated at 2022-06-21 20:39:28.012056
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"]="https://ci.example.com"
    os.environ["BRANCH_NAME"]="release"
    os.environ["GIT_BRANCH"]="release"
    os.environ['JENKINS_URL']="https://ci.example.com"
    os.environ["CHANGE_ID"]="1234"
    os.environ["FRIGG"]=None
    os.environ["TRAVIS"]=None
    os.environ["CIRCLECI"]=None
    os.environ["GITLAB_CI"]=None
    os.environ["BITBUCKET_BUILD_NUMBER"]=None
    os.environ["SEMAPHORE"]=None
    branch="release"
    check=check(branch)


# Generated at 2022-06-21 20:39:38.744081
# Unit test for function jenkins
def test_jenkins():
    """
    Test the verify_ci function on the jenkins CI.

    :param branch: The branch the environment should be running against.
    """
    assert os.environ.get("JENKINS_URL") is None
    assert os.environ.get("CHANGE_ID") is None
    branch_name = os.environ.get("BRANCH_NAME") or os.environ.get("GIT_BRANCH")
    os.environ["JENKINS_URL"] = "1"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")
    os.environ.pop("JENKINS_URL")
    os.environ.pop("BRANCH_NAME")
   

# Generated at 2022-06-21 20:39:50.169963
# Unit test for function bitbucket
def test_bitbucket():
    """
    
    """

# Generated at 2022-06-21 20:39:55.539924
# Unit test for function jenkins
def test_jenkins():
    """
    Test the jenkins checks.
    """
    os.environ['JENKINS_URL'] = 'http://localhost:8080'
    os.environ['GIT_BRANCH'] = 'master'
    os.environ['CHANGE_ID'] = '123'
    check()
    os.environ['GIT_BRANCH'] = 'test'
    check()

# Generated at 2022-06-21 20:39:58.162185
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert check()

# Generated at 2022-06-21 20:40:03.035881
# Unit test for function gitlab
def test_gitlab():
    """
    assert variables GITLAB_CI, CI_PROJECT_PATH
    """
    assert os.environ.get("GITLAB_CI") == "true"
    assert os.environ.get("CI_PROJECT_PATH") == "group1/package1"

# Generated at 2022-06-21 20:40:10.673557
# Unit test for function semaphore
def test_semaphore():
    """
    Test if checks pass when PR is set
    """
    mytestenv = dict(SEMAPHORE="true",
                     BRANCH_NAME="master",
                     PULL_REQUEST_NUMBER=1234)
    with mock(semaphore, os.environ, mytestenv):
        assert not semaphore("master")

    mytestenv = dict(SEMAPHORE="true",
                     BRANCH_NAME="master",
                     PULL_REQUEST_NUMBER=None)
    with mock(semaphore, os.environ, mytestenv):
        assert semaphore("master")



# Generated at 2022-06-21 20:40:15.694122
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    try:
        check()
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."
    else:
        assert "Test failed"
    del os.environ['PULL_REQUEST_NUMBER']
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"

# Generated at 2022-06-21 20:40:23.076129
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = 'true'
    os.environ["CI_PULL_REQUEST"] = 'true'
    os.environ["CIRCLE_BRANCH"] = 'testBranch'
    assert not circle("testBranch")
    
    os.environ["CIRCLE_BRANCH"] = 'master'
    os.environ["CI_PULL_REQUEST"] = 'false'
    assert circle("master")
    

# Generated at 2022-06-21 20:40:31.233821
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "branch"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        frigg("master")
    except CiVerificationError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 20:40:33.045016
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    check()

# Generated at 2022-06-21 20:40:35.478221
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "test"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert check("test") == True


# Generated at 2022-06-21 20:41:06.190810
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["PULL_REQUEST_NUMBER"] = ""
    semaphore(os.environ["BRANCH_NAME"])
    del os.environ["BRANCH_NAME"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    del os.environ["PULL_REQUEST_NUMBER"]

# Generated at 2022-06-21 20:41:08.939977
# Unit test for function gitlab
def test_gitlab():
    """
    Test function gitlab
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert gitlab("master")


test_gitlab.__test__ = False



# Generated at 2022-06-21 20:41:12.864863
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "true"
    with pytest.raises(CiVerificationError):
        jenkins("master")

    os.environ["CHANGE_ID"] = None
    jenkins("master")

# Generated at 2022-06-21 20:41:17.756384
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")

# Generated at 2022-06-21 20:41:19.009964
# Unit test for function semaphore
def test_semaphore():
    assert semaphore == checker(semaphore)


# Generated at 2022-06-21 20:41:27.856778
# Unit test for function circle
def test_circle():
    # Test "CIRCLE_BRANCH" and "CI_PULL_REQUEST"
    # When "CIRCLE_BRANCH" is not equal to "master" and "CI_PULL_REQUEST" exists
    os.environ['CIRCLE_BRANCH'] = 'test'
    os.environ['CI_PULL_REQUEST'] = 'test'
    try:
        circle('master')
        raise AssertionError('Test Failed')
    except CiVerificationError:
        assert True
    del os.environ['CI_PULL_REQUEST']

    # When "CIRCLE_BRANCH" is equal to "master" and "CI_PULL_REQUEST" exists
    os.environ['CIRCLE_BRANCH'] = 'master'

# Generated at 2022-06-21 20:41:35.667540
# Unit test for function checker
def test_checker():
    from ..errors import CiVerificationError

    def bad_func():
        assert False

    def good_func():
        assert True

    assert checker(bad_func)() == False
    assert checker(good_func)() == True

    # Check for error messages
    try:
        checker(bad_func)()
    except CiVerificationError as err:
        assert str(err) == "The verification check for the environment did not pass."

# Generated at 2022-06-21 20:41:40.842601
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PULLREQUEST_ID"] = "1"
    bitbucket("master")
    os.environ["BITBUCKET_PULLREQUEST_ID"] = ""
    bitbucket("master")


# Generated at 2022-06-21 20:41:44.124669
# Unit test for function checker
def test_checker():
    def success():
        return True
    
    def failure():
        raise AssertionError
    
    new_success = checker(success)
    assert new_success() == True
    new_failure = checker(failure)
    try:
        new_failure()
    except:
        assert True

# Generated at 2022-06-21 20:41:54.225268
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1234"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master")
    assert not semaphore("develop")
    del os.environ["BRANCH_NAME"]
    assert not semaphore("develop")
    assert not semaphore("master")
    assert semaphore("master")
    os.environ["PULL_REQUEST_NUMBER"] = None
    assert semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    assert semaphore("master")
    del os.environ["SEMAPHORE_THREAD_RESULT"]


# Generated at 2022-06-21 20:42:46.729657
# Unit test for function checker
def test_checker():
    from semantic_release.errors import CiVerificationError

    def func1():
        raise AssertionError

    def func2():
        return True

    decorated = checker(func1)
    try:
        decorated()
    except CiVerificationError as e:
        pass
    else:
        raise Exception("Did not raise correct error")

    assert decorated() is None


# Generated at 2022-06-21 20:42:55.455405
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")

    os.environ["BRANCH_NAME"] = "other"
    assert semaphore("master") == False

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    assert semaphore("master") == False

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"