

# Generated at 2022-06-21 20:32:59.392752
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    assert gitlab(branch='master')

# Generated at 2022-06-21 20:33:02.289536
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "2"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    check(branch="master")

# Generated at 2022-06-21 20:33:07.905755
# Unit test for function circle
def test_circle():
    """
    Test the code circle
    """
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "https://github.com/steveklabnik/semantic-release"
    os.environ["CIRCLE_BRANCH"] = "master"
    check("master")



# Generated at 2022-06-21 20:33:10.700290
# Unit test for function gitlab
def test_gitlab():
    """Test CI check for GitLab job"""
    os.environ["CI_COMMIT_REF_NAME"] = "release"
    try:
        check("release")
    except CiVerificationError:
        assert False



# Generated at 2022-06-21 20:33:15.906534
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.example.org"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")
    os.environ["BRANCH_NAME"] = "not-master"
    with pytest.raises(CiVerificationError):
        jenkins("master")
    os.environ["CHANGE_ID"] = "123456789"
    with pytest.raises(CiVerificationError):
        jenkins("master")


# Generated at 2022-06-21 20:33:18.554079
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com/"
    os.environ["BRANCH_NAME"] = "master"
    jenkins("master")

    os.environ["JENKINS_URL"] = "https://jenkins.com/"
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")



# Generated at 2022-06-21 20:33:28.002286
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'test_branch'
    os.environ['FRIGG_PULL_REQUEST'] = 'true'
    try:
        frigg('test_branch')
        assert False
    except CiVerificationError:
        assert True
    os.environ['FRIGG_PULL_REQUEST'] = None
    try:
        frigg('test_branch')
        assert True
    except CiVerificationError:
        assert False
    try:
        frigg('master')
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-21 20:33:32.253665
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    travis("master")



# Generated at 2022-06-21 20:33:40.544786
# Unit test for function jenkins
def test_jenkins():
    """
    Test the jenkins build
    """
    os.environ["JENKINS_URL"] = "https://jenkins"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = None

    try:
        jenkins("master")
        assert True
    except CiVerificationError:
        assert False
    finally:
        del os.environ["JENKINS_URL"]
        del os.environ["BRANCH_NAME"]
        del os.environ["CHANGE_ID"]


# Generated at 2022-06-21 20:33:50.774302
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "true"

    import pytest
    with pytest.raises(CiVerificationError):
        check()

    del os.environ["FRIGG_PULL_REQUEST"]

    check()

    del os.environ["FRIGG_BUILD_BRANCH"]
    os.environ["FRIGG_BUILD_BRANCH"] = "other"

    with pytest.raises(CiVerificationError):
        check()

    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]

# Generated at 2022-06-21 20:34:08.467776
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    check()

    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = 'master1'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False

    # reset
    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = 'master'

# Generated at 2022-06-21 20:34:14.405340
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "True"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1234"
    bitbucket("master")
    os.environ["BITBUCKET_PR_ID"] = None
    bitbucket("master")
    # TODO - check behavior on failure/error

# Generated at 2022-06-21 20:34:23.803285
# Unit test for function circle
def test_circle():
    try:
        circle(branch="master")
    except CiVerificationError:
        assert False
    os.environ["CIRCLE_BRANCH"] = "dev"
    try:
        circle(branch="master")
        assert False
    except CiVerificationError:
        os.environ["CIRCLE_BRANCH"] = "master"
        assert True
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "True"
    try:
        circle(branch="master")
        assert False
    except CiVerificationError:
        del os.environ["CI_PULL_REQUEST"]
        assert True

# Generated at 2022-06-21 20:34:29.843811
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "master"
    os.environ["CHANGE_ID"] = ""
    assert jenkins("master") is True



# Generated at 2022-06-21 20:34:40.377417
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    # try with an invalid branch
    os.environ["CIRCLE_BRANCH"] = "dev"
    try:
        check()
        raise RuntimeError
    except CiVerificationError:
        pass
    # try with a pull request
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "1234"
    try:
        check()
        raise RuntimeError
    except CiVerificationError:
        pass



# Generated at 2022-06-21 20:34:43.966216
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = "true"
    os.environ['CIRCLE_BRANCH'] = "master"
    os.environ['CI_PULL_REQUEST'] = ""
    circle("master")

# Generated at 2022-06-21 20:34:53.440275
# Unit test for function semaphore
def test_semaphore():
    assert not semaphore("master")
    assert not semaphore("develop")

    os.environ["PULL_REQUEST_NUMBER"] = '1'
    assert not semaphore("master")
    assert not semaphore("develop")

    os.environ["PULL_REQUEST_NUMBER"] = 'false'
    assert not semaphore("master")
    assert not semaphore("develop")

    os.environ["BRANCH_NAME"] = 'develop'
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    else:
        assert False

    os.environ["BRANCH_NAME"] = 'master'
    try:
        semaphore("develop")
    except CiVerificationError:
        pass
    else:
        assert False


# Generated at 2022-06-21 20:34:56.015350
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "dev"
    os.environ["FRIGG_PULL_REQUEST"] = "10"
    check("dev")
    assert True


# Generated at 2022-06-21 20:34:57.046816
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master") == True

# Generated at 2022-06-21 20:34:58.320586
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("master")

# Generated at 2022-06-21 20:35:06.646517
# Unit test for function check
def test_check():
    try:
        check("branch-name")
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:35:08.422240
# Unit test for function check
def test_check():
    try:
    	check()
    except:
    	pass

# Generated at 2022-06-21 20:35:09.718660
# Unit test for function circle
def test_circle():
    assert circle()



# Generated at 2022-06-21 20:35:13.063360
# Unit test for function travis
def test_travis():
    test_env('TRAVIS_BRANCH', 'master')
    test_env('TRAVIS_PULL_REQUEST', 'false')
    assert travis("master")


# Generated at 2022-06-21 20:35:17.329278
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "develop"
    assert jenkins("develop")
    os.environ["CHANGE_ID"] = "false"
    assert jenkins("develop")


# Generated at 2022-06-21 20:35:23.135599
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    try:
        circle("master")
    except CiVerificationError:
        assert False
    finally:
        del os.environ["CIRCLECI"]
        del os.environ["CIRCLE_BRANCH"]
        del os.environ["CI_PULL_REQUEST"]



# Generated at 2022-06-21 20:35:30.446341
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"

    circle("master")
    # Checking that it's throwing an CiVerificationError
    try:
        circle("test")
    except CiVerificationError:
        pass



# Generated at 2022-06-21 20:35:33.195141
# Unit test for function checker
def test_checker():
    """
    Assert that a function wrapped with @checker returns True
    """

    def assertion():
        assert True

    assert checker(assertion)()



# Generated at 2022-06-21 20:35:42.165711
# Unit test for function jenkins
def test_jenkins():
    """
    Unit test for function jenkins
    """
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "http://jenkins.url"
    os.environ["CHANGE_ID"] = ""
    assert jenkins(os.environ.get("BRANCH_NAME"))
    del os.environ["BRANCH_NAME"]
    assert jenkins(os.environ.get("GIT_BRANCH"))
    assert jenkins(os.environ.get("BRANCH_NAME"))

# Generated at 2022-06-21 20:35:52.412180
# Unit test for function gitlab
def test_gitlab():
    # Make sure the gitlab functions works correctly
    current = os.environ.get("CI_COMMIT_REF_NAME")
    current_merge_id = os.environ.get("CI_MERGE_REQUEST_IID")

    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = None
    gitlab(branch="master")

    try:
        os.environ["CI_COMMIT_REF_NAME"] = "master"
        os.environ["CI_MERGE_REQUEST_IID"] = "1"
        gitlab(branch="master")
    except CiVerificationError:
        assert True
    finally:
        os.environ["CI_COMMIT_REF_NAME"] = current
       

# Generated at 2022-06-21 20:35:59.212023
# Unit test for function circle
def test_circle():
    assert circle(branch="master")



# Generated at 2022-06-21 20:36:06.548157
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket(branch="master")

    with os.environ.copy():
        os.environ["BITBUCKET_BRANCH"] = "fa"

        with os.environ.copy():
            os.environ["BITBUCKET_PR_ID"] = "1"
            assert not bitbucket(branch="master")

        with os.environ.copy():
            del os.environ["BITBUCKET_PR_ID"]
            assert not bitbucket(branch="master")



# Generated at 2022-06-21 20:36:13.124117
# Unit test for function checker
def test_checker():
    @checker
    def func1():
        raise AssertionError

    @checker
    def func2():
        pass

    try:
        func1()
    except CiVerificationError:
        assert True
    else:
        assert False

    try:
        func2()
    except CiVerificationError:
        assert False
    else:
        assert True

# Generated at 2022-06-21 20:36:14.284613
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master") == True

# Generated at 2022-06-21 20:36:20.954663
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '123'
    os.environ['BITBUCKET_BUILD_NUMBER'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = '1'
    try:
        bitbucket("master")
    except CiVerificationError:
        os.environ['BITBUCKET_PR_ID'] = ''
    assert(bitbucket("master") == True)

# Generated at 2022-06-21 20:36:26.914886
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("branch1") == True
    os.environ["BRANCH_NAME"] = "branch2"
    assert jenkins("branch1") == False
    os.environ["BRANCH_NAME"] = "branch1"
    assert jenkins("branch1") == True
    os.environ["CHANGE_ID"] = "abc"
    assert jenkins("branch1") == False
    os.environ["CHANGE_ID"] = ""
    assert jenkins("branch1") == True
    os.environ["JENKINS_URL"] = ""
    assert jenkins("branch1") == False
    os.environ["JENKINS_URL"] = "http://jenkins.org"
    assert jenkins("branch1") == True
   

# Generated at 2022-06-21 20:36:31.574221
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "123"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = None
    jenkins("master")

# Generated at 2022-06-21 20:36:33.139006
# Unit test for function check
def test_check():
    """
    Test the check function to ensure that it runs smoothly.
    """
    check()

# Generated at 2022-06-21 20:36:36.876593
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    check("master")

# Generated at 2022-06-21 20:36:42.317577
# Unit test for function circle
def test_circle():
    import semantic_release.ci_checks as ci
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    ci.circle('master')
    del os.environ['CIRCLECI']
    del os.environ['CIRCLE_BRANCH']

# Generated at 2022-06-21 20:36:56.827082
# Unit test for function frigg
def test_frigg():
    frigg("master")
    frigg("develop")
    os.environ["FRIGG_PULL_REQUEST"] = "666"
    with pytest.raises(CiVerificationError):
        frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    with pytest.raises(CiVerificationError):
        frigg("master")
    del os.environ["FRIGG_PULL_REQUEST"]
    del os.environ["FRIGG_BUILD_BRANCH"]


# Generated at 2022-06-21 20:36:58.970524
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")



# Generated at 2022-06-21 20:37:05.474941
# Unit test for function circle
def test_circle():
    env = os.environ
    env['CIRCLECI'] = "true"
    env['CIRCLE_BRANCH'] = "master"
    env['CI_PULL_REQUEST'] = None
    check()
    env['CIRCLE_BRANCH'] = "release"
    with pytest.raises(CiVerificationError):
        check(branch="master")
    env['CI_PULL_REQUEST'] = "true"
    with pytest.raises(CiVerificationError):
        check(branch="master")

# Generated at 2022-06-21 20:37:07.967315
# Unit test for function checker
def test_checker():
    """Unit test function.
    """
    @checker
    def func():
        assert False

    try:
        func()
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:37:14.088061
# Unit test for function bitbucket
def test_bitbucket():
    # Set environment variables
    os.environ['BITBUCKET_BUILD_NUMBER'] = '30'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = ''

    # Test for successful code execution
    try:
        assert bitbucket(branch="master") == True
    except AssertionError:
        assert True == False

# Generated at 2022-06-21 20:37:23.950384
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "0"
    bitbucket("master")

    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        assert True

    os.environ["BITBUCKET_BRANCH"] = "master"
    del os.environ["BITBUCKET_PR_ID"]
    try:
        bitbucket("master")
    except CiVerificationError:
        assert True


# Generated at 2022-06-21 20:37:28.877076
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "stable"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check(branch="stable")


# Generated at 2022-06-21 20:37:33.226335
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "not-master"
    os.environ["CI_PULL_REQUEST"] = "1234"
    check()



# Generated at 2022-06-21 20:37:38.992855
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test that checker correctly raises a CIVerificationError on failure,
    and correctly continues on success.
    """
    def func():
        os.environ["BITBUCKET_BRANCH"] = "master"
        os.environ["BITBUCKET_PR_ID"] = None
        return

    @checker
    def decorated(func):
        func()

    decorated(func)

# Generated at 2022-06-21 20:37:42.348688
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    branch = "master"
    bitbucket(branch)

# Generated at 2022-06-21 20:37:52.917487
# Unit test for function travis
def test_travis():
    # Arrange
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    # Act
    travis("master")
    # Assert
    assert os.environ["TRAVIS"] == "true"
    assert os.environ["TRAVIS_BRANCH"] == "master"
    assert os.environ["TRAVIS_PULL_REQUEST"] == "false"


# Generated at 2022-06-21 20:37:56.929854
# Unit test for function frigg
def test_frigg():
    assert os.environ.get("FRIGG") == "true"
    assert os.environ.get("FRIGG_BUILD_BRANCH") == "master"
    assert not os.environ.get("FRIGG_PULL_REQUEST")



# Generated at 2022-06-21 20:38:04.876841
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    circle("test_circle")
    assert os.environ.get("CIRCLECI") == "true"
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-21 20:38:06.404190
# Unit test for function travis
def test_travis():
    assert os.system("cd test/test_travis/; python3 -m pytest") == 0


# Generated at 2022-06-21 20:38:17.284539
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    os.environ.pop('CI_MERGE_REQUEST_PROJECT_ID', None)
    gitlab("master")
    assert True
    os.environ.pop('CI_MERGE_REQUEST_PROJECT_ID', None)
    os.environ['CI_MERGE_REQUEST_PROJECT_ID'] = "99"
    assert gitlab("master") is False
    os.environ.pop('CI_MERGE_REQUEST_PROJECT_ID', None)
    os.environ.pop('CI_COMMIT_REF_NAME', None)
    os.environ['CI_COMMIT_REF_NAME'] = "v1.0.0"
    assert gitlab("master") is False
    os.environ.pop

# Generated at 2022-06-21 20:38:20.370619
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    frigg(branch="master")



# Generated at 2022-06-21 20:38:30.731523
# Unit test for function jenkins
def test_jenkins():
    # CI is running on some jenkins environment.
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "http://some/jenkins/url"
    # The branch is master
    check()
    # The branch is release/3.3.0
    os.environ["BRANCH_NAME"] = "release/3.3.0"
    check()
    # The branch is a pull request
    os.environ["BRANCH_NAME"] = "pull/1"
    os.environ["CHANGE_ID"] = "1"
    with pytest.raises(CiVerificationError):
        check()
    # There is no BRANCH_NAME
    del os.environ["BRANCH_NAME"]
    os.environ

# Generated at 2022-06-21 20:38:34.335389
# Unit test for function travis
def test_travis():
    assert os.environ.get("TRAVIS_BRANCH") == "testing"
    assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"


# Generated at 2022-06-21 20:38:40.081616
# Unit test for function jenkins
def test_jenkins():
    os.environ.setdefault('CI_COMMIT_REF_NAME','master')
    os.environ.setdefault('CHANGE_ID','')
    os.environ.setdefault('GIT_BRANCH','master')
    os.environ.setdefault('JENKINS_URL','https://localhost/')
    os.environ.setdefault('BRANCH_NAME','master')
    jenkins('master')

# Generated at 2022-06-21 20:38:45.523918
# Unit test for function jenkins
def test_jenkins():
    try:
        # these variables for testing
        os.environ["JENKINS_URL"] = "1"
        os.environ["BRANCH_NAME"] = "master"

        jenkins("master")
    except AssertionError:
        # AssertionError is expected
        pass
    else:
        raise AssertionError

    # reset os.environ
    del os.environ["JENKINS_URL"]
    del os.environ["BRANCH_NAME"]



# Generated at 2022-06-21 20:38:57.686316
# Unit test for function jenkins
def test_jenkins():
    """
    Test jenkins function in ci_checks.py
    """
    # TODO - add test case for specified branch
    os.environ["JENKINS_URL"] = "test_jenkins"
    os.environ["GIT_BRANCH"] = "master"
    check()
    del os.environ["JENKINS_URL"]
    del os.environ["GIT_BRANCH"]

# Generated at 2022-06-21 20:38:58.668745
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket() == True

# Generated at 2022-06-21 20:39:04.074338
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""

    check("master")



# Generated at 2022-06-21 20:39:14.108118
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    check()

    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    check()


# Generated at 2022-06-21 20:39:19.485837
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test function to unit test function bitbucket

    """
    test_os_environ = {"BITBUCKET_BRANCH": "test_branch"}
    assert os.environ.get("BITBUCKET_BRANCH") == "test_branch"
    assert not os.environ.get("BITBUCKET_PR_ID")
    try:
        bitbucket(branch="test_branch")
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:39:24.275687
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"

    frigg("master")



# Generated at 2022-06-21 20:39:28.299667
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('master')


# Generated at 2022-06-21 20:39:38.294105
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master") is True
    os.environ["CIRCLE_BRANCH"] = "development"
    assert circle("master") is False
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "1231234"
    assert circle("master") is False
    os.environ["CI_PULL_REQUEST"] = ""
    del os.environ["CIRCLECI"]
    assert circle("master") is False



# Generated at 2022-06-21 20:39:40.860021
# Unit test for function checker
def test_checker():
    @checker
    def func():
        raise AssertionError()

    try:
        func()
    except CiVerificationError:
        pass
    else:
        assert False, "Should have raised CiVerificationError"

# Generated at 2022-06-21 20:39:43.677693
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test case which verifies the funcation bitbucket
    """
    os.environ['BITBUCKET_BRANCH']='develop'
    bitbucket('develop')

# Generated at 2022-06-21 20:39:56.643974
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "10"
    os.environ["BITBUCKET_BRANCH"] = "25"
    os.environ["BITBUCKET_PR_ID"] = "50"
    assert bitbucket("25") == True
    assert bitbucket("26") == False
    del os.environ["BITBUCKET_BUILD_NUMBER"]
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]


# Generated at 2022-06-21 20:40:03.698169
# Unit test for function jenkins
def test_jenkins():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "http://www.test.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    jenkins()

# Generated at 2022-06-21 20:40:09.457957
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "Test"
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert check()

    os.environ["BITBUCKET_BUILD_NUMBER"] = "Test"
    os.environ["BITBUCKET_BRANCH"] = "develop"
    assert check(branch="develop")



# Generated at 2022-06-21 20:40:11.473169
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    check()


# Generated at 2022-06-21 20:40:23.644800
# Unit test for function semaphore
def test_semaphore():
    """
    Unit test for function semaphore
    """
    os.environ['BRANCH_NAME'] = "master"
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'
    assert semaphore("master")

    os.environ['BRANCH_NAME'] = "master"
    os.environ['PULL_REQUEST_NUMBER'] = "10"
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'
    try:
        semaphore("master")
    except CiVerificationError:
        pass

    os.environ['BRANCH_NAME'] = "develop"
    os.environ['PULL_REQUEST_NUMBER'] = None
   

# Generated at 2022-06-21 20:40:24.709670
# Unit test for function gitlab
def test_gitlab():
    assert check(branch="master")

# Generated at 2022-06-21 20:40:35.124703
# Unit test for function check
def test_check():
    # Test without any environment variable
    os.environ.clear()
    check()

    # Test with Travis
    os.environ.clear()
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    # Test with semaphore
    os.environ.clear()
    os.environ["SEMAPHORE"] = "true"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "None"
    check()

    # Test with frigg


# Generated at 2022-06-21 20:40:39.165112
# Unit test for function checker
def test_checker():
    def f():
        raise AssertionError

    g = checker(f)
    try:
        g()
        raise Exception("checker should throw error")
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:40:43.148988
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "master"
    check()
    del os.environ["JENKINS_URL"]
    del os.environ["GIT_BRANCH"]


# Generated at 2022-06-21 20:40:45.150834
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = None
    circle("master")



# Generated at 2022-06-21 20:41:00.185832
# Unit test for function jenkins
def test_jenkins():
    """
    Unit test for function jenkins.
    """
    # Case 1: Jenkins build and branch
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "http://localhost/"
    os.environ["CHANGE_ID"] = None
    assert jenkins("master") == True
    # Case 2: Jenkins build and pull request
    os.environ["JENKINS_URL"] = "http://localhost/"
    os.environ["CHANGE_ID"] = "1"
    assert jenkins("master") == False

# Generated at 2022-06-21 20:41:03.270770
# Unit test for function semaphore
def test_semaphore():
    if os.environ.get("SEMAPHORE") == "true":
        semaphore(os.environ.get("BRANCH_NAME"))
        

# Generated at 2022-06-21 20:41:05.667266
# Unit test for function gitlab
def test_gitlab():
    assert os.environ.get("CI_SERVER_NAME") == "GitLab CI"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    gitlab("master")

# Generated at 2022-06-21 20:41:08.098177
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket(branch="master")

# Generated at 2022-06-21 20:41:10.414302
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()



# Generated at 2022-06-21 20:41:12.023384
# Unit test for function checker
def test_checker():
    @checker
    def test():
        assert False

    import pytest

    with pytest.raises(CiVerificationError):
        test()

# Generated at 2022-06-21 20:41:20.732749
# Unit test for function checker
def test_checker():
    @checker
    def function(a: int, b: int) -> bool:
        """
        Returns True if both a and b are equal, False otherwise

        :param a: The first number to be compared
        :param b: The second number to be compared
        :return: True if both a and b are equal, False otherwise
        """
        assert a == b
        return True

    assert function(1, 1)
    try:
        function(2, 3)
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Function should have raised CiVerificationError")

# Generated at 2022-06-21 20:41:24.056960
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "0"
    bitbucket("master")
    assert "BITBUCKET_PR_ID" in os.environ


# Generated at 2022-06-21 20:41:31.906558
# Unit test for function travis
def test_travis():
    # Return True
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    travis("master")
    assert os.environ["TRAVIS_BRANCH"] == "master"
    assert os.environ["TRAVIS_PULL_REQUEST"] == "false"


# Generated at 2022-06-21 20:41:41.385841
# Unit test for function frigg
def test_frigg():
    """
    Test to verify the frigg function checks are working as expected
    """
    with os.environ.copy():
        # This build should pass
        os.environ["FRIGG"] = "true"
        os.environ["FRIGG_BUILD_BRANCH"] = "master"
        os.environ["FRIGG_PULL_REQUEST"] = "false"
        assert frigg("master")

        # This build should fail as the branch is not master
        os.environ["FRIGG"] = "true"
        os.environ["FRIGG_BUILD_BRANCH"] = "nope"
        os.environ["FRIGG_PULL_REQUEST"] = "false"
        try:
            frigg("master")
        except CiVerificationError:
            assert True

       

# Generated at 2022-06-21 20:41:50.803261
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch="master")



# Generated at 2022-06-21 20:41:53.873575
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    try:
        circle("master")
    except CiVerificationError as e:
        print(e)

# Generated at 2022-06-21 20:42:00.861194
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    circle()
    os.environ["CIRCLE_BRANCH"] = "not-master"
    os.environ["CI_PULL_REQUEST"] = ""
    try:
        circle()
        raise Exception("There should be an exception")
    except (CiVerificationError, AssertionError):
        pass

    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "true"

# Generated at 2022-06-21 20:42:03.876560
# Unit test for function travis
def test_travis():
    try:
        travis("master")
    except CiVerificationError:
        raise AssertionError("Travis check failed to pass.")


# Generated at 2022-06-21 20:42:04.866788
# Unit test for function check
def test_check():
    branch = "master"
    check(branch)

# Generated at 2022-06-21 20:42:10.145518
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for function bitbucket
    """
    branch = "master"
    os.environ['BITBUCKET_BRANCH'] = branch
    bitbucket(branch)
    assert os.environ.get("BITBUCKET_BRANCH") == branch
    assert not os.environ.get("BITBUCKET_PR_ID")

# Generated at 2022-06-21 20:42:13.763743
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "dev"
    os.environ["BITBUCKET_PR_ID"] = "20"
    try:
        bitbucket(branch = "dev")
    except CiVerificationError:
        os.environ["BITBUCKET_BRANCH"] = "master"
        os.environ["BITBUCKET_PR_ID"] = None
        bitbucket(branch = "master")



# Generated at 2022-06-21 20:42:23.822145
# Unit test for function check
def test_check():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["PULL_REQUEST_NUMBER"] = None
    assert check()

    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST" ] = "false"
    assert check()

    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = False
    assert check

# Generated at 2022-06-21 20:42:25.374015
# Unit test for function bitbucket
def test_bitbucket():
    assert checker(bitbucket("master"))()



# Generated at 2022-06-21 20:42:29.332458
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    check()



# Generated at 2022-06-21 20:42:42.872560
# Unit test for function bitbucket
def test_bitbucket():
    # Given
    branch = "master"
    os.environ["BITBUCKET_BUILD_NUMBER"] = ""
    os.environ["BITBUCKET_BRANCH"] = branch

    # When
    try:
        bitbucket(branch)
    except CiVerificationError:
        assert False

    # Then
    del os.environ["BITBUCKET_BRANCH"]
    assert True

# Generated at 2022-06-21 20:42:45.867629
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = ''
    bitbucket('master')


# Generated at 2022-06-21 20:42:50.975823
# Unit test for function checker
def test_checker():
    """
    Test the checker decorator.
    """
    @checker
    def test_func(assert_this: bool):
        """
        :param assert_this: Should be True
        """
        assert assert_this
    test_func(True)

    called = False
    try:
        test_func(False)
    except CiVerificationError:
        called = True

    assert called