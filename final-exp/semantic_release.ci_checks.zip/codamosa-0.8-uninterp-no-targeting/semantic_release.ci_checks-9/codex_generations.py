

# Generated at 2022-06-21 20:33:04.506019
# Unit test for function bitbucket
def test_bitbucket():
    # no branch name
    os.environ["BITBUCKET_BRANCH"] = None
    try:
        bitbucket("master")
    except AssertionError:
        pass

    # branch name is not master
    os.environ["BITBUCKET_BRANCH"] = "not-master"
    try:
        bitbucket("master")
    except AssertionError:
        pass

    # branch name is master, pull request id exists
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except AssertionError:
        pass

    # branch name is master, pull request id not exists

# Generated at 2022-06-21 20:33:09.177996
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://bd-jenkins.frigg.io/"
    os.environ["GIT_BRANCH"] = "master"
    check()
    del os.environ["JENKINS_URL"]
    del os.environ["GIT_BRANCH"]



# Generated at 2022-06-21 20:33:14.086605
# Unit test for function travis
def test_travis():
    """
    Test for the travis checker
    """
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    # os.environ["TRAVIS_BRANCH"] = "master"
    # os.environ["TRAVIS_PULL_REQUEST"] = "true"
    # assert travis("master") == False


# Generated at 2022-06-21 20:33:23.800367
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    bitbucket('master')
    del os.environ['BITBUCKET_BRANCH']

    os.environ['BITBUCKET_BRANCH'] = 'feature'
    bitbucket('master')
    del os.environ['BITBUCKET_BRANCH']

    os.environ['BITBUCKET_PULL_REQUEST_ID'] = '1'
    bitbucket('master')
    del os.environ['BITBUCKET_PULL_REQUEST_ID']

# Generated at 2022-06-21 20:33:27.002192
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"]="master"
    os.environ["CI_PROJECT_NAME"]="Gitlab CI"
    gitlab("master")

# Generated at 2022-06-21 20:33:40.065972
# Unit test for function jenkins
def test_jenkins():
    jenkins("master")
    jenkins("foo")
    os.environ["BRANCH_NAME"] = "master"
    jenkins("master")
    os.environ["BRANCH_NAME"] = "foo"
    jenkins("foo")
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")
    os.environ["GIT_BRANCH"] = "foo"
    jenkins("foo")
    os.environ["BRANCH_NAME"] = "bar"
    os.environ["GIT_BRANCH"] = "foo"
    jenkins("foo")
    os.environ["CHANGE_ID"] = "http://test"
    os.environ["BRANCH_NAME"] = "master"

# Generated at 2022-06-21 20:33:41.571167
# Unit test for function checker
def test_checker():
    def func():
        pass
    decorated_checker = checker(func)
    assert decorated_checker()

# Generated at 2022-06-21 20:33:43.350409
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = 1
    os.environ["BRANCH_NAME"] = 1
    os.environ["GIT_BRANCH"] = 1
    os.environ["CHANGE_ID"] = 1
    check()



# Generated at 2022-06-21 20:33:53.571539
# Unit test for function jenkins
def test_jenkins():
    # Test with environment variable set
    os.environ["JENKINS_URL"] = "http://someurl.com"
    os.environ["BRANCH_NAME"] = "some_branch"
    os.environ["CHANGE_ID"] = "1"
    try:
        jenkins()
        assert False
    except CiVerificationError:
        assert True

    # Test with environment variable not set
    os.environ["JENKINS_URL"] = "http://someurl.com"
    os.environ["BRANCH_NAME"] = "some_branch"
    os.environ.pop("CHANGE_ID")
    try:
        jenkins()
        assert True
    except CiVerificationError:
        assert False



# Generated at 2022-06-21 20:34:02.998603
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore("master")
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    os.environ["BRANCH_NAME"] = "develop"
    assert not semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    assert not semaphore("master")
    del os.environ["PULL_REQUEST_NUMBER"]


# Generated at 2022-06-21 20:34:14.273306
# Unit test for function semaphore
def test_semaphore():
    try:
        semaphore(branch="master")
    except CiVerificationError:
        pass
    assert not os.environ.get("BRANCH_NAME")
    assert os.environ.get("PULL_REQUEST_NUMBER") != ""
    assert os.environ.get("SEMAPHORE_THREAD_RESULT") == "failed"

# Generated at 2022-06-21 20:34:17.641846
# Unit test for function jenkins
def test_jenkins():
    # Testing with dummy values
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["CHANGE_ID"] = None

    jenkins("master")

# Generated at 2022-06-21 20:34:23.854992
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    try:
        check(branch="master")
    except CiVerificationError:
        assert False
    except Exception:
        assert False
    else:
        assert True

if __name__ == '__main__':
    test_jenkins()

# Generated at 2022-06-21 20:34:32.030294
# Unit test for function bitbucket
def test_bitbucket():
    # test checking valid build
    os.environ["BITBUCKET_BRANCH"] = "4"
    os.environ["BITBUCKET_PR_ID"] = "None"
    check()
    # test checking invalid build
    os.environ["BITBUCKET_BRANCH"] = "5"
    os.environ["BITBUCKET_PR_ID"] = "3"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-21 20:34:37.945113
# Unit test for function checker
def test_checker():
    def simple_func(fail=False):
        if fail:
            raise AssertionError()

    simple_func = checker(simple_func)

    try:
        simple_func(fail=True)
    except CiVerificationError:
        assert True

    try:
        simple_func(fail=False)
    except CiVerificationError:
        assert False



# Generated at 2022-06-21 20:34:42.619590
# Unit test for function jenkins
def test_jenkins():
    os.environ['BRANCH_NAME'] = "master"
    os.environ['JENKINS_URL'] = "something"
    os.environ['CHANGE_ID'] = "something"
    try:
        jenkins()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-21 20:34:52.723153
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert check() is None, "Checker should not raise an error"
    os.environ['TRAVIS'] = 'false'
    os.environ['SEMAPHORE'] = 'true'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = 'false'
    assert check() is None, "Checker should not raise an error"
    os.environ['SEMAPHORE'] = 'false'
    os.environ['FRIGG'] = 'true'

# Generated at 2022-06-21 20:34:55.878867
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    branch = "master"
    
    try:
        travis(branch)
    except:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-21 20:34:59.357401
# Unit test for function circle
def test_circle():
    assert (not checker(circle)("master"))
    os.environ["CIRCLE_BRANCH"] = "master"
    assert (checker(circle)("master"))



# Generated at 2022-06-21 20:35:04.943898
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "hello"
    os.environ['BRANCH_NAME'] = "master"

    def check():
        jenkins("master")

    assert check() == True

    os.environ['BRANCH_NAME'] = "branch"

    def check2():
        jenkins("master")

    assert check2() == False

# Generated at 2022-06-21 20:35:19.421016
# Unit test for function semaphore
def test_semaphore():
    """
    Test the function semaphore
    """
    # Set environment variables for CI_BRANCH and PULL_REQUEST_NUMBER
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "false"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    # Check to see if the function has detected semaphore and runs the checker
    if os.environ.get("SEMAPHORE") == "true":
        semaphore("master")
        print("Semaphore has successfully passed the checks")
    else:
        print("Semaphore did not detect the CI")



# Generated at 2022-06-21 20:35:30.347877
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os

# Generated at 2022-06-21 20:35:34.987391
# Unit test for function checker
def test_checker():
    def test_function():
        raise AssertionError()

    def test_function_ok():
        pass

    try:
        decorated = checker(test_function)
        decorated()
        assert False, "Should raise assertion error"
    except CiVerificationError:
        assert True

    decorated = checker(test_function_ok)
    assert decorated()

# Generated at 2022-06-21 20:35:42.832366
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    jenkins("master")
    os.environ["BRANCH_NAME"] = "other"
    try:
        jenkins("master")
        assert False
    except CiVerificationError:
        pass
    os.environ["CHANGE_ID"] = "1234"
    try:
        jenkins("master")
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:35:52.915197
# Unit test for function check
def test_check():
    # Check the master branch (default)
    # master branch is the default
    env_vars = {
        "CI_COMMIT_REF_NAME": "master",
        "GITLAB_CI": "true",
        "CHANGE_ID": ""
    }
    with AssertionError:
        # This should not raise an error
        check("master", env=env_vars)

    # Check a different branch
    env_vars = {
        "CI_COMMIT_REF_NAME": "master",
        "CHANGE_ID": "",
        "GITLAB_CI": "true"
    }
    with AssertionError:
        # This should not raise an error
        check("master", env=env_vars)

    # Check a different branch

# Generated at 2022-06-21 20:35:57.477737
# Unit test for function travis
def test_travis():
    try:
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        travis("master")
    except Exception as e:
        print(e)
        raise AssertionError("Something went wrong in travis test")



# Generated at 2022-06-21 20:36:05.246597
# Unit test for function frigg
def test_frigg():
    # Check that frigg can be used frigg
    assert frigg("master") is True
    # Check that frigg does not detect a pull-request
    os.environ["FRIGG_PULL_REQUEST"] = "42"
    try:
        frigg("master")
        pytest.fail("Frigg did not detect the pull-request")
    except CiVerificationError:
        pass
    finally:
        os.environ.pop("FRIGG_PULL_REQUEST")



# Generated at 2022-06-21 20:36:10.892368
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None

    check(branch="master")

    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        check(branch="master")
    except CiVerificationError:
        pass
    os.environ["BITBUCKET_BRANCH"] = "master"

    os.environ["BITBUCKET_PR_ID"] = "dummy"
    try:
        check(branch="master")
    except CiVerificationError:
        pass

    del os.environ["BITBUCKET_PR_ID"]
    del os.environ["BITBUCKET_BRANCH"]

# Generated at 2022-06-21 20:36:21.907057
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "jenkins"
    os.environ["BRANCH_NAME"] = "master"
    assert check() is None
    os.environ["BRANCH_NAME"] = "staging"
    assert check(branch="staging") is None
    os.environ["BRANCH_NAME"] = None
    os.environ["GIT_BRANCH"] = "master"
    assert check() is None
    os.environ["GIT_BRANCH"] = "staging"
    assert check(branch="staging") is None
    os.environ["CHANGE_ID"] = "pull_request_id"
    try:
        check()
    except CiVerificationError:
        os.environ.pop("CHANGE_ID", None)
   

# Generated at 2022-06-21 20:36:22.925630
# Unit test for function check
def test_check():
    try:
        check()
    except Exception as e:
        raise e

# Generated at 2022-06-21 20:36:34.629472
# Unit test for function bitbucket
def test_bitbucket():
    env = {
        "BITBUCKET_BRANCH": "master",
        "BITBUCKET_PR_ID": "false",
        "BITBUCKET_BUILD_NUMBER": "321",
    }
    bitbucket = checker(bitbucket)
    assert bitbucket(env=env, branch="master") is True

# Generated at 2022-06-21 20:36:39.436634
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-21 20:36:43.918033
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert travis('master')
    assert not travis('develop')
    assert not travis('dev')


# Generated at 2022-06-21 20:36:47.745567
# Unit test for function checker

# Generated at 2022-06-21 20:36:48.501118
# Unit test for function check
def test_check():
    assert(check())

# Generated at 2022-06-21 20:36:51.822298
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "http://localhost:8080"

    check()

# Generated at 2022-06-21 20:36:55.316075
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "release-1.0"
    assert jenkins("release-1.0")

# Generated at 2022-06-21 20:36:57.176197
# Unit test for function checker

# Generated at 2022-06-21 20:37:02.739700
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = "branch"
    os.environ['BITBUCKET_PR_ID'] = "123"
    try:
        bitbucket("branch")
        raise AssertionError("fail")
    except CiVerificationError:
        pass
    os.environ['BITBUCKET_PR_ID'] = ""
    bitbucket("branch")
    del os.environ['BITBUCKET_BRANCH']
    del os.environ['BITBUCKET_PR_ID']

# Generated at 2022-06-21 20:37:07.186974
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = "true"
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    check()



# Generated at 2022-06-21 20:37:22.152443
# Unit test for function travis
def test_travis():
    branch = 'master'
    os.environ["TRAVIS_BRANCH"] = branch
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check(branch)

# Generated at 2022-06-21 20:37:23.176505
# Unit test for function circle
def test_circle():
    assert circle("master") == True



# Generated at 2022-06-21 20:37:29.647369
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "test"
    os.environ["BRANCH_NAME"] = "test"
    os.environ["CHANGE_ID"] = "test"
    try:
        jenkins("test")
        assert False, "jenkins should have thrown an error"
    except AssertionError:
        assert True


# Generated at 2022-06-21 20:37:34.504621
# Unit test for function travis
def test_travis():
    try:
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        travis(os.environ["TRAVIS_BRANCH"])
    except CiVerificationError:
        assert False


# Generated at 2022-06-21 20:37:41.844785
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = 'master'
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket('master')
    except CiVerificationError:
        assert True

    os.environ["BITBUCKET_PR_ID"] = None
    try:
        bitbucket('master')
    except CiVerificationError:
        assert False


# Generated at 2022-06-21 20:37:45.009285
# Unit test for function checker
def test_checker():
    """
    Test the checker decorator
    """
    @checker
    def testing():
        assert False

    try:
        testing()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:37:47.902728
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    travis('master')


# Generated at 2022-06-21 20:37:52.099521
# Unit test for function frigg
def test_frigg():
    assert os.environ.get("FRIGG_BUILD_BRANCH") == "test"
    assert not os.environ.get("FRIGG_PULL_REQUEST")

    os.environ["FRIGG_BUILD_BRANCH"] = "test2"
    os.environ["FRIGG_PULL_REQUEST"] = "test"
    assert frigg(branch="test2") is False
    assert frigg(branch="test") is True

# Generated at 2022-06-21 20:37:57.993064
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    gitlab("master")
    assert os.getenv("GITLAB_CI") == "true"
    assert os.getenv("CI_COMMIT_REF_NAME") == "master"


# Generated at 2022-06-21 20:38:01.194283
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()



# Generated at 2022-06-21 20:38:26.672056
# Unit test for function bitbucket
def test_bitbucket():
    assert not bitbucket("master")


# Generated at 2022-06-21 20:38:38.928583
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "test_circle"
    os.environ["CI_PULL_REQUEST"] = None
    assert circle("test_circle") == True
    os.environ["CIRCLE_BRANCH"] = "wrong_branch"
    try:
        circle("test_circle")
        assert False
    except CiVerificationError:
        assert True
    os.environ["CIRCLE_BRANCH"] = "test_circle"
    os.environ["CI_PULL_REQUEST"] = "true"
    try:
        circle("test_circle")
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-21 20:38:44.404001
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"

    try:
        bitbucket("master")
    except CiVerificationError:
        assert False

    os.environ["BITBUCKET_BRANCH"] = "notmaster"
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        pass

    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        pass

    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]



# Generated at 2022-06-21 20:38:50.162441
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = None
    check("master")
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]



# Generated at 2022-06-21 20:38:53.670491
# Unit test for function circle
def test_circle():
    """
    Test that we are able to call the circle function, and 
    that we can assert an exception.
    """
    with pytest.raises(CiVerificationError):
        circle("master")
        

# Generated at 2022-06-21 20:38:55.503220
# Unit test for function check
def test_check():
    assert not check()


# Generated at 2022-06-21 20:38:58.273422
# Unit test for function travis
def test_travis():
    """
    Travis
    """
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()



# Generated at 2022-06-21 20:39:10.544117
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    checker(frigg)()
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]

    # Test for failed condition
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "123"

# Generated at 2022-06-21 20:39:13.693220
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    os.environ["TRAVIS_BRANCH"] = "develop"
    assert travis("master") == False
    os.environ["TRAVIS_BRANCH"] = "master"
    assert travis("master") == True


# Generated at 2022-06-21 20:39:16.747448
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("master")


# Generated at 2022-06-21 20:40:08.108136
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"]="master"
    os.environ["TRAVIS_PULL_REQUEST"]="false"
    assert travis("master")
    with pytest.raises(CiVerificationError):
        assert travis("develop")


# Generated at 2022-06-21 20:40:14.108764
# Unit test for function semaphore
def test_semaphore():
    """
    Test if all the necessary checks are passed for semaphore
    """
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("master")
    except CiVerificationError:
        assert False
    else:
        assert True

    try:
        semaphore("xyz")
    except CiVerificationError:
        assert True
    else:
        assert False

    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
    except CiVerificationError:
        assert True
    else:
        assert False

    del os

# Generated at 2022-06-21 20:40:22.808713
# Unit test for function frigg
def test_frigg():
    try:
        os.environ["FRIGG"] = "true"
        os.environ["FRIGG_BUILD_BRANCH"] = "master"
        os.environ["FRIGG_PULL_REQUEST"] = "false"
        frigg("master")
        assert True
    except Exception:
        assert False
    finally:
        del os.environ["FRIGG"]
        del os.environ["FRIGG_BUILD_BRANCH"]
        del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-21 20:40:23.395776
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket("master")



# Generated at 2022-06-21 20:40:27.843570
# Unit test for function gitlab
def test_gitlab():
    # Test pull request
    assert not gitlab("master")
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = "12"
    assert not gitlab("master")

    # Test success
    del os.environ["CI_MERGE_REQUEST_IID"]
    assert gitlab("master")

# Generated at 2022-06-21 20:40:37.242278
# Unit test for function bitbucket
def test_bitbucket():
    bitbucket("test_branch_name")
    # Test if the function will raise an error if env is incorrectly set.
    os.environ["BITBUCKET_BUILD_NUMBER"] = "true"
    os.environ["BITBUCKET_BRANCH"] = "test_branch_name"
    os.environ["BITBUCKET_PR_ID"] = "true"
    assert bitbucket("test_branch_name")
    os.environ["BITBUCKET_PR_ID"] = None
    assert bitbucket("test_branch_name")
    # Test if the function will raise an error if the "branch" is different than
    # the one set in the environment.
    os.environ["BITBUCKET_BRANCH"] = "not_test_branch_name"

# Generated at 2022-06-21 20:40:39.935169
# Unit test for function bitbucket
def test_bitbucket():
    assert checker(bitbucket)("bitbucket")
    assert not checker(bitbucket)("bit")



# Generated at 2022-06-21 20:40:42.840852
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_PROJECT_ID'] = None
    assert gitlab('master')

    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_PROJECT_ID'] = '5'
    assert gitlab('master')



# Generated at 2022-06-21 20:40:43.970462
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket('master')
    assert not bitbucket('release')


# Generated at 2022-06-21 20:40:49.351835
# Unit test for function gitlab
def test_gitlab():
    assert os.environ['GITLAB_CI'] is not None

    os.environ['CI_COMMIT_REF_NAME'] = "master"
    os.environ['CI_MERGE_REQUEST_IID'] = ""
    gitlab("master")

# Generated at 2022-06-21 20:42:35.870035
# Unit test for function travis
def test_travis():
    env_var = {
        "TRAVIS_BRANCH": "foo",
        "TRAVIS_PULL_REQUEST": "false"
    }
    os.environ = {**os.environ, **env_var}
    try:
        travis("foo")
    except CiVerificationError as e:
        raise AssertionError("Travis Checks failed")
    os.environ = {**os.environ, **{"TRAVIS_BRANCH": ""}}
    try:
        travis("foo")
        raise AssertionError("Travis Checks did not fail")
    except CiVerificationError as e:
        return


# Generated at 2022-06-21 20:42:47.764188
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '2'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ.pop('BITBUCKET_PR_ID', None)
    bitbucket('master')
    os.environ['BITBUCKET_BRANCH'] = 'develop'
    with pytest.raises(errors.CiVerificationError):
        bitbucket('master')
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = '2'
    with pytest.raises(errors.CiVerificationError):
        bitbucket('master')
    os.environ.pop('BITBUCKET_PR_ID', None)

# Generated at 2022-06-21 20:42:54.515631
# Unit test for function travis
def test_travis():
    """
    Test for the behavior of the travis checker.
    """
    os.environ["TRAVIS_BRANCH"] = 'test'
    os.environ["TRAVIS_PULL_REQUEST"] = 'false'

    assert travis(os.environ["TRAVIS_BRANCH"])
    assert not travis('master')
    assert not travis('')
    os.environ["TRAVIS_PULL_REQUEST"] = 'true'
    assert not travis(os.environ["TRAVIS_BRANCH"])
