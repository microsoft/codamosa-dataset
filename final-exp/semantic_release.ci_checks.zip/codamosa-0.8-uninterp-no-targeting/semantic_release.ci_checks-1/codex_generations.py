

# Generated at 2022-06-21 20:33:05.353472
# Unit test for function checker
def test_checker():
    """Unit test for function checker."""

    def assert_error_raised(error_type_class, func, *args, **kwargs):
        """Assert that an error is raised of a given type."""
        try:
            func(*args, **kwargs)
            assert False, "Expected error was not raised"
        except error_type_class:
            assert True

    # Test happy path

# Generated at 2022-06-21 20:33:13.845751
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = False
    assert check(branch='master') is True

    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = False
    assert check(branch='feature') is False
    os.environ['BITBUCKET_BRANCH'] = 'feature'
    os.environ['BITBUCKET_PR_ID'] = False
    assert check(branch='feature') is True

    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = 'pull/1'

# Generated at 2022-06-21 20:33:19.658230
# Unit test for function checker
def test_checker():
    """
    Test function checker, in case you change the checker function.
    """
    @checker
    def f():
        raise AssertionError

    try:
        f()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:33:30.966675
# Unit test for function bitbucket
def test_bitbucket():
    # All environment variables are set
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_REPO_OWNER'] = "semantic-release"
    os.environ['BITBUCKET_REPO_SLUG'] = "semantic-release"
    os.environ['BITBUCKET_BUILD_NUMBER'] = "1"
    os.environ['BITBUCKET_BUILD_NUMBER_1'] = "1"

    # All checks should pass
    assert bitbucket("master") is True
    assert bitbucket("release") is True

    # Reset the environment variables
    os.environ.pop('BITBUCKET_BRANCH')
    os.environ.pop('BITBUCKET_REPO_OWNER')
   

# Generated at 2022-06-21 20:33:35.145900
# Unit test for function checker
def test_checker():
    @checker
    def function(a: int, b: int):
        assert a == b

    function(5, 5)
    try:
        function(5, 6)
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Did not raise CiVerificationError")

# Generated at 2022-06-21 20:33:38.493842
# Unit test for function check
def test_check():
    assert check(branch="test_branch")


if __name__ == "__main__":
    check(branch="master")

# Generated at 2022-06-21 20:33:39.359450
# Unit test for function frigg
def test_frigg():
    assert frigg("master")

# Generated at 2022-06-21 20:33:40.213776
# Unit test for function check
def test_check():
    assert check("test_branch")

# Generated at 2022-06-21 20:33:48.420281
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg(branch="master")
    os.environ["FRIGG_BUILD_BRANCH"] = "dev"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg(branch="master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg(branch="master")
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-21 20:33:59.953831
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        True
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("dev")
    except CiVerificationError:
        True


# Generated at 2022-06-21 20:34:08.272455
# Unit test for function checker
def test_checker():
    @checker
    def func(branch):
        assert os.environ.get("TRAVIS") == "true"
        assert branch == "master"

    os.environ["TRAVIS"] = "true"
    func("master")



# Generated at 2022-06-21 20:34:09.246535
# Unit test for function semaphore
def test_semaphore():
    """
    Unit test for function semaphore.
    """
    assert not semaphore("master")

# Generated at 2022-06-21 20:34:15.574174
# Unit test for function semaphore
def test_semaphore():
    os.environ['SEMAPHORE'] = "true"
    os.environ['BRANCH_NAME'] = "master"
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = "passed"
    assert semaphore("master")
    os.environ['SEMAPHORE_THREAD_RESULT'] = "failed"
    assert semaphore("master") is False

# Generated at 2022-06-21 20:34:25.206123
# Unit test for function frigg
def test_frigg():
    # Function check should throw CiVerificationError if os.environ['FRIGG'] is not 'true'
    os.environ['FRIGG'] = 'true'
    assert check() == None
    os.environ['FRIGG'] = 'false'
    assert check() == None
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'test_branch'
    assert check('test_branch') == None
    assert check('test_branch_another') != None
    os.environ['FRIGG_PULL_REQUEST'] = 'true'
    assert check('test_branch') != None

# Generated at 2022-06-21 20:34:29.645288
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = 'master'
    os.environ["TRAVIS_PULL_REQUEST"] = 'false'
    travis("master")


# Generated at 2022-06-21 20:34:40.998580
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://myjenkins.com:443"
    os.environ["BRANCH_NAME"] = "feature/1"
    os.environ["CHANGE_ID"] = ""
    check("feature/1")

    os.environ["JENKINS_URL"] = "https://myjenkins.com:443"
    os.environ["GIT_BRANCH"] = "feature/1"
    os.environ["CHANGE_ID"] = ""
    check("feature/1")

    os.environ["JENKINS_URL"] = "https://myjenkins.com:443"
    os.environ["GIT_BRANCH"] = "develop"
    os.environ["CHANGE_ID"] = ""

# Generated at 2022-06-21 20:34:45.310417
# Unit test for function checker
def test_checker():
    def function_that_fails():
        assert False

    def function_that_passes():
        pass

    fail_check = checker(function_that_fails)
    pass_check = checker(function_that_passes)

    assert fail_check() == False
    assert pass_check() == True

# Generated at 2022-06-21 20:34:54.545251
# Unit test for function semaphore
def test_semaphore():
    def semaphore_wrapper(branch_name, pull_request_number,
                          thread_result,
                          expected_error):
        os.environ["BRANCH_NAME"] = branch_name
        os.environ["PULL_REQUEST_NUMBER"] = pull_request_number
        os.environ["SEMAPHORE_THREAD_RESULT"] = thread_result

        try:
            semaphore(branch_name)
        except CiVerificationError as e:
            assert expected_error in str(e)
        else:
            assert not expected_error

    semaphore_wrapper("master", None, "passed", "")
    semaphore_wrapper("master", None, "failed", "failed")

# Generated at 2022-06-21 20:34:58.909808
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "foo"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    check("master")



# Generated at 2022-06-21 20:35:06.084072
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for function bitbucket
    """
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    assert bitbucket("master") == True
    os.environ["BITBUCKET_BRANCH"] = "other_branch"
    try:
        bitbucket("master")
    except:
        assert True



# Generated at 2022-06-21 20:35:13.542704
# Unit test for function frigg
def test_frigg():
    assert frigg(branch="master")
    assert frigg(branch="test")

# Generated at 2022-06-21 20:35:22.150928
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")

    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("develop")

    # AssertionError
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 20:35:25.666165
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "true"
    circle("master")

# Generated at 2022-06-21 20:35:30.095673
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")


# Generated at 2022-06-21 20:35:40.729440
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test the function bitbucket.
    """
    # Test CASE1
    # GIVEN
    branch = "master"
    os.environ["BITBUCKET_BRANCH"] = branch
    os.environ["BITBUCKET_PR_ID"] = None

    # WHEN
    bitbucket(branch)

    # THEN
    # No exception should be raised

    # Test CASE2
    # GIVEN
    branch = "master"
    os.environ["BITBUCKET_BRANCH"] = branch
    os.environ["BITBUCKET_PR_ID"] = "1"

    # WHEN
    try:
        bitbucket(branch)

    # THEN
    # Should raise exception
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:35:41.370672
# Unit test for function check
def test_check():
    assert check() is None

# Generated at 2022-06-21 20:35:47.161731
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    assert os.environ['CI_COMMIT_REF_NAME'] == 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = "1"
    assert os.environ.get("CI_MERGE_REQUEST_ID") is not None



# Generated at 2022-06-21 20:35:54.169419
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "test"
    assert circle("test")
    assert not circle("master")
    del os.environ["CIRCLE_BRANCH"]
    assert not circle("master")
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "https://www.github.com/user/pulls"
    assert not circle("master")
    del os.environ["CI_PULL_REQUEST"]
    del os.environ["CIRCLECI"]

# Generated at 2022-06-21 20:36:06.151963
# Unit test for function check
def test_check():
    # Set environment variables
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    # Case 1: Check returns true
    try:
        check(branch="master")
    except CiVerificationError:
        raise AssertionError("Excessive checks in Travis CI")

    # Case 2: Check returns false
    try:
        check(branch="develop")
    except CiVerificationError:
        assert True
    else:
        raise AssertionError("Failed to catch improper branch in Travis CI")

    # Unset environment variables
    os.environ["TRAVIS"] = ""
    os.environ["TRAVIS_BRANCH"] = ""


# Generated at 2022-06-21 20:36:13.922964
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"

    try:
        frigg("master")
    except CiVerificationError as e:
        assert False, "frigg raised CiVerificationError unexpectedly"
    else:
        assert True



# Generated at 2022-06-21 20:36:24.708068
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["TRAVIS"] = "false"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""

    try:
        check()
    except CiVerificationError:
        assert False, "Frigg CI build should pass"



# Generated at 2022-06-21 20:36:35.449600
# Unit test for function semaphore
def test_semaphore():
    """
    Test the semaphore function.
    """

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")

    del os.environ["SEMAPHORE"]
    assert not semaphore("master")

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "develop"
    assert semaphore("master") == False

    del os.environ["BRANCH_NAME"]
    assert not semaphore("master")


# Generated at 2022-06-21 20:36:38.616366
# Unit test for function jenkins
def test_jenkins():
    os.environ['CI'] = True
    os.environ['JENKINS_URL'] = True
    os.environ['CHANGE_ID'] = None
    jenkins('master')

# Generated at 2022-06-21 20:36:42.627083
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert travis('master') is True


# Generated at 2022-06-21 20:36:45.451726
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    try:
        gitlab('master')
        assert True
    except Exception as e:
        assert False

# Generated at 2022-06-21 20:36:50.381694
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master")



# Generated at 2022-06-21 20:36:56.102945
# Unit test for function checker
def test_checker():
    def check_if_error(func):
        try:
            func()
            return False
        except CiVerificationError:
            return True
    @checker
    def check_true():
        assert True
    @checker
    def check_false():
        assert False
    assert not check_if_error(check_true)
    assert check_if_error(check_false)

# Generated at 2022-06-21 20:37:00.691025
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['CI_PULL_REQUEST'] = 'false'
    assert circle(branch='master')
    assert not circle(branch='develop')
    del os.environ['CIRCLECI']
    del os.environ['BRANCH_NAME']
    del os.environ['CI_PULL_REQUEST']


# Generated at 2022-06-21 20:37:11.709055
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["TRAVIS_BRANCH"] = "other"
    try:
        check()
        assert False
    except CiVerificationError:
        assert True
    del os.environ["TRAVIS"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()

# Generated at 2022-06-21 20:37:17.798824
# Unit test for function jenkins
def test_jenkins():
    """
    Test for function jenkins
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "test"
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["GIT_BRANCH"]
    del os.environ["JENKINS_URL"]



# Generated at 2022-06-21 20:37:36.323684
# Unit test for function frigg
def test_frigg():
    with os.environ.copy():
        os.environ['FRIGG'] = 'true'
        os.environ['FRIGG_BUILD_BRANCH'] = 'master'
        os.environ['FRIGG_PULL_REQUEST'] = '1'
        assert frigg('master') == False

    with os.environ.copy():
        os.environ['FRIGG'] = 'true'
        os.environ['FRIGG_BUILD_BRANCH'] = 'master'
        os.environ['FRIGG_PULL_REQUEST'] = ''
        assert frigg('master') == False

    with os.environ.copy():
        os.environ['FRIGG'] = 'true'

# Generated at 2022-06-21 20:37:42.388982
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    with pytest.raises(CiVerificationError):
        os.environ["TRAVIS_PULL_REQUEST"] = "true"
        travis("master")

test_travis()


# Generated at 2022-06-21 20:37:49.193310
# Unit test for function jenkins
def test_jenkins():
    test_env = {'BRANCH_NAME':'master',
                'GIT_BRANCH': None,
                'JENKINS_URL': 'http://test.com',
                'CHANGE_ID': '12345'}
    jenkins('master')
    assert 'BRANCH_NAME' in test_env.keys()
    assert 'GIT_BRANCH' in test_env.keys()
    assert 'JENKINS_URL' in test_env.keys()
    assert 'CHANGE_ID' in test_env.keys()

# Generated at 2022-06-21 20:37:50.196880
# Unit test for function semaphore
def test_semaphore():
    semaphore('testBranch')

# Generated at 2022-06-21 20:37:52.014543
# Unit test for function check
def test_check():
    try:
        check(branch='master')
    except CiVerificationError:
        pass
    else:
        print('should fail unit test', file=sys.stderr)
        assert 1 == 0

# Generated at 2022-06-21 20:38:01.692349
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        assert True
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        assert True
    del os.environ["BITBUCKET_BRANCH"]



# Generated at 2022-06-21 20:38:07.234226
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    circle("master")
    os.environ["CIRCLE_BRANCH"] = "1234"
    try:
        circle("master")
        assert False
    except CiVerificationError:
        pass
    del os.environ['CIRCLECI']
    try:
        circle("master")
        assert False
    except KeyError:
        pass



# Generated at 2022-06-21 20:38:16.055079
# Unit test for function check
def test_check():
    assert os.environ.get("TRAVIS") == "true"
    assert os.environ.get("SEMAPHORE") == "true"
    assert os.environ.get("FRIGG") == "true"
    assert os.environ.get("CIRCLECI") == "true"
    assert os.environ.get("GITLAB_CI") == "true"
    assert os.environ.get("JENKINS_URL") is not None
    assert "BITBUCKET_BUILD_NUMBER" in os.environ
    #assert os.environ.get("GIT_BRANCH") == "master"

# Generated at 2022-06-21 20:38:26.770848
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = 'test'
    os.environ['GIT_BRANCH'] = 'test'
    os.environ['CHANGE_ID'] = 'test'

    os.environ['JENKINS_URL'] = 'test'
    os.environ['GIT_BRANCH'] = 'test'
    os.environ['CHANGE_ID'] = ''

    os.environ['JENKINS_URL'] = 'test'
    os.environ['GIT_BRANCH'] = 'test'
    os.environ['CHANGE_ID'] = None

    os.environ['JENKINS_URL'] = 'test'
    os.environ['GIT_BRANCH'] = 'master'
    os.environ['CHANGE_ID']

# Generated at 2022-06-21 20:38:32.030659
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"

    bitbucket("master")
    assert os.environ["BITBUCKET_PR_ID"] is not None

# Generated at 2022-06-21 20:38:43.581805
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    # Should not raise CiVerificationError
    check("master")

    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "123"
    # Should raise CiVerificationError
    try:
        check()
        assert False, "CiVerificationError not raised"
    except CiVerificationError:
        assert True

    os.environ["CIRCLE_BRANCH"] = "develop"
    os.environ["CI_PULL_REQUEST"] = ""
    # Should raise CiVerificationError

# Generated at 2022-06-21 20:38:46.796865
# Unit test for function checker
def test_checker():
    @checker
    def should_pass():
        print("Checker is working")
    @checker
    def should_fail():
        assert 1 == 2

    should_pass()
    try:
        should_fail()
    except AssertionError:
        pass
    except CiVerificationError:
        return
    raise AssertionError("Checker should catch AssertionErrors")

# Generated at 2022-06-21 20:38:52.180565
# Unit test for function checker
def test_checker():
    @checker
    def check_fun(x):
        assert x == 3

    # should succeed
    check_fun(3)
    # should raise exception
    try:
        check_fun(4)
    except CiVerificationError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 20:38:55.376020
# Unit test for function semaphore
def test_semaphore():
    """
    CI Checks
    """
    assert os.environ.get("SEMAPHORE") == "true"
    semaphore("master")

# Generated at 2022-06-21 20:38:56.994657
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = None
    assert frigg('master') == True



# Generated at 2022-06-21 20:39:00.841265
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-21 20:39:08.250968
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = False

    #If the following two lines are uncommented a CIVerificationError is raised
    #os.environ["CI_COMMIT_REF_NAME"] = "other"
    #os.environ["CI_MERGE_REQUEST_ID"] = True

    gitlab("master")

# Generated at 2022-06-21 20:39:12.715701
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    os.environ['FRIGG_PULL_REQUEST'] = "false"
    frigg("master")
    assert "FRIGG" in os.environ


# Generated at 2022-06-21 20:39:16.088412
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    circle("master")
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]



# Generated at 2022-06-21 20:39:24.197501
# Unit test for function checker
def test_checker():
    """
    Test for the ``checker`` decorator
    """

    @checker
    def pass_function():
        """
        A function to decorate which passes
        """
        pass

    def fail_function():
        """
        A function to decorate which fails
        """
        raise AssertionError("Failed")

    failure = checker(fail_function)
    assert pass_function() is True
    try:
        failure()
    except CiVerificationError as error:
        assert str(error) == "The verification check for the environment did not pass."

# Generated at 2022-06-21 20:39:41.008972
# Unit test for function check
def test_check():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS"] = "true"

    check()
    del os.environ["TRAVIS_BRANCH"]
    os.environ["TRAVIS_PULL_REQUEST"] = "true"

    check()
    del os.environ["TRAVIS_PULL_REQUEST"]

    del os.environ["TRAVIS"]

    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    os.environ["SEMAPHORE"] = "true"

    check()

# Generated at 2022-06-21 20:39:53.856519
# Unit test for function check
def test_check():
    os.environ.clear()
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    os.environ.clear()
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()

    os.environ.clear()
    os.environ["FRIGG"] = "true"

# Generated at 2022-06-21 20:39:54.951982
# Unit test for function circle
def test_circle():
    circle('master')
    circle('develop')
    circle('release/v1.0.0')

# Generated at 2022-06-21 20:40:06.930296
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://my.jenkins.example/"
    os.environ["GIT_BRANCH"] = "master"
    try:
        jenkins("master")
        assert True
    except:
        assert False

    os.environ["GIT_BRANCH"] = "other-branch"
    try:
        jenkins("master")
        assert False
    except:
        assert True

    del os.environ["GIT_BRANCH"]
    os.environ["BRANCH_NAME"] = "master"
    try:
        jenkins("master")
        assert True
    except:
        assert False

    os.environ["BRANCH_NAME"] = "other-branch"

# Generated at 2022-06-21 20:40:10.607841
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    os.environ["SEMAPHORE"] = "true"
    check()



# Generated at 2022-06-21 20:40:14.624687
# Unit test for function gitlab
def test_gitlab():
    # setup
    env = {}
    env["CI_COMMIT_REF_NAME"] = "master"
    # test
    os.environ = env
    # verify
    checker(gitlab)("master")


# Generated at 2022-06-21 20:40:22.041320
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "random_build_number"
    os.environ["BITBUCKET_BRANCH"] = "random_branch"
    os.environ["BITBUCKET_PR_ID"] = "random_pr_id"
    assert bitbucket() == False

    del os.environ["BITBUCKET_PR_ID"]
    assert bitbucket() == True



# Generated at 2022-06-21 20:40:25.554738
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = 'abc'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_REPO_SLUG'] = 'caa-devs/semantic-release-test'
    os.environ['BITBUCKET_PR_ID'] = '123'
    bitbucket('master')


# Generated at 2022-06-21 20:40:34.086866
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = 'master'
    os.environ["FRIGG_PULL_REQUEST"] = '20'
    assert frigg('master')
    # True because its not correct branch as 20 would be a PR
    # and were only interested in master
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]



# Generated at 2022-06-21 20:40:41.494025
# Unit test for function semaphore
def test_semaphore():
    import sys
    try:
        semaphore("master")
        assert False
    except CiVerificationError:
        assert True
        print("Expected exception was raised")
    except AssertionError:
        assert False
        print("Unexpected AssertionError occurred")
    except:
        print("Unexpected exception occurred type: " + sys.exc_info()[0])
        assert False
    print("Test Successful")

# Generated at 2022-06-21 20:40:53.291949
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["GITLAB_CI"] = "true"
    check()
    assert True

# Generated at 2022-06-21 20:40:55.431429
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert gitlab("master")


# Generated at 2022-06-21 20:41:05.031738
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "url"
    os.environ["BRANCH_NAME"] = "master"
    jenkins("master")
    os.environ["CHANGE_ID"] = "id"
    assert jenkins("master") == False
    assert os.environ["CHANGE_ID"] == "id"
    os.environ["CHANGE_ID"] = None
    os.environ["BRANCH_NAME"] = "other"
    assert jenkins("master") == False
    assert os.environ["BRANCH_NAME"] == "other"
    os.environ["BRANCH_NAME"] = "master"

if __name__ == "__main__" :
    test_jenkins()

# Generated at 2022-06-21 20:41:09.397930
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "branch_name"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("branch_name")
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:41:13.842250
# Unit test for function checker
def test_checker():
    @checker
    def function_assert(value: str):
        assert value == "123"

    assert function_assert("123") is True

    @checker
    def function_assert_failed(value: str):
        assert value == "456"

    try:
        function_assert_failed("456")
    except CiVerificationError as e:
        assert e.args[0] == "The verification check for the environment did not pass."

# Generated at 2022-06-21 20:41:18.656227
# Unit test for function checker
def test_checker():
    from semantic_release.errors import CiVerificationError

    @checker
    def func():
        assert False

    try:
        func()
        assert False
    except CiVerificationError as e:
        assert "The verification check for the environment did not pass." in str(e)

# Generated at 2022-06-21 20:41:21.563275
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_COMMIT_REF_SLUG"] = "master"
    check("master")

# Generated at 2022-06-21 20:41:33.982337
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert check()

    os.environ["TRAVIS_BRANCH"] = "develop"
    assert check("develop")
    assert check(branch="develop")

    os.environ["TRAVIS"] = "false"
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert check()

    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    assert check("develop")

    os.environ["FRIGG"] = "false"
    os

# Generated at 2022-06-21 20:41:38.546187
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master") == True
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-21 20:41:40.791374
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")
    assert True

# Generated at 2022-06-21 20:41:57.326695
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test_branch"
    assert frigg("test_branch")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        frigg("test_branch")
    except CiVerificationError:
        assert True
    finally:
        os.environ["FRIGG_PULL_REQUEST"] = "false"


# We assume that all continuous integration environments have some kind
# of environment variable set to indicate that we are running in that
# environment.  So we test all functions to see if they throw an exception
# when we set an environment variable for the CI environment and then unset
# the environment variable for the CI environment.
#
# All exceptions raised

# Generated at 2022-06-21 20:42:04.916474
# Unit test for function checker
def test_checker():
    """
    Loads a function `func` that raises AssertionError when called
    and checks that it raises CiVerificationError when called.
    """

    @checker
    def func():
        assert False

    try:
        func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should raise CiVerificationError")

# Generated at 2022-06-21 20:42:12.940668
# Unit test for function semaphore
def test_semaphore():
    # test the pass scenario
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'success'
    assert semaphore('master') == True


    # test the fail scenario
    os.environ['BRANCH_NAME'] = 'staging'
    os.environ['PULL_REQUEST_NUMBER'] = '123'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'
    assert semaphore('master') == False



# Generated at 2022-06-21 20:42:18.801867
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "none"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") is True
    del os.environ["BRANCH_NAME"]
    assert semaphore("master") is False
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    assert semaphore("master") is False
    del os.environ["PULL_REQUEST_NUMBER"]
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master") is False
    del os.en

# Generated at 2022-06-21 20:42:29.143680
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "True"
    os.environ["FRIGG_BUILD_BRANCH"] = "Develop"
    os.environ["FRIGG_PULL_REQUEST"] = "True"
    assert frigg("Develop") == True

    os.environ["FRIGG_BUILD_BRANCH"] = "Master"
    os.environ["FRIGG_PULL_REQUEST"] = "False"
    assert frigg("Master") == True

    os.environ["FRIGG_BUILD_BRANCH"] = "Develop"
    os.environ["FRIGG_PULL_REQUEST"] = "False"
    assert frigg("Master") != True

    os.environ["FRIGG_BUILD_BRANCH"] = "Master"

# Generated at 2022-06-21 20:42:35.329091
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://my.jenkins.net"
    os.environ["CI_COMMIT_REF_NAME"] = "master"

    with pytest.raises(CiVerificationError):
        jenkins(branch="develop")

    with pytest.raises(CiVerificationError):
        jenkins(branch="master")

    os.environ["CHANGE_ID"] = "123"

    with pytest.raises(CiVerificationError):
        jenkins(branch="master")

    del os.environ["CHANGE_ID"]
    os.environ["CI_COMMIT_REF_NAME"] = "master"

    jenkins(branch="master")

    del os.environ["JENKINS_URL"]

   

# Generated at 2022-06-21 20:42:39.583994
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert (travis('master') == True)


# Generated at 2022-06-21 20:42:48.585696
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_TARGET_BRANCH_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_IID'] = '123'
    test_check = check(branch="master")
    assert test_check is None
    # clean
    del os.environ['CI_COMMIT_REF_NAME']
    del os.environ['CI_MERGE_REQUEST_TARGET_BRANCH_NAME']
    del os.environ['CI_MERGE_REQUEST_IID']



# Generated at 2022-06-21 20:42:52.923674
# Unit test for function frigg
def test_frigg():
    """
    Tests that the frigg checker passes as expected.
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = None
    frigg()

