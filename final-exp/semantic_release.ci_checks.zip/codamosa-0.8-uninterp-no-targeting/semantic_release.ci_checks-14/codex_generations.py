

# Generated at 2022-06-21 20:33:02.107661
# Unit test for function checker
def test_checker():
    @checker
    def passfunction():
        pass

    passfunction()
    try:
        @checker
        def failfunction():
            raise AssertionError()

        failfunction()
    except CiVerificationError:
        pass



# Generated at 2022-06-21 20:33:06.794126
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER']='100'
    os.environ['BITBUCKET_BRANCH']='master'
    os.environ['BITBUCKET_PR_ID']=None

    bitbucket('master')


# Generated at 2022-06-21 20:33:14.596571
# Unit test for function bitbucket
def test_bitbucket():
    if "BITBUCKET_BRANCH" in os.environ:
        del os.environ["BITBUCKET_BRANCH"]
    if "BITBUCKET_PR_ID" in os.environ:
        del os.environ["BITBUCKET_PR_ID"]
    if "BITBUCKET_BUILD_NUMBER" in os.environ:
        del os.environ["BITBUCKET_BUILD_NUMBER"]
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    assert bitbucket("master") is True
    del os.environ["BITBUCKET_BRANCH"]
    with pytest.raises(CiVerificationError):
        bit

# Generated at 2022-06-21 20:33:20.251267
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://ci.jenkins.io"
    os.environ["BRANCH_NAME"] = "branch"
    os.environ["CHANGE_ID"] = "123"
    jenkins("branch")

# Generated at 2022-06-21 20:33:30.968045
# Unit test for function frigg
def test_frigg():
    # should not raise an exception
    assert frigg('master')

    os.environ['FRIGG_BUILD_BRANCH'] = 'develop'
    # should raise an exception as the build is not on master
    try:
        frigg('master')
    except AssertionError:
        pass
    else:
        raise AssertionError('frigg should have raised an exception')

    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    # should raise an exception as the build is not master
    try:
        frigg('develop')
    except AssertionError:
        pass
    else:
        raise AssertionError('frigg should have raised an exception')

    del os.environ['FRIGG_BUILD_BRANCH']
    # should raise an exception as

# Generated at 2022-06-21 20:33:33.181788
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    gitlab('master')



# Generated at 2022-06-21 20:33:41.975125
# Unit test for function gitlab
def test_gitlab():
    assert gitlab.__doc__ is not None
    assert gitlab.__name__ == "gitlab"
    assert gitlab.__qualname__ == "gitlab"
    # setting the environment variable BITBUCKET_BUILD_NUMBER=1
    # in the shell command would cause the function bitbucket to execute
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_PR_ID"] = "1"
    bitbucket("Branch")

# Generated at 2022-06-21 20:33:43.860488
# Unit test for function travis
def test_travis():
    assert travis(branch="master") is True


# Generated at 2022-06-21 20:33:47.098658
# Unit test for function checker
def test_checker():
    def test_func():
        assert 1 == 2

    def test_func_noexception():
        assert 1 == 1

    assert not checker(test_func)()
    assert checker(test_func_noexception)()

# Generated at 2022-06-21 20:33:48.453592
# Unit test for function circle
def test_circle():
    
    assert not hasattr(circle, "__name__")
    assert hasattr(circle, "__call__")

# Generated at 2022-06-21 20:34:00.722249
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "true"
    with pytest.raises(CiVerificationError):
        check()

    del os.environ["CI_PULL_REQUEST"]
    check()


# Generated at 2022-06-21 20:34:10.930994
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for bitbucket checker.
    """
    print("Checking dummy bitbucket env.")
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")
    print("Checking dummy bitbucket env with PR.")
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
        raise
    except CiVerificationError:
        print("Bitbucket PR detection is working.")
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]



# Generated at 2022-06-21 20:34:14.654461
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle("master") == True
    os.environ["CIRCLE_BRANCH"] = "develop"
    assert circle("master") == False


# Generated at 2022-06-21 20:34:18.068788
# Unit test for function bitbucket
def test_bitbucket():
    # Set valid environment variables
    os.environ["BITBUCKET_BRANCH"] = "test"
    os.environ["BITBUCKET_PR_ID"] = ""

    # Test function without error
    assert bitbucket("test") is True



# Generated at 2022-06-21 20:34:23.271683
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = ""
    check()
    try:
        os.environ["CI_COMMIT_REF_NAME"] = "develop"
        check()
    except CiVerificationError:
        return True

# Generated at 2022-06-21 20:34:30.295265
# Unit test for function jenkins
def test_jenkins():
    # The test should succeed.
    os.environ["JENKINS_URL"] = "https://not.a.valid.url"
    os.environ["BRANCH_NAME"] = "master"
    check()
    # The test should fail
    os.environ["BRANCH_NAME"] = "other"
    try:
        check()
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:34:31.453165
# Unit test for function gitlab
def test_gitlab():
    assert gitlab("dev")



# Generated at 2022-06-21 20:34:34.670429
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-21 20:34:46.035276
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = ""
    os.environ["CIRCLE_BRANCH"] = "develop"
    check("develop")
    os.environ["CI_PULL_REQUEST"] = "PR1"
    try:
        check("develop")
    except CiVerificationError:
        os.environ.pop("CI_PULL_REQUEST")
        os.environ.pop("CIRCLE_BRANCH")
        os.environ.pop("CIRCLECI")
        return True
    else:
        os.environ.pop("CI_PULL_REQUEST")
        os.environ.pop("CIRCLE_BRANCH")
        os.environ.pop("CIRCLECI")

# Generated at 2022-06-21 20:34:54.848864
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    circle(branch="master")

    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "develop"
    try:
        circle(branch="master")
    except CiVerificationError:
        return
    assert False

    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "true"
    try:
        circle(branch="master")
    except CiVerificationError:
        return
    assert False

    # Clean environment
    del os.en

# Generated at 2022-06-21 20:35:09.277920
# Unit test for function check
def test_check():
    """
    Tests the check function in ci.py.
    """
    # TODO
    pass

# Generated at 2022-06-21 20:35:11.913050
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    check()

# Generated at 2022-06-21 20:35:20.684394
# Unit test for function checker
def test_checker():
    def assert_true():
        assert True
    try:
        assert_true = checker(assert_true)()
    except CiVerificationError as e:
        assert False, "CiVerificationError should not be thrown : {}".format(e)

    def assert_false():
        assert False
    try:
        assert_false = checker(assert_false)()
    except CiVerificationError as e:
        assert True, "CiVerificationError should be thrown : {}".format(e)
    else:
        assert False, "CiVerificationError should be thrown"


if __name__ == '__main__':
    import sys
    import nose

    sys.exit(nose.main())

# Generated at 2022-06-21 20:35:26.176861
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = 'https://cicd.example.com'
    os.environ[
        'GIT_BRANCH'] = 'master'

    assert jenkins('master') == True

    # Test the branch name is not equal
    os.environ[
        'GIT_BRANCH'] = 'develop'
    jenkins('master')



# Generated at 2022-06-21 20:35:36.470060
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    os.environ["BRANCH_NAME"] = "master"

    ## Check success
    semaphore("master")

    ## Check failure
    caught = False
    try:
        semaphore("devel")
    except CiVerificationError:
        caught = True
    assert caught

    ## Check failure
    caught = False
    os.environ["PULL_REQUEST_NUMBER"] = '15'
    try:
        semaphore("master")
    except CiVerificationError:
        caught = True
    assert caught



# Generated at 2022-06-21 20:35:45.620326
# Unit test for function bitbucket
def test_bitbucket():
    # set envrironment variable
    os.environ['BITBUCKET_BUILD_NUMBER'] = "1"
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_PR_ID'] = ""
    # call the function
    bitbucket("master")
    # remove envrironment variable
    del os.environ['BITBUCKET_BUILD_NUMBER']
    del os.environ['BITBUCKET_BRANCH']
    del os.environ['BITBUCKET_PR_ID']

# Generated at 2022-06-21 20:35:48.624863
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = None
    check()
    assert True



# Generated at 2022-06-21 20:35:53.279925
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "12"
    assert bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "master"
    del os.environ["BITBUCKET_PR_ID"]
    assert bitbucket("master")
    os.environ["BITBUCKET_PR_ID"] = "12"
    assert bitbucket("master") is False

# Generated at 2022-06-21 20:36:04.920565
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]
    try:
        check()
        assert False
    except CiVerificationError:
        pass
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "12345"
    try:
        check()
        assert False
    except CiVerificationError:
        pass
    del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-21 20:36:08.417968
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://github.com/relekang/semantic-release-cli"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = None # pull request id

    jenkins("master")

# Generated at 2022-06-21 20:36:45.334631
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    gitlab("master")
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    try:
        gitlab("master")
    except CiVerificationError:
        pass
    else:
        raise Exception("gitlab(\"master\") should have thrown an exception")
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["GITLAB_CI"]
    del os.environ["CI_MERGE_REQUEST_ID"]

# Generated at 2022-06-21 20:36:53.476403
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test_branch"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    check("test_branch")
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]
    del os.environ["FRIGG"]


# Generated at 2022-06-21 20:36:59.103349
# Unit test for function jenkins
def test_jenkins():
    checker(jenkins)("test")

    os.environ["JENKINS_URL"] = "https://some.url"
    os.environ["BRANCH_NAME"] = "test"
    os.environ["GIT_BRANCH"] = "test"
    os.environ["CHANGE_ID"] = "123"
    try:
        checker(jenkins)("test")
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:37:01.790237
# Unit test for function checker
def test_checker():
    def f(x):
        assert x == 1

    f2 = checker(f)
    f2(1)

    try:
        f2(2)
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-21 20:37:05.214427
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-21 20:37:10.384573
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = 'https://github.com/'
    os.environ['BRANCH_NAME'] = 'master'
    #os.environ['GIT_BRANCH'] = 'master'
    os.environ['CHANGE_ID'] = '' # pull request id
    check()


# Generated at 2022-06-21 20:37:16.587373
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "55"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        bitbucket("master")
    except CiVerificationError as exc:
        assert str(exc) == "The verification check for the environment did not pass."
    else:
        raise Exception("This should have failed")



# Generated at 2022-06-21 20:37:17.758483
# Unit test for function semaphore
def test_semaphore():
    assert semaphore(branch="master")


# Generated at 2022-06-21 20:37:21.824559
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://jenkins"
    os.environ["BRANCH_NAME"] = os.environ["GIT_BRANCH"] = "master"
    check()

# Generated at 2022-06-21 20:37:33.692614
# Unit test for function frigg
def test_frigg():
    # Making sure the checks are performed
    branch = "master"
    os.environ["BRANCH_NAME"] = branch
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "succeeded"
    semaphore(branch)
    os.environ["TRAVIS_BRANCH"] = branch
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch)
    os.environ["FRIGG_BUILD_BRANCH"] = branch
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg(branch)
    os.environ["CIRCLE_BRANCH"] = branch
    os.en

# Generated at 2022-06-21 20:38:27.027609
# Unit test for function circle
def test_circle():
    assert circle("master")
    assert circle("release")
    assert circle("release/2.4.6")



# Generated at 2022-06-21 20:38:39.365934
# Unit test for function frigg
def test_frigg():
    # Non-release build
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "1"
    try:
        frigg("master")
        assert False
    except CiVerificationError:
        pass
    os.environ["FRIGG_PULL_REQUEST"] = ""
    frigg("master")
    try:
        frigg("test")
        assert False
    except CiVerificationError:
        pass
    # Release build
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    os.environ["FRIGG_PULL_REQUEST"] = "1"

# Generated at 2022-06-21 20:38:44.979687
# Unit test for function circle
def test_circle():
    """
    Test for the circle function.
    """
    os.environ["CIRCLECI"] = 'true'
    os.environ["CIRCLE_BRANCH"] = 'test'
    os.environ["CI_PULL_REQUEST"] = 'false'
    assert circle('test') is True
    os.environ["CI_PULL_REQUEST"] = 'true'
    try:
        circle('test')
        assert False
    except CiVerificationError:
        assert True

    os.environ["CIRCLE_BRANCH"] = 'wrong_branch'
    try:
        circle('test')
        assert False
    except CiVerificationError:
        assert True
    os.environ["CIRCLECI"] = 'false'



# Generated at 2022-06-21 20:38:50.831369
# Unit test for function travis
def test_travis():
    with os.environ.copy():
        os.environ.update({
            'TRAVIS_BRANCH': os.environ.get('TRAVIS_BRANCH') or 'master',
            'TRAVIS_PULL_REQUEST': os.environ.get('TRAVIS_PULL_REQUEST') or 'false'
        })
        travis(branch="master")


# Generated at 2022-06-21 20:38:55.547845
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    os.environ["BRANCH_NAME"] = "master"
    semaphore("master")
    check()

# Generated at 2022-06-21 20:39:01.512872
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "12345"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Expected CiVerificationError")
    del os.environ["PULL_REQUEST_NUMBER"]
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Expected CiVerificationError")
    del os.environ["SEMAPHORE_THREAD_RESULT"]

# Generated at 2022-06-21 20:39:04.958525
# Unit test for function circle
def test_circle():
    assert circle(branch="master") == True
    assert circle(branch="not_master") == False



# Generated at 2022-06-21 20:39:11.548066
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    test_bitbucket()
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]
    del os.environ["BITBUCKET_BUILD_NUMBER"]
    assert True

# Generated at 2022-06-21 20:39:14.942964
# Unit test for function check
def test_check():
    check("master")
    os.environ["GITLAB_CI"]="master"
    with pytest.raises(CiVerificationError):
        check("test")
    os.environ["GITLAB_CI"]=""
    assert check("test") is None

# Generated at 2022-06-21 20:39:17.166441
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    ret = travis("master")
    assert ret


# Generated at 2022-06-21 20:41:09.550951
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG_BUILD_BRANCH"] = "featureBranch"
    os.environ["FRIGG_PULL_REQUEST"] = "4"
    with pytest.raises(CiVerificationError):
        check("master")
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-21 20:41:16.337024
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    try:
        check()
        assert True
    except CiVerificationError:
        assert False
    finally:
        del os.environ["BRANCH_NAME"]
        del os.environ["PULL_REQUEST_NUMBER"]
        del os.environ["SEMAPHORE_THREAD_RESULT"]



# Generated at 2022-06-21 20:41:22.852450
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    assert frigg('master') is True, 'It should return True'
    os.environ['FRIGG'] = "false"
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    assert frigg('master') is False, 'It should return False'



# Generated at 2022-06-21 20:41:28.312791
# Unit test for function checker
def test_checker():
    def f_true():
        assert True
    def f_raise():
        assert False
    @checker
    def f_true_checked():
        f_true()
    @checker
    def f_raise_checked():
        f_raise()

    # This function should pass
    assert f_true_checked()

    # This function should raise a CiVerificationError
    try:
        f_raise_checked()
    except CiVerificationError:
        pass
    else:
        assert False, "The assertion error did not raise to a CiVerificationError"


# Generated at 2022-06-21 20:41:34.342639
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "something"
    os.environ["BRANCH_NAME"] = "master"
    try:
        jenkins("master")
        assert True
    except Exception as err:
        assert False, err

# Generated at 2022-06-21 20:41:37.450369
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    del os.environ["CI_PULL_REQUEST"]
    check()


# Generated at 2022-06-21 20:41:44.964027
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = False
    assert frigg("master") == True
    os.environ["FRIGG_PULL_REQUEST"] = True
    try:
        frigg("master")
    except CiVerificationError:
        assert True
    except:
        assert False
    finally:
        os.environ.pop("FRIGG")
        os.environ.pop("FRIGG_BUILD_BRANCH")
        os.environ.pop("FRIGG_PULL_REQUEST")



# Generated at 2022-06-21 20:41:50.480938
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    gitlab("master")
    with pytest.raises(CiVerificationError):
        gitlab("dev")
    os.environ['CI_COMMIT_REF_NAME'] = "1"
    with pytest.raises(CiVerificationError):
        gitlab("dev")


# Generated at 2022-06-21 20:41:58.236725
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = "1"
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_PR_ID'] = ""
    check()
    del os.environ['BITBUCKET_BUILD_NUMBER']
    del os.environ['BITBUCKET_BRANCH']
    del os.environ['BITBUCKET_PR_ID']
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_PR_ID'] = "23"
    check()
    del os.environ['BITBUCKET_BRANCH']
    del os.environ['BITBUCKET_PR_ID']


# Unit test

# Generated at 2022-06-21 20:42:03.721323
# Unit test for function frigg
def test_frigg():
    """
    Unit test for the frigg checker.
    """
    import os
    assert os.environ.get(
        "FRIGG_BUILD_BRANCH") is None, "Enviroment variable FRIGG_BUILD_BRANCH must be unset."
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    assert os.environ.get("FRIGG") is None, "Enviroment variable FRIGG must be unset."