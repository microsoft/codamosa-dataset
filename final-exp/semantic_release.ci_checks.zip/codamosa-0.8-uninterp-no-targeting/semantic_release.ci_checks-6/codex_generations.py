

# Generated at 2022-06-21 20:33:02.199817
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_BUILD_ID"] = "1234"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    assert frigg("master")

# Generated at 2022-06-21 20:33:09.637829
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    assert os.environ["BRANCH_NAME"] == "master"
    assert os.environ["PULL_REQUEST_NUMBER"] == None
    assert os.environ["SEMAPHORE_THREAD_RESULT"] == "passed"


# Generated at 2022-06-21 20:33:16.235583
# Unit test for function check
def test_check():
    """
    Unit tests to make sure check function works correctly.
    """
    ci_runner = "jenkins"

    branch = "master"

    # Return True only if jenkins environment detected
    if ci_runner == "jenkins":
        os.environ["JENKINS_URL"] = "hello world"
        os.environ["GIT_BRANCH"] = branch
        os.environ["CHANGE_ID"] = ""
        assert check(branch)
    else:
        assert not check(branch)

    # Return False if jenkins environment detected but branch is not master
    if ci_runner == "jenkins":
        os.environ["JENKINS_URL"] = "hello world"
        os.environ["GIT_BRANCH"] = "not master"

# Generated at 2022-06-21 20:33:27.387663
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS_BRANCH"] = "master"
    check()

    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
    except CiVerificationError:
        pass

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()

    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"


# Generated at 2022-06-21 20:33:32.937167
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check("master")
    os.environ["CI_COMMIT_REF_NAME"] = "dev"
    check("master")

# Generated at 2022-06-21 20:33:45.945598
# Unit test for function frigg
def test_frigg():
    """
    Verifies that the frigg checker is working correctly by creating a
    custom os.environ dictionary to simulate a frigg environment.
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]

    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"

# Generated at 2022-06-21 20:33:49.056810
# Unit test for function checker
def test_checker():
    """
    The decorator checker should convert AssertionErrors into CiVerificationError.
    """
    @checker
    def func():
        raise AssertionError()

    try:
        func()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:33:54.665655
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'some-branch'
    os.environ['CI_PULL_REQUEST'] = ''
    assert circle('some-branch')


# Generated at 2022-06-21 20:34:00.418098
# Unit test for function checker
def test_checker():
    """
    Tests the checker decorator by applying it to
    a function that raises an AssertionError and
    seeing if it raises properly.
    """
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        return
    raise Exception("Expected a CiVerificationError")

# Generated at 2022-06-21 20:34:01.590641
# Unit test for function gitlab
def test_gitlab():
    assert gitlab("master") == True

# Generated at 2022-06-21 20:34:08.303500
# Unit test for function check
def test_check():
    assert check() == True

# Generated at 2022-06-21 20:34:16.263296
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""

    assert bitbucket("master")

    os.environ["BITBUCKET_BRANCH"] = "develop"
    assert bitbucket("master")

    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123"

    assert bitbucket("master")



# Generated at 2022-06-21 20:34:20.000990
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    check()



# Generated at 2022-06-21 20:34:23.271111
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    assert bitbucket("master")

# Generated at 2022-06-21 20:34:35.397417
# Unit test for function checker
def test_checker():
    @checker
    def test_func(branch: str = "master"):
        """
        Perform dummy checks to ensure that the test is run on the correct environment.
        :param branch: The branch that should be the current branch.
        """

        assert "CI" in os.environ
        assert os.environ.get("BRANCH_NAME") == branch

    os.environ["CI"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    test_func()

    # Test function with wrong branch
    os.environ["BRANCH_NAME"] = "master2"

# Generated at 2022-06-21 20:34:43.402232
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    
    try:
        travis('master')
    except Exception as e:
        assert type(e) == CiVerificationError
    

    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    
    try:
        travis('master')
    except Exception as e:
        assert type(e) == None


# Generated at 2022-06-21 20:34:45.954696
# Unit test for function checker
def test_checker():
    """
    Test that the checker function will wrap it's function
    and convert AssertionError to CiVerificationError
    """

    @checker
    def wrong_assert():
        assert False

    # Check we get a CiVerificationError on assertion failure
    try:
        wrong_assert()
    except CiVerificationError:
        pass
    else:
        assert False, "Did not raise error on assert"

# Generated at 2022-06-21 20:34:53.340828
# Unit test for function jenkins
def test_jenkins():
    """
    Unit test for method jenkins
    """
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["GIT_BRANCH"] = "feature"
    try:
        jenkins("feature")
    except CiVerificationError:
        raise AssertionError("Not expected")
    try:
        jenkins("develop")
    except CiVerificationError as cive:
        print(cive)
    try:
        jenkins("master")
    except CiVerificationError as cive:
        print(cive)



# Generated at 2022-06-21 20:34:55.707218
# Unit test for function checker
def test_checker():
    def function():
        assert False

    try:
        checker(function)()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should have raised CiVerificationError")


# Generated at 2022-06-21 20:34:59.702292
# Unit test for function travis
def test_travis():
    import os
    os.environ.setdefault('TRAVIS_BRANCH', 'master')
    os.environ.setdefault('TRAVIS_PULL_REQUEST', 'false')
    assert check() == True


# Generated at 2022-06-21 20:35:09.768947
# Unit test for function checker
def test_checker():
    @checker
    def test_function():
        raise AssertionError()

    try:
        test_function()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:35:10.922554
# Unit test for function semaphore
def test_semaphore():
	assert check() == True
	assert check() != None

# Generated at 2022-06-21 20:35:17.794824
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]



# Generated at 2022-06-21 20:35:22.932105
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'test'
    os.environ['GITLAB_CI'] = 'true'
    check()
    os.environ['CI_COMMIT_REF_NAME'] = 'something-else'
    try:
        check()
    except CiVerificationError:
        os.environ.pop('CI_COMMIT_REF_NAME')
        os.environ.pop('GITLAB_CI')
        return
    assert False

# Generated at 2022-06-21 20:35:33.590551
# Unit test for function semaphore
def test_semaphore():
    """
    Test the semaphore checker
    """
    # AssertionError should be caught by checker

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    assert semaphore()

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"

    assert not semaphore()


# Generated at 2022-06-21 20:35:37.222358
# Unit test for function checker
def test_checker():
    def func():
        raise AssertionError("Assertion message")

    @checker
    def func_wrapper():
        func()

    try:
        func_wrapper()
    except CiVerificationError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 20:35:42.447776
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert check("master")

# Generated at 2022-06-21 20:35:52.602585
# Unit test for function check
def test_check():
    """ Unit test for function check
    """
    # Travis
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check(branch="master")

    # Semaphore
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = ""
    check(branch="master")

    # Frigg
    os.environ["FRIGG"] = "true"

# Generated at 2022-06-21 20:35:55.423150
# Unit test for function checker
def test_checker():
    """
    Tests the checker function
    """
    @checker
    def fail_check():  # type: ignore
        assert False
    @checker
    def pass_check():  # type: ignore
        assert True
    try:
        fail_check()
        assert False
    except CiVerificationError:
        pass
    assert pass_check()

# Generated at 2022-06-21 20:36:07.367151
# Unit test for function check
def test_check():
    """
    Testing function check to ensure:
        - Checks are performed correctly
        - Checks are not performed in the wrong scenario
        - CIVerificationError is correctly raised
    """
    from semantic_release.errors import CiVerificationError
    from unittest.mock import patch

    # Check does not raise any exceptions
    # when no CI-environment is detected.
    # This should be the case for testing on
    # developers desktops
    try:
        check()
    except CiVerificationError:
        raise Exception("A CIVerificationError was raised even though no CI-environment was detected")

    # Mock os.environ for test

# Generated at 2022-06-21 20:36:19.131528
# Unit test for function jenkins
def test_jenkins():
    assert not jenkins("master")
    os.environ.setdefault("BRANCH_NAME", "master")
    assert jenkins("master")
    assert not jenkins("branch")
    os.environ.setdefault("CHANGE_ID", "1")
    assert not jenkins("master")

# Generated at 2022-06-21 20:36:23.253462
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    travis('master')
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "true"
    pass


# Generated at 2022-06-21 20:36:25.321003
# Unit test for function gitlab
def test_gitlab():
    assert os.environ.get("GITLAB_CI") == "true"
    assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
    # TODO - don't think there's a merge request indicator variable

# Generated at 2022-06-21 20:36:28.963857
# Unit test for function gitlab
def test_gitlab():
    ## Setup a test environment
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None

    check("master")

# Generated at 2022-06-21 20:36:34.008920
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]

# Generated at 2022-06-21 20:36:37.337378
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-21 20:36:39.485782
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    checker(gitlab)(branch="master")


# Generated at 2022-06-21 20:36:44.513037
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '138'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = ''
    branch = 'master'
    assert bitbucket(branch)



# Generated at 2022-06-21 20:36:49.369095
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    check()
    try:
        check(branch="develop")
    except CiVerificationError:
        pass



# Generated at 2022-06-21 20:36:59.195314
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    timestamp = os.environ.get('TRAVIS_BRANCH')
    assert timestamp == 'master'
    assert os.environ.get('TRAVIS_PULL_REQUEST') == 'false'
    os.environ['TRAVIS_BRANCH'] = 'dev'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    timestamp = os.environ.get('TRAVIS_BRANCH')
    assert timestamp == 'dev'
    assert os.environ.get('TRAVIS_PULL_REQUEST') == 'false'


# Generated at 2022-06-21 20:37:15.699602
# Unit test for function frigg
def test_frigg():
    """
    Tests if all checks for frigg are done correctly
    """

    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"

    frigg("master")

    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    try:
        frigg("master")
    except CiVerificationError:
        pass
    os.environ["FRIGG_BUILD_BRANCH"] = "master"

    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        frigg("master")
    except CiVerificationError:
        pass


# Generated at 2022-06-21 20:37:22.224216
# Unit test for function semaphore
def test_semaphore():
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = "passed"
    os.environ['BRANCH_NAME'] = 'master'
    assert semaphore("master")

    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = "failed"
    os.environ['BRANCH_NAME'] = 'master'
    assert not semaphore("master")

    os.environ['PULL_REQUEST_NUMBER'] = '1'
    os.environ['SEMAPHORE_THREAD_RESULT'] = "passed"
    os.environ['BRANCH_NAME'] = 'master'
    assert not semaph

# Generated at 2022-06-21 20:37:26.750296
# Unit test for function semaphore
def test_semaphore():
    """
    Test function semaphore
    """
    assert checker(semaphore)('master')
    assert not checker(semaphore)('dev')
    assert isinstance(
        checker(semaphore)('dev'),
        CiVerificationError)

# Generated at 2022-06-21 20:37:32.465994
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PROJECT_ID"] = "900"
    os.environ["CI_PROJECT_PATH"] = "project"
    os.environ["CI_PROJECT_NAME"] = "project_name"
    gitlab("master")

# Generated at 2022-06-21 20:37:35.355401
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert check("master") == True


# Generated at 2022-06-21 20:37:42.310784
# Unit test for function checker
def test_checker():
    """
    checks the checker function
    :return:
    """

    @checker
    def test():
        """
        Testing the checker.
        :return:
        """
        assert True

    assert test()

    @checker
    def test_false():
        """
        Testing the checker.
        :return:
        """
        assert False


    try:
        test_false()
        assert False # pragma: no cover
    except CiVerificationError:
        assert True

# Generated at 2022-06-21 20:37:50.993600
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check("develop")
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check("develop")
    del os.environ["SEMAPHORE"]

# Generated at 2022-06-21 20:37:52.898054
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["TRAVIS_BRANCH"] = "master"
    check()


# Generated at 2022-06-21 20:37:53.910303
# Unit test for function check
def test_check():
    """Test for function check"""
    assert check() == None

# Generated at 2022-06-21 20:37:58.267548
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "dev"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis(branch="dev") is True


# Generated at 2022-06-21 20:38:15.729101
# Unit test for function bitbucket
def test_bitbucket():
    for env_variable in ['BITBUCKET_BRANCH', 'BITBUCKET_PR_ID']:
        os.environ[env_variable] = ''
    os.environ['BITBUCKET_BUILD_NUMBER'] = '1'
    bitbucket('1.0')
    assert 'BITBUCKET_BRANCH' in os.environ
    assert 'BITBUCKET_PR_ID' in os.environ
    assert os.environ['BITBUCKET_BRANCH'] == '1.0'
    assert not os.environ['BITBUCKET_PR_ID']
    os.environ['BITBUCKET_BRANCH'] = 'other'
    os.environ['BITBUCKET_PR_ID'] = '1'

# Generated at 2022-06-21 20:38:17.986013
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    with check(branch="master"):
        pass

# Generated at 2022-06-21 20:38:23.043168
# Unit test for function semaphore
def test_semaphore():
    os.environ.update(
        {
            "BRANCH_NAME": "master",
            "PULL_REQUEST_NUMBER": None,
            "SEMAPHORE_THREAD_RESULT": "passed"
        }
    )
    assert semaphore("master")
    os.environ.update(
        {
            "BRANCH_NAME": "master",
            "PULL_REQUEST_NUMBER": "1",
            "SEMAPHORE_THREAD_RESULT": "passed"
        }
    )
    try:
        semaphore("master")
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:38:28.469682
# Unit test for function circle
def test_circle():
    """
    Just simulate the ENV.
    """
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "branch"
    assert check("branch")
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]


# Generated at 2022-06-21 20:38:39.118502
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    assert check() is None
    os.environ['FRIGG_BUILD_BRANCH'] = 'notmaster'
    try:
        assert check() is None
    except AssertionError:
        assert None
    assert check('notmaster') is None
    try:
        os.environ['FRIGG_PULL_REQUEST'] = 'true'
        assert check() is None
    except AssertionError:
        assert None
    os.environ.clear()
    assert check() is None


# Generated at 2022-06-21 20:38:44.902866
# Unit test for function check
def test_check():
    # Check raised error when in wrong branch
    def test_check_helper(branch):
        os.environ["TRAVIS"] = "true"
        os.environ["TRAVIS_BRANCH"] = branch
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        try:
            check(branch)
        except CiVerificationError:
            raise AssertionError(
                "Didn't expect a CiVerificationError for correct branch: {}".format(branch)
            )

    for branch in ["master", "v4.0.0", "feature/test"]:
        test_check_helper(branch)

    # Check raised error when not in travis
    os.environ["TRAVIS"] = "false"

# Generated at 2022-06-21 20:38:48.225912
# Unit test for function frigg
def test_frigg():
    # Test failure condition
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "11"
    try:
        frigg("master")
        raise AssertionError
    except CiVerificationError:
        pass

    os.environ["FRIGG_PULL_REQUEST"] = None

    # Test success condition
    frigg("master")



# Generated at 2022-06-21 20:38:53.922951
# Unit test for function frigg
def test_frigg():
    try:
        frigg("master")
    except CiVerificationError:
        assert False
    try:
        frigg("0.3.20")
    except CiVerificationError:
        assert False
    try:
        frigg("invalid")
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-21 20:38:59.635741
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")

    # avoid to create release on another branch
    os.environ["BRANCH_NAME"] = "dev"
    assert semaphore("master") is False



# Generated at 2022-06-21 20:39:04.243408
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")



# Generated at 2022-06-21 20:39:15.705908
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]
    try:
        travis("master")
    except Exception as e:
        assert e.args[0] == "The verification check for the environment did not pass."


# Generated at 2022-06-21 20:39:18.382373
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check("master")



# Generated at 2022-06-21 20:39:22.943266
# Unit test for function circle
def test_circle():
    env = os.environ.copy()
    env["CIRCLECI"] = "true"
    env["CIRCLE_BRANCH"] = "branch"
    env["CI_PULL_REQUEST"] = "true"
    check()

# Generated at 2022-06-21 20:39:25.528900
# Unit test for function checker
def test_checker():
    """
    Unit test for the checker decorator.
    """

    def test_function():
        pass

    assert checker(test_function)() is True



# Generated at 2022-06-21 20:39:36.913135
# Unit test for function semaphore
def test_semaphore():
    # with all environment variables properly set, this should run successfully
    contains = ["SEMAPHORE=true", "BRANCH_NAME=master", "PULL_REQUEST_NUMBER=None", "SEMAPHORE_THREAD_RESULT=passed"]
    assert semaphore("master") == True
    # this should fail as the branch_name is not correct
    not_contains = ["SEMAPHORE=true", "BRANCH_NAME=notmaster", "PULL_REQUEST_NUMBER=None", "SEMAPHORE_THREAD_RESULT=passed"]
    assert semaphore("master") == False
    # this should fail as the pull_request_number is not None

# Generated at 2022-06-21 20:39:38.793044
# Unit test for function travis
def test_travis():
    try:
        travis("master")
    except CiVerificationError:
        assert True


# Generated at 2022-06-21 20:39:39.337110
# Unit test for function check
def test_check():
    assert check()

# Generated at 2022-06-21 20:39:43.346781
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg(branch="master")
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]
    del os.environ["FRIGG"]

# Generated at 2022-06-21 20:39:52.078145
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "develop"
    assert circle("develop")
    os.environ["CI_PULL_REQUEST"] = "123"
    assert not circle("develop")
    os.environ["CIRCLE_BRANCH"] = "master"
    assert not circle("develop")
    del os.environ["CIRCLE_BRANCH"]
    assert not circle("develop")



# Generated at 2022-06-21 20:39:55.424902
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "test"
    os.environ["CI_PULL_REQUEST"] = ""
    assert check()



# Generated at 2022-06-21 20:40:09.588730
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    travis(branch=os.environ["TRAVIS_BRANCH"])

    os.environ["TRAVIS_PULL_REQUEST"] = "true"

    try:
        travis(branch=os.environ["TRAVIS_BRANCH"])
    except CiVerificationError:
        assert True
    else:
        assert False

# Unit tests for function semaphore

# Generated at 2022-06-21 20:40:11.592828
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    gitlab("master")

# Generated at 2022-06-21 20:40:15.664352
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = 'master'
    frigg(branch="master")
    assert True



# Generated at 2022-06-21 20:40:26.116733
# Unit test for function jenkins
def test_jenkins():
    ci_attributes = ["JENKINS_URL", "BRANCH_NAME", "CHANGE_ID"]
    for ci_attribute in ci_attributes:
        if ci_attribute in os.environ:
            del os.environ[ci_attribute]
    os.environ["JENKINS_URL"] = "https://www.jenkins.io"
    os.environ["BRANCH_NAME"] = "master"

    jenkins("master")
    os.environ["BRANCH_NAME"] = "dev"
    jenkins("dev")
    # jenkins("master")
    # AssertionError

    os.environ["CHANGE_ID"] = "1"
    # jenkins("master")
    # AssertionError

# Generated at 2022-06-21 20:40:34.129653
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")

    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    else:
        raise Exception("Didn't get a CiVerificationError!")

# Generated at 2022-06-21 20:40:39.646426
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "https://jenkins"
    os.environ['GIT_BRANCH'] = "release-test"
    try:
        jenkins("release-test")
        assert True
    except:
        assert False

# Generated at 2022-06-21 20:40:46.870167
# Unit test for function check
def test_check():
    branch = 'master'

    # Expected behavior:
    # if there is no environment variable, function check will raise no error
    # if there is an environment variable, function check will not raise error
    # if there is an environment variable with a branch, function check will raise no error
    # if there is an environment variable with a branch, function check will raise error
    for env_name in os.environ:
        del os.environ[env_name]
    # 1, 2
    check(branch)

    # 1, 3
    os.environ["TRAVIS"] = "true"
    check(branch)

    # 4
    os.environ["TRAVIS_BRANCH"] = "branch"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check(branch)

# Generated at 2022-06-21 20:40:53.292713
# Unit test for function gitlab
def test_gitlab():
    os.environ['GITLAB_CI'] = "true"
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    check()
    os.environ['GITLAB_CI'] = "true"
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    check()


# Generated at 2022-06-21 20:40:54.737467
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "develop"
    os.environ.pop("CI_PULL_REQUEST", None)
    check("develop")


# Generated at 2022-06-21 20:40:55.924134
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master")



# Generated at 2022-06-21 20:41:11.108691
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-21 20:41:19.569387
# Unit test for function circle
def test_circle():
    import os
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master") == True
    os.environ["CI_PULL_REQUEST"] = "1"
    try:
        circle("master")
    except AssertionError:
        assert True
    except:
        assert False
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-21 20:41:23.519840
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check(branch = "master")
    os.environ["CI_COMMIT_REF_NAME"] = "1.0.0"
    check(branch = "master")

# Generated at 2022-06-21 20:41:29.676320
# Unit test for function jenkins
def test_jenkins():
    import os
    from semantic_release.hvcs import (
        check,
        jenkins
    )
    os.environ["BRANCH_NAME"] = "test_jenkins"
    os.environ["GIT_BRANCH"] = "test_jenkins"
    os.environ["JENKINS_URL"] = "true"
    os.environ["CHANGE_ID"] = None
    jenkins("test_jenkins")
    os.environ["CHANGE_ID"] = "PR_ID"
    try:
        jenkins("test_jenkins")
    except CiVerificationError:
        assert True
    else:
        assert False
    os.environ.pop("BRANCH_NAME")
    os.environ.pop("GIT_BRANCH")

# Generated at 2022-06-21 20:41:35.250883
# Unit test for function travis
def test_travis():
    try:
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        travis("master")
    except CiVerificationError:
        raise AssertionError("Environment variable not detected correctly.")

# Generated at 2022-06-21 20:41:42.323470
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'feature'
    os.environ['FRIGG_PULL_REQUEST'] = '1'
    try:
        frigg('feature')
        assert False
    except:
        assert True
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    frigg('master')


# Generated at 2022-06-21 20:41:48.304974
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "https://github.com/relekang/python-semantic-release"
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle(branch="master") is True
    assert circle(branch="test") is False
    os.environ.pop("CIRCLECI")


# Generated at 2022-06-21 20:41:52.036717
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-21 20:41:57.428486
# Unit test for function circle
def test_circle():

    os.environ["CI_PULL_REQUEST"] = "test"
    assert not circle(branch="master")

    os.environ["CI_PULL_REQUEST"] = None
    os.environ["CIRCLE_BRANCH"] = "test"
    assert not circle(branch="master")

    os.environ["CI_PULL_REQUEST"] = None
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle(branch="master")



# Generated at 2022-06-21 20:42:02.978090
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-21 20:42:32.668565
# Unit test for function travis
def test_travis():
    """
    For testing travis function
    """
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-21 20:42:42.871912
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = 'master'
    os.environ["CI_PROJECT_PATH"] = 'dada'

    check()

    assert os.environ.get("CI_COMMIT_REF_NAME") is not None
    assert os.environ.get("CI_PROJECT_PATH") == 'dada'
    assert os.environ.get("CI_COMMIT_REF_NAME") == 'master'

    del os.environ["BRANCH_NAME"]
    del os.environ["CI_PROJECT_PATH"]


# Generated at 2022-06-21 20:42:46.157379
# Unit test for function bitbucket
def test_bitbucket():
    """
    Ensures that the check for bitbucket raises a
    CiVerificationError for a given set of environemnt
    variables.

    :return: True
    """

    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1234"
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1234"
    os.environ["BITBUCKET_COMMIT"] = "1234"

    try:
        bitbucket()
    except CiVerificationError:
        return True

    raise Exception("CiVerificationError not raised for bitbucket")

# Generated at 2022-06-21 20:42:55.162828
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("develop") == True
    del os.environ["BRANCH_NAME"]
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["PULL_REQUEST_NUMBER"] = "12"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("develop") == False
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["PULL_REQUEST_NUMBER"] = None