

# Generated at 2022-06-18 02:52:09.170415
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    os.environ["CI_PULL_REQUEST"] = ""
    circle("develop")
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "123"
    try:
        circle("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should have raised CiVerificationError")


# Generated at 2022-06-18 02:52:14.107363
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    os.environ["TRAVIS_BRANCH"] = "develop"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")

    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")


# Generated at 2022-06-18 02:52:18.949034
# Unit test for function checker
def test_checker():
    """
    Test the checker decorator.
    """
    @checker
    def test_func():
        """
        Test function.
        """
        raise AssertionError()

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False, "CiVerificationError not raised"

# Generated at 2022-06-18 02:52:22.408053
# Unit test for function checker
def test_checker():
    """
    Test the checker decorator.
    """
    @checker
    def test_func():
        """
        Test function for checker decorator.
        """
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:52:34.256353
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os

# Generated at 2022-06-18 02:52:38.310780
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")



# Generated at 2022-06-18 02:52:41.691616
# Unit test for function checker
def test_checker():
    def func():
        raise AssertionError

    func_wrapper = checker(func)
    try:
        func_wrapper()
    except CiVerificationError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-18 02:52:51.470669
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-18 02:52:56.927582
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-18 02:53:03.116938
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("develop")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        assert False


# Generated at 2022-06-18 02:53:18.022794
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os

# Generated at 2022-06-18 02:53:26.887008
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["TRAVIS_BRANCH"] = "develop"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should have raised CiVerificationError")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should have raised CiVerificationError")
    del os

# Generated at 2022-06-18 02:53:35.768515
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")


# Generated at 2022-06-18 02:53:38.876099
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://localhost:8080"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")

# Generated at 2022-06-18 02:53:43.379072
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 02:53:50.201382
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    circle("develop")
    os.environ["CI_PULL_REQUEST"] = "https://github.com/relekang/python-semantic-release/pull/1"
    try:
        circle("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should raise CiVerificationError")


# Generated at 2022-06-18 02:53:52.447211
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()



# Generated at 2022-06-18 02:54:03.471982
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should have raised CiVerificationError")

    os.environ["BRANCH_NAME"] = "master"

# Generated at 2022-06-18 02:54:12.517075
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None

# Generated at 2022-06-18 02:54:20.526809
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") is True
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master") is False
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

# Generated at 2022-06-18 02:54:32.801164
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        raise AssertionError

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")

# Generated at 2022-06-18 02:54:41.237057
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["CHANGE_ID"] = ""
    jenkins("develop")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "123"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should raise CiVerificationError")
    os.environ["BRANCH_NAME"] = "develop"

# Generated at 2022-06-18 02:54:52.629864
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = ""
    assert jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["GIT_BRANCH"] = "develop"
    assert jenkins("develop")
    os.environ["CHANGE_ID"] = "123"
    assert not jenkins("develop")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    assert not jenkins("develop")
    del os

# Generated at 2022-06-18 02:54:57.044180
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-18 02:54:59.798768
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()



# Generated at 2022-06-18 02:55:05.018734
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]



# Generated at 2022-06-18 02:55:09.327780
# Unit test for function checker
def test_checker():
    """
    Test the checker decorator.
    """
    @checker
    def test_func():
        """
        Test function.
        """
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")

# Generated at 2022-06-18 02:55:12.554137
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-18 02:55:17.205058
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]



# Generated at 2022-06-18 02:55:23.382688
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-18 02:55:45.491758
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "1"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["CHANGE_ID"] = "0"
    jenkins("master")
    os.environ["BRANCH_NAME"] = "release"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"

# Generated at 2022-06-18 02:55:56.176909
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "123"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["CHANGE_ID"]
    jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BRANCH_NAME"] = "master"
    del os.environ["JENKINS_URL"]

# Generated at 2022-06-18 02:56:02.461947
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    try:
        frigg("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Should have raised CiVerificationError"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        frigg("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Should have raised CiVerificationError"
    del os.environ["FRIGG"]

# Generated at 2022-06-18 02:56:08.513700
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]


# Generated at 2022-06-18 02:56:16.513398
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None

# Generated at 2022-06-18 02:56:25.342658
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]

# Generated at 2022-06-18 02:56:33.413709
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("develop")
    os.environ["BRANCH_NAME"] = "develop"
    semaphore("develop")
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    semaphore("develop")

# Generated at 2022-06-18 02:56:42.866332
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")

# Generated at 2022-06-18 02:56:54.198907
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    try:
        bitbucket("develop")
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:57:04.808389
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    with pytest.raises(CiVerificationError):
        frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    with pytest.raises(CiVerificationError):
        frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]

# Generated at 2022-06-18 02:57:23.535875
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("master")
        assert False
    except CiVerificationError:
        assert True
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None

# Generated at 2022-06-18 02:57:34.234494
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["CI_MERGE_REQUEST_ID"]
    del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-18 02:57:40.085811
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 02:57:42.560312
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-18 02:57:46.090253
# Unit test for function checker
def test_checker():
    """
    Test the checker decorator
    """
    @checker
    def test_func():
        """
        Test function
        """
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")

# Generated at 2022-06-18 02:57:52.914852
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "1"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Jenkins check should have failed")

    os.environ["CHANGE_ID"] = ""
    jenkins("master")

    os.environ["BRANCH_NAME"] = "develop"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Jenkins check should have failed")

    os.environ["BRANCH_NAME"] = "master"

# Generated at 2022-06-18 02:57:58.148825
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 02:58:07.958733
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "123"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Jenkins check should have failed"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Jenkins check should have failed"
    os.environ["BRANCH_NAME"] = "master"

# Generated at 2022-06-18 02:58:12.543008
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "123"
    check("master")
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 02:58:19.524336
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master") is False
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    assert semaphore("master") is False
    os.environ["BRANCH_NAME"] = "develop"
    assert semaphore("master") is False
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]

# Generated at 2022-06-18 02:58:37.496235
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    check()
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-18 02:58:40.397691
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        raise AssertionError

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError was not raised")

# Generated at 2022-06-18 02:58:47.819762
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "123"
    try:
        gitlab("master")
        assert False
    except CiVerificationError:
        assert True
    del os.environ["CI_MERGE_REQUEST_ID"]
    gitlab("master")
    assert True

# Generated at 2022-06-18 02:58:56.957351
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os

# Generated at 2022-06-18 02:59:06.031463
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-18 02:59:10.753149
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")



# Generated at 2022-06-18 02:59:15.454153
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")


# Generated at 2022-06-18 02:59:23.986677
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    assert not circle("master")
    os.environ["CI_PULL_REQUEST"] = "123"
    assert not circle("master")
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 02:59:28.904630
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-18 02:59:34.930044
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]



# Generated at 2022-06-18 02:59:57.810283
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    try:
        bitbucket("develop")
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 03:00:08.053461
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")
    os.environ["CHANGE_ID"] = "1"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Jenkins check should fail on pull request")
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["GIT_BRANCH"] = "develop"
    try:
        jenkins("master")
    except CiVerificationError:
        pass

# Generated at 2022-06-18 03:00:16.576084
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    with pytest.raises(CiVerificationError):
        frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    with pytest.raises(CiVerificationError):
        frigg("master")
    os.environ["FRIGG"] = "false"
    with pytest.raises(CiVerificationError):
        frigg("master")


# Generated at 2022-06-18 03:00:27.727447
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    circle("master")
    os.environ["CI_PULL_REQUEST"] = "true"
    try:
        circle("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["CI_PULL_REQUEST"] = ""
    os.environ["CIRCLE_BRANCH"] = "develop"
    try:
        circle("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["CIRCLE_BRANCH"] = "master"

# Generated at 2022-06-18 03:00:29.350843
# Unit test for function checker
def test_checker():
    def test_func():
        raise AssertionError

    assert checker(test_func)() is False

# Generated at 2022-06-18 03:00:33.376712
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 03:00:38.838931
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]



# Generated at 2022-06-18 03:00:44.540813
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]


# Generated at 2022-06-18 03:00:52.492369
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = ""
    assert jenkins("master") is True
    os.environ["CHANGE_ID"] = "123"
    assert jenkins("master") is False
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["GIT_BRANCH"] = "develop"
    assert jenkins("master") is False
    os.environ["CHANGE_ID"] = ""
    assert jenkins("master") is False
    del os.environ["JENKINS_URL"]
    del os

# Generated at 2022-06-18 03:01:00.254689
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"

# Generated at 2022-06-18 03:01:24.486818
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os

# Generated at 2022-06-18 03:01:34.730748
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("master")
    except CiVerificationError:
        assert True
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None

# Generated at 2022-06-18 03:01:43.543714
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()
    os.environ["CIRCLE_BRANCH"] = "develop"
    check("develop")
    os.environ["CI_PULL_REQUEST"] = "true"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")
    del os.environ["CI_PULL_REQUEST"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CIRCLECI"]



# Generated at 2022-06-18 03:01:45.371335
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")

# Generated at 2022-06-18 03:01:45.822049
# Unit test for function check
def test_check():
    assert check()

# Generated at 2022-06-18 03:01:51.166642
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "false"
    check()
    os.environ["BRANCH_NAME"] = "dev"
    os.environ["CHANGE_ID"] = "false"
    check("dev")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "true"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BRANCH_NAME"] = "dev"
    os.environ["CHANGE_ID"] = "true"