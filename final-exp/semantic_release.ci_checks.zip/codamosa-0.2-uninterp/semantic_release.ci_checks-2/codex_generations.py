

# Generated at 2022-06-18 02:52:02.052541
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()
    del os.environ["GITLAB_CI"]
    del os.environ["CI_COMMIT_REF_NAME"]


# Generated at 2022-06-18 02:52:11.847171
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "123"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Should have raised CiVerificationError"

    os.environ["CHANGE_ID"] = None
    assert jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Should have raised CiVerificationError"

    os.environ["BRANCH_NAME"] = "master"
    assert jen

# Generated at 2022-06-18 02:52:14.776717
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:52:18.747625
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check("develop")
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:52:25.094742
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    os.environ["CIRCLE_BRANCH"] = "develop"
    os.environ["CI_PULL_REQUEST"] = "123"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 02:52:31.896829
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["GITLAB_CI"]


# Generated at 2022-06-18 02:52:36.052279
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 02:52:41.901592
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "false"
    assert jenkins("master") is True

# Generated at 2022-06-18 02:52:45.758391
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]

# Generated at 2022-06-18 02:52:48.609828
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-18 02:53:04.023740
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Should raise CiVerificationError"

    os.environ["BITBUCKET_PR_ID"] = ""
    try:
        bitbucket("master")
    except CiVerificationError:
        assert False, "Should not raise CiVerificationError"
    else:
        pass

    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Should raise CiVerificationError"



# Generated at 2022-06-18 02:53:07.600454
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "123"
    jenkins("master")

# Generated at 2022-06-18 02:53:16.007667
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    os.environ["CI_PULL_REQUEST"] = ""
    circle("develop")
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "https://github.com/relekang/python-semantic-release/pull/1"
    try:
        circle("master")
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-18 02:53:21.993584
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master")
    os.environ["CI_PULL_REQUEST"] = "1"
    assert not circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    assert not circle("master")


# Generated at 2022-06-18 02:53:26.099799
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 02:53:28.657451
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        raise AssertionError()

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")

# Generated at 2022-06-18 02:53:33.165950
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 02:53:42.832176
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    assert frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    assert not frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    assert not frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-18 02:53:48.614726
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = ""
    check()
    os.environ["CI_MERGE_REQUEST_IID"] = "1"
    try:
        check()
        assert False
    except CiVerificationError:
        pass
    del os.environ["CI_MERGE_REQUEST_IID"]
    del os.environ["CI_COMMIT_REF_NAME"]


# Generated at 2022-06-18 02:53:54.864772
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os

# Generated at 2022-06-18 02:54:15.277885
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket("master")



# Generated at 2022-06-18 02:54:17.569186
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-18 02:54:20.061708
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:54:25.848479
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")

# Generated at 2022-06-18 02:54:29.386174
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 02:54:36.590027
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os

# Generated at 2022-06-18 02:54:40.635160
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should have raised CiVerificationError")

    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")

    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should have raised CiVerificationError")

    os.environ

# Generated at 2022-06-18 02:54:52.115613
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check("develop")
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    try:
        check()
        assert False
    except CiVerificationError:
        pass
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"

# Generated at 2022-06-18 02:54:55.681188
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    assert True


# Generated at 2022-06-18 02:54:58.514443
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-18 02:55:23.629137
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-18 02:55:29.299962
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Travis should raise CiVerificationError")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        raise Ass

# Generated at 2022-06-18 02:55:34.583052
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    assert True



# Generated at 2022-06-18 02:55:41.089025
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]

# Generated at 2022-06-18 02:55:48.163753
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    os.environ["CIRCLE_BRANCH"] = "develop"
    with pytest.raises(CiVerificationError):
        check()
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "1"
    with pytest.raises(CiVerificationError):
        check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]

# Unit

# Generated at 2022-06-18 02:55:51.615445
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()



# Generated at 2022-06-18 02:55:56.893189
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-18 02:56:08.060087
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BITBUCKET_BRANCH"] = "master"
    del os.environ["BITBUCKET_BRANCH"]

# Generated at 2022-06-18 02:56:10.906681
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-18 02:56:16.645311
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os

# Generated at 2022-06-18 02:57:11.379559
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")
   

# Generated at 2022-06-18 02:57:17.775251
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None

# Generated at 2022-06-18 02:57:25.196455
# Unit test for function check
def test_check():
    """
    Test the check function
    """
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()

# Generated at 2022-06-18 02:57:35.296584
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "false"
    assert jenkins("master") == True
    os.environ["CHANGE_ID"] = "true"
    assert jenkins("master") == False
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["GIT_BRANCH"] = "develop"
    os.environ["CHANGE_ID"] = "false"
    assert jenkins("master") == False
    os.environ["CHANGE_ID"] = "true"
    assert jenkins("master") == False

# Generated at 2022-06-18 02:57:45.277287
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") == True
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") == False
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"

# Generated at 2022-06-18 02:57:49.162808
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "0"
    jenkins("master")

# Generated at 2022-06-18 02:57:53.205447
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:57:58.690180
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    assert not circle("master")
    os.environ["CI_PULL_REQUEST"] = "123"
    assert not circle("master")



# Generated at 2022-06-18 02:58:05.618005
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]


# Generated at 2022-06-18 02:58:11.265326
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    check("develop")
    del os.environ["CI_COMMIT_REF_NAME"]
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should have raised CiVerificationError")


# Generated at 2022-06-18 02:59:46.159661
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 02:59:49.158148
# Unit test for function checker
def test_checker():
    """
    Test the checker decorator
    """
    @checker
    def test_func():
        """
        A test function that will raise an AssertionError
        """
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:59:58.288894
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os

# Generated at 2022-06-18 03:00:03.880821
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 03:00:09.912282
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 03:00:11.969851
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 03:00:19.602775
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    try:
        bitbucket("develop")
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 03:00:29.834689
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://localhost:8080"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "1"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False

    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = None
    try:
        jenkins("master")
    except CiVerificationError:
        assert False
    else:
        pass

    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "1"

# Generated at 2022-06-18 03:00:36.907061
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["CHANGE_ID"] = ""
    jenkins("develop")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "1"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Jenkins check should fail")
    os.environ["BRANCH_NAME"] = "develop"

# Generated at 2022-06-18 03:00:42.054251
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    bitbucket("master")
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]
