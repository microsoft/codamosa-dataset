

# Generated at 2022-06-18 02:52:01.219974
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 02:52:11.524201
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert not semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaph

# Generated at 2022-06-18 02:52:21.465582
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]

# Generated at 2022-06-18 02:52:30.637411
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "123"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["CHANGE_ID"]
    jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BRANCH_NAME"] = "master"
    del os.environ["JENKINS_URL"]

# Generated at 2022-06-18 02:52:35.142829
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 02:52:37.068412
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:52:41.350555
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "false"
    check()



# Generated at 2022-06-18 02:52:45.267279
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]

# Generated at 2022-06-18 02:52:48.130995
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-18 02:52:55.956103
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Should have raised an exception"
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Should have raised an exception"
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_BUILD_NUMBER"]



# Generated at 2022-06-18 02:53:10.712245
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "1234"
    jenkins("master")
    os.environ["CHANGE_ID"] = ""
    jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["GIT_BRANCH"] = "develop"
    jenkins("develop")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "1234"

# Generated at 2022-06-18 02:53:17.463849
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("develop")
    del os.en

# Generated at 2022-06-18 02:53:24.696766
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        assert True
    else:
        assert False
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]
    try:
        bitbucket("master")
    except CiVerificationError:
        assert False
    else:
        assert True


# Generated at 2022-06-18 02:53:31.163562
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]

# Generated at 2022-06-18 02:53:37.404086
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 02:53:45.985525
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()
    os.environ["CIRCLE_BRANCH"] = "develop"
    with pytest.raises(CiVerificationError):
        check()
    del os.environ["CIRCLE_BRANCH"]
    with pytest.raises(CiVerificationError):
        check()
    del os.environ["CIRCLECI"]
    with pytest.raises(CiVerificationError):
        check()


# Generated at 2022-06-18 02:53:48.514042
# Unit test for function checker
def test_checker():
    """
    Test the checker decorator.
    """
    @checker
    def func():
        assert False

    try:
        func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:53:54.839626
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]

# Generated at 2022-06-18 02:53:57.053293
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:54:02.675304
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 02:54:29.244874
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_BUILD_NUMBER"]


# Generated at 2022-06-18 02:54:36.512104
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("develop")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        raise Exception("CiVerificationError not raised")
    os.environ["TRAVIS_BRANCH"] = "develop"

# Generated at 2022-06-18 02:54:40.585080
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["GIT_BRANCH"] = "develop"
    jenkins("develop")
    os.environ["CHANGE_ID"] = "123"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should have raised CiVerificationError")

# Generated at 2022-06-18 02:54:50.775553
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    assert not circle("master")
    os.environ["CI_PULL_REQUEST"] = "true"
    assert not circle("master")
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 02:54:56.933002
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Should have raised an error"
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Should have raised an error"

# Generated at 2022-06-18 02:55:02.837614
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]



# Generated at 2022-06-18 02:55:11.297395
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")


# Generated at 2022-06-18 02:55:16.783283
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    assert bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        assert True
    else:
        assert False


# Generated at 2022-06-18 02:55:21.020623
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 02:55:24.466632
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    os.environ["CI_PULL_REQUEST"] = "true"
    assert not circle("master")
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 02:56:02.060735
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os

# Generated at 2022-06-18 02:56:07.343681
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]



# Generated at 2022-06-18 02:56:15.757052
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "123"
    try:
        jenkins("master")
        assert False
    except CiVerificationError:
        assert True
    os.environ["CHANGE_ID"] = None
    os.environ["BRANCH_NAME"] = "develop"
    try:
        jenkins("master")
        assert False
    except CiVerificationError:
        assert True
    os.environ["BRANCH_NAME"] = "master"
    try:
        jenkins("master")
        assert True
    except CiVerificationError:
        assert False

# Generated at 2022-06-18 02:56:24.549899
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os

# Generated at 2022-06-18 02:56:31.479316
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore("master")
    os.environ["BRANCH_NAME"] = "develop"
    assert not semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    assert not semaphore("master")

# Generated at 2022-06-18 02:56:41.487451
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert not travis("master")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    assert not travis("master")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    assert not travis("master")

# Generated at 2022-06-18 02:56:52.028548
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("develop")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.en

# Generated at 2022-06-18 02:57:00.692239
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should raise CiVerificationError")
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket("master")


# Generated at 2022-06-18 02:57:11.427149
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "123"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Jenkins should have failed"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Jenkins should have failed"
    os.environ["BRANCH_NAME"] = "master"

# Generated at 2022-06-18 02:57:17.800469
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os

# Generated at 2022-06-18 02:58:12.688784
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os

# Generated at 2022-06-18 02:58:17.265905
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 02:58:25.454340
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")
    os.environ["CHANGE_ID"] = "123"
    jenkins("master")
    os.environ["CHANGE_ID"] = ""
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["GIT_BRANCH"] = "develop"
    jenkins("develop")
    os.environ["CHANGE_ID"] = "123"
    jenkins("develop")
    os.environ["CHANGE_ID"] = ""


# Generated at 2022-06-18 02:58:27.558491
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:58:35.398862
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]


# Generated at 2022-06-18 02:58:43.806824
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "123"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["CHANGE_ID"]
    jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["BRANCH_NAME"]
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")

# Generated at 2022-06-18 02:58:49.429343
# Unit test for function checker
def test_checker():
    """
    Test the checker decorator.
    """
    @checker
    def test_func():
        """
        Test function for checker decorator.
        """
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")

# Generated at 2022-06-18 02:58:53.695425
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should have raised CiVerificationError")

    del os.environ["BITBUCKET_PR_ID"]
    bitbucket("master")



# Generated at 2022-06-18 02:59:00.755103
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 02:59:03.738765
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 03:01:11.297499
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]


# Generated at 2022-06-18 03:01:23.160606
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = "1"
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")

# Generated at 2022-06-18 03:01:25.786584
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()



# Generated at 2022-06-18 03:01:36.480393
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    os.environ["CI_PULL_REQUEST"] = "false"
    circle("master")
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "true"
    circle("master")
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    circle("develop")

# Generated at 2022-06-18 03:01:40.830980
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "123"
    jenkins("master")

# Generated at 2022-06-18 03:01:47.279013
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    assert not circle("master")
    os.environ["CI_PULL_REQUEST"] = "true"
    assert not circle("master")
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]

