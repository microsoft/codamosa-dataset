

# Generated at 2022-06-18 02:52:00.721383
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")



# Generated at 2022-06-18 02:52:07.377010
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 02:52:10.493370
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-18 02:52:14.747439
# Unit test for function checker
def test_checker():
    # Test that checker works
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("checker decorator did not work")

# Generated at 2022-06-18 02:52:17.524830
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:52:21.992111
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    check()


# Generated at 2022-06-18 02:52:31.250428
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BITBUCKET_PR_ID"] = None
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ

# Generated at 2022-06-18 02:52:39.197010
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os

# Generated at 2022-06-18 02:52:48.311449
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
        assert False
    except CiVerificationError:
        assert True
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-18 02:52:56.090917
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Travis checker should have failed")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        raise Assert

# Generated at 2022-06-18 02:53:08.140340
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]

# Generated at 2022-06-18 02:53:16.277025
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") is False
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaph

# Generated at 2022-06-18 02:53:19.615676
# Unit test for function checker
def test_checker():
    def func():
        raise AssertionError()

    func = checker(func)
    try:
        func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:53:23.966960
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")

# Generated at 2022-06-18 02:53:31.593045
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"

# Generated at 2022-06-18 02:53:40.790701
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    assert not circle("master")
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "123"
    assert not circle("master")
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 02:53:49.656057
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["TRAVIS_BRANCH"] = "develop"
    check("develop")
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
        assert False
    except CiVerificationError:
        assert True
    os.environ["TRAVIS"] = "false"
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.en

# Generated at 2022-06-18 02:53:51.491016
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:53:56.162053
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "123"
    jenkins("master")

# Generated at 2022-06-18 02:54:06.416193
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("semaphore should raise CiVerificationError")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["BRANCH_NAME"] = "develop"
    try:
        semaphore("master")
    except CiVerificationError:
        pass

# Generated at 2022-06-18 02:54:25.019198
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")



# Generated at 2022-06-18 02:54:27.370421
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-18 02:54:37.711029
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = ""
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:54:48.630858
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["TRAVIS_BRANCH"] = "develop"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")
    del os

# Generated at 2022-06-18 02:54:56.042859
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["BITBUCKET_BRANCH"]

# Generated at 2022-06-18 02:55:05.269467
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()
    os.environ["CIRCLE_BRANCH"] = "develop"
    with pytest.raises(CiVerificationError):
        check()
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "true"
    with pytest.raises(CiVerificationError):
        check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]



# Generated at 2022-06-18 02:55:10.241889
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    os.environ["CI_PULL_REQUEST"] = "true"
    try:
        circle("master")
        assert False
    except CiVerificationError:
        assert True
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "true"
    try:
        circle("master")
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-18 02:55:13.213441
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-18 02:55:17.823276
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 02:55:28.918879
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    circle("develop")
    os.environ["CI_PULL_REQUEST"] = "true"
    try:
        circle("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should have raised CiVerificationError")
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-18 02:56:01.127112
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-18 02:56:06.555850
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-18 02:56:12.352751
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]



# Generated at 2022-06-18 02:56:14.971369
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()



# Generated at 2022-06-18 02:56:24.237816
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "123"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["CHANGE_ID"] = None
    jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")

# Generated at 2022-06-18 02:56:27.122962
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = ""
    check()

# Generated at 2022-06-18 02:56:30.373158
# Unit test for function checker
def test_checker():
    """
    Test the checker decorator.
    """
    @checker
    def test_func():
        """
        Test function for checker decorator.
        """
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 02:56:37.253085
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]


# Generated at 2022-06-18 02:56:45.207600
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        assert False


# Generated at 2022-06-18 02:56:57.053196
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["TRAVIS_BRANCH"] = "develop"
    check("develop")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
        assert False
    except CiVerificationError:
        pass
    os.environ["TRAVIS"] = "false"
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.en

# Generated at 2022-06-18 02:57:51.815416
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()
    os.environ["CIRCLE_BRANCH"] = "develop"
    with pytest.raises(CiVerificationError):
        check()
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "true"
    with pytest.raises(CiVerificationError):
        check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]



# Generated at 2022-06-18 02:57:56.260577
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-18 02:58:06.177023
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore("master")
    os.environ["BRANCH_NAME"] = "develop"
    assert not semaphore("master")
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    assert not semaphore("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]

# Generated at 2022-06-18 02:58:15.463838
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")

# Generated at 2022-06-18 02:58:23.927109
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "123"
    try:
        gitlab("master")
    except CiVerificationError:
        pass
    else:
        assert False, "gitlab should raise an exception"
    del os.environ["CI_MERGE_REQUEST_ID"]
    gitlab("master")
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    try:
        gitlab("master")
    except CiVerificationError:
        pass
    else:
        assert False, "gitlab should raise an exception"
    gitlab("develop")
    del os.environ["CI_COMMIT_REF_NAME"]


# Generated at 2022-06-18 02:58:27.225185
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-18 02:58:37.554356
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-18 02:58:45.381439
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["TRAVIS_BRANCH"] = "develop"
    check("develop")
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None

# Generated at 2022-06-18 02:58:55.066831
# Unit test for function check
def test_check():
    """
    Unit test for function check
    """
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["TRAVIS_BRANCH"] = "develop"
    check("develop")
    del os.environ["TRAVIS"]
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    os.environ["BRANCH_NAME"]

# Generated at 2022-06-18 02:59:05.257868
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    os.environ["BRANCH_NAME"] = "develop"
    assert not semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    assert not semaphore("master")
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore("master")

# Generated at 2022-06-18 03:01:11.637752
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = None
    jenkins("master")
    os.environ["BRANCH_NAME"] = "develop"
    jenkins("develop")
    os.environ["CHANGE_ID"] = "123"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = None
    os.environ["JENKINS_URL"] = None

# Generated at 2022-06-18 03:01:16.579296
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    assert True

# Generated at 2022-06-18 03:01:19.593758
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-18 03:01:22.321110
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 03:01:27.194948
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-18 03:01:38.497456
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    try:
        gitlab("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["CI_MERGE_REQUEST_ID"]
    gitlab("master")
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    try:
        gitlab("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    gitlab("master")
    del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-18 03:01:40.714942
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-18 03:01:48.102859
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]
    del os