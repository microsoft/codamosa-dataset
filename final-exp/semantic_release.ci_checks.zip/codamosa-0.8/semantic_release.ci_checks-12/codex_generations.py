

# Generated at 2022-06-12 06:21:07.294562
# Unit test for function bitbucket
def test_bitbucket():
    assert check is not None
    assert bitbucket is not None


# Generated at 2022-06-12 06:21:10.674850
# Unit test for function jenkins
def test_jenkins():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['JENKINS_URL'] = 'https://www.jenkins.com'
    os.environ['CHANGE_ID'] = '324324'
    jenkins()

# Generated at 2022-06-12 06:21:15.368847
# Unit test for function semaphore
def test_semaphore():
    assert not semaphore('master')
    assert not semaphore('development')
    assert not semaphore('feature/test')
    assert not semaphore('release/v1.0.0')
    assert not semaphore('release/1.0.0')

# Generated at 2022-06-12 06:21:18.128591
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "https://jenkis.com"
    os.environ['GIT_BRANCH'] = "master"
    check()



# Generated at 2022-06-12 06:21:21.868616
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "test"

    assert jenkins("master") is True

# Generated at 2022-06-12 06:21:26.585187
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "test"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    bitbucket("master")
    assert True
    os.environ["BITBUCKET_BRANCH"] = "test"
    bitbucket("master")
    assert False



# Generated at 2022-06-12 06:21:29.969495
# Unit test for function checker
def test_checker():
    @checker
    def do_check():
        raise AssertionError()

    try:
        do_check()
    except CiVerificationError:
        pass
    else:
        raise Exception("Should have raised a CiVerificationError")

# Generated at 2022-06-12 06:21:35.952148
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'False'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'success'
    check()
    assert True
    

# Generated at 2022-06-12 06:21:40.098316
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_BRANCH"] = "master"
    check()

# Generated at 2022-06-12 06:21:47.472843
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    os.environ['FRIGG_PULL_REQUEST'] = "false"
    try:
        frigg('master')
    except CiVerificationError as e:
        assert "The verification check for the environment did not pass." in str(e)
    else:
        raise AssertionError



# Generated at 2022-06-12 06:22:06.284490
# Unit test for function check
def test_check():
    # Checks for travis
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    # Checks for semaphore
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "10"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False

    # Checks for frigg
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    check()



# Generated at 2022-06-12 06:22:16.575455
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket(branch="master")
    os.environ["BITBUCKET_BRANCH"] = "branch"
    try:
        bitbucket(branch="master")
        assert False
    except CiVerificationError:
        assert True
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket(branch="master")
        assert False
    except CiVerificationError:
        assert True
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ

# Generated at 2022-06-12 06:22:22.488679
# Unit test for function checker
def test_checker():
    # No error
    @checker
    def noerror_checker_func():
        pass
    noerror_checker_func()

    # Error
    @checker
    def error_checker_func():
        raise AssertionError
    try:
        error_checker_func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-12 06:22:25.718883
# Unit test for function semaphore
def test_semaphore():
    with pytest.raises(CiVerificationError):
        ci_checks.semaphore(branch="branch")


if __name__ == "__main__":
    check()

# Generated at 2022-06-12 06:22:37.841962
# Unit test for function jenkins
def test_jenkins():
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")
    assert os.environ.get("JENKINS_URL") == "https://jenkins.io"
    assert os.environ.get("CHANGE_ID") == ""
    assert os.environ.get("GIT_BRANCH") == "master"
    del os.environ["GIT_BRANCH"]
    del os.environ["JENKINS_URL"]
    del os.environ["CHANGE_ID"]
    assert os.environ.get("GIT_BRANCH") == None

# Generated at 2022-06-12 06:22:43.668395
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    if semaphore("master"):
        print("test passed")


# Generated at 2022-06-12 06:22:48.712176
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = "true"
    os.environ['CIRCLE_BRANCH'] = "master"
    del os.environ['CI_PULL_REQUEST']
    check("master")



# Generated at 2022-06-12 06:22:54.180247
# Unit test for function check
def test_check():
    # Missing env variables should raise an error
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Verification doesn't pass")

    # Passing env variables should not raise an error
    try:
        os.environ["TRAVIS"] = "true"
        check()
    except CiVerificationError:
        raise AssertionError("Verification passed")

# Generated at 2022-06-12 06:23:04.115236
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    try:
        check() 
    except Exception as err:
        assert(str(err) == "The verification check for the environment did not pass.")
        
    os.environ["BITBUCKET_BRANCH"] = "feature/t3"
    try:
        check()
    except Exception as err:
        assert(str(err) == "The verification check for the environment did not pass.")
        
    os.environ["BITBUCKET_BRANCH"] = "release/v1"
    try:
        check()
    except Exception as err:
        assert(str(err) == "The verification check for the environment did not pass.")
        

# Generated at 2022-06-12 06:23:07.296390
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = ''
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'success'
    assert semaphore('master')

# Generated at 2022-06-12 06:23:25.573719
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = 'master'
    os.environ["CI_PULL_REQUEST"] = 'false'
    try:
        check("master")
    except CiVerificationError:
        assert False

# Generated at 2022-06-12 06:23:29.111315
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = None
    check("master")

# Generated at 2022-06-12 06:23:31.324897
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://localhost:8080"
    os.environ["BRANCH_NAME"] = "master"
    jenkins()


# Generated at 2022-06-12 06:23:38.378047
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test if bitbucket is working as intended
    """
    # Success
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"

    bitbucket("master")

    # Failure
    os.environ["BITBUCKET_PR_ID"] = "PR-1"
    bitbucket("master")

# Generated at 2022-06-12 06:23:42.229480
# Unit test for function semaphore
def test_semaphore():
    """Unit test for function semaphore"""
    assert os.environ.get("BRANCH_NAME") is None
    assert os.environ.get("PULL_REQUEST_NUMBER") is None
    assert os.environ.get("SEMAPHORE_THREAD_RESULT") is None
    semaphore("master")


# Generated at 2022-06-12 06:23:45.163378
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = ''
    check()

# Generated at 2022-06-12 06:23:48.578065
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "42"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")

# Generated at 2022-06-12 06:23:53.422467
# Unit test for function checker
def test_checker():
    def inner_func(c):
        """
        inner function
        """
        print(c)
        assert c > 9
        return 1

    c = checker(inner_func)(9)
    assert c == 1

    c = checker(inner_func)(13)
    assert c == 1

    try:
        checker(inner_func)(6)
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:23:56.054449
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'False'
    check()



# Generated at 2022-06-12 06:24:03.836851
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    semaphore("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]

# Unit test function frigg

# Generated at 2022-06-12 06:24:40.017624
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'develop'
    os.environ['FRIGG_PULL_REQUEST'] = ''
    assert frigg('develop') == True
    os.environ.pop('FRIGG', None)
    os.environ.pop('FRIGG_BUILD_BRANCH', None)
    os.environ.pop('FRIGG_PULL_REQUEST', None)


# Generated at 2022-06-12 06:24:45.595826
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_BUILD_BRANCH"] = "false"
    check("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_BUILD_BRANCH"]


# Generated at 2022-06-12 06:24:49.692780
# Unit test for function frigg
def test_frigg():
    assert frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "development"
    assert not frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "1"
    assert not frigg("master")
    del os.environ["FRIGG_PULL_REQUEST"]



# Generated at 2022-06-12 06:24:53.298674
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    os.environ['CI_MERGE_REQUEST_ID'] = None
    test_return = gitlab("master")
    assert test_return == True



# Generated at 2022-06-12 06:24:57.852759
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'develop'
    os.environ['CI_PULL_REQUEST'] = 'false'
    assert circle('develop') is True


# Generated at 2022-06-12 06:25:01.196536
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    check()

# Generated at 2022-06-12 06:25:04.251512
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check("master")

# Generated at 2022-06-12 06:25:07.516982
# Unit test for function frigg
def test_frigg():
    import os
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert frigg("master") is True
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    assert frigg("master") is False



# Generated at 2022-06-12 06:25:16.387757
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "dev"
    try:
        frigg("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Function frigg doesn't work properly")
    del os.environ["FRIGG"]

# Generated at 2022-06-12 06:25:23.948023
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "foo"
    os.environ["BITBUCKET_PR_ID"] = "bar"
    try:
        bitbucket("foo")
    except Exception:
        pass
    assert "BITBUCKET_BRANCH" in os.environ
    assert "BITBUCKET_PR_ID" in os.environ



# Generated at 2022-06-12 06:26:23.547196
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")
    del os.environ["BRANCH_NAME"]
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")
    del os.environ["JENKINS_URL"]
    os.environ["JENKINS_URL"] = ""
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    finally:
        del os.environ["JENKINS_URL"]
    os.environ["JENKINS_URL"] = "https://jenkins.io"
   

# Generated at 2022-06-12 06:26:25.733150
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")



# Generated at 2022-06-12 06:26:32.530704
# Unit test for function jenkins
def test_jenkins():
    env = (
        os.environ["BRANCH_NAME"]
        or os.environ["GIT_BRANCH"]
        or os.environ["GIT_LOCAL_BRANCH"]
    )
    assert os.environ["JENKINS_URL"] is not None
    assert env == "master"
    assert not os.environ["CHANGE_ID"]



# Generated at 2022-06-12 06:26:37.618669
# Unit test for function gitlab
def test_gitlab():
    assert os.environ.get("GITLAB_CI") == "true"
    assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
    assert os.environ.get("CI_MERGE_REQUEST_ID") == "True"
    check()

# Generated at 2022-06-12 06:26:43.052006
# Unit test for function bitbucket
def test_bitbucket():
    branch = ""
    os.environ["BITBUCKET_BRANCH"] = branch
    os.environ["BITBUCKET_PR_ID"] = branch
    assert bitbucket(branch) is True
    os.environ["BITBUCKET_PR_ID"] = "pull/request"
    assert bitbucket(branch) is False

# Generated at 2022-06-12 06:26:47.471902
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    assert os.environ["TRAVIS_BRANCH"] == "master"


# Generated at 2022-06-12 06:26:56.916685
# Unit test for function check
def test_check():
    # In case the function has already been run
    os.environ.pop('TRAVIS', None)
    os.environ.pop('SEMAPHORE', None)
    os.environ.pop('FRIGG', None)
    os.environ.pop('CIRCLECI', None)
    os.environ.pop('GITLAB_CI', None)
    os.environ.pop('JENKINS_URL', None)
    os.environ.pop('BITBUCKET_BUILD_NUMBER', None)

    # Test Travis
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ

# Generated at 2022-06-12 06:27:01.547423
# Unit test for function circle
def test_circle():
    branch = 'master'
    assert "CIRCLE_BRANCH" in os.environ
    assert not os.environ.get("CI_PULL_REQUEST")
    assert check(branch) == None


# Generated at 2022-06-12 06:27:10.623924
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") == True
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") == False
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
   

# Generated at 2022-06-12 06:27:22.050387
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = None
    try:
        frigg("master")
        assert False, "Should have raised exception"
    except CiVerificationError:
        assert True
    finally:
        del os.environ["FRIGG"]
    os.environ["FRIGG_BUILD_BRANCH"] = None
    try:
        frigg("master")
        assert False, "Should have raised exception"
    except CiVerificationError:
        assert True
    finally:
        del os.environ["FRIGG_BUILD_BRANCH"]
    os.environ["FRIGG_BUILD_BRANCH"] = "not_master"
    try:
        frigg("master")
        assert False, "Should have raised exception"
    except CiVerificationError:
        assert True
   

# Generated at 2022-06-12 06:29:01.893030
# Unit test for function semaphore
def test_semaphore():
    """
    Performs necessary checks to ensure that the semaphore build is successful,
    on the correct branch and not a pull-request.

    :param branch:  The branch the environment should be running against.
    """
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    try:
        semaphore(branch="master")
    except CiVerificationError:
        assert false, "CiVerificationError raised"

# Generated at 2022-06-12 06:29:10.755579
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1234"
    # CI
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert bitbucket("master") == True
    # PR
    os.environ["BITBUCKET_PR_ID"] = "42"
    assert bitbucket("master") == False
    # Wrong branch
    os.environ["BITBUCKET_BRANCH"] = "feature_release"
    assert bitbucket("master") == False



# Generated at 2022-06-12 06:29:14.841314
# Unit test for function travis
def test_travis():
    assert os.environ.get("TRAVIS_BRANCH") == "master"
    assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"
    travis(branch="master")

# Generated at 2022-06-12 06:29:18.708797
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'test'
    check()
    os.environ['CIRCLE_BRANCH'] = 'master'
    check()
    del os.environ['CIRCLECI']
    check()


# Generated at 2022-06-12 06:29:25.976922
# Unit test for function circle
def test_circle():
    """
    Asserts that the function circle checks for the CIRCLECI environment varible
    and checks the branch on which we are
    """
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    assert not circle("master")


# Generated at 2022-06-12 06:29:31.071444
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert check(branch="master") == True



# Generated at 2022-06-12 06:29:37.582880
# Unit test for function circle
def test_circle():
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = ''
    assert circle('master')

    del os.environ['CI_PULL_REQUEST']
    assert circle('master') == False

    del os.environ['CIRCLE_BRANCH']
    assert circle('master') == False


# Generated at 2022-06-12 06:29:44.219372
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"

    del os.environ["CI_PULL_REQUEST"]
    check()

    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PULL_REQUEST"] = "1"
    try:
        check()
    except CiVerificationError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 06:29:55.258535
# Unit test for function bitbucket
def test_bitbucket():
    # without environment
    os.environ.pop('BITBUCKET_BUILD_NUMBER', None)
    assert bitbucket(branch="master") == True
    os.environ['BITBUCKET_BUILD_NUMBER'] = '1'
    os.environ.pop('BITBUCKET_BRANCH', None)
    os.environ.pop('BITBUCKET_PR_ID', None)
    assert bitbucket(branch="master") == True
    # with environment
    os.environ['BITBUCKET_BRANCH'] = 'master'
    assert bitbucket(branch="master") == True
    os.environ['BITBUCKET_PR_ID'] = '1'
    bitbucket(branch="master")


# Generated at 2022-06-12 06:30:05.035594
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    assert semaphore("master")

    os.environ["BRANCH_NAME"] = "dev"
    assert not semaphore("master")

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    assert not semaphore("master")

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
   