

# Generated at 2022-06-12 06:21:10.801466
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_ID"] = "dummy"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    check()



# Generated at 2022-06-12 06:21:19.602598
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test the function bitbucket.
    """
    branch = "master"
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"

    # Should not raise an exception
    bitbucket(branch)

    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket(branch)
    except CiVerificationError:
        os.environ.pop("BITBUCKET_PR_ID")
        os.environ.pop("BITBUCKET_BUILD_NUMBER")
        return
    assert False

# Generated at 2022-06-12 06:21:27.575348
# Unit test for function travis
def test_travis():
    # normal build
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ.pop("TRAVIS_BRANCH")
    os.environ.pop("TRAVIS_PULL_REQUEST")

    # pull request
    os.environ["TRAVIS_PULL_REQUEST"] = "1"
    with raises(CiVerificationError) as e:
        travis("master")
    os.environ.pop("TRAVIS_PULL_REQUEST")
    assert "The verification check for the environment did not pass." in str(e)

    # wrong branch
    os.environ["TRAVIS_BRANCH"] = "master1"
   

# Generated at 2022-06-12 06:21:32.989042
# Unit test for function checker
def test_checker():
    # This test should pass
    @checker
    def test_fun_pass():
        assert True

    test_fun_pass()

    # This test should fail
    @checker
    def test_fun_fail():
        assert False

    try:
        test_fun_fail()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-12 06:21:35.562163
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://localhost"
    os.environ["BRANCH_NAME"] = "master"
    jenkins(branch="master")



# Generated at 2022-06-12 06:21:36.869210
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket("master") == None

# Generated at 2022-06-12 06:21:40.292339
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-12 06:21:45.791049
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    try:
        check()
    except CiVerificationError:
        assert False
    else:
        assert True



# Generated at 2022-06-12 06:21:46.271548
# Unit test for function travis
def test_travis():
    travis("master")

# Generated at 2022-06-12 06:21:51.665518
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["GITLAB_CI"] = "true"
    gitlab("master")
    os.environ.pop("CI_COMMIT_REF_NAME")
    os.environ.pop("GITLAB_CI")

# Generated at 2022-06-12 06:22:02.454940
# Unit test for function checker
def test_checker():
    """Test for checker"""

    @checker
    def assert_function(should_pass):
        assert should_pass

    assert assert_function(True) == True

    try:
        assert_function(False)
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-12 06:22:06.723319
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = ""

    check()
    
    assert os.environ["GITLAB_CI"] is "true"

# Generated at 2022-06-12 06:22:12.674112
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "true"
    os.environ["BITBUCKET_BRANCH"] = "abc"
    os.environ["BITBUCKET_PR_ID"] = "true"
    try:
        bitbucket(branch="master")
        assert(False)
    except CiVerificationError:
        assert(True)
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "false"
    assert bitbucket(branch="master")
    del os.environ["BITBUCKET_BUILD_NUMBER"]
    del os.environ["BITBUCKET_BRANCH"]

# Generated at 2022-06-12 06:22:18.524945
# Unit test for function circle
def test_circle():
    # Travis environment variables
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"

    assert circle("master") is False

    os.environ["CI_PULL_REQUEST"] = "false"

    assert circle("dev") is False

    os.environ["CIRCLE_BRANCH"] = "dev"

    assert circle("dev") is True

# Generated at 2022-06-12 06:22:24.763737
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"

    semaphore("master")

# Generated at 2022-06-12 06:22:32.254092
# Unit test for function jenkins
def test_jenkins():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "develop"
    res = jenkins("develop")
    assert res == True
    os.environ["BRANCH_NAME"] = "master"
    res = jenkins("master")
    assert res == False
    del os.environ["BRANCH_NAME"]
    del os.environ["SEMAPHORE"]

# Generated at 2022-06-12 06:22:37.220723
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket(branch="master")
    assert os.environ.get("BITBUCKET_BRANCH") == "master"


# Generated at 2022-06-12 06:22:46.958946
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    assert frigg("master") is False
    os.environ["FRIGG_PULL_REQUEST"] = "12"
    assert frigg("master") is False
    assert os.environ["FRIGG_BUILD_BRANCH"] == "develop"
    del os.environ["FRIGG_BUILD_BRANCH"]
    assert frigg("master") is False
    del os.environ["FRIGG"]
    assert frigg("master") is False
    del os.environ["FRIGG_PULL_REQUEST"]

# Generated at 2022-06-12 06:22:49.490819
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "True"
    check()

# Generated at 2022-06-12 06:22:55.867209
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "qa-branch"
    try:
        gitlab("master")
        assert False
    except CiVerificationError:
        assert True
    del os.environ["CI_COMMIT_REF_NAME"]
    try:
        gitlab("master")
        assert False
    except AssertionError:
        assert True
    del os.environ["GITLAB_CI"]
    assert gitlab("master") is True

# Generated at 2022-06-12 06:23:18.693504
# Unit test for function circle
def test_circle():
    assert os.environ.get("CIRCLECI") is None
    try:
        circle(branch='master')
        assert 0
    except CiVerificationError:
        pass

    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    circle(branch='master')
    assert os.environ.get('CI_PULL_REQUEST')

    os.environ['CI_PULL_REQUEST'] = ''
    circle(branch='master')

    os.environ['CI_PULL_REQUEST'] = 'true'
    try:
        circle(branch='master')
        assert 0
    except CiVerificationError:
        pass

    del os.environ['CI_PULL_REQUEST']

# Generated at 2022-06-12 06:23:23.741699
# Unit test for function checker
def test_checker():
    with raises(CiVerificationError) as e:
        @checker
        def should_raise_error():
            assert False
        should_raise_error()
    assert e.value.message == "The verification check for the environment did not pass."


# Unit tests for function check

# Generated at 2022-06-12 06:23:32.442134
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    try:
        bitbucket(os.environ["BITBUCKET_BRANCH"])
    except CiVerificationError:
        raise AssertionError("The branch and pull request fields do match environment variables")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket(os.environ["BITBUCKET_BRANCH"])
        raise AssertionError("The branch and pull request fields do not match environment variables")
    except CiVerificationError:
        print("Correctly raises an exception when the branch and pull request fields do not match environment variables")

# Generated at 2022-06-12 06:23:42.948369
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("master")
    except CiVerificationError:
        assert True
    else:
        assert False

    os.environ["BRANCH_NAME"] = "develop"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ

# Generated at 2022-06-12 06:23:46.037127
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-12 06:23:47.802715
# Unit test for function bitbucket
def test_bitbucket():
    try:
        bitbucket(branch="release-0.0.1")
        assert False
    except:
        assert True



# Generated at 2022-06-12 06:23:56.054866
# Unit test for function semaphore
def test_semaphore():
    # Should pass
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["PULL_REQUEST_NUMBER"] = None
    semaphore("master")

    # Should fail due to bad branch, but no exception is raised
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["PULL_REQUEST_NUMBER"] = None
    semaphore("master")

    # Should fail due to bad branch and pull request
    os.environ["BRANCH_NAME"] = "develop"

# Generated at 2022-06-12 06:24:05.988372
# Unit test for function gitlab
def test_gitlab():
    """ Function gitlab should raise a 
    CiVerificationError when the checks fail.
    """
    os.environ["CI_COMMIT_REF_NAME"] = "test"
    os.environ["GITLAB_CI"] = "true"
    try:
        gitlab("master")
        assert False
    except CiVerificationError:
        assert True
        os.environ["CI_COMMIT_REF_NAME"] = "master"
        assert gitlab("master") == True
        os.environ.pop("CI_COMMIT_REF_NAME")
        os.environ.pop("GITLAB_CI")


# Generated at 2022-06-12 06:24:08.538888
# Unit test for function frigg
def test_frigg():
    with os.environ.copy():
        os.environ["FRIGG"] = "true"
        os.environ["FRIGG_BUILD_BRANCH"] = "master"
        check()

# Generated at 2022-06-12 06:24:14.403894
# Unit test for function gitlab
def test_gitlab():
    # Check with defined env variable
    os.environ["CI_COMMIT_REF_NAME"] = "my-branch"
    assert gitlab("my-branch")

    # Check with undefined env variable
    os.environ["CI_COMMIT_REF_NAME"] = "my-branch"
    del os.environ["CI_COMMIT_REF_NAME"]
    assert not gitlab("my-branch")

    # Check with a different branch
    os.environ["CI_COMMIT_REF_NAME"] = "other-branch"
    assert not gitlab("my-branch")

# Generated at 2022-06-12 06:24:47.534605
# Unit test for function circle
def test_circle():
    """Test the function circle"""
    user_envir = {
        "CIRCLECI": True,
        "CIRCLE_BRANCH": "master",
        "CI_PULL_REQUEST": None,
    }
    os.environ = user_envir
    branch = "master"
    check(branch)



# Generated at 2022-06-12 06:24:49.722060
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()


# Generated at 2022-06-12 06:24:59.121011
# Unit test for function bitbucket
def test_bitbucket():
    """
    A unit test for the bitbucket function
    """
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "456"
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        assert True

    os.environ["BITBUCKET_BRANCH"] = "non master"

    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        assert True

    os.environ["BITBUCKET_BRANCH"] = "master"
    del os.environ["BITBUCKET_PR_ID"]

# Generated at 2022-06-12 06:25:00.992770
# Unit test for function check
def test_check():
    check()

# Generated at 2022-06-12 06:25:07.170544
# Unit test for function frigg
def test_frigg():
    try:
        os.environ["FRIGG"] = "true"
        os.environ["FRIGG_BUILD_BRANCH"] = "master"
        frigg("master")

        os.environ["FRIGG_BUILD_BRANCH"] = "feature"
        frigg("master")

        os.environ["FRIGG"] = "false"
        frigg("master")
    except CiVerificationError:
        pass
    finally:
        os.environ.pop("FRIGG_BUILD_BRANCH", None)
        os.environ.pop("FRIGG", None)



# Generated at 2022-06-12 06:25:12.330328
# Unit test for function travis
def test_travis():
    assert travis == os.environ.get("TRAVIS_BRANCH")
    assert travis == os.environ.get("TRAVIS_PULL_REQUEST")

# Generated at 2022-06-12 06:25:16.489805
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = None
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = None
    # no pull requests
    jenkins("master")

# Generated at 2022-06-12 06:25:26.116777
# Unit test for function frigg
def test_frigg():
    """
    Ensures the frigg checker functions correctly by asserting a CiVerificationError
    when an assertion error is raised.
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "not correct"
    try:
        frigg("correct")
        raise AssertionError("Expected a CiVerificationError")
    except CiVerificationError:
        pass
    finally:
        del os.environ["FRIGG"]
        del os.environ["FRIGG_BUILD_BRANCH"]

# Generated at 2022-06-12 06:25:35.649661
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should have raised an exception")

# Generated at 2022-06-12 06:25:40.925765
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check(branch="master")



# Generated at 2022-06-12 06:26:48.028479
# Unit test for function checker
def test_checker():
    # type: () -> None
    """
    Tests the checker decorator.
    """
    # This test is visible, because the decorators are only visible in the
    # test files.

# Generated at 2022-06-12 06:26:54.838671
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    assert frigg("develop")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert not frigg("develop")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    assert not frigg("develop")


# Generated at 2022-06-12 06:26:59.150983
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle()
    os.environ["CIRCLE_BRANCH"] = "master-2"
    os.environ["CI_PULL_REQUEST"] = "http://"
    assert not circle()



# Generated at 2022-06-12 06:27:04.469297
# Unit test for function bitbucket
def test_bitbucket():
    #setup
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = True
    expected_result= True
    #act
    result = bitbucket("master")
    #assert
    assert result == expected_result

# Generated at 2022-06-12 06:27:07.501842
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master") == True


# Generated at 2022-06-12 06:27:16.483556
# Unit test for function checker
def test_checker():
    def test_func():
        raise AssertionError

    @checker
    def checker_test():
        test_func()

    # Error is not raised
    try:
        checker_test()
    except CiVerificationError:
        raise AssertionError

    # Error is raised
    try:
        test_func()
    except CiVerificationError as e:
        raise AssertionError from e
    except AssertionError as e:
        assert str(e) == 'The verification check for the environment did not pass.'

# Generated at 2022-06-12 06:27:22.980795
# Unit test for function checker
def test_checker():
    """
    test function checker
    """
    @checker
    def test_something(a: str, b: str) -> str:
        """
        test something
        :return: string
        """
        assert a == b
        assert a != "foo"
        return a

    assert test_something("foo", "foo") is True
    assert test_something("foo", "bar") is True


# Unit tests for environment variables
# Non-exhaustive, as these are system variables

# Generated at 2022-06-12 06:27:30.002512
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = True
    os.environ["BRANCH_NAME"] = "test_branch"
    os.environ["CHANGE_ID"] = False
    assert jenkins("test_branch") == True
    os.environ["CHANGE_ID"] = True
    try:
        jenkins("test_branch")
    except CiVerificationError:
        assert True
        return
    raise AssertionError("No error raised")
    os.environ.pop("JENKINS_URL")


# Generated at 2022-06-12 06:27:32.696243
# Unit test for function jenkins

# Generated at 2022-06-12 06:27:35.007095
# Unit test for function travis
def test_travis():
    assert travis("master") == True
    assert travis("someotherbranch") == False


# Generated at 2022-06-12 06:29:32.691616
# Unit test for function bitbucket
def test_bitbucket():
    environment = "master"
    assert bitbucket(branch=environment) == True

# Generated at 2022-06-12 06:29:39.301656
# Unit test for function gitlab
def test_gitlab():
    os.environ = {
        "CI_COMMIT_REF_NAME": "master",
        "CI_PROJECT_NAME": "semantic-release",
        "CI_PROJECT_NAMESPACE": "relekang",
        "CI_PROJECT_PATH": "relekang/semantic-release",
        "CI_PROJECT_URL": "https://gitlab.com/relekang/semantic-release",
    }
    gitlab("master")

# Generated at 2022-06-12 06:29:44.062147
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "test"
    os.environ["BITBUCKET_BRANCH"] = "test"
    os.environ["BITBUCKET_PR_ID"] = "test"
    try:
        bitbucket("test")
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-12 06:29:54.824411
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_PULL_REQUEST'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'notmaster'
    try:
        frigg('master')
        assert False, 'Error: Frigg check should fail'
    except CiVerificationError as e:
        assert str(e) == 'The verification check for the environment did not pass.'
    os.environ['FRIGG'] = 'false'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'



# Generated at 2022-06-12 06:29:55.883806
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("master")

# Generated at 2022-06-12 06:30:05.629674
# Unit test for function jenkins
def test_jenkins():
    os.environ.pop("JENKINS_URL", None)
    os.environ.pop("BRANCH_NAME", None)
    os.environ.pop("GIT_BRANCH", None)
    os.environ.pop("CHANGE_ID", None)

    with pytest.raises(CiVerificationError):
        jenkins("branch")

    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "branch"
    os.environ["CHANGE_ID"] = "1"

    with pytest.raises(CiVerificationError):
        jenkins("branch")

    os.environ["CHANGE_ID"] = ""

# Generated at 2022-06-12 06:30:16.090021
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "feat"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        frigg(branch="feat")
    except AssertionError:
        assert True
    else:
        assert False

    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    try:
        frigg(branch="master")
    except AssertionError:
        assert False
    else:
        assert True

    os.environ["FRIGG_BUILD_BRANCH"] = "master"

# Generated at 2022-06-12 06:30:18.361727
# Unit test for function travis
def test_travis():
    assert travis('master')
    try:
        travis('feature')
    except CiVerificationError:
        pass


# Generated at 2022-06-12 06:30:24.136357
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = 1
    try:
        bitbucket()
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket()
    del os.environ["BITBUCKET_BRANCH"]
    try:
        bitbucket()
    except CiVerificationError:
        pass
    else:
        assert False



# Generated at 2022-06-12 06:30:27.946523
# Unit test for function travis
def test_travis():
    try:
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        travis("master")
        assert True
    except:
        assert False

