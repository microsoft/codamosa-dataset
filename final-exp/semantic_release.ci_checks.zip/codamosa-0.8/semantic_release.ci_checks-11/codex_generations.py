

# Generated at 2022-06-12 06:21:09.690895
# Unit test for function jenkins
def test_jenkins():
    # Should raise an exception
    os.environ["BRANCH_NAME"] = "not-master"
    try:
        jenkins("master")
    except Exception:
        os.environ.pop("BRANCH_NAME")
        return
    raise Exception("Did not raise CiVerificationError")



# Generated at 2022-06-12 06:21:13.716089
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for function bitbucket
    """
    # Not a pull request
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "None"
    assert bitbucket("master")

    # A pull request
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "7"
    assert not bitbucket("master")

    # Not the right branch
    os.environ["BITBUCKET_BRANCH"] = "not-master"
    os.environ["BITBUCKET_PR_ID"] = "None"
    assert not bitbucket("master")


# Generated at 2022-06-12 06:21:20.598961
# Unit test for function jenkins
def test_jenkins():
    try:
        original_env = os.environ.copy()
        os.environ["JENKINS_URL"] = "http://jenkins.source"
        os.environ["BRANCH_NAME"] = "feature/new"
        os.environ["CHANGE_ID"] = "1234"
        jenkins("master")
        assert False
    except CiVerificationError:
        pass
    finally:
        os.environ.clear()
        os.environ.update(original_env)


# Generated at 2022-06-12 06:21:23.544002
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")



# Generated at 2022-06-12 06:21:25.842763
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")
    del os.environ["BITBUCKET_BRANCH"]



# Generated at 2022-06-12 06:21:36.299140
# Unit test for function checker
def test_checker():
    @checker
    def test_raise_assertionerror():  # pylint: disable=unused-variable
        assert False

    def test_raise_cierror():  # pylint: disable=unused-variable
        try:
            test_raise_assertionerror()  # pylint: disable=undefined-variable
        except CiVerificationError:
            raise AssertionError("test_raise_cierror should not raise CiVerificationError")

    def test_raise_cierror_on_asserterror():  # pylint: disable=unused-variable
        try:
            test_raise_assertionerror()  # pylint: disable=undefined-variable
        except CiVerificationError:
            pass

    test_raise_cierror()
    test_raise_cierror_on_asser

# Generated at 2022-06-12 06:21:44.081841
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master") is True
    os.environ["CI_PULL_REQUEST"] = "PR_ID"
    assert circle("master") is False
    os.environ["CIRCLE_BRANCH"] = "not-master"
    assert circle("master") is False

# Generated at 2022-06-12 06:21:51.719454
# Unit test for function bitbucket
def test_bitbucket():
    def build_environ(branch="master", pull_request=None):
        environ = dict(os.environ)
        environ["BITBUCKET_BRANCH"] = branch
        if pull_request is None:
            environ.pop("BITBUCKET_PR_ID", None)
        else:
            environ["BITBUCKET_PR_ID"] = str(pull_request)

        if "BITBUCKET_BUILD_NUMBER" in environ:
            del environ["BITBUCKET_BUILD_NUMBER"]
        return environ

    # Unknown environment
    with os.environ as environ:
        environ.clear()
        try:
            bitbucket("master")
        except CiVerificationError:
            pass
        else:
            assert False, "Exception expected"



# Generated at 2022-06-12 06:22:02.238891
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master123"
    os.environ["CI_MERGE_REQUEST_IID"] = None
    assert check()
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = None
    assert check()
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = "300"
    from semantic_release.errors import CiVerificationError
    try:
        check()
        assert False
    except CiVerificationError as e:
        assert True
        print(e)



# Generated at 2022-06-12 06:22:10.534949
# Unit test for function jenkins
def test_jenkins():
    """
    Unit test for function jenkins
    """
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "false"
    assert jenkins("master") == True
    del os.environ["JENKINS_URL"]
    del os.environ["BRANCH_NAME"]
    del os.environ["CHANGE_ID"]
    try:
        os.environ["BRANCH_NAME"] = "dev"
        assert jenkins("master") == False
    finally:
        del os.environ["BRANCH_NAME"]

# Generated at 2022-06-12 06:22:27.689049
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    check(branch='master')

    os.environ['FRIGG_BUILD_BRANCH'] = 'develop'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    try:
        check(branch='master')
        assert False
    except CiVerificationError:
        assert True

    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'true'

# Generated at 2022-06-12 06:22:37.036370
# Unit test for function bitbucket
def test_bitbucket():
    branch = "master"
    os.environ["BITBUCKET_BUILD_NUMBER"] = "0"
    os.environ["BITBUCKET_BRANCH"] = branch
    os.environ["BITBUCKET_PR_ID"] = "0"
    check(branch)
    del os.environ["BITBUCKET_BUILD_NUMBER"]
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]
    #raise Exception()

# Generated at 2022-06-12 06:22:41.165927
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "some_url"
    assert check() is None



# Generated at 2022-06-12 06:22:44.675834
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "True"
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")



# Generated at 2022-06-12 06:22:55.606977
# Unit test for function frigg
def test_frigg():
    assert frigg('develop')('develop')
    assert frigg('master')('master')
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    assert frigg('master')()
    del os.environ['FRIGG_BUILD_BRANCH']
    os.environ['FRIGG_PULL_REQUEST'] = 'true'
    assert frigg('master')()
    del os.environ['FRIGG_PULL_REQUEST']
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    assert frigg('master')()
    del os.environ['FRIGG_BUILD_BRANCH']
    os.environ['FRIGG_PULL_REQUEST'] = 'true'

# Generated at 2022-06-12 06:23:00.580201
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    check()


if __name__ == "__main__":
    test_frigg()

# Generated at 2022-06-12 06:23:09.258013
# Unit test for function travis
def test_travis():
    """
    Test travis environment
    """
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["TRAVIS_BRANCH"] = "not-master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        check()
        assert False, "This should have failed"
    except CiVerificationError:
        pass
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
        assert False, "This should have failed"
    except CiVerificationError:
        pass
   

# Generated at 2022-06-12 06:23:14.457144
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    del os.environ["FRIGG_PULL_REQUEST"]
    frigg(branch="master")
    os.environ["FRIGG_BUILD_BRANCH"] = "development"
    frigg(branch="master")



# Generated at 2022-06-12 06:23:16.653329
# Unit test for function bitbucket
def test_bitbucket():
    assert os.environ.get("BITBUCKET_BUILD_NUMBER") == 'NULL'

# Generated at 2022-06-12 06:23:27.242694
# Unit test for function check
def test_check():
    """
    Test if function check works for these CI systems:
    - Travis
    - Frigg
    - Jenkins
    - Circle
    """
    os.environ["TRAVIS"] = "true"
    check("dev")
    os.environ["TRAVIS"] = ""
    os.environ["FRIGG"] = "true"
    check("dev")
    os.environ["FRIGG"] = ""
    os.environ["JENKINS_URL"] = "https://jenkins.my-ci-system.com"
    check("dev")
    os.environ["JENKINS_URL"] = ""
    os.environ["CIRCLECI"] = "true"
    check("dev")
    os.environ["CIRCLECI"] = ""

# Generated at 2022-06-12 06:23:42.947988
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "test"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    check()

# Generated at 2022-06-12 06:23:47.917535
# Unit test for function checker
def test_checker():
    # wrong type
    def w(a):
        pass
    assert checker(w) == w

    # correct type
    pre_exception = False
    def w(a):
        nonlocal pre_exception
        assert pre_exception, "This is a successful test"
    try:
        checker(w)()
    except CiVerificationError:
        pass
    else:
        assert False, "The decorator did not remap the exceptions"
    pre_exception = True
    checker(w)()

# Generated at 2022-06-12 06:23:55.192480
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    os.environ["CI_MERGE_REQUEST_IID"] = "10"

    try:
        gitlab("master")
        assert False
    except CiVerificationError:
        pass

    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_IID"]
    try:
        gitlab("develop")
        assert True
    except CiVerificationError:
        assert False

    del os.environ["GITLAB_CI"]

# Generated at 2022-06-12 06:24:00.238571
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "develop"
    os.environ["CHANGE_ID"] = "5"
    check("develop")

# Generated at 2022-06-12 06:24:02.457387
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-12 06:24:09.503709
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://ci.jenkins.io/"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = ""  # No value
    jenkins("master")  # Should not raise an exception
    os.environ["BRANCH_NAME"] = "dev"
    with pytest.raises(CiVerificationError):
        jenkins("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "53"  # Value
    with pytest.raises(CiVerificationError):
        jenkins("master")
    del os.environ["JENKINS_URL"]

# Generated at 2022-06-12 06:24:10.437618
# Unit test for function frigg
def test_frigg():
    assert frigg



# Generated at 2022-06-12 06:24:16.662891
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master")

    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    assert semaphore("master")

    os.environ["BRANCH_NAME"] = "branch"
    assert semaphore("master")
    os.environ["PULL_REQUEST_NUMBER"] = "1234"
    assert semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master")


# Generated at 2022-06-12 06:24:17.423741
# Unit test for function check
def test_check():
    check()

# Generated at 2022-06-12 06:24:18.563143
# Unit test for function frigg
def test_frigg():
    with os.environ.copy() as env:
        env["FRIGG"] = "true"
        env["FRIGG_BUILD_BRANCH"] = "master"
        frigg("master")

# Generated at 2022-06-12 06:24:44.809127
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.url"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "123"
    check()

# Generated at 2022-06-12 06:24:54.227797
# Unit test for function bitbucket
def test_bitbucket():
    """
    Tests that bitbucket raises an exception if `BITBUCKET_BUILD_NUMBER` is not in os.environ.
    """
    import os
    os.environ["BITBUCKET_BUILD_NUMBER"] = "test"
    try:
        bitbucket()
    except CiVerificationError:
        raise AssertionError("bitbucket did not return a boolean.")
    os.environ.pop("BITBUCKET_BUILD_NUMBER")

    try:
        bitbucket()
        raise AssertionError("bitbucket did not raise a CiVerificationError.")
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:25:06.422196
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_IID'] = None
    assert check()
    os.environ['CI_MERGE_REQUEST_IID'] = '123'
    try:
        check()
        assert False, 'This line should not be reached'
    except AssertionError:
        pass

    os.environ['CI_COMMIT_REF_NAME'] = 'release'
    os.environ['CI_MERGE_REQUEST_IID'] = '123'
    try:
        check('release')
        assert True, 'This line should be reached'
    except AssertionError:
        assert False, 'This line should not be reached'

    os.environ['CI_COMMIT_REF_NAME']

# Generated at 2022-06-12 06:25:17.042777
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://localhost:8080"
    os.environ["BRANCH_NAME"] = "dev"
    jenkins("dev")
    os.environ["BRANCH_NAME"] = "master"
    jenkins("master")

    os.environ["JENKINS_URL"] = None
    del os.environ["BRANCH_NAME"]
    os.environ["GIT_BRANCH"] = "dev"
    jenkins("dev")
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")

# Generated at 2022-06-12 06:25:24.195989
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    os.environ["FRIGG_PULL_REQUEST"] = "1337"
    try:
        frigg("test")
    except CiVerificationError:
        return 1
    raise AssertionError("Should have raised error!")


# Generated at 2022-06-12 06:25:28.770634
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()

# Generated at 2022-06-12 06:25:33.131885
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    try:
        gitlab("master")
        assert False
    except CiVerificationError :
        assert True
    except Exception:
        assert False

# Generated at 2022-06-12 06:25:36.215536
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    check()

# Generated at 2022-06-12 06:25:41.076700
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_BRANCH"] = "master"
    circle(branch="master")


# Generated at 2022-06-12 06:25:52.336387
# Unit test for function circle
def test_circle():
    """Test the circle function"""
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master")

    os.environ["CIRCLE_BRANCH"] = "master2"
    os.environ["CI_PULL_REQUEST"] = ""
    try:
        assert circle("master")
    except CiVerificationError:
        assert True
    except AssertionError:
        assert False

    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "23"
    try:
        assert circle("master")
    except CiVerificationError:
        assert True

# Generated at 2022-06-12 06:26:50.268844
# Unit test for function check
def test_check():
    """
    Unit test for function check
    """
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "test"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check("test")

    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check("test")
    except CiVerificationError:
        pass

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "test"

# Generated at 2022-06-12 06:26:53.755634
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    check()

# Generated at 2022-06-12 06:27:01.089208
# Unit test for function gitlab
def test_gitlab():
    assert os.environ.get("GITLAB_CI") == "true"
    assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
    assert not os.environ.get("CI_MERGE_REQUEST_ID")
    assert os.environ.get("CI_PROJECT_NAMESPACE") == "dummy-test"
    assert os.environ.get("CI_PROJECT_NAME") == "dummy-project"
    assert os.environ.get("CI_PROJECT_URL") == "http://gitlab-ci.com/namespace/project"
    assert os.environ.get("CI_COMMIT_SHA") == "dummysha"
    assert os.environ.get("CI_COMMIT_SHORT_SHA") == "dummysha"


# Generated at 2022-06-12 06:27:10.441797
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    check()
    del os.environ['TRAVIS']
    del os.environ['TRAVIS_BRANCH']
    del os.environ['TRAVIS_PULL_REQUEST']

    os.environ['SEMAPHORE'] = 'true'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = ''
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    check()
    del os.environ['SEMAPHORE']
    del os

# Generated at 2022-06-12 06:27:12.012438
# Unit test for function check
def test_check():
    #call a function to check if it is travis
    check()
    assert True

# Generated at 2022-06-12 06:27:17.969827
# Unit test for function semaphore
def test_semaphore():
    with open('env.list', 'r') as env_f:
        line = env_f.readline()
        while line:
            key, value = line.strip().split('=')
            os.environ[key] = value
            line = env_f.readline()
    return semaphore(os.environ.get("BRANCH_NAME"))

# Generated at 2022-06-12 06:27:29.760524
# Unit test for function gitlab
def test_gitlab():

    os.environ.setdefault("CI_COMMIT_REF_NAME", "master")
    os.environ.setdefault("CI_MERGE_REQUEST_IID", "123")
    os.environ.setdefault("CI_MERGE_REQUEST_SOURCE_BRANCH_NAME", "branch_name")

    try:
        check()
    except CiVerificationError:
        pass
    except Exception:
        raise AssertionError("Should have raised a CiVerificationError.")

    os.environ.setdefault("CI_MERGE_REQUEST_IID", None)
    try:
        check()
    except CiVerificationError:
        raise AssertionError("Should not have raised a CiVerificationError.")
    except Exception:
        raise AssertionError("Should not have raised any exception.")

# Generated at 2022-06-12 06:27:33.951325
# Unit test for function frigg
def test_frigg():
    expected_env = {
        "FRIGG": "true",
        "FRIGG_BUILD_BRANCH": "master"
    }
    frigg(branch="master")

# Generated at 2022-06-12 06:27:44.332600
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "True"
    os.environ["BITBUCKET_BRANCH"] = "wip"
    os.environ["BITBUCKET_PR_ID"] = "12345"
    try:
        bitbucket("wip")
    except Exception as e:
        assert isinstance(e, CiVerificationError)
    else:
        raise Exception("Should have raised an error")

    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    assert bitbucket("master") == True


# Generated at 2022-06-12 06:27:53.789636
# Unit test for function semaphore
def test_semaphore():
    # Arrange
    branch = "master"
    # Act and assert
    semaphore(branch)
    # Empty branch name
    branch = ""
    try:
        # Act and assert
        semaphore(branch)
        assert False
    except CiVerificationError:
        assert True
    # Set branch name
    branch = "master"
    # Set pull request number
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    try:
        # Act and assert
        semaphore(branch)
        assert False
    except CiVerificationError:
        assert True
    # Set thread result
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"

# Generated at 2022-06-12 06:29:32.038501
# Unit test for function checker
def test_checker():
    @checker
    def func():
        assert False

    try:
        func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-12 06:29:37.625325
# Unit test for function checker
def test_checker():
    @checker
    def really_add(x):
        assert x == 3
    try:
        really_add(2)
    except CiVerificationError as e:
        msg = e.args[0]
    else:
        assert False, "CiVerificationError not raised!"
    assert msg == "The verification check for the environment did not pass."

# Generated at 2022-06-12 06:29:46.119138
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = ""
    assert check(branch="master") is None
    os.environ['CIRCLE_BRANCH'] = 'wrong_branch'
    assert check(branch="master") is None
    os.environ['CI_PULL_REQUEST'] = "https://pull_req.com"
    assert check(branch="master") is None
    # Reset environment to avoid conflicts with other tests
    os.environ['CIRCLECI'] = ""
    os.environ['CIRCLE_BRANCH'] = ""
    os.environ['CI_PULL_REQUEST'] = ""



# Generated at 2022-06-12 06:29:55.126436
# Unit test for function checker
def test_checker():
    """
    Unit tests for function checker.
    """

    # Test that checker handles exceptions the same way
    @checker
    def raise_assertion_error():
        raise AssertionError

    try:
        raise_assertion_error()
    except CiVerificationError:
        pass

    # Test that checker also raises errors in unexpected situations.
    @checker
    def raise_unexpected_error():
        raise Exception

    try:
        raise_unexpected_error()
    except CiVerificationError:
        pass

    # Test that checker just returns True in the expected situation
    @checker
    def good_function():
        pass

    assert good_function()



# Generated at 2022-06-12 06:29:58.290609
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = branch = "master"
    os.environ["JENKINS_URL"] = "https://url.com"
    os.environ["CHANGE_ID"] = "123"
    jenkins(branch)

# Generated at 2022-06-12 06:30:02.756034
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")


# Generated at 2022-06-12 06:30:11.964715
# Unit test for function gitlab
def test_gitlab():
    """
    Test: Performs necessary checks to ensure that the gitlab build is one
    that should create releases.

    :param branch: The branch the environment should be running against.
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    os.environ["CI_COMMIT_REF_NAME"] = "gitlab"  # set environ
    gitlab("master")
    os.environ.pop("CI_COMMIT_REF_NAME")  # unset environ
    os.environ.pop("CI_MERGE_REQUEST_ID")  # unset environ



# Generated at 2022-06-12 06:30:14.497192
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-12 06:30:19.976143
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "test-branch"
    bitbucket("test-branch")
    os.environ["BITBUCKET_PR_ID"] = "1"
    bitbucket("test-branch")
    del os.environ["BITBUCKET_PR_ID"]


# Generated at 2022-06-12 06:30:30.601398
# Unit test for function frigg
def test_frigg():
    case = os.environ.get
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "dev"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    assert check() == None
    os.environ["FRIGG_BUILD_BRANCH"] = "dev"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    assert check() == True
    os.environ["FRIGG_BUILD_BRANCH"] = "dev"
    os.environ["FRIGG_PULL_REQUEST"] = "True"
    assert check() == None
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os