

# Generated at 2022-06-12 06:21:14.420701
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg(branch="master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "random"
    try:
        frigg(branch="master")
    except Exception as e:
        assert str(e) == "The verification check for the environment did not pass."

    # No Error should be thrown
    os.environ["FRIGG_PULL_REQUEST"] = "false"

# Generated at 2022-06-12 06:21:23.526277
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    assert bitbucket("master") == True
    os.environ["BITBUCKET_BRANCH"] = "branch1"
    os.environ["BITBUCKET_PR_ID"] = ""
    assert bitbucket("master") == False
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123"
    assert bitbucket("master") == False
    os.environ["BITBUCKET_BRANCH"] = "master"
    del os.environ["BITBUCKET_PR_ID"]
    assert bitbucket("master") == True

# Generated at 2022-06-12 06:21:28.263449
# Unit test for function bitbucket
def test_bitbucket():
    """
    :Test for function bitbucket
    """
    assert bitbucket("master")
    os.environ["BITBUCKET_PR_ID"] = 1
    assert not bitbucket("master")
    del os.environ["BITBUCKET_PR_ID"]
    os.environ["BITBUCKET_BRANCH"] = "dev"
    assert not bitbucket("master")
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_BUILD_NUMBER"]



# Generated at 2022-06-12 06:21:35.084436
# Unit test for function checker
def test_checker():
    @checker
    def check_one():
        raise AssertionError

    @checker
    def check_two():
        pass

    def check_three():
        raise AssertionError

    try:
        check_one()
    except CiVerificationError:
        pass
    else:
        raise Exception("No assertion error was raised.")

    check_two()

    try:
        check_three()
    except AssertionError:
        pass
    else:
        raise Exception("No assertion error was raised.")

# Generated at 2022-06-12 06:21:47.183585
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "test_branch"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore(os.environ["BRANCH_NAME"])
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    os.environ["BRANCH_NAME"] = "test_branch"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"

# Generated at 2022-06-12 06:21:54.009804
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '1'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = '2'

    try:
        bitbucket("master")
    except AssertionError:
        return
    raise AssertionError("bitbucket checker does not work for pull request")

# Generated at 2022-06-12 06:22:04.443337
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    os.environ['FRIGG_PULL_REQUEST'] = None
    frigg("master")
    os.environ['FRIGG_BUILD_BRANCH'] = "develop"
    os.environ['FRIGG_PULL_REQUEST'] = None
    frigg("master")
    del os.environ['FRIGG_BUILD_BRANCH']
    del os.environ['FRIGG_PULL_REQUEST']

# Unit test function for Jenkins
# Test case 1-Execeute the function when environment variable is set.

# Generated at 2022-06-12 06:22:07.880682
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    assert semaphore("master") == True

# Generated at 2022-06-12 06:22:16.133461
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    check("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "branch"
    try:
        check("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["FRIGG_PULL_REQUEST"] = "42"
    try:
        check("master")
    except CiVerificationError:
        pass
    else:
        assert False


# Generated at 2022-06-12 06:22:27.001238
# Unit test for function gitlab
def test_gitlab():
    try:
        os.environ["GITLAB_CI"] = "true"
        os.environ["CI_COMMIT_REF_NAME"] = "master"
        check(branch="master")
        assert True
    except CiVerificationError:
        assert False

    try:
        os.environ["GITLAB_CI"] = "true"
        os.environ["CI_COMMIT_REF_NAME"] = "release"
        check()
        assert False
    except CiVerificationError:
        assert True

    try:
        os.environ["GITLAB_CI"] = "true"
        os.environ["CI_COMMIT_REF_NAME"] = "master"
        check()
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-12 06:22:38.180789
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = "true"
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    check()
    del os.environ['TRAVIS']
    del os.environ['TRAVIS_BRANCH']
    del os.environ['TRAVIS_PULL_REQUEST']

# Generated at 2022-06-12 06:22:47.030051
# Unit test for function frigg

# Generated at 2022-06-12 06:22:48.854260
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = "test-branch"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"

    travis("test-branch")



# Generated at 2022-06-12 06:22:55.126033
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = 'master'
    os.environ["TRAVIS_PULL_REQUEST"] = 'false'
    travis('master')
    os.environ["TRAVIS_BRANCH"] = 'dev'
    os.environ["TRAVIS_PULL_REQUEST"] = 'false'
    travis('dev')
    try:
        travis('master')
    except CiVerificationError:
        pass


# Generated at 2022-06-12 06:22:56.307520
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master") is True


# Generated at 2022-06-12 06:23:06.542188
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://localhost:8080"
    os.environ["GIT_BRANCH"] = "master"
    assert check() == None
    assert check('other') == None
    os.environ["GIT_BRANCH"] = "other"
    assert check() == None
    assert check('other') == None
    os.environ["CHANGE_ID"] = "123"
    assert check() == None
    assert check('other') == None
    os.environ["GIT_BRANCH"] = "master"
    assert check() == None
    assert check('other') == None
    del os.environ["CHANGE_ID"]
    assert check() == None
    assert check('other') == None

# Generated at 2022-06-12 06:23:08.949193
# Unit test for function circle
def test_circle():
    """
    Test for function circle

    :param branch: The branch the environment should be running against.
    """
    circle()

# Generated at 2022-06-12 06:23:17.458042
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["GIT_BRANCH"] = "master"
    with pytest.raises(CiVerificationError):
        jenkins("different")
    with pytest.raises(CiVerificationError):
        jenkins("master")
        os.environ["BRANCH_NAME"] = "dev"
    with pytest.raises(CiVerificationError):
        jenkins("master")
        os.environ["CHANGE_ID"] = "1"

    jenkins("master")
    os.environ.pop("JENKINS_URL", None)
    os.environ.pop("GIT_BRANCH", None)

# Generated at 2022-06-12 06:23:23.592276
# Unit test for function circle
def test_circle():
    """
    Test to verify that the required environment is set up
    """
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle(branch="master")
    del os.environ["CIRCLECI"]


# Generated at 2022-06-12 06:23:28.892616
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "gh-pages"

    assert frigg("gh-pages") == True

    # Cleanup
    del os.environ['FRIGG']
    del os.environ['FRIGG_BUILD_BRANCH']


# Generated at 2022-06-12 06:23:41.687313
# Unit test for function checker
def test_checker():
    @checker
    def test_func(branch: str):
        assert os.environ.get("TRAVIS_BRANCH") == branch
        assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"

    test_func("test")
    try:
        test_func("bad-test")
        raise AssertionError
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:23:51.850753
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("master")
    except CiVerificationError:
        assert False
    os.environ["BRANCH_NAME"] = "develop"
    try:
        semaphore("master")
        assert False
    except CiVerificationError:
        pass
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:23:56.209420
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    os.environ["FRIGG_PULL_REQUEST"] = "1"
    try:
        frigg("develop")
    except:
        pass
    else:
        assert False

    os.environ["FRIGG_PULL_REQUEST"] = "0"
    frigg("master")



# Generated at 2022-06-12 06:23:57.414159
# Unit test for function semaphore
def test_semaphore():
    assert checker(semaphore)("master") is True

# Generated at 2022-06-12 06:24:07.883281
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
        assert False
    except CiVerificationError:
        assert True
    os.environ["TRAVIS_BRANCH"] = "develop"
    try:
        travis("master")
        assert False
    except CiVerificationError:
        assert True
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-12 06:24:15.285330
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    os.environ['FRIGG'] = 'true'
    try:
        frigg('master')
        assert True
    except:
        assert False
    os.environ['FRIGG_BUILD_BRANCH'] = 'not_master'
    try:
        frigg('master')
        assert False
    except:
        assert True
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'true'
    try:
        frigg('master')
        assert False
    except:
        assert True
    os.environ

# Generated at 2022-06-12 06:24:19.733345
# Unit test for function checker
def test_checker():
    def no_errors():
        pass

    def throws_error():
        raise AssertionError

    assert checker(no_errors)()
    try:
        checker(throws_error)()
        assert False
    except CiVerificationError as e:
        assert True

# Generated at 2022-06-12 06:24:29.750652
# Unit test for function jenkins
def test_jenkins():
    with os.environ.copy():
        os.environ["JENKINS_URL"] = "true"
        os.environ["BRANCH_NAME"] = "develop"
        os.environ["CHANGE_ID"] = "test"
        assert jenkins("develop") == True
        os.environ["BRANCH_NAME"] = "master"
        os.environ["CHANGE_ID"] = "test"
        assert jenkins("master") == False
        os.environ["BRANCH_NAME"] = "master"
        os.environ["CHANGE_ID"] = ""
        assert jenkins("master") == True

# Generated at 2022-06-12 06:24:38.470365
# Unit test for function jenkins
def test_jenkins():
    import os
    # JENKINS_URL environment variable should be set
    # GIT_BRANCH environment variable should be set
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["GIT_BRANCH"] = "master"
    # CHANGE_ID environment variable should not be set
    os.environ["CHANGE_ID"] = None
    # assert it throws no exception
    jenkins("master")
    # assert it throws exception for other branches
    assert jenkins("develop") == False

# Generated at 2022-06-12 06:24:39.575017
# Unit test for function travis
def test_travis():
    assert travis("master")

# Generated at 2022-06-12 06:24:48.504893
# Unit test for function checker
def test_checker():
    """Unit test for function checker
    """
    @checker
    def test_func():
        """
        Will raise assertion error to verify that the function is
        wrapped to raise a CiVerificationError.
        """
        assert False

    try:
        test_func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Function is not wrapped.")

# Generated at 2022-06-12 06:24:52.897684
# Unit test for function jenkins
def test_jenkins():
    """
    Test jenkins()
    """
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = ""
    jenkins()

# Generated at 2022-06-12 06:24:56.204899
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "test"
    os.environ["BRANCH_NAME"] = "master"

    jenkins("master")

# Generated at 2022-06-12 06:25:00.987307
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master") is True


# Generated at 2022-06-12 06:25:04.056411
# Unit test for function checker
def test_checker():
    @checker
    def decorated_function():
        raise AssertionError("Assertion Error")
    try:
        decorated_function()
    except CiVerificationError:
        assert 1
    else:
        assert 0

# Generated at 2022-06-12 06:25:09.407704
# Unit test for function travis
def test_travis():
    # can check travis ci
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    # will use default branch if not set
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = ""
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    # branch check
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"

# Generated at 2022-06-12 06:25:14.859511
# Unit test for function circle
def test_circle():
    # A branch named 'master'
    os.environ['CIRCLE_BRANCH'] = 'master'
    # CI_PULL_REQUEST is empty
    os.environ['CI_PULL_REQUEST'] = ''

    # The program should run without error
    circle(branch='master')

# Generated at 2022-06-12 06:25:19.288907
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = ''
    os.environ['PULL_REQUEST_NUMBER'] = ''
    os.environ['SEMAPHORE_THREAD_RESULT'] = ''
    assert check('master')


# Generated at 2022-06-12 06:25:26.225455
# Unit test for function bitbucket
def test_bitbucket():
    branch = os.environ.get('BITBUCKET_BRANCH')
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_PR_ID'] = "false"
    check(branch)
    print("test_bitbucket pass")
    del os.environ['BITBUCKET_BRANCH']
    del os.environ['BITBUCKET_PR_ID']


# Generated at 2022-06-12 06:25:35.956106
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = "True"
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ.pop('BITBUCKET_PR_ID', None)
    bitbucket('master')
    assert os.environ.get('BITBUCKET_PR_ID') is None
    assert os.environ.get('BITBUCKET_BRANCH') == 'master'
    assert os.environ.get('BITBUCKET_BUILD_NUMBER') == 'True'



# Generated at 2022-06-12 06:25:43.228121
# Unit test for function travis
def test_travis():
    assert travis("master") == True



# Generated at 2022-06-12 06:25:52.823122
# Unit test for function gitlab
def test_gitlab():
    """
    Test the function gitlab.
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["GITLAB_CI"] = "true"
    gitlab("master")
    os.environ["CI_COMMIT_REF_NAME"] = "test"
    os.environ["GITLAB_CI"] = "None"
    try:
        gitlab("test")
        assert False
    except CiVerificationError:
        pass
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["GITLAB_CI"]


# Generated at 2022-06-12 06:26:04.123467
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_TASK_ID"] = "1"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert frigg("master") is True
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    os.environ["FRIGG_PULL_REQUEST"] = "1"
    assert frigg("master") is False
    assert frigg("develop") is False
    assert os.environ["FRIGG_PULL_REQUEST"] == "1"
    del os.environ["FRIGG"]
    del os.environ["FRIGG_TASK_ID"]

# Generated at 2022-06-12 06:26:14.194626
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "true"

    jenkins("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["JENKINS_URL"]

    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "true"

    jenkins("master")
    del os.environ["GIT_BRANCH"]
    del os.environ["JENKINS_URL"]

# Generated at 2022-06-12 06:26:17.594837
# Unit test for function circle
def test_circle():
    os.environ['CIRCLE_BRANCH'] = "master"
    os.environ['CI_PULL_REQUEST'] = ""
    check(branch="master")



# Generated at 2022-06-12 06:26:19.677258
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert gitlab("master") == True


# Generated at 2022-06-12 06:26:29.569501
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "http://localhost:8080/"
    os.environ['BRANCH_NAME'] = "master"
    assert jenkins()
    os.environ['BRANCH_NAME'] = "test"
    assert not jenkins()
    del os.environ['JENKINS_URL']
    assert not jenkins()
    os.environ['BRANCH_NAME'] = "test"
    assert not jenkins()
    os.environ['JENKINS_URL'] = "http://localhost:8080/"
    assert not jenkins()
    os.environ['BRANCH_NAME'] = "master"
    assert jenkins()


if __name__ == '__main__':
    test_jenkins()

# Generated at 2022-06-12 06:26:33.936950
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = "true"
    os.environ['CI_PULL_REQUEST'] = "true"
    os.environ['CIRCLE_BRANCH'] = "dev"
    try:
        circle("master")
    except CiVerificationError:
        assert True



# Generated at 2022-06-12 06:26:46.653969
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket()
    os.environ["BITBUCKET_PR_ID"] = "1"
    bitbucket()
    os.environ["BITBUCKET_BRANCH"] = "develop"
    bitbucket("develop")
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket()
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket()
    os.environ["BITBUCKET_BRANCH"] = "foo"
    bitbucket()

    os.environ.pop("BITBUCKET_BRANCH")
    os.environ.pop("BITBUCKET_PR_ID")

# Generated at 2022-06-12 06:26:51.861229
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'develop'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    assert frigg('develop') is True
    os.environ['FRIGG_BUILD_BRANCH'] = 'dev1'
    assert frigg('develop') is False

# Generated at 2022-06-12 06:27:06.508923
# Unit test for function gitlab
def test_gitlab():
    assert (os.environ.get("GITLAB_CI") == "true")
    assert (os.environ.get("CI_COMMIT_REF_NAME") == "release")
    assert (os.environ.get("CI_MERGE_REQUEST_ID") == None)
    assert (gitlab("release") == True)
    assert (os.environ.get("CI_COMMIT_REF_NAME") == "release")
    assert (os.environ.get("CI_MERGE_REQUEST_ID") == "1")
    assert (gitlab("release") == False)

# Generated at 2022-06-12 06:27:15.412906
# Unit test for function checker
def test_checker():
    def checker_func():
        return True

    def checker_func_with_check():
        raise AssertionError

    # Assert that both functions return True when wrapped
    assert checker(checker_func)() is True
    assert checker(checker_func_with_check)() is True

    # Assert that the function that raises AssertionError instead throws
    try:
        checker(checker_func_with_check)(raise_check_error=True)
        assert False, "Failed to raise CiVerificationError"
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:27:18.633109
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = 'http://localhost:8080'
    os.environ['GIT_BRANCH'] = 'master'
    assert check()

# Generated at 2022-06-12 06:27:22.428518
# Unit test for function checker
def test_checker():
    @checker
    def f():
        assert False

    try:
        f()
        assert False
    except CiVerificationError:
        assert True



# Generated at 2022-06-12 06:27:30.938994
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "dev"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("dev")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("dev")


# Generated at 2022-06-12 06:27:35.145563
# Unit test for function checker
def test_checker():
    def dummy():
        pass

    def dummy2():
        assert False

    assert checker(dummy)()
    assert not checker(dummy2)()

# Generated at 2022-06-12 06:27:46.255997
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test the function bitbucket
    """

    branch = "master"

    # Set up environment variables - bitbucket
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    os.environ["BITBUCKET_BRANCH"] = branch
    os.environ["BITBUCKET_PR_ID"] = "12"

    # Run function bitbucket - successful
    result = bitbucket(branch)
    assert result

    # Run function bitbucket - failure
    os.environ["BITBUCKET_BRANCH"] = "notmaster"
    try:
        bitbucket(branch)
        assert False
    except CiVerificationError:
        pass
    assert True



# Generated at 2022-06-12 06:27:50.492560
# Unit test for function bitbucket
def test_bitbucket():
    bitbucket("test_branch")
    #test env variable
    os.environ["BITBUCKET_BUILD_NUMBER"] = "25"
    os.environ["BITBUCKET_BRANCH"] = "test_branch"
    assert bitbucket("test_branch")


# Generated at 2022-06-12 06:27:54.370196
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '0'
    os.environ['BITBUCKET_BRANCH'] = 'master'

    assert bitbucket('master') is True



# Generated at 2022-06-12 06:27:59.417694
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    semaphore("master")

# Generated at 2022-06-12 06:28:08.916035
# Unit test for function jenkins
def test_jenkins():
    os.environ['BRANCH_NAME']='master'
    os.environ['JENKINS_URL']='jenkins'
    os.environ['CHANGE_ID']=''
    jenkins()


# Generated at 2022-06-12 06:28:20.822307
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"

    check()
    assert os.environ.get("FRIGG_BUILD_BRANCH") == "master"
    assert not os.environ.get("FRIGG_PULL_REQUEST")

    os.environ["FRIGG_BUILD_BRANCH"] = "develop"

    check()
    assert os.environ.get("FRIGG_BUILD_BRANCH") == "develop"

    os.environ["FRIGG_PULL_REQUEST"] = "12"

    check()
    assert os.environ.get("FRIGG_BUILD_BRANCH") == "develop"

# Generated at 2022-06-12 06:28:23.320288
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()



# Generated at 2022-06-12 06:28:25.788050
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")


# Generated at 2022-06-12 06:28:29.197341
# Unit test for function circle
def test_circle():
    # Mock os.environ
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    # Circle CI does not have the environment variable CI_PULL_REQUEST
    # so we delete it if it exists.
    try:
        del os.environ["CI_PULL_REQUEST"]
    except KeyError:
        pass
    check()



# Generated at 2022-06-12 06:28:39.079561
# Unit test for function bitbucket
def test_bitbucket():
    # when:
    # bitbucket_build_number is set
    # pull request id is present in environment
    os.environ["BITBUCKET_BUILD_NUMBER"] = "test_build_number"
    os.environ["BITBUCKET_PR_ID"] = "test_pr_id"

    # then:
    # Should raise an exception
    try:
        bitbucket("master")
        assert False
    except CiVerificationError as e:
        assert e

    # cleanup
    del os.environ["BITBUCKET_BUILD_NUMBER"]
    del os.environ["BITBUCKET_PR_ID"]

    # when:
    # bitbucket_build_number is set

# Generated at 2022-06-12 06:28:45.032959
# Unit test for function checker
def test_checker():
    def no_exception_test():
        assert True

    def exception_test():
        assert False

    decorated = checker(no_exception_test)
    decorated()

    decorated = checker(exception_test)
    try:
        decorated()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should raise a CiVerificationError")

# Generated at 2022-06-12 06:28:48.537933
# Unit test for function checker
def test_checker():
    """
    Check if exception is raised when checker decorator is used on a failing function.
    """
    @checker
    def failing_function():
        assert False

    try:
        failing_function()
        assert False
    except CiVerificationError:
        assert True



# Generated at 2022-06-12 06:28:51.700580
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = None
    check()


# Generated at 2022-06-12 06:28:55.750353
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    bitbucket("master")


# Generated at 2022-06-12 06:29:05.837549
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")



# Generated at 2022-06-12 06:29:10.865262
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CI_PULL_REQUEST'] = 'false'
    os.environ['CIRCLE_BRANCH'] = 'master'

    check()
    assert True


# Generated at 2022-06-12 06:29:15.326932
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    return semaphore("master")



# Generated at 2022-06-12 06:29:17.315740
# Unit test for function checker
def test_checker():
    # test for decorator checker
    @checker
    def func():
        assert False

    try:
        func()
        assert False
    except CiVerificationError:
        pass


# Generated at 2022-06-12 06:29:23.429856
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_BRANCH"] = "master"
    check()
    del os.environ["CIRCLECI"]



# Generated at 2022-06-12 06:29:28.417749
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://test.jenkins.com"
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")
    os.environ["JENKINS_URL"] = "https://test.jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    jenkins("master")



# Generated at 2022-06-12 06:29:31.115053
# Unit test for function semaphore
def test_semaphore():
    assert os.environ.get("SEMAPHORE") == "true"
    assert os.environ.get("BRANCH_NAME") == "master"

# Generated at 2022-06-12 06:29:35.809700
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"

    semaphore("master")



# Generated at 2022-06-12 06:29:39.633068
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG_BUILD_BRANCH'] = 'test'
    os.environ['FRIGG_PULL_REQUEST'] = ''
    assert frigg('master') == True

# Generated at 2022-06-12 06:29:42.736766
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    assert bitbucket("master") is True

# Generated at 2022-06-12 06:29:52.383288
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"]="https://jenkins.com"
    os.environ["BRANCH_NAME"]="master"
    jenkins("master")


# Generated at 2022-06-12 06:29:59.763860
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()
    os.environ["CIRCLE_BRANCH"] = "dev"
    try:
        check()
        assert False
    except CiVerificationError:
        assert True
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-12 06:30:01.184097
# Unit test for function check
def test_check():
    assert check() is None

# Generated at 2022-06-12 06:30:09.632994
# Unit test for function check
def test_check():
    """
    Unit test for function check.
    """
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["TRAVIS_BRANCH"] = "dev"
    try:
        check()
        raise AssertionError("Should have failed")
    except CiVerificationError:
        pass
    try:
        os.environ["TRAVIS_PULL_REQUEST"] = "true"
        check()
        raise AssertionError("Should have failed")
    except CiVerificationError:
        pass



# Generated at 2022-06-12 06:30:18.064135
# Unit test for function frigg
def test_frigg():
    import os
    import unittest

    #For test FRIGG_PULL_REQUEST = true
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    with unittest.mock.patch("warnings.warn") as warn:
        frigg("master")
        assert warn.called

    #For test FRIGG_BUILD_BRANCH is not same as required branch
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    with unittest.mock.patch("warnings.warn") as warn:
        frigg("master")
        assert warn.called



# Generated at 2022-06-12 06:30:23.087206
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "True"
    os.environ["BRANCH_NAME"] = "master"
    jenkins(branch='master')
    os.environ["BRANCH_NAME"] = "staging"
    jenkins(branch='master')
    os.environ["BRANCH_NAME"] = "master"
    jenkins(branch='staging')

# Generated at 2022-06-12 06:30:31.682974
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check("master")
    try:
        os.environ["CI_PULL_REQUEST"] = "true"
        check("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Expected CiVerificationError here")
    try:
        os.environ["CIRCLE_BRANCH"] = "develop"
        check("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Expected CiVerificationError here")
    os.environ.pop("CI_PULL_REQUEST")

# Generated at 2022-06-12 06:30:36.843718
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = "test"
    os.environ['BITBUCKET_BRANCH'] = "test"
    bitbucket('test')
    assert True

if __name__ == '__main__':
    test_bitbucket()

# Generated at 2022-06-12 06:30:39.851581
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = None

    circle("master")



# Generated at 2022-06-12 06:30:43.929162
# Unit test for function semaphore
def test_semaphore():
    os.environ.update({
        "BRANCH_NAME": "master",
        "PULL_REQUEST_NUMBER": None,
        "SEMAPHORE_THREAD_RESULT": "passed",
    })

    semaphore("master")
    assert True



# Generated at 2022-06-12 06:30:56.721151
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = "true"
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"

    check()

    os.environ['TRAVIS_BRANCH'] = "feature"
    try:
        check()
    except CiVerificationError:
        os.environ['TRAVIS_BRANCH'] = "master"
        os.environ['TRAVIS'] = "false"
        os.environ['SEMAPHORE'] = "true"
        os.environ['BRANCH_NAME'] = "master"
        os.environ['PULL_REQUEST_NUMBER'] = "None"

# Generated at 2022-06-12 06:30:59.296040
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123456"
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")