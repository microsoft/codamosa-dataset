

# Generated at 2022-06-12 06:21:11.241332
# Unit test for function checker
def test_checker():
    @checker
    def test_check(fail: bool):
        assert not fail

    assert test_check(fail=False)
    try:
        test_check(fail=True)
    except CiVerificationError:
        pass
    else:
        raise AssertionError('Check did not raise CiVerificationError')

# Generated at 2022-06-12 06:21:19.911412
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    assert frigg(branch="master")

    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    assert frigg(branch="master")
    assert not frigg(branch="feature/test")

    os.environ['FRIGG_PULL_REQUEST'] = "false"
    assert frigg(branch="master")

    os.environ.pop('FRIGG')
    assert not frigg(branch="master")
    os.environ.pop('FRIGG_BUILD_BRANCH')



# Generated at 2022-06-12 06:21:27.342387
# Unit test for function semaphore
def test_semaphore():
    print('Test 1: semaphore function')
    assert semaphore('master') == True
    os.environ['BRANCH_NAME'] = 'hello'
    assert semaphore('master') == False
    del os.environ['BRANCH_NAME']
    os.environ['PULL_REQUEST_NUMBER'] = 'pull'
    assert semaphore('master') == False
    del os.environ['PULL_REQUEST_NUMBER']
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'
    assert semaphore('master') == False
    del os.environ['SEMAPHORE_THREAD_RESULT']
    print('Test 1: pass')
    print()


# Generated at 2022-06-12 06:21:35.810495
# Unit test for function semaphore
def test_semaphore():
    """
    Test if the enviroment variables are set in the right way.
    """
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore(os.environ.get("BRANCH_NAME"))
    assert os.environ.get("BRANCH_NAME") == "master"
    assert os.environ.get("PULL_REQUEST_NUMBER") is None
    assert os.environ.get("SEMAPHORE_THREAD_RESULT") == "passed"

# Generated at 2022-06-12 06:21:39.955221
# Unit test for function travis
def test_travis():
    """Unit test for function travis
    """
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-12 06:21:47.005534
# Unit test for function checker
def test_checker():
    from semantic_release.errors import CiVerificationError

    @checker
    def test_function_1():
        assert True  # this should be fine

    test_function_1()

    @checker
    def test_function_2():
        assert False  # this should raise error

    try:
        test_function_2()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Expected CiVerificationError")

# Generated at 2022-06-12 06:21:55.129140
# Unit test for function semaphore
def test_semaphore():
    """
    Test function semaphore()
    """
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "None"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]


# Generated at 2022-06-12 06:21:58.843439
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check("master")

# Generated at 2022-06-12 06:22:02.150612
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "test-branch"
    check("test-branch")
    del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-12 06:22:08.415572
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    try:
        circle("feature")
        assert(False)
    except CiVerificationError:
        assert(True)

    del os.environ["CIRCLECI"]
    del os.environ["CI_PULL_REQUEST"]
    del os.environ["CIRCLE_BRANCH"]

# Generated at 2022-06-12 06:22:27.175040
# Unit test for function check
def test_check():
    os.environ['GITLAB_CI'] = "true"
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = None
    assert(check())

    os.environ['GITLAB_CI'] = "true"
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = 'null'
    assert(check())

    os.environ['GITLAB_CI'] = "true"
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = '5'

# Generated at 2022-06-12 06:22:38.709453
# Unit test for function check
def test_check():
    assert len(checker.__closure__) > 0
    for ci in globals().copy():
        if ci not in globals().copy():
            raise ValueError(
                "Function " + ci + " is not defined, but is found in __closure__"
            )
    assert os.environ.get("TRAVIS") == "true"
    assert os.environ.get("TRAVIS_BRANCH") == "master"
    assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"
    assert os.environ.get("SEMAPHORE") == "true"
    assert os.environ.get("BRANCH_NAME") == "master"
    assert os.environ.get("PULL_REQUEST_NUMBER") is None

# Generated at 2022-06-12 06:22:41.826850
# Unit test for function semaphore
def test_semaphore():
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'

    semaphore('master')

# Generated at 2022-06-12 06:22:47.477199
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "release1"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    check("release1")


# Generated at 2022-06-12 06:22:50.752978
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert check('master') == True


# Generated at 2022-06-12 06:22:54.192740
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    gitlab("master")
    assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
    del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-12 06:23:00.636516
# Unit test for function jenkins
def test_jenkins():
    assert os.environ.get("BRANCH_NAME") is None
    with open("/dev/null", "w") as f:
        os.environ["BRANCH_NAME"] = "master"
        os.environ["JENKINS_URL"] = "TEST_JENKINS_URL"
        os.environ["CHANGE_ID"] = "TEST_CHANGE_ID"
        jenkins(branch="master")
        os.environ["CHANGE_ID"] = "TEST_CHANGE_ID"
        jenkins(branch="not_master")
    with open("/dev/null", "w") as f:
        os.environ["BRANCH_NAME"] = "not_master"

# Generated at 2022-06-12 06:23:08.192920
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "12345"
    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = "1234"
    check("develop")
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    check()
    del os.environ["BITBUCKET_BUILD_NUMBER"]
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]

# Generated at 2022-06-12 06:23:10.451925
# Unit test for function check
def test_check():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    os.environ['TRAVIS'] = 'true'
    check()

# Generated at 2022-06-12 06:23:13.913625
# Unit test for function checker
def test_checker():
    @checker
    def busy_bee(): raise AssertionError()
    try:
        busy_bee()
        assert False
    except CiVerificationError:
        assert True

# Unit tests for the functions in this module

# Generated at 2022-06-12 06:23:30.620558
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")



# Generated at 2022-06-12 06:23:35.043010
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ.pop("CI_MERGE_REQUEST_ID", None)
    gitlab("master")

# Generated at 2022-06-12 06:23:36.113300
# Unit test for function circle
def test_circle():
    assert circle('master') == True

# Generated at 2022-06-12 06:23:41.127356
# Unit test for function checker
def test_checker():
    @checker
    def func_raises_assertion_error():
        raise AssertionError()

    @checker
    def func_returns_true():
        return True

    try:
        func_raises_assertion_error()
    except CiVerificationError:
        pass
    else:
        raise AssertionError()

    assert func_returns_true()

# Generated at 2022-06-12 06:23:46.703985
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('master')
    os.environ['TRAVIS_BRANCH'] = 'test'
    try:
        travis('master')
    except CiVerificationError:
        assert True



# Generated at 2022-06-12 06:23:48.920580
# Unit test for function circle
def test_circle():
    assert os.environ.get("CIRCLE_BRANCH") == "master"
    assert not os.environ.get("CI_PULL_REQUEST")



# Generated at 2022-06-12 06:23:51.313179
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")


# Generated at 2022-06-12 06:23:53.007190
# Unit test for function gitlab
def test_gitlab():
    try:
        gitlab("master")
    except CiVerificationError:
        assert False, "gitlab should make it through verification check"


# Generated at 2022-06-12 06:23:55.193239
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-12 06:24:01.796840
# Unit test for function circle
def test_circle():
    """circle"""
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()

    os.environ["CIRCLE_BRANCH"] = "develop"
    check("develop")



# Generated at 2022-06-12 06:24:40.660212
# Unit test for function checker
def test_checker():
    def function():
        raise AssertionError()

    with pytest.raises(CiVerificationError):
        checker(function)()


# Unit tests for function travis
travis_branch = "master"


# Generated at 2022-06-12 06:24:48.454598
# Unit test for function frigg
def test_frigg():
    """
    Test frigg with all true, false and wrong inputs
    """
    frigg("master")
    frigg("branch")
    os.environ["FRIGG"] = "false"
    frigg("master")
    os.environ["FRIGG"] = "wrong"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "wrong"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "branch"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "branch"
    os.environ["FRIGG_PULL_REQUEST"] = "wrong"
    frigg("master")

# Generated at 2022-06-12 06:24:51.930429
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = '1'
    assert check() is None

# Generated at 2022-06-12 06:24:55.281245
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('master')
    

# Generated at 2022-06-12 06:24:56.494707
# Unit test for function frigg
def test_frigg():
    assert frigg("master") == True


# Generated at 2022-06-12 06:25:01.986704
# Unit test for function gitlab
def test_gitlab():
    assert isinstance(gitlab('1.0.0'), type(None))
#
# def test_gitlab():
#     try:
#         assert isinstance(gitlab('1.0.0'), type(None))
#     except:
#         assert False
#

# Generated at 2022-06-12 06:25:07.672020
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "5"
    check()
    os.environ["BITBUCKET_PR_ID"] = ""
    check()
    os.unsetenv("BITBUCKET_PR_ID")
    check()
    os.environ["BITBUCKET_BRANCH"] = "pr"
    try:
        check()
        assert False, "The check should have raised an error."
    except CiVerificationError:
        pass

    

# Generated at 2022-06-12 06:25:14.046089
# Unit test for function semaphore
def test_semaphore():
    if os.environ.get("SEMAPHORE") == "true":
        assert semaphore("master")
        assert semaphore("release")
        assert semaphore("development")
        assert semaphore("branch_with_patch_release")
        assert semaphore("branch_with_minor_release")

# Generated at 2022-06-12 06:25:16.376131
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://no"
    os.environ["GIT_BRANCH"] = "master"
    check()



# Generated at 2022-06-12 06:25:23.066296
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = "true"
    os.environ['CIRCLE_BRANCH'] = "master"
    circle("master")

    os.environ['CIRCLECI'] = "false"
    os.environ['CIRCLE_BRANCH'] = "notmaster"
    circle("master")

# Generated at 2022-06-12 06:26:21.486362
# Unit test for function checker
def test_checker():
    @checker
    def foo():
        assert False, "Checker failed"

    foo()

# Generated at 2022-06-12 06:26:29.477508
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "circle_branch"
    os.environ["CI_PULL_REQUEST"] = "pull request"

    def run_check():
        check()

    checker(run_check)()

    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""

    check()

    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]

# Generated at 2022-06-12 06:26:33.853499
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg(branch="master")
    os.environ["FRIGG_BUILD_BRANCH"] = "some_branch"
    frigg(branch="master")

# Generated at 2022-06-12 06:26:38.386494
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_TARGET_BRANCH_NAME"] = ""
    check()

# Generated at 2022-06-12 06:26:45.676661
# Unit test for function checker
def test_checker():
    """
    Test the checker decorator
    """
    count = 0

    @checker
    def checker_func():
        """
        Test function
        """
        nonlocal count
        count += 1
        assert count != 0

    checker_func()

    count = 0

    try:
        checker_func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("checker_func should have raised CiVerificationError")

# Generated at 2022-06-12 06:26:54.932174
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket()
    os.environ["BITBUCKET_BRANCH"] = "testing"
    bitbucket()
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    raises(CiVerificationError, bitbucket)
    os.environ["BITBUCKET_PR_ID"] = "1234"
    raises(CiVerificationError, bitbucket)
    del os.environ["BITBUCKET_PR_ID"]
    del os.environ["BITBUCKET_BRANCH"]

# Generated at 2022-06-12 06:26:58.492970
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "test"
    os.environ['BRANCH_NAME'] = "master"
    assert check() is None
    assert os.environ['JENKINS_URL'] == "test"
    assert os.environ['BRANCH_NAME'] == "master"


# Generated at 2022-06-12 06:27:00.197928
# Unit test for function gitlab
def test_gitlab():
    """
    Checks the gitlab function.
    """
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    check()


# Generated at 2022-06-12 06:27:07.183879
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    assert frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-12 06:27:11.907120
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    circle("master")

# Generated at 2022-06-12 06:28:56.101812
# Unit test for function bitbucket
def test_bitbucket():
    assert os.environ.get("BITBUCKET_BUILD_NUMBER") == "1"
    bitbucket("master")

# Generated at 2022-06-12 06:28:59.632078
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = 'true'
    os.environ["TRAVIS_PULL_REQUEST"] = 'false'
    os.environ["TRAVIS_BRANCH"] = 'master'
    check()

# Generated at 2022-06-12 06:29:00.292781
# Unit test for function jenkins
def test_jenkins():
    assert check() == True

# Generated at 2022-06-12 06:29:04.484542
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    assert circle('master')
    os.environ['CIRCLE_BRANCH'] = 'develop'
    assert not circle('master')
    os.environ['CI_PULL_REQUEST'] = '123'
    os.environ['CIRCLE_BRANCH'] = 'master'
    assert not circle('master')

# Generated at 2022-06-12 06:29:16.734642
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg(branch="master")
    os.environ["FRIGG_BUILD_BRANCH"] = "dev"
    with pytest.raises(CiVerificationError):
        frigg(branch="master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    with pytest.raises(CiVerificationError):
        frigg(branch="master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]

# Generated at 2022-06-12 06:29:28.030578
# Unit test for function circle
def test_circle():
    from semantic_release.ci_checks import CIRCLE_ENV_VARIABLES

    for env_var in CIRCLE_ENV_VARIABLES:
        os.environ[env_var] = "true"

    try:
        circle("master")
    except CiVerificationError as e:
        assert e.message == "The verification check for the environment did not pass."

    os.environ["CIRCLE_BRANCH"] = "develop"

    try:
        circle("master")
    except CiVerificationError as e:
        assert e.message == "The verification check for the environment did not pass."

    os.environ["CIRCLE_BRANCH"] = "develop"

# Generated at 2022-06-12 06:29:32.446650
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "testbranch"
    os.environ["BITBUCKET_PR_ID"] = "14"
    try:
        bitbucket("testbranch")
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."
    else:
        assert False



# Generated at 2022-06-12 06:29:35.806506
# Unit test for function frigg
def test_frigg():
    """
    Makes sure function frigg does not raise an exception when the environment is frigg.
    """
    assert frigg("master") is True



# Generated at 2022-06-12 06:29:42.847847
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    try:
        check()
    except Exception as e:
        assert isinstance(e, CiVerificationError)
        list1 = str(e).split("\n")
        assert list1[0] == "The verification check for the environment did not pass."
        assert list1[1] == "Expected CIRCLE_BRANCH to equal 'master', got 'master'"
        assert list1[2] == "Expected CI_PULL_REQUEST to equal '', got ''"

# Generated at 2022-06-12 06:29:49.514267
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert bitbucket("master")
    os.environ["BITBUCKET_PR_ID"] = ""
    assert bitbucket("master") is False
    os.environ["BITBUCKET_BRANCH"] = "test"
    assert bitbucket("master") is False
