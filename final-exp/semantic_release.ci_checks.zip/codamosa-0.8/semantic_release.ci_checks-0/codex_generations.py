

# Generated at 2022-06-12 06:21:12.406128
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "url"
    os.environ["BRANCH_NAME"] = "branch_name"
    os.environ["GIT_BRANCH"] = "${BRANCH_NAME}"
    os.environ["CHANGE_ID"] = "change_id"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["BRANCH_NAME"] = "master"
    jenkins("master")
    del os.environ["CHANGE_ID"]
    jenkins("master")
    del os.environ["BRANCH_NAME"]
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")
    # Unit

# Generated at 2022-06-12 06:21:22.215248
# Unit test for function bitbucket
def test_bitbucket():
    """
    This test is to test bitbucket function on CI.
    """
    os.environ["BITBUCKET_BRANCH"] = "branch1"
    try:
        check()
    except CiVerificationError:
        assert False
    os.environ["BITBUCKET_PR_ID"] = "12345"
    try:
        check()
        assert False
    except CiVerificationError:
        assert True
    del os.environ["BITBUCKET_PR_ID"]
    try:
        check("branch2")
        assert False
    except CiVerificationError:
        assert True
    del os.environ["BITBUCKET_BRANCH"]
    try:
        check()
        assert False
    except CiVerificationError:
        assert True



# Generated at 2022-06-12 06:21:25.749955
# Unit test for function frigg
def test_frigg():
    assert os.environ.get("FRIGG") == "true"
    assert os.environ.get("FRIGG_PULL_REQUEST") == "true"
    assert os.environ.get("FRIGG_BUILD_BRANCH") == "develop"

    frigg("develop")



# Generated at 2022-06-12 06:21:30.738447
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = "FEATURE_BRANCH"
    os.environ['PULL_REQUEST_NUMBER'] = "1234"
    os.environ['SEMAPHORE_THREAD_RESULT']=''
    try:
        semaphore("FEATURE_BRANCH")
        assert False
    except CiVerificationError:
        assert True
    except Exception:
        assert False
    os.environ['SEMAPHORE_THREAD_RESULT']='failed'
    try:
        semaphore("FEATURE_BRANCH")
        assert False
    except CiVerificationError:
        assert True
    except Exception:
        assert False
    os.environ['SEMAPHORE_THREAD_RESULT']='success'

# Generated at 2022-06-12 06:21:33.397965
# Unit test for function checker
def test_checker():
    @checker
    def is_valid_environment():
        assert True

    is_valid_environment()

    @checker
    def is_invalid_environment():
        assert False

    try:
        is_invalid_environment()
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."

# Generated at 2022-06-12 06:21:36.147978
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""

    circle("master")

# Generated at 2022-06-12 06:21:48.026849
# Unit test for function check
def test_check():
    """
    This unit test calls function check, checks that it does not raise the
    CiVerificationError, and then asserts the proper environment variables
    are set for each CI environment.
    """
    check()
    if os.environ.get("TRAVIS") == "true":
        assert os.environ.get("TRAVIS_BRANCH") == "master"
        assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"
    elif os.environ.get("SEMAPHORE") == "true":
        assert os.environ.get("BRANCH_NAME") == "master"
        assert os.environ.get("PULL_REQUEST_NUMBER") is None
        assert os.environ.get("SEMAPHORE_THREAD_RESULT") != "failed"


# Generated at 2022-06-12 06:21:52.397190
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "test"
    assert circle("test")
    assert not circle("master")



# Generated at 2022-06-12 06:21:59.254952
# Unit test for function checker
def test_checker():
    @checker
    def false_test():
        assert False

    @checker
    def true_test():
        assert True

    try:
        false_test()
        assert False, "Didn't raise an error"
    except CiVerificationError:
        assert True

    try:
        true_test()
        assert True
    except CiVerificationError:
        assert False, "Raised an error, though it shouldn't have"



# Generated at 2022-06-12 06:22:06.252728
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'test_branch'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    assert frigg('test_branch')
    os.environ['FRIGG_BUILD_BRANCH'] = 'other_branch'
    try:
        frigg('test_branch')
    except CiVerificationError:
        os.environ.clear()
        return True
    os.environ.clear()
    return False


# Generated at 2022-06-12 06:22:26.911605
# Unit test for function checker
def test_checker():
    @checker
    def test_true():
        assert 1 == 1

    @checker
    def test_false():
        assert 1 == 2

    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    test_true()

    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        test_true()
    except CiVerificationError:
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        test_true()

    del os.environ["TRAVIS"]
    try:
        test_true()
    except CiVerificationError:
        pass


# Generated at 2022-06-12 06:22:37.002826
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test the bitbucket checker
    """
    assert checker(bitbucket)("master")
    assert checker(bitbucket)("develop")
    assert checker(bitbucket)("feature/test")
    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        checker(bitbucket)("master")
        assert False
    except CiVerificationError:
        assert True
    finally:
        del os.environ["BITBUCKET_PR_ID"]



# Generated at 2022-06-12 06:22:44.647554
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    del os.environ["FRIGG_PULL_REQUEST"]
    frigg("master")
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]
    del os.environ["FRIGG"]
    assert frigg("master") is True


# Generated at 2022-06-12 06:22:49.691388
# Unit test for function bitbucket
def test_bitbucket():
    branch = "master"
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    os.environ["BITBUCKET_BRANCH"] = branch
    
    assert bitbucket(branch)


# Generated at 2022-06-12 06:22:54.936661
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]

# Generated at 2022-06-12 06:22:59.105166
# Unit test for function checker
def test_checker():
    def raise_error():
        assert True

    def dont_raise_error():
        assert False

    assert checker(raise_error)() is True
    try:
        checker(dont_raise_error)()
        assert False
    except CiVerificationError:
        assert True



# Generated at 2022-06-12 06:23:02.394471
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    check()
    os.environ["BITBUCKET_BRANCH"] = "feature"
    check("feature")


# Generated at 2022-06-12 06:23:11.963332
# Unit test for function semaphore
def test_semaphore():
    """
    Test method semaphore.
    """
    os.environ["BRANCH_NAME"] = "test_branch"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "succeeded"
    assert semaphore("test_branch")

    try:
        os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
        semaphore("test_branch")
    except:
        pass
    else:
        assert False

    try:
        os.environ["BRANCH_NAME"] = "master"
        semaphore("test_branch")
    except:
        pass
    else:
        assert False


# Generated at 2022-06-12 06:23:19.425911
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "true"
    os.environ['GIT_BRANCH'] = "master"
    assert jenkins(os.environ.get("GIT_BRANCH"))
    os.environ['CHANGE_ID'] = "true"
    with raises(CiVerificationError):
        jenkins(os.environ.get("GIT_BRANCH"))
    del os.environ['CHANGE_ID']
    os.environ['GIT_BRANCH'] = "develop"
    with raises(CiVerificationError):
        jenkins(os.environ.get("GIT_BRANCH"))
    del os.environ['GIT_BRANCH']
    del os.environ['JENKINS_URL']

# Unit

# Generated at 2022-06-12 06:23:20.452922
# Unit test for function circle
def test_circle():
    circle("feature/test")

# Generated at 2022-06-12 06:23:31.640748
# Unit test for function gitlab
def test_gitlab():
    assert os.getenv('CI_COMMIT_REF_NAME') == None
    assert os.getenv('CI_PROJECT_DIR') == None
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_PROJECT_DIR'] = 'ls'
    gitlab(os.environ['CI_COMMIT_REF_NAME'])


# Generated at 2022-06-12 06:23:35.809413
# Unit test for function checker
def test_checker():
    @checker
    def test_function():
        raise AssertionError()
    try:
        test_function()
    except CiVerificationError:
        pass
    else:
        raise Exception("Test for checker decorator failed")

# Generated at 2022-06-12 06:23:39.106333
# Unit test for function gitlab
def test_gitlab():
  os.environ["CI_COMMIT_REF_NAME"] = "master"
  os.environ["CI_MERGE_REQUEST_ID"] = "false"
  assert gitlab("master")



# Generated at 2022-06-12 06:23:41.724088
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert gitlab("master")



# Generated at 2022-06-12 06:23:46.705301
# Unit test for function frigg
def test_frigg():
    """
    Unit test for frigg CI environment.
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    check("master")



# Generated at 2022-06-12 06:23:55.231448
# Unit test for function jenkins
def test_jenkins():
    branch = 'master'

# Generated at 2022-06-12 06:24:00.239684
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "2"
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert bitbucket(branch="master") == True

# Generated at 2022-06-12 06:24:03.593228
# Unit test for function checker
def test_checker():
    # type: () -> None
    try:
        @checker
        def f1():
            pass
    except CiVerificationError:
        raise AssertionError

    try:
        @checker
        def f2():
            raise AssertionError
    except CiVerificationError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-12 06:24:08.662592
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    assert True



# Generated at 2022-06-12 06:24:11.261724
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-12 06:24:34.274503
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")
    # Checking if bitbucket env variables do not exist anymore
    assert "BITBUCKET_BRANCH" not in os.environ
    assert "BITBUCKET_PR_ID" not in os.environ
    # Checking if bitbucket env variables do not exist anymore



# Generated at 2022-06-12 06:24:36.306116
# Unit test for function check
def test_check():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check("master")

# Generated at 2022-06-12 06:24:44.885672
# Unit test for function bitbucket
def test_bitbucket():
    """
    Performs necessary checks to ensure that the bitbucket build is one
    that should create releases.
    """

    # Set os.environ
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "2"
    try:
        check("master")
    except CiVerificationError:
        assert True
    else:
        assert False

    os.environ["BITBUCKET_PR_ID"] = ""
    try:
        check("master")
    except CiVerificationError:
        assert False

# Generated at 2022-06-12 06:24:50.118735
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    check("master")
    os.environ["BITBUCKET_BRANCH"] = ""
    check("master")


# Generated at 2022-06-12 06:24:54.053118
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    frigg("master")


# Generated at 2022-06-12 06:24:58.983344
# Unit test for function semaphore
def test_semaphore():
    try:
        os.environ["BRANCH_NAME"] = "not-master"
        semaphore("not-master")
        assert True
    except CiVerificationError:
        assert False
    finally:
        del os.environ["BRANCH_NAME"]

# Generated at 2022-06-12 06:25:06.726163
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = 'true'
    os.environ['BRANCH_NAME'] = 'master'
    # Jenkins should verify without error in this case
    jenkins('master')
    # Jenkins should verify with error in this case
    os.environ['BRANCH_NAME'] = 'develop'
    os.environ['CHANGE_ID'] = '10'
    # assertRaises: https://docs.python.org/3/library/unittest.html
    jenkins('develop')

# Generated at 2022-06-12 06:25:18.471259
# Unit test for function check
def test_check():
    # Setting the CI environment variables to different values
    os.environ["TRAVIS"] = "false"
    os.environ["SEMAPHORE"] = "false"
    os.environ["FRIGG"] = "false"
    os.environ["CIRCLECI"] = "false"
    os.environ["GITLAB_CI"] = "false"
    os.environ["JENKINS_URL"] = "false"
    os.environ["BITBUCKET_BUILD_NUMBER"] = "false"
    # Assigning the values to different branches
    branch = "develop"
    # Checking the CI environment variables
    check(branch)
    os.environ["TRAVIS"] = "true"
    branch = "master"
    check(branch)

# Generated at 2022-06-12 06:25:25.668822
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    result = travis("master")
    assert result == True

    os.environ["TRAVIS_BRANCH"] = "dev"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    result = travis("master")
    assert result == False


# Generated at 2022-06-12 06:25:31.290282
# Unit test for function circle
def test_circle():
    assert circle(branch="master") is True
    assert circle(branch="other-branch") is False
    assert circle(branch="test-branch") is False
    assert circle(branch="test-branch-2") is False

# Generated at 2022-06-12 06:26:04.567207
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test to make sure bitbucket is raising a CiVerificationError
    when the wrong branch is checked.
    """
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        assert True
    del os.environ["BITBUCKET_BRANCH"]

# Generated at 2022-06-12 06:26:07.254569
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = None
    check()

# Generated at 2022-06-12 06:26:12.244006
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"

    assert semaphore("master")



# Generated at 2022-06-12 06:26:19.364145
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://myjenkins.com"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["BRANCH_NAME"] = "master"

    check()
    del os.environ["JENKINS_URL"]
    del os.environ["GIT_BRANCH"]
    del os.environ["BRANCH_NAME"]

# Generated at 2022-06-12 06:26:29.323710
# Unit test for function semaphore
def test_semaphore():
    test_branch = "master"
    os.environ["BRANCH_NAME"] = test_branch
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    semaphore(branch=test_branch)
    del os.environ["BRANCH_NAME"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    test_branch = "release/"
    os.environ["BRANCH_NAME"] = test_branch
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    semaphore(branch=test_branch)
    del os.environ["BRANCH_NAME"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    test_branch

# Generated at 2022-06-12 06:26:31.991609
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()

# Generated at 2022-06-12 06:26:37.618385
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = False
    check()
    # no exceptions should be raised
    assert True



# Generated at 2022-06-12 06:26:41.474086
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    frigg("master")

# Generated at 2022-06-12 06:26:46.000678
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "dev"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("dev") is True

# Generated at 2022-06-12 06:26:54.575087
# Unit test for function checker
def test_checker():
    def check_env(branch):
        assert os.environ.get("TRAVIS") == "true"
        assert os.environ.get("TRAVIS_BRANCH") == branch
        assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"

    try:
        check_env("master")
    except AssertionError:
        raise AssertionError("Failed to set the environment correctly")

    try:
        check_env("wrong-branch")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError should have been raised")

# Generated at 2022-06-12 06:27:44.741428
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")



# Generated at 2022-06-12 06:27:46.488679
# Unit test for function circle
def test_circle():
    # This unit test is just a simple example
    try:
        circle("master")
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-12 06:27:51.336079
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    assert frigg(branch="develop")
    os.environ["FRIGG_PULL_REQUEST"] = "1"
    assert not frigg(branch="develop")



# Generated at 2022-06-12 06:27:53.055222
# Unit test for function frigg
def test_frigg():
    result = frigg("master")
    assert result



# Generated at 2022-06-12 06:27:57.555259
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "test-branch"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("test-branch")


# Generated at 2022-06-12 06:28:04.942367
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    semaphore("master")
    assert os.environ.get("BRANCH_NAME") == "master"
    assert os.environ.get("PULL_REQUEST_NUMBER") is None
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]


# Generated at 2022-06-12 06:28:13.808041
# Unit test for function circle
def test_circle():
    env = {
        "CIRCLE_BRANCH": "master",
        "CI_PULL_REQUEST": "",
    }
    circle("master")
    env["CIRCLE_BRANCH"] = "develop"
    with pytest.raises(CiVerificationError):
        circle("master")
    env["CIRCLE_BRANCH"] = "master"
    env["CI_PULL_REQUEST"] = "some-value"
    with pytest.raises(CiVerificationError):
        circle("master")


# Generated at 2022-06-12 06:28:17.408370
# Unit test for function checker
def test_checker():
    assert checker(lambda: False)() == True
    assert checker(lambda: True)() == True
    try:
        checker(lambda: False)()
        assert False
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."
    try:
        checker(lambda: False)()
        assert False
    except AssertionError:
        assert False


# Unit tests for function travis

# Generated at 2022-06-12 06:28:26.504031
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    bitbucket(os.environ["BITBUCKET_BRANCH"])
    os.environ["BITBUCKET_PR_ID"] = 123
    result = bitbucket(os.environ["BITBUCKET_BRANCH"])
    assert(result == False)
    os.environ["BITBUCKET_BRANCH"] = "dev"
    result = bitbucket(os.environ["BITBUCKET_BRANCH"])
    assert(result == False)
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    result

# Generated at 2022-06-12 06:28:31.977315
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    assert travis("master") is False

# Generated at 2022-06-12 06:30:25.243631
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_BUILD_ID"] = "12345"
    os.environ["FRIGG_BUILD_URL"] = "http://example.com"
    os.environ["FRIGG_BUILD_COMMIT"] = "75f4c4d"
    os.environ["FRIGG_BUILD_NUMBER"] = "123"
    os.environ["FRIGG_ORGANIZATION"] = "frigg"
    os.environ["FRIGG_PROJECT_SLUG"] = "release"
    os.environ["FRIGG_PULL_REQUEST"] = "false"

# Generated at 2022-06-12 06:30:28.128012
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")



# Generated at 2022-06-12 06:30:30.466276
# Unit test for function semaphore
def test_semaphore():
    """
    unit test for function semaphore
    
    """
    # execution of test cases is done here
    assert semaphore("master") is True

# Generated at 2022-06-12 06:30:34.025343
# Unit test for function checker
def test_checker():
    @checker
    def test_function():
        raise ValueError

    try:
        test_function()
    except CiVerificationError:
        pass
    else:
        raise RuntimeError

# Generated at 2022-06-12 06:30:38.849756
# Unit test for function jenkins
def test_jenkins():
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert(False)
    try:
        os.environ["BRANCH_NAME"] = "master"
        jenkins("master")
    except CiVerificationError:
        assert(False)

# Generated at 2022-06-12 06:30:40.543961
# Unit test for function circle
def test_circle():
    circle("master")

# Generated at 2022-06-12 06:30:43.257587
# Unit test for function checker
def test_checker():
    @checker
    def test_function():
        assert False
    try:
        test_function()
    except CiVerificationError as e:
        assert e.code == 1

# Generated at 2022-06-12 06:30:50.623779
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "bitbucket"
    os.environ["BITBUCKET_PR_ID"] = "4"
    try:
        bitbucket(branch="master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should not succeed.")

# Generated at 2022-06-12 06:30:53.047736
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = None
    check()
    
    

# Generated at 2022-06-12 06:30:58.493851
# Unit test for function checker
def test_checker():
    def test():
        raise AssertionError('Initial test failed.')

    def fail():
        raise Exception("test has failed.")

    wrapped = checker(test)
    wrapped_fail = checker(fail)
    assert wrapped()
    try:
        assert wrapped_fail()
        assert False
    except CiVerificationError:
        assert True