

# Generated at 2022-06-12 06:21:07.805184
# Unit test for function checker
def test_checker():
    def func():
        pass

    assert checker(func)() is True

    def func():
        assert False

    try:
        assert checker(func)() is True
    except CiVerificationError:
        return
    assert False


if __name__ == "__main__":
    check()

# Generated at 2022-06-12 06:21:14.699329
# Unit test for function checker
def test_checker():
    def no_value():
        pass

    def value():
        return "value"

    def raises():
        raise AssertionError()

    def returns():
        return None

    checker_no_value = checker(no_value)
    checker_value = checker(value)
    checker_raises = checker(raises)
    checker_returns = checker(returns)

    assert checker_no_value() is None
    assert checker_value() == "value"
    try:
        checker_raises()
    except CiVerificationError:
        pass
    else:
        raise Exception("Should have raised a CiVerificationError.")
    try:
        checker_returns()
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:21:23.754482
# Unit test for function gitlab
def test_gitlab():
    """
    Make sure that gitlab function works with all the possible
    environment variables.
    """
    change_id = "change_id"
    branch_name = "master"
    os.environ["CI_COMMIT_REF_NAME"] = branch_name
    os.environ["CI_MERGE_REQUEST_ID"] = change_id
    gitlab(branch_name)
    assert os.environ["CI_COMMIT_REF_NAME"] == branch_name
    assert os.environ["CI_MERGE_REQUEST_ID"] == change_id
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]
    gitlab(branch_name)

# Generated at 2022-06-12 06:21:28.752349
# Unit test for function gitlab
def test_gitlab():
    # Test pull-request build
    os.environ["CI_COMMIT_REF_NAME"] = "my-branch"
    os.environ["CI_MERGE_REQUEST_IID"] = "1"
    os.environ["GITLAB_CI"] = "true"
    # Test branch build
    try:
        gitlab(branch="my-branch")
        assert False, "Semantic Release failed to raise exception"
    except CiVerificationError:
        assert True
    del os.environ["CI_MERGE_REQUEST_IID"]
    gitlab(branch="my-branch")


# Generated at 2022-06-12 06:21:36.500217
# Unit test for function gitlab
def test_gitlab():
    import unittest
    import unittest.mock as mock

    class MockEnvironment(dict):
        def get(self, key):
            if key == 'CI_COMMIT_REF_NAME':
                return 'master'
            else:
                return None

    mock_env = MockEnvironment()

    with mock.patch('os.environ', mock_env):
        test = gitlab('master')
        assert test

    mock_env['CI_COMMIT_REF_NAME'] = 'someotherbranch'
    with mock.patch('os.environ', mock_env):
        test2 = gitlab('master')
        assert test2 is False

# Generated at 2022-06-12 06:21:37.816024
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master") == True

# Generated at 2022-06-12 06:21:48.143991
# Unit test for function travis
def test_travis():
    # Test to see if branch is master
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")

    # Test to see if branch is not master
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
        assert False
    except CiVerificationError:
        assert True
        del os.environ["TRAVIS_BRANCH"]
        del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-12 06:21:56.272777
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "test"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    del os.environ["PULL_REQUEST_NUMBER"]
    assert semaphore("test")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore("test")
    os.environ["PULL_REQUEST_NUMBER"] = "42"
    assert not semaphore("test")



# Generated at 2022-06-12 06:22:06.914292
# Unit test for function jenkins
def test_jenkins():
    # Check the function jenkis works fine with PR and no PR
    os.environ["JENKINS_URL"] = 'some.url'
    os.environ["BRANCH_NAME"] = 'master'
    os.environ["CHANGE_ID"] = ''
    assert check() is None
    del os.environ["CHANGE_ID"]
    assert check() is None
    os.environ["BRANCH_NAME"] = 'develop'
    assert check('develop') is None
    os.environ["BRANCH_NAME"] = 'master'
    os.environ["CHANGE_ID"] = 'someid'
    assert check() is None
    try:
        check()
    except CiVerificationError:
        assert True

# Generated at 2022-06-12 06:22:17.134324
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["PULL_REQUEST_NUMBER"] = None
    assert semaphore("master")
    try:
        assert semaphore("test")
        assert False
    except CiVerificationError:
        assert True
    except AssertionError:
        assert False
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    try:
        assert semaphore("master")
        assert False
    except CiVerificationError:
        assert True
    except AssertionError:
        assert False

# Generated at 2022-06-12 06:22:25.534873
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"

    check()

# Generated at 2022-06-12 06:22:35.949714
# Unit test for function bitbucket
def test_bitbucket():
    # Test run on a pull request
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_PR_ID'] = "5"
    try:
        bitbucket('master')
        assert False, "test_bitbucket should have failed on a Pull Request"
    except CiVerificationError:
        pass

    # Test run on a normal commit
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_PR_ID'] = ""
    assert bitbucket('master')

# Generated at 2022-06-12 06:22:46.241876
# Unit test for function circle
def test_circle():
    """
    Test the `circle` function
    """
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle("master") == True

    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle("master") == True

    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_BRANCH"] = "gh-pages"
    assert circle("master") == True
    os.environ.pop("CI_PULL_REQUEST")

# Generated at 2022-06-12 06:22:56.091738
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_SOURCE_BRANCH_NAME"] = "develop"
    check()

    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    os.environ["CI_MERGE_REQUEST_SOURCE_BRANCH_NAME"] = "master"
    check()

    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    os.environ["CI_MERGE_REQUEST_SOURCE_BRANCH_NAME"] = "develop"
    check(branch="develop")

    os.environ["CI_COMMIT_REF_NAME"] = "master"

# Generated at 2022-06-12 06:23:06.387987
# Unit test for function frigg
def test_frigg():
    # Check success
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    os.environ['FRIGG_PULL_REQUEST'] = ""
    assert frigg("master") == True

    # Check failed due to wrong branch
    os.environ['FRIGG_BUILD_BRANCH'] = "develop"
    assert frigg("master") == False

    # Check failed due to pull request
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    os.environ['FRIGG_PULL_REQUEST'] = "42"
    assert frigg("master") == False

    # Remove environment variables
    del os.environ['FRIGG']

# Generated at 2022-06-12 06:23:07.123546
# Unit test for function check
def test_check():
    check()

# Generated at 2022-06-12 06:23:11.307791
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "23"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "0"
    check()

# Generated at 2022-06-12 06:23:16.587190
# Unit test for function check
def test_check():
    for key in os.environ.keys():
        del os.environ[key]
    os.environ["TRAVIS"] = "true"
    try:
        check("master")
        assert True
    except CiVerificationError as err:
        assert False
    os.environ["TRAVIS_BRANCH"] = "develop"
    try:
        check("master")
        assert False
    except CiVerificationError as err:
        assert True
    


# Generated at 2022-06-12 06:23:21.517092
# Unit test for function check
def test_check():
    # Configure test environment
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    # Run tests
    check()

# Generated at 2022-06-12 06:23:27.044644
# Unit test for function checker
def test_checker():
    """
    Checks that the function checker raises the right error
    """
    @checker
    def check_my_error():
        """
        Raise an error to see what happens
        """
        raise AssertionError

    try:
        check_my_error()
        raise AssertionError
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:23:37.382393
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = False
    circle('master')

# Generated at 2022-06-12 06:23:43.429184
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"]="master"
    os.environ["PULL_REQUEST_NUMBER"]="null"
    os.environ["SEMAPHORE_THREAD_RESULT"]="failed"
    assert semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"]="passing"
    assert semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"]="passing"
    assert semaphore("master")


# Generated at 2022-06-12 06:23:53.047712
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = None
    os.environ["VERSION"] = "0.2.0"

    # Test checker
    frigg("master")

    assert os.environ["VERSION"] == "0.2.0"

    # Test travis
    travis("master")

    assert os.environ["VERSION"] == "0.2.0"

    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]
    del os.environ["VERSION"]


# Generated at 2022-06-12 06:23:53.819164
# Unit test for function travis
def test_travis():
    assert travis("master")


# Generated at 2022-06-12 06:23:57.297379
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-12 06:24:01.422811
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "a1/b2"
    os.environ["BITBUCKET_PR_ID"] = "12345678"
    bitbucket("master")

# Generated at 2022-06-12 06:24:08.060722
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    check()
    del os.environ["TRAVIS_BRANCH"]
    with pytest.raises(CiVerificationError):
        check()
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    with pytest.raises(CiVerificationError):
        check()
    os.environ["TRAVIS_BRANCH"] = "other_branch"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

# Generated at 2022-06-12 06:24:09.615917
# Unit test for function check
def test_check():
    """
    Unit test for function check.
    """
    assert check('test-branch')

# Generated at 2022-06-12 06:24:15.333833
# Unit test for function frigg
def test_frigg():
    """
    Test frigg() function

    :return: True if test passed
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test-branch"
    assert frigg("test-branch")

    os.environ["FRIGG_BUILD_BRANCH"] = "test-branch"
    os.environ["FRIGG_PULL_REQUEST"] = "False"
    try:
        frigg("test-branch")
    except CiVerificationError:
        assert True
    else:
        assert False



# Generated at 2022-06-12 06:24:27.145833
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") == True

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
    except CiVerificationError:
        assert True
    else:
        assert False

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1234"

# Generated at 2022-06-12 06:24:38.275999
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = None
    check()
    

# Generated at 2022-06-12 06:24:39.310576
# Unit test for function bitbucket
def test_bitbucket():

    bitbucket(branch)



# Generated at 2022-06-12 06:24:41.943164
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

# Generated at 2022-06-12 06:24:49.230794
# Unit test for function semaphore
def test_semaphore():
    env_dict_successful = {
        "BRANCH_NAME": "master",
        "PULL_REQUEST_NUMBER": None,
        "SEMAPHORE_THREAD_RESULT": "passed",
    }
    env_dict_wrong_branch = {
        "BRANCH_NAME": "development",
        "PULL_REQUEST_NUMBER": None,
        "SEMAPHORE_THREAD_RESULT": "passed",
    }
    env_dict_pull_request = {
        "BRANCH_NAME": "master",
        "PULL_REQUEST_NUMBER": "2",
        "SEMAPHORE_THREAD_RESULT": "passed",
    }

# Generated at 2022-06-12 06:24:53.918553
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    os.environ["CHANGE_ID"] = ""
    check()

# Generated at 2022-06-12 06:24:57.699202
# Unit test for function gitlab
def test_gitlab():
    assert os.environ.get("GITLAB_CI") == "true"
    assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
    gitlab(branch="master")

# Generated at 2022-06-12 06:25:05.672766
# Unit test for function bitbucket
def test_bitbucket():
    # Should raise an error
    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = "123456"
    try:
        bitbucket("master")
    except CiVerificationError:
        assert True

    # Should not raise an error
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    assert bitbucket("master")

# Generated at 2022-06-12 06:25:13.684279
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = "true"
    os.environ['CI_PULL_REQUEST'] = ""
    os.environ['CIRCLE_BRANCH'] = "development"
    assert circle.__wrapped__("development")
    os.environ['CI_PULL_REQUEST'] = "false"
    assert circle.__wrapped__("development")


# Generated at 2022-06-12 06:25:17.061896
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = 'http://localhost/'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['GIT_BRANCH'] = 'master'
    check()

# Generated at 2022-06-12 06:25:24.601164
# Unit test for function gitlab
def test_gitlab():
    os.environ['GITLAB_CI'] = "true"
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    check()
    os.environ['CI_COMMIT_REF_NAME'] = "release-notes"
    check(branch="release-notes")
    del os.environ['CI_COMMIT_REF_NAME']
    check(branch="release-notes")


# Generated at 2022-06-12 06:25:31.619833
# Unit test for function circle
def test_circle():
    assert circle("master")



# Generated at 2022-06-12 06:25:36.569797
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test the function bitbucket
    """
    assert checker(bitbucket)(branch="mybranch") == True
    os.environ["BITBUCKET_BRANCH"] = "mybranch"
    assert checker(bitbucket)(branch="master") == True
    del os.environ["BITBUCKET_BRANCH"]


# Generated at 2022-06-12 06:25:38.657505
# Unit test for function check
def test_check():
    try:
        assert check() == None
    except:
        pass

# Generated at 2022-06-12 06:25:39.761586
# Unit test for function travis
def test_travis():
    assert travis("master")



# Generated at 2022-06-12 06:25:41.566618
# Unit test for function jenkins
def test_jenkins():
    """
    Tests the Jenkins function against an environment variable
    """
    assert jenkins == True

# Generated at 2022-06-12 06:25:43.084998
# Unit test for function checker
def test_checker():
    def testfunc():
        raise AssertionError

    assert checker(testfunc)() is False

# Generated at 2022-06-12 06:25:44.214732
# Unit test for function semaphore
def test_semaphore():
    assert semaphore(branch="master")

# Generated at 2022-06-12 06:25:50.775930
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    ci_env = "travis"
    os.environ["CI_ENV"] = ci_env

    check('master')
    assert os.environ["CI_ENV"] == ci_env


# Generated at 2022-06-12 06:25:58.524918
# Unit test for function check
def test_check():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["SEMAPHORE"] = "true"
    os.environ["FRIGG"] = "true"
    os.environ["CIRCLECI"] = "true"
    os.environ["JENKINS_URL"] = "https://jenkins.pennock-tech.net/"
    check()

# Generated at 2022-06-12 06:26:03.792531
# Unit test for function checker
def test_checker():
    @checker
    def check_success():
        assert True

    @checker
    def check_fail():
        assert False

    try:
        check_success()
    except CiVerificationError as e:
        assert False, "Expected this to pass"
    try:
        check_fail()
        assert False, "Expected this to fail"
    except CiVerificationError as e:
        assert True

# Generated at 2022-06-12 06:26:22.312681
# Unit test for function semaphore
def test_semaphore():
    # Test success
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")

    # Test fail
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore("master")

    # Test fail
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["BRANCH_NAME"] = "develop"
    assert not semaphore("master")

    # Clean up
    del os.environ["BRANCH_NAME"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]

# Generated at 2022-06-12 06:26:30.497771
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"]="true"
    os.environ["CIRCLE_BRANCH"]="master"
    os.environ["CI_PULL_REQUEST"]="true"

    try:
        circle(os.environ["CIRCLE_BRANCH"])
    except CiVerificationError:
        pass

    os.environ["CI_PULL_REQUEST"]="false"
    try:
        circle(os.environ["CIRCLE_BRANCH"])
    except CiVerificationError:
        assert False

    os.environ["CIRCLECI"] = "false"
    try:
        circle(os.environ["CIRCLE_BRANCH"])
    except CiVerificationError:
        assert False


# Generated at 2022-06-12 06:26:33.303352
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "test"
    os.environ["CI_MERGE_REQUEST_IID"] = "test"
    gitlab("test")



# Generated at 2022-06-12 06:26:46.000719
# Unit test for function circle
def test_circle():
    # Test should pass
    os.environ['CIRCLE_BRANCH'] = "circle_branch"
    os.environ['CI_PULL_REQUEST'] = ""
    check("circle_branch")

    # Test should raise an error
    os.environ['CIRCLE_BRANCH'] = "circle_branch"
    os.environ['CI_PULL_REQUEST'] = "true"
    try:
        check("circle_branch")
    except CiVerificationError:
        os.environ['CIRCLE_BRANCH'] = ""
        os.environ['CI_PULL_REQUEST'] = ""
    else:
        os.environ['CIRCLE_BRANCH'] = ""
        os.environ['CI_PULL_REQUEST'] = ""
        raise Exception

# Generated at 2022-06-12 06:26:46.978538
# Unit test for function travis
def test_travis():
    pass


# Generated at 2022-06-12 06:26:48.253791
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket("master") is True
    # assert bitbucket("master") is False

# Generated at 2022-06-12 06:26:54.395570
# Unit test for function circle
def test_circle():
    """
    Performs necessary checks to ensure that the circle build is one
    that should create releases.

    :param branch: The branch the environment should be running against.
    """
    import os
    assert os.environ.get("CIRCLECI") == "true"
    assert circle(branch="master") == True
    assert circle(branch="develop") == True
    assert circle(branch="mater") == False
    assert circle(branch="") == False


# Generated at 2022-06-12 06:27:01.610915
# Unit test for function semaphore
def test_semaphore():
    """
    This function test if the semaphore is working properly
    """
    # check if the branch is the commit branch
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "true"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    with pytest.raises(CiVerificationError):
        semaphore("master")
    # check if the branch is the commit branch
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "false"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    with pytest.raises(CiVerificationError):
        sem

# Generated at 2022-06-12 06:27:06.938407
# Unit test for function gitlab
def test_gitlab():
    branch = 'master'
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = branch
    del os.environ["CI_MERGE_REQUEST_ID"]

    res = check(branch)
    assert(res == True)


# Generated at 2022-06-12 06:27:13.874687
# Unit test for function travis
def test_travis():
    assert travis("develop")
    os.environ["TRAVIS_BRANCH"] = "master"
    assert travis("master")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        pass


# Generated at 2022-06-12 06:27:29.072321
# Unit test for function gitlab
def test_gitlab():
    """
    This function is a unit test for the gitlab checker function
    in contextual_versioning/ci_checks.py
    """
    env = {'GITLAB_CI': 'true', 'CI_COMMIT_REF_NAME': 'master',
           'CI_PROJECT_NAME': 'test'}
    gitlab(branch='master', **env)
    env = {'GITLAB_CI': 'true', 'CI_COMMIT_REF_NAME': 'develop',
           'CI_PROJECT_NAME': 'test'}
    gitlab(branch='master', **env)

# Generated at 2022-06-12 06:27:33.045305
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()


# Generated at 2022-06-12 06:27:37.680138
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert check()
    os.environ["CI_COMMIT_REF_NAME"] = "my_branch"
    assert not check()
    del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-12 06:27:42.332722
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")



# Generated at 2022-06-12 06:27:50.666142
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "dev"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("dev")
    except CiVerificationError:
        assert False
    os.environ["BRANCH_NAME"] = "dev"
    os.environ["PULL_REQUEST_NUMBER"] = "32"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("dev")
        assert False
    except CiVerificationError:
        assert True
    os.environ["BRANCH_NAME"] = "master"

# Generated at 2022-06-12 06:27:54.154112
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check("master")


# Generated at 2022-06-12 06:27:58.838843
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = 'false'
    check()



# Generated at 2022-06-12 06:28:02.387919
# Unit test for function checker
def test_checker():
    """
    A test that tests the checker decorator.
    """

    # Raise assertion error
    @checker
    def fail():
        assert False

    # Raise no assertion error
    @checker
    def pass_():
        pass

    try:
        fail()
    except CiVerificationError:
        pass_()
    else:
        assert False

# Generated at 2022-06-12 06:28:08.365374
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    circle("master")
    having_exception = False
    try:
        circle("other_branch")
    except CiVerificationError:
        having_exception = True
    assert having_exception



# Generated at 2022-06-12 06:28:12.395463
# Unit test for function gitlab
def test_gitlab():
	# Test that the 'ci_commit_ref_name' variable is not equal to the branch
	# If branch doesn't match, function should return False
	assert gitlab("test") == False


# Generated at 2022-06-12 06:28:36.709434
# Unit test for function jenkins
def test_jenkins():
    # Test case 1
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = None
    assert check() is None

    # Test case 2
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "test-branch"
    os.environ["CHANGE_ID"] = None
    assert check("test-branch") is None

    # Test case 3
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "pr-1234"
    assert check()

# Generated at 2022-06-12 06:28:37.232074
# Unit test for function check
def test_check():
    check()

# Generated at 2022-06-12 06:28:47.904513
# Unit test for function frigg
def test_frigg():
    """
    :return:
    """

    # Test for expected error
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = True
    os.environ["FRIGG_BUILD_RESULT"] = "passed"
    try:
        frigg("master")
    except CiVerificationError:
        print("FRIGG CASE 1: Passed")
    except AssertionError:
        raise AssertionError("FRIGG CASE 1: Failed")

    # Test for expected error
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "demo"

# Generated at 2022-06-12 06:28:51.699774
# Unit test for function check
def test_check():
    # Set os.environ['TRAVIS'] to true
    os.environ['TRAVIS'] = "true"
    
    # No exception should be raised
    check("master")
    
    # Unset os.environ['TRAVIS']
    del os.environ['TRAVIS']

# Generated at 2022-06-12 06:28:57.385150
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check("master")
    del os.environ["CI_COMMIT_REF_NAME"]

    os.environ["CI_COMMIT_REF_NAME"] = "test"
    try:
        check("master")
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:29:00.545291
# Unit test for function checker
def test_checker():
    """
    Tests the checker decorator.
    """

    @checker
    def failing_check():
        """
        Fails the check.
        """
        assert False

    assert failing_check() is True

# Generated at 2022-06-12 06:29:02.466890
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    del os.environ["CI_MERGE_REQUEST_ID"]
    check()

# Generated at 2022-06-12 06:29:03.457239
# Unit test for function circle
def test_circle():
    assert circle() is True


# Generated at 2022-06-12 06:29:15.676507
# Unit test for function semaphore
def test_semaphore():
    """
    Check if semaphore can handle all of its variables
    """
    # Test if all variables is set
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "False"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "True"
    assert semaphore("master")

    # Test if there is no SEMAPHORE_THREAD_RESULT
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    assert semaphore("master")

    # Test if there is a SEMAPHORE_THREAD_RESULT is set to "failed"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore("master")

    # Test

# Generated at 2022-06-12 06:29:18.635763
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://localhost:8080"
    os.environ["BRANCH_NAME"] = "master"

    branch = "master"

    jenkins(branch)

# Generated at 2022-06-12 06:29:54.306699
# Unit test for function frigg

# Generated at 2022-06-12 06:29:59.818880
# Unit test for function gitlab
def test_gitlab():
    Test_Gitlab_Env_True_Commit_Ref_Name = "master"
    Test_Gitlab_Env_False_Commit_Ref_Name = ""

    # Test Environment with Commit_Ref_Name == master
    assert gitlab(Test_Gitlab_Env_True_Commit_Ref_Name) is True

    # Test Environment with Commit_Ref_Name != master
    assert gitlab(Test_Gitlab_Env_False_Commit_Ref_Name) is False



# Generated at 2022-06-12 06:30:09.157356
# Unit test for function circle
def test_circle():
    try:
        os.environ["TRAVIS"] = "false"
        os.environ["SEMAPHORE"] = "false"
        os.environ["FRIGG"] = "false"
        os.environ["CIRCLECI"] = "true"
        os.environ["GITLAB_CI"] = "false"
        os.environ["JENKINS_URL"] = "false"
        os.environ["BITBUCKET_BUILD_NUMBER"] = "false"
        os.environ["CI_PULL_REQUEST"] = "false"
        os.environ["CIRCLE_BRANCH"] = "master"
        check("master")
    except CiVerificationError:
        assert False
    finally:
        os.environ["CIRCLECI"] = "false"


# Generated at 2022-06-12 06:30:18.212224
# Unit test for function jenkins
def test_jenkins():
    os.environ["CI_COMMIT_REF_NAME"] = "test_branch"
    assert jenkins("test_branch") == True
    del os.environ["CI_COMMIT_REF_NAME"]
    assert jenkins("test_branch") == False
    os.environ["BRANCH_NAME"] = "test_branch"
    assert jenkins("test_branch") == True
    del os.environ["BRANCH_NAME"]
    assert jenkins("test_branch") == False
    os.environ["GIT_BRANCH"] = "test_branch"
    assert jenkins("test_branch") == True
    del os.environ["GIT_BRANCH"]
    assert jenkins("test_branch") == False
    os.environ

# Generated at 2022-06-12 06:30:22.916148
# Unit test for function bitbucket
def test_bitbucket():
    """
    Function for testing bitbucket CI checker
    """
    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = "2"
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        os.environ.pop("BITBUCKET_PR_ID")
        assert True

# Generated at 2022-06-12 06:30:25.791963
# Unit test for function bitbucket
def test_bitbucket():
    assert os.environ.get("BITBUCKET_BUILD_NUMBER") is '$BITBUCKET_BUILD_NUMBER'

# Generated at 2022-06-12 06:30:34.350270
# Unit test for function check
def test_check():
    """Test check function
    """
    os.environ['TRAVIS'] = 'false'
    os.environ['FRIGG'] = 'false'
    os.environ['SEMAPHORE'] = 'false'
    os.environ['CIRCLECI'] = 'false'
    os.environ['GITLAB_CI'] = 'false'
    os.environ['JENKINS_URL'] = 'false'
    os.environ['CHANGE_ID'] = None
    os.environ['BITBUCKET_BUILD_NUMBER'] = 'false'
    check("master")

# Generated at 2022-06-12 06:30:40.188686
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")
    os.environ["BITBUCKET_BUILD_NUMBER"] = None
    os.environ["BITBUCKET_BRANCH"] = "other_branch"
    bitbucket("master")

# Generated at 2022-06-12 06:30:46.800744
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.local"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = None
    assert jenkins("master")
    assert not jenkins("develop")
    assert not jenkins("feature/test")

# Generated at 2022-06-12 06:30:55.361282
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "http://jenkins-server.com"
    os.environ["CHANGE_ID"] = ""
    assert jenkins("master") == True

    os.environ["BRANCH_NAME"] = "master"
    del os.environ["JENKINS_URL"]
    os.environ["CHANGE_ID"] = ""
    assert jenkins("master") == False

    os.environ["BRANCH_NAME"] = "dev"
    os.environ["JENKINS_URL"] = "http://jenkins-server.com"
    os.environ["CHANGE_ID"] = ""
    assert jenkins("master") == False
