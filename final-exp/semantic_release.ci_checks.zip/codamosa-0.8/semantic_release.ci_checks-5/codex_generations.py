

# Generated at 2022-06-12 06:21:11.549961
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = None
    assert bitbucket("master")
    os.environ['BITBUCKET_PR_ID'] = 1
    assert not bitbucket("master")
    del os.environ['BITBUCKET_BRANCH']
    del os.environ['BITBUCKET_PR_ID']

# Generated at 2022-06-12 06:21:15.113791
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG_BUILD_BRANCH"] = "1.2.3"
    frigg("1.2.3")
    del os.environ["FRIGG_BUILD_BRANCH"]



# Generated at 2022-06-12 06:21:17.980505
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    travis("master")



# Generated at 2022-06-12 06:21:23.308581
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
    del os.environ["CI_COMMIT_REF_NAME"]
    assert os.environ.get("CI_COMMIT_REF_NAME") is None


# Generated at 2022-06-12 06:21:23.824370
# Unit test for function check
def test_check():
    assert check()

# Generated at 2022-06-12 06:21:25.813031
# Unit test for function checker
def test_checker():
    def test_func():
        raise AssertionError

    try:
        checker(test_func)()
    except CiVerificationError:
        assert True

# Generated at 2022-06-12 06:21:27.877790
# Unit test for function jenkins
def test_jenkins():
    assert jenkins( "master" ) == True


# Generated at 2022-06-12 06:21:31.162900
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    check()


# Generated at 2022-06-12 06:21:40.245719
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    os.environ["BRANCH_NAME"] = "staging"

    # should check out ok
    jenkins("staging")

    # should throw assertion error as on wrong branch
    try:
        jenkins("master")
    except AssertionError:
        pass
    else:
        # AssertionError not raised if checking on wrong branch
        assert False

    os.environ["GIT_BRANCH"] = "staging"
    jenkins("staging")

    # should throw exception for env vars not set for pull request
    os.environ["CHANGE_ID"] = "12"
    try:
        jenkins("staging")
    except AssertionError:
        pass

# Generated at 2022-06-12 06:21:44.244555
# Unit test for function travis
def test_travis():
    try:
        travis('master')
        assert 1
    except AssertionError:
        assert 0
    try:
        travis('Not boolean')
        assert 0
    except AssertionError:
        assert 1


# Generated at 2022-06-12 06:21:55.554098
# Unit test for function checker
def test_checker():
    def should_pass():
        assert 1 == 1

    def should_fail():
        assert 1 == 2

    assert checker(should_pass)()
    try:
        checker(should_fail)()
    except CiVerificationError:
        pass
    else:
        assert False, "CiVerificationError not raised"

# Generated at 2022-06-12 06:22:06.838802
# Unit test for function check
def test_check():
    import os
    os.environ['TRAVIS'] = 'true'
    assert check()
    os.environ.pop('TRAVIS')
    os.environ['SEMAPHORE'] = 'true'
    assert check()
    os.environ.pop('SEMAPHORE')
    os.environ['FRIGG'] = 'true'
    assert check()
    os.environ.pop('FRIGG')
    os.environ['CIRCLECI'] = 'true'
    assert check()
    os.environ.pop('CIRCLECI')
    os.environ['GITLAB_CI'] = 'true'
    assert check()
    os.environ.pop('GITLAB_CI')
    os.environ['JENKINS_URL'] = 'true'
    assert check()

# Generated at 2022-06-12 06:22:16.134033
# Unit test for function semaphore
def test_semaphore():
    os.environ['COMMIT_MESSAGE'] = "feat(test): test"
    os.environ['BRANCH_NAME'] = "master"
    os.environ['PULL_REQUEST_NUMBER'] = None
    assert semaphore("master") == True
    os.environ['COMMIT_MESSAGE'] = "fix(test): test"
    assert semaphore("master") == True
    os.environ['COMMIT_MESSAGE'] = "perf(test): test"
    assert semaphore("master") == True
    os.environ['COMMIT_MESSAGE'] = ""
    assert semaphore("master") == False


# Generated at 2022-06-12 06:22:22.225554
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['RELEASE'] = '1.1.1'
    os.environ["CIRCLE_BRANCH"] = 'master'
    os.environ["CI_PULL_REQUEST"] = ''
    os.environ['CI_COMMIT_ID'] = ''
    assert check() == True
    

# Generated at 2022-06-12 06:22:25.438713
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('master')


# Generated at 2022-06-12 06:22:29.187030
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "test"
    circle("test")



# Generated at 2022-06-12 06:22:31.084184
# Unit test for function travis
def test_travis():
        try:
            travis("master")
        except:
            raise


# Generated at 2022-06-12 06:22:38.943106
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    assert "TRAVIS" in os.environ
    assert os.environ["TRAVIS"] == "true"
    assert "TRAVIS_BRANCH" in os.environ
    assert os.environ["TRAVIS_BRANCH"] == "master"
    assert "TRAVIS_PULL_REQUEST" in os.environ
    assert os.environ["TRAVIS_PULL_REQUEST"] == "false"

# Generated at 2022-06-12 06:22:42.871384
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '111'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = ''
    bitbucket('master')

# Generated at 2022-06-12 06:22:47.275217
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    branch = 'master'
    travis(branch)

# Generated at 2022-06-12 06:23:04.550189
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "test"
    os.environ["CI_PULL_REQUEST"] = "false"
    circle("test")



# Generated at 2022-06-12 06:23:05.402291
# Unit test for function check
def test_check():
    assert check("master") is None

# Generated at 2022-06-12 06:23:11.923827
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    check(branch = "master")
    assert os.environ["TRAVIS"] == "true"
    del os.environ["TRAVIS"]
    os.environ["SEMAPHORE"] = "true"
    check(branch = "master")
    assert os.environ["SEMAPHORE"] == "true"
    del os.environ["SEMAPHORE"]
    os.environ["FRIGG"] = "true"
    check(branch = "master")
    assert os.environ["FRIGG"] == "true"
    del os.environ["FRIGG"]
    os.environ["CIRCLECI"] = "true"
    check(branch = "master")

# Generated at 2022-06-12 06:23:16.234103
# Unit test for function checker
def test_checker():
    """
    Makes sure that the checker will correctly identify AssertionErrors
    and raise a CiVerificationError.
    """
    def test_func():
        assert False
    wrapped_func = checker(test_func)
    try:
        wrapped_func()
    except CiVerificationError:
        pass


# Unit tests for individual check functions

# Generated at 2022-06-12 06:23:21.183218
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")

# Generated at 2022-06-12 06:23:26.174980
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check("master")
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    with pytest.raises(CiVerificationError):
        check("master")



# Generated at 2022-06-12 06:23:29.747042
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    check()


# Generated at 2022-06-12 06:23:41.281401
# Unit test for function travis
def test_travis():
    branch_name = "master"
    payload = {"TRAVIS_BRANCH": branch_name, "TRAVIS_PULL_REQUEST": "false"}
    assert travis(branch_name=branch_name)
    try:
        del payload["TRAVIS_BRANCH"]
        assert not travis(branch_name=branch_name)
    except CiVerificationError:
        pass
    try:
        payload["TRAVIS_BRANCH"] = "develop"
        assert not travis(branch_name=branch_name)
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:23:51.700943
# Unit test for function semaphore
def test_semaphore():
    from semantic_release.ci_checks import semaphore
    import os
    import re
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    semaphore(os.environ["BRANCH_NAME"])
    assert re.match(r"^[a-f0-9]{40}$", os.environ["SEMAPHORE_THREAD_RESULT"])
    os.environ["PULL_REQUEST_NUMBER"] = "3833"
    semaphore(os.environ["BRANCH_NAME"])

# Generated at 2022-06-12 06:24:02.153296
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    try:
        semaphore("wrong_branch_name")
        assert 1==0
    except CiVerificationError:
        pass
    try:
        os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
        semaphore("master")
        assert 1==0
    except CiVerificationError:
        pass
    try:
        os.environ["PULL_REQUEST_NUMBER"] = "5"
        semaphore("master")
        assert 1==0
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:24:41.335051
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    os.environ['FRIGG_PULL_REQUEST'] = ""

    frigg("master")

    os.environ['FRIGG_PULL_REQUEST'] = "1"
    try:
        frigg("master")
    except CiVerificationError:
        pass

    os.environ['FRIGG_BUILD_BRANCH'] = "develop"
    try:
        frigg("master")
    except CiVerificationError:
        pass


# Generated at 2022-06-12 06:24:42.359264
# Unit test for function check
def test_check():
    assert checker(check)()

# Generated at 2022-06-12 06:24:44.998667
# Unit test for function gitlab
def test_gitlab():
    os.environ['GITLAB_CI'] = "true"
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    os.environ['CI_MERGE_REQUEST_ID'] = None
    gitlab("master")

# Generated at 2022-06-12 06:24:47.632469
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = ""
    os.environ["CI_PULL_REQUEST"] = ""
    os.environ["CIRCLE_BRANCH"] = ""
    try:
        circle("master")
    except CiVerificationError as e:
        pass

# Generated at 2022-06-12 06:24:54.743110
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
    except CiVerificationError:
        assert True
    else:
        assert False



# Generated at 2022-06-12 06:24:56.575688
# Unit test for function frigg
def test_frigg():
    assert frigg("master")



# Generated at 2022-06-12 06:25:02.039098
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""


# Generated at 2022-06-12 06:25:03.088358
# Unit test for function circle
def test_circle():
    assert circle("master")



# Generated at 2022-06-12 06:25:10.179003
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = "true"
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    assert check("master"), "Travis CI should pass the check"

    os.environ['TRAVIS'] = "true"
    os.environ['TRAVIS_BRANCH'] = "develop"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    try:
        check("master")
    except CiVerificationError:
        assert True
    else:
        assert False, "Travis CI should fail the check"

    os.environ['TRAVIS'] = "true"
    os.environ['TRAVIS_BRANCH'] = "master"

# Generated at 2022-06-12 06:25:17.009929
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    os.environ['CI_BUILD_REASON'] = 'PULL_REQUEST'
    os.environ['CI_BUILD_PULL_REQUEST'] = '1337'
    assert check()

# Generated at 2022-06-12 06:26:22.316980
# Unit test for function circle
def test_circle():
    assert not os.environ.get("TRAVIS")
    assert not os.environ.get("SEMAPHORE")
    assert not os.environ.get("FRIGG")
    assert not os.environ.get("CIRCLECI")
    assert not os.environ.get("GITLAB_CI")
    assert not os.environ.get("JENKINS_URL")
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "0"
    assert check()
    os.environ["CIRCLE_BRANCH"] = "develop"
    try:
        check()
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-12 06:26:24.469248
# Unit test for function circle
def test_circle():
    assert not checker(circle)("master")


# Generated at 2022-06-12 06:26:26.946348
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")

# Generated at 2022-06-12 06:26:31.802971
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    os.environ["CHANGE_ID"] = "1"
    jenkins(branch='master')

# Generated at 2022-06-12 06:26:43.269427
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket(branch="master")

    os.environ["BITBUCKET_BUILD_NUMBER"] = ""
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        bitbucket(branch="master")
        assert False
    except CiVerificationError:
        pass
    assert True


# Generated at 2022-06-12 06:26:47.283449
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    circle("master")



# Generated at 2022-06-12 06:26:55.404216
# Unit test for function check
def test_check():
    # Calling check on any environment will raise an error
    # since there is no BRANCH_NAME environment variable.
    #
    # TODO: use other checkers if available
    os.environ["BRANCH_NAME"] = "master"

    check()

    # Remove BRANCH_NAME to test that branch is not required
    del os.environ["BRANCH_NAME"]
    check()

    # TODO: test with all checkers
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    check()

# Generated at 2022-06-12 06:26:57.787488
# Unit test for function frigg
def test_frigg():
    env = {'FRIGG': 'true', 'FRIGG_BUILD_BRANCH': 'master' }
    with mock.patch.dict(os.environ, env):
        frigg('master')

# Generated at 2022-06-12 06:27:04.260791
# Unit test for function jenkins
def test_jenkins():
    """
    Unit test for function jenkins
    """
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"

    check("master")

    del os.environ["JENKINS_URL"]
    del os.environ["BRANCH_NAME"]

# Generated at 2022-06-12 06:27:07.345984
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "gitlab"
    del os.environ["CI_MERGE_REQUEST_ID"]
    check(branch="gitlab")

# Generated at 2022-06-12 06:28:49.647184
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    assert jenkins("master")

    os.environ["BRANCH_NAME"] = "develop"
    assert jenkins("develop")



# Generated at 2022-06-12 06:28:54.817160
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    assert check()
    os.environ["BITBUCKET_PR_ID"] = "12"
    os.environ["BITBUCKET_BRANCH"] = "other"
    assert check("other")

# Generated at 2022-06-12 06:29:02.240061
# Unit test for function jenkins
def test_jenkins():
    """Unit test for my function jenkins."""
    os.environ['JENKINS_URL'] = 'test'
    os.environ['GIT_BRANCH'] = 'test'
    assert jenkins('test')
    os.environ['JENKINS_URL'] = 'test'
    os.environ['GIT_BRANCH'] = 'not_test'
    assert jenkins('test')
    os.environ['JENKINS_URL'] = 'test'
    os.environ['CHANGE_ID'] = 'id'
    assert jenkins('test')

# Generated at 2022-06-12 06:29:05.739341
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert not check()


# Generated at 2022-06-12 06:29:08.282715
# Unit test for function checker
def test_checker():
    @checker
    def foo(branch: str):
        assert branch == "master"

    foo("master")
    

# Generated at 2022-06-12 06:29:19.087324
# Unit test for function check
def test_check():
    # check the function with no env
    check()

    # check with travis
    os.environ["TRAVIS"] = "true"
    check()

    # check with semaphore
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()

    # check with frigg
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    check()

    # check with circle
   

# Generated at 2022-06-12 06:29:27.855113
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "branch"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("branch")
    os.environ["TRAVIS_BRANCH"] = "master"
    try:
        travis("branch")
    except CiVerificationError:
        pass
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]
    try:
        travis("branch")
    except CiVerificationError:
        pass


# Generated at 2022-06-12 06:29:39.301455
# Unit test for function bitbucket
def test_bitbucket():
    assert not os.environ.get("BITBUCKET_BRANCH")
    assert not os.environ.get("BITBUCKET_PR_ID")
    assert not bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert not os.environ.get("BITBUCKET_PR_ID")
    assert bitbucket("master")
    os.environ["BITBUCKET_PR_ID"] = "1"
    assert bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "another"
    assert bitbucket("master")
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]

# Generated at 2022-06-12 06:29:43.129039
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-12 06:29:53.403600
# Unit test for function check
def test_check():
    for os_environ_value, function in (('TRAVIS',travis),('SEMAPHORE',semaphore),('FRIGG',frigg),('CIRCLECI',circle),('GITLAB_CI',gitlab),('JENKINS_URL',jenkins),('BITBUCKET_BUILD_NUMBER',bitbucket)):
        os.environ[os_environ_value] = ''
        check(os_environ_value)
        function.__wrapped__()
        try:
            check('a')
        except CiVerificationError:
            check()
        os.environ[os_environ_value]=None
