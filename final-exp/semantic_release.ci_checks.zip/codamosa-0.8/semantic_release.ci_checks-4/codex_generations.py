

# Generated at 2022-06-12 06:21:14.371580
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "JENKINS_URL"
    with open(os.devnull, "w") as devnull:
        with os.fdopen(os.dup(sys.stdout.fileno()), "wb", 0) as stdout:
            sys.stdout = devnull
            try:
                jenkins("master")
            except AssertionError as error:
                print("AssertionError:", error)
            sys.stdout = stdout

    os.environ["JENKINS_URL"] = "JENKINS_URL"
    os.environ["BRANCH_NAME"] = "master"

# Generated at 2022-06-12 06:21:17.980059
# Unit test for function checker
def test_checker():
    def assertion_err():
        raise AssertionError

    def no_err():
        pass

    decorated = checker(assertion_err)

    with pytest.raises(CiVerificationError):
        decorated()

    decorated = checker(no_err)
    assert decorated()

# Generated at 2022-06-12 06:21:22.837512
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["BRANCH_NAME"] = os.environ["GIT_BRANCH"]
    os.environ["JENKINS_URL"] = "True"
    os.environ["CHANGE_ID"] = "False"
    jenkins("master")

# Generated at 2022-06-12 06:21:26.121103
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    travis("master")


# Generated at 2022-06-12 06:21:29.036834
# Unit test for function checker
def test_checker():
    # pylint: disable=protected-access
    @checker
    def _assert_success():
        assert True
    @checker
    def _assert_fail():
        assert False

    _assert_success()
    try:
        _assert_fail()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError was not thrown.")

# Generated at 2022-06-12 06:21:34.754824
# Unit test for function checker
def test_checker():
    def test_function():
        assert False

    try:
        checker(test_function)()
        assert False
    except CiVerificationError as e:
        assert str(e) == 'The verification check for the environment did not pass.'

# Generated at 2022-06-12 06:21:38.214383
# Unit test for function gitlab
def test_gitlab():
    """
    Checks if CI checks works correctly with GITLAB_CI variable
    """
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"

    check()

    del os.environ["GITLAB_CI"]
    del os.environ["CI_COMMIT_REF_NAME"]



# Generated at 2022-06-12 06:21:40.775364
# Unit test for function checker
def test_checker():
    def test_func():
        raise AssertionError

    with pytest.raises(CiVerificationError):
        checker(test_func)()

# Generated at 2022-06-12 06:21:45.066596
# Unit test for function bitbucket
def test_bitbucket():
    check("testing")
    assert os.environ.get("BITBUCKET_BRANCH") == "testing"
    assert not os.environ.get("BITBUCKET_PR_ID")


# Generated at 2022-06-12 06:21:46.865283
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    gitlab("master")

# Generated at 2022-06-12 06:22:04.655684
# Unit test for function travis
def test_travis():
    # Pass case
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")

    # Failure case
    os.environ["TRAVIS_BRANCH"] = "test"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
        assert False
    except CiVerificationError:
        pass



# Generated at 2022-06-12 06:22:07.313681
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-12 06:22:11.162711
# Unit test for function gitlab
def test_gitlab():
    test_env = {
        "CI_COMMIT_REF_NAME": "master"
    }
    gitlab(branch="master")
    old_env = os.environ.copy()
    os.environ.clear()
    os.environ.update(test_env)
    gitlab("master")
    os.environ.clear()
    os.environ.update(old_env)



# Generated at 2022-06-12 06:22:12.612217
# Unit test for function semaphore
def test_semaphore():
    semaphore(branch="master")

# Generated at 2022-06-12 06:22:17.576216
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check(branch = "master")
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    check(branch = "master")

# Generated at 2022-06-12 06:22:29.034817
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "Jenkins"
    os.environ["CHANGE_ID"] = "1"

    try:
        jenkins("master")
    except:
        pass
    else:
        assert False
    
    os.environ["BRANCH_NAME"] = "integration"
    os.environ["CHANGE_ID"] = ""

    jenkins("integration")

    del os.environ["BRANCH_NAME"]
    os.environ["GIT_BRANCH"] = "master"

    jenkins("master")

    del os.environ["GIT_BRANCH"]
    os.environ["BRANCH_NAME"] = "develop"


# Generated at 2022-06-12 06:22:37.897183
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    assert check(branch="master")
    os.environ["BITBUCKET_BRANCH"] = "test"
    os.environ["BITBUCKET_PR_ID"] = None
    assert check(branch="master") is None
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "True"
    assert check(branch="master") is None


# Generated at 2022-06-12 06:22:47.030147
# Unit test for function travis
def test_travis():
    branch = "master"
    os.environ["TRAVIS_BRANCH"] = branch
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch)
    os.environ["TRAVIS_BRANCH"] = "dummy_branch"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis(branch)
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["TRAVIS_BRANCH"] = branch
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ.pop("TRAVIS_PULL_REQUEST")

# Generated at 2022-06-12 06:22:50.386809
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket()



# Generated at 2022-06-12 06:22:56.942025
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PULL_REQUEST"] = "1"

    try:
        gitlab('master')
    except CiVerificationError as ex:
        assert str(ex) == 'The verification check for the environment did not pass.'
    else:
        raise RuntimeError('Should not get this far')

    del os.environ["CI_PULL_REQUEST"]

    ret = gitlab('master')
    assert ret is True



# Generated at 2022-06-12 06:23:19.327222
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"

    assert check() is None
    assert not check("dev")



# Generated at 2022-06-12 06:23:24.742967
# Unit test for function semaphore
def test_semaphore():
    """
    Test that semaphore function returns true
    """
    # Set key-value pairs
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    assert semaphore("master")



# Generated at 2022-06-12 06:23:32.526629
# Unit test for function checker
def test_checker():
    """
    Tests decorator
    """
    def test_function():
        """
        test function
        """
        raise AssertionError("Failed")

    def test_function2():
        """
        test function
        """
        raise AssertionError("Passed")

    test_function = checker(test_function)
    test_function2 = checker(test_function2)

    try:
        test_function()
    except CiVerificationError:
        pass

    try:
        test_function()
    except CiVerificationError:
        pass

    # Ensure that the decorator doesn't catch Execptions it shouldn't.
    try:
        test_function2()
    except AssertionError:
        pass

# Generated at 2022-06-12 06:23:33.863221
# Unit test for function bitbucket
def test_bitbucket():
    return None

# Generated at 2022-06-12 06:23:36.367626
# Unit test for function bitbucket
def test_bitbucket():
    branch = "master"
    os.environ["BITBUCKET_BRANCH"] = branch
    bitbucket(branch)

# Generated at 2022-06-12 06:23:44.146455
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "test_branch"
    assert os.environ.get("GITLAB_CI") == "true"
    assert os.environ.get("CI_COMMIT_REF_NAME") == "test_branch"
    assert os.environ.get("CI_MERGE_REQUEST_IID") is None
    del os.environ["GITLAB_CI"]
    del os.environ["CI_COMMIT_REF_NAME"]
    assert os.environ.get("GITLAB_CI") is None
    assert os.environ.get("CI_COMMIT_REF_NAME") is None

# Generated at 2022-06-12 06:23:48.534606
# Unit test for function checker
def test_checker():
    def some_check():
        raise AssertionError("Some error")

    wrapped_check = checker(some_check)

    try:
        wrapped_check()
    except CiVerificationError:
        assert True
    else:
        assert False


# Uses a standard dict for mocking the environment
# because mocking os.environ is weird

# Generated at 2022-06-12 06:23:56.483502
# Unit test for function circle
def test_circle():
    try:
        circle('master')
        os.environ['CIRCLE_BRANCH'] = 'master'
        os.environ['CI_PULL_REQUEST'] = 'false'
    except CiVerificationError:
        raise AssertionError("CiVerificationError is raised unexpectedly")

    os.environ['CIRCLE_BRANCH'] = 'not_master'
    try:
        circle('master')
        raise AssertionError("CiVerificationError is expected")
    except CiVerificationError:
        pass

    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = 'true'

# Generated at 2022-06-12 06:23:57.454303
# Unit test for function semaphore
def test_semaphore():
    assert checker(semaphore)("master") is True

# Generated at 2022-06-12 06:24:02.290914
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "https://ci.frigg.io/"
    os.environ["CHANGE_ID"] = "0"
    jenkins()

# Generated at 2022-06-12 06:24:37.155323
# Unit test for function frigg
def test_frigg():
    assert frigg('feature') == True



# Generated at 2022-06-12 06:24:41.466057
# Unit test for function checker
def test_checker():
    """
    Test that checker function raises the correct error when AssertionError occurs.
    """

    @checker
    def test_func():
        assert False

    try:
        test_func()
    except CiVerificationError:
        return
    assert False, "Did not raise CiVerificationError"

# Generated at 2022-06-12 06:24:46.060844
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"

    try:
        frigg("develop")
    except CiVerificationError:
        pass


# Generated at 2022-06-12 06:24:54.656801
# Unit test for function checker
def test_checker():
    class TestException(Exception):
        pass

    global counter
    counter = 0

    @checker
    def test_func(should_raise: bool):
        global counter
        counter += 1

        if should_raise:
            raise AssertionError()
        else:
            return True

    # Should raise if the function raises
    try:
        test_func(True)
        assert False
    except CiVerificationError:
        pass

    # Should return True if the function does not raise
    assert test_func(False) == True

    # The function should only have been called twice, even though
    # we called it three times
    assert counter == 2

# Generated at 2022-06-12 06:24:56.134507
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master") == True

# Generated at 2022-06-12 06:25:02.543609
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle("master") is True
    assert os.environ.get("CIRCLE_BRANCH") == "master"
    del os.environ["CIRCLECI"]



# Generated at 2022-06-12 06:25:09.526783
# Unit test for function travis
def test_travis():
    """
    Function to test function travis
    """
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    try:
        travis("develop")
    except CiVerificationError:
        assert True
    else:
        assert False
    try:
        os.environ["TRAVIS_PULL_REQUEST"] = "true"
        travis("master")
    except CiVerificationError:
        assert True
    else:
        assert False
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-12 06:25:14.148652
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")
    del os.environ["BITBUCKET_BRANCH"]

# Generated at 2022-06-12 06:25:25.377022
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["GITLAB_CI"] = "true"
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["GITLAB_CI"] = "true"
    check("master")
    os.environ["CI_COMMIT_REF_NAME"] = "release/"
    os.environ["GITLAB_CI"] = "true"
    check("release/")
    os.environ["CI_COMMIT_REF_NAME"] = "dev"
    os.environ["GITLAB_CI"] = "true"
    check("master")


# Generated at 2022-06-12 06:25:37.428508
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
        assert False
    except CiVerificationError:
        assert True
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    try:
        semaphore("master")
        assert True
    except CiVerificationError:
        assert False
    os.environ["BRANCH_NAME"] = "develop"
    try:
        semaphore("master")
        assert False
    except CiVerificationError:
        assert True
    del os

# Generated at 2022-06-12 06:26:47.979586
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "testBranch"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    semaphore("testBranch")
    assert os.environ["BRANCH_NAME"] == "testBranch"
    assert os.environ["SEMAPHORE_THREAD_RESULT"] == "passed"

    os.environ.pop("BRANCH_NAME", 0)
    os.environ.pop("SEMAPHORE_THREAD_RESULT", 0)

# Generated at 2022-06-12 06:26:57.348448
# Unit test for function semaphore
def test_semaphore():
    # Test when everything works
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "successful"
    semaphore("master")
    # Test when pull_request_number is present
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "successful"
    try:
        semaphore("master")
    except CiVerificationError:
        pass
   

# Generated at 2022-06-12 06:27:03.418590
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check("master")
    assert os.environ.get("CIRCLECI") == "true"



# Generated at 2022-06-12 06:27:06.402401
# Unit test for function checker
def test_checker():
    def func():
        raise AssertionError()

    assert checker(func)() == True
    try:
        checker(func)()
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:27:18.634384
# Unit test for function check
def test_check():
    """
    Validate check.
    """

    # Travis
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        check()
    except CiVerificationError:
        assert False
    os.environ["TRAVIS_BRANCH"] = "fake"
    try:
        check()
        assert False
    except CiVerificationError:
        pass
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
        assert False
    except CiVerificationError:
        pass

    # Semaphore
    os.environ["SEMAPHORE"] = "true"


# Generated at 2022-06-12 06:27:30.068569
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["SEMAPHORE"] = "true"
    os.environ["FRIGG"] = "true"
    os.environ["CIRCLECI"] = "true"
    os.environ["GITLAB_CI"] = "true"
    os.environ["JENKINS_URL"] = "true"
    os.environ["BITBUCKET_BUILD_NUMBER"] = "true"
    check()
    del os.environ["TRAVIS"]
    del os.environ["SEMAPHORE"]
    del os.environ["FRIGG"]
    del os.environ["CIRCLECI"]
    del os.environ["GITLAB_CI"]

# Generated at 2022-06-12 06:27:35.289819
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    assertTrue(True)



# Generated at 2022-06-12 06:27:46.745965
# Unit test for function semaphore
def test_semaphore():
    test_env1 = {
        "BRANCH_NAME": "develop",
        "PULL_REQUEST_NUMBER": "14",
        "SEMAPHORE_THREAD_RESULT": "failed",
    }
    test_env2 = {"BRANCH_NAME": "develop"}
    semaphore("develop")
    try:
        semaphore("master")
    except:
        raise CiVerificationError(
            "The verification check for the environment did not pass."
        )
    with os.environ.copy():
        os.environ.update(test_env1)
        try:
            semaphore("develop")
        except:
            raise CiVerificationError(
                "The verification check for the environment did not pass."
            )
    with os.environ.copy():
        os.environ

# Generated at 2022-06-12 06:27:48.447093
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")



# Generated at 2022-06-12 06:27:55.156294
# Unit test for function checker
def test_checker():
    @checker
    def func_with_error():
        assert False

    @checker
    def func_without_error():
        assert True

    try:
        func_with_error()
    except CiVerificationError:
        pass
    else:
        assert False, "func_with_error didn't raise an exception"

    try:
        func_without_error()
    except CiVerificationError:
        assert False, "func_without_error raised an exception"

# Generated at 2022-06-12 06:30:01.841300
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")

    del os.environ["TRAVIS_BRANCH"]
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master") == False

    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master") == False

    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    assert travis("master") == False

    del os.en

# Generated at 2022-06-12 06:30:07.858020
# Unit test for function jenkins
def test_jenkins():
    # Given
    os.environ["JENKINS_URL"] = "https://jenkins.example.com:8443/"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = ""

    # When
    jenkins("master")

    # Clean
    os.environ.pop("CHANGE_ID")
    os.environ.pop("JENKINS_URL")
    os.environ.pop("GIT_BRANCH")


# Generated at 2022-06-12 06:30:11.070313
# Unit test for function checker
def test_checker():
    """
    Unit test for function checker.
    """
    @checker
    def decor_test():
        assert True

    assert decor_test() is True

    @checker
    def decor_test2():
        assert False

    try:
        decor_test2()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-12 06:30:14.148709
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-12 06:30:18.790053
# Unit test for function checker
def test_checker():
    @checker
    def always_raise():
        raise AssertionError("i always raise")

    @checker
    def never_raise():
        pass

    assert always_raise() is False
    assert never_raise() is True


nose2 = "nose2"

# Generated at 2022-06-12 06:30:23.941446
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = "true"
    os.environ['CIRCLE_BRANCH'] = "master"
    os.environ['CI_PULL_REQUEST'] = ""
    check()
    #TODO: add code to actually test the function.
    del os.environ['CIRCLECI']
    del os.environ['CIRCLE_BRANCH']
    del os.environ['CI_PULL_REQUEST']


# Generated at 2022-06-12 06:30:25.542828
# Unit test for function check
def test_check():
    with pytest.raises(SystemExit):
        check()

# Generated at 2022-06-12 06:30:33.426314
# Unit test for function jenkins
def test_jenkins():
    os.environ['GIT_BRANCH'] = 'master'
    os.environ['JENKINS_URL'] = 'true'
    os.environ['CHANGE_ID'] = 'branch_name'

    try:
        jenkins(branch='master')
        assert True
    except CiVerificationError:
        assert False

    os.environ['CHANGE_ID'] = 'branch_name'

    try:
        jenkins(branch='master')
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-12 06:30:40.155243
# Unit test for function semaphore
def test_semaphore():
    semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
    except CiVerificationError:
        pass
    try:
        semaphore("not_master")
    except CiVerificationError:
        pass
    os.environ["PULL_REQUEST_NUMBER"] = "12345"
    try:
        semaphore("master")
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:30:49.057584
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'staging'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    check('staging')
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'true'
    with pytest.raises(CiVerificationError):
        check('staging')