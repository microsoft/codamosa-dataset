

# Generated at 2022-06-12 06:21:07.197265
# Unit test for function gitlab
def test_gitlab():
    assert gitlab("master") == True


# Generated at 2022-06-12 06:21:11.109824
# Unit test for function gitlab
def test_gitlab():
    assert (
        os.environ.get("GITLAB_CI") == "true"
        and os.environ.get("CI_COMMIT_REF_NAME") == "master"
        and not os.environ.get("CI_MERGE_REQUEST_IID")
    )
    assert check(branch="master")

# Generated at 2022-06-12 06:21:21.480250
# Unit test for function travis
def test_travis():
    os.environ.update({
        "TRAVIS": "true",
        "TRAVIS_BRANCH": "master",
        "TRAVIS_PULL_REQUEST": "false"})
    travis("master")

    os.environ.update({"TRAVIS_BRANCH": "staging"})
    try:
        travis("master")
        assert False
    except CiVerificationError:
        assert True
    except Exception as e:
        assert False, "Unexpected exception thrown: " + str(e)

    os.environ.update({"TRAVIS_PULL_REQUEST": "123"})
    try:
        travis("master")
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-12 06:21:24.375990
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert check() is None


# Generated at 2022-06-12 06:21:25.233953
# Unit test for function travis
def test_travis():
    assert check() == True


# Generated at 2022-06-12 06:21:34.829984
# Unit test for function travis
def test_travis():
    try:
        # Testing for master branch and no pull request
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        travis("master")
    except:
        assert False
    try:
        # Testing for develop branch and a pull request
        os.environ["TRAVIS_BRANCH"] = "develop"
        os.environ["TRAVIS_PULL_REQUEST"] = "true"
        travis("master")
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-12 06:21:38.230711
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    check('master')


# Generated at 2022-06-12 06:21:40.388665
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert check("master")



# Generated at 2022-06-12 06:21:48.655677
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master") is True
    del os.environ["CI_PULL_REQUEST"]
    assert circle("master") is True
    os.environ["CI_PULL_REQUEST"] = "1"
    assert circle("master") is False
    os.environ["CIRCLE_BRANCH"] = "develop"
    assert circle("master") is False

# Generated at 2022-06-12 06:21:54.439496
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for function 'bitbucket'
    """
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert bitbucket("master")

    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:22:06.607715
# Unit test for function semaphore
def test_semaphore():
    """
    Test semaphore function
    """
    assert os.environ['SEMAPHORE'] == 'true'
    assert os.environ['SEMAPHORE_THREAD_RESULT'] != 'failed'
    assert os.environ['BRANCH_NAME'] == 'master'

# Generated at 2022-06-12 06:22:08.697778
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check()

# Generated at 2022-06-12 06:22:12.801484
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    circle(branch = "master")



# Generated at 2022-06-12 06:22:15.633536
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    check("master")

# Generated at 2022-06-12 06:22:21.730815
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = ""

    gitlab("master")
    os.environ["CI_MERGE_REQUEST_IID"] = "1"
    try:
        gitlab("master")
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:22:27.796681
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "jenkins"
    jenkins("master")
    os.environ["CHANGE_ID"] = "42"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        raise Exception("VerificationError expected")

# Generated at 2022-06-12 06:22:38.726493
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_TARGET_BRANCH_NAME"] = ""
    check()
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_TARGET_BRANCH_NAME"]
    with pytest.raises(CiVerificationError):
        check()
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_TARGET_BRANCH_NAME"] = "master"
    with pytest.raises(CiVerificationError):
        check()
    del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-12 06:22:43.420664
# Unit test for function checker
def test_checker():
    flag = False

    @checker
    def check_error_and_raise():
        nonlocal flag
        flag = True
        raise AssertionError("CI Check failed.")

    try:
        check_error_and_raise()
    except Exception:
        assert True, "Catch Exception"
    assert flag, "the function should be executed"

# Generated at 2022-06-12 06:22:50.237657
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()  # should not raise an Exception
    # clean up environment for next test
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]



# Generated at 2022-06-12 06:22:55.233757
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "my_branch"
    os.environ["BITBUCKET_PULLREQUEST_ID"] = 1234
    bitbucket("my_branch")
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PULLREQUEST_ID"]
    bitbucket("my_branch")


# Generated at 2022-06-12 06:23:13.913523
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    assert frigg("master") is True

    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "dev"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    try:
        frigg("master")
    except CiVerificationError:
        assert True
    except:
        assert False

    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"

# Generated at 2022-06-12 06:23:25.812383
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com/job/test"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = None
    try:
        jenkins("master")
    except CiVerificationError as err:
        print(err)
    else:
        assert False  
    os.environ["CHANGE_ID"] = "1234"
    try:
        jenkins("master")
    except CiVerificationError as err:
        print(err)
    else:
        assert True
    del os.environ["CHANGE_ID"]
    del os.environ["BRANCH_NAME"]
    del os.environ["JENKINS_URL"]
    assert True


# Generated at 2022-06-12 06:23:29.500224
# Unit test for function check
def test_check():
    os.environ['SEMAPHORE'] = 'true'
    assert check('master')

    os.environ['SEMAPHORE'] = 'false'
    os.environ['CIRCLECI'] = 'true'
    assert check('function-test')



# Generated at 2022-06-12 06:23:32.827611
# Unit test for function frigg
def test_frigg():
    branch = "master"
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = branch
    os.environ["FRIGG_TRIGGERED_WORKFLOW"] = "semantic-release"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    frigg(branch)



# Generated at 2022-06-12 06:23:36.885415
# Unit test for function gitlab
def test_gitlab():
    branch = "master"
    os.environ["CI_COMMIT_REF_NAME"] = branch
    os.environ["CI_MERGE_REQUEST_IID"] = None
    gitlab(branch)

# Generated at 2022-06-12 06:23:43.082642
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    assert jenkins("master") == True

    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "1"
    assert jenkins("master") == False


# Generated at 2022-06-12 06:23:47.372330
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'

    try:
        travis('master')
        assert True
    except AssertionError:
        pass
    else:
        assert False


# Generated at 2022-06-12 06:23:51.465331
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLEBRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = 'true'
    try:
        circle('master')
    except CiVerificationError:
        pass

# Generated at 2022-06-12 06:23:53.585264
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['CI_PULL_REQUEST'] = '1'
    check()
    del os.environ['CI_PULL_REQUEST']
    check()

# Generated at 2022-06-12 06:23:56.001280
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert check() is None
    del os.environ["CI_COMMIT_REF_NAME"]
    assert check() is None

# Generated at 2022-06-12 06:24:12.322745
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://john-doe:password@ci.example.com/"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = None
    jenkins("master")
    os.environ["BRANCH_NAME"] = "semver:patch"
    jenkins("semver:patch")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "1"
    try:
        jenkins("master")
        assert False
    except CiVerificationError:
        assert True
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = None

# Generated at 2022-06-12 06:24:19.937714
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://some-url"
    try:
        jenkins("master")
        os.environ["GIT_BRANCH"] = "master"
        jenkins("master")
        os.environ["BRANCH_NAME"] = "master"
        jenkins("master")
        os.environ["CHANGE_ID"] = "123"
        jenkins("master")
    except:
        assert("Jenkins not in correct branch")

# Generated at 2022-06-12 06:24:23.856736
# Unit test for function checker
def test_checker():
    def test_func():
        raise AssertionError

    try:
        checker(test_func)()
    except CiVerificationError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-12 06:24:26.644006
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()
    del os.environ["CI_COMMIT_REF_NAME"]


# Generated at 2022-06-12 06:24:33.143239
# Unit test for function gitlab
def test_gitlab():
    env_vars = {'BRANCH_NAME': 'master',
                'CI_COMMIT_REF_NAME': 'master',
                'CI_PULL_REQUEST': ''}

    try:
        gitlab('master')
    except CiVerificationError:
        assert True
    else:
        assert False

    try:
        os.environ.update(env_vars)
        gitlab('master')
    except CiVerificationError:
        assert False



# Generated at 2022-06-12 06:24:37.497969
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-12 06:24:38.131404
# Unit test for function travis
def test_travis():
	travis("master")

# Generated at 2022-06-12 06:24:41.237113
# Unit test for function gitlab
def test_gitlab():
    branch = "master"
    os.environ["CI_COMMIT_REF_NAME"] = branch
    os.environ["CI_MERGE_REQUEST"] = "false"
    gitlab(branch)

# Generated at 2022-06-12 06:24:46.715784
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = ''
    check('master')
    os.environ['FRIGG_PULL_REQUEST'] = 'true'
    check('master')
    os.environ['FRIGG_BUILD_BRANCH'] = 'development'
    check('master')
    os.environ['FRIGG'] = ''


# Generated at 2022-06-12 06:24:48.486395
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    assert os.environ['CI_COMMIT_REF_NAME'] == gitlab('master')

# Generated at 2022-06-12 06:25:06.656740
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'

    check()
    travis('master')

    os.environ['SEMAPHORE'] = 'true'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'

    check()
    semaphore('master')

    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'

# Generated at 2022-06-12 06:25:17.939800
# Unit test for function checker
def test_checker():
    @checker
    def foo():
        assert False

    try:
        foo()
    except CiVerificationError:
        assert True
    else:
        assert False

    @checker
    def foo():
        assert True

    assert foo()

    @checker
    def foo():
        raise AssertionError()

    try:
        foo()
    except CiVerificationError:
        assert True
    else:
        assert False

    @checker
    def foo():
        if True:
            raise AssertionError()
        else:
            assert True

    try:
        foo()
    except CiVerificationError:
        assert True
    else:
        assert False


test_checker()

# Generated at 2022-06-12 06:25:21.941360
# Unit test for function travis
def test_travis():
    branch = "master"
    os.environ['TRAVIS_BRANCH'] = branch
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis(branch)

# Generated at 2022-06-12 06:25:24.300501
# Unit test for function checker
def test_checker():
    def func_assertion_error(*args, **kwargs):
        assert False

    assert checker(func_assertion_error)() == False

# Generated at 2022-06-12 06:25:28.121216
# Unit test for function bitbucket
def test_bitbucket():
    class os:
        environ = {"BITBUCKET_BUILD_NUMBER": True}

    assert bitbucket.__wrapped__(branch = 'master') == None



# Generated at 2022-06-12 06:25:33.788274
# Unit test for function checker
def test_checker():
    @checker
    def _test_func():
        raise AssertionError

    with pytest.raises(CiVerificationError):
        _test_func()

    @checker
    def _test_func_pass():
        pass

    assert _test_func_pass() is True

# Generated at 2022-06-12 06:25:40.295511
# Unit test for function frigg
def test_frigg():
    """ Unit test for function frigg
    """
    os.environ.update({"FRIGG": "true", "FRIGG_BUILD_BRANCH": "master"})
    assert frigg("master")

    os.environ.update({"FRIGG": "true", "FRIGG_BUILD_BRANCH": "master", "FRIGG_PULL_REQUEST": "1"})
    
    try:
       frigg("master")
       assert False
    except CiVerificationError as e:
       assert "environment did not pass" in e.message 

    os.environ.pop("FRIGG_PULL_REQUEST")
    try:
       frigg("master", "master") 
       assert False
    except CiVerificationError as e:
       assert "environment did not pass" in e

# Generated at 2022-06-12 06:25:43.790613
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")



# Generated at 2022-06-12 06:25:54.598951
# Unit test for function bitbucket
def test_bitbucket():
    def check_bitbucket(server_env, expected_result):
        actual_result = ""
        try:
            os.environ.update(server_env)
            check("master")
        except CiVerificationError as e:
            actual_result = str(e)

        assert actual_result == expected_result

    server_env_1 = {
        "BITBUCKET_BUILD_NUMBER": "123",
        "BITBUCKET_BRANCH": "master",
        "BITBUCKET_PR_ID": "12",
    }

    expected_result = "The verification check for the environment did not pass."
    check_bitbucket(server_env_1, expected_result)


# Generated at 2022-06-12 06:26:01.298066
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "develop"
    with pytest.raises(ci_verification_error.CiVerificationError):
        travis("master")


# Generated at 2022-06-12 06:26:20.251166
# Unit test for function gitlab
def test_gitlab():
    """
    Test whether the right variables are set for gitlab
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert check()
    os.environ["GITLAB_CI"] = "true"
    assert check()



# Generated at 2022-06-12 06:26:20.923239
# Unit test for function check
def test_check():
    assert check() == None

# Generated at 2022-06-12 06:26:25.981867
# Unit test for function frigg
def test_frigg():
    os.environ.update({"FRIGG": "True", "FRIGG_BUILD_BRANCH": "master"})

    try:
        frigg("master")
    except AssertionError:
        pytest.fail("Frigg check should not raise an error")



# Generated at 2022-06-12 06:26:34.468349
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = None
    try:
        check("master")
        success = True
    except CiVerificationError:
        success = False
    finally:
        del os.environ["FRIGG"]
        del os.environ["FRIGG_BUILD_BRANCH"]
        del os.environ["FRIGG_PULL_REQUEST"]
    assert success



# Generated at 2022-06-12 06:26:44.624164
# Unit test for function gitlab
def test_gitlab():
    """
    Test that the checker decorator converts an AssertionError to
    a CiVerificationError
    """
    try:
        gitlab("testbranch")
        assert False, "Test should fail"
    except CiVerificationError:
        assert True, "Test should pass"

    with open("~/.gitlab-ci", "w") as f:
        f.write("test")
    try:
        gitlab("testbranch")
        assert True, "Test should pass"
    except CiVerificationError:
        assert False, "Test should not fail"

# Generated at 2022-06-12 06:26:45.811920
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master")



# Generated at 2022-06-12 06:26:55.405876
# Unit test for function frigg
def test_frigg():
    import os
    import pytest
    try:
        del os.environ['FRIGG']
        pytest.raises(CiVerificationError, frigg, 'master')
    except KeyError:
        pass
    # Simulate a FRIGG env
    import os
    import pytest
    try:
        os.environ['FRIGG'] = '0'
        frigg('master')
    except KeyError:
        pass
    try:
        del os.environ['FRIGG_BUILD_BRANCH']
        pytest.raises(CiVerificationError, frigg, 'master')
    except KeyError:
        pass

# Generated at 2022-06-12 06:26:57.533435
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    check()

# Generated at 2022-06-12 06:27:08.991826
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") == True
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master") == False
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    del os.environ["BRANCH_NAME"]
    os.environ["BRANCH_NAME"] = "develop"
    assert semaphore

# Generated at 2022-06-12 06:27:13.137104
# Unit test for function checker
def test_checker():
    # checker should return false if assertionErr is raised
    @checker
    def test():
        assert False

    assert(not test())

    # checker should return true if no assertionErr is raised
    @checker
    def test():
        assert True

    assert(test())

# Generated at 2022-06-12 06:27:41.291858
# Unit test for function checker
def test_checker():
    @checker
    def dummy(*args, **kwargs):
        assert False

    try:
        dummy()
    except AssertionError:
        assert True
    except CiVerificationError:
        assert False
    else:
        assert False

# Generated at 2022-06-12 06:27:48.051780
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] ='1'
    os.environ["BITBUCKET_BRANCH"] ='master'
    os.environ["BITBUCKET_PR_ID"] =''
    assert bitbucket("master")
    del os.environ['BITBUCKET_BRANCH']
    assert not bitbucket("master")
    del os.environ['BITBUCKET_BUILD_NUMBER']
    assert not bitbucket("master")


# Generated at 2022-06-12 06:27:51.925823
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "master"
    check()
    os.environ["GIT_BRANCH"] = "release"
    check(branch="release")

# Generated at 2022-06-12 06:28:01.420057
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    # frigg function returns true when the above environmental variable 
    # are set to the correct values.
    assert frigg("master") == True
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-12 06:28:04.012424
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "123"
    os.environ['CHANGE_ID'] = "23"
    os.environ['GIT_BRANCH'] = "master"
    assert(check())

# Generated at 2022-06-12 06:28:15.828079
# Unit test for function gitlab
def test_gitlab():
    assert os.environ.get("GITLAB_CI") is None  # environment is not set
    branch = "master"
    assert not gitlab(branch)
    os.environ["GITLAB_CI"] = "true"
    # environment is set but not on master branch
    os.environ["CI_COMMIT_REF_NAME"] = "other_branch"
    assert branch == "master"
    assert not gitlab(branch)
    # environment is set but not on master branch
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    # environment is set but a merge request
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    assert not gitlab(branch)
    # environment is set with the correct branch and not a merge request
    os

# Generated at 2022-06-12 06:28:23.035431
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://example.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    assert not os.environ.get("CHANGE_ID")  # pull request id

    check(branch="master")
    os.environ["BRANCH_NAME"] = "branch"
    with pytest.raises(CiVerificationError):
        check(branch="master")

# Generated at 2022-06-12 06:28:25.237474
# Unit test for function travis
def test_travis():
    assert os.environ.get("TRAVIS_BRANCH") == "master"
    assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"

# Generated at 2022-06-12 06:28:29.356083
# Unit test for function checker
def test_checker():
    try:
        @checker
        def testfunc():
            raise AssertionError
    except CiVerificationError:
        assert True
    else:
        assert False  # should raise an error

# Unit tests for function check

# Generated at 2022-06-12 06:28:32.370512
# Unit test for function gitlab
def test_gitlab():
    assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
    assert not os.environ.get("CI_MERGE_REQUEST_ID")


# Generated at 2022-06-12 06:29:40.553645
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "not_none"
    semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    semaphore("master")
    os.environ["BRANCH_NAME"] = "not_master"

# Generated at 2022-06-12 06:29:45.247639
# Unit test for function check
def test_check():
    ci_env = {
        "TRAVIS_BRANCH": "master",
        "TRAVIS_PULL_REQUEST": "false",
        "SEMAPHORE_THREAD_RESULT": "passed",
        "BRANCH_NAME": "master",
    }
    for key, value in ci_env.items():
        os.environ[key] = value
    check()

test_check()

# Generated at 2022-06-12 06:29:55.308325
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    check()
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        check()
    except CiVerificationError:
        assert True
    else:
        assert False
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os

# Generated at 2022-06-12 06:30:01.664438
# Unit test for function gitlab
def test_gitlab():
    test_variables = {
        "GITLAB_CI": "true",
        "CI_COMMIT_REF_NAME": "master",
        "CI_MERGE_REQUEST_ID": "",
    }

    for k, v in test_variables.items():
        os.environ[k] = v
    try:
        check()
    except AssertionError:
        raise AssertionError("test_gitlab failed.")
    else:
        print("test_gitlab passed.")

# Generated at 2022-06-12 06:30:06.885853
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "0"
    try:
        frigg("master")
        raise AssertionError("This case failed")
    except CiVerificationError as e:
        assert "The verification check" in str(e)

# Generated at 2022-06-12 06:30:12.561424
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for bitbucket function
    """
    os.environ["BITBUCKET_BUILD_NUMBER"] = "12345"
    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = "123456"
    bitbucket("develop")

# Generated at 2022-06-12 06:30:22.704745
# Unit test for function frigg
def test_frigg():
    # Setup
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "feature/new_feature"
    os.environ["FRIGG_PULL_REQUEST"] = "true"

    # Has not passed verification
    assert frigg("master") is True

    # Has passed verification
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""

    assert frigg("master") is not True
    os.environ.pop('FRIGG')
    os.environ.pop('FRIGG_BUILD_BRANCH')
    os.environ.pop('FRIGG_PULL_REQUEST')



# Generated at 2022-06-12 06:30:28.706060
# Unit test for function semaphore
def test_semaphore():
    # Semaphore is non-trivial to test in a real environment, because
    # we are trying to test if these checks actually run. Something
    # beyond tests are neccessary. The tests in this file are more
    # to exercise the flow of the code and ensure it is valid.
    assert os.environ.get("SEMAPHORE") == "true"
    assert semaphore("master") is True

# Generated at 2022-06-12 06:30:36.791395
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]



# Generated at 2022-06-12 06:30:41.753958
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CIRCLE_REPOSITORY_URL"] = "https://github.com/relekang/test-repo"
    circle()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CIRCLE_REPOSITORY_URL"]