

# Generated at 2022-06-24 01:29:20.983690
# Unit test for function gitlab
def test_gitlab():
    """
    Test if gitlab function works properly.
    """
    env_repo = dict()
    env_repo["GITLAB_CI"] = "true"
    env_repo["CI_COMMIT_REF_NAME"] = "new_branch"
    env_repo["CI_MERGE_REQUEST_IID"] = "42"

    os.environ = env_repo
    try:
        gitlab("some_branch")
        assert False
    except CiVerificationError as verification_error:
        assert "CI_COMMIT_REF_NAME" in str(verification_error)
        assert "CI_MERGE_REQUEST_IID" in str(verification_error)

# Generated at 2022-06-24 01:29:24.412110
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    travis("master")


# Generated at 2022-06-24 01:29:33.091894
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "http://www.github.com/patrickceg/semantic-release.git"
    os.environ["CIRCLE_BRANCH"] = "bugfix/test"

    try:
        circle("bugfix/test")
    except CiVerificationError:
        pass
    else:
        raise Exception("Didn't raise an error when it should")

    del os.environ["CI_PULL_REQUEST"]
    try:
        circle("bugfix/test")
    except CiVerificationError:
        raise Exception("Raised an error when it shouldn't have")



# Generated at 2022-06-24 01:29:33.865061
# Unit test for function check
def test_check():
    assert check(branch='master') is None

# Generated at 2022-06-24 01:29:36.730149
# Unit test for function frigg
def test_frigg():
    """
    Example test for the frigg environment, could be run with:
    python -m pytest test_ci.py -v
    """
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    try:
        frigg("master")
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:29:43.169100
# Unit test for function gitlab
def test_gitlab():
    ci = "gitlab"
    my_env = os.environ
    try:
        my_env["CI_COMMIT_REF_NAME"] = "master"
        my_env["CI_BUILD_REF_NAME"] = "travis-ci"
        # os.environ["CI_BUILD_REF_NAME"] = "travis-ci"
        if ci == "gitlab":
            assert gitlab() == True
            assert gitlab("travis-ci") == False
    except Exception as e:
        print(e)
    finally:
        my_env.clear()


# Generated at 2022-06-24 01:29:55.683576
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    branch = "master"
    
    try:
        travis(branch)
        assert False
    except CiVerificationError:
        assert True
    else:
        assert False
        
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    try:
        travis(branch)
        assert True
    except CiVerificationError:
        assert False
    else:
        assert True
        
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-24 01:29:57.322999
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    gitlab('master')

# Generated at 2022-06-24 01:30:00.520787
# Unit test for function check
def test_check():
    assert os.environ.get("TRAVIS_BRANCH") in ["master","test_branch"]
    assert os.environ.get("TRAVIS_PULL_REQUEST") in ["", "false"]
    assert check()

# Generated at 2022-06-24 01:30:09.311223
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = ""
    os.environ["CIRCLE_BRANCH"] = "master"
    check()
    os.environ.pop("CIRCLECI", None)
    os.environ.pop("CI_PULL_REQUEST", None)
    os.environ.pop("CIRCLE_BRANCH", None)
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "foo"
    os.environ["CIRCLE_BRANCH"] = "master"
    check()
    os.environ.pop("CIRCLECI", None)

# Generated at 2022-06-24 01:30:11.604161
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    check('master')


# Generated at 2022-06-24 01:30:15.963878
# Unit test for function semaphore
def test_semaphore():
    """
    Test for function semaphore
    """
    os.environ['BRANCH_NAME'] = 'master'
    os.environ.pop('PULL_REQUEST_NUMBER', None)
    os.environ.pop('SEMAPHORE_THREAD_RESULT', None)
    semaphore(os.environ['BRANCH_NAME'])



# Generated at 2022-06-24 01:30:23.773147
# Unit test for function circle
def test_circle():
    try:
        circle("master")
    except CiVerificationError:
        assert False
    os.environ["CIRCLE_BRANCH"] = "unittest"
    assert circle("unittest")
    del os.environ["CIRCLE_BRANCH"]
    assert circle("master")
    os.environ["CI_PULL_REQUEST"] = "1"
    try:
        circle("master")
        assert False
    except CiVerificationError:
        pass
    del os.environ["CI_PULL_REQUEST"]



# Generated at 2022-06-24 01:30:28.307409
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis


# Generated at 2022-06-24 01:30:37.493561
# Unit test for function frigg
def test_frigg():
    # Successful test
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "None"
    assert frigg("master") == True
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]

    # Unsuccessful test
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "None"
    assert frigg("stable") == False
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]

    # Unsuccessful test
   

# Generated at 2022-06-24 01:30:40.856864
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "42"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123"

    check()

# Generated at 2022-06-24 01:30:42.477348
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    circle("master")


# Generated at 2022-06-24 01:30:43.981735
# Unit test for function check
def test_check():
    """
    Unit tests for function check.
    """
    check()

# Generated at 2022-06-24 01:30:49.882347
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    print(circle(branch="master"))
    os.environ["CI_PULL_REQUEST"] = "true"
    print(circle(branch="master"))



# Generated at 2022-06-24 01:30:50.901243
# Unit test for function semaphore
def test_semaphore():
    return semaphore("master")

# Generated at 2022-06-24 01:30:58.336341
# Unit test for function bitbucket
def test_bitbucket():
    fake_build_number = "1234"
    fake_pull_request_id = "5678"
    fake_branch_name = "master"
    fake_pull_request_env = {
        "BITBUCKET_BUILD_NUMBER": fake_build_number,
        "BITBUCKET_PR_ID": fake_pull_request_id,
        "BITBUCKET_BRANCH": fake_branch_name
    }
    fake_regular_env = {
        "BITBUCKET_BUILD_NUMBER": fake_build_number,
        "BITBUCKET_PR_ID": None,
        "BITBUCKET_BRANCH": fake_branch_name
    }

    os.environ = fake_pull_request_env

# Generated at 2022-06-24 01:31:02.769260
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-24 01:31:13.496503
# Unit test for function bitbucket
def test_bitbucket():
    # Setup test environment
    os.environ["BITBUCKET_BUILD_NUMBER"] = "true"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "333"
    os.environ["BITBUCKET_TAG"] = "2.0.0"
    os.environ["BITBUCKET_REPO_SLUG"] = "MyRepoName"
    os.environ["BITBUCKET_COMMIT"] = "da39a3ee5e6b4b0d3255bfef95601890afd80709"

    bitbucket(branch="master")



# Generated at 2022-06-24 01:31:15.983578
# Unit test for function travis
def test_travis():
    assert travis(branch="master")


# Generated at 2022-06-24 01:31:21.314645
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    semaphore('master')
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'
    semaphore('master')


# Generated at 2022-06-24 01:31:25.233960
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "test_branch"
    os.environ["CIRCLE_BUILD_NUM"] = "1"

    if os.environ.get("CI_PULL_REQUEST"):
        raise AssertionError

    check()



# Generated at 2022-06-24 01:31:30.159758
# Unit test for function checker
def test_checker():
    @checker
    def _raise_exception():
        assert False

    try:
        _raise_exception()
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-24 01:31:34.902864
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '12345'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = ''
    bitbucket('master')

# Generated at 2022-06-24 01:31:43.475626
# Unit test for function travis
def test_travis():
    env = os.environ
    env["TRAVIS_BRANCH"] = "master"
    env["TRAVIS_PULL_REQUEST"] = "false"
    check()

    env["TRAVIS_BRANCH"] = "develop"
    env["TRAVIS_PULL_REQUEST"] = "false"
    check("develop")

    env["TRAVIS_BRANCH"] = "feature/test"
    env["TRAVIS_PULL_REQUEST"] = "false"
    check("feature/test")


# Generated at 2022-06-24 01:31:47.117149
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "0"
    check()


# Unit test to check that frigg with a PR fails

# Generated at 2022-06-24 01:31:55.044320
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "www.google.com"
    os.environ["GIT_BRANCH"] = "master"
    assert jenkins("master")
    os.environ["GIT_BRANCH"] = "develop"
    assert not jenkins("master")
    assert jenkins("develop")
    os.environ["CHANGE_ID"] = "098"
    assert not jenkins("master")
    assert not jenkins("develop")
    del os.environ["CHANGE_ID"]
    assert jenkins("master")
    del os.environ["JENKINS_URL"]
    assert not jenkins("master")



# Generated at 2022-06-24 01:31:58.418757
# Unit test for function semaphore
def test_semaphore():
    # Arrange
    branch = "develop"
    # Act
    semaphore(branch)

# Generated at 2022-06-24 01:32:04.013319
# Unit test for function gitlab
def test_gitlab():
    """
    Unit test for function gitlab

    :return: None
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"

    check(branch="master")
    assert True

    os.environ["CI_COMMIT_REF_NAME"] = "test"

    try:
        check(branch="master")
        assert False
    except CiVerificationError:
        assert True



# Generated at 2022-06-24 01:32:13.198672
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert travis('master')
    os.environ['TRAVIS_BRANCH'] = 'develop'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert not travis('master')
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    assert not travis('master')
    os.environ['TRAVIS_BRANCH'] = 'develop'
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    assert not travis('master')

# Unit test

# Generated at 2022-06-24 01:32:17.879752
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")

# Generated at 2022-06-24 01:32:29.316869
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()
    os.environ["CIRCLE_BRANCH"] = "staging"
    check("staging")
    del os.environ["CIRCLE_BRANCH"]
    os.environ["CI_PULL_REQUEST"] = "true"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        assert False
    os.environ["CIRCLE_BRANCH"] = "master"
    check()
    del os.environ["CI_PULL_REQUEST"]
    os.environ["CIRCLE_BRANCH"] = "staging"
    check("staging")

#

# Generated at 2022-06-24 01:32:31.768886
# Unit test for function circle
def test_circle():
    circle("master")
    # Test with wrong branch
    try:
        circle("wrong")
    except CiVerificationError:
        assert True


# Generated at 2022-06-24 01:32:37.665557
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")
    del os.environ["BITBUCKET_BRANCH"]
    with open("bitbucket_out.txt") as f:
        assert f.read() == "Branch: None\nPR: None\n"

# Generated at 2022-06-24 01:32:47.420605
# Unit test for function check
def test_check():
    """Unit test for function check"""
    from unittest.mock import patch

# Generated at 2022-06-24 01:32:53.618064
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "42"
    os.environ["BITBUCKET_BRANCH"] = "1.0.0"
    assert bitbucket() == None
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert bitbucket() == None
    del os.environ["BITBUCKET_BUILD_NUMBER"]
    assert bitbucket() == None


# Generated at 2022-06-24 01:33:04.723980
# Unit test for function check
def test_check():
    try:
        checker(travis)()
    except Exception as e:
        assert isinstance(e, CiVerificationError)
    try:
        checker(semaphore)()
    except Exception as e:
        assert isinstance(e, CiVerificationError)
    try:
        checker(frigg)()
    except Exception as e:
        assert isinstance(e, CiVerificationError)
    try:
        checker(circle)()
    except Exception as e:
        assert isinstance(e, CiVerificationError)
    try:
        checker(gitlab)()
    except Exception as e:
        assert isinstance(e, CiVerificationError)
    try:
        checker(jenkins)()
    except Exception as e:
        assert isinstance(e, CiVerificationError)


# Generated at 2022-06-24 01:33:12.226318
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "0.0.1"
    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = "1"
    bitbucket("develop")
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket("develop")
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")

# Generated at 2022-06-24 01:33:22.162344
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "https://some.jenkins.server"
    jenkins("master")
    os.environ["JENKINS_URL"] = None
    jenkins("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "develop"
    try:
        jenkins("master")
        assert False
    except AssertionError:
        pass
    os.environ["CHANGE_ID"] = ""

# Generated at 2022-06-24 01:33:32.418679
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    try:
        travis('master')
        assert True, "Test Passed"
    except AssertionError:
        assert False, "Test Failed"
    except CiVerificationError:
        assert False, "Test Failed"
    
    os.environ['TRAVIS_BRANCH'] = None
    try:
        travis('master')
        assert False, "Test Failed"
    except AssertionError:
        assert False, "Test Failed"
    except CiVerificationError:
        assert True, "Test Passed"
    
    os.environ['TRAVIS_BRANCH'] = 'master'

# Generated at 2022-06-24 01:33:37.659092
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "url"
    os.environ["CHANGE_ID"] = ""
    check()

# Generated at 2022-06-24 01:33:40.345178
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for function bitbucket
    """
    os.environ["BITBUCKET_BRANCH"] = "master"
    try:
        bitbucket("master")
    except CiVerificationError:
        assert False
    os.environ["BITBUCKET_BRANCH"] = "development"
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        pass


# Generated at 2022-06-24 01:33:43.381370
# Unit test for function checker
def test_checker():
    def func(param1, param2):
        raise AssertionError()

    wrapped_func = checker(func)
    assert wrapped_func('a', 'b') is False


# Generated at 2022-06-24 01:33:53.391435
# Unit test for function bitbucket
def test_bitbucket():
    # set env variables
    os.environ["BITBUCKET_BRANCH"] = "test_branch_name"
    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        bitbucket("test_branch_name")
    except CiVerificationError as error:
        assert error.message == "The verification check for the environment did not pass."
        os.environ.pop("BITBUCKET_BRANCH")
        os.environ.pop("BITBUCKET_PR_ID")

    os.environ["BITBUCKET_BRANCH"] = "test_branch_name"
    os.environ["BITBUCKET_PR_ID"] = None

# Generated at 2022-06-24 01:33:58.732598
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    check()

# Generated at 2022-06-24 01:34:05.875504
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for function bitbucket
    """

    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    bitbucket("master")

    os.environ["BITBUCKET_BRANCH"] = "branch"
    os.environ["BITBUCKET_PR_ID"] = None
    bitbucket("branch")

    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        print("Code works")
    else:
        print("Code doesn't work")


# Generated at 2022-06-24 01:34:08.307738
# Unit test for function circle
def test_circle():
    try:
        circle("master")
    except CiVerificationError:
        assert True
    else:
        assert False



# Generated at 2022-06-24 01:34:16.033096
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = None
    gitlab('master')
    del os.environ['CI_COMMIT_REF_NAME']
    del os.environ['CI_MERGE_REQUEST_ID']
    os.environ['CI_COMMIT_REF_NAME'] = 'develop'
    os.environ['CI_MERGE_REQUEST_ID'] = 5
    try:
        gitlab('master')
        assert False
    except CiVerificationError:
        assert True
    del os.environ['CI_COMMIT_REF_NAME']
    del os.environ['CI_MERGE_REQUEST_ID']

# Generated at 2022-06-24 01:34:20.222738
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()

# Generated at 2022-06-24 01:34:30.346611
# Unit test for function jenkins
def test_jenkins():
    
    os.environ["JENKINS_URL"] = "True"
    os.environ["BRANCH_NAME"] = "master"
    try:
        jenkins("master")
    except CiVerificationError:
        raise AssertionError
    os.environ["BRANCH_NAME"] = "test"
    try:
        jenkins("test")
    except CiVerificationError:
        raise AssertionError
    os.environ["GIT_BRANCH"] = "master"
    try:
        jenkins("master")
    except CiVerificationError:
        raise AssertionError
    os.environ["GIT_BRANCH"] = "test"
    try:
        jenkins("test")
    except CiVerificationError:
        raise AssertionError
   

# Generated at 2022-06-24 01:34:35.521314
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    assert frigg("master") == True
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    assert frigg("master") == False

# Generated at 2022-06-24 01:34:39.119094
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        assert 1 == 2

    try:
        test_func()
    except CiVerificationError:
        pass
    except Exception:
        raise Exception("CiVerificationError not raised on failed assertion.")

# Generated at 2022-06-24 01:34:42.052501
# Unit test for function bitbucket
def test_bitbucket():
    os.environ.update({
        "BITBUCKET_BUILD_NUMBER": "test"
    })
    assert bitbucket("test") == True



# Generated at 2022-06-24 01:34:48.884415
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "https://jenkins.jenkins.io"
    os.environ['GIT_BRANCH'] = "master"
    assert jenkins("master")
    assert not jenkins("development")
    os.environ['JENKINS_URL'] = None
    os.environ['GIT_BRANCH'] = None

# Generated at 2022-06-24 01:35:00.211253
# Unit test for function gitlab
def test_gitlab():
    # Make sure that gitlab without the variables raises a verification error
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert gitlab("master")

    # Assert that the branch is the wrong branch
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    try:
        gitlab("master")
    except CiVerificationError:
        assert True
    else:
        assert False
    os.environ["CI_COMMIT_REF_NAME"] = "master"

    # Assert that environment variable for merge-request is set
    os.environ["CI_MERGE_REQUEST_IID"] = "1"

# Generated at 2022-06-24 01:35:07.073862
# Unit test for function bitbucket
def test_bitbucket():
    import os
    os.environ["BITBUCKET_BRANCH"] = "Branch2"
    os.environ["BITBUCKET_PR_ID"] = "false"
    bitbucket("Branch2")
    os.environ["BITBUCKET_BRANCH"] = "Branch1"
    os.environ["BITBUCKET_PR_ID"] = "true"
    try:
        bitbucket("Branch2")
    except CiVerificationError:
        return 0
    raise Exception("Bitbucket branch verification test failed")


# Generated at 2022-06-24 01:35:11.516855
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()



# Generated at 2022-06-24 01:35:13.590247
# Unit test for function check
def test_check():
    with pytest.raises(CiVerificationError):
        check(branch="master")


if __name__ == "__main__":
    check(branch="master")

# Generated at 2022-06-24 01:35:18.443097
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"

    try:
        travis("master")
    except Exception as e:
        assert isinstance(e, CiVerificationError)
        assert "environment did not pass." in e.message

    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "true"

    try:
        travis("master")
    except Exception as e:
        assert isinstance(e, CiVerificationError)
        assert "environment did not pass." in e.message


# Generated at 2022-06-24 01:35:23.498306
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    try:
        frigg(branch='master')
    except Exception as err:
        assert str(err) == "Environment check failed"



# Generated at 2022-06-24 01:35:24.741790
# Unit test for function jenkins
def test_jenkins():
    jenkins("master")

# Generated at 2022-06-24 01:35:25.821532
# Unit test for function circle
def test_circle():
    circle("master")


# Generated at 2022-06-24 01:35:32.395293
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PROJECT_DIR"] = "/home/gitlab-runner/builds/f2s4s4s4/0/jiyun-jiang/semantic-release-test"
    os.environ["CI_MERGE_REQUEST_ID"] = "None"
    try:
        gitlab(branch="master")
    except Exception as e:
        assert type(e) is CiVerificationError

# Generated at 2022-06-24 01:35:38.543257
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""

    frigg("master")

    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    with pytest.raises(CiVerificationError):
        frigg("master")

    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "123"
    with pytest.raises(CiVerificationError):
        frigg("master")

# Generated at 2022-06-24 01:35:44.118620
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "not-none"
    os.environ["BRANCH_NAME"] = "master"
    jenkins("master")
    # del os.environ["JENKINS_URL"]
    # jenkins("master")



# Generated at 2022-06-24 01:35:48.113615
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    bitbucket("master")


# Generated at 2022-06-24 01:35:54.196986
# Unit test for function frigg
def test_frigg():
    # Set up
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "dev"
    os.environ["FRIGG_PULL_REQUEST"] = "true"

    # Act and Assert
    assert frigg("dev")
    assert not frigg("master")

    # Tear Down
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]



# Generated at 2022-06-24 01:36:01.151971
# Unit test for function bitbucket
def test_bitbucket():
    # GIVEN
    os.environ['BITBUCKET_BRANCH'] = 'PR'
    os.environ['BITBUCKET_PR_ID'] = '233'
    # WHEN
    # THEN
    try:
        bitbucket('PR')
    except CiVerificationError:
        pass

    os.environ['BITBUCKET_BRANCH'] = ''
    os.environ['BITBUCKET_PR_ID'] = ''


# Generated at 2022-06-24 01:36:09.301614
# Unit test for function semaphore
def test_semaphore():
    import os
    import sys
    if sys.version_info[0] > 2:
        from unittest.mock import patch
    else:
        from mock import patch
    with patch.dict("os.environ", {"BRANCH_NAME": "master", "PULL_REQUEST_NUMBER": None, "SEMAPHORE_THREAD_RESULT": "passed"}):
        semaphore("master")
    with patch.dict("os.environ", {"BRANCH_NAME": "master", "PULL_REQUEST_NUMBER": None, "SEMAPHORE_THREAD_RESULT": None}):
        semaphore("master")

# Generated at 2022-06-24 01:36:13.064408
# Unit test for function checker

# Generated at 2022-06-24 01:36:19.522396
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")

    os.environ["BRANCH_NAME"] = "not_master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore("master")
    except CiVerificationError:
        return

    assert False


# Generated at 2022-06-24 01:36:29.821607
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "False"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "staging"
    os.environ["FRIGG_PULL_REQUEST"] = "True"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "False"
    os.environ["FRIGG_BUILD_TAG"] = "0.1.0"
    os.environ["FRIGG_VERSION_FILE"] = "path/to/file"
    frigg("master")
   

# Generated at 2022-06-24 01:36:36.123219
# Unit test for function check
def test_check():
    """
    Unit test for function check.
    """
    from unittest.mock import patch

    ci_patchers = {
        "TRAVIS": "travis",
        "SEMAPHORE": "semaphore",
        "FRIGG": "frigg",
        "CIRCLECI": "circle",
        "GITLAB_CI": "gitlab",
        "JENKINS_URL": "jenkins",
        "BITBUCKET_BUILD_NUMBER": "bitbucket",
    }

# Generated at 2022-06-24 01:36:46.289979
# Unit test for function check
def test_check():
    if os.environ.get("TRAVIS") == "true":
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        travis("master")
        os.environ["TRAVIS_BRANCH"] = "feature"
        os.environ["TRAVIS_PULL_REQUEST"] = "true"
        travis("master")

    elif os.environ.get("SEMAPHORE") == "true":
        os.environ["BRANCH_NAME"] = "master"
        os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
        os.environ["PULL_REQUEST_NUMBER"] = None
        semaphore("master")
       

# Generated at 2022-06-24 01:36:54.821396
# Unit test for function frigg
def test_frigg():
    def _check(environ: dict):
        os.environ.update(environ)
        frigg('master')

    # Assert that frigg is set to true
    _check({'BRANCH_NAME': 'master', 'FRIGG': 'true'})

    # Assert that frigg is set to false
    _check({'BRANCH_NAME': 'master', 'FRIGG': 'false'})

    # Assert that frigg is not set
    _check({'BRANCH_NAME': 'master'})


# Generated at 2022-06-24 01:37:06.144067
# Unit test for function jenkins
def test_jenkins():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "nonzero"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "True"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "nonzero"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "True"


# Generated at 2022-06-24 01:37:14.302093
# Unit test for function checker
def test_checker():
    """
    A unit test for the function "checker", a decorator to ensure
    that AssertionError are propagated as CiVerificationError.
    """
    def dummy_func(*args, **kwargs):
        raise AssertionError()

    dummy_func = checker(dummy_func)
    try:
        dummy_func()
    except CiVerificationError:
        assert True

# Unit tests for the ci environment checks

# Generated at 2022-06-24 01:37:16.514821
# Unit test for function check
def test_check():
    try:
        check()
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:37:21.950116
# Unit test for function circle
def test_circle():
    """
    Tests if the correct environment variables are checked and if they
    are checked correctly.

    :returns: No return Value
    """
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_CI"] = "true"

    assert check("master")



# Generated at 2022-06-24 01:37:25.901742
# Unit test for function travis
def test_travis():
    test_branch = "test_branch"
    os.environ["TRAVIS_BRANCH"] = test_branch
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    try:
        travis(test_branch)
    except CiVerificationError:
        raise AssertionError("travis check failed")



# Generated at 2022-06-24 01:37:31.011922
# Unit test for function semaphore
def test_semaphore():
    for key, value in {"BRANCH_NAME": "master", "PULL_REQUEST_NUMBER": None, "SEMAPHORE_THREAD_RESULT": "passed"}.items():
        os.environ[key] = value

    try:
        semaphore("master")
    except CiVerificationError:
        assert False



# Generated at 2022-06-24 01:37:33.930861
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://example.com"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = None
    jenkins("master")



# Generated at 2022-06-24 01:37:35.286526
# Unit test for function gitlab
def test_gitlab():
    os.environ['GITLAB_CI'] = 'true'
    check('devel')

# Generated at 2022-06-24 01:37:43.591693
# Unit test for function check
def test_check():
    """
    Unit test for function check.

    :return: None
    """
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
    except CiVerificationError:
        os.environ.pop("TRAVIS")
        os.environ.pop("TRAVIS_BRANCH")
        os.environ.pop("TRAVIS_PULL_REQUEST")


# Generated at 2022-06-24 01:37:48.655139
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "None"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert check()



# Generated at 2022-06-24 01:37:52.690810
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = False
    check()



# Generated at 2022-06-24 01:37:57.087140
# Unit test for function travis
def test_travis():
    with pytest.raises(CiVerificationError):
        os.environ["TRAVIS_BRANCH"]= "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"

        assert os.environ.get("TRAVIS_BRANCH") == branch
        assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"


# Generated at 2022-06-24 01:38:05.536649
# Unit test for function gitlab
def test_gitlab():
    """
    Test function gitlab
    """

    try:
        # bad
        os.environ["CI_COMMIT_REF_NAME"] = "master"
        os.environ["CI_MERGE_REQUEST_ID"] = "1"
        gitlab("master")
    except CiVerificationError:
        pass

    try:
        # good
        os.environ["CI_COMMIT_REF_NAME"] = "master"
        os.environ["CI_MERGE_REQUEST_ID"] = None
        gitlab("master")
    except CiVerificationError:
        pass


# Generated at 2022-06-24 01:38:10.688747
# Unit test for function semaphore
def test_semaphore():
    assert checker(semaphore)("master")
    assert checker(semaphore)("test")
    assert checker(semaphore)("branch")


# Generated at 2022-06-24 01:38:16.745057
# Unit test for function gitlab
def test_gitlab():
    if os.environ.get("GITLAB_CI") == "true":
        assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
        assert not os.environ.get("CI_MERGE_REQUEST_IID")
    else:
        os.environ["GITLAB_CI"] = "true"
        os.environ["CI_COMMIT_REF_NAME"] = "master"
        os.environ["CI_MERGE_REQUEST_IID"] = "''"

        assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
        assert not os.environ.get("CI_MERGE_REQUEST_IID")

        os.environ["GITLAB_CI"] = "false"

# Generated at 2022-06-24 01:38:27.672058
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "something"
    jenkins("master")
    os.environ.pop("JENKINS_URL", None)
    os.environ.pop("CHANGE_ID", None)
    os.environ.pop("BRANCH_NAME", None)
    os.environ.pop("GIT_BRANCH", None)

# Generated at 2022-06-24 01:38:30.309382
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for function bitbucket
    """
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")



# Generated at 2022-06-24 01:38:34.281219
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = ""
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = ""
    assert semaphore("master") is True

    os.environ["BRANCH_NAME"] = "develop"
    assert semaphore("master") is False

    # os.environ["PULL_REQUEST_NUMBER"] = "false"
    # assert semaphore("master") is False

    # os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    # assert semaphore("master") is False

    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"


# Generated at 2022-06-24 01:38:39.448999
# Unit test for function travis
def test_travis():
    os.environ.update(
        {
            "TRAVIS": "true",
            "TRAVIS_BRANCH": "develop",
            "TRAVIS_PULL_REQUEST": "false",
        }
    )
    travis("develop")



# Generated at 2022-06-24 01:38:44.156534
# Unit test for function jenkins
def test_jenkins():
    try:
        os.environ["JENKINS_URL"] = "https://localhost:8080/"
        os.environ["BRANCH_NAME"] = "master"
        jenkins()
    except CiVerificationError as e:
        assert False, "Jenkins Check Failed"


# Generated at 2022-06-24 01:38:47.854447
# Unit test for function jenkins
def test_jenkins():
    assert jenkins(branch="master") is True
    assert jenkins(branch="other") is False



# Generated at 2022-06-24 01:38:49.560951
# Unit test for function checker
def test_checker():
    def foo():
        raise AssertionError

    assert checker(foo)() is False

    def bar():
        pass

    assert checker(bar)() is True

# Generated at 2022-06-24 01:38:58.290068
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    del os.environ["SEMAPHORE"]
    del os.environ["FRIGG"]
    del os.environ["CIRCLECI"]
    del os.environ["GITLAB_CI"]
    del os.environ["JENKINS_URL"]
    del os.environ["BITBUCKET_BUILD_NUMBER"]
    os.environ["TRAVIS"] = "true"
    check(branch="master")


# Generated at 2022-06-24 01:39:01.413442
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = '1234'
    os.environ["BITBUCKET_BRANCH"] = 'master'
    os.environ["BITBUCKET_PR_ID"] = None
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = 'not-master'
    os.environ["BITBUCKET_PR_ID"] = None
    bitbucket("master")
    del os.environ["BITBUCKET_BUILD_NUMBER"]


# Generated at 2022-06-24 01:39:09.075336
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    os.environ["FRIGG_PULL_REQUEST"] = "1"
    try:
        frigg("test")
    except CiVerificationError:
        assert True
    else:
        assert False
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    assert frigg("test")
    os.environ["FRIGG"] = "false"
    assert frigg("test")


# Generated at 2022-06-24 01:39:15.106330
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PROJECT_NAME"] = "semantic_release_test"
    os.environ["CI_PROJECT_ID"] = "12345"
    os.environ["GITLAB_CI"] = "true"
    assert gitlab("master")
    os.environ["CI_COMMIT_REF_NAME"] = "branch"
    assert not gitlab("master")
    os.environ.pop("CI_PROJECT_NAME")
    os.environ.pop("CI_PROJECT_ID")
    os.environ.pop("GITLAB_CI")
    os.environ.pop("CI_COMMIT_REF_NAME")
