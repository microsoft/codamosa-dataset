

# Generated at 2022-06-24 01:29:17.502418
# Unit test for function checker

# Generated at 2022-06-24 01:29:23.210815
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "22"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    semaphore("master")


# Generated at 2022-06-24 01:29:33.273657
# Unit test for function frigg
def test_frigg():
    """Unit test for function frigg"""
    import os
    import warnings

    os.environ["FRIGG_BUILD_BRANCH"] = "test-branch"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    frigg("test-branch")

    os.environ["FRIGG_PULL_REQUEST"] = "false"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        frigg("test-branch")

    os.environ["FRIGG_BUILD_BRANCH"] = "other-branch"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        frigg("test-branch")

    del os.environ["FRIGG_BUILD_BRANCH"]

# Generated at 2022-06-24 01:29:38.136286
# Unit test for function circle
def test_circle():
    os.environ['CIRCLE_BRANCH'] = 'develop'
    os.environ['CI_PULL_REQUEST'] = '1'

    assert circle('develop')

    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = None

    assert circle('master')



# Generated at 2022-06-24 01:29:44.722319
# Unit test for function checker
def test_checker():
    def foo():
        pass

    def bar():
        raise AssertionError

    assert foo() is True
    try:
        bar()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:29:54.557292
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = 'true'
    os.environ["BRANCH_NAME"] = 'master'
    os.environ["SEMAPHORE_THREAD_RESULT"] = 'passed'
    assert check()
    os.environ["SEMAPHORE"] = 'true'
    os.environ["BRANCH_NAME"] = 'master'
    os.environ["SEMAPHORE_THREAD_RESULT"] = 'failed'
    assert not check()
    del os.environ["SEMAPHORE"]
    del os.environ["BRANCH_NAME"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]


# Generated at 2022-06-24 01:30:01.943300
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_COMMIT_REF_NAME1'] = 'nope'

    assert check()

    del os.environ['CI_COMMIT_REF_NAME1']
    assert not check()

    del os.environ['CI_COMMIT_REF_NAME']
    assert not check()
    
    # error detection
    os.environ['CI_COMMIT_REF_NAME'] = 'development'
    try:
        check()
    except CiVerificationError:
        assert True

# Generated at 2022-06-24 01:30:06.068835
# Unit test for function checker
def test_checker():
    @checker
    def raise_assertionerror():
        assert False
    try:
        raise_assertionerror()
        assert False, "The checker decorator did not catch the AssertionError"
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:30:08.136126
# Unit test for function check
def test_check():
    assert check is not None

# Generated at 2022-06-24 01:30:11.930242
# Unit test for function circle
def test_circle():
    """
    Checks if the function circle executes well.

    :return: Test result
    """
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "true"
    assert circle() is True

# Generated at 2022-06-24 01:30:16.268542
# Unit test for function semaphore
def test_semaphore():
    os.environ['SEMAPHORE'] = 'true'
    os.environ['BRANCH_NAME'] = 'master'
    semaphore("master")
    del os.environ["SEMAPHORE"]
    del os.environ["BRANCH_NAME"]

# Generated at 2022-06-24 01:30:21.615103
# Unit test for function bitbucket
def test_bitbucket():
    """Unit test for function bitbucket
    """
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""

    bitbucket("master")


# Generated at 2022-06-24 01:30:28.931505
# Unit test for function jenkins
def test_jenkins():
    branch = 'master'
    os.environ["BRANCH_NAME"] = 'master'
    os.environ["GIT_BRANCH"] = 'master'
    os.environ["JENKINS_URL"] = 'test'
    #os.environ["CHANGE_ID"] = ''
    jenkins(branch)
    # Assert not passed
    branch = 'develop'
    os.environ["BRANCH_NAME"] = 'develop'
    try:
        jenkins(branch)
    except CiVerificationError:
        assert True
    except AssertionError:
        assert False
    # Assert not passed
    branch = 'master'
    os.environ["BRANCH_NAME"] = 'master'
    os.environ["CHANGE_ID"] = 'test'


# Generated at 2022-06-24 01:30:34.193491
# Unit test for function checker
def test_checker():
    def test_raise_assertion_error():
        assert 1 == 2

    def test_do_nothing():
        pass

    assert checker(test_raise_assertion_error)() is False
    assert checker(test_do_nothing)() is True

# Generated at 2022-06-24 01:30:41.557846
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "http://build.nltk.org/"
    os.environ['GIT_BRANCH'] = "master"
    os.environ['CHANGE_ID'] = ""
    try:
        jenkins(branch = "master")
    except:
        raise AssertionError("Environment variable not set")


# Generated at 2022-06-24 01:30:42.250206
# Unit test for function check
def test_check():
    check(branch="master")

# Generated at 2022-06-24 01:30:45.490535
# Unit test for function checker
def test_checker():
    from semantic_release.errors import CiVerificationError
    from semantic_release.checks import checker

    @checker
    def checker_test():
        assert 2+2 == 4

    assert checker_test()
    assert checker_test() == True

# Generated at 2022-06-24 01:30:48.449242
# Unit test for function jenkins
def test_jenkins():
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "jenkins_url"
    check()


# Generated at 2022-06-24 01:30:53.454806
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://server.com/jenkins"
    os.environ["GIT_BRANCH"] = "master"
    check()
    os.environ["JENKINS_URL"] = "https://server.com/jenkins"
    os.environ["BRANCH_NAME"] = "master"
    check()

# Generated at 2022-06-24 01:30:59.764239
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    assert bitbucket(branch='master') is None
    os.environ['BITBUCKET_PR_ID'] = 'pr'
    assert bitbucket(branch='master') is None
    assert os.environ['BITBUCKET_BRANCH'] == 'master'



# Generated at 2022-06-24 01:31:01.520099
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = None
    assert check(branch="master") == None


# Generated at 2022-06-24 01:31:06.791844
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = "master"
    os.environ['PULL_REQUEST_NUMBER'] = ''
    os.environ['SEMAPHORE_THREAD_RESULT'] = "passed"
    assert semaphore('') == True

    os.environ['BRANCH_NAME'] = "master"
    os.environ['PULL_REQUEST_NUMBER'] = '123'
    os.environ['SEMAPHORE_THREAD_RESULT'] = "passed"
    try:
        semaphore('')
    except CiVerificationError as err:
        assert str(err) == "The verification check for the environment did not pass."

    os.environ['BRANCH_NAME'] = 'release-1.0'

# Generated at 2022-06-24 01:31:15.846289
# Unit test for function circle
def test_circle():
    #  Circle environment not set.
    os.environ["CIRCLECI"] = "false"
    assert circle("branch")

    #  Circle environment set to True.
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "branch"
    os.environ["CI_PULL_REQUEST"] = "False"
    assert circle("branch")

    #  Circle environment set to True, but different branch.
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "different"
    os.environ["CI_PULL_REQUEST"] = "False"
    try:
        circle("branch")
    except CiVerificationError:
        assert True

    #

# Generated at 2022-06-24 01:31:24.368702
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "false"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    try:
        semaphore("master")
        assert True
    except:
        assert False

    os.environ["BRANCH_NAME"] = "develop"
    os.environ["PULL_REQUEST_NUMBER"] = "false"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    try:
        semaphore("master")
        assert False
    except:
        assert True


# Generated at 2022-06-24 01:31:30.035224
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "True"
    os.environ['GIT_BRANCH'] = "master"
    os.environ['CHANGE_ID'] = "True"

    try:
        jenkins(branch="master")
        assert False, "Should not be reached"
    except CiVerificationError:
        # Expected
        assert True


# Generated at 2022-06-24 01:31:32.436262
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check(branch="master")



# Generated at 2022-06-24 01:31:44.373300
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = "1233"
    os.environ['BITBUCKET_BRANCH'] = "master"
    bitbucket("master")
    os.environ['BITBUCKET_BRANCH'] = "master_fake"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        raise Exception("Test failed")
    os.environ['BITBUCKET_PR_ID'] = "abcde"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        raise Exception("Test failed")
    # cleanup
    del os.environ['BITBUCKET_BUILD_NUMBER']

# Generated at 2022-06-24 01:31:48.790279
# Unit test for function checker
def test_checker():
    def raise_exception():
        raise AssertionError

    def return_true():
        return True

    assert checker(raise_exception)() is True
    assert checker(return_true)() is True

# Generated at 2022-06-24 01:31:52.498142
# Unit test for function check
def test_check():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()

# Generated at 2022-06-24 01:31:55.710105
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-24 01:32:05.376257
# Unit test for function check
def test_check():
    os.environ["FRIGG"] = "true"
    check()
    del os.environ["FRIGG"]
    os.environ["TRAVIS"] = "true"
    check()
    del os.environ["TRAVIS"]
    os.environ["SEMAPHORE"] = "true"
    check()
    del os.environ["SEMAPHORE"]
    os.environ["CIRCLECI"] = "true"
    check()
    del os.environ["CIRCLECI"]
    os.environ["GITLAB_CI"] = "true"
    check()
    del os.environ["GITLAB_CI"]
    os.environ["JENKINS_URL"] = "somevalue"
    check()

# Generated at 2022-06-24 01:32:12.435820
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    check()
    os.environ["FRIGG_PULL_REQUEST"] = "1234"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    check()


# Generated at 2022-06-24 01:32:17.131593
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_BRANCH"] = "master"
    circle("master")

# Generated at 2022-06-24 01:32:23.258786
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")



# Generated at 2022-06-24 01:32:32.739067
# Unit test for function travis
def test_travis():
    """
    Unit tests for checking the environment variables
    of Travis CI
    """
    travis_env = {
        "TRAVIS_PULL_REQUEST": "false",
        "TRAVIS_BRANCH": "master",
        "TRAVIS": "true",
    }
    os.environ.update(travis_env)
    assert travis("master") is True
    os.environ.pop("TRAVIS_BRANCH")
    assert travis("master") is False
    os.environ.pop("TRAVIS_PULL_REQUEST")
    assert travis("master") is False
    os.environ.update(travis_env)
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    assert travis("master") is False

# Generated at 2022-06-24 01:32:37.237260
# Unit test for function gitlab
def test_gitlab():
    os.environ['GITLAB_CI'] = 'true'
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    check('master')



# Generated at 2022-06-24 01:32:42.978383
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.test.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = ""
    expected = True
    observed = jenkins("master")
    assert observed == expected

# Generated at 2022-06-24 01:32:49.215947
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_PROJECT_PATH'] = ''
    gitlab('master')
    os.environ['CI_COMMIT_REF_NAME'] = 'develop'
    with pytest.raises(CiVerificationError):
        gitlab('master')

    os.environ['CI_MERGE_REQUEST_PROJECT_PATH'] = 'semantic-release'
    with pytest.raises(CiVerificationError):
        gitlab('master')

# Generated at 2022-06-24 01:32:51.459615
# Unit test for function checker
def test_checker():
    @checker
    def checked_func():
        assert False
    try:
        checked_func()
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:32:56.405768
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = 1
    os.environ["BITBUCKET_BRANCH"] = "master"
    name = "BITBUCKET_BRANCH"
    assert os.environ.get(name) == "master"
    assert not os.environ.get("BITBUCKET_PR_ID")


# Generated at 2022-06-24 01:33:01.595339
# Unit test for function checker
def test_checker():
    def test_func():
        raise AssertionError

    wrapped_test_func = checker(test_func)

    try:
        wrapped_test_func()
        assert False, 'Should throw exception'
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:33:03.695867
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "test"
    os.environ["BITBUCKET_BRANCH"] = "test"
    bitbucket("test")
    del os.environ["BITBUCKET_BUILD_NUMBER"]
    del os.environ["BITBUCKET_BRANCH"]

# Generated at 2022-06-24 01:33:15.219308
# Unit test for function checker
def test_checker():
    def test_function(branch: str):
        assert os.environ.get("TEST_VAR") == branch

    try:
        test_function(branch="test")
    except AssertionError:
        pass
    else:
        raise Exception("test_function should raise AssertionError")

    try:
        wrapped_test_function = checker(test_function)
        wrapped_test_function(branch="test")
    except AssertionError:
        raise Exception("checker should have converted AssertionError to CiVerificationError")
    except CiVerificationError:
        pass
    else:
        raise Exception("checker should have raised a CiVerificationError")

    # wrapped_test_function should not raise an error
    assert wrapped_test_function(branch="true")

# Generated at 2022-06-24 01:33:17.408621
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["GITLAB_CI"] = "true"
    assert gitlab("master")


# Generated at 2022-06-24 01:33:23.995050
# Unit test for function travis
def test_travis():
    """
    Performs necessary checks to ensure that the travis build is one
    that should create releases.
    """
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis(branch="master")
        assert True
    except CiVerificationError:
        assert False
        print('Error')


# Generated at 2022-06-24 01:33:28.153239
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "http://localhost:8080"
    jenkins("master")
    del os.environ["JENKINS_URL"]
    del os.environ["BRANCH_NAME"]

# Generated at 2022-06-24 01:33:31.824149
# Unit test for function circle
def test_circle():
    branch = "master"
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = branch
    os.environ["CI_PULL_REQUEST"] = None
    circle(branch)

# Generated at 2022-06-24 01:33:37.403260
# Unit test for function gitlab
def test_gitlab():
    env = {
        'CI_COMMIT_REF_NAME': 'master',
        'CI_MERGE_REQUEST_IID': '',
    }
    for k in env.keys():
        os.environ[k] = env[k]
    assert gitlab('master')

# Generated at 2022-06-24 01:33:42.406110
# Unit test for function circle
def test_circle():
    branch = "master"
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = branch
    os.environ["CI_PULL_REQUEST"] = ""
    circle(branch)


if __name__ == "__main__":
    check(branch="develop")
    print("Check done")

# Generated at 2022-06-24 01:33:47.079390
# Unit test for function gitlab
def test_gitlab():
    assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
    assert not os.environ.get("CI_MERGE_REQUEST_IID")
    gitlab("master")
    print("Test for gitlab passed")


# Generated at 2022-06-24 01:33:51.392760
# Unit test for function frigg
def test_frigg():
    """ Unit test for function frigg() """
    os.environ["FRIGG"] = "true"

# Generated at 2022-06-24 01:33:57.697551
# Unit test for function travis
def test_travis():
    """
    Test the travis function
    """
    os.environ['TRAVIS_BRANCH'] = 'test_branch'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    os.environ['TRAVIS'] = 'true'
    del os.environ['SEMAPHORE']
    del os.environ['FRIGG']
    del os.environ['CIRCLECI']
    del os.environ['GITLAB_CI']
    del os.environ['JENKINS_URL']
    del os.environ['BITBUCKET_BUILD_NUMBER']

    check('test_branch')


# Generated at 2022-06-24 01:34:05.105588
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://localhost:8080/"
    os.environ["GIT_BRANCH"] = "PR-1234"
    os.environ["CHANGE_ID"] = "PR-1234"
    try:
        jenkins()
    except CiVerificationError:
        pass
    os.environ["CHANGE_ID"] = "null"
    os.environ["GIT_BRANCH"] = "master"

# Generated at 2022-06-24 01:34:09.407634
# Unit test for function semaphore
def test_semaphore():
    ci = True
    branch = os.environ.get("BRANCH_NAME")
    os.environ.get("PULL_REQUEST_NUMBER") is None
    print(
        "The checks for this environment did not pass which are necessary for "
        "a release."
    )



# Generated at 2022-06-24 01:34:15.019326
# Unit test for function checker
def test_checker():
    try:
        @checker
        def func():
            assert False
        func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("checker did not raise CiVerificationError")

# Generated at 2022-06-24 01:34:19.704470
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("master") is True
    assert jenkins("foo_branch") is False

    os.environ["JENKINS_URL"] = "test_url"
    os.environ["BRANCH_NAME"] = "foo_branch"
    os.environ["CHANGE_ID"] = "42"

    assert jenkins("master") is False
    assert jenkins("foo_branch") is True
    assert jenkins("foo_branch2") is False

    del os.environ["JENKINS_URL"]
    del os.environ["BRANCH_NAME"]
    del os.environ["CHANGE_ID"]

# Generated at 2022-06-24 01:34:26.280884
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "https://ci.jenkins.com"
    os.environ["CHANGE_ID"] = "1"

    check()

    assert os.environ.get("BRANCH_NAME") == "master"
    assert os.environ.get("GIT_BRANCH") == "master"
    assert os.environ.get("JENKINS_URL") == "https://ci.jenkins.com"
    assert os.environ.get("CHANGE_ID") is None


# Generated at 2022-06-24 01:34:37.153462
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"

    def cleanup():
        del os.environ["TRAVIS"]

    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    check("master")
    cleanup()

    os.environ["TRAVIS_BRANCH"] = "feature_branch"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"

    try:
        check("master")
    except CiVerificationError:
        pass
    else:
        assert False

    cleanup()

    os.environ["TRAVIS"] = "false"

    os.environ["SEMAPHORE"] = "true"

# Generated at 2022-06-24 01:34:42.038744
# Unit test for function check
def test_check():
    """
    Unit test for function check
    """
    env = os.environ
    os.environ = {}
    try:
        check()
    except CiVerificationError:
        assert False
    os.environ = env

# Generated at 2022-06-24 01:34:47.990761
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = None
    assert jenkins("master") is True


# Generated at 2022-06-24 01:34:52.753426
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    check()

# Generated at 2022-06-24 01:34:56.131852
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = False
    circle("master")

# Generated at 2022-06-24 01:35:00.736720
# Unit test for function checker
def test_checker():
    def password_validator_no_exception(password):
        return True

    def password_validator_with_exception(password):
        raise AssertionError

    assert checker(password_validator_no_exception)("test") is True
    assert checker(password_validator_with_exception)("test") is False

# Generated at 2022-06-24 01:35:09.291757
# Unit test for function check
def test_check():
    """
    Tests for the function check
    """
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()
    del os.environ["SEMAPHORE"]

# Generated at 2022-06-24 01:35:13.104916
# Unit test for function frigg
def test_frigg():
    """
    Unit test for function frigg
    
    :raise: AssertionError: If the test failed
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")


# Generated at 2022-06-24 01:35:15.428854
# Unit test for function check
def test_check():
    """
    test_check function
    """
    try:
        check()
    except Exception as exc:
        assert isinstance(exc, CiVerificationError)

# Generated at 2022-06-24 01:35:19.874654
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check() # should pass
    os.environ["TRAVIS_PULL_REQUEST"] = "12345"  # should fail
    try:
        check()
    except CiVerificationError:
        print("CiVerificationError raised, test_check passed")
    finally:
        del os.environ["TRAVIS"]
        del os.environ["TRAVIS_BRANCH"]
        del os.environ["TRAVIS_PULL_REQUEST"]

test_check()

# Generated at 2022-06-24 01:35:28.036333
# Unit test for function gitlab
def test_gitlab():
    def aux(p_name, p_value, p_branch, p_expected):
        # Set some values
        os.environ[p_name] = p_value
        # Call the function
        gitlab(p_branch)
        # Get the value from the environment
        res = os.environ.get(p_name)
        # Check expectation
        assert res == p_expected
        # Delete the value
        os.environ.pop(p_name)

    # Set the branch
    branch = "master"

    # Set the variables to check
    v_name = "CI_COMMIT_REF_NAME"
    v_value = "master"
    v_expected = "master"
    aux(v_name, v_value, branch, v_expected)


# Generated at 2022-06-24 01:35:31.010184
# Unit test for function checker
def test_checker():
    @checker
    def function():
        assert False

    try:
        function()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("checker did not raise CiVerificationError")

# Generated at 2022-06-24 01:35:35.934475
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check("master")

    os.environ["CI_COMMIT_REF_NAME"] = "dev"
    try:
        check("master")
    except CiVerificationError as e:
        assert e.args[0] == "The verification check for the environment did not pass."

    assert os.environ.get("CI_COMMIT_REF_NAME") == "dev"

# Generated at 2022-06-24 01:35:43.028864
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PROJECT_NAME"] = "jangorecki/semantic-release"
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "feature/test"
    with pytest.raises(CiVerificationError):
        check()
    del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-24 01:35:51.447146
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://jenkins.build.com"
    os.environ["BRANCH_NAME"] = "master"
    jenkins(branch="master")
    os.environ.pop("JENKINS_URL")
    os.environ.pop("BRANCH_NAME")
    os.environ["JENKINS_URL"] = "http://jenkins.build.com"
    os.environ["GIT_BRANCH"] = "master"
    jenkins(branch="master")
    os.environ.pop("JENKINS_URL")
    os.environ.pop("GIT_BRANCH")

# Generated at 2022-06-24 01:36:01.470918
# Unit test for function bitbucket
def test_bitbucket():
    import os
    import pytest
    from semantic_release.errors import CiVerificationError
    try:
        os.environ['BITBUCKET_BUILD_NUMBER'] = "1"
        os.environ['BITBUCKET_BRANCH'] = "master"
        os.environ['BITBUCKET_PR_ID'] = "42"
        with pytest.raises(CiVerificationError):
            bitbucket("dev")

        os.environ['BITBUCKET_PR_ID'] = ""
        bitbucket("master")

        os.environ['BITBUCKET_BRANCH'] = "dev"
        bitbucket("dev")

    finally:
        if os.environ.get("BITBUCKET_BUILD_NUMBER") is not None:
            del os.en

# Generated at 2022-06-24 01:36:09.441000
# Unit test for function frigg
def test_frigg():
    """
    Unit test for function frigg
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "123"

    try:
        check()
    except Exception:
        pass
    else:
        raise ValueError("test_frigg failed")

    os.environ["FRIGG_PULL_REQUEST"] = None
    check()
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    try:
        check("develop")
    except Exception:
        pass
    else:
        raise ValueError("test_frigg failed")

    del os.environ["FRIGG"]

# Generated at 2022-06-24 01:36:11.526941
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check("master")
    assert True



# Generated at 2022-06-24 01:36:18.687318
# Unit test for function semaphore
def test_semaphore():

    # Test: successful build
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    check('master')

    os.environ.pop("SEMAPHORE_THREAD_RESULT")

    # Test: failed build
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        check('master')
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."
    else:
        assert False

    os.environ.pop("SEMAPHORE_THREAD_RESULT")


# Generated at 2022-06-24 01:36:24.695517
# Unit test for function check
def test_check():
    """
    Test function check
    """
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert check() == True

# Generated at 2022-06-24 01:36:32.699773
# Unit test for function frigg
def test_frigg():
    with_frigg = dict(FRIGG="true", FRIGG_BUILD_BRANCH="master", FRIGG_PULL_REQUEST=False)
    without_frigg = dict(NOTFRIGG="true", FRIGG_BUILD_BRANCH="master", FRIGG_PULL_REQUEST=False)

    os.environ.update(with_frigg)
    check()
    os.environ.update(without_frigg)
    check()

# Generated at 2022-06-24 01:36:38.472651
# Unit test for function checker
def test_checker():
    def no_err():
        pass

    def err():
        assert False

    assert checker(no_err)()
    try:
        checker(err)()
    except CiVerificationError:
        pass
    else:
        assert False, "Should have raised a CiVerificationError."

# Generated at 2022-06-24 01:36:47.131901
# Unit test for function semaphore
def test_semaphore():
    # Case 1: Branch name is correct, pull request number is None, thread result is not failed
    assert os.environ.get("BRANCH_NAME") == 'master'
    assert os.environ.get("PULL_REQUEST_NUMBER") == None
    assert os.environ.get("SEMAPHORE_THREAD_RESULT") != "failed"
    semaphore('master')
    # Case 2: Branch name is incorrect, pull request number is None, thread result is not failed
    assert os.environ.get("BRANCH_NAME") != 'master'
    assert os.environ.get("PULL_REQUEST_NUMBER") == None
    assert os.environ.get("SEMAPHORE_THREAD_RESULT") != "failed"
    semaphore('master')
    # Case 3: Branch name

# Generated at 2022-06-24 01:36:58.892558
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    try:
        circle('master')
    except AssertionError:
        assert False
    del os.environ['CIRCLE_BRANCH']
    os.environ['CI_PULL_REQUEST'] = 'True'
    try:
        circle('master')
        assert False
    except AssertionError:
        assert True
    del os.environ['CI_PULL_REQUEST']
    os.environ['CIRCLE_BRANCH'] = 'staging'
    try:
        circle('master')
        assert False
    except AssertionError:
        assert True
    del os.environ['CIRCLE_BRANCH']
    del os

# Generated at 2022-06-24 01:37:00.587754
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket("Release") == True

# Generated at 2022-06-24 01:37:06.086379
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    del os.environ['BITBUCKET_PR_ID']
    import semantic_release.ci_checks
    # set function bitbucket as function that is to be tested
    semantic_release.ci_checks.check = semantic_release.ci_checks.bitbucket
    # call the function
    semantic_release.ci_checks.check()
    # delete the environment variable BITBUCKET_PR_ID
    del os.environ['BITBUCKET_PR_ID']

# Generated at 2022-06-24 01:37:11.599329
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")


# Generated at 2022-06-24 01:37:17.930803
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('master')
    os.environ['TRAVIS_BRANCH'] = 'develop'
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    try:
        travis('master')
    except CiVerificationError:
        travis_flag = True
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'


# Generated at 2022-06-24 01:37:24.797878
# Unit test for function circle
def test_circle():
    # We test this function with a sample valid environment
    # and a sample invalid environment
    os.environ['CIRCLE_BRANCH'] = 'master'
    assert circle('master')
    os.environ['CIRCLE_BRANCH'] = 'notmaster'
    assert not circle('master')



# Generated at 2022-06-24 01:37:34.189527
# Unit test for function check

# Generated at 2022-06-24 01:37:42.071090
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "branch"
    os.environ["BITBUCKET_PR_ID"] = "pr_id"
    try:
        assert bitbucket("branch")
        assert False
    except CiVerificationError as error:
        assert error.__str__() == "The verification check for the environment did not pass."

    del os.environ["BITBUCKET_PR_ID"]

    try:
        assert bitbucket("branch")
        assert bitbucket("other") == False
        assert False
    except CiVerificationError as error:
        assert error.__str__() == "The verification check for the environment did not pass."



# Generated at 2022-06-24 01:37:48.656250
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = "true"
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = 'false'

    check()
    del os.environ['CIRCLECI']
    del os.environ['CIRCLE_BRANCH']
    del os.environ['CI_PULL_REQUEST']


# Generated at 2022-06-24 01:37:56.033987
# Unit test for function gitlab
def test_gitlab():
    # Raise error if environment variable is not set
    assert gitlab("master") == None
    # Set environment variable to run test
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    # Raise error if branch is not "master"
    assert gitlab("not-master") == None
    # Pass test if branch is "master"
    assert gitlab("master") == True
    # Raise error if there is a merge request
    assert gitlab("master") == None


# Generated at 2022-06-24 01:37:57.136225
# Unit test for function semaphore
def test_semaphore():
    semaphore("master")

# Generated at 2022-06-24 01:38:07.977634
# Unit test for function check
def test_check():
    # Checking for branch: 'test_branch'
    os.environ["TRAVIS_BRANCH"] = "test_branch"
    assert check("test_branch") == None

    # Travis should raise a CiVerificationError
    os.environ["TRAVIS_BRANCH"] = "master"
    try:
        check("test_branch")
    except CiVerificationError as e:
        assert type(e) == CiVerificationError
    else:
        raise AssertionError("Should raise a CiVerificationError")

    # Checking for branch: 'test_branch'
    os.environ["BRANCH_NAME"] = "test_branch"
    assert check("test_branch") == None

    # Semaphore should raise a CiVerificationError

# Generated at 2022-06-24 01:38:15.317986
# Unit test for function frigg
def test_frigg():
    os.environ.update({"FRIGG": "true"})
    assert len(os.environ) == 1
    try:
        frigg("master")
    except CiVerificationError:
        pass
    else:
        assert 0, "Frigg should have raised an exception"

    os.environ.update({"FRIGG_BUILD_BRANCH": "master"})
    assert len(os.environ) == 2
    try:
        frigg("master")
    except CiVerificationError:
        assert 0, "Frigg should not have raised an exception"
    else:
        os.environ.update({"FRIGG_PULL_REQUEST": "true"})
        assert len(os.environ) == 3

# Generated at 2022-06-24 01:38:20.241779
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = ''
    assert bitbucket('master')


# Generated at 2022-06-24 01:38:26.293863
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "https://github.com/relekang/python-semantic-release/pull/181"
    circle()


if __name__ == '__main__':
    test_circle()

# Generated at 2022-06-24 01:38:33.188117
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master") == True

# Generated at 2022-06-24 01:38:35.633224
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-24 01:38:46.106384
# Unit test for function circle
def test_circle():
    for key, value in [('CIRCLECI', 'true'), ('CIRCLE_BRANCH', 'master'), ('CI_PULL_REQUEST', None)]:
        os.environ[key] = value
    try:
        circle('master')
        print("- Function 'circle' work correctly. TEST OK")
    except CiVerificationError:
        pass
    del os.environ['CIRCLECI']
    del os.environ['CIRCLE_BRANCH']
    del os.environ['CI_PULL_REQUEST']
    try:
        circle('master')
    except CiVerificationError:
        print("- Function 'circle' work correctly. TEST OK")
    except Exception as e:
        print("- ERROR: ", e)

# Generated at 2022-06-24 01:38:50.392747
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "jenkins-test-branch"
    os.environ["CI_PULL_REQUEST"] = "jenkins-test-pull-request-id"
    os.environ["JENKINS_URL"] = "jenkins-test-url"
    check()
    print("Jenkins Check: Passed")


# Generated at 2022-06-24 01:38:53.636786
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://url:8080"
    os.environ["GIT_BRANCH"] = "test_branch"
    check("test_branch")
    del os.environ["JENKINS_URL"]
    del os.environ["GIT_BRANCH"]

# Generated at 2022-06-24 01:39:04.851039
# Unit test for function gitlab
def test_gitlab():
    """
    Test that the gitlab checker works in the expected fashion.
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_TARGET_BRANCH_NAME"] = "feature"

    os.environ["GITLAB_CI"] = "true"

    with pytest.raises(CiVerificationError):
        check()

    os.environ["CI_MERGE_REQUEST_TARGET_BRANCH_NAME"] = "master"
    os.environ["GITLAB_CI"] = "false"

    check()

    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_TARGET_BRANCH_NAME"]
    del os

# Generated at 2022-06-24 01:39:09.122355
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()



# Generated at 2022-06-24 01:39:14.775797
# Unit test for function travis
def test_travis():
    '''
        Unit test for checker
        Function: travis
        Check: Check if the build is on specified branch and not a pull request
    '''
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    if os.environ["TRAVIS_BRANCH"] != "master":
        raise AssertionError("The verification check for the environment did not pass")
    if os.environ["TRAVIS_PULL_REQUEST"] != "false":
        raise AssertionError("The verification check for the environment did not pass")
