

# Generated at 2022-06-24 01:29:21.129801
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")

    del os.environ["BITBUCKET_BRANCH"]
    os.environ["BITBUCKET_PR_ID"] = "1"
    bitbucket("master")

    del os.environ["BITBUCKET_PR_ID"]
    os.environ["BITBUCKET_BRANCH"] = "feature"
    bitbucket("master")

    del os.environ["BITBUCKET_BRANCH"]



# Generated at 2022-06-24 01:29:30.702308
# Unit test for function checker
def test_checker():
    from semantic_release.errors import CiVerificationError

    def assert_raised(func, args, kwargs):
        try:
            func(*args, **kwargs)
        except CiVerificationError:
            return True
        else:
            return False

    is_raises = checker(assert_raised)
    assert not is_raises(AssertionError)
    assert not is_raises(AssertionError, (True,))
    assert not is_raises(AssertionError, (), {"arg": False})
    assert is_raises(AssertionError, (), {"arg": True})
    assert is_raises(AssertionError, (True,))

# Generated at 2022-06-24 01:29:37.403443
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "12345"
    os.environ["BRANCH_NAME"] = "master"
    check("master")
    os.environ["BRANCH_NAME"] = "test"
    with pytest.raises(CiVerificationError):
        check("master")
    del os.environ["BRANCH_NAME"]
    os.environ["GIT_BRANCH"] = "master"
    check("master")
    os.environ["GIT_BRANCH"] = "test"
    with pytest.raises(CiVerificationError):
        check("master")
    del os.environ["GIT_BRANCH"]
    os.environ["CHANGE_ID"] = "123"

# Generated at 2022-06-24 01:29:43.437297
# Unit test for function bitbucket
def test_bitbucket():
    # success case
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket(branch="master")
    # failure case
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        bitbucket(branch="master")
    except CiVerificationError:
        pass
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]

# Generated at 2022-06-24 01:29:55.683479
# Unit test for function semaphore
def test_semaphore():
    """
    Unit test for function semaphore
    """
    # Correct case
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")

    # Wrong branch
    os.environ["BRANCH_NAME"] = "develop"
    with pytest.raises(CiVerificationError):
        semaphore("master")

    # Pull request
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "5"
    with pytest.raises(CiVerificationError):
        semaphore("master")

    # Failed build

# Generated at 2022-06-24 01:30:00.973151
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"

    assert circle("master")

    os.environ["CIRCLE_BRANCH"] = "develop"

    try:
        circle("master")
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-24 01:30:09.334108
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = "some_number"
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_PR_ID'] = "some_pr_id"

    assert check("master") == True

    # remove two environment variables used by bitbucket()
    os.environ.pop('BITBUCKET_BRANCH')
    os.environ.pop('BITBUCKET_PR_ID')

    # CI_COMMIT_REF_NAME is defined in gitlab CI environment
    os.environ['CI_COMMIT_REF_NAME'] = 'master'

    assert check("master") == True

    # remove one environment variable used by gitlab()

# Generated at 2022-06-24 01:30:13.530135
# Unit test for function bitbucket
def test_bitbucket():
    assert os.environ.get("BITBUCKET_BUILD_NUMBER") is not None
    assert os.environ.get("BITBUCKET_BUILD_NUMBER") == '1'
    assert os.environ.get("BITBUCKET_BRANCH") is not None
    assert os.environ.get("BITBUCKET_BRANCH") == 'master'
    
test_bitbucket()

check()

# Generated at 2022-06-24 01:30:14.948794
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("master")

# Generated at 2022-06-24 01:30:18.525091
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123456"
    result = bitbucket("master")
    assert result == True

    os.environ["BITBUCKET_BRANCH"] = "master"
    del os.environ["BITBUCKET_PR_ID"]
    result = bitbucket("master")
    assert result == True

# Generated at 2022-06-24 01:30:22.807915
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket(branch="master")


# Generated at 2022-06-24 01:30:23.593356
# Unit test for function bitbucket
def test_bitbucket():
    bitbucket('master')

# Generated at 2022-06-24 01:30:31.771519
# Unit test for function jenkins
def test_jenkins():
    os.environ["BITBUCKET_BUILD_NUMBER"] = ""
    os.environ["JENKINS_URL"] = "http://jenkins.com"
    os.environ["BRANCH_NAME"] = ""
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = ""
    if jenkins("master") != True:
        raise AssertionError("Test 5 failed")

# Generated at 2022-06-24 01:30:37.428450
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG_BUILD_BRANCH'] = 'test-branch'
    os.environ['FRIGG_PULL_REQUEST'] = None
    assert frigg('test-branch')
    os.environ['FRIGG_BUILD_BRANCH'] = 'wrong-branch'
    assert frigg('test-branch') is False
    os.environ['FRIGG_PULL_REQUEST'] = 'some pull request'
    assert frigg('test-branch') is False
    

# Generated at 2022-06-24 01:30:44.248789
# Unit test for function frigg
def test_frigg():
    # Set the environment variable of FRIGG to true
    os.environ["FRIGG"] = "true"

    # Expected to pass
    frigg("master")

    # Set the environment variable of FRIGG to true and the BRANCH_NAME to "development"
    os.environ["BRANCH_NAME"] = "development"
    os.environ["FRIGG"] = "true"

    # Expected to fail since the branch is not master
    try:
        frigg("master")
    except CiVerificationError as e:
        assert "The verification check for the environment did not pass." == str(e)



# Generated at 2022-06-24 01:30:54.225672
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("This check should have failed.")
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
    except CiVerificationError:
        raise AssertionError("This check should not have failed.")
    del os.environ["TRAVIS_BRANCH"]
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("This check should have failed.")

# Generated at 2022-06-24 01:30:59.525778
# Unit test for function bitbucket
def test_bitbucket():
    branch = "master"
    # Mock environment variables
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = branch
    os.environ["BITBUCKET_PR_ID"] = ""

    # Check
    bitbucket(branch)

# Generated at 2022-06-24 01:31:05.650596
# Unit test for function travis
def test_travis():
    # should not raise exception for correct environment
    travis("master")

    # reset the environment
    os.environ["TRAVIS_BRANCH"] = "foo"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    # should raise exception for wrong branch
    assert travis("master") == False

    # reset the environment
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"

    # should raise exception for pull request
    assert travis("master") == False


# Generated at 2022-06-24 01:31:12.697694
# Unit test for function semaphore
def test_semaphore():
    # Should not raise
    semaphore("master")

    os.environ["BRANCH_NAME"] = None
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore("master")
        assert False
    except CiVerificationError:
        # Expected
        pass

# Generated at 2022-06-24 01:31:15.138534
# Unit test for function checker
def test_checker():
    @checker
    def my_func():
        raise AssertionError("Fail")

    try:
        my_func()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:31:19.212682
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    assert check()


# Generated at 2022-06-24 01:31:23.371257
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('master')
    

# Generated at 2022-06-24 01:31:29.211513
# Unit test for function checker
def test_checker():
    """
    Test checker(func)

    :raises AssertionError: Always raises as a test.
    """
    def raise_error():
        raise AssertionError
    check = checker(raise_error)
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise Asse

# Generated at 2022-06-24 01:31:34.079233
# Unit test for function jenkins
def test_jenkins():
    if os.environ.get("TRAVIS") == "true":
        return
    os.environ["JENKINS_URL"] = "test"
    os.environ["BRANCH_NAME"] = os.environ["GIT_BRANCH"] = "test"
    check()
    del os.environ["JENKINS_URL"]
    del os.environ["BRANCH_NAME"]
    del os.environ["GIT_BRANCH"]

# Generated at 2022-06-24 01:31:40.196486
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    os.environ["CHANGE_ID"] = None
    check()

# Generated at 2022-06-24 01:31:42.110563
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check("master")
    del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-24 01:31:44.998684
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'appveyor'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('appveyor')

# Generated at 2022-06-24 01:31:54.321602
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_IID'] = None

    assert check()

    os.environ['CI_COMMIT_REF_NAME'] = 'test-branch'
    os.environ['CI_MERGE_REQUEST_IID'] = None

    try:
        check()
    except CiVerificationError:
        assert True

    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_IID'] = 1

    try:
        check()
    except CiVerificationError:
        assert True


# Generated at 2022-06-24 01:32:02.017575
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "test"
    os.environ["CI_PULL_REQUEST"] = "true"
    assert not circle("")
    os.environ["CI_PULL_REQUEST"] = None
    assert circle("test")
    assert not circle("non_test")


# Generated at 2022-06-24 01:32:05.848002
# Unit test for function bitbucket
def test_bitbucket():
    assert os.environ.get("BITBUCKET_BRANCH") == 'master'
    assert not os.environ.get("BITBUCKET_PR_ID")

# Generated at 2022-06-24 01:32:12.540729
# Unit test for function jenkins
def test_jenkins():
    os.environ['BRANCH_NAME'] = "master"
    os.environ['JENKINS_URL'] = "https://jenkins.io"
    os.environ['CHANGE_ID'] = None
    try:
        jenkins("master")
    except CiVerificationError as e:
        raise e
    except Exception as e:
        raise e
    finally:
        del os.environ['BRANCH_NAME']
        del os.environ['JENKINS_URL']
        del os.environ['CHANGE_ID']

# Generated at 2022-06-24 01:32:20.136982
# Unit test for function checker
def test_checker():
    """
    Assert that the checker only wraps AssertionErrors to
    CiVerificationError
    """
    def success():
        """
        This function should execute without a try/except block.
        """
    def fail():
        """
        This function should throw an assertion error.
        """
        assert False
    def generic_exception():
        """
        This function should throw an exception
        """
        raise Exception("This exception is not an AssertionError")

    assert checker(success)()
    try:
        checker(fail)()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("The failed function did not raise a CiVerificationError")
    try:
        checker(generic_exception)()
    except Exception:
        pass
    else:
        raise

# Generated at 2022-06-24 01:32:24.883161
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()
    assert "CI_COMMIT_REF_NAME" in os.environ
    os.environ["GITLAB_CI"] = "true"
    check()



# Generated at 2022-06-24 01:32:28.101852
# Unit test for function gitlab
def test_gitlab():
    """
    Tests the gitlab check function.
    """
    assert gitlab.__name__ == "gitlab"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    gitlab(branch="master")

# Generated at 2022-06-24 01:32:39.110425
# Unit test for function checker
def test_checker():
    """
    Test the checker decorator.
    """

    @checker
    def test_function():
        assert False

    # In case the checker doesn't raise any error at all
    def test_function_no_error():
        return

    # In case the checker doesn't raise the right error
    @checker
    def test_function_wrong_error():
        raise Exception

    # In case the checker raises no error and returns a value
    @checker
    def test_function_with_return():
        return True

    try:
        test_function()
    except AssertionError:
        pass
    except Exception:
        # In case the checker doesn't raise any error
        raise
    else:
        # In case the checker doesn't raise any error
        raise


# Generated at 2022-06-24 01:32:41.218467
# Unit test for function semaphore
def test_semaphore():
    checker(semaphore)(branch='master')


# Generated at 2022-06-24 01:32:49.525874
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1750"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_COMMIT"] = "3e7d2e8fdbb7"
    os.environ["BITBUCKET_PR_ID"] = None
    os.environ["BITBUCKET_REPO_SLUG"] = "remram44/semantic-release"
    os.environ["BITBUCKET_WORKSPACE"] = "/home/git/repositories/remram44/semantic-release"
    bitbucket("master")



# Generated at 2022-06-24 01:32:57.995710
# Unit test for function semaphore
def test_semaphore():
    """
    This function is a unit test for the function semaphore
    """
    assert os.environ.get("SEMAPHORE")
    assert os.environ.get("BRANCH_NAME") == "master"
    assert os.environ.get("PULL_REQUEST_NUMBER") is None
    assert os.environ.get("SEMAPHORE_THREAD_RESULT") != "failed"

    assert semaphore("master")

    os.environ["SEMAPHORE"] = ""
    os.environ["BRANCH_NAME"] = "develop"
    assert not semaphore("master")

if __name__ == '__main__':
    check()

# Generated at 2022-06-24 01:33:05.417625
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["CHANGE_ID"] = "0"

    check()
    del os.environ["BRANCH_NAME"]
    del os.environ["GIT_BRANCH"]
    del os.environ["JENKINS_URL"]
    del os.environ["CHANGE_ID"]


# Generated at 2022-06-24 01:33:11.534583
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert check("master")

    os.environ["CI_COMMIT_REF_NAME"] = "non-master"
    try:
        check("master")
        assert False
    except CiVerificationError as e:
        pass
    finally:
        del os.environ["CI_COMMIT_REF_NAME"]


# Generated at 2022-06-24 01:33:14.850639
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    check()

# Generated at 2022-06-24 01:33:16.762791
# Unit test for function travis
def test_travis():
    """
    Unit test for function travis
    """
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-24 01:33:22.593725
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"]= "Test"
    os.environ["TRAVIS_PULL_REQUEST"]= "false"
    assert travis("Test") == True
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-24 01:33:26.147445
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check(branch="master")
    del(os.environ["CI_COMMIT_REF_NAME"])

# Generated at 2022-06-24 01:33:35.241058
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = ''
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    assert semaphore(branch = 'master') == True

    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = '444'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    try:
        assert semaphore(branch = 'master') == True
    except AssertionError:
        assert semaphore(branch = 'master') == False

    os.environ['BRANCH_NAME'] = 'master'

# Generated at 2022-06-24 01:33:43.963806
# Unit test for function frigg
def test_frigg():
    assert not checker(frigg)("1")

    os.environ['FRIGG_PULL_REQUEST'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'non_master'
    try:
        checker(frigg)("master")
        assert False
    except CiVerificationError:
        pass
    del os.environ['FRIGG_PULL_REQUEST']

    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    assert checker(frigg)("master")
    del os.environ['FRIGG_BUILD_BRANCH']


# Generated at 2022-06-24 01:33:48.327759
# Unit test for function checker
def test_checker():
    def test():
        assert False

    @checker
    def test_wrapped():
        assert False

    with pytest.raises(AssertionError):
        test()

    with pytest.raises(CiVerificationError):
        test_wrapped()

# Generated at 2022-06-24 01:33:54.233003
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "develop"
    travis("develop")
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        assert True
    else:
        assert False



# Generated at 2022-06-24 01:33:57.750174
# Unit test for function gitlab
def test_gitlab():
    os = __import__('os')
    os.environ['GITLAB_CI'] = 'true'
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    check()

# Generated at 2022-06-24 01:34:06.971539
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    # On valid environment
    assert travis("master")
    # On invalid branch
    try:
        travis("staging")
    except CiVerificationError:
        pass
    else:
        raise Exception("Should raise an assertion")
    # On pull request
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        raise Exception("Should raise an assertion")



# Generated at 2022-06-24 01:34:11.661706
# Unit test for function travis
def test_travis():
    os.environ.setdefault("TRAVIS_BRANCH","master")
    os.environ.setdefault("TRAVIS_PULL_REQUEST","false")
    checker(travis)("master")
    try:
        checker(travis)("a")
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."


# Generated at 2022-06-24 01:34:15.217606
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-24 01:34:22.575872
# Unit test for function checker
def test_checker():
    """
    Test custom decorator
    """
    def func(branch: str):
        assert os.environ.get("TRAVIS_BRANCH") == branch
        assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"
    assert checker(func)("master") is True
    assert checker(func)("develop") is False



# Generated at 2022-06-24 01:34:33.107773
# Unit test for function check
def test_check():

    # set os.environ so that travis_checker() is called when
    # check() function is called
    os.environ['TRAVIS'] = 'true'
    # set branch to master in os.environ
    os.environ['TRAVIS_BRANCH'] = 'master'
    # set a PR
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'

    # call check() function

# Generated at 2022-06-24 01:34:33.998243
# Unit test for function travis
def test_travis():
    assert travis("test") is True

test_travis()


# Generated at 2022-06-24 01:34:39.937543
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    #os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    assert check() == True


# Generated at 2022-06-24 01:34:41.102218
# Unit test for function circle
def test_circle():
    assert not circle



# Generated at 2022-06-24 01:34:42.448982
# Unit test for function check
def test_check():
    """
    Unit test for function check
    """
    assert check(branch="testing")

# Generated at 2022-06-24 01:34:47.564379
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    check("master")
    os.environ["BITBUCKET_BRANCH"] = "feature"
    try:
        check("master")
    except CiVerificationError:
        pass


# Generated at 2022-06-24 01:34:48.716913
# Unit test for function circle
def test_circle():
    assert os.environ["CIRCLECI"] == True
    # circle()

# Generated at 2022-06-24 01:34:57.028769
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    os.environ["BUILD_NUMBER"] = "any"

    ci_lock_check()

    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]
    del os.environ["BUILD_NUMBER"]


# Generated at 2022-06-24 01:34:58.377414
# Unit test for function frigg
def test_frigg():
    assert frigg("master") is True


# Generated at 2022-06-24 01:35:07.617168
# Unit test for function jenkins
def test_jenkins():
    # GIVEN nothing
    # WHEN there are no environment variables
    # THEN the check should return True
    assert jenkins() is None

    # GIVEN nothing
    # WHEN there is an environment variable for BRANCH_NAME
    os.environ['JENKINS_URL'] = 'JENKINS_URL'
    os.environ['BRANCH_NAME'] = 'master'
    # THEN the check should return True
    assert jenkins() is True

    # GIVEN a pull request environment
    # WHEN there is an environment variable for CHANGE_ID
    os.environ['CHANGE_ID'] = 'CHANGE_ID'
    # THEN the check should raise a CiVerificationError

# Generated at 2022-06-24 01:35:11.585949
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert travis('master')


# Generated at 2022-06-24 01:35:12.475438
# Unit test for function check
def test_check():
    assert check(branch="master") == True

# Generated at 2022-06-24 01:35:14.257622
# Unit test for function check
def test_check():
    try:
        check()
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:35:23.499518
# Unit test for function circle
def test_circle():
    """
    Unit test for function circle
    """
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    try:
        circle("master")
        raise AssertionError("The release should not have been created")
    except CiVerificationError as e:
        assert "The verification check for the environment did not pass." == str(e)



# Generated at 2022-06-24 01:35:27.835248
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "1"
    check("master")



# Generated at 2022-06-24 01:35:30.562460
# Unit test for function checker
def test_checker():
    from semantic_release.hvcs import check
    from semantic_release.errors import CiVerificationError

    check = checker(check)

    try:
        check()
    except CiVerificationError:
        assert False
    else:
        assert True

    try:
        check()
    except AssertionError:
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-24 01:35:34.411050
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '12345'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = 'None'
    check()



# Generated at 2022-06-24 01:35:46.076715
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError as e:
        assert (
            "The verification check for the environment did not pass."
            in str(e)
        )
        del os.environ["BITBUCKET_BRANCH"]
        del os.environ["BITBUCKET_PR_ID"]

    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""

# Generated at 2022-06-24 01:35:48.729528
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('master')


# Generated at 2022-06-24 01:35:52.126481
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'frigg_master'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    frigg('frigg_master')



# Generated at 2022-06-24 01:36:02.200178
# Unit test for function check
def test_check():
    """
    Tests whether the function ``check`` raises an exception when the
    correct environment variables are not set.
    """
    os.environ.pop("TRAVIS", None)
    os.environ.pop("SEMAPHORE", None)
    os.environ.pop("FRIGG", None)
    os.environ.pop("CIRCLECI", None)
    os.environ.pop("GITLAB_CI", None)
    os.environ.pop("JENKINS_URL", None)
    os.environ.pop("BITBUCKET_BUILD_NUMBER", None)

    # Lack of environment variables should not raise an exception
    check()

    # Set travis environment variables and rerun
    os.environ["TRAVIS"] = "true"

# Generated at 2022-06-24 01:36:07.147533
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")

# Generated at 2022-06-24 01:36:16.093316
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch="master")
    assert os.environ["TRAVIS_BRANCH"] == "master"
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

# Generated at 2022-06-24 01:36:18.695612
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    check()



# Generated at 2022-06-24 01:36:26.702086
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("master") == True
    os.environ["BRANCH_NAME"] = "notmaster"
    assert jenkins("master") == False
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "1122"
    assert jenkins("master") == False
    os.environ["CHANGE_ID"] = None
    os.environ["JENKINS_URL"] = None
    assert jenkins("master") == False

# Generated at 2022-06-24 01:36:34.027081
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master") is True
    os.environ["TRAVIS_BRANCH"] = "dev"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master") is False
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    assert travis("master") is False



# Generated at 2022-06-24 01:36:36.710118
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "2"
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")

# Generated at 2022-06-24 01:36:37.950241
# Unit test for function jenkins
def test_jenkins():
    assert os.environ.get("JENKINS_URL") is not None

# Generated at 2022-06-24 01:36:47.086510
# Unit test for function gitlab
def test_gitlab():
    """
    :return: the environment variable GITLAB_CI of the CI system GitLab
    """
    # Set GITLAB_CI to True
    os.environ["GITLAB_CI"] = "true"
    # Set CI_COMMIT_REF_NAME to master
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    # Set CHANGE_ID to None
    os.environ["CHANGE_ID"] = None
    # If a branch is provided e.g., master, check for GITLAB_CI and CI_COMMIT_REF_NAME
    # and return true. Otherwise, return false.
    try:
        gitlab("master")
        return True
    except CiVerificationError:
        return False
    # Ensure that the test fails if the branch is not master

# Generated at 2022-06-24 01:36:49.986464
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket('master')
    assert not bitbucket('develop')

# Generated at 2022-06-24 01:37:00.917942
# Unit test for function gitlab
def test_gitlab():

    os.environ.update(
        {
            # Branch Name
            "CI_COMMIT_REF_NAME": "master",
            "CI_COMMIT_REF_NAME_CHANGED": "False",
            # Pull Request
            "CI_MERGE_REQUEST_ID": "",
            "CI_MERGE_REQUEST_SOURCE_BRANCH_NAME": "",
            "CI_MERGE_REQUEST_TARGET_BRANCH_NAME": "",
            # Pipeline BRANCH
            "CI_PIPELINE_SOURCE": "",
            "CI_PIPELINE_SOURCE_CHANGED": "",
            "CI_PIPELINE_TRIGGERED": "",
        }
    )

    gitlab(branch="master")

# Generated at 2022-06-24 01:37:10.331223
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    del os.environ["TRAVIS_PULL_REQUEST"]
    check()
    del os.environ["TRAVIS_BRANCH"]

    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]



# Generated at 2022-06-24 01:37:12.587901
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "master"
    check()

# Generated at 2022-06-24 01:37:17.253619
# Unit test for function semaphore
def test_semaphore():
    os.environ['SEMAPHORE'] = "true"
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    try:
        semaphore('master')
    except AssertionError:
        raise AssertionError("function semaphore failed")


# Generated at 2022-06-24 01:37:19.480279
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://localhost:8080"
    os.environ["GIT_BRANCH"] = "test"
    os.environ["CHANGE_ID"] = "test"
    jenkins("test")

# Generated at 2022-06-24 01:37:24.079316
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-24 01:37:28.629213
# Unit test for function bitbucket
def test_bitbucket():
    # Setup
    os.environ["BITBUCKET_BUILD_NUMBER"] = "true"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = 'False'
    # Exercise
    # Assert
    try:
        bitbucket("master")
    except CiVerificationError as e:
        raise e


# Generated at 2022-06-24 01:37:37.268840
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "http://jenkins.io"
    os.environ["CHANGE_ID"] = None
    jenkins("master")
    del os.environ["CHANGE_ID"]
    del os.environ["BRANCH_NAME"]
    del os.environ["GIT_BRANCH"]
    del os.environ["JENKINS_URL"]

# Generated at 2022-06-24 01:37:42.440989
# Unit test for function checker
def test_checker():
    @checker
    def test_func(raise_exception):
        if raise_exception:
            raise AssertionError()
    test_func(raise_exception=False)
    try:
        test_func(raise_exception=True)
    except CiVerificationError:
        pass
    else:
        raise AssertionError(
            "Expected CiVerificationError was not raised"
        )



# Generated at 2022-06-24 01:37:47.634240
# Unit test for function checker
def test_checker():
    with checker(lambda x: "b" in x)("abc"):
        pass
    try:
        with checker(lambda x: "d" in x)("abc"):
            pass
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not raised")

# Generated at 2022-06-24 01:37:53.166545
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    check()
    assert frigg("master") is True
    del os.environ["FRIGG"]

# Generated at 2022-06-24 01:37:58.309368
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "1234"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    assert jenkins("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["CHANGE_ID"]
    del os.environ["GIT_BRANCH"]
    del os.environ["JENKINS_URL"]
    assert jenkins("master")

# Generated at 2022-06-24 01:37:59.789155
# Unit test for function check
def test_check():
    check()

# Generated at 2022-06-24 01:38:10.199834
# Unit test for function check
def test_check():
    test_travis = os.environ.get("TRAVIS")
    test_semaphore = os.environ.get("SEMAPHORE")
    test_frigg = os.environ.get("FRIGG")
    test_circle = os.environ.get("CIRCLECI")
    test_gitlab = os.environ.get("GITLAB_CI")
    test_jenkins = os.environ.get("JENKINS_URL")
    test_bitbucket = os.environ.get("BITBUCKET_BUILD_NUMBER")

    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check

# Generated at 2022-06-24 01:38:20.089395
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "test"
    os.environ["BITBUCKET_BRANCH"] = "test"
    os.environ["BITBUCKET_PR_ID"] = "test"
    bitbucket("test")
    os.environ["BITBUCKET_BRANCH"] = "test2"
    try:
        bitbucket("test")
        assert False
    except CiVerificationError:
        assert True
    os.environ.pop("BITBUCKET_PR_ID")
    bitbucket("test2")
    os.environ.pop("BITBUCKET_BUILD_NUMBER")
    os.environ.pop("BITBUCKET_BRANCH")



# Generated at 2022-06-24 01:38:23.551365
# Unit test for function checker
def test_checker():
    """
    Check that checker handles functions correctly
    """
    @checker
    def failing_function():
        raise AssertionError
    @checker
    def passing_function():
        pass

    assert failing_function() is True
    assert passing_function() is True



# Generated at 2022-06-24 01:38:26.370883
# Unit test for function frigg
def test_frigg():
    check = frigg("master")
    assert check is True


# Generated at 2022-06-24 01:38:29.610758
# Unit test for function semaphore
def test_semaphore():
    func = lambda :semaphore("master")
    func()

# Generated at 2022-06-24 01:38:33.372383
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "branch"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("branch")



# Generated at 2022-06-24 01:38:36.612938
# Unit test for function circle
def test_circle():
    """
    Unit test for function circle
    :return:
    """
    branch = 'master'
    os.environ["CIRCLE_BRANCH"] = branch
    os.environ["CI_PULL_REQUEST"] = "false"
    circle(branch)



# Generated at 2022-06-24 01:38:40.651027
# Unit test for function frigg
def test_frigg():
    assert os.environ.get("FRIGG") == "true"
    
    if os.environ.get("FRIGG") == "true":
        frigg("master")
        frigg("dev")
        frigg("release/v1.2.3")


# Generated at 2022-06-24 01:38:50.189988
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    try:
        travis('master')
    except CiVerificationError:
        pass
    assert 'TRAVIS_PULL_REQUEST' in os.environ, 'Environment variable not deleted'
    assert os.environ['TRAVIS_PULL_REQUEST'] == 'true', 'Environment variable not deleted'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    try:
        travis('master')
        os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    except CiVerificationError:
        pass
    assert 'TRAVIS_PULL_REQUEST' in os.environ, 'Environment variable not deleted'

# Generated at 2022-06-24 01:38:54.974377
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    with pytest.raises(CiVerificationError):
        travis("feature")
    travis("master")


# Generated at 2022-06-24 01:39:01.930988
# Unit test for function circle
def test_circle():
    circle.__wrapped__("master")

    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"

    check()
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]

    with pytest.raises(CiVerificationError):
        check()



# Generated at 2022-06-24 01:39:04.205870
# Unit test for function travis
def test_travis():
    import os
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis('master')



# Generated at 2022-06-24 01:39:09.327009
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-24 01:39:12.168140
# Unit test for function semaphore
def test_semaphore():
    os.environ['SEMAPHORE'] = "true"
    os.environ['BRANCH_NAME'] = "master"
    os.environ['SEMAPHORE_THREAD_RESULT'] = "passed"
    assert semaphore("master") == True



# Generated at 2022-06-24 01:39:21.918141
# Unit test for function circle
def test_circle():
    """
    Test the function circle
    """

    # test case 1:
    # all checks passed
    os.environ["CIRCLE_BRANCH"] = "master dev"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle()

    # test case 2:
    # the branch does not match
    os.environ["CIRCLE_BRANCH"] = "dev"
    os.environ["CI_PULL_REQUEST"] = ""
    try:
        circle()
    except CiVerificationError:
        assert True
    else:
        assert False

    # test case 3:
    # pull request is present
    os.environ["CIRCLE_BRANCH"] = "master dev"
    os.environ["CI_PULL_REQUEST"] = "127"
