

# Generated at 2022-06-24 01:29:24.832800
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://localhost:8080/jenkins/"

    for key in ["GIT_BRANCH", "BRANCH_NAME", "CHANGE_ID", "PULL_REQUEST_ID"]:
        if key in os.environ:
            os.environ.pop(key)

    check("master")

    os.environ["BRANCH_NAME"] = "dev"

    os.environ["CHANGE_ID"] = "1234"
    check("dev")

    os.environ["CHANGE_ID"] = "1234"
    os.environ["BRANCH_NAME"] = "dev"
    check("dev")

    os.environ["GIT_BRANCH"] = "dev"
    check("dev")


# Generated at 2022-06-24 01:29:26.443470
# Unit test for function check
def test_check():
    """
    CI Checks
    """
    check("master")

# Generated at 2022-06-24 01:29:35.098249
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch="master")

    with open("./change_log.md", "w"):
        pass

    with open("./tag_log.md", "w"):
        pass

    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS_PULL_REQUEST_SLUG"] = "fake/pr_repo"
    travis(branch="master")
    os.environ["TRAVIS_PULL_REQUEST_SLUG"] = ""


# Generated at 2022-06-24 01:29:39.794242
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "feature"
    try:
        frigg("master")
    except CiVerificationError:
        os.environ.pop("FRIGG")
        os.environ.pop("FRIGG_BUILD_BRANCH")
        os.environ.pop("FRIGG_PULL_REQUEST")
        return
    raise AssertionError


# Generated at 2022-06-24 01:29:49.034878
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = ''
    try:
        check()
    except CiVerificationError:
        assert False
    os.environ['CIRCLE_BRANCH'] = 'test'
    try:
        check()
        assert False
    except CiVerificationError:
        pass
    os.environ['CI_PULL_REQUEST'] = 'https://github.com/julien-pontabry/semantic-release/pull/74'
    try:
        check()
        assert False
    except CiVerificationError:
        pass



# Generated at 2022-06-24 01:30:01.656243
# Unit test for function check
def test_check():
    """
    Tests the check function.
    """
    os.environ["JENKINS_URL"] = "http://jenkins.com"
    os.environ["SEMAPHORE"] = "true"
    os.environ["GITLAB_CI"] = "true"
    os.environ["CIRCLECI"] = "true"
    os.environ["FRIGG"] = "true"
    os.environ["TRAVIS"] = "true"
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"

    os.environ["TRAVIS_BRANCH"] = "mybranch"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_BRANCH"] = "mybranch"

# Generated at 2022-06-24 01:30:05.146900
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")



# Generated at 2022-06-24 01:30:12.231243
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '1'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = '123'
    bitbucket('master')
    del os.environ['BITBUCKET_BUILD_NUMBER']


# Generated at 2022-06-24 01:30:24.417666
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_BRANCH"] = "master"
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CI_PULL_REQUEST"]
    del os.environ["CIRCLE_BRANCH"]

    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    try:
        check()
    except CiVerificationError:
        del os.environ["CIRCLECI"]

# Generated at 2022-06-24 01:30:35.878746
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()

    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = None
    check()

    os

# Generated at 2022-06-24 01:30:42.452814
# Unit test for function bitbucket
def test_bitbucket():
    def fake_environ(d):
        def fake_environ(key, default=None):
            if key in d:
                return d[key]
            else:
                return default
        return fake_environ
    # os.getenv should return defaults
    assert os.getenv('TRAVIS', None) is None
    assert os.getenv('BITBUCKET', None) is None
    # It should fail if the PR id is set
    os.environ = fake_environ({'BITBUCKET_PULL_REQUEST_ID': '123'})
    try:
        bitbucket('master')
        assert False
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."
    # It should pass if the PR id is not set

# Generated at 2022-06-24 01:30:44.181943
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    check()

# Generated at 2022-06-24 01:30:48.349181
# Unit test for function jenkins
def test_jenkins():
    """Test function jenkins"""
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "True"
    jenkins(branch="master")
    del os.environ["JENKINS_URL"]



# Generated at 2022-06-24 01:30:54.037230
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"]="master"
    assert bitbucket("master") == True
    os.environ["BITBUCKET_BRANCH"]="dev"
    assert bitbucket("dev") == True
    os.environ["BITBUCKET_BRANCH"]="master"
    os.environ["BITBUCKET_PR_ID"]="1"
    assert bitbucket("dev") == False

# Generated at 2022-06-24 01:30:57.644768
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")


# Generated at 2022-06-24 01:31:02.696333
# Unit test for function checker
def test_checker():

    @checker
    def check_fail():
        assert False

    try:
        check_fail()
        assert False
    except CiVerificationError:
        assert True


# Unit tests for CI environments

# Generated at 2022-06-24 01:31:14.442785
# Unit test for function jenkins
def test_jenkins():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['JENKINS_URL'] = 'https://jenkins.com'
    os.environ['GIT_BRANCH'] = ''
    os.environ['CHANGE_ID'] = ''
    jenkins('master')
    os.environ['BRANCH_NAME'] = 'develop'
    os.environ['JENKINS_URL'] = 'https://jenkins.com'
    os.environ['GIT_BRANCH'] = ''
    os.environ['CHANGE_ID'] = ''
    with pytest.raises(CiVerificationError) as err:
        jenkins('master')
    assert err.value.message == "The verification check for the environment did not pass."
    os.environ

# Generated at 2022-06-24 01:31:17.435221
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['CI_PULL_REQUEST'] = 'false'
    try:
        check()
    except CiVerificationError:
        assert False
    assert True


# Generated at 2022-06-24 01:31:20.717087
# Unit test for function check
def test_check():
    assert check("master") == True

# test for travis

# Generated at 2022-06-24 01:31:24.359694
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    # No exception should raise.
    check()


# Generated at 2022-06-24 01:31:29.755672
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PUSH'] = 'true'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    check()
    assert True


# Generated at 2022-06-24 01:31:35.710234
# Unit test for function travis
def test_travis():
    try:
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        travis(os.environ["TRAVIS_BRANCH"])
    except CiVerificationError:
        assert False, "Test failed"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis(os.environ["TRAVIS_BRANCH"])
        assert False, "Test failed"
    except CiVerificationError:
        pass


# Generated at 2022-06-24 01:31:40.314138
# Unit test for function checker
def test_checker():
    checker_func = checker(lambda: False)
    with pytest.raises(CiVerificationError):
        checker_func()

    checker_func = checker(lambda: True)
    assert checker_func() == True


# Unit tests for function travis

# Generated at 2022-06-24 01:31:42.414820
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = '22'
    bitbucket('master')

# Generated at 2022-06-24 01:31:45.597321
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = "develop"
    bitbucket("master")

# Generated at 2022-06-24 01:31:48.276846
# Unit test for function checker
def test_checker():
    @checker
    def testfunction(branch):
        assert branch == "master"
        raise AssertionError()

    from semantic_release.errors import CiVerificationError

    try:
        testfunction("master")
    except CiVerificationError as cive:
        assert cive.args[0] == "The verification check for the environment did not pass."

# Generated at 2022-06-24 01:31:51.765347
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1234"
    os.environ["BITBUCKET_BRANCH"] = "master"
    check()

# Generated at 2022-06-24 01:32:00.517463
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = ""  # pull request id
    jenkins(branch="master")
    os.environ["BRANCH_NAME"] = "develop"
    try:
        jenkins(branch="master")
    except CiVerificationError:
        os.environ.pop("JENKINS_URL")
        os.environ.pop("BRANCH_NAME")
        os.environ.pop("CHANGE_ID")
        return
    raise AssertionError

# Generated at 2022-06-24 01:32:07.488232
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    assert bitbucket('master') == True
    del os.environ['BITBUCKET_BRANCH']

    os.environ['BITBUCKET_BRANCH'] = 'master'
    assert bitbucket('testing') == False
    del os.environ['BITBUCKET_BRANCH']

    os.environ['BITBUCKET_BRANCH'] = 'testing'
    os.environ['BITBUCKET_PR_ID'] = '123'
    assert bitbucket('master') == False
    del os.environ['BITBUCKET_BRANCH']
    del os.environ['BITBUCKET_PR_ID']

# Generated at 2022-06-24 01:32:11.980830
# Unit test for function travis
def test_travis():
    assert checker(travis)("master") is True
    assert checker(travis)("not master") is False


# Generated at 2022-06-24 01:32:18.713951
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert checker(semaphore)("master") == True
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert checker(semaphore)("master") == False
    os.environ["BRANCH_NAME"] = "other"
    assert checker(semaphore)("master") == False



# Generated at 2022-06-24 01:32:26.632143
# Unit test for function frigg
def test_frigg():
    """
    This function removes the environment variables for travis, frigg and semaphore,
    sets the frigg environment variables and tests whether frigg is the CI detected
    and that the function frigg-checker runs.
    """
    del os.environ["TRAVIS"]
    del os.environ["SEMAPHORE"]
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert check()



# Generated at 2022-06-24 01:32:32.384383
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "some_url"
    os.environ["GIT_BRANCH"] = "some_branch"
    os.environ["CHANGE_ID"] = "1234"
    jenkins("some_branch")
    os.environ.pop("CHANGE_ID")
    jenkins("some_branch")
    os.environ.pop("JENKINS_URL")


# Generated at 2022-06-24 01:32:39.558920
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1234"
    os.environ["BITBUCKET_BRANCH"] = "develop"
    bitbucket("develop")
    assert os.environ.get("BITBUCKET_PR_ID") == None
    os.environ["BITBUCKET_PR_ID"] = "1324"
    with pytest.raises(CiVerificationError):
        bitbucket("develop")

# Generated at 2022-06-24 01:32:45.204906
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    circle("branch")

# Generated at 2022-06-24 01:32:55.023131
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "true"
    branch = "master"
    try:
        circle(branch)
    except CiVerificationError:
        pass
    else:
        raise AssertionError("CiVerificationError not being raised when expected.")

    os.environ["CI_PULL_REQUEST"] = ""
    try:
        circle(branch)
    except CiVerificationError:
        raise AssertionError("CiVerificationError raised when not expected.")



# Generated at 2022-06-24 01:32:57.626223
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    os.environ["BRANCH_NAME"] = "dev"
    assert not semaphore("master")

# Generated at 2022-06-24 01:33:06.880560
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'

    # Correct branch
    frigg('master')
    assert 'FRIGG' in os.environ

    # Incorrect branch
    try:
        frigg('develop')
        assert 'FRIGG' in os.environ
    except:
        assert 'FRIGG' in os.environ
        assert True

    # Pull request
    os.environ['FRIGG_PULL_REQUEST'] = '123'
    try:
        frigg('master')
        assert 'FRIGG' in os.environ
    except:
        assert 'FRIGG' in os.environ
        assert True

    del os.environ['FRIGG_PULL_REQUEST']
    del os.environ['FRIGG']


# Generated at 2022-06-24 01:33:16.189643
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg(branch="develop")
    os.environ["FRIGG_BUILD_BRANCH"] = "notdevelop"
    try:
        frigg(branch="develop")
        assert False, "Should have raised an error"
    except CiVerificationError:
        pass
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        frigg(branch="develop")
        assert False, "Should have raised an error"
    except CiVerificationError:
        pass
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os

# Generated at 2022-06-24 01:33:27.521724
# Unit test for function checker
def test_checker():
    class TestException(Exception):
        pass
    
    def test1():
        raise AssertionError()

    def test2():
        raise TestException()

    @checker
    def test3():
        raise AssertionError()

    @checker
    def test4():
        raise TestException()

    # AssertionError
    try:
        test1()
    except CiVerificationError:
        pass
    else:
        assert False

    # TestException
    try:
        test2()
    except CiVerificationError:
        assert False
    except TestException:
        pass
    else:
        assert False

    # AssertionError
    try:
        test3()
    except CiVerificationError:
        pass
    else:
        assert False

    # TestException

# Generated at 2022-06-24 01:33:33.867392
# Unit test for function travis
def test_travis():
    try:
        os.environ["TRAVIS_BRANCH"] = ""
        os.environ["TRAVIS_PULL_REQUEST"] = ""
        travis(branch=None)
        assert False
    except CiVerificationError:
        pass

    try:
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        travis(branch="master")
        assert True
    except AssertionError:
        assert False



# Generated at 2022-06-24 01:33:40.785906
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    circle("master")
    os.environ["CIRCLE_BRANCH"] = "different-branch"
    try:
        circle("master")
        assert False
    except CiVerificationError:
        assert True
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]



# Generated at 2022-06-24 01:33:43.862755
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"]  = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    assert gitlab("master")



# Generated at 2022-06-24 01:33:44.441992
# Unit test for function check
def test_check():
    assert check("release")

# Generated at 2022-06-24 01:33:53.354504
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master") == False
    del os.environ["SEMAPHORE_THREAD_RESULT"]
    os.environ["BRANCH_NAME"] = "wrong"
    assert semaphore("master") == False
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    assert semaphore("master") == False
    del os.environ["PULL_REQUEST_NUMBER"]
    assert semaphore("master") == True


# Generated at 2022-06-24 01:34:05.106106
# Unit test for function check
def test_check():
    """
    Test check by doing an end to end run with all of CI providers.
    """
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None

# Generated at 2022-06-24 01:34:13.959976
# Unit test for function frigg
def test_frigg():
    # Test if there is an error when both variables are true
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        frigg()
    except CiVerificationError:
        pass
    else:
        raise Exception
    # Test if there is an error when branch_name and branch is not the same
    os.environ["FRIGG_BUILD_BRANCH"] = "other-branch"
    try:
        frigg()
    except CiVerificationError:
        pass
    else:
        raise Exception
    # Test if there is an error when pull request is empty
    os.environ["FRIGG_BUILD_BRANCH"] = "master"

# Generated at 2022-06-24 01:34:18.802577
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = None
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "http://example.com"
    os.environ["CHANGE_ID"] = None
    assert jenkins("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["CHANGE_ID"]
    del os.environ["JENKINS_URL"]
    del os.environ["GIT_BRANCH"]


# Generated at 2022-06-24 01:34:23.997186
# Unit test for function semaphore
def test_semaphore():
    os.environ.clear()
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'success'
    os.environ['SEMAPHORE'] = 'True'

    assert semaphore('master') == True
    os.environ.clear()


# Generated at 2022-06-24 01:34:28.256933
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg(branch="master")

# Generated at 2022-06-24 01:34:32.675047
# Unit test for function semaphore
def test_semaphore():
    """
    Check that we are on master branch and we are not in a pull request
    """
    os.environ["BRANCH_NAME"] = 'master'
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    ciCheck =semaphore('master')
    assert ciCheck == True

# Generated at 2022-06-24 01:34:35.888994
# Unit test for function semaphore
def test_semaphore():
    assert os.environ.get("BRANCH_NAME") == "master"
    assert os.environ.get("PULL_REQUEST_NUMBER") is None
    assert os.environ.get("SEMAPHORE_THREAD_RESULT") != "failed"
    assert semaphore("master")

# Generated at 2022-06-24 01:34:42.039134
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("develop")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]



# Generated at 2022-06-24 01:34:44.976630
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "CI_COMMIT_REF_NAME"
    gitlab("CI_COMMIT_REF_NAME")
    os.environ.clear()

# Generated at 2022-06-24 01:34:53.541467
# Unit test for function bitbucket
def test_bitbucket():
    env = {}
    bitbucket(branch="master")

    os.environ['BITBUCKET_BUILD_NUMBER'] = ''
    os.environ['BITBUCKET_BRANCH'] = ''
    bitbucket(branch="master")
    os.environ['BITBUCKET_BRANCH'] = 'master'
    bitbucket(branch="master")
    os.environ['BITBUCKET_BRANCH'] = 'production'
    bitbucket(branch="master")
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = 'dummy'
    bitbucket(branch="master")
    del os.environ['BITBUCKET_PR_ID']


# Unit

# Generated at 2022-06-24 01:34:58.178290
# Unit test for function gitlab
def test_gitlab():
    branch = "master"
    os.environ['CI_COMMIT_REF_NAME'] = branch
    try:
        gitlab(branch)
    except CiVerificationError as e:
        assert str(e) == 'The verification check for the environment did not pass.'

# Generated at 2022-06-24 01:34:59.862894
# Unit test for function jenkins
def test_jenkins():
    assert not jenkins(branch='master')
    assert not jenkins(branch='release')


# Generated at 2022-06-24 01:35:07.686722
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = ''
    frigg('master')
    os.environ['FRIGG_BUILD_BRANCH'] = 'dev'
    os.environ['FRIGG_PULL_REQUEST'] = ''
    try:
        frigg('master')
    except CiVerificationError:
        os.environ.pop('FRIGG_BUILD_BRANCH')
        os.environ.pop('FRIGG_PULL_REQUEST')
        return 
    assert False


# Generated at 2022-06-24 01:35:15.897244
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert bitbucket(branch="master") is True
    os.environ["BITBUCKET_BRANCH"] = "develop"
    assert bitbucket(branch="master") is False
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    assert bitbucket(branch="master") is False
    del os.environ["BITBUCKET_PR_ID"]
    del os.environ["BITBUCKET_BRANCH"]

# Generated at 2022-06-24 01:35:23.072551
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")
    assert "BITBUCKET_PR_ID" not in os.environ
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_BUILD_NUMBER"]



# Generated at 2022-06-24 01:35:27.173763
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    os.environ["PULL_REQUEST_NUMBER"] = ""

    semaphore("master")


# Generated at 2022-06-24 01:35:32.438829
# Unit test for function frigg
def test_frigg():
    # Setup environment
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "true"

    # Checks
    assert not check(branch="master")
    del os.environ["FRIGG_PULL_REQUEST"]
    assert check(branch="master")



# Generated at 2022-06-24 01:35:40.725149
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "org/repo"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["PULL_REQUEST_NUMBER"] = "1234_1245"
    try:
        semaphore("org/repo")
        raise Exception('Assertion error not raised')
    except CiVerificationError:
        os.environ["PULL_REQUEST_NUMBER"] = None
        semaphore("org/repo")
  

# Generated at 2022-06-24 01:35:49.892508
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    bitbucket("master")

    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = None
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    bitbucket("master")
    os.environ["BITBUCKET_PR_ID"] = "123"
    bitbucket("master")

# Generated at 2022-06-24 01:35:57.262694
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = 'https://jenkins.com'
    os.environ['GIT_BRANCH'] = 'test'
    os.environ['CHANGE_ID'] = 'test'
    jenkins('test')
    #  unset environment variables
    if os.environ.get('JENKINS_URL'):
        del os.environ['JENKINS_URL']
    if os.environ.get('GIT_BRANCH'):
        del os.environ['GIT_BRANCH']
    if os.environ.get('CHANGE_ID'):
        del os.environ['CHANGE_ID']

# Generated at 2022-06-24 01:36:01.674544
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")

    os.environ["BITBUCKET_PR_ID"] = "2"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass

    os.environ["BITBUCKET_BRANCH"] = "devel"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:36:04.296049
# Unit test for function checker
def test_checker():
    @checker
    def foo():
        raise AssertionError()

    try:
        foo()
    except CiVerificationError:
        pass
    else:
        assert False



# Generated at 2022-06-24 01:36:10.044370
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_REF"] = "refs/heads/master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket()
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket()
    except CiVerificationError:
        assert True
        return
    assert False

# Generated at 2022-06-24 01:36:12.215384
# Unit test for function check
def test_check():
    assert check(branch="7.0")
    assert check(branch="8.0")

# Generated at 2022-06-24 01:36:20.290805
# Unit test for function bitbucket
def test_bitbucket():
    """Unit test for function bitbucket."""
    # no exception raised
    os.environ['BITBUCKET_BUILD_NUMBER'] = "1"
    os.environ['BITBUCKET_BRANCH'] = "master"
    bitbucket('master')
    del os.environ['BITBUCKET_BRANCH']

    # raises assert exception
    os.environ['BITBUCKET_BRANCH'] = "develop"
    raised = False
    try:
        bitbucket('master')
    except AssertionError:
        raised = True
    assert raised

    # raises CiVerificationError
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_PR_ID'] = "1234"
    raised = False


# Generated at 2022-06-24 01:36:31.804369
# Unit test for function jenkins
def test_jenkins():
    import mock
    assert not jenkins("master")
    #with mock.patch.dict(os.environ, {}):
    #    assert not jenkins("master")
    #with mock.patch.dict(os.environ, {"BRANCH_NAME": "master"}):
    #    assert jenkins("master")
    with mock.patch.dict(os.environ, {"GIT_BRANCH": "master"}):
        assert jenkins("master")
    with mock.patch.dict(os.environ, {"GIT_BRANCH": "not-master"}):
        assert not jenkins("master")
    with mock.patch.dict(os.environ, {"JENKINS_URL": "https://jenkins.example.com/"}):
        assert not jenkins("master")

# Generated at 2022-06-24 01:36:42.386988
# Unit test for function gitlab
def test_gitlab():
    """
    Performs necessary checks to ensure that the gitlab build is one
    that should create releases.

    :param branch: The branch the environment should be running against.
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    try:
        gitlab(branch="master")
    except AssertionError:
        assert False
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    try:
        gitlab(branch="master")
    except CiVerificationError:
        assert True
    except AssertionError:
        assert False
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = "2"

# Generated at 2022-06-24 01:36:45.556220
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    semaphore(branch="master")
    os.environ["BRANCH_NAME"] = "feature/test"
    semaphore(branch="master")


# Generated at 2022-06-24 01:36:51.396829
# Unit test for function checker
def test_checker():
    @checker
    def test_func(branch):
        assert branch == "master"

    try:
        test_func("master")
    except:
        raise AssertionError

    try:
        test_func("test")
    except CiVerificationError:
        pass  # exception expected
    except:
        raise AssertionError



# Generated at 2022-06-24 01:36:56.553923
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test-branch"
    assert frigg("test-branch") == True
    os.environ["FRIGG_PULL_REQUEST"] = True
    assert frigg("test-branch") == False

# Generated at 2022-06-24 01:37:03.157174
# Unit test for function gitlab
def test_gitlab():
  os.environ['CI_COMMIT_REF_NAME'] = 'master'
  os.environ['CI_MERGE_REQUEST_IID'] = ''
  gitlab(branch='master')
  os.environ['CI_COMMIT_REF_NAME'] = 'test'
  gitlab(branch='master')
  os.environ['CI_COMMIT_REF_NAME'] = 'master'
  os.environ['CI_MERGE_REQUEST_IID'] = '1'
  gitlab(branch='master')

# Generated at 2022-06-24 01:37:07.578333
# Unit test for function bitbucket
def test_bitbucket():
        assert not bitbucket("master")
        os.environ["BITBUCKET_BUILD_NUMBER"] = str(1)
        os.environ["BITBUCKET_BRANCH"] = "master"
        assert bitbucket("master")
        del os.environ["BITBUCKET_BRANCH"]
        del os.environ["BITBUCKET_BRANCH"]



# Generated at 2022-06-24 01:37:17.227087
# Unit test for function circle
def test_circle():
    c = circle
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    os.environ["CIRCLE_BRANCH"] = "pull/123/merge"
    os.environ["CI_PULL_REQUEST"] = "123"
    c("master")
    c("pull/123/merge")
    assert circle("master")
    assert not circle("not-master")
    assert not circle("pull/not-123/merge")
    assert circle("pull/123/merge")
    assert not circle("pull/not-123/merge")
    del os.environ["CIRCLECI"]

# Generated at 2022-06-24 01:37:22.032111
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check("master")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check("master")
    except CiVerificationError:
        assert True
    else:
        assert False

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    try:
        check("master")
    except CiVerificationError:
        assert True
    else:
        assert False

    os.environ

# Generated at 2022-06-24 01:37:29.643436
# Unit test for function check
def test_check():
    """
    Testing check function
    """
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    assert check()

    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PULL_REQUEST"] = "true"
    try:
        check()
    except CiVerificationError as cve:
        assert str(cve) == "The verification check for the environment did not pass."

    del os.environ["GITLAB_CI"]
    os.environ["TRAVIS"] = "true"

# Generated at 2022-06-24 01:37:35.621518
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()
    os.environ.pop("CI_COMMIT_REF_NAME", None)
    os.environ.pop("CI_MERGE_REQUEST_ID", None)


# Generated at 2022-06-24 01:37:43.663673
# Unit test for function frigg
def test_frigg():
    # Successful branch check
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "0"

    check()
    assert True

    # branch check failure
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    try:
        check()
        assert False
    except CiVerificationError:
        assert True
        # Clear out environment variable once assertion is done.
        del os.environ["FRIGG_BUILD_BRANCH"]

    # pull-request check failure
    os.environ["FRIGG_PULL_REQUEST"] = "1"

# Generated at 2022-06-24 01:37:48.341256
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'dev'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert travis("dev")
    assert travis("master") is not True
    assert travis("master") is not None


# Generated at 2022-06-24 01:37:53.121620
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "test_branch"
    semaphore("test_branch")
    del os.environ["SEMAPHORE"]
    del os.environ["BRANCH_NAME"]



# Generated at 2022-06-24 01:37:57.731588
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "release"
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "hotfix"
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "features"
    check()

# Generated at 2022-06-24 01:38:01.341452
# Unit test for function checker
def test_checker():
    """
    Test that checker decorator raises CiVerificationError on AssertionError
    """
    @checker
    def func(*args, **kwargs):
        raise AssertionError()

    try:
        func()
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:38:04.950438
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI"] = "true"
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()

# Generated at 2022-06-24 01:38:13.413248
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "http://jenkins.com"
    os.environ["CHANGE_ID"] = None

    check()

    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "http://jenkins.com"
    os.environ["CHANGE_ID"] = "123"
    
    try:
        check()
        assert False
    except CiVerificationError:
        assert True

    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = None
    os.environ["CHANGE_ID"] = "123"


# Generated at 2022-06-24 01:38:16.959818
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("master")
    os.environ["BRANCH_NAME"]="master"
    assert jenkins("master")
    os.environ["GIT_BRANCH"]="master"
    assert jenkins("master")
    os.environ["CHANGE_ID"]="123"
    assert jenkins("master")

# Generated at 2022-06-24 01:38:19.590833
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master") is True
    assert semaphore("development") is True
    assert semaphore("hw/hw3") is True
    assert semaphore("hw/hw4") is True
    assert semaphore("hw/hw5") is True
    assert semaphore("hw/hw6") is True

# Generated at 2022-06-24 01:38:29.759396
# Unit test for function check
def test_check():
    
    os.environ["TRAVIS_BRANCH"]="master"
    os.environ["TRAVIS_PULL_REQUEST"]="false"
    os.environ["TRAVIS"]="true"
    check("master")
    os.environ["TRAVIS_BRANCH"]="master"
    os.environ["TRAVIS_PULL_REQUEST"]="true"
    os.environ["TRAVIS"]="true"
    try:
        check("master")
        assert True == False 
    except:
        assert True
    os.environ["TRAVIS_BRANCH"]="develop"
    os.environ["TRAVIS_PULL_REQUEST"]="false"
    os.environ["TRAVIS"]="true"

# Generated at 2022-06-24 01:38:37.735430
# Unit test for function bitbucket
def test_bitbucket():
    try:
        bitbucket('master')
        assert False, 'Should have raised a CIVerificationError'
    except CiVerificationError as e:
        assert 'The verification check for the environment did not pass.' in str(e)
        pass

    os.environ['BITBUCKET_BRANCH'] = 'master'

    try:
        bitbucket('master')
        assert False, 'Should have raised a CIVerificationError'
    except CiVerificationError as e:
        assert 'The verification check for the environment did not pass.' in str(e)
        pass

    os.environ['BITBUCKET_PR_ID'] = '1'


# Generated at 2022-06-24 01:38:43.110044
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    assert check()



# Generated at 2022-06-24 01:38:46.344282
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    check()
    os.environ["BITBUCKET_PR_ID"] = None
    check()

# Generated at 2022-06-24 01:38:49.559828
# Unit test for function gitlab
def test_gitlab():
    assert gitlab("master")
    os.environ["CI_COMMIT_REF_NAME"] = "not master"
    assert not gitlab("master")
    os.environ["CI_MERGE_REQUEST_ID"] = "non-none"
    assert not gitlab("master")


# Generated at 2022-06-24 01:39:00.908690
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")
    os.environ["TRAVIS_BRANCH"] = "main"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("main")
    os.environ["TRAVIS_BRANCH"] = "main"
    os.environ["TRAVIS_PULL_REQUEST"] = "1"
    assert not travis("main")
    os.environ["TRAVIS_BRANCH"] = "1"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert not travis("main")

# Generated at 2022-06-24 01:39:04.661983
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
    except AssertionError:
        raise Exception(
            "Travis build should pass for master branch but was not allowed"
        )



# Generated at 2022-06-24 01:39:09.360865
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    checker(gitlab)("master")
    del os.environ['CI_COMMIT_REF_NAME']



# Generated at 2022-06-24 01:39:13.013039
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = True
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore(branch = "master")

# Generated at 2022-06-24 01:39:16.667599
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "10"
    check()

