

# Generated at 2022-06-24 01:29:26.845876
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    assert semaphore('master') == True
    os.environ['BRANCH_NAME'] = 'devel'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    assert semaphore('master') == False
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = '1234'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'

# Generated at 2022-06-24 01:29:30.301305
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = 'closed'
    bitbucket('master')

# Generated at 2022-06-24 01:29:31.654403
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()

# Generated at 2022-06-24 01:29:37.828148
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    assert bitbucket("master") == True
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "9"
    assert bitbucket("master") == False
    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = "9"
    assert bitbucket("master") == False
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]


# Generated at 2022-06-24 01:29:42.125248
# Unit test for function circle
def test_circle():
    env = {
        "CIRCLE_BRANCH": "master",
        "CI_PULL_REQUEST": "",
        "CIRCLECI": "true"
    }
    for env_name, env_value in env.items():
        os.environ[env_name] = env_value
    circle("master")



# Generated at 2022-06-24 01:29:51.237021
# Unit test for function checker
def test_checker():
    """
    Unit test for checker decorator
    """

    # TODO: Need to migrate this to pytest
    def test_success(branch: str):
        assert os.environ["TRAVIS_BRANCH"] == branch

    test_success = checker(test_success)
    assert test_success("branch")

    def test_failure(branch: str):
        assert os.environ["TRAVIS_BRANCH"] == "refs/heads/master"

    test_failure = checker(test_failure)

    try:
        test_failure("branch")
    except CiVerificationError:
        print("test_checker - success")
        pass
    else:
        print("test_checker - fail")

# Generated at 2022-06-24 01:29:55.470672
# Unit test for function travis
def test_travis():
    param_branch = "master"
    try:
        travis(param_branch)
        raise NameError
    except AssertionError:
        assert True
    except NameError:
        assert False


# Generated at 2022-06-24 01:29:58.732469
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch="master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]


# Generated at 2022-06-24 01:30:08.898971
# Unit test for function check
def test_check():
    """
    Tests the check function to ensure it runs the correct checker
    """
    with os.environ:
        os.environ.clear()
        os.environ["TRAVIS"] = "true"
        assert check() == True

        os.environ.clear()
        os.environ["SEMAPHORE"] = "true"
        assert check() == True

        os.environ.clear()
        os.environ["FRIGG"] = "true"
        assert check() == True

        os.environ.clear()
        os.environ["CIRCLECI"] = "true"
        assert check() == True

        os.environ.clear()
        os.environ["GITLAB_CI"] = "true"
        assert check() == True

        os.environ.clear()

# Generated at 2022-06-24 01:30:13.624004
# Unit test for function checker
def test_checker():
    # 1. Decorator will raise on assertion error
    @checker
    def raises(branch: str):
        raise AssertionError("Test")

    try:
        raises("raise")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should raise")

    # 2. Decorator will not raise on pass
    @checker
    def passes(branch: str):
        assert True

    passes("pass")

# Generated at 2022-06-24 01:30:19.837335
# Unit test for function gitlab
def test_gitlab():
    os.environ['GITLAB_CI'] = 'true'
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    check()
    os.environ['CI_COMMIT_REF_NAME'] = 'wrong'
    try:
        check()
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:30:25.937585
# Unit test for function frigg
def test_frigg():
    # Case 1: Environment Variables for Frigg CI is not set
    assert os.environ.get("FRIGG") == "true"
    assert frigg("master") == 1
    # Case 2: Branch name is not the same
    os.environ["FRIGG_BUILD_BRANCH"]="dev"
    assert frigg("master") == 0
    # Case 3: Pull Request is open
    os.environ["FRIGG_BUILD_BRANCH"]="master"
    os.environ["FRIGG_PULL_REQUEST"]="true"
    assert frigg("master") == 0


# Generated at 2022-06-24 01:30:28.875625
# Unit test for function semaphore
def test_semaphore():
    assert os.environ.get("SEMAPHORE") == "true"
    assert os.environ.get("BRANCH_NAME") == "master"
    assert os.environ.get("PULL_REQUEST_NUMBER") is None
    assert os.environ.get("SEMAPHORE_THREAD_RESULT") != "failed"

# Generated at 2022-06-24 01:30:33.236890
# Unit test for function checker
def test_checker():
    '''
    Make sure that this function decorator properly wraps functions
    '''
    def test():
        return 1
    assert(checker(test)())

# Generated at 2022-06-24 01:30:45.010575
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "xxxx"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = ""
    os.environ["TRAVIS_BRANCH"] = ""
    os.environ["TRAVIS_PULL_REQUEST"] = ""
    os.environ["FRIGG_BUILD_BRANCH"] = ""
    os.environ["FRIGG_PULL_REQUEST"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = ""
    os.environ["BRANCH_NAME"] = ""
    os

# Generated at 2022-06-24 01:30:45.582555
# Unit test for function jenkins
def test_jenkins():
    jenkins()

# Generated at 2022-06-24 01:30:48.150147
# Unit test for function check
def test_check():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

# Generated at 2022-06-24 01:30:57.123984
# Unit test for function semaphore
def test_semaphore():
    envir = {
        "BRANCH_NAME": "master",
        "PULL_REQUEST_NUMBER": None,
        "SEMAPHORE_THREAD_RESULT": "passed",
    }
    for key, value in envir.items():
        os.environ[key] = value
    semaphore("master")

    envir = {
        "BRANCH_NAME": "master",
        "PULL_REQUEST_NUMBER": "1",
        "SEMAPHORE_THREAD_RESULT": "passed",
    }
    for key, value in envir.items():
        os.environ[key] = value
    semaphore("master")


# Generated at 2022-06-24 01:31:02.035395
# Unit test for function checker
def test_checker():

    func = lambda: 1

    assert func() == 1

    # verify that original function will work
    new_func = checker(func)
    assert new_func() == 1

    # verify that if function returns an AssertionError
    # it will be raised as a CiVerificationError.

# Generated at 2022-06-24 01:31:09.982142
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    del os.environ['BITBUCKET_PR_ID']
    bitbucket('master')
    os.environ['BITBUCKET_BRANCH'] = 'develop'
    with pytest.raises(CiVerificationError):
        bitbucket('master')
    os.environ['BITBUCKET_PR_ID'] = '5678'
    with pytest.raises(CiVerificationError):
        bitbucket('master')

# Generated at 2022-06-24 01:31:16.102479
# Unit test for function frigg
def test_frigg():
    assert os.environ.get("FRIGG") != "true"
    os.environ["FRIGG"] = "true"
    try:
        frigg("development")
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."
    os.environ["FRIGG_BUILD_BRANCH"] = "development"
    assert frigg("development") is True
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]

# Generated at 2022-06-24 01:31:20.617585
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"]='master'
    os.environ["GIT_BRANCH"]="master"
    os.environ["JENKINS_URL"]="https://ci.jenkins.io/"
    os.environ["CHANGE_ID"]=""
    check()


# Generated at 2022-06-24 01:31:21.804320
# Unit test for function check
def test_check():
    assert check() == True
    global os
    os = None
    assert check() == None

# Generated at 2022-06-24 01:31:24.672121
# Unit test for function checker

# Generated at 2022-06-24 01:31:27.356544
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()

# Generated at 2022-06-24 01:31:32.184571
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "http://jenkins.com"
    os.environ['GIT_BRANCH'] = "master"
    os.environ['CHANGE_ID'] = ""
    assert check()


# Generated at 2022-06-24 01:31:37.343822
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH']='master'
    os.environ['TRAVIS_PULL_REQUEST']='false'
    travis('master')


# Generated at 2022-06-24 01:31:40.282380
# Unit test for function check
def test_check():
    """
    Unit test for check() function
    """
    # TODO: Add other test environment
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    del os.environ["CI_PULL_REQUEST"]
    check()

# Generated at 2022-06-24 01:31:46.742967
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'develop'
    os.environ['FRIGG_PULL_REQUEST'] = 'true'
    try:
        frigg('develop')
    except CiVerificationError as e:
        assert e.args[0] == 'The verification check for the environment did not pass.'

    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    try:
        frigg('master')
    except CiVerificationError as e:
        assert e.args[0] == 'The verification check for the environment did not pass.'

    os.environ['FRIGG_BUILD_BRANCH'] = 'develop'

# Generated at 2022-06-24 01:31:49.148986
# Unit test for function gitlab
def test_gitlab():
    # Environment variable GITLAB_CI should be set
    os.environ["GITLAB_CI"] = "true"
    # Environment variable CI_COMMIT_REF_NAME should be set
    os.environ["CI_COMMIT_REF_NAME"] = "test"

    gitlab("test")

# Generated at 2022-06-24 01:31:49.986789
# Unit test for function circle
def test_circle():
    assert circle()

# Generated at 2022-06-24 01:31:55.752416
# Unit test for function jenkins
def test_jenkins():
    import pytest
    os.environ["JENKINS_URL"] = "http://localhost:8080/"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "3"
    with pytest.raises(CiVerificationError):
        jenkins("master")
    os.environ["CHANGE_ID"] = "0"
    assert jenkins("master")

# Generated at 2022-06-24 01:32:05.397522
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    # TODO: fix this in a more robust way
    check()

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "successful"
    check()

    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"

# Generated at 2022-06-24 01:32:10.926711
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    check()
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]

# Generated at 2022-06-24 01:32:12.757930
# Unit test for function check
def test_check():
    from unittest.mock import patch
    from semantic_release.ci_checks import travis, circ

# Generated at 2022-06-24 01:32:18.806596
# Unit test for function travis
def test_travis():
    """Unit test for function travis"""
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS"] = "true"
    check(branch="master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]
    del os.environ["TRAVIS"]


# Generated at 2022-06-24 01:32:26.411076
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "other"
    os.environ["CI_PULL_REQUEST"] = "true"
    os.environ["BRANCH_NAME"] = "other"
    os.environ["PULL_REQUEST_NUMBER"] = "other"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "other"



# Generated at 2022-06-24 01:32:29.716377
# Unit test for function checker
def test_checker():
    @checker
    def foo(num: int):
        if num > 1:
            raise AssertionError("Number is greater than 1")
        return True

    assert foo(1) is True
    assert foo(100) is False

# Generated at 2022-06-24 01:32:34.174809
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check(branch="master")
    del os.environ["CI_COMMIT_REF_NAME"]

    os.environ["CI_COMMIT_REF_NAME"] = "not-master"
    check(branch="master")
    del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-24 01:32:41.956875
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["SEMAPHORE"] = "false"
    os.environ["FRIGG"] = "false"
    os.environ["CIRCLECI"] = "false"
    os.environ["GITLAB_CI"] = "false"
    os.environ["JENKINS_URL"] = "true"

    check(branch = "master")


# Generated at 2022-06-24 01:32:45.402071
# Unit test for function checker
def test_checker():
    @checker
    def test_function():
        assert False

    try:
        test_function()
        assert False
    except CiVerificationError:
        assert True

    # Test that a successful check does not raise a CiVerificationError
    @checker
    def test_function():
        assert True

    test_function()

# Generated at 2022-06-24 01:32:50.610638
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"]="true"
    os.environ["FRIGG_PULL_REQUEST"]="false"
    os.environ["FRIGG_BUILD_BRANCH"]="master"
    check()


# Generated at 2022-06-24 01:33:01.953517
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "successful"
    assert semaphore("master")

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore("master")

    os.environ["BRANCH_NAME"] = "dev"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "successful"
    assert not semaphore("master")

# Generated at 2022-06-24 01:33:06.427782
# Unit test for function circle
def test_circle():
    branch_name = "master"
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = branch_name
    circle(branch_name)
    os.environ["CI_PULL_REQUEST"] = "true"
    try:
        circle(branch_name)
        # If this code is reached, then the test has failed
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-24 01:33:15.917948
# Unit test for function jenkins
def test_jenkins():
    assert os.environ.get("JENKINS_URL") == None
    assert os.environ.get("BRANCH_NAME") == None
    assert os.environ.get("CHANGE_ID") == None
    os.environ["JENKINS_URL"] = "https://jenkins.com/"
    os.environ["BRANCH_NAME"] = "master"
    jenkins("master")
    os.environ["CHANGE_ID"] = "50"
    assert jenkins("master") == False
    os.environ["CHANGE_ID"] = None
    jenkins("master")
    os.environ["JENKINS_URL"] = None
    assert os.environ.get("JENKINS_URL") == None
    assert jenkins("master") == False

#

# Generated at 2022-06-24 01:33:22.594051
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert check() is None
    assert os.environ.get("CI_COMMIT_REF_NAME") == "master"

    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    assert check("master") is None
    assert check("develop") is None



# Generated at 2022-06-24 01:33:28.586381
# Unit test for function frigg
def test_frigg():
    # fake inputs
    branch = "master"
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = branch
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    assert frigg(branch) == True
    # fake pull request
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    assert frigg(branch) == False

# Generated at 2022-06-24 01:33:31.664772
# Unit test for function checker
def test_checker():
    import pytest

    @checker
    def raise_error():
        raise AssertionError("Error")

    with pytest.raises(CiVerificationError):
        raise_error()

# Generated at 2022-06-24 01:33:43.613409
# Unit test for function gitlab
def test_gitlab():
    """
    test_gitlab.
    """

    with os.environ.copy():
        os.environ["GITLAB_CI"] = "true"
        os.environ["CI_COMMIT_REF_NAME"] = "develop"
        os.environ["CI_MERGE_REQUEST_IID"] = "1"

        check("develop")

    with os.environ.copy():
        os.environ["GITLAB_CI"] = "true"
        os.environ["CI_COMMIT_REF_NAME"] = "feature/test"
        os.environ["CI_MERGE_REQUEST_IID"] = "1"

        check("feature/test")

    # Check if exception is raised with different branches

# Generated at 2022-06-24 01:33:50.041202
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for function bitbucket
    """
    release_branch = "dev"
    assert not bitbucket(branch=release_branch)
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert bitbucket(branch=release_branch)
    os.environ["BITBUCKET_PR_ID"] = "pull-request-id"
    assert not bitbucket(branch=release_branch)

# Generated at 2022-06-24 01:33:56.086275
# Unit test for function semaphore
def test_semaphore():
    # test success
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    semaphore(branch="master")

    # test failure
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore(branch="master")
        assert False, "Should raise exception"
    except CiVerificationError:
        pass


# Generated at 2022-06-24 01:34:01.274918
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    assert frigg(branch='master')
    os.environ['FRIGG_BUILD_BRANCH'] = 'not-master'
    assert not frigg(branch='master')

# Generated at 2022-06-24 01:34:07.582179
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    os.environ["FRIGG_PULL_REQUEST"] = "true"

    try:
        frigg("master")
        assert 0
    except CiVerificationError:
        pass


# Generated at 2022-06-24 01:34:16.034500
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["SEMAPHORE"] = "false"
    os.environ["FRIGG"] = "false"
    os.environ["CIRCLECI"] = "false"
    os.environ["GITLAB_CI"] = "false"
    os.environ.pop("JENKINS_URL", None)
    os.environ.pop("BITBUCKET_BUILD_NUMBER", None)
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    os.environ.pop("BRANCH_NAME", None)
    os.environ.pop("PULL_REQUEST_NUMBER", None)

# Generated at 2022-06-24 01:34:23.965440
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    try:
        frigg("master")
    except CiVerificationError as err:
        raise AssertionError(err)

    assert os.environ.get("FRIGG_BUILD_BRANCH") == "master"
    assert not os.environ.get("FRIGG_PULL_REQUEST")


# Generated at 2022-06-24 01:34:28.577452
# Unit test for function frigg
def test_frigg():
    """
    Test the function frigg
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")

# Generated at 2022-06-24 01:34:35.594843
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    check()
    del os.environ["SEMAPHORE"]

# Generated at 2022-06-24 01:34:46.474448
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
    except CiVerificationError:
        pass

    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "dev"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

# Generated at 2022-06-24 01:34:49.072469
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "http://jenkins"
    jenkins("master")



# Generated at 2022-06-24 01:34:59.054721
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["TRAVIS_BRANCH"] = "develop"
    try:
        check()
    except:
        assert True
        os.environ.pop("TRAVIS_BRANCH")
        os.environ.pop("TRAVIS_PULL_REQUEST")
    else:
        os.environ.pop("TRAVIS_BRANCH")
        os.environ.pop("TRAVIS_PULL_REQUEST")
        assert False



# Generated at 2022-06-24 01:35:03.103592
# Unit test for function check
def test_check():
    """
    Test case to check that an exception gets raised if the branch name
    is not 'master'
    """
    try:
        check("not-master")
        raise AssertionError("Branch name is not 'master'. Check failed.")
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:35:08.568340
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["GIT_BRANCH"] = "other_branch"
    try:
        jenkins("branch")
        assert False, "jenkins() should have failed"
    except CiVerificationError:
        del os.environ["JENKINS_URL"]
        del os.environ["GIT_BRANCH"]
        assert True
    del os.environ["JENKINS_URL"]



# Generated at 2022-06-24 01:35:16.293398
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = "true"
    os.environ['CIRCLE_BRANCH'] = "master"
    os.environ['CI_PULL_REQUEST'] = None
    assert circle("master") is True
    os.environ['CIRCLECI'] = "true"
    os.environ['CIRCLE_BRANCH'] = "develop"
    os.environ['CI_PULL_REQUEST'] = "https://github.com/org/repo/pulls/1"
    assert circle("develop") is False
    del os.environ['CIRCLECI']
    assert circle("develop") is False


# Generated at 2022-06-24 01:35:25.095309
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    try:
        ci_checks.check()
    except:
        raise AssertionError("Frigg checker failed.")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        ci_checks.check()
    except ci_checks.CiVerificationError:
        pass
    except:
        raise AssertionError("Frigg checker failed.")


# Generated at 2022-06-24 01:35:29.558979
# Unit test for function gitlab
def test_gitlab():
    """
    Tests the gitlab function.
    """
    # Test environment variables
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = None
    assert gitlab("master")



# Generated at 2022-06-24 01:35:34.814880
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "http://localhost:8080"
    os.environ['BRANCH_NAME'] = "master"
    os.environ['GIT_BRANCH'] = "master"
    check()
    del os.environ['JENKINS_URL']
    del os.environ['BRANCH_NAME']
    del os.environ['GIT_BRANCH']

# Generated at 2022-06-24 01:35:39.790432
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    try:
        check()
    except CiVerificationError:
        pass



# Generated at 2022-06-24 01:35:40.460769
# Unit test for function check
def test_check():
    check()

# Generated at 2022-06-24 01:35:46.184873
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "mybranch"
    assert not os.environ.get("FRIGG_PULL_REQUEST")
    frigg("mybranch")
    del os.environ["FRIGG"]



# Generated at 2022-06-24 01:35:52.694067
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    check()

    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'true'
    try:
        check()
    except CiVerificationError:
        print('frigg: success')


# Generated at 2022-06-24 01:35:54.993885
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")


# Generated at 2022-06-24 01:36:02.553253
# Unit test for function gitlab
def test_gitlab():
    """
    Test that GitLab checker returns True when the environment
    variables are set properly.
    """
    # Create a test environment
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    os.environ["CI_MERGE_REQUEST_IID"] = None

    # Run a test
    assert gitlab("master")

    # Delete environment
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]
    del os.environ["CI_MERGE_REQUEST_IID"]



# Generated at 2022-06-24 01:36:08.026971
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    #os.environ['CI_MERGE_REQUEST_ID'] = None
    gitlab('master')


# Generated at 2022-06-24 01:36:15.515784
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"

    check()

    os.environ["CI_COMMIT_REF_NAME"] = "foo"

    try:
        check()
    except CiVerificationError:
        assert True
    else:
        assert False



# Generated at 2022-06-24 01:36:21.585227
# Unit test for function frigg
def test_frigg():
	assert os.environ.get("FRIGG_BUILD_BRANCH") == None
	assert not os.environ.get("FRIGG_PULL_REQUEST") == None
	assert frigg(os.environ.get("FRIGG_BUILD_BRANCH")) == True
	assert frigg(os.environ.get("FRIGG_PULL_REQUEST")) == True



# Generated at 2022-06-24 01:36:25.379899
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["GITLAB_CI"] = "true"
    check()



# Generated at 2022-06-24 01:36:34.962235
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "master"
    try:
        jenkins("master")
        assert True
    except CiVerificationError:
        assert False
    os.environ["GIT_BRANCH"] = "notmaster123"
    try:
        jenkins("master")
        assert False
    except CiVerificationError:
        assert True
    del os.environ["JENKINS_URL"]
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "true"

# Generated at 2022-06-24 01:36:44.232594
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://localhost:8080/"
    os.environ["GIT_BRANCH"] = "SomeOtherBranch"
    os.environ["CHANGE_ID"] = "SomeOtherChange"
    try:
        jenkins("SomeOtherBranch")
    except CiVerificationError as e:
        assert e.args[0] == "The verification check for the environment did not pass."
    else:
        raise Exception("Expected a CiVerificationError")

    os.environ["GIT_BRANCH"] = "master"
    assert jenkins("master")

    os.environ["CHANGE_ID"] = "SomeOtherChange"

# Generated at 2022-06-24 01:36:51.588522
# Unit test for function bitbucket
def test_bitbucket():
    # Use case 1:
    # BITBUCKET_BRANCH=master, BITBUCKET_PR_ID=False
    os.environ.pop("BITBUCKET_BRANCH", None)
    os.environ.pop("BITBUCKET_PR_ID", None)
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "False"
    assert bitbucket("master")
    # Use case 2:
    # BITBUCKET_BRANCH=develop, BITBUCKET_PR_ID=False
    os.environ.pop("BITBUCKET_BRANCH", None)
    os.environ.pop("BITBUCKET_PR_ID", None)

# Generated at 2022-06-24 01:36:52.361192
# Unit test for function check
def test_check():
    try:
        check('master')
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:37:02.617019
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "5"
    try:
        check()
    except CiVerificationError:
        pass

    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

# Generated at 2022-06-24 01:37:12.299411
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://abc:8080"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = None
    check()
    del os.environ["JENKINS_URL"]
    del os.environ["BRANCH_NAME"]
    del os.environ["CHANGE_ID"]
    del os.environ["GIT_BRANCH"]
    del os.environ["CHANGE_ID"]
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "12345"
    with pytest.raises(CiVerificationError):
        check()
    del os.environ["GIT_BRANCH"]

# Generated at 2022-06-24 01:37:16.645083
# Unit test for function travis
def test_travis():

    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    check()

    del os.environ['TRAVIS_BRANCH']
    del os.environ['TRAVIS_PULL_REQUEST']



# Generated at 2022-06-24 01:37:22.290379
# Unit test for function jenkins
def test_jenkins():
    local_env = dict(os.environ)
    local_env.update({"JENKINS_URL": "fake", "BRANCH_NAME": "master"})

    old_environ = os.environ
    os.environ = local_env
    try:
        jenkins("master")
    except CiVerificationError:
        assert False, "test_jenkins failed"
    os.environ = old_environ

# Generated at 2022-06-24 01:37:28.513428
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()
    del os.environ["GITLAB_CI"]
    del os.environ["CI_COMMIT_REF_NAME"]
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    try:
        check()
        success=False
    except CiVerificationError:
        success=True
    del os.environ["CI_COMMIT_REF_NAME"] 
    assert(success)


# Generated at 2022-06-24 01:37:37.269086
# Unit test for function circle
def test_circle():
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = ''
    assert circle('master') == True
    os.environ['CIRCLE_BRANCH'] = 'dev'
    assert circle('master') == False
    os.environ['CI_PULL_REQUEST'] = 'https://github.com/steve-parker/semantic-release/pulls/44'
    assert circle('master') == False
    assert os.environ['CIRCLE_BRANCH'] == 'dev'

# Generated at 2022-06-24 01:37:47.728194
# Unit test for function check
def test_check():
    """
    Test that the check function will call the correct function
    based on the environment variables, else raise a
    CiVerificationError
    """
    os.environ["TRAVIS"] = "true"
    try:
        check()
    except CiVerificationError:
        os.environ.pop("TRAVIS")
        raise AssertionError("Leaving check with Travis environment failed")
    os.environ.pop("TRAVIS")

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        check()
    except CiVerificationError:
        os.environ.pop("SEMAPHORE")
        os.environ

# Generated at 2022-06-24 01:37:53.672562
# Unit test for function bitbucket
def test_bitbucket():
    test_env = {}
    test_env['BITBUCKET_BRANCH'] = "master"
    test_env['BITBUCKET_PR_ID'] = ""
    assert os.environ.get("BITBUCKET_BRANCH") == None
    assert os.environ.get("BITBUCKET_PR_ID") == None
    os.environ = test_env
    bitbucket("master")

# Generated at 2022-06-24 01:37:57.884918
# Unit test for function travis
def test_travis():
    try:
        travis('master')
    except AssertionError as e:
        print('travis function failed')
        os.environ['TRAVIS_BRANCH'] = 'master'
        os.environ['TRAVIS_PULL_REQUEST'] = 'false'
        travis('master')


# Generated at 2022-06-24 01:38:08.625176
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")
    assert not semaphore("not_master")
    assert not semaphore("master")

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "2"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore("master")
    assert not semaphore("not_master")
    assert not semaphore("master")

    os.environ["BRANCH_NAME"] = "master"
    os

# Generated at 2022-06-24 01:38:15.328474
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = 'https://ci.jenkins.io'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['GIT_BRANCH'] = 'master'
    os.environ['CHANGE_ID'] = ''
    assert jenkins(branch='master')

    os.environ['JENKINS_URL'] = 'https://ci.jenkins.io'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['CHANGE_ID'] = '1234567'
    try:
        jenkins(branch='master')
        assert False
    except AssertionError:
        pass
    except CiVerificationError:
        assert True


# Generated at 2022-06-24 01:38:19.240329
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = ''
    assert bitbucket('master')
    os.environ['BITBUCKET_BRANCH'] = 'staging'
    assert not bitbucket('master')
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = '1'
    assert not bitbucket('master')

# Generated at 2022-06-24 01:38:20.024003
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("master")

# Generated at 2022-06-24 01:38:30.189029
# Unit test for function gitlab
def test_gitlab():
    """
    Test gitlab function
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PROJECT_NAMESPACE"] = "ci"
    os.environ["CI_PROJECT_NAME"] = "ci"
    os.environ["CI_PROJECT_ID"] = "1"
    os.environ["CI_COMMIT_SHA"] = "123456789"
    os.environ["CI_COMMIT_REF_SLUG"] = "v2.2.2"
    os.environ["CI_COMMIT_MESSAGE"] = "message"
    os.environ["CI_BUILD_ID"] = "2"
    os.environ["CI_BUILD_REF_NAME"] = "master"
    assert gitlab

# Generated at 2022-06-24 01:38:33.938855
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "release"
    assert frigg("release")

# Generated at 2022-06-24 01:38:38.546053
# Unit test for function frigg
def test_frigg():
    """
    Unit test for function frigg.
    Returns:

    """
    assert frigg("master") is True
    assert frigg("development") is True
    assert frigg("rel_branch") is True


# Generated at 2022-06-24 01:38:40.337301
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    check()



# Generated at 2022-06-24 01:38:47.352857
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "true"
    try:
        jenkins("master")
        assert False
    except CiVerificationError:
        assert True
    os.environ["CHANGE_ID"] = "false"
    try:
        jenkins("master")
        assert True
    except CiVerificationError:
        assert False


# Generated at 2022-06-24 01:38:52.030756
# Unit test for function travis
def test_travis():

    os.environ['TRAVIS_BRANCH']="master"
    os.environ['TRAVIS_PULL_REQUEST']="false"
    assert travis(branch="master") == True

    os.environ['TRAVIS_BRANCH']="master"
    os.environ['TRAVIS_PULL_REQUEST']="true"
    assert travis(branch="master") == False


# Generated at 2022-06-24 01:38:55.408433
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"

    check()



# Generated at 2022-06-24 01:39:00.757850
# Unit test for function gitlab
def test_gitlab():
    env = {'CI_COMMIT_REF_NAME': 'master'}
    assert checker(gitlab)(env, 'master')
    env = {'CI_COMMIT_REF_NAME': 'other'}
    assert not checker(gitlab)(env, 'master')


# Generated at 2022-06-24 01:39:09.831539
# Unit test for function checker
def test_checker():
    """
    Test function checker.
    """
    @checker
    def check_test(branch):
        """
        Fake CI environment check.
        :param branch: branch to check
        """
        assert branch == "master"

    check_test("master")
    try:
        check_test("other")
    except CiVerificationError as error:
        # Ensure that checker wraps up AssertionError as CiVerificationError
        assert error.args[0] == "The verification check for the environment did not pass."
    else:
        raise AssertionError("Should have raised a CiVerificationError.")

# Generated at 2022-06-24 01:39:17.994197
# Unit test for function semaphore
def test_semaphore():
    correct_env = {
        "BRANCH_NAME": "master",
        "PULL_REQUEST_NUMBER": None,
        "SEMAPHORE_THREAD_RESULT": "passed",
    }
    assert semaphore("master")
    assert semaphore("master", **correct_env)

    from semantic_release.errors import CiVerificationError

    wrong_env = {
        "BRANCH_NAME": "m",
        "PULL_REQUEST_NUMBER": None,
        "SEMAPHORE_THREAD_RESULT": "passed",
    }
    wrong_env_semaphore = "m"
    try:
        semaphore(wrong_env_semaphore, **wrong_env)
        assert False
    except CiVerificationError:
        assert True