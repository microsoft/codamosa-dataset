

# Generated at 2022-06-24 01:29:20.345740
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = ""
    jenkins("master")

# Generated at 2022-06-24 01:29:31.298940
# Unit test for function jenkins
def test_jenkins():
    def set_env_var(name, value):
        """
        Set environment variable if it doesn't exist.
        """
        if name in os.environ:
            del os.environ[name]

        os.environ[name] = value

    # This will pass
    set_env_var("JENKINS_URL", "test123")
    set_env_var("BRANCH_NAME", "master")
    set_env_var("GIT_BRANCH", "master")

    check("master")

    # This will pass
    set_env_var("JENKINS_URL", "test123")
    set_env_var("BRANCH_NAME", "master")
    set_env_var("GIT_BRANCH", "develop")

    check("master")

    # This will pass


# Generated at 2022-06-24 01:29:36.127975
# Unit test for function checker
def test_checker():
    try:
        checker(lambda x: x)(1)
    except CiVerificationError:
        assert False, "Raised CiVerificationError for passing test"
    else:
        assert True, "Didn't raise for passing test"

    def failing_test(x):
        assert x == 2

    try:
        checker(failing_test)(1)
    except CiVerificationError:
        assert True, "Raised CiVerificationError for failing test"
    else:
        assert False, "Didn't raise for failing test"

# Generated at 2022-06-24 01:29:42.920227
# Unit test for function frigg
def test_frigg():
    # Case: FRIGG is not set
    assert os.environ.get("FRIGG") is None
    try:
        frigg("master")
        assert False
    except CiVerificationError:
        assert True

    # Case: FRIGG is set but FRIGG_BUILD_BRANCH is not set
    os.environ["FRIGG"] = "true"
    del os.environ["FRIGG_BUILD_BRANCH"]
    try:
        frigg("master")
        assert False
    except CiVerificationError:
        assert True

    # Case: FRIGG_BUILD_BRANCH is not "master"
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"

# Generated at 2022-06-24 01:29:45.353490
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") is True

# Generated at 2022-06-24 01:29:47.866505
# Unit test for function checker
def test_checker():
    def func():
        assert True

    def func_false():
        assert False

    assert checker(func)()
    assert checker(func_false)()

# Generated at 2022-06-24 01:29:54.758874
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "true"
    jenkins("master")

    del os.environ["JENKINS_URL"]
    try:
        jenkins("master")
    except CiVerificationError:
        pass

    os.environ["BRANCH_NAME"] = "develop"
    try:
        jenkins("master")
    except CiVerificationError:
        pass



# Generated at 2022-06-24 01:29:57.832088
# Unit test for function checker
def test_checker():

    @checker
    def test_function():
        raise AssertionError()

    try:
        test_function()
    except AssertionError:
        assert True
    except:
        assert False



# Generated at 2022-06-24 01:30:08.561329
# Unit test for function gitlab
def test_gitlab():
    try:
        os.environ["CI_COMMIT_REF_NAME"] = "master"
        os.environ["CI_MERGE_REQUEST_ID"] = "9999"
    except:
        pass
    try:
        gitlab("master")
        assert False
    except AssertionError:
        assert True
    try:
        os.environ["CI_COMMIT_REF_NAME"] = "branch-1"
        os.environ["CI_MERGE_REQUEST_ID"] = "9999"
    except:
        pass
    try:
        gitlab("master")
        assert False
    except CiVerificationError as e:
        assert True

# Generated at 2022-06-24 01:30:11.752022
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")



# Generated at 2022-06-24 01:30:16.802595
# Unit test for function circle
def test_circle():
    """
    This function unit test for function circle
    """
    assert circle("master")
    os.environ["CIRCLE_BRANCH"] = "dev"
    assert circle("dev")



# Generated at 2022-06-24 01:30:20.026407
# Unit test for function checker
def test_checker():
    def simple_func():
        raise AssertionError("Tests should fail")
    decorated_func = checker(simple_func)
    decorated_func()



# Generated at 2022-06-24 01:30:25.640407
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")

    os.environ["BRANCH_NAME"] = "feature"
    semaphore("master")

    os.environ["BRANCH_NAME"] = "feature"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    semaphore("master")



# Generated at 2022-06-24 01:30:30.480074
# Unit test for function frigg
def test_frigg():
    # Test that the checker works
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    check()

# Generated at 2022-06-24 01:30:33.885032
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch="master")


# Generated at 2022-06-24 01:30:39.704841
# Unit test for function travis
def test_travis():
    # Passing checks
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis(branch="master")

    # Failing checks
    assert not travis(branch="develop")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    assert not travis(branch="master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]



# Generated at 2022-06-24 01:30:45.670434
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "dev"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")
    del os.environ["FRIGG_PULL_REQUEST"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG"]


# Generated at 2022-06-24 01:30:55.502921
# Unit test for function checker
def test_checker():
    """
    Tests the checker decorator
    """

# Generated at 2022-06-24 01:31:05.271383
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    assert frigg("master")
    os.environ['FRIGG_BUILD_BRANCH'] = 'develop'
    assert not frigg("master")
    os.environ['FRIGG_PULL_REQUEST'] = '12'
    assert not frigg("master")
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    assert not frigg("master")
    del os.environ['FRIGG_PULL_REQUEST']
    assert not frigg("master")
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'

# Generated at 2022-06-24 01:31:14.946177
# Unit test for function bitbucket
def test_bitbucket():
    bb_env = {
        "BITBUCKET_BRANCH": "master",
        "BITBUCKET_PR_ID": None,
    }
    # On branch master, not a pull request
    bitbucket(branch="master")
    # On branch master, pull request
    bb_env["BITBUCKET_PR_ID"] = "12345"
    bitbucket(branch="master")
    # On branch dev, not a pull request
    bb_env["BITBUCKET_BRANCH"] = "dev"
    bb_env["BITBUCKET_PR_ID"] = None
    bitbucket(branch="dev")

# Generated at 2022-06-24 01:31:16.867338
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()



# Generated at 2022-06-24 01:31:24.920913
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("develop")
    assert frigg("master") == False
    assert frigg("develop") == False
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master") == True
    frigg("develop") == True
    os.environ.pop("FRIGG_BUILD_BRANCH", None)
    os.environ.pop("FRIGG_PULL_REQUEST", None)
    os.environ.pop("FRIGG", None)
    assert frigg("master") == False

# Generated at 2022-06-24 01:31:35.374648
# Unit test for function jenkins
def test_jenkins():
    # Set up environment variables to be as close to real Jenkins as possible
    os.environ["JENKINS_URL"] = "http://www.example.org"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "12345"

    exception = None
    try:
        jenkins("master")
    except AssertionError as e:
        exception = e
    finally:
        assert exception is not None
        assert exception.args[0] == "The verification check for the environment did not pass."

    os.environ["CHANGE_ID"] = ""
    try:
        jenkins("master")
    except AssertionError as e:
        exception = e
    finally:
        assert exception is None

# Generated at 2022-06-24 01:31:37.516677
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '123'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    check()

# Generated at 2022-06-24 01:31:41.349371
# Unit test for function circle
def test_circle():
    for key in ('CIRCLE_BRANCH', 'CI_PULL_REQUEST'):
        value = os.environ.get(key)
        if value is not None:
            del os.environ[key]
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = ''
    circle('master')


# Generated at 2022-06-24 01:31:43.971416
# Unit test for function checker
def test_checker():
    def test_function():
        assert False

    try:
        checker(test_function)()
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-24 01:31:49.661542
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    semaphore("master")

# Generated at 2022-06-24 01:31:52.401452
# Unit test for function bitbucket
def test_bitbucket():
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        assert True



# Generated at 2022-06-24 01:31:55.232152
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    check()

# Generated at 2022-06-24 01:32:04.499085
# Unit test for function travis
def test_travis():
    print("Test for function travis")

    # Set environment variable TRAVIS_BRANCH and TRAVIS_PULL_REQUEST
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'

    # Test: correct environment variable setting
    travis('master')

    # Test: incorrect TRAVIS_BRANCH value
    try:
        travis('develop')
        assert False  # Should never be executed
    except AssertionError:
        pass
    except:
        assert False  # Should never be executed

    os.environ['TRAVIS_BRANCH'] = 'develop'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'

    # Test: correct environment variable setting

# Generated at 2022-06-24 01:32:08.252708
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://jenkins"
    os.environ["GIT_BRANCH"] = "master"
    del os.environ["CHANGE_ID"]
    jenkins()

# Generated at 2022-06-24 01:32:18.058745
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = "123456"
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_PR_ID'] = "12345"
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        assert True

    os.environ['BITBUCKET_BRANCH'] = "test"
    try:
        bitbucket("test")
        assert True
    except CiVerificationError:
        assert False

    os.environ['BITBUCKET_PR_ID'] = ""
    try:
        bitbucket("test")
        assert True
    except CiVerificationError:
        assert False


# Generated at 2022-06-24 01:32:23.008261
# Unit test for function checker
def test_checker():
    """
    Unit test for function checker

    :return: True
    """
    @checker
    def test():
        assert 0

    try:
        test()
    except CiVerificationError:
        assert 1

    return True

# Generated at 2022-06-24 01:32:25.882831
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-24 01:32:36.593959
# Unit test for function gitlab
def test_gitlab():
    import os
    import pytest

    # with default branch
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = ""
    with pytest.raises(CiVerificationError):
        gitlab(branch="dev")

    # with dev branch
    os.environ["CI_COMMIT_REF_NAME"] = "dev"
    os.environ["CI_MERGE_REQUEST_IID"] = ""
    gitlab(branch="dev")

    # with a merge request
    os.environ["CI_MERGE_REQUEST_IID"] = "123"
    with pytest.raises(CiVerificationError):
        gitlab(branch="master")

# Generated at 2022-06-24 01:32:39.512416
# Unit test for function checker
def test_checker():
    def dummy_function():
        raise AssertionError

    wrapped = checker(dummy_function)
    try:
        wrapped()
    except CiVerificationError:
        pass
    else:
        assert False, "CiVerificationError not raised"

# Generated at 2022-06-24 01:32:47.709562
# Unit test for function checker
def test_checker():
    def test_func_raise():
        raise AssertionError('Test AssertionError')

    def test_func_pass():
        pass

    @checker
    def test_decorator_pass():
        test_func_pass()

    @checker
    def test_decorator_raise():
        test_func_raise()

    assert test_decorator_pass()

    try:
        test_decorator_raise()
    except CiVerificationError:
        assert True

    try:
        test_func_raise()
    except AssertionError:
        assert True

# Generated at 2022-06-24 01:32:58.201883
# Unit test for function check
def test_check():
    # Check each of the functions to ensure they work as expected
    # This can't be done with pytest, since the checking functions
    # are dynamically created, so it isn't possible to check that
    # the functions raise an assertion error.
    os.environ["TRAVIS"] = "true"
    check()

    os.environ.pop("TRAVIS")
    os.environ["SEMAPHORE"] = "true"
    check()

    os.environ.pop("SEMAPHORE")
    os.environ["FRIGG"] = "true"
    check()

    os.environ.pop("FRIGG")
    os.environ["CIRCLECI"] = "true"
    check()

    os.environ.pop("CIRCLECI")
    os.environ["GITLAB_CI"]

# Generated at 2022-06-24 01:33:07.132867
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = "true"
    os.environ['TRAVIS_BRANCH'] = "feature/test"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    check(branch="master")
    os.environ['TRAVIS'] = "false"
    os.environ['TRAVIS_BRANCH'] = "master"

    os.environ['SEMAPHORE'] = "true"
    os.environ['BRANCH_NAME'] = "feature/test"
    os.environ['PULL_REQUEST_NUMBER'] = "123456"
    os.environ['SEMAPHORE_THREAD_RESULT'] = "failed"
    check(branch="master")

# Generated at 2022-06-24 01:33:09.202304
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "dev"
    bitbucket("dev")


# Generated at 2022-06-24 01:33:15.006377
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "dummy url"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")
    os.environ["CHANGE_ID"] = "change id"
    try:
        jenkins("master")
    except CiVerificationError:
        pass
    else:
        assert True == False, "Expected a CiVerificationError"


# Generated at 2022-06-24 01:33:21.898770
# Unit test for function bitbucket
def test_bitbucket():
    """
    Ensure function bitbucket raises an Error
    when run from Jenkins CI
    """

    assert os.environ.get("BITBUCKET_BUILD_NUMBER") == "10"
    assert os.environ.get("BITBUCKET_BRANCH") == "master"
    assert os.environ.get("BITBUCKET_PR_ID") is None

    try:
        bitbucket(branch="master")
    except CiVerificationError:
        assert True


# Generated at 2022-06-24 01:33:26.396424
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"

    check("master")



# Generated at 2022-06-24 01:33:32.767332
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    bitbucket("master")
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "dev"
    bitbucket(None)
    del os.environ["BITBUCKET_BRANCH"]



# Generated at 2022-06-24 01:33:36.232148
# Unit test for function circle
def test_circle():
    os.environ['CIRCLE_BRANCH'] = "master"
    assert os.environ['CIRCLE_BRANCH'] == "master"
    del os.environ['CIRCLE_BRANCH']
    os.environ['CIRCLE_BRANCH'] = "feature1"
    assert os.environ['CIRCLE_BRANCH'] != "master"
    del os.environ['CIRCLE_BRANCH']


# Generated at 2022-06-24 01:33:39.312072
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'

    assert travis('master')

# Generated at 2022-06-24 01:33:49.545068
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    frigg("other")

    os.environ["FRIGG_PULL_REQUEST"] = "1"
    try:
        frigg("master")
        assert False, "Expected exception due to pull request"
    except Exception:
        pass
    del os.environ["FRIGG_PULL_REQUEST"]

    os.environ["FRIGG_BUILD_BRANCH"] = "other"
    try:
        frigg("master")
        assert False, "Expected exception due to branch mismatch"
    except Exception:
        pass
    
    os.environ.pop("FRIGG")
    frigg("master")

# Generated at 2022-06-24 01:33:52.470161
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    check()



# Generated at 2022-06-24 01:33:58.999344
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()

    os.environ["CI_COMMIT_REF_NAME"] = "dev"
    try:
        check()
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:34:09.672084
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123"
    assert bitbucket(os.environ["BITBUCKET_BRANCH"])
    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = "124"
    assert not bitbucket(os.environ["BITBUCKET_BRANCH"])
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    assert bitbucket(os.environ["BITBUCKET_BRANCH"])

# Generated at 2022-06-24 01:34:16.344637
# Unit test for function semaphore
def test_semaphore():
    """
    Performs a unit test for the semaphore function
    """
    os.environ["BRANCH_NAME"] = 'master'
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    assert(semaphore("master") is True)


# Generated at 2022-06-24 01:34:25.741324
# Unit test for function travis
def test_travis():
    # Function under test
    def internal_test_travis():
        travis(branch='master')

    # should pass
    try:
        os.environ['TRAVIS_BRANCH'] = 'master'
        os.environ['TRAVIS_PULL_REQUEST'] = 'false'
        internal_test_travis() # calls travis(branch="master")
    except CiVerificationError:
        assert False
    os.environ.pop('TRAVIS_BRANCH', None)
    os.environ.pop('TRAVIS_PULL_REQUEST', None)
    # should fail

# Generated at 2022-06-24 01:34:33.833978
# Unit test for function gitlab
def test_gitlab():
    try:
        gitlab("master")
        assert False, "Should have raised a CiVerificationError"
    except CiVerificationError:
        pass

    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    gitlab("master")

    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "1234"
    try:
        gitlab("master")
        assert False, "Should have raised a CiVerificationError"
    except CiVerificationError:
        pass

    # Cleanup
    del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-24 01:34:37.710866
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "succeeded"
    semaphore("master")
    os.environ["BRANCH_NAME"] = "develop"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    semaphore("master")


# Generated at 2022-06-24 01:34:45.560014
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "1.0.0"
    os.environ["BITBUCKET_PR_ID"] = "1"
    assert check("1.0.0") == True
    os.environ["BITBUCKET_PR_ID"] = None
    assert check("1.0.0") == True
    os.environ["BITBUCKET_BRANCH"] = "0.0.1"
    assert check("1.0.0") == False


# Generated at 2022-06-24 01:34:56.131763
# Unit test for function check
def test_check():
    """
    Test check function.
    :return:
    """
    try:
        check("master")
    except Exception:
        assert  False

    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check("master")

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = ""
    check("master")

    os.environ["FRIGG"] = "true"

# Generated at 2022-06-24 01:35:06.128062
# Unit test for function gitlab
def test_gitlab():
    env_orig = os.environ.copy()

    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    try:
        gitlab("master")
        assert 1 == 1
    except CiVerificationError:
        assert 1 == 0

    os.environ["CI_MERGE_REQUEST_ID"] = ""
    try:
        gitlab("master")
        assert 1 == 1
    except CiVerificationError:
        assert 1 == 0

    os.environ["CI_MERGE_REQUEST_ID"] = "123"
    try:
        gitlab("master")
        assert 1 == 0
    except CiVerificationError:
        assert 1 == 1


# Generated at 2022-06-24 01:35:11.864653
# Unit test for function jenkins
def test_jenkins():
    os.environ['BRANCH_NAME'] = "master"
    os.environ['JENKINS_URL'] = ''

    try:
        jenkins("master")
    except:
        assert False


# Generated at 2022-06-24 01:35:22.869480
# Unit test for function check
def test_check():
    class Environment():
        def __init__(self, env):
            self.env = env

        def __enter__(self):
            self.original = os.environ.copy()
            os.environ = self.env
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            os.environ = self.original

    def raises_error(func):
        def func_wrapper(*args, **kwargs):
            with raises(CiVerificationError):
                func(*args, **kwargs)

        try:
            func_wrapper()
        except TypeError:
            raise Exception()

    def test_travis(branch):
        travis(branch)

    def test_semaphore(branch):
        semaphore(branch)


# Generated at 2022-06-24 01:35:26.131686
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]



# Generated at 2022-06-24 01:35:35.580122
# Unit test for function travis
def test_travis():
    """
    Performs necessary checks to ensure that the travis build is one
    that should create releases.
    """
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis(branch = "master") == True
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis(branch = "master") == True
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    assert travis(branch = "master") == True

# Generated at 2022-06-24 01:35:45.121445
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check("master")
    os.environ["CI_COMMIT_REF_NAME"] = "feature"
    check("master")
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    del os.environ["CI_COMMIT_REF_NAME"]
    try:
        check("master")
    except CiVerificationError:
        os.unsetenv("CI_COMMIT_REF_NAME")


# Generated at 2022-06-24 01:35:48.739235
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://dev.azkaban.org:80/jenkins/"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "1234"
    check(branch="master")

# Generated at 2022-06-24 01:35:56.296264
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket()

    os.environ["BITBUCKET_BRANCH"] = "develop"
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket(branch="develop")

    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket()
        assert False, "Should not run on a PR."
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:35:59.225131
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert frigg("master")



# Generated at 2022-06-24 01:36:03.168117
# Unit test for function gitlab
def test_gitlab():
    """
    Test for gitlab function
    """
    os.environ["CI_COMMIT_REF_NAME"] = "branch"
    gitlab("branch")



# Generated at 2022-06-24 01:36:08.716152
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_BRANCH"] = "false"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    check()

# Generated at 2022-06-24 01:36:16.265894
# Unit test for function checker
def test_checker():
    def increment(x: int) -> int:
        return x + 1

    wrapped_increment = checker(increment)
    assert wrapped_increment(1) == 2

    def raise_exception(x: int) -> None:
        raise AssertionError

    wrapped_exception = checker(raise_exception)
    try:
        wrapped_exception(1)
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-24 01:36:20.673093
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1234"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    check()

# Generated at 2022-06-24 01:36:24.476805
# Unit test for function circle
def test_circle():
    assert checker(circle)(branch="dev")
    assert checker(circle)(branch="staging")
    assert checker(circle)(branch="production")

# Generated at 2022-06-24 01:36:29.931549
# Unit test for function check
def test_check():
    """
    Unit test for function check
    """
    try:
        check()
    except CiVerificationError:
        assert True
    else:
        assert False


# Unit tests for function travis

# Generated at 2022-06-24 01:36:33.733203
# Unit test for function bitbucket
def test_bitbucket():
    bitbucket("master")

    os.environ["BITBUCKET_BRANCH"] = "development"
    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Bitbucket check should have failed.")



# Generated at 2022-06-24 01:36:37.562051
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST'] = 'false'
    check('master')

# Generated at 2022-06-24 01:36:41.195013
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    #TODO: add cases for other elements
    check("master")
    check("not-master")

# Generated at 2022-06-24 01:36:41.705183
# Unit test for function frigg
def test_frigg():
    pass

# Generated at 2022-06-24 01:36:45.058937
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master") == True
    assert os.environ.get("BRANCH_NAME") == "master"
    assert os.environ.get("PULL_REQUEST_NUMBER") is None
    assert os.environ.get("SEMAPHORE_THREAD_RESULT") != "failed"



# Generated at 2022-06-24 01:36:55.682167
# Unit test for function bitbucket
def test_bitbucket():
    """ test function bitbucket """
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1234"
    try:
        bitbucket("master")
    except CiVerificationError as cve:
        assert str(cve) == "The verification check for the environment did not pass."
    finally:
        del os.environ["BITBUCKET_BUILD_NUMBER"]
        del os.environ["BITBUCKET_BRANCH"]
        del os.environ["BITBUCKET_PR_ID"]


# Generated at 2022-06-24 01:37:05.441545
# Unit test for function semaphore
def test_semaphore():
    """
    Unit tests for function semaphore
    """

# Generated at 2022-06-24 01:37:12.629537
# Unit test for function check
def test_check():
    """
    Unit test for function check
    """
    try:
        os.environ["TRAVIS"] = "true"
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        check()
    except CiVerificationError:
        assert False

    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
    except CiVerificationError:
        assert True

    os.environ["TRAVIS"] = ""
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        check()
    except CiVerificationError:
        assert False

    return 0

# Generated at 2022-06-24 01:37:15.153233
# Unit test for function checker
def test_checker():
    def bad_func():
        assert False

    def good_func():
        assert True

    assert not checker(bad_func)()
    assert checker(good_func)()

# Generated at 2022-06-24 01:37:25.164716
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = 'true'

    # Test TravisCI's env var
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    check()

    # Test Circle CI's env var
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = 'false'
    check()

    # Test Semaphore's env var
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = 'false'
    check()

    # Test Frigg's env var

# Generated at 2022-06-24 01:37:26.475745
# Unit test for function bitbucket
def test_bitbucket():
    assert checker(bitbucket)("master")
    assert checker(bitbucket)(None) is not True

# Generated at 2022-06-24 01:37:31.219137
# Unit test for function check
def test_check():
    """
    Test check function
    """
    check()


# Unit tests for check decorator

# Generated at 2022-06-24 01:37:35.020609
# Unit test for function check
def test_check():
    os.environ["CI_COMMIT_REF_NAME"] = 'master'
    assert check() is None
    assert check('release') is None
    # AssertionError
    os.environ["CI_COMMIT_REF_NAME"] = 'release'
    try:
        assert check()
    except CiVerificationError:
        assert True



# Generated at 2022-06-24 01:37:41.195206
# Unit test for function semaphore
def test_semaphore():
    for branch in ["master", "dev"]:
        try:
            os.environ["SEMAPHORE"] = "true"
            os.environ["BRANCH_NAME"] = branch
            os.environ["PULL_REQUEST_NUMBER"] = None
            os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
            semaphore(branch)
        except AssertionError:
            raise AssertionError("Failed for %s" % branch)



# Generated at 2022-06-24 01:37:45.341485
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    os.environ['FRIGG_PULL_REQUEST'] = "false"
    frigg("master")

# Generated at 2022-06-24 01:37:47.775948
# Unit test for function circle
def test_circle():
    assert os.environ.get("CIRCLECI") == "true"
    assert not os.environ.get("CI_PULL_REQUEST")

# Generated at 2022-06-24 01:37:52.154083
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "test"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("test")

# Generated at 2022-06-24 01:37:57.603397
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "153"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "feature"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass


# Generated at 2022-06-24 01:38:01.214232
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "12345"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""

    assert bitbucket("master")

# Generated at 2022-06-24 01:38:02.191709
# Unit test for function circle
def test_circle():
    circle("master")
    pass


# Generated at 2022-06-24 01:38:06.056327
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    check("master")

# Generated at 2022-06-24 01:38:09.312669
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    check()


# Generated at 2022-06-24 01:38:14.710948
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg(branch="master")
    assert (
        os.environ.get("FRIGG_BUILD_BRANCH") == "master"
        and os.environ.get("FRIGG_PULL_REQUEST") == "false"
    )
    try:
        frigg(branch="wrong")
    except CiVerificationError:
        assert True



# Generated at 2022-06-24 01:38:18.064410
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["TRAVIS_BRANCH"] = "develop"
    check(branch="develop")



# Generated at 2022-06-24 01:38:20.184853
# Unit test for function checker
def test_checker():
    """
    Tests that checker decorates a function, and returns
    """

    @checker
    def test_func():
        """
        Simple test function
        """
        assert True

    try:
        test_func()
    except CiVerificationError:
        assert False

# Generated at 2022-06-24 01:38:30.486438
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
    assert semaphore(branch="master")

    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "48"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert not semaphore(branch="master")

    os.environ["BRANCH_NAME"] = "develop"
    os.environ["PULL_REQUEST_NUMBER"] = "48"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"

# Generated at 2022-06-24 01:38:33.450061
# Unit test for function check
def test_check():
    os.environ['GIT_BRANCH'] = 'development'
    os.environ['JENKINS_URL'] = 'jonis.devops.jnj.com'
    check(branch = 'master')

# Generated at 2022-06-24 01:38:34.319657
# Unit test for function circle
def test_circle():
    assert circle(branch='master')

# Generated at 2022-06-24 01:38:41.882013
# Unit test for function semaphore
def test_semaphore():
    os.environ['SEMAPHORE'] = "true"
    os.environ['BRANCH_NAME'] = "master"
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = None
    assert True == semaphore(branch="master")
    os.environ['SEMAPHORE_THREAD_RESULT'] = "failed"
    assert True != semaphore(branch="master")


# Generated at 2022-06-24 01:38:43.552071
# Unit test for function check
def test_check():
    # Assert no error raised
    check(os.environ.get("TRAVIS_BRANCH"))

# Generated at 2022-06-24 01:38:48.856202
# Unit test for function checker
def test_checker():
    @checker
    def my_test():
        raise AssertionError()
    try:
        my_test()
    except CiVerificationError:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-24 01:38:51.560535
# Unit test for function check
def test_check():
    check()

# Generated at 2022-06-24 01:38:55.015248
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "0"
    check()



# Generated at 2022-06-24 01:39:00.415711
# Unit test for function circle
def test_circle():
    branch = "master"
    assert os.environ.get("CIRCLECI") == "true"
    assert os.environ.get("CIRCLE_BRANCH") == branch
    assert not os.environ.get("CI_PULL_REQUEST")

# Generated at 2022-06-24 01:39:02.993482
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("develop")

# Generated at 2022-06-24 01:39:08.223157
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "dummy"
    os.environ["BRANCH_NAME"] = "not_master"
    try:
        jenkins(branch="master")
    except CiVerificationError:
        pass



# Generated at 2022-06-24 01:39:14.737696
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    try:
        travis("master")
    except CiVerificationError:
        assert False
    finally:
        assert True

    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"

    try:
        travis("master")
        assert False
    except CiVerificationError:
        assert True

    try:
        travis("develop")
    except CiVerificationError:
        assert False
    finally:
        assert True


# Generated at 2022-06-24 01:39:20.568730
# Unit test for function checker
def test_checker():
    def my_function(branch):
        assert branch == "master"

    decorated_function = checker(my_function)
    assert decorated_function("master")

    def my_function_that_fails(branch):
        assert branch == "master"
        assert branch == "develop"

    decorated_failing_function = checker(my_function_that_fails)
    try:
        decorated_failing_function("master")
    except CiVerificationError:
        pass
    else:
        assert False, "Expected CiVerificationError"