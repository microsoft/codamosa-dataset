

# Generated at 2022-06-24 01:29:19.017120
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = None

    gitlab("master")

    # cleanup
    os.environ["CI_COMMIT_REF_NAME"] = None
    os.environ["CI_MERGE_REQUEST_IID"] = None

# Generated at 2022-06-24 01:29:30.410471
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    del os.environ["BITBUCKET_PR_ID"]
    assert bitbucket("master")

    with open(os.devnull, "w") as devnull:
        stderr = os.dup(2)
        os.dup2(devnull.fileno(), 2)

        os.environ["BITBUCKET_BRANCH"] = "dev"
        del os.environ["BITBUCKET_PR_ID"]
        assert not bitbucket("master")

        os.environ["BITBUCKET_BRANCH"] = "master"
        os.environ["BITBUCKET_PR_ID"] = "123"
        assert not bitbucket("master")


# Generated at 2022-06-24 01:29:31.470412
# Unit test for function bitbucket
def test_bitbucket():
    bitbucket("master")
    assert True


# Generated at 2022-06-24 01:29:36.041993
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["SEMAPHORE"] = "true"
    os.environ["FRIGG"] = "true"
    os.environ["CIRCLECI"] = "true"
    os.environ["GITLAB_CI"] = "true"
    os.environ["JENKINS_URL"] = "true"
    os.environ["BITBUCKET_BUILD_NUMBER"] = "true"



# Generated at 2022-06-24 01:29:40.423392
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check("master")
    del os.environ["CIRCLECI"]
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]


# Generated at 2022-06-24 01:29:45.331054
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master") == True
    assert semaphore("somebranch") == True
    assert semaphore("someotherbranch") == True


# Generated at 2022-06-24 01:29:50.495635
# Unit test for function checker
def test_checker():
    """
    Asserts that checker decorator raises a proper Error
    """
    @checker
    def bad_func():
        """
        A function that should raise an AssertionError
        """
        assert False

    try:
        bad_func()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:29:59.423176
# Unit test for function semaphore
def test_semaphore():
    """
    Perform all necessary checks to ensure that the semaphore build is successful,
    on the correct branch and not a pull-request.
    """
    os.environ.update(
        {
            "BRANCH_NAME": "master",
            "PULL_REQUEST_NUMBER": None,
            "SEMAPHORE_THREAD_RESULT": "passed",
        }
    )
    assert semaphore("master")

    os.environ.update({"SEMAPHORE_THREAD_RESULT": "failed"})
    assert semaphore("develop") is False

# Generated at 2022-06-24 01:30:02.570111
# Unit test for function bitbucket
def test_bitbucket():
    """
    test_bitbucket
    """
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "hello"
    bitbucket("hello")

# Generated at 2022-06-24 01:30:04.133311
# Unit test for function frigg
def test_frigg():
    assert frigg("master")


# Generated at 2022-06-24 01:30:06.157836
# Unit test for function checker
def test_checker():
    def test_function():
        assert False

    wrapped_function = checker(test_function)
    wrapped_function()

# Generated at 2022-06-24 01:30:15.187728
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    try:
        frigg("test_branch")
    except:
        assert False
    os.environ["FRIGG_BUILD_BRANCH"] = "not_the_right_branch"
    try:
        frigg("test_branch")
        assert False
    except CiVerificationError:
        pass
    os.environ["FRIGG_BUILD_BRANCH"] = "test_branch"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        frigg("test_branch")
        assert False
    except CiVerificationError:
        pass
    del os.environ["FRIGG_BUILD_BRANCH"]

# Generated at 2022-06-24 01:30:25.177421
# Unit test for function semaphore
def test_semaphore():
    # Lambda function to reset environment
    reset_env = lambda: os.environ.update({
        "BRANCH_NAME": None,
        "PULL_REQUEST_NUMBER": None,
        "SEMAPHORE_THREAD_RESULT": None
    })

    # Test for when everything passes
    reset_env()
    os.environ.update({
        "BRANCH_NAME": "master",
        "PULL_REQUEST_NUMBER": None,
        "SEMAPHORE_THREAD_RESULT": "passed"
    })
    assert semaphore("master")

    # Test for when BRANCH_NAME != desired branch
    reset_env()

# Generated at 2022-06-24 01:30:27.497394
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "correctBranch"
    os.environ["CI_PULL_REQUEST"] = "false"

    circle("correctBranch")

# Generated at 2022-06-24 01:30:30.327535
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-24 01:30:38.216527
# Unit test for function checker
def test_checker():
    class TestClass():
        def success(self):
            """
            Test function that passes.
            :return:
            """
            pass

        def fail(self):
            """
            Test function that fails.
            :return:
            """
            assert False

        def raise_exception(self,exception):
            """
            Test function that raises an exception.
            :param exception:
            :return:
            """
            raise exception

    instance = TestClass()

    assert checker(instance.success)() == True
    assert checker(instance.fail)() == False

    try:
        checker(instance.raise_exception)(Exception())
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-24 01:30:42.797566
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    semaphore("master")

    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    semaphore("master")

# Generated at 2022-06-24 01:30:49.594217
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "test"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = ''
    jenkins("master")
    os.environ["CHANGE_ID"] = "123456"
    jenkins("master")
    jenkins("master2")
    del os.environ["CHANGE_ID"]
    del os.environ["JENKINS_URL"]

# Generated at 2022-06-24 01:30:54.863053
# Unit test for function jenkins
def test_jenkins():
    import os
    os.environ["JENKINS_URL"] = "http://abc.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = ""
    print("Test started")
    try:
        jenkins()
        print("This line will not be executed")
    except CiVerificationError as e:
        print("Test passed")
        print("Cannot be a pull request with no change id")

# Generated at 2022-06-24 01:30:57.801423
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://ci.example.com"
    os.environ["BRANCH_NAME"] = "master"
    check()
    del os.environ["JENKINS_URL"]
    del os.environ["BRANCH_NAME"]


# Generated at 2022-06-24 01:30:59.818079
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    try:
        circle("master")
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-24 01:31:02.001022
# Unit test for function travis
def test_travis():
    os.environ.setdefault('TRAVIS_BRANCH', 'master')
    os.environ.setdefault('TRAVIS_PULL_REQUEST', 'false')
    travis()


# Generated at 2022-06-24 01:31:04.082912
# Unit test for function checker
def test_checker():
    func = checker(lambda: False)
    assert not func()
    try:
        checker(lambda: True)()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-24 01:31:09.898860
# Unit test for function checker
def test_checker():
    """
    Test the checker decorator.
    """
    def hello():
        raise AssertionError()
    assert checker(hello)() is False
    hello()


if __name__ == "__main__":
    # Unit test for function check
    test_checker()

# Generated at 2022-06-24 01:31:11.210208
# Unit test for function checker
def test_checker():
    def test_func():
        raise AssertionError

    test_func()

# Generated at 2022-06-24 01:31:16.245619
# Unit test for function gitlab
def test_gitlab():
    # Set the environment variable
    os.environ["GITLAB_CI"] = "true"
    # Check that check is running properly
    try:
        check()
        assert False
    # The except should be raised as GITLAB_CI is set but not the
    # proper environment variables
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."
        assert os.environ["GITLAB_CI"] == "true"

# Generated at 2022-06-24 01:31:24.647752
# Unit test for function bitbucket
def test_bitbucket():
    # Callback function for bitbucket
    def callback():
        bitbucket()
    # If a key environment variable is missing,
    # the callback function should raise an exception
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert True is callback()

    # If a key environment variable is missing,
    # the callback function should raise an exception
    del os.environ["BITBUCKET_BUILD_NUMBER"]
    assert False is callback()

    # If the two environment variables do not match,
    # the callback function should raise an exception
    os.environ["BITBUCKET_BRANCH"] = "not_master"
    assert False is callback()

    # If the two environment variables do not match

# Generated at 2022-06-24 01:31:26.778810
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "whatever"
    check()

# Generated at 2022-06-24 01:31:34.366840
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH']='master'
    os.environ['TRAVIS_PULL_REQUEST']='false'
    assert travis('master')
    os.environ['TRAVIS_BRANCH']='develop'
    assert not travis('master')
    os.environ['TRAVIS_BRANCH']='master'
    os.environ['TRAVIS_PULL_REQUEST']='true'
    assert not travis('master')

# Generated at 2022-06-24 01:31:44.960245
# Unit test for function gitlab
def test_gitlab():
    # Checking if GITLAB_CI is true to satisfy check
    os.environ["GITLAB_CI"] = "true"

    # Checking if CI_COMMIT_REF_NAME is correct
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()

    # Checking if gitlab check fails when CI_COMMIT_REF_NAME is different
    os.environ["CI_COMMIT_REF_NAME"] = "some_branch"
    try:
        check()
    except CiVerificationError:
        pass

    # Deleting env variables
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["GITLAB_CI"]

# Generated at 2022-06-24 01:31:52.437771
# Unit test for function travis
def test_travis():
    assert travis("master")
    os.environ["TRAVIS_BRANCH"] = "master1"
    try:
        travis("master")
    except Exception as e:
        assert isinstance(e, CiVerificationError)
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except Exception as e:
        assert isinstance(e, CiVerificationError)


# Generated at 2022-06-24 01:31:57.250656
# Unit test for function travis
def test_travis():
    os.environ.update(
        {
            "TRAVIS": "true",
            "TRAVIS_BRANCH": "master",
            "TRAVIS_PULL_REQUEST": "false",
        }
    )
    branch="master"
    check(branch)


# Generated at 2022-06-24 01:31:59.541521
# Unit test for function jenkins
def test_jenkins():
    os.environ.update({
        "JENKINS_URL": "test",
        "GIT_BRANCH": "master"})
    jenkins("master")



# Generated at 2022-06-24 01:32:04.382667
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    del os.environ["PULL_REQUEST_NUMBER"]
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    try:
        semaphore(branch="master")
    except CiVerificationError:
        assert False
    else:
        assert True

# Generated at 2022-06-24 01:32:05.512235
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("branch1")
    assert jenkins("branch2")

# Generated at 2022-06-24 01:32:07.965465
# Unit test for function check
def test_check():
    try:
        check(branch = "develop")
    except CiVerificationError:
        assert True

# Generated at 2022-06-24 01:32:14.394742
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '1'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = '1'
    bitbucket('master')
    assert os.environ['BITBUCKET_PR_ID'] == ''
    assert os.environ['BITBUCKET_BRANCH'] == 'feature'

# Generated at 2022-06-24 01:32:17.987629
# Unit test for function circle
def test_circle():
    """
    Test the circle checks
    """
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    circle("master")
    os.environ["CI_PULL_REQUEST"] = "true"
    circle("master")



# Generated at 2022-06-24 01:32:26.365592
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = "true"
    os.environ['CIRCLE_BRANCH'] = "master"
    os.environ['CI_PULL_REQUEST'] = "true"
    assert circle(branch="staging")
    os.environ['CIRCLE_BRANCH'] = "master"
    os.environ['CI_PULL_REQUEST'] = ""
    assert circle(branch="master")
    os.environ['CIRCLECI'] = "false"


# Generated at 2022-06-24 01:32:33.567175
# Unit test for function frigg
def test_frigg():
    # Test Conditions
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "semantic-release"
    os.environ["FRIGG_PULL_REQUEST"] = "false"

    assert frigg()

    # Test Conditions
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "semantic-release"
    os.environ["FRIGG_PULL_REQUEST"] = "true"

    assert not frigg()


# Generated at 2022-06-24 01:32:34.472739
# Unit test for function travis
def test_travis():
    assert travis("master")


# Generated at 2022-06-24 01:32:41.073057
# Unit test for function semaphore
def test_semaphore():
    os.environ['SEMAPHORE'] = "true"
    os.environ['BRANCH_NAME'] = "master"
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = "success"

    semaphore(branch="master")

# Generated at 2022-06-24 01:32:45.066784
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1234"
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket()

# Generated at 2022-06-24 01:32:49.222341
# Unit test for function checker

# Generated at 2022-06-24 01:32:55.093858
# Unit test for function frigg
def test_frigg():
    """
    A unit test for the frigg function.
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    # test with branch name that should pass
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    # test with branch name that should not pass
    try:
        frigg("master")
    except CiVerificationError as e:
        assert isinstance(e, CiVerificationError)


# Generated at 2022-06-24 01:32:56.581412
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert gitlab("master")



# Generated at 2022-06-24 01:32:59.950756
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "test"
    os.environ["FRIGG_PULL_REQUEST"] = "False"
    check()

# Generated at 2022-06-24 01:33:04.039320
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "test"
    gitlab("test")
    os.environ["CI_COMMIT_REF_NAME"] = "test3"
    try:
        gitlab("test")
    except CiVerificationError as ce:
        assert "environment did not pass" in ce.errors


# Generated at 2022-06-24 01:33:15.275259
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        check()
    except CiVerificationError as e:
        print(e)
        assert False
    os.environ["TRAVIS_BRANCH"] = "wrong"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check()
        assert False
    except CiVerificationError as e:
        print(e)
        assert True
    del os.environ["TRAVIS_BRANCH"]
    try:
        check()
        assert False
    except CiVerificationError as e:
        print(e)


# Generated at 2022-06-24 01:33:22.812672
# Unit test for function frigg
def test_frigg():
    assert os.environ.get("FRIGG") != "true"
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    assert frigg("master") is True
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]

# Generated at 2022-06-24 01:33:33.050732
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    bitbucket('master')
    assert os.environ['BITBUCKET_BRANCH'] == 'master'
    os.environ['BITBUCKET_BRANCH'] = 'notmaster'
    try:
        bitbucket('master')
        assert False
    except CiVerificationError as e:
        assert str(e) == 'The verification check for the environment did not pass.'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = '123'
    try:
        bitbucket('master')
        assert False
    except CiVerificationError as e:
        assert str(e) == 'The verification check for the environment did not pass.'

# Generated at 2022-06-24 01:33:36.909901
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for function bitbucket
    """
    assert not bitbucket("master")
    os.environ["BITBUCKET_BRANCH"] = "notmaster"

    with open(".git/HEAD", "w") as f:
        f.write("refs/heads/master")
    assert bitbucket("master")

    # Check pull-request
    os.environ["BITBUCKET_PR_ID"] = "1"
    assert not bitbucket("master")
    del os.environ["BITBUCKET_PR_ID"]



# Generated at 2022-06-24 01:33:40.732146
# Unit test for function circle
def test_circle():
    # Set environment variables for test
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()


# Generated at 2022-06-24 01:33:44.950168
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    bitbucket("master")



# Generated at 2022-06-24 01:33:47.489903
# Unit test for function jenkins
def test_jenkins():
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")

# Generated at 2022-06-24 01:33:54.845974
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    check()
    os.environ['CIRCLE_BRANCH'] = 'develop'
    check(branch='develop')
    del os.environ['CIRCLE_BRANCH']
    os.environ['CI_PULL_REQUEST'] = 'true'
    try:
        check()
    except CiVerificationError as e:
        os.environ['CIRCLE_BRANCH'] = 'develop'
        check(branch='develop')
    del os.environ['CI_PULL_REQUEST']


# Generated at 2022-06-24 01:33:55.592062
# Unit test for function check
def test_check():
    assert check()

# Generated at 2022-06-24 01:33:59.321413
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket(branch="master")
    os.environ["BITBUCKET_PR_ID"] = "123"
    bitbucket(branch="master")
    return True

# Generated at 2022-06-24 01:34:04.451119
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "testbranch"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()



# Generated at 2022-06-24 01:34:09.497791
# Unit test for function checker
def test_checker():
    def mock_function():
        assert False

    def mock_function_bool():
        assert True

    mock_function_bool = checker(mock_function_bool)

    with mock_function_bool.__wrapped__:
        mock_function_bool()

    with mock_function_bool.__wrapped__:
        mock_function()



# Generated at 2022-06-24 01:34:17.920328
# Unit test for function semaphore
def test_semaphore():
    import os
    import unittest
    import semantic_release.ci_checks as ci_checks

    class TestCIChecks(unittest.TestCase):
        def test_semaphore(self):
            os.environ["BRANCH_NAME"] = "master"
            os.environ["PULL_REQUEST_NUMBER"] = None
            os.environ["SEMAPHORE_THREAD_RESULT"] = "success"
            ci_checks.semaphore("master")

    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-24 01:34:26.205887
# Unit test for function semaphore
def test_semaphore():
    # Semaphore CI environment is not set
    assert not semaphore("master")

    # Semaphore CI environment is set
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    assert semaphore("master")

    # Incorrect Semaphore CI environment
    os.environ["BRANCH_NAME"] = "develop"
    assert not semaphore("master")

    # Semaphore CI environment is not set
    del os.environ["SEMAPHORE"]
    assert not semaphore("master")

    # Semaphore CI environment is set, but not on the correct branch
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "develop"
    assert not semaph

# Generated at 2022-06-24 01:34:32.907240
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = ''

    branch = 'master'

    frigg(branch)


# Generated at 2022-06-24 01:34:37.806400
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "develop"
    os.environ['FRIGG_PULL_REQUEST'] = "true"
    try:
        frigg("develop")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Expected check function to raise a CiVerificationError")

    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    assert frigg("master")



# Generated at 2022-06-24 01:34:43.458329
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


if __name__ == "__main__":
    check()

# Generated at 2022-06-24 01:34:53.444850
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    assert check(branch="master") is True
    assert os.environ["CIRCLECI"] == "true"
    assert os.environ["CI_PULL_REQUEST"] == "true"
    assert os.environ["CIRCLE_BRANCH"] == "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    assert check(branch="master") is True
    assert os.environ["CIRCLECI"] == "true"
    assert os.environ["CI_PULL_REQUEST"] == "false"

# Generated at 2022-06-24 01:35:03.756148
# Unit test for function checker
def test_checker():
    """
    test_checker verifies the decorator checker works as expected
    """

    # Create a function that will pass the test
    @checker
    def passing_test(foo):
        assert foo == "bar"

    assert passing_test("bar") is True

    # Create a function that will fail the test
    @checker
    def failing_test(foo):
        assert foo == "baz"

    try:
        failing_test("bar")
        assert False
    except CiVerificationError:
        assert True

    # Create a function that raises an exception and is not AssertionError
    # that should re-raise the same exception
    @checker
    def non_assertion_error_test(foo):
        raise Exception("Non-assertion exception")


# Generated at 2022-06-24 01:35:06.076303
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = False

    check()

test_frigg()

# Generated at 2022-06-24 01:35:16.793109
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = "12"
    branch = "develop"
    test_result = False
    try:
        bitbucket(branch)
    except CiVerificationError:
        test_result = True
    del os.environ["BITBUCKET_PR_ID"]
    assert test_result

    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = ""
    branch = "develop"
    test_result = False
    try:
        bitbucket(branch)
    except CiVerificationError:
        test_result = True
    assert test_result

# Generated at 2022-06-24 01:35:22.439815
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = ""
    os.environ["CIRCLE_BRANCH"] = "different_branch"
    try:
        check()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:35:28.520651
# Unit test for function frigg
def test_frigg():
    # Test os environ with success
    os.environ["FRIGG_BUILD_BRANCH"] = 'master'
    os.environ["FRIGG_BUILD_PULL_REQUEST"] = False
    frigg(branch)
    # Test os.environ with Pull Request
    os.environ["FRIGG_BUILD_BRANCH"] = 'master'
    os.environ["FRIGG_BUILD_PULL_REQUEST"] = True
    try:
        frigg(branch)
    except CiVerificationError as e:
        assert "The verification check for the environment did not pass." in str(
            e
        )
    # Test os environ with wrong branch
    os.environ["FRIGG_BUILD_BRANCH"] = 'other'

# Generated at 2022-06-24 01:35:32.178416
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CI_PULL_REQUEST'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'develop'
    circle('master')


# Generated at 2022-06-24 01:35:36.187924
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    check("master")
    os.environ["CI_MERGE_REQUEST_ID"] = "null"
    check("master")

# Generated at 2022-06-24 01:35:36.768468
# Unit test for function check
def test_check():
    assert check()

# Generated at 2022-06-24 01:35:41.122634
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "url"
    os.environ["CHANGE_ID"] = ""
    check()

# Generated at 2022-06-24 01:35:49.191219
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test for function bitbucket
    """
    os.environ['BITBUCKET_BUILD_NUMBER'] = 'test'
    os.environ['BITBUCKET_BRANCH'] = 'branch'
    assert bitbucket('branch')

    os.environ['BITBUCKET_BUILD_NUMBER'] = 'test'
    os.environ['BITBUCKET_BRANCH'] = 'branch'
    os.environ['BITBUCKET_PR_ID'] = 'test'
    assert not bitbucket('branch')

# Generated at 2022-06-24 01:35:56.660869
# Unit test for function check
def test_check():
    """
    Unit test for function check
    """
    # test case with TRAVIS
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    check("master")

    # test case with SEMAPHORE
    os.environ["TRAVIS"] = ""
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    check("master")

    # test case with FRIGG

# Generated at 2022-06-24 01:36:00.126267
# Unit test for function checker
def test_checker():
    @checker
    def check_test(branch: str = "master"):
        assert False

    from semantic_release.errors import CiVerificationError
    try:
        check_test()
    except CiVerificationError:
        pass
    else:
        assert False, "CiVerificationError should have been raised"

# Generated at 2022-06-24 01:36:10.153871
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "http://localhost:8080"
    os.environ["CHANGE_ID"] = "123456"

    try:
        jenkins("master")
    except:
        pass

    del os.environ["CHANGE_ID"]
    try:
        jenkins("master")
    except:
        pass

    os.environ["GIT_BRANCH"] = "branch"
    try:
        jenkins("master")
        raise Exception("Wrong branch name should raise exception")
    except CiVerificationError:
        pass

    os.environ["GIT_BRANCH"] = "master"


# Generated at 2022-06-24 01:36:11.651127
# Unit test for function check
def test_check():
    os.environ["FRIGG"] = "true"
    check()
    os.environ["FRIGG"] = "false"

# Generated at 2022-06-24 01:36:19.665571
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_PR_ID'] = ""
    try:
        bitbucket("master")
    except AssertionError:
        raise Exception("ERROR : bitbucket function returns false on a valid build")

    os.environ['BITBUCKET_BRANCH'] = "master"
    os.environ['BITBUCKET_PR_ID'] = "1234"
    try:
        bitbucket("master")
    except CiVerificationError:
        return "SUCCESS : bitbucket function could detect pull request"
    raise Exception("ERROR : bitbucket function returns true on pull request")


# Generated at 2022-06-24 01:36:21.728935
# Unit test for function semaphore
def test_semaphore():
    os.environ['SEMAPHORE'] = 'true'
    os.environ['BRANCH_NAME'] = 'develop'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    semaphore('develop')

# Generated at 2022-06-24 01:36:24.822968
# Unit test for function semaphore
def test_semaphore():
    # Check if the checks are working
    assert semaphore("random_branch")


# Generated at 2022-06-24 01:36:27.013281
# Unit test for function gitlab
def test_gitlab():
    """
    Unit test for function gitlab
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    gitlab("master")



# Generated at 2022-06-24 01:36:31.861448
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "https://www.jenkins.com"
    os.environ['BRANCH_NAME'] = "master"
    os.environ['GIT_BRANCH'] = "master"
    os.environ.pop('CHANGE_ID', None)
    assert check()



# Generated at 2022-06-24 01:36:37.102853
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "fix-jenkins"
    check(branch="fix-jenkins")
    assert True


# Generated at 2022-06-24 01:36:42.231685
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    check("master")



# Generated at 2022-06-24 01:36:45.291730
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""

    try:
        check()
    except CiVerificationError:
        assert False



# Generated at 2022-06-24 01:36:50.539749
# Unit test for function semaphore
def test_semaphore():
    import os
    os.environ['SEMAPHORE'] = 'true'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    check()


# Generated at 2022-06-24 01:36:57.069667
# Unit test for function check
def test_check():
    def test_branch(branch):
        os.environ["TRAVIS"] = "true"
        os.environ["TRAVIS_BRANCH"] = branch
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        check("master")

    test_branch("master")

    try:
        test_branch("develop")
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:37:02.903778
# Unit test for function gitlab
def test_gitlab():
    try:
        os.environ["CI_COMMIT_REF_NAME"] = "master"
        os.environ["CI_MERGE_REQUEST_ID"] = ""
        gitlab(branch = "master")
    except CiVerificationError:
        pass
    else:
        raise Exception
    finally:
        del os.environ["CI_COMMIT_REF_NAME"]
        del os.environ["CI_MERGE_REQUEST_ID"]

# Generated at 2022-06-24 01:37:09.577721
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "circle-master"
    os.environ["CI_PULL_REQUEST"] = "true"
    assert check("circle-master")

    os.environ["CIRCLE_BRANCH"] = "circle-pr"
    assert not check("circle-master")

    del os.environ["CIRCLE_BRANCH"]
    os.environ["CIRCLE_BRANCH"] = "circle-master"
    assert check("circle-master")

    assert not check("circle-pr")


# Generated at 2022-06-24 01:37:13.292867
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = 'master'
    os.environ["TRAVIS_PULL_REQUEST"] = 'true'
    try:
        check()
    except CiVerificationError:
        assert True

#Unit test for function semaphore

# Generated at 2022-06-24 01:37:16.212799
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check()

# Generated at 2022-06-24 01:37:23.916663
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        pass
    else:
        assert False
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]



# Generated at 2022-06-24 01:37:34.124834
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ.pop("TRAVIS", None)
    os.environ.pop("TRAVIS_BRANCH", None)
    os.environ.pop("TRAVIS_PULL_REQUEST", None)
    assert "TRAVIS" not in os.environ
    assert "TRAVIS_BRANCH" not in os.environ
    assert "TRAVIS_PULL_REQUEST" not in os.environ
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"


# Generated at 2022-06-24 01:37:38.098163
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = "master"
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    semaphore("master")


# Generated at 2022-06-24 01:37:42.417071
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    gitlab("master")
    # pull request will raise exception
    os.environ['CI_COMMIT_REF_NAME'] = "pull-request"
    try:
        gitlab("master")
    except CiVerificationError:
        pass



# Generated at 2022-06-24 01:37:53.667617
# Unit test for function semaphore
def test_semaphore():
    # Test with successful build
    os.environ["SEMAPHORE"] = "true"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["BRANCH_NAME"] = "master"
    assert semaphore(os.environ["BRANCH_NAME"])

    # Test with failed build
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore(os.environ["BRANCH_NAME"]) == False

    # Test with failed build
    os.environ["PULL_REQUEST_NUMBER"] = "pull_request_number"
    assert semaphore(os.environ["BRANCH_NAME"]) == False

# Generated at 2022-06-24 01:38:03.489520
# Unit test for function bitbucket
def test_bitbucket():
    setattr(os, "environ", {
        "BITBUCKET_BRANCH": "master",
        "BITBUCKET_PR_ID": "123",
        "BITBUCKET_BUILD_NUMBER": "1"
    })
    try:
        bitbucket("master")  # if pull request
    except CiVerificationError:
        pass
    setattr(os, "environ", {
        "BITBUCKET_BRANCH": "master",
        "BITBUCKET_PR_ID": "",
        "BITBUCKET_BUILD_NUMBER": "1"
    })
    assert bitbucket("master") is True

# Generated at 2022-06-24 01:38:08.217962
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    frigg('master')
    os.environ['FRIGG_BUILD_BRANCH'] = 'hotfix'
    frigg('hotfix')

# Generated at 2022-06-24 01:38:10.922081
# Unit test for function checker
def test_checker():
    @checker
    def dummy():
        assert True

    assert dummy() is True

    @checker
    def dummy2():
        assert False

    try:
        dummy2()
    except CiVerificationError:
        assert True



# Generated at 2022-06-24 01:38:13.441477
# Unit test for function frigg
def test_frigg():
    assert os.environ.get("FRIGG") == "true"
    assert os.environ.get("FRIGG_BUILD_BRANCH") == "master"
    assert not os.environ.get("FRIGG_PULL_REQUEST")

# Generated at 2022-06-24 01:38:16.025953
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    frigg('master')


# Generated at 2022-06-24 01:38:27.877532
# Unit test for function checker
def test_checker():
    from semantic_release.errors import CiVerificationError
    from semantic_release.ci_checks import checker

    @checker
    def func_should_not_raise_error():
        pass

    func_should_not_raise_error()

    @checker
    def func_raises_assertion_error():
        assert False

    try:
        func_raises_assertion_error()
    except CiVerificationError:
        pass
    else:
        raise AssertionError('CiVerificationError not raised')

    @checker
    def func_raises_standard_error():
        raise RuntimeError('error')

    try:
        func_raises_standard_error()
    except RuntimeError:
        pass
    else:
        raise AssertionError('RuntimeError not raised')

# Generated at 2022-06-24 01:38:36.517073
# Unit test for function circle
def test_circle():
    class TestCiChecker:
        def test_ci_checker_circle_true(self):
            os.environ["CIRCLECI"] = "true"
            os.environ["CIRCLE_BRANCH"] = "master"
            assert circle("master") == True

        def test_ci_checker_circle_pull_request_true(self):
            os.environ["CI_PULL_REQUEST"] = "1"
            assert circle("master") == False

        def test_ci_checker_circle_false(self):
            os.environ["CIRCLECI"] = "false"
            assert circle("master") == False

        def test_ci_checker_circle_empty_branch(self):
            os.environ["cIRCLECI"] = "true"

# Generated at 2022-06-24 01:38:44.787360
# Unit test for function checker
def test_checker():
    @checker
    def _test_func():
        pass

    try:
        _test_func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("checker fails on correct call")

    try:
        @checker
        def _test_func2():
            raise AssertionError()
        _test_func2()
    except CiVerificationError:
        pass
    except AssertionError:
        raise AssertionError("checker fails on correct call")
    else:
        raise AssertionError("checker fails on correct call")

# Generated at 2022-06-24 01:38:49.899931
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch='master')
    os.environ.pop("TRAVIS_BRANCH")
    os.environ.pop("TRAVIS_PULL_REQUEST")


# Generated at 2022-06-24 01:38:55.933921
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg(branch="master")

    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]

    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg(branch="master")


# Generated at 2022-06-24 01:39:01.644116
# Unit test for function gitlab
def test_gitlab():
    """
    Unit test for function gitlab.
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    try:
        gitlab("master")
    except Exception as exception:
        assert False
    os.environ["CI_COMMIT_REF_NAME"] = "no-master"
    try:
        gitlab("master")
        assert False
    except Exception as exception:
        assert True


# Generated at 2022-06-24 01:39:03.085140
# Unit test for function circle
def test_circle():
    assert circle(branch="develop") == True


# Generated at 2022-06-24 01:39:05.103533
# Unit test for function travis
def test_travis():
    assert travis("master") is True


# Generated at 2022-06-24 01:39:06.744509
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "mybranch"
    os.environ["GITLAB_CI"] = "true"
    assert gitlab("mybranch")



# Generated at 2022-06-24 01:39:14.061868
# Unit test for function frigg
def test_frigg():
    """ If variable FRIGG is set and variable FRIGG_BUILD_BRANCH is not set, this function should raise a CiVerificationError. """
    os.environ["FRIGG"] = "true"
    with pytest.raises(CiVerificationError):
        frigg("master")
    os.environ.pop("FRIGG")
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    with pytest.raises(CiVerificationError):
        frigg("master")
    os.environ.pop("FRIGG_BUILD_BRANCH")
