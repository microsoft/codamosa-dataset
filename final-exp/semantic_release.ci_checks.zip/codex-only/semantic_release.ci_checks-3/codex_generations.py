

# Generated at 2022-06-24 01:29:22.343390
# Unit test for function checker
def test_checker():
    """
    Test suite for function checker
    """
    @checker
    def for_test():
        """
        For Testing
        """
        assert True

    @checker
    def for_test2():
        """
        For Testing
        """
        assert False

    assert for_test()
    try:
        for_test2()
        assert False, "Test should have failed"
    except CiVerificationError:
        assert True

# Generated at 2022-06-24 01:29:26.153319
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "true"
    jenkins("master")
    assert True


# Generated at 2022-06-24 01:29:30.846225
# Unit test for function checker
def test_checker():
    # When:
    @checker
    def false_func():
        return False

    # Then:
    # A ci verification error is raised
    try:
        false_func()
        assert False
    except CiVerificationError as e:
        assert True


# Generated at 2022-06-24 01:29:34.042203
# Unit test for function circle
def test_circle():
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = ''
    circle('master')
    os.environ['CIRCLE_BRANCH'] = 'develop'
    circle('master')


# Generated at 2022-06-24 01:29:38.491769
# Unit test for function circle
def test_circle():
    assert circle("master")
    os.environ["CIRCLE_BRANCH"] = "develop"
    assert circle("develop")
    del os.environ["CIRCLE_BRANCH"]
    try:
        assert circle("master") == True
    except CiVerificationError:
        assert True
    os.environ["CI_PULL_REQUEST"] = "https://github.com/relekang/semantic-release"
    try:
        assert circle("master") == True
    except CiVerificationError:
        assert True


# Generated at 2022-06-24 01:29:41.402096
# Unit test for function jenkins
def test_jenkins():
    os.environ.update(
        {
            "JENKINS_URL": "http://127.0.0.1:8080/",
            "BRANCH_NAME": "master",
            "CHANGE_ID": "",
        }
    )
    jenkins("master")



# Generated at 2022-06-24 01:29:42.711250
# Unit test for function check
def test_check():
    """
    This function tests the check function alone
    """
    try:
        check()
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:29:50.401174
# Unit test for function jenkins
def test_jenkins():
    """
    Unit tests for jenkins()
    """
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "https://some_url"
    assert jenkins("master") == True

    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "https://some_url"
    os.environ["CHANGE_ID"] = "some_id" # pull request
    assert jenkins("master") == False

# Generated at 2022-06-24 01:29:54.968755
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis() == True



# Generated at 2022-06-24 01:30:05.784152
# Unit test for function checker
def test_checker():
    import mock
    import pytest
    checker_func = mock.MagicMock()
    wrapped_func = checker(checker_func)

    # Assert that the checker returns True when there is no Exception
    assert wrapped_func() is True
    checker_func.assert_called_once()

    # AssertionError raised by checker_func is converted to
    # CiVerificationError
    checker_func.reset_mock()
    checker_func.side_effect = AssertionError
    with pytest.raises(CiVerificationError):
        wrapped_func()
    checker_func.assert_called_once()

    # Exception other than AssertionError are not converted
    checker_func.reset_mock()
    checker_func.side_effect = Exception

# Generated at 2022-06-24 01:30:11.758153
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    try:
        travis('master')
    except CiVerificationError as e:
        assert False
    assert True


# Generated at 2022-06-24 01:30:22.084802
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    os.environ["FRIGG_PULL_REQUEST"] = "1"
    try:
        frigg("develop")
    except CiVerificationError:
        assert True
    else:
        assert False
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    try:
        frigg("master")
    except CiVerificationError:
        assert False
    else:
        assert True



# Generated at 2022-06-24 01:30:23.274323
# Unit test for function semaphore
def test_semaphore():
    assert not semaphore(branch="master")

# Generated at 2022-06-24 01:30:35.277082
# Unit test for function check
def test_check():
    branch = str(976)
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = branch
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check(branch)
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        check(branch)
    except CiVerificationError:
        pass
    
    del os.environ["TRAVIS"]
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = branch
    check(branch)
    os.environ["PULL_REQUEST_NUMBER"] = "true"

# Generated at 2022-06-24 01:30:37.703295
# Unit test for function bitbucket
def test_bitbucket():
    os.environ[
        "BITBUCKET_BUILD_NUMBER"
    ] = "8"  # for the moment, no Bitbucket CI environment variables exist.
    assert bitbucket("master")
    assert not bitbucket("develop")

# Generated at 2022-06-24 01:30:39.256313
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master") == True
    assert semaphore("not_master") == False


# Generated at 2022-06-24 01:30:46.444291
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert check('master') == True
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    assert check('master') == True
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = 'false'
    assert check('master') == True
    os.environ

# Generated at 2022-06-24 01:30:50.115321
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    del os.environ["BITBUCKET_PR_ID"]
    bitbucket("master")

# Generated at 2022-06-24 01:30:57.272615
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    try:
        bitbucket("master")
        assert False
    except:
        assert True
    del os.environ["BITBUCKET_BRANCH"]
    del os.environ["BITBUCKET_PR_ID"]

# Generated at 2022-06-24 01:31:00.508254
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    assert True


# Generated at 2022-06-24 01:31:05.336360
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = 'false'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'
    assert semaphore('master') == True

# Generated at 2022-06-24 01:31:09.495227
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")
    assert True


# Generated at 2022-06-24 01:31:15.175571
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert checker(semaphore)("master")
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]


# Generated at 2022-06-24 01:31:18.003458
# Unit test for function checker
def test_checker():
    """
    Test if checker decorator works with functions that should not raise an
    exception.
    """
    def my_function():
        """
        Function that should not raise an exception
        """
        assert True
    my_function = checker(my_function)
    my_function()


# Generated at 2022-06-24 01:31:22.980153
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = ""
    check()

# Generated at 2022-06-24 01:31:35.293194
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master") is True

    os.environ["PULL_REQUEST_NUMBER"] = "123"
    with pytest.raises(CiVerificationError):
        assert semaphore("master") is False

    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    with pytest.raises(CiVerificationError):
        assert semaphore("master") is False

    os.environ["BRANCH_NAME"] = "notmaster"


# Generated at 2022-06-24 01:31:43.516649
# Unit test for function circle
def test_circle():
    """
    Test the circle function
    """
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    del os.environ["CI_PULL_REQUEST"]
    assert all([
        circle("master"),
        os.environ["CIRCLECI"] == "true",
        os.environ["CIRCLE_BRANCH"] == "master",
        "CI_PULL_REQUEST" not in os.environ
    ])



# Generated at 2022-06-24 01:31:50.715753
# Unit test for function frigg
def test_frigg():
    global os
    os = MagicMock()
    os.environ = {'FRIGG': '/home/frigg', 'FRIGG_BUILD_BRANCH': 'staging'}

    x = frigg()
    assert x == True

    os.environ = {'FRIGG': '/home/frigg', 'FRIGG_BUILD_BRANCH': 'development'}
    assert x == False



# Generated at 2022-06-24 01:31:54.650437
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'false'
    test_func = frigg('master')
    assert test_func == True



# Generated at 2022-06-24 01:31:59.644306
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_PULL_REQUEST"] = "False"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")



# Generated at 2022-06-24 01:32:06.030079
# Unit test for function check
def test_check():
    env_dict = {}
    os.environ = env_dict
    check(branch="master")

    env_dict["TEST"]="True"
    os.environ = env_dict
    check(branch="master")
    check(branch="master")
    check(branch="master")
    check(branch="master")
    check(branch="master")
    check(branch="master")
    check(branch="master")
    check(branch="master")
    check(branch="master")
    check(branch="master")
    pass

# Generated at 2022-06-24 01:32:10.209205
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "my_branch"
    check(branch="my_branch")
    os.environ.pop("JENKINS_URL")
    os.environ.pop("BRANCH_NAME")
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "my_branch"
    check(branch="my_branch")
    os.environ.pop("JENKINS_URL")
    os.environ.pop("GIT_BRANCH")
    os.environ["JENKINS_URL"] = "true"

# Generated at 2022-06-24 01:32:18.312181
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    check()
    os.environ['SEMAPHORE'] = 'true'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    check()
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = None
    check()
    os

# Generated at 2022-06-24 01:32:22.424583
# Unit test for function semaphore
def test_semaphore():
    if os.environ.get("SEMAPHORE") == "true":
        semaphore("develop")
    else:
        assert True



# Generated at 2022-06-24 01:32:24.700236
# Unit test for function checker
def test_checker():
    """
    Tests that the checker decorator raises the correct error when
    the wrapped function fails.
    """
    @checker
    def function():
        assert False

    try:
        function()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("No error was raised.")



# Generated at 2022-06-24 01:32:29.626381
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"

    frigg("master")

    with pytest.raises(CiVerificationError):
        os.environ["FRIGG_BUILD_BRANCH"] = "no_master"
        frigg("master")


# Generated at 2022-06-24 01:32:41.184368
# Unit test for function frigg
def test_frigg():
    assert os.environ.get("FRIGG") == "true"
    assert os.environ.get("FRIGG_BUILD_BRANCH") == "master"
    assert not os.environ.get("FRIGG_PULL_REQUEST")
    frigg('master')

    os.environ['FRIGG_BUILD_BRANCH'] = "develop"
    assert os.environ.get("FRIGG_BUILD_BRANCH") == "develop"
    frigg('develop')
    os.environ.pop('FRIGG_BUILD_BRANCH')

    os.environ['FRIGG_PULL_REQUEST'] = "True"
    assert os.environ.get("FRIGG_PULL_REQUEST")

# Generated at 2022-06-24 01:32:46.937954
# Unit test for function check
def test_check():
    false_env_1 = {"TRAVIS": "true", "SEMAPHORE": "true"}
    message = "The verification check for the environment did not pass."
    try:
        check()
    except CiVerificationError as e:
        assert str(e) == message
    try:
        check()
    except CiVerificationError as e:
        assert str(e) == message
        assert e.__cause__.__class__.__name__ == "AssertionError"

# Generated at 2022-06-24 01:32:51.663695
# Unit test for function checker
def test_checker():
    """
    Test whether checker wrapper works as expected.
    """
    def func():
        raise AssertionError("Exception message.")
    wrapped_func = checker(func)
    try:
        wrapped_func()
    except CiVerificationError as exc:
        assert exc.args[0] == "The verification check for the environment did not pass."

# Generated at 2022-06-24 01:32:54.502047
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "https://jenkins.com"
    os.environ['BRANCH_NAME'] = "master"
    jenkins("master")

# Generated at 2022-06-24 01:33:04.687193
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check()

    os.environ["CIRCLE_BRANCH"] = "develop"
    check('develop')

    os.environ["CI_PULL_REQUEST"] = "https://github.com/relekang/python-semantic-release/pull/30"
    os.environ["CIRCLE_PR_NUMBER"] = "30"
    with pytest.raises(CiVerificationError) as exception_info:
        check()
    assert 'The verification check for the environment did not pass.' in str(exception_info.value)


# Generated at 2022-06-24 01:33:15.302622
# Unit test for function travis
def test_travis():
    # PR
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
        assert False
    except CiVerificationError:
        pass

    # Wrong branch
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
        assert False
    except CiVerificationError:
        pass

    # Success
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")



# Generated at 2022-06-24 01:33:23.729740
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = 'aaa'
    os.environ['BRANCH_NAME'] = 'master'
    assert checker(jenkins)('master') is True
    os.environ['JENKINS_URL'] = 'aaa'
    os.environ['BRANCH_NAME'] = 'otherbranch'
    assert checker(jenkins)('master') is False
    os.environ['JENKINS_URL'] = 'aaa'
    os.environ['CHANGE_ID'] = 'aaa'
    assert checker(jenkins)('master') is False

# Generated at 2022-06-24 01:33:33.594554
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "other"
    try:
        frigg("master")
        raise AssertionError("frigg should fail the check")
    except CiVerificationError:
        pass
    os.environ["FRIGG_PULL_REQUEST"] = "123"
    try:
        frigg("master")
        raise AssertionError("frigg should fail the check")
    except CiVerificationError:
        pass
    del os.environ["FRIGG"]
    del os.en

# Generated at 2022-06-24 01:33:37.141901
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"]="master"
    os.environ["TRAVIS_PULL_REQUEST"]="false"
    travis("master")


# Generated at 2022-06-24 01:33:37.759500
# Unit test for function semaphore
def test_semaphore():
    pass

# Generated at 2022-06-24 01:33:42.771708
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert travis('master')
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    assert not travis('master')


# Generated at 2022-06-24 01:33:52.902405
# Unit test for function circle
def test_circle():
    """Test circle CI checker

    :return: None
    """
    assert checker(circle)("master") == True
    assert checker(circle)("release") == True
    os.environ["CIRCLE_BRANCH"] = "release"
    assert checker(circle)("release") == True
    assert checker(circle)("master") == False
    os.environ["CI_PULL_REQUEST"] = "true"
    assert checker(circle)("release") == False
    os.environ["CI_PULL_REQUEST"] = "false"
    os.environ["CIRCLE_BRANCH"] = "master"
    assert checker(circle)("master") == True
    os.environ["CIRCLE_BRANCH"] = ""

# Generated at 2022-06-24 01:33:55.936489
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master") == True


# Generated at 2022-06-24 01:33:58.947315
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert travis('master')


# Generated at 2022-06-24 01:34:03.162013
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PULLREQUEST_ID"] = "12"
    assert bitbucket == "master"
    assert not BITBUCKET_PULLREQUEST_ID

# Generated at 2022-06-24 01:34:10.777169
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = "true"
    os.environ['CIRCLE_BRANCH'] = "master"
    os.environ['CI_PULL_REQUEST'] = ""
    assert circle("master")
    os.environ['CIRCLE_BRANCH'] = "staging"
    assert not circle("master")
    os.environ['CI_PULL_REQUEST'] = "1"
    assert not circle("master")
    os.environ['CIRCLECI'] = ""
    assert not circle("master")
    os.environ.clear()


# Generated at 2022-06-24 01:34:15.390848
# Unit test for function gitlab
def test_gitlab():
  os.environ['GITLAB_CI'] = 'something'
  os.environ['CI_COMMIT_REF_NAME'] = 'master'
  os.environ['CI_MERGE_REQUEST_ID'] = ''
  check()

# Generated at 2022-06-24 01:34:25.073821
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PULL_REQUEST_ID"] = "22"
    try:
        gitlab("master")
        assert False
    except CiVerificationError:
        assert True
    os.environ["CI_PULL_REQUEST_ID"] = None
    try:
        gitlab("master")
        assert True
    except CiVerificationError:
        assert False
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    try:
        gitlab("master")
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-24 01:34:31.408868
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    del os.environ['SEMAPHORE']
    del os.environ['FRIGG']
    del os.environ['CIRCLECI']
    del os.environ['GITLAB_CI']
    del os.environ['JENKINS_URL']
    del os.environ['BITBUCKET_BUILD_NUMBER']
    check()


# Generated at 2022-06-24 01:34:39.614030
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "http://test.com"
    os.environ["BRANCH_NAME"] = "master"
    check()
    del os.environ["JENKINS_URL"]
    os.environ["GIT_BRANCH"] = "master"
    check()
    os.environ["CHANGE_ID"] = "123"
    check("master")
    os.environ["CHANGE_ID"] = None
    check("master")



# Generated at 2022-06-24 01:34:50.567517
# Unit test for function circle
def test_circle():
    assert not os.environ.get("CIRCLECI")  # check that no env vars

    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle()
    del os.environ["CIRCLE_BRANCH"]
    del os.environ["CI_PULL_REQUEST"]

    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "123"
    try:
        circle()
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-24 01:34:55.652422
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = "semantic-release-test-4"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"

    assert travis(os.environ['TRAVIS_BRANCH'])


# Generated at 2022-06-24 01:35:01.664810
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")
    os.environ["TRAVIS_BRANCH"] = "foobar"
    assert not travis("master")
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    assert not travis("master")



# Generated at 2022-06-24 01:35:05.890115
# Unit test for function circle
def test_circle():
    try:
        os.environ['CIRCLECI'] = 'true'
        os.environ['CIRCLE_BRANCH'] = 'test'
        os.environ['CI_PULL_REQUEST'] = 'false'
        circle('test')
        assert True
    except Exception:
        assert False

# Generated at 2022-06-24 01:35:15.012484
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "True"
    os.environ['BRANCH_NAME'] = "master"
    del os.environ['CHANGE_ID']
    jenkins('master')
    os.environ['JENKINS_URL'] = "True"
    del os.environ['BRANCH_NAME']
    os.environ['GIT_BRANCH'] = "master"
    jenkins('master')
    os.environ['JENKINS_URL'] = "True"
    del os.environ['GIT_BRANCH']
    os.environ['BRANCH_NAME'] = "test"
    os.environ['GIT_BRANCH'] = "master"
    jenkins('test')

# Generated at 2022-06-24 01:35:19.554372
# Unit test for function bitbucket
def test_bitbucket():
    assert checker(bitbucket)('master') == True
    assert checker(bitbucket)('develop') == True


# Generated at 2022-06-24 01:35:25.532242
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = '1'
    os.environ["BITBUCKET_BRANCH"] = 'master'

    try:
        bitbucket(['master']);
    except CiVerificationError as e:
        pytest.fail("Environment checks failed")
        print(e)


# Generated at 2022-06-24 01:35:32.567630
# Unit test for function frigg
def test_frigg():
    os.environ.clear()
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "False"
    try:
        frigg("master")
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."
    else:
        assert False, "Did not raise expected exception"



# Generated at 2022-06-24 01:35:39.115796
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    travis("develop")
    travis("feature/add-release-notes")
    os.environ["TRAVIS_BRANCH"] = "develop"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("develop")
    os.environ["TRAVIS_BRANCH"] = "feature/add-release-notes"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("feature/add-release-notes")
    os.environ["TRAVIS_PULL_REQUEST"] = "true"

# Generated at 2022-06-24 01:35:40.976410
# Unit test for function check
def test_check():
    try:
        check()
    except Exception as e:
        assert False, e

# Generated at 2022-06-24 01:35:45.433161
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    check()
    os.environ["BITBUCKET_BRANCH"] = "non-master"
    try:
        check()
    except:
        assert True
        try:
            os.environ["BITBUCKET_BRANCH"] = "master"
            os.environ["BITBUCKET_PR_ID"] = "test"
            check()
        except:
            assert True
    finally:
        os.environ["BITBUCKET_BRANCH"] = ""
        os.environ["BITBUCKET_PR_ID"] = ""

# Generated at 2022-06-24 01:35:53.722235
# Unit test for function jenkins
def test_jenkins():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['JENKINS_URL'] = 'https://ci.jenkins.io/job/Plugins/job/workflow-scm-step/'
    os.environ['CHANGE_ID'] = None
    assert jenkins('master') is True

    os.environ['BRANCH_NAME'] = 'stable'
    os.environ['JENKINS_URL'] = 'https://ci.jenkins.io/job/Plugins/job/workflow-scm-step/'
    os.environ['CHANGE_ID'] = None
    assert jenkins('master') is False

    os.environ['BRANCH_NAME'] = 'stable'
    os.environ['JENKINS_URL'] = None


# Generated at 2022-06-24 01:35:59.848271
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore("master")


# Generated at 2022-06-24 01:36:01.589621
# Unit test for function frigg
def test_frigg():
    test_env = {"FRIGG": "true", "FRIGG_BUILD_BRANCH": "master"}
    frigg("master")


# Generated at 2022-06-24 01:36:03.486791
# Unit test for function gitlab
def test_gitlab():
    import os
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()


# Generated at 2022-06-24 01:36:10.802365
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_PROJECT_NAME"] = "my_project"
    try:
        check()
    except CiVerificationError:
        assert True
    else:
        assert False

    os.environ["CI_COMMIT_REF_NAME"] = "master"
    try:
        check()
    except CiVerificationError:
        assert False
    else:
        assert True


# Generated at 2022-06-24 01:36:14.263716
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('master')



# Generated at 2022-06-24 01:36:24.259345
# Unit test for function circle
def test_circle():
    """Unit test for the circle function"""
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"

    # Both cases should return True
    assert circle("master")
    del os.environ["CI_PULL_REQUEST"]
    assert circle("master")

    del os.environ["CIRCLE_BRANCH"]
    os.environ["CIRCLE_BRANCH"] = "develop"
    assert circle("develop")

    del os.environ["CIRCLE_BRANCH"]
    os.environ["CI_PULL_REQUEST"] = "true"
    assert circle("master")


# Generated at 2022-06-24 01:36:28.915221
# Unit test for function circle
def test_circle():
    """
    Tests the circle function
    """
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = "true"
    os.environ["CIRCLE_BRANCH"] = "test_branch"
    circle_error = None
    try:
        circle()
    except CiVerificationError as error:
        circle_error = error
    assert circle_error is not None

# Generated at 2022-06-24 01:36:31.127741
# Unit test for function gitlab
def test_gitlab():
    os.environ['GITLAB_CI'] = 'true'
    os.environ['CI_COMMIT_REF_NAME'] = 'develop'
    os.environ['CI_PULL_REQUEST'] = 'true'
    os.environ['CI_PROJECT_URL'] = 'https://gitlab.com/testing/test'
    gitlab('develop')

# Generated at 2022-06-24 01:36:37.334175
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"

    semaphore("master")



# Generated at 2022-06-24 01:36:39.885201
# Unit test for function bitbucket
def test_bitbucket():
    assert not bitbucket("master")
    assert not bitbucket("develop")
    try:
        bitbucket("feature/XYZ")
    except CiVerificationError as verification_error:
        assert "not passed" in str(verification_error)
    else:
        assert False, "Failed to raise VerificationError"

# Generated at 2022-06-24 01:36:47.316781
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    circle("master")
    assert os.environ.get("CIRCLE_BRANCH") == "master"
    assert not os.environ.get("CI_PULL_REQUEST")
    os.environ["CIRCLE_BRANCH"] = "release/1.0.0"
    circle("release/1.0.0")
    assert os.environ.get("CIRCLE_BRANCH") == "release/1.0.0"
    assert not os.environ.get("CI_PULL_REQUEST")

# Generated at 2022-06-24 01:36:59.079305
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    travis("master")
    travis()
    os.environ['TRAVIS_BRANCH'] = "dev"
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    try:
        travis("master")
        assert False
    except Exception as e:
        assert type(e) == CiVerificationError
    try:
        travis()
        assert False
    except Exception as e:
        assert type(e) == CiVerificationError
    os.environ['TRAVIS_BRANCH'] = "master"
    os.environ['TRAVIS_PULL_REQUEST'] = "true"
   

# Generated at 2022-06-24 01:37:02.837680
# Unit test for function checker
def test_checker():
    import pytest
    @checker
    def func():
    	assert False, "Raising AssertionError"
    with pytest.raises(CiVerificationError) as excinfo:
        func()

# Unit tests for the different CI checkers.

# Generated at 2022-06-24 01:37:12.300261
# Unit test for function gitlab
def test_gitlab():
    branch = "master"
    # Test not gitlab
    os.environ["GITLAB_CI"] = None
    try:
        gitlab(branch)
    except CiVerificationError:
        pass
    else:
        assert False, 'Expected CiVerificationError, but no error was raised.'
    # Test gitlab but wrong branch
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "dev"
    try:
        gitlab(branch)
    except CiVerificationError:
        pass
    else:
        assert False, 'Expected CiVerificationError, but no error was raised.'
    # Test gitlab but pull request
    os.environ["GITLAB_CI"] = "true"

# Generated at 2022-06-24 01:37:19.855601
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore("master")
    os.environ["BRANCH_NAME"] = "branch"
    try:
        semaphore("master")
        raise AssertionError("Should raise")
    except CiVerificationError:
        pass



# Generated at 2022-06-24 01:37:25.497259
# Unit test for function semaphore
def test_semaphore():
    os.environ.clear()
    os.environ.update(
        {
            "SEMAPHORE": "true",
            "BRANCH_NAME": "master",
            "PULL_REQUEST_NUMBER": None,
            "SEMAPHORE_THREAD_RESULT": "passed",
        }
    )
    check()



# Generated at 2022-06-24 01:37:27.656601
# Unit test for function semaphore
def test_semaphore():
    try:
        semaphore("master")
    except Exception:
        raise
        assert False


# Generated at 2022-06-24 01:37:30.825984
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "false"
    check(branch = "master")

# Generated at 2022-06-24 01:37:33.173054
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    check(branch="master")



# Generated at 2022-06-24 01:37:39.948090
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"]="master"
    os.environ["TRAVIS_PULL_REQUEST"]="false"
    travis("master")
    os.environ["TRAVIS_BRANCH"]="develop"
    os.environ["TRAVIS_PULL_REQUEST"]="false"
    travis("master")
    os.environ["TRAVIS_BRANCH"]="master"
    os.environ["TRAVIS_PULL_REQUEST"]="true"
    travis("master")


# Generated at 2022-06-24 01:37:44.284692
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle("master")
    assert not circle("dev")
    del os.environ["CIRCLECI"]



# Generated at 2022-06-24 01:37:55.078408
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    semaphore(branch="master")

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = 1234
    try:
        semaphore(branch="master")
        assert False
    except CiVerificationError:
        assert True

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"

# Generated at 2022-06-24 01:37:58.020889
# Unit test for function check
def test_check():
    """
    Submit an assertion error when processing the result of check.
    """
    try:
        check("bad")
    except CiVerificationError as e:
        print(e)

# Generated at 2022-06-24 01:38:00.553861
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    assert check("develop") is True
    del os.environ["FRIGG"]



# Generated at 2022-06-24 01:38:06.632515
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    with pytest.raises(CiVerificationError):
        travis("master")

    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")

# Generated at 2022-06-24 01:38:10.770161
# Unit test for function checker
def test_checker():
    """
    Tests the checker decorator.
    """
    checker_pass(True, "master")
    checker_pass(False, "develop")


# Generated at 2022-06-24 01:38:12.615136
# Unit test for function circle
def test_circle():
    try:
        circle("master")
        assert(False)
    except AssertionError:
        assert(True)
    except Exception:
        assert(False)

# Generated at 2022-06-24 01:38:20.542775
# Unit test for function check
def test_check():
    # this import is here to prevent a circular dependency
    import semantic_release.hvcs

    # set up some dummy environment variables
    env_vars = {
        "TRAVIS": "true",
        "TRAVIS_BRANCH": "foo",
        "TRAVIS_PULL_REQUEST": "true",
    }
    try:
        semantic_release.hvcs.ENVIRON = env_vars
        check("foo")
    except CiVerificationError:
        # this is the correct branch being tested
        pass
    else:
        raise AssertionError(
            "CiVerificationError not raised for incorrect branch"
        )

    env_vars.update({"TRAVIS_PULL_REQUEST": "false"})

# Generated at 2022-06-24 01:38:23.670544
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "master"
    check()
    print("test passed")

# Generated at 2022-06-24 01:38:34.136954
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    check()

    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    check("master")

    os.environ["CIRCLECI"] = "true"
    os

# Generated at 2022-06-24 01:38:45.683412
# Unit test for function circle
def test_circle():
    os.environ.update({"CIRCLECI": "true", "CIRCLE_BRANCH": "master"})
    check()

    os.environ.update({"CIRCLECI": "true", "CIRCLE_BRANCH": "master",
                       "CI_PULL_REQUEST": "https://github.com/relekang/python-semantic-release/pull/75"})
    try:
        check()
        assert False
    except CiVerificationError:
        assert True

    os.environ.update({"CIRCLECI": "true", "CIRCLE_BRANCH": "master", "CI_PULL_REQUEST": "None"})
    try:
        check()
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-24 01:38:53.636853
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "1"
    # No GIT_BRANCH and BRANCH_NAME
    check(branch="master")

    # No GIT_BRANCH and BRANCH_NAME is not master
    os.environ["BRANCH_NAME"] = "not_master"
    check(branch="master")

    # No GIT_BRANCH and BRANCH_NAME is master
    os.environ["BRANCH_NAME"] = "master"
    check(branch="master")

    # No GIT_BRANCH, no BRANCH_NAME and CHANGE_ID is not None
    os.environ.pop("BRANCH_NAME")
    os.environ["CHANGE_ID"] = "not_none"

# Generated at 2022-06-24 01:39:01.087805
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CI_PULL_REQUEST'] = 'false'
    os.environ['CIRCLE_BRANCH'] = 'master'
    assert circle('master')
    os.environ['CI_PULL_REQUEST'] = 'true'
    assert not circle('master')



# Generated at 2022-06-24 01:39:07.428043
# Unit test for function frigg
def test_frigg():
    # Setup
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "not-master"
    # Test
    try:
        frigg("master")
        raise AssertionError
    except CiVerificationError:
        pass
    os.environ["FRIGG_PULL_REQUEST"] = None
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-24 01:39:10.336832
# Unit test for function checker
def test_checker():
    @checker
    def _test_func():
        raise AssertionError

    try:
        _test_func()
    except CiVerificationError:
        pass
    else:
        raise AssertionError("No Assertion Error")

# Generated at 2022-06-24 01:39:16.043459
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "true"
    os.environ['GIT_BRANCH'] = 'master'
    jenkins('master')