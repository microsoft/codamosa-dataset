

# Generated at 2022-06-24 01:29:13.868887
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check(branch="master")

# Generated at 2022-06-24 01:29:20.983709
# Unit test for function frigg
def test_frigg():
    with checker(frigg("master")):
        os.environ["FRIGG_BUILD_BRANCH"] = "master"
        os.environ["FRIGG_PULL_REQUEST"] = "false"
        frigg("master")
    os.environ.pop("FRIGG_BUILD_BRANCH")
    os.environ.pop("FRIGG_PULL_REQUEST")


# Generated at 2022-06-24 01:29:31.178195
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = None

    try:
        circle("master")
    except CiVerificationError:
        assert 1 == 0

    os.environ["CIRCLE_BRANCH"] = "develop"
    with pytest.raises(CiVerificationError):
        circle("master")

    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "true"
    with pytest.raises(CiVerificationError):
        circle("master")



# Generated at 2022-06-24 01:29:34.237778
# Unit test for function checker
def test_checker():
    @checker
    def test_func(a: str, b: str):
        assert a == b
    test_func("foo", "foo")
    try:
        test_func("foo", "bar")
    except CiVerificationError:
        assert True
    else:
        assert False



# Generated at 2022-06-24 01:29:39.007955
# Unit test for function gitlab
def test_gitlab():
    # Test with GITLAB_CI and CI_COMMIT_REF_NAME
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    r = gitlab("master")
    assert r == True
    # Test with GITLAB_CI, CI_COMMIT_REF_NAME, and CI_MERGE_REQUEST_ID
    os.environ["CI_MERGE_REQUEST_ID"] = "20"
    r = gitlab("master")
    assert r == False

# Generated at 2022-06-24 01:29:45.551437
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["GIT_BRANCH"] = "master"
    jenkins("master")


# Generated at 2022-06-24 01:29:50.930147
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BUILD_NUMBER'] = '1'
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = ''
    check()
    os.environ['BITBUCKET_BRANCH'] = 'notmaster'
    check(branch='master')

# Generated at 2022-06-24 01:29:57.235808
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    try:
        check()
    except:
        raise AssertionError
    assert travis('master')
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    assert travis('master')


# Generated at 2022-06-24 01:30:00.564463
# Unit test for function circle
def test_circle():
    """
    Test the checker for Circle CI
    """
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    CI_PULL_REQUEST = "false"
    check()

# Generated at 2022-06-24 01:30:06.904996
# Unit test for function check
def test_check():
    current_env = os.environ.copy()
    try:
        os.environ["TRAVIS"] = "true"
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        check()
    except Exception as e:
        raise e
    finally:
        os.environ = current_env


# Generated at 2022-06-24 01:30:11.719324
# Unit test for function gitlab
def test_gitlab():
    """Test for gitlab CI/CD
    """
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    gitlab("master")
    del os.environ["GITLAB_CI"]
    del os.environ["CI_COMMIT_REF_NAME"]



# Generated at 2022-06-24 01:30:16.746591
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch="master")


# Generated at 2022-06-24 01:30:24.906817
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "BRANCH_NAME"
    os.environ["GIT_BRANCH"] = "GIT_BRANCH"
    os.environ["JENKINS_URL"] = "JENKINS_URL"
    del os.environ['CHANGE_ID']
    assert jenkins(branch="BRANCH_NAME")
    assert jenkins(branch="GIT_BRANCH")
    # Clean up the environment
    del os.environ["BRANCH_NAME"]
    del os.environ["GIT_BRANCH"]
    del os.environ["JENKINS_URL"]

# Generated at 2022-06-24 01:30:29.583630
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"]="master"
    os.environ["TRAVIS_PULL_REQUEST"]="false"
    travis("master")


# Generated at 2022-06-24 01:30:34.221126
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'release/v1.2.3'
    frigg('release/v1.2.3')



# Generated at 2022-06-24 01:30:42.193912
# Unit test for function semaphore
def test_semaphore():
    env_dict = {
        "BRANCH_NAME": "master",
        "PULL_REQUEST_NUMBER": None,
        "SEMAPHORE_THREAD_RESULT": "passed",
    }
    for key, val in env_dict.items():
        os.environ[key] = val
    try:
        semaphore("master")
    except CiVerificationError as ex:
        assert False, ex.message


# Generated at 2022-06-24 01:30:44.471842
# Unit test for function gitlab
def test_gitlab():
    os.environ['GITLAB_CI'] = 'true'
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    assert check('master') == True



# Generated at 2022-06-24 01:30:49.976731
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch="master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]



# Generated at 2022-06-24 01:30:56.570108
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert gitlab("master")
    os.environ["CI_COMMIT_REF_NAME"] = "not-master"
    try:
        gitlab("master")
    except CiVerificationError:
        return
    assert False


# Generated at 2022-06-24 01:30:58.737298
# Unit test for function frigg
def test_frigg():
    """
    Testing function frigg
    """
    assert frigg('master')
    assert frigg('dev')
    assert frigg('prod')


# Generated at 2022-06-24 01:31:04.083137
# Unit test for function jenkins
def test_jenkins():
    """
    Checks that the jenkins environment variable branch variable is correct.
    """
    os.environ["JENKINS_URL"] = "https://jenkins"
    os.environ["GIT_BRANCH"] = "GIT-BRANCH-NAME"
    assert jenkins("GIT-BRANCH-NAME")


# Generated at 2022-06-24 01:31:13.738625
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
    except Exception as e:
        assert False

    assert True

    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
        assert False
    except CiVerificationError as e:
        assert True
    os.environ.pop("TRAVIS_BRANCH")
    os.environ.pop("TRAVIS_PULL_REQUEST")

    

# Generated at 2022-06-24 01:31:20.126654
# Unit test for function jenkins
def test_jenkins():
    # GIVEN
    os.environ["JENKINS_URL"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "false"
    
    # WHEN
    jenkins("master")

    # THEN
    # Should not fail



# Generated at 2022-06-24 01:31:23.008410
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
    except Exception:
        assert False



# Generated at 2022-06-24 01:31:35.293160
# Unit test for function circle
def test_circle():
    # The build is not on master
    os.environ["CIRCLE_BRANCH"] = 'test_branch'
    assert circle() is False

    # cleanup
    os.environ.pop('CIRCLE_BRANCH')

    # The build is on master
    os.environ["CIRCLE_BRANCH"] = 'master'
    assert circle() is True

    # cleanup
    os.environ.pop('CIRCLE_BRANCH')

    # The build is on master and a pull request
    os.environ["CIRCLE_BRANCH"] = 'master'
    os.environ["CI_PULL_REQUEST"] = 'link_to_pull_request'
    assert circle() is False
    os.environ.pop('CIRCLE_BRANCH')
    os.environ

# Generated at 2022-06-24 01:31:42.335824
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = os.environ.get("JENKINS_URL") or "https://test.com/"
    os.environ["BRANCH_NAME"] = "development"
    os.environ["GIT_BRANCH"] = "develop"
    os.environ["CHANGE_ID"] = "123"
    try:
        jenkins("develop")
    except CiVerificationError:
        pass
    os.environ["CHANGE_ID"] = ""
    jenkins("develop")
    del os.environ["JENKINS_URL"]
    del os.environ["BRANCH_NAME"]
    del os.environ["GIT_BRANCH"]
    del os.environ["CHANGE_ID"]

# Generated at 2022-06-24 01:31:46.076021
# Unit test for function frigg
def test_frigg():
    # The function "frigg" should be called if FRIGG environment variable is true
    assert os.environ.get("FRIGG") is not None
    check()

# Generated at 2022-06-24 01:31:55.445361
# Unit test for function check
def test_check():
    """
    Dummy unit test for function check()
    """
    os.environ["CI"] = "true"
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    check()

    os.environ["FRIGG"] = "true"

# Generated at 2022-06-24 01:32:02.784522
# Unit test for function checker
def test_checker():
    @checker
    def function_to_test(num: int):
        assert num > 0

    with open(os.devnull, "w") as devnull:
        real_stdout, _ = os.sys.stdout, devnull
        os.sys.stdout = devnull

        try:
            assert function_to_test(0) is False
        except CiVerificationError:
            pass  # Expected
        os.sys.stdout = real_stdout



# Generated at 2022-06-24 01:32:09.648879
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    os.environ["TRAVIS_BRANCH"] = "0.x"
    check()
    with pytest.raises(CiVerificationError):
        os.environ["TRAVIS_BRANCH"] = "dev"
        check()


# Generated at 2022-06-24 01:32:13.045611
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "0.0.0"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    semaphore("0.0.0")

# Generated at 2022-06-24 01:32:17.431224
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = ""
    check()  # No exception should be thrown

# Generated at 2022-06-24 01:32:22.580834
# Unit test for function circle
def test_circle():
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"
    circle("master")



# Generated at 2022-06-24 01:32:24.141387
# Unit test for function travis
def test_travis():
    assert checker(travis)("master")
    assert checker(travis)("master")


# Generated at 2022-06-24 01:32:27.759242
# Unit test for function semaphore
def test_semaphore():
    assert os.environ.get("BRANCH_NAME") is not None
    assert os.environ.get("PULL_REQUEST_NUMBER") is None
    assert os.environ.get("SEMAPHORE_THREAD_RESULT") != "failed"
    semaphore()

# Generated at 2022-06-24 01:32:32.117863
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = 'master'
    # Should not raise an error
    semaphore('master')
    # Should raise an error because of wrong branch
    try:
        semaphore('wrong')
        assert False, 'Expected an error'
    except CiVerificationError as e:
        pass

# Generated at 2022-06-24 01:32:39.309829
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['CI_MERGE_REQUEST_ID'] = None
    check()

    os.environ['CI_COMMIT_REF_NAME'] = 'release'
    os.environ['CI_MERGE_REQUEST_ID'] = None
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise Exception("Did not raise CiVerificationError")

# Generated at 2022-06-24 01:32:46.750306
# Unit test for function check
def test_check():
    assert os.environ.get("TRAVIS") is None
    assert os.environ.get("SEMAPHORE") is None
    assert os.environ.get("FRIGG") is None
    assert os.environ.get("CIRCLECI") is None
    assert os.environ.get("GITLAB_CI") is None
    assert os.environ.get("JENKINS_URL") is None
    assert "BITBUCKET_BUILD_NUMBER" not in os.environ

    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()

    del os.environ["TRAVIS"]
    os.en

# Generated at 2022-06-24 01:32:49.815616
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    gitlab("master")

if __name__ == "__main__":
    check()

# Generated at 2022-06-24 01:32:59.644556
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "1"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "1"
    bitbucket("master")
    del os.environ["BITBUCKET_BRANCH"]
    os.environ["BITBUCKET_BRANCH"] = "develop"
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        assert True
    del os.environ["BITBUCKET_BRANCH"]
    os.environ["BITBUCKET_BRANCH"] = "master"
    del os.environ["BITBUCKET_PR_ID"]

# Generated at 2022-06-24 01:33:08.593038
# Unit test for function check
def test_check():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["PULL_REQUEST_NUMBER"] = None
    check()
    os.environ.pop("SEMAPHORE")
    os.environ.pop("BRANCH_NAME")
    os.environ.pop("SEMAPHORE_THREAD_RESULT")
    os.environ.pop("PULL_REQUEST_NUMBER")

    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

# Generated at 2022-06-24 01:33:12.406005
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    semaphore('master')

# Generated at 2022-06-24 01:33:15.571507
# Unit test for function gitlab
def test_gitlab():
    """
    Performs necessary checks to ensure that the gitlab build is one
    that should create releases.

    :param branch: The branch the environment should be running against.
    """
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    gitlab("master")

# Generated at 2022-06-24 01:33:16.066705
# Unit test for function check
def test_check():
    assert check()

# Generated at 2022-06-24 01:33:20.336082
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    os.environ["FRIGG_BUILD_BRANCH"] = "release-123"
    frigg("release-123")
    os.environ["FRIGG_BUILD_BRANCH"] = "develop"
    frigg("develop")
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG"]


# Generated at 2022-06-24 01:33:20.831328
# Unit test for function check
def test_check():
    assert check(branch="master")

# Generated at 2022-06-24 01:33:22.030819
# Unit test for function check
def test_check():
    assert check(branch="branch")

# Generated at 2022-06-24 01:33:25.089820
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")


if __name__ == "__main__":
    check()

# Generated at 2022-06-24 01:33:28.236276
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_COMMIT_REF_NAME"] = "false"
    assert check()
    del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-24 01:33:31.630804
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    check()



# Generated at 2022-06-24 01:33:38.814378
# Unit test for function bitbucket
def test_bitbucket():
    """
    Unit test for function bitbucket
    """
    os.environ['BITBUCKET_BRANCH'] = 'master'
    os.environ['BITBUCKET_PR_ID'] = 'test'
    try:
        bitbucket('master')
    except Exception: 
        pass
    os.environ['BITBUCKET_PR_ID'] = 'None'



# Generated at 2022-06-24 01:33:41.798864
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS_BRANCH"] = "master"
    travis("master")


# Generated at 2022-06-24 01:33:48.790893
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket("master")
    del os.environ["BITBUCKET_BRANCH"]

    os.environ["BITBUCKET_BRANCH"] = "tag"
    bitbucket("tag")
    del os.environ["BITBUCKET_BRANCH"]

    os.environ["BITBUCKET_BRANCH"] = "not_tag"
    try:
        bitbucket("tag")
    except CiVerificationError:
        pass
    del os.environ["BITBUCKET_BRANCH"]

    os.environ["BITBUCKET_PR_ID"] = "true"
    try:
        bitbucket("master")
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:33:52.668540
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'

    try:
        travis('master')
    except CiVerificationError:
        assert False
    except:
        assert True



# Generated at 2022-06-24 01:34:01.227499
# Unit test for function checker
def test_checker():
    flag = False
    @checker
    def check_checker():
        nonlocal flag
        assert True
        flag = True
    check_checker()
    assert flag
    @checker
    def check_checker_raise():
        nonlocal flag
        assert False
        flag = True
    try:
        check_checker_raise()
    except CiVerificationError as e:
        assert "The verification check for the environment did not pass." in str(e)


# Generated at 2022-06-24 01:34:11.007752
# Unit test for function jenkins
def test_jenkins():
    """
    Tests the jenkins function
    """

    # test empty environment
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "null"
    os.environ["JENKINS_URL"] = None
    assert check("master")

    # Test with actual environment variables
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "null"
    os.environ["JENKINS_URL"] = "https://jenkins.ci"
    assert check("master")

    # Test incorrect branch
    os.environ["BRANCH_NAME"] = "dev"
    os.environ["CHANGE_ID"] = "null"
    os.environ["JENKINS_URL"]

# Generated at 2022-06-24 01:34:13.854407
# Unit test for function frigg
def test_frigg():
    assert os.environ.get("FRIGG") == "true"


# Generated at 2022-06-24 01:34:20.456809
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    try:
        gitlab("master")
    except CiVerificationError:
        assert False, "gitlab should not raise exception"
    try:
        gitlab("not_master")
        assert False, "gitlab should raise exception"
    except CiVerificationError:
        pass
    os.environ["CI_COMMIT_REF_NAME"] = "not_master"
    try:
        gitlab("master")
        assert False, "gitlab should raise exception"
    except CiVerificationError:
        pass



# Generated at 2022-06-24 01:34:26.311660
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    assert circle("master")
    assert not circle("develop")
    del os.environ["CIRCLE_BRANCH"]
    assert not circle("master")
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "1"
    assert not circle("master")
    del os.environ["CIRCLECI"]


# Generated at 2022-06-24 01:34:37.191163
# Unit test for function frigg
def test_frigg():
    assert travis("master")==True

    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")==True

    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        
        travis("master")
    except CiVerificationError:
        assert True

    os.environ["TRAVIS_BRANCH"] = "feature"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        travis("master")
    except CiVerificationError:
        assert True


# Generated at 2022-06-24 01:34:44.497850
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    bitbucket(branch="master")
    assert os.environ["BITBUCKET_BRANCH"] == "master"
    assert not os.environ.get("BITBUCKET_PR_ID")
    os.environ["BITBUCKET_BRANCH"] = "develop"
    assert bitbucket() == "BITBUCKET_BRANCH"

# Generated at 2022-06-24 01:34:50.656510
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-24 01:34:56.496069
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"

    try:
        gitlab("master")
        assert True
    except CiVerificationError:
        assert False

    os.environ["CI_COMMIT_REF_NAME"] = "develop"

    try:
        gitlab("master")
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-24 01:34:59.329490
# Unit test for function checker
def test_checker():
    @checker
    def func():
        assert False

    try:
        func()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-24 01:35:03.371370
# Unit test for function frigg
def test_frigg():
    """
    Test function frigg
    """
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = False
    assert frigg("master") == True



# Generated at 2022-06-24 01:35:04.265650
# Unit test for function circle
def test_circle():
    check('develop')
    assert False

# Generated at 2022-06-24 01:35:09.112025
# Unit test for function gitlab
def test_gitlab():
    env_vars = {
        'CI_COMMIT_REF_NAME': 'master',
        'CI_MERGE_REQUEST_IID': '0'
    }
    for k, v in env_vars.items():
        os.environ[k] = v

    check()

    assert 'master' == os.environ.get('CI_COMMIT_REF_NAME')
    assert '0' == os.environ.get('CI_MERGE_REQUEST_IID')

# Generated at 2022-06-24 01:35:09.747159
# Unit test for function jenkins
def test_jenkins():
    # TODO
    pass


# Generated at 2022-06-24 01:35:16.708441
# Unit test for function checker
def test_checker():
    from semantic_release.errors import CiVerificationError

    @checker
    def func():
        assert False

    try:
        func()
    except CiVerificationError:
        pass
    else:
        assert False, "Checker does not convert AssertionError to CiVerificationError"

    @checker
    def func():
        assert True

    assert func() is True

# Generated at 2022-06-24 01:35:23.431329
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    try:
        frigg("master")
        assert True
    except AssertionError:
        assert False

    os.environ["FRIGG_BUILD_BRANCH"] = "development"
    try:
        frigg("master")
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-24 01:35:25.046706
# Unit test for function frigg
def test_frigg():
    result = frigg("master")
    assert result == True


# Generated at 2022-06-24 01:35:29.148650
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"]="master"
    os.environ["CI_MERGE_REQUEST_ID"]=None
    assert check(branch="master") == True
    assert check(branch="master") == True



# Generated at 2022-06-24 01:35:35.126022
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CI_PULL_REQUEST'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    assert circle('master')
    os.environ['CIRCLE_BRANCH'] = 'test'
    assert not circle('master')
    os.environ['CI_PULL_REQUEST'] = 'false'
    assert not circle('master')


# Generated at 2022-06-24 01:35:46.757975
# Unit test for function gitlab
def test_gitlab():
    """
    Test GitLab CI environment checker
    """
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_IID"] = ""
    os.environ["BRANCH_NAME"] = ""
    os.environ["PULL_REQUEST_NUMBER"] = ""
    os.environ["SEMAPHORE_THREAD_RESULT"] = ""
    os.environ["FRIGG_BUILD_BRANCH"] = ""
    os.environ["FRIGG_PULL_REQUEST"] = ""
    os.environ["CIRCLE_BRANCH"] = ""
    os.environ["CI_PULL_REQUEST"] = ""
   

# Generated at 2022-06-24 01:35:52.013603
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    check()
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]



# Generated at 2022-06-24 01:36:02.114825
# Unit test for function semaphore
def test_semaphore():
    """
    Testing whether the semaphore CI environment is supported.
    """
    # Set the attributes of an environment variable SEMAPHORE
    os.environ["SEMAPHORE"] = "true"

    # Set the attribute for BRANCH_NAME
    os.environ["BRANCH_NAME"] = "master"

    # Set the attribute for PULL_REQUEST_NUMBER
    os.environ["PULL_REQUEST_NUMBER"] = "false"

    # Set the attribute for SEMAPHORE_THREAD_RESULT
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    # Call the check
    check()

    # Delete the attributes set for the environment variable SEMAPHORE
    del os.environ["SEMAPHORE"]

# Generated at 2022-06-24 01:36:07.633179
# Unit test for function travis
def test_travis():
    travis_branch = "master"
    os.environ["TRAVIS_BRANCH"] = travis_branch
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert os.environ.get("TRAVIS_BRANCH") == travis_branch
    assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"
    travis(travis_branch)



# Generated at 2022-06-24 01:36:11.187519
# Unit test for function semaphore
def test_semaphore():
    assert semaphore() == True

# Generated at 2022-06-24 01:36:14.848334
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"]="true"
    os.environ["CIRCLE_BRANCH"]="master"
    os.environ["CI_PULL_REQUEST"]="false"
    try:
        circle("master")
    except CiVerificationError as e:
        raise(e)
    os.environ["CIRCLE_BRANCH"]="testing"
    try:
        circle("master")
    except CiVerificationError as e:
        raise(e)

# Generated at 2022-06-24 01:36:16.166003
# Unit test for function checker
def test_checker():
    checker(lambda: os.getcwd())();

# Generated at 2022-06-24 01:36:24.919362
# Unit test for function bitbucket
def test_bitbucket():
    # check if healthy return True when branch is same as in bitbucket
    os.environ["BITBUCKET_BRANCH"] = "master"
    assert bitbucket("master")
    # check if healthy return False when branch is not same as in bitbucket
    assert bitbucket("develop") == False
    # check if healthy return False when branch is not same as in bitbucket and pull request is True
    os.environ["BITBUCKET_PR_ID"] = "1"
    assert bitbucket("develop") == False



# Generated at 2022-06-24 01:36:27.398895
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "https://jenkins-url.com"
    os.environ['GIT_BRANCH'] = "master"
    check()



# Generated at 2022-06-24 01:36:37.456498
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"

    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "success"

    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = None

    os.environ["CIRCLECI"] = "true"

# Generated at 2022-06-24 01:36:39.330698
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    try:
        bitbucket("master")
    except Exception as e:
        return False
    return True


# Generated at 2022-06-24 01:36:41.525586
# Unit test for function frigg
def test_frigg():
    assert frigg(branch="master") is True


# Generated at 2022-06-24 01:36:44.210543
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    bitbucket("master")

# Generated at 2022-06-24 01:36:48.653655
# Unit test for function checker
def test_checker():
    """
    Test that the checker decorator returns the correct error
    """
    import pytest
    from semantic_release.errors import CiVerificationError

    with pytest.raises(CiVerificationError):
        @checker
        def func1():
            raise AssertionError

        func1()



# Generated at 2022-06-24 01:37:00.146390
# Unit test for function check
def test_check():
    os.environ['TRAVIS'] = 'true'
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    check()

    os.environ['SEMAPHORE'] = 'true'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'success'
    check()

    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = False
    check()


# Generated at 2022-06-24 01:37:03.138702
# Unit test for function checker
def test_checker():
    # Tests that this decorator converts the error types
    @checker
    def test_failing_func():
        raise AssertionError

    try:
        test_failing_func()
        raise AssertionError("Expected to raise")
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:37:05.363600
# Unit test for function circle
def test_circle():
    circle(branch="master")

# Generated at 2022-06-24 01:37:08.696426
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CI_PULL_REQUEST"] = ""
    os.environ["CIRCLE_BRANCH"] = "master"
    check()

# Generated at 2022-06-24 01:37:13.797483
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    frigg('master')
    os.environ['FRIGG_BUILD_BRANCH'] = 'dev'
    with pytest.raises(CiVerificationError):
        frigg('master')
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = 'true'
    with pytest.raises(CiVerificationError):
        frigg('master')


# Generated at 2022-06-24 01:37:20.732860
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = 'test'
    os.environ['GIT_BRANCH'] = 'test'
    os.environ['GIT_URL'] = 'test'
    os.environ['GIT_COMMIT'] = 'test'
    os.environ['BUILD_ID'] = 'test'
    os.environ['BUILD_NUMBER'] = 'test'
    os.environ['BUILD_DISPLAY_NAME'] = 'test'
    os.environ['BUILD_TAG'] = 'test'
    os.environ['BUILD_URL'] = 'test'
    os.environ['NODE_NAME'] = 'test'
    os.environ['JOB_NAME'] = 'test'

# Generated at 2022-06-24 01:37:22.336210
# Unit test for function circle
def test_circle():
    assert checker(circle)("master") == True
    assert checker(circle)("master") == True



# Generated at 2022-06-24 01:37:29.795284
# Unit test for function check
def test_check():
    """Test check function
    """
    import pytest
    from semantic_release.errors import CiVerificationError
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check("master")
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "false"

# Generated at 2022-06-24 01:37:38.991431
# Unit test for function check
def test_check():
    os.environ.clear()
    os.environ["TRAVIS"] = "true"
    check()
    del os.environ["TRAVIS"]
    os.environ["SEMAPHORE"] = "true"
    check()
    del os.environ["SEMAPHORE"]
    os.environ["FRIGG"] = "true"
    check()
    del os.environ["FRIGG"]
    os.environ["CIRCLECI"] = "true"
    check()
    del os.environ["CIRCLECI"]
    os.environ["GITLAB_CI"] = "true"
    check()
    del os.environ["GITLAB_CI"]
    os.environ["JENKINS_URL"] = "https://jenkins.io"
    check()


# Generated at 2022-06-24 01:37:50.619776
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = None
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    semaphore('master')

    del os.environ['BRANCH_NAME']
    with pytest.raises(CiVerificationError):
        semaphore('master')

    os.environ['BRANCH_NAME'] = 'foo'
    with pytest.raises(CiVerificationError):
        semaphore('master')

    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = 1

# Generated at 2022-06-24 01:37:55.149471
# Unit test for function jenkins
def test_jenkins():
    import os
    os.environ["JENKINS_URL"] = "https://my-jenkins.com"
    os.environ["BRANCH_NAME"] = "the_branch_name"
    os.environ["CHANGE_ID"] = "the_pull_request_id"
    jenkins("the_branch_name")

# Generated at 2022-06-24 01:37:56.566441
# Unit test for function jenkins
def test_jenkins():
    """
    Unit test for function jenkins
    """


# Generated at 2022-06-24 01:38:02.372828
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS"] = "true"
    assert travis("master")
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]



# Generated at 2022-06-24 01:38:03.991406
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    assert bitbucket("master")



# Generated at 2022-06-24 01:38:12.830231
# Unit test for function checker
def test_checker():
    """Unit test for function checker."""
    def travis_check_success(branch: str):
        """
        A dummy check for Travis CI that will succeed.
        """
        assert os.environ.get("TRAVIS_BRANCH") == branch

    def travis_check_fail(branch: str):
        """
        A dummy check for Travis CI that will fail.
        """
        assert os.environ.get("TRAVIS_BRANCH") == "invalid"

    @checker
    def test_success(branch: str):
        """
        A dummy check that will succeed.
        """
        travis_check_success(branch)

    @checker
    def test_fail(branch: str):
        """
        A dummy check that will fail.
        """
        travis

# Generated at 2022-06-24 01:38:18.032302
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"]="master"
    os.environ["PULL_REQUEST_NUMBER"]="None"
    os.environ["SEMAPHORE_THREAD_RESULT"]="passed"
    semaphore("master")
    os.environ["SEMAPHORE_THREAD_RESULT"]="failed"
    semaphore("master")


# Generated at 2022-06-24 01:38:19.967460
# Unit test for function checker
def test_checker():
    # pylint: disable=missing-function-docstring
    @checker
    def checker_test():
        assert False

    try:
        checker_test()
    except CiVerificationError:
        pass
    else:
        assert False

# Generated at 2022-06-24 01:38:30.151269
# Unit test for function semaphore
def test_semaphore():
    os.environ.update({"BRANCH_NAME":"master"})
    os.environ.pop("PULL_REQUEST_NUMBER", None)
    os.environ.pop("SEMAPHORE_THREAD_RESULT", None)
    semaphore("master")
    os.environ.update({"PULL_REQUEST_NUMBER":"1"})
    with pytest.raises(CiVerificationError):
        semaphore("master")
    os.environ.pop("PULL_REQUEST_NUMBER", None)
    os.environ.update({"SEMAPHORE_THREAD_RESULT":"failed"})
    with pytest.raises(CiVerificationError):
        semaphore("master")

# Generated at 2022-06-24 01:38:36.345852
# Unit test for function checker
def test_checker():
    def test_func(branch: str):
        assert os.environ["EXPECTED"] == branch
        raise AssertionError('Test successful')

    func = checker(test_func)

    os.environ["EXPECTED"] = "master"
    assert func("master")
    del os.environ["EXPECTED"]

    os.environ["EXPECTED"] = "master"
    try:
        func("notmaster")
    except CiVerificationError:
        assert True
    else:
        assert False
    del os.environ["EXPECTED"]

# Generated at 2022-06-24 01:38:46.617964
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "testing"
    os.environ["PULL_REQUEST_NUMBER"] = "true"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    try:
        semaphore()
    except CiVerificationError:
        pass
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    try:
        semaphore()
        assert True
    except CiVerificationError:
        pass
    del os.environ["SEMAPHORE"]

# Generated at 2022-06-24 01:38:47.808357
# Unit test for function semaphore
def test_semaphore():
    assert semaphore('branch')

# Generated at 2022-06-24 01:38:51.420996
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test the bitbucket check function
    """
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    assert bitbucket()

    # Error test
    del os.environ["BITBUCKET_PR_ID"]
    try:
        bitbucket()
    except CiVerificationError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:39:01.181602
# Unit test for function circle
def test_circle():
    """
    Tests the function circle.
    """
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = None

    circle("master")

    del os.environ["CIRCLE_BRANCH"]
    os.environ["CIRCLE_BRANCH"] = "develop"

    with pytest.raises(CiVerificationError):
        circle("master")

    del os.environ["CIRCLE_BRANCH"]
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "12345"
    with pytest.raises(CiVerificationError):
        circle

# Generated at 2022-06-24 01:39:03.017554
# Unit test for function circle
def test_circle():
    assert checker(circle)("master")

# Generated at 2022-06-24 01:39:06.918264
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis(branch="master") is True


# Generated at 2022-06-24 01:39:11.710101
# Unit test for function frigg
def test_frigg():
    # GIVEN: The frigg true env variable
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    # WHEN: We run the check for frigg
    # THEN: No exception will be raised
    frigg("master")



# Generated at 2022-06-24 01:39:17.877611
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['CIRCLE_BRANCH'] = 'master'
    os.environ['CI_PULL_REQUEST'] = 'false'
    assert check(branch='master')
    os.environ['CIRCLE_BRANCH'] = 'dev'
    assert not check(branch='master')