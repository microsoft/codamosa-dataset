

# Generated at 2022-06-24 01:29:22.789619
# Unit test for function jenkins
def test_jenkins():
    # No JENKINS_URL defined
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = ""
    assert jenkins("master")

    # GIT_BRANCH not defined
    os.environ["BRANCH_NAME"] = "dev"
    del os.environ["GIT_BRANCH"]
    assert not jenkins("master")

    # BRANCH_NAME not defined
    os.environ["GIT_BRANCH"] = "dev"
    del os.environ["BRANCH_NAME"]
    assert not jenkins("master")

    # BRANCH_NAME and GIT_BRANCH not defined

# Generated at 2022-06-24 01:29:27.135923
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = 'https://example.com'
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['CHANGE_ID'] = ''

    jenkins('master')


# Generated at 2022-06-24 01:29:28.617971
# Unit test for function check
def test_check():
    """
    Unit test for function check
    """
    check()

# Generated at 2022-06-24 01:29:31.618609
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "test"
    print(os.environ)

check()

# Generated at 2022-06-24 01:29:37.991718
# Unit test for function check
def test_check():
    """
    Unit test for function check.
    """
    with open('environment_vars_test.txt', 'w') as file:
        file.write('TRAVIS=true\n')
        file.write('TRAVIS_BRANCH=test\n')
        file.write('TRAVIS_PULL_REQUEST=false\n')
        file.write('SEMAPHORE=true\n')
        file.write('BRANCH_NAME=test\n')
        file.write('SEMAPHORE_THREAD_RESULT=passed\n')
        file.write('FRIGG=true\n')
        file.write('FRIGG_BUILD_BRANCH=test\n')
        file.write('CI_PULL_REQUEST=false\n')

# Generated at 2022-06-24 01:29:39.526208
# Unit test for function frigg
def test_frigg():
    assert frigg()

# Generated at 2022-06-24 01:29:42.602876
# Unit test for function checker
def test_checker():
    # Setup
    def test_func():
        raise AssertionError()
    # Exercise
    with pytest.raises(CiVerificationError):
        checker(test_func)()


# Generated at 2022-06-24 01:29:44.282364
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    bitbucket("master")

# Generated at 2022-06-24 01:29:50.495449
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.com"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "False"
    assert jenkins("master") == True

# Generated at 2022-06-24 01:29:56.106770
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    try:
        frigg()
    except CiVerificationError:
        pass
    except AssertionError:
        pass
    os.environ.pop('FRIGG')
    del os.environ['FRIGG']



# Generated at 2022-06-24 01:29:57.953441
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"

    check()


# Generated at 2022-06-24 01:30:01.155022
# Unit test for function check
def test_check():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    check()

# Generated at 2022-06-24 01:30:06.217850
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.implicitproductions.com"
    os.environ["CHANGE_ID"] = "12345"
    check()

# Generated at 2022-06-24 01:30:12.108726
# Unit test for function travis
def test_travis():
    with open('branch.txt', 'w') as f:
        f.write('master')
    os.environ["TRAVIS_BRANCH"] = 'master'
    os.environ["TRAVIS_PULL_REQUEST"] = 'false'

    check()
    assert os.environ["TRAVIS_BRANCH"] == 'master'
    assert os.environ["TRAVIS_PULL_REQUEST"] == 'false'



# Generated at 2022-06-24 01:30:24.385302
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    os.environ['FRIGG_PULL_REQUEST'] = ""
    frigg('master')
    # Wrong branch..
    os.environ['FRIGG_BUILD_BRANCH'] = "notmaster"
    try:
        frigg('master')
        raise AssertionError
    except CiVerificationError:
        pass
    # Pull Request..
    os.environ['FRIGG_PULL_REQUEST'] = "2"
    try:
        frigg('master')
        raise AssertionError
    except CiVerificationError:
        pass
    del os.environ['FRIGG']

# Generated at 2022-06-24 01:30:30.687988
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]


# Generated at 2022-06-24 01:30:32.406714
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-24 01:30:40.053443
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "123"
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = ""
    os.environ["CHANGE_ID"] = ""
    assert bitbucket("master")
    del os.environ["BITBUCKET_BRANCH"]
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        assert True
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        assert True

# Generated at 2022-06-24 01:30:41.558827
# Unit test for function check
def test_check():
    """
    Unit test for function check
    """
    check("test_branch")
    assert True

# Generated at 2022-06-24 01:30:46.973210
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""

    check()

    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-24 01:30:50.720264
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    travis('master')


# Generated at 2022-06-24 01:30:56.813979
# Unit test for function circle
def test_circle():
    """
    test for function circle
    """
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    check(branch="master")



# Generated at 2022-06-24 01:30:58.348441
# Unit test for function circle
def test_circle():
    # Test that the function does not raise AssertionError
    assert circle(branch="master") is True


# Generated at 2022-06-24 01:31:04.861699
# Unit test for function circle
def test_circle():
    # Test passes
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle("master") is True
    del os.environ["CIRCLE_BRANCH"]

    # Test fails 1st assertion
    os.environ["CIRCLE_BRANCH"] = "development"
    try:
        circle("master")
        assert False
    except CiVerificationError as err:
        assert err.args[0] == "The verification check for the environment did not pass."
    del os.environ["CIRCLE_BRANCH"]

    # Test fails 2nd assertion
    os.environ["CIRCLE_BRANCH"] = "master"

# Generated at 2022-06-24 01:31:06.377448
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master")



# Generated at 2022-06-24 01:31:10.265962
# Unit test for function gitlab
def test_gitlab():
    assert gitlab("master") is True
    assert gitlab("my_branch") is True
    assert gitlab("my_branch") is True

# Generated at 2022-06-24 01:31:16.361613
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "feature_branch"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    assert frigg("feature_branch") is True
    assert not frigg("master")

    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    assert not frigg("feature_branch")



# Generated at 2022-06-24 01:31:21.598470
# Unit test for function checker
def test_checker():
    """
    Test suite for checker function
    """

    def inner_func():
        return 5

    def inner_func2():
        assert False

    assert checker(inner_func)() == True

    try:
        checker(inner_func2)()
    except CiVerificationError:
        # No op
        assert True
    else:
        assert False, "Assertion Error not raised correctly"

# Generated at 2022-06-24 01:31:26.538973
# Unit test for function jenkins
def test_jenkins():
    """
    Check if the jenkins checker works correctly
    """
    # Master branch
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "http://www.jenkins.com"
    os.environ["CHANGE_ID"] = ""
    check()
    del os.environ["BRANCH_NAME"]
    del os.environ["GIT_BRANCH"]
    os.environ["BRANCH_NAME"] = "master"
    check()
    with open("tempfile.txt", "w") as f:
        f.write("master\n")
    os.environ["GIT_BRANCH"] = "tempfile.txt"
   

# Generated at 2022-06-24 01:31:32.957906
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["PULL_REQUEST_NUMBER"] = None
    assert semaphore(os.environ["BRANCH_NAME"])

# Generated at 2022-06-24 01:31:37.625421
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = ""
    assert not check()
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert check()


# Generated at 2022-06-24 01:31:40.576051
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"]='v2.2.7'
    #os.environ["PULL_REQUEST_NUMBER"]='5'
    os.environ["SEMAPHORE_THREAD_RESULT"]='success'
    semaphore("v2.2.7")

# Generated at 2022-06-24 01:31:41.125771
# Unit test for function gitlab
def test_gitlab():
    gitlab("master")


# Generated at 2022-06-24 01:31:44.411315
# Unit test for function gitlab
def test_gitlab():
    """
    Unit-test for the gitlab checker
    """
    os.environ['GITLAB_CI'] = 'true'
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    check()

# Generated at 2022-06-24 01:31:46.656301
# Unit test for function checker
def test_checker():
    def test_func(s: str, i: int):
        assert s == "foo"
        assert i == 5

    assert checker(test_func)("foo", 5)

    try:
        checker(test_func)("bar", 5)
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 01:31:51.567862
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis(branch="master")
    os.environ["TRAVIS_BRANCH"] = "feature"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis(branch="master")
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:31:52.504211
# Unit test for function check
def test_check():
    assert check() is None



# Generated at 2022-06-24 01:31:57.736720
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    os.environ['GITLAB_CI'] = 'true'
    os.environ['MERGE_REQUEST_ID'] = ''
    assert gitlab('master') == True
    assert gitlab('staging') == False


# Generated at 2022-06-24 01:32:06.372104
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"

# Generated at 2022-06-24 01:32:11.377050
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = 'http://localhost:8080'
    os.environ['CI_BRANCH'] = 'master'
    os.environ['BUILD_ID'] = '1'
    os.environ['GIT_BRANCH'] = 'master'
    os.environ['BRANCH_NAME'] = 'master'

    jenkins(branch='master')


# Generated at 2022-06-24 01:32:20.087809
# Unit test for function semaphore
def test_semaphore():
    # Check for successful build and correct branch
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"

    assert semaphore("master")

    # Check for failed build
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"

    try:
        semaphore("master")
    except CiVerificationError:
        assert True
    else:
        assert False

    # Check for pull-request build
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["PULL_REQUEST_NUMBER"] = "1"

# Generated at 2022-06-24 01:32:30.598353
# Unit test for function jenkins
def test_jenkins():
    # Set environment variables
    os.environ["JENKINS_URL"] = "jenkins.com"
    os.environ["GIT_BRANCH"] = "master"
    assert check() is None
    os.environ["BRANCH_NAME"] = "master"
    assert check() is None
    
    # Set environment variables
    os.environ["JENKINS_URL"] = "jenkins.com"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "1234"
    assert check() is None
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CHANGE_ID"] = "1234"
    assert check() is None

# Generated at 2022-06-24 01:32:41.924532
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "hello"
    os.environ["BRANCH_NAME"] = "master"
    assert jenkins("master") == True
    os.environ["BRANCH_NAME"] = "master2"
    assert jenkins("master") != True
    os.environ["BRANCH_NAME"] = None
    os.environ["GIT_BRANCH"] = "master"
    assert jenkins("master") == True
    os.environ["GIT_BRANCH"] = "master2"
    assert jenkins("master") != True
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "1"
    assert jenkins("master") != True



# Generated at 2022-06-24 01:32:45.185916
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["GITLAB_CI"] = "true"
    check()
    del os.environ["GITLAB_CI"]
    del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-24 01:32:50.234356
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = None
    assert circle("master")

# Generated at 2022-06-24 01:32:58.373445
# Unit test for function frigg
def test_frigg():
    # Set environ to frigg
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "frigg"
    os.environ["FRIGG_PULL_REQUEST"] = "0"
    # Call frigg
    frigg("frigg")
    # Check if exception is raise when the wrong branch is given
    try:
        frigg("frig")
    except CiVerificationError:
        os.environ["FRIGG_BUILD_BRANCH"] = "frig"
        frigg("frig")
    assert True

# Generated at 2022-06-24 01:33:03.148856
# Unit test for function jenkins
def test_jenkins():
    ci = "jenkins"
    os.environ["JENKINS_URL"] = "https://ci.cloudbees.com/"
    os.environ["BRANCH_NAME"] = "master"
    check(branch="master")
    check(branch="develop")

# Generated at 2022-06-24 01:33:11.197992
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    try:
        check()
    except CiVerificationError as e:
        assert "did not pass" in str(e)
    finally:
        del os.environ["GITLAB_CI"]
        del os.environ["CI_COMMIT_REF_NAME"]

# Generated at 2022-06-24 01:33:19.732327
# Unit test for function semaphore
def test_semaphore():
    """
    Test semaphore environment.
    """
    assert (
        "SEMAPHORE_THREAD_RESULT" in os.environ
    ), "SEMAPHORE_THREAD_RESULT is not in os.environ"
    assert not os.environ.get(
        "SEMAPHORE_THREAD_RESULT"
    ), "SEMAPHORE_THREAD_RESULT is not null"
    assert "BRANCH_NAME" in os.environ, "BRANCH_NAME is not in os.environ"
    assert not os.environ.get("PULL_REQUEST_NUMBER"), "PULL_REQUEST_NUMBER is not null"
    semaphore("semaphore")



# Generated at 2022-06-24 01:33:25.045800
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    del os.environ["FRIGG"]
    del os.environ["FRIGG_BUILD_BRANCH"]



# Generated at 2022-06-24 01:33:34.252517
# Unit test for function frigg
def test_frigg():
    assert os.environ.get("FRIGG") != "true"
    os.environ["FRIGG"] = "true"
    assert os.environ.get("FRIGG_BUILD_BRANCH") != "master"
    assert os.environ.get("FRIGG_PULL_REQUEST") != "false"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert os.environ.get("FRIGG_BUILD_BRANCH") == "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    assert os.environ.get("FRIGG_PULL_REQUEST") != "false"
    frigg("master")

# Generated at 2022-06-24 01:33:40.563044
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    check()
    del os.environ["FRIGG_PULL_REQUEST"]
    del os.environ["FRIGG_BUILD_BRANCH"]
    del os.environ["FRIGG"]



# Generated at 2022-06-24 01:33:44.806699
# Unit test for function jenkins
def test_jenkins():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "http://localhost"
    os.environ["CHANGE_ID"] = None
    jenkins("master")


if __name__ == "__main__":
    test_jenkins()

# Generated at 2022-06-24 01:33:45.811683
# Unit test for function semaphore
def test_semaphore():
  assert semaphore() == True

# Generated at 2022-06-24 01:33:51.168578
# Unit test for function gitlab
def test_gitlab():
    def actual_func(*args, **kwargs):
        assert os.environ.get("CI_COMMIT_REF_NAME")

    def func_wrapper(*args, **kwargs):
        try:
            actual_func(*args, **kwargs)
            return True
        except AssertionError:
            raise CiVerificationError(
                "The verification check for the environment did not pass."
            )

    return func_wrapper

# Generated at 2022-06-24 01:33:54.296849
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()


# Generated at 2022-06-24 01:34:05.280497
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "some-pr-branch"
    os.environ["FRIGG_PULL_REQUEST"] = "1"

    try:
        frigg("master")
    except CiVerificationError:
        pass
    else:
        raise AssertionError

    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = ""
    frigg("master")

    os.environ["FRIGG_BUILD_BRANCH"] = "dev"
    os.environ["FRIGG_PULL_REQUEST"] = ""


# Generated at 2022-06-24 01:34:06.969784
# Unit test for function gitlab
def test_gitlab():  # noqa: D103
    assert gitlab("master") is True



# Generated at 2022-06-24 01:34:11.371323
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master-f"
    os.environ["FRIGG_PULL_REQUEST"] = "0"
    os.environ["FRIGG_BUILD_STATUS"] = "success"
    frigg("master-f")

# Generated at 2022-06-24 01:34:15.808219
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg("master")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    try:
        frigg("master")
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-24 01:34:25.672369
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "https://jenkins.com"
    os.environ['BRANCH_NAME'] = "master"
    os.environ['GIT_BRANCH'] = "master"
    assert jenkins("master")
    assert jenkins("dev") is False
    os.environ['CHANGE_ID'] = "1"
    assert jenkins("master") is False
    del os.environ['CHANGE_ID']
    os.environ['BRANCH_NAME'] = "dev"
    del os.environ['BRANCH_NAME']
    assert jenkins("dev") is False
    os.environ['GIT_BRANCH'] = "dev"
    assert jenkins("dev")

# Generated at 2022-06-24 01:34:30.392975
# Unit test for function semaphore
def test_semaphore():
    """ Simply test if function returns False when OS env vars not set,
        True otherwise. """
    assert semaphore('master') == False
    os.environ["BRANCH_NAME"] = 'master'
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    assert semaphore('master') == True

# Generated at 2022-06-24 01:34:35.591480
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_PULL_REQUEST"]
    del os.environ["TRAVIS_BRANCH"]


# Generated at 2022-06-24 01:34:39.310650
# Unit test for function checker
def test_checker():
    @checker
    def a_function():
        raise AssertionError()

    try:
        a_function()
        assert False
    except CiVerificationError:
        pass

# Generated at 2022-06-24 01:34:43.038833
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = 'true'
    os.environ['FRIGG_BUILD_BRANCH'] = 'master'
    os.environ['FRIGG_PULL_REQUEST'] = ''
    check()

# Generated at 2022-06-24 01:34:48.611461
# Unit test for function checker
def test_checker():
    @checker
    def test_function():
        assert False

    try:
        test_function()
    except CiVerificationError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-24 01:34:49.521586
# Unit test for function circle
def test_circle():
    assert circle is checker(circle)

# Generated at 2022-06-24 01:35:00.737915
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "localhost"
    branch_name_set = [
        "master",
        "feature/foo",
        "bugfix/bar",
        "hotfix",
        "hotfix/baz"
    ]
    for branch_name in branch_name_set:
        os.environ["BRANCH_NAME"] = branch_name
        os.environ["GIT_BRANCH"] = branch_name
        os.environ["CHANGE_ID"] = ""
        jenkins(branch_name)
        os.environ["CHANGE_ID"] = "1"
        try:
            jenkins(branch_name)
            raise Exception("This exception should not be raised")
        except AssertionError:
            pass

# Generated at 2022-06-24 01:35:04.710227
# Unit test for function checker
def test_checker():
    def inner_func(check: Callable, branch: str):
        check(branch)

    @checker
    def decorated_func(check: Callable, branch: str):
        inner_func(check, branch)

    decorated_func(travis, "master")



# Generated at 2022-06-24 01:35:10.531717
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = 'www.test.test'
    os.environ["BRANCH_NAME"] = 'master'
    # CHANGE_ID is set to pull request id
    os.environ["CHANGE_ID"] = 'test-id'
    try: 
        jenkins('master')
    except CiVerificationError:
        pass
    else:
        raise AssertionError('Should have raised CiVerificationError')
    del os.environ["CHANGE_ID"]
    try: 
        jenkins('master')
    except CiVerificationError:
        print('Should not have raised CiVerificationError')

# Generated at 2022-06-24 01:35:16.492312
# Unit test for function jenkins
def test_jenkins():
    os.environ["GIT_BRANCH"] = "master"
    os.environ["JENKINS_URL"] = "http://example.com"
    assert jenkins("master")
    del os.environ["JENKINS_URL"]
    del os.environ["GIT_BRANCH"]


# Generated at 2022-06-24 01:35:20.363099
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-24 01:35:30.461714
# Unit test for function frigg
def test_frigg():
    """
    Checks if the function frigg works as intended.
    """
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    frigg(os.environ["FRIGG_BUILD_BRANCH"])
    os.environ["FRIGG_BUILD_BRANCH"] = "other-branch"
    try:
        frigg(os.environ["FRIGG_BUILD_BRANCH"])
    except CiVerificationError as e:
        assert str(e) == "The verification check for the environment did not pass."
        return
    raise AssertionError("The frigg function on branch does not work as intended")
    

# Generated at 2022-06-24 01:35:33.549991
# Unit test for function frigg
def test_frigg():
    assert frigg("master") is True
    assert frigg("release") is True
    assert frigg("feature") is True
    try:
        assert frigg("release") is False
    except AssertionError:
        pass
    else:
        assert False

# Generated at 2022-06-24 01:35:37.261446
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "test"
    os.environ["BRANCH_NAME"] = "test"
    jenkins()
    os.environ["GIT_BRANCH"] = "test"
    jenkins()
    del os.environ["JENKINS_URL"]
    del os.environ["GIT_BRANCH"]

# Generated at 2022-06-24 01:35:44.441798
# Unit test for function bitbucket
def test_bitbucket():
    os.environ.update(BITBUCKET_BRANCH = "master", BITBUCKET_PR_ID = "")
    bitbucket("master")
    os.environ.update(BITBUCKET_BRANCH = "", BITBUCKET_PR_ID = "1")
    try:
        bitbucket("master")
        assert False
    except CiVerificationError:
        pass



# Generated at 2022-06-24 01:35:50.256936
# Unit test for function jenkins
def test_jenkins():
    # GIVEN a branch
    branch='master'
    # WHEN the checker is running
    os.environ['JENKINS_URL'] = 'https://my.jenkins.server'
    os.environ['CHANGE_ID'] = '12345'
    try:
        jenkins(branch)
    except:
        assert True
    os.environ['CHANGE_ID'] = None
    assert jenkins(branch)
    del os.environ['JENKINS_URL']

# Generated at 2022-06-24 01:35:52.947217
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = "false"

    check()



# Generated at 2022-06-24 01:35:56.934469
# Unit test for function semaphore
def test_semaphore():
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    os.environ["PULL_REQUEST_NUMBER"] = None
    assert semaphore("master") == True

    del os.environ["SEMAPHORE"]
    assert semaphore("master") == True
    os.environ.pop("PULL_REQUEST_NUMBER")
    os.environ.pop("BRANCH_NAME")
    os.environ.pop("SEMAPHORE_THREAD_RESULT")


# Generated at 2022-06-24 01:36:01.889532
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        assert travis("master") == True
    except AssertionError:
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "true"
        try:
            travis("master")
        except AssertionError:
            assert True

# Generated at 2022-06-24 01:36:06.498687
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_PULL_REQUEST'] = "false"
    os.environ['TRAVIS_BRANCH'] = "master"
    travis("master")
    try:
        os.environ['TRAVIS_BRANCH'] = "dev"
        travis("master")
    except CiVerificationError:
        return True
    return False


# Generated at 2022-06-24 01:36:10.083319
# Unit test for function checker
def test_checker():
    @checker
    def func(input: bool):
        assert input

    func(input=True)

    try:
        func(input=False)
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Expected a CiVerificationError on the check failing")

# Generated at 2022-06-24 01:36:15.722534
# Unit test for function gitlab
def test_gitlab():
    assert checker(gitlab)('master')
    assert checker(gitlab)('develop')

    os.environ['CI_COMMIT_REF_NAME'] = 'master'
    assert checker(gitlab)('master')
    assert checker(gitlab)('develop')

    os.environ['CI_COMMIT_REF_NAME'] = 'develop'
    assert checker(gitlab)('develop')
    assert checker(gitlab)('master')

    os.environ['CI_COMMIT_REF_NAME'] = 'branch'
    assert checker(gitlab)('branch')
    assert checker(gitlab)('master')
    assert checker(gitlab)('develop')

    os.environ['CI_COMMIT_REF_NAME'] = None

# Generated at 2022-06-24 01:36:25.380928
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    assert semaphore() is True

    os.environ["BRANCH_NAME"] = "develop"
    assert semaphore() is False

    del os.environ["BRANCH_NAME"]
    os.environ["PULL_REQUEST_NUMBER"] = "1"
    assert semaphore() is False

    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore() is False

# Generated at 2022-06-24 01:36:31.942200
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "true"
    try:
        travis("master")
    except CiVerificationError:
        pass


# Generated at 2022-06-24 01:36:42.119022
# Unit test for function semaphore
def test_semaphore():
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = None
    os.environ["SEMAPHORE_THREAD_RESULT"] = "passed"
    semaphore(branch="master")
    assert os.environ["BRANCH_NAME"] == "master"
    assert os.environ["PULL_REQUEST_NUMBER"] is None
    assert os.environ["SEMAPHORE_THREAD_RESULT"] == "passed"
    del os.environ["BRANCH_NAME"]
    del os.environ["PULL_REQUEST_NUMBER"]
    del os.environ["SEMAPHORE_THREAD_RESULT"]


# Generated at 2022-06-24 01:36:48.109856
# Unit test for function jenkins
def test_jenkins():
    branch = "master"
    branch_env_name = "BRANCH_NAME"
    branch_env_value = "master"
    branch_env_name_git = "GIT_BRANCH"
    branch_env_value_git = "master"
    jenkins_url = "https://builds.apache.org/job/openwhisk-utest/job/master/"
    jenkins_url_env_value = "https://builds.apache.org/job/openwhisk-utest/job/master/"
    jenkins_url_env_name = "JENKINS_URL"
    change_id = "123"
    change_id_env_name = "CHANGE_ID"
    change_id_env_value = "123"

# Generated at 2022-06-24 01:36:55.425461
# Unit test for function checker
def test_checker():
    def func_assertion_error():
        raise AssertionError()

    func_ci_error = checker(func_assertion_error)

    try:
        func_assertion_error()
    except AssertionError as err:
        pass
    else:
        raise Exception()

    try:
        func_ci_error()
    except CiVerificationError as err:
        pass
    else:
        raise Exception()



# Generated at 2022-06-24 01:37:04.602071
# Unit test for function circle
def test_circle():
    assert os.environ.get("CIRCLECI") == "true"
    assert os.environ.get("CIRCLE_BRANCH") == "master"
    assert not os.environ.get("CI_PULL_REQUEST")
    try:
        check(branch="master")
        assert True
    except CiVerificationError:
        assert False
    try:
        check(branch="dev")
        assert False
    except CiVerificationError:
        assert True
    try:
        check(branch="pull-request")
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-24 01:37:06.959788
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "jenkinsurl"
    os.environ["BRANCH"] = "test"
    os.environ["CHANGE_ID"] = None
    check("test")
    os.environ["BRANCH"] = "test"
    os.environ["CHANGE_ID"] = 1
    assert not check("test")

# Generated at 2022-06-24 01:37:17.199400
# Unit test for function jenkins
def test_jenkins():
    """
    Unit test for function jenkins
    """
    # The "JENKINS_URL" variable must be set for this function to pass.
    if os.environ.get("JENKINS_URL") is None:
        os.environ["JENKINS_URL"] = "http://jenkins/"

    # Test 1: the "JENKINS_URL" variable is set and the branch name matches.
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    assert jenkins("master") == True
    del os.environ["BRANCH_NAME"]
    del os.environ["GIT_BRANCH"]

    # Test 2: the "JENKINS_URL" variable is set but the branch names do

# Generated at 2022-06-24 01:37:20.114355
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    assert check() == None


# Generated at 2022-06-24 01:37:25.497676
# Unit test for function checker
def test_checker():
    @checker
    def test_decorator():
        raise AssertionError("This error should be raised")

    try:
        test_decorator()
    except AssertionError:
        raise AssertionError("This error should NOT be raised")
    except CiVerificationError:
        pass
    else:
        raise AssertionError("This error should be raised")

# Generated at 2022-06-24 01:37:34.599089
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    with pytest.raises(CiVerificationError):
        bitbucket("devel")
    os.environ['BITBUCKET_BRANCH'] = 'devel'
    with pytest.raises(CiVerificationError):
        bitbucket("master")
    os.environ['BITBUCKET_BRANCH'] = 'master'

    os.environ["BITBUCKET_PR_ID"] = "1"
    with pytest.raises(CiVerificationError):
        bitbucket("devel")
    os.environ['BITBUCKET_PR_ID'] = '1'
    with pytest.raises(CiVerificationError):
        bitbucket("master")
    os.en

# Generated at 2022-06-24 01:37:37.811547
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "test"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("test")
    # TODO: Should add more thorough tests for function travis


# Generated at 2022-06-24 01:37:40.839814
# Unit test for function frigg
def test_frigg():
    """Simulate frigg CI run"""
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    with pytest.raises(CiVerificationError):
        check()
    os.environ["FRIGG_PR"] = "false"
    check()



# Generated at 2022-06-24 01:37:42.171630
# Unit test for function checker
def test_checker():
    @checker
    def test(branch: str = "master"):
        assert branch == "master"

    test()

# Generated at 2022-06-24 01:37:50.083948
# Unit test for function checker
def test_checker():
    def func1(a,b,c=None):
        return a+b+c

    checker_func1 = checker(func1)

    assert checker_func1(1,2, 3) == True

    def func2(a,b):
        return a+b

    checker_func2 = checker(func2)
    try:
        checker_func2(1,2,3)
    except Exception as e:
        assert isinstance(e, CiVerificationError)



# Generated at 2022-06-24 01:37:56.788839
# Unit test for function semaphore
def test_semaphore():
    os.environ['BRANCH_NAME'] = 'master'
    os.environ['PULL_REQUEST_NUMBER'] = 'null'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    assert semaphore('master') == True
    # os.environ['BRANCH_NAME'] = 'test'
    # os.environ['PULL_REQUEST_NUMBER'] = 'null'
    # os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    # assert semaphore('master') == False



# Generated at 2022-06-24 01:38:00.415436
# Unit test for function frigg
def test_frigg():
    """
    Checks that frigg() works as expected.
    """
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = None
    frigg("master")



# Generated at 2022-06-24 01:38:09.477565
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check()

    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    os.environ["CI_MERGE_REQUEST_ID"] = None
    check("develop")

    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    try:
        check()
    except CiVerificationError:
        pass
    else:
        raise Exception("gitlab - Merge request not detected")

# Generated at 2022-06-24 01:38:10.345896
# Unit test for function check
def test_check():
    # TODO - use environments like nose does
    pass

# Generated at 2022-06-24 01:38:19.789318
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    print("\n", "Frigg CI test: Needs to raise  CiVerificationError:")
    frigg("master")
    print("\n", "Frigg CI test: No need to raise CiVerificationError:")
    frigg("develop")
    print("\n", "Frigg CI test: Needs to raise  CiVerificationError:")
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    frigg("master")

# Generated at 2022-06-24 01:38:22.291241
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "develop"
    os.environ["BITBUCKET_PR_ID"] = "0"
    check("develop")


# Generated at 2022-06-24 01:38:26.409122
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")



# Generated at 2022-06-24 01:38:29.914465
# Unit test for function checker
def test_checker():
    @checker
    def test_func():
        raise AssertionError

    test_func()

# Generated at 2022-06-24 01:38:33.979405
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BUILD_NUMBER"] = "12345"
    os.environ["BITBUCKET_BRANCH"] = "release/v2.1.0"
    os.environ["BITBUCKET_PR_ID"] = "100"
    bitbucket('master')



# Generated at 2022-06-24 01:38:43.504030
# Unit test for function gitlab
def test_gitlab():
    """
    Test method for gitlab. Checks if the environment variables are set right.
    """
    branch = 'master'
    os.environ["CI_COMMIT_REF_NAME"] = branch
    os.environ["CI_BUILD_TAG"] = None
    gitlab(branch)
    os.environ["CI_COMMIT_REF_NAME"] = branch+"1"
    try:
        gitlab(branch)
    except CiVerificationError as e:
        assert "did not pass" in str(e)
    os.environ["CI_COMMIT_REF_NAME"] = branch

# Generated at 2022-06-24 01:38:50.666458
# Unit test for function circle
def test_circle():
    # Test for correct branch name in os.environ
    os.environ["CIRCLE_BRANCH"] = "master"
    assert circle("master")
    assert not circle("dev")

    # Test for a pull-request id in os.environ
    os.environ["CI_PULL_REQUEST"] = "1"
    assert not circle()

    # Test for no branch name in os.environ
    del os.environ["CIRCLE_BRANCH"]
    assert not circle("master")

# Generated at 2022-06-24 01:38:53.314236
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    try:
        check()
    except CiVerificationError:
        assert False

# Generated at 2022-06-24 01:38:54.228598
# Unit test for function gitlab
def test_gitlab():
    assert checker(gitlab)("master") is True

# Generated at 2022-06-24 01:38:59.771807
# Unit test for function frigg
def test_frigg():
    os.environ["BRANCH_NAME"] = "new_branch"
    os.environ["PULL_REQUEST_NUMBER"] = "1234"

    assert check() == True


# Generated at 2022-06-24 01:39:10.956188
# Unit test for function bitbucket
def test_bitbucket():
    # Case 1:
    # A Bitbucket Environment with the correct branch,
    # not a pull-request and with the BITBUCKET environment variable enabled
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = None
    os.environ["BITBUCKET_BUILD_NUMBER"] = "12345"

    assert bitbucket("master") is True

    # Case 2:
    # A Bitbucket Environment with the wrong branch,
    # not a pull-request and with the BITBUCKET environment variable enabled
    os.environ["BITBUCKET_BRANCH"] = "feature"
    os.environ["BITBUCKET_PR_ID"] = None

# Generated at 2022-06-24 01:39:18.516190
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master")
    os.environ["BRANCH_NAME"] = "master"
    os.environ["PULL_REQUEST_NUMBER"] = "123"
    assert semaphore("master") is False
    del os.environ["PULL_REQUEST_NUMBER"]
    os.environ["SEMAPHORE_THREAD_RESULT"] = "failed"
    assert semaphore("master") is False

