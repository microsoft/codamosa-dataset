

# Generated at 2022-06-26 01:02:32.080197
# Unit test for function check
def test_check():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    try:
        check()
        raise AssertionError("Should raise error")
    except CiVerificationError:
        pass
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]



# Generated at 2022-06-26 01:02:32.579225
# Unit test for function check
def test_check():
    assert check() is None

# Generated at 2022-06-26 01:02:34.176731
# Unit test for function bitbucket
def test_bitbucket():
    var_1 = bitbucket("$3v3n71m3")
    assert var_1 is not None


# Generated at 2022-06-26 01:02:35.032193
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("master") == None

# Generated at 2022-06-26 01:02:36.205476
# Unit test for function gitlab
def test_gitlab():
    with pytest.raises(CiVerificationError):
        gitlab("develop")

# Generated at 2022-06-26 01:02:37.019400
# Unit test for function bitbucket
def test_bitbucket():
    assert 1 == bitbucket()


# Generated at 2022-06-26 01:02:38.109897
# Unit test for function gitlab
def test_gitlab():
    branch = 'master'
    assert gitlab(branch) == True


# Generated at 2022-06-26 01:02:41.297059
# Unit test for function circle
def test_circle():
    # Assert for correct behavior for circle
    assert circle("master")
    assert circle("dev")
    assert bitbucket("release")

    # Assert for incorrect behavior for circle
    assert not circle("wrong")



# Generated at 2022-06-26 01:02:44.261261
# Unit test for function gitlab
def test_gitlab():
    var_0 = gitlab("master")
    assert var_0 == True


# Generated at 2022-06-26 01:02:45.276569
# Unit test for function jenkins
def test_jenkins():
    # TODO: Write unit test
    pass


# Generated at 2022-06-26 01:02:54.124255
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "dev"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    var_0 = check("dev")


# Generated at 2022-06-26 01:03:03.325954
# Unit test for function semaphore
def test_semaphore():
    var_1 = os.environ.get("BRANCH_NAME")
    os.environ.update({
        "BRANCH_NAME": "var_2",
        "PULL_REQUEST_NUMBER": None,
        "SEMAPHORE_THREAD_RESULT": "var_3"
    })
    var_2 = semaphore("var_2")
    # Restore environment variable
    if var_1 is None:
        del os.environ["BRANCH_NAME"]
    else:
        os.environ["BRANCH_NAME"] = var_1
    # Restore environment variable
    if var_1 is None:
        del os.environ["PULL_REQUEST_NUMBER"]
    else:
        os.environ["PULL_REQUEST_NUMBER"] = var_1
   

# Generated at 2022-06-26 01:03:06.721367
# Unit test for function jenkins
def test_jenkins():
    branch = 'master'
    x = jenkins(branch)
    assert x == None


# Generated at 2022-06-26 01:03:07.992211
# Unit test for function semaphore
def test_semaphore():
    assert semaphore('master') == True


# Generated at 2022-06-26 01:03:10.198534
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    var_0 = check()


# Generated at 2022-06-26 01:03:11.988148
# Unit test for function gitlab
def test_gitlab():
    # Make sure that it can detect the variable properly
    assert gitlab.__name__ == 'gitlab'
    # Make sure it raises an error
    assert gitlab('master') == True

# Generated at 2022-06-26 01:03:14.835730
# Unit test for function frigg
def test_frigg():
    assert frigg("master")
    assert frigg("some_branch")


# Generated at 2022-06-26 01:03:15.614128
# Unit test for function travis
def test_travis():
    var_0 = check()



# Generated at 2022-06-26 01:03:26.681647
# Unit test for function check
def test_check():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    var_0 = check("master")

    os.environ["CIRCLE_BRANCH"] = "develop"
    var_0 = check("develop")
    del os.environ["CIRCLE_BRANCH"]
    var_0 = check("master")
    var_0 = check("develop")

    os.environ["CIRCLE_BRANCH"] = "master"
    var_0 = check("master")
    del os.environ["CIRCLE_BRANCH"]

    os.environ["CI_PULL_REQUEST"] = "123"
    var_0 = check("master")
    del os.environ["CI_PULL_REQUEST"]

# Generated at 2022-06-26 01:03:28.205980
# Unit test for function travis
def test_travis():

    assert travis(branch="master") == True
    assert travis(branch="foo") == False


# Generated at 2022-06-26 01:03:43.164121
# Unit test for function circle
def test_circle():
    circle("master")


# Generated at 2022-06-26 01:03:46.046362
# Unit test for function frigg
def test_frigg():
    assert os.environ.get("FRIGG_BUILD_BRANCH") == "master"
    assert not os.environ.get("FRIGG_PULL_REQUEST")


# Generated at 2022-06-26 01:03:47.217889
# Unit test for function check
def test_check():
    result = check()
    assert result != None


# Generated at 2022-06-26 01:03:51.657596
# Unit test for function bitbucket
def test_bitbucket():
    var_0 = bitbucket('')


# Generated at 2022-06-26 01:03:56.049503
# Unit test for function bitbucket
def test_bitbucket():
    """
    Test whether bitbucket() works correctly.
    """
    # Assign arguments
    var_0 = "master"

    # Call function
    try:
        bitbucket(var_0)
    except ValueError as e:
        print(e)


# Generated at 2022-06-26 01:03:57.432824
# Unit test for function travis
def test_travis():
    var_0 = travis()
    var_1 = travis(branch = "master")


# Generated at 2022-06-26 01:04:00.108922
# Unit test for function semaphore
def test_semaphore():
    branch = "master"
    result = checker(semaphore("master"))
    assert result == True # "Checking that `checker` decorator works correctly."


# Generated at 2022-06-26 01:04:03.575487
# Unit test for function check
def test_check():
    try:
        check()
    except CiVerificationError as err:
        assert type(err) == CiVerificationError


# Generated at 2022-06-26 01:04:04.442376
# Unit test for function travis
def test_travis():
    travis('master')

# Generated at 2022-06-26 01:04:12.370487
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket('master')(), "Valid input should return True"
    assert not bitbucket('master')(), "Invalid input should return False"
    assert not bitbucket('master')(), "Valid input should return True"
    assert bitbucket('master')(), "Invalid input should return False"
    assert bitbucket('master')(), "Valid input should return True"
    assert not bitbucket('master')(), "Invalid input should return False"
    assert bitbucket('master')(), "Valid input should return True"
    assert bitbucket('master')(), "Invalid input should return False"


# Generated at 2022-06-26 01:04:39.499287
# Unit test for function frigg
def test_frigg():
    current_branch = "master"
    assert os.environ.get("FRIGG") != current_branch, "Environment variable FRIGG is not master"
    assert os.environ.get("FRIGG_BUILD_BRANCH") == current_branch, "Environment variable FRIGG_BUILD_BRANCH is not master"
    assert not os.environ.get("FRIGG_PULL_REQUEST"), "Environment variable FRIGG_PULL_REQUEST is not empty"



# Generated at 2022-06-26 01:04:40.435715
# Unit test for function checker
def test_checker():
    assert checker(travis)



# Generated at 2022-06-26 01:04:42.484234
# Unit test for function checker
def test_checker():
    # Verify that the function checker evaluates the function func, and that the return value is True
    def func():
        pass
    assert checker(func)() == True



# Generated at 2022-06-26 01:04:50.393313
# Unit test for function circle
def test_circle():
    env = os.environ.copy()
    env['CIRCLECI'] = 'true'
    env['CIRCLE_BRANCH'] = 'master'
    env['CI_PULL_REQUEST'] = ''
    assert circle('master')
    env['CIRCLE_BRANCH'] = ''
    assert not circle('master')
    env['CIRCLE_BRANCH'] = 'master'
    env['CI_PULL_REQUEST'] = 'true'
    assert not circle('master')
    env['CIRCLE_BRANCH'] = 'develop'
    env['CI_PULL_REQUEST'] = ''
    assert not circle('master')


# Generated at 2022-06-26 01:04:51.482407
# Unit test for function frigg
def test_frigg():
    var_1 = frigg(branch="master")


# Generated at 2022-06-26 01:04:54.074673
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    assert travis("master")



# Generated at 2022-06-26 01:04:56.007726
# Unit test for function check
def test_check():
    try:
        check()
    except CiVerificationError:
        assert True
    else:
        assert False

# Generated at 2022-06-26 01:04:56.657011
# Unit test for function bitbucket
def test_bitbucket():
    assert type(bitbucket(branch)) is bool

# Generated at 2022-06-26 01:04:57.814166
# Unit test for function travis
def test_travis():
    assert isinstance(travis("master"),bool)

# Generated at 2022-06-26 01:04:58.445575
# Unit test for function semaphore
def test_semaphore():
    assert semaphore('master')


# Generated at 2022-06-26 01:05:59.031711
# Unit test for function circle
def test_circle():
    try:
        circle(branch="master")
        assert True == False
    except AssertionError:
        pass
    except CiVerificationError:
        pass


# Generated at 2022-06-26 01:05:59.829883
# Unit test for function check
def test_check():
    var_0 = check()

# Generated at 2022-06-26 01:06:00.543915
# Unit test for function travis
def test_travis():
    var_0 = travis()


# Generated at 2022-06-26 01:06:07.331414
# Unit test for function semaphore
def test_semaphore():
    branch_0 = os.environ.get("BRANCH_NAME")
    branch_1 = os.environ.get("PULL_REQUEST_NUMBER")
    branch_2 = os.environ.get("SEMAPHORE_THREAD_RESULT")
    branch_3 = branch_0 == branch_1
    branch_4 = branch_3 is None
    branch_5 = branch_2 != "failed"
    branch_6 = branch_4 and branch_5
    branch_7 = branch_1 is branch_6
    branch_8 = branch_7 is branch_6
    branch_9 = branch_4 or branch_6
    branch_10 = branch_9 and branch_3
    branch_11 = branch_1 is branch_8
    branch_12 = branch_10 and branch_11
    branch_13 = branch

# Generated at 2022-06-26 01:06:09.048619
# Unit test for function bitbucket
def test_bitbucket():
    try:
        bitbucket("master")
    except CiVerificationError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 01:06:16.830367
# Unit test for function semaphore
def test_semaphore():

    # Test case for when the checks fail all assertions
    os.environ['BRANCH_NAME'] = 'this_should_fail'
    os.environ['PULL_REQUEST_NUMBER'] = 'True'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'

    try:
        semaphore('master')
    except:
        var_1 = True
    else:
        var_1 = False

    # Test case for when the checks fail the first assertion
    os.environ['BRANCH_NAME'] = 'another_branch'
    os.environ['PULL_REQUEST_NUMBER'] = 'True'
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'failed'


# Generated at 2022-06-26 01:06:22.569548
# Unit test for function checker
def test_checker():
    assert checker(check()) == True
    try:
        var_0 = checker(travis())
    except:
        var_0 = False
    assert var_0 == False
    try:
        var_0 = checker(semaphore())
    except:
        var_0 = False
    assert var_0 == False
    try:
        var_0 = checker(frigg())
    except:
        var_0 = False
    assert var_0 == False
    try:
        var_0 = checker(circle())
    except:
        var_0 = False
    assert var_0 == False
    try:
        var_0 = checker(gitlab())
    except:
        var_0 = False
    assert var_0 == False

# Generated at 2022-06-26 01:06:23.780210
# Unit test for function frigg
def test_frigg():
    var_1 = frigg("master")
    assert var_1 == True


# Generated at 2022-06-26 01:06:25.675747
# Unit test for function checker
def test_checker():
    assert checker(test_case_0)

# Generated at 2022-06-26 01:06:27.779422
# Unit test for function bitbucket
def test_bitbucket():

  # Variables
  branch = "master"

  # Print
  print ("Branch:", branch)

  # Test code
  return bitbucket(_branch=branch)

# Generated at 2022-06-26 01:08:30.764774
# Unit test for function bitbucket
def test_bitbucket():
    # Case 0
    try:
        bitbucket()
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-26 01:08:34.810954
# Unit test for function jenkins
def test_jenkins():
    # Calling function jenkins with no arguments
    var_0 = checker(jenkins)()
    assert type(var_0) is bool
    # Calling function jenkins with no arguments
    var_0 = checker(jenkins)()
    assert type(var_0) is bool


# Generated at 2022-06-26 01:08:37.800141
# Unit test for function gitlab
def test_gitlab():
    env = {
        "CI_COMMIT_REF_NAME": "master"
    }

    with mock.patch.dict(os.environ, env):
        var_0 = check()

test_case_0()
test_gitlab()

# Generated at 2022-06-26 01:08:38.671413
# Unit test for function check
def test_check():
    assert callable(check)

# Generated at 2022-06-26 01:08:39.825098
# Unit test for function travis
def test_travis():
    var_0 = travis()
    assert var_0 is True


# Generated at 2022-06-26 01:08:48.608903
# Unit test for function jenkins
def test_jenkins():
    var_0 = os.environ.get("JENKINS_URL")
    var_1 = not os.environ.get("CHANGE_ID")
    var_2 = os.environ.get("BRANCH_NAME") or os.environ.get("GIT_BRANCH")
    var_3 = jenkins(var_2)

    assert var_0 is not None, "Failed to assert that var_0 is not None."
    assert var_1 is not None, "Failed to assert that var_1 is not None."
    assert var_2 == "master", "Failed to assert that var_2 == 'master'."
    assert var_3 is True, "Failed to assert that var_3 is True."


# Generated at 2022-06-26 01:08:55.978157
# Unit test for function bitbucket
def test_bitbucket():
    # No value for bitbucket:
    try:
        os.environ.pop('BITBUCKET_BRANCH')
        os.environ.pop('BITBUCKET_PR_ID')
        check()
        assert False
    except CiVerificationError as e:
        assert 'Check for bitbucket environment failed.' in str(e)

    # Pull request found:
    os.environ.pop('BITBUCKET_BRANCH')
    os.environ.pop('BITBUCKET_PR_ID')
    os.environ['BITBUCKET_PR_ID'] = '1'
    try:
        check()
        assert False
    except CiVerificationError as e:
        assert 'Check for bitbucket environment failed.' in str(e)

    # Branch is different:
    os.environ

# Generated at 2022-06-26 01:08:57.284796
# Unit test for function gitlab
def test_gitlab():
    var_0 = 'master'
    var_1 = gitlab(branch=var_0)


# Generated at 2022-06-26 01:08:58.655844
# Unit test for function gitlab
def test_gitlab():
    assert gitlab("FOO") == None

test_case_0()

# Generated at 2022-06-26 01:09:01.471318
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("test") == True
    assert jenkins("master") == True
