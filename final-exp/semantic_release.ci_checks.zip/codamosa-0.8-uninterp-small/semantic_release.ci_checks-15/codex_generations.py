

# Generated at 2022-06-26 01:02:27.386056
# Unit test for function travis
def test_travis():
    assert True == True

# Generated at 2022-06-26 01:02:28.521425
# Unit test for function checker
def test_checker():
    assert checker(func_wrapper) == func_wrapper


# Generated at 2022-06-26 01:02:33.081254
# Unit test for function circle
def test_circle():
    # source: https://www.tutorialspoint.com/python/os_environ.htm
    os.environ["CIRCLECI"] = "true"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["CI_PULL_REQUEST"] = None
    try:
        check()
    except:
        assert False
    assert True

# Generated at 2022-06-26 01:02:34.704128
# Unit test for function travis
def test_travis():
    try:
      var_0 = func_wrapper()
    except CiVerificationError:
        return 'error'
    else:
        return 'ok'

# Generated at 2022-06-26 01:02:36.268176
# Unit test for function jenkins
def test_jenkins():
    branch: str = "master"
    assert jenkins(branch) == True


# Generated at 2022-06-26 01:02:37.043762
# Unit test for function check
def test_check():
    var_1 = check()


# Generated at 2022-06-26 01:02:38.756757
# Unit test for function checker
def test_checker():
    @checker
    def func_wrapper():
        pass
    var_0 = func_wrapper()
    assert var_0 == True


# Generated at 2022-06-26 01:02:40.794611
# Unit test for function bitbucket
def test_bitbucket():
    assert False
    if os.environ.get("BITBUCKET_BRANCH") == branch:
        bitbucket(branch)


# Generated at 2022-06-26 01:02:45.816990
# Unit test for function checker
def test_checker():
    def func_wrapper(*args, **kwargs):
        try:
            func(*args, **kwargs)
            return True
        except AssertionError:
            raise CiVerificationError(
                "The verification check for the environment did not pass."
            )

    var_0 = func_wrapper()


# Generated at 2022-06-26 01:02:48.116237
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH']="master"
    os.environ['TRAVIS_PULL_REQUEST']="false"
    branch = "master"
    var_0 = travis(branch)
    assert var_0 == True


# Generated at 2022-06-26 01:02:56.128649
# Unit test for function circle
def test_circle():
    assert checker(circle)("develop") == True


# Generated at 2022-06-26 01:02:57.235962
# Unit test for function checker
def test_checker():
    assert checker(test_case_0)() == True


# Generated at 2022-06-26 01:02:58.168734
# Unit test for function semaphore
def test_semaphore():
    var_0 = semaphore()


# Generated at 2022-06-26 01:02:58.951219
# Unit test for function travis
def test_travis():
    assert travis('master')


# Generated at 2022-06-26 01:03:01.430792
# Unit test for function frigg
def test_frigg():
    os.environ["FRIGG"] = "true"
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    assert frigg(branch="master")


# Generated at 2022-06-26 01:03:03.110364
# Unit test for function bitbucket
def test_bitbucket():
    test_case_0()


if __name__ == "__main__":
    # unit tests for bitbucket
    test_bitbucket()

# Generated at 2022-06-26 01:03:03.842191
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("master")


# Generated at 2022-06-26 01:03:08.400388
# Unit test for function bitbucket
def test_bitbucket():
    ci_version = "0.0.0"
    try:
        bitbucket(branch = ci_version)
    except CiVerificationError as e:
        print(e)


# Generated at 2022-06-26 01:03:09.187303
# Unit test for function check
def test_check():
    assert callable(check)



# Generated at 2022-06-26 01:03:10.831364
# Unit test for function jenkins
def test_jenkins():
    os.environ['JENKINS_URL'] = "true"
    var_0 = jenkins("test")
    assert var_0 == True

# Generated at 2022-06-26 01:03:25.115440
# Unit test for function jenkins
def test_jenkins():
    branch = "master"
    var_0 = jenkins(branch)
    assert var_0 == True


# Generated at 2022-06-26 01:03:26.131461
# Unit test for function bitbucket
def test_bitbucket():
    assert not bitbucket(None)



# Generated at 2022-06-26 01:03:28.280571
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket("master") == True

    try:
        bitbucket("not master")
        assert False
    except CiVerificationError:
        pass


# Generated at 2022-06-26 01:03:32.718268
# Unit test for function bitbucket
def test_bitbucket():
    try:
        assert os.environ.get("BITBUCKET_BRANCH") == "master"
        assert not os.environ.get("BITBUCKET_PR_ID")
    except AssertionError:
        raise CiVerificationError("The verification check for the environment did not pass.")
    return True



# Generated at 2022-06-26 01:03:36.000086
# Unit test for function circle
def test_circle():
    try:
        circle("test_branch")
    except CiVerificationError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 01:03:39.021520
# Unit test for function semaphore
def test_semaphore():
    try:
        semaphore("master")
        print("Test case 0 passed")
    except Exception:
        print("Test case 0 failed")


# Generated at 2022-06-26 01:03:44.990845
# Unit test for function gitlab
def test_gitlab():
    # Arbitrary values
    branch = "branch"
    os.environ["CI_COMMIT_REF_NAME"] = branch
    os.environ["CI_MERGE_REQUEST_ID"] = "1"

    try:
        gitlab(branch)
    except CiVerificationError:
        pass
    else:
        raise AssertionError("Should raise a checked environment error")



# Generated at 2022-06-26 01:03:51.535938
# Unit test for function circle
def test_circle():
    os.environ["CIRCLECI"] = "true"
    os.environ["CIRCLE_BRANCH"] = "master"
    os.environ["CI_PULL_REQUEST"] = ""
    var_0 = check()
    


# Generated at 2022-06-26 01:03:53.732801
# Unit test for function semaphore
def test_semaphore():
    if "SEMAPHORE" in os.environ:
        var_1 = check()


# Generated at 2022-06-26 01:03:58.583146
# Unit test for function travis
def test_travis():
    var_0 = os.environ.get("TRAVIS_BRANCH")
    var_1 = os.environ.get("TRAVIS_PULL_REQUEST")
    var_2 = var_0 == "master"
    var_3 = var_1 == "false"
    var_4 = var_2 and var_3
    assert var_4 == True
    
    

# Generated at 2022-06-26 01:04:24.513771
# Unit test for function gitlab
def test_gitlab():
    "Testing function gitlab"

    # Checking whether gitlab's environment variables are assigned correctly
    assert os.environ.get("CI_COMMIT_REF_NAME") == "master"
    assert not os.environ.get("CI_MERGE_REQUEST_IID")  # pull request id

# Generated at 2022-06-26 01:04:25.338142
# Unit test for function jenkins
def test_jenkins():
    assert not jenkins('master')


# Generated at 2022-06-26 01:04:26.188659
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket(None) == True


# Generated at 2022-06-26 01:04:27.549955
# Unit test for function frigg
def test_frigg():
    test_return = frigg('master')
    assert test_return == True



# Generated at 2022-06-26 01:04:30.915362
# Unit test for function semaphore
def test_semaphore():
    branch = 'master'
    def func():
        assert not os.environ.get("PULL_REQUEST_NUMBER")
        assert not os.environ.get("SEMAPHORE_THREAD_RESULT")
    return func

# Generated at 2022-06-26 01:04:32.284952
# Unit test for function travis
def test_travis():
    assert callable(travis)
    assert isinstance(travis(branch='master'), bool)


# Generated at 2022-06-26 01:04:33.531729
# Unit test for function checker
def test_checker():
    # Verify CI
    var_1 = check()



# Generated at 2022-06-26 01:04:35.761637
# Unit test for function frigg
def test_frigg():
    assert os.environ.get("FRIGG_BUILD_BRANCH") is None
    assert not os.environ.get("FRIGG_PULL_REQUEST")


# Generated at 2022-06-26 01:04:44.793535
# Unit test for function jenkins
def test_jenkins():
    # assert check(branch="master") == None, 'Expected none, but received ' + str(check(branch="master"))
    # assert check(branch="master") == None, 'Expected none, but received ' + str(check(branch="master"))
    # assert check(branch="master") == None, 'Expected none, but received ' + str(check(branch="master"))
    # assert check(branch="master") == None, 'Expected none, but received ' + str(check(branch="master"))
    # assert check(branch="master") == None, 'Expected none, but received ' + str(check(branch="master"))
    assert check(branch="master") == None, 'Expected none, but received ' + str(check(branch="master"))

# Generated at 2022-06-26 01:04:45.738946
# Unit test for function travis
def test_travis():
    pass


# Generated at 2022-06-26 01:05:47.700354
# Unit test for function gitlab
def test_gitlab():
    assert gitlab("master") == True

# Generated at 2022-06-26 01:05:48.538436
# Unit test for function circle
def test_circle():
    assert circle("master") is True


# Generated at 2022-06-26 01:05:51.335527
# Unit test for function travis
def test_travis():
    branch_0 = "master"
    try:
        assert os.environ.get("TRAVIS_BRANCH") == branch_0
        assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"
        return True
    except AssertionError:
        raise CiVerificationError("The verification check for the environment did not pass.")


# Generated at 2022-06-26 01:05:57.902497
# Unit test for function semaphore
def test_semaphore():
    # Travis CI should return True
    correct_branch = "master"
    assert semaphore(correct_branch) is True
    # Non-Travis CI environment
    fake_travis = {"TRAVIS_BRANCH": "master", "TRAVIS_PULL_REQUEST": "false"}
    os.environ = fake_travis
    assert semaphore(correct_branch) is False
    # Travis CI environment with wrong branch
    wrong_branch = "wrong_branch"
    assert semaphore(wrong_branch) is False
    # Travis CI environment with pull-request
    with_pull_request = "true"
    fake_travis["TRAVIS_PULL_REQUEST"] = with_pull_request
    assert semaphore(correct_branch) is False

# Generated at 2022-06-26 01:05:58.950588
# Unit test for function gitlab
def test_gitlab():
    gitlab("master")
    return


# Generated at 2022-06-26 01:06:01.002309
# Unit test for function gitlab
def test_gitlab():
    os.environ['CI_COMMIT_REF_NAME'] = "master"
    os.environ['BITBUCKET_PR_ID'] = "23456"
    gitlab("master")


# Generated at 2022-06-26 01:06:02.401220
# Unit test for function gitlab
def test_gitlab():

    # Test case 0
    test_case_0()

    # Test case 1
    var_1 = check()


# Generated at 2022-06-26 01:06:04.006247
# Unit test for function semaphore
def test_semaphore():
    assert callable(semaphore)
    assert isinstance(semaphore(branch = None), bool)


# Generated at 2022-06-26 01:06:04.890036
# Unit test for function semaphore
def test_semaphore():
    var_1 = semaphore(0)


# Generated at 2022-06-26 01:06:05.767283
# Unit test for function jenkins
def test_jenkins():
    var_1 = jenkins()


# Generated at 2022-06-26 01:08:22.270533
# Unit test for function checker
def test_checker():
    import sys
    import io

    # Capture the output
    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput

    @checker
    def dummy():
        assert False

    try:
        dummy()
    except CiVerificationError:
        assert True
    else:
        assert False

    sys.stdout = sys.__stdout__

# Generated at 2022-06-26 01:08:24.005414
# Unit test for function gitlab
def test_gitlab():
    assert gitlab("release-1.2.3")


# Generated at 2022-06-26 01:08:28.237664
# Unit test for function jenkins
def test_jenkins():
    # Assert the checks for jenkins do not pass with default environment
    try:
        jenkins("master")
    except CiVerificationError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 01:08:31.409602
# Unit test for function bitbucket
def test_bitbucket():
    assert callable(bitbucket)
    try:
        bitbucket(branch="")
    except CiVerificationError:
        return True
    raise Exception("Test FAILED: bitbucket()")


# Generated at 2022-06-26 01:08:34.465704
# Unit test for function circle
def test_circle():
    try:
        # Call function to be tested
        circle("master")
    except:
        # Check error is CiVerificationError
        assert isinstance(Exception.args, CiVerificationError)


# Generated at 2022-06-26 01:08:35.353884
# Unit test for function gitlab
def test_gitlab():
    gitlab('master')


# Generated at 2022-06-26 01:08:39.712967
# Unit test for function checker
def test_checker():
    @checker
    def test_function():
        return "foo"

    assert test_function.__name__ == "test_function"

    test_function()
    try:
        @checker
        def test_function_fail():
            raise AssertionError

        test_function_fail()
        assert False
    except CiVerificationError:
        pass



# Generated at 2022-06-26 01:08:44.041930
# Unit test for function gitlab
def test_gitlab():
    with pytest.raises(CiVerificationError):
        os.environ["CI_COMMIT_REF_NAME"] = "not_master"
        gitlab("master")

    os.environ["CI_COMMIT_REF_NAME"] = "master"
    gitlab("master")



# Generated at 2022-06-26 01:08:45.794938
# Unit test for function travis
def test_travis():
    assert travis("master") == True
    assert travis("feature/test") == True


# Generated at 2022-06-26 01:08:49.530804
# Unit test for function frigg
def test_frigg():
    """
    Perform necessary checks to ensure that the frigg build is one
    that should create releases.
    """
    os.environ["FRIGG_BUILD_BRANCH"] = "master"
    os.environ["FRIGG_PULL_REQUEST"] = "false"
    frigg(branch="master")
