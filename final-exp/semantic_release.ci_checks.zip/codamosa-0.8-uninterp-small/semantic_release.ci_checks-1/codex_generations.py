

# Generated at 2022-06-26 01:02:24.868702
# Unit test for function travis
def test_travis():
    var_0 = travis()
    assert var_0 == True



# Generated at 2022-06-26 01:02:25.491172
# Unit test for function circle
def test_circle():
    assert circle(branch) == True

# Generated at 2022-06-26 01:02:26.570549
# Unit test for function gitlab
def test_gitlab():
    assert isinstance(gitlab(), bool)


# Generated at 2022-06-26 01:02:27.284792
# Unit test for function gitlab
def test_gitlab():
    assert True == funct_gitlab(Master)

# Generated at 2022-06-26 01:02:32.576921
# Unit test for function check
def test_check():
    assert check_0 == 'True'
    assert check_1 == 'True'
    assert check_2 == 'True'
    assert check_3 == 'True'
    assert check_4 == 'True'
    assert check_5 == 'True'
    assert check_6 == 'True'
    assert check_7 == 'True'
    assert check_8 == 'True'
    assert check_9 == 'True'



# Generated at 2022-06-26 01:02:33.334410
# Unit test for function bitbucket
def test_bitbucket():
    var_0 = bitbucket()


# Generated at 2022-06-26 01:02:35.066733
# Unit test for function bitbucket
def test_bitbucket():
    try:
        bitbucket()
    except AssertionError:
        assert True
    else:
        assert False



# Generated at 2022-06-26 01:02:35.969229
# Unit test for function check
def test_check():
    assert check() == None
    pass

# Generated at 2022-06-26 01:02:39.503079
# Unit test for function bitbucket
def test_bitbucket():
    try:
        assert os.environ.get("BITBUCKET_BRANCH") == branch
        assert not os.environ.get("BITBUCKET_PR_ID")
    except AssertionError:
        raise CiVerificationError(
            "The verification check for the environment did not pass."
        )


# Generated at 2022-06-26 01:02:40.551028
# Unit test for function bitbucket
def test_bitbucket():
    var_0 = bitbucket()
    assert var_0 == None


# Generated at 2022-06-26 01:02:50.606274
# Unit test for function checker
def test_checker():
    def test_function():
        assert True == True
    ret = checker(test_function)()
    assert ret == True
    def test_function1():
        assert True == False
    with pytest.raises(CiVerificationError) as excinfo:
        checker(test_function1)()
    assert 'The verification check for the environment did not pass.' in str(excinfo.value)


# Generated at 2022-06-26 01:02:52.250205
# Unit test for function semaphore
def test_semaphore():
    # Create a list of inputs
    inputList = [("master")]
    for i in inputList:
        assert semaphore(*i) == True


# Generated at 2022-06-26 01:02:53.231499
# Unit test for function travis
def test_travis():
    assert (travis('master') == True)


# Generated at 2022-06-26 01:02:56.474021
# Unit test for function gitlab
def test_gitlab():
    assert gitlab("master") is True
    assert gitlab("") is True


# Generated at 2022-06-26 01:02:57.732651
# Unit test for function frigg
def test_frigg():
    var_0 = frigg()
    assert var_0 == True


# Generated at 2022-06-26 01:02:58.489351
# Unit test for function frigg
def test_frigg():
    assert checker(frigg)() == True

# Generated at 2022-06-26 01:02:59.853823
# Unit test for function semaphore
def test_semaphore():
    branch = "master"
    assert semaphore(branch) == True


# Generated at 2022-06-26 01:03:05.194976
# Unit test for function frigg
def test_frigg():
    def frigg(branch: str):
        assert os.environ.get("FRIGG_BUILD_BRANCH") == branch
        assert not os.environ.get("FRIGG_PULL_REQUEST")
    try:
        frigg(branch="master")
        assert True
    except:
        assert False


# Generated at 2022-06-26 01:03:06.865343
# Unit test for function check
def test_check():
    var_1 = check()



# Generated at 2022-06-26 01:03:11.637172
# Unit test for function checker
def test_checker():
    import inspect
    # Capture arguments
    args, _, _, values = inspect.getargvalues(inspect.currentframe())
    values.pop("func")

    func_return_value = checker(func_wrapper)(*args, *values)
    assert callable(checker(func_wrapper))
    assert isinstance(checker(func_wrapper), Callable)
    assert inspect.isfunction(checker(func_wrapper))
    assert func_return_value == True


# Generated at 2022-06-26 01:03:22.986472
# Unit test for function semaphore
def test_semaphore():
    pass


# Generated at 2022-06-26 01:03:23.877178
# Unit test for function circle
def test_circle():
    pass


# Generated at 2022-06-26 01:03:33.051897
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "test_branch"
    with pytest.raises(CiVerificationError):
        bitbucket(branch = "test_branch")
    with pytest.raises(CiVerificationError):
        bitbucket(branch = "test_branch")
    os.environ["BITBUCKET_BRANCH"] = ""
    with pytest.raises(CiVerificationError):
        bitbucket(branch = "test_branch")
    os.environ["BITBUCKET_PR_ID"] = "True"
    with pytest.raises(CiVerificationError):
        bitbucket(branch = "test_branch")
    os.environ.pop("BITBUCKET_PR_ID")


# Generated at 2022-06-26 01:03:35.255189
# Unit test for function semaphore
def test_semaphore():
    assert semaphore(branch="master") == True


# Generated at 2022-06-26 01:03:43.901651
# Unit test for function frigg
def test_frigg():
    assert checker(frigg)(branch='master') is True
    assert checker(frigg)(branch='develop') is True
    assert checker(frigg)(branch='1.7.x') is True
    assert checker(frigg)(branch='1.6.x') is True
    assert checker(frigg)(branch='2.1.x') is True
    assert checker(frigg)(branch='stable/icehouse') is True
    assert checker(frigg)(branch='stable/juno') is True


# Generated at 2022-06-26 01:03:55.089385
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "develop"
    os.environ["CI_MERGE_REQUEST_ID"] = "43"
    assert gitlab("develop") is False
    os.environ["CI_MERGE_REQUEST_ID"] = None
    assert gitlab("develop") is True
    del os.environ["GITLAB_CI"]
    del os.environ["CI_COMMIT_REF_NAME"]
    del os.environ["CI_MERGE_REQUEST_ID"]


# Generated at 2022-06-26 01:03:59.074656
# Unit test for function jenkins
def test_jenkins():
    branch = "master"

    branch_name = os.environ.get("BRANCH_NAME") or os.environ.get("GIT_BRANCH")
    assert os.environ.get("JENKINS_URL") is not None
    assert branch_name == branch
    assert not os.environ.get("CHANGE_ID")  # pull request id



# Generated at 2022-06-26 01:04:00.306161
# Unit test for function semaphore
def test_semaphore():
    # no assertions yet
    var_2 = semaphore("branch")


# Generated at 2022-06-26 01:04:04.931638
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_COMMIT_TAG"] = ""

    assert gitlab("master") is True



# Generated at 2022-06-26 01:04:06.121779
# Unit test for function semaphore
def test_semaphore():
    var_0 = check(branch="master")


# Generated at 2022-06-26 01:04:26.960760
# Unit test for function gitlab
def test_gitlab():
    os.environ["CI_COMMIT_REF_NAME"] = "test"
    os.environ["GITLAB_CI"] = "true"
    assert check("test")



# Generated at 2022-06-26 01:04:27.556147
# Unit test for function check
def test_check():
    pass

# Generated at 2022-06-26 01:04:29.782887
# Unit test for function jenkins
def test_jenkins():
    var_1 = jenkins("master")
    assert var_1 == True


# Generated at 2022-06-26 01:04:33.087676
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    os.environ["CI_JOB_ID"] = "16"
    branch = "master"
    var_0 = gitlab(branch)


# Generated at 2022-06-26 01:04:34.150064
# Unit test for function frigg
def test_frigg():
    var_0 = frigg("Test string")


# Generated at 2022-06-26 01:04:35.242646
# Unit test for function travis
def test_travis():
    var_1 = travis()
    assert var_1 == True


# Generated at 2022-06-26 01:04:36.587167
# Unit test for function gitlab
def test_gitlab():
    assert gitlab(branch="master")==True


# Generated at 2022-06-26 01:04:37.728796
# Unit test for function bitbucket
def test_bitbucket():
    branch = "master"
    assert bitbucket(branch) == True

# Generated at 2022-06-26 01:04:38.829165
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("master") == True


# Generated at 2022-06-26 01:04:47.940875
# Unit test for function checker
def test_checker():
    expected_result_0 = True
    expected_result_1 = CiVerificationError
    expected_result_1_message = "The verification check for the environment did not pass."

    var_0 = False

    def func_0(): return None

    def func_1(): var_0 = True

    @checker
    def func_2(): return None

    @checker
    def func_3(): var_0 = True

    def func_4():
        raise AssertionError

    def func_5():
        raise AssertionError
        var_0 = True

    @checker
    def func_6():
        raise AssertionError

    @checker
    def func_7():
        raise AssertionError
        var_0 = True

    result_0 = func_0()
    expected_0 = None
   

# Generated at 2022-06-26 01:05:42.922763
# Unit test for function travis
def test_travis():
    assert os.environ.get("TRAVIS_BRANCH") == "master"
    assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"


# Generated at 2022-06-26 01:05:44.333556
# Unit test for function frigg
def test_frigg():
    assert frigg('master') == True


# Generated at 2022-06-26 01:05:46.832971
# Unit test for function semaphore
def test_semaphore():
    branch = "master"
    semaphore(branch)


# Generated at 2022-06-26 01:05:52.125533
# Unit test for function check
def test_check():
    branch_fake = "fake branch"
    # test 1
    os.environ["TRAVIS"] = "true"
    os.environ["TRAVIS_BRANCH"] = branch_fake
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    var_1 = check(branch_fake)
    del os.environ["TRAVIS"]
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]
    assert var_1 == True
    # test 1
    os.environ["SEMAPHORE"] = "true"
    os.environ["BRANCH_NAME"] = branch_fake
    os.environ["PULL_REQUEST_NUMBER"] = None

# Generated at 2022-06-26 01:05:57.959041
# Unit test for function frigg
def test_frigg():
    var_0 = frigg("master")
    assert var_0 == True


# Generated at 2022-06-26 01:06:04.891278
# Unit test for function check
def test_check():
    import pytest
    import sys
    import os


    @pytest.mark.parametrize(
        "environ, branch, check_func",
        [
            ({"TRAVIS": "true"}, "master", travis),
            ({"SEMAPHORE": "true"}, "master", semaphore),
            ({"FRIGG": "true"}, "master", frigg),
            ({"CIRCLECI": "true"}, "master", circle),
            ({"GITLAB_CI": "true"}, "master", gitlab),
            (
                {"JENKINS_URL": "https://www.github.com"},
                "master",
                jenkins,
            ),
        ],
    )
    def test_case_1(environ, branch, check_func):
        os.environ = environ

# Generated at 2022-06-26 01:06:06.351879
# Unit test for function gitlab
def test_gitlab():
    try:
        return check(branch = "master")
    except AssertionError:
        pass

# Generated at 2022-06-26 01:06:08.482998
# Unit test for function gitlab
def test_gitlab():
    assert os.environ.get("GITLAB_CI") is None
    try:
        gitlab("master")
    except CiVerificationError:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-26 01:06:09.115917
# Unit test for function check
def test_check():
    assert check() is True

# Generated at 2022-06-26 01:06:15.667203
# Unit test for function travis
def test_travis():
    # Build Params
    branch = 'master'

    TEMP_VERIFICATION_ERROR = CiVerificationError
    def f():
        raise TEMP_VERIFICATION_ERROR("The verification check for the environment did not pass.")

    # Call the function
    try:
        travis(branch)
    except:
        pass
    else:
        raise Exception("Expected to see an error")

    # Call the function again, now with an error
    try:
        travis(branch)
    except TEMP_VERIFICATION_ERROR as e:
        pass
    else:
        raise Exception("Expected to see an error")


# Generated at 2022-06-26 01:08:13.377469
# Unit test for function travis
def test_travis():
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    var_0 = travis(branch='master')
    assert var_0 == True


# Generated at 2022-06-26 01:08:14.544047
# Unit test for function semaphore
def test_semaphore():
    semaphore("master")


# Generated at 2022-06-26 01:08:15.620496
# Unit test for function gitlab
def test_gitlab():
    # test gitlab
    assert gitlab('master')


# Generated at 2022-06-26 01:08:17.043133
# Unit test for function travis
def test_travis():
    var_0 = travis('master')
    print('{}'.format(var_0))


# Generated at 2022-06-26 01:08:19.010322
# Unit test for function bitbucket
def test_bitbucket():
    branch = "master"
    var_0 = checker(bitbucket)
    var_0(branch)


# Generated at 2022-06-26 01:08:21.001631
# Unit test for function check
def test_check():
    var_0 = check()
    try:
        check()
    except:
        pass

# Generated at 2022-06-26 01:08:22.039129
# Unit test for function semaphore
def test_semaphore():
    var_0 = semaphore("branch")

# Generated at 2022-06-26 01:08:23.909724
# Unit test for function jenkins
def test_jenkins():
    assert jenkins('test') == True


# Generated at 2022-06-26 01:08:25.167298
# Unit test for function gitlab
def test_gitlab():
    branch = "master"
    os.environ["CI_COMMIT_REF_NAME"] = branch
    gitlab(branch)


# Generated at 2022-06-26 01:08:32.452690
# Unit test for function checker
def test_checker():
    @checker
    def test_function_1():
        raise AssertionError
    try:
        test_function_1()
    except CiVerificationError as e:
        assert True
    except Exception:
        assert False

    try:
        @checker
        def test_function_2():
            pass
        test_function_2()
    except Exception:
        assert False
    assert True

