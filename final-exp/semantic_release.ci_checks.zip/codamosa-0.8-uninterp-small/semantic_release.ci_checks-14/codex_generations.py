

# Generated at 2022-06-26 01:02:32.396183
# Unit test for function semaphore
def test_semaphore():
    if os.environ.get("SEMAPHORE") == "true":
        assert os.environ.get("SEMAPHORE_THREAD_RESULT") != "failed"
        assert os.environ.get("BRANCH_NAME") == branch
        if os.environ.get("PULL_REQUEST_NUMBER") is not None:
            raise AssertionError
        else:
            return "true"
    else:
        return "false"


# Generated at 2022-06-26 01:02:34.349879
# Unit test for function checker
def test_checker():
    # Arrange
    def func():
        raise AssertionError
    # Act
    new_func = checker(func)
    # Assert
    # new_func()

# Generated at 2022-06-26 01:02:38.145360
# Unit test for function checker
def test_checker():
    # Case 0
    try:
        var_0 = checker(lambda: 0)()
        print("Successful")
    except:
        print("Failed")
    # Case 1
    try:
        var_1 = checker(lambda: 1 / 0)()
        print("Failed")
    except:
        print("Successful")


# Generated at 2022-06-26 01:02:46.847240
# Unit test for function checker
def test_checker():
    assert checker(func_0)
    assert checker(func_1)
    assert checker(func_2)
    assert checker(func_3)
    assert checker(func_4)
    assert checker(func_5)
    assert checker(func_6)
    assert checker(func_7)
    assert checker(func_8)
    assert checker(func_9)
    assert checker(func_10)
    assert checker(func_11)
    assert checker(func_12)
    assert checker(func_13)
    assert checker(func_14)
    assert checker(func_15)
    assert checker(func_16)
    assert checker(func_17)
    assert checker(func_18)
    assert checker(func_19)

# Generated at 2022-06-26 01:02:48.976207
# Unit test for function jenkins
def test_jenkins():
    assert jenkins("master")


# Generated at 2022-06-26 01:02:49.919165
# Unit test for function jenkins
def test_jenkins():
    # Write the test statement here.
    return


# Generated at 2022-06-26 01:02:50.577549
# Unit test for function travis
def test_travis():
    var_0 = travis()


# Generated at 2022-06-26 01:02:54.040210
# Unit test for function semaphore
def test_semaphore():
    # These can be set to the values expected for your test
    os.environ['BRANCH_NAME'] = 'test_branch'
    os.environ['PULL_REQUEST_NUMBER'] = ''
    os.environ['SEMAPHORE_THREAD_RESULT'] = 'passed'
    semaphore('test_branch')
    assert True


# Generated at 2022-06-26 01:02:56.757078
# Unit test for function semaphore
def test_semaphore():
    try:
        semaphore()
        assert False
    except CiVerificationError:
        assert True



# Generated at 2022-06-26 01:03:06.372925
# Unit test for function jenkins
def test_jenkins():
    try:
        assert os.environ.get("JENKINS_URL") is not None
        assert os.environ.get("BRANCH_NAME") == 'master'
        assert not os.environ.get("CHANGE_ID")
        print('Successful')
    except AssertionError:
        raise CiVerificationError('The verification check for the environment did not pass.')
    finally:
        try:
            assert os.environ.get("JENKINS_URL") is not None
            assert os.environ.get("BRANCH_NAME") == 'master'
            assert not os.environ.get("CHANGE_ID")  # Pull request id
            print('Successful')
        except CiVerificationError:
            print('The verification check for the environment did not pass.')


# Generated at 2022-06-26 01:03:15.780278
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    var_1 = travis("master")

# Generated at 2022-06-26 01:03:19.930668
# Unit test for function jenkins
def test_jenkins():
    try:
        assert checker(jenkins)() is True
        assert False
    except CiVerificationError:
        assert True


# Generated at 2022-06-26 01:03:20.954589
# Unit test for function check
def test_check():
    assert check()

# Test function for function check

# Generated at 2022-06-26 01:03:21.800930
# Unit test for function frigg
def test_frigg():
    var_0 = frigg("")


# Generated at 2022-06-26 01:03:24.859022
# Unit test for function jenkins
def test_jenkins():
    try:
        jenkins('master')
    except CiVerificationError as e:
        assert str(e) == 'The verification check for the environment did not pass.'
    else:
        assert False, 'test_jenkins did not throw an error'


# Generated at 2022-06-26 01:03:26.344838
# Unit test for function circle
def test_circle():
    var_0 = circle("master")
    assert var_0 == True


# Generated at 2022-06-26 01:03:34.505349
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"]="true"
    assert os.environ.get("GITLAB_CI") == "true"
    os.environ["CI_COMMIT_REF_NAME"]="ci_commit_ref_name"
    assert os.environ.get("CI_COMMIT_REF_NAME") == "ci_commit_ref_name"
    os.environ["CI_MERGE_REQUEST_IID"]="ci_merge_request_iid"
    assert os.environ.get("CI_MERGE_REQUEST_IID") == "ci_merge_request_iid"
    os.environ["GITLAB_CI"]="true"
    assert os.environ.get("GITLAB_CI") == "true"

# Generated at 2022-06-26 01:03:35.586863
# Unit test for function jenkins
def test_jenkins():
    var_0 = check()



# Generated at 2022-06-26 01:03:37.709582
# Unit test for function jenkins
def test_jenkins():
    branch = "master"
    jenkins(branch)


# Generated at 2022-06-26 01:03:39.642403
# Unit test for function checker
def test_checker():
    def wrapped0():
        check()
    wrapped0()
    def wrapped1():
        raise AssertionError('Assertion Error')
    wrapped1()

# Generated at 2022-06-26 01:03:52.109490
# Unit test for function jenkins
def test_jenkins():
    var_0 = jenkins("test_0")

# Generated at 2022-06-26 01:03:54.441573
# Unit test for function semaphore
def test_semaphore():
    assert type(semaphore) == FunctionType
    assert semaphore.__name__ == "semaphore"

# Generated at 2022-06-26 01:03:55.576861
# Unit test for function gitlab
def test_gitlab():
    assert gitlab("master") == True


# Generated at 2022-06-26 01:03:56.575851
# Unit test for function check
def test_check():
    assert check


# Generated at 2022-06-26 01:03:57.358264
# Unit test for function bitbucket
def test_bitbucket():
    var_0 = check()


# Generated at 2022-06-26 01:03:58.468657
# Unit test for function check
def test_check():
    assert check(branch="master") == None


# Generated at 2022-06-26 01:03:59.946203
# Unit test for function checker
def test_checker():
    # Test Cases
    @checker
    def travis():
        assert True

    assert travis()

# Generated at 2022-06-26 01:04:02.821838
# Unit test for function checker
def test_checker():
    check_0 = checker(check)



# Generated at 2022-06-26 01:04:03.699266
# Unit test for function frigg
def test_frigg():
    var_0 = frigg()


# Generated at 2022-06-26 01:04:04.564321
# Unit test for function frigg
def test_frigg():
    var_1 = check()


# Generated at 2022-06-26 01:04:28.974033
# Unit test for function frigg
def test_frigg():
    var_0 = check("master")
    var_1 = frigg("master")


# Generated at 2022-06-26 01:04:30.690088
# Unit test for function bitbucket
def test_bitbucket():
    branch = "master"
    checker = bitbucket(branch)
    assert branch == "master"
    return checker

# Generated at 2022-06-26 01:04:31.463907
# Unit test for function circle
def test_circle():
    assert(circle("master")==True)

# Generated at 2022-06-26 01:04:33.892581
# Unit test for function semaphore
def test_semaphore():
    try:
        semaphore("master")
    except CiVerificationError as e:
        print(str(e))
        assert str(e) == "The verification check for the environment did not pass."

# Generated at 2022-06-26 01:04:34.676777
# Unit test for function frigg
def test_frigg():
    assert frigg("master") == True


# Generated at 2022-06-26 01:04:37.823970
# Unit test for function bitbucket
def test_bitbucket():
    # Should raise a CiVerificationError
    try:
        bitbucket("master")
        assert False

    # Should raise a CiVerificationError
    except CiVerificationError:
        pass

    # Should not raise exception
    assert bitbucket("master") == True


# Generated at 2022-06-26 01:04:40.666819
# Unit test for function checker
def test_checker():
    def myfunc(foo: str) -> bool:
        return bool(foo)
    result = checker(myfunc)("bar")
    assert result is True
    result = checker(myfunc)("")
    assert result is False


# Generated at 2022-06-26 01:04:41.812778
# Unit test for function travis
def test_travis():
    var_1 = travis(branch='master')


# Generated at 2022-06-26 01:04:50.972823
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    os.environ['FRIGG_PULL_REQUEST'] = "false"
    print("FRIGG test")

    var_0 = check()
    try:
        frigg("master")
        var_1 = True
    except:
        var_1 = False
        print("AssertionError expected.")

    assert var_1

    os.environ['FRIGG'] = "true"
    os.environ['FRIGG_BUILD_BRANCH'] = "master"
    os.environ['FRIGG_PULL_REQUEST'] = "1"
    print("FRIGG false test")

    var_0 = check()

# Generated at 2022-06-26 01:04:51.778595
# Unit test for function travis
def test_travis():
    assert travis() == True


# Generated at 2022-06-26 01:05:53.511367
# Unit test for function checker
def test_checker():

    assert checker(test_case_0)



# Generated at 2022-06-26 01:05:56.408266
# Unit test for function circle
def test_circle():
    assert circle("master") == True

# Generated at 2022-06-26 01:05:58.253041
# Unit test for function check
def test_check():
    var_0 = check()
    return var_0

# Generated at 2022-06-26 01:05:59.829111
# Unit test for function travis
def test_travis():
  try:
    assert travis() == True
  except AssertionError as e:
    assert False


# Generated at 2022-06-26 01:06:02.429432
# Unit test for function travis
def test_travis():
    var_1 = os.environ.get("TRAVIS_BRANCH") == "master"
    assert var_1 == True
    var_2 = os.environ.get("TRAVIS_PULL_REQUEST") == "false"
    assert var_2 == True


# Generated at 2022-06-26 01:06:03.279064
# Unit test for function gitlab
def test_gitlab():
    assert checker("master")
    assert not checker("wrong")


# Generated at 2022-06-26 01:06:03.944614
# Unit test for function check
def test_check():
    assert check() is None

# Generated at 2022-06-26 01:06:04.607347
# Unit test for function check
def test_check():
    assert callable(check)

# Generated at 2022-06-26 01:06:06.863043
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    bitbucket('master')
    assert os.environ['BITBUCKET_BRANCH'] == 'master'


# Generated at 2022-06-26 01:06:08.871057
# Unit test for function semaphore
def test_semaphore():
    branch = 'master'
    try:
        semaphore(branch)
        assert False, "Assertion Error not raised"
    except:
        pass



# Generated at 2022-06-26 01:08:18.172614
# Unit test for function travis
def test_travis():
    try:
        travis()
    except Exception as e:
        assert type(e) == CiVerificationError
    else:
        assert False, "Exception not raised"



# Generated at 2022-06-26 01:08:19.018393
# Unit test for function check
def test_check():
    assert callable(check)

# Generated at 2022-06-26 01:08:20.654011
# Unit test for function travis
def test_travis():

    # No assertion

    pass


# Generated at 2022-06-26 01:08:23.437861
# Unit test for function semaphore
def test_semaphore():
    
    try:
        variable = semaphore("[")
    except TypeError:
        variable = None
    
    assert variable == None

# Generated at 2022-06-26 01:08:24.434081
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("master") == False


# Generated at 2022-06-26 01:08:25.055258
# Unit test for function frigg
def test_frigg():
    assert frigg("master") is True

# Generated at 2022-06-26 01:08:29.426684
# Unit test for function gitlab
def test_gitlab():
    var_0 = gitlab('MASTER')
    assert isinstance(var_0, Callable), "Variable is not a function"


# Generated at 2022-06-26 01:08:30.365401
# Unit test for function check
def test_check():
    assert check() == None


# Generated at 2022-06-26 01:08:38.264368
# Unit test for function gitlab
def test_gitlab():
    # tests if the variables are the same
    if os.environ.get("CI_COMMIT_REF_NAME") == "master" and not os.environ.get("BITBUCKET_PR_ID"):
        assert checker(gitlab)()
    else:
        assert checker(gitlab)() != True
    # tests if the variables are different
    if os.environ.get("CI_COMMIT_REF_NAME") == "master" and not os.environ.get("BITBUCKET_PR_ID"):
        assert not checker(gitlab)("test")
    else:
        assert checker(gitlab)("test")


# Generated at 2022-06-26 01:08:43.195079
# Unit test for function jenkins
def test_jenkins():
    os.environ["JENKINS_URL"] = "https://jenkins.example.com"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = "1234"
    assert jenkins(branch="master") == False
    assert jenkins(branch="develop") == False