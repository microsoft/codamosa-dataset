

# Generated at 2022-06-26 01:02:26.781315
# Unit test for function frigg
def test_frigg():
    frigg('master')



# Generated at 2022-06-26 01:02:28.229591
# Unit test for function bitbucket
def test_bitbucket():
    var_1 = bitbucket(branch="master")
    assert var_1 == True

# Generated at 2022-06-26 01:02:29.295756
# Unit test for function frigg
def test_frigg():
    assert frigg()
    assert frigg(branch = 'master')

# Generated at 2022-06-26 01:02:31.744604
# Unit test for function travis
def test_travis():
    branch = "master"
    try:
        travis(branch)
    except CiVerificationError:
        pass


# Generated at 2022-06-26 01:02:32.543563
# Unit test for function semaphore
def test_semaphore():
    assert 1 == 1



# Generated at 2022-06-26 01:02:39.392456
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"

    check(branch="develop")

    # This should cause an issue since we are on 'develop' and not 'master'
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    with pytest.raises(CiVerificationError):
        check(branch="develop")

    # Create a pull request branch and then check
    os.environ["CI_COMMIT_REF_NAME"] = "test"
    os.environ["CI_MERGE_REQUEST_ID"] = "1"
    with pytest.raises(CiVerificationError):
        check(branch="develop")


# Generated at 2022-06-26 01:02:40.200543
# Unit test for function gitlab
def test_gitlab():
    assert gitlab() == True


# Generated at 2022-06-26 01:02:41.722361
# Unit test for function travis
def test_travis():
    try:
        travis()
        assert True
    except AssertionError:
        assert False
    except Exception:
        assert False


# Generated at 2022-06-26 01:02:44.590873
# Unit test for function check
def test_check():
    # No envs var specified
    os.environ["TRAVIS"] = "qwerty"

    assert check('master')

# Generated at 2022-06-26 01:02:47.077217
# Unit test for function gitlab
def test_gitlab():
    branch = "master"
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    expected = gitlab(branch)
    actual = True
    assert expected == actual


# Generated at 2022-06-26 01:02:56.265501
# Unit test for function travis
def test_travis():
    assert travis("master") == True
    assert travis("dev") == True
    assert travis("/HEAD") == True


# Generated at 2022-06-26 01:02:57.571565
# Unit test for function bitbucket
def test_bitbucket():
    bitbucket("branch=BITBUCKET_BRANCH")


# Generated at 2022-06-26 01:02:58.624120
# Unit test for function semaphore
def test_semaphore():
    assert semaphore('master') == True


# Generated at 2022-06-26 01:03:00.221533
# Unit test for function circle
def test_circle():
    #assert global_var_0 == "default"
    #assert global_var_0 != "default"
    assert True


# Generated at 2022-06-26 01:03:06.162643
# Unit test for function gitlab
def test_gitlab():
    # case 1
    var_1 = os.environ.get("CI_COMMIT_REF_NAME") is None
    # case 1 assert
    assert not var_1

    # case 2
    var_2 = os.environ.get("CI_COMMIT_REF_NAME") != "master"
    # case 2 assert
    assert not var_2


# Generated at 2022-06-26 01:03:11.754839
# Unit test for function jenkins
def test_jenkins():

    # Makes sure that os.environ.get("BRANCH_NAME") returns 'master'
    os.environ["BRANCH_NAME"] = 'master'

    # Makes sure that os.environ.get("JENKINS_URL") is not None
    os.environ["JENKINS_URL"] = '12345'

    # Makes sure that os.environ.get("CHANGE_ID") is not true
    os.environ["CHANGE_ID"] = False

    assert jenkins("master") == True



# Generated at 2022-06-26 01:03:21.446568
# Unit test for function frigg
def test_frigg():
    os.environ['FRIGG']="true"
    os.environ['FRIGG_BUILD_BRANCH']="master"
    os.environ['FRIGG_PULL_REQUEST']=""
    assert frigg("master")
    os.environ['FRIGG']="true"
    os.environ['FRIGG_BUILD_BRANCH']="master"
    os.environ['FRIGG_PULL_REQUEST']="true"
    assert frigg("master")==False


# Generated at 2022-06-26 01:03:22.865366
# Unit test for function bitbucket
def test_bitbucket():
    try:
        bitbucket("master")
    except Exception:
        pass


# Generated at 2022-06-26 01:03:23.350254
# Unit test for function frigg
def test_frigg():
    frigg("master")

# Generated at 2022-06-26 01:03:24.164896
# Unit test for function gitlab
def test_gitlab():
    var_0 = check()



# Generated at 2022-06-26 01:03:39.123989
# Unit test for function jenkins
def test_jenkins():
    print('Testing jenkins()')
    check = jenkins(branch)
    assert check == True, "The function jenkins return a False value."


# Generated at 2022-06-26 01:03:40.310567
# Unit test for function gitlab
def test_gitlab():
    assert gitlab("test-branch") == True


# Generated at 2022-06-26 01:03:42.887914
# Unit test for function circle
def test_circle():
    assert circle("master")


# Generated at 2022-06-26 01:03:44.390463
# Unit test for function circle
def test_circle():
    var_0 = circle(branch = 'foo')


# Generated at 2022-06-26 01:03:46.224755
# Unit test for function bitbucket
def test_bitbucket():
    try:
        var_0 = check()
    except Exception as e:
        print(e)
    return

# Generated at 2022-06-26 01:03:55.390636
# Unit test for function circle
def test_circle():
    # default value for branch
    branch = "master"
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-26 01:03:56.460342
# Unit test for function circle
def test_circle():
    var_0 = circle("master")


# Generated at 2022-06-26 01:03:59.753884
# Unit test for function bitbucket
def test_bitbucket():
    try:
        assert os.environ.get("BITBUCKET_BRANCH") == "master"
        assert not os.environ.get("BITBUCKET_PR_ID")
    except AssertionError:
        # pass
        raise CiVerificationError(
            "The verification check for the environment did not pass."
        )


# Generated at 2022-06-26 01:04:02.725356
# Unit test for function semaphore
def test_semaphore():
    assert semaphore("test") == True


# Generated at 2022-06-26 01:04:04.324736
# Unit test for function gitlab
def test_gitlab():
    var_1 = "master"
    var_2 = gitlab(var_1)


# Generated at 2022-06-26 01:04:30.952783
# Unit test for function checker
def test_checker():
    def mock_decorated_func(*args, **kwargs):
        assert (args[0], args[1]) == (1, 2)
        raise AssertionError

    wrapped = checker(mock_decorated_func)
    try:
        wrapped(1, 2)
        assert False, "Should raise an exception"
    except CiVerificationError:
        pass


# Generated at 2022-06-26 01:04:33.725278
# Unit test for function jenkins
def test_jenkins():
    # Setup
    branch = "master"

    # Exercise SUT
    var_0 = jenkins(branch)
    var_1 = frigg(branch)
    var_2 = semaphore(branch)


# Generated at 2022-06-26 01:04:34.533155
# Unit test for function circle
def test_circle():
    var_0 = circle('master')

# Generated at 2022-06-26 01:04:35.300744
# Unit test for function travis
def test_travis():
    assert travis('master') == True


# Generated at 2022-06-26 01:04:39.071773
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"
    os.environ["BITBUCKET_PR_ID"] = "123"
    try:
        var_0 = bitbucket("master")
    except Exception as e:
        assert isinstance(e,CiVerificationError)
    assert False


# Generated at 2022-06-26 01:04:42.752524
# Unit test for function semaphore
def test_semaphore():
    var_0 = semaphore('master')
    assert 'PULL_REQUEST_NUMBER' in os.environ == 'false'
    assert 'BRANCH_NAME' in os.environ == 'master'
    assert 'SEMAPHORE_THREAD_RESULT' in os.environ == 'failed'


# Generated at 2022-06-26 01:04:43.898106
# Unit test for function frigg
def test_frigg():
    assert checker(frigg)



# Generated at 2022-06-26 01:04:44.996757
# Unit test for function gitlab
def test_gitlab():
    assert gitlab() == True


# Generated at 2022-06-26 01:04:45.900818
# Unit test for function gitlab
def test_gitlab():
    assert gitlab("master")



# Generated at 2022-06-26 01:04:46.779659
# Unit test for function circle
def test_circle():
    assert circle("branch") == None



# Generated at 2022-06-26 01:05:48.868310
# Unit test for function check
def test_check():
    assert func(par) == expected_result


# Generated at 2022-06-26 01:05:50.100506
# Unit test for function checker
def test_checker():
    
    # Call function checker with parameters: func
    assert checker() == checker
    
    # No return type defined for checker



# Generated at 2022-06-26 01:05:54.197257
# Unit test for function check
def test_check():
    try:
        var_0 = check()
    except Exception as var_1:
        var_2 = isinstance(var_1, CiVerificationError)
        var_3 = "The verification check for the environment did not pass."
        assert var_2
        assert var_3 in str(var_1)

# Generated at 2022-06-26 01:05:56.466455
# Unit test for function gitlab
def test_gitlab():
    assert gitlab('master') == True


# Generated at 2022-06-26 01:05:59.382874
# Unit test for function jenkins
def test_jenkins():
    try:
        assert jenkins()
    except CiVerificationError:
        pass
    except AssertionError:
        pass

# Generated at 2022-06-26 01:06:00.132504
# Unit test for function frigg
def test_frigg():
    assert frigg('master') == True


# Generated at 2022-06-26 01:06:00.811830
# Unit test for function frigg
def test_frigg():
    assert not frigg('master')

# Generated at 2022-06-26 01:06:02.645757
# Unit test for function bitbucket
def test_bitbucket():
    os.environ["BITBUCKET_BRANCH"] = "master"

    var_1 = check("master")


os.environ["BITBUCKET_BRANCH"] = ""


# Generated at 2022-06-26 01:06:06.205515
# Unit test for function jenkins
def test_jenkins():

    os.environ["JENKINS_URL"] = "http://200.20.20.20:8080"
    os.environ["BRANCH_NAME"] = "master"
    os.environ["GIT_BRANCH"] = "master"
    os.environ["CHANGE_ID"] = ""
    assert jenkins("master") == True


# Generated at 2022-06-26 01:06:09.295800
# Unit test for function jenkins
def test_jenkins():
    environs = {
        "JENKINS_URL": None,
        "BRANCH_NAME": "master",
        "CHANGE_ID": None
    }
    assert jenkins(environs, "master") == True

if __name__ == "__main__":
    test_jenkins()

# Generated at 2022-06-26 01:08:19.758122
# Unit test for function circle
def test_circle():
    branch = "master"
    circle(branch)


# Generated at 2022-06-26 01:08:23.402191
# Unit test for function travis
def test_travis():
    global branch
    branch = "master"
    func_var_0 = travis(branch)
    assert func_var_0 == True


# Generated at 2022-06-26 01:08:25.030580
# Unit test for function check
def test_check():
    # Test case 0
    try:
        var_0 = check()
    except Exception:
        var_0 = None
    assert var_0 is None



# Generated at 2022-06-26 01:08:31.740679
# Unit test for function gitlab
def test_gitlab():
    try:
        os.environ["GITLAB_CI"] = "true"
        os.environ["CI_COMMIT_REF_NAME"] = "master"
        var_0 = gitlab("master")
    finally:
        del os.environ["GITLAB_CI"]
        del os.environ["CI_COMMIT_REF_NAME"]



# Generated at 2022-06-26 01:08:35.141674
# Unit test for function circle
def test_circle():
    # Default case
    var_0 = checker(circle)
    var_0()
    # Test case 2
    var_1 = checker(circle)
    var_1(branch="test_case_1")


# Generated at 2022-06-26 01:08:37.488491
# Unit test for function jenkins
def test_jenkins():
    try:
        jenkins("master")
        assert False
    except CiVerificationError:
        assert True
    jenkins("branch")


# Generated at 2022-06-26 01:08:38.756975
# Unit test for function gitlab
def test_gitlab():
    var_0 = gitlab('master')


# Generated at 2022-06-26 01:08:43.716788
# Unit test for function checker
def test_checker():
    def func(*args, **kwargs):
        return True

    def func_wrapper(*args, **kwargs):
        return checker(func)(*args, **kwargs)

    assert(func_wrapper() == True)

    # TODO - how to cover the exception case?
    # TODO - figure out how to reset os.environ after each test


# Generated at 2022-06-26 01:08:44.592351
# Unit test for function check
def test_check():
    assert check() == None



# Generated at 2022-06-26 01:08:47.635340
# Unit test for function travis
def test_travis():
    global os
    os.environ = {}
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    check()
