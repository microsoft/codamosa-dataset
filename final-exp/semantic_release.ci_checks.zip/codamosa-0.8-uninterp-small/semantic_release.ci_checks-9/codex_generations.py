

# Generated at 2022-06-26 01:02:20.824842
# Unit test for function travis
def test_travis():
    result = travis()
    assert result == True

checker(test_travis)


# Generated at 2022-06-26 01:02:21.673401
# Unit test for function bitbucket
def test_bitbucket():
    assert callable(bitbucket)


# Generated at 2022-06-26 01:02:23.667327
# Unit test for function semaphore
def test_semaphore():
    var_0 = semaphore(branch)
    if os.environ.get("SEMAPHORE") == "true":
        assert var_0 == True
    else:
        assert var_0 == False


# Generated at 2022-06-26 01:02:28.053680
# Unit test for function jenkins
def test_jenkins():
  try:
    jenkins()
  except Exception as e:
    assert type(e) is ImportError or type(e) is AttributeError or type(e) is ValueError or type(e) is IndexError or type(e) is KeyError or type(e) is NameError or type(e) is TypeError or type(e) is AssertionError or type(e) is ZeroDivisionError or type(e) is OverflowError
  else:
    raise AssertionError('CiVerificationError not raised')


# Generated at 2022-06-26 01:02:31.745192
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    check()
    os.environ["CI_COMMIT_REF_NAME"] = "wrong"
    failCheck()


# Generated at 2022-06-26 01:02:32.292146
# Unit test for function frigg
def test_frigg():
    pass

# Generated at 2022-06-26 01:02:33.080892
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket() == True


# Generated at 2022-06-26 01:02:34.143933
# Unit test for function semaphore
def test_semaphore():
    assert isinstance(semaphore('master'), bool)


# Generated at 2022-06-26 01:02:35.309533
# Unit test for function semaphore
def test_semaphore():
    assert semaphore(1) == True


# Generated at 2022-06-26 01:02:40.655022
# Unit test for function semaphore
def test_semaphore():
    # Testing with the valid input
    try:
        assert semaphore(branch = "master") == True
    except AssertionError:
        raise AssertionError("Expected True, got False")
    # Testing the input which will not pass the condition
    try:
        assert semaphore(branch = "test") == True
    except AssertionError:
        raise AssertionError("Expected True, got False")

if __name__ == "__main__":
    print("Running tests for main.py")
    test_semaphore()

# Generated at 2022-06-26 01:02:49.325839
# Unit test for function gitlab
def test_gitlab():
    branch = "master"
    assert os.environ.get("CI_COMMIT_REF_NAME") == branch
    assert not os.environ.get("CI_PULL_REQUEST")


# Generated at 2022-06-26 01:02:53.467351
# Unit test for function travis
def test_travis():
    # Success case
    os.environ['TRAVIS_BRANCH'] = 'master'
    os.environ['TRAVIS_PULL_REQUEST'] = 'false'
    result = travis('master')
    assert result

    # Failure case
    os.environ['TRAVIS_BRANCH'] = 'develop'
    os.environ['TRAVIS_PULL_REQUEST'] = 'true'
    result = travis('master')
    assert not result


# Generated at 2022-06-26 01:03:03.327145
# Unit test for function checker
def test_checker():

    # Perform check with expected argument
    try:
        var_1 = checker(lambda x: 1)
    except AssertionError:
        var_1 = 0
    assert var_1 == 1
    assert var_1 is not None

    # Perform check with unexpected argument
    try:
        var_2 = checker(lambda x: 0)
    except AssertionError:
        var_2 = 1
    assert var_2 == 0
    assert var_2 is not None

    # Perform check with unexpected argument
    try:
        var_3 = checker(lambda x: 0)
    except Exception as e:
        var_3 = e
    assert isinstance(var_3, CiVerificationError)
    assert var_3 is not None

    # Perform check with unexpected argument

# Generated at 2022-06-26 01:03:04.113733
# Unit test for function travis
def test_travis():
    assert travis("master")



# Generated at 2022-06-26 01:03:06.818456
# Unit test for function check
def test_check():
    check()


# Generated at 2022-06-26 01:03:11.030309
# Unit test for function frigg
def test_frigg():
    """Tests frigg function with an environment variable that has a value."""
    os.environ["FRIGG_BUILD_BRANCH"] = "test_branch"
    os.environ["FRIGG_PULL_REQUEST"] = "true"
    with pytest.raises(CiVerificationError) as e:
        frigg("test_branch")
    assert e is not None


# Generated at 2022-06-26 01:03:14.107356
# Unit test for function frigg
def test_frigg():
    a = frigg("master")
    assert a == True

# Generated at 2022-06-26 01:03:15.529384
# Unit test for function travis
def test_travis():
    try:
        var_0 = travis()
    except AssertionError:
        pass


# Generated at 2022-06-26 01:03:16.291768
# Unit test for function frigg
def test_frigg():
    var_0 = frigg()


# Generated at 2022-06-26 01:03:19.869125
# Unit test for function travis
def test_travis():
    branch = "master"
    var_0 = check()


# Generated at 2022-06-26 01:03:34.724051
# Unit test for function semaphore
def test_semaphore():
    pass


# Generated at 2022-06-26 01:03:44.412390
# Unit test for function frigg
def test_frigg():
    # Tests a successful branch check.
    os.environ['FRIGG_BUILD_BRANCH'] = 'test'
    var_0 = check()
    os.environ['FRIGG_BUILD_BRANCH'] = 'test'
    os.environ['FRIGG_PULL_REQUEST'] = 'test_0'
    # Tests a successful PR check.
    try:
        var_0 = check()
    except CiVerificationError:
        pass
    # Tests for a branch that doesn't match
    try:
        var_0 = check('wrong_branch')
        pass
    except CiVerificationError:
        pass



# Generated at 2022-06-26 01:03:45.789417
# Unit test for function semaphore
def test_semaphore():
   assert semaphore('master') == True


# Generated at 2022-06-26 01:03:58.732921
# Unit test for function jenkins
def test_jenkins():
    # Capture environment
    var_0 = os.environ.copy()
    var_1 = os.environ.copy()
    # Setting the environment
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = "https://jenkins.example.com"
    os.environ["CHANGE_ID"] = ""

    # Calling the function
    var_2 = jenkins("master")

    # Assertions
    assert not var_2

    # Resetting the environment
    os.environ = var_0

    # Setting the environment
    os.environ["BRANCH_NAME"] = "master"
    os.environ["JENKINS_URL"] = ""

    # Calling the function
    with raises(CiVerificationError):
        j

# Generated at 2022-06-26 01:03:59.592607
# Unit test for function semaphore
def test_semaphore():
    pass


# Generated at 2022-06-26 01:04:02.123661
# Unit test for function gitlab
def test_gitlab():
    gitlab("gitlab")

# Generated at 2022-06-26 01:04:03.028815
# Unit test for function circle
def test_circle():
    assert circle("master")


# Generated at 2022-06-26 01:04:07.831940
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")
    del os.environ["TRAVIS_BRANCH"]
    del os.environ["TRAVIS_PULL_REQUEST"]

# Generated at 2022-06-26 01:04:09.115323
# Unit test for function gitlab
def test_gitlab():
    # This function raises no errors, so no testing required.
    pass


# Generated at 2022-06-26 01:04:12.369680
# Unit test for function gitlab
def test_gitlab():
    os.environ["GITLAB_CI"] = "true"
    os.environ["CI_COMMIT_REF_NAME"] = "master"
    var_0 = check(branch = "master")
    assert var_0 == True


# Generated at 2022-06-26 01:04:33.455492
# Unit test for function semaphore
def test_semaphore():
    try:
        semaphore("master")
    except Exception:
        assert False, "AssertionError not raised"



# Generated at 2022-06-26 01:04:34.530374
# Unit test for function frigg
def test_frigg():
    assert checker.frigg(branch="test_branch")


# Generated at 2022-06-26 01:04:35.620616
# Unit test for function circle
def test_circle():
    # Use case
    assert circle(branch = "master") == True



# Generated at 2022-06-26 01:04:37.301402
# Unit test for function gitlab
def test_gitlab():
    var_1 = gitlab("master")
    assert var_1 == True



# Generated at 2022-06-26 01:04:39.968135
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    var_0 = travis("master")
    assert var_0


# Generated at 2022-06-26 01:04:42.364496
# Unit test for function travis
def test_travis():
    os.environ["TRAVIS_BRANCH"] = "master"
    os.environ["TRAVIS_PULL_REQUEST"] = "false"
    travis("master")


# Generated at 2022-06-26 01:04:47.232426
# Unit test for function travis
def test_travis():
    old_env = os.environ.copy()
    os.environ.update({"TRAVIS_BRANCH": "master"})
    os.environ.update({"TRAVIS_PULL_REQUEST": "false"})
    var_0 = check()
    os.environ.clear()
    os.environ.update(old_env)


# Generated at 2022-06-26 01:04:48.691218
# Unit test for function travis
def test_travis():
    try:
        travis()
    except CiVerificationError:
        pass
    return


# Generated at 2022-06-26 01:04:49.870373
# Unit test for function travis
def test_travis():
    var_0 = travis("master")
    assert var_0 == True

# Generated at 2022-06-26 01:04:54.684113
# Unit test for function frigg
def test_frigg():
    try:
        os.environ["FRIGG"] = "true"
        os.environ["FRIGG_BUILD_BRANCH"] = "master"
        os.environ["FRIGG_PULL_REQUEST"] = ""
        frigg("master")
    except CiVerificationError:
        assert False
    finally:
        del os.environ["FRIGG"]
        del os.environ["FRIGG_BUILD_BRANCH"]
        del os.environ["FRIGG_PULL_REQUEST"]


# Generated at 2022-06-26 01:05:51.724096
# Unit test for function bitbucket
def test_bitbucket():
    os.environ['BITBUCKET_BRANCH'] = 'master'
    assert bitbucket('master')
    os.remove('BITBUCKET_BRANCH')
    assert bitbucket('test') == False
    os.environ['BITBUCKET_PR_ID'] = 'test'
    assert bitbucket('test') == False
    os.remove('BITBUCKET_PR_ID') == False


# Generated at 2022-06-26 01:05:55.235851
# Unit test for function jenkins
def test_jenkins():
    # Test: semaphore not set and jenkins set
    os.environ["SEMAPHORE"] = ""
    os.environ["JENKINS_URL"] = "http://foo"

    jenkins("branch")


# Generated at 2022-06-26 01:05:58.609078
# Unit test for function semaphore
def test_semaphore():
    expected_output = True
    actual_output = semaphore("master")
    assert actual_output == expected_output


# Generated at 2022-06-26 01:06:01.228092
# Unit test for function travis
def test_travis():
    """
    This tests the function travis() to ensure that it
    checks the os.environ and the branch is the same
    """
    assert travis(branch="master") == True
    assert travis(branch="feature") == False


# Generated at 2022-06-26 01:06:03.279470
# Unit test for function circle
def test_circle():
    os.environ['CIRCLECI'] = 'true'
    os.environ['BITBUCKET_BRANCH'] = 'dev'

    try:
        circle('dev')
    except CiVerificationError:
        pass



# Generated at 2022-06-26 01:06:04.196612
# Unit test for function travis
def test_travis():
    assert not travis("master")


# Generated at 2022-06-26 01:06:06.610082
# Unit test for function gitlab
def test_gitlab():
    # noinspection PyStringFormat
    os.environ['GITLAB_CI'] = 'True'
    os.environ['CI_COMMIT_REF_NAME'] = 'fix/fix-01'
    assert check()

# Generated at 2022-06-26 01:06:07.399796
# Unit test for function check
def test_check():
    assert callable(check)

# Generated at 2022-06-26 01:06:08.871100
# Unit test for function bitbucket
def test_bitbucket():
    assert bitbucket(branch = (64 * 'a')) == True


# Generated at 2022-06-26 01:06:09.924550
# Unit test for function circle
def test_circle():
    pass


# Generated at 2022-06-26 01:08:09.861275
# Unit test for function travis
def test_travis():
    try:
        os.environ["TRAVIS_BRANCH"] = "master"
        os.environ["TRAVIS_PULL_REQUEST"] = "false"
        checker(travis)()
    except:
        assert False


# Generated at 2022-06-26 01:08:10.628028
# Unit test for function travis
def test_travis():
    var_0 = travis()


# Generated at 2022-06-26 01:08:14.107495
# Unit test for function jenkins
def test_jenkins():
    jenkins('master')


# Generated at 2022-06-26 01:08:16.045081
# Unit test for function checker
def test_checker():
    var_0 = checker(test_case_0)
    var_0()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 01:08:16.867290
# Unit test for function gitlab
def test_gitlab():
    assert gitlab('master') == True


# Generated at 2022-06-26 01:08:18.835212
# Unit test for function jenkins
def test_jenkins():
    bran = "master"
    var_1 = jenkins(bran)
    assert var_1 == True



# Generated at 2022-06-26 01:08:25.112752
# Unit test for function bitbucket
def test_bitbucket():
    bitbucket_0 = bitbucket()
    # State 0
    subst0 = Substitution()
    subst0.method_name = 'bitbucket'
    subst0.params0 = ()
    subst0.type = type(None)
    subst1 = Substitution()
    subst1.method_name = 'bitbucket'
    subst1.params0 = (branch,)
    subst1.type = type(None)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @builtin_attr
    def assert_attr_4(arg0, arg1):
        return arg0 == arg1
    @builtin_attr
    def assert_attr_6(arg0, arg1):
        return arg0 != arg1

    # State

# Generated at 2022-06-26 01:08:30.566106
# Unit test for function travis
def test_travis():
    branch = "master"

    assert os.environ.get("TRAVIS_BRANCH") == branch
    assert os.environ.get("TRAVIS_PULL_REQUEST") == "false"



# Generated at 2022-06-26 01:08:31.410064
# Unit test for function checker
def test_checker():
    pass


# Generated at 2022-06-26 01:08:32.763500
# Unit test for function circle
def test_circle():
	branch = 'master'
	result = circle(branch)
	assert result == True