

# Generated at 2022-06-23 06:03:15.024992
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cst = CollectionSearch()
    print (cst.__dict__)

# Generated at 2022-06-23 06:03:19.259070
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    attr = None
    ds = None
    x = CollectionSearch()

    # testing the ds list is getting populated
    assert x._load_collections(attr, ds) == _ensure_default_collection()

# Generated at 2022-06-23 06:03:22.522252
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    role_definition = RoleDefinition()
    collection_search = CollectionSearch()
    collection_search.__init__(role_definition)
    assert collection_search._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:03:27.955182
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']
    assert cs._load_collections(None, ['test']) == ['test']
    assert cs._load_collections(None, None) == None
    assert cs._load_collections(None, []) == None

# Generated at 2022-06-23 06:03:30.775006
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    if not obj:
        raise Exception('test_CollectionSearch failed')
    print('test_CollectionSearch is passed')


# Generated at 2022-06-23 06:03:31.372922
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().__class__.__name__ == 'CollectionSearch'

# Generated at 2022-06-23 06:03:38.530187
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = []
    obj = CollectionSearch()
    collections = obj._load_collections(0, ds)
    assert collections == None
    assert ds == []

    collections = obj._load_collections(0, ['my.collection'])
    assert collections == ['my.collection']
    assert ds == ['my.collection']

    collections = obj._load_collections(0, ['my.collection'])
    assert collections == ['my.collection', 'ansible.legacy']
    assert ds == ['my.collection', 'ansible.legacy']

    obj = CollectionSearch()
    collections = obj._load_collections(0, {'my.collection'})
    assert collections == ['my.collection', 'ansible.legacy']

# Generated at 2022-06-23 06:03:45.175160
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute import FieldAttribute

    assert isinstance(CollectionSearch._collections, FieldAttribute)
    assert CollectionSearch._collections.isa is 'list'
    assert CollectionSearch._collections.listof is string_types
    assert CollectionSearch._collections.priority is 100
    assert CollectionSearch._collections.default is _ensure_default_collection
    assert CollectionSearch._collections.always_post_validate is True
    assert CollectionSearch._collections.static is True

# Generated at 2022-06-23 06:03:48.170802
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude
    assert(isinstance(TaskInclude()._load_collections, type(RoleDefinition()._load_collections)))

# Generated at 2022-06-23 06:03:50.738367
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collections = _ensure_default_collection(collection_list=None)
    assert collection_search._collections == collections
    # Init template env
    Environment()

# Generated at 2022-06-23 06:04:01.292084
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch('.', [['ansible.builtin', 'ansible.legacy'], ['ansible.builtin', 'collections.test']], None, None, None)

    # This test checks if the initialization of the constructor sets the _collections value
    # to the expected value
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy'], 'Expected value is the first of the collections in collections list.'

    # This test checks if the initialization of the constructor sets the _collections value
    # to the expected default value when no collections are specified
    assert CollectionSearch('.', [], None, None, None)._collections == ['ansible.legacy'], 'Expected value is ansible.legacy'

# Generated at 2022-06-23 06:04:02.891008
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    fields = CollectionSearch.fields
    assert fields['collections'].default == _ensure_default_collection

# Generated at 2022-06-23 06:04:04.307782
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:04:08.499228
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    payload = {}

    # Create an instance of CollectionSearch.
    collection_search = CollectionSearch(None, payload)

    # Check if the __init__ method returns None
    assert not collection_search

# Generated at 2022-06-23 06:04:10.555203
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    c = CollectionSearch()
    ds = dict()
    c._collections = dict()
    c._load_collections(ds, ds)

# Generated at 2022-06-23 06:04:11.933414
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-23 06:04:13.578371
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._load_collections("test_attr", None)

# Generated at 2022-06-23 06:04:14.563377
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test_obj = CollectionSearch()
    pass

# Generated at 2022-06-23 06:04:16.658602
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['ansible_collections.my_namespace.my_collection', 'ansible.builtin']

# Generated at 2022-06-23 06:04:19.361268
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible_collections.ansible.builtin.plugins.module_utils.common.collections_loader import default_collection
    X = CollectionSearch()
    assert X.collections == [default_collection]

# Generated at 2022-06-23 06:04:27.156438
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    input_data = {'collections': ["ansible_collections.namespace1.foo:some_collection"]}
    search = CollectionSearch(input_data)
    search.post_validate(loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(search._collections, list)
    assert list(search._collections)[0] == "ansible_collections.namespace1.foo:some_collection"

# Generated at 2022-06-23 06:04:33.396770
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    assert CollectionSearch()._collections == CollectionSearch._collections
    CollectionSearch._collections = []
    assert CollectionSearch()._collections == CollectionSearch._collections
    assert CollectionSearch()._load_collections('collections', []) is None
    CollectionSearch._collections = ['ansible.builtin']

# Generated at 2022-06-23 06:04:34.800384
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	assert(_ensure_default_collection() == ['ansible.builtin'])

# Generated at 2022-06-23 06:04:44.686288
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

    # testing null value
    search.set_loader({'collections': 'null'})
    assert isinstance(search.collections, list)
    assert len(search.collections) == 1

    # testing empty list value
    search.set_loader({'collections': '[]'})
    assert isinstance(search.collections, list)
    assert len(search.collections) == 1

    # testing list value
    search.set_loader({'collections': '["mycollection"]'})
    assert isinstance(search.collections, list)
    assert len(search.collections) == 2
    assert 'mycollection' in search.collections

    # testing template value
    search.set_loader({'collections': '{{ some_template }}'})

# Generated at 2022-06-23 06:04:46.631988
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display.display = False
    collection = CollectionSearch()
    collection.collections = ['collection_1']


# Generated at 2022-06-23 06:04:48.875333
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Testing constructor of Base
    c1 = CollectionSearch()
    c2 = CollectionSearch()
    assert c1._collections == c2._collections

# Generated at 2022-06-23 06:04:59.455077
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    attr = 'collections'
    ds = ['ansible_collections.my_namespace.my_collection']
    isa_list = 'list'
    listof = string_types
    priority = 100
    default = _ensure_default_collection
    always_post_validate = True
    static = True

    collection_search = CollectionSearch()
    collection_search._collections = FieldAttribute(isa=isa_list, listof=listof, priority=priority, default=default,
                                                    always_post_validate=always_post_validate, static=static)
    result = collection_search._load_collections(attr, ds)
    assert result == ['ansible_collections.my_namespace.my_collection', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:05:02.628111
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.role import Role
    role = Role()
    assert role._collections.value == ['ansible_collections.internal', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:05:04.116140
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:05:04.717196
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:05:08.140948
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Constructor
    c = CollectionSearch()

    assert c._collections.default() == _ensure_default_collection()

    assert c._collections.default() == _ensure_default_collection()

# Generated at 2022-06-23 06:05:11.097917
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    collection._load_collections('collections', None)
    assert collection._collections == ['ansible_collections.ansible.builtin', 'ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-23 06:05:20.706915
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import collections
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import RoleInclude
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.template import is_template, Environment
    import ansible.utils.collection_loader
    import ansible.utils.collection_loader.api
    import ansible.utils.collection_loader.main
    import ansible.utils.collection_loader.plugins

    # Make sure that appropriate modules are imported
    add_all_plugin_dirs()

    with mock.patch('ansible.module_utils.basic.AnsibleModule'):
        play_context = PlayContext()
        task_v

# Generated at 2022-06-23 06:05:24.110491
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search._load_collections('collections', []))

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:05:30.149422
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    # Default collections list before _collections is set
    assert obj.full_collections_list is None
    # Setting collections and verifying with full_collections_list
    obj.collections = [ "my.collections.test1", "my.collections.test2" ]
    assert obj.full_collections_list == [ "my.collections.test1", "my.collections.test2","ansible.builtin" ]

# Generated at 2022-06-23 06:05:32.290792
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection(collection_list=None)

# Generated at 2022-06-23 06:05:34.680437
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = CollectionSearch()
    assert ds
    assert ds._collections is not None
    assert isinstance(ds._collections, list)

# Generated at 2022-06-23 06:05:39.412752
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Arrange
    co = CollectionSearch()
    # Act
    co._collections = ['col1', 'col2']
    co._load_collections('_collections', co._collections)
    # Assert
    assert len(co._load_collections('_collections', co._collections)) == 5

# Generated at 2022-06-23 06:05:40.965479
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testClass = CollectionSearch()
    assert testClass._collections.default_from == _ensure_default_collection

# Generated at 2022-06-23 06:05:42.637028
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch([])
    collectionSearch.post_validate()

# Generated at 2022-06-23 06:05:50.813162
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.__dict__.update({"_collections": ["ansible.builtin"]})
    assert cs.collections == ["ansible.builtin"]

    cs = CollectionSearch()
    cs.__dict__.update({"_collections": None})
    assert cs.collections == ["ansible.builtin"]

    cs = CollectionSearch()
    cs.__dict__.update({"_collections": ["ns1.collection"]})
    assert cs.collections == ["ns1.collection", "ansible.builtin"]


# Generated at 2022-06-23 06:05:53.021909
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert isinstance(instance, CollectionSearch)


# Generated at 2022-06-23 06:05:59.017572
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance._collections is not None
    assert instance._collections._always_post_validate
    assert instance._collections._static
    assert instance._collections._listof is string_types
    assert instance._collections._default == ['ansible.builtin']
    assert instance._collections._priority == 100
    assert instance._collections._isa == 'list'

# Generated at 2022-06-23 06:06:10.028112
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  # Test for condition: collection_list is None
  CollectionSearch._ensure_default_collection(None)

  # Test for condition: collection_list is [],
  # and also test for condition: default_collection is not in collection_list
  CollectionSearch._ensure_default_collection([])

  # Test for condition: collection_list is not None
  CollectionSearch._ensure_default_collection(['ansible.builtin'])

  # Test for condition: collection_list is [],
  # and also test for condition: 'ansible.builtin' is in collection_list
  CollectionSearch._ensure_default_collection(['ansible.builtin'])

  # Test for condition: collection_list is [],
  # and also test for condition: 'ansible.legacy' is in collection_list
  CollectionSearch._ensure_default

# Generated at 2022-06-23 06:06:14.961062
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    x.collections = []
    assert x._collections ==  ('ansible.builtin', 'ansible.legacy')

# Generated at 2022-06-23 06:06:22.207924
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    import os
    import yaml
    yml = os.path.join(os.path.dirname(__file__), "../../molecule/default/molecule.yml")
    print(yml)
    with open(yml, "r") as stream:
        ds = yaml.safe_load(stream)
    print(ds)
    cs._load_collections(None, ds)

# Run test
test_CollectionSearch()

# Generated at 2022-06-23 06:06:28.007295
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.value == _ensure_default_collection()
    assert CollectionSearch._collections.value_is_static
    assert CollectionSearch._collections.always_post_validate
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.isa == 'list'
    assert CollectionSearch._collections.static



# Generated at 2022-06-23 06:06:31.925041
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search = CollectionSearch()
        collection_search._load_collections(1,1)
    except:
        raise AssertionError('CollectionSearch class need to be working')
    else:
        print('CollectionSearch test passed.')

# Generated at 2022-06-23 06:06:37.595709
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class TestClass(CollectionSearch):
        def set_data(self, data):
            self._load_data(data)
    
    testobj = TestClass()
    testobj.set_data({})
    assert testobj.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:06:41.469874
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    print(a.__dict__)
    print(vars(a))
    print(dir(a))
    print(a._collections)
    print(a.collections)
    a.collections = ['aaa', 'bbb']
    print(a.collections)

# Generated at 2022-06-23 06:06:46.794151
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == ['ansible_collections.ansible']
    obj.collections = ['ns1.coll1', 'ns2.coll2']
    assert obj.collections == ['ns1.coll1', 'ns2.coll2', 'ansible_collections.ansible']
    obj.collections = []
    assert obj.collections == ['ansible_collections.ansible']


# Generated at 2022-06-23 06:06:48.262397
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert not cs.collections
    assert cs._collections._static



# Generated at 2022-06-23 06:06:55.621390
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Construct CollectionSearch
    # _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
    #                               always_post_validate=True, static=True)
    assert CollectionSearch._collections.isa == 'list'
    assert CollectionSearch._collections.listof == string_types
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.always_post_validate == True
    assert CollectionSearch._collections.static == True

# Test _ensure_default_collection function

# Generated at 2022-06-23 06:07:00.254746
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection(None)

# Generated at 2022-06-23 06:07:05.407291
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()
    assert cs._collections.listof == string_types
    assert cs._collections.always_post_validate == True
    assert cs._collections.static == True

# Generated at 2022-06-23 06:07:15.903244
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    x = CollectionSearch()

    # test the helper function _ensure_default_collection
    assert _ensure_default_collection() == ["ansible.legacy"]
    assert _ensure_default_collection(["ansible.builtin"]) == ["ansible.builtin","ansible.legacy"]
    assert _ensure_default_collection(["ansible_builtin"]) == ["ansible_builtin","ansible.legacy"]
    assert _ensure_default_collection(["ansible_builtin", "ansible_legacy"]) == ["ansible_builtin","ansible_legacy"]

    # test the function _load_collections
    assert x._load_collections("collections", None) is None

# Generated at 2022-06-23 06:07:19.420494
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible_collections.nsxt.appliance.plugins.module_utils.vmware_nsxt.ansible.builtin', 'ansible_collections.nsxt.appliance.plugins.module_utils.vmware_nsxt.ansible.legacy']

# Generated at 2022-06-23 06:07:20.623876
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._db == None

# Generated at 2022-06-23 06:07:24.936785
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert cs._collections.default == _ensure_default_collection()
    assert cs._collections.data_source == ['tasks']

    # see FieldAttribute.py
    assert cs._collections.isa == 'list'
    assert cs._collections.static == True
    assert cs._collections.listof == string_types

# Generated at 2022-06-23 06:07:36.406349
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test case #1 : when the value of collections is None
    collectionsTest = CollectionSearch()
    assert collectionsTest._load_collections("collections", None) is None

    # Test case #2 : when the value of collections is an empty list (default value of collections is an empty list)
    collectionsTest = CollectionSearch()
    assert collectionsTest._load_collections("collections", []) is None

    # Test case #3 : when the value of collections is a list of strings
    collectionsTest = CollectionSearch()
    assert collectionsTest._load_collections("collections", ["collections1","collections2"]) == ["collections1","collections2"]

    # Test case #4 : when the value of collections is not a list (here we take a set as an example)
    collectionsTest = CollectionSearch()

# Generated at 2022-06-23 06:07:38.014860
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    myClass = CollectionSearch()
    myClass.collections = ['ansible.builtin','ansible.legacy']

# Generated at 2022-06-23 06:07:39.117753
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj

# Generated at 2022-06-23 06:07:40.994169
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections is not None
    assert collection._load_collections(None, None) is not None

# Generated at 2022-06-23 06:07:43.182462
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert s._collections.static_value is not None

# Generated at 2022-06-23 06:07:43.806779
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-23 06:07:53.661243
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # pylint: disable=protected-access
    import sys
    cs = CollectionSearch()
    # test CollectionSearch._collections is a FieldAttribute
    assert cs._collections.__class__.__name__ == 'FieldAttribute'
    # test CollectionSearch._collections isa list
    assert cs._collections.isa == 'list'
    # test CollectionSearch._collections listof string_types
    assert cs._collections.listof is string_types
    # test CollectionSearch._collections priority 100
    assert cs._collections.priority == 100
    # test CollectionSearch._collections default _ensure_default_collection
    assert cs._collections.default() == _ensure_default_collection()
    # test CollectionSearch._collections always_post_validate True
    assert cs._collections.always_post_validate is True


# Generated at 2022-06-23 06:08:02.147290
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_obj = CollectionSearch()

    errors = search_obj.post_validate()
    assert errors == []

    # Static attribute post_validate may not run, but the static attribute is
    # initialized in constructor.
    assert hasattr(search_obj, '_collections')

    # Check default value '_collections'
    assert (search_obj.get_validated_value('collections', search_obj._collections, [], None) == _ensure_default_collection())

    # Check cases where '_collections' is provided when constructor is called
    search_obj = CollectionSearch(collections=['my_collection', 'my_other_collection'])

    errors = search_obj.post_validate()
    assert errors == []

    # Static attribute post_validate may not run, but the static attribute is
    # initialized

# Generated at 2022-06-23 06:08:04.393138
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(collections=['test']) == ['ansible.builtin', 'test']

# Generated at 2022-06-23 06:08:07.547990
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    c = CollectionSearch()

    # This is just a test to access functions of class CollectionSearch
    try:
        c._collections
        c._load_collections(None, None)
    except:
        assert False

# Generated at 2022-06-23 06:08:16.147870
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class MockMixin(CollectionSearch):
        _collections = 'ansible.builtin'

    class Mock(MockMixin):
        def __init__(self, **kwargs):
            super(Mock, self).__init__(**kwargs)

    t = Mock(collections='ansible.builtin')
    t.post_validate(ds=None, validation_cache=None)  # TODO: fix unit test
    assert type(t._collections) is list

# Generated at 2022-06-23 06:08:22.066875
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = AnsibleCollectionConfig.default_collection
    collection_search = CollectionSearch()
    if collection_search._collections == None:
        assert collection_search._collections[0] == ds
    else:
        assert collection_search._collections == None
    test_collection_search = CollectionSearch()
    test_collection_search.define_collection(ds)
    assert ds in test_collection_search._collections

# Generated at 2022-06-23 06:08:24.526111
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections
    assert cs._collections.default
    assert cs._collections.default() == _ensure_default_collection()



# Generated at 2022-06-23 06:08:25.789016
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # A valid base class must have a constructor without arguments
    assert CollectionSearch()

# Generated at 2022-06-23 06:08:29.228199
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("Testing CollectionSearch:")
    # Creating a instance of CollectionSearch
    collection_search = CollectionSearch()

    # Testing the constructor of CollectionSearch
    assert collection_search._collections == _ensure_default_collection()


# Testing _ensure_default_collection()

# Generated at 2022-06-23 06:08:30.562077
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections is None

# Generated at 2022-06-23 06:08:33.182077
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    res = CollectionSearch()

    # Test that we get the right result when no value is specified
    assert res._collections(None, None) is None

    # Test that we get the right result when no value is specified
    assert res._collections(['ansible_collections.db_demo.zabbix'], None) == ['ansible_collections.db_demo.zabbix']

# Generated at 2022-06-23 06:08:40.670292
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    a = HostVars(play_context.connection_info, play_context.variable_manager, play_context.loader, play_context.templar)
    collection_search = CollectionSearch()
    print(collection_search._load_collections('collections', a))

# Generated at 2022-06-23 06:08:42.622877
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs=CollectionSearch()
    cs._collections=['common.yaml']
    assert cs._collections == ['common.yaml']

# Generated at 2022-06-23 06:08:45.085980
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), '../lib'))
    t = CollectionSearch()
    assert t.collections is None

# Generated at 2022-06-23 06:08:48.198422
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch, '_load_collections')
    assert CollectionSearch is CollectionSearch
    assert hasattr(CollectionSearch, '_collections')
    assert hasattr(CollectionSearch, '_collections')

# Generated at 2022-06-23 06:08:49.617260
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections.default is not None

# Generated at 2022-06-23 06:08:58.010826
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Need to test constructor of CollectionSearch class
    # since collection loader is class variable and will be
    # initialized at the time of import of collection loader
    # in module.
    search = CollectionSearch()
    assert search.collections == _ensure_default_collection()

    # Testing constructor with empty collections list
    search = CollectionSearch(collections=[])
    assert search.collections == _ensure_default_collection(collection_list=[])

    # Testing constructor with collections list
    search = CollectionSearch(collections=['collection_1'])
    assert search.collections == _ensure_default_collection(collection_list=['collection_1'])

# Generated at 2022-06-23 06:09:00.364999
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Unit test for constructor of class CollectionSearch"""
    collection_search = CollectionSearch()
    assert collection_search
    assert collection_search._collections == ['ansible_collections.amazon.aws', 'ansible.builtin']



# Generated at 2022-06-23 06:09:02.982508
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:09:04.084854
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = Collecti

# Generated at 2022-06-23 06:09:13.373605
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    # When _collections is empty, it should return ['ansible.builtin', 'ansible.legacy']
    assert c._load_collections('collections', []) == ['ansible.builtin', 'ansible.legacy']
    # When _collections is not empty, it should return ['ansible.builtin', 'ansible.legacy', 'collection_name']
    assert c._load_collections('collections', ['collection_name']) == ['ansible.builtin', 'ansible.legacy', 'collection_name']

# Unit test of _ensure_default_collection

# Generated at 2022-06-23 06:09:13.891949
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()

# Generated at 2022-06-23 06:09:25.567397
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #test CollectionSearch with no collection list specified
    collections = ["test_collection"]
    search = CollectionSearch()
    assert len(search._collections.default(collections)) == 2
    assert 'test_collection' in search._collections.default(collections)
    assert 'ansible.builtin' in search._collections.default(collections) or 'ansible.legacy' in search._collections.default(collections)
    #test CollectionSearch with collection list specified
    collections = ["test_collection", "ansible_test_collection"]
    search = CollectionSearch()
    assert len(search._collections.default(collections)) == 3
    assert 'test_collection' in search._collections.default(collections)
    assert 'ansible_test_collection' in search._collections.default(collections)

# Generated at 2022-06-23 06:09:27.413815
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # construct object of class CollectionSearch
    obj = CollectionSearch()
    # get value of variable _collections
    obj._collections

# Generated at 2022-06-23 06:09:32.071285
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    __builtin__.__dict__['__playbook_task_from_entry_point'] = None
    a._load_collections('collections', None)

# Generated at 2022-06-23 06:09:34.856775
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # TODO: README: Add a unit test to instantiate the class CollectionSearch and make sure an object is created.
    raise NotImplementedError

# Generated at 2022-06-23 06:09:43.905402
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['ansible_collections.ansible.builtin']
    c = CollectionSearch(collections=['foo.bar'])
    assert c.collections == ['foo.bar', 'ansible_collections.ansible.builtin']
    c2 = CollectionSearch()
    assert c2._collections == ['ansible_collections.ansible.builtin']
    c = CollectionSearch(collections=['foo.bar', 'ansible_collections.ansible.builtin'])
    assert c.collections == ['foo.bar', 'ansible_collections.ansible.builtin']

# Generated at 2022-06-23 06:09:47.226686
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    #check if collections is empty
    assert obj._collections == _ensure_default_collection()
    #check if collections is not empty
    assert obj._collections != None

# Generated at 2022-06-23 06:09:51.745825
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    if obj is None:
        print("test_CollectionSearch::Failed")
    else:
        print("test_CollectionSearch::Done")

# Generated at 2022-06-23 06:09:56.340371
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This is a simple test to identify if there is a syntax error or not.
    # This test will not check if the logic of the class is right or not.
    try:
        CollectionSearch()
    except Exception as error:
        assert False, "Cannot construct a CollectionSearch object: %s" % error

# Generated at 2022-06-23 06:09:57.576129
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default(None).default == _ensure_default_collection()

# Generated at 2022-06-23 06:10:01.171673
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class test_ds(CollectionSearch):
        def __init__(self):
            self.collections = ['test_collection']
    t = test_ds()
    assert(t._load_collections(None, t.collections) == ['test_collection', 'ansible.builtin'])

# Generated at 2022-06-23 06:10:07.790278
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test with default collection
    default_collection = AnsibleCollectionConfig.default_collection
    collection_search = CollectionSearch()
    collections = collection_search._load_collections('collections', [])
    assert collections == [default_collection]

    # test with no collection
    collection_search = CollectionSearch()
    collections = collection_search._load_collections('collections', [])
    assert collections == [default_collection]

# Generated at 2022-06-23 06:10:13.532221
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search is not None
    assert len(search._collections) == 1
    assert search._collections[0] == "ansible_collections.ansible.builtin"
    # Ensure that the default collection is not added twice.
    search._collections = search._ensure_default_collection(search._collections)
    assert len(search._collections) == 1
    assert search._collections[0] == "ansible_collections.ansible.builtin"

# Generated at 2022-06-23 06:10:18.694023
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test with empty collections
    c = CollectionSearch()

    assert c.collections == _ensure_default_collection()

    # Test with collections
    collections = ['collection1', 'collection2']
    c = CollectionSearch(collections=collections)

    assert c.collections == collections

# Generated at 2022-06-23 06:10:20.563668
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:21.592574
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()


# Generated at 2022-06-23 06:10:25.966448
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.dataloader import DataLoader
    data_loader = DataLoader()
    CollectionSearch(data_loader=data_loader, collections=['ansible_collections.test.test_invalid_collection'])

# Generated at 2022-06-23 06:10:29.337032
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections('collections', ['somename.somespace']) == ['ansible.builtin', 'somename.somespace']

# Generated at 2022-06-23 06:10:32.005500
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:10:35.092184
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = dict(collections=[])
    cs = CollectionSearch()
    cs._load_collections("collections", ds)

# Generated at 2022-06-23 06:10:36.172917
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    return CollectionSearch()

# Generated at 2022-06-23 06:10:41.428384
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.utils.collection_loader import AnsibleCollectionConfig, is_collection_ref
    testCollectionSearch = CollectionSearch()
    assert not testCollectionSearch._load_collections(None, None)

    testCollectionSearch2 = CollectionSearch()
    testCollectionSearch2.collections = 'ansible.builtin'
    assert testCollectionSearch2._load_collections(None, None) == ['ansible.builtin']

    testCollectionSearch3 = CollectionSearch()
    testCollectionSearch3.collections = 'ansible.builtin,ansible.posix'
    assert testCollectionSearch3._load_collections(None, None) == ['ansible.builtin', 'ansible.posix']

    testCollectionSearch4 = CollectionSearch()
    testCollectionSearch4.collections = 1

# Generated at 2022-06-23 06:10:43.029944
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    _ensure_default_collection()

# Generated at 2022-06-23 06:10:54.146902
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.include.role import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_vars import TaskVars
    from ansible.playbook.block_include import BlockInclude
    from ansible.playbook.include_role import IncludeRole
    from ansible.plugins.task.include_vars import IncludeVars

    # init CollectionSearch
    task = Task()
    task.action = IncludeVars()
   

# Generated at 2022-06-23 06:10:55.732792
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible_collections.test', 'ansible.builtin']


# Generated at 2022-06-23 06:10:57.044174
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _ensure_default_collection()

# Generated at 2022-06-23 06:11:00.035877
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:03.016315
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections.static == True
    assert CollectionSearch()._collections.always_post_validate == True



# Generated at 2022-06-23 06:11:04.491158
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections is not None

# Generated at 2022-06-23 06:11:09.927523
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Initialize an instance of CollectionSearch
    cs = CollectionSearch()
    # Value is still None
    assert cs._collections.default_value is None
    # Value is still None
    assert _ensure_default_collection() is None
    # Value is still None
    assert cs._load_collections(attr='collections', ds=[]) is None

# Generated at 2022-06-23 06:11:10.539917
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:11:12.695445
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print("collections of collection_search are", collection_search._collections)


# Generated at 2022-06-23 06:11:14.356491
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    if c is None:
        raise Exception("Expected value, got None")

# Generated at 2022-06-23 06:11:16.494336
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.legacy']



# Generated at 2022-06-23 06:11:26.114039
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == ['ansible.legacy']
    assert _ensure_default_collection(None) == ['ansible.legacy']
    assert _ensure_default_collection([]) == ['ansible.legacy']
    assert _ensure_default_collection(['ansible.builtin']) == ['ansible.builtin']
    assert _ensure_default_collection(['ansible.builtin', 'collections.ansible']) == ['ansible.builtin', 'collections.ansible']
    assert _ensure_default_collection(['ansible.legacy', 'collections.ansible']) == ['ansible.legacy', 'collections.ansible']

# Generated at 2022-06-23 06:11:31.299437
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = {}
    test_obj = CollectionSearch(ds)
    assert test_obj._collections == []
    ds = {'collections': ['col1', 'col2']}
    test_obj = CollectionSearch(ds)
    assert test_obj._collections == ['col1','col2']
    ds = {}
    test_obj = CollectionSearch(ds)
    assert test_obj._collections == ['col1','col2']

# Generated at 2022-06-23 06:11:33.589294
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._load_collections('_collections', []) == None

# Generated at 2022-06-23 06:11:40.510688
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    def_coll = c._ensure_default_collection("")
    assert def_coll is not None
    assert def_coll == [AnsibleCollectionConfig.default_collection]
    c = CollectionSearch()
    def_coll = c._ensure_default_collection("")
    assert def_coll is not None
    assert def_coll == [AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-23 06:11:42.818314
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test_obj_one will contain the test for constructor of class CollectionSearch
    test_obj_one = CollectionSearch()
    result = test_obj_one._load_collections(FieldAttribute, [''])
    assert result == None

# Generated at 2022-06-23 06:11:48.613578
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def test_field_attribute_name(self=None, field_attribute=None):
        return field_attribute
    def test_field_attribute_value(self=None, field_attribute=None):
        return field_attribute
    CollectionSearch.field_attribute_name = test_field_attribute_name
    CollectionSearch.field_attribute_value = test_field_attribute_value
    collection_search = CollectionSearch(None)
    assert collection_search._collections.name == '_collections'
    assert collection_search._collections.value == '_collections'


# Generated at 2022-06-23 06:11:51.962437
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print('Name of the class is:', cs.__class__.__name__)
    print('Value returned from class attribute', cs.collections)

test_CollectionSearch()


# Importing this class will cause the display to not output to the host
# but instead print the output. This is due to the import display from 
# ansible.utils.display.

# Generated at 2022-06-23 06:11:54.996776
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:12:02.084714
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert isinstance(collection_search._collections, FieldAttribute)
    assert collection_search._collections._default is _ensure_default_collection
    assert collection_search._collections.always_post_validate is True
    assert collection_search._collections.static is True
    assert collection_search._collections.isa is 'list'
    assert collection_search._collections.listof is string_types
    assert collection_search._collections.priority is 100

# Generated at 2022-06-23 06:12:05.194263
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_name = 'test_collection_name'
    test_module = CollectionSearch()
    assert test_module._collections is not None
    assert test_module._collections.default is not None
    assert test_module._collections.default() == [test_name]
    assert test_module._collections.default(collection_list=['foo']) == ['foo', test_name]



# Generated at 2022-06-23 06:12:08.542416
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create a test object of class CollectionSearch
    test_collection_search = CollectionSearch()
    assert test_collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:12:09.748762
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-23 06:12:11.019054
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c, 'failed to create a CollectionSearch object'

# Generated at 2022-06-23 06:12:14.200551
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.collections = []
    # will return the default collection
    assert 'ansible.builtin' in search.collections

# Generated at 2022-06-23 06:12:15.862683
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:12:19.162524
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections == 'ansible.builtin'
    assert test_obj._collections == 'ansible.builtin'
    assert test_obj._collections == 'ansible.builtin'

# Generated at 2022-06-23 06:12:25.325827
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = CollectionSearch(collections=['F5Networks.f5_modules']).get_validated_value('collections', _ensure_default_collection, _ensure_default_collection(['F5Networks.f5_modules']), None)
    if ds:
        return ds
    
test_CollectionSearch()

# Generated at 2022-06-23 06:12:33.889741
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    test_dict = dict(
        name='test',
        hosts='localhost',
        collections=['test_collection'],
        remote_user='root',
        gather_facts='no',
        roles=[]
    )
    play_context = PlayContext(**test_dict)
    play = None
    t = TaskInclude.load(dict(name='test'), play=play, play_context=play_context, loader=None, variable_manager=None, use_handlers=False)
    assert(t.get_value('name') == 'test')

# Generated at 2022-06-23 06:12:44.294889
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook import Playbook
    loader = DataLoader()
    play_context = PlayContext()
    play_context._ansible_delegated_vars = {}
    play_source = {
        'name': 'test',
        'hosts': 'localhost',
        'collections': 'ansible.builtin',
        'tasks': [
            {
                'name': 'first',
                'action': 'debug',
                'args': {
                    'msg': 'Hello World'
                }
            }
        ]
    }

# Generated at 2022-06-23 06:12:56.102223
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    data_source = ('{% for i in range(10) %}\n'
                   '- ansible.collections.test'
                   '{% if i != 9 %}\n{% endif %}\n'
                   '{% endfor %}')
    data_source = '\n'.join([line.strip() for line in data_source.splitlines()])

    collect = CollectionSearch()
    collect.post_validate('collections', data_source, None)

    assert 'ansible.collections.test' in collect.collections

    collect.post_validate('collections', None, None)
    collect.post_validate('collections', [], None)
    collect.post_validate('collections', [''], None)

    assert 'ansible.builtin' in collect.collections

# Generated at 2022-06-23 06:13:00.663054
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    attr = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)

    assert(attr._get_default() == ['ansible.builtin'])

# Generated at 2022-06-23 06:13:06.746951
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()
    assert cs._collections == _ensure_default_collection()

    assert cs._collections.post_validate(None, [], None) == _ensure_default_collection()
    assert cs._collections.post_validate(None, ['collection1','collection2','collection3'], None) == ['collection1','collection2','collection3']

# Generated at 2022-06-23 06:13:15.817971
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections._static
    assert CollectionSearch._collections._static
    assert CollectionSearch().get_validated_value('collections', CollectionSearch()._collections, 'ansible.builtin', None)
    assert CollectionSearch().get_validated_value('collections', CollectionSearch()._collections, 'ansible.builtin', None) == ['ansible.builtin']
    assert CollectionSearch().get_validated_value('collections', CollectionSearch()._collections, 'ansible.legacy', None) == ['ansible.legacy']
    assert CollectionSearch().get_validated_value('collections', CollectionSearch()._collections, 'ansible.netcommon', None) == ['ansible.netcommon']