

# Generated at 2022-06-23 06:03:12.675534
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    print(c)
    assert c.get_validated_value('collections', c._collections, [], None) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:03:26.086196
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test 1
    # Given a CollectionSearch() object, upon instantiation
    # Then there should be a string attribute '_collections'
    # Likewise, there should be three methods: '__init__', '_load_collections', and '__class_getitem__'
    collection_search_obj = CollectionSearch()
    assert hasattr(collection_search_obj, '_collections')
    assert isinstance(collection_search_obj._collections, string_types)
    assert hasattr(collection_search_obj, '_load_collections')
    assert callable(collection_search_obj._load_collections)
    assert hasattr(collection_search_obj, '__class_getitem__')
    assert callable(collection_search_obj.__class_getitem__)
    # Test 2
    # Given a CollectionSearch()

# Generated at 2022-06-23 06:03:33.048961
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()
    assert c._load_collections('collections', []) == None
    assert c._load_collections('collections', ['test_collection']) == ['test_collection', 'ansible.legacy']
    assert c._load_collections('collections', ['test_collection_1', 'test_collection_2']) == ['test_collection_1', 'test_collection_2', 'ansible.legacy']

# Generated at 2022-06-23 06:03:37.395249
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()
    # Col_search._collections is None when calling ensure_default_collection
    assert col_search._collections == None
    col_search_collections = col_search._load_collections(col_search, None)
    assert col_search_collections == ['ansible.builtin','ansible.legacy'] # default collection is ansible

# Generated at 2022-06-23 06:03:47.771562
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create CollectionSearch object
    cs = CollectionSearch()
    # Test default value of _collections is correct
    assert(cs._collections == _ensure_default_collection())
    # Test that the default value of _collections is correct
    # after the setters are called with various values
    cs.set_collections(['ansible.posix_local'])
    assert(cs._collections == ['ansible.posix_local'])
    cs.set_collections(None)
    assert(cs._collections == ['ansible.posix_local'])
    cs.set_collections([])
    assert(cs._collections == ['ansible.posix_local'])
    cs.set_collections(['ansible.posix_local', 'ansible.builtin'])

# Generated at 2022-06-23 06:03:48.636831
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()
    pass

# Generated at 2022-06-23 06:03:51.329656
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Initialize an object for CollectionSearch class
    collection_search_obj = CollectionSearch()
    assert isinstance(collection_search_obj, CollectionSearch)
    assert collection_search_obj._collections is not None

# Generated at 2022-06-23 06:03:54.529961
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    data = dict()
    result = CollectionSearch()._load_collections('collections', data)
    assert result == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:03:56.091180
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    print(search)



# Generated at 2022-06-23 06:03:57.559394
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections._static

# Generated at 2022-06-23 06:04:05.400980
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # See if the variable collections is defined
    assert 'collections' in CollectionSearch.__dict__
    # See if the variable is a type of FieldAttribute
    assert isinstance(CollectionSearch.__dict__['collections'], FieldAttribute)
    assert CollectionSearch.__dict__['collections'].static
    # See if the variable is a type of string
    assert CollectionSearch.__dict__['collections'].listof == string_types
    # See if the variable has a default value
    assert CollectionSearch.__dict__['collections'].default == _ensure_default_collection

# Generated at 2022-06-23 06:04:15.934778
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == 'ansible.builtin,ansible.legacy'
    c.collections = None
    c = CollectionSearch()
    assert c._collections == 'ansible.builtin,ansible.legacy'
    c.collections = []
    assert c._collections == 'ansible.builtin,ansible.legacy'
    c.collections = ['ansible.builtin']
    assert c._collections == 'ansible.builtin,ansible.legacy'
    c.collections = ['ansible.builtin', 'ansible.legacy']
    assert c._collections == 'ansible.builtin,ansible.legacy'
    c.collections = ['ansible.builtin', 'ansible.legacy', 'collection']
    assert c._col

# Generated at 2022-06-23 06:04:18.635684
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert 'ansible.builtin' in CollectionSearch._collections.default
    assert 'ansible.legacy' in CollectionSearch._collections.default

# Generated at 2022-06-23 06:04:20.808274
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
        obj = CollectionSearch()
        assert obj is not None

# Generated at 2022-06-23 06:04:23.204618
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    _ensure_default_collection(collection_list=[])

# Generated at 2022-06-23 06:04:26.045380
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test(CollectionSearch):
        pass
    obj = Test()
    # test that collections field is not none
    assert(obj._collections)

# Generated at 2022-06-23 06:04:31.400413
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    sortedListOfCollections = sorted(collection_search._collections)
    assert sortedListOfCollections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:04:33.380529
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default_value(None) == (
        _ensure_default_collection(None))

# Generated at 2022-06-23 06:04:43.472374
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from collections import namedtuple
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import IncludeTask
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    collectionSearch = CollectionSearch()
    collectionSearch.set_loader(dataloader)
    collectionSearch.validate_attributes()

    # Tests of _load_collections()
    collectionSearch.set_loader(dataloader)
    datastructure = namedtuple('datastructure', ['collections'])
    datat = datastructure(collections='ansible.builtin')
    collectionSearch._load_collections(None, datat)
    assert datat.collections is not None

    # Tests of get_collection_name()

# Generated at 2022-06-23 06:04:46.267574
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_obj = CollectionSearch()
    if collection_search_obj._collections is None:
        collection_search_obj._collections = _ensure_default_collection()
    # print('CollectionSearch Object: ', collection_search_obj)



# Generated at 2022-06-23 06:04:48.019667
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    #check class attribute
    assert collection._collections
    #check default value of _collections
    assert collection._collections.default()

# Generated at 2022-06-23 06:04:49.265687
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections._collections is not None

# Generated at 2022-06-23 06:04:52.315595
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert isinstance(x, CollectionSearch)

# Generated at 2022-06-23 06:04:54.520783
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testcollection = CollectionSearch()
    assert testcollection._collections == _ensure_default_collection()


# Generated at 2022-06-23 06:04:59.432945
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection([])
    assert CollectionSearch(collections=[])._collections == _ensure_default_collection([])
    assert CollectionSearch(collections=['test.test'])._collections == _ensure_default_collection(['test.test'])

# Generated at 2022-06-23 06:05:10.193501
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext

    cs = CollectionSearch()
    assert cs._collections.default is not None

    # initialize a base

# Generated at 2022-06-23 06:05:13.298255
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.__construct__()
    assert collection_search._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:05:21.988105
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    test_dict = dict()
    test_dict['collection'] = 'test_collection'
    test_list = cs._load_collections(attr=None, ds=test_dict)
    assert test_list == ['test_collection', 'ansible.builtin', 'ansible.legacy']

    test_dict_empty = dict()
    test_list_empty = cs._load_collections(attr=None, ds=test_dict_empty)
    assert test_list_empty == ['ansible.builtin', 'ansible.legacy']

    test_dict_empty_str = dict()
    test_dict_empty_str['collection'] = ''
    test_list_empty_str = cs._load_collections(attr=None, ds=test_dict_empty_str)
   

# Generated at 2022-06-23 06:05:23.658925
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch(), '_collections')

# Generated at 2022-06-23 06:05:26.916013
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    value = collection_search._collections
    assert value._default == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-23 06:05:30.407773
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._collections = ['ansible.builtin', 'my.collection']
    cs.post_validate(validate_value=True, perform_default_validation=True)
    assert cs.collections == ['my.collection', 'ansible.builtin']

# Generated at 2022-06-23 06:05:32.098900
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:05:36.661840
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch

    cs = AnsibleCollectionConfig.default_collection
    assert cs in collectionSearch._load_collections(None, ["test", "test2"])
    assert cs not in collectionSearch._load_collections(None, ["test", "test2"], False)

# Generated at 2022-06-23 06:05:40.580638
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ['collection1', 'collection2']

    # Verify constructor.
    assert cs._collections == ['collection1', 'collection2']
    assert cs._load_collections(None, ['collection1', 'collection2']) == ['collection1', 'collection2']

# Generated at 2022-06-23 06:05:47.825809
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    class _Role(Role):
        _collections = None

    assert _Role(None, None).collections == []

    class _Role(Role):
        _collections = ['foo']

    assert _Role(None, None).collections == ['foo']

    class _Role(RoleInclude):
        _collections = None

    assert _Role(None, None).collections == ['ansible.builtin']

# Generated at 2022-06-23 06:05:48.973152
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert [AnsibleCollectionConfig.default_collection] == obj._collections.default

# Generated at 2022-06-23 06:05:51.413911
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    assert collectionsearch.collections == ['ansible_collections.apscontrol.apscontrol_plugins']

# Generated at 2022-06-23 06:05:58.468741
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # construct new collectionsearch
    cs = CollectionSearch()
    # assert the default value
    assert cs._collections(None, None) == None
    # assign 'task' to collectionsearch
    cs.set_data({'collections': 'task'})
    # assert the new value
    assert cs._collections(None, {'collections': 'task'}) == ['ansible_collections.task', 'ansible_collections.ansible.builtin', 'ansible_collections.ansible.legacy']

# Generated at 2022-06-23 06:06:01.551233
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._collections.default == _ensure_default_collection
    assert cs._collections.name == '_collections'

# Generated at 2022-06-23 06:06:04.082512
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    t._load_collections('collections',['ansible.legacy'])
    assert t.collections == ['ansible.legacy']

# Generated at 2022-06-23 06:06:10.898767
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert (collectionSearch._load_collections(None, ['ansible.builtin']) == ['ansible.builtin'])
    assert (collectionSearch._load_collections(None, None) == ['ansible.builtin'])
    assert (collectionSearch._load_collections(None, []) == ['ansible.builtin'])
    assert (collectionSearch._load_collections(None, ['ansible.collection']) == ['ansible.collection'])

# Generated at 2022-06-23 06:06:14.307534
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections._static is True, 'Attribute "_static" of _collections is not a True'
    assert collection_search._collections._default() == ['ansible.builtin'], '_default() returns unexpected value'



# Generated at 2022-06-23 06:06:22.135600
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj.collections = []  # Adding empty list
    obj._load_collections('collections', obj.collections)
    obj.post_validate()

    obj = CollectionSearch()
    obj._load_collections('collections', obj.collections)
    obj.post_validate()

    obj = CollectionSearch()
    obj.collections = ['abc.abc']  # Adding collection list
    obj._load_collections('collections', obj.collections)
    obj.post_validate()

# Generated at 2022-06-23 06:06:24.285408
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._load_collections == a._load_collections, "Problem with the constructor"

# Generated at 2022-06-23 06:06:32.891938
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_search = CollectionSearch()

    # _ensure_default_collection() covers below tests
    assert test_search._ensure_default_collection()
    assert test_search._ensure_default_collection(['ansible.collections.test'])
    assert test_search._ensure_default_collection(['ansible.builtin', 'ansible.collections.test'])
    assert test_search._ensure_default_collection(['ansible.builtin', 'ansible.collections.test', 'ansible.legacy'])
    assert test_search._ensure_default_collection(['ansible.collections.test', 'ansible.builtin'])
    assert test_search._ensure_default_collection(['ansible.collections.test', 'ansible.builtin', 'ansible.legacy'])


# Generated at 2022-06-23 06:06:44.651303
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearch:
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)

        def _load_collections(self, attr, ds):
            # We are always a mixin with Base, so we can validate this untemplated
            # field early on to guarantee we are dealing with a list.
            ds = self.get_validated_value('collections', self._collections, ds, None)

            # this will only be called if someone specified a value; call the shared value
            _ensure_default_collection(collection_list=ds)

            if not ds:  # don't return an empty collection list, just return None
                return None

            # This duplicates static

# Generated at 2022-06-23 06:06:47.835069
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert not is_template(s._collections.default(), Environment())
    assert s._collections.default() == ['ansible_galaxy.collection']
    assert s._collections.default() == _ensure_default_collection([])

# Generated at 2022-06-23 06:06:48.276669
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-23 06:06:51.434873
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    print(col._collections)
    print(col._load_collections("collections", "Ansible/ansible"))


# Generated at 2022-06-23 06:06:58.335698
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
        collection = CollectionSearch()

        from ansible.errors import AnsibleError
        from ansible.module_utils._text import to_text
        from ansible.module_utils.six import ensure_str, ensure_text

        with pytest.raises(AnsibleError):
            collection._load_collections("collections", ["collections", "collections1"])

# Generated at 2022-06-23 06:06:59.088073
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ''' Test constructor for CollectionSearch '''
    assert CollectionSearch()

# Generated at 2022-06-23 06:07:00.588884
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:01.833285
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def_ = CollectionSearch()
    assert def_._collections is not None

# Generated at 2022-06-23 06:07:05.554031
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    searcher = CollectionSearch()
    assert(searcher._collections == ['ansible.builtin', 'ansible.legacy'])

# Generated at 2022-06-23 06:07:07.054826
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert s._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:11.587743
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

    cs = CollectionSearch(collections=['ansible.builtin'])
    assert cs._collections == ['ansible.builtin']

    cs = CollectionSearch(collections=['ansible.builtin', 'ansible.legacy'])
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:07:12.926589
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:15.015740
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cls = CollectionSearch()
    # attribute collections, default: ansible_collections.ansible.builtin
    assert cls._collections == [AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-23 06:07:19.572397
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  search = CollectionSearch()
  def fn(x): pass
  search._collections.post_validate = fn
  assert search._collections.post_validate == fn

# Generated at 2022-06-23 06:07:31.281244
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    from collections import namedtuple
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task.include.static_include import StaticTaskInclude
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    # Create a mock for AnsibleCollectionConfig.default_collection
    AnsibleCollectionConfig.default_collection = 'ansible.builtin'
    # Create a mock for Display.warning
    Display.warning = lambda self, value: print(value)

    obj = CollectionSearch()

    # Test case 1: Call classmethod post_validate with collections as None and
    # check that the resulting value of collections is same as default collection.
    obj.collections = None
    obj.post_validate()
    assert obj.collections == ['ansible.builtin']

    #

# Generated at 2022-06-23 06:07:32.433905
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()
    pass

# Generated at 2022-06-23 06:07:34.164448
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    null_object = CollectionSearch()
    assert null_object._collections.value == ['ansible.builtin']

# Generated at 2022-06-23 06:07:35.440535
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None

# Generated at 2022-06-23 06:07:44.242238
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = dict(collections=['ansible.builtin'])
    cs = CollectionSearch(d)
    assert cs.collections == ['ansible.builtin']

    d = dict(collections=['ansible.builtin', 'ansible.legacy'])
    cs = CollectionSearch(d)
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']

    d = dict(collections=['ansible.builtin', 'ansible.legacy', 'test.test'])
    cs = CollectionSearch(d)
    assert cs.collections == ['ansible.builtin', 'ansible.legacy', 'test.test']

    # case of: both 'collections' and 'namespace.collection' specified
    # 'namespace.collection' is appended to 'collections',
    #

# Generated at 2022-06-23 06:07:50.160117
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Will be None when used as the default
    if collection_list is None:
        collection_list = []

    # FIXME: exclude role tasks?
    if default_collection and default_collection not in collection_list:
        collection_list.insert(0, default_collection)

    # if there's something in the list, ensure that builtin or legacy is always there too
    if collection_list and 'ansible.builtin' not in collection_list and 'ansible.legacy' not in collection_list:
        collection_list.append('ansible.legacy')

    return collection_list

# Generated at 2022-06-23 06:07:54.296832
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    '''
    This test is to check the output of constructor of class CollectionSearch
    '''

    print('Test of CollectionSearch')

    n = CollectionSearch()
    print(n)

# Generated at 2022-06-23 06:08:04.398450
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import sys
    import ansible

    test_instance = CollectionSearch()

    # Test that the default collection is always loaded, by default
    assert test_instance._collections == _ensure_default_collection(), "Default collection was not loaded"

    # Test that the default collection is loaded when explicitly using None
    test_instance.collections = None
    assert test_instance._collections == _ensure_default_collection(), "Default collection was not loaded with None"

    # Test that the default collection is loaded when explicitly using []
    test_instance.collections = []
    assert test_instance._collections == _ensure_default_collection(), "Default collection was not loaded with []"

    # Test that the default collection is loaded when explicitly using ['']
    test_instance.collections = ['']
    assert test_instance._collections == _ensure

# Generated at 2022-06-23 06:08:07.610560
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    import unittest.mock as mock

    with mock.patch.dict(os.environ):
        test_class = CollectionSearch()
        assert test_class._collections.default is not None
        assert test_class._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:08:13.371171
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert len(cs._collections) == 0
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-23 06:08:22.690279
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._load_collections('collections', []) is None
    assert test._load_collections('collections', ['my_custom_collection']) == ['my_custom_collection', 'ansible.legacy']
    assert test._load_collections('collections', [None]) is None
    assert test._load_collections('collections', ['']) is None
    assert test._load_collections('collections', ['ansible.legacy']) == ['ansible.legacy']
    assert test._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:08:24.354041
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert isinstance(search, CollectionSearch)
    assert isinstance(search._collections, FieldAttribute)

# Generated at 2022-06-23 06:08:25.585905
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-23 06:08:28.223279
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # testing the constructor of CollectionSearch class
    try:
        test_collection_search = CollectionSearch()
    except Exception as err:
        print(err)
        print("CollectionSearch class cannot be instantiated")

# Generated at 2022-06-23 06:08:33.497539
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.module_utils.six import PY3
    assert PY3

    import sys
    sys.path.append('../')

    class FakeCollectionSearch(CollectionSearch):
        pass

    t = FakeCollectionSearch()
    t._load_collections(None, None)

# Generated at 2022-06-23 06:08:44.750937
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test will fail if "abc" is not at the beginning of the list
    # This is because "redhat.certification" is the value of default_collection
    # and the default collection should always be at the beginning.
    # The test also fail if 'ansible.builtin' or 'ansible.legacy' is not at the end
    # This is because we should always load builtin/legacy last.
    collection_list = CollectionSearch().get_collections()
    assert collection_list[0] == "abc"
    assert collection_list[-2] == "ansible.legacy"

    collection_list = CollectionSearch().get_collections(collection_list=["def", "ghi", "jkl"])
    assert collection_list[0] == "def"

# Generated at 2022-06-23 06:08:47.971114
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = AnsibleCollectionConfig.default_collection
    _ = CollectionSearch(collections=[collection])

# Generated at 2022-06-23 06:08:49.769227
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:08:52.846271
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is None
    c._collections = 'abc'
    assert c._collections == 'abc'


# Generated at 2022-06-23 06:08:58.273474
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create a CollectionSearch object
    cs_obj1 = CollectionSearch()
    assert isinstance(cs_obj1._collections.name, str)
    assert isinstance(cs_obj1._collections.default, list)
    assert isinstance(cs_obj1._collections.always_post_validate, bool)
    assert isinstance(cs_obj1._collections.static, bool)

# Generated at 2022-06-23 06:09:02.597561
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) is None
    assert cs._load_collections(None, 'my_collection') == ['my_collection']

# Generated at 2022-06-23 06:09:13.914992
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    expected_result = [
        'ansible_collections.test_ns.test_coll.plugins.modules.test_module',
        'ansible_collections.test_ns.test_coll.plugins.module_utils.test_utils',
        'ansible_collections.test_ns.test_coll.plugins.lookup.test_lookup',
        'ansible_collections.test_ns.test_coll.plugins.filter.test_filter'
    ]

    test_ds = {'collections': ['test_ns.test_coll']}
    test_collection_search = CollectionSearch()
    collection_search_result = test_collection_search._load_collections(
        'collections', test_ds
    )

    assert collection_search_result == expected_result

# Generated at 2022-06-23 06:09:23.629599
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("\n" + "-" * 30 + 'test_CollectionSearch' + "-" * 30)
    import ansible_collections
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    # Test set_load_collections and get_load_collections.
    print("-" * 60)
    print("Test set_load_collections and get_load_collections.")
    # Get _collections
    play = Play()
    print("Before set _collections, main.py:104: " + play.get_collection_loader()._load_collections({}, None))
    # Set _collections

# Generated at 2022-06-23 06:09:25.202498
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c is not None

# Generated at 2022-06-23 06:09:32.217653
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    ansible_collection = CollectionSearch()

    #Test case for "collections" attribute when no value is passed to it
    #Test case to check the type of object is a list
    assert isinstance(ansible_collection.collections, list)

    #Test case to check the default value of "collections" attribute
    assert ['ansible.legacy'] == ansible_collection.collections

    #Test case for "collections" when value is passed to it
    ansible_collection.collections.append('ansible.netcommon')
    assert ['ansible.netcommon'] == ansible_collection.collections

    #Test case for "collections" when multiple values are passed to it
    ansible_collection.collections.append('ansible.builtin')
    assert ['ansible.netcommon', 'ansible.builtin'] == ansible_

# Generated at 2022-06-23 06:09:36.121877
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    test_block = Block()
    test_block.collections = _ensure_default_collection()
    assert test_block.collections == [None]

# Generated at 2022-06-23 06:09:37.124122
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    loader = CollectionSearch()
    # Should not be empty
    assert loader._collections() is not None

# Generated at 2022-06-23 06:09:40.331204
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   # Negative case
   test = CollectionSearch()
   assert test._collections != None

   # Positive case
   test._collections = _ensure_default_collection()
   assert test._collections != None

# Generated at 2022-06-23 06:09:43.049231
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:45.244831
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == ['ansible.builtin'], 'CollectionSearch._collections initial value should be ["ansible.builtin"]'

# Generated at 2022-06-23 06:09:51.248427
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections(None,None) == _ensure_default_collection()

# Generated at 2022-06-23 06:09:54.797951
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an instance of the class CollectionSearch
    instance = CollectionSearch()

    # Test the constructor of class CollectionSearch
    assert not hasattr(instance, '_collections')

    assert hasattr(instance, '_load_collections')

# Generated at 2022-06-23 06:09:58.904634
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

test_dict = {
    "collections": [
        "ansible.builtin",
        "ansible.legacy"
    ]
}


# Generated at 2022-06-23 06:10:01.790682
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Unit test for constructor of class CollectionSearch"""
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
# ============================= Unit test ends here ================================

# Generated at 2022-06-23 06:10:04.001575
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == ['ansible.posix']

# Generated at 2022-06-23 06:10:09.428608
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)
    assert obj._collections is not None
    assert obj._collections == FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)

# Generated at 2022-06-23 06:10:15.786125
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.module_utils.six import PY2
    if PY2:
        # Python2 doesn't have nonlocal
        import ansible.module_utils.six.moves.builtins as __builtin__
        __builtin__.__dict__['nonlocal'] = __builtin__.__dict__['global']
        ansible.module_utils.six.moves.builtins.__dict__['nonlocal'] = ansible.module_utils.six.moves.builtins.__dict__['global']
    obj = CollectionSearch()
    assert not obj._collections.set_in_task

# Generated at 2022-06-23 06:10:16.995111
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-23 06:10:20.723316
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()
    assert coll._collections.default == _ensure_default_collection()
    assert 'ansible.builtin' in coll._collections.default
    assert 'ansible.legacy' in coll._collections.default

# Generated at 2022-06-23 06:10:23.647299
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    print(c._collections)
    print(c._collections.default)
    print(c.get_validated_value('collections', c._collections, None, None))

# Generated at 2022-06-23 06:10:24.575686
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch() is not None


# Generated at 2022-06-23 06:10:31.377361
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context.CLIARGS = {'collection_list': []}
    assert _ensure_default_collection() == [AnsibleCollectionConfig.default_collection]

    play_context.collections = ['collections.testns.testcoll']
    play_context.CLIARGS = {'collection_list': play_context.collections}
    assert _ensure_default_collection() == ['collections.testns.testcoll',
                                            AnsibleCollectionConfig.default_collection]

    play_context.collections = []

# Generated at 2022-06-23 06:10:33.897181
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._load_collections(None, None) is None


# Generated at 2022-06-23 06:10:36.080698
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.__class__.__name__ == 'CollectionSearch'

# Generated at 2022-06-23 06:10:47.418437
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = "Ansible.builtin"
    co = CollectionSearch()
    co.post_validate(ds, None)
    assert ds == ["Ansible.builtin"], "String should be converted to list"

    ds = []
    co.post_validate(ds, None)
    assert ds == ["Ansible.builtin"], "List should be prepended with Ansible.builtin"

    ds = ["Ansible.builtin", "test"]
    co.post_validate(ds, None)
    assert ds == ["Ansible.builtin", "test"], "List should be prepended with Ansible.builtin"

    ds = [ "test"]
    co.post_validate(ds, None)

# Generated at 2022-06-23 06:10:49.359491
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Here a instance of CollectionSearch is created
    a = CollectionSearch()
    assert isinstance(a, CollectionSearch)

# Generated at 2022-06-23 06:10:51.379208
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:55.470433
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    list_var = ["ansible"]
    instance = CollectionSearch(value={},vars={},collection_list=list_var) # Everything is set to default.
    assert instance.collections == ['ansible']

    instance = CollectionSearch(value={},vars={},collection_list=None) # Everything is set to default.
    assert instance.collections == ['ansible.legacy']

# Generated at 2022-06-23 06:10:57.216893
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    collections.post_validate(cold=True)

# Generated at 2022-06-23 06:11:00.296638
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert _ensure_default_collection() == collection_search._collections

# Generated at 2022-06-23 06:11:11.732542
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.plugins.loader import collections_loader
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import AnsibleCollectionRequirement
    import collections

    collections_loader._clear_collections()

    # Test constructor
    cs = CollectionSearch()
    assert cs._collections._static is True
    assert cs._collections._default == _ensure_default_collection
    assert cs._collections._always_post_validate is True

    # Test the default value of collections
    ds = {u'collections': u'name'}
    assert cs._collections.post_validate(ds, None) == _ensure_default_collection()

    # Test

# Generated at 2022-06-23 06:11:14.573403
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance.collections is None
    assert instance.collections is not []
    assert instance._initial_attribute_values == {}
    assert instance._initial_field_values == {'collections': []}

# Generated at 2022-06-23 06:11:16.456831
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    # Test call _ensure_default_collection on _collections
    test._collections.post_validate(None, None)

# Generated at 2022-06-23 06:11:19.387422
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        obj = CollectionSearch()
        assert obj.collections is not None
    except BaseException as e:
        print(e)

# Generated at 2022-06-23 06:11:21.398728
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    colsear = CollectionSearch()
    assert colsear._load_collections(None, None) is None

# Generated at 2022-06-23 06:11:29.179283
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.to_data()['collections'] == ['ansible.builtin', 'ansible.legacy']

    # This is a validator for AnsibleCollectionConfig.default_collection
    # which is set in AnsibleCollectionConfig.__init__()
    cs._collections = "my.collection"
    assert cs.to_data()['collections'] == ['my.collection', 'ansible.builtin', 'ansible.legacy']
    cs._collections = ['my.collection']
    assert cs.to_data()['collections'] == ['my.collection', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:11:31.816411
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:33.271495
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    print("In Unit test for constructor of class CollectionSearch")

# Generated at 2022-06-23 06:11:40.149089
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection is not None
    # because no collections were specified, it should return the default collection
    assert collection._collections == _ensure_default_collection()

    # if we specify another collection, the default should not be returned
    collection = CollectionSearch(collections=['other_collection'])
    assert collection is not None
    assert collection._collections == ['other_collection', 'ansible.legacy']

# Generated at 2022-06-23 06:11:42.172861
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass
    result = TestCollectionSearch()
    assert result._collections == ['ansible_collections.test.test_collection']

# Generated at 2022-06-23 06:11:51.895864
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert cs.get_validated_value('collections', cs._collections, None, None) == ['ansible_collections.import_tasks.test_ns.test_coll.plugins.modules']
    assert cs.get_validated_value('collections', cs._collections, ['ansible_collections.import_tasks.test_ns.test_coll.plugins.modules'], None) == ['ansible_collections.import_tasks.test_ns.test_coll.plugins.modules']

# Generated at 2022-06-23 06:11:52.588388
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.default() == []

# Generated at 2022-06-23 06:11:55.749180
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    test_data = ['ansible.builtin','ansible.legacy']
    d = c._load_collections(None, test_data)
    assert test_data == d

# Generated at 2022-06-23 06:11:57.457479
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    assert CollectionSearch._collections.default() == _ensure_default_collection()

# Generated at 2022-06-23 06:12:08.187563
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode
    #mock_ds = [u'ansible.builtin', u'ansible.builtin', u'k8s.core']
    mock_ds = [u'ansible.builtin', u'k8s.core']
    mock_ds = [AnsibleUnicode(x) for x in mock_ds]
    collection_search = CollectionSearch()
    #mock_ds = collection_search._load_collections("collections", mock_ds)
    collection_search.post_validate("collections", mock_ds, None)
    print("collection_search.collections: " + str(collection_search.collections))

# Generated at 2022-06-23 06:12:13.138901
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs_obj = CollectionSearch()
    # Test __init__
    assert cs_obj._collections is not None
    assert cs_obj._collections is not []
    assert isinstance(cs_obj._collections, list)
    assert 'ansible.builtin' in cs_obj._collections
    assert 'ansible.legacy' in cs_obj._collections


# Generated at 2022-06-23 06:12:14.199298
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Todo
    assert True

# Generated at 2022-06-23 06:12:16.813334
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testClass = CollectionSearch()
    testClass._collections = _ensure_default_collection()
    testClass.post_validate(_ensure_default_collection())

# Generated at 2022-06-23 06:12:19.068583
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance.collections is not None
    assert instance.collections[0] == 'ansible.builtin'

# Generated at 2022-06-23 06:12:21.971044
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert isinstance(s._collections, FieldAttribute)
    assert isinstance(s._load_collections, collections.Callable)

# Generated at 2022-06-23 06:12:29.757023
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.collections import azure

    ir = IncludeRole()
    ir._collections.post_validate(ir, ir._collections, [])
    test_collections = ir._collections.post_validate(ir, ir._collections, [])
    assert not test_collections

# Generated at 2022-06-23 06:12:33.479632
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # GIVEN
    # WHEN
    search = CollectionSearch()
    # THEN
    assert search._collections.default() == ['ansible_collections.foo.bar.plugins.module_utils.example']

# Generated at 2022-06-23 06:12:34.445512
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-23 06:12:36.123304
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.name == 'collections'

# Generated at 2022-06-23 06:12:37.198700
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections is not None



# Generated at 2022-06-23 06:12:38.659405
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert _ensure_default_collection() == obj._collections

# Generated at 2022-06-23 06:12:40.774737
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection(collection_list=[]) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:12:43.140544
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c_search = CollectionSearch()
    assert c_search._collections == _ensure_default_collection()
    assert c_search._collections == ['ansible_collections.ansible']

# Generated at 2022-06-23 06:12:44.210360
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert isinstance(collectionSearch._collections, tuple)

# Generated at 2022-06-23 06:12:46.910540
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    ansible_collection_str = 'ansible.builtin'
    assert obj.collections == [ansible_collection_str]

# Generated at 2022-06-23 06:12:55.548229
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_list = CollectionSearch._ensure_default_collection(None)
    assert(len(collection_list) == 2)
    assert(collection_list[0] == AnsibleCollectionConfig.default_collection)
    assert(collection_list[1] == 'ansible.legacy')

    collection_list = CollectionSearch._ensure_default_collection(['test_collection'])
    assert(len(collection_list) == 2)
    assert(collection_list[0] == 'test_collection')
    assert(collection_list[1] == 'ansible.legacy')

# Generated at 2022-06-23 06:13:01.000904
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:13:02.992322
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch() 
    assert cs.post_validate() == None

# Generated at 2022-06-23 06:13:07.171964
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    _collections = {'collections': 'test'}

    # Test _load_collections
    ds = cs._load_collections('_collections', _collections)
    assert ds is not None

# Generated at 2022-06-23 06:13:10.020826
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch.__dict__['_collections'] == _ensure_default_collection()

# Generated at 2022-06-23 06:13:13.288691
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    c.collections = ["/etc/ansible/collections"]

    assert c.collections == ["/etc/ansible/collections"]