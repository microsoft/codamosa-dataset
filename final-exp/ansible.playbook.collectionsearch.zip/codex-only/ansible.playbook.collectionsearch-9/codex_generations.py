

# Generated at 2022-06-23 06:03:15.518848
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # tests if the init method of CollectionSearch with params.
    cs = CollectionSearch(collections=['action', 'client', 'core', 'database'])
    assert cs != None

#Unit test for method for _ensure_default_collection

# Generated at 2022-06-23 06:03:18.195876
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	collection_search_instance=CollectionSearch()
	assert isinstance(collection_search_instance,CollectionSearch)


# Generated at 2022-06-23 06:03:20.499244
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = {"collections": [{"foo": "bar"}]}
    c = CollectionSearch()
    c._load_collections("collections", d)

# Generated at 2022-06-23 06:03:22.436568
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj._collections)
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:03:25.137431
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testObj = CollectionSearch()
    assert testObj.collections == _ensure_default_collection()


# Generated at 2022-06-23 06:03:26.943091
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:03:36.917147
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is None
    # Only testing that the field exists and can be referenced
    assert isinstance(cs._collections, FieldAttribute)

    _test_string = "ansible_test_collection"
    cs = CollectionSearch(collections=_test_string)
    assert cs.collections == [_test_string]
    # Only testing that the field exists and can be referenced
    assert isinstance(cs._collections, FieldAttribute)

    _test_list = ["ansible_test_collection_v2", "ansible_test_collection_v3"]
    cs = CollectionSearch(collections=_test_list)
    assert cs.collections == _test_list
    # Only testing that the field exists and can be referenced
    assert isinstance(cs._collections, FieldAttribute)

    _

# Generated at 2022-06-23 06:03:47.281791
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    c = CollectionSearch()
    ds = None

    # _load_collections() is called from self.get_validated_value
    # Skipping that for the unit test
    attr = None

    # No values were passed for the constructor
    result = c._load_collections(attr, ds)
    assert result == [AnsibleCollectionConfig.default_collection]

    # Creating new value for 'ds'
    ds = ['collections']

    # _load_collections() will be called for as self.get_validated_value is
    # called within the function, so we will have to patch that
    def mock_get_validated_value(*args, **kwargs):
        ds = args[1]
        assert ds == ['collections']
        return ds

    # Patching the get_validated

# Generated at 2022-06-23 06:03:53.925684
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Note: It's not possible to test whether the default value is returned.

    # Test with collection list as a list
    collection_search = CollectionSearch()
    actual_value = collection_search._load_collections(None, ['test.collection'])
    assert actual_value == ['test.collection']

    # Test with collection list as a string
    actual_value = collection_search._load_collections(None, 'test.collection')
    assert actual_value == ['test.collection']

    # Test with collection list as None
    actual_value = collection_search._load_collections(None, None)
    assert actual_value is None

# Generated at 2022-06-23 06:04:04.948283
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test(CollectionSearch):
        pass
    assert Test._collections.default == _ensure_default_collection()
    assert Test._load_collections('collections', []) == _ensure_default_collection()
    assert Test._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']
    assert Test._load_collections('collections', ['ansible.legacy']) == ['ansible.legacy']
    assert Test._load_collections('collections', ['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:04:06.675424
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:11.406754
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    if isinstance(collection_search, CollectionSearch):
        print("Test successful")
    else:
        print("Test unsuccessful")

#test_CollectionSearch()

# Generated at 2022-06-23 06:04:20.939090
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test 1: Unset the collections attribute
    cs_obj = CollectionSearch()
    assert cs_obj.collections is None

    # Test 2: Set the collections attribute in the method call
    cs_obj._load_collections(None, ['my_ns.my_coll'])
    assert cs_obj.collections == ['my_ns.my_coll']

    # Test 3: Set the collections attribute in the method call and make
    # the default collections attribute empty
    cs_obj._collections = []
    cs_obj._load_collections(None, ['my_ns.my_coll'])
    assert cs_obj.collections == ['my_ns.my_coll']

    # Test 4: Set the collections attribute in the method call and make
    # the default collections attribute empty and passing
    # empty list in the method call
   

# Generated at 2022-06-23 06:04:27.711892
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert cs._load_collections('_collections', ['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']
    assert cs._load_collections('_collections', []) == None
    assert cs._load_collections('_collections', None) == None

# Generated at 2022-06-23 06:04:29.787169
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:04:32.447761
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj is not None

# Generated at 2022-06-23 06:04:33.721311
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a != None

# Generated at 2022-06-23 06:04:34.701624
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    feed = CollectionSearch()


# Generated at 2022-06-23 06:04:43.547085
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Case1: Constructor - default collection
    # Expected result: default collection ansible.builtin is appended to the collection list
    # assertEqual(x, y) x == y
    assert CollectionSearch._ensure_default_collection([]) == ['ansible.builtin']

    # Case2: Constructor - allowed collection name
    # Expected result: collection name is included in the collection list
    assert CollectionSearch._ensure_default_collection(['test.test']) == ['test.test', 'ansible.builtin']

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:04:45.078736
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:04:48.480886
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test 1: Test that the constructor creates an object as desired
    assert CollectionSearch() is not None

    # Test 2: Test that the object has the desired fields
    assert CollectionSearch()._collections == _ensure_default_collection()


# Generated at 2022-06-23 06:04:50.134642
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a  # Making sure we can make an instance of CollectionSearch

# Generated at 2022-06-23 06:04:54.042223
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    default_collection = AnsibleCollectionConfig.default_collection
    if default_collection is None:
        assert collection._collections == []
    else:
        assert collection._collections == [default_collection]

# Generated at 2022-06-23 06:04:57.682545
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default(_ensure_default_collection) == ['ansible_collections.ansible.builtin', 'ansible.builtin']

# Generated at 2022-06-23 06:04:59.385659
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    print(a.collections)

# Generated at 2022-06-23 06:05:02.531170
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test for constructor of class CollectionSearch
    collection_search = CollectionSearch()

    assert len(collection_search._collections) == 1
    assert collection_search._collections[0] == "ansible.builtin"

# Generated at 2022-06-23 06:05:04.473510
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_collection = CollectionSearch()

    collection = search_collection._collections
    assert (collection is not None)

# Generated at 2022-06-23 06:05:06.164960
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:05:07.731013
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.get_fields() == ['collections']

# Generated at 2022-06-23 06:05:10.358963
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Class(CollectionSearch):
        pass
    instance = Class()

    assert instance._collections._default == ['ansible.builtin']

# Generated at 2022-06-23 06:05:13.099935
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections['default'] == _ensure_default_collection()

# Generated at 2022-06-23 06:05:16.630915
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    obj = CollectionSearch()

    # check for attribute has _collections
    assert hasattr(obj, '_collections')

    # check for attribute has _load_collections
    assert hasattr(obj, '_load_collections')



# Generated at 2022-06-23 06:05:22.358899
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # We need to mock AnsibleCollectionConfig for the test
    class MockAnsibleCollectionConfig:
        default_collection = None
    AnsibleCollectionConfig = MockAnsibleCollectionConfig

    collection_search = CollectionSearch()
    assert collection_search._collections is None
    assert collection_search._collections_list == _ensure_default_collection()

# Generated at 2022-06-23 06:05:32.868082
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.errors import AnsibleError
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    import collections.abc as abc

    # test for constructor without params
    test_collection_search = CollectionSearch()

    assert isinstance(test_collection_search._collections, FieldAttribute)
    assert isinstance(test_collection_search._collections._isa, abc.Iterable)
    assert isinstance(test_collection_search._collections._isa[0], abc.Type)
    assert test_collection_search._collections._isa[0] == str

    assert test_collection_search._collections._listof == str
    assert test_collection_search._collections._static == True
    assert test_collection_search._collections._priority == 100
    assert test

# Generated at 2022-06-23 06:05:34.071635
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj

# Generated at 2022-06-23 06:05:35.703057
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_obj = CollectionSearch()
    search_obj._ensure_default_collection()

# Generated at 2022-06-23 06:05:38.045701
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	collection_search = CollectionSearch()
	assert collection_search._load_collections(None, None) == None

# Generated at 2022-06-23 06:05:41.005620
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Testing class collection_search before fix
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection(), "Collection list is not correctly returned"

# Generated at 2022-06-23 06:05:44.591481
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()
    cs.collections = ['my.collection1', 'my.collection2']
    assert cs._load_collections(None, cs.collections) == cs.collections


# Generated at 2022-06-23 06:05:45.604183
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) is None

# Generated at 2022-06-23 06:05:47.998048
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ["test_collection"]

    assert(cs.collections == ["test_collection"])

# Generated at 2022-06-23 06:05:54.467845
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.plugins.loader import shared_loader
    import os

    testcase = CollectionSearch()
    testcase.post_validate()
    assert('ansible.builtin' in testcase.collections or 'ansible.legacy' in testcase.collections)
    assert('ansible.builtin' in testcase.collections or 'ansible.legacy' in testcase.collections)
    assert('default' in testcase.collections)

    # Test if ansible.builtin in collections if no collection is specified
    testcase = CollectionSearch()
    testcase._collections = None
    testcase.post_validate()
    assert('ansible.builtin' in testcase.collections)
    assert('default' not in testcase.collections)

    # Test if ansible.builtin not in collections
   

# Generated at 2022-06-23 06:05:55.983590
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # @todo This is a testable function.
    pass

# Generated at 2022-06-23 06:06:04.269192
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.module_utils.six import string_types

    cs = CollectionSearch()
    assert cs.get_field_attributes() == {
        'collections': FieldAttribute(isa='list', listof=string_types,
                                      priority=100, default=_ensure_default_collection,
                                      always_post_validate=True, static=True,
                                      name='collections', auto_convert=True)
    }


# The following tests don't really do anything as the class is only a
# collection of static methods.
# FIXME: Rewrite these tests, previously they were only testing the init
# of the _collections object.

# Generated at 2022-06-23 06:06:07.323687
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections is not None
    collection._load_collections(None, None)
    assert collection._collections is None

# Generated at 2022-06-23 06:06:16.047916
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_class = CollectionSearch()
    assert test_class._collections == _ensure_default_collection()
    assert test_class._loader_class is None
    assert test_class.__doc__ is not None and len(test_class.__doc__) > 0
    assert test_class.__init__ is not None
    assert test_class.include_tasks is None
    assert test_class.include_role is None
    assert test_class.include_vars is None
    assert test_class.include_metadata is None
    assert test_class.include_files is None
    assert test_class.include_default_vars is None
    assert test_class.include_dependencies is None
    assert test_class.include_task_files is None
    assert test_class.include_handlers is None
    assert test_

# Generated at 2022-06-23 06:06:18.580588
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch()
    assert d._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:06:22.530932
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(None, None) == _ensure_default_collection()

# Generated at 2022-06-23 06:06:24.380224
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible_collections.nsweb.nti310', 'ansible.builtin']



# Generated at 2022-06-23 06:06:25.682209
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()



# Generated at 2022-06-23 06:06:26.885564
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test constructor of class CollectionSearch
    assert CollectionSearch._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:06:28.651914
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()


# Generated at 2022-06-23 06:06:33.082587
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an empty CollectionSearch object
    cs = CollectionSearch()
    # Check methods
    assert cs._load_collections
    # Check attributes
    assert cs._collections
    assert cs._collections.name == 'collections'
    assert cs._collections.parent is cs

# Generated at 2022-06-23 06:06:38.157610
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    if type(result) != CollectionSearch:
        raise ValueError("Error: Type of result is not class CollectionSearch")


# Generated at 2022-06-23 06:06:39.981673
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:06:43.322259
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display.warning('Under test: display.warning')
    display.deprecated('Under test: display.deprecated')
    # display.deprecated('Under test: display.deprecated but no warning msg for display.warning')
    return

# Generated at 2022-06-23 06:06:44.307715
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_class = CollectionSearch()

# Generated at 2022-06-23 06:06:45.208929
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    myInstance = CollectionSearch()

# Generated at 2022-06-23 06:06:51.906904
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_object = CollectionSearch()
    assert my_object._collections == _ensure_default_collection()
    my_object._collections = ['bar.collections', 'foo.collections']
    assert my_object._collections == ['bar.collections', 'foo.collections']

# Generated at 2022-06-23 06:06:54.445231
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections([], None) is None

# Generated at 2022-06-23 06:07:02.847245
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    assert CollectionSearch().collections is None
    assert CollectionSearch(collections=[]).collections == []
    assert CollectionSearch(collections=None).collections is None

    assert CollectionSearch(collections=['test']).collections == ['test', 'ansible.builtin']
    assert CollectionSearch(collections=['test1', 'test2']).collections == ['test1', 'test2', 'ansible.builtin']

    # When there is no default collection, collections are left as they are
    AnsibleCollectionConfig.default_collection = None
    assert CollectionSearch(collections=['test']).collections == ['test']
    assert CollectionSearch(collections=['test1', 'test2']).collections == ['test1', 'test2']

# Generated at 2022-06-23 06:07:12.671123
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_obj = CollectionSearch()
    search_obj._collections = None
    assert search_obj._collections == _ensure_default_collection()
    search_obj._collections = 'ansible.posix'
    assert search_obj._collections == ['ansible.posix', 'ansible.builtin']
    search_obj._collections = ['ansible.posix']
    assert search_obj._collections == ['ansible.posix', 'ansible.builtin']
    search_obj._collections = ['ansible.posix', 'ansible.windows']
    assert search_obj._collections == ['ansible.posix', 'ansible.windows', 'ansible.builtin']

# Generated at 2022-06-23 06:07:20.932384
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def test_object():
        class AnsibleTest:
            _collections = FieldAttribute(isa='list', listof=string_types, priority=100,
                                          default=_ensure_default_collection, always_post_validate=True, static=True)

            def __init__(self, collections=None):
                memo = {}

                # _collections is a special attribute that is used as the default
                # collection list. It is not a regular attribute. We need to populate
                # the value before we attempt to construct the attributes.
                self.collections = _ensure_default_collection(collections)

                self.ds = {'collections': self.collections}

                self._collections = self._load_collections('collections', self.ds)


# Generated at 2022-06-23 06:07:21.964979
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # FIXME: write tests for this module
    return True

# Generated at 2022-06-23 06:07:25.689576
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    col = obj._load_collections(None, None)

    # FIXME: should we include the default collection instead of None?
    assert col is None


# Generated at 2022-06-23 06:07:27.726689
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()
    assert test_object._collections["default"] == _ensure_default_collection()

# Generated at 2022-06-23 06:07:29.650565
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is not None and isinstance(cs.collections, list)

# Generated at 2022-06-23 06:07:30.452615
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()

# Generated at 2022-06-23 06:07:40.415170
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test the constructor of class
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)
    # We are always a mixin with Base, so we can validate this untemplated
    # field early on to guarantee we are dealing with a list.
    val = obj.get_validated_value('collections', obj._collections, ['ansible.posix'], None)
    assert val is not None
    env = Environment()
    for collection_name in val:
        if is_template(collection_name, env):
            display.warning('"collections" is not templatable, but we found: %s, '
                            'it will not be templated and will be used "as is".' % (collection_name))
    # This duplicates static attr checking logic from post_validate()
    # because if the

# Generated at 2022-06-23 06:07:41.582111
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:44.718324
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == ['ansible_collections.ansible']

# test for adding ansible default collection with user defined collection

# Generated at 2022-06-23 06:07:54.283571
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # validate that a default is set when a list is provided
    # Empty list
    cs = CollectionSearch(collections=[])
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']
    # List with values
    cs = CollectionSearch(collections=[AnsibleCollectionConfig.default_collection])
    assert cs.collections == [AnsibleCollectionConfig.default_collection, 'ansible.legacy']

    # validate that a default is set when an empty string is provided
    cs = CollectionSearch(collections="")
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']
    # validate that a default is set when no value is provided
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:07:57.068069
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    t._load_collections('collections', {'collections': ['ansible.builtin', 'my_namespace.my_collection']})

# Generated at 2022-06-23 06:08:03.091491
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == 'ansible.builtin,ansible.legacy'

    # test the always_post_validate=True
    cs = CollectionSearch(collections=['CollectionA'])
    assert cs._collections == 'CollectionA,ansible.builtin,ansible.legacy'

    cs = CollectionSearch(collections=['CollectionA', 'CollectionB'])
    assert cs._collections == 'CollectionA,CollectionB,ansible.builtin,ansible.legacy'



# Generated at 2022-06-23 06:08:05.351047
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None

# Unit test to check get_validated_value()

# Generated at 2022-06-23 06:08:05.923631
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-23 06:08:11.053713
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestDS(CollectionSearch):
        def __init__(self):
            self._data = {}
            for field_name, field in self._get_attributes().items():
                self._data[field_name] = field.get_default()

    test_ds = TestDS()
    assert test_ds.collections is not None
    assert "ansible.builtin" in test_ds.collections
    assert "ansible.legacy" in test_ds.collections



# Generated at 2022-06-23 06:08:13.018743
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default is _ensure_default_collection

# Generated at 2022-06-23 06:08:23.880785
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # First test
    try:
        _ensure_default_collection(collection_list=None)
    except AttributeError:
        pass
    else:
        raise RuntimeError("Test case #1 failed")

    # Second test
    try:
        _ensure_default_collection(collection_list=[])
    except AttributeError:
        pass
    else:
        raise RuntimeError("Test case #2 failed")

    # Third test
    try:
        _ensure_default_collection(collection_list=['ansible.builtin'])
    except AttributeError:
        pass
    else:
        raise RuntimeError("Test case #3 failed")

    # Fourth test

# Generated at 2022-06-23 06:08:25.101946
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:08:27.064654
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()


# Generated at 2022-06-23 06:08:36.500159
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections.name == 'collections'
    assert collection._collections.isa == 'list'
    assert collection._collections.priority == 100
    assert collection._collections.listof == string_types
    assert isinstance(collection._collections.default, types.FunctionType)
    assert collection._collections.always_post_validate is True
    assert collection._collections.static is True


if __name__ == '__main__':
    pytest.main(['-v', '-s', 'test_collection.py'])

# Generated at 2022-06-23 06:08:37.259448
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c=CollectionSearch()

# Generated at 2022-06-23 06:08:40.050603
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.default is not None
    assert c._collections.default is _ensure_default_collection

# Generated at 2022-06-23 06:08:42.953155
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is not None
    assert obj._load_collections is not None
    assert type(obj._load_collections) is _ensure_default_collection
    assert obj._collections == ['ansible.legacy']

# Generated at 2022-06-23 06:08:48.765332
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestClass(CollectionSearch):
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=None,
                                      always_post_validate=True, static=True)
    test_obj = TestClass()
    test_obj.post_validate({'collections': None}, None)

# Generated at 2022-06-23 06:08:55.595084
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    var_manager = VariableManager()
    test_collection_search = CollectionSearch(loader, var_manager, play=None)
    x = test_collection_search._load_collections(attr="none", ds=None)
    y = test_collection_search.collections
    assert x is None
    assert y is None

# Generated at 2022-06-23 06:08:59.434065
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_class = CollectionSearch()
    assert test_class.collections == ['ansible.builtin', 'ansible.legacy']
    assert test_class._load_collections(attr=None, ds=['community.general', 'ops-ansible.legacy']) == ['community.general', 'ops-ansible.legacy']

# Generated at 2022-06-23 06:09:05.635113
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    key = 'collections'
    ds = None
    assert(obj._load_collections(key, ds) == None)
    ds = []
    assert(obj._load_collections(key, ds) == None)
    ds = ['']
    assert(obj._load_collections(key, ds) == ['ansible.legacy'])


# Generated at 2022-06-23 06:09:06.878465
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is None

# Generated at 2022-06-23 06:09:07.764763
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:09:11.952183
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible_collections.my_ns.my_coll']
    assert cs.collections == _ensure_default_collection(cs.collections)

# Generated at 2022-06-23 06:09:15.183192
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    res = obj._collections.default()
    assert res == ['ansible.builtin']
    assert not CollectionSearch._collections.always_post_validate
    assert CollectionSearch._collections.static

# Generated at 2022-06-23 06:09:22.304907
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case = CollectionSearch()
    # Default collection is there and 'ansible.builtin' or 'ansible.legacy' always is there.
    assert test_case._collections.default == ['ansible.builtin'] or test_case._collections.default == ['ansible.legacy'], "Fails to set default collection"
    assert test_case.collections is None, "Fails to set 'collections' attribute"



# Generated at 2022-06-23 06:09:25.747794
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("test_CollectionSearch()")
    searchObj = CollectionSearch()
    print("searchObj._collections: ", searchObj._collections)

# Unit to test method _load_collections()

# Generated at 2022-06-23 06:09:27.257194
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default() == _ensure_default_collection()

# Generated at 2022-06-23 06:09:28.306436
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.default() is not None

# Generated at 2022-06-23 06:09:37.544344
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import datetime
    from ansible.playbook.attribute import Attribute
    from ansible.playbook.base import Base
    from ansible import release
    assert issubclass(CollectionSearch, Attribute)
    assert issubclass(CollectionSearch, Base)
    assert CollectionSearch.__name__ == 'CollectionSearch'
    assert isinstance(CollectionSearch.__doc__, str)
    assert isinstance(CollectionSearch.__module__, str)
    assert '__init__' in CollectionSearch.__dict__


# Generated at 2022-06-23 06:09:39.084386
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections is None

# Generated at 2022-06-23 06:09:42.235575
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin', 'ansible.collection']

# Generated at 2022-06-23 06:09:44.081807
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None
    assert isinstance(obj, CollectionSearch)


# Generated at 2022-06-23 06:09:45.762018
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    assert _ensure_default_collection(None) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:09:53.330186
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

    cs = CollectionSearch(collections=['ansible_collections.mycollection'])
    assert cs._collections == ['ansible_collections.mycollection', 'ansible.legacy']

# Generated at 2022-06-23 06:09:56.579052
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == [AnsibleCollectionConfig.default_collection or 'ansible.builtin']
    assert cs.collections == [AnsibleCollectionConfig.default_collection or 'ansible.builtin']

# Generated at 2022-06-23 06:10:02.063585
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t._load_collections(None, None) == _ensure_default_collection(collection_list = None)
    assert t._load_collections(None, ['abc']) == _ensure_default_collection(collection_list = ['abc'])
    assert t._load_collections(None, ['abc', 'def']) == _ensure_default_collection(collection_list = ['abc', 'def'])

# Generated at 2022-06-23 06:10:05.419909
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Basic test for constructor of class CollectionSearch
    test_class = CollectionSearch()
    assert test_class._collections._get_value() == _ensure_default_collection()

# Generated at 2022-06-23 06:10:08.224718
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections == None
    assert collectionSearch.static is True
    assert collectionSearch.attribute is True

# Generated at 2022-06-23 06:10:12.666526
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test with collections as a list of strings
    test_instance = CollectionSearch()
    test_instance.collections = ['ansible.builtin']

    assert test_instance.collections == ['ansible.builtin']

    # Test with collections as None
    test_instance = CollectionSearch()
    test_instance.collections = None

    assert test_instance.collections is None

# Generated at 2022-06-23 06:10:14.329403
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()

# Generated at 2022-06-23 06:10:15.637107
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs

# Generated at 2022-06-23 06:10:21.643219
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Initialize CollectionSearch class
    collection = CollectionSearch()

    #Test that collection has _collections property
    assert hasattr(collection, '_collections')

    #Test that collection has _load_collections method
    assert hasattr(collection, '_load_collections')

    #Test that collection has _ensure_default_collection method
    assert hasattr(collection, '_ensure_default_collection')

# Generated at 2022-06-23 06:10:23.556603
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # collection_search = CollectionSearch()
    assert True

# Generated at 2022-06-23 06:10:24.953302
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections != None

# Generated at 2022-06-23 06:10:26.779749
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:35.869285
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection()
    assert CollectionSearch(collections=['path/to/collection'])._collections == \
           _ensure_default_collection(['path/to/collection'])
    assert CollectionSearch(collections=['path/to/collection', 'another/collection'])._collections == \
           _ensure_default_collection(['path/to/collection', 'another/collection'])
    assert CollectionSearch(collections=_ensure_default_collection())._collections == \
           _ensure_default_collection()

# Generated at 2022-06-23 06:10:40.171201
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    play_context = PlayContext()
    play_context._ansible_vars = VariableManager(loader=loader)

    collection_search = CollectionSearch()
    collection_search = collection_search._load_collections('collections', None)

    # Test if result is none
    assert collection_search is None

# Generated at 2022-06-23 06:10:44.733032
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    attr = None
    ds = None
    cs._load_collections(attr, ds)

    cs._collections = ['']
    cs._load_collections(attr, ds)
    cs._collections = [{}]
    cs._load_collections(attr, ds)

# Generated at 2022-06-23 06:10:47.196184
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections
    assert obj._load_collections('_collections', ["ansible_collections.nti_cloud"])
    assert obj._load_collections('_collections', None)

# Generated at 2022-06-23 06:10:48.330762
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs != None

# Generated at 2022-06-23 06:10:49.755250
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    assert col.collections == 'ansible.builtin'

# Generated at 2022-06-23 06:10:51.425832
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections is not None

# Generated at 2022-06-23 06:10:55.901487
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    print("test_CollectionSearch()")
    print("test._collections = %s" % test._collections)
    print("")

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:11:01.252618
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert ((instance._collections.default() == []) or
            (instance._collections.default() == ['ansible.legacy']))
    assert ((instance._collections.static is True) or
            (instance._collections.static is None))
    assert (instance._collections.mutable is None)
    assert (instance._collections.type == 'list')
    assert (instance._collections.listof == string_types)
    assert (instance._collections.priority == 100)

# Generated at 2022-06-23 06:11:03.141820
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search._load_collections('collections', [])

# Generated at 2022-06-23 06:11:09.825995
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.helpers import load_list_of_blocks

    block = load_list_of_blocks([
        dict(
            name="test",
            connection="first",
            collections=["ansible_collections.cool_namespace.cool_collection"],
        ),
    ], play_context=None).pop()

    collection_search = block[0]
    assert collection_search.collections == ["ansible_collections.cool_namespace.cool_collection"]

# Generated at 2022-06-23 06:11:11.218238
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None

# Generated at 2022-06-23 06:11:14.140059
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()
    assert obj._load_collections('collections', []) == None



# Generated at 2022-06-23 06:11:17.148183
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # Test the inherited and local attributes
    assert isinstance(collection_search, CollectionSearch)
    assert 'collections' in collection_search._attributes

# Generated at 2022-06-23 06:11:20.535480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass
    t = TestCollectionSearch()
    print(t.collections)
    assert t._collections is not None



# Generated at 2022-06-23 06:11:31.121306
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from collections import namedtuple
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    options = namedtuple('Options', ['collections'])
    options.collections = None
    display = Display()
    cs = CollectionSearch(None, options, display)
    assert cs._collections == _ensure_default_collection()

    options.collections = ["namespace.collection"]
    AnsibleCollectionConfig.default_collection = None
    cs = CollectionSearch(None, options, display)
    assert cs._collections == ["namespace.collection"]

    options.collections = None
    AnsibleCollectionConfig.default_collection = "namespace.collection"
    cs = CollectionSearch(None, options, display)
    assert cs._collections == ["namespace.collection"]

    options.collections = ["namespace.collection"]


# Generated at 2022-06-23 06:11:31.819060
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-23 06:11:42.659599
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test with specific collections
    ds = dict(collections=['one', 'two'])
    cs = CollectionSearch(ds)
    assert cs.collections == ['one', 'two', 'ansible.legacy']

    # Test default collections with no explicit collection
    ds = dict()
    cs = CollectionSearch(ds)
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']

    # Test default collections with an explicit collection
    ds = dict(collections=['one', 'two'])
    cs = CollectionSearch(ds)
    assert cs.collections == ['one', 'two', 'ansible.legacy']

    # Test default collections with an explicit default collection
    ds = dict(collections=['ansible.builtin'])
    cs = CollectionSearch(ds)

# Generated at 2022-06-23 06:11:46.134682
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._load_collections(collections=['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-23 06:11:51.419813
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    if cs._collections is None or cs._collections == ['ansible.builtin']:
        print('Test for constructor of class CollectionSearch fails')
    else:
        print("Test for constructor of class CollectionSearch passes")


# Generated at 2022-06-23 06:11:56.932960
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch("user", {"a": "test"}, 1, "collections", "_collections", "isa")
    assert cs.name == "user"
    assert cs.params == {"a": "test"}
    assert cs.depth == 1
    assert cs._attributes == {"_collections": "isa"}
    assert cs.attribute == "_collections"

# Generated at 2022-06-23 06:11:58.046730
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This should not raise an error.
    CollectionSearch()

# Generated at 2022-06-23 06:12:02.664911
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test(CollectionSearch):
        collections = _ensure_default_collection()

    ds = Test()
    ds.post_validate()

    assert ds.collections == ['ansible_collections.ansible.builtin']
    assert ds.get_validated_value('collections', ds._collections, None) == ['ansible_collections.ansible.builtin']

# Generated at 2022-06-23 06:12:06.511449
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default is None
    assert collection_search._collections.priority == 100
    assert collection_search._collections.static == True

# Generated at 2022-06-23 06:12:08.290935
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert isinstance(x, CollectionSearch)

# Generated at 2022-06-23 06:12:13.473551
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(CollectionSearch._collections.name == 'collections')
    assert(CollectionSearch._collections.isa is list)
    assert(CollectionSearch._collections.priority == 100)
    assert(CollectionSearch._collections.default == _ensure_default_collection)
    assert(CollectionSearch._collections.always_post_validate == True)
    assert(CollectionSearch._collections.static == True)

# Generated at 2022-06-23 06:12:16.884317
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    loader = AnsibleCollectionConfig('')
    loader.collections = []

    task = CollectionSearch(loader=loader)
    assert len(task.collections) == 1
    assert 'ansible.legacy' in task.collections

# Generated at 2022-06-23 06:12:29.453176
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # Test _collections
    assert collection_search._collections
    assert collection_search._collections.post_validate(None) == ['ansible.builtin', 'ansible_collections.my_namespace.my_collection']
    # Test _load_collections
    # mock 'ansible_collections' form ansible-config
    ansible_collections = ['ansible.builtin', 'ansible_collections.my_namespace.my_collection']
    with open('/tmp/ansible_collections', 'w') as f:
        f.writelines(ansible_collections)
    # mock 'get_validated_value' and 'get_config'
    collection_search.get_validated_value = lambda a, b, c, d, e: c
   

# Generated at 2022-06-23 06:12:30.804591
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    searcher = CollectionSearch()
    assert searcher._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:12:32.907336
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    o = CollectionSearch()
    assert o.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:12:35.908697
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    result = a._ensure_default_collection(collection_list=None)
    assert result is not None
    assert len(result) == 1

# Generated at 2022-06-23 06:12:37.558968
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)

# Generated at 2022-06-23 06:12:39.026905
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:12:41.169480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        CollectionSearch()
    except:
        raise Exception("No exception should be thrown")

# Generated at 2022-06-23 06:12:44.437518
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs_obj = CollectionSearch()
    print(cs_obj.__dict__)
    if cs_obj._collections == _ensure_default_collection():
        print("Unit test successfull")
    else:
        print("Unit test failed")


# Generated at 2022-06-23 06:12:49.564753
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

    c = CollectionSearch(collections=['zoo', 'banana'])
    assert c._collections == ['zoo', 'banana', 'ansible.builtin']

# Generated at 2022-06-23 06:12:53.130714
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass
    test_obj = TestCollectionSearch()
    default_collection = AnsibleCollectionConfig.default_collection
    assert default_collection in test_obj._collections

# Generated at 2022-06-23 06:12:59.619990
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    expected_collections = _ensure_default_collection()
    collection_search = CollectionSearch()
    assert expected_collections == collection_search._collections

# Generated at 2022-06-23 06:13:01.345585
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj
    assert obj._load_collections(1,2) == [ 'ansible.builtin' ]

# Generated at 2022-06-23 06:13:03.484847
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cls = type('AnsibleDS', (CollectionSearch,), {})
    cls()

# Generated at 2022-06-23 06:13:13.094310
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # check that _load_collections returns the same
    # value if explicitly set
    cs = CollectionSearch()
    cs._collections = ['another.collection']
    assert cs._load_collections(None, ['another.collection']) == ['another.collection']
    # check that _load_collections returns the same
    # value if explicitly set
    cs = CollectionSearch()
    cs._collections = ['another.collection']
    assert cs._load_collections(None, ['ansible.builtin']) == ['ansible.builtin', 'another.collection']
    # check that _load_collections handles empty lists correctly
    cs = CollectionSearch()
    cs._collections = ['another.collection']
    assert cs._load_collections(None, []) == ['another.collection']