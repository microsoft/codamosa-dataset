

# Generated at 2022-06-23 06:03:14.040402
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest

    class CollectionSearchTestCase(unittest.TestCase):
        def test_collections(self):
            cs = CollectionSearch()
            assert cs.collections == ['ansible_collections/ansible/buildin']

    test_case = CollectionSearchTestCase()
    test_case.test_collections()

# Generated at 2022-06-23 06:03:15.469221
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collections = CollectionSearch()
    assert test_collections is not None

# Generated at 2022-06-23 06:03:17.356268
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert collection_search.CollectionSearch._collections is not None

# Generated at 2022-06-23 06:03:23.243283
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin', 'ansible.legacy']
    assert c.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:03:28.971181
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    # Testing for variable collections
    #When collections variable is empty
    assert test_obj._load_collections(None,[]) == _ensure_default_collection(['ansible.builtin'])
    #When collections variable has some values
    assert test_obj._load_collections(None,['test']) == _ensure_default_collection(['ansible.builtin','test'])

# Generated at 2022-06-23 06:03:30.425958
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:03:32.137190
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections.get_validated_value('collections', collections._collections, None, None) == ['ansible.builtin']

# Generated at 2022-06-23 06:03:33.522879
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None, "Unable to create CollectionSearch object"

# Generated at 2022-06-23 06:03:44.045732
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import role_loader
    from ansible.plugins.loader import module_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    play_context = PlayContext(variable_manager=variable_manager)

   

# Generated at 2022-06-23 06:03:51.238129
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    
    # test with a valid collection search
    testcollectionsearch = CollectionSearch(collections=['collections.ansible.builtin'])

    # test with an invalid collection search (not a list)
    invalidtestcollectionsearch = 'collections.ansible.builtin'
    testcollectionsearch2 = CollectionSearch(collections=invalidtestcollectionsearch)

    # test with an invalid collection search (empty list)
    invalidtestcollectionsearch2 = []
    testcollectionsearch3 = CollectionSearch(collections=invalidtestcollectionsearch2)

# Generated at 2022-06-23 06:03:52.922403
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    assert col._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:03:55.791714
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    # All Attributes
    assert obj._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:04:01.859606
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_attr = []

    class TestCollectionSearch(CollectionSearch):
        pass

    test_object = TestCollectionSearch()
    test_object._load_collections(test_attr, [])
    assert test_object.collections == ['ansible.builtin', 'ansible.legacy']

    display.verbosity = 1
    test_object._load_collections(test_attr, ['{{foo}}', '{{bar}}'])

# Generated at 2022-06-23 06:04:09.564217
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    data_struct = {'collections': ['ansible_collections.nti_cloud']}

    # ensure that we can create an object and that it defaults to the correct list
    my_cs = CollectionSearch()

    # update the object with the data_struct and call _load_collections to set the lists
    my_cs._update_fields(data_struct)
    my_cs._load_collections(None, data_struct)

    # assert that the collections list is equal to the one from the data struct and not just the default
    assert my_cs.collections == data_struct['collections']

# Generated at 2022-06-23 06:04:19.360821
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test with a valid collection list that has builtin and legacy in it
    col = CollectionSearch()
    expected_result = ['ansible.builtin', 'collection', 'ansible.legacy']
    assert col._load_collections('_collections', ['ansible.builtin', 'collection', 'ansible.legacy']) == expected_result

    # Test with an empty collection list
    expected_result = ['ansible.builtin', 'ansible.legacy']
    assert col._load_collections('_collections', []) == expected_result

    # Test with a collection list that excludes builtin, but has legacy
    expected_result = ['collection', 'ansible.legacy']
    assert col._load_collections('_collections', ['collection', 'ansible.legacy']) == expected_result

    # Test with a collection

# Generated at 2022-06-23 06:04:26.150288
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # TestCollectionSearch class inherits __init__ from CollectionSearch
    from ansible.plugins.loader import get_all_plugin_loaders
    test_classes = get_all_plugin_loaders()
    test_class = test_classes['test']
    test_obj = test_class()
    assert test_obj.collections == ['ansible_collections.ansible.builtin']

# Generated at 2022-06-23 06:04:28.824432
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj.collections)

# Generated at 2022-06-23 06:04:31.341116
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    env = CollectionSearch()
    assert env.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:33.688096
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    '''
    CollectionSearch constructor should be available.
    '''
    cs = CollectionSearch()
    assert cs

# Generated at 2022-06-23 06:04:40.382913
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    # 下面将报错，因为 s.collections 是静态属性，可以设置值但是不能改变
    # s.collections.append('test')
    # 下面将输出: None
    print(s._load_collections('collections','test'))

# Generated at 2022-06-23 06:04:42.818488
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    
    cs = CollectionSearch()
    
    cs._collections = ['collection1', 'collection2']
    cs._load_collections(cs.collections, cs._collections)

# Generated at 2022-06-23 06:04:50.233211
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    import doctest
    import ansible.module_utils
    doctest.testmod(ansible.module_utils, verbose=False)
    path = os.path.dirname(os.path.dirname(__file__)) + '/'
    ansible_dir = path + '../../'
    module_utils_dir = ansible_dir + 'lib/ansible/module_utils/'
    collections_dir = module_utils_dir + 'collections/'

# Generated at 2022-06-23 06:04:55.359744
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections == ['ansible_collections.ansible.builtin']
    assert collection._collections != ['ansible_collections.ansible.builtin', 'ansible.builtin']

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:05:07.081183
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook import Playbook
    from ansible.module_utils.six import PY3

    # Initialize an object of class Playbook with host_list as empty list and
    # options as None
    pb = Playbook()
    pb.host_list = []
    options = None

    # Initialize an object of class CollectionSearch
    cs = CollectionSearch()

    # Set attrs of object cs
    cs.set_loader(pb.loader)
    cs.set_task_overrides('test_task')
    cs.set_task_vars('test_var')
    cs.set_play_context('test_play_context')
    cs.set_data_loader(pb.loader)
    cs.set_variable_manager(pb.variable_manager)

# Generated at 2022-06-23 06:05:09.946411
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:05:12.900306
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pprint

    # Setup
    cs = CollectionSearch()
    # Verify
    pprint.pprint(cs.collections)

# Generated at 2022-06-23 06:05:18.668683
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections == ['ansible.builtin', 'ansible.legacy']
    search.collections = ['col1', 'col2', 'col3']
    assert search.collections == ['col1', 'col2', 'col3', 'ansible.builtin', 'ansible.legacy']
    search.collections = None
    assert search.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:05:20.930944
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == 'ansible.builtin,ansible.legacy'

# Generated at 2022-06-23 06:05:24.053263
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Reproducing error for "unexpected keyword argument '_validate'"

    class DummyBase(object):
        dummy_field = FieldAttribute(isa='str', priority=100, default='default_value')

    base_object = DummyBase()
    my_obj = CollectionSearch(base_object)

# Generated at 2022-06-23 06:05:27.200213
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    ds = {"collections": ['my_collection']}
    assert CollectionSearch(ds, {})._collections.value == ['my_collection', 'ansible.builtin']

# Generated at 2022-06-23 06:05:30.769196
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.__class__.__name__ == 'CollectionSearch'

# Generated at 2022-06-23 06:05:33.282204
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._collections = ['collection1', 'collection2']
    assert cs._collections == ['collection1', 'collection2']

# Generated at 2022-06-23 06:05:35.452409
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:05:38.774737
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == ['ansible.builtin', 'ansible.legacy']
    assert _ensure_default_collection(['foo']) == ['foo', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:05:42.180041
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == None
    cs._collections = 'ansible.builtin'
    assert cs._collections == 'ansible.builtin'
    cs._collections = ['ansible.builtin']
    assert cs._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:05:43.809800
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:05:44.963763
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:05:47.774362
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert cs._loader is None
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:05:49.725798
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection1 = CollectionSearch()
    assert collection1.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:06:00.415770
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Ensure list always return a list (not an iterator)
    def _ensure_default_collection_test():
        return _ensure_default_collection(collection_list=None)

    # No collections; an empty collections list is returned
    result = _ensure_default_collection_test()
    assert not result

    # Populate collections
    result = _ensure_default_collection(collection_list=['nslcd', 'ansible.legacy'])

    # Ensure that the expected list is returned
    assert result[0] == 'nslcd'
    assert result[1] == 'ansible.legacy'

    # Ensure that the default collection is not re-added to the list
    result = _ensure_default_collection(collection_list=['nslcd', 'ansible.legacy'])
    assert result[0]

# Generated at 2022-06-23 06:06:02.682005
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:06:04.329595
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default_value == _ensure_default_collection()

# Generated at 2022-06-23 06:06:09.801434
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    if c._collections != ['ansible.legacy']:
        raise Exception('CollectionSearch object has wrong _collection attribute')
    c = CollectionSearch(collections=['ansible.builtin'])
    if c._collections != ['ansible.builtin', 'ansible.legacy']:
        raise Exception('CollectionSearch object has wrong _collection attribute')

# Generated at 2022-06-23 06:06:16.100601
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert collection_search.get_collections() is _ensure_default_collection(collection_search.get_collections())

# Generated at 2022-06-23 06:06:17.706550
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:06:24.971781
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    import types

    # test when no collection is in the task
    collections = []
    assert sorted(collections) == sorted(_ensure_default_collection(collection_list=collections))

    # test with a collection already in the task
    collections = [col.strip('.') for col in AnsibleCollectionConfig.default_collection.split('.')]
    assert sorted(collections) == sorted(_ensure_default_collection(collection_list=collections))

    # test with a collection already in the task
    collections = [col.strip('.') for col in AnsibleCollectionConfig.default_collection.split('.')]
    collections.append('fred')
    assert sorted(collections) == sorted(_ensure_default_collection(collection_list=collections))


# Generated at 2022-06-23 06:06:26.414502
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections is not None


# Generated at 2022-06-23 06:06:28.220401
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    value = collection_search._load_collections(None, 'test_data')
    assert value == 'test_data'

# Generated at 2022-06-23 06:06:32.527782
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import sys
    import os
    import glob
    import re
    import shutil

    if sys.version_info < (3, 5):
        return

    # Create the temp test directory
    d_name = 'test_collection_search'

# Generated at 2022-06-23 06:06:36.337807
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search._collections, list)
    assert collection_search is not None and isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-23 06:06:45.229221
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection.collections == ['ansible.builtin', 'ansible.legacy']
    assert collection.get_validated_value('collections', collection._collections, ['ansible.test.test_module'], None) == ['ansible.test.test_module', 'ansible.legacy']
    assert collection.get_validated_value('collections', collection._collections, [], None) == ['ansible.legacy']
    assert collection.get_validated_value('collections', collection._collections, None, None) == ['ansible.legacy']

# Generated at 2022-06-23 06:06:51.014980
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections_list = ['ansible.builtin']
    obj = CollectionSearch()
    obj.collections = collections_list
    assert obj._collections == collections_list

# Generated at 2022-06-23 06:06:55.413846
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = 'test'
    collection_search = CollectionSearch()
    assert collection_search._load_collections(None, ds) == ['test', 'ansible.legacy']

# Generated at 2022-06-23 06:06:58.039513
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections.name == "_collections"
    assert CollectionSearch()._collections.listof == string_types

# Generated at 2022-06-23 06:06:59.877970
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None

# Generated at 2022-06-23 06:07:05.061452
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Test _load_collections method
    obj = CollectionSearch()
    attr = None
    ds = ['test']
    obj._load_collections(attr, ds)

    #Test _ensure_default_collection method
    collection_list = None
    obj._ensure_default_collection(collection_list)

# Generated at 2022-06-23 06:07:07.100631
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections == 'ansible.builtin,ansible.legacy'

# Generated at 2022-06-23 06:07:08.837689
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._load_collections('collections',[]) is None

# Generated at 2022-06-23 06:07:09.618934
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-23 06:07:15.213647
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        def __init__(self, collection_list=None):
            self._collections = collection_list

    assert TestCollectionSearch()._collections == ['ansible.builtin']
    assert TestCollectionSearch(collection_list=['ansible.builtin', 'ansible.legacy'])._collections == ['ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-23 06:07:20.174208
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    x._load_collections(1,2)
    x._collections = ['ansible.builtin']
    x.get_validated_value('collections', x._collections, x._collections, None)
    x.get_validated_value('collections', x._collections, x._collections, 'ansible.builtin')
    x.get_validated_value('collections', x._collections, x._collections, 'ansible.legacy')

# Generated at 2022-06-23 06:07:27.931561
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Create an object of type CollectionSearch and pass empty (default) collections
    collection_search = CollectionSearch(None, collections=[])

    # Verify that the constructor has added 'ansible.builtin' as the first item in the collections
    assert 'ansible.builtin' == collection_search.collections[0]

    # Create an object of type CollectionSearch and pass 'ansible.builtin' as collections
    collection_search = CollectionSearch(None, collections=['ansible.builtin'])

    # Verify that the constructor has not added 'ansible.builtin' as the first item in the collections
    assert 'ansible.builtin' != collection_search.collections[0]

# Generated at 2022-06-23 06:07:35.965256
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

	test_list = ["col1","col2", "col3"] # This list should be populated by collections
	
    # Check if the list is empty

# Generated at 2022-06-23 06:07:37.111306
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()


# Generated at 2022-06-23 06:07:38.345414
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections._collections is None


# Generated at 2022-06-23 06:07:40.946674
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs
    assert cs.namespace == 'AnsibleInternal'
    assert cs.name == 'CollectionSearch'
    assert not cs.__dict__['_collections']


# Generated at 2022-06-23 06:07:43.181378
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)

# Generated at 2022-06-23 06:07:44.614838
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default is _ensure_default_collection



# Generated at 2022-06-23 06:07:48.074595
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    assert CollectionSearch.collections is None
    # Should return a list of all the collection names
    assert _ensure_default_collection() == ['ansible_collections.ansible.builtin', 'ansible_collections.nsweb.myrole']

# Generated at 2022-06-23 06:07:48.692137
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:07:58.791318
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("Testing class constructor")
    attr = {}
    data = {}
    print("\tUsing: attr={}, data={}".format(attr, data))
    cs = CollectionSearch()
    expected = []
    actual = cs._load_collections(attr, data)
    print("\tExpected: {}".format(expected))
    print("\tActual: {}".format(actual))
    if expected == actual:
        print("\tTEST PASSED")
    else:
        print("\tTEST FAILED")

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:08:00.016003
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)

# Generated at 2022-06-23 06:08:05.014862
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.post_validate({}, {'collections': ['my.collection']})
    assert collection_search.collections == ['my.collection']


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:08:06.271274
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Testing constructor
    cs = CollectionSearch()
    assert cs._collections == []

# Generated at 2022-06-23 06:08:07.901613
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == ['ansible_collections.maz Reply.Network', 'ansible.builtin']

# Generated at 2022-06-23 06:08:11.568281
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections == _ensure_default_collection()


# Generated at 2022-06-23 06:08:13.425406
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CS = CollectionSearch()
    print("Test for __init__", CS.collections)

# Generated at 2022-06-23 06:08:18.042111
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.__setattr__('_collections', ['local'])
    # Don't need to call _load_collections since it will get called in post_validate
    # search._load_collections('collections', ['local'])
    assert search.__getattribute__('_collections') == ['local']

# Generated at 2022-06-23 06:08:19.669604
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections._get_value() == _ensure_default_collection()

# Generated at 2022-06-23 06:08:21.279048
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert 'ansible.builtin' in obj.collections
    assert 'ansible.builtin' in obj._load_collections('collections', obj.collections)

# Generated at 2022-06-23 06:08:23.538788
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:08:25.667735
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test attr "collections"
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()


# Generated at 2022-06-23 06:08:28.301467
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, []) is None
    assert cs._load_collections(None, None) == ["ansible.builtin"]

# Generated at 2022-06-23 06:08:29.155378
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None

# Generated at 2022-06-23 06:08:30.027860
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert not cs

# Generated at 2022-06-23 06:08:42.378907
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.tasks import Task
    from ansible.playbook.play_context import PlayContext

    cr = CollectionSearch()
    assert isinstance(cr, CollectionSearch)

    # Test validation
    class FakeClass:
        pass
    fake_obj = FakeClass()
    fake_obj.__class__.collections = cr._collections
    fake_obj.__class__.name = cr._collections

    # Fields are required for dependencies that are not always populated
    # This is simpler than mocking the fields out
    class FakeCollectionRole:
        def __init__(self):
            self.self_contained = None


    # Interactive
    fake_obj.context = {'INTERACTIVE_MODE': True}

# Generated at 2022-06-23 06:08:44.627630
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()
    assert not collection_search._load_collections(None, None)

# Generated at 2022-06-23 06:08:49.816227
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Foo(object):
        def __init__(self):
            self._collections = None
    foo = Foo()
    foo._collections = 'ansible.builtin'
    assert foo._collections == 'ansible.builtin'


# Generated at 2022-06-23 06:08:55.776637
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch._collections, FieldAttribute)
    assert CollectionSearch._collections.name == 'collections'
    assert CollectionSearch._collections.isa == 'list'
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.always_post_validate is True
    assert CollectionSearch._collections.static is True

# Generated at 2022-06-23 06:08:56.416248
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-23 06:08:57.423863
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()


# Generated at 2022-06-23 06:08:59.363696
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    # Parameterized constructor check
    collectionSearch.post_validate()

    assert collectionSearch._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:09:02.202509
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance_collectionsearch = CollectionSearch()
    assert isinstance(instance_collectionsearch, CollectionSearch)

# Generated at 2022-06-23 06:09:05.150276
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    collection_list = collection._load_collections("collections", ["test_collection"])
    assert('ansible.builtin' in collection_list)


# Generated at 2022-06-23 06:09:10.078576
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)

    # Test for get_validated_value()
    assert isinstance(obj.get_validated_value("collections", obj._collections, None), list)

# Generated at 2022-06-23 06:09:19.434318
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # run the test
    instance = CollectionSearch()
    # check the result
    assert isinstance(instance._collections, FieldAttribute)
    assert isinstance(instance._collections.isa, type(None))
    assert isinstance(instance._collections.listof, type(None))
    assert isinstance(instance._collections.always_post_validate, bool)
    assert isinstance(instance._collections.static, bool)
    assert isinstance(instance._collections.priority, int)
    assert isinstance(instance._collections.default, staticmethod)
    assert (instance._collections.default() == ['ansible.builtin', 'ansible.builtin'])
    # check the result
    assert isinstance(instance._load_collections(attr=None,ds='ansible.builtin'), list)

# Generated at 2022-06-23 06:09:24.687037
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # test to check the constructor of CollectionSearch class
    def __init__(self):
        super(CollectionSearch, self).__init__()
        self._collections = 'ansible.builtin'

    test_collection_search = CollectionSearch()
    assert test_collection_search._collections == 'ansible.builtin'



# Generated at 2022-06-23 06:09:32.829668
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    task = TaskInclude()
    assert task.collections is None
    task.collections = [u'ansible.posix']
    assert task.collections == [u'ansible.posix']
    task.collections = None
    assert task.collections is None
    # Should add `ansible.builtin` to collection list if not specified or
    # completely empty.
    task.collections = []
    assert len(task.collections) == 2
    assert u'ansible.builtin' in task.collections and u'ansible.legacy' in task.collections
    task.collections = [u'ansible.posix']
    assert len(task.collections) == 3

# Generated at 2022-06-23 06:09:34.458699
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch(collections = "ansible_collections.community.windows")

# Generated at 2022-06-23 06:09:44.503209
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Initialize the data structure
    ds = {}
    ds['collections'] = [
        'ansible.builtin',
        'ansible.posix',
        'ansible.windows',
    ]


    # Initialize the Class
    obj = CollectionSearch()

    # Initialize values
    obj.set_loader(object)
    obj._collections = list(ds['collections'])

    # Test for _load_collections()
    nds = obj._collections
    assert nds is not None

    assert nds[0] == 'ansible.builtin'
    assert nds[1] == 'ansible.posix'
    assert nds[2] == 'ansible.windows'



# Generated at 2022-06-23 06:09:46.902528
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    test_obj = CollectionSearch()
    # Test for Field Attribute: _collections
    assert test_obj._collections == ('ansible.builtin',)

# Generated at 2022-06-23 06:09:50.068941
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._load_collections(None, None)
    assert cs.collections._value == ['ansible.builtin'] or cs.collections._value == ['ansible.legacy']

# Generated at 2022-06-23 06:09:52.316026
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    mc = CollectionSearch()
    assert mc.collections == ['ansible_collections.testns.testcoll']

# Generated at 2022-06-23 06:09:58.133267
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj._load_collections(None, None))
    assert(obj._load_collections(None, None) is not None)
    print(obj._load_collections(None, ['ansible.builtin', 'ansible.posix']))
    assert(obj._load_collections(None, ['ansible.builtin', 'ansible.posix']) is not None)

# Generated at 2022-06-23 06:09:59.988721
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert result._collections == _ensure_default_collection(collection_list=None)



# Generated at 2022-06-23 06:10:09.379773
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class FakeDS(object):
        def __init__(self, ds):
            self.ds = ds

    collection_search = CollectionSearch()
    # not a list
    ds = FakeDS("not_a_list")
    result = collection_search._load_collections("collections", ds)
    assert result == ['ansible.builtin', 'ansible.legacy']
    # an empty list
    ds = FakeDS([])
    result = collection_search._load_collections("collections", ds)
    assert result is None
    # a list of collection names
    ds = FakeDS(['foo.bar'])
    result = collection_search._load_collections("collections", ds)
    assert result == ['foo.bar', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:10:11.316749
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    sc = CollectionSearch()
    sc._load_collections(attr = True, ds = ['test1', 'test2'])

# Generated at 2022-06-23 06:10:15.845937
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    # expect nothing to be returned as collections is None
    assert collection_search._load_collections("collections", None) is None

    # expect inserts 'ansible.builtin' in collection_list if collections is not None
    collection_list_ = ['ansible.legacy']
    actual_collections = collection_search._load_collections("collections", collection_list_)

    assert 'ansible.builtin' in actual_collections

# Generated at 2022-06-23 06:10:23.027576
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class MyCollectionSearch(CollectionSearch):
        pass

    test_object = MyCollectionSearch()

    # _collection attribute is empty
    assert test_object._collections is None

    # _load_collections returns what it is passed
    # _collections are None
    assert test_object._load_collections('collections', None) == []

    # _collections are not None
    assert test_object._load_collections('collections', ['collection1', 'collection2']) == ['collection1', 'collection2']

# Generated at 2022-06-23 06:10:23.957735
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs

# Generated at 2022-06-23 06:10:27.443067
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs1 = CollectionSearch()
    cs2 = CollectionSearch()
    assert cs1 is not cs2
    assert cs1._collections == cs2._collections
    assert cs1._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:10:28.432994
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.collections is not None


# Generated at 2022-06-23 06:10:31.126390
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert None == x._load_collections('collections', [])

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:10:34.338306
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        cs = CollectionSearch()
    except Exception:
        assert False, "Failed to instantiate class CollectionSearch"



# Generated at 2022-06-23 06:10:39.342965
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def _test_CollectionSearch_constructor_helper(collection_list):
        obj = CollectionSearch()
        # pylint: disable=protected-access
        assert obj._collections == collection_list

    _test_CollectionSearch_constructor_helper(None)
    _test_CollectionSearch_constructor_helper(['namespace.collection'])

# Generated at 2022-06-23 06:10:41.600130
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    if c._load_collections:
        pass
    else:
        raise RuntimeError("cannot find _load_collections")

# Generated at 2022-06-23 06:10:47.221229
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test class constructor when passing no argument
    collection_search = CollectionSearch()
    assert(collection_search.collections == 'ansible.builtin')

    # Test class constructor when passing an argument
    collection_search = CollectionSearch(collections=['special1','special2','special3'])
    assert(collection_search.collections == 'special3')

# Generated at 2022-06-23 06:10:49.064437
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  cs = CollectionSearch()
  assert cs._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:10:50.621839
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:58.028419
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) == ['ansible.builtin', 'ansible.legacy']
    assert cs._load_collections(None, ['foo']) == ['foo', 'ansible.builtin', 'ansible.legacy']
    assert cs._load_collections(None, ['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']
    assert cs.get_validated_value('collections', cs._collections, None, None) == ['ansible.builtin', 'ansible.legacy']
    assert cs.get_validated_value('collections', cs._collections, ['foo'], None) == ['foo', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:11:00.689114
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # The __init__ method of the CollectionSearch class does not return anything.
    # Therefore, we only test the initialisation of the class here.
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()



# Generated at 2022-06-23 06:11:04.383307
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    assert cs._collections is not None
    assert cs._collections == _ensure_default_collection(["test"])

# Generated at 2022-06-23 06:11:05.880353
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-23 06:11:10.437417
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_collection = CollectionSearch()
    test_collections = ['configured', 'default_collections']
    search_collection.set_loader({'collections': test_collections})
    assert search_collection.collections == test_collections
    assert search_collection.loader.collections == test_collections

# Generated at 2022-06-23 06:11:12.174061
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test that the constructor of class ManagedValue runs without errors
    CollectionSearch()

# Generated at 2022-06-23 06:11:17.199229
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Constructor of class CollectionSearch
    cs = CollectionSearch()
    # Call _load_collections() method
    ds = cs._load_collections(None, None)
    print(ds)
    # Call _ensure_default_collection() method
    dc = _ensure_default_collection()
    print(dc)
    dc = _ensure_default_collection(collection_list=['ansible.builtin'])
    print(dc)

if __name__ == "__main__":
    # execute only if run as a script
    test_CollectionSearch()

# Generated at 2022-06-23 06:11:18.260152
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:11:28.571392
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    # Test for _collections field
    assert search._collections is not None
    assert search._collections.name == 'collections'
    assert search._collections.static
    assert not search._collections.private
    assert search._collections.priority == 100
    assert not search._collections.default
    assert search._collections.listof is string_types
    assert not search._collections.always_post_validate
    assert search._collections.always_post_coerce

    assert search._load_collections(attr='attr', ds=['ansible.builtin']) == ['ansible.builtin']

    # Test for default_collection
    assert search._load_collections(attr='attr', ds=None) == ['ansible.builtin']

    # Test for _ensure

# Generated at 2022-06-23 06:11:33.454312
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestClass:
        def __init__(self):
            self.collections = ['ansible.builtin']
            p = CollectionSearch()
            p.__dict__ = self.__dict__
            assert True
    test_obj = TestClass()
    test_obj.__init__()

# Generated at 2022-06-23 06:11:44.722681
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, []) == None, "Expected None, got " + str(cs._load_collections(None, []))
    assert cs._load_collections(None, ["a"]) == ["a"], "Expected [a], got " + str(cs._load_collections(None, ["a"]))
    assert cs._load_collections(None, ["ansible.builtin"]) == ["ansible.builtin"], "Expected [ansible.builtin], got " + str(cs._load_collections(None, ["ansible.builtin"]))

# Generated at 2022-06-23 06:11:49.102897
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test: _load_collections method
    _collections = 'ansible.builtin'
    obj = CollectionSearch()
    result = obj._load_collections(obj._collections, _collections)
    assert result == ['ansible.builtin', 'ansible.legacy']
    _collections = None
    result = obj._load_collections(obj._collections, _collections)
    assert result == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:11:51.130019
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch()
    assert d.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:52.394439
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	collection_search = CollectionSearch()

# Generated at 2022-06-23 06:11:53.604424
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections is not None

# Generated at 2022-06-23 06:11:55.514428
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection(collection_list=None)

# Generated at 2022-06-23 06:12:01.714067
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.module_utils.six import PY3

    cs = CollectionSearch()

    assert isinstance(cs._load_collections, type(cs._ensure_default_collection))

    if PY3:
        assert isinstance(cs._load_collections, type(cs._collections.post_validate))
    else:
        # For Python 2 this is a function
        assert isinstance(cs._load_collections, type(cs._collections.post_validate.__func__))

# Generated at 2022-06-23 06:12:04.343349
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base

    class test_collection_search(CollectionSearch, Base):
        pass

    t_col = test_collection_search()
    assert t_col._collections == 'ansible.builtin'

# Generated at 2022-06-23 06:12:04.887235
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-23 06:12:06.924169
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None

# Generated at 2022-06-23 06:12:08.911427
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None

# Generated at 2022-06-23 06:12:19.276726
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()

    # Check object type
    assert isinstance(test_object, object)
    assert isinstance(test_object, CollectionSearch)

    # Test data
    test_data = {
        "collections": [
            "ansible.builtin",
            "Ansible.awx",
            "awx"
        ]
    }

    # Check initial value
    assert test_object._collections.value is None

    # Load collections
    test_object._load_collections('collections', test_data)

    # Check the value
    assert test_object._collections.value == test_data['collections']

    # Check the type
    assert isinstance(test_object._collections.value, list)

# Generated at 2022-06-23 06:12:31.264694
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    cs = CollectionSearch()

    assert cs._valid_attrs['collections'].static

    # _load_collections is a post validate method, so we need to make sure
    # it's called for the class and for an instance of the class.

    # Call the _load_collections on the class and make sure it returns the
    # default collections
    default_collections = cs._load_collections('collections', None)
    assert default_collections == _ensure_default_collection()

    # Now call it on an instance of the class and make sure it also returns
    # the default collections
    cs = CollectionSearch()
    default_collections = cs._load_collections('collections', None)
    assert default_collections == _ens

# Generated at 2022-06-23 06:12:34.352073
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert isinstance(instance._collections, FieldAttribute)
    assert isinstance(instance._collections.default, type(callable))

# Generated at 2022-06-23 06:12:37.807635
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:12:38.413906
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:12:40.518929
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c1 = CollectionSearch()
    assert c1._collections == ['ansible.builtin']



# Generated at 2022-06-23 06:12:45.339836
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test for method _ensure_default_collection
    # collection_list is None
    assert (CollectionSearch()._ensure_default_collection() == ['ansible.builtin'])
    # collection_list isn't None
    assert (CollectionSearch()._ensure_default_collection(['ansible.legacy']) == ['ansible.builtin', 'ansible.legacy'])
    # collection_list is [], it will not return an empty list
    assert (CollectionSearch()._ensure_default_collection([]) is None)


# Generated at 2022-06-23 06:12:48.947238
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default is _ensure_default_collection
    assert CollectionSearch._collections.always_post_validate

# Generated at 2022-06-23 06:12:54.172982
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestAttr(CollectionSearch):
        pass

    ds = {'collections': ['/etc/ansible/collections/testing/collection/ansible_collections/my_namespace/my_collection/']}
    test_attr = TestAttr()
    test_attr.datasource = ds
    test_attr.post_validate()

# Generated at 2022-06-23 06:13:00.143076
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Test collection_search.CollectionSearch constructor"""
    collection_search = CollectionSearch()
    assert type(collection_search._collections) is list

# Generated at 2022-06-23 06:13:02.350116
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch is not None

# Generated at 2022-06-23 06:13:10.880252
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block

    class Dummy(Block,CollectionSearch):
        pass

    d = Dummy()
    assert d.get_validated_value('collections',d._collections,None,None) is not None
    assert 'ansible.builtin' in d.get_validated_value('collections', d._collections, None, None)
    assert 'ansible.legacy' not in d.get_validated_value('collections', d._collections, None, None)