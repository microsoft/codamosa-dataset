

# Generated at 2022-06-23 06:03:23.684038
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is None
    assert obj.collections is None
    assert obj._load_collections('collections', None) is None
    assert obj.collections is None
    assert obj.get_validated_value('collections', obj._collections, None, None) is None
    assert obj._load_collections('collections', list()) is None
    assert obj.collections is None
    assert obj.get_validated_value('collections', obj._collections, None, None) is None

# Generated at 2022-06-23 06:03:29.918915
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("Unit test for CollectionSearch")

    # Construct with no arguments
    print("Construct with no arguments")
    search = CollectionSearch()
    print(search.collections)
    print()

    # Construct with one argument
    print("Construct with one argument")
    search = CollectionSearch(['custom.collection'])
    print(search.collections)
    print()

    # Construct with two arguments
    print("Construct with two arguments")
    search = CollectionSearch(['custom.collection', 'another.collection'])
    print(search.collections)
    print()


# Generated at 2022-06-23 06:03:30.729618
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    return c

# Generated at 2022-06-23 06:03:32.549116
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:03:38.447722
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude

    for obj in (RoleInclude(), TaskInclude()):
        # No collection_list passed, self.collections should contain the default_collection
        assert _ensure_default_collection() == obj._load_collections(None, None)

        # Check _load_collections() with a collection_list passed
        assert ['collection1', 'collection2'] == obj._load_collections(None, ['collection1', 'collection2'])

# Generated at 2022-06-23 06:03:45.123608
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert isinstance(x, CollectionSearch)
    assert isinstance(x._collections, FieldAttribute)
    assert x._collections.isa() == 'list'
    assert isinstance(x._collections.listof(), string_types)
    assert x._collections.priority() == 100
    assert x._collections.default() == _ensure_default_collection
    assert x._collections.always_post_validate()
    assert x._collections.static()

# Generated at 2022-06-23 06:03:46.282496
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   c = CollectionSearch()  # noqa

# Generated at 2022-06-23 06:03:49.868447
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    l = c._load_collections(None, None)
    assert l == AnsibleCollectionConfig.default_collection, 'Default collection should be at the beginning of the list'

# Generated at 2022-06-23 06:03:54.735779
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

    collections_list = ['foo', 'bar', 'baz']
    cs = CollectionSearch(collections=collections_list)
    assert cs._collections == collections_list

# Generated at 2022-06-23 06:03:55.447027
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-23 06:03:58.514442
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == "ansible.legacy"
    with pytest.raises(ValueError):
        collection_search._collections = 0

# Generated at 2022-06-23 06:04:04.276519
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_play = CollectionSearch()
    assert test_play._collections._static is True
    assert test_play._collections._priority is 100
    assert test_play._collections._default is _ensure_default_collection
    assert test_play._collections._always_post_validate is True
    assert test_play._collections.isa is 'list'
    assert test_play._collections.listof is string_types

# Generated at 2022-06-23 06:04:06.132032
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:04:06.929321
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-23 06:04:09.799664
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search = CollectionSearch()
    except Exception:
        print("Object creation failed.")
    else:
        print("Object creation success.")

# Call to the constructor of class CollectionSearch
test_CollectionSearch()

# Generated at 2022-06-23 06:04:11.114550
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections is not None

# Generated at 2022-06-23 06:04:20.694770
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    import tempfile
    #Creating a temporary file and writing the data to the file
    filename = tempfile.mkstemp()[1]
    f = open(filename, 'w')
    f.close()

    #Creating a class object for the CollectionSearch class
    col_sch = CollectionSearch()

    #Checking whether the created object is an instance of the class
    assert isinstance(col_sch,CollectionSearch)

    col_sch._collections = ['collections_1', 'collections_2']

    #Checking for the value after post validation
    assert col_sch.collections == ['collections_1', 'collections_2']

    #Checking for the default value after post validation
    assert col_sch.collections == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-23 06:04:23.536231
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == cs._ensure_default_collection(cs._collections.default)


# Generated at 2022-06-23 06:04:27.251734
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ['a.b.c']
    assert cs.collections == ['a.b.c']
    assert cs._collections == ['a.b.c']

# Generated at 2022-06-23 06:04:38.074219
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    import pytest

    play_context = PlayContext()
    play_context._template_uid = 10
    play_context._loader = AnsibleCollectionConfig.default_loader

    play = Play()
    play._role_context = RoleContext()
    play._loader = AnsibleCollectionConfig.default_loader
    play_context._cur_task = Task()

    # test for class Task
    with pytest.raises(Exception) as eobj:
        task = Task()
        task._role = Role()
        assert task._role is None

# Generated at 2022-06-23 06:04:43.702577
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible_collections.ztj.test_collection.roles.baz_role', 'ansible_collections.ztj.test_collection.plugins.modules.baz_module', 'ansible_collections.ztj.test_collection.plugins.inventory.baz_inventory', 'ansible_collections.ztj.test_collection.plugins.cliconf.baz_cliconf']

# Generated at 2022-06-23 06:04:46.094074
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    ds = {
        'collections': ['col1', 'col2']
    }
    assert c._load_collections('collections', ds) == ['col1', 'col2']

# Generated at 2022-06-23 06:04:54.751506
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)

    if AnsibleCollectionConfig.default_collection is None:
        assert obj._collections.value is None
    else:
        assert obj._collections.value == [AnsibleCollectionConfig.default_collection]
    assert obj._collections.data == [AnsibleCollectionConfig.default_collection]
    assert obj._collections.always_post_validate()

    assert obj._load_collections(None, []) == [AnsibleCollectionConfig.default_collection]
    assert obj._load_collections(None, ['foo']) == ['foo', AnsibleCollectionConfig.default_collection]

    # Now don't allow default_collection
    AnsibleCollectionConfig.default_collection = None

    assert obj._collections.value is None
    assert obj._load_col

# Generated at 2022-06-23 06:04:57.577845
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.value is not None
    assert cs.collections == ['ansible.builtin']



# Generated at 2022-06-23 06:05:08.887499
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import mock
    import unittest

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    class CollectionSearchTest(unittest.TestCase):
        def test_collection_search(self):
            # TODO: The depedencyInjection needs to be improved to remove the need for mocking.
            play_context = PlayContext()
            templar = Templar(loader=mock.MagicMock())
            templar._available_variables = mock.MagicMock()

# Generated at 2022-06-23 06:05:10.195905
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections is not None

# Generated at 2022-06-23 06:05:18.513804
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Init CollectionSearch class
    collection_search = CollectionSearch()
    if collection_search is None:
        raise AssertionError("CollectionsSearch init failed")
    print('test CollectionSearch init success')

    # Test _load_collections
    collection_search._collections = ["foo", "bar"]
    ret = collection_search._load_collections("collections", "fake_attr")
    if ret is None:
        raise AssertionError("_load_collections() failed")
    print('test _load_collections success')

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:05:20.164793
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test for correct class creation
    collection_search = CollectionSearch()
    assert collection_search

# Generated at 2022-06-23 06:05:30.688256
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    # test when collections is not being passed in
    collection_search.ds = dict()
    result = collection_search._load_collections(collection_search.get_field_by_name('collections'), collection_search.ds)
    assert result == ['ansible.builtin', 'ansible.legacy']

    # test when collections is being passed in
    collection_search.ds = dict(collections=['ansible_collections.namespace.collection'])
    result = collection_search._load_collections(collection_search.get_field_by_name('collections'), collection_search.ds)
    assert result == ['ansible_collections.namespace.collection', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:05:31.573404
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()

# Generated at 2022-06-23 06:05:33.380381
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    print(collections._load_collections('collections', ''))

# Generated at 2022-06-23 06:05:37.153094
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    attr = 'collections'
    ds = None
    result = obj.load_collections(attr, ds)
    assert result == ['ansible.builtin']
    assert len(result) == 1

# Generated at 2022-06-23 06:05:39.636896
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass
    instance = TestCollectionSearch()
    assert instance._load_collections(None, []) == _ensure_default_collection([])

# Generated at 2022-06-23 06:05:41.442403
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TmplSearch(CollectionSearch):
        pass
    task = TmplSearch()
    assert task.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:05:43.012934
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.collections == []

# Generated at 2022-06-23 06:05:43.760702
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()

# Generated at 2022-06-23 06:05:53.840594
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    #test1: Test _load_collections function
    #todo: need to update test data
    result = cs._load_collections('collections', [])
    assert result == None

    #test2: Test _load_collections function
    result = cs._load_collections('collections', ['ansible.builtin'])
    assert result == ['ansible.builtin', 'ansible.legacy']

    #test3: Test _load_collections function
    result = cs._load_collections('collections', ['ansible.builtin', 'ansible.builtin', 'ansible.builtin'])
    assert result == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:05:55.350102
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == []

# Generated at 2022-06-23 06:05:56.836850
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs._collections)

# Generated at 2022-06-23 06:05:57.841624
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None

# Generated at 2022-06-23 06:06:00.574163
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._collections = 'ansible.builtin'
    assert cs._load_collections('', '') == ['ansible.builtin']

# Generated at 2022-06-23 06:06:06.830826
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    derived_class_name = 'base'
    derived_class = type(derived_class_name, (CollectionSearch,), {})

    # Test the constructor
    instance = derived_class()

    # Test that _collections is of type 'list'
    if not isinstance(instance._collections, list):
        raise AssertionError("_collections should be of type 'list'")

# Generated at 2022-06-23 06:06:09.945855
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections is not None
    assert 'ansible.builtin' in x._collections or 'ansible.legacy' in x._collections

# Generated at 2022-06-23 06:06:19.619384
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.role.task
    import ansible.playbook.role.include
    import ansible.playbook.role.meta
    import ansible.playbook.role.defaults
    import ansible.playbook.role.vars
    import ansible.playbook.role.handlers
    import ansible.playbook.cleanup_task
    import ansible.playbook.become_task
    import ansible.playbook.block.block
    import ansible.playbook.block.role
    import ansible.playbook.block.rescue
    import ansible.playbook.block

# Generated at 2022-06-23 06:06:25.600031
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    test_attrs = {
        "collections": ['coleflect.cwebb_apache', 'coleflect.cwebb_coreos'],
    }
    cs.post_validate(test_attrs, None)
    assert not cs.post_validate(test_attrs, None)
    assert cs.collections == ['coleflect.cwebb_apache', 'coleflect.cwebb_coreos']

# Generated at 2022-06-23 06:06:26.889280
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == []

# Generated at 2022-06-23 06:06:30.939908
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert None == cs._load_collections('collections', [])
    assert None == cs._load_collections('collections', None)
    assert ['ansible_collections.t_collection.t_role'] == cs._load_collections('collections', ['ansible_collections.t_collection.t_role'])

# Generated at 2022-06-23 06:06:35.150780
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.__dict__['_collections'] == [None]
    assert cs.__dict__['_collections'] == _ensure_default_collection()

# Generated at 2022-06-23 06:06:35.779379
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert True

# Generated at 2022-06-23 06:06:37.788384
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:06:39.740452
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    # Verify that collections are set
    assert collection_search.collections is not None

# Generated at 2022-06-23 06:06:45.122833
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    cs._collections = ['ansible.builtin', 'ansible.misc']
    assert cs._collections == ['ansible.misc', 'ansible.builtin']


# Generated at 2022-06-23 06:06:48.902192
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(CollectionSearch._collections == None)

# Generated at 2022-06-23 06:06:54.213817
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    # Default value is 'ansible.builtin'
    collect_search = CollectionSearch()
    # The value of _collections is a list
    assert isinstance(collect_search._collections, list)

# Generated at 2022-06-23 06:06:57.074331
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an instance of CollectionSeach
    obj = CollectionSearch()
    # Assert constructor class should return list
    assert isinstance(obj._collections.get_default(None), list)

# Generated at 2022-06-23 06:06:58.823818
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:01.444004
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role import Role
    cs = CollectionSearch()
    role = Role.load({'name': 'test_name'}, {}, [cs])
    assert role._collections == ['ansible.builtin', 'community.general']

# Generated at 2022-06-23 06:07:03.611495
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == None

# Generated at 2022-06-23 06:07:05.647377
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ['ansible.posix', 'ansible.legacy']

# Generated at 2022-06-23 06:07:12.397589
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext

    obj = Base()
    obj.play_context = PlayContext()
    assert (obj.collections == [])
    assert (obj._load_collections('collections', obj.collections) is None)

    obj.collections = ['test']
    assert (obj.collections == ['test'])
    assert (obj._load_collections('collections', obj.collections) == ['test'])

# Generated at 2022-06-23 06:07:15.982426
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    val1 = CollectionSearch()
    assert val1.collections is not None

    val2 = CollectionSearch(collections=[])
    assert val2._collections == []

    instance = CollectionSearch()
    assert instance.post_validate() is True

# Generated at 2022-06-23 06:07:17.476988
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collections = CollectionSearch()
    assert test_collections._collections.default_value is not None

# Generated at 2022-06-23 06:07:20.217644
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj)
    assert obj.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:21.774020
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:07:33.352150
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert not CollectionSearch().get_collections()

    # We purposely pass in an empty list to ensure it does not get the
    # default collection
    assert not CollectionSearch(collections=[]).get_collections()

    # Make sure we don't repeat the default collection in the list
    assert CollectionSearch().get_collections() == ['ansible.builtin']
    assert CollectionSearch().get_collections() == ['ansible.builtin']

    # CollectionSearch should dedup collection names
    assert CollectionSearch(collections=['ansible.builtin', 'ansible.builtin']).get_collections() == ['ansible.builtin']

    # Make sure we insert the default collection
    assert CollectionSearch(collections=['acme.demo']).get_collections() == ['acme.demo', 'ansible.builtin']

# Generated at 2022-06-23 06:07:36.856721
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == _ensure_default_collection()
    assert c.collections == _ensure_default_collection([])
    assert c.collections == _ensure_default_collection(['ansible.foo'])

# Generated at 2022-06-23 06:07:44.888441
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Testing with existing collection
    assert cs._load_collections(None, ["ansible_collections.community.general"]) == ["ansible_collections.community.general"]
    # Testing with non existing collection
    assert cs._load_collections(None, ["ansible_collections.community.general1"]) == ["ansible_collections.community.general1"]
    # Testing with collection with namespace in lowercase
    assert cs._load_collections(None, ["ansible_collections.community"]) == ["ansible_collections.community"]
    # Testing with existing namespace
    assert cs._load_collections(None, ["ansible_collections"]) == ["ansible_collections"]
    # Testing with non existing namespace

# Generated at 2022-06-23 06:07:53.330188
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.plugins.loader import collection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.tasks import ActionModule
    coll_search = CollectionSearch()
    assert coll_search.collections == ['ansible.builtin', 'ansible.legacy']
    assert coll_search._collections == ['ansible.builtin', 'ansible.legacy']
    assert not module_loader._all_found  # Unit test expects all caches to be empty
    assert not collection_loader._get_all_collections()
    assert ActionModule._load_collections(None, None) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:07:54.630644
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch, type)

# Generated at 2022-06-23 06:07:58.073693
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Object(CollectionSearch):
        _collections = ''
    obj = Object()
    assert obj.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:08:01.968247
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default() == _ensure_default_collection.__defaults__[0]

# Generated at 2022-06-23 06:08:03.490999
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None

# Generated at 2022-06-23 06:08:06.751341
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    arg = dict(collections=['testcollection'])
    c = CollectionSearch()
    c.post_validate(None, arg)
    assert c.collections == ['testcollection', 'ansible.builtin']

# Generated at 2022-06-23 06:08:08.028891
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections() is None

# Generated at 2022-06-23 06:08:11.094250
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection is not None


# Generated at 2022-06-23 06:08:13.477711
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == "ansible.builtin,ansible.legacy"

# Generated at 2022-06-23 06:08:14.277967
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default is _ensure_default_collection



# Generated at 2022-06-23 06:08:16.153846
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    context = CollectionSearch()
    assert context._load_collections("collections", []) == None

# Generated at 2022-06-23 06:08:21.551296
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    default_collection = AnsibleCollectionConfig.default_collection

    # This is the same as what would be in the yaml
    ds = []

    # This will test when the default_collection is None
    AnsibleCollectionConfig.default_collection = None
    Search = CollectionSearch()
    test = Search._load_collections('collections', ds)
    assert test == ['ansible.legacy']

    # This will test when the default_collection is set to ansible_collections.nsxt.ns.plugins.module_utils
    AnsibleCollectionConfig.default_collection = 'ansible_collections.nsxt.ns.plugins.module_utils'
    Search = CollectionSearch()
    test = Search._load_collections('collections', ds)

# Generated at 2022-06-23 06:08:22.704058
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    data = '*'
    expect = None
    result = _ensure_default_collection(data)
    assert result == expect

# Generated at 2022-06-23 06:08:28.388923
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testobj = CollectionSearch()
    # test what happens when collections are included
    assert testobj._load_collections('collections', ['one.two']) == ['one.two']
    assert testobj._load_collections('collections', ['one.two', 'three.four']) == ['one.two', 'three.four']
    # test what happens when collections are not included
    assert testobj._load_collections('collections', None) == None

# Generated at 2022-06-23 06:08:29.901902
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.default() == _ensure_default_collection()

# Generated at 2022-06-23 06:08:34.729757
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t_CollectionSearch = CollectionSearch()
    t_CollectionSearch._load_collections(None, 'collections')
    assert t_CollectionSearch


# Generated at 2022-06-23 06:08:35.774131
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    return

# Generated at 2022-06-23 06:08:42.105154
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

    cs = CollectionSearch(collections=[])
    assert cs._collections == _ensure_default_collection(collection_list=[])

    cs = CollectionSearch(collections=['collection1', 'collection2'])
    assert cs._collections == _ensure_default_collection(collection_list=['collection1', 'collection2'])

# Generated at 2022-06-23 06:08:44.396841
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create instance of CollectionSearch
    _collection_search = CollectionSearch()

    # Test __init__()
    assert isinstance(_collection_search, CollectionSearch)


# Generated at 2022-06-23 06:08:47.343701
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()



# Generated at 2022-06-23 06:08:48.866899
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:08:50.264853
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert not collection_search._collections

# Generated at 2022-06-23 06:08:52.132975
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    print(search._collections)

# Generated at 2022-06-23 06:08:53.156001
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()


# Generated at 2022-06-23 06:09:01.651866
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def _ensure_default_collection(collection_list=None):
        default_collection = AnsibleCollectionConfig.default_collection
        # Will be None when used as the default
        if collection_list is None:
            collection_list = []

        # FIXME: exclude role tasks?
        if default_collection and default_collection not in collection_list:
            collection_list.insert(0, default_collection)

        # if there's something in the list, ensure that builtin or legacy is always there too
        if collection_list and 'ansible.builtin' not in collection_list and 'ansible.legacy' not in collection_list:
            collection_list.append('ansible.legacy')

        return collection_list
    # checking default
    test_object = CollectionSearch()
    assert test_object._collections == _ensure_

# Generated at 2022-06-23 06:09:04.034272
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections
    assert c._collections.default() == ['ansible.builtin']

# Generated at 2022-06-23 06:09:05.295303
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ['ansible.builtin']

# Generated at 2022-06-23 06:09:06.677701
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:07.665571
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-23 06:09:10.234185
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:14.056241
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)

    # See if the default value of _collections is present
    assert obj._collections == _ensure_default_collection()


# Unit Test for function _ensure_default_collection

# Generated at 2022-06-23 06:09:16.138835
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.collection_list == _ensure_default_collection()

# Generated at 2022-06-23 06:09:18.954599
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin']
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:09:28.202512
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._load_collections([], []) == None
    assert search._load_collections([], ['ansible.builtin']) == ['ansible.builtin']
    assert search._load_collections([], ['ansible.builtin', 'my_collection']) == ['my_collection', 'ansible.builtin']
    assert search._load_collections([], ['my_collection']) == ['my_collection', 'ansible.builtin']
    assert search._load_collections([], ['my_collection']) == ['my_collection', 'ansible.builtin']
    assert search._load_collections([], [{'ansible.builtin'}]) == ['ansible.builtin', 'ansible.builtin']

# Generated at 2022-06-23 06:09:38.211807
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    C = CollectionSearch()
    assert C._collections._default == _ensure_default_collection
    assert C._collections._priority == 100
    assert C._collections.always_post_validate
    assert C._collections.static
    assert C._collections.isa == 'list'
    assert C._collections.listof == string_types
    assert C._collections.required == False
    assert C._collections.static

    assert C.collections == _ensure_default_collection()
    assert C.collections is not None

# Generated at 2022-06-23 06:09:39.127750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch


# Generated at 2022-06-23 06:09:49.354321
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) is None

    cs = CollectionSearch()
    assert cs._load_collections(None, ['test.collection']) == ['test.collection']

    cs = CollectionSearch()
    assert cs._load_collections(None, ['test.collection', 'ansible.builtin']) == ['test.collection']

    cs = CollectionSearch()
    assert cs._load_collections(None, []) == ['ansible.builtin']

    cs = CollectionSearch()
    assert cs._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-23 06:09:52.722156
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass

    tc = TestCollectionSearch()
    assert tc._collections == _ensure_default_collection()
    assert tc._load_collections(None, None) is None

# Generated at 2022-06-23 06:09:56.374612
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.collections = ['ansible.collection1', 'ansible.collection2']
    assert collection_search._load_collections(None, None) == ['ansible.collection1', 'ansible.collection2']

# Generated at 2022-06-23 06:09:59.677164
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Dummy():
        def __init__(self):
            pass
    search = CollectionSearch(Dummy())
    assert (search._collections is not None)

# Generated at 2022-06-23 06:10:04.001725
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    # check if _collections is created
    assert a._collections
    # check if _collections is a list
    assert type(a._collections) is list


# Generated at 2022-06-23 06:10:05.417764
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.posix']

# Generated at 2022-06-23 06:10:12.106252
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    my_CollectionSearch = CollectionSearch()
    my_CollectionSearch.post_validate()
    assert my_CollectionSearch._collections == _ensure_default_collection()
    # assert type(my_CollectionSearch) == IncludeRole
    # assert type(my_CollectionSearch) == Block
    # assert type(my_CollectionSearch) == Role

# Generated at 2022-06-23 06:10:15.481350
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()
    assert col_search._load_collections(col_search._collections, []) == None
    assert col_search._load_collections(col_search._collections, None) == None

# Generated at 2022-06-23 06:10:17.809770
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default is _ensure_default_collection

# Generated at 2022-06-23 06:10:19.677628
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    Obj = CollectionSearch()
    path = Obj._load_collections("",[])
    assert path == None

# Generated at 2022-06-23 06:10:29.454916
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._load_collections("", "") is None
    assert list(collection._load_collections("", ["test"])) == ["test", "ansible.legacy"]
    assert list(collection._load_collections("", ["test", "ansible"])) == ["test", "ansible", "ansible.legacy"]
    assert list(collection._load_collections("", ["test", "ansible"])) == ["test", "ansible", "ansible.legacy"]
    assert list(collection._load_collections("", ["test", "ansible.builtin"])) == ["test", "ansible.builtin", "ansible.legacy"]


# Generated at 2022-06-23 06:10:32.066570
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c



# Generated at 2022-06-23 06:10:34.045750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj.__init__()
    assert obj

# Generated at 2022-06-23 06:10:36.172298
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections is not None

# Generated at 2022-06-23 06:10:42.796481
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    # check if '_collections' is a instance variable and it has all the right values
    assert isinstance(test._collections, FieldAttribute)
    assert test._collections.isa == 'list'
    assert test._collections.listof == string_types
    assert test._collections.priority == 100
    assert test._collections.default == _ensure_default_collection
    assert test._collections.always_post_validate
    assert test._collections.static


# Generated at 2022-06-23 06:10:45.079931
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch._collections is None

# Generated at 2022-06-23 06:10:49.614842
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible import errors

    try:
        cs = CollectionSearch()
        
        assert cs._collections == ['ansible_collection.wechat'], "Test Failed"
    except Exception as e:
        errors.AnsibleError(error_message='An error occurred: %s' % e)

# Generated at 2022-06-23 06:10:51.652953
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj.__dict__)
    assert(obj.__dict__['_collections'] == _ensure_default_collection())

# Generated at 2022-06-23 06:10:59.205638
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    y = CollectionSearch()
    assert y._collections == ['ansible.posix', 'ansible.builtin']
    assert y._load_collections(None, ['ansible.posix']) == ['ansible.posix', 'ansible.builtin']
    assert y._load_collections(None, None) == ['ansible.posix', 'ansible.builtin']
    assert y._load_collections(None, []) == ['ansible.posix', 'ansible.builtin']

# Generated at 2022-06-23 06:11:01.320524
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    collections._load_collections()

# Generated at 2022-06-23 06:11:04.393161
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert isinstance(search, CollectionSearch)

    assert search.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:09.772198
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an instance of CollectionSearch
    collection_search = CollectionSearch()

    # Test to see if the constructor sets the correct FieldAttribute for collections
    assert collection_search._collections.__dict__['_default'] == _ensure_default_collection



# Generated at 2022-06-23 06:11:12.492291
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    c._load_collections('collections', ['ansible.builtin'])
    assert c._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:11:14.527482
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj1 = CollectionSearch()
    obj1.post_validate()
    assert obj1.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:16.228335
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(CollectionSearch()._collections == _ensure_default_collection(None))

# Generated at 2022-06-23 06:11:18.636673
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_search = CollectionSearch()
    assert test_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:22.705795
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    
    # Create a CollectionSearch instance
    collectionSearch = CollectionSearch()
    
    # Test that this instance has the right attributes
    assert hasattr(collectionSearch, "_collections")
    assert hasattr(collectionSearch, "_load_collections")

# Generated at 2022-06-23 06:11:24.074547
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Testing creation of object
    c = CollectionSearch()
    assert c is not None

# Generated at 2022-06-23 06:11:25.519009
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_search = CollectionSearch()
    assert coll_search._collections == ['ansible.legacy']



# Generated at 2022-06-23 06:11:27.567605
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    Display.warning = Display.debug

    with pytest.raises(AssertionError):
        disp = Display()

# Generated at 2022-06-23 06:11:28.684415
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_collections = CollectionSearch()
    assert my_collections is not None

# Generated at 2022-06-23 06:11:31.975919
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # collection = CollectionSearch()
    # print(collection._load_collections())
    pass


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:11:33.414727
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs.collections, list)

# Generated at 2022-06-23 06:11:38.699186
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.__dict__["_collections"] == ['ansible.builtin']

    c = CollectionSearch({'collections': ['foo.bar']})
    assert c.__dict__["_collections"] == ['foo.bar', 'ansible.builtin']

# Generated at 2022-06-23 06:11:40.825094
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.static
    assert c._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:11:48.963307
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Verify that the default value for the collections are
    # ['ansible.builtin','ansible.legacy'] and no other collection.
    cs.__dict__.update(collections = ['ansible.builtin','ansible.legacy'])
    assert cs.collections == cs._load_collections("collections", None)
    # Verify that the default value for the collections are
    # ['ansible.builtin','ansible.legacy'] when no collection is specified
    cs.__dict__.update(collections = [])
    assert cs.collections == cs._load_collections("collections", None)
    # Verify that the default value for the collections are
    # ['ansible.builtin','ansible.legacy'] even if the list has only one collection
    cs.__dict__.update

# Generated at 2022-06-23 06:11:51.572317
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    assert collection_search._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:12:02.367330
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.static == True
    assert CollectionSearch._collections.isa == 'list'
    assert CollectionSearch._collections.listof == string_types
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.always_post_validate == True

    # When CollectionSearch is used as a stand-alone class, load_collections() returns None
    _collections = CollectionSearch()
    assert _collections._load_collections(attr=None, ds=None) == None

    # When CollectionSearch is used as a stand-alone class, load_collections() returns a list of collections
    _collections = CollectionSearch(collections=[])
    assert _collections._load_collections(attr=None, ds=[])

# Generated at 2022-06-23 06:12:13.477291
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.module_utils.facts import is_collection_rooted_task_include
    def __init__(self, role_definition, role_path, task_include, _role=None, **kwargs):
        assert isinstance(role_definition, RoleDefinition)
        assert isinstance(role_path, string_types)
        assert isinstance(task_include, string_types)
        assert task_include.endswith('.yml')
        assert isinstance(_role, string_types) or _role is None
        self._role_definition = role_definition


# Generated at 2022-06-23 06:12:15.100886
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)



# Generated at 2022-06-23 06:12:18.301733
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    loader = CollectionSearch()
    loader._collections = ['ansible.legacy']
    print("loader._collections", loader._collections)
    loader._load_collections("_collections", loader._collections)


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:12:21.544238
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()
    assert cs._collections.static == True


# Generated at 2022-06-23 06:12:32.257002
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from collections import namedtuple

    class Fake:
        pass
    fake = Fake()
    fake.__dict__ = dict()

    class FakeSearch:
        Fake_namespace = namedtuple('Fake_namespace', ['collections'])
        namespace = Fake_namespace(collections=None)
    fake.__class__.__bases__ = (CollectionSearch,)
    search = fake._load_collections('collections', None)
    assert search is None

    class FakeSearch:
        Fake_namespace = namedtuple('Fake_namespace', ['collections'])
        namespace = Fake_namespace(collections='my.namespace')
    fake.__class__.__bases__ = (CollectionSearch,)
    search = fake._load_collections('collections', None)
    assert search is not None
    assert search

# Generated at 2022-06-23 06:12:42.358393
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search1 = CollectionSearch()
    search1.post_validate(loader=None, templar=None)
    assert(search1._collections is not None)

    search2 = CollectionSearch()
    search2.collections = [u'ntc-ansible.ntc-templates_0.2.2']
    assert(search2._collections == [u'ntc-ansible.ntc-templates_0.2.2'])
    search2.post_validate(loader=None, templar=None)
    assert(search2._collections == [u'ntc-ansible.ntc-templates_0.2.2'])


test_CollectionSearch()

# Generated at 2022-06-23 06:12:49.000437
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._load_collections('collections', 'whatever.collection') == None
    assert collection._load_collections('collections', None) == None
    assert collection._load_collections('collections', ['']) == None
    assert collection._load_collections('collections', []) == None
    # TODO: don't have a good example to test this
    #assert collection._load_collections('collections', ['']) == None

# Generated at 2022-06-23 06:12:55.675129
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = _ensure_default_collection()
    assert(result is not None)
    assert(len(result) == 1)
    assert(result[0] == 'ansible.builtin')

    result = _ensure_default_collection(['test'])
    assert(result is not None)
    assert(len(result) == 2)
    assert(result[0] == 'test')
    assert(result[1] == 'ansible.builtin')

# Generated at 2022-06-23 06:13:02.885277
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Setup
    collection_search = CollectionSearch()

    # Assertions
    assert hasattr(collection_search, '_load_collections')
    assert hasattr(collection_search, '_collections')

# Generated at 2022-06-23 06:13:03.487054
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()

# Generated at 2022-06-23 06:13:06.321160
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is not None
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:13:13.512425
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # import CollectionSearch class
    from ansible.playbook.role.definition import CollectionSearch

    # create instance of CollectionSearch class
    collectionsearch_instance = CollectionSearch()

    # test CollectionSearch class constructor
    assert collectionsearch_instance._collections.isa == 'list'
    assert collectionsearch_instance._collections.listof == string_types
    assert collectionsearch_instance._collections.priority == 100
    assert collectionsearch_instance._collections.default == collectionsearch_instance._ensure_default_collection
    assert collectionsearch_instance._collections.always_post_validate == True
    assert collectionsearch_instance._collections.static == True