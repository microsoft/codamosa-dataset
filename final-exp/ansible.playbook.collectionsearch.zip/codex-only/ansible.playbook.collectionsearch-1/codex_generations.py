

# Generated at 2022-06-23 06:03:16.848121
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    def validate_collections():
        import ansible.constants as C

        # NOTE: this still depends on the constant value, not the attribute
        default_collection = C.DEFAULT_COLLECTION_NAME

        # Will be None when used as the default
        if collection_list is None:
            collection_list = []

        # FIXME: exclude role tasks?
        if default_collection and default_collection not in collection_list:
            collection_list.insert(0, default_collection)

        # if there's something in the list, ensure that builtin or legacy is always there too
        if collection_list and 'ansible.builtin' not in collection_list and 'ansible.legacy' not in collection_list:
            collection_list.append('ansible.legacy')

        return collection_list
    # test case 1
    collection

# Generated at 2022-06-23 06:03:17.899938
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    print(search)

# Generated at 2022-06-23 06:03:19.216556
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:03:22.478763
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin']
    assert c._collections == c.collections
    assert c._collections == ['ansible.builtin']

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:03:25.137785
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    import collections
    assert isinstance(search._collections, collections.Iterable)

# Generated at 2022-06-23 06:03:34.657681
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.taggable import Taggable

    cs = CollectionSearch()
    cs.populate_instance(Base)
    cs.populate_instance(Taggable)

    # test with collection_list
    # FIXME: validate this test
    cs.get_validated_value('collections', cs._collections, ['ansible_collections.example'], None)
    assert cs.collections == ['ansible_collections.example', 'ansible.builtin']

    # test without collection_list
    cs.get_validated_value('collections', cs._collections, [], None)
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:03:38.853212
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ansible_collections_name = "test"
    # an instance of the class: CollectionSearch
    collection_search = CollectionSearch()
    collection_list = collection_search._load_collections(collection_search._collections, ansible_collections_name)
    # assert to check the first element in the collection_list
    assert collection_list == None

# Generated at 2022-06-23 06:03:44.046669
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.get_validated_value('collections', collection_search._collections) == ['ansible_collections.ansible.builtin', 'ansible.builtin']
    assert collection_search.get_validated_value('collections', collection_search._collections, ['ns1.collection']) == ['ns1.collection', 'ansible.builtin']

# Generated at 2022-06-23 06:03:50.122889
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin', 'ansible.legacy']
    assert c._collections == ['ansible.builtin', 'ansible.legacy']
    assert c._load_collections('collections', []) == None
    assert c._load_collections('collections', ['test.test']) == ['test.test']
    assert c._load_collections('collections', ['test.test','ansible.builtin','foo.bar']) == ['test.test','ansible.builtin','foo.bar']

# Generated at 2022-06-23 06:03:52.153400
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == 'ansible.builtin,ansible.legacy'

# Generated at 2022-06-23 06:03:54.104164
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    a._load_collections(None,None)

# Generated at 2022-06-23 06:04:01.497438
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base

    class MyBase(Base, CollectionSearch):
        pass

    assert MyBase.collections._static is True
    assert isinstance(MyBase.collections.default, staticmethod)
    assert isinstance(MyBase.collections.always_post_validate, staticmethod)

    assert MyBase(collections=['foo']).collections == ['foo', 'ansible.builtin']
    assert MyBase(collections=['foo', 'ansible.builtin']).collections == ['foo', 'ansible.builtin']
    assert MyBase(collections=[AnsibleCollectionConfig.default_collection]).collections == [AnsibleCollectionConfig.default_collection, 'ansible.builtin']

# Generated at 2022-06-23 06:04:04.137665
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections._static
    assert collection_search._collections._always_post_validate

# Generated at 2022-06-23 06:04:10.216715
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch._collections, FieldAttribute)
    assert CollectionSearch._collections.type == 'list'
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.static
    assert CollectionSearch._collections.priority == 100

# Generated at 2022-06-23 06:04:12.362165
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Ensure that CollectionSearch class is constructed without errors
    """
    collection = CollectionSearch()
    assert collection is not None



# Generated at 2022-06-23 06:04:14.375865
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c_search = CollectionSearch()
    assert isinstance(c_search, CollectionSearch)



# Generated at 2022-06-23 06:04:14.932265
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-23 06:04:19.823467
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Prepare test data
    test_data = {'collections': ['test_collections']}
    attr = 'collections'
    ds = 'test_collections'

    # Construct class
    collection_search = CollectionSearch()

    # Call function
    result = collection_search._load_collections(attr, ds)

    # Assert results
    assert result == test_data['collections']

# Generated at 2022-06-23 06:04:21.878726
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch is not None

# Generated at 2022-06-23 06:04:23.902566
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._load_collections('', None) is None

# Generated at 2022-06-23 06:04:24.992303
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    assert col._collections

# Generated at 2022-06-23 06:04:27.931096
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_class = CollectionSearch()
    test_class._collections = _ensure_default_collection
    test_class._collections()
    test_class._load_collections()

# Generated at 2022-06-23 06:04:29.301525
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    print(x._collections)

# Generated at 2022-06-23 06:04:33.496109
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()

    # Ensure that _collections gets updated by _ensure_default_collection()
    assert test_instance._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:35.019846
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(CollectionSearch())

# Unit test to search collection

# Generated at 2022-06-23 06:04:36.468637
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:37.535018
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:04:46.724331
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # We are going to run this test only when AnsibleCollections doesn't exist
    # AnsibleCollections should set the _collections attribute in a way
    # it doesn't need this test
    if not AnsibleCollectionConfig.is_ansible_collections_installed():
        # CollectionSearch._collections should be a list and len should be 1
        # when not AnsibleCollections and default_collection is None
        # (value is set in AnsibleCollectionConfig.default_collection
        collection_search = CollectionSearch()
        assert isinstance(collection_search._collections, list)
        assert len(collection_search._collections) == 1

        # Set the default_collection and CollectionSearch._collections should be a 
        # list and len should be equal to 2
        AnsibleCollectionConfig.default_collection = 'dummy_value'
        collection_

# Generated at 2022-06-23 06:04:55.157583
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play.base import Base
    import ansible.utils.collection_loader as loader
    import ansible.module_utils.connection.connection_loader as connection_loader
    import ansible.module_utils.network.network_loader as network_loader
    # Import ansible.module_utils to register the loaders
    import ansible.module_utils
    import ansible.module_utils.common.validation as validation

    def _mock_load_collections(attr, ds):
        ds = self.get_validated_value('collections', self._collections, ds, None)

        # this will only be called if someone specified a value; call the shared value
        _ensure_default_collection(collection_list=ds)

       

# Generated at 2022-06-23 06:05:03.383407
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.objects import AnsibleUnicode
    c = CollectionSearch()
    block = Block()
    assert c._collections(block, None) == ['ansible.builtin']

    # check if the constructor can run properly with a collection name
    name = AnsibleUnicode('ceph.ceph-ansible')
    role = Role(name, {})
    assert c._collections(role, None) == ['ceph.ceph-ansible']

# Generated at 2022-06-23 06:05:10.193376
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test the constructor handling collection_list
    test_obj = CollectionSearch()
    assert test_obj._collections._field_used is True
    assert test_obj._collections._value == _ensure_default_collection()
    # Test the constructor handling default_collection
    AnsibleCollectionConfig.default_collection = "test"
    test_obj = CollectionSearch()
    assert test_obj._collections._value == ["test", "ansible.builtin", "ansible.legacy"]



# Generated at 2022-06-23 06:05:14.027144
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = 'ansible.builtin'
    obj = CollectionSearch(ds)

    ds = {'collections' : ['ansible.builtin']}
    obj = CollectionSearch(ds)

# Generated at 2022-06-23 06:05:22.504331
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    import ansible.playbook.role.requiremen
    import ansible.playbook.role
    import ansible.playbook.task.include_role
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.play
    import ansible.playbook.playbook
    assert(issubclass(CollectionSearch, RoleDefinition))
    assert(issubclass(CollectionSearch, PlayContext))
    assert(issubclass(CollectionSearch, Block))
    assert(issubclass(CollectionSearch, ansible.playbook.role.requiremen.RoleRequirement))

# Generated at 2022-06-23 06:05:31.707225
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    _display_object = display

    _collection_search = CollectionSearch()
    collection_list = None
    _collection_list = _ensure_default_collection(collection_list)
    assert len(_collection_list) == 1
    assert _collection_list[0] == 'ansible.legacy'

    collection_list = ['one', 'two']
    _collection_list = _ensure_default_collection(collection_list)
    assert len(_collection_list) == 3
    assert _collection_list[0] == 'one'
    assert _collection_list[1] == 'two'
    assert _collection_list[2] == 'ansible.legacy'

# Generated at 2022-06-23 06:05:33.871070
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default == ['ansible.builtin']

# Generated at 2022-06-23 06:05:37.890717
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections is None
    assert CollectionSearch(collections=['ansible.builtin']).collections == ['ansible.builtin']
    assert CollectionSearch(collections=['ansible.builtin','test']).collections == ['test','ansible.builtin']

# Generated at 2022-06-23 06:05:39.815288
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert len(collection_search._collections.default) != 0

# Generated at 2022-06-23 06:05:49.114862
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from units.mock.loader import DictDataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars import MutableVars

    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)
    variable_manager._fact_cache = dict()
    variable_manager.set_nonpersistent_facts(dict())
    variable_manager.extra_vars = MutableVars({"collections": "unit_test_collections"})
    variable_manager.options_vars = MutableVars({"collections": "unit_test_collections"})
    variable_manager.extra_vars.update(variable_manager.options_vars)


# Generated at 2022-06-23 06:05:57.987461
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class TestCollection(CollectionSearch):
        # Dummy class for unit test of constructor
        # pylint: disable=too-many-instance-attributes

        def __init__(self):
            super(CollectionSearch, self).__init__()
            self._collections = None

        def _load_collections(self, attr, ds):
            # _load_collections is not allowed to be called with the
            # constructor, so this method should not be invoked
            return "Test"

    test_collection = TestCollection()

    # test if _load_collections has not been called
    assert test_collection._collections is None

# Generated at 2022-06-23 06:06:01.874753
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test for collection field is initialized
    collectionsearch = CollectionSearch()
    assert collectionsearch._collections
    # Test for collection validation
    assert collectionsearch.get_validated_value('collections', collectionsearch._collections, 'ansible.builtin', None) == ['ansible.builtin']

# Generated at 2022-06-23 06:06:04.745015
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-23 06:06:06.134035
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert isinstance(search, CollectionSearch)

# Generated at 2022-06-23 06:06:07.405613
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # TODO: Test with collections
    collection_search = CollectionSearch()

# Generated at 2022-06-23 06:06:08.542719
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch, object)

# Generated at 2022-06-23 06:06:14.449942
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is _ensure_default_collection
    assert cs.collections == _ensure_default_collection()
    assert cs._collections(None) == _ensure_default_collection()
    assert cs.collections is None
    # Test the _load_collections() method
    assert cs.collections == _ensure_default_collection(None)
    assert cs.collections == _ensure_default_collection([])

# Generated at 2022-06-23 06:06:16.669379
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Test constructor of class CollectionSearch"""
    c = CollectionSearch()


# Generated at 2022-06-23 06:06:24.062313
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import json
    import sys

    if sys.version_info >= (3, 0):
        unicode = str

    # Test when collection_list is None
    collection_list = None
    test_obj = CollectionSearch()
    result = test_obj._ensure_default_collection(collection_list)
    assert result == ['ansible_collections.ansible.builtin']

    # Test when collection_list is list with one item
    collection_list = ['test_collection1']
    result = test_obj._ensure_default_collection(collection_list)
    assert result == ['test_collection1', 'ansible_collections.ansible.builtin']

    # Test when collection_list is list with two items
    collection_list = ['test_collection1', 'test_collection2']
    result = test_obj._ensure

# Generated at 2022-06-23 06:06:25.558923
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-23 06:06:33.516690
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    loader = AnsibleCollectionConfig()
    collection_name = 'test.namespace'
    loader.set_collection_playbook_path(collection_name,['/some/path/some/file'])
    role_name = 'some_role'
    loader.set_collection_role_path(collection_name, role_name, ['/some/path/some/file'])
    task_name = 'some_task'
    loader.set_collection_task_path(collection_name, task_name, ['/some/path/some/file'])
    module_name = 'some_module'
    loader.set_collection_module_path(collection_name, module_name, ['/some/path/some/file'])
    plugin_name = 'some_plugin'

# Generated at 2022-06-23 06:06:35.930864
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:06:38.421410
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch()
    if d is None:
        assert False, "CollectionSearch class constructor failed."
    else:
        assert True


# Generated at 2022-06-23 06:06:40.600834
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection([])

# Generated at 2022-06-23 06:06:47.755483
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Test case where collection_list is None
    collection_list = None
    collection_expected = ['ansible_collections.community.general']
    assert _ensure_default_collection(collection_list) == collection_expected
    #Test case where collection_list is empty
    collection_list = []
    assert _ensure_default_collection(collection_list) == collection_expected
    #Test case where collection_list is populated
    collection_list = ['col1.collection1']
    assert _ensure_default_collection(collection_list) == ['col1.collection1', 'ansible_collections.community.general']

# Generated at 2022-06-23 06:06:49.475679
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    if collection._collections == _ensure_default_collection():
        assert True
    else:
        assert False

# Generated at 2022-06-23 06:06:52.702573
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    module_args = dict(collections = ['community.general','ansible.builtin','ansible.legacy'])
    myobj = CollectionSearch()
    myobj.load_from_module_args(module_args)
    value = myobj.get_value('collections')
    assert isinstance(value, list)



# Generated at 2022-06-23 06:06:55.992244
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    object = CollectionSearch()
    assert object.get_validated_value('collections', object._collections, ['ansible.builtin'], None) is not None

# Generated at 2022-06-23 06:07:03.871697
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Tasks(CollectionSearch):
        def post_validate(self, attr, value):
            super(CollectionSearch, self).post_validate(attr, value)
            # this will test the collections are correctly returned
            print(self.get('collections'))

    class Handler(CollectionSearch):
        def post_validate(self, attr, value):
            super(CollectionSearch, self).post_validate(attr, value)
            # this will test the collections are correctly returned
            print(self.get('collections'))

    class Task(CollectionSearch):
        def post_validate(self, attr, value):
            super(CollectionSearch, self).post_validate(attr, value)
            # this will test the collections are correctly returned
            print(self.get('collections'))


# Generated at 2022-06-23 06:07:06.676520
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_test_class = CollectionSearch();
    assert my_test_class._load_collections('collections', ds=[]);

# Generated at 2022-06-23 06:07:07.665119
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.posix']

# Generated at 2022-06-23 06:07:11.967581
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is None

    cs = CollectionSearch(collections=[])
    assert cs.collections is None

    cs = CollectionSearch(collections=['collection.ns'])
    assert cs.collections == ['collection.ns', 'ansible.legacy']

# Generated at 2022-06-23 06:07:14.029753
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection(collection_list=None)

# Generated at 2022-06-23 06:07:18.389414
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.plugins.loader import collection_loader

    collections = [
        'ansible.builtin',
        'somenamespace.othercollection',
        'mycollection'
    ]

    # test constructor with collections argument
    s = CollectionSearch(collections=collections)
    assert(s._collections == collections)

    # test constructor without collections argument
    s = CollectionSearch()
    assert(s._collections == collections)

    # test _ensure_default_collection with no argument
    assert(_ensure_default_collection() == collections)

    # test _ensure_default_collection with argument
    collections3 = [
        'somenamespace.othercollection',
        'mycollection'
    ]
    assert(_ensure_default_collection(collections3) == collections)

    # test constructor with collections argument but no

# Generated at 2022-06-23 06:07:19.421860
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections is not None

# Generated at 2022-06-23 06:07:28.502288
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # assert that member with _collections has value [{},'ansible.builtin'] if no value is passed
    assert cs.collections == [{},'ansible.builtin']
    # assert that member with _collections has value ['ansible.builtin', 'ansible_namespace.collection'] if value ['ansible_namespace.collection'] is passed
    cs.collections = ['ansible_namespace.collection']
    assert cs.collections == ['ansible_namespace.collection','ansible.builtin']
    # assert that member with _collections has value ['ansible.builtin', 'ansible_namespace.collection', 'ansible_namespace.collection1'] if value ['ansible_namespace.collection', 'ansible_namespace.collection1'] is passed

# Generated at 2022-06-23 06:07:40.582501
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()
    assert cs._collections.default == ['ansible.builtin']
    assert cs._collections.default == _ensure_default_collection(None)
    assert cs._collections.default == ['ansible.builtin']

    assert cs._collections.default ==  _ensure_default_collection([''])
    assert cs._collections.default !=  _ensure_default_collection(['ansible.builtin'])
    assert cs.get_value('collections') == _ensure_default_collection([''])
    assert cs.get_value('collections') == ['ansible.builtin']

    assert cs.get_value('collections') == _ensure_default_collection(['example.collection'])

# Generated at 2022-06-23 06:07:42.648345
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # load the CollectionSearch class
    CollectionSearch()
    print("Execution completed")

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:07:46.725612
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class testcollection(CollectionSearch):
        def __init__(self, collections=[]):
            if collections != []:
                super(testcollection, self).__init__(collections=collections)

    collections = ['ansible.builtin', 'ansible.legacy', 'awx.awx', 'chocolatey.chocolatey', 'community.general']
    testcol = testcollection(collections=collections)
    assert testcol._collections_load == collections


# Generated at 2022-06-23 06:07:50.613621
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test __init__()

    # Test with no argument provided
    cs1 = CollectionSearch()
    assert cs1._collections == _ensure_default_collection()

    # Test with argument provided
    collection_list = ['my_namespace.my_collection']
    cs2 = CollectionSearch(collection_list=collection_list)
    assert cs2._collections == _ensure_default_collection(collection_list=collection_list)



# Generated at 2022-06-23 06:07:53.316594
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections is _ensure_default_collection

# Generated at 2022-06-23 06:07:55.962852
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collections = collection_search.get_collections()
    assert collections is not None

# Generated at 2022-06-23 06:08:03.301505
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # Tested method
    assert cs._load_collections('collections', None) is None

    # Tested method
    assert cs._load_collections('collections', ['ansible_collections.my.collection_name']) == ['ansible_collections.my.collection_name', 'ansible.legacy']

    # Tested method
    assert cs._load_collections('collections', ['ansible.builtin', 'ansible_collections.my.collection_name']) == ['ansible_collections.my.collection_name', 'ansible.builtin']

# Generated at 2022-06-23 06:08:05.220578
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:08:06.602550
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    collections.collections = ['ansible.builtin']
    collections.post_validate()

# Generated at 2022-06-23 06:08:08.245305
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()
    assert(coll.collections == ['ansible.builtin', 'ansible.legacy'])

# Generated at 2022-06-23 06:08:11.300774
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == []

# Generated at 2022-06-23 06:08:20.026903
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Will fail if not all the methods are defined and if the class does not exist
    try:
        from ansible.playbook.role_includes import RoleInclude
        from ansible.playbook.task_include import TaskInclude
        from ansible.playbook.handler_include import HandlerInclude
        from ansible.playbook.block import Block
        from ansible.playbook.play_context import PlayContext
        x = CollectionSearch()
        
        y = RoleInclude()
        y = TaskInclude()
        y = HandlerInclude()
        y = Block()
        y = PlayContext()
    except Exception:
        assert False


# Generated at 2022-06-23 06:08:22.211940
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch(loader=None,play=None)
    result = search._load_collections(attr={},ds={})
    assert result == ['ansible.builtin']

# Generated at 2022-06-23 06:08:25.283094
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default() == cs._ensure_default_collection()


# Main method for unit test
if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:08:34.066076
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("\nTesting constructor of class CollectionSearch")
    print("\nConstructing a CollectionSearch class object...")
    search = CollectionSearch()
    print("Done!")
    print("\nCollectionSearch class object created!")
    print("\nTesting _load_collections method of class CollectionSearch")
    search._load_collections(None, None)
    print("\nDone!")
    print("\nTesting _load_collections method of class CollectionSearch passed!")
    print("\nTesting constructor of class CollectionSearch passed!")

#Testing class CollectionSearch
test_CollectionSearch()

# Generated at 2022-06-23 06:08:43.234850
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert (search._load_collections('collections', ["my.namespace"]) == ["my.namespace", 'ansible.builtin'])
    assert (search._load_collections('collections', ['my.namespace', 'my.namespace']) == ['my.namespace', 'my.namespace', 'ansible.builtin'])
    assert (search._load_collections('collections', ['ansible.requires']) == ['ansible.requires', 'ansible.builtin'])
    assert (search._load_collections('collections', None) == ['ansible.builtin'])

# Generated at 2022-06-23 06:08:48.712744
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        # create CollectionSearch class object
        cs = CollectionSearch()
        # if object creation is successful
        # then no error will be raised and
        # this statement will be printed
        print("CollectionSearch object is created successfully")
    except:
        print("error: unable to create CollectionSearch object")

# Generated at 2022-06-23 06:08:52.589753
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert collection_search._collections == _ensure_default_collection()
    assert collection_search.collections == _ensure_default_collection()


# Generated at 2022-06-23 06:08:54.134944
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert not hasattr(obj, '_collections')

# Generated at 2022-06-23 06:08:59.117748
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.get_validated_value("collections", collection_search._collections, None, None) is None

    collection_search = CollectionSearch(collections=["collection1", "collection2"])
    assert collection_search.get_validated_value("collections", collection_search._collections, None, None) == ["collection1", "collection2"]

# Generated at 2022-06-23 06:09:08.774892
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    import sys

    sys.path.append('/')
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = '/etc/ansible/playbooks'

    col = CollectionSearch()
    ansible_builtin_collection = 'ansible.builtin'
    ansible_legacy_collection = 'ansible.legacy'
    assert col.collections == None
    col.collections = []
    assert col.collections != None
    assert col.collections[0] == ansible_builtin_collection
    assert col.collections[1] == ansible_legacy_collection
    assert len(col.collections) == 2
    col.collections = [ansible_builtin_collection]
    assert col.collections[0] == ansible_builtin_collection

# Generated at 2022-06-23 06:09:10.783406
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert isinstance(instance,CollectionSearch)
    assert isinstance(instance.get_validated_value('collections', instance._collections, ['ansible.builtin'], None),list)


if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:09:11.377489
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-23 06:09:12.992989
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:14.017956
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test that the constructor runs when called directly
    a = CollectionSearch()



# Generated at 2022-06-23 06:09:16.084949
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:09:17.919570
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:19.523424
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections is None

# Generated at 2022-06-23 06:09:21.878822
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_search = CollectionSearch()
    assert test_collection_search._load_collections('collections', None) is not None

# Generated at 2022-06-23 06:09:24.890225
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Call the constructor of class CollectionSearch
    cs = CollectionSearch()
    # Check if the attribute _collection is set
    assert hasattr(cs, '_collections')

# Generated at 2022-06-23 06:09:27.454545
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        cs = CollectionSearch()
        assert(cs)
        assert(cs._collections == _ensure_default_collection())
    except Exception as e:
        raise Exception('CollectionSearch failed with exception:', e)

# Generated at 2022-06-23 06:09:33.649477
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections == _ensure_default_collection()
    assert a._collections != _ensure_default_collection(collection_list=["my.sample.collection.name"])
    assert a._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:39.101611
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # no parameter
    collection_search = CollectionSearch()
    assert 'collections' in collection_search._get_validatable_attributes()

    # parameter, set metadata is empty
    collection_search = CollectionSearch(metadata=dict())
    assert 'collections' in collection_search._get_validatable_attributes()

# Generated at 2022-06-23 06:09:50.865997
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test(CollectionSearch):
        def __init__(self):
            self._collections = []
        def get_validated_value(self, name, attr, value, args):
            return self._collections
    test = Test()

    # test with no collections (none by default)
    assert test._load_collections(None, None) == None

    # test with default collection
    test._collections = ['ansible.builtin']
    assert test._load_collections(None, None) == ['ansible.builtin', 'ansible.legacy']

    # test with user collection
    test._collections = ['user.collection']
    assert test._load_collections(None, None) == ['user.collection', 'ansible.builtin', 'ansible.legacy']

    # test with user collection and a legacy

# Generated at 2022-06-23 06:09:52.328296
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:09:54.742651
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert (isinstance(cs, CollectionSearch))

test_CollectionSearch()

# Generated at 2022-06-23 06:09:56.715374
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search = CollectionSearch()
        print("CollectionSearch instance created!")
    except:
        print("Failed to create an instance of class CollectionSearch")


# Generated at 2022-06-23 06:10:06.516739
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task.include_task import TaskInclude

    task_block = Block()
    block_include_task = TaskInclude()
    task_include_role = RoleRequirement()
    task_block.block = task_include_role
    block_include_task.block = task_block
    role_definition = RoleDefinition(name="test", collection_name="test", tasks=[block_include_task])
    cs = CollectionSearch()
    role_definition.post_validate(cs)
    cs.collections = None
    cs.post_validate()

# Generated at 2022-06-23 06:10:09.421681
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    test_list = ['test1','test2','test3']
    search.collections = test_list
    assert search.collections == test_list

# Generated at 2022-06-23 06:10:11.460530
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:10:17.653464
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    ds = {
        "collections": [
            "ansible_namespace.collection_name"
        ]
    }

    task_include = TaskInclude()
    task_include.post_validate(ds, 'TaskInclude', None)
    assert task_include.collections == ds['collections']

    block = Block()
    block.post_validate(ds, 'Block', None)
    assert block.collections == ds['collections']

    task = Task()
    task.post_validate(ds, 'Task', None)
    assert task.collections == ds['collections']

    # now test an empty collection list


# Generated at 2022-06-23 06:10:19.938561
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['ansible.builtin']
    assert c.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:10:27.272070
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    assert isinstance(collectionsearch._collections,FieldAttribute)
    assert collectionsearch._collections.isa == 'list'
    assert collectionsearch._collections.listof == string_types
    assert collectionsearch._collections.priority == 100
    assert isinstance(collectionsearch._collections.default,_ensure_default_collection)
    assert collectionsearch._collections.always_post_validate == True
    assert collectionsearch._collections.static == True

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:10:31.322572
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    collection._collections = ['ansible.builtin', 'ansible.legacy']
    assert collection._collections == ['ansible.builtin', 'ansible.legacy']
    assert collection._load_collections(None, None) is None

# Generated at 2022-06-23 06:10:38.304425
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # instantiate an object obj of class CollectionSearch
    obj = CollectionSearch()
    # get the value of field attribute _collections
    obj._collections = obj.get_field_value('collections', None)
    # get the value of field attribute _collections and store it in collections
    collections = obj._collections
    # assert that the list of collections fetched from the configuration file is not empty
    assert collections != []

# Generated at 2022-06-23 06:10:49.755175
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    colSearchObj = CollectionSearch()

    # Ensure all collections are loaded
    default_collection = AnsibleCollectionConfig.default_collection
    colSearchObj._load_collections(None, None)

    # Ensure the default collection is set
    assert 'ansible.legacy' not in colSearchObj._collections
    assert default_collection in colSearchObj._collections

    # Ensure the default collections are set
    assert 'ansible.builtin' in colSearchObj._collections
    assert 'ansible.legacy' in colSearchObj._collections

    # Ensure the default collection is not loaded when user has specified the collections
    colSearchObj._load_collections(None, 'my_collection')
    assert 'my_collection' in colSearchObj._collections
    assert 'ansible.builtin' not in colSearchObj._collections

# Generated at 2022-06-23 06:10:52.156218
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert (type(cs._collections) == 'list')
    assert (type(cs._collections) == 'list')

# Generated at 2022-06-23 06:10:59.807639
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    base = Base.load(dict(name='test', hosts='all', gather_facts='no'), PlayContext(), loader=None, variable_manager=None)
    task = Task.load(dict(name='task', action=dict(module='debug', args=dict(msg='hi'))), base, loader=None)
    assert base._collections is None
    assert task._collections is None

# Generated at 2022-06-23 06:11:00.802516
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:12.124371
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest.mock as mock
    mock_display = mock.MagicMock()
    mock_display.warning = mock.MagicMock()
    with mock.patch('ansible.utils.display.Display', mock_display):
        class Test(CollectionSearch):
            pass
        test_obj = Test()
        test_obj.get_validated_value = mock.MagicMock()
        test_obj._ensure_default_collection = mock.MagicMock()
        test_obj._load_collections('test_attr', {'test_attr': 'test_value'})
        assert mock_display.warning.call_count == 0
        assert test_obj.get_validated_value.call_count == 1
        assert test_obj._ensure_default_collection.call_count == 1
        test_obj._load

# Generated at 2022-06-23 06:11:14.962055
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testObj = CollectionSearch()
    testObj.collections = "ansible.builtin"
    testObj._load_collections(0, "ansible.builtin")
    testObj._ensure_default_collection()

# Generated at 2022-06-23 06:11:17.199535
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections.default == _ensure_default_collection(collection_list=None)

# Generated at 2022-06-23 06:11:19.168402
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:22.381044
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_class = CollectionSearch
    test_object = test_class()
    assert test_object._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:11:24.306704
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.galaxy.role import GalaxyRole

    galaxy_role = GalaxyRole()
    galaxy_role.init_collection_search()

# Generated at 2022-06-23 06:11:32.897245
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    import time
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole

    # Create test inventory
    inventory_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    inventory_dir = os.path.join(inventory_dir, 'test', 'inventory')
    inventory_path = os.path.join(inventory_dir, 'hosts')

# Generated at 2022-06-23 06:11:35.561300
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearchTest(CollectionSearch):
        pass
    cst_test = CollectionSearchTest()
    print(cst_test.collections)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:11:44.722746
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.default == _ensure_default_collection()
    assert obj._collections.name == 'collections'
    assert obj._collections.always_post_validate
    assert obj._collections.static
    assert obj._collections.priority == 100
    assert obj._collections.static
    assert obj._collections._value() == []
    assert obj._collections.listof == string_types
    assert obj._collections.isa == 'list'
    assert obj._collections.always_post_validate == True
    assert obj._collections.static == True
    assert obj._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:11:47.582673
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

    assert obj._collections == []  # noqa

    obj.collections = ['ansible.builtin']

    assert obj.collections == ['ansible.builtin']  # noqa

# Generated at 2022-06-23 06:11:53.604942
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test if constructor of class CollectionSearch works
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

    # test if _collections attribute is set correctly
    collection_list = ['fake_collection']
    assert collection_search._load_collections(None, collection_list) == collection_list

# Generated at 2022-06-23 06:11:56.589925
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == [
        'ansible.builtin',
        'ansible.legacy',
    ]

# Generated at 2022-06-23 06:11:58.635178
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections == _ensure_default_collection()


# Generated at 2022-06-23 06:12:02.074212
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    # This test is to check that the data type of the list from collections
    # is valid
    assert isinstance(search._collections, list)
    # This test is to check that the data type from collections is valid
    assert isinstance(search._collections[0], str)

# Generated at 2022-06-23 06:12:08.232910
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # 获取 CollectionSearch 的实例
    c = CollectionSearch()
    # 获取实例的属性 collections 的 FieldAttribute 实例
    collections = c._collections
    # 校验 collections 的类型
    assert isinstance(collections, FieldAttribute)
    assert collections.isa == 'list'
    # 校验 collections 的默认值
    assert collections.default == ['ansible.builtin']

    # 校验对 collections 的赋值
    ds1 = {}
    # 验证返回的值

# Generated at 2022-06-23 06:12:10.891162
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    attr, ds = '_collections', None
    assert cs._collections.default() == cs._load_collections(attr, ds)

# Generated at 2022-06-23 06:12:16.356921
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    
    # test for class attr _collections type
    #assert type(cs._collections) == 'list'
    
    # test for _load_collections return type
    #assert type(cs._load_collections('collections', 'collections')) == 'list'

# Generated at 2022-06-23 06:12:19.069064
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    default_collections = AnsibleCollectionConfig.default_collection
    default_collections.append(default_collections)
    assert cs._collections is not None

# Generated at 2022-06-23 06:12:23.829456
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testobject = CollectionSearch()
    assert testobject._load_collections(None, None) == _ensure_default_collection()
    assert testobject._load_collections(None, ['test_collection']) == ['test_collection']

# Generated at 2022-06-23 06:12:31.537542
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.plugins
    x = CollectionSearch()
    instance = x.__class__()
    for f in x.__class__.__dict__['_get_fields']():
        value = x.__class__.__dict__[f]['default']()
        setattr(instance, f, value)
    collection_search_instance = instance._collections
    try:
        assert(isinstance(collection_search_instance, list))
    except AssertionError:
        print("assertion error")
    else:
        print("assertion passed")

# Generated at 2022-06-23 06:12:33.929289
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c1 = CollectionSearch()
    assert isinstance(c1, CollectionSearch)

# Generated at 2022-06-23 06:12:43.011433
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    base_cls = CollectionSearch()
    assert base_cls._collections.default() == _ensure_default_collection([])
    assert base_cls._collections.static == True
    assert base_cls._collections.priority == 100
    assert base_cls._collections.isa == 'list'
    assert base_cls._collections.listof == string_types
    assert base_cls._collections.always_post_validate == True
    assert base_cls._collections.unique == False
    assert base_cls._collections.include_default == False
    assert base_cls._collections.default_in_vars == False

# Generated at 2022-06-23 06:12:54.607981
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test _ensure_default_collection()
    assert _ensure_default_collection(['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']
    assert _ensure_default_collection([]) == ['ansible.legacy']
    assert _ensure_default_collection() is None

    # Test _load_collections()
    cs = CollectionSearch()
    # Test loading when value is None
    assert cs._load_collections(None, None) is None
    # Test loading when value is empty
    assert cs._load_collections(None, []) == ['ansible.legacy']
    # Test loading when value is valid
    assert cs._load_collections(None, ['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:12:55.849656
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections is not None

# Generated at 2022-06-23 06:13:09.268458
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Test the CollectionSearch constructor
    
    :return:
    """
    print('Testing constructor of class CollectionSearch')
    
    # Test with valid and invalid inputs
    # Should return object
    collection_search = CollectionSearch(collections=['ansible.builtin'])
    assert collection_search.__class__.__name__ == 'CollectionSearch'
    collection_search = CollectionSearch(collections=['ansible.builtin', 'ansible.builtin.collections'])
    assert collection_search.__class__.__name__ == 'CollectionSearch'
    collection_search = CollectionSearch(collections=['ansible.builtin'])
    assert collection_search.__class__.__name__ == 'CollectionSearch'
    
    # Test with invalid inputs
    # Should raise TypeError