

# Generated at 2022-06-23 06:03:13.353718
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute import Attribute
    from ansible.playbook.role_include import IncludeRole

    assert Attribute.from_attr(vars(CollectionSearch))['collections']._value == _ensure_default_collection()
    assert Attribute.from_attr(vars(IncludeRole))['collections']._value == _ensure_default_collection()

# Generated at 2022-06-23 06:03:15.964039
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    display.display("TEST")
    #search = CollectionSearch("ana", display)
    #assert search



# Generated at 2022-06-23 06:03:21.332451
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert(cs)

    # check collections value
    expected_collections = AnsibleCollectionConfig.default_collection
    assert(cs.collections == expected_collections)

    # This test only succeeds when 'ansible.builtin' or 'ansible.legacy' is 'default' collection
    assert(cs.collections == ['ansible.builtin', 'ansible.legacy'])

# Generated at 2022-06-23 06:03:22.933271
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    new_collection = CollectionSearch()
    assert new_collection._collections is not None


# Generated at 2022-06-23 06:03:25.671938
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection(collection_list=None)

# Generated at 2022-06-23 06:03:30.931709
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()
    coll._load_collections('collections', None)
    coll._load_collections('collections', ['ansible.builtin','ansible.legacy'])
    coll._load_collections('collections', 'ansible.builtin')
    coll._load_collections('collections', 'ansible.builtin,ansible.legacy')

# Generated at 2022-06-23 06:03:39.280693
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ds = None

    cs.collections = ['my.ns.test']
    assert cs._collections._default == _ensure_default_collection
    assert cs.get_validated_value('test', cs._collections, ds, None) == ['my.ns.test']

    cs.collections = ['my.ns.test', 'my.ns.dev']
    assert cs.get_validated_value('test', cs._collections, ds, None) == ['my.ns.test', 'my.ns.dev']

    # Test with missing default 'ansible.builtin' collection
    cs.collections = []
    assert cs.get_validated_value('test', cs._collections, ds, None) == ['ansible.builtin']

# Generated at 2022-06-23 06:03:45.022463
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Instance of class CollectionSearch
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)

    # Instance of class FieldAttribute
    assert isinstance(cs._collections, FieldAttribute)

    try:
        assert cs._load_collections(cs._collections, [['ansible.posix', 'ansible.builtin']]) == [['ansible.posix', 'ansible.builtin']]
    except AssertionError:
        assert False

# Generated at 2022-06-23 06:03:46.498177
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:03:52.251261
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    config = CollectionSearch()
    assert config.get_validated_value('collections',config._collections,{},None) is None
    assert config.get_validated_value('collections',config._collections,[],None) == []
    assert config.get_validated_value('collections',config._collections,["foo","bar"],None) == ['foo','bar']
    assert config.get_validated_value('collections',config._collections,'foo',None) == ['foo']

# Generated at 2022-06-23 06:03:53.017628
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:04:01.341134
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert not collections.collections

    collections.collections = [
        'Ansible.foo',
        'Ansible.bar',
        'Ansible.baz'
    ]
    assert collections.collections[0] == 'Ansible.foo'
    assert collections.collections[1] == 'Ansible.bar'
    assert collections.collections[2] == 'Ansible.baz'

    # collections_path can't be templated
    collections.collections = '{{ foo }}'
    assert not collections.collections

# Generated at 2022-06-23 06:04:07.809001
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestClass(CollectionSearch):
        pass
    test = TestClass()
    # Should be able to set to any iterable
    for value in [(), [], ['test'], set(), {'test'}]:
        test.collections = value
    # Should not be able to set to non-iterable
    for value in [0, True, None]:
        with pytest.raises(TypeError):
            test.collections = value

# Generated at 2022-06-23 06:04:09.530060
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections('collections', None) is None



# Generated at 2022-06-23 06:04:17.518832
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search._collections, FieldAttribute)
    assert collection_search._collections._name == 'collections'
    assert collection_search._collections._isa == 'list'
    assert isinstance(collection_search._collections._listof, type(string_types))
    assert collection_search._collections._priority == 100
    assert callable(collection_search._collections._default)
    assert collection_search._collections._always_post_validate == True
    assert collection_search._collections._static == True

# Generated at 2022-06-23 06:04:19.056806
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-23 06:04:23.472110
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collections = ['ansible.netcommon', 'ansible.builtin']
    c = CollectionSearch(collections=test_collections)
    assert c.collections == test_collections



# Generated at 2022-06-23 06:04:27.623714
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch(collections='not_a_list')
    assert not isinstance(x.collections, list)
    x = CollectionSearch(collections=['list'])
    assert isinstance(x.collections, list)

# Generated at 2022-06-23 06:04:28.970095
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    a.collections = None
    assert a.collections == ['ansible_collections.my_namespace.my_collection']

# Generated at 2022-06-23 06:04:31.956329
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:04:35.333427
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ['ansible.builtin']
    cs._validate_collections()
    print("cs.collections is {0}".format(cs.collections))

# Generated at 2022-06-23 06:04:37.167295
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    assert col._collections == 'ansible.builtin,ansible.legacy'

# Generated at 2022-06-23 06:04:42.346278
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    # c._collections is a FieldAttribute object
    assert c._collections.default == _ensure_default_collection
    # _ensure_default_collection() returns an array
    assert _ensure_default_collection() is not None
    assert len(_ensure_default_collection()) == 1
    assert _ensure_default_collection()[0] == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-23 06:04:45.872363
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Preparing the test environment
    collection_list = ["collection_name"]
    actual_collection_list = _ensure_default_collection(collection_list)
    # Comparing the structure of collection list
    assert (actual_collection_list == ["collection_name", "ansible_collections.ansible.builtin"])

# Generated at 2022-06-23 06:04:49.479872
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Unit test for the constructor of class CollectionSearch"""
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert collection_search._collections is not None
    
if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:04:52.798605
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:05:00.725915
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from collections import namedtuple

    FakeOpt = namedtuple('FakeOpt', ['connection', 'collections'])
    opts = FakeOpt('local', None)
    PlaybookCLI = type('PlaybookCLI', (Base,), {})
    PlaybookCLI.base_vars = {}
    PlaybookCLI.options = opts
    assert PlaybookCLI.options.connection == 'local'
    assert PlaybookCLI.options.collections is None

# Generated at 2022-06-23 06:05:09.530092
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class MyBase(object): pass
    class Test(CollectionSearch, MyBase): pass
    t = Test()
    assert t._collections._static_value is not None
    assert t._load_collections(None, None) is None  # Test isa='list'
    assert t.get_validated_value('foo', [3, 4], None, None) == [3, 4]  # Check ListAttribute
    assert t.get_validated_value('foo', 3, None, None) == 3  # Check ScalarAttribute
    assert t.get_validated_value('foo', 'yes', None, None) == 'yes'  # Check ScalarAttribute

# Generated at 2022-06-23 06:05:11.557040
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collect = CollectionSearch()
    assert collect._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:05:17.189072
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections_list = []
    cs = CollectionSearch()
    assert cs._collections.default_value == _ensure_default_collection(collections_list)
    collections_list = ['collection1', 'collection2']
    cs = CollectionSearch()
    assert cs._collections.default_value == _ensure_default_collection(collections_list)
    assert cs._collections.default_value == collections_list

# Generated at 2022-06-23 06:05:19.036528
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c is not None

# Generated at 2022-06-23 06:05:20.716467
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj._collections)

# Generated at 2022-06-23 06:05:23.511794
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()
    assert obj.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:05:25.406644
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert isinstance(collection, CollectionSearch)


# Generated at 2022-06-23 06:05:32.192737
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Example(CollectionSearch):
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                      always_post_validate=True, static=True)
        def __init__(self, *args, **kwargs):
            super(Example, self).__init__(*args, **kwargs)
            self.loader = None

    e = Example(collections=['test'])

    assert e.collections == ['test','ansible.builtin']

# Generated at 2022-06-23 06:05:35.161254
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.collections = ['ansible.builtin']
    assert search.collections == ['ansible.builtin']

# Unit test when default will get inserted if no collection is in the list

# Generated at 2022-06-23 06:05:38.930014
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    a.__setattr__('_collections', ['test'])
    assert isinstance(a._collections, list)
    assert a._collections == ['test']



# Generated at 2022-06-23 06:05:43.309566
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch(collections=['foo.bar', 'baz.bang'])

    # Test static _load_collections
    assert _ensure_default_collection(['foo.bar', 'baz.bang']) == \
           collection_search._load_collections('collections', ['foo.bar', 'baz.bang'])

    assert _ensure_default_collection([{'foo': 'bar'}]) == []

# Generated at 2022-06-23 06:05:44.590960
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    p = CollectionSearch()
    assert p is not None

# Generated at 2022-06-23 06:05:55.768884
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import Include
    task_include = TaskInclude()
    role_include = RoleInclude()
    include = Include()
    cs = CollectionSearch()
    assert cs is not None
    assert cs._collections is not None
    assert cs._collections.isa == 'list'
    assert cs._collections.listof == string_types
    assert cs._collections.priority == 100
    assert cs._collections.default == _ensure_default_collection
    assert cs._collections.always_post_validate is True
    assert cs._collections.static is True
    assert cs._collections.name == 'collections'

# Generated at 2022-06-23 06:05:57.193733
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._load_collections({}, {}) == None

# Generated at 2022-06-23 06:06:00.511710
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == ['ansible.builtin', 'ansible.legacy']
    assert CollectionSearch(collections=['test_collection'])._collections == ['test_collection', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:06:02.331210
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections.collections is not None

# Generated at 2022-06-23 06:06:09.147269
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_inst = CollectionSearch()
    assert(test_inst._collections.default == _ensure_default_collection())
    assert(test_inst._collections.isa == 'list')
    assert(test_inst._collections.listof == string_types)
    assert(test_inst._collections.priority == 100)
    assert(test_inst._collections.always_post_validate == True)
    assert(test_inst._collections.static == True)

# Generated at 2022-06-23 06:06:15.315068
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_list = ["ansible.posix", "ansible.windows"]
    assert(CollectionSearch._ensure_default_collection(collection_list) != None)
    assert(CollectionSearch._ensure_default_collection(collection_list) == ["ansible.posix", "ansible.windows", "ansible.builtin"])

    collection_list = ["ansible.builtin", "ansible.windows"]
    assert(CollectionSearch._ensure_default_collection(collection_list) == ["ansible.builtin", "ansible.windows", "ansible.legacy"])

    collection_list = []
    assert(CollectionSearch._ensure_default_collection(collection_list) == ["ansible.builtin", "ansible.legacy"])

# Generated at 2022-06-23 06:06:20.154810
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == ['ansible.builtin', 'ansible.legacy']

    obj.collections = ['col1', 'col2']
    assert obj.collections == ['ansible.builtin', 'ansible.legacy', 'col1', 'col2']
    assert obj.get_validated_value('collections', obj._collections, None, None) == ['ansible.builtin', 'ansible.legacy', 'col1', 'col2']

# Generated at 2022-06-23 06:06:31.218014
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from collections import namedtuple
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    import ansible.playbook.play_context
    from ansible.playbook.role import Role
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.become import Become

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    from ansible.module_utils.six import iteritems

    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader._collection_finder import _CollectionFinder

# Generated at 2022-06-23 06:06:38.408025
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # create a CollectionSearch object with no parameter
    collectionSearch = CollectionSearch()
    # test if the constructor is correct
    assert collectionSearch._collections == _ensure_default_collection()

    # create a CollectionSearch object with valid parameter
    collectionSearch = CollectionSearch(collections=['ansible.builtin'])
    # test if the constructor is correct
    assert collectionSearch._collections == ['ansible.builtin']

    # create a CollectionSearch object with invalid parameter
    try:
        collectionSearch = CollectionSearch(collections=123)
    except Exception:
        # test if the constructor raises exception correctly
        assert True
    else:
        assert False

    # create a CollectionSearch object with valid parameter and then test if the parameter is templatable

# Generated at 2022-06-23 06:06:45.251786
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collections = collection_search._load_collections(None, [])
    assert collections is not None
    assert '/etc/ansible/collections' in collections[0]
    collections = collection_search._load_collections(None, ['/etc/ansible/ansible_collections'])
    assert collections is not None
    assert '/etc/ansible/collections' in collections[0]
    assert '/etc/ansible/ansible_collections' in collections[1]

# Generated at 2022-06-23 06:06:56.235384
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds=None
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin', 'ansible.legacy']
    c = CollectionSearch(collections=['ansible.builtin', 'ansible.legacy'])
    assert c.collections == ['ansible.builtin', 'ansible.legacy']

    # c = CollectionSearch(collections='c')  # does not work, as it expects a sequence, not a string
    c = CollectionSearch(collections=['c'])
    assert c.collections == ['c', 'ansible.builtin', 'ansible.legacy']
    c = CollectionSearch(collections=['c', 'b', 'a'])
    assert c.collections == ['c', 'b', 'a', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:06:58.521218
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ansible_internal_collection = CollectionSearch()
    ansible_internal_collection._load_collections(attr=None, ds=None)

# Generated at 2022-06-23 06:07:07.534403
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    test = CollectionSearch()

    attr = []
    ds = None
    assert test._load_collections(attr, ds) == _ensure_default_collection(collection_list=[])

    ds = ['ansible.builtin']
    assert test._load_collections(attr, ds) == _ensure_default_collection(collection_list=['ansible.builtin'])

    ds = [
        'ansible.builtin',
        'ansible_namespace.collection_name',
        'ansible.legacy'
    ]
    assert test._load_collections(attr, ds) == _ensure_default_collection(collection_list=ds)

# Generated at 2022-06-23 06:07:16.930126
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	cs = CollectionSearch()
	print(cs)
	print(cs.__dict__)
	print(cs.__slots__)
	print(cs.__dict__['_collections'].default)
	print(cs._collections.default)
	print(cs.__dict__['_collections'].always_post_validate)
	print(cs._collections.always_post_validate)
	print(cs.__dict__['_collections'].static)
	print(cs._collections.static)
	print(cs._load_collections(None, None))
	print(cs._load_collections('foo', 'bar'))

if __name__ == "__main__":
	test_CollectionSearch()

# Generated at 2022-06-23 06:07:20.660205
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == 'ansible.builtin'
    assert isinstance(cs.collections, string_types)

# Generated at 2022-06-23 06:07:24.145842
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._def_attrs['collections'] == _ensure_default_collection

# Generated at 2022-06-23 06:07:25.544651
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default is _ensure_default_collection

# Generated at 2022-06-23 06:07:31.414327
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    #pylint: disable=protected-access
    assert cs._collections is not None
    assert cs._collections._value is not None
    assert cs._collections._value[0] == AnsibleCollectionConfig.default_collection
    assert cs._collections._value[1] == 'ansible.builtin'
    assert len(cs._collections._value) == 2

# Generated at 2022-06-23 06:07:34.113236
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().__dict__ == {'_collections': ['ansible_collections.nsanalytics.hyperglance']}

testobj = CollectionSearch()

# Generated at 2022-06-23 06:07:35.400739
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

	# Test the constructor by creating an instance of this class
	collection_search = CollectionSearch()

# Generated at 2022-06-23 06:07:37.839621
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert cs._collections == ['ansible.posix', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:07:40.454800
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    o = CollectionSearch()

    # CollectionSearch collection_list is list
    assert type(o._collections) is list

    # CollectionSearch is subclass of Base
    assert isinstance(o, Base)

# Generated at 2022-06-23 06:07:41.619692
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:07:43.940390
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()



# Generated at 2022-06-23 06:07:46.278962
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:47.650083
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections is not None

# Generated at 2022-06-23 06:07:50.591284
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:07:55.413962
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:07:57.993439
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs=CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:08:01.111474
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert("ansible.builtin" in test._load_collections("collections", None))
    assert("ansible.legacy" in test._load_collections("collections", None))

# Generated at 2022-06-23 06:08:03.093373
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()


# Generated at 2022-06-23 06:08:05.351006
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance is not None
    assert instance._collections is not None

# Generated at 2022-06-23 06:08:07.514346
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Arrange
    class TestCollectionSearch(CollectionSearch):
        pass

    # Act
    result = TestCollectionSearch()

    # Assert
    assert result._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:08:11.177307
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()

    assert len(collection_search.collections) == 1
    assert 'ansible.builtin' in collection_search.collections

    assert str(collection_search) == '<CollectionSearch collections=ansible.builtin>'

# Generated at 2022-06-23 06:08:22.601962
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # 1. Select collections from resource file
    collection_search = CollectionSearch()

    # 1.2 Select all collections from ansible default directory and ansible.builtin
    collection_search._collections = [os.getcwd() + "/collections"]
    collection_search._load_collections(None, None)

    # 1.3 Select all collections from ansible default directory and ansible.legacy
    collection_search._collections = [os.getcwd() + "/collections", "ansible.legacy"]
    collection_search._load_collections(None, None)

    # 1.4 Select all collections from ansible default directory, ansible.builtin and ansible.legacy
    collection_search._collections = [os.getcwd() + "/collections", "ansible.legacy", "ansible.builtin"]


# Generated at 2022-06-23 06:08:23.664977
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None

# Generated at 2022-06-23 06:08:25.183132
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    t._load_collections('collections', [])

# Generated at 2022-06-23 06:08:26.828975
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == []
    assert CollectionSearch(collections="test").collections == []

# Generated at 2022-06-23 06:08:33.393724
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert "ansible.builtin" in obj._collections
    obj._collections.remove("ansible.builtin")

    obj._collections = ["test.test_collection", "ansible.builtin"]
    assert obj._collections == _ensure_default_collection(["test.test_collection", "ansible.builtin"])

# Generated at 2022-06-23 06:08:35.422164
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:08:36.028480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:08:37.579193
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        import __main__
        delattr(__main__, '__file__')
    except:
        pass

    test_instance = CollectionSearch()

    assert test_instance._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:08:40.577876
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    from ansible.playbook.role_include import RoleInclude
    assert isinstance(RoleInclude.collections, FieldAttribute)

# Generated at 2022-06-23 06:08:44.078372
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ['ansible.builtin', 'ansible.legacy']
    assert CollectionSearch(collections=['test_ns.collection_name']).collections == ['test_ns.collection_name', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:08:48.765259
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None
    assert collection_search._collections.default is _ensure_default_collection
    assert collection_search._collections.data is None

# Generated at 2022-06-23 06:08:51.178199
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c1 = CollectionSearch()
    c2 = CollectionSearch(collections=['first_collection'])
    assert c1.collections == c2.collections

# Generated at 2022-06-23 06:08:57.201379
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is None
    c._load_collections("collections", None)
    assert c._collections == ["ansible.builtin"]
    c._load_collections("collections", ['foo.bar'])
    assert c._collections == ['foo.bar', 'ansible.builtin']
    c._load_collections("collections", [])
    assert c._collections is None

# Generated at 2022-06-23 06:08:58.920123
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_test = CollectionSearch()
    assert _ensure_default_collection(search_test._collections.default)




# Generated at 2022-06-23 06:09:01.326384
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs_obj = CollectionSearch()
    assert cs_obj.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:05.144699
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearchTest(CollectionSearch):
        pass
    cs = CollectionSearchTest()
    # Verify that collections is added to the attributes of class CollectionSearch
    assert '_collections' in cs.__class__.__dict__

# Generated at 2022-06-23 06:09:09.598450
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    '''

    :return:
    '''
    from ansible.playbook.role_include import IncludeRole
    print(IncludeRole.collections)
    assert isinstance(IncludeRole.collections, list)

# Generated at 2022-06-23 06:09:11.421003
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default is _ensure_default_collection

# Generated at 2022-06-23 06:09:14.096654
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch(collections=['col.o'])
    assert isinstance(cs.collections, list)
    assert len(cs.collections) == 1

# Generated at 2022-06-23 06:09:22.304724
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cls = CollectionSearch()
    test_data = [
        (
            {},
            _ensure_default_collection()
        ),
        (
            {'collections': []},
            _ensure_default_collection()
        ),
        (
            {'collections': ['geerlingguy.java']},
            _ensure_default_collection(['geerlingguy.java'])
        )
    ]
    for data, expected in test_data:
        assert cls._load_collections('collections', data) == expected

# Generated at 2022-06-23 06:09:23.781757
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert 'ansible.builtin' in CollectionSearch._collections.default(object)

# Generated at 2022-06-23 06:09:26.565440
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._load_collections('collections', [])
    print(cs._collections.value, cs._collections.value)


# Generated at 2022-06-23 06:09:27.713363
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert isinstance(instance, CollectionSearch)

# Generated at 2022-06-23 06:09:31.270331
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:09:31.975382
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:09:42.254802
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play import Play

    p = Play()
    assert isinstance(p, CollectionSearch)

    assert p.collections == _ensure_default_collection()

    # Test that an empty list does not return an empty list
    p = Play(collections=['my.collection'])
    assert isinstance(p, CollectionSearch)
    assert p.collections == ['my.collection']

    # Test that the default collection is moved to the front
    p = Play(collections=['my.collection'])
    assert isinstance(p, CollectionSearch)
    assert p.collections == ['my.collection', AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-23 06:09:43.721018
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == ['unittest.collection']

# Generated at 2022-06-23 06:09:52.904676
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test case when there is no default collection
    # AnsibleCollectionConfig.default_collection = None
    display = Display()
    display.debug = True
    def test_load_collections1(self, attr, ds):
        return self._load_collections(attr, ds)

    # Test case when there is a default collection
    AnsibleCollectionConfig.default_collection = 'ansible_collections.nsbl.test'
    def test_load_collections2(self, attr, ds):
        return self._load_collections(attr, ds)

    # Test case when the default collection is in the collection list
    AnsibleCollectionConfig.default_collection = 'ansible_collections.nsbl.test'
    display.debug = True

# Generated at 2022-06-23 06:10:02.562283
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_search = CollectionSearch()
    assert coll_search._load_collections(None, None) is None

    coll_search = CollectionSearch()
    assert coll_search._load_collections(None, {'collections': ['collection']}) == ['collection']

    coll_search = CollectionSearch()
    assert coll_search._load_collections(None, {'collections': ['ansible.builtin']}) == ['ansible.builtin']

    coll_search = CollectionSearch()
    assert coll_search._load_collections(None, {'collections': ['ansible.builtin', 'ansible.legacy']}) == \
           ['ansible.builtin', 'ansible.legacy']

    coll_search = CollectionSearch()

# Generated at 2022-06-23 06:10:04.773473
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search=CollectionSearch()
    assert collection_search._collections == "ansible.builtin"

# Generated at 2022-06-23 06:10:06.030548
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections is not None


# Generated at 2022-06-23 06:10:07.975803
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:12.824167
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search._collections = None
    collection_search._collections = ['wazuh.collection']

    assert collection_search._collections == ['wazuh.collection', 'ansible_collections.ansible.wazuh']

# Generated at 2022-06-23 06:10:17.810252
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)
    assert isinstance(_collections, FieldAttribute)

# Generated at 2022-06-23 06:10:28.587031
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.vault import VaultLib
    from ansible.playbook import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    templar = Templar(
        vault_secrets=VaultLib(), loader=None, variables=VariableManager(),
        shared_loader_obj=PlayContext()
    )

    collection_search = CollectionSearch(loader=None, variable_manager=VariableManager())

    # test with default value
    collection_list = collection_search._load_collections(attr="collections", ds=[])
    assert collection_list is None

    # test with dark value
    dark_collection_list = ['ansible.builtin', 'ansible.legacy']
    collection_search._collections = dark_collection_list
    collection_list = collection_

# Generated at 2022-06-23 06:10:30.090222
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch._collections

# Generated at 2022-06-23 06:10:33.946774
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    k = CollectionSearch()
    k._collections = ["ansible.builtin","ansible.test_collection"]
    assert k._load_collections("collections", None) is not None

# Generated at 2022-06-23 06:10:37.440736
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    attr = CollectionSearch()
    attr.post_validate('', {'_collections': []})
    attr._load_collections('', [])


if __name__ == '__main__':
   test_CollectionSearch()

# Generated at 2022-06-23 06:10:40.606650
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections == _ensure_default_collection()
    assert search._load_collections(None, None) == _ensure_default_collection()

# Generated at 2022-06-23 06:10:46.050522
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play_context = PlayContext()
    play_context.collections = ['ansible.builtin', 'ansible.legacy']
    play = Play.load('test', dict(name='test'), play_context=play_context)
    assert not play._collections
    assert len(play_context.collections) == 2


# Generated at 2022-06-23 06:10:55.640460
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest
    import unittest.mock

    # Create a new class using the constructor of CollectionSearch
    class NewCollectionSearch(CollectionSearch):
        pass

    # Create a new object of NewCollectionSearch
    test_obj = NewCollectionSearch()

    # Create a mock object of the Display

# Generated at 2022-06-23 06:10:57.347996
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    print(instance.collections)

# Generated at 2022-06-23 06:11:10.083483
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestTask(CollectionSearch):
        pass
    # create the class object
    test_obj = TestTask()
    # assert the value is correctly set
    assert(test_obj.collections == ['ansible_collections.ansible'])
    # we call the _ensure_default_collection with default arguments
    assert(test_obj._load_collections(None, None) == ['ansible_collections.ansible'])
    assert(test_obj._load_collections(None, ['ansible_collections.ansible']) == ['ansible_collections.ansible'])
    assert(test_obj._load_collections(None, ['ansible_collections.ansible', 'test_collection']) ==
            ['ansible_collections.ansible', 'test_collection'])

# Generated at 2022-06-23 06:11:12.305861
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj

    assert obj.collections == ['ansible.builtin']
    assert obj._collections.static

# Generated at 2022-06-23 06:11:14.361184
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Unit test for constructor of class CollectionSearch"""
    search = CollectionSearch()
    assert search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:18.700518
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # create a test object for class CollectionSearch
    testCollectionSearch = CollectionSearch()
    # check the attributes of class CollectionSearch
    result = {'_collections': []}
    assert (result == testCollectionSearch.__dict__)

# Generated at 2022-06-23 06:11:21.606028
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._load_collections("collections", ["ansible.builtin"]) == ["ansible.builtin", "ansible.legacy"]

# Generated at 2022-06-23 06:11:24.036430
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # NOTE: constructor of class CollectionSearch uses a static method from FieldAttribute, hence
    # it cannot be tested using unittest.
    pass

# Generated at 2022-06-23 06:11:25.481525
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:11:28.954750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # create an object of CollectionSearch and verify if it is initialized properly
    sc = CollectionSearch()
    # Assert that object attribute _collections is initialized to a list
    assert(isinstance(sc._collections, list))

# Generated at 2022-06-23 06:11:32.761818
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    try:
        assert obj.collections == ["ansible.builtin"]
    except AssertionError:
        print("Test collection search Failed")
# End of unit test

# Generated at 2022-06-23 06:11:36.450859
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    c._load_collections(None, ['quark', 'quanta'])
    assert c._collections == ['ansible.builtin', 'quark', 'quanta']
    c._load_collections(None, None)
    assert c._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:11:37.465214
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # 

# Generated at 2022-06-23 06:11:38.600750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs)

# Generated at 2022-06-23 06:11:46.639502
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class MyTestClass(CollectionSearch):
        pass

    mtc = MyTestClass()
    assert mtc._collections == ['ansible.builtin', 'ansible.legacy']

    class MyTestClass2(CollectionSearch):

        _collections = FieldAttribute(isa='list', listof=string_types, priority=100,
                                      always_post_validate=True, static=True)

        def __init__(self, col_list):
            self._collections = col_list

    mtc2 = MyTestClass2(["my.custom.collection"])
    assert mtc2._collections == ['my.custom.collection', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:11:53.007019
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test for default
    obj = CollectionSearch()
    assert obj._collections.default == _ensure_default_collection
    assert obj.collections == _ensure_default_collection()

    # test for setting collections
    obj = CollectionSearch()
    obj.collections = ['test_collections']
    assert obj.collections == ['test_collections']

# Generated at 2022-06-23 06:11:54.843276
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert(c._collections == _ensure_default_collection())

# Generated at 2022-06-23 06:11:58.209271
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    y = x._load_collections(None, ['ansible.builtin', 'ansible.legacy'])
    assert y == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-23 06:12:00.083724
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert 'ansible.builtin' in obj._collections

# Generated at 2022-06-23 06:12:07.261941
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.collection import CollectionRole
    from ansible.playbook.task.collection import CollectionTask
    from ansible.playbook.block.collection import CollectionBlock

    # register a collection to test against
    a_collection = 'jdoe.my_collection'
    AnsibleCollectionConfig.add_collection_to_cache(a_collection)

    def _test_search(obj, collection_name):

        # I'm a Role
        if isinstance(obj, CollectionRole):

            # the top level collection list should be the same, we use -1 as the default index
            # to get the value of the last element in the collection list
            assert a_collection == obj.get_collections()[-1]

            # the collection name specified in the task should be the same
            assert collection_name == obj.get_col

# Generated at 2022-06-23 06:12:09.249456
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.post_validate(None, None)

# Generated at 2022-06-23 06:12:16.239853
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _attr_collections = '_collections'
    obj = CollectionSearch()
    # Check if _collections is instance of FieldAttribute class
    assert isinstance(obj.__dict__[_attr_collections], FieldAttribute)
    # Check if _collections is a list type
    assert obj.__dict__[_attr_collections].isa == 'list'
    # Ensure _collections is a list of strings
    assert obj.__dict__[_attr_collections].listof == string_types
    # Ensure _collections attribute has the default value _ensure_default_collection
    assert obj.__dict__[_attr_collections]._default == _ensure_default_collection


# Generated at 2022-06-23 06:12:18.136347
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	c = CollectionSearch()
	assert c._collections == _ensure_default_collection()



# Generated at 2022-06-23 06:12:30.417513
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test 1: No value is provided for collections
    testcase = CollectionSearch()
    testcase._load_collections(None, {})

    # Test 2: Testcase with collections as input without default collection
    testcase = CollectionSearch()

# Generated at 2022-06-23 06:12:42.138019
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # We are not passing any values to constructor of class CollectionSearch, so it should
    # return None.
    search = CollectionSearch()
    assert search._load_collections(None, None) is None

    # When we passing value to constructor of class CollectionSearch, so it should
    # return value.
    search = CollectionSearch(collections='ansible_collections.some.collection')
    assert search._load_collections(None, 'ansible_collections.some.collection') == 'ansible_collections.some.collection'

    # When we passing value to constructor of class CollectionSearch, so it should
    # return value.
    search = CollectionSearch(collections=['ansible_collections.some.collection'])

# Generated at 2022-06-23 06:12:42.885672
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    print(collection)

# Generated at 2022-06-23 06:12:47.126440
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections
    for index, collection in enumerate(obj.collections):
        if index > 1:
            assert collection != obj.collections[index - 1]
    assert obj.collections == _ensure_default_collection(collection_list=None)

# Generated at 2022-06-23 06:12:51.471351
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class MyClass(CollectionSearch):
        pass

    my_class = MyClass()

    my_class.load_data_structures("yaml")

    assert my_class.collections == ['ansible.legacy']

# Generated at 2022-06-23 06:12:52.726207
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert(cs)

# Generated at 2022-06-23 06:12:55.281849
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()
    assert collection_search._load_collections is not None

# Generated at 2022-06-23 06:13:01.215268
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition

    role_definition = RoleDefinition()
    assert role_definition.collections is not None

# Generated at 2022-06-23 06:13:10.683381
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from AnsibleModule import AnsibleModule
    from ansible.playbook.connection import Connection
    from ansible.playbook.task import Task
    from ansible.playbook.tasks import Tasks
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.become import Become
    from ansible.playbook.become_context import BecomeContext
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include.include import Include