

# Generated at 2022-06-23 06:03:12.193559
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    temp_collection = CollectionSearch()
    assert(temp_collection._collections == [])
    assert(temp_collection)
    assert(temp_collection._collections == 'test_namespace.test_collection')

# Generated at 2022-06-23 06:03:25.821487
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    attr = obj._collections
    ds = None
    expect = _ensure_default_collection()
    res = obj._load_collections(attr, ds)
    assert(res == expect)

    ds = ['community.general']
    expect = _ensure_default_collection(ds)
    res = obj._load_collections(attr, ds)
    assert(res == expect)

    ds = ['community.general', 'ansible.builtin']
    expect = _ensure_default_collection(ds)
    res = obj._load_collections(attr, ds)
    assert(res == expect)

    ds = ['community.general', 'ansible.builtin', 'ansible.legacy']
    expect = _ensure_default_collection(ds)


# Generated at 2022-06-23 06:03:31.128503
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    # To check whether constructor sets the attribute 'collections' or not
    assert hasattr(collectionSearch, '_collections')
    # To check whether the value of attribute 'collections' is None or not
    assert collectionSearch._collections == None
    # To check whether load_collections method is called or not
    assert collectionSearch._load_collections([]) == None

# Generated at 2022-06-23 06:03:32.600163
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_object = CollectionSearch()
    assert isinstance(search_object, CollectionSearch)

# Generated at 2022-06-23 06:03:34.659380
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()  # pylint: disable=too-few-public-methods
    assert cs



# Generated at 2022-06-23 06:03:36.330908
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, []) == _ensure_default_collection()

# Generated at 2022-06-23 06:03:38.592697
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible.legacy']

# Generated at 2022-06-23 06:03:40.504504
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:03:42.924668
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(attr='collections', ds="ansible.builtin", ) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:03:44.908444
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.__dict__['_collections'].default == _ensure_default_collection

# Generated at 2022-06-23 06:03:46.716952
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections('collections', ['test_collection']) == ['test_collection']


# Generated at 2022-06-23 06:03:47.893657
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:03:56.092936
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    collection_search.collections = ['ansible.builtin', 'ansible.legacy', 'local_collections_1', 'local_collections_2']
    args = ''
    assert collection_search._load_collections(args, collection_search.collections) == collection_search.collections

    collection_search.collections =  'ansible.builtin, ansible.legacy, local_collections_1, local_collections_2'
    args = ''
    assert collection_search._load_collections(args, collection_search.collections) == ['ansible.builtin', 'ansible.legacy', 'local_collections_1', 'local_collections_2']


# Generated at 2022-06-23 06:03:58.064861
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # constructor for class CollectionSearch
    cs = CollectionSearch()

# test for method _load_collections of class CollectionSearch

# Generated at 2022-06-23 06:04:00.925280
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()
    assert cs._collections == ['ansible.legacy']

    cs = CollectionSearch(collections = ['collection_one', 'collection_two'])
    assert cs._collections == ['collection_one', 'collection_two', 'ansible.legacy']

# Generated at 2022-06-23 06:04:11.886090
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.template import is_template
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.display import Display

    # test AnsibleCollectionConfig.default_collection attribute
    # check if default_collection attribute is set
    assert AnsibleCollectionConfig.default_collection is None
    # check if default_collection attribute is read only
    try:
        AnsibleCollectionConfig.default_collection = 'hello'
    except AttributeError:
        # pass
        pass
    assert AnsibleCollectionConfig.default_collection is None

    # check if Display.display attributes are read only
    try:
        display.verbosity = 4
        display.columns = 100
    except AttributeError:
        pass

    # check if display.display attributes are read only
    assert display.verbosity == 0

# Generated at 2022-06-23 06:04:21.299268
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    ds = {u'collections': [u'./library2.yaml', u'example.my_namespace.my_collection']}
    collection_search._load_collections(None, ds)
    assert ds == {u'collections': [u'./library2.yaml', u'example.my_namespace.my_collection', u'ansible.builtin']}

    ds2 = {u'collections': [u'./library2.yaml', u'example.my_namespace.my_collection']}
    collection_search._load_collections(None, ds2)

# Generated at 2022-06-23 06:04:27.155971
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from collections import namedtuple

    class DataSet(namedtuple('DataSet', 'collections')):
        pass

    test_data = DataSet('test.ansible')

    test_obj = CollectionSearch()
    result = test_obj._load_collections('collections', test_data)

    assert result[0] == 'test.ansible'

# Generated at 2022-06-23 06:04:39.498258
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    from collections import defaultdict
    from ansible.utils.version import SemanticVersion
    from ansible.galaxy import Galaxy

    with pytest.raises(Exception):
        from ansible.playbook.attribute_wrapper import AttributeWrapper
        with pytest.raises(AttributeError):
            AttributeWrapper(CollectionSearch, {'tags': []}, 'tags', False)

    m_CollectionSearch = CollectionSearch()
    assert m_CollectionSearch.collections == _ensure_default_collection()

    # Test the _load_collections function
    # This test actually doesn't seem to test anything
    Test_Class = type("Test_Class", (CollectionSearch,), {})
    test_obj = Test_Class()
    test_obj.post_validate()
    test_obj.tags = None

# Generated at 2022-06-23 06:04:45.400349
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Unit tests for the CollectionSearch constructor"""
    cs = CollectionSearch()
    assert cs._collections.static == True
    assert cs._collections.name == 'collections'
    assert cs._collections.priority == 100
    assert cs._collections.default == ['ansible_collections.ansible.builtin']
    assert cs._collections.isa == 'list'
    assert cs._collections.listof == string_types
    assert cs._collections.always_post_validate == True

# Generated at 2022-06-23 06:04:54.375342
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert 'ansible.legacy' in CollectionSearch()._collections
    assert 'ansible.builtin' not in CollectionSearch()._collections
    assert 'ansible.builtin' in CollectionSearch(collections=['my.collection'])._collections
    assert 'my.collection' in CollectionSearch(collections=['my.collection'])._collections
    assert 'ansible.builtin' in CollectionSearch(collections=['my.collection', 'ansible.builtin'])._collections

# Generated at 2022-06-23 06:05:03.340352
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # if collections is empty, add ansible.legacy
    assert _ensure_default_collection() == ['ansible.legacy']
    # if collections is not empty, add ansible.legacy to the 0th position
    assert _ensure_default_collection(['foo', 'bar']) == ['ansible.legacy', 'foo', 'bar']
    # collections is empty, and the collection does not exist.
    # ansible.cfg[collections] is set to ansible_namespace.collection
    assert cs._load_collections('', '') == None

# Generated at 2022-06-23 06:05:08.393442
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is not None

    # this one is a little weird
    assert c._collections.default(None) is None
    assert c._collections.default([]) == ['ansible.builtin']

    assert c._collections.default(['foobar']) == ['foobar', 'ansible.builtin']

# Generated at 2022-06-23 06:05:12.484414
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = {'collections': ['awx.awx','awx.tower']}
    cs = CollectionSearch()
    rtv = cs.post_validate(ds,None)
    assert rtv['collections'] == ['awx.tower', 'awx.awx', 'ansible.builtin']


# Generated at 2022-06-23 06:05:14.805889
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c is not None
    assert c._collections.default() == _ensure_default_collection()

# Generated at 2022-06-23 06:05:16.276136
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == ['ansible.generated']


# Generated at 2022-06-23 06:05:19.236720
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_set = CollectionSearch()
    assert test_set._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:05:21.077771
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections is not None



# Generated at 2022-06-23 06:05:24.398348
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert isinstance(search, CollectionSearch)
    assert search._collections is None
    assert search._collections.default == 'ansible.builtin'

# Generated at 2022-06-23 06:05:34.007122
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    # check attributes are initialized correctly
    assert isinstance(obj._collections, FieldAttribute)
    assert isinstance(obj._collections.isa, type('str'))
    assert obj._collections.listof == string_types
    assert obj._collections.priority == 100
    assert callable(obj._collections.default)
    assert obj._collections.default() == _ensure_default_collection()
    assert obj._collections.always_post_validate
    assert obj._collections.static
    assert not obj._collections.secret

    # check rest of class attributes are None, empty or False
    assert not obj._attributes
    assert not obj._dont_inherit_attributes
    assert not obj._dont_call_runtime_setup
    assert not obj._no_log

# Generated at 2022-06-23 06:05:39.503281
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()
    # Make sure the result is a list
    assert isinstance(test_object._collections, list)
    # Make sure the default result is the default collection
    assert test_object._collections == _ensure_default_collection(collection_list=None)
    # Make sure _collections is static
    assert test_object._static_attributes == set(['_collections'])

# Generated at 2022-06-23 06:05:41.906430
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    if type(cs) == CollectionSearch:
        print("CollectionSearch constructor created class object successfully.")
    else:
        print("error CollectionSearch constructor failed.")


# Generated at 2022-06-23 06:05:42.586701
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch

# Generated at 2022-06-23 06:05:45.560454
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    test_collection_search = CollectionSearch()
    assert test_collection_search.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:05:48.063727
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # This is a check for the constructor to have initialized the value with the default value.
    # If the constructor is not working, this check will fail.
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:05:52.119344
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # Assert object creation
    assert isinstance(cs, CollectionSearch)

    # Assert object creation with valid collection
    cs = CollectionSearch(collections="ansible.builtin")

    # Assert object creation with valid collection
    cs = CollectionSearch(collections=["ansible.builtin"])

    # Assert object creation with valid collection
    cs = CollectionSearch(collections=["ansible.builtin", "namespace.collection"])

# Generated at 2022-06-23 06:06:03.498455
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    tests = [
        # CollectionSearch
        {
            'b_obj': CollectionSearch(),
            'validation_method': '_load_collections',
            'data_structure': {'collections': ['community.kubernetes:k8s']}
        },
    ]
    for test in tests:
        result = test['b_obj'].attributes[test['validation_method']].get_value(test['data_structure'], None, test['b_obj'])
        assert test['data_structure']['collections'] == result
        test['data_structure']['collections'] = []
        result = test['b_obj'].attributes[test['validation_method']].get_value(test['data_structure'], '', test['b_obj'])
        assert test

# Generated at 2022-06-23 06:06:13.037120
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections() == ['ansible_collections.nsnb.testing']
    assert CollectionSearch()._load_collections([]) == ['ansible_collections.nsnb.testing']
    assert CollectionSearch()._load_collections([u'ansible_collections.nsnb.testing']) == ['ansible_collections.nsnb.testing']
    assert CollectionSearch()._load_collections([u'ansible_collections.nsnb.testing', 'ansible_collections.nsnb.secondary']) == ['ansible_collections.nsnb.testing', 'ansible_collections.nsnb.secondary']

# Generated at 2022-06-23 06:06:24.938120
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test _ensure_default_collection()
    test_value = CollectionSearch()
    assert test_value._ensure_default_collection() is not None

    # test_value._ensure_default_collection(['invalid-1']) is required to avoid error
    # TypeError: 'NoneType' object is not iterable while appending the default-collection value
    assert test_value._ensure_default_collection(['invalid-1']) is not None
    assert test_value._ensure_default_collection(['invalid-2']) is not None
    assert test_value._ensure_default_collection(['ansible.builtin']) is not None
    assert test_value._ensure_default_collection(['ansible.builtin', 'invalid-2']) is not None
    assert test_value._ensure

# Generated at 2022-06-23 06:06:27.400438
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert hasattr(obj, "collections")
    assert hasattr(obj, "_collections")
    assert obj.collections is None

# Generated at 2022-06-23 06:06:29.459328
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections == _ensure_default_collection

# Generated at 2022-06-23 06:06:31.491523
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == 'ansible.builtin,ansible.legacy'

# Generated at 2022-06-23 06:06:35.829186
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch_obj = CollectionSearch()
    assert collectionsearch_obj._collections.default == []
    assert collectionsearch_obj._collections.name == 'collections'

# Generated at 2022-06-23 06:06:45.665073
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    # test if the default collections list is set correctly
    assert obj._collections == _ensure_default_collection()

    # test the method _load_collections:
    # - attr is the attribute name we want to find
    # - ds is the data structure we are looking at
    assert obj._load_collections('collections', None) is None

    # test the method _load_collections:
    # - attr is the attribute name we want to find
    # - ds is the data structure we are looking at
    # - a list of collections is passed to the method
    assert obj._load_collections('collections', ['test.test']) == ['test.test', 'ansible.legacy']

# Generated at 2022-06-23 06:06:50.513925
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch(collections=['col'])
    assert collection_search._collections == ['col']
    return collection_search

# Generated at 2022-06-23 06:06:54.494604
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    first_obj = CollectionSearch()
    print(first_obj._collections)
    print(first_obj._collections is first_obj.__class__._collections)
    print(first_obj.collections)
    print(_ensure_default_collection(collection_list=None))


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:06:57.462010
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t
    assert t._collections
    assert t.collections
    assert t.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:07:02.788485
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import yaml
    yaml_src = """
    - hosts:
        - localhost
      collections:
        - my.collection
    """
    yaml_data = yaml.safe_load(yaml_src)
    task_ds = yaml_data[-1]
    attr = 'collections'
    class_obj = CollectionSearch()
    result = class_obj._load_collections(attr, task_ds)

# Generated at 2022-06-23 06:07:05.195057
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == "ansible.builtin,ansible.legacy"

# Generated at 2022-06-23 06:07:06.301890
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections is None

# Generated at 2022-06-23 06:07:08.163126
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:07:10.904099
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with pytest.raises(ValueError):
        assert(CollectionSearch())

    from ansible.playbook.play import Play
    assert(CollectionSearch(Play()))

# Generated at 2022-06-23 06:07:15.349780
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    collection_list = collection._load_collections(False, None)
    assert "ansible_collections.ansible.builtin" in collection_list
    assert "ansible.builtin" not in collection_list
    assert "ansible.legacy" not in collection_list

# Generated at 2022-06-23 06:07:20.023798
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible.builtin']
    # Set the _collections field
    collection_search._collections = ['ansible.builtin', 'awx.awx']
    # Test the _load_collections method
    val_a = collection_search._load_collections("_collections", ["awx.awx"])
    assert val_a == ["awx.awx", "ansible.builtin"]

# Generated at 2022-06-23 06:07:22.011378
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    # Test FieldAttribute object
    assert isinstance(search, CollectionSearch)

# Generated at 2022-06-23 06:07:29.249740
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        def __init__(self, ds):
            super(TestCollectionSearch, self).__init__()
            self._load_ds_attributes(ds)

    c = TestCollectionSearch({})
    assert c._collections == ['ansible.builtin']

    c = TestCollectionSearch({'collections': ['test']})
    assert c._collections == ['test', 'ansible.builtin']

# Generated at 2022-06-23 06:07:29.826939
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_search = CollectionSearch()
    assert test_search

# Generated at 2022-06-23 06:07:30.689253
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch

# Generated at 2022-06-23 06:07:35.362513
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().get_validated_value('collections', CollectionSearch._collections, None, None) == _ensure_default_collection()
    assert CollectionSearch().get_validated_value('collections', CollectionSearch._collections, ['test'], None) == _ensure_default_collection(collection_list=['test'])

# Generated at 2022-06-23 06:07:37.796458
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections("_collections", "_collections") == ["ansible.builtin"]

# Generated at 2022-06-23 06:07:45.291442
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # _collections is a FieldAttribute object
    assert isinstance(cs._collections, FieldAttribute)

    # _collections has list as a base
    assert 'list' in cs._collections.isa

    # _collections has listof = string_types
    assert cs._collections.listof == string_types

    # _collections has priority 100
    assert cs._collections.priority == 100

    # _collections has _ensure_default_collection as default
    assert cs._collections.default == _ensure_default_collection

    # _collections has always_post_validate = True
    assert cs._collections.always_post_validate

    # _collections has static = True
    assert cs._collections.static

# Generated at 2022-06-23 06:07:46.823191
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch

# Generated at 2022-06-23 06:07:55.023431
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible_collections
    import types
    import sys

    myclass = TaskInclude()

    assert type(myclass._collections) is types.FunctionType
    assert hasattr(myclass, "get_validated_value")
    assert hasattr(myclass, "_load_collections")
    assert len(sys.modules[ansible_collections.__spec__.name].__path__) == 4
    assert type(myclass) is TaskInclude

# Generated at 2022-06-23 06:07:57.239637
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections is not None


if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:08:00.451810
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.collections = 'ansible.builtin'
    assert search.collections == 'ansible.builtin'

# Generated at 2022-06-23 06:08:02.508371
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections._get_default() == _ensure_default_collection()

# Generated at 2022-06-23 06:08:11.578713
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import sys
    from collections import namedtuple

    # This is an example of namedtuple object.
    # This object is used to store a task object's data.
    # The object is passed to CollectionSearch object's constructor.
    # This object is a task object which is a class instance.
    # So, we are providing the attributes of a task object in the form of a dictionary.
    # The dictionary's keys are the attributes of the task object and
    # the dictionary's values are the values of the attributes of the task object.
    TaskObject = namedtuple('TaskObject',
                            ['_attributes', '_name', '_ds', '_loader', '_task_blocks', '_parent'])


# Generated at 2022-06-23 06:08:16.294441
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Given
    collection_name = "ansible_collections.test_name"
    data = dict(collections=[collection_name])

    # When
    collection_search = CollectionSearch(data, dict())

    # Then
    assert collection_search.collections == [collection_name]

# Generated at 2022-06-23 06:08:18.040936
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:08:19.667225
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection(), 'The collections is empty'

# Generated at 2022-06-23 06:08:22.504764
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test class constructor with default values
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.legacy']

# Generated at 2022-06-23 06:08:23.921615
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:08:28.869181
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections('collections', None) is None
    assert cs._load_collections('collections', []) is None
    assert cs._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin']
    assert cs._load_collections('collections', ['collection.foo']) == ['collection.foo', 'ansible.builtin']

# Generated at 2022-06-23 06:08:30.070804
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print('Passed.')


# Generated at 2022-06-23 06:08:34.947098
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    display.warning(collection_search._collections)

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:08:37.008396
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play import Play
    p = Play()
    p.post_validate()

# Generated at 2022-06-23 06:08:39.451462
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ob = CollectionSearch()
    assert 'ansible.legacy' in ob._load_collections(None,None)

# Generated at 2022-06-23 06:08:41.431312
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_object = CollectionSearch()
    print(collection_search_object._collections)


# Generated at 2022-06-23 06:08:44.437081
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    # this test is to check whether the implemented constructor gets called and
    # it is able to assign a default value for the class attribute _collections
    assert collectionsearch._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:08:54.996427
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    c_collections = c._load_collections(attr='collections', ds=[])
    assert c_collections[0] == 'ansible.builtin'
    c_collections = c._load_collections(attr='collections', ds=['collections','another_one'])
    assert c_collections[0] == 'ansible.builtin'
    assert len(c_collections) == 3
    c_collections = c._load_collections(attr='collections', ds=None)
    assert c_collections[0] == 'ansible.builtin'
    assert len(c_collections) == 1

# Generated at 2022-06-23 06:08:58.272464
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestClass(CollectionSearch):
        # pylint: disable=too-few-public-methods
        pass

    test_instance = TestClass()
    assert test_instance.get_value('collections') == ['ansible.legacy']

# Generated at 2022-06-23 06:08:59.167803
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()

# Generated at 2022-06-23 06:09:02.842788
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.post_validate(dict(), None)
    assert search._collections == _ensure_default_collection()



# Generated at 2022-06-23 06:09:06.273286
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collections = collection_search._load_collections('collections',
                                                      [{'collections': 'ansible.netcommon'}])
    assert collections == ['ansible.netcommon']


# Generated at 2022-06-23 06:09:10.335384
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    result = obj._collections.default()
    assert result is not None
    assert result == _ensure_default_collection()


# Generated at 2022-06-23 06:09:13.463156
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    display.warning("test_CollectionSearch Warning: %s" % search._collections)
    display.warning("test_CollectionSearch Warning: %s" % search._load_collections(None, None))

# Generated at 2022-06-23 06:09:14.799744
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_collections = CollectionSearch()
    print(my_collections._collections)

# Generated at 2022-06-23 06:09:16.893659
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:18.450958
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-23 06:09:25.913964
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context._collections = ['faketest.collectiontotest']

    obj = CollectionSearch()
    assert obj._load_collections(None, play_context) == ['faketest.collectiontotest']

    play_context._collections = None

    obj = CollectionSearch()
    assert obj._load_collections(None, play_context) == ['ansible.legacy']

# Generated at 2022-06-23 06:09:27.414308
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(CollectionSearch._ensure_default_collection() == ['ansible.builtin', 'ansible.legacy'])

# Generated at 2022-06-23 06:09:34.090288
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs1 = CollectionSearch()
    print(cs1.__dict__)
    print(cs1.get_validated_value('collections', cs1._collections, None, None))
    print(cs1.__dict__)


# Unit test of _ensure_default_collection

# Generated at 2022-06-23 06:09:39.839572
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Can construct an instance of CollectionSearch
    CollectionSearch()
    # Cannot construct an instance of CollectionSearch with unknown argument
    try:
        CollectionSearch(unknown_arg="unknown")
    except TypeError as e:
        assert 'unknown keyword' in str(e)
    # Can access _ensure_default_collection
    _ensure_default_collection()

# Generated at 2022-06-23 06:09:43.667861
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    setattr(col, "collections", "ansible.builtin")

    assert col.collections == "ansible.builtin"

# Generated at 2022-06-23 06:09:52.880308
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    attr = "collections"
    ds = [
        'ansible.builtin',
        'ansible.legacy',
        'ansible_collections.stackstorm.st2',
        'ansible_collections.stackstorm.st2_pack_ec2',
        'ansible_collections.stackstorm.st2_pack_hosts'
    ]
    collection_search = CollectionSearch()

    # If collections are not specified, it should return the default collection
    assert collection_search._collections.default() == _ensure_default_collection()
    assert collection_search._collections.default() == ['ansible.builtin', 'ansible.legacy']

    # If the the ds is None, it should return the default collection

# Generated at 2022-06-23 06:09:56.098352
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    srcdict = {'collections': ['my.collection']}
    c = CollectionSearch(data=srcdict, variable_manager={})
    # TODO: add more tests for validation and templating

# Generated at 2022-06-23 06:09:57.556487
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == None

# Generated at 2022-06-23 06:10:00.953382
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == _ensure_default_collection()

    c = CollectionSearch(collections=['nsmb.my_collection'])
    assert c.collections == ['nsmb.my_collection']

# Generated at 2022-06-23 06:10:03.342454
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:10:04.416366
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert not CollectionSearch._collections.has_default()

# Generated at 2022-06-23 06:10:13.932438
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == cs._ensure_default_collection
    assert cs._collections.static == True
    assert cs._collections.always_post_validate == True
    assert cs._collections.priority == 100
    assert cs._collections.private is False
    assert cs._collections.isa == 'list'
    assert cs._collections.listof == string_types
    assert _ensure_default_collection() == ['ansible_collections.ansible.builtin']
    assert cs._load_collections(None, ['ansible_collections.ansible.builtin']) == ['ansible_collections.ansible.builtin']

# Generated at 2022-06-23 06:10:19.991553
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert not collectionSearch.collections
    collectionSearch.collections.append('ansible.builtins')
    collectionSearch.collections.append('ansible.test')
    assert list(collectionSearch.collections).__contains__('ansible.builtins')
    assert list(collectionSearch.collections).__contains__('ansible.test')

# Generated at 2022-06-23 06:10:21.500238
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-23 06:10:24.455539
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:28.861820
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an instance of CollectionSearch class to test
    obj_collectionsearch = CollectionSearch()
    # Check the instance of the class
    assert isinstance(obj_collectionsearch, CollectionSearch)
    # Check the type of collections variable
    assert isinstance(obj_collectionsearch._collections, FieldAttribute)
    # Check the default value for collections variable
    assert obj_collectionsearch._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:10:33.130460
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task import Task
    # TODO(nop): maybe add something?
    collection_search = CollectionSearch()
    assert collection_search.collections is None

# Generated at 2022-06-23 06:10:41.875454
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    setattr(test_CollectionSearch,'_collections', None)
    assert not hasattr(test_CollectionSearch,'_collections')
    class Obj(CollectionSearch):
        collections = ['ansible.builtin.test']
        pass
    assert hasattr(test_CollectionSearch,'_collections')
    setattr(test_CollectionSearch,'_collections', None)
    assert not hasattr(test_CollectionSearch,'_collections')
    Obj()
    assert hasattr(test_CollectionSearch,'_collections')
    assert test_CollectionSearch._collections == ['ansible.builtin.test']
    assert len(test_CollectionSearch._collections) == 1

# Generated at 2022-06-23 06:10:45.845491
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test case
    collection_search = CollectionSearch()
    assert collection_search._collections.default == _ensure_default_collection
    assert collection_search.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:47.749263
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default() == _ensure_default_collection()

# Generated at 2022-06-23 06:10:48.841981
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == None

# Generated at 2022-06-23 06:10:57.198298
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_search = CollectionSearch()
    assert test_search._load_collections('collections', None) == None
    assert test_search._load_collections('collections', 'ansible.builtin') == ['ansible.builtin']
    assert test_search._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin']
    assert test_search._load_collections('collections', ['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:11:02.301913
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This is a test for a very simple class, the CollectionSearch
    # class exists to set some default values, the methods of this class
    # are not used by the _load_collections method
    assert isinstance(CollectionSearch()._collections, FieldAttribute)

# Generated at 2022-06-23 06:11:07.008920
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs =CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert cs._collections == []
    ds = ['cn1', 'cn2']
    ds_ret = cs._load_collections(None, ds)
    assert ds_ret == ds
    assert cs._collections == ds

# Generated at 2022-06-23 06:11:12.730480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.value is not None
    assert collection_search._collections.value[0] == 'ansible_collections'
    assert len(collection_search._collections.value) == 1
    assert collection_search._collections.type == 'list'
    assert collection_search._collections.type_name == 'list'

# Generated at 2022-06-23 06:11:19.112333
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testsearch = CollectionSearch()

    #test default constructor
    print("\nTesting CollectionSearch with default constructor.")
    print("Collections: " + str(testsearch.collections))
    if (testsearch.collections == None):
        print("Passed.")
    else:
        print("Failed.")

    #test constructor with parameter
    print("\nTesting CollectionSearch with constructor with parameter.")
    testsearch = CollectionSearch(collections=['test_collection'])
    print("Collections: " + str(testsearch.collections))
    if (testsearch.collections == ['test_collection']):
        print("Passed.")
    else:
        print("Failed.")

    #test constructor with parameter and its value is None
    print ("\nTesting CollectionSearch with constructor with parameter and its value is None.")
    testsearch = Collection

# Generated at 2022-06-23 06:11:21.149359
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:28.085595
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.role import Role
    r = Role()
    r._collections_manager = {}

    # with empty collections value
    assert r._get_collections(None) == [1, 'ansible.legacy']

    # with not empty collections value
    assert r._get_collections(['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']

    # with "default" collections value
    assert r._get_collections([1]) == [1, 'ansible.legacy']

# Generated at 2022-06-23 06:11:29.179876
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-23 06:11:30.343881
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch, '_load_collections')

# Generated at 2022-06-23 06:11:31.604202
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-23 06:11:40.605110
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    collections._collections = [
        'ansible.builtin',
        'ansible.legacy',
        'ansible_collections.rubrik',
        'ansible_collections.rubrik.cdm',
        'ansible_collections.rubrik.cdm.v1',
        'ansible_collections.rubrik.cdm.v1.rubrik_host_update'
    ]
    assert collections._collections == ['ansible_collections.rubrik.cdm.v1.rubrik_host_update', 'ansible.builtin', 'ansible.legacy', 'ansible_collections.rubrik', 'ansible_collections.rubrik.cdm', 'ansible_collections.rubrik.cdm.v1']

# Generated at 2022-06-23 06:11:41.695425
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  collection_search = CollectionSearch()
  assert collection_search is not None

# Generated at 2022-06-23 06:11:47.505104
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    _collection_search_obj = CollectionSearch()
    # Should return False, as no attributes are present on the class
    assert not hasattr(_collection_search_obj, 'collections')

    assert not hasattr(_collection_search_obj, '_load_collections')



# Generated at 2022-06-23 06:11:54.798501
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._load_collections(None, None) is None
    assert CollectionSearch._load_collections(None, ['']) is None
    assert CollectionSearch._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']
    assert CollectionSearch._load_collections(None, ['ansible.builtin', 'test']) == ['ansible.builtin', 'test']

# Generated at 2022-06-23 06:12:02.915160
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test Case 1: field "collections" is None
    init_collections = ""
    CollectionSearch()._load_collections(init_collections, None)

    # Test Case 2: field "collections" is a list of strings
    init_collections = ["ansible.builtin"]
    CollectionSearch()._load_collections(init_collections, None)

    # Test Case 3: field "collections" is a list of string and template
    init_collections = ["ansible.builtin", "{{ 'ansible.networking' }}"]
    CollectionSearch()._load_collections(init_collections, None)


# Generated at 2022-06-23 06:12:09.019886
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test with no parameter
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()

    # Test with parameter
    cs = CollectionSearch(collections=['ansible.builtin'])
    assert cs.collections == _ensure_default_collection(collections=['ansible.builtin'])

# Generated at 2022-06-23 06:12:15.959568
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This constructor is not intented to be called directly.
    # It should be instantiated through an inherited class ( e.g. Task ).
    # So the following test does not have any real sence.
    try:
        collection_search = CollectionSearch('name')
    except TypeError:
        pass

# Generated at 2022-06-23 06:12:17.246454
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search._load_collections()

# Generated at 2022-06-23 06:12:24.916512
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection
    cs2 = CollectionSearch(collections=['ansible.builtin'])
    assert cs2._collections == ['ansible.builtin']
    cs3 = CollectionSearch(collections=['ansible.builtin', 'my.collection'])
    assert cs3._collections == ['my.collection', 'ansible.builtin']
    assert cs2._collections != cs3._collections

# Generated at 2022-06-23 06:12:30.136500
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    csearch = CollectionSearch()
    csearch.collections = None
    assert csearch.collections == ['ansible.builtin'], 'Could not set a value for collections'
    csearch.collections = ['test_collection.test']
    assert csearch.collections == ['test_collection.test', 'ansible.builtin'], 'Could not set a value for collections'
    csearch = CollectionSearch()
    csearch.collections = ['test_collection.test']
    assert csearch.collections == ['test_collection.test', 'ansible.builtin'], 'Could not set a value for collections'

# Generated at 2022-06-23 06:12:35.744495
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test for constructor for class CollectionSearch
    search = CollectionSearch()
    # Test for the attribute '_collections'
    assert search._collections is not None
    assert len(search._collections) == 1
    assert 'ansible.builtin' in search._collections


# Test for the function '_ensure_default_collection'

# Generated at 2022-06-23 06:12:37.752926
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:12:39.813476
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:12:40.417849
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:12:44.181081
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CS = CollectionSearch()
    assert CS._load_collections('collections', ['ansible.builtin', 'test.test_collection']) == ['ansible.builtin', 'test.test_collection']
    assert CS._load_collections('collections', []) == ['ansible.legacy']


# Generated at 2022-06-23 06:12:45.949760
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)

    

# Generated at 2022-06-23 06:12:51.778415
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    
    with pytest.raises(AssertionError):
        CollectionSearch()

    obj = CollectionSearch.__new__(CollectionSearch)
    assert isinstance(obj,CollectionSearch)
    
    assert hasattr(obj,'_collections')
    assert hasattr(obj,'_load_collections')

# Generated at 2022-06-23 06:12:53.474638
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:13:02.049563
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    t = CollectionSearch()
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.check_mode = True
    play_context.become = True
    play_context.become_method = 'sudo'
    _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)

# Generated at 2022-06-23 06:13:03.529692
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:13:13.373589
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.name == 'collections'
    assert cs._collections.isa == 'list'
    assert cs._collections.listof == str
    assert cs._collections.default is _ensure_default_collection
    assert cs._collections.always_post_validate is True
    assert cs._collections.static is True
    assert cs._collections.priority == 100

    # Test that _ensure_default_collection works
    assert _ensure_default_collection() == ['ansible_collections.ansible.builtin.tasks']
    assert _ensure_default_collection() == ['ansible_collections.ansible.builtin.tasks']

    # Test that _ensure_default_collection works