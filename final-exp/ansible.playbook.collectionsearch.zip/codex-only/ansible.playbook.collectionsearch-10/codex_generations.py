

# Generated at 2022-06-23 06:03:16.827215
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']
    assert collection_search._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin']
    assert collection_search._load_collections('collections', []) == None

# Generated at 2022-06-23 06:03:19.174472
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    print(c.collections)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:03:20.380268
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)

# Generated at 2022-06-23 06:03:21.584484
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Tested at: test_task_loader, test_role_loader
    pass

# Generated at 2022-06-23 06:03:26.129788
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj._collections = ['ansible.builtin']
    obj.collections = _ensure_default_collection()
    assert obj._collections == _ensure_default_collection(obj.collections), "test failed"

# Generated at 2022-06-23 06:03:28.412755
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    assert play_context.collections is not None

# Generated at 2022-06-23 06:03:30.825950
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']
    assert cs._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:03:31.564524
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.post_validate(loader=None, templar=None)

# Generated at 2022-06-23 06:03:36.796233
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test(CollectionSearch):
        pass
    t = Test()
    assert t.collections is not None
    t.collections = ['a', 'b']
    assert t.collections == ['a', 'b']


# Generated at 2022-06-23 06:03:42.610639
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default is _ensure_default_collection
    assert cs._collections.always_post_validate is True
    assert cs._collections.static is True
    assert cs._collections.priority == 100
    assert cs._collections.isa == 'list'
    assert cs._collections.listof is string_types

# Generated at 2022-06-23 06:03:49.546620
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test empty case
    res = CollectionSearch()
    assert res._collections is not None
    assert res._collections == _ensure_default_collection()

    # Test default collections use-case
    res = CollectionSearch(collections=_ensure_default_collection())
    assert res._collections is not None
    assert res._collections == _ensure_default_collection()

    # Test collections list is not None, it uses _ensure_default_collection
    # to fill the list
    res = CollectionSearch(collections=None)
    assert res._collections is not None
    assert res._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:03:52.056925
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None
    

# Generated at 2022-06-23 06:03:54.342332
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj1 = CollectionSearch()
    obj1._collections = ['']
    assert obj1._collections == ['']

# Generated at 2022-06-23 06:03:56.160917
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible_collections.my_namespace.my_collection']

# Generated at 2022-06-23 06:03:58.058951
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass
    cs = TestCollectionSearch()
    assert cs.collections is not None

# Generated at 2022-06-23 06:03:59.093987
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    module = CollectionSearch()
    assert module._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:04.365128
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ''' Unit test for CollectionSearch constructor '''
    test_module = CollectionSearch()
    collections = test_module._load_collections(None, ['collections.azure'])
    assert collections is not None
    assert len(collections) == 2
    assert collections[0] == 'collections.azure'
    assert collections[1] == 'ansible.builtin'
    collections = test_module._load_collections(None, ['collections.azure', 'collections.google'])
    assert collections is not None
    assert len(collections) == 3
    assert collections[0] == 'collections.azure'
    assert collections[1] == 'collections.google'
    assert collections[2] == 'ansible.builtin'

# Generated at 2022-06-23 06:04:13.626840
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # test case when none collection is passed to the constructor
    assert cs._collections is None
    # test case when a collection_list is passed to the constructor
    cs = CollectionSearch(_collections = ['ansible.builtin', 'awx.awx.notifier'])
    assert cs._collections[0] == 'ansible.builtin'
    assert cs._collections[1] == 'awx.awx.notifier'
    # test case when a malformed collection_list is passed to the constructor
    try:
        cs = CollectionSearch(_collections = ['ansible..builtin', 1])
        assert False
    except:
        assert True
    

# Generated at 2022-06-23 06:04:16.847092
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None
    collections = collection_search._load_collections(None, ['ansible_collection.collectionA', 'ansible_collection.collectionB'])
    assert collections == collection_search._collections

# Generated at 2022-06-23 06:04:18.498914
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections is not None

# Generated at 2022-06-23 06:04:22.694814
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.default == _ensure_default_collection
    assert c.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:27.572441
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    if not isinstance(obj, CollectionSearch):
        print('Failed to create instance of class CollectionSearch')
        return 1
    return 0


if __name__ == '__main__':
    result = test_CollectionSearch()
    exit(result)

# Generated at 2022-06-23 06:04:28.057609
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

# Generated at 2022-06-23 06:04:29.398533
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:32.969654
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections == ['ansible_collections.ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-23 06:04:34.883871
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj_class = CollectionSearch()
    assert isinstance(obj_class, CollectionSearch)


# Generated at 2022-06-23 06:04:38.020156
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    data = {"collections":["ansible_namespace.my_collection"]}
    obj = CollectionSearch(data, [])
    assert obj._collections == ['ansible_namespace.my_collection']

# Generated at 2022-06-23 06:04:39.596776
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj._load_collections(attr='collections', ds=None)

# Generated at 2022-06-23 06:04:46.130882
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert ['ansible.builtin'] == cs._load_collections('collections', None)
    assert ['ansible.builtin', 'foo.bar'] == cs._load_collections('collections', ['foo.bar'])
    assert ['ansible.builtin', 'foo.bar'] == cs._load_collections('collections', ['foo.bar'])
    assert ['ansible.builtin', 'foo.bar'] == cs._load_collections('collections', ['foo.bar'])
    assert [] == cs._load_collections('collections', [])

# Generated at 2022-06-23 06:04:54.779282
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections.default == "ansible_collections.azure.azcollection"
    assert collection._collections.type == "[<class 'ansible.module_utils.six.string_types'>, <class 'ansible.module_utils.six.string_types'>, <class 'ansible.module_utils.six.string_types'>]"

    assert collection._load_collections("collections",['ansible.builtin']) == ['ansible.builtin']
    assert collection._load_collections("collections",['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']

    assert collection._load_collections("collections",['foo']) == ['foo', 'ansible.legacy']
    assert collection._load_col

# Generated at 2022-06-23 06:05:02.671700
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.module_utils.common.collections import CollectionSearch
    from ansible.module_utils.common.collections import _ensure_default_collection
    # Assert that the class CollectionSearch exists
    test_CollectionSearch = isinstance(CollectionSearch, type)
    assert test_CollectionSearch is True
    # Assert that the function _ensure_default_collection exists
    test__ensure_default_collection = callable(_ensure_default_collection)
    assert test__ensure_default_collection is True

# Generated at 2022-06-23 06:05:04.574679
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    assert collectionsearch._collections == 'ansible.builtin'

# Generated at 2022-06-23 06:05:07.257077
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    expected_collections = _ensure_default_collection()
    cs = CollectionSearch()
    collections = cs.collections
    assert collections == expected_collections

# Generated at 2022-06-23 06:05:10.636868
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Initialization tests
    try:
        CollectionSearch()
    except Exception as e:
        # Assert if there is an exception when initializing
        assert False


# Generated at 2022-06-23 06:05:13.395177
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_search = CollectionSearch()
    assert coll_search
    assert coll_search._load_collections

# Generated at 2022-06-23 06:05:22.060331
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from collections import namedtuple
    from ansible.playbook.attribute import Attribute

    collections = Attribute()
    test_input = namedtuple('test_input', ['collections'])
    test_result = namedtuple('test_result', ['collections'])

    # Tuple of test inputs and results. This tuple is passed
    # as an argument to the namedtuple() call in the mock.patch
    # decorator.

# Generated at 2022-06-23 06:05:31.396496
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import copy
    dummy_ds = copy.deepcopy(__import__('ansible.parsing.dataloader').DataLoader().load_from_file('/etc/ansible/hosts'))

    # test for callable
    class Foo(CollectionSearch):
        collections = _ensure_default_collection

    foo = Foo()
    assert isinstance(foo._load_collections('collections', dummy_ds), list)

    # test for list of strings
    class Foo(CollectionSearch):
        collections = ['test1', 'test2']

    foo = Foo()
    assert isinstance(foo._load_collections('collections', dummy_ds), list)

# Generated at 2022-06-23 06:05:32.905641
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert ['ansible.builtin'] == cs._collections.default

# Generated at 2022-06-23 06:05:34.473244
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert isinstance(x, CollectionSearch)



# Generated at 2022-06-23 06:05:36.859535
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch._ensure_default_collection()
    print(result)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:05:38.631261
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.value == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:05:40.330696
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == 'ansible.builtin,ansible.legacy'

# Generated at 2022-06-23 06:05:43.519521
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.post_validate([], {})

    collection_search = CollectionSearch()
    collection_search.post_validate(['nsweb.common'], {})

# Generated at 2022-06-23 06:05:53.630353
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This test is for default value of collections, which is ansible.builtin when no
    # collection is mentioned in the playbook
    # collections = ansible.builtin
    # collections = [ansible.builtin, collection_name]
    test_obj = CollectionSearch()
    collections = test_obj._load_collections('collections', ['collection_name'])
    assert collections == ['ansible.builtin', 'collection_name']

    # collections = [ansible.builtin, collection1, collection2]
    collections = test_obj._load_collections('collections', ['collection1', 'collection2'])
    assert collections == ['ansible.builtin', 'collection1', 'collection2']



# Generated at 2022-06-23 06:05:58.400743
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.role import Role
    role = Role.load('test')
    role.post_validate(loader=None, templar=None)
    assert role.collections == ['ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-23 06:06:00.740076
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()



# Generated at 2022-06-23 06:06:02.419142
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-23 06:06:08.865944
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections('collections', ['my.collection', 'my.invalid.collection']) == ['my.collection', 'my.invalid.collection']
    assert cs._load_collections('collections', []) == ['ansible.builtin', 'ansible.legacy']
    assert cs._load_collections('collections', None) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:06:09.791260
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch,object)

# Generated at 2022-06-23 06:06:11.966482
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    val = search._collections.post_validate(['ansible.builtin'])
    assert val == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:06:16.715130
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    load_collections = CollectionSearch()
    display.warning()
    load_collections._load_collections(attr='collections', ds=_ensure_default_collection())

# Generated at 2022-06-23 06:06:18.745887
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert isinstance(collectionSearch, CollectionSearch)
    assert isinstance(collectionSearch._collections, FieldAttribute)


# Generated at 2022-06-23 06:06:20.084540
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    if len(t.collections) == 0:
        raise Exception("Incorrect value for constructor")

# Generated at 2022-06-23 06:06:26.758050
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    assert _ensure_default_collection(['ansible.builtin']) == ['ansible.builtin']
    assert _ensure_default_collection(['ansible.builtin', 'ansible.builtin']) == ['ansible.builtin']
    assert _ensure_default_collection(['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-23 06:06:29.368041
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == None

# Generated at 2022-06-23 06:06:33.613920
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    assert(isinstance(CollectionSearch.static_vars['_collections'], FieldAttribute))

    del CollectionSearch.static_vars['_collections']
    assert not (CollectionSearch.static_vars['_collections'])

    assert(isinstance(CollectionSearch._collections, FieldAttribute))

# Generated at 2022-06-23 06:06:43.400963
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    task_ds = {'name': 'create_config',
               'collections': ['geerlingguy.apache', 'geerlingguy.php']}
    task = CollectionSearch(task_ds)
    task_collections = task.get_validated_value('collections')
    assert len(task_collections) == 3
    assert task_collections[0] == 'ansible_collections.geerlingguy.apache'
    assert task_collections[1] == 'ansible_collections.geerlingguy.php'
    assert task_collections[2] == 'ansible.builtin'

# Generated at 2022-06-23 06:06:46.601352
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Instance of class Playbook
    playbook = Playbook()
    # Testing constructor of class CollectionSearch
    CollectionSearch(playbook)
    assert playbook.collections == ['ansible_collections.community.general', 'ansible.builtin']

# Test for attribute collections

# Generated at 2022-06-23 06:06:49.321143
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()

# Generated at 2022-06-23 06:06:55.700523
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def _ensure_default_collection_mock(value):
        if value is None:
            return ['ansible.builtin']
        else:
            return value
    return_val = 'ansible.builtin'
    CollectionSearch._ensure_default_collection = _ensure_default_collection_mock
    assert(CollectionSearch._collections.default() == return_val)
    # checking for a non empty value
    assert(CollectionSearch._collections.default(value=['ansible.builtin']) == return_val)
    # to check for a None value
    assert(CollectionSearch._collections.default(value=None) == return_val)

# Generated at 2022-06-23 06:07:03.800636
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.module_utils.common.collections import ImmutableDict

    # mocked FieldAttribute for testing
    class ImmutableFieldAttribute(FieldAttribute):
        def __init__(self, *args, **kwargs):
            super(FieldAttribute, self).__init__(*args, **kwargs)
            self._data.immutable = True

    # mocked Base
    class MockedBase(Base):
        def __init__(self, *args, **kwargs):
            super(Base, self).__init__(*args, **kwargs)
            self._attributes = ImmutableDict()

    test_collections = ['ansible.builtin', 'namespace.collection']
    test_class = MockedBase()
    test_class._attributes['collections'] = Immutable

# Generated at 2022-06-23 06:07:07.008906
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj._collections = ['ansible.builtin', 'ansible.legacy']
    assert obj._load_collections(obj._collections, None)

# Generated at 2022-06-23 06:07:17.128641
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()

# Generated at 2022-06-23 06:07:21.107992
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Used for testing the constructor of CollectionSearch
    """
    c = CollectionSearch()

    assert c._collections.value == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-23 06:07:22.441504
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_obj = CollectionSearch()
    assert collection_list is None

# Generated at 2022-06-23 06:07:24.709887
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    o = CollectionSearch()
    assert o.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:27.077198
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-23 06:07:30.869581
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test _load_collections
    class MyClass(object):
        def _load_collections(self, attr, ds):
            return None
    c = MyClass()
    assert c._load_collections('collections', None) is None

# Generated at 2022-06-23 06:07:32.141963
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs != None

# Generated at 2022-06-23 06:07:33.890056
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()
    assert (collection_search._collections[0] == 'ansible.builtin')

# Generated at 2022-06-23 06:07:35.202624
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is not None

# Generated at 2022-06-23 06:07:37.966552
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # initialize object
    obj = CollectionSearch()

    # Check whether collection is not None
    assert obj.collections is not None
    assert obj.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:07:41.228291
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    default_collection = AnsibleCollectionConfig.default_collection
    assert search._collections.default_for_object([default_collection]) == [default_collection]
    assert search._collections.default_for_object(None) == [default_collection]

# Generated at 2022-06-23 06:07:43.549073
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collections_value = collection_search._collections.post_validate(None, None)
    assert collections_value == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:07:45.924149
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    if collection_search is None:
        raise AssertionError('Constructor of class CollectionSearch failed')

# Generated at 2022-06-23 06:07:47.362419
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t



# Generated at 2022-06-23 06:07:49.101689
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testObj = CollectionSearch()
    assert testObj._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:51.401945
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch(collections=None)
    assert collection_search.collections is not None

# Generated at 2022-06-23 06:07:54.897327
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert cs._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:07:59.359147
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    display.warning = lambda msg: msg
    collection_search = CollectionSearch()
    _load_collections = collection_search._load_collections
    _load_collections(attr='collections', ds=None)
    _load_collections(attr='collections', ds=['role', 'sample.role2'])

# Generated at 2022-06-23 06:08:03.301880
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    if c._collections is None:
        print("_collections should not be None")
    print(c._collections)
    if c._load_collections('foo', 'bar') == None:
        print("_load_collections should not return None")

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:08:09.082750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_cases = [
        (['foo'], ['foo']),
        ([], ['ansible.builtin']),
        (None, ['ansible.builtin']),
        ([None], ['ansible.builtin']),
    ]

    for value, expected in test_cases:
        search_obj = CollectionSearch()
        search_obj._load_collections(None, value)
        assert search_obj._collections == expected

# Generated at 2022-06-23 06:08:17.400792
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert(collection_search.collections == ['community.general', 'ansible.builtin', 'ansible.legacy'])

    # Test to ensure that when None is passed, the list contains only builtin and legacy
    # collection names
    # https://github.com/ansible/ansible/issues/55238
    collection_search = CollectionSearch(None)
    assert(collection_search.collections == ['ansible.builtin', 'ansible.legacy'])

# Generated at 2022-06-23 06:08:20.689215
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections == None
    collectionSearch.__dict__['_collections'] = "test"
    assert collectionSearch._collections == "test"



# Generated at 2022-06-23 06:08:22.460926
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ['ansible.builtin']



# Generated at 2022-06-23 06:08:23.836594
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    print(a)

# test_CollectionSearch()

# Generated at 2022-06-23 06:08:24.669671
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()

# Generated at 2022-06-23 06:08:27.708920
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import IncludeRole
    from ansible.utils.color import stringc
    include_role = IncludeRole()
    assert include_role.collections is None, 'CollectionSearch object "collections" attribute is not None.'

# Generated at 2022-06-23 06:08:28.869159
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert not search._collections

# Generated at 2022-06-23 06:08:30.508628
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs._collections)
    assert cs._collections is not None

# Generated at 2022-06-23 06:08:35.634310
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert isinstance(collectionSearch._collections, FieldAttribute)
    assert collectionSearch._collections.__repr__()
    assert collectionSearch._load_collections(0, 0)

# Generated at 2022-06-23 06:08:37.696239
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search,CollectionSearch)


# Generated at 2022-06-23 06:08:43.324193
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # Fields default to an empty list
    assert collection_search.collections == []
    # Post validate logic puts "default" collection first
    # so it can be used later
    collection_search.post_validate('task')
    assert collection_search.collections[0] == 'ansible_collections.ansible.builtin'

# Generated at 2022-06-23 06:08:44.636733
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert isinstance(collection, CollectionSearch)

# Generated at 2022-06-23 06:08:47.207057
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # TODO: write a unit test for CollectionSearch
    pass

# Generated at 2022-06-23 06:08:48.408412
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # TODO; rewrite to a unit test
    pass

# Generated at 2022-06-23 06:08:53.506670
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert cs._load_collections(None, ["ansible.builtin"]) == ["ansible.builtin"]

    assert cs._load_collections(None, ["ansible.builtin", "ansible.netcommon"]) == ["ansible.builtin", "ansible.netcommon", "ansible.legacy"]

# Generated at 2022-06-23 06:08:56.840837
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj.collections == None
    assert test_obj._load_collections(None, None) == None
    assert test_obj._collections == None

# Generated at 2022-06-23 06:08:58.348512
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.collections = "ansible.builtin"

# Generated at 2022-06-23 06:09:05.952429
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    import tempfile

    t = tempfile.NamedTemporaryFile(delete=False)
    t.write("""- collections:
    - test_collection
    - test_another""")
    t.close()

    c = CollectionSearch()
    c._load_collections("collections", os.path.abspath(t.name))
    assert c._collections == {'collections': [u'test_collection', u'test_another']}

    os.unlink(t.name)

# Generated at 2022-06-23 06:09:09.492679
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections is not None
    assert(test._collections == _ensure_default_collection())

# Generated at 2022-06-23 06:09:11.430272
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance1 = CollectionSearch()
    print(instance1)
    print(instance1._collections)

# test_CollectionSearch()

# Generated at 2022-06-23 06:09:13.373192
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs._collections, FieldAttribute)



# Generated at 2022-06-23 06:09:17.286489
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # test get_validated_value(...)
    assert cs.get_validated_value('collections', cs._collections, ['test.ansible_test_collection'], None) == ['test.ansible_test_collection', 'ansible.builtin']
    assert cs.get_validated_value('test', cs._collections, ['test.ansible_test_collection'], None) == ['test.ansible_test_collection', 'ansible.builtin']

# Ut function for _load_collections(...)

# Generated at 2022-06-23 06:09:18.634104
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ['ansible.builtin']

# Generated at 2022-06-23 06:09:29.262047
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import RoleInclude
    import os
    import os.path
    import sys
    import json

    my_path = os.path.dirname(os.path.abspath(__file__))
    path = my_path + '/../../examples/'

    # Load data and create object
    with open(path + 'roles/good_role/tasks/main.yaml', 'r') as stream:
        data = yaml.load(stream, Loader=yaml.FullLoader)

    my_object = RoleInclude()
    my_object._load_data(data)

    # Check object
    assert (my_object.name == 'good_role')

    # Clean
    my_object = None

# Generated at 2022-06-23 06:09:32.446238
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin','ansible.legacy']


# Generated at 2022-06-23 06:09:34.398381
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections is not None

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:09:36.674717
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection.collections is None
#test_CollectionSearch()

# Generated at 2022-06-23 06:09:43.300109
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class myTest:
        pass

    obj = myTest()
    cs = CollectionSearch()
    cs._collections.inject(obj)

    obj.collections = ['a', 'b']
    obj._load_collections('collections', None)

    obj.collections = ['ansible.builtin']
    obj._load_collections('collections', None)

    obj.collections = []
    obj._load_collections('collections', None)

# Generated at 2022-06-23 06:09:52.231814
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  import os
  from ansible.module_utils.common.collections import CollectionLoader
  loader = CollectionLoader()
  try:
    loader.find_collections_in_path(os.path.abspath('.'))
  except Exception:
    pass
  test = CollectionSearch()
  output = test._load_collections(None, ['test'])
  assert 'ansible.builtin' in output

# Generated at 2022-06-23 06:09:56.544994
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    _result = test_obj.get_field_value('collections')
    assert isinstance(_result, list)
    assert _result[0] == 'ansible.builtin'
    assert ((len(_result) == 1) or (_result[1] == 'ansible.builtin'))

# Generated at 2022-06-23 06:10:01.521692
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._load_collections(None, ['ansible.builtin']) is not None
    assert CollectionSearch._load_collections(None, ['ansible.legacy']) is not None
    assert CollectionSearch._load_collections(None, ['ansible.builtin', 'ansible.legacy']) is not None
    assert CollectionSearch._collections is not None

# Generated at 2022-06-23 06:10:02.678600
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-23 06:10:04.050593
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-23 06:10:04.637734
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-23 06:10:06.516804
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.post_validate()
    assert search.collections is not None

# Generated at 2022-06-23 06:10:08.708353
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:10.376509
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:10:11.615996
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:10:14.672798
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, {'collections': 'test.collection'})[0] == 'test.collection'
    assert cs._load_collections(None, {'collections': 'test.collection'})[1] == 'ansible.builtin'

# Generated at 2022-06-23 06:10:25.789509
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test case when the basic constructor is called
    s = CollectionSearch()
    if not (s.collections and isinstance(s.collections, list)):
        raise AssertionError('CollectionSearch() failed')

    # Test case when constructor is called with the collections parameter
    # Test case 1: collections parameter is an empty list
    try:
        s = CollectionSearch(collections=[])
        raise AssertionError('CollectionSearch(collections=[]) should have failed')
    except TypeError as e:
        if str(e) != '"collections" expected a list of strings, got a list of unknown type':
            raise

    # Test case 2: collections parameter is not a list

# Generated at 2022-06-23 06:10:29.101487
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.get_validated_value('collections', collection_search._collections, None, None) is not None

# Generated at 2022-06-23 06:10:36.308446
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._validated_attributes['collections'] == _ensure_default_collection()
    assert collection_search._validated_attributes['collections'] == [
        'ansible_collections.ns1.collection1',
        'ansible_collections.ns2.collection2',
        'ansible.builtin'
    ]

# Generated at 2022-06-23 06:10:37.987711
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert(test_obj.collections == _ensure_default_collection())

# Generated at 2022-06-23 06:10:40.253101
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._load_collections(None,None) == None

# Generated at 2022-06-23 06:10:42.048104
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # just call the constructor and make sure it doesn't throw an exception
    CollectionSearch()

# Generated at 2022-06-23 06:10:53.388300
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert cs.collections == []

    # init with a string that contains a collection that isn't the default
    cs2 = CollectionSearch('foo.bar')
    assert cs2.collections == ['foo.bar', 'ansible.builtin']

    # init with a list that contains the default
    cs3 = CollectionSearch(['foo.bar', 'ansible.builtin'])
    assert cs3.collections == ['foo.bar', 'ansible.builtin']

    # init with a list that does not contain the default
    cs4 = CollectionSearch(['foo.bar'])
    assert cs4.collections == ['foo.bar', 'ansible.builtin']

    # init with a default collection
    cs5 = CollectionSearch('ansible.builtin')


# Generated at 2022-06-23 06:10:56.150532
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search._load_collections('collections',['name']))

# Generated at 2022-06-23 06:11:06.854371
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == ['ansible.builtin', 'ansible.legacy']
    assert CollectionSearch(collections=[])._collections == ['ansible.builtin', 'ansible.legacy']
    assert CollectionSearch(collections=["ansible.builtin"])._collections == ['ansible.builtin', 'ansible.legacy']
    assert CollectionSearch(collections=["ansible.builtin", "ansible.legacy"])._collections == ['ansible.builtin', 'ansible.legacy']
    assert CollectionSearch(collections=["ansible.builtin", "ansible.legacy", "ansible.extra_collection"])._collections == \
           ['ansible.builtin', 'ansible.legacy', 'ansible.extra_collection']

# Generated at 2022-06-23 06:11:09.354400
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    c.post_validate()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:17.436092
# Unit test for constructor of class CollectionSearch

# Generated at 2022-06-23 06:11:19.050519
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create new instance of CollectionSearch
    c = CollectionSearch()
    # Assert that _load_collections is a function
    assert callable(c._load_collections)

# Generated at 2022-06-23 06:11:21.098588
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._load_collections(None,None) == _ensure_default_collection()

# Generated at 2022-06-23 06:11:25.262901
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # create an object of class CollectionSearch
    collection_list = CollectionSearch()
    # check the attribute collections was created
    assert hasattr(collection_list, '_collections')
    # check that the attribute '_collections' has the same type as a normal list
    assert isinstance(collection_list._collections, list)

# Generated at 2022-06-23 06:11:30.009688
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        obj = CollectionSearch()
        obj.collections = ['ansible.builtin']
        obj.collections.append('geerlingguy.java')
        assert obj.collections == ['ansible.builtin', 'geerlingguy.java']
    except Exception:
        print("Error: test_CollectionSearch() failed.\n")

# Generated at 2022-06-23 06:11:33.086341
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection()
    assert CollectionSearch(collections=['test.collection'])._collections == ['test.collection']



# Generated at 2022-06-23 06:11:35.268088
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch()
    assert d._collections == d._ensure_default_collection()

# Generated at 2022-06-23 06:11:43.604823
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # create an instance of class
    cs = CollectionSearch()
    # print(cs.__dict__)
    # print(cs._collections)
    # x = cs._collections
    # print(x)
    # print(x.default)
    # print(x.default())
    # print(type(x.default()))
    print(cs._collections)
    # cs.collections = _ensure_default_collection()
    cs.collections = None
    print(cs.collections)
    print(type(cs.collections))


# test_CollectionSearch()

# Generated at 2022-06-23 06:11:44.843621
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections._static_value is not None

# Generated at 2022-06-23 06:11:50.121282
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collection_list == _ensure_default_collection(collection_list=None)
    assert collection_search._collections.default == collection_search.collection_list
    assert collection_search._collections.priority == 100
    assert collection_search._collections.listof == string_types
    assert collection_search._collections.always_post_validate == True
    assert collection_search._collections.static == True

# Generated at 2022-06-23 06:11:51.677140
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:54.381951
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert isinstance(search._collections._handle_attribute_exceptions(search), list)


# Generated at 2022-06-23 06:12:03.564902
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("TESTING: test_CollectionSearch")

    # FIXME: This test should create a class with a collection_search attribute.  The collection_search attribute
    # FIXME: should be initialized with a value to test that the constructor is called.  Instead, the constructor
    # FIXME: is called and the constructor calls methods that cannot be called since the test did not create an
    # FIXME: object with a collection_search attribute.

    # FIXME: Replace this test with a test that actually tests that the constructor is called.
    collection_search = CollectionSearch()
    assert collection_search is not None
    print("SUCCESS: test_CollectionSearch")

if __name__ == '__main__':
    # Unit test
    test_CollectionSearch()

# Generated at 2022-06-23 06:12:11.145331
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_test = CollectionSearch()
    attr = '_collections'
    ds = ["my_collection"]
    # Test when value exists in constructor (no default)
    assert search_test.get_validated_field_value(attr,
        ds, "constructor") is not None
    # Test when value does not exist in constructor (with default)
    ds = None
    assert search_test.get_validated_field_value(attr,
        ds, "constructor") is not None

# Generated at 2022-06-23 06:12:13.549748
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch()
    assert d._collections is not None
    assert d._collections._internal_name == 'collections'
    assert d.collections is None

# Generated at 2022-06-23 06:12:16.356663
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Test for constructor of class CollectionSearch
    collection_search_obj = CollectionSearch()
    assert collection_search_obj._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:12:18.289579
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()


# Generated at 2022-06-23 06:12:23.269487
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()

    cs = CollectionSearch(collections=['foo.bar'])
    assert cs.collections == _ensure_default_collection(collection_list=['foo.bar'])

# Generated at 2022-06-23 06:12:24.436101
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    item = CollectionSearch()


# Generated at 2022-06-23 06:12:25.384862
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t._load_collections('collections',None) == _ensure_default_collection()

# Generated at 2022-06-23 06:12:26.672973
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = CollectionSearch()
    assert ds._collections.default == 'ansible.builtin'

# Generated at 2022-06-23 06:12:28.587593
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:12:34.945046
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # setup a hash with a list of collections
    h = {}
    h['collections'] = ['ansible.posix', 'ansible.builtin', 'mycollection']
    # call the setup method
    cs.setup(h)
    # get the value of the 'collections' key
    value = getattr(cs, 'collections')
    # test if the list has the correct number of entries
    assert len(value) == 3
    # test if the list contains 'ansible.builtin'
    assert 'ansible.builtin' in value
    # test if the list contains 'ansible.posix'
    assert 'ansible.posix' in value
    # test if the list contains 'mycollection'
    assert 'mycollection' in value

# Generated at 2022-06-23 06:12:36.966444
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch(collections=['collections'])
    assert result.collections == ['collections']

# Generated at 2022-06-23 06:12:40.020626
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    try:
        a._collections = ['geerlingguy.java', 'zrax.raspberry-pi']
        b = a._load_collections(a._collections, a)
    except:
        assert False
    else:
        assert True
    finally:
        a._collections = ['zrax.raspberry-pi', 'geerlingguy.java']
        b = a._load_collections(a._collections, a)
        assert b

# Generated at 2022-06-23 06:12:43.434797
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    test_attr = collection._collections
    assert test_attr.name == "_collections"
    assert test_attr.isa == "list"
    assert test_attr.listof == string_types
    assert test_attr.priority == 100
    assert test_attr.default == _ensure_default_collection
    assert test_attr.always_post_validate == True
    assert test_attr.static == True


# Generated at 2022-06-23 06:12:55.150496
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()

    # test collection with None case
    cs.collections = None
    assert cs.collections is None

    # test collection with empty case
    cs.collections = []
    assert cs.collections is not None
    assert cs.collections[0] == 'ansible_collections.ansible.builtin'

    # test colleciton with already populated case
    cs.collections = ["ansible_collections.my.collection1", "ansible_collections.my.collection2"]
    assert cs.collections[0] == "ansible_collections.ansible.builtin"
    assert cs.collections[1] == "ansible_collections.my.collection1"
    assert cs.collections[2] == "ansible_collections.my.collection2"

# Generated at 2022-06-23 06:13:02.406639
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == None
    assert cs._load_collections('collections', []) == None
    assert cs._load_collections('collections', ["name"]) == ["name"]

# Generated at 2022-06-23 06:13:03.940708
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-23 06:13:09.233928
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    c.collections = None
    assert c.collections == ['ansible.legacy']
    c.collections = ['ansible.builtin']
    assert c.collections == ['ansible.builtin', 'ansible.legacy']
    assert c._attributes['collections'].static

# Generated at 2022-06-23 06:13:11.285029
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.get_value('collections') == 'ansible.builtin' or cs.get_value('collections') == 'ansible.legacy'