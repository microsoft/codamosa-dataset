

# Generated at 2022-06-23 06:03:16.619247
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("test_CollectionSearch: begin")

    cs = CollectionSearch()
    # print("cs._collections: " + str(cs._collections))

    print("test_CollectionSearch: end")


# Generated at 2022-06-23 06:03:20.955275
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        def __init__(self, *args, **kwargs):
            super(TestCollectionSearch, self).__init__(*args, **kwargs)
            self._validate_set_attrs()
    collection_search = TestCollectionSearch()
    assert collection_search.collections is None


# Generated at 2022-06-23 06:03:22.564458
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections.default() == ['ansible.builtin']

# Generated at 2022-06-23 06:03:30.615324
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test default value of _collections
    assert CollectionSearch._collections.default() == ['ansible.legacy']

    # test _ensure_default_collection
    assert _ensure_default_collection([]) == ['ansible.legacy']
    assert _ensure_default_collection(['foo', 'bar']) == ['foo', 'bar', 'ansible.legacy']
    assert _ensure_default_collection(['foo', 'bar', 'ansible.legacy']) == ['foo', 'bar', 'ansible.legacy']

# Generated at 2022-06-23 06:03:32.231507
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.default is not None



# Generated at 2022-06-23 06:03:33.620859
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-23 06:03:37.980750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        def __init__(self):
            pass

    test_obj = TestCollectionSearch()

    assert test_obj._collections == {'default': _ensure_default_collection,
                                     'type': 'list',
                                     'elements': 'string'}

# Generated at 2022-06-23 06:03:47.933094
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    current_collection_search = CollectionSearch()
    current_collection_search.collections = ['ansible.builtin', 'ansible.legacy']
    print(current_collection_search.collections)
    current_collection_search.collections = ['ansible.builtin']
    print(current_collection_search.collections)
    current_collection_search.collections = ['test_collection']
    print(current_collection_search.collections)
    current_collection_search.collections = ['test_collection', 'test_collection_2']
    print(current_collection_search.collections)
    current_collection_search.collections = ['ansible.builtin', 'test_collection', 'test_collection_2']
    print(current_collection_search.collections)

# Generated at 2022-06-23 06:03:49.169829
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == ['ansible.builtin']

# Generated at 2022-06-23 06:03:51.638458
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert cs.collections
    assert isinstance(cs.collections, list)
    assert isinstance(cs.collections[0], str)

# Generated at 2022-06-23 06:04:02.810730
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # The behavior of this module is dependent on the environment, so we'll
    # do a simple test that we can load it with various constructors
    def _test_search_constructor(search_paths):
        CollectionSearch(search_paths=search_paths)

    # We can instantiate an empty search
    _test_search_constructor(None)

    # We can instantiate with an empty list or tuple of search paths
    _test_search_constructor([])
    _test_search_constructor(())

    # We can instantiate with a list of search paths
    _test_search_constructor(['col1', 'col2'])

    # We can instantiate with a tuple of search paths
    _test_search_constructor(('col1', 'col2'))

    # We can instantiate with a string
   

# Generated at 2022-06-23 06:04:09.520070
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest

    class testCollectionSearch(unittest.TestCase):
        def test_constructor(self):
            test_collections = ['test.collections']
            cs = CollectionSearch(collections=test_collections)
            self.assertEqual(cs._collections, ['test.collections'])

    suite = unittest.TestLoader().loadTestsFromTestCase(testCollectionSearch)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-23 06:04:11.260273
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    colsearch = CollectionSearch()
    assert _ensure_default_collection(collection_list=None) == colsearch._collections

# Generated at 2022-06-23 06:04:11.839151
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:04:15.709320
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    base_path = '/etc/ansible/collections/ansible_collections/namespace/test'
    collection_list = CollectionSearch.create_from_data(collections=[base_path])
    assert collection_list.collections == [base_path]


# Generated at 2022-06-23 06:04:16.329451
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s=CollectionSearch()

# Generated at 2022-06-23 06:04:18.428130
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert isinstance(collection, CollectionSearch)

# Generated at 2022-06-23 06:04:21.277959
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)

# Generated at 2022-06-23 06:04:23.465770
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.plugins.loader as pl
    assert 'ansible.builtin' in pl.all_plugin_loaders 
    assert 'ansible.legacy' in pl.all_plugin_loaders

# Generated at 2022-06-23 06:04:26.640921
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def x():
        for i in range(100):
            a = CollectionSearch()
    import timeit
    print(timeit.timeit(x, number=500))

# Generated at 2022-06-23 06:04:28.062883
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:31.447543
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.post_validate()
    assert cs._attributes['collections'].value == _ensure_default_collection()



# Generated at 2022-06-23 06:04:38.277602
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections is None
    assert collection.collections is None
    assert collection._load_collections('collections', ['zaza, test']) == ['ansible.legacy', 'zaza, test']
    assert collection.collections == ['ansible.legacy', 'zaza, test']
    assert collection._load_collections('collections', None) == ['ansible.legacy']
    assert collection.collections == ['ansible.legacy']

# Generated at 2022-06-23 06:04:42.972688
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def mock_load_collections(attr, ds):
        return ['ansible.builtin']

    test_instance = CollectionSearch()
    setattr(test_instance, '_load_collections', mock_load_collections)
    test_instance.post_validate({}, {})
    assert test_instance._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:04:44.521619
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections('collections', None) is None

# Generated at 2022-06-23 06:04:46.241621
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch()
    assert d._collections.default is not None

# Generated at 2022-06-23 06:04:50.952195
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections(None, None) is None

    collection_search.collections = ['See,', 'change', 'is,', 'good.']
    assert collection_search._load_collections(None, None) == ['See,', 'change', 'is,', 'good.']

# Generated at 2022-06-23 06:04:53.649785
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import IncludeRole

    my_role = IncludeRole()
    assert my_role._collections._default == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-23 06:04:55.616192
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:04:59.682110
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test(CollectionSearch):
        def __init__(self, data):
            self._load_data(data)
    test = Test({})
    assert test._collections == _ensure_default_collection()


# Generated at 2022-06-23 06:05:02.057874
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    print("Testing class CollectionSearch")
    test_class = CollectionSearch()
    assert test_class is not None


# Generated at 2022-06-23 06:05:03.961088
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._load_collections([]) == []

# Generated at 2022-06-23 06:05:05.369355
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is not None


# Generated at 2022-06-23 06:05:07.256835
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default('foo') == ['foo']

# Generated at 2022-06-23 06:05:16.980770
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # construct an attribute named 'collections' which has value as a unicode
    # and call the constructor

    named_tuple = namedtuple('named_tuple', ['value'])
    collections = named_tuple(AnsibleUnicode('ansible.builtin'))
    collection_search = CollectionSearch()

    # reference to the constructor method called by the constructor
    post_validate_method = collection_search._load_collections

    # call the constructor method with attributes as arguments
    post_validate_method('collections', collections)

    AnsibleCollectionConfig.default_collection = None

    # call the constructor method with attributes as arguments
   

# Generated at 2022-06-23 06:05:24.614980
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) == ['ansible_collections.ansible.builtin']

    test_module_files = [
        'ansible_collections.ansible.builtin.module_utils.module_utils'
    ]
    assert cs._load_collections(None, test_module_files) == test_module_files
    # FIXME: what about role tasks?

# Generated at 2022-06-23 06:05:27.543042
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()
    #assert collection_search._collections == ["ansible.builtin"]

# Generated at 2022-06-23 06:05:34.473313
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.default == _ensure_default_collection()
    assert obj._collections.priority == 100
    assert obj._collections.isa == 'list'
    assert obj._collections.listof == string_types
    assert obj._collections.always_post_validate is True
    assert obj._collections.static is True

# Generated at 2022-06-23 06:05:36.467364
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    s._load_collections("sf", "ds")



# Generated at 2022-06-23 06:05:38.631323
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert(collection_search._collections == _ensure_default_collection())



# Generated at 2022-06-23 06:05:40.330212
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:05:42.532360
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:05:44.154485
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()

    assert collection_search._collections is not None

# Generated at 2022-06-23 06:05:45.668078
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    name = CollectionSearch().collections = ['jdoe.my_collection']

# Generated at 2022-06-23 06:05:50.651038
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.post_validate(cs._collections.field, [], None)
    # __init__ is not defined for CollectionSearch, therefore the call to
    # __init__ from AnsibleBase should be called instead, which calls
    # init_from_collection_loader()
    assert hasattr(cs, '_collections')

# Generated at 2022-06-23 06:05:53.734851
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance.collections._get_default() is not None

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:05:55.851285
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:06:02.465320
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """CollectionSearch: __init__ returns an object for CollectionSearch class
    """
    # CollectionSearch is a mixin with Base, so we can't instantiate it
    # directly.
    import ansible.plugins.loader
    mixin = ansible.plugins.loader.ActionModule
    cs = mixin(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Ensure that this is a class of CollectionSearch
    assert isinstance(cs, CollectionSearch)

# Generated at 2022-06-23 06:06:04.637198
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search._collections = None
    assert search._load_collections(search._collections, None) is None

# Generated at 2022-06-23 06:06:09.092887
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_list = []
    default_collection_list = _ensure_default_collection(collection_list)
    assert default_collection_list == ['ansible_collections.notstdlib.moveit', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:06:11.517228
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Test for fields not being None and initialized with the type declared in the FieldAttribute
    assert cs._collections != None and isinstance(cs._collections, list)

# Generated at 2022-06-23 06:06:19.248531
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default is not None
    assert isinstance(cs._collections.default, type(cs._ensure_default_collection()))
    assert cs._collections.default is not cs._ensure_default_collection()
    assert cs._load_collections(None, None) is None


# Generated at 2022-06-23 06:06:22.338966
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    tmp = CollectionSearch()
    assert tmp is not None

# Generated at 2022-06-23 06:06:27.754397
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections == _ensure_default_collection()
    a.__dict__['_collections'] = None
    assert a._collections == _ensure_default_collection()
    b = CollectionSearch(collections=['plugins', 'test.test'])
    assert b._collections == ['test.test', 'plugins']

# Test for private method _load_collections

# Generated at 2022-06-23 06:06:30.355462
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    test_CollectionSearch._load_collections(test_CollectionSearch._collections, None)

# Generated at 2022-06-23 06:06:37.499615
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # Ensure a collections field is added
    assert cs.fields.get('collections') is not None
    assert cs.collections is None

    # Add a value to the collections field
    cs.collections = "collections"
    assert cs.fields.get('collections') is not None
    assert cs.collections == "collections"

    # Ensure the default value is present
    cs.collections = None
    assert cs.fields.get('collections') is not None
    assert cs.collections == _ensure_default_collection()

    # Add a value to the collections field now that the default is present
    cs.collections = "collections"
    assert cs.fields.get('collections') is not None
    assert cs.collections == "collections"

# Generated at 2022-06-23 06:06:41.857403
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test instantiation, constructor of class CollectionSearch.
    collection_search = CollectionSearch()

    collections = {
        'collections': ['foo.bar'],
    }

    # Test method call
    collection_search._load_collections(collections)

# Generated at 2022-06-23 06:06:45.463165
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    res = cs.get_validated_value('collections', cs._collections, None, None)
    print("This is the result of pattern", res)


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:06:48.298977
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.post_validate(dict(), 'value')
    print("Testing constructor of class CollectionSearch")
    print("The input is {}".format("No Input"))
    print("Expected output: {}".format(""))

# Generated at 2022-06-23 06:06:50.276752
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_collection_search = CollectionSearch()
    my_collection_search._load_collections('collections', ['test_collection'])
    assert my_collection_search

# Generated at 2022-06-23 06:07:02.077790
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # In case of a success it should return a list.
    assert isinstance(cs._load_collections(None, ['ansible.windows']), list)
    assert cs._load_collections(None, ['ansible.windows']) == ['ansible.windows']
    # In case of a success it should return a list and the default collection.
    assert isinstance(cs._load_collections(None, ['ansible.builtin', 'ansible.windows']), list)
    assert cs._load_collections(None, ['ansible.builtin', 'ansible.windows']) == ['ansible.windows', 'ansible.builtin']
    # In case of failure it should return None
    assert cs._load_collections(None, ['ansible']) == None

# Generated at 2022-06-23 06:07:05.989387
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs._collections)

# Runs the unit test
if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:07:13.208527
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    x = c._load_collections("collections", ['ansible.builtin'])
    assert x[0] == 'ansible.builtin'

    x = c._load_collections("collections", [])
    assert x[0] == 'ansible.builtin'

    x = c._load_collections("collections", ['ansible.builtin', 'ansible.posix'])
    assert x[0] == 'ansible.builtin'
    assert x[1] == 'ansible.posix'

# Generated at 2022-06-23 06:07:15.169658
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ds = cs._load_collections(None, None)
    assert ds is not None

# Generated at 2022-06-23 06:07:17.360847
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    if cs._collections != cs.collections:
        raise AssertionError("Unexcepted values for _collections and collections")

# Generated at 2022-06-23 06:07:20.765179
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    # The name should be CollectionSearch
    assert c.__class__.__name__ == "CollectionSearch"

# Generated at 2022-06-23 06:07:32.557776
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class A(object):
        def get_validated_value(self, attr, schema, datastructure, value):
            return value
    a = A()
    b = CollectionSearch.__new__(CollectionSearch)
    CollectionSearch.__init__(b, a)

    # Tests
    # test_ds_is_none
    assert b._load_collections('collections', None) == None

    # test_ds_is_not_none
    attr_list = ['ansible.builtin', 'ansible.legacy']
    assert b._load_collections('collections', attr_list) == ['ansible.builtin', 'ansible.legacy']

    # test_ds_is_not_none_and_not_in_default
    attr_list = ['ansible.netcommon']
   

# Generated at 2022-06-23 06:07:34.561688
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    if collection_search._load_collections('collections', 'ansible.posix'):
        assert True

# Generated at 2022-06-23 06:07:38.052979
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch.get_validated_value('collections', collectionSearch._collections,
                                                [], None) == ['ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-23 06:07:41.559476
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collections = ['collections.test_1.test_1', 'collections.test_2.test_2']
    search = CollectionSearch(collections=test_collections)
    assert search.collections == test_collections

# Generated at 2022-06-23 06:07:43.432265
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is not None

# Generated at 2022-06-23 06:07:48.120240
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Check if the default value of the 'collections' variable is the same as the expected value
    assert cs._collections == _ensure_default_collection()
    # check if the collections variable is a list
    assert cs.collections is None or isinstance(cs.collections, list)


# Generated at 2022-06-23 06:07:49.830784
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._load_collections(None, None) == _ensure_default_collection()

# Generated at 2022-06-23 06:07:55.316844
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections == _ensure_default_collection()

    search = CollectionSearch(collections=['helloworld.mytest'])
    assert search._collections == ['helloworld.mytest']

# Generated at 2022-06-23 06:08:05.420362
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == _ensure_default_collection()
    assert test._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin']
    assert test._load_collections('collections', ['collections.example']) == ['collections.example']
    assert test._load_collections('collections', ['collections.example', 'collections.test']) == ['collections.example', 'collections.test']
    assert test._load_collections('collections', ['collections.example', 'collections.test', 'ansible.builtin']) == \
           ['ansible.builtin', 'collections.example', 'collections.test']

# Generated at 2022-06-23 06:08:05.962719
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-23 06:08:07.237240
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None

# Generated at 2022-06-23 06:08:09.246767
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create object
    collection_search = CollectionSearch()

    # Check created object is not None
    assert collection_search is not None

# Generated at 2022-06-23 06:08:12.420044
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()



# Generated at 2022-06-23 06:08:23.537205
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test the constructor with no parameter
    assert(CollectionSearch().collections == ['ansible.builtin', 'ansible.legacy'])

    # Creating an instance of CollectionSearch with no parameter
    assert(CollectionSearch().collections == ['ansible.builtin', 'ansible.legacy'])

    # Test the constructor with some collections value
    default_collection=AnsibleCollectionConfig.default_collection

    if default_collection and default_collection != 'ansible.builtin':
        assert(CollectionSearch(collections=['my.collection']).collections == ['my.collection', default_collection, 'ansible.builtin', 'ansible.legacy'])
    else:
        assert(CollectionSearch(collections=['my.collection']).collections == ['my.collection', 'ansible.builtin', 'ansible.legacy'])

# Generated at 2022-06-23 06:08:24.315461
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:08:25.937235
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None


# CollectionSearch.collections

# Generated at 2022-06-23 06:08:27.526486
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search._load_collections(None,[]))

# Generated at 2022-06-23 06:08:29.031506
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:08:34.208740
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  cs = CollectionSearch();
  assert cs._collections == [], "Failed: _collections == []. Returned: %s" % (cs._collections)
  assert AnsibleCollectionConfig.default_collection is None, "Failed: AnsibleCollectionConfig.default_collection is None. Returned: %s" % (AnsibleCollectionConfig.default_collection)
  # Testing with a value for AnsibleCollectionConfig.default_collection that doesn't include .
  AnsibleCollectionConfig.default_collection = "/path/to/default/ansible/collections/ansible_namespace/collection_name"
  assert cs._collections == []
  # Testing with a value for AnsibleCollectionConfig.default_collection that does include .
  AnsibleCollectionConfig.default_collection = "ansible_namespace.collection_name"
  assert cs._collections

# Generated at 2022-06-23 06:08:36.808474
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collectionSearch = CollectionSearch()
    assert test_collectionSearch
    assert test_collectionSearch.collections is not None


# Generated at 2022-06-23 06:08:41.386051
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    # Run constructor of class CollectionSearch
    def test_constructor_with_no_params():
        test_obj = CollectionSearch()
        assert test_obj is not None

    test_constructor_with_no_params()



# Generated at 2022-06-23 06:08:43.413784
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:08:48.073732
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Arrange
    collections = ['collection1', 'collection2', 'collection3']
    obj = CollectionSearch()
    obj.collections = collections

    # Action
    result = obj.collections

    # Assert
    assert result == collections

# Generated at 2022-06-23 06:08:49.944209
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Constructor of class CollectionSearch
    coll = CollectionSearch()
    assert coll._collections is not None

# Generated at 2022-06-23 06:08:57.365196
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    search_object = CollectionSearch()

    # Unit test for _load_collections method.

    # Given:
    #       when
    #           ds is None
    #       then
    #           return None
    assert search_object._load_collections(None, None) is None

    # Given:
    #       when
    #           ds is a list object
    #       then
    #           return ds
    assert search_object._load_collections(None, ['collection1', 'collection2']) == ['collection1', 'collection2']

# Generated at 2022-06-23 06:08:58.457157
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.static == True

# Generated at 2022-06-23 06:09:00.219166
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)


# Generated at 2022-06-23 06:09:03.619319
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()

    assert collection_search._collections == _ensure_default_collection()

# Test for _load_collections()

# Generated at 2022-06-23 06:09:07.614571
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert isinstance(collection_search, list)
    assert isinstance(collection_search, dict)
    assert isinstance(collection_search, object)
    assert collection_search == []

# Generated at 2022-06-23 06:09:10.609483
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:16.751864
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # Test _collections field
    attr = 'collections'
    ds = None
    # Test _ensure_default_collection()
    collection_list = None
    display.debug('Testing _ensure_default_collection method')
    collection_search._ensure_default_collection(collection_list)
    # Test _load_collections()
    display.debug('Testing _load_collections method')
    collection_search._load_collections(attr, ds)

# Generated at 2022-06-23 06:09:18.345812
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:20.347509
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    found_collections = CollectionSearch()
    assert found_collections._collections == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-23 06:09:26.068933
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == None
    assert cs._load_collections(None, []) == None
    assert cs._load_collections(None, ['ansible.builtin', 'ansible.legacy', 'geerlingguy.apache']) == ['ansible.builtin', 'ansible.legacy', 'geerlingguy.apache']

# Generated at 2022-06-23 06:09:28.790952
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_collection = CollectionSearch()
    print(my_collection._collections)
    assert my_collection._collections == _ensure_default_collection()

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:09:31.038036
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj._load_collections('hello', 'world')

# Generated at 2022-06-23 06:09:32.179280
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Make sure constructor doesn't fail
    CollectionSearch()

# Generated at 2022-06-23 06:09:38.374944
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    target = CollectionSearch()

    target._collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)

    assert target.collections == [('ansible_collections.some.collection', 'plugins')]

# Generated at 2022-06-23 06:09:42.587795
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == ['ansible.builtin']
    assert _ensure_default_collection(['ns.collection']) == ['ns.collection', 'ansible.builtin']

# Generated at 2022-06-23 06:09:47.952571
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance1 = CollectionSearch()
    instance1._collections = [ "filename.tar.gz" ]
    assert(instance1.collections == [ "filename.tar.gz" ])

    instance2 = CollectionSearch()
    instance2._collections = None
    assert(instance2.collections == [ "ansible_collections.sensu.sensu_go.plugins" ])

# Generated at 2022-06-23 06:09:59.201737
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test case 1: collections is None
    looker = CollectionSearch(collections=None)
    assert looker._collections == ['ansible.builtin']

    # Test case 2: collections is empty
    looker = CollectionSearch(collections=[])
    assert looker._collections == ['ansible.builtin']

    # Test case 3: collections is ['ansible.builtin']
    looker = CollectionSearch(collections=['ansible.builtin'])
    assert looker._collections == ['ansible.builtin']

    # Test case 4: collections is ['sample.builtin'] (a sample name)
    looker = CollectionSearch(collections=['sample.builtin'])
    assert looker._collections == ['sample.builtin', 'ansible.builtin']

    # Test case 5: collections is ['sample.

# Generated at 2022-06-23 06:10:00.953751
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert type(cs) is CollectionSearch

# Generated at 2022-06-23 06:10:05.317411
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_list = collection_search._load_collections('collections', [])
    assert len(collection_list) == 1
    assert collection_list[0] == 'ansible.builtin'

# Generated at 2022-06-23 06:10:09.211054
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None
    assert collection_search._collections.default == _ensure_default_collection
    assert collection_search._collections.always_post_validate is True


# Generated at 2022-06-23 06:10:11.186175
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    result = obj._load_collections('collections','ansible.builtin')
    assert result == ['ansible.builtin']

# Generated at 2022-06-23 06:10:12.596871
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 06:10:15.769684
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._collections.value == ['ansible.legacy']

# Generated at 2022-06-23 06:10:18.025220
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default is _ensure_default_collection

# Generated at 2022-06-23 06:10:19.885544
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test constructor of class CollectionSearch
    collection_search = CollectionSearch()
    assert(collection_search)


# Generated at 2022-06-23 06:10:29.966148
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == None
    assert cs._load_collections('collections', None) == None
    assert cs._load_collections('collections', []) == None
    assert cs._load_collections('collections', ["ansible.builtin"]) == ["ansible.builtin"]
    assert cs._load_collections('collections', ["ansible.builtin", "ansible.legacy"]) == ["ansible.builtin", "ansible.legacy"]
    assert cs._load_collections('collections', ["ansible.builtin", "ansible.legacy", "test.test_collection"]) == ["ansible.builtin", "ansible.legacy", "test.test_collection"]

# Generated at 2022-06-23 06:10:32.130696
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:10:37.772376
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    test_attr_collections = ['ansible.builtin']
    test_value_collections = ['ansible.builtin']
    obj.collections = test_attr_collections
    value = obj._load_collections(test_attr_collections, test_value_collections)
    assert (value == test_attr_collections)

# Generated at 2022-06-23 06:10:40.154788
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) == ['ansible.builtin']

# Generated at 2022-06-23 06:10:41.626086
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)

# Generated at 2022-06-23 06:10:44.930397
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test = CollectionSearch()
        assert test
    except Exception as e:
        assert False, "Unexpected error: %s" % e


# Generated at 2022-06-23 06:10:47.849974
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    i = CollectionSearch()
    assert i.collections is None
    assert i.get_validated_value('collections', i._collections, [], None)

# Generated at 2022-06-23 06:10:48.594606
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()

# Generated at 2022-06-23 06:10:49.208483
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:10:51.233579
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Testing if it is possible to create an instance of the class CollectionSearch
    obj = CollectionSearch()
    assert obj is not None

# Generated at 2022-06-23 06:10:53.552436
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search = CollectionSearch()
    except Exception as e:
        raise AssertionError("Could not create object of class CollectionSearch: " + str(e))

# Generated at 2022-06-23 06:11:00.682766
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections._collections.default(collections) == ['ansible.builtin']

    display.screen = False
    env = Environment()
    assert collections._load_collections('collections', []) is None
    assert collections._load_collections('collections', ['test']) == ['test', 'ansible.builtin']

    assert collections._load_collections('collections', ['test', env.from_string('{{ test }}')]) == ['test', 'ansible.builtin']
    display.screen = True

# Generated at 2022-06-23 06:11:10.703033
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude

    TaskInclude._collections = []
    # Test constructor
    # TaskInclude._load_collections will call _ensure_default_collection internally
    # which will check is there only one collection name in TaskInclude._collections
    # since TaskInclude._collections is empty, _ensure_default_collection will add
    # 'ansible.builtin' or 'ansible.legacy' to it, so the size of _collections
    # will be 2
    TaskInclude._load_collections(TaskInclude, {})
    assert len(TaskInclude._collections) == 2

# Generated at 2022-06-23 06:11:15.334855
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class FakeCollectionSearch(CollectionSearch):
        pass

    collection_search = FakeCollectionSearch()
    collection_search._collections = _ensure_default_collection()
    # Ensure that the class variable _collections is updated before the method _load_collections() is called
    assert collection_search._collections == ['ansible_collections.ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:11:22.512989
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().__dict__['_collections'] == None
    assert CollectionSearch().__dict__['_collections_is_set'] == False
    assert CollectionSearch().__dict__['_collections_is_static'] == True
    assert CollectionSearch().__dict__['_collections_priority'] == 100
    assert CollectionSearch().__dict__['_collections_always_post_validate'] == True

# Generated at 2022-06-23 06:11:24.155501
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()
    assert cs._collections['default'] == _ensure_default_collection()

# Generated at 2022-06-23 06:11:28.881889
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        def __init__(self):
            super(TestCollectionSearch, self).__init__(
                None, {'collections': ['ansible_namespace.collection_name']}, [], None)

    c = TestCollectionSearch()
    assert c.collections == ['ansible_namespace.collection_name']

# Generated at 2022-06-23 06:11:32.255615
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   # Create a CollectionSearch object
   attr = []
   ds = None
   ds = _ensure_default_collection(ds)
   test = CollectionSearch()
   # TODO: In order for this to work, we need to figure out how to test _load_collections
   test._load_collections(attr,ds)

# Generated at 2022-06-23 06:11:41.405470
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task.task import Task
    from ansible.playbook.handler.task import HandlerTask
    from ansible.playbook.task.include_role import TaskIncludeRole
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name
    import ansible_collections.microsoft.azure.azcollection


# Generated at 2022-06-23 06:11:43.559328
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections(None, None) == ['ansible.legacy']

# Generated at 2022-06-23 06:11:46.970466
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print (cs._collections)
    #assert cs._collections == 'ansible_collections.ansible.builtin'
    #assert cs.collections == 'ansible_collections.ansible.builtin'
    print('Test succeed !')

test_CollectionSearch()

# Generated at 2022-06-23 06:11:53.831434
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    # I'm leaving this commented in because it's a reminder that the CollectionSearch class has to be
    # instantiated before it can be used.
    # obj.get_validated_value('collections', obj._collections, '[ansible.builtin, ansible.legacy, cisco.asa, cisco.nxos, cisco.iosxr]')

# Generated at 2022-06-23 06:11:54.479114
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:11:56.343904
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   collection_search = CollectionSearch()
   assert collection_search is not None
   assert collection_search._collections is not None

# Generated at 2022-06-23 06:12:02.663924
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Create a new collection search object
    cs = CollectionSearch()

    # Ensure that the name of the collection search object is 'CollectionSearch'
    assert cs.__class__.__name__ == 'CollectionSearch'

    # Ensure that the collections field for the class collection search is of the list type
    assert cs._collections.isa == 'list'

    # Ensure that the collection field is an empty list
    assert cs._collections.default == []

    # Ensure that the collections name is of the string type
    assert cs._collections.listof == string_types

# Generated at 2022-06-23 06:12:08.076869
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    cs._collections = ['foo.bar']
    assert cs._collections == ['foo.bar']
    cs._collections = None
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:12:13.319133
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # this is for testing purposes
    import sys
    sys.modules['__main__'] = object()

    # Create instance of CollectionSearch
    search = CollectionSearch()

    # Validate values
    assert search._load_collections("collections", ["test"]) is None
    assert search._load_collections("collections", None) == ['test']

    # Cleanup namespace
    sys.modules.pop('__main__')

# Generated at 2022-06-23 06:12:13.999611
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:12:16.007323
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    modules = CollectionSearch();
    assert modules.collections == ['ansible_collections.ansible']

# Generated at 2022-06-23 06:12:19.754067
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ds = {'collections': ['ansible.builtin', 'collection_one', 'collection_two']}
    assert cs.get_validated_value('collections', cs._collections, ds, None) == ds['collections']

# Generated at 2022-06-23 06:12:23.147062
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test __init__() of class CollectionSearch
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:12:27.913237
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections == ['ansible.builtin']
    assert test_obj._load_collections(1,2) == ['ansible.builtin']
    assert test_obj._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:12:31.300344
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    a._collections = ['ansible.builtin', 'ansible.legacy']
    a._load_collections('_collections', None)
    assert a._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:12:37.599471
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _collections = ['ansible.builtin', 't.community.turbot', 'Turbot.cloud.aws']
    cs = CollectionSearch(_collections)
    if cs._collections != _collections:
        return False
    if cs._collections[0] != 'ansible.builtin':
        return False
    return True


# Generated at 2022-06-23 06:12:40.469149
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert 'ansible.builtin' in cs.collections or 'ansible.legacy' in cs.collections
    assert len(cs.collections) == 1

# Generated at 2022-06-23 06:12:42.598683
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = {
        'collections': ['author.collection1', 'collection2', 'collection3'],
    }
    cs = CollectionSearch()
    assert cs._load_collections('collections', ds) == ds['collections']

# Generated at 2022-06-23 06:12:53.519071
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Test the output of self._collections
    assert cs._collections() == ['ansible.builtin']
    cs = CollectionSearch(collections=['ciscolabs.aci', 'ciscolabs.aci_apic_helper'])
    assert cs._collections() == ['ciscolabs.aci', 'ciscolabs.aci_apic_helper']
    cs = CollectionSearch(collections=['ciscolabs.aci', 'ciscolabs.aci_apic_helper', 'ciscolabs.aci_apic'])
    assert cs._collections() == ['ciscolabs.aci', 'ciscolabs.aci_apic_helper', 'ciscolabs.aci_apic']

# Generated at 2022-06-23 06:12:59.337162
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collsearch = CollectionSearch()
    assert collsearch._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:13:03.395193
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        obj = CollectionSearch()
        print(obj.collections)
    except Exception as e:
        print(f'Unable to create an object from CollectionSearch: {str(e)}')

# Generated at 2022-06-23 06:13:06.702608
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    c = CollectionSearch()
    ds = None

    c._load_collections(ds, ds)

# Generated at 2022-06-23 06:13:11.868315
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.playbook.play
    play = ansible.playbook.play.Play()
    test_obj = CollectionSearch()
    setattr(play, '_collections', None)
    assert test_obj._load_collections('collections', play) == [u'ansible.builtin']

# unit test to check that the output of _load_collections() is a list

# Generated at 2022-06-23 06:13:12.735130
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert isinstance(a, CollectionSearch)

