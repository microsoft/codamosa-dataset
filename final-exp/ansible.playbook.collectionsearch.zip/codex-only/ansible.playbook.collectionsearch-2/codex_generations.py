

# Generated at 2022-06-23 06:03:15.175680
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-23 06:03:18.526884
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch(collections=[u'ansible.delegation'])

    assert cs.collections == [u'ansible.delegation']

# Generated at 2022-06-23 06:03:20.788090
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch(None)
    assert(collectionSearch._load_collections('collections', ['ansible_namespace.collections']) != None)



# Generated at 2022-06-23 06:03:22.391915
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == 'ansible.legacy'

# Generated at 2022-06-23 06:03:24.293302
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs

# Generated at 2022-06-23 06:03:27.291073
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert isinstance(cs._collections, FieldAttribute)
    assert isinstance(cs._load_collections, callable)

# Generated at 2022-06-23 06:03:27.904978
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()

# Generated at 2022-06-23 06:03:29.314976
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    config_class = CollectionSearch()
    assert config_class._load_collections(None, None) is None

# Generated at 2022-06-23 06:03:30.465047
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is not None


# Generated at 2022-06-23 06:03:32.473073
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   obj = CollectionSearch()
   assert obj.collections == ['ansible.builtin', 'ansible.legacy', 'ansible_collections.notstdlib.moveit']

# Generated at 2022-06-23 06:03:40.609418
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This test is to test the functionality of class CollectionSearch
    # We create an object of CollectionSearch
    obj = CollectionSearch()
    display.debug('Start of unit test for class CollectionSearch')

    # This test is for validate function _load_collections
    display.debug('Start of unit test for _load_collections in class CollectionSearch')
    assert obj._load_collections(obj._collections,'ansible.builtin') == ['ansible.builtin']
    assert obj._load_collections(obj._collections, None) == None
    assert obj._load_collections(obj._collections, []) == None
    assert obj._load_collections(obj._collections,'test') == ['test']
    display.debug('End of unit test for _load_collections in class CollectionSearch')


# Generated at 2022-06-23 06:03:41.956610
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-23 06:03:45.064556
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert len(search._collections) == 2
    assert 'ansible_collections.foo.bar' in search._collections
    assert 'ansible.builtin' in search._collections

# Generated at 2022-06-23 06:03:46.281997
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections(None).collections

# Generated at 2022-06-23 06:03:48.235372
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible_collections.foo.bar']

# Generated at 2022-06-23 06:03:50.265557
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    assert cs.__dict__ == {}

# Generated at 2022-06-23 06:03:51.616136
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:00.178686
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Unit test for class CollectionSearch.
    """

    # No value for collections
    result = CollectionSearch()
    if result._Collections._collections.default_value != ['ansible_collections.my_namespace.my_collection']:
        raise AssertionError()

    # Custom value
    result = CollectionSearch(collections=['ansible.builtin', 'ansible.legacy'])
    if result._Collections._collections.default_value != ['ansible.builtin', 'ansible.legacy']:
        raise AssertionError()

# Generated at 2022-06-23 06:04:06.726783
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # following tests only works with python3
    # in python2, class Base has no __init__()
    # because it is not a new-style class
    try:
        base = Base()
        cs = CollectionSearch(base)
        assert cs.collections is None
        cs = CollectionSearch(base, collections=['ansible', 'ansible.builtin'])
        assert cs.collections == ['ansible', 'ansible.builtin']
    except:
        print('this is python2')

# Generated at 2022-06-23 06:04:09.452456
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections == AnsibleCollectionConfig.default_collection
    assert x._collections == 'ansible.builtin'
    assert x._collections is not None

# Generated at 2022-06-23 06:04:12.314388
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = AnsibleCollectionConfig.default_collection
    c = CollectionSearch()
    assert c.collections == [a]
    c = CollectionSearch(collections=['b'])
    assert c.collections == ['b']

# Generated at 2022-06-23 06:04:13.955342
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default is _ensure_default_collection



# Generated at 2022-06-23 06:04:17.551990
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert isinstance(collection_search, FieldAttribute)
    assert collection_search._collections.data == _ensure_default_collection()
    assert isinstance(collection_search._collections, FieldAttribute)

# Generated at 2022-06-23 06:04:23.316218
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default == _ensure_default_collection
    assert collection_search._collections.always_post_validate == True
    assert collection_search._collections.static == True

# Unit test default collections

# Generated at 2022-06-23 06:04:24.682565
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    print(CollectionSearch())


test_CollectionSearch()

# Generated at 2022-06-23 06:04:25.691194
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible_collections.foo.bar']

# Generated at 2022-06-23 06:04:27.297184
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-23 06:04:28.894954
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:04:31.398509
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Make sure constructor of CollectionSearch works as expected
    search = CollectionSearch()

# Generated at 2022-06-23 06:04:33.381185
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs_obj = CollectionSearch()
    assert cs_obj


# Test to verify the default collection is returned

# Generated at 2022-06-23 06:04:35.570036
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:04:40.067354
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.__dict__ = {"collections": "ansible.builtin,ansible.posix"}
    if collection_search._collections != ["ansible.builtin", "ansible.posix"]:
        raise AssertionError()

# Generated at 2022-06-23 06:04:41.510755
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj)

# Generated at 2022-06-23 06:04:42.345690
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c

# Generated at 2022-06-23 06:04:42.858274
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:04:44.112961
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:45.456213
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:04:54.406515
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearchTest(CollectionSearch):
        pass

    cst = CollectionSearchTest()
    # test with default collections
    cst._collections = None
    cst._load_collections(None, None)
    assert cst._collections == ['ansible.builtin', 'ansible.legacy']

    # test with default collections and a new collection
    cst._collections = ['ns.collection_name']
    cst._load_collections(None, None)
    assert cst._collections == ['ns.collection_name', 'ansible.builtin', 'ansible.legacy']

    # test with no collections
    cst._collections = []
    cst._load_collections(None, None)
    assert cst._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:04:55.905103
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()


# Generated at 2022-06-23 06:05:03.402468
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test CollectionSearch constructor
    csearch = CollectionSearch()
    # Test Collections private attribute
    collections_attr = csearch._collections
    assert collections_attr.name == 'collections'
    assert collections_attr.isa == 'list'
    assert collections_attr.listof == string_types
    assert collections_attr.priority == 100
    assert collections_attr.default == _ensure_default_collection
    assert collections_attr.always_post_validate == True
    assert collections_attr.static == True

# Generated at 2022-06-23 06:05:13.250881
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import RoleInclude
    role_include = RoleInclude()
    # Constructor
    assert isinstance(role_include.collections, list)
    assert len(role_include.collections) == 2
    assert 'ansible.builtin' in role_include.collections
    assert 'ansible.legacy' in role_include.collections

    role_include.collection = ["collection1", "collection2"]
    # Constructor
    assert isinstance(role_include.collections, list)
    assert len(role_include.collections) == 4
    assert 'collection1' in role_include.collections
    assert 'collection2' in role_include.collections
    assert 'ansible.builtin' in role_include.collections

# Generated at 2022-06-23 06:05:15.203440
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections._default == _ensure_default_collection()



# Generated at 2022-06-23 06:05:16.911158
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:05:28.937765
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']
    assert cs._collections.default_value == ['ansible.builtin']
    assert cs.get_validated_value('collections', cs._collections, [], None) == ['ansible.builtin']
    cs._collections = None
    assert cs.get_validated_value('collections', cs._collections, [], None) == ['ansible.builtin']
    assert cs.get_validated_value('collections', cs._collections, ['ansible.other'], None) == ['ansible.other', 'ansible.builtin']

# Generated at 2022-06-23 06:05:30.808025
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.__class__  == CollectionSearch

# Generated at 2022-06-23 06:05:32.920572
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert result._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:05:34.240201
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:05:38.631048
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search._collections = ["ansible_collections.foo.bar"]

    ds = {"collections": ["ansible_collections.foo.bar"]}
    collection_list = search._load_collections(None, ds)
    assert collection_list == search._collections

# Generated at 2022-06-23 06:05:47.795296
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    o = CollectionSearch()
    collections = o._load_collections(o._collections, [])
    assert isinstance(collections, list)

    # test for valid collections
    collections = ['test.default']
    new_collections = o._load_collections(o._collections, collections)
    assert isinstance(new_collections, list)
    assert len(new_collections) == len(collections) + 1

    # test for invalid collections
    collections = ['test.default']
    new_collections = o._load_collections(o._collections, collections)
    assert isinstance(new_collections, list)
    assert len(new_collections) == len(collections) + 1

    # test for empty collections
    collections = []

# Generated at 2022-06-23 06:05:50.781125
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == ['ansible.builtin', 'ansible.legacy']
    assert _ensure_default_collection([]) == ['ansible.builtin', 'ansible.legacy']
    assert _ensure_default_collection(['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-23 06:06:02.624237
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    import sys
    import unittest
    import json
    import ansible_collections
    from ansible.utils import context_objects as co
    from ansible.module_utils.common.removed import removed_class
    from ansible.module_utils.common._collections_compat import ImmutableDict

    from ansible.template import Templar

    class TestPlay(unittest.TestCase):
        def setUp(self):
            co.GlobalCLIArgs._store = ImmutableDict({'connection_plugins': []})
            self.play = ansible_collections.ansible.builtin.playbooks.CollectionSearch()
            self.loader = ansible_collections.ansible.builtin.plugins.loader.PluginLoader()

# Generated at 2022-06-23 06:06:08.684872
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    csearch = CollectionSearch()
    assert csearch._collections.default == _ensure_default_collection()
    assert csearch._collections.listof
    assert csearch._collections.isa("list")
    assert csearch._collections.priority == 100
    assert csearch._collections.static
    assert csearch._collections.always_post_validate
    assert csearch._collections.name == "collections"

# Generated at 2022-06-23 06:06:09.981745
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:06:11.693106
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()

    assert test_CollectionSearch._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:06:13.802441
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test(CollectionSearch):
        pass

    assert Test()._collections.value == _ensure_default_collection()



# Generated at 2022-06-23 06:06:15.656770
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections is not None


# Generated at 2022-06-23 06:06:16.721433
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch is not None
    assert collection_search is not None


# Generated at 2022-06-23 06:06:18.786888
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == ['local']

# Generated at 2022-06-23 06:06:24.149592
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  test_collections = {'my_collection', 'other_collection'}
  collection_search = CollectionSearch()
  collection_search.collections = test_collections
  assert collection_search.collections == test_collections

# Generated at 2022-06-23 06:06:26.758077
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()
    result = test_object.get_validated_value('collections', test_object._collections, [], None)
    assert result



# Generated at 2022-06-23 06:06:28.780141
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    cs._collections = test_args = ["test1", "test2"]

    assert cs._load_collections(None, test_args) == test_args

# Generated at 2022-06-23 06:06:31.043287
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:06:40.159120
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # The default value of collection is None
    cs = CollectionSearch()
    assert cs._collections is None

    # The default value of _load_collections is None
    assert cs._load_collections(None, None) is None

    # The value of _load_collections is []
    assert cs._load_collections(None, []) == []

    # The value of _load_collections is ['ansible.builtin']
    assert cs._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-23 06:06:45.160835
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.__dict__['collections'] = []
    _load_collections = cs._load_collections('collections')
    assert _load_collections == None

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:06:51.324060
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    searchCollections = CollectionSearch()
    searchCollections._collections = ["ansible_namespace.collection_name"]
    searchCollections._load_collections(None, None)


# Generated at 2022-06-23 06:07:02.459420
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Type is a class
    if not isinstance(CollectionSearch, type):
        raise AssertionError("CollectionSearch is not a class.")

    cs = CollectionSearch()

    # Type of attribute collections of class CollectionSearch should be 'list'
    if not isinstance(cs._collections, FieldAttribute):
        raise AssertionError("Type of attribute collections of class CollectionSearch should be 'list'.")

    # Type of attribute collections of class CollectionSearch should be 'listof'
    if cs._collections.listof:
        raise AssertionError("Type of attribute collections of class CollectionSearch should be 'listof'.")

    # Type of attribute collections of class CollectionSearch should be 'string_types'

# Generated at 2022-06-23 06:07:04.208819
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:07:05.056407
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch.static

# Generated at 2022-06-23 06:07:06.725550
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections._default == _ensure_default_collection

# Generated at 2022-06-23 06:07:10.179124
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Case with default value.
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

    # Case with invalid type.
    try:
        CollectionsSearch(collections=None)
    except TypeError:
        pass

# Generated at 2022-06-23 06:07:15.732684
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # test params
    ds = None

    # test with no param
    cs._load_collections(None, ds)

    # test with default param
    ds = None
    cs._load_collections(None, ds)

    # test with custom param
    ds = 'test_collections_list'
    cs._load_collections(None, ds)

# Generated at 2022-06-23 06:07:16.929184
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj,CollectionSearch)


# Generated at 2022-06-23 06:07:25.089215
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) == ['ansible.legacy', 'ansible_collections.namespace.plugin_name']
    # param is None
    assert cs._collections(None, None) == ['ansible.legacy', 'ansible_collections.namespace.plugin_name']
    # param is not None
    assert cs._collections(None, ["ansible_collections.namespace.plugin_name"]) == ['ansible_collections.namespace.plugin_name']

# Generated at 2022-06-23 06:07:30.387105
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test default constructor arguments
    display = Display()

    # Test default constructor arguments
    test_obj = CollectionSearch(loader=None)
    assert isinstance(test_obj._collections, FieldAttribute)
    assert test_obj._collections.iso == 'list'
    assert test_obj._collections.listof == string_types
    assert test_obj._collections.priority == 100
    assert test_obj._collections.default == _ensure_default_collection
    assert test_obj._collections.always_post_validate == True
    assert test_obj._collections.static == True

    assert test_obj.loader == None

# Generated at 2022-06-23 06:07:32.858167
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    search = CollectionSearch()

    assert search._collections

    assert search._collections() == ['ansible_collections.oracle.oci']

# Generated at 2022-06-23 06:07:36.781711
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create object with parametr
    t = CollectionSearch()

    # Check if object is instance of class CollectionSearch
    assert isinstance(t, CollectionSearch)

    # Check if the result is of the type "list"
    assert isinstance(t._load_collections, list)

# Generated at 2022-06-23 06:07:39.409519
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj._collections, list)
    assert 'ansible.builtin' in obj._collections or 'ansible.legacy' in obj._collections

# Generated at 2022-06-23 06:07:40.945241
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.post_validate({}, {}, {}, {})

# Generated at 2022-06-23 06:07:45.217331
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test=CollectionSearch()
    assert test._load_collections(None,None)==_ensure_default_collection()
    assert test._load_collections(None,['collection'])==['collection', 'ansible.builtin']



# Generated at 2022-06-23 06:07:47.167113
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:48.432247
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert isinstance(result.collections, list)
    assert result.collections is not None

# Generated at 2022-06-23 06:07:59.094528
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.playbook
    import ansible.template
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch.object(ansible.playbook.Base, '_collections', return_value=[]):
        with patch.object(ansible.template.is_template, return_value=False):
            with patch.object(ansible.playbook.Attribute, 'get_validated_value', return_value=True):
                with patch.object(ansible.playbook.Display, 'warning'):
                    t = CollectionSearch()
                    t._load_collections('collections', [])

# Generated at 2022-06-23 06:08:04.842559
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection(None)
    cs.collections = _ensure_default_collection(["ansible_web_infrastructure.apache"])
    assert cs.collections == _ensure_default_collection(["ansible_web_infrastructure.apache"])
    cs = CollectionSearch(collections = ["ansible_web_infrastructure.apache"])
    assert cs.collections == _ensure_default_collection(["ansible_web_infrastructure.apache"])

# Generated at 2022-06-23 06:08:05.446491
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-23 06:08:09.246820
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestSearch(CollectionSearch):
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=[],
                                      always_post_validate=True, static=True)

    testClass = TestSearch()
    testClass._load_collections(None, None)

# Generated at 2022-06-23 06:08:14.232339
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._load_collections(None, None) == ['ansible_collections.ansible.builtin']

    # Test that the _ensure_default_collection() returns correctly for None
    assert _ensure_default_co

# Generated at 2022-06-23 06:08:16.522316
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert(test_obj.__dict__['_collections'] == _ensure_default_collection())

# Generated at 2022-06-23 06:08:18.219060
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

    # check for default value of colletion
    collections = obj._collections
    assert collections

# Generated at 2022-06-23 06:08:26.292761
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This unit test is for the CollectionSearch class
    # Checks all variable initialization in constructor and _load_collections
    cs = CollectionSearch()

    # Checks _collections variable - should be a list and default value should be ansible.legacy
    assert isinstance(cs._collections, list)
    assert isinstance(cs._collections[0], str)
    assert cs._collections[0] == "ansible.legacy"
    assert cs.collections is None

    # Checks _collection_paths variable - should be a list of dictionaries and each dictionary should be a list of
    # strings
    assert isinstance(cs._collection_paths, list)
    for path in cs._collection_paths:
        assert isinstance(path, dict)
        for key in path:
            assert isinstance(key, str)

# Generated at 2022-06-23 06:08:28.188590
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_fields = CollectionSearch()
    assert test_fields._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:08:40.644174
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    actual = instance.collections
    assert actual == ['ansible_collections.default']

    instance = CollectionSearch(collections=[])
    actual = instance.collections
    assert actual == ['ansible_collections.default']

    instance = CollectionSearch(collections=['c1'])
    actual = instance.collections
    assert actual == ['c1', 'ansible_collections.default']

    instance = CollectionSearch(collections=['c1', 'c2'])
    actual = instance.collections
    assert actual == ['c1', 'c2', 'ansible_collections.default']

    instance = CollectionSearch(collections=['c1', 'c2', 'c3'])
    actual = instance.collections

# Generated at 2022-06-23 06:08:44.676816
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Test of CollectionSearch class"""
    c = CollectionSearch()
    lst = ['ansible.builtin', 'ansible.legacy', 'infoblox.cloud', 'ansible.netcommon']
    c._collections = _ensure_default_collection(lst)
    assert c._collections == lst

# Generated at 2022-06-23 06:08:55.636304
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert s._load_collections(None, None) == ['ansible.builtin', 'ansible.legacy']
    assert s._load_collections(None, []) == ['ansible.builtin', 'ansible.legacy']
    assert s._load_collections(None, ['namespace.collection']) == ['namespace.collection', 'ansible.builtin', 'ansible.legacy']
    assert s._load_collections(None, ['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']
    assert s._load_collections(None, ['ansible.legacy']) == ['ansible.legacy', 'ansible.builtin']

# Generated at 2022-06-23 06:08:57.634345
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None
    assert cs._collections == [AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-23 06:09:04.149670
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("test_CollectionSearch")

    class TestClass(CollectionSearch):
        @property
        def collections(self):
            return self._load_collections('collections', self._collections_value)

        @collections.setter
        def collections(self, value):
            self._collections_value = value

    test = TestClass()

    # test empty value
    test.collections = []
    print("_collections_value: ", test._collections_value)
    assert test._collections_value is None

    # test 1 item
    test.collections = ['bar']
    print("_collections_value: ", test._collections_value)
    assert test._collections_value is not None
    assert len(test._collections_value) == 1

# Generated at 2022-06-23 06:09:13.037042
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    obj = CollectionSearch()

    assert isinstance(obj, CollectionSearch)
    assert isinstance(obj._collections, FieldAttribute)
    assert obj._collections.isa=='list'
    assert isinstance(obj._collections.listof, string_types)
    assert obj._collections.priority==100
    assert obj._collections.default==_ensure_default_collection
    assert obj._collections.always_post_validate==True
    assert obj._collections.static==True
    assert obj.__class__.__name__=='CollectionSearch'
    


# Generated at 2022-06-23 06:09:14.756705
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    assert collectionsearch._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:26.286059
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    T = type('T', (CollectionSearch,), {})
    t = T()

    # test _load_collections function
    t._collections = t._load_collections('_collections', ['n1', 'n2'])
    assert t._collections == ['n1', 'n2']

    t._collections = t._load_collections('_collections', ['n1'])
    assert t.collections == ['n1', 'ansible.legacy']

    t._collections = t._load_collections('_collections', [])
    assert t.collections == ['ansible.legacy']

    t._collections = t._load_collections('_collections', None)
    assert t.collections == ['ansible.legacy']

# Generated at 2022-06-23 06:09:27.454698
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj1 = CollectionSearch()
    assert obj1._collections == []

# Generated at 2022-06-23 06:09:31.636091
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t._collections == t._load_collections(t._collections, "ansible.builtin")

# Generated at 2022-06-23 06:09:43.509045
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import IncludeTask

    c = CollectionSearch()

    # Validate that constructor always sets _collections field in obj
    _expected = _ensure_default_collection()
    _actual = c._collections
    assert _actual == _expected

    # Validate that constructor sets _collections field in obj
    with pytest.raises(AttributeError):
        c = CollectionSearch(collections="whatever")
    _actual = c._collections
    assert _actual == _expected

    # Validate that constructor sets _collections field in obj
    with pytest.raises(AttributeError):
        c = IncludeRole()
    _actual = c._collections
    assert _actual == _expected

    # Validate that constructor sets

# Generated at 2022-06-23 06:09:45.298940
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    # Test constructor value
    assert c.collections == _ensure_default_collection

# Generated at 2022-06-23 06:09:56.040258
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.actions.include import Include
    assert hasattr(Block, '_collections')
    assert hasattr(Include, '_collections')
    assert isinstance(Block._collections, FieldAttribute)
    assert isinstance(Include._collections, FieldAttribute)
    assert Block._collections.name == 'collections'
    assert Include._collections.name == 'collections'

# Generated at 2022-06-23 06:09:57.961906
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_loader = CollectionSearch()
    assert test_collection_loader._collections == _ensure_default_collection()


# Generated at 2022-06-23 06:09:59.161737
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert(obj.collections == 'ansible.builtin')

# Generated at 2022-06-23 06:10:01.263634
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:03.288443
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default(None) == _ensure_default_collection()

# Generated at 2022-06-23 06:10:04.323463
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

# Generated at 2022-06-23 06:10:13.869902
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    ansible_collections_paths = ['/usr/share/ansible/collections']
    collection_loader = AnsibleCollectionConfig(ansible_collections_paths)
    import os
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionRequirement

# Generated at 2022-06-23 06:10:15.870177
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    print("Collections :",search._collections)

# Generated at 2022-06-23 06:10:18.951251
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections[0] == 'ansible.builtin'
    assert 'ansible.legacy' in c.collections

# Generated at 2022-06-23 06:10:20.825220
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()
    assert col_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:32.300021
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.taggable import Taggable

    block = Block()
    role = Role()
    task = Task()
    role_include = RoleInclude()
    task_include = TaskInclude()
    handler_task_include = HandlerTaskInclude()
    taggable = Taggable()

    assert isinstance(block, CollectionSearch)
    assert isinstance(role, CollectionSearch)
    assert isinstance(task, CollectionSearch)

# Generated at 2022-06-23 06:10:34.842850
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    c = CollectionSearch()

    # Test constructor with only required parameters
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:37.147180
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert s._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:38.808223
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)



# Generated at 2022-06-23 06:10:40.474635
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:43.000350
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Default collection name is 'ansible.builtin'
    assert cs._collections._default == ['ansible.builtin']

# Generated at 2022-06-23 06:10:47.195949
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.priority == 100
    assert cs._collections.listof == string_types
    assert cs._collections.isa == 'list'
    assert cs._collections.always_post_validate
    assert cs._collections.static
    assert cs._collections.default == _ensure_default_collection
    assert cs._collections._value is None


# Generated at 2022-06-23 06:10:54.451932
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch, object):
        def __init__(self):
            self._collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                               always_post_validate=True, static=True)
            collection_search = CollectionSearch()
            collection_search._collections = collection_search._load_collections(collection_search._collections, [])

    test_collection_search = TestCollectionSearch()
    assert(test_collection_search._collections)


# Generated at 2022-06-23 06:10:57.084932
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    actual_result = collectionSearch._collections.default
    assert actual_result != []

# Generated at 2022-06-23 06:11:00.694898
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch()._collections, list)
    assert CollectionSearch()._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:11:12.027249
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.task.include import TaskInclude, TaskIncludeRole
    from ansible.playbook.play import Play


# Generated at 2022-06-23 06:11:14.057291
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_search = CollectionSearch()
    print(test_collection_search._collections)


# test_CollectionSearch()

# Generated at 2022-06-23 06:11:24.361751
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search1 = CollectionSearch()

    assert(search1._collections is not None)
    assert(len(search1._collections) == 1)
    assert(search1._collections[0] == 'ansible.builtin')
    assert(search1.collections == ['ansible.builtin'])

    search2 = CollectionSearch(collections=['ansible.builtin', 'ansible.legacy'])
    assert(search2.collections == ['ansible.legacy', 'ansible.builtin'])

    search3 = CollectionSearch(collections=['ansible.legacy', 'ansible.legacy'])
    assert(search3.collections == ['ansible.legacy'])

# Generated at 2022-06-23 06:11:24.897469
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-23 06:11:28.128189
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert type(search.collections) is list
    assert search.collections[0] == 'ansible_collections.nsweb.basic'

# Generated at 2022-06-23 06:11:28.646972
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

# Generated at 2022-06-23 06:11:38.958593
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import tempfile
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs

    loader = DataLoader()
    ansible_path = tempfile.mkdtemp()
    add_all_plugin_dirs(ansible_path)

    inventory = InventoryManager(loader=loader, sources=['localhost', 'localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 06:11:40.870296
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Foo:
        pass

    search = CollectionSearch()
    search._load_collections(Foo)
    assert len(search._collections) == 1

# Generated at 2022-06-23 06:11:49.747277
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ob = CollectionSearch()
    # collections will be set to ansible.builtin or ansible.legacy
    assert ob._collections is None or ob._collections in ('ansible.builtin', 'ansible.legacy')

    ob = CollectionSearch({'collections': ['foo']})
    assert ob._collections == ['foo', 'ansible.legacy']

    ob = CollectionSearch({'collections': ['foo', 'bar', 'baz']})
    assert ob._collections == ['bar', 'baz', 'foo', 'ansible.legacy']

    ob = CollectionSearch({'collections': ['ansible.builtin', 'foo', 'bar', 'baz']})
    assert ob._collections == ['bar', 'baz', 'foo', 'ansible.builtin']


# Generated at 2022-06-23 06:12:00.970766
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(None, None) is None
    assert CollectionSearch()._load_collections(None, []) is None
    assert CollectionSearch()._load_collections(None, ['']) is None
    assert CollectionSearch()._load_collections(None, '') is None

    # Test a collection from a galaxy project_name.
    assert CollectionSearch()._load_collections(None, ['community.kubernetes']) == ['community.kubernetes']

    # Test a collection from a galaxy project_name, with a namespace.
    assert CollectionSearch()._load_collections(None, ['namespace.community.kubernetes']) == \
        ['namespace.community.kubernetes']

    # Test a collection from a galaxy project_name with a version.
    assert CollectionSearch()._load

# Generated at 2022-06-23 06:12:02.804393
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_construction = CollectionSearch()
    assert test_construction._collections == _ensure_default_collection()


# Generated at 2022-06-23 06:12:05.848656
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    result= a._load_collections('attr','ds')
    assert result == [u'ansible.builtin']

# Generated at 2022-06-23 06:12:07.293717
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)

# Generated at 2022-06-23 06:12:09.613642
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default() == _ensure_default_collection()

# Generated at 2022-06-23 06:12:12.971248
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.__class__  is CollectionSearch

# Generated at 2022-06-23 06:12:14.445070
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert _ensure_default_collection() == x._collections

# Generated at 2022-06-23 06:12:21.155906
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection

    cs = CollectionSearch()

    # Test with collections set to None
    assert cs.post_validate(collections=None, orig_ds={}) == (None, {})
    assert cs.post_validate(collections=[], orig_ds={}) == ([], {})
    assert cs.post_validate(collections=None, orig_ds={}, validate_required=True) == ([], {})

    ansible_collections = AnsibleCollectionConfig.default_collection
    if ansible_collections:
        assert cs.post_validate(collections=None, orig_ds={}) == ([ansible_collections], {})
    else:
        assert cs.post_validate(collections=None, orig_ds={}) == (None, {})

# Generated at 2022-06-23 06:12:23.628210
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()



# Generated at 2022-06-23 06:12:29.266778
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    attributes = CollectionSearch._get_attributes()
    assert 'collections' in attributes
    assert attributes['collections'].priority == 100
    assert attributes['collections'].default == _ensure_default_collection
    assert attributes['collections'].always_post_validate == True
    assert attributes['collections'].static == True

# Generated at 2022-06-23 06:12:40.514823
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    is_search = CollectionSearch()
    is_search._load_collections(None, 'my.collection')
    assert is_search._load_collections(None, None) == None
    assert is_search._load_collections(None, []) == None
    assert is_search._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']
    assert is_search._load_collections(None, ['my.collection']) == ['my.collection']
    assert is_search._collections(['my.collection']) == ['my.collection']
    assert is_search._collections(None) == ['my.collection']
    assert is_search._collections(['my.collection']) == ['my.collection']

# Generated at 2022-06-23 06:12:43.947742
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # Test that no argument will not raise Exception
    cs._load_collections('', '')

    # Test that an argument is passed to _ensure_default_collection method
    assert cs._load_collections('', ['collection1']) == 'collection1'

# Generated at 2022-06-23 06:12:46.910442
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert_is_instance(collections, CollectionSearch)
    assert_is_instance(collections._collections, FieldAttribute)



# Generated at 2022-06-23 06:12:57.902470
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook_tests.units.mock.loader import DictDataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = {}
    variable_manager.set_commandline_vars({'collection_list': 'collections'})
    variable_manager.set_commandline_args({'collection_list': 'collections'})
    play_context = PlayContext()
    collection_search = CollectionSearch()
    collection_search._load_collections('collections', loader)

# Generated at 2022-06-23 06:13:00.512686
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections['static']
    assert cs._collections['default'] == [AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-23 06:13:02.937833
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:13:10.951190
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Arrange
    # only test of the scenario where no collection is given, so we only test the constructor
    # under given conditions
    collections_none = None
    builtin_collection = 'ansible.builtin'
    legacy_collection = 'ansible.legacy'

    # Act
    collections = _ensure_default_collection(collection_list=collections_none)

    # Assert
    assert (isinstance(collections, list))
    assert (builtin_collection in collections)
    assert (legacy_collection in collections)

# Generated at 2022-06-23 06:13:16.356478
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert isinstance(CollectionSearch()._collections, list) is False
    assert CollectionSearch()._collections is None
    assert CollectionSearch(collections=["random.collection"])._collections is not None

if __name__ == '__main__':
    test_CollectionSearch()