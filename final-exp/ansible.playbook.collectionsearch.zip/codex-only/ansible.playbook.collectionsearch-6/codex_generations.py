

# Generated at 2022-06-23 06:03:13.042604
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert not cs._collections()

# Generated at 2022-06-23 06:03:26.266756
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import datetime
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.parsing.dataloader import DataLoader

    AnsibleCollectionConfig.default_collection = 'foo.bar'

# Generated at 2022-06-23 06:03:36.417328
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_obj = CollectionSearch()
    assert search_obj._collections == ['ansible_collections.notmintest.not_a_real_collection.plugins.modules', 'ansible_collections.notmintest.not_a_real_collection.plugins.module_utils', 'ansible.builtin', 'ansible_collections.notmintest.not_a_real_collection.plugins.modules.lookup_plugins']

# Generated at 2022-06-23 06:03:38.344917
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == 'ansible.legacy' or cs.collections == 'ansible.builtin'

# Generated at 2022-06-23 06:03:40.253553
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == (AnsibleCollectionConfig.default_collection or 'ansible.legacy')

# Generated at 2022-06-23 06:03:43.621345
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test that __init__ runs
    cs = CollectionSearch()
    try:
        attr = cs._collections
    except:
        assert False


# Generated at 2022-06-23 06:03:46.063199
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    display.display("collection_search.__dict__:%s"%collection_search.__dict__)

if __name__ == "__main__":
    test_CollectionSearch();

# Generated at 2022-06-23 06:03:47.249480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections is not None

# Generated at 2022-06-23 06:03:55.197681
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert not collection_search._load_collections(None, None)

    collection_search._collections = 'default'
    assert collection_search._load_collections(None, None)[0] == 'ansible.legacy'

    collection_search._collections = ['default', 'ansible.terminal']
    assert collection_search._load_collections(None, None)[0] == 'ansible.terminal'
    assert collection_search._load_collections(None, None)[1] == 'ansible.legacy'
    assert collection_search._load_collections(None, None)[2] == 'ansible.terminal'

# Generated at 2022-06-23 06:03:57.510267
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)
    #tests field_attributes
    assert CollectionSearch()._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:03:59.439701
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ds = {"collections": [ "ansible_collections.xyz.zor"]}

# Generated at 2022-06-23 06:04:00.950976
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert cs.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:03.698911
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.value == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:04:06.628730
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    print(a)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:04:13.319723
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    fake_ds = [
        'local_module',
        'local_module2',
    ]
    collection_search._load_collections(None, fake_ds)
    assert collection_search._collections == [
        'local_module',
        'local_module2',
    ]

# Generated at 2022-06-23 06:04:15.108676
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collections = CollectionSearch()
    assert test_collections.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:15.667496
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-23 06:04:19.622471
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._ensure_default_collection(['A']) == ['A', 'ansible.legacy']
    assert CollectionSearch._ensure_default_collection(None) == ['ansible.legacy']
    assert CollectionSearch._ensure_default_collection([]) == ['ansible.legacy']

# Generated at 2022-06-23 06:04:30.756863
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        from ansible.playbook.play import Play
        from ansible.playbook.playbook import Playbook
        from ansible.playbook.task_include import TaskInclude
        from ansible.playbook.role.include import RoleInclude
    except ImportError:
        # We likely didn't include the playground and unit tests should be skipped
        return

    # Setting up the testing environment
    PLAYBOOK_PATH = '/ansible/test/unit/test_playbook_v2.yml'
    pb = Playbook.load(PLAYBOOK_PATH, variable_manager={}, loader=None)
    # Playbook Object has multiple attributes one of them being plays.
    pb_plays = pb.get_plays()
    # pb contains only one play, thus we get the first play

# Generated at 2022-06-23 06:04:33.478497
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = ['ansible.builtin', 'ansible.legacy']
    test_class = CollectionSearch(collections=collections)
    assert test_class._collections == collections

# Generated at 2022-06-23 06:04:35.280458
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ts = CollectionSearch()
    ts.collections = None
    assert ts.collections is None

# Generated at 2022-06-23 06:04:45.045962
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # If no collection is passed as constructor's argument, then by default, 
    # ansible.builtin collection is set as the collection.
    cs = CollectionSearch()
    if cs._collections == 'ansible.builtin':
        print('SUCCESS: ansible.builtin collection by default.')
    else:
        print('FAILURE: ansible.builtin collection is not set by default.')
    # If collection is set to a list of values, then the _collections attribute
    # is set to that list.
    cs = CollectionSearch(['col1', 'col2'])
    if cs._collections == ['col1', 'col2']:
        print('SUCCESS: Ansible collection is set to %s' % cs._collections)

# Generated at 2022-06-23 06:04:51.245884
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test to assert the object creation and value for collections
    obj = CollectionSearch()
    
    assert obj._collections == ['ansible.builtin', 'ansible.legacy']
    assert not hasattr(obj, '_collections_cache')
    assert obj.__dict__['_collections'] == ['ansible.builtin', 'ansible.legacy']
    assert obj.__dict__['collections'] == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:04:53.425232
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollSearch(CollectionSearch):
        pass
    coll_search = CollSearch()
    coll_search.load(dict(), None, None, '')

# Generated at 2022-06-23 06:04:56.298999
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert cs.collections is not None
    cs.collections = "test"
    assert cs.collections is None

# Generated at 2022-06-23 06:04:58.503761
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ["ansible_collections.ns.name", "ansible.legacy"]

# Generated at 2022-06-23 06:05:09.614992
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    cs = CollectionSearch()

    # test for FieldAttribute of type list having listof string_types and priority=100
    assert isinstance(cs._collections, FieldAttribute)
    assert cs._collections.isa == 'list'
    assert (list, string_types) == cs._collections.listof
    assert cs._collections.priority == 100
    assert cs._collections.default is _ensure_default_collection

    # test for _ensure_default_collection() method
    assert _ensure_default_collection(['namespace.action_name1, namespace.action_name2, ansible.legacy']) == ['namespace.action_name1', 'namespace.action_name2', 'ansible.legacy']
    assert _ensure

# Generated at 2022-06-23 06:05:19.657784
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    
    # test the constructor of Class CollectionSearch
    collection_search = CollectionSearch()
    
    # test the _load_collections function
    # get the default collection
    default_collection = AnsibleCollectionConfig.default_collection
    collection = collection_search._load_collections(None, [default_collection])
    assert len(collection) &gt; 0
    # empty list
    collection = collection_search._load_collections(None, [])
    assert collection is None
    collection = collection_search._load_collections(None, None)
    assert collection is None
    # add a new collection to the list.
    new_collection = 'ansible.builtin'
    list = ['ansible.builtin']
    collection = collection_search._load_collections(None, list)
    assert new_collection in collection

# Generated at 2022-06-23 06:05:21.622264
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:05:28.033135
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._load_collections({'name': 'collections', 'tasks': 'tasks', 'roles': 'roles'}, {}) == ['ansible.builtin']
    assert obj._load_collections({'name': 'collections', 'tasks': 'tasks', 'roles': 'roles'}, {'collections': ['collection1']}) == ['collection1', 'ansible.builtin']

# Generated at 2022-06-23 06:05:30.932627
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print("collections : ", obj.collections)

# test_CollectionSearch()

# Generated at 2022-06-23 06:05:33.016640
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    tst = CollectionSearch()
    assert tst._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:05:41.406500
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert isinstance(x._load_collections('collections', ['test']), list)
    assert x._load_collections('collections', ['test']) == ['test']
    assert x._load_collections('collections', ['ansible_collections.acme.test']) == ['ansible_collections.acme.test']
    assert x._load_collections('collections', []) == None
    assert x._load_collections('collections', ['test', 'test1']) == ['test', 'test1']

# This is called by the unit test
if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:05:43.992397
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class testclass(CollectionSearch):
        pass
    testobj = testclass()
    assert(testobj._collections is not None)

# Generated at 2022-06-23 06:05:44.837186
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_object = CollectionSearch()

# Generated at 2022-06-23 06:05:45.508978
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    raise NotImplemented

# Generated at 2022-06-23 06:05:47.006850
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:05:58.035828
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # pylint: disable=unused-variable
    repo_dict = dict()
    repos = dict()
    cache_entry = dict()
    repos_paths = dict()
    collection_config_obj = CollectionSearch()
    default_collection = AnsibleCollectionConfig.default_collection

    # Populate repos_paths dict with paths of different collections
    repos_paths[default_collection] = '/tmp/ansible.ansible_collections.' + default_collection
    repos_paths['ansible.legacy'] = '/tmp/ansible.ansible_collections.' + 'ansible.legacy'
    repos_paths['collection1'] = '/tmp/ansible.ansible_collections.' + 'collection1'
    # pylint: enable=unused-variable

    # No cache file found

# Generated at 2022-06-23 06:06:01.906018
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections("collection_search", None)[0] == "ansible_collections.ansible.builtin"
    assert cs._load_collections("collection_search", ['my_custom_collection'])[0] == "my_custom_collection"

# Generated at 2022-06-23 06:06:03.860101
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    # default value
    assert search._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:06:07.303486
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch() 
    collection_search._collections="test_collection"
    collection_search.collections = _ensure_default_collection()
    assert collection_search.collections =="test_collection"

# Generated at 2022-06-23 06:06:14.610765
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch(ds=dict(collections=['local_collection']))
    assert search._collections.value == ['local_collection']
    assert 'local_collection' in search._collections.value
    assert 'ansible.builtin' not in search._collections.value
    assert 'ansible.legacy' not in search._collections.value

    assert 'ansible.builtin' not in search._collections.value
    assert 'ansible.legacy' not in search._collections.value

    search = CollectionSearch(ds=dict(collections=[]))
    assert search._collections.value is not None

# Generated at 2022-06-23 06:06:19.690314
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook import Play
    from ansible.playbook.role import Role

    c = Play()
    assert c.collections == c._collections.default()

    c = Role()
    assert c.collections == c._collections.default()

# Generated at 2022-06-23 06:06:21.024843
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == None

# Generated at 2022-06-23 06:06:23.483606
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch is not None
    assert collectionSearch._collections is not None
    assert collectionSearch._collections._default() is not None
    assert collectionSearch._collections._default() == _ensure_default_collection()

# Generated at 2022-06-23 06:06:24.996708
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections.default() is None

# Generated at 2022-06-23 06:06:29.061827
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:06:37.082156
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()


# Generated at 2022-06-23 06:06:39.002620
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        t = CollectionSearch()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-23 06:06:47.052514
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create a devpi_search object
    t = CollectionSearch()

    # Check if the object is an instance of CollectionSearch
    assert(isinstance(t, CollectionSearch))

    # Check if devpi_search object has correct default value for _collections
    assert(t._collections['default'] == _ensure_default_collection())

    # Check if CollectionSearch has the method _load_collections
    assert(hasattr(t, '_load_collections'))

# Generated at 2022-06-23 06:06:53.163191
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.load_data(dict(collections=None,))
    assert cs._collections._value is None
    cs.load_data(dict(collections=[],))
    assert cs._collections._value == []
    cs.load_data(dict(collections=['a', 'b'],))
    assert cs._collections._value == ['a', 'b']

# Generated at 2022-06-23 06:06:54.360549
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj

# Generated at 2022-06-23 06:06:58.479002
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

    if search.collections is None:
        return "Warning: search.collections is None."
    elif len(search.collections) == 0:
        return "Warning: search.collections is empty."
    else:
        return True

# Generated at 2022-06-23 06:07:07.047710
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.module_utils.six.moves import cStringIO as StringIO

    class TestCollectionSearchClass(Base, CollectionSearch):
        def __init__(self):
            Base.__init__(self)
            CollectionSearch.__init__(self)

    with open('test_playbook_tasks_roles_include_skip.yml') as f:
        data = f.read()
        stream = StringIO(data)
        yaml_data = yaml.load(stream, yaml.SafeLoader)

    yaml_data.pop('collections', None)
    t = TestCollectionSearchClass()
    t.load_data(yaml_data)
    expected = ['ansible.builtin', 'ansible.legacy']
    assert t.collections

# Generated at 2022-06-23 06:07:08.788339
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:09.569697
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()

# Generated at 2022-06-23 06:07:11.380499
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # test default collections
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:19.384908
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    pc = PlayContext()
    collection_search = CollectionSearch()
    result = collection_search._load_collections('collections', None)
    assert result == ['ansible.posix']
    result = collection_search.get_validated_value('collections', collection_search._collections, ['ansible.posix'], None)
    assert result == ['ansible.posix']
    result = collection_search.get_validated_value('collections', collection_search._collections, ['ansible.posix', 'ansible.legacy'], None)
    assert result == ['ansible.posix', 'ansible.legacy']

# Generated at 2022-06-23 06:07:28.502242
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import json

    display.verbosity = 3
    display.display('=== test_CollectionSearch ===')

    test_data = {
        "collections": [
            "collection1",
            "collection2"
        ]
    }
    test_data_json = json.dumps(test_data)
    display.display('test_data_json: %s' % test_data_json)

    cs = CollectionSearch()
    display.display('cs._collections: %s' % cs._collections)

    # set __dict__
    cs.__dict__ = test_data

    display.display('test_data: %s' % test_data)

    # With templated collections
    display.display('test_data[collections]: %s' % test_data['collections'])

    # Without templated collections

# Generated at 2022-06-23 06:07:40.624928
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.task_include import TaskInclude
    import collections

    # Create a TaskInclude object
    uut = TaskInclude()
    # Check the __init__() function of TaskInclude class
    assert uut.__init__() == None

    # Create an object for the CollectionSearch class
    uut2 = CollectionSearch()
    assert uut2._collections.name == 'collections'

    # Make sure that the post_validate method return the same list as it receives
    # in the case where the list it receives is None
    collections_list = None
    result = _ensure_default_collection(collections_list)
    assert result == None

    # Make sure that the post_validate method return the same list as it receives
    # in the case where the list it receives is empty
    collections

# Generated at 2022-06-23 06:07:41.465661
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections

# Generated at 2022-06-23 06:07:43.332467
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-23 06:07:44.337601
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    c.post_validate(dict(), 'test')

# Generated at 2022-06-23 06:07:47.891498
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections._static is True
    collections = obj._load_collections(attr=None, ds=None)
    assert collections == ['ansible_collections.nsot.mixins']

    try:
        obj._collections._static = False
        new_collections = obj._load_collections(attr=None, ds=None)
    except Exception as e:
        assert 'is not templatable' in str(e)

# Generated at 2022-06-23 06:07:52.702876
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_instance = CollectionSearch()
    assert collection_search_instance._collections == _ensure_default_collection()
    assert collection_search_instance._load_collections('collections', []) == None

# Generated at 2022-06-23 06:07:55.627161
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    sc = CollectionSearch()
    sc._collections = ['ansible-network.network']
    sc._load_collections('collections', 'name')
    assert sc._collections == ['ansible-network.network']

    sc = CollectionSearch()
    sc._collections = ['ansible.builtin', 'ansible-network.network']
    sc._load_collections('collections', 'name')
    assert sc._collections == ['ansible.builtin', 'ansible-network.network']

# Generated at 2022-06-23 06:08:01.517781
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import collections

    collection_loader = collections.namedtuple('collection_loader', ['search_paths', 'aliases'])
    collection_loader._collections = []
    collection_loader.playbook_dir = '/tmp'

    cs = CollectionSearch(loader=collection_loader)

    assert cs._collections == ['ansible.builtin']
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:08:03.126245
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()
    coll.collections = ['ansible.ops']
    coll._load_collections('collections', coll.collections)

# Generated at 2022-06-23 06:08:06.051406
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ['ansible.builtin', 'ansible.legacy', 'community.general']
    print(cs.collections)

# Generated at 2022-06-23 06:08:08.373699
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search
    assert collection_search._collections is not None
    assert collection_search._load_collections is not None

# Generated at 2022-06-23 06:08:13.171774
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    # test for creation of instance
    assert c
    # test for testing fields
    assert c.fields == dict(collections=c._collections)

# Generated at 2022-06-23 06:08:15.500859
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    tcs = CollectionSearch()
    assert tcs._collections is not None, "CollectionSearch._collections not created"


# Generated at 2022-06-23 06:08:20.801683
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_data = {'collections': ['collection_one', 'collection_two']}
    test_instance = CollectionSearch()
    assert test_instance._load_collections(None, test_data) == test_data['collections']

    test_data = {'collections': []}
    assert test_instance._load_collections(None, test_data) is None

# Generated at 2022-06-23 06:08:25.404945
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()
    ds = {'collections': ['my.ansible_collections.my_namespace.my_collection']}
    cs._load_collections('collections', ds)
    assert cs.collections == ['my.ansible_collections.my_namespace.my_collection']

# Generated at 2022-06-23 06:08:26.722696
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == _ensure_default_collection()

# Generated at 2022-06-23 06:08:28.259712
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:08:29.445382
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj._load_collections, staticmethod)

# Generated at 2022-06-23 06:08:34.993123
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ''' make sure we instantiate CollectionSearch class with no error '''
    try:
        cs = CollectionSearch()
    except Exception as e:
        pytest.fail("CollectionSearch instantiation failed, {0}".format(e))

# Generated at 2022-06-23 06:08:36.024957
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    if not CollectionSearch():
        assert False

# Generated at 2022-06-23 06:08:37.053011
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.default == 'ansible.builtin'

# Generated at 2022-06-23 06:08:39.113104
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:08:44.845941
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    field = CollectionSearch._collections
    assert field.name == 'collections'
    assert field.isa == 'list'
    assert field.listof == string_types
    assert field.priority == 100
    assert field.default() == ['ansible.builtin']
    assert field.always_post_validate
    assert field.static
    assert field.type_name == 'list'
    assert field.required == False
    assert field.aliases == []
    assert field.final

# Generated at 2022-06-23 06:08:49.214422
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']
    assert cs._load_collections([], ['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-23 06:08:59.164703
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.playbook.base
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.playbook.handler

    # test that the default collections list with default_collection
    # before searching for roles, tasks, etc.
    ansible_collections = [
        'ansible.builtin',
        'nsxt.modules.network.nsxt_logical_routers_facts',
        'nsxt.modules.network.nsxt_logical_routers_sets_facts'
    ]
    display = Display()
    tmp_params = {
        'collections': ansible_collections
    }
    tmp_ds = {}
    collection_search = CollectionSearch()

# Generated at 2022-06-23 06:09:01.545617
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections('_load_collections', None) == None

# Generated at 2022-06-23 06:09:09.813717
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.playbook.base import Base

    class DummyRole(Base, CollectionSearch):
        pass

    d = DummyRole()
    assert d._collections.default == ['ansible.legacy']

    d.collections = ['collection']
    assert d.collections == ['collection', 'ansible.legacy']

    d.collections = []
    assert d.collections == ['ansible.legacy']

    d.collections = ['collection1', 'collection2']
    assert d.collections == ['collection1', 'collection2', 'ansible.legacy']

    d.collections = ['collection1', 'ansible.builtin', 'collection2']
    assert d.collections == ['collection1', 'ansible.builtin', 'collection2']

# Generated at 2022-06-23 06:09:14.051623
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.set_loader(MagicMock())
    cs.set_task_basedir(MagicMock())
    cs.get_validated_value('collections', cs._collections, None, None)
    assert cs.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:15.378812
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is not None

# Generated at 2022-06-23 06:09:17.513526
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This test verifies no exception raised
    CollectionSearch()



# Generated at 2022-06-23 06:09:18.189786
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-23 06:09:21.929088
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    x._collections = ["Ansible"]
    x._load_collections("collections", x._collections)
    print(x)

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:09:23.572579
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert s._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:32.436053
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    h = CollectionSearch()
    if h._collections == 'ansible.builtin,ansible.legacy':
        print("test_CollectionSearch: Case 1: " + "True")
    else:
        print("test_CollectionSearch: Case 1: " + "False")

    h1 = CollectionSearch()
    h1.collections = ["ansible.module_utils.network.nxos.nxos", "ansible.netcommon"]
    if h1._collections == "ansible.module_utils.network.nxos.nxos,ansible.netcommon,ansible.builtin,ansible.legacy":
        print("test_CollectionSearch: Case 2: " + "True")
    else:
        print("test_CollectionSearch: Case 2: " + "False")

    h2 = CollectionSearch()
   

# Generated at 2022-06-23 06:09:33.871608
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    '''collection_search = CollectionSearch()'''

# Generated at 2022-06-23 06:09:37.402631
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    collections = collection._load_collections(attr='collections', ds=None)
    assert collections == _ensure_default_collection()
    return collections

# Generated at 2022-06-23 06:09:39.154547
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:40.272759
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None

# Generated at 2022-06-23 06:09:43.826874
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass

    c = TestCollectionSearch()

    c.post_validate(None, None)

# Generated at 2022-06-23 06:09:44.814263
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert not instance.collections

# Generated at 2022-06-23 06:09:59.082522
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.plugins.loader import lookup_loader
    def loader_factory(module_loader):
        return lookup_loader
    def display_warning(message):
        print(message)
    display.display_warning = display_warning
    display.warning = display_warning

    obj = CollectionSearch()
    assert(obj._collections == ['ansible.builtin', 'ansible.legacy'])
    obj._collections = []
    obj.post_validate()
    assert(obj.collections == ['ansible.builtin', 'ansible.legacy'])
    obj.collections = ['ansible.zero']
    obj._load_collections(None, ['ansible.zero'])
    obj.collections = ['ansible.zero']
    obj.post_validate()

# Generated at 2022-06-23 06:09:59.945656
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None

# Generated at 2022-06-23 06:10:01.045545
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c=CollectionSearch()

# Generated at 2022-06-23 06:10:02.627174
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    new_CollectionSearch = CollectionSearch()

# Generated at 2022-06-23 06:10:04.020961
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch.collections, FieldAttribute)

# Generated at 2022-06-23 06:10:06.877725
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = CollectionSearch()
    assert ds._collections._get_default() == ["ansible_collections.ansible.builtin", "ansible.legacy"]


# Generated at 2022-06-23 06:10:08.987878
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # CollectionSearch() to test basic initialization of the class
    c = CollectionSearch()
    assert c is not None

# Generated at 2022-06-23 06:10:09.994230
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections is not None

# Generated at 2022-06-23 06:10:16.903761
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test for constructor without parameter
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']
    # test for constructor with parameter
    cs = CollectionSearch(collections=[])
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']
    cs = CollectionSearch(collections=['jdauphant.nginx'])
    assert cs._collections == ['jdauphant.nginx', 'ansible.builtin', 'ansible.legacy']
    cs = CollectionSearch(collections=['ansible.builtin'])
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']
    cs = CollectionSearch(collections=['ansible.builtin', 'ansible.legacy'])
    assert cs._col

# Generated at 2022-06-23 06:10:19.004021
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a=CollectionSearch()
    assert a._collections==['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:10:21.282703
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    vl = cs._valid_attrs['collections']
    assert vl.default() == []

# Generated at 2022-06-23 06:10:24.130657
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:30.739287
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()

    collection_list = ['collectionA', 'collectionB']
    collection_search = CollectionSearch(collections=collection_list)
    assert collection_search.collections == _ensure_default_collection(collection_list)

    collection_list = ['ansible.builtin', 'collectionA', 'collectionB']
    collection_search = CollectionSearch(collections=collection_list)
    assert collection_search.collections == collection_list

    collection_list = ['ansible.builtin', 'ansible.legacy']
    collection_search = CollectionSearch(collections=collection_list)
    assert collection_search.collections == collection_list

# Generated at 2022-06-23 06:10:34.790939
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        obj = CollectionSearch()
    except Exception as e:
        assert False, "Unexpected exception raised when creating object CollectionSearch. Error: " + str(e)
    else:
        assert True

# Generated at 2022-06-23 06:10:37.764234
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj1 = CollectionSearch()
    # default value 'collections'
    assert obj1._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:10:40.155146
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    env = Environment()
    search = CollectionSearch()

    assert isinstance(search, CollectionSearch)


# Generated at 2022-06-23 06:10:42.667945
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs == {}

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:10:44.858415
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collsearch = CollectionSearch()
    assert collsearch is not None

# Generated at 2022-06-23 06:10:54.375492
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import inspect

    name = "test_name"
    collection_search = CollectionSearch(name)

    # Test return value of '_collections'
    assert type(collection_search._collections) is inspect.getmembers(collection_search, inspect.isdatadescriptor)

    # Test return value of collection
    # print(collection_search.collection)
    # assert collection_search.collection

    # Test return value of _load_collections()
    attr = collection_search._collections
    ds = None
    assert type(collection_search._load_collections(attr, ds)) is list
    assert collection_search._load_collections(attr, ds)
    # print(collection_search._load_collections(attr, ds))

# Generated at 2022-06-23 06:10:57.041068
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:03.722465
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()
    assert c.__dict__ == {'_collections': ['ansible.builtin', 'ansible.builtin.linux', 'ansible.builtin.windows', 'ansible.netcommon', 'ansible.legacy', 'community.general']}

# Generated at 2022-06-23 06:11:05.625799
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    assert isinstance(collectionsearch,CollectionSearch)



# Generated at 2022-06-23 06:11:10.117404
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Testing constructor of CollectionSearch class
    collection_search = CollectionSearch()
    assert(collection_search._collections.default == _ensure_default_collection)
    assert(collection_search._load_collections(None, None) == None)

# Generated at 2022-06-23 06:11:17.404513
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # call the constructor
    c = CollectionSearch()
    # call needed private vars (will be needed for testing private method)
    c._collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=c._ensure_default_collection, always_post_validate=True, static=True)
    # call private method that is used in the constructor
    collection_list = ['ansible.builtin', 'ansible.legacy', 'ansible.builtin.role']
    c._ensure_default_collection(collection_list)
    # assert expected value
    assert collection_list == ['ansible.builtin', 'ansible.legacy', 'ansible.builtin.role']


# Generated at 2022-06-23 06:11:19.168934
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._ensure_default_collection([]) == 'ansible.builtin'

# Generated at 2022-06-23 06:11:20.849007
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == 'ansible.builtin'

# Generated at 2022-06-23 06:11:22.663045
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch

# Generated at 2022-06-23 06:11:31.783011
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.module_utils.six import StringIO
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context._host = "localhost"
    play_context._port = 22

    display = Display()
    display.verbosity = 2
    display.deprecate = frozenset()

    my_io = StringIO()
    display.add_event_handler('vvv', my_io.write)

    Play = Base.load('play', dict(name="test_play", hosts={}, collections=[], gather_facts='no'), play_context, loader=None, variable_manager=None)

    play = Play.load(play_context, variable_manager=None, loader=None)

    assert play._collections is not None

# Generated at 2022-06-23 06:11:36.365468
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    t = Task(play=None, block=Block(play=None), task_include=None,
             role=None, play_context=PlayContext())

    assert t._collections == ["ansible.builtin"]

# Generated at 2022-06-23 06:11:42.938595
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()
    assert collection_search._collections.priority == 100
    assert not collection_search._collections.always_post_validate
    assert collection_search._collections.static
    assert collection_search._collections.listof == string_types
    assert collection_search._collections.template_name == 'collections'
    assert collection_search._collections.path_name == 'collections'

# Generated at 2022-06-23 06:11:45.853094
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection = CollectionSearch()
    assert test_collection._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:11:46.574340
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-23 06:11:56.253692
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.parsing.dataloader import DataLoader

    Base = type('Base', tuple(CollectionSearch.get_mixin_class()), {'_collections': FieldAttribute()})
    dataloader = DataLoader()
    cs = Base(task_loader=dataloader)

    assert cs._collections == ['ansible_collections.foo.bar']

    cs = Base('some_path', task_loader=dataloader)
    assert cs._collections == ['ansible.builtin', 'ansible_collections.foo.bar']

# Generated at 2022-06-23 06:11:58.169624
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert _ensure_default_collection(collection_list=t._collections)

# Generated at 2022-06-23 06:11:59.566953
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs=CollectionSearch()
    assert cs is not None


# Generated at 2022-06-23 06:12:01.068117
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch=CollectionSearch()
    assert test_CollectionSearch.collections==_ensure_default_collection()

# Generated at 2022-06-23 06:12:02.553931
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Test CollectionSearch()."""
    collection_search = CollectionSearch()
    assert collection_search.collections is None

# Generated at 2022-06-23 06:12:04.248718
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections is not None

# Generated at 2022-06-23 06:12:09.249538
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch.get_validated_value('collections', collectionSearch._collections,
                                                ['ansible.builtin', 'ansible.community.aws'], None) == ['ansible.builtin', 'ansible.community.aws']

# Generated at 2022-06-23 06:12:18.214969
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._load_collections(1, []) == None
    assert collectionSearch._load_collections(1, ['test']) == ['ansible.builtin', 'test']
    assert collectionSearch._load_collections(1, ['test', 'test2']) == ['ansible.builtin', 'test', 'test2']
    assert collectionSearch._load_collections(1, ['test', 'test2']) != ['test', 'test2']

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:12:22.273038
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    displayed = collection_search._load_collections(['ansible.builtin','ansible.legacy'], {})
    assert displayed == ['ansible.builtin','ansible.legacy']

# Generated at 2022-06-23 06:12:29.266880
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def get_validated_value(self, attr, field, data, validate_filters=True):
        return data

    CollectionSearch.get_validated_value = get_validated_value
    collection_search = CollectionSearch(collections=None)
    collections = collection_search.collections
    assert collections is not None
    assert collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:12:32.594319
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   try:
     assert CollectionSearch().collections == _ensure_default_collection()
   except AssertionError:
     print("class CollectionSearch():collections is not equal to _ensure_default_collection()")


# Generated at 2022-06-23 06:12:33.711283
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:12:42.137717
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case = CollectionSearch()
    # print('_collections: ', test_case._collections)
    print('_load_collections: ', test_case._load_collections(attr='collections', ds=['ansible_collections.nsxt']))
    print('_collections: ', test_case._collections)

# test_case = CollectionSearch()
# print('_load_collections: ', test_case._load_collections(attr='collections', ds=['ansible_collections.nsxt']))
# print('_collections: ', test_case._collections)

# Generated at 2022-06-23 06:12:43.054846
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search

# Generated at 2022-06-23 06:12:53.423307
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import sys
    import inspect

    # Getting function members
    try:
        function_members = inspect.getmembers(CollectionSearch, predicate=inspect.ismethod)
    except AttributeError:
        # Python 2.6 doesn't have predicate.
        function_members = inspect.getmembers(CollectionSearch, lambda x: inspect.ismethod(x) and not inspect.isbuiltin(x))

    # Getting the private function __search_in_list
    function_names = [n for n, x in function_members if n.startswith('_')]
    assert len(function_names) == 2
    assert '_ensure_default_collection' in function_names
    assert '_load_collections' in function_names

# Generated at 2022-06-23 06:13:02.502952
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This will try to load the collection list from a
    # ansible.cfg file in the current directory. If there
    # is no such config file, then the implicit default
    # [ansible_collections] will be used. Alternatively,
    # you can use the collection list to supply a different
    # default collection if you are using your own collection.
    search = CollectionSearch()
    # this should print the list of collections in the config file
    print(search._collections)
    # this should print the list of collections in the config file
    # with 'ansible.builtin' appended to the end.
    print(search._load_collections(1, search._collections))

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:13:05.938150
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search._collections)

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:13:07.257019
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # TODO: Implement
    assert False, "TODO: Implement"

# Generated at 2022-06-23 06:13:13.922108
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.playbook.play_context import PlayContext

    # check "collections" field
    # test with empty, list and invalid data
    try:
        play_context = PlayContext()
        play_context.collections = []
        assert play_context.collections is None
    except:
        assert False

    try:
        play_context = PlayContext()
        play_context.collections = ['ansible.posix']
        assert play_context.collections == ['ansible.posix']
    except:
        assert False
