

# Generated at 2022-06-23 06:03:23.483985
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']
    # Note: when _load_collections is called with None as ds,
    # _ensure_default_collection(collection_list=ds) returns defaults to ['ansible.builtin']
    assert c._load_collections(None, None) == ['ansible.builtin']
    assert c._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']
    assert c._load_collections(None, []) == ['ansible.builtin']

# Generated at 2022-06-23 06:03:34.045823
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class MyClass(CollectionSearch):
        def __init__(self):
            self._collections = TestVal()

    # Test default value
    obj = MyClass()
    assert obj.get_validated_value('collections', obj._collections, None, None) == ['ansible.builtin']

    obj = MyClass()
    obj._collections = "ansible.builtin"
    assert obj.get_validated_value('collections', obj._collections, None, None) == ['ansible.builtin']

    obj._collections = ['ansible.ansible_collections.test_collection']
    assert obj.get_validated_value('collections', obj._collections, None, None) == ['ansible.ansible_collections.test_collection']

    obj._collections = None
    assert obj.get

# Generated at 2022-06-23 06:03:36.700666
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()
    assert c._collections == [AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-23 06:03:44.773769
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    # Make sure "collections" field is added to vars
    assert('collections' in collection_search.attr_names)

    # Make sure "collections" field is readonly
    assert(collection_search.fields['collections'].read_only)

    # Make sure "collections" field is set to None
    assert(collection_search.collections is None)

    # Make sure "_collections" field is not None
    assert(collection_search._collections is not None)

# Test if _ensure_default_collection returns correct list

# Generated at 2022-06-23 06:03:53.085219
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    col_ins = CollectionSearch()
    result = col_ins.get_validated_value(col_ins.collections, None)

    # Should return a list of strings
    assert isinstance(result, list)
    assert isinstance(result[0], str)

    # Should return default collection if nothing is passed
    assert result[0] == 'ansible.builtin'

    result = col_ins.get_validated_value(col_ins.collections, ['my.collection'])

    # Should return passed collection, if it is not the same as the default
    assert isinstance(result, list)
    assert isinstance(result[0], str)

    # Should return default collection if nothing is passed
    assert result[0] == 'my.collection'


# Generated at 2022-06-23 06:04:04.306521
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test for _ensure_default_collection
    assert CollectionSearch._ensure_default_collection(['ansible.builtin']) == ['ansible.builtin', 'ansible.builtin']
    assert CollectionSearch._ensure_default_collection(['ansible.builtin', 'ansible.builtin']) == ['ansible.builtin', 'ansible.builtin', 'ansible.builtin']
    assert CollectionSearch._ensure_default_collection(['ansible.builtin', 'ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.builtin', 'ansible.legacy']
    assert CollectionSearch._ensure_default_collection(['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']
   

# Generated at 2022-06-23 06:04:06.189351
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch is not None

# Generated at 2022-06-23 06:04:15.619505
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ds = None
    attr = 'collections'
    result = cs._load_collections(attr, ds)
    assert ['ansible.builtin', 'ansible.legacy'] == result

    cs = CollectionSearch()
    ds = []
    attr = 'collections'
    result = cs._load_collections(attr, ds)
    assert ['ansible.builtin', 'ansible.legacy'] == result

    cs = CollectionSearch()
    ds = ['ansible.builtin']
    attr = 'collections'
    result = cs._load_collections(attr, ds)
    assert ['ansible.builtin', 'ansible.legacy'] == result

# Generated at 2022-06-23 06:04:17.733859
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    c = CollectionSearch()
    assert c._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:04:21.929326
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create CollectionSearch instance
    collection_search = CollectionSearch()

    # Make sure that collections property is initialized correctly
    assert collection_search.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:04:23.204899
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections is not None

# Generated at 2022-06-23 06:04:33.902908
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test for default value of _collections
    assert _ensure_default_collection() == ['ansible.builtin', 'ansible.legacy']

    # Test for constructor called with {{ansible_collection_path}}
    # _ensure_default_collection is not invoked in that case
    assert _ensure_default_collection([]) == []
    assert _ensure_default_collection(['{{ansible_collection_path}}']) == ['{{ansible_collection_path}}']
    # _ensure_default_collection is invoked in that case
    assert _ensure_default_collection(['foo.bar']) == ['ansible.builtin', 'ansible.legacy', 'foo.bar']

    # Test for constructor called with --roles-path and --collections-path

# Generated at 2022-06-23 06:04:35.333414
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.value is not None

# Generated at 2022-06-23 06:04:38.866656
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.set_loader(None)
    cs._collections = None
    cs._load_collections('collections', None)
    assert cs._collections == _ensure_default_collection(collection_list=None)

# Generated at 2022-06-23 06:04:41.310680
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # testing constructor
    collectionSearch1 = CollectionSearch()
    assert collectionSearch1._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:44.885845
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collections_search_class = CollectionSearch()
    print(test_collections_search_class._collections)
    print(test_collections_search_class._collections.data_from)
    print(test_collections_search_class._collections.post_validate())


# Generated at 2022-06-23 06:04:47.556862
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections('collections', "foo") == ['foo']
    assert cs.collections == ['foo']


# Generated at 2022-06-23 06:04:49.265696
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ["ansible_collections.nsxt"]

# Generated at 2022-06-23 06:04:52.315077
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:04:57.258813
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_dict = {
        'collections': ['collection_1', 'collection_2']
    }

    try:
        CollectionSearch(ds=test_dict, data=None)
    except KeyError:
        raise AssertionError("Failed to create CollectionSearch object")


# Generated at 2022-06-23 06:05:00.777967
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Object of class CollectionSearch
    collections_obj = CollectionSearch()
    # Check for _ensure_default_collection
    assert collections_obj._collections, collections_obj._ensure_default_collection()

# Generated at 2022-06-23 06:05:09.230163
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()

    assert cs._collections.default == ['ansible.collections.ansible_devel']

    collections = ['ansible.collections.nsweb.zabbix']
    assert cs._load_collections(None, collections) == ['ansible.collections.nsweb.zabbix', 'ansible.collections.ansible_devel']

    collections = ['ansible.collections.ansible_devel']
    assert cs._load_collections(None, collections) == ['ansible.collections.ansible_devel', 'ansible.collections.ansible_devel']

# Generated at 2022-06-23 06:05:10.750980
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_base = CollectionSearch()
    assert test_base.collections == ['ansible.legacy']

# Generated at 2022-06-23 06:05:16.376230
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search = CollectionSearch()
        assert collection_search
        collections = collection_search._load_collections('collections', [])
        assert collections
    except Exception as e:
        print("Test fail!")

# Do unit test when invoked directly
if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:05:18.310364
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()


# Generated at 2022-06-23 06:05:24.532948
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    test_obj = CollectionSearch()

    assert test_obj._collections is not None
    assert _ensure_default_collection(None) == ['ansible_collections.ansible.builtin']
    assert _ensure_default_collection(['collection1']) == ['collection1', 'ansible_collections.ansible.builtin']

# Generated at 2022-06-23 06:05:25.700562
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c is not None

# Generated at 2022-06-23 06:05:27.690914
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections['default'] == ['ansible.legacy']



# Generated at 2022-06-23 06:05:32.339285
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import RoleInclude
    result = RoleInclude()
    c = CollectionSearch()
    c._collections = result._collections
    assert c._collections == result._collections

# Generated at 2022-06-23 06:05:35.195006
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert [] == collection_search._load_collections(None, None)
    assert None is collection_search._load_collections(None, [])

# Generated at 2022-06-23 06:05:37.335622
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d=CollectionSearch()
    d._load_collections('collections',None)

# Generated at 2022-06-23 06:05:38.336915
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-23 06:05:40.659203
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = ["jdoe.mytest"]
    assert CollectionSearch._collections.default(ds) == ['jdoe.mytest', 'ansible.builtin']

# Generated at 2022-06-23 06:05:43.992341
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testSearch = CollectionSearch()
    testSearch.collections = ['collection_1', 'collection_2']
    assert testSearch.collections == ['collection_1', 'collection_2']


# Generated at 2022-06-23 06:05:54.445732
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = dict()
    t = CollectionSearch()
    assert t is not None
    # test for collection_list which is None
    assert t._load_collections('collections', ds) == ['ansible.legacy']
    # test for list of collections
    ds['collections'] = ["test.ns1.collection1", "test.ns2.collection2"]
    assert t._load_collections('collections', ds) == ['ansible.legacy', 'test.ns1.collection1', 'test.ns2.collection2']
    # test for empty list of collections
    ds['collections'] = []
    assert t._load_collections('collections', ds) == ['ansible.legacy']

# Generated at 2022-06-23 06:05:56.751228
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Fake:
        collections = []

    a = CollectionSearch()
    a.set_loader(Fake())
    a._load_collections('', [])

# Generated at 2022-06-23 06:06:02.053549
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.playbook.attribute import FieldAttribute
    from string import ascii_letters as letters
    from random import choice
    from ansible.template import is_template, Environment

    collection_name = "".join(choice(letters) for i in range(10))
    # An AnsibleCollectionConfig with the collection name
    testAnsibleCollectionConfig = AnsibleCollectionConfig(collection_name)
    # To check the output results of the default constructor
    obj1 = CollectionSearch()

    assert obj1.__class__.__name__ == "CollectionSearch"
    assert obj1._collections.isa == 'list'
    assert obj1._collections.listof == string_types
    assert len(obj1._collections.default(None)) == 1
    assert obj1

# Generated at 2022-06-23 06:06:02.643363
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-23 06:06:03.931776
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  # Test class instantiation
  testObj = CollectionSearch()
  assert testObj is not None

# Generated at 2022-06-23 06:06:14.307393
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import yaml
    yaml_str_case1 = """
    foo:
        collections:
            - foo.bar
    """
    yaml_str_case2= """
    foo:
        collections: []
    """
    yaml_str_case3 = """
    foo:
        collections:
            - foo.bar
            - foo.bar
    """
    yaml_str_case4 = """
    foo:
        collections:
            - foo.bar
            - foo.baz
    """
    yaml_str_case5 = """
    foo:
        collections:
            - foo.bar
    """

    data_structure1 = yaml.safe_load(yaml_str_case1)
    data_structure2 = yaml.safe_load(yaml_str_case2)


# Generated at 2022-06-23 06:06:17.784258
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(CollectionSearch._collections, FieldAttribute)
    assert isinstance(cs._collections, FieldAttribute)



# Generated at 2022-06-23 06:06:19.610752
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections('collections', 'test_collection')

# Generated at 2022-06-23 06:06:21.848511
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._set_attributes_from_yaml('', {}, [])
    cs.post_validate(temp_vars={}, all_vars={})

# Generated at 2022-06-23 06:06:23.210022
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch() 
    c.collections

# Generated at 2022-06-23 06:06:24.717237
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Fails
    x = CollectionSearch()
    x._collections = 1

# Generated at 2022-06-23 06:06:29.607618
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections.__class__.__name__ == 'CollectionSearch'

# Generated at 2022-06-23 06:06:37.344300
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.become import Become
    from ansible.playbook.task.include.static import StaticInclude
    from ansible.playbook.task.include.role import RoleInclude
    from ansible.playbook.task.include.tasks import TasksInclude

    collection = None
    base = Become()
    static_include = StaticInclude(collection=collection, base=base)
    role_include = RoleInclude(collection=collection, base=base)
    tasks_include = TasksInclude(collection=collection, base=base)

    assert collection is None
    assert base is not None
    assert static_include is not None
    assert role_include is not None
    assert tasks_include is not None

    # test defaults
    assert collection == AnsibleCollection

# Generated at 2022-06-23 06:06:47.384746
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import collection_loader
    from ansible.utils.collection_loader import AnsibleCollectionRequirement
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.collection_loader import AnsibleMixinVars
    import os
    import pytest
    collections_path = os.path.join(os.path.dirname(__file__), "test_collections")
    collection_loader._set_collection_paths(collections_path)
    test_

# Generated at 2022-06-23 06:06:52.852932
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    # collection_list = None
    list = obj._collections
    assert list == ['ansible_collections.barbican.barbican_k8s', 'ansible_collections.community.kubernetes']
    # collection_list = []
    list = obj._collections([])
    assert list == ['ansible_collections.barbican.barbican_k8s', 'ansible_collections.community.kubernetes']
    # collection_list = ['ansible_collections.load_collections.collection1']
    list = obj._collections(['ansible_collections.load_collections.collection1'])

# Generated at 2022-06-23 06:07:00.797181
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create object with no parameters
    object = CollectionSearch()

    # Check if object was created properly
    assert object
    assert isinstance(object._collections, FieldAttribute)
    assert isinstance(object.post_validate_attrs, dict)
    assert isinstance(object.always_post_validate_attrs, dict)
    assert not isinstance(object._collections.static, bool)
    assert isinstance(object.post_validate_attrs['collections'], FieldAttribute)
    assert isinstance(object.always_post_validate_attrs['collections'], FieldAttribute)

# Generated at 2022-06-23 06:07:03.457806
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    new_collection_search = CollectionSearch()
    assert new_collection_search._collections == ['ansible.builtin,ansible.legacy']

# Generated at 2022-06-23 06:07:08.016591
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch(collections=['asd.collection', 'def.collection'])
    assert cs.collections == ['asd.collection', 'def.collection']
    cs = CollectionSearch()
    assert cs.collections == ['asd.collection', 'def.collection']

# Generated at 2022-06-23 06:07:15.354470
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

    assert [] == obj._load_collections('collections', [])
    assert None == obj._load_collections('collections', None)

    # we should always have something in the collection list
    assert ['ansible.legacy'] == obj._load_collections('collections', [])

    # the default collection should always be in the list.
    assert ['ansible_collections.default', 'ansible.legacy'] == obj._load_collections('collections', ['ansible_collections.default'])

# Generated at 2022-06-23 06:07:23.874835
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    roles_path = './myroles'
    collection_list = ['ansible.posix']

    collection_search = CollectionSearch(roles_path=roles_path, collections=collection_list)

    if type(collection_search) is not CollectionSearch:
        raise AssertionError("Type of collection_search is not CollectionSearch")

    if collection_search.get_collections() != collection_list:
        raise AssertionError("Collection list is not equivalent to specified collection list")

# Generated at 2022-06-23 06:07:32.054358
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()

    # testing FieldAttribute for 'collections'
    assert (c.collections is None)
    assert (c.get_value('collections') == ['ansible.builtin'])

    # testing load_collections
    assert (c._load_collections('collections', None) == None)
    assert (c._load_collections('collections', []) == None)
    assert (c._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin'])

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:07:41.505052
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test Case 1
    from ansible.playbook.role_include import IncludeRole
    test1 = IncludeRole()
    assert test1._ensure_default_collection(['tower.ansible.com', 'ansible.builtin']), \
        "The _ensure_default_collection function is not working"

    # Test Case 2
    from ansible.playbook.task_include import IncludeTask
    test2 = IncludeTask()
    assert test2._ensure_default_collection(collection_list=['tower.ansible.com', 'ansible.builtin']), \
        "The _ensure_default_collection function is not working"

    # Test Case 3

# Generated at 2022-06-23 06:07:44.197555
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None
    assert cs.collections is not None
    assert cs.collections == ['ansible.legacy']

# Generated at 2022-06-23 06:07:54.260378
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    # Test the constructor of the class CollectionSearch
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection(['ansible.builtin'])

    # Test the method of _load_collections
    block = Block()
    block._parent = Play()
    block._parent._loader = None
    block._parent._collection = None
    block._role = RoleRequirement()
    block._role.role = RoleDefinition()
   

# Generated at 2022-06-23 06:07:55.837484
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:59.223241
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    task = CollectionSearch()
    assert task._collections == _ensure_default_collection()
    assert task._collections == ['ansible_collections.test_collection']


# Generated at 2022-06-23 06:08:07.389506
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    Base._collections = _ensure_default_collection()
    cs = CollectionSearch()
    assert cs._load_collections('collections', ['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']
    assert cs._load_collections('collections', []) is None
    cs._collections = ['t.ansible_collections.my_org.my_ns.my_coll']
    assert cs._load_collections('collections', []) == ['t.ansible_collections.my_org.my_ns.my_coll']

# Generated at 2022-06-23 06:08:09.949785
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj.collections, list)
    assert isinstance(obj.collections, FieldAttribute)
    assert obj.collections[0].startswith("ansible.collection:")

# Generated at 2022-06-23 06:08:11.564344
# Unit test for constructor of class CollectionSearch

# Generated at 2022-06-23 06:08:23.005893
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import json
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import is_template, Environment
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.display import Display
    # Get collections
    display = Display()
    # This will be None when used as the default
    collection_list = []
    default_collection = 'ansible.builtin'
    # FIXME: exclude role tasks?
    if default_collection and default_collection not in collection_list:
        collection_list.insert(0, default_collection)
    if collection_list and 'ansible.builtin' not in collection_list and 'ansible.legacy' not in collection_list:
        collection_list.append('ansible.legacy')


# Generated at 2022-06-23 06:08:24.581809
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TCollectionSearch(CollectionSearch):
        pass
    assert TCollectionSearch().collections == ['ansible.builtin']

# Generated at 2022-06-23 06:08:26.151753
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()
    assert isinstance(coll._collections, FieldAttribute)

# Generated at 2022-06-23 06:08:28.309994
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj != None
    assert type(test_obj).__name__ == 'CollectionSearch'

# Generated at 2022-06-23 06:08:30.663206
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch._collections, FieldAttribute)
    assert CollectionSearch._collections.listof == string_types
    assert CollectionSearch._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:08:34.310887
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c_search = CollectionSearch()
    assert c_search.collections is not None

# Generated at 2022-06-23 06:08:38.094359
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    attribute = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)
    assert CollectionSearch._collections == attribute

# Generated at 2022-06-23 06:08:48.278500
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    import os
    import tempfile
    # First test good case
    data = {}
    data["hosts"] = "localhost"
    data["tasks"] = []
    data["collections"] = ["ansible_collections.test_collection.test_ns"]
    pb = Playbook.load(data, loader=None)
    assert len(pb.plays) == 1
    play = pb.plays[0]
    assert isinstance(play, Play)
    assert len(play._blocks) == 0
    assert len(play._tasks) == 0
    assert play.task_include is None
    assert len(play.handlers) == 0

    # Second test when None


# Generated at 2022-06-23 06:08:55.498906
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import copy
    import sys

    collection_search = CollectionSearch()
    # get object's copy of dict of class fields
    fields_copy = copy.deepcopy(collection_search.fields)

    # TODO: use different mechanisms to determine python version
    if sys.version_info >= (3, 0):
        assert isinstance(fields_copy['collections']['loader'].listof, type)
    else:
        assert isinstance(fields_copy['collections']['loader'].listof, types.ClassType)

# Generated at 2022-06-23 06:08:58.189901
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch({"collections": ["ansible_namespace.col"]})
    assert isinstance(search, CollectionSearch)
    assert isinstance(search._collections, list)

# Generated at 2022-06-23 06:09:00.113892
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections is not None

# Generated at 2022-06-23 06:09:02.695202
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:11.952910
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an object instance of class CollectionSearch
    from ansible.playbook.role.definition import RoleDefinition
    class CollectionSearchTest(CollectionSearch, RoleDefinition):
        pass

    # Create empty instance of the above class
    collection_search = CollectionSearchTest()

    # Test that the collections field attribute has the expected value
    for field in collection_search.__class__.FIELDS:
        if field.name == '_collections':
            assert field.static is True and field.default == '_ensure_default_collection' and \
                   field.listof==string_types and field.isa=='list'

# Generated at 2022-06-23 06:09:19.419420
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    collections = collection._load_collections(None, None)
    # It will return none for current AnsibleCollectionConfig.default_collection
    assert collections is None

    collections = collection._load_collections(None, AnsibleCollectionConfig.default_collection)
    # If AnsibleCollectionConfig.default_collection exists, it will return a list
    assert isinstance(collections, list)

    collection2 = CollectionSearch()
    collections2 = collection2._load_collections(None, [])
    # It will return a list
    assert isinstance(collections2, list)

# Generated at 2022-06-23 06:09:23.727409
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    col.collections = ['collection_1', 'collection_2']
    assert col.collections == ['collection_1', 'collection_2']
    col.collections = None
    assert col.collections == ['ansible_collections.community.general']

# Generated at 2022-06-23 06:09:28.770160
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.playbook.task_include as task_include
    print("\n=======================\nUnit test for class CollectionSearch")
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']
    # cs._load_collections()
    # assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:09:32.986797
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    collections = c._load_collections('collections', None)
    assert collections is not None
    assert len(collections) == 1
    assert collections[0] == 'ansible.builtin'

# Generated at 2022-06-23 06:09:34.202345
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)

# Generated at 2022-06-23 06:09:34.965856
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

# Generated at 2022-06-23 06:09:45.157061
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) == _ensure_default_collection()

    assert cs._load_collections(None, []) == _ensure_default_collection(collection_list=[])
    assert cs._load_collections(None, ['ansible.builtin']) == _ensure_default_collection(collection_list=['ansible.builtin'])
    assert cs._load_collections(None, ['collections.yaml']) == _ensure_default_collection(collection_list=['collections.yaml'])
    assert cs._load_collections(None, ['collections.yaml', 'ansible.builtin']) == _ensure_default_collection(collection_list=['collections.yaml', 'ansible.builtin'])

# Generated at 2022-06-23 06:09:58.424347
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_object = CollectionSearch()
    #_collections is a property set by decorator FieldAttribute
    #first parameter is the name of the attribute used to retrieve it
    coll_val = getattr(coll_object, '_collections')
    assert(isinstance(coll_val, FieldAttribute))
    assert(coll_val.isa == 'list')
    assert(coll_val.listof == string_types)
    assert(coll_val.priority == 100)
    assert(coll_val.default == _ensure_default_collection)
    assert(coll_val.always_post_validate is True)
    assert(coll_val.static is True)
    assert(coll_val.name == '_collections')

# Generated at 2022-06-23 06:10:01.450371
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    block = Block()
    play_context = PlayContext()
    test_instance = CollectionSearch(play_context)
    assert test_instance.play_context == play_context

# Generated at 2022-06-23 06:10:03.037805
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:10:05.612189
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None


if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:10:08.023039
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _obj = CollectionSearch()
    _obj.post_validate()
    return



# Generated at 2022-06-23 06:10:12.784257
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()

    assert col._collections == ['ansible.builtin', 'ansible.legacy']
    assert col._load_collections(col._collections, ['namespace.collection']) == ['namespace.collection', 'ansible.builtin', 'ansible.legacy']


if __name__ == "__main__":
    pytest.main([__file__, ])

# Generated at 2022-06-23 06:10:24.090375
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']
    assert CollectionSearch()._load_collections(None, []) == ['ansible.legacy']
    assert CollectionSearch()._load_collections(None, [None]) == ['ansible.legacy']
    assert CollectionSearch()._load_collections(None, None) == ['ansible.legacy']
    assert CollectionSearch()._load_collections(None, ['namir.test1']) == ['namir.test1', 'ansible.legacy']
    assert CollectionSearch()._load_collections(None, ['namir.test1', 'ansible.builtin']) == ['namir.test1', 'ansible.builtin']

# Generated at 2022-06-23 06:10:27.520474
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition

    role_def = RoleDefinition.load('roles/test', None, False)
    assert role_def.get_vars() == {'collections': 'ansible_collections.name.collection'}

# Generated at 2022-06-23 06:10:29.304466
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play import Play
    a = Play()
    # a.load()

# Generated at 2022-06-23 06:10:34.281889
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ds = {'collections': ['collection_name']}
    cs._collections = None
    assert cs._load_collections(None, ds) == ['collection_name']

# Generated at 2022-06-23 06:10:35.149170
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print(CollectionSearch)

# Generated at 2022-06-23 06:10:37.251797
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    print(c._collections)
    c.post_validate({})

# test_CollectionSearch()


# Generated at 2022-06-23 06:10:39.970607
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()

    # test for the constructor property '_collections'
    assert isinstance(test._collections, FieldAttribute)

# Generated at 2022-06-23 06:10:45.319522
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()

    # Given _collections is empty, it should return a default collection (if
    # present)
    assert cs.collections == _ensure_default_collection(collection_list=[])

    # Given _collections is a collection name, it should return the name in a
    # list
    assert cs.collections == _ensure_default_collection(collection_list=['namespace.collection'])

# Generated at 2022-06-23 06:10:48.997007
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearchTest(CollectionSearch):
        __slots__ = ('collections',)
        def __init__(self):
            self.collections = "test"
    a = CollectionSearchTest()
    print(a.collections)

# Generated at 2022-06-23 06:10:54.489405
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    from ansible.errors import AnsibleParserError
    
    # Test constructor
    for collection_list in [[]]:
       with pytest.raises(AnsibleParserError) as error:
           CollectionSearch()
       assert "invalid value for 'collections': defaulting to 'ansible_collections.ansible.builtin'" in str(error)
       assert "but the default collection can not be resolved" in str(error)

# Generated at 2022-06-23 06:10:57.085464
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._load_collections([]) == _ensure_default_collection([])

# Generated at 2022-06-23 06:10:59.359480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:01.525817
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:02.625518
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c is not None

# Generated at 2022-06-23 06:11:04.273921
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search

# Generated at 2022-06-23 06:11:13.138258
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test1:
    # collections:
#     - test_collection
    check_collections = _ensure_default_collection(["test_collection"])
    assert check_collections == ['test_collection']

    # Test2:
    # collections:
#     - ansible.builtin
    check_collections = _ensure_default_collection(["ansible.builtin"])
    assert check_collections == ['ansible.builtin']

    # Test3:
    # collections:
#     - ansible.builtin
    check_collections = _ensure_default_collection()
    assert check_collections == ['ansible.builtin']

# Generated at 2022-06-23 06:11:15.178973
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = {"collections":['test_collection']}
    f = CollectionSearch()
    assert f._load_collections(None, d)

# Generated at 2022-06-23 06:11:17.815436
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs_instance = CollectionSearch()  # creaing instance of class CollectionSearch
    assert cs_instance is not None

# Generated at 2022-06-23 06:11:18.907682
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()



# Generated at 2022-06-23 06:11:20.534160
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:27.931101
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj._load_collections(obj._collections, None)
    assert(obj._collections == _ensure_default_collection())
    obj._load_collections(obj._collections, "ansible_collections.community.windows, ansible_collections.sensu.sensu_go")
    assert(obj._collections == ["ansible_collections.sensu.sensu_go", 
                                "ansible_collections.community.windows", 
                                "ansible.builtin", "ansible.legacy"])

# Generated at 2022-06-23 06:11:30.183569
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # default constructor returns default value for _collections
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:32.029478
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    print(collection.collections)

test_CollectionSearch()

# Generated at 2022-06-23 06:11:41.214826
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    import os

    cwd = os.getcwd()
    role = RoleDefinition()
    role.name = 'role'
    role.collections = ['collections']

    role._get_collections()

    role.name = u'role'
    role.collections = ['collections']

    role._get_collections()

    pub_path = os.path.splitext(os.path.dirname(__file__))[0] + '/unit_tests/pub_roles'
    os.chdir(pub_path)
    role.name = 'role'
    role.collections = ['collections']

    role._get_collections()

    role.name = u'role'
    role.collections = ['collections']

    role._

# Generated at 2022-06-23 06:11:44.092470
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_object = CollectionSearch()
    assert  collection_search_object._collections == ['ansible_collections.ansible.builtin', 'ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-23 06:11:47.231116
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    objct = CollectionSearch()
    print(objct.collections)
    # assert objct.collections == []

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:11:57.598081
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    env = Environment()
    test = CollectionSearch(ds={"collections": ["ansible_collections.collection_namespace.collection_name"]}, env=env)
    assert None == test._load_collections("collections", {"collections": []})
    assert ["ansible_collections.collection_namespace.collection_name"] == test._load_collections("collections", {"collections": ["ansible_collections.collection_namespace.collection_name"]})
    assert ["ansible_collections.ansible.builtin"] == test._load_collections("collections", {"collections": ["ansible_collections.ansible.builtin"]})

# Generated at 2022-06-23 06:11:58.795934
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    print(search)

# Generated at 2022-06-23 06:12:00.944265
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()
    assert collection_search._load_collections(None, None) == None

# Generated at 2022-06-23 06:12:01.645684
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with pytest.raises(ValueError):
        # Missing collections argument
        CollectionSearch()

# Generated at 2022-06-23 06:12:06.008505
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Check that the _load_collections method exists
    assert hasattr(cs, '_load_collections')
    # Check the type of the _collections property
    assert cs._collections.__class__.__name__ == 'FieldAttribute'

# Generated at 2022-06-23 06:12:07.523768
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs._collections, FieldAttribute)

# Generated at 2022-06-23 06:12:09.209042
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    x = CollectionSearch()
    assert x._collections == ['ansible_collections.ansible.builtin', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:12:12.171379
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search)
    print(collection_search._collections)
    print(collection_search._load_collections)


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:12:14.631217
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert _ensure_default_collection() == search._load_collections(None, None)

# Generated at 2022-06-23 06:12:16.272145
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    t_cs = CollectionSearch()
    assert isinstance(t_cs, CollectionSearch)

# Generated at 2022-06-23 06:12:25.324895
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.get_validated_value('collections', cs._collections, None, None) is None
    assert cs.get_validated_value('collections', cs._collections, ['name'], None) == ['name', 'ansible.legacy']
    assert cs.get_validated_value('collections', cs._collections, None, None) is None
    assert cs.get_validated_value('collections', cs._collections, ['name', 'ansible.builtin'], None) == ['name', 'ansible.builtin']

# Generated at 2022-06-23 06:12:34.165992
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections is _ensure_default_collection

    # test default value
    ds = dict()
    attr = None
    result = search._load_collections(attr, ds)
    assert result is None

    # test with a single collection name
    ds = dict(collections=['test.test_collection'])
    attr = None
    result = search._load_collections(attr, ds)
    assert len(result) == 2
    if result is not None:
        assert result[0] == 'test.test_collection'
        assert result[1] == _ensure_default_collection()[0]

    # test with mutilple collection names
    ds = dict(collections=['test.test_collection1', 'test.test_collection2'])

# Generated at 2022-06-23 06:12:37.599795
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    clist = CollectionSearch()
    clist._load_collections("",[])
    #print(clist.collections)


if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:12:38.181080
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs

# Generated at 2022-06-23 06:12:42.227386
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collections = collection_search._load_collections(None, [])  # FIXME: 'collections' is None
    assert collections
    assert collections[0] == 'ansible_collections.mazerj.ansible_collections_ns1'

# Generated at 2022-06-23 06:12:43.221539
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-23 06:12:45.609861
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # no collection_list is passed in constructor
    assert not CollectionSearch._collections._default_value
    # Enable default collection
    assert CollectionSearch._collections._default_value(None) == ['ansible.legacy']

# Generated at 2022-06-23 06:12:48.147998
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)



# Generated at 2022-06-23 06:12:49.889018
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  search = CollectionSearch()
  assert isinstance(search, CollectionSearch)



# Generated at 2022-06-23 06:12:52.931058
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    fld = CollectionSearch._collections
    assert fld.default == _ensure_default_collection


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:12:53.931693
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj

# Generated at 2022-06-23 06:12:57.431106
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin','ansible.legacy']
    c.collections = ['cl1','cl2','cl3']
    assert c.collections == ['cl1','cl2','cl3']

# Generated at 2022-06-23 06:13:00.549995
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is _ensure_default_collection


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:13:06.981841
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """This class is only a place holder for the 'collections' attribute."""

    # Create an object for testing
    test = CollectionSearch()

    # test isa
    assert isinstance(test, CollectionSearch)

    # test collections
    assert test.collections is not None

    # collections is always a list
    assert isinstance(test.collections, list)

    # collections should only contain strings
    for collection in test.collections:
        assert isinstance(collection, string_types)

# Generated at 2022-06-23 06:13:16.003803
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Instantiate CollectionSearch
    collection_search = CollectionSearch()

    # Assert that fields are set as expected
    assert '_collections' in collection_search._fields
    assert isinstance(collection_search._fields['_collections'], FieldAttribute)
    assert 'isa' in collection_search._fields['_collections']._validators
    assert collection_search._fields['_collections']._validators['isa'] == 'list'
    assert 'listof' in collection_search._fields['_collections']._validators
    assert collection_search._fields['_collections']._validators['listof'] == string_types
    assert collection_search._fields['_collections'].priority == 100
    assert 'default' in collection_search._fields['_collections']._validators