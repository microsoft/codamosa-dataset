

# Generated at 2022-06-23 06:03:17.345706
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.playbook.role
    cs = CollectionSearch()

    role = ansible.playbook.role.Role()
    role._load_collections('_collections', [])

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:03:26.323433
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        from ansible.module_utils.ansible_yaml.dict_utils import _get_common_dict
    except:
        assert True
        return

    coll_search = CollectionSearch()
    common_dict = _get_common_dict(coll_search)
    assert 'collections' in common_dict, "Assertion Error: 'collections' not in common_dict"
    assert common_dict['collections'] == _ensure_default_collection(), "Assertion Error: common_dict['collections'] == _ensure_default_collection()"

    test_collection = ['test_collection']

# Generated at 2022-06-23 06:03:33.195538
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections
    assert collections._collections
    assert collections.collections
    assert collections.collections == ['ansible.builtin']
    assert collections.get_validated_value('collections', collections._collections, 'ansible.builtin', None)
    assert collections.get_validated_value('collections', collections._collections, ['ansible.builtin'], None)
    assert collections.get_validated_value('collections', collections._collections, ['my.collection'], None)

# Generated at 2022-06-23 06:03:36.195785
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-23 06:03:37.813289
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
        obj = CollectionSearch()
        assert obj._collections._default == _ensure_default_collection

# Generated at 2022-06-23 06:03:46.822697
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()
    assert col_search.__dict__['_collections'] == _ensure_default_collection()
    assert col_search._collections.__dict__['_attributes'] == {}
    assert col_search.__dict__['_collections'].__dict__['_attributes'] == {}
    assert col_search._collections == _ensure_default_collection()
    assert col_search.collections == _ensure_default_collection()
    assert col_search._load_collections(col_search._collections, []) == []
    assert col_search._load_collections(col_search._collections, ['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-23 06:03:49.713960
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = {'collections': ['test.collection']}
    cs = CollectionSearch()
    collections = cs._load_collections('collections', ds)
    assert collections == ['test.collection', "ansible.builtin"]

# Generated at 2022-06-23 06:03:51.565103
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

    assert obj._collections == []

# Generated at 2022-06-23 06:03:54.065188
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()  # Expecting a list

# Generated at 2022-06-23 06:04:01.626208
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_search = CollectionSearch()
    assert coll_search._collections.name == 'collections'
    assert coll_search._collections.isa == 'list'
    assert coll_search._collections.listof == string_types
    assert coll_search._collections.priority == 100
    assert coll_search._collections.always_post_validate
    assert coll_search._collections.static
    assert coll_search._collections.default() is not None
    assert coll_search._load_collections(None, []) is not None

# Generated at 2022-06-23 06:04:06.391062
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = {
            "name": "test",
            "collections": "somemodule.somesubmodule"
        }
    testObject = CollectionSearch(ds, 'playbooks/name/action')
    assert testObject._collections == None

# Generated at 2022-06-23 06:04:14.815091
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def_collection = AnsibleCollectionConfig.default_collection
    collection = CollectionSearch()

    assert collection.collections == ['ansible.builtin']

    # The default collection should be present when the default_collection is set
    if def_collection is not None:
        AnsibleCollectionConfig.default_collection = "ansible.builtin"
        collection = CollectionSearch()
        assert collection.collections == ['ansible.builtin']

        AnsibleCollectionConfig.default_collection = def_collection

# Generated at 2022-06-23 06:04:20.193808
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()

    assert cs._collections == _ensure_default_collection()

    cs.set_loader('loader')
    cs._load_collections(None, None)
    assert cs._collections == _ensure_default_collection()

    cs = CollectionSearch()
    cs.set_loader(None)
    cs._load_collections(None, None)
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:23.263117
# Unit test for constructor of class CollectionSearch

# Generated at 2022-06-23 06:04:25.098494
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-23 06:04:28.694827
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    a.post_validate('collections', a._collections)
    _collections = a._load_collections('collections', {'collections': []})
    assert _collections is not None

# Generated at 2022-06-23 06:04:40.802249
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import _LoaderModuleCollectionSearchLoader
    from ansible.playbook.deprecated import Task
    from ansible.playbook.role import Task as RoleTask
    from ansible.playbook.role_include import Task as RoleIncludeTask
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import lookup_loader, filter_loader
    from ansible.plugins.test.test_filter.test_print import TestPrint
    import os

    # load the task
    t = Task.load('print')
    assert t.__class__ == RoleTask
    # print('t: %s' % t._attributes)

    # load the handler
    h = Handler.load('copy')
    assert h.__class__ == RoleTask
    # print('h: %s' % h._

# Generated at 2022-06-23 06:04:45.836868
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    collection.collections = ['ansible.builtin']
    assert collection.collections == "ansible.builtin"

# Generated at 2022-06-23 06:04:54.343827
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    mock_class = CollectionSearch()
    default_collection = AnsibleCollectionConfig.default_collection

    if default_collection:
        # Check if the default collection is inserted in the collection list.
        assert default_collection in mock_class._collections.default

        # Check if the default collection is inserted only once.
        assert mock_class._collections.default.count(default_collection) == 1

    # Check if ansible.builtin is inserted in the collection list.
    assert 'ansible.builtin' in mock_class._collections.default

    mock_class._collections.default.append('ansible.builtin')

    # Check if ansible.builtin is inserted only once.
    assert mock_class._collections.default.count('ansible.builtin') == 1

# Generated at 2022-06-23 06:04:56.323813
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is not None

# Generated at 2022-06-23 06:05:07.978062
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test case 1: collection_list is None
    test1 = CollectionSearch()
    test1._collections = None
    assert(test1._collections == _ensure_default_collection())
    assert(test1._collections == ['ansible.builtin', 'ansible.builtin_rpms', 'ansible.examples', 'ansible.legacy'])
    test1._collections = ['ansible.builtin']
    assert(test1._collections == ['ansible.builtin', 'ansible.builtin_rpms', 'ansible.examples', 'ansible.legacy'])
    assert(test1._load_collections(None, None) == None)
    assert(test1._load_collections(None, "") == None)

# Generated at 2022-06-23 06:05:17.013888
# Unit test for constructor of class CollectionSearch

# Generated at 2022-06-23 06:05:19.082845
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:05:25.930267
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs)
    print(cs.__dict__)
    ds = "ansible_collections.ansible.builtin"
    print(cs._load_collections(cs._collections, ds))
    cs = CollectionSearch(collections=ds)
    print(cs)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:05:30.993604
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #This should return an error
    try:
        cs = CollectionSearch([1,2,3])
    except Exception as e:
        assert 'is not a valid string' in str(e)

    #This should not return anything
    try:
        cs = CollectionSearch(['one'])
    except Exception as e:
        assert 'is not a valid string' in str(e)

# Generated at 2022-06-23 06:05:33.066428
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj._collections, FieldAttribute)



# Generated at 2022-06-23 06:05:35.653773
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    assert collectionsearch._collections is not None
    assert collectionsearch._load_collections is not None

# Generated at 2022-06-23 06:05:42.417275
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    t = CollectionSearch()

    with pytest.raises(TypeError):
        t.collections = 'abc'

    t.collections = []
    with pytest.raises(TypeError):
        t.collections = ['abc']

    with pytest.raises(TypeError):
        t.collections = ['abc', 1]

    with pytest.raises(TypeError):
        t.collections = ['a', 'b', 1]

    t.collections = ['a', 'b']
    t.collections = None
    t.collections = ['a', 'b']

# Generated at 2022-06-23 06:05:44.536507
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:05:46.465313
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == ['ansible.posix', 'ansible.builtin']

# Generated at 2022-06-23 06:05:57.542717
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    global display
    display = Display()

    list_values = ['/home/dev/ansible/collections']
    collection_search = CollectionSearch()
    collection_search._collections = list_values
    assert collection_search._collections == list_values

    list_values = ['/home/dev/ansible/collections', 'ansible.builtin']
    assert collection_search._collections == list_values

    list_values = ['/home/dev/ansible/collections', 'ansible.builtin', 'ansible.legacy']
    assert collection_search._collections == list_values

    list_values = ['']
    assert collection_search._collections == list_values

    list_values = ['/home/dev/ansible/collections']
    assert collection_search._collections == list_values

   

# Generated at 2022-06-23 06:06:01.505172
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    a._collections =['ansible.builtin', 'ansible.legacy']
    a._load_collections('collections', a._collections)
    assert a._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:06:04.375907
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = _ensure_default_collection()
    if result == []:
        assert "ansible.legacy" in result
    else:
        raise AssertionError ("_ensure_default_collection failed")

# Generated at 2022-06-23 06:06:13.309704
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_mixedin_class = type('Test', (CollectionSearch,), {})
    test_instance = test_mixedin_class()
    assert test_instance.collections is None
    assert test_instance.post_validate() is None
    assert test_instance.vars == {}

    test_instance.collections = []
    assert test_instance.collections == []
    assert test_instance.vars == {}

    test_instance.collections = ['ansible.builtin', 'ansible.legacy']
    assert test_instance.collections == ['ansible.builtin', 'ansible.legacy']
    assert test_instance.vars == {}

    test_instance.collections = ['ansible.builtin', 'ansible.legacy', 'foo.bar']

# Generated at 2022-06-23 06:06:23.342024
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestClass(CollectionSearch):
        def __init__(self):
            super(TestClass, self).__init__()
            self._initialize_data()

    test_obj = TestClass()
    print(test_obj)
    print("_collections:", test_obj.get_value('_collections'))
    print("collections:", test_obj.get_value('collections'))
    # assert test_obj.get_value('_collections') == ['ansible_collections.my_ns.my_coll']
    # assert test_obj.get_value('collections') == ['ansible_collections.my_ns.my_coll']

# Generated at 2022-06-23 06:06:24.464782
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert issubclass(CollectionSearch, object)

# Generated at 2022-06-23 06:06:26.371073
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch(collections=['collections'])
    assert collection_search.collections == ['collections']

# Generated at 2022-06-23 06:06:31.469689
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch(collections=["ansible.builtin"])
    assert collection_search.collections == ["ansible.builtin"]

    # Test that if the collections value is None, AnsibleCollectionConfig.default_collection
    # is added as the first item in the collections list.
    assert collection_search._load_collections(None, None) == ["ansible.builtin"]
    collection_search = CollectionSearch(collections=None)
    assert collection_search.collections == ["ansible.builtin"]
    assert collection_search._load_collections(None, None) == ["ansible.builtin"]

    # Test that if the collections value is a list with no items,
    # the _load_collections method will set the value to None.
    assert collection_search._load_collections([], None) is None

# Generated at 2022-06-23 06:06:35.363525
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._load_collections('collections', ['test.collection']) == ['test.collection', 'ansible.builtin']

# Generated at 2022-06-23 06:06:38.674606
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    '''
    This is a constructor Test Case of collection search
    '''
    collections = ["Test collection"]
    search = CollectionSearch(collections=collections)
    assert search._collections == collections

# Generated at 2022-06-23 06:06:48.413411
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(object):
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                      always_post_validate=True, static=True)

        def __init__(self):
            self._collections = ['ansible.builtin', 'ansible.legacy']
            self._load_collections("collections", {'collections': ['ansible.builtin', 'ansible.legacy']})
            self._collections = ['collection.microsoft.azcollection']
            self._load_collections("collections", {'collections': ['collection.microsoft.azcollection']})
            self._collections = ['collection.microsoft.azcollection', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:06:51.172150
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections_search = CollectionSearch()
    assert collections_search._collections.default == _ensure_default_collection()


# Generated at 2022-06-23 06:06:54.445240
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:06:59.905576
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections() == ['ansible.builtin', 'ansible.legacy']
    assert type(cs._collections()) is list
    assert cs.get_validated_value('collections', cs._collections, ['ansible_test.test_action'], None) == ['ansible_test.test_action', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:07:01.481089
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default==_ensure_default_collection()

# Generated at 2022-06-23 06:07:04.409242
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == collection_search._collections

# Generated at 2022-06-23 06:07:07.009144
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass
    assert TestCollectionSearch._collections.default == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:07:08.421354
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a is not None


# Generated at 2022-06-23 06:07:10.425078
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_class = CollectionSearch()
    assert test_class.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:10.880557
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = Collectio

# Generated at 2022-06-23 06:07:12.630456
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:07:14.714465
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:15.525117
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:07:20.610534
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj

# Tests the following function(s)
# * def _ensure_default_collection(collection_list=None)

# Generated at 2022-06-23 06:07:22.683907
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)
    assert obj != obj._collections


# Generated at 2022-06-23 06:07:33.483561
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import IncludeRole
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils import context_objects as co
    from ansible.vars.clean import strip_internal_keys
    co.GlobalCLIArgs.command = 'include_role'
    co.GlobalCLIArgs.add_yaml_key = False

    test_task = IncludeRole()
    test_task._role_name = 'an_include_role'
    test_task.vars = {'a': 'included_role_a'}
    test_task.defaults = {'b': 'included_role_b'}
    test_task.run_once = True
    test_task.meta = {'meta_a': 'included_role_meta_a'}

# Generated at 2022-06-23 06:07:35.107588
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection([])

# Generated at 2022-06-23 06:07:38.948826
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.role import Role
    from ansible.playbook.task.task import Task

    role = Role()
    print('role object: ', role.__dict__)
    task = Task()
    print('task object: ', task.__dict__)

# Generated at 2022-06-23 06:07:40.170141
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Check that the constructor of class CollectionSearch is initialized without error
    assert CollectionSearch()

# Generated at 2022-06-23 06:07:47.156432
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from collections import namedtuple
    from ansible.playbook.attribute import FieldAttribute


# Generated at 2022-06-23 06:07:50.317295
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()

    assert collections._load_collections("collections",['ansible.builtin', 'ansible.legacy', 'project.a']) ==  ['project.a', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:07:53.241764
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None
    assert cs._collections is not None

# Generated at 2022-06-23 06:07:54.018023
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

# Generated at 2022-06-23 06:07:55.316442
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-23 06:07:57.954229
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert  CollectionSearch._collections.default() == _ensure_default_collection()

# Generated at 2022-06-23 06:07:59.974456
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['empty']
    assert cs._collections == ['empty']

# Generated at 2022-06-23 06:08:03.561119
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cls = 'CollectionSearch'
    obj = CollectionSearch()

    assert hasattr(obj, '_load_collections')
    assert hasattr(obj, 'get_validated_value')

    assert obj._collections is not None
    assert isinstance(obj._collections, FieldAttribute)
    assert isinstance(obj._collections.default, list)

# Generated at 2022-06-23 06:08:06.061244
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    y = CollectionSearch()
    y.get_validated_value('collections', y._collections, [], None)
    _ensure_default_collection(collection_list=[])

# Generated at 2022-06-23 06:08:09.251605
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == _ensure_default_collection()
    # Should not be able to assign to collections
    try:
        c.collections == []
    except AttributeError:
        pass


# Generated at 2022-06-23 06:08:13.882306
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def usage():
        class InvalidCollectionSearch(CollectionSearch):
            pass

    test_collection_search = CollectionSearch()
    if not test_collection_search:
        usage()
    else:
        assert True

# Generated at 2022-06-23 06:08:14.476530
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    return obj

# Generated at 2022-06-23 06:08:15.942046
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-23 06:08:19.782566
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    # simple test
    ds = collectionSearch._load_collections(None, ds=['col1', 'col2'])
    # default test
    ds = collectionSearch._load_collections(None, ds=None)



# Generated at 2022-06-23 06:08:22.601817
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert hasattr(obj, '_collections')
    assert hasattr(obj, '_load_collections')

# Generated at 2022-06-23 06:08:26.070422
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == [AnsibleCollectionConfig.default_collection]
    assert obj._load_collections(None, None) is None
    assert obj._load_collections(None, []) is None

# Generated at 2022-06-23 06:08:28.300123
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible_collections.ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:08:34.789018
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.playbook.role_include as role_include
    obj = role_include.RoleInclude()
    assert obj._load_collections(attr='collections', ds=None) == None
    assert obj._load_collections(attr='collections', ds=['collection1', 'collection2']) == ['collection1', 'collection2']

# Generated at 2022-06-23 06:08:38.033579
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch(collections=['ansible_col_test'])
    assert c.collections == ['ansible_col_test']


# Unit test of _load_collections() in class CollectionSearch

# Generated at 2022-06-23 06:08:40.627494
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    bar = CollectionSearch()
    assert bar._load_collections == None
    assert bar._collections == None

# Generated at 2022-06-23 06:08:44.119165
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_search_instance = CollectionSearch()
    assert test_collection_search_instance._collections == _ensure_default_collection()
    assert test_collection_search_instance._collections == ['ansible_collections.example_collection.subcollection']


# Generated at 2022-06-23 06:08:49.161981
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == _ensure_default_collection()
    assert test._load_collections("attr", "ds") == _ensure_default_collection()
    assert test._load_collections("attr", "") == None



# Generated at 2022-06-23 06:08:50.169358
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()



# Generated at 2022-06-23 06:08:52.898286
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c_search = CollectionSearch()
    assert c_search.collections == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-23 06:08:54.861432
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #test that the constructor passes
    test_collection_search_instance = CollectionSearch()

# Generated at 2022-06-23 06:08:56.598189
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections._collections == ['ansible_galaxy.collection']

# Generated at 2022-06-23 06:08:58.779424
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_search = CollectionSearch()
    print(test_collection_search.collections)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:08:59.355435
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()

# Generated at 2022-06-23 06:09:01.378413
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search._collections)

# Generated at 2022-06-23 06:09:07.812529
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    myobj = CollectionSearch()
    myobj.__dict__ = dict(display=Display())
    myobj.collections = ['ansible.builtin', 'ansible.legacy']
    #assert myobj._collections == ['ansible.builtin', 'ansible.legacy'], "Setting 'collections' did not work!"
    assert myobj._load_collections(None, myobj.collections) == ['ansible.builtin', 'ansible.legacy'], \
        "Setting 'collections' did not work!"

# Generated at 2022-06-23 06:09:18.450759
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest
    import ansible.module_utils.collection_loader

    class TestCollectionSearch(CollectionSearch):
        def __init__(self):
            self._collections = None

        def get_validated_value(self, attr, field, ds, value):
            return ds

    attr_1 = 'ansible.builtin'
    attr_2 = 'ansible.builtin'
    attr_3 = 'collection_name'
    class_instance_1 = TestCollectionSearch()
    class_instance_2 = TestCollectionSearch()
    class_instance_3 = TestCollectionSearch()

    class_instance_1.collections = attr_1
    class_instance_2.collections = attr_2
    class_instance_3.collections = attr_3


# Generated at 2022-06-23 06:09:20.867122
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass
    search = TestCollectionSearch()
    assert search.collections == 'ansible.builtin'

# Generated at 2022-06-23 06:09:22.696931
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.get_default(object()) == ['ansible.builtin']

# Generated at 2022-06-23 06:09:26.335944
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    ds = collection_search._load_collections('', 'ansible_collections.test_namespace.test_collection')
    assert(ds == ['ansible_collections.test_namespace.test_collection'])

# Generated at 2022-06-23 06:09:27.178751
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)

# Generated at 2022-06-23 06:09:28.281765
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_test = CollectionSearch()
    assert search_test._collections is not None

# Generated at 2022-06-23 06:09:30.302175
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections is None

# Generated at 2022-06-23 06:09:32.071035
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ["ansible.builtin"]

# Generated at 2022-06-23 06:09:33.885180
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default() == _ensure_default_collection()



# Generated at 2022-06-23 06:09:36.387268
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_obj = CollectionSearch()
    assert collection_search_obj._collections == ['ansible.posix']

# Generated at 2022-06-23 06:09:37.498577
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections

# Generated at 2022-06-23 06:09:39.522493
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:09:40.073586
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-23 06:09:42.741551
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert isinstance(instance, CollectionSearch)


# Generated at 2022-06-23 06:09:44.957917
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """ Constructor of class CollectionSearch """
    print(CollectionSearch()._load_collections(None, []))

test_CollectionSearch()

# Generated at 2022-06-23 06:09:49.754518
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()  # mocking class object
    obj.collections = ['geerlingguy.aws', '/tmp/collection']
    obj.post_validate()
    obj.collections[0] = 'TEST'
    obj.__class__.collections.validate('TEST', None)

# Generated at 2022-06-23 06:09:53.822425
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Test for default constructor
    testObj = CollectionSearch()
    testObj._load_collections(None, None)

    #Test for with collections constructor
    testObj2 = CollectionSearch()
    testObj2._load_collections(None, ["testCollections"])

# Generated at 2022-06-23 06:09:56.383286
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections("collections", "some-collection")[0] == "some-collection"

# Generated at 2022-06-23 06:09:58.302523
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._load_collections == 'ansible.builtin'


# Generated at 2022-06-23 06:10:00.347789
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search.collections)

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:10:01.440508
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   obj = CollectionSearch()
   assert [obj]

# Generated at 2022-06-23 06:10:03.033550
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass


# Generated at 2022-06-23 06:10:06.661603
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.value == ['ansible_collections.ansible.builtin', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:10:08.849267
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search._load_collections(None, [])

# Generated at 2022-06-23 06:10:10.211321
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:10:13.204954
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(isinstance(CollectionSearch._ensure_default_collection(), list))
    
# Unit tests for function _ensure_default_collection(collection_list)

# Generated at 2022-06-23 06:10:14.982895
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search

# Generated at 2022-06-23 06:10:22.934461
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj.collections = ['test', 'test2']
    expected_result = "test2"

    # Constructor with only one parameter
    obj2 = CollectionSearch(collections = ['test3', 'test4'])
    expected_result2 = "test4"

    assert obj.collections[0] == 'test'
    assert obj.collections[1] == expected_result
    assert obj2.collections[0] == 'test3'
    assert obj2.collections[1] == expected_result2

# Generated at 2022-06-23 06:10:24.212973
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search

# Generated at 2022-06-23 06:10:26.233762
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._collections = "ansible.posix"
    cs._load_collections(None, None)

# Generated at 2022-06-23 06:10:27.957876
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections is None


# Generated at 2022-06-23 06:10:30.853140
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()

    # set a task to be loading
    cs._task = cs

    # check the default collections
    assert _ensure_default_collection() == cs._collections

# Generated at 2022-06-23 06:10:41.278108
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import is_template, Environment
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # create a collectionSearch
    CollectionSearch = CollectionSearch()

    # create a FieldAttribute
    FieldAttribute = FieldAttribute()

    # create an Environment
    Environment = Environment()

    # create an AnsibleCollectionConfig
    AnsibleCollectionConfig = AnsibleCollectionConfig()

    # ensure that _ensure_default_collection is callable
    assert callable(CollectionSearch._ensure_default_collection)

    # ensure that _load_collections is callable
    assert callable(CollectionSearch._load_collections)

# Generated at 2022-06-23 06:10:43.296350
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['x.x.x']


# Generated at 2022-06-23 06:10:45.207015
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class Obj(CollectionSearch):
        pass

    assert str(Obj) == 'ansible.playbook.collection_search.CollectionSearch'

# Generated at 2022-06-23 06:10:46.298220
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None


# Generated at 2022-06-23 06:10:49.100937
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    ds = {
        "collections": ["community"]
    }
    obj._collections = _ensure_default_collection(ds["collections"])

# Generated at 2022-06-23 06:10:49.879177
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections is not None

# Generated at 2022-06-23 06:10:53.001279
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert [cs._collections] == [_ensure_default_collection()]
    assert [cs._load_collections()] == [_ensure_default_collection()]

# Generated at 2022-06-23 06:10:55.662069
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert(cs._collections == _ensure_default_collection())

# Generated at 2022-06-23 06:10:58.981836
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import IncludeRole
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert isinstance(collection_search, IncludeRole)
    assert collection_search._collections == []

# Generated at 2022-06-23 06:11:04.851707
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()
    # This should return None as no values have been passed in
    assert cs._load_collections(None, None) is None

    # This should return a list of collections as values have been passed in
    assert cs._load_collections('foo', ['bar', 'baz']) == ['bar', 'baz']


# Generated at 2022-06-23 06:11:07.731832
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        search = CollectionSearch()
    except Exception as e:
        assert False, "Test for constructor of CollectionSearch failed: Exception: {}".format(e)



# Generated at 2022-06-23 06:11:10.081738
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is None
    assert obj.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:11.494362
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:18.555077
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Success:
    # dictionaries (which is right format for `validate_attributes`)
    data1 = {"collections": [
        "ansible_collections.community.general",
        "ansible_collections.tungstenfabric.tf_vnc_k8s_contrail_ansible"
    ]}
    # Success:
    # List of collection names (which is right format for `validate_attributes`)
    data2 = [
        "ansible_collections.community.general",
        "ansible_collections.tungstenfabric.tf_vnc_k8s_contrail_ansible"
    ]
    collection_search = CollectionSearch()
    assert [] == collection_search.post_validate(data=data1)
    assert [] == collection_search.post_validate

# Generated at 2022-06-23 06:11:19.701491
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()

# Generated at 2022-06-23 06:11:29.906440
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role import Role
    collection_search = CollectionSearch()
    # When nothing is provided, then static method `_ensure_default_collection` should be called and returned
    assert collection_search._load_collections(attr='collections', ds=None) == _ensure_default_collection()
    # When provided value is an empty list, then static method `_ensure_default_collection` should be called and returned
    assert collection_search._load_collections(attr='collections', ds=[]) == [AnsibleCollectionConfig.default_collection]
    # When provided value is not empty, then the provided value should be returned
    assert collection_search._load_collections(attr='collections', ds=[Role]) == [Role]
    # When provided value is not empty and there is no default collection name, then the

# Generated at 2022-06-23 06:11:32.184089
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections.default == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:11:39.667492
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.tests import base_unit_test
    def assert_display_warning(msg):
        assert msg == '"collections" is not templatable, but we found: {{ collection_name }}, it will not be templated and will be used "as is".'

    with base_unit_test._patch_runner_display_warning(assert_display_warning):
        cs = CollectionSearch(base_unit_test.FakeDS())
        assert cs.collections == ['ansible.builtin', 'ansible.legacy']
        assert cs.collections == ["{{ collection_name }}"]
        assert cs.collections == None

# Generated at 2022-06-23 06:11:40.909727
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:11:41.937199
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    path = CollectionSearch()
    assert path._collections.default is not None

# Generated at 2022-06-23 06:11:44.917836
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch

# Generated at 2022-06-23 06:11:46.971082
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == ['ansible.builtin']

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-23 06:11:49.964943
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    assert test_instance._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:12:01.142380
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    play_source = dict(
        name="Ansible Play14",
        hosts='localhost',
        gather_facts='no',
        roles=['role1', 'role2'],
    )

    # Test role with defined class value.
    p = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    assert isinstance(p._role_names, list)
    assert len(p._role_names) == 2
    assert 'role1' in p

# Generated at 2022-06-23 06:12:03.898311
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # test for __init__() for proper initialization
    assert (CollectionSearch._load_collections('_collections', None)) is None
    assert CollectionSearch._collections.default is not None

# test for __call__()

# Generated at 2022-06-23 06:12:04.464120
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-23 06:12:07.284325
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Test that the class CollectionSearch is able to be instantiated by its constructor
    """
    collection_search = CollectionSearch()

# Generated at 2022-06-23 06:12:09.975800
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    m = CollectionSearch()
    assert m._collections is not None
    assert m._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:12:13.941915
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-23 06:12:15.570528
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None

# Generated at 2022-06-23 06:12:19.211147
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    attr = 'collections'
    ds = None
    # These tests are just to get through the code coverage.
    collection_search._load_collections(attr, ds)
    _ensure_default_collection()

# Generated at 2022-06-23 06:12:25.461868
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # If a collection is not provided, it will return the default collection
    assert(CollectionSearch._ensure_default_collection() == [])
    assert(CollectionSearch._ensure_default_collection([]) == [])
    assert(CollectionSearch._ensure_default_collection(['namespace.collection']) == ['namespace.collection'])

# Generated at 2022-06-23 06:12:28.353755
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        _CollectionSearch = CollectionSearch()
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-23 06:12:30.949667
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = { 'collections': ["foo.bar", "bam.baz"]}
    c = CollectionSearch(ds,None)
    assert c.collections == ["foo.bar", "bam.baz"]

# Generated at 2022-06-23 06:12:36.756439
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    t1 = CollectionSearch()
    assert t1._collections is not None

    t2 = CollectionSearch({"collections": ["ansible.builtin", "ansible.legacy"]})
    assert t2._collections is not None

    t3 = CollectionSearch({"collections": []})
    assert t3._collections is not None

# Generated at 2022-06-23 06:12:40.167729
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    c = CollectionSearch()
    assert c._collections is _ensure_default_collection

    i = c._load_collections
    assert i(['test']) == ['test']

# Generated at 2022-06-23 06:12:42.709058
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert [('ansible.builtin', 'ansible.legacy')] == t._load_collections('collections', 'ansible.builtin')

# Generated at 2022-06-23 06:12:44.724929
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    ansible_collections = obj._collections

    for collection in ansible_collections:
        print(collection)


# Generated at 2022-06-23 06:12:50.949088
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #test case 1
    data = {}
    ds = {"collections": ["test"]}

    #test case 2
    data = {}
    ds = {}

    #test case 3
    data = {}
    ds = {"collections": []}

    #test case 4
    data = {}
    ds = {"collections": [""]}

# Generated at 2022-06-23 06:12:54.275066
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections() == CollectionSearch._collections.default()
    assert CollectionSearch._collections.default(_ensure_default_collection()) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:13:06.370806
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # CollectionSearch(collections=[]) is same as CollectionSearch()
    c = CollectionSearch(collections=[])
    assert c.collections is None
    c = CollectionSearch()
    # c.collections is ['ansible.builtin']
    assert c.collections == ['ansible.builtin']
    # c.collections is ['ansible.builtin', 'ansible.legacy']
    c = CollectionSearch(collections=['ansible.builtin', 'ansible.legacy'])
    assert c.collections == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-23 06:13:11.364723
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs_obj = CollectionSearch()
    assert cs_obj._collections.default == _ensure_default_collection
    assert cs_obj._collections.always_post_validate == True
    assert cs_obj._collections.static == True
    cs_obj.collections = ['test.collection']
    assert cs_obj.collections == ['test.collection']

# Generated at 2022-06-23 06:13:14.236784
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    collection_list = collection._load_collections('collections', None)
    assert (collection_list is not None)