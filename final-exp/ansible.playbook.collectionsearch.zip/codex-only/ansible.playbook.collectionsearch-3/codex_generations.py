

# Generated at 2022-06-23 06:03:10.338169
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search is not None
    assert isinstance(search, CollectionSearch)



# Generated at 2022-06-23 06:03:18.288325
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    print("\ntest_CollectionSearch(): " + "collections = " + str(collections))
    print("\ntest_CollectionSearch(): " + "type(collections) = " + str(type(collections)))
    print("\ntest_CollectionSearch(): " + "collections._collections = " + str(collections._collections))
    print("\ntest_CollectionSearch(): " + "type(collections._collections) = " + str(type(collections._collections)))
    print("\ntest_CollectionSearch(): " + "isinstance(collections._collections, list) = " + str(isinstance(collections._collections, list)))

# Generated at 2022-06-23 06:03:19.258901
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None

# Generated at 2022-06-23 06:03:22.125346
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    data = {'collections': ['ansible.builtin']}
    cs = CollectionSearch()
    cs.post_validate(data, None)
    assert cs.collections == ['ansible.builtin']


# Generated at 2022-06-23 06:03:27.902802
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection.collections == _ensure_default_collection()
    # TODO: add test to ensure that a constructor without a parameter will work
    #       (and validate a non-list "collection_list" parameter)
    # TODO: add test to ensure that a constructor with an empty list will work

# Generated at 2022-06-23 06:03:33.147376
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Success case
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']

    # failure case
    with pytest.raises(AttributeError) as excinfo:
        assert cs.collections == ['ansible.builtin', 'foo']
    assert "Field 'collections' expects a list value, received " in excinfo.exconly()


# Generated at 2022-06-23 06:03:34.503740
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)

# Generated at 2022-06-23 06:03:35.593411
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # should not raise an exception
    CollectionSearch()

# Generated at 2022-06-23 06:03:40.337717
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj._collections = ['collection1','collection2','collection3','collection4','collection5']
    result = obj._load_collections('_collections', obj._collections)
    expected_result = ['ansible.builtin', 'ansible.legacy', 'collection1', 'collection2', 'collection3', 'collection4', 'collection5']
    assert result == expected_result

# Generated at 2022-06-23 06:03:49.491842
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # _collections = ['ansible.builtin', 'ansible.legacy', 'ansible.collections.awesome']
    # collections = _collections = AnsibleCollectionConfig.default_collection

    collection = CollectionSearch()

    # test _ensure_default_collection()
    assert collection._ensure_default_collection() == ['ansible.builtin', 'ansible.legacy', 'ansible.collections.awesome']
    assert collection._ensure_default_collection(['ansible.collections.awesome']) == ['ansible.collections.awesome', 'ansible.builtin', 'ansible.legacy']

    assert collection._load_collections(None, ['ansible.collections.awesome']) == ['ansible.collections.awesome', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:03:51.415352
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    t._collections = ['my_collection']
    assert t._collections_loaded == ['my_collection']

# Generated at 2022-06-23 06:03:53.060749
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert not isinstance(cs._collections, field_attribute)

# Generated at 2022-06-23 06:04:00.124305
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import sys
    import unittest
    sys.path.append('/home/xiangyu.zou@couchbase.com/workspace/couchbase-python-client')
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    play = PlayContext()
    task_include = TaskInclude()
    task_include.load()
    assert isinstance(task_include, CollectionSearch)

# Generated at 2022-06-23 06:04:06.695011
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs._collections, FieldAttribute)
    assert cs._collections.isa == 'list'
    assert cs._collections.listof == string_types
    assert cs._collections.priority == 100
    assert cs._collections.default(_ensure_default_collection) == ['ansible_collections.nsot.nxos']
    assert cs._collections.always_post_validate is True
    assert cs._collections.static is True


# Generated at 2022-06-23 06:04:18.495505
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    # TEST 1: Test against collections field
    role = Role.load(dict(name='test_role', collections=['acme_test_collection']), loader=DataLoader(), play=None)
    assert _ensure_default_collection(role.collections) == ['acme_test_collection', 'ansible.builtin', 'ansible.legacy']

    task_include = TaskInclude.load(dict(name='test_task_include', collections=['acme_test_collection']), loader=DataLoader(), play=None)

# Generated at 2022-06-23 06:04:24.993205
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    c = CollectionSearch(play_context=PlayContext())
    d = c.get_value('collections')
    assert d == _ensure_default_collection()
    assert d == ['ansible.builtin']


# Generated at 2022-06-23 06:04:27.575023
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    tc = CollectionSearch()
    # check if the constructor fail
    assert tc is not None
    assert isinstance(tc, CollectionSearch)

# Generated at 2022-06-23 06:04:31.836552
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    import inspect
    assert inspect.ismethod(a._load_collections) and \
        inspect.isclass(CollectionSearch) and isinstance(a, CollectionSearch)

# Generated at 2022-06-23 06:04:33.637677
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is not  None

# Generated at 2022-06-23 06:04:41.645813
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():


    # Constructor of CollectionSearch class
    c = CollectionSearch()

    # To check the type of object created
    assert type(c) == CollectionSearch

    # To check the type of attribute value
    assert type(c._collections) == FieldAttribute

    # To check the value of attribute
    assert c._collections.isa == 'list'

    # To check the value of attribute
    assert c._collections.listof == string_types

    # To check the value of attribute
    assert c._collections.priority == 100

    # To check if the value of attribute is callable
    assert callable(c._collections.default)

# Generated at 2022-06-23 06:04:46.764158
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert isinstance(cs._collections, FieldAttribute)
    assert cs._collections.default == _ensure_default_collection
    assert cs._collections.priority == 100
    assert cs._collections.static is True
    assert cs._collections.always_post_validate is True
    assert cs._collections.listof == string_types
    assert cs._collections.isa == 'list'

# Generated at 2022-06-23 06:04:50.087182
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj._collections = ['namespace.collection']
    obj.post_validate()
    assert obj._collections == _ensure_default_collection(['namespace.collection'])

# Generated at 2022-06-23 06:04:52.414120
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test calling the constructor - nothing should fail
    CollectionSearch()

# Generated at 2022-06-23 06:04:57.390621
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Unit test for constructor of class CollectionSearch"""
    collection = CollectionSearch()
    # we got the right class
    assert isinstance(collection, CollectionSearch)

    #_collections correctly initialized
    assert isinstance(collection._collections, FieldAttribute)
    assert collection._collections.default == _ensure_default_collection

# Generated at 2022-06-23 06:05:04.705455
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection(['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']
    assert _ensure_default_collection(['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']
    assert _ensure_default_collection(['ansible.builtin', 'ansible.legacy', 'ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:05:07.777904
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Init class
    collection_search = CollectionSearch()
    # Check field types
    assert collection_search._collections.collection is True
    assert collection_search._collections.listof is True

# Generated at 2022-06-23 06:05:10.030675
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert ['ansible.builtin'] == collection_search._collections.default

# Generated at 2022-06-23 06:05:13.395068
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test that the constructor correctly assigns the value to the attribute collections
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()


# Generated at 2022-06-23 06:05:16.463285
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default() == ['ansible.legacy']
    assert collection_search.get_validated_value('collections', collection_search._collections, '') == ['ansible.legacy']



# Generated at 2022-06-23 06:05:21.330281
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Constructor test - CollectionSearch.__init__()
    search = CollectionSearch()
    assert isinstance(search, CollectionSearch)

    # Property test - CollectionSearch._collections property
    assert isinstance(search._collections, list)

# Generated at 2022-06-23 06:05:24.062271
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible_collections.nsweb.xml']

# Generated at 2022-06-23 06:05:31.727672
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
    #                               always_post_validate=True, static=True)
    assert isinstance(cs._collections, FieldAttribute)
    assert cs._collections.isa == 'list'
    assert cs._collections.listof == string_types
    assert cs._collections.priority == 100
    assert cs._collections.default == _ensure_default_collection
    assert cs._collections.always_post_validate
    assert cs._collections.static

# Generated at 2022-06-23 06:05:32.191400
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()

# Generated at 2022-06-23 06:05:34.881936
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is not None
    assert len(c._collections) == 1
    assert c._collections[0] == 'ansible.builtin'

# Generated at 2022-06-23 06:05:35.705733
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-23 06:05:40.414996
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) == ['ansible.builtin', 'ansible.legacy']

    # FIXME: Needs a real test. The mixin constructor checks
    # the collections field before it actually validates it, which means that
    # isa='list', listof=string_types, etc. are not checked yet.

# Generated at 2022-06-23 06:05:51.513082
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    from ansible.playbook.role_include import RoleInclude
    v = []
    c = CollectionSearch()
    # role._collections = FieldAttribute(isa='list', listof=string_types, priority=100,
    #                                      default=_ensure_default_collection, always_post_validate=True, static=True)
    v = c._collections.post_validate(v, "collections")
    assert v == ['ansible.builtin', 'ansible.legacy'], "collections not valid"
    v = c._collections.post_validate(v, "collections")
    assert v == ['ansible.builtin', 'ansible.legacy'], "collections not valid"

# Generated at 2022-06-23 06:05:53.220642
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c

# Generated at 2022-06-23 06:05:56.072815
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class test_CollectionSearch(CollectionSearch):
        def __init__(self):
            self._collections = _ensure_default_collection()
    assert test_CollectionSearch.__init__

# Generated at 2022-06-23 06:05:57.890804
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection1 = CollectionSearch()
    collection2 = CollectionSearch()
    assert collection1 == collection2

# Generated at 2022-06-23 06:06:01.775731
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # populate a Vars object with a list and call the constructor of CollectionSearch
    res = Vars(collections=['foo.bar'])
    search = CollectionSearch(res)
    res._load_collections('collections', search)

    assert res == search



# Generated at 2022-06-23 06:06:11.967023
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible_collections.test.unit.mock import patch
    from ansible.playbook.base import Base
    from ansible.playbook.role.definition import RoleDefinition

    class TestClass(CollectionSearch, Base):
        pass

    # test collection_search from role is correct
    role = RoleDefinition()
    role.role_path = 'roles/test'
    role.collections = ['test_col.test_col1']
    role.__task_cache = {'test_task': {}}

    # test collection_search from task is correct

# Generated at 2022-06-23 06:06:14.273254
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()



# Generated at 2022-06-23 06:06:22.100104
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

    assert(obj._collections == 'ansible.builtin')
    assert(obj.__dict__['_collections'] is None)
    assert(obj.collections == 'ansible.builtin')
    assert(obj.__dict__['_collections'] == 'ansible.builtin')
    
    obj.collections = ['ansible.builtin', 'test']
    assert(obj.__dict__['_collections'] == ['ansible.builtin', 'test'])

test_CollectionSearch()

# Generated at 2022-06-23 06:06:22.961761
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()

# Generated at 2022-06-23 06:06:31.076644
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with pytest.raises(ValueError) as excinfo:
        collection_list = ["foo.bar"]
        cs = CollectionSearch()
        cs.collections = collection_list
    assert excinfo.match("does not appear to be a valid collection") == None

    collection_list = ["foo.bar"]
    cs = CollectionSearch()
    cs.collections = collection_list
    assert cs._load_collections("collections",collection_list) == collection_list

# Generated at 2022-06-23 06:06:34.150267
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._load_collections(None, None) == _ensure_default_collection()

# Generated at 2022-06-23 06:06:37.023672
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.collections = ['nsb.pjt']
    print(collection_search.collections)

# Generated at 2022-06-23 06:06:38.096975
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-23 06:06:39.648917
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == _ensure_default_collection()

# Generated at 2022-06-23 06:06:46.843539
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections._validate_attr([], {}, {}) == [], 'default collection not empty'
    assert cs._collections._validate_attr(None, {}, {}) == [], 'default collection not empty'
    assert cs._collections._validate_attr(['test_collection'], {}, {}) == ['test_collection', 'ansible.builtin'],\
        'collection search missing default collection'

# Generated at 2022-06-23 06:06:54.028988
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create instance of CollectionSearch
    test = CollectionSearch()
    # Check if '_collections' attribute has correct type
    assert isinstance(test._collections, FieldAttribute)
    # Check if '_collections' attribute has right property
    assert test._collections.name == 'collections'
    assert test._collections.isa == 'list'
    assert test._collections.listof == string_types
    assert test._collections.priority == 100
    assert test._collections.default == _ensure_default_collection
    assert test._collections.always_post_validate == True
    assert test._collections.static == True
    # Check if _load_collection() returns right value
    assert test._load_collections('', ['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:06:55.327591
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch, '_load_collections')

# Generated at 2022-06-23 06:06:56.723715
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() != None

# Generated at 2022-06-23 06:07:00.878965
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default is _ensure_default_collection

    # test that the constructor actually sets an instance attribute
    cs = CollectionSearch()
    assert hasattr(cs, '_collections')

    # test that the instance attribute is set to a FieldAttribute
    assert isinstance(cs._collections, FieldAttribute)

# Generated at 2022-06-23 06:07:01.342109
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:07:11.867189
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    data = dict(collections=['my.collection'])
    b = CollectionSearch()
    # Base class __init__ will do the post-validation and set the attributes
    # with their default values
    super(CollectionSearch, b).__init__(data)
    assert b.collections == ['my.collection', 'ansible.builtin']

    # CollectionSearch should be a singleton
    b2 = CollectionSearch()
    assert b2.collections == ['ansible.builtin']

    # Now let's update the singleton with a new collection list
    b2.collections = ['my.collection', 'ansible.builtin']
    assert b2.collections == ['my.collection', 'ansible.builtin']

# Generated at 2022-06-23 06:07:13.406924
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:07:14.561425
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-23 06:07:16.887919
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ['test']
    out = cs._load_collections(None, ['test'])
    assert out == ['test']

# Generated at 2022-06-23 06:07:24.184710
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.default_value == _ensure_default_collection()
    assert c._collections.name == 'collections'
    assert c._collections.always_post_validate == True
    assert c._collections.static == True
    assert c._collections.priority == 100
    assert c._collections.is_task_include == False
    assert c._collections.default_from_config == False

# Generated at 2022-06-23 06:07:34.790178
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    if getattr(obj,'__dict__')['_collections']['kwargs']['listof'] != string_types:
        raise Exception("test failed")
    if getattr(obj,'__dict__')['_collections']['kwargs']['priority'] != 100:
        raise Exception("test failed")
    if getattr(obj,'__dict__')['_collections']['kwargs']['always_post_validate'] != True:
        raise Exception("test failed")
    if getattr(obj,'__dict__')['_collections']['kwargs']['static'] != True:
        raise Exception("test failed")

# Generated at 2022-06-23 06:07:43.444708
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test _load_collections()
    # Default collection_list is None
    assert CollectionSearch._load_collections(CollectionSearch(), '', None) == None
    # Default collection_list is []
    assert CollectionSearch._load_collections(CollectionSearch(), '', []) == []
    # Default collection_list is ['test.test_collection', 'ansible.builtin']
    assert CollectionSearch._load_collections(CollectionSearch(), '', ['test.test_collection', 'ansible.builtin']) == ['test.test_collection', 'ansible.builtin']
    # Default collection_list include "ansible.builtin"
    assert CollectionSearch._load_collections(CollectionSearch(), '', ['test.test_collection']) == ['test.test_collection', 'ansible.builtin']

# Generated at 2022-06-23 06:07:43.864221
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-23 06:07:49.649900
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        def __init__(self, collection_search=None, *args, **kwargs):
            self._collection_search = collection_search

            self.collections = collection_search
            super(CollectionSearch, self).__init__(*args, **kwargs)

    test_collection_search = TestCollectionSearch(collection_search=['test'])
    assert test_collection_search.collections == ['test']

# Generated at 2022-06-23 06:07:55.264170
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # Check the constructor is called without error
    assert collection_search
    # Check '_collections' is defined on collection_search
    assert(hasattr(collection_search, 'collections'))

# Generated at 2022-06-23 06:08:00.099456
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == None

    cs.collections = []
    assert cs.collections == ['ansible.builtin']

    cs.collections = ['my_collection']
    assert cs.collections == ['my_collection', 'ansible.builtin']

# Generated at 2022-06-23 06:08:01.777663
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-23 06:08:07.415962
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._load_collections("attr", "ds") is None
    assert obj._load_collections("attr", ["ansible_collections.my_namespace.my_collection"]) \
           == ['ansible_collections.my_namespace.my_collection', 'ansible.builtin']
    assert obj._load_collections("attr", []) == ['ansible.builtin']

# Generated at 2022-06-23 06:08:19.979521
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class testCollectionSearch(CollectionSearch):
        pass

    # check when field is None
    obj = testCollectionSearch()
    collections = obj.get_validated_value('collections', obj._collections, None, None)
    assert collections == _ensure_default_collection()

    # check when field is a list and it is empty
    obj = testCollectionSearch()
    collections = obj.get_validated_value('collections', obj._collections, [], None)
    assert collections == _ensure_default_collection(collection_list=[])

    # check when field is a list and it is not empty
    obj = testCollectionSearch()
    collections = obj.get_validated_value('collections', obj._collections, ['hello.world'], None)

# Generated at 2022-06-23 06:08:27.333258
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test 1: just set collections to ansible.builtin
    cs = CollectionSearch(collections=['ansible.builtin'])
    assert cs._collections == ['ansible.builtin']
    assert cs._collections_paths == [AnsibleCollectionConfig.collection_dir]

    # Test 2: test the default value
    css = CollectionSearch()
    assert css._collections == ['ansible.builtin']
    assert css._collections_paths == [AnsibleCollectionConfig.collection_dir]

# Generated at 2022-06-23 06:08:39.815864
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search_object = CollectionSearch()
    display.deprecated("Since the introduction of collections, the 'collections' field is deprecated. "
                       "To silence this warning, remove 'collections: []' from your playbook.")
    assert col_search_object._collections.post_validate(None) == ['ansible.builtin']

    col_search_object = CollectionSearch()
    display.deprecated("Since the introduction of collections, the 'collections' field is deprecated. "
                       "To silence this warning, remove 'collections: []' from your playbook.")
    assert col_search_object._collections.post_validate(['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']

    col_search_object = CollectionSearch()

# Generated at 2022-06-23 06:08:41.432772
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()

    # Test the constructor
    assert collection is not None

# Generated at 2022-06-23 06:08:45.086288
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert isinstance(search, CollectionSearch)
    assert isinstance(search._collections, FieldAttribute)
    assert search._collections.name == '_collections'
    assert search._collections.isa == 'list'
    assert search._collections.listof == string_types
    assert search._collections.priority == 100
    assert search._collections.always_post_validate
    assert search._collections.static
    assert isinstance(search._collections.default, _ensure_default_collection)

# Generated at 2022-06-23 06:08:46.716480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None


# Generated at 2022-06-23 06:08:54.546105
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs._collections, FieldAttribute)
    assert cs._collections._field_name == 'collections'
    assert cs._collections._field_label == 'collections'
    assert cs._collections._isa == 'list'
    assert cs._collections._priority == 100
    assert cs._collections._parent is None
    assert cs._collections._read_only is False
    assert cs._collections._always_post_validate is True
    assert cs._collections._static is True


# Generated at 2022-06-23 06:08:58.920596
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print('Test for constructor of class CollectionSearch')
    c1 = CollectionSearch()
    c2 = CollectionSearch()
    c3 = CollectionSearch()
    c1.set_loader('ansible.builtin')
    c2.set_loader('ansible.legacy')
    print(c1)
    print(c2)
    print(c3)

# Generated at 2022-06-23 06:09:01.326747
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._load_collections('attribute_name', 'data') == 'data'

# Generated at 2022-06-23 06:09:08.774690
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # assert FieldAttribute(isa='list', listof=string_types, priority=100, always_post_validate=True, static=True) \
    #== collection_search._collections
    assert collection_search._collections == FieldAttribute(isa='list', listof=string_types, priority=100,
                                                            default=_ensure_default_collection,
                                                            always_post_validate=True, static=True)
    assert 'ansible.legacy' in collection_search._collections.default(None)
    assert 'ansible.builtin' in collection_search._collections.default(None)

# Generated at 2022-06-23 06:09:11.421034
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == _ensure_default_collection(), 'It should return a list of string types.'

# Generated at 2022-06-23 06:09:21.940970
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    import yaml
    show_data = {'collections': ['ansible.builtin', 'test.collection1']}
    show_data_yaml = yaml.dump(show_data, default_flow_style=False)
    setattr(show_data, '_ds', 'yaml')
    setattr(show_data, '_data', show_data_yaml)
    test_CollectionSearch = CollectionSearch()
    test_CollectionSearch.post_validate(show_data, 'tasks')
    assert hasattr(test_CollectionSearch, 'collections')
    assert test_CollectionSearch.collections == ['ansible.builtin', 'test.collection1']

# Generated at 2022-06-23 06:09:23.305133
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections.always_post_validate == True


# Generated at 2022-06-23 06:09:32.304415
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # This is the same code that is inside the default argument to _ensure_default_collection
    collections_list_original = list(AnsibleCollectionConfig.default_collection)
    if collections_list_original and 'ansible.builtin' not in collections_list_original and 'ansible.legacy' not in collections_list_original:
        collections_list_original.append('ansible.legacy')

    collectionSearch = CollectionSearch(collections=collections_list_original)
    assert collectionSearch.collections == collections_list_original

    collectionSearch = CollectionSearch(collections=None)
    collections_list_new = collections_list_original
    if collections_list_new and 'ansible.builtin' not in collections_list_new and 'ansible.legacy' not in collections_list_new:
        collections_list_

# Generated at 2022-06-23 06:09:34.342599
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testObj = CollectionSearch()
    assert isinstance(testObj, CollectionSearch)


# Generated at 2022-06-23 06:09:35.791867
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch() is not None


# Generated at 2022-06-23 06:09:37.779836
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_obj = CollectionSearch()
    assert isinstance(search_obj, CollectionSearch)

# Generated at 2022-06-23 06:09:40.032751
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestClass(object, CollectionSearch):
        pass

    test_class = TestClass()
    assert test_class._collections is None

# Generated at 2022-06-23 06:09:43.517055
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test proper assignment of each attribute
    x = vars(CollectionSearch())
    assert type(x['_collections']) == FieldAttribute

# Generated at 2022-06-23 06:09:45.974515
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    assert RoleDefinition._collections.name == 'collections'
    assert RoleDefinition._collections.static is True

# Generated at 2022-06-23 06:09:50.897243
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    assert test_instance._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:09:52.723305
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:02.562818
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = None

# Generated at 2022-06-23 06:10:12.441530
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._load_collections(None, None) == ['ansible_collections.community.general', 'ansible.builtin']
    assert search._load_collections(None, ['ansible_collections.community.general', 'ansible.builtin']) == ['ansible_collections.community.general', 'ansible.builtin']
    assert search._load_collections(None, ['test_collection', 'ansible.builtin']) == ['test_collection', 'ansible.builtin']
    assert search._load_collections(None, ['test_collection']) == ['test_collection', 'ansible.legacy']

# Generated at 2022-06-23 06:10:14.339925
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._load_collections(None, None)

# Generated at 2022-06-23 06:10:15.774875
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()


# Generated at 2022-06-23 06:10:18.433285
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    print(c)


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:10:20.352991
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch._collections == 'ansible.builtin'

# Generated at 2022-06-23 06:10:22.983902
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch._collections, FieldAttribute)
    assert isinstance(CollectionSearch.collections, FieldAttribute)
    assert CollectionSearch.collections == CollectionSearch._collections

# Generated at 2022-06-23 06:10:28.535114
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    attr = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                          always_post_validate=True, static=True)
    ds = []

    assert collections._load_collections(attr,ds) == _ensure_default_collection()


# Generated at 2022-06-23 06:10:33.893200
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test1 = CollectionSearch()
    test2 = CollectionSearch()

    print(test1.get_validated_value('collections', test1._collections, ['test']))
    print(test2.get_validated_value('collections', test2._collections, ['test1', 'test2']))

# Generated at 2022-06-23 06:10:37.401206
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class FakeCollectionSearch(CollectionSearch):
        def __init__(self):
            self.attributes = ('attributes',)

    c = FakeCollectionSearch()

    c.attributes = {}
    assert c.attributes == {}



# Generated at 2022-06-23 06:10:40.563197
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # initialising CollectionSearch class
    obj = CollectionSearch()
    # checking whether the object is instance of CollectionSearch class
    assert isinstance(obj, CollectionSearch)


# Generated at 2022-06-23 06:10:49.884425
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from copy import deepcopy

    # test constructor of class CollectionSearch
    # deepcopy for test purpose because of static attribute
    collection_search = deepcopy(CollectionSearch())
    assert collection_search._collections._attributes['default'] == _ensure_default_collection
    assert collection_search._collections._attributes['always_post_validate'] is True
    assert collection_search._collections._attributes['static'] is True
    collection_search._collections.set_default_value(_ensure_default_collection)
    assert collection_search._collections._default_value == _ensure_default_collection

    # test _load_collections method of class PlayContext


# Generated at 2022-06-23 06:10:51.884858
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == 'ansible.legacy,ansible.builtin'

# Generated at 2022-06-23 06:10:56.789864
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs.collections, list)
    assert cs.collections == _ensure_default_collection()
    cs.collections = None
    assert cs.collections == [AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-23 06:10:58.349144
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        CollectionSearch()
    except Exception as err:
        assert False, "Unable to initialize 'CollectionSearch'"

# Generated at 2022-06-23 06:11:01.195602
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection(collection_list=None)

# Generated at 2022-06-23 06:11:03.514467
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert isinstance(x, CollectionSearch)
    assert x.collections is None

# Generated at 2022-06-23 06:11:15.139309
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._load_collections(None, None) is None
    assert search._load_collections(None, []) is None
    assert search._load_collections(None, ['col']) == ['ansible.builtin', 'col']
    assert search._load_collections(None, ['col', 'col2']) == ['ansible.builtin', 'col', 'col2']
    assert search._load_collections(None, ['col', 'ansible.builtin', 'col2']) == ['ansible.builtin', 'col', 'col2']
    assert search._load_collections(None, ['ansible.builtin', 'col2']) == ['ansible.builtin', 'col2']

# Generated at 2022-06-23 06:11:26.826720
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.plugins.task.include_role import IncludeRole
    from ansible.plugins.task.include_tasks import IncludeTasks
    s = CollectionSearch()
    t = TaskInclude()
    r = Role()
    b = Block()
    ir = IncludeRole()
    it = IncludeTasks()
    ir.__dict__['_role_name'] = 'F5Modules.f5networks_analytics_policy'
    ir.__dict__['_role_params'] = {}

# Generated at 2022-06-23 06:11:36.705980
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.from_yaml("", ds='collections: "ansible.builtin"')
    assert search._collections == ['ansible.builtin']
    search.from_yaml("", ds='collections: [ ansible.builtin ]')
    assert search._collections == ['ansible.builtin']
    search.from_yaml("", ds='collections: [ "galaxy.example.com,namespace.collection" ]')
    assert search._collections == ['galaxy.example.com,namespace.collection']
    search.from_yaml("", ds='collections: [ role.name ]')
    assert search._collections == ['role.name']
    search.from_yaml("", ds='')

# Generated at 2022-06-23 06:11:40.915260
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # tests for static attr
    cs = CollectionSearch()
    # tests for static attr with default value
    cs.get_value('collections')
    cs.post_validate('collections',{})

    # tests for attr
    cs.load_attr_from_datasource('collections','')

# Generated at 2022-06-23 06:11:47.841838
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()

    # ensure default collections are set in constructor
    assert len(cs._collections) == len(_ensure_default_collection())

    # check constructor also sets collections in self.collections
    assert len(cs.collections) == len(_ensure_default_collection())

    for c in cs.collections:
        assert c in _ensure_default_collection()

# Generated at 2022-06-23 06:11:50.801695
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._load_collections('collections', None) is None

# Generated at 2022-06-23 06:11:53.978050
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible_collections.nti310.nti310_linux', 'ansible.legacy']

# Generated at 2022-06-23 06:11:57.334963
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert len(collection_search._collections._get_default()) == 1
    assert collection_search._collections._get_default()[0] == 'ansible.builtin,ansible.legacy'

# Generated at 2022-06-23 06:11:59.607839
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()

    assert str(collectionSearch) == '{},class_only=False,fields=[],info_only_fields=[]'

# Generated at 2022-06-23 06:12:01.114475
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs)
    print(cs._collections)


# test_CollectionSearch()

# Generated at 2022-06-23 06:12:11.972497
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # pylint: disable=protected-access
    assert getattr(CollectionSearch, '_collections') is not None

    # pylint: disable=protected-access
    assert getattr(CollectionSearch, '_load_collections') is not None

    # pylint: disable=protected-access
    assert getattr(CollectionSearch, '_collections').static is True

    # pylint: disable=protected-access
    assert getattr(CollectionSearch, '_collections').always_post_validate is True

    assert _ensure_default_collection(['default_collection']) == ['default_collection']

    assert _ensure_default_collection(['ansible.builtin']) == ['ansible.builtin']

    assert _ensure_default_collection(['ansible.legacy']) == ['ansible.legacy']

# Generated at 2022-06-23 06:12:14.490169
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert isinstance(cs, FieldAttribute)


# Generated at 2022-06-23 06:12:17.327346
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create instance of class CollectionSearch
    test_class = CollectionSearch()

    # Check default value of "_collections"
    assert test_class._collections == ""
    assert test_class.collections == ""

# Generated at 2022-06-23 06:12:21.763068
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestModule(CollectionSearch):
        pass

    test_module = TestModule()
    module_attr = test_module.get_attr_metadata()
    assert module_attr['collections']['default'][0] == 'ansible.builtin,ansible.legacy'

# Generated at 2022-06-23 06:12:24.282822
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cls = CollectionSearch()
    assert cls._collections == cls._load_collections(None, [])

# Generated at 2022-06-23 06:12:26.504852
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # TODO: to complete the unit test for constructor of class CollectionSearch
    _collection_search = CollectionSearch()
    pass

# Generated at 2022-06-23 06:12:34.385503
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.plugins.loader import get_all_plugin_loaders

    c_s = CollectionSearch()

    # AnsibleCollectionConfig.default_collection has been initialized
    assert c_s._collections == ['ansible.builtin']

    # We are always a mixin with Base, so we can validate this untemplated field early on to guarantee we are dealing with a list.
    assert (c_s.get_validated_value('collections', c_s._collections, ['ansible.builtin'], None) == ['ansible.builtin'])

    # _ensure_default_collection will add default_collection to the list

# Generated at 2022-06-23 06:12:44.676623
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play_iterator import PlayIterator

    play = Base.load({
        'name': 'my_play',
        'hosts': 'all',
        'tasks': [
            {'name': 'my_task1'},
            {'name': 'my_task2'}
        ],
        'roles': [
            {'name': 'test_include_role1'},
            {'name': 'test_include_role2'}
        ]
    })

    play_context = PlayContext()

    # play_context is a mandatory argument to constructor of class CollectionSearch
    try:
        CollectionSearch()
    except TypeError:
        pass
    else:
        raise Assert

# Generated at 2022-06-23 06:12:45.570621
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c

# Generated at 2022-06-23 06:12:58.032543
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task import Task
    from ansible.plugins.test.test_plugin import TestModule
    from ansible.plugins.loader import module_loader
    from ansible.plugins.action.normal import at_least_one_included

# Generated at 2022-06-23 06:13:02.472792
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = AnsibleCollectionConfig.default_collection
    assert t is not None
    try:
        AnsibleCollectionConfig.default_collection = None
        assert 'ansible.legacy' in CollectionSearch._ensure_default_collection()
        assert 'ansible.builtin' in CollectionSearch._ensure_default_collection()
    finally:
        AnsibleCollectionConfig.default_collection = t

# Generated at 2022-06-23 06:13:10.020898
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._collections = 'ansible.builtin'
    assert cs._collections == 'ansible.builtin'
    cs._collections = ['ansible.builtin', 'ansible.builtin.role']
    assert cs._collections == ['ansible.builtin', 'ansible.builtin.role']
    assert cs._collections == _ensure_default_collection(collection_list=cs._collections)