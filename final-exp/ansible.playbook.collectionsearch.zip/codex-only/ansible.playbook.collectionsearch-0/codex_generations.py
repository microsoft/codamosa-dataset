

# Generated at 2022-06-23 06:03:14.618534
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

    #_collections is a static attribute, should always be
    #returned as a list
    assert isinstance(search._collections, list)

    #_load_collections should always return a list of collections
    #if specifed.
    assert isinstance(search._load_collections('collections',
                      ['ansible.builtin', 'test']), list)

    #If no collections are specified at the top level, the
    #default collection will be used.
    assert isinstance(search._load_collections('collections',
                      None), list)

# Generated at 2022-06-23 06:03:17.914847
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ['ansible_collections.notmintest.not_a_real_collection']

# Generated at 2022-06-23 06:03:22.605790
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_value = CollectionSearch()
    assert test_value._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:03:33.764690
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import load_collections
    from ansible.plugins.loader import RoleLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.errors import AnsibleError

    class MyLoader(RoleLoader):
        pass

    CollectionSearch()

    assert not load_collections(None, [])

    # We need to use a real collection with a valid entry point
    # since the entry point is called to validate the collection.
    # We can't use a simple role.yml since we don't have a
    # collection path or namespace.
    default_collection = AnsibleCollectionConfig.default_collection
    if default_collection:
        loader = AnsibleCollectionLoader()
        collection = loader.load_collections([default_collection], {}, [])
        assert collection

    loader = My

# Generated at 2022-06-23 06:03:44.222240
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import task_loader, lookup_loader, fragment_loader, callback_loader, test_loader

    pb = Play.load({
        'name': 'test',
        'hosts': 'localhost',
        'tasks': [{
            'name': 'x',
            'action': {
                'module': 'debug',
                'args': {
                    'msg': 'Hello world'
                },
            },
        }],
    }, base_dir=tmpdir, variable_manager=None, loader=task_loader)
    pb.load_callbacks()

# Generated at 2022-06-23 06:03:49.000988
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    ds = collection._load_collections('collections', None)
    assert(ds == _ensure_default_collection())
    ds = collection._load_collections('collections', [])
    assert(ds == _ensure_default_collection())
    ds = collection._load_collections('collections', ['foo'])
    assert(ds == _ensure_default_collection(['foo']))

# Generated at 2022-06-23 06:03:50.948787
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        assert(CollectionSearch().collections == ['ansible.builtin'])
    except:
        # Catch all exception
        assert(False)

# Generated at 2022-06-23 06:04:02.242613
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    # get the object attribute collections
    collections = c._collections
    # test the default value of attribute collections
    assert collections.default(None) == ['ansible_collection.test_collection', 'ansible.builtin', 'ansible.legacy']
    # test the new version of default value
    assert collections.default([]) == ['ansible_collection.test_collection', 'ansible.builtin', 'ansible.legacy']
    assert collections.default([1,2]) == [1, 2, 'ansible_collection.test_collection', 'ansible.builtin', 'ansible.legacy']
    assert collections.default(None) == ['ansible_collection.test_collection', 'ansible.builtin', 'ansible.legacy']
    # test that the validate method throws error

# Generated at 2022-06-23 06:04:04.845613
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance.collections is not None
    assert len(instance.collections) == 1
    assert instance.collections[0] == 'ansible.builtin'

# Generated at 2022-06-23 06:04:10.817429
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestSearch(CollectionSearch):
        pass

    search = TestSearch()
    assert search._collections is None
    assert search.collections == ['ansible.builtin']
    search.__init__()
    assert search.collections == ['ansible.builtin']

# Generated at 2022-06-23 06:04:20.448874
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.config import NetworkConfig
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import dict_to_set

    env = Environment()
    display = Display()

    collection_search = CollectionSearch()
    collection_search.display = display
    v = collection_search.get_validated_value('collections', collection_search._collections, ['test_collection'], None)
    assert v == ['test_collection'], 'Expected collection list of ["test_collection"], got: %s' % v

    NetworkConfig._collections = ['test_collection']
    assert 'ansible.legacy' not in NetworkConfig._collections, 'Expected to find ansible.legacy in collection list'
   

# Generated at 2022-06-23 06:04:22.386172
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.default() is not None

# Generated at 2022-06-23 06:04:24.421573
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:26.097804
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch is not None

# Generated at 2022-06-23 06:04:31.059883
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test case - create an instance of class CollectionSearch
    collection_search = CollectionSearch()
    # Ensure collection search class constructor is initialized correctly
    assert collection_search is not None

# Generated at 2022-06-23 06:04:34.170390
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cls = CollectionSearch()
    assert cls.collections == _ensure_default_collection()
    assert cls._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:40.137829
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # We are instantiating Base class just to test its constructor
    obj = CollectionSearch()

    if not obj:
        print("test_CollectionSearch is failed")
        exit(1)

    # WE are just asserting the collections, constructor will assign the collections as empty list
    if obj._collections != []:
        print("test_CollectionSearch is failed")
        exit(1)

    print("test_CollectionSearch is passed")
    exit(0)

# Generated at 2022-06-23 06:04:42.192562
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch(collections = ['TestCollection'])
    assert c._collections == ['TestCollection']

# Generated at 2022-06-23 06:04:50.017901
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds_ok = dict()

    ds_ok['collections'] = [
        'ansible.builtin',
        'ansible.legacy',
        'ansible_namespace.collection_name',
    ]
    collection_search = CollectionSearch(ds_ok)
    collection_search.post_validate(ds_ok, 'collections')

    ds_ok['collections'] = []
    collection_search = CollectionSearch(ds_ok)
    collection_search.post_validate(ds_ok, 'collections')

    ds_ok['collections'] = [
        'ansible.builtin',
        'ansible.legacy',
        'ansible_namespace.collection_name',
    ]
    collection_search = CollectionSearch(ds_ok)
    collection_search.post_validate

# Generated at 2022-06-23 06:04:52.424524
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:04:56.948419
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    attr = None
    ds = None
    collection_list = collectionSearch._load_collections(attr, ds)
    assert len(collection_list) == 1
    assert collection_list[0] == 'ansible.builtin'

# Generated at 2022-06-23 06:05:07.975562
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.plugins.tasks.add_host import ActionModule
    m = ActionModule(task=dict())
    # Run the base class constructor to create the collection list
    m.__class__.collections.__init__(m)
    # Get the collection list from the object m
    collection_list = m.collections if m.collections is not None else []
    # Assert that the number of collections added equals 2
    assert len(collection_list) == 2
    # Assert that the default collection is the first entry
    assert collection_list[0] == 'ansible_collections.amazon.aws'
    # Assert that the default builtin collection is the second entry
    assert collection_list[1] == 'ansible.builtin'


# Generated at 2022-06-23 06:05:09.322976
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None

# Generated at 2022-06-23 06:05:15.260138
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    test_value = cs._load_collections(attr='_collections', ds=['abc.def'])
    assert test_value == ['abc.def', 'ansible.legacy']

    test_value = cs._load_collections(attr='_collections', ds=None)
    assert test_value == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:05:19.434566
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

    # Assert the default value of _collections
    assert obj._collections == _ensure_default_collection()

    obj2 = obj.load(dict(collections = ['foo.bar']))

    # Confirm that _collections is assigned the value that is assigned in obj2
    assert obj2._collections == ['foo.bar']

# Generated at 2022-06-23 06:05:30.519126
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = ["one","two"]
    obj = CollectionSearch()
    # test_data_validation_for_collections
    res = obj.get_validated_value("collections",obj._collections,ds,None)
    if res != ds:
        raise AssertionError("Collections are not validated properly")
    # test_attrs_populated_in_validation
    if obj._static_attrs['collections'].value != ds:
        raise AssertionError("Collections are not validated properly")
    # test_list_validation_in_validation
    ds = ["one","two","one"]
    res = obj.get_validated_value("collections",obj._collections,ds,None)

# Generated at 2022-06-23 06:05:33.424774
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collections = collection_search._collections
    assert collections.default == _ensure_default_collection()
    assert collections._type == 'list'

# Generated at 2022-06-23 06:05:39.137836
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest
    import doctest

    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    suite.addTests(loader.loadTestsFromTestCase(CollectionSearchTest))

    suite.addTests(loader.loadTestsFromModule(doctest))

    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-23 06:05:40.088156
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs


# Generated at 2022-06-23 06:05:40.927628
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()

# Generated at 2022-06-23 06:05:44.483148
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    loader = CollectionSearch()
    assert loader._collections['always_post_validate'] is True
    assert loader._collections['static'] is True
    assert loader._collections['default'] is _ensure_default_collection

# Generated at 2022-06-23 06:05:48.594395
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # check if an instance of class CollectionSearch is successfully created
    a_CollectionSearch = CollectionSearch()
    assert isinstance(a_CollectionSearch, CollectionSearch)

    # check if the _collections field is created
    assert isinstance(a_CollectionSearch._collections, FieldAttribute)

# Generated at 2022-06-23 06:05:55.020603
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This is the only constructor of class CollectionSearch, so test it in isolation
    # Test that a default collection is added if there is one, and only one when there is no default
    class Host:
        pass

    from ansible.plugins.loader import module_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.collection_loader import AnsibleCollectionConfig, AnsibleCollectionRef
    from ansible.utils.display import Display

    task = CollectionSearch()

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    
    display = Display()

    # The filenames are modified to prevent a real path from being used in the filter
    filename = '/dev/null'

    # task.collections is empty,

# Generated at 2022-06-23 06:05:56.893133
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    t._load_collections(None, None)
    assert t._collections is None

# Generated at 2022-06-23 06:05:58.013275
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()

# Generated at 2022-06-23 06:05:59.082794
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()

# Generated at 2022-06-23 06:06:00.635631
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    b = CollectionSearch()
    assert b.collections == None

# Generated at 2022-06-23 06:06:02.356781
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-23 06:06:13.036666
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # Test _load_collections()
    task = TaskInclude()
    block = Block()

    with pytest.raises(AssertionError) as e:
        task._load_collections()

    assert "may only be called" in str(e.value)

    # Test TaskInclude.__init__()
    task1 = TaskInclude("one.yml")
    block1 = Block("one.yml")
    play1 = Play("one.yml")

    assert type(task1) == type(TaskInclude("one.yml"))

# Generated at 2022-06-23 06:06:15.657401
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test the constructor
    test = CollectionSearch()
    assert test._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:06:16.722001
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test = CollectionSearch()
        assert True
    except:
        assert False

# Generated at 2022-06-23 06:06:18.295688
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search

# Generated at 2022-06-23 06:06:19.367190
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        CollectionSearch()
    except:
        assert False

# Generated at 2022-06-23 06:06:25.671184
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cSearch = CollectionSearch()
    cSearch.collections = ['Ansible.builtin']
    cSearch._load_collections(None, ['Ansible.builtin'])


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-23 06:06:31.836520
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test constructor
    obj = CollectionSearch()
    # Test __init__ method
    collection_search_instance = type.__init__(CollectionSearch, obj)
    # Test the container with dict
    test_dict = dict()
    test_dict['_collections'] = value='ansible.builtin'
    test_dict['_collections'] = 'ansible.legacy'
    test_dict['_collections'] = 'ansible.builtin'
    # Test for dict instance
    test_dict_instance = obj._collections
    assert test_dict_instance == test_dict

# Generated at 2022-06-23 06:06:35.259027
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.default == 'ansible.builtin'

# Generated at 2022-06-23 06:06:45.912185
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections() == ['ansible.builtin', 'ansible.legacy']
    assert CollectionSearch(collections=[])._load_collections() == ['ansible.builtin', 'ansible.legacy']
    assert CollectionSearch(collections=['a.b'])._load_collections() == ['a.b', 'ansible.builtin', 'ansible.legacy']
    assert CollectionSearch(collections=['ansible.builtin'])._load_collections() == ['ansible.builtin', 'ansible.legacy']
    assert CollectionSearch(collections=['ansible.legacy'])._load_collections() == ['ansible.legacy', 'ansible.builtin']

# Generated at 2022-06-23 06:06:49.826244
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs.collections)

test_CollectionSearch()

# Generated at 2022-06-23 06:06:57.023251
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    collections = AnsibleCollectionConfig.default_collection

    # we are always a mixin with Base, so we can validate this untemplated
    # field early on to guarantee we are dealing with a list.
    data = search.get_validated_value('collections', search._collections, collections, None)

    # this will only be called if someone specified a value; call the shared value
    _ensure_default_collection(collection_list=data)

    # collections is empty list
    if not data:
        return None

    # This duplicates static attr checking logic from post_validate()
    # because if the user attempts to template a collection name, it may
    # error before it ever gets to the post_validate() warning (e.g. trying
    # to import a role from the collection).

# Generated at 2022-06-23 06:07:06.221649
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t._collections.default == ['ansible.builtin'] or t._collections.default == ['ansible.legacy']
    assert t._collections.priority == 100
    assert t._collections.always_post_validate
    assert t._collections.static
    assert t.collections == ['ansible.builtin'] or t.collections == ['ansible.legacy']
    assert t.get_validated_value('collections', None, None, None) == ['ansible.builtin'] or t.get_validated_value('collections', None, None, None) == ['ansible.legacy']

    t2 = CollectionSearch(collections=['ansible.builtin', 'ansible.legacy'])

# Generated at 2022-06-23 06:07:11.612048
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    fields = CollectionSearch()
    assert fields._load_collections(['awx.awx', 'ansible.builtin'], None) == ['awx.awx', 'ansible.builtin', 'ansible.legacy']
    assert fields._load_collections(['ansible.builtin'], None) == ['ansible.builtin', 'ansible.legacy']
    assert fields._load_collections(None, None) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:07:13.495638
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    obj = CollectionSearch()
    display.display(obj._collections)

# Generated at 2022-06-23 06:07:15.437185
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    result = collection._ensure_default_collection("")
    assert type(result) == list

# Generated at 2022-06-23 06:07:16.970415
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # this is a test
    test = CollectionSearch()
    assert test.collections == _ensure_default_collection()

# Generated at 2022-06-23 06:07:19.777934
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is not None

# Generated at 2022-06-23 06:07:22.104131
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().get_validated_value('collections', CollectionSearch()._collections, None, None) == ['ansible.builtin']

# Generated at 2022-06-23 06:07:28.943588
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    sc = CollectionSearch(variable_manager=variable_manager)

    assert sc._collections == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible.legacy']

# Generated at 2022-06-23 06:07:32.639033
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    data_structure = {}
    collections = search.get_validated_value('collections', search._collections, data_structure, None)
    assert(collections is not None)
    assert(len(collections) > 0)

# Generated at 2022-06-23 06:07:33.930641
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection=CollectionSearch()
    assert collection._collections._default()

# Generated at 2022-06-23 06:07:36.770947
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t._collections == _ensure_default_collection()
    assert t._load_collections(None, None) == _ensure_default_collection()

# Generated at 2022-06-23 06:07:41.386890
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin']
    assert cs._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']
    assert cs._load_collections(None, ['foo.bar']) == ['foo.bar', 'ansible.builtin']
    assert cs._load_collections(None, []) is None

# Generated at 2022-06-23 06:07:44.460155
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()
    assert c._collections is not _ensure_default_collection()


# Generated at 2022-06-23 06:07:54.277865
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test that AnsibleCollectionConfig.default_collection is not in
    # search list.
    cs = CollectionSearch()
    assert AnsibleCollectionConfig.default_collection not in cs._collections

    # Test that AnsibleCollectionConfig.default_collection is in
    # search list.
    cs = CollectionSearch(collections=["ansible.builtin"])
    assert AnsibleCollectionConfig.default_collection in cs._collections
    assert len(cs._collections) == 2

    # Test that ansible.builtin is in search list
    # even when collections is not specified.
    cs = CollectionSearch()
    assert "ansible.builtin" in cs._collections
    assert len(cs._collections) == 2

    # Test that ansible.builtin is in search list
    # even when collections is set to None.

# Generated at 2022-06-23 06:07:56.724050
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections['default'] is _ensure_default_collection

# Generated at 2022-06-23 06:08:01.149791
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    
    obj = CollectionSearch()
    collections = obj._load_collections('collections', None)

    collections_expected = ['ansible_namespace.my_collection', 'ansible.builtin', 'ansible.legacy']

    assert collections == collections_expected
    assert obj.collections == collections_expected



# Generated at 2022-06-23 06:08:10.862349
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block

    test_block = Block()
    my_collection_search = CollectionSearch(parent_block=test_block)
    class_instance = CollectionSearch()
    assert my_collection_search.collections == class_instance.collections
    assert my_collection_search.data == class_instance.data
    assert my_collection_search.ds == class_instance.ds
    assert my_collection_search._block == class_instance._block
    assert my_collection_search._block_parent == class_instance._block_parent
    assert my_collection_search.role_names == class_instance.role_names
    assert my_collection_search.task_names == class_instance.task_names
    assert my_collection_search.role_names == class_instance.role_names
    assert my_collection

# Generated at 2022-06-23 06:08:13.680478
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj is not None
    assert test_obj._load_collections(None, None) is not None

# Generated at 2022-06-23 06:08:15.124716
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:08:19.159946
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    # Test _load_collections function
    collections = collectionsearch._load_collections('CollectionSearch','None')
    # Test returned collection name
    assert collections is not None
    assert isinstance(collections, list)
    assert collections[0] == 'ansible.builtin'

# Generated at 2022-06-23 06:08:20.184860
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_search = CollectionSearch()
    test_collection_search._load_collections('collections', None)

# Generated at 2022-06-23 06:08:21.343186
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    co = CollectionSearch()
    assert co is not None

# Generated at 2022-06-23 06:08:30.958918
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    import os

    # Creating a loader instance
    loader = DataLoader()
    # Setting the inventory manager
    inventory = InventoryManager(loader=loader, sources=['examples/ansible-playbooks/hosts'])
    # Setting the variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # Setting a fake play

# Generated at 2022-06-23 06:08:32.017163
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_search = CollectionSearch()
    assert coll_search._collections._value is None

# Generated at 2022-06-23 06:08:35.573421
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    collection_search = CollectionSearch()
    display.display('0')
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:08:40.808627
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_Collection_Search = CollectionSearch()
    test_Collection_Search._collections = ['Test Collection']
    assert test_Collection_Search._load_collections('collections', 'Test Collection') is not None
    assert test_Collection_Search._load_collections('collections', 'Test Collection') == ['Test Collection']

# Generated at 2022-06-23 06:08:43.954981
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Task1(CollectionSearch): pass
    t1 = Task1()
    assert t1._collections is Task1._collections
    assert t1._collections.default is not Task1._collections.default



# Generated at 2022-06-23 06:08:46.319408
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:08:48.022274
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert isinstance(search._collections, FieldAttribute)

# Generated at 2022-06-23 06:08:56.373870
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # None value to the constructor
    collection = CollectionSearch(collections=None)
    assert collection._collections is None

    # List value to the constructor
    collection = CollectionSearch(collections=['ansible.builtin'])
    assert collection._collections == ['ansible.builtin']

    # String value to the constructor
    try:
        collection = CollectionSearch(collections='ansible.builtin')
    except Exception:
        pass

    # Invalid value to the constructor
    try:
        collection = CollectionSearch(collections=['ansible.builtin', 123])
    except Exception:
        pass

# Generated at 2022-06-23 06:09:00.362352
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Given
    ds = dict(
        collections=['ansible.builtin', 'ansible.legacy']
    )

    # When
    search = CollectionSearch()

    # Then
    assert search._load_collections('collections', ds) is not None
    assert search._load_collections('collections', ds) == ['ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-23 06:09:04.764656
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()
    #assert test_object._collections == _ensure_default_collection()
    #assert test_object._collections == _ensure_default_collection()
    assert test_object._collections == 'ansible.builtin'

# Generated at 2022-06-23 06:09:10.438436
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role import Role
    r = Role()
    r.post_validate(dict(), dict())
    assert 'ansible.builtin' in r.collections
    assert 'ansible.legacy' in r.collections
    assert 'ansible.netcommon' not in r.collections

# Generated at 2022-06-23 06:09:13.510180
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert hasattr(collection_search, '_collections')
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:09:22.997973
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Returns None if no collections are provided
    # ansible.builtin and ansible.legacy will be always added if collection is provided to ensure backwards compatibility
    assert cs._load_collections('collections', None) is None

    # Returns list of collections
    test = cs._load_collections('collections', ['collection1', 'collection2', 'collection3'])
    assert isinstance(test, list)
    assert set(test) == set(['collection1', 'collection2', 'collection3'])

    # ansible.builtin and ansible.legacy will be always added if collection is provided to ensure backwards compatibility
    test = cs._load_collections('collections', ['collection1', 'collection2', 'collection3'])
    assert isinstance(test, list)
    assert set(test).issupers

# Generated at 2022-06-23 06:09:26.285997
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch(collections=['col1','col2'])
    assert(a._collections == ['col1','col2'])
    a = CollectionSearch()
    assert(a._collections == None)

# Generated at 2022-06-23 06:09:28.976541
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection
    assert cs._collections.always_post_validate
    assert cs._collections.static
    assert cs._collections.priority == 100

# Generated at 2022-06-23 06:09:31.800338
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)


# Generated at 2022-06-23 06:09:36.121182
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    success = True


    # Check that the constructor executes fully.
    try:
        class_obj = CollectionSearch()
    except:
        success = False

    if not success:
        raise AssertionError("CollectionSearch did not run successfully.")

# Generated at 2022-06-23 06:09:36.920744
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections.default == ['ansible.builtin']

# Generated at 2022-06-23 06:09:39.048583
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert s._collections.value == _ensure_default_collection()

# Generated at 2022-06-23 06:09:40.152485
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-23 06:09:42.844142
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)



# Generated at 2022-06-23 06:09:43.877118
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search

# Generated at 2022-06-23 06:09:47.183585
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Execute get_validated_value() method
    # ds = None
    # cs.get_validated_value('collections', cs._collections, ds, None)

# Generated at 2022-06-23 06:09:50.947096
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:09:58.004018
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    path = '/tmp/test_collection_search'
    with open(path, 'w') as f:
        text = '---\ncollections:\n  - ansible.builtin'
        f.write(text)

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    parser = CollectionSearch()
    parser._load_collections('collections', module.load_file_common_arguments(path))
    assert parser._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:09:59.898944
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:01.349851
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()


# Generated at 2022-06-23 06:10:03.393035
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._load_collections() is not None

# Generated at 2022-06-23 06:10:05.530734
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._load_collections(None, None) is None

# Generated at 2022-06-23 06:10:09.422506
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        cs = CollectionSearch()
        assert isinstance(cs._load_collections("collections", None), list)
    except Exception as ex:
        assert False, "Exception raised: " + str(ex)
    assert True

# Generated at 2022-06-23 06:10:16.597260
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass

    from ansible.playbook.role.definition import RoleDefinition

    tc = TestCollectionSearch()
    assert tc.collections == ['ansible.builtin', 'ansible.legacy']
    tc.collections = ['sample.ns']
    tc.post_validate(templar=None, loader=None, cur_ds=None)
    assert tc.collections == ['sample.ns', 'ansible.builtin', 'ansible.legacy']
    tc.collections = ['sample.ns', 'sample.ns2']
    tc.post_validate(templar=None, loader=None, cur_ds=None)
    assert tc.collections == ['sample.ns', 'sample.ns2', 'ansible.builtin', 'ansible.legacy']
   

# Generated at 2022-06-23 06:10:18.278318
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:21.382843
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections == _ensure_default_collection()
    test_obj._collections = None
    assert test_obj._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:10:26.991230
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	_collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)
	assert _collections == FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)

# Generated at 2022-06-23 06:10:38.837733
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    cs = CollectionSearch()
    cs.display = display
    # Test empty constructor
    assert cs.collections == ['ansible.legacy'], 'Should be able to add empty collections'
    # Test constructor with a single string
    cs = CollectionSearch(collections='ansible_collections.test_ns.test_coll')
    cs.display = display
    assert cs.collections == ['ansible_collections.test_ns.test_coll', 'ansible.legacy'], 'Should be able to add a single collection'
    # Test constructor with a list
    cs = CollectionSearch(collections=['ansible_collections.test_ns.test_coll', 'ansible.builtin'])
    cs.display = display

# Generated at 2022-06-23 06:10:48.434268
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.errors import AnsibleError
    from ansible.module_utils.cli.argparse import ArgumentTypeError
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean

    # Argument validation testing
    try:
        CollectionSearch(collections='not a list')
    except ArgumentTypeError:
        pass
    else:
        raise AssertionError("Expected ArgumentTypeError")

    # Boolean Argument testing
    try:
        CollectionSearch(collections=[boolean(False)])
    except AnsibleError:
        pass
    else:
        raise AssertionError("Expected AnsibleError")

    # Option testing
    ds = CollectionSearch(collections=['ansible.builtin', 'ansible.legacy'])
    d

# Generated at 2022-06-23 06:10:54.108061
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # create an instance of CollectionSearch class
    test_collection_search = CollectionSearch()

    # display the values of fields of the instance of CollectionSearch class
    print(test_collection_search._fields)

    # display the values of fields of the instance of CollectionSearch class after calling get_validated_value
    print(test_collection_search.get_validated_value('collections', test_collection_search._collections, ['placeholder'], None))

# Generated at 2022-06-23 06:10:57.266033
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play import Play

    play = Play()
    assert play._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:11:04.800236
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert 'ansible.builtin' in obj._collections

    obj = CollectionSearch(collections=['testing.collection'])
    assert 'ansible.builtin' in obj._collections
    assert 'testing.collection' in obj._collections

    obj = CollectionSearch(collections=['ansible.builtin'])
    assert 'ansible.builtin' in obj._collections

# Generated at 2022-06-23 06:11:06.697151
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == 'ansible.builtin,ansible.legacy'

# Generated at 2022-06-23 06:11:09.616569
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible_collections.ansible', 'ansible_collections.notstdlib']

# Generated at 2022-06-23 06:11:11.443236
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-23 06:11:12.851799
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # Test for the attribute 'collections', which was defined in the constructor
    if cs.collections != None:
        raise AssertionError("Failed to initialize 'collections' in constructor of CollectionSearch")

# Generated at 2022-06-23 06:11:13.804616
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections

# Generated at 2022-06-23 06:11:25.100436
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.plugins.loader import find_plugin_filepaths
    from ansible.plugins import ActionModuleLoader, ConnectionLoader
    from ansible.utils.collection_loader import _get_collection_subdir

    # Class definition for test
    class A(CollectionSearch):
        pass
    a = A()

    # Initialize object
    a.post_validate()

    # Check object has all required attributes
    assert a.collections == _ensure_default_collection()

    # Check that connection plugin is loaded from default ansible collection
    assert 'connection' in find_plugin_filepaths(subdirs=_get_collection_subdir('ansible.builtin'))

    # Check that action plugin can be loaded
    ActionModuleLoader()
    ConnectionLoader()

    # Check the validator

# Generated at 2022-06-23 06:11:33.460664
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)

    # _collections
    assert isinstance(obj._collections, FieldAttribute)
    assert obj._collections.name == 'collections'
    assert obj._collections.isa == 'list'
    assert obj._collections.listof == string_types
    assert obj._collections.default == obj._ensure_default_collection
    assert obj._collections.always_post_validate is True
    assert obj._collections.static is True

    obj = CollectionSearch()
    assert obj.collections == ['ansible.legacy']

    obj = CollectionSearch(collections=['foo'])
    assert obj.col

# Generated at 2022-06-23 06:11:37.478672
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    cs._load_collections("collections", "test")

# Generated at 2022-06-23 06:11:46.824560
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = {'collections': ['ansible.builtin']}
    cs = CollectionSearch()
    assert cs._load_collections(ds) == ds['collections']

    ds = {'collections': ['ansible.builtin', 'ansible.legacy']}
    cs = CollectionSearch()
    assert cs._load_collections(ds) == ds['collections']

    ds = {'collections': ['ansible.builtin', 'ansible.legacy']}
    cs = CollectionSearch()
    assert cs._load_collections(ds) == ds['collections']

    ds = {'collections': []}
    cs = CollectionSearch()
    assert cs._load_collections(ds) is None

    ds = {'collections': None}
    cs = CollectionSearch()
   

# Generated at 2022-06-23 06:11:53.662405
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    collections = AnsibleCollectionConfig.default_collection
    # the default_collection is 'ansible_collections'
    assert collections == 'ansible_collections'
    ds = cs._load_collections(cs.collections, collections)
    # the ds is 'ansible_collections'
    assert ds == 'ansible_collections'

# Generated at 2022-06-23 06:11:57.022993
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._populate_from_extras(['collection_search'], {}, {'collections': None})

    assert cs._collections is not None
    assert cs._collections == ['ansible.builtin']

# Generated at 2022-06-23 06:11:58.716657
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance._collections is None

# Generated at 2022-06-23 06:12:09.432967
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task import Task
    search = CollectionSearch()
    assert isinstance(search, object)
    assert isinstance(search._load_collections, object)
    assert '_collections' in search.__dict__
    assert isinstance(search.__dict__['_collections'], FieldAttribute)
    assert not hasattr(search.__dict__['_collections'], 'parent_name')
    assert hasattr(search.__dict__['_collections'], 'isa')
    assert hasattr(search.__dict__['_collections'], 'default')
    #assert hasattr(search.__dict__['_collections'], '_from_module_params')
    #assert hasattr(search.__dict__['_collections'], '_from_action_plugin')
    #assert hasattr(

# Generated at 2022-06-23 06:12:12.959421
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    collections = search._load_collections(None, None)
    assert collections == _ensure_default_collection()
    assert collections == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible.legacy']


# Generated at 2022-06-23 06:12:17.395760
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    collections = cs._load_collections('collections', [])
    assert collections == ['ansible.builtin', 'ansible.legacy']    
    collections = cs._load_collections('collections', [])
    assert collections == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-23 06:12:18.777056
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search)

# Generated at 2022-06-23 06:12:22.073373
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    # The correct type of the returned value should be a list.
    assert isinstance(a._load_collections('', []), list)



# Generated at 2022-06-23 06:12:24.633048
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-23 06:12:28.973299
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task import Task

    task = Task()
    task.collections = ['ansible_collections.nti_cloud']

    assert task.collections == ['ansible_collections.nti_cloud']

# Generated at 2022-06-23 06:12:31.372765
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    fields, attrs = CollectionSearch.get_composite_fields()
    fields_dict = dict((f.name, f) for f in fields)
    assert 'collections' in fields_dict.keys()

# Generated at 2022-06-23 06:12:33.750050
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    print(search._collections)

# Generated at 2022-06-23 06:12:37.959234
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    This test case is to run the constructor of class CollectionSearch
    and check if it returns an object as expected.
    :return:
    """

    testCollectionSearch = CollectionSearch()
    assert testCollectionSearch is not None, "Failed to run the constructor of class CollectionSearch."

# Generated at 2022-06-23 06:12:46.531889
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    collection_search = CollectionSearch()
    default_collections = collection_search._collections()
    collections = [collection_search._load_collections(None, [])]
    collections.extend([collection_search._load_collections(None, 'ansible.builtin')])
    collections.extend([collection_search._load_collections(None, ['ansible.builtin', 'ansible.builtin/system'])])
    for collection in collections:
        assert isinstance(collection, list)
        assert default_collections == collection
    collections = [collection_search._load_collections(None, 'ansible.builtin/system')]
    collections.extend([collection_search._load_collections(None, ['ansible.builtin', 'ansible.builtin/system'])])

# Generated at 2022-06-23 06:12:58.313535
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    cs = CollectionSearch()

    assert isinstance(cs._collections, FieldAttribute)
    assert cs._collections.priority == 100
    assert cs._collections.default == _ensure_default_collection
    assert cs._collections.always_post_validate
    assert cs._collections.static

    assert cs._collections.default() == _ensure_default_collection()
    assert cs._collections.default(['test']) == _ensure_default_collection(['test'])

    assert not cs._collections.static

    # Test with builtin collection data
    assert AnsibleCollectionConfig.default_collection == 'ansible.builtin'
    assert cs._collections.default() == _ensure_

# Generated at 2022-06-23 06:13:00.877578
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    a._collections = [['foo', 'bar.baz'], 'abc', 'abc.def']
    assert a._collections == [['foo', 'bar.baz'], 'abc', 'abc.def']
    a._collections = None
    assert a._collections is None

# Generated at 2022-06-23 06:13:02.885329
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is not None

# Generated at 2022-06-23 06:13:05.146610
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ['ansible.builtin']
    assert cs.collections == [AnsibleCollectionConfig.default_collection, 'ansible.builtin']

# Generated at 2022-06-23 06:13:06.609918
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-23 06:13:10.134342
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    test.collections = "test"
    assert _ensure_default_collection(test.collections) == ['ansible.builtin', 'ansible.legacy', 'test']