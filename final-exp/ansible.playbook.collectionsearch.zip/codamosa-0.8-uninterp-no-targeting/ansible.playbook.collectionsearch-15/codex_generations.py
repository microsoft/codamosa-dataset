

# Generated at 2022-06-21 00:21:55.539934
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default == AnsibleCollectionConfig.default_collection
    assert collection_search._collections.priority == 100
    assert not collection_search._collections.always_post_validate
    assert collection_search._collections.static
    assert collection_search._collections.isa == 'list'
    assert collection_search._collections.listof == string_types



# Generated at 2022-06-21 00:22:00.508362
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    class TestCollectionSearch(CollectionSearch):
        def __init__(self, **kwargs):
            self.collections = _ensure_default_collection(['test.test_collections'])
    display.debug(TestCollectionSearch().collections)

# Generated at 2022-06-21 00:22:04.621494
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collections = ['col1', 'col2']
    collection = CollectionSearch()

    # Test constructor of class CollectionSearch
    collection.__init__(collections=test_collections)

    assert collection._collections == test_collections
    assert collection._load_collections(None, None) == test_collections

# Generated at 2022-06-21 00:22:06.374034
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == 'ansible.builtin,ansible.legacy'

# Generated at 2022-06-21 00:22:09.011149
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Execute constructor of class CollectionSearch
    collection_search = CollectionSearch()
    print("Test success")


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:22:14.121923
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections._static is True
    assert c._collections.default() == ['ansible.builtin', 'ansible.legacy']
    assert c._collections._post_validate(['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']
    assert c._collections._post_validate([]) is None
    assert c._collections._post_validate(['non-exists.collection']) == ['non-exists.collection', 'ansible.legacy']

# Generated at 2022-06-21 00:22:15.143891
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass
#     cs = CollectionSearch()

# Generated at 2022-06-21 00:22:17.129485
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testCol = CollectionSearch()
    assert testCol._load_collections('','ansible.builtin')

# Generated at 2022-06-21 00:22:25.238898
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    # For now there is no way to retrieve the actual value of 'collections'
    # We do not want to define a getter here because we really want to stick to the key-value interface
    # So we will have to stick to this code for now
    print(obj._attributes['collections'].value)
    # We will work with a private attribute to access the value
    print(obj._collections)
    # The following will not work:
    print(obj.collections)
    # => The above code will print nothing

# Generated at 2022-06-21 00:22:30.542526
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.static
    assert CollectionSearch._collections.always_post_validate
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.name == 'collections'
    assert CollectionSearch._collections.get_value() == _ensure_default_collection()

# Generated at 2022-06-21 00:22:42.252891
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def _ensure_default_collection_test(collection_list):
        return AnsibleCollectionConfig.default_collection

    # this needs to be populated before we can resolve tasks/roles/etc
    _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection_test,
                                  always_post_validate=True, static=True)

    object = CollectionSearch()
    object._collections = _collections

    collections = ["ansible.builtin", "my.collection"]
    assert object._load_collections(1, collections) == collections

# Generated at 2022-06-21 00:22:44.966756
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    fs = CollectionSearch(collections=['col1', 'col2'])
    assert fs._collections == ['col1', 'col2']

# Generated at 2022-06-21 00:22:48.324808
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(None, None) == ['ansible_collections.foo.bar', 'ansible_collections.foo.bar2', 'ansible.builtin']

# Generated at 2022-06-21 00:22:51.097970
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._collections = _ensure_default_collection()
    cs._load_collections(None, '')


# Generated at 2022-06-21 00:22:53.193623
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print('Testing construction of class CollectionSearch')
    collection_search = CollectionSearch()
    if collection_search._collections != []:
        print('Failed to construct class CollectionSearch')
        return False
    print('Construction of class CollectionSearch successful')
    return True

# Generated at 2022-06-21 00:22:55.610162
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default(None) == ['ansible.builtin'] or \
        cs._collections.default(None) == ['ansible.legacy']

# Generated at 2022-06-21 00:22:59.017872
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    test_obj.collections = ['my.collection', 'my.other.collection']
    assert test_obj.collections == ['my.collection', 'my.other.collection']

# Generated at 2022-06-21 00:23:02.212563
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.always_post_validate is True
    assert obj._collections.default() == ['ansible_collections.community.general']

# Generated at 2022-06-21 00:23:02.825484
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

# Generated at 2022-06-21 00:23:04.397035
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.default()

# Generated at 2022-06-21 00:23:13.046642
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    d = dict(collections="abc.xyz")
    c._load_collections("collections", d)

# Generated at 2022-06-21 00:23:14.912084
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:16.312514
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    assert col.collections == ['ansible.builtin']

# Generated at 2022-06-21 00:23:17.790023
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:18.831745
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    assert(CollectionSearch._collections)

# Generated at 2022-06-21 00:23:20.633523
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:32.013384
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class HostVars():
        pass

    hostvars = HostVars()

    hostvars.vars = dict()
    hostvars.vars['collections'] = ['best.collection']
    hostvars.default_type = 'host'

    cs = CollectionSearch()
    assert cs._load_collections(None, hostvars) == ['best.collection']

    cs = CollectionSearch()
    hostvars = HostVars()
    hostvars.vars = dict()
    hostvars.default_type = 'host'
    assert cs._load_collections(None, hostvars) == ['ansible.builtin', 'ansible.legacy']
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:23:40.453959
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.__dict__ == {'_collections': None, '_validation_errors': {}, '_task': None, '_deprecated_reasons': {}, '_deprecated_errors': {}}
    collection_search.post_validate()
    assert collection_search.__dict__ == {'_collections': ['ansible.builtin'], '_validation_errors': {}, '_task': None, '_deprecated_reasons': {}, '_deprecated_errors': {}}
    assert collection_search._collections == ['ansible.builtin']


# Generated at 2022-06-21 00:23:50.724616
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    no_field = {'default': ''}

    class ConcreteCollectionSearch(CollectionSearch):
        def __init__(self, *args, **kwargs):
            super(ConcreteCollectionSearch, self).__init__(*args, **kwargs)
            self._collection_list = self.get_validated_value('collections', self._collections, None, None)

    config = {'collections': [], 'any_other_config': 'spam'}

    ccs = ConcreteCollectionSearch()
    ccs.post_validate(no_field, config, 'collections')
    assert set(ccs._collection_list) == {'ansible.builtin', 'ansible.legacy'}

    ccs = ConcreteCollectionSearch()

# Generated at 2022-06-21 00:23:59.344975
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearchStub:
        def __init__(self, *args, **kwargs):
            self._collections = []

    config = CollectionSearchStub()
    assert isinstance(config, CollectionSearch)

    collection_list = ['collection_tasks', '']
    config = CollectionSearchStub(collection_list)
    assert config._collections == ['collection_tasks', 'ansible.builtin']

    collection_list = []
    config = CollectionSearchStub(collection_list)
    assert config._collections == ['ansible.builtin']



# Generated at 2022-06-21 00:24:23.030937
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections._load_collections('collections', None) is None
    result = collections._load_collections('collections', [])
    assert len(result) == 2
    assert result[0] == 'ansible.builtin' or result[0] == 'ansible.legacy'
    assert result[1] == 'ansible.builtin' or result[1] == 'ansible.legacy'
    assert result[0] != result[1]
    assert collections._load_collections('collections', ['collection']) == ['collection', 'ansible.builtin']
    assert collections._load_collections('collections', ['collection1', 'collection2']) == ['collection1', 'collection2']

# Generated at 2022-06-21 00:24:27.905391
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert(cs._load_collections('collections', ['geerlingguy.java']) == ['ansible.builtin', 'geerlingguy.java'])
    assert(cs._load_collections('collections', ['ansible.builtin', 'geerlingguy.java']) == ['ansible.builtin', 'geerlingguy.java'])

# Generated at 2022-06-21 00:24:31.811872
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert cs.collections == _ensure_default_collection()
    assert isinstance(cs.collections, list)
    assert len(cs.collections) == 1 or len(cs.collections) == 2

# Generated at 2022-06-21 00:24:33.332427
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-21 00:24:44.489863
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.module_utils.six import PY3
    import sys

    # sys.modules is a dict of key, value pairs.  The key is the name of the module
    # The value is an object of type module
    # Let us get the object of module ansible.utils.collection_loader and store it in temp_module.
    temp_module = sys.modules.get('ansible.utils.collection_loader')

    # Let us create a mock object of module ansible.utils.collection_loader and store it in mock_module.
    # Let us also create a dictionary mock_attrs which will have the attributes of a module object.
    mock_attrs = {}
    mock_module = type('ansible.utils.collection_loader', (), {})

    # now mock the required attributes in mock_attrs.

# Generated at 2022-06-21 00:24:47.250692
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    if search == None:
        print("test CollectionSearch test_CollectionSearch(): PASS")
    else:
        print("test CollectionSearch test_CollectionSearch(): FAILED")

# Generated at 2022-06-21 00:24:48.640943
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search=CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-21 00:24:54.564993
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # cs.collections should have been already set to "ansible.builtin" by default.
    assert cs.collections == ['ansible.builtin']
    # set collections to ["c1", "c2", "c3"]
    cs._collections = ['c1', 'c2', 'c3']
    assert cs.collections == ['c1', 'c2', 'c3']

# Generated at 2022-06-21 00:24:58.616123
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()
    assert collection_search._collections.data == _ensure_default_collection(collection_search._collections.data)

# Generated at 2022-06-21 00:25:03.278978
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

    # _collections is not their
    assert(search._collections is None)

    # check the we get a list of two items
    assert(len(search._load_collections('_collections',['ansible.builtin','ansible.legacy'])) == 2)

# Generated at 2022-06-21 00:25:29.771446
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == _ensure_default_collection()

# Generated at 2022-06-21 00:25:35.250890
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == 'ansible.builtin, ansible.legacy'
    cs.collections = 'test'
    assert cs.collections == 'test, ansible.builtin, ansible.legacy'
    cs.collections = 'test, test1'
    assert cs.collections == 'test, test1, ansible.builtin, ansible.legacy'

# Generated at 2022-06-21 00:25:35.702875
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-21 00:25:47.121091
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def_coll_name = AnsibleCollectionConfig.default_collection

    # check empty
    c1 = CollectionSearch()
    c2 = CollectionSearch(collections=None)
    coll = c1._collections
    assert coll == [def_coll_name]
    coll = c1._load_collections('collections', [])
    assert coll is None
    coll = c2._load_collections('collections', None)
    assert coll is None

    # check non empty
    c1 = CollectionSearch(collections=['mycoll:mynamespace'])
    coll = c1._load_collections('collections', ['mycoll:mynamespace'])
    assert coll == ['mycoll:mynamespace', def_coll_name]
    c2 = CollectionSearch(collections=['mycoll'])
    coll = c2

# Generated at 2022-06-21 00:25:49.402156
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections is not None
    assert search._collections == ['ansible.builtin']



# Generated at 2022-06-21 00:25:51.550524
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:26:00.134742
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    
    # Test constructor
    collection_search = CollectionSearch()
    assert collection_search._collections is not None
    assert collection_search._collections.meta['static'] == True
    
    # Test _ensure_default_collection
    collection_list1 = _ensure_default_collection()
    assert collection_list1 == [AnsibleCollectionConfig.default_collection] if AnsibleCollectionConfig.default_collection else []
    collection_list2 = _ensure_default_collection(collection_list=['collection1', 'collection2'])
    assert collection_list2 == ['collection1', 'collection2', 'ansible.legacy']
    collection_list3 = _ensure_default_collection(collection_list=['collection1', AnsibleCollectionConfig.default_collection, 'collection2'])

# Generated at 2022-06-21 00:26:03.531087
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    test_val = "ansible.posix"

    c.collections = test_val

    assert c._collections == [test_val]

# Generated at 2022-06-21 00:26:05.607291
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:26:16.741260
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestClass(AnsibleCollectionConfig, CollectionSearch):
        def __init__(self, data):
            super(TestClass, self).__init__()
            self.__initialized = True
            self._load_data(data)

    data = {'collections': ['collection_1']}
    tc = TestClass(data)
    assert tc.collections == ['collection_1', 'ansible.legacy']

    data = {'collections': ['collection_1', 'ansible.builtin']}
    tc = TestClass(data)
    assert tc.collections == ['collection_1', 'ansible.builtin']

    data = {'collections': ['collection_1', 'ansible.builtin', 'ansible.legacy']}
    tc = TestClass(data)

# Generated at 2022-06-21 00:27:20.862276
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection

# Generated at 2022-06-21 00:27:23.485008
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Instantiate the class
    obj = CollectionSearch()
    # Check the value of private variable `_collections`
    print(obj._collections)

# Generated at 2022-06-21 00:27:24.828405
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), object)



# Generated at 2022-06-21 00:27:37.957192
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an instance of CollectionSearch
    collection_search = CollectionSearch()
    # Check the collections property of the class
    assert collection_search.collections == None
    # Check that the default collection is always first
    collection_list = ['namespace.collection_name']
    assert _ensure_default_collection(collection_list=collection_list) == ['namespace.collection_name', 'ansible.builtin.oracle']

    # Test case where collection_list is None
    assert _ensure_default_collection(collection_list=None) == ['ansible.builtin.oracle']
    # Test case where collections is an empty list
    collection_list = []
    assert _ensure_default_collection(collection_list=collection_list) == ['ansible.builtin.oracle']

# Generated at 2022-06-21 00:27:40.813597
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.base']
    cs = CollectionSearch(collections=['custom_collection'])
    assert cs.collections == ['custom_collection']

# Generated at 2022-06-21 00:27:42.089891
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x.collections == x._collections

# Generated at 2022-06-21 00:27:43.693023
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert result._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:27:45.458338
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch(collections=['ansible.builtin'])
    assert cs._collections == ['ansible.builtin']

# Generated at 2022-06-21 00:27:46.577973
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) is None

# Generated at 2022-06-21 00:27:47.628214
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch()._load_collections('collections', []), list)

# Generated at 2022-06-21 00:30:06.788345
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	collectionSearch = CollectionSearch()
	assert collectionSearch is not None

# Generated at 2022-06-21 00:30:11.141366
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    colleciton_search = CollectionSearch()
    assert colleciton_search._collections == _ensure_default_collection()
    assert colleciton_search._load_collections("collections",None) == None

# Generated at 2022-06-21 00:30:12.874756
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch() is not None

# Generated at 2022-06-21 00:30:20.421473
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	collections = "collections"
	ds = "ds"
	attr = "attr"
	attr_val = "attr_val"
	_load_collections = "load_collections"
	
	# Create the object from class CollectionSearch
	obj = CollectionSearch()
	obj.collections = collections
	obj._collections = collections
	obj._load_collections = _load_collections
	
	# Check if the attr is created properly
	#assert obj.attr == attr_val

# Generated at 2022-06-21 00:30:22.617492
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:30:28.333132
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test = CollectionSearch()
        assert test._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']
        assert test._load_collections(None, []) == ['ansible.legacy']
    except AssertionError:
        assert False, "The test case has failed"

# Generated at 2022-06-21 00:30:31.601446
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()
    assert type(obj) is CollectionSearch

# Generated at 2022-06-21 00:30:42.489028
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute import Attribute, FieldAttribute

    class CollectionSearch(object):
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)

        def __init__(self):
            self._attribute_values = Attribute()

        def get_validated_value(self, attr, field, ds, fail_on_undefined=True):
            return field.post_validate(self._attribute_values, attr, self)

    cs = CollectionSearch()
    collection_list = ['ansible.builtin', 'ansible.legacy']
    cs._attribute_values.value = collection_list
    cs._collections = collection_list
    ds = cs

# Generated at 2022-06-21 00:30:45.829936
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._load_collections(None, None) == ['ansible_collections.test_namespace.test_collection']

# Generated at 2022-06-21 00:30:48.619510
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_name = CollectionSearch()
    assert test_name.collections == ['ansible.builtin']