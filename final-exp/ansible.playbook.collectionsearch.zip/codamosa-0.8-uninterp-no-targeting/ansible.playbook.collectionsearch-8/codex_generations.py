

# Generated at 2022-06-21 00:21:55.041538
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    
    cs = CollectionSearch()
    assert len(cs._collections) == 1

# Generated at 2022-06-21 00:22:02.649765
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # Test the constructor
    assert cs and isinstance(cs, CollectionSearch)

    # Test the _load_collections() method
    assert cs._load_collections(None, None) == None

    # Test the _load_collections() method
    assert cs._load_collections(None, 'collections=geerlingguy.ansible-role-docker') == ['geerlingguy.ansible-role-docker', 'ansible.builtin']



# Generated at 2022-06-21 00:22:04.418907
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    print(collectionsearch._load_collections('collections', None))

# Generated at 2022-06-21 00:22:09.360694
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.collections = ['ansible.builtin']
    assert collection_search._load_collections('collections', ['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']
    assert collection_search.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:22:10.546923
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        _ = CollectionSearch()
        assert True
    except:
        assert False

# Generated at 2022-06-21 00:22:22.780574
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Get an instance of class CollectionSearch
    obj = CollectionSearch()

    # Let's create a sample list

# Generated at 2022-06-21 00:22:24.831006
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    ds = CollectionSearch()
    new_value = _ensure_default_collection()
    assert ds._collections.default == new_value

# Generated at 2022-06-21 00:22:34.173879
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection=CollectionSearch()
    assert(len(collection._collections.default) == 1)
    assert(collection._collections.default[0] == 'ansible.builtin')
    from ansible.constants import DEFAULT_COLLECTIONS_PATHS
    from ansible.module_utils.six.moves.configparser import ConfigParser
    config=ConfigParser()
    config.read(DEFAULT_COLLECTIONS_PATHS)
    assert(config.get('defaults', 'collections_paths'))
    assert('extras=' in config.get('defaults', 'roles_path'))
    assert('extras=' in config.get('defaults', 'action_plugins'))
    assert('extras=' in config.get('defaults', 'lookup_plugins'))

# Generated at 2022-06-21 00:22:37.935046
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    print(c._collections)
    c._load_collections("collections", ["ansible.builtin","collection.community.general"])

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-21 00:22:39.512832
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert 'ansible.builtin' in cs._collections

# Generated at 2022-06-21 00:22:49.210825
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    if c._collections._default != _ensure_default_collection:
        raise AssertionError('Tests failed: CollectionSearch')

# Generated at 2022-06-21 00:22:51.046526
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == cs._collections



# Generated at 2022-06-21 00:22:52.762860
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == ['ansible.builtin']

# Generated at 2022-06-21 00:22:59.600736
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.playbook.play_context import PlayContext

    collection_search = CollectionSearch()

    class Plug1:
        def __init__(self, name):
            self.name = name

        def v  (self, args, kwargs):
            print("name: %s, args: %s, kwargs: %s" % (self.name, args, kwargs))

    class Plug2:
        def __init__(self, name):
            self.name = name

        def v  (self, args, kwargs):
            print("name: %s, args: %s, kwargs: %s" % (self.name, args, kwargs))

    plug1 = Plug1("plug1")
    plug2 = Plug2("plug2")

    collection_search._plugin_type_validators

# Generated at 2022-06-21 00:23:01.967263
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search._collections)

test_CollectionSearch()

# Generated at 2022-06-21 00:23:09.774899
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    result_collection_search = test_CollectionSearch._collections('collections', 'ds')
    assert result_collection_search == ['ansible.builtin']
    assert test_CollectionSearch._collections('collections', []) == ['ansible.builtin']
    assert test_CollectionSearch._collections('collections', []) == ['ansible.builtin']
    assert test_CollectionSearch._collections('collections', []) == ['ansible.builtin']

# Generated at 2022-06-21 00:23:11.589517
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        CollectionSearch().collections
    except Exception:
        raise AssertionError


# Generated at 2022-06-21 00:23:20.778203
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task import Task

    collection_search = CollectionSearch()
    collection_search._load_collections(ds=[])
    assert collection_search._collections == ['ansible.builtin']

    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible.builtin']

    task = Task()
    task._load_collections(ds=['foo'])
    assert task._collections == ['foo', 'ansible.builtin']

    role_include = RoleInclude()
    role_include._load_collections(ds=['foo'])
    assert role_include._collections == ['foo', 'ansible.builtin']

# Generated at 2022-06-21 00:23:23.648939
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ['col1', 'col2']
    assert cs.collections == ['col1', 'col2']

# Generated at 2022-06-21 00:23:32.788829
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test _load_collections, constructor
    cs = CollectionSearch()
    assert cs._collections is None
    assert cs.args is None
    assert cs._validate_attrs_called is False
    assert cs._validate_attrs_called is False
    assert cs._cache_validated_value('collections', None, None, None) is None
    assert cs._cache_validated_value('args', None, None, None) is None
    assert cs._validate_attrs_called is False
    assert cs._validate_attrs_called is False
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:46.983875
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:55.943501
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._ensure_default_collection(['redhat.myapp']) == ['redhat.myapp', 'ansible_collections.ansible.builtin']
    assert CollectionSearch._ensure_default_collection(['ansible_collections.ansible.builtin']) == ['ansible_collections.ansible.builtin']
    assert CollectionSearch._ensure_default_collection([]) == ['ansible_collections.ansible.builtin']
    assert CollectionSearch._ensure_default_collection() == ['ansible_collections.ansible.builtin']

# Generated at 2022-06-21 00:24:04.122372
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    klass = CollectionSearch()
    assert klass._collections.default == _ensure_default_collection
    assert klass._collections.attribute_name == 'collections'
    assert klass._collections.static == True
    assert klass._collections.always_post_validate == True
    assert klass.get_validated_value('collections', klass._collections, None, None) is None
    assert klass.get_validated_value('collections', klass._collections, [], None) is not None
    assert klass.get_validated_value('collections', klass._collections, [], None) == ['ansible.builtin']

# Generated at 2022-06-21 00:24:05.715826
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test __new__
    obj = CollectionSearch()
    assert obj.collections == _ensure_default_collection()
    assert obj._collections.should_post_validate

# Generated at 2022-06-21 00:24:14.565745
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Create one object of class CollectionSearch and test_instantiation
    seach = CollectionSearch()
    assert seach.__class__.__name__ == "CollectionSearch"

    # Test _load_collections
    collection = ['ansible']
    env = Environment()
    for collection_name in collection:
        assert is_template(collection_name, env)
    # Validate the warninig message printed in case of failing the test
    assert display.warning('"collections" is not templatable, but we found: %s, '
                                'it will not be templated and will be used "as is".' % (collection))

# Generated at 2022-06-21 00:24:16.336682
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections.default(_ensure_default_collection)

# Generated at 2022-06-21 00:24:21.682814
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition

    c = CollectionSearch()
    # Test if collections attribute is set properly
    assert c.collections == _ensure_default_collection()

    # Test if _load_collections function is working properly
    assert c._load_collections('collections', ['test_collection']) == ['test_collection', 'ansible.builtin']

# Generated at 2022-06-21 00:24:22.987225
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs._collections, FieldAttribute)

# Generated at 2022-06-21 00:24:25.950210
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    sl = CollectionSearch()
    sl._collections = ['ansible.builtin', 'ansible.legacy']
    sl._validate_namespace('collections', sl._collections)


# Generated at 2022-06-21 00:24:27.302988
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch("test_playbook")
    # TODO - this class was clearly a place holder for something else

# Generated at 2022-06-21 00:24:46.041119
# Unit test for constructor of class CollectionSearch

# Generated at 2022-06-21 00:24:47.490294
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert not collection_search is None

# Generated at 2022-06-21 00:24:48.193684
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

# Generated at 2022-06-21 00:24:52.728702
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = "default_collection"
    assert cs.collections == _ensure_default_collection(["default_collection"])

    cs.collections = ["default_collection"]
    assert cs.collections == _ensure_default_collection(["default_collection"])

# Generated at 2022-06-21 00:25:04.276494
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_class = CollectionSearch()
    test_instance = test_class.__class__()
    assert isinstance(test_instance.collections, FieldAttribute)
    assert isinstance(test_instance._load_collections, types.MethodType)
    assert isinstance(test_instance._collections, FieldAttribute)
    assert test_instance.collections.isa == 'list'
    assert test_instance.collections.listof == string_types
    assert test_instance.collections.priority == 100
    assert test_instance.collections.default == _ensure_default_collection
    assert test_instance.collections.always_post_validate == True
    assert test_instance.collections.static == True
    assert test_instance._collections.isa == 'list'
    assert test_instance._collections.listof == string_types

# Generated at 2022-06-21 00:25:06.360364
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj.construct()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:25:09.432117
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # default collection list
    obj = CollectionSearch()
    assert obj._collections is None

    # custom collection list
    obj = CollectionSearch(collections=['foo.bar'])
    assert obj._collections == ['foo.bar']

# Generated at 2022-06-21 00:25:16.312520
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_searcher = CollectionSearch()
    # Check if col_searcher is an instance of CollectionSearch
    print(isinstance(col_searcher, CollectionSearch))
    # Check if the attribute _collections is created and has the correct field attribute values
    print(col_searcher._collections.key == 'collections')
    print(col_searcher._collections.isa == 'list')
    print(col_searcher._collections.listof == string_types)
    print(col_searcher._collections.priority == 100)
    print(col_searcher._collections.default == _ensure_default_collection)
    print(col_searcher._collections.always_post_validate == True)
    print(col_searcher._collections.static == True)

# Generated at 2022-06-21 00:25:21.010324
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

    cs = CollectionSearch(collections="ansible.posix, test_namespace")
    assert cs._collections == ["ansible.posix", "test_namespace"]

# Generated at 2022-06-21 00:25:24.960283
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    object1 = CollectionSearch()
    object1._collections = ['ansible.builtin', 'ansible.netcommons', 'ansible.ansible_collections']
    object1.__dict__['_collections'] = object1._collections
    print(object1.collections)

# Generated at 2022-06-21 00:25:59.837867
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    import os

    loader = DataLoader()
    play_context = PlayContext()
    path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    file_name = os.path.join(path, 'test_block_loader/test_block.yml')
    play_source =  dict(
        name ="Ansible Play",
        hosts='local',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello World!')))
        ]
    )


# Generated at 2022-06-21 00:26:06.901925
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base

    collection = Base()
    collection._collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)
    assert isinstance(collection, Base)
    assert isinstance(collection, CollectionSearch)
    assert isinstance(collection._collections, FieldAttribute)

# Generated at 2022-06-21 00:26:17.827326
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.loader import become_loader

    context = PlayContext()
    context.become = True
    become_plugin = become_loader._get_become_plugin(context)
    become_plugin.validate()

    play = Play().load({'hosts': 'host1', 'gather_facts': 'no',
                        'tasks': [{'name': 'Task1', 'action': 'debug', 'msg': '1'}]}, variable_manager=None, loader=None)


# Generated at 2022-06-21 00:26:19.041868
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None

# Generated at 2022-06-21 00:26:21.345357
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections.default == ['ansible']
    assert search._load_collections(None, None) == ['ansible']

# Generated at 2022-06-21 00:26:22.430764
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    cs = CollectionSearch()
    assert cs

# Generated at 2022-06-21 00:26:26.213415
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.collections = [ "ansible.builtin", "my_namespace.my_collection"]
    assert search.collections == ["ansible.builtin", "my_namespace.my_collection"]

# Generated at 2022-06-21 00:26:32.744142
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # _collections will be validated in self.get_validated_value()
    #   collection_list is None
    #   default_collection is ansible.builtin
    #   ansible.builtin is inserted into collections list
    #   ansible.legacy is appended to the collections list
    #   the collections list is returned
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:26:36.631435
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['ansible.builtin', 'ansible.legacy']
    assert c._collections == _ensure_default_collection(collection_list=[])
    assert c._collections != _ensure_default_collection(collection_list=['foo.bar'])

# Generated at 2022-06-21 00:26:42.066271
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    default_collections = AnsibleCollectionConfig.default_collection
    cs._collections = None

    # Direct assignment via property
    assert cs.collections == default_collections

    # Getter method
    assert cs.get_collections() == default_collections

    # Assignment via property
    cs.collections = []
    assert cs.collections == []

    # Getter method
    assert cs.get_collections() == []



# Generated at 2022-06-21 00:27:47.282750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ds = cs._load_collections(None, None)
    assert isinstance(ds, list)
    assert "ansible.builtin" in ds

# Generated at 2022-06-21 00:27:48.968552
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections._collections == 'ansible.builtin'
    assert collections._collections == 'ansible.builtin'

# Generated at 2022-06-21 00:27:50.386108
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections == 'ansible.legacy'

# Generated at 2022-06-21 00:27:53.405544
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default is not None, "Default value of _collections not set"
    assert CollectionSearch._collections.static, "Field is not static"

# Generated at 2022-06-21 00:27:55.441071
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search._load_collections()
    assert collection_search._collections.default is _ensure_default_collection

# Generated at 2022-06-21 00:27:56.721006
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()


# Generated at 2022-06-21 00:27:58.210013
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is not None

# Generated at 2022-06-21 00:27:59.735003
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch
    assert hasattr(collection_search, '_collections')

# Generated at 2022-06-21 00:28:05.115903
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    # assert isinstance(c, AnsibleCollectionConfig), 'CollectionSearch().collections should be an AnsibleCollectionConfig'
    assert c.collections[0].startswith('ansible'), \
        'CollectionSearch().collections[0] should be ansible.builtin or ansible.legacy'


if __name__ == '__main__': 
    test_CollectionSearch()

# Generated at 2022-06-21 00:28:08.313951
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert AnsibleCollectionConfig.default_collection == "ansible.builtin"
    c = CollectionSearch()
    assert c._collections == [AnsibleCollectionConfig.default_collection]
    assert c._collections == ["ansible.builtin"]

# Generated at 2022-06-21 00:29:32.942567
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    # _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
    # always_post_validate=True, static=True)
    assert c._collections.isa == 'list'
    assert c._collections.listof == string_types
    assert c._collections.priority == 100
    assert c._collections.default == _ensure_default_collection
    assert c._collections.always_post_validate == True
    assert c._collections.static == True

    # assert isinstance(c._collections.default, FieldAttribute)
    # assert isinstance(getattr(CollectionSearch, '_collections'), FieldAttribute)

    # collections = FieldAttribute(isa='list', listof=string_types, priority=100

# Generated at 2022-06-21 00:29:41.062078
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) == ['ansible_collections.ansible.builtin', 'ansible.legacy']
    assert cs._load_collections(None, ['']) == ['ansible_collections.ansible.builtin', 'ansible.legacy']
    assert cs._load_collections(None, ['', '']) == ['ansible_collections.ansible.builtin', 'ansible.legacy']
    assert cs._load_collections(None, ['my.namespace']) == ['my.namespace', 'ansible_collections.ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:29:41.841345
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == ['ansible.builtin']

# Generated at 2022-06-21 00:29:53.741165
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    b = AnsibleCollectionConfig.default_collection
    print(a._collections)
    assert(a._collections == [b])
    print(a.__dict__)
    print(a.__hash__())
    print(type(a))
    assert(type(a) == CollectionSearch)
    assert(type(a) != dict)
    assert(type(a) != list)
    print(a.__module__)
    assert(a.__module__ == 'ansible.playbook.collection_loader')
    a.__delattr__('_collections')
    assert(a._collections == None)

# test code
if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-21 00:30:00.341958
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    def_col = AnsibleCollectionConfig.default_collection
    if def_col is None:
        assert cs._collections == [None]
    else:
        assert cs._collections == [def_col]
    AnsibleCollectionConfig.default_collection = None
    def_col = AnsibleCollectionConfig.default_collection
    assert def_col is None
    assert cs._collections == [None]
    AnsibleCollectionConfig.default_collection = 'my.collection'
    cs._collections = None
    assert cs._collections == [None]
    cs._collections = []
    assert cs._collections == [None]
    cs._collections = ['ansible.builtin']
    assert cs._collections == [None]
    cs._collections = ['my.collection']
    assert cs._col

# Generated at 2022-06-21 00:30:07.343955
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test no collection
    cs = CollectionSearch()
    cs.collections = []
    assert not cs.collections

    # test with one collection
    cs.collections = ['my_collection']
    assert cs.collections == ['my_collection']

    # test with default collection
    cs.collections = None
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-21 00:30:13.856607
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # A empty list to store the collections
    collection_list = []
    # A test to check that a collection is created and added to the
    # collection_list
    collection_search_test = CollectionSearch()
    assert collection_search_test._collections(collection_list) == _ensure_default_collection()

# Generated at 2022-06-21 00:30:18.263512
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    print(a._collections)
    print(a._load_collections('a', 'b'))

test_CollectionSearch()

# Generated at 2022-06-21 00:30:20.578234
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()



# Generated at 2022-06-21 00:30:31.552170
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()