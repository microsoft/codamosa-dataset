

# Generated at 2022-06-21 00:22:01.541412
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() is not None
    assert _ensure_default_collection() == ['ansible.legacy']
    assert _ensure_default_collection('ansible.builtin') is not None
    assert _ensure_default_collection('ansible.builtin') == ['ansible.builtin', 'ansible.legacy']
    assert _ensure_default_collection(None) is not None
    assert _ensure_default_collection(None) == ['ansible.legacy']

# Generated at 2022-06-21 00:22:11.134034
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    search = CollectionSearch(display)

    valid_collections = ['ansible.builtin', 'demo.valid_collection_name']
    search.collections = ['ansible.builtin', 'demo.valid_collection_name']
    assert search.collections == valid_collections

    search.collections = ['ansible.builtin', 'demo.valid_collection_name', 'demo.valid_collection_name']
    assert search.collections == valid_collections

    search.collections = ['ansible.builtin', 'demo.valid_collection_name', 'demo.valid_collection_name', 'ansible.builtin']
    assert search.collections == valid_collections

    search.collections = ['ansible.builtin']

# Generated at 2022-06-21 00:22:14.129030
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == [AnsibleCollectionConfig.default_collection, 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:22:22.633696
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    display.vvvv = True
    obj = CollectionSearch()
    obj.post_validate()
    # No errors
    obj.collections = ['test']
    obj.post_validate()
    obj.collections = '{{test}}'
    obj.post_validate()
    # Test for {{ }} error
    obj.collections = ['{{test}}']
    obj.post_validate()
    # Test for [ ] error
    obj.collections = ['[ ]']
    obj.post_validate()

# Generated at 2022-06-21 00:22:27.431348
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)
    #assert isinstance(CollectionSearch(), Base)
    #assert isinstance(CollectionSearch(), object)
    assert issubclass(CollectionSearch, object)
    assert CollectionSearch.__name__ == 'CollectionSearch'
    assert CollectionSearch.__module__ == __name__


# Generated at 2022-06-21 00:22:29.215997
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert isinstance(collections, CollectionSearch)


# Generated at 2022-06-21 00:22:29.827267
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-21 00:22:31.216419
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testobj=CollectionSearch()
    testobj.post_validate()

# Generated at 2022-06-21 00:22:33.950540
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is not None
    assert cs.collections[0] == 'ansible.builtin' or cs.collections[0] == 'ansible.legacy'

# Generated at 2022-06-21 00:22:35.546405
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print('obj is: {0}'.format(obj))

# Generated at 2022-06-21 00:22:44.578901
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    print("collections = " + str(collections))


# Test for the constructor of class CollectionSearch
test_CollectionSearch()

# Generated at 2022-06-21 00:22:46.898144
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_CollectionSearch = CollectionSearch()
    assert my_CollectionSearch._collections.default == _ensure_default_collection()

# Generated at 2022-06-21 00:22:48.579430
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert isinstance(a, CollectionSearch)



# Generated at 2022-06-21 00:22:50.147088
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_search = CollectionSearch()
    assert coll_search is not None

# Generated at 2022-06-21 00:22:54.462156
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Unit test for post_validate_collections()
    assert CollectionSearch()._collections.post_validate(_ensure_default_collection, None)

    # Unit test for _load_collections()
    assert CollectionSearch()._load_collections('collections', None) is None


# Generated at 2022-06-21 00:22:55.642949
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:22:59.460153
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.static == True
    assert CollectionSearch._collections.always_post_validate == True

# Generated at 2022-06-21 00:23:02.207544
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections == ['ansible.builtin', 'ansible.legacy', 'ansible.builtin.core']

# Generated at 2022-06-21 00:23:03.507795
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection


# Generated at 2022-06-21 00:23:14.399090
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.playbook.attribute import FieldAttribute

    # Ensure collection is None
    cs = CollectionSearch()
    assert cs._collections._default == _ensure_default_collection
    assert cs.get_validated_value('collections', cs._collections, None, None) is None

    # Ensure collection is not None
    assert type(cs._collections) == FieldAttribute
    assert cs._collections._isa == 'list'
    assert cs._collections._listof == string_types
    assert cs._collections._priority == 100
    assert cs._collections._default == _ensure_default_collection
    assert cs._collections._always_post_validate
    assert cs._collections._static
    assert cs.get_validated_value

# Generated at 2022-06-21 00:23:24.015265
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj
    assert obj._collections
    assert obj._collections.get_empty_value() == _ensure_default_collection()


# Generated at 2022-06-21 00:23:29.410866
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.playbook.role_include import IncludeRole

    class TestCollectionSearch(CollectionSearch, IncludeRole):
        pass

    include_role_test = TestCollectionSearch()
    include_role_test.post_validate(validate_templated=False)

    assert isinstance(include_role_test, IncludeRole)
    assert isinstance(include_role_test, CollectionSearch)

# Generated at 2022-06-21 00:23:37.234676
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search =  CollectionSearch()
    assert(len(collection_search._collections.default) == 1)
    assert('ansible.builtin' in collection_search._collections.default)

    collections = collection_search._load_collections('collections', 'ansible.netcommon')
    assert(collections == ['ansible.netcommon','ansible.builtin'])
    collections = collection_search._load_collections('collections', None)
    assert(collections is None)

# Generated at 2022-06-21 00:23:38.524387
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == cs.collections
    assert cs.collections is not None

# Generated at 2022-06-21 00:23:40.396437
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        class_object = CollectionSearch()
    except:
        assert False, 'Failed to create CollectionSearch() class object'

# Generated at 2022-06-21 00:23:42.567987
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections is not None
    assert "ansible.legacy" in x._collections
    assert "ansible.builtin" in x._collections

# Generated at 2022-06-21 00:23:53.948225
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.base import Base
    from ansible.plugins.loader import collection_loader
    from ansible.vars.clean import module_response_deepcopy

    # create base class object
    base = Base()

    # create role object
    role = RoleDefinition(base=base)

    # populate collections in base class object 
    base.collections = ['ansible.builtin', 'ansible.junos']

    # populate name in role object
    role.name = 'ansible.junos'

    # import role from role object
    collection_loader.load_collections([role.name])
    role_metadata = collection_loader._collections[role.name].get_role_metadata(role=role)

    # create new role from role_

# Generated at 2022-06-21 00:23:57.378545
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test:
        collect = CollectionSearch()

    t = Test()
    t.collect._load_collections(None, None)
    t.collect._load_collections(None, [])

# Generated at 2022-06-21 00:24:01.526826
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass
#     ModelData = collections.namedtuple('ModelData', ['collection_list'])
#     _CollectionSearch = CollectionSearch._load_collections(self, ds)
#     print(_CollectionSearch)
#     ModelData.collection_list.append('ansible.legacy')

# Generated at 2022-06-21 00:24:02.373150
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:24:17.941141
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test exists
    collection = CollectionSearch()
    # Test fields
    assert '_collections' in collection.__dict__
    assert isinstance(collection.collections, str)

# Generated at 2022-06-21 00:24:21.682060
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, []) == _ensure_default_collection([])
    assert cs._load_collections(None, None) == _ensure_default_collection(None)

# Generated at 2022-06-21 00:24:30.140437
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.plugins.loader import connection_loader
    from ansible.utils import plugin_docs

    from ansible.errors import AnsibleUndefinedVariable
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class TestCollectionSearch(Base, CollectionSearch):
        pass

    play = TestCollectionSearch()

    assert play.collections is None

    play._validate_attributes()

    assert play.collections == ['ansible_collections.ns.collection']

    # This is required because we are importing connection, but the unit tests
    # don't initialize this plugin.
    plugin_docs.connection_loader = connection_loader

    play.collections = '{{ foo }}'
    play._validate_attributes()
    assert play.collections is None

    play

# Generated at 2022-06-21 00:24:38.323795
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()
    test_value = ['test', ['test_1', 'test_2']]

    # Test setting the value and verifying it
    test_object.set_value('collections', test_value[0])
    assert(test_object.get_value('collections') == test_value[0])

    # Test setting the value and verifying that it is not in the output
    test_object.set_value('collections', test_value[1])
    assert(test_object.get_value('collections') == test_value[1])

# Generated at 2022-06-21 00:24:39.120755
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert 'ansible.builtin' in CollectionSearch()._collections

# Generated at 2022-06-21 00:24:44.965056
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()
    # test for _load_collections
    obj._collections = [1, 2, 3]
    assert obj._collections == _ensure_default_collection([1, 2, 3])
    obj._collections = ['ansible.builtin', 'ansible.builtin']
    assert obj._collections == ['ansible.builtin']

# Generated at 2022-06-21 00:24:55.966968
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test _ensure_default_collection()
    assert _ensure_default_collection(None) == []

    assert _ensure_default_collection(['foo']) == ['foo', 'ansible.builtin']

    assert _ensure_default_collection(['ansible.builtin', 'foo']) == ['ansible.builtin', 'foo']

    assert _ensure_default_collection(['ansible.legacy', 'foo']) == ['ansible.legacy', 'foo']

    # Test _load_collections()
    assert CollectionSearch._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin']

    assert CollectionSearch._load_collections('collections', ['ansible.legacy']) == ['ansible.legacy']


# Generated at 2022-06-21 00:25:02.882230
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()
    assert c._load_collections("collections", []) == _ensure_default_collection([])
    assert c._load_collections("collections", None) == _ensure_default_collection()

    # should not be able to set collections attribute
    try:
        c.collections = [1, 2, 3]
        assert False
    except AttributeError:
        pass

# Generated at 2022-06-21 00:25:12.284722
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.roles import Roles
    from ansible.plugins.loader import collection_loader

    colls = CollectionSearch()
    collection_loader.all_collections = None
    colls._collections = _ensure_default_collection(['foobar', 'ansible.builtin'])
    assert colls._collections == ['ansible.builtin', 'foobar']

    play = Playbook()
    play._collections = ['ansible.builtin', 'foobar']
    assert play._

# Generated at 2022-06-21 00:25:21.201649
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    RoleData = type('RoleData', (CollectionSearch,), {})
    assert None == RoleData()._load_collections('collections', None)
    assert ['my_collections'] == RoleData(collections=['my_collections'])._load_collections('collections', ['my_collections'])
    assert ['ansible.builtin'] == RoleData(collections=['my_collections'])._load_collections('collections', None)
    assert ['ansible.builtin'] == RoleData(collections=[])._load_collections('collections', None)

# Generated at 2022-06-21 00:25:50.715614
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.utils import context_objects as co
    co.GlobalCLIArgs()
    co.GlobalCLIConfig()

    search = CollectionSearch()
    assert not search._collections.value

# Generated at 2022-06-21 00:25:53.462613
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = []
    collection_list = CollectionSearch._ensure_default_collection(collection_list=ds)
    assert collection_list == [AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-21 00:25:54.824476
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert not CollectionSearch()._collections._has_been_set

# Generated at 2022-06-21 00:25:56.333057
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert 'ansible.builtin' in cs.collections

# Generated at 2022-06-21 00:26:03.577932
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.post_validate('', {'collections': []})
    assert search.collections is None
    assert search._collections is None
    search.post_validate('', {'collections': ['/tmp/test']})
    assert search.collections == ['/tmp/test']
    assert search._collections == ['/tmp/test']

# Generated at 2022-06-21 00:26:05.659110
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection.collections == ['ansible.builtin']


# Generated at 2022-06-21 00:26:16.779621
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test constructor with default collections.
    search_obj = CollectionSearch()
    assert search_obj._load_collections('collections', None)
    assert search_obj._load_collections('collections', [])

    # Test constructor without default collections.
    # FIXME: The behavior of field attribute instantiation is wrong. Setting default to empty list
    # breaks the unit test and causes an issue in integration tests.
    search_obj = CollectionSearch()
    search_obj._collections.default = []
    assert search_obj._load_collections('collections', None) == []
    assert search_obj._load_collections('collections', [])

    # Test constructor with default collections and custom collection.
    search_obj = CollectionSearch()

# Generated at 2022-06-21 00:26:17.993804
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is not None

# Generated at 2022-06-21 00:26:19.685512
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == ['ansible.posix', 'ansible.builtin']

# Generated at 2022-06-21 00:26:25.052749
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    result = c._load_collections('collections', None)
    # The Default Collection Name is 'ansible.builtin'
    # because when there be no 'default_collection' (it will be None)
    # so '_ensure_default_collection' function will return [ansible.built-in]
    assert result == ['ansible.builtin']



# Generated at 2022-06-21 00:27:33.961256
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert ['ansible.builtin'] == cs._load_collections

# Generated at 2022-06-21 00:27:43.819681
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_data = [
        {
            'value': ['my.collection'],
            'expected_value': ['my.collection', 'ansible.builtin'],
        },
        {
            'value': ['ansible.builtin', 'my.collection'],
            'expected_value': ['ansible.builtin', 'my.collection'],
        },
        {
            'value': ['ansible.legacy', 'my.collection'],
            'expected_value': ['ansible.legacy', 'my.collection'],
        },
        {
            'value': [],
            'expected_value': ['ansible.builtin'],
        },
    ]
    for test in test_data:
        cs = CollectionSearch()
        result = cs._load_collections('collections', test['value'])
       

# Generated at 2022-06-21 00:27:46.726541
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.errors import AnsibleError

    class MyCollectionSearch(CollectionSearch):
        pass

    with pytest.raises(AnsibleError):
        MyCollectionSearch()

    MyCollectionSearch.load_collections = lambda self: None
    MyCollectionSearch()

# Generated at 2022-06-21 00:27:53.839137
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.__dict__['_collections'].default == _ensure_default_collection
    assert collection_search.__dict__['_collections'].always_post_validate == True
    assert collection_search.__dict__['_collections'].static == True
    assert collection_search._load_collections("collections", ["ansible.builtin"]) == ['ansible.builtin', 'ansible.builtin']

# Generated at 2022-06-21 00:28:01.370143
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_list = ['ns1.test_collection']
    col_search = CollectionSearch()
    default_collection = AnsibleCollectionConfig.default_collection
    if default_collection and default_collection not in test_collection_list:
        new_collection_list = [default_collection]
        new_collection_list.extend(test_collection_list)
    else:
        new_collection_list = test_collection_list
    ret_collection_list = col_search._load_collections(0, test_collection_list)
    assert ret_collection_list == new_collection_list

# Generated at 2022-06-21 00:28:05.246572
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search._collections = [
        'contributed.nsntrace',
        'ansible.builtin',
        'ansible.legacy']

    # test _load_collections function
    search._load_collections("", "")

# Generated at 2022-06-21 00:28:12.347958
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert s.__dict__['_collections']['default'] == _ensure_default_collection.__defaults__[0]
    assert s.__dict__['_collections']['type'] == 'list'
    assert s.__dict__['_collections']['priority'] == 100
    assert s.__dict__['_collections']['always_post_validate']
    assert s.__dict__['_collections']['static']
    assert s.__dict__['_collections']['isa'] == 'list'
    assert s.__dict__['_collections']['listof'] == string_types


# Generated at 2022-06-21 00:28:13.330269
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection

# Generated at 2022-06-21 00:28:22.523037
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    try:
        AnsibleCollectionConfig.default_collection = 'ansible.builtin'
        block = Block()
        task = Task()
        role = Role()

        assert block.collections == ['ansible.builtin']
        assert block.collections is not None
        assert task.collections == ['ansible.builtin']
        assert task.collections is not None
        assert role.collections == ['ansible.builtin']
        assert role.collections is not None
        assert task.collections == block.collections
        assert role.collections == block.collections
    finally:
        AnsibleCollectionConfig.default_collection = None

# Generated at 2022-06-21 00:28:23.739103
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == ['ansible.legacy']

# Generated at 2022-06-21 00:30:46.476394
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch(collections=['mycollection'])

    assert cs.get_value('collections') == ['mycollection']

# Generated at 2022-06-21 00:30:48.160616
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert is_instance(CollectionSearch(), CollectionSearch)

# Generated at 2022-06-21 00:30:49.414405
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch() 
    print(cs._collections)

# Generated at 2022-06-21 00:30:51.816870
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:30:54.919404
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin'] or cs.collections == ['ansible.legacy']

# Generated at 2022-06-21 00:30:59.110490
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs._collections)
    assert cs._load_collections(None, None) == ['builtin']

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:31:10.691142
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # collectionsearch_obj = CollectionSearch
    collectionsearch_obj = CollectionSearch()
    assert isinstance(collectionsearch_obj._collections, FieldAttribute)
    assert isinstance(collectionsearch_obj._collections.isa, string_types)
    assert isinstance(collectionsearch_obj._collections.listof, string_types)
    assert isinstance(collectionsearch_obj._collections.priority, int)
    assert isinstance(collectionsearch_obj._collections.default, type(_ensure_default_collection))
    assert isinstance(collectionsearch_obj._collections.always_post_validate, bool)
    assert isinstance(collectionsearch_obj._collections.static, bool)

# Generated at 2022-06-21 00:31:15.326538
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class CollectionSearchTest(CollectionSearch):
        pass

    try:
        cs = CollectionSearchTest()
        assert cs._collections == _ensure_default_collection()
    except:
        assert False

# Generated at 2022-06-21 00:31:17.295214
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search._load_collections(None, None)

# Generated at 2022-06-21 00:31:21.227793
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.model_vars import VarsModule
    t = CollectionSearch()
    assert t._collections is not None
    assert t._load_collections(None, None) is None
    display.warning = lambda s: None
    result = t._load_collections(None, [VarsModule.default_collection])
    assert VarsModule.default_collection in result