

# Generated at 2022-06-21 00:22:06.126466
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Test that the collections field is a list (which is what _load_collections needs)
    assert isinstance(cs._collections, list)

    # Test that _load_collections doesn't return a list with just ansible.builtin.
    # We need to add a collection_list to this so that we can test the _ensure_default_collection
    # function, which is set as the default for the collections field.
    test_list = ['my.collection']
    result = cs._load_collections('collections', test_list)

    # Test that the _load_collections function returned a list
    assert isinstance(result, list)

    # Test that the _ensure_default_collection function put ansible.builtin into the list
    assert 'ansible.builtin' in result

# Generated at 2022-06-21 00:22:07.698628
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:22:10.353132
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()
    col_search._collections = 'ansible.builtin'
    assert col_search._load_collections('collections', 'ansible.builtin') == ['ansible.builtin']

# Generated at 2022-06-21 00:22:22.538234
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._load_collections('collections', 'foobar') == None
    assert c._load_collections('collections', None) == None
    assert c._load_collections('collections', []) == None
    assert c._load_collections('collections', ['foo', 'bar']) == ['ansible.builtin', 'foo', 'bar']
    assert c._load_collections('collections', ['ansible.builtin', 'foo', 'bar']) == ['ansible.builtin', 'foo', 'bar']
    assert c._load_collections('collections', ['foo', 'bar', 'ansible.builtin']) == ['ansible.builtin', 'foo', 'bar']

# Generated at 2022-06-21 00:22:26.930213
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import collections
    cs = CollectionSearch()
    cs_list = cs._load_collections('collections',[])
    assert isinstance(cs_list, collections.Iterable), "Newly created object's _ensure_default_collection not return isinstance(collections.Iterable)"


# Generated at 2022-06-21 00:22:29.517018
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c_search_obj=CollectionSearch()
    collection_list=_ensure_default_collection()
    assert(c_search_obj._collections == collection_list)

# Generated at 2022-06-21 00:22:34.364568
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._load_collections('collections', 'ansible.builtin') is None
    assert search._load_collections('collections', ['collection1', 'collection2', 'collection3']) == ['collection1', 'collection2', 'collection3']
    assert search._load_collections('collections', ['ansible.builtin', 'collection1', 'collection2', 'collection3']) == ['collection1', 'collection2', 'collection3']

# Generated at 2022-06-21 00:22:37.637850
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_search = CollectionSearch()
    print(type(coll_search))
    print(coll_search.collections)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:22:40.220311
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()



# Generated at 2022-06-21 00:22:43.625339
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collections = _ensure_default_collection(['test_collection_1', 'test_collection_2'])
    assert test_collections == ['test_collection_1', 'test_collection_2', 'ansible.builtin']

# Generated at 2022-06-21 00:22:56.368865
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch()
    d.__init__()
    assert d._collections == None
    assert d._collections.isa == 'list'
    assert d._collections.listof == string_types
    assert d._collections.priority == 100
    assert d._collections.default == _ensure_default_collection
    assert d._collections.always_post_validate == True
    assert d._collections.static == True


# Generated at 2022-06-21 00:23:00.317024
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    ansible_collections = AnsibleCollectionConfig.collections
    if not ansible_collections:
        assert collectionSearch.collections == None
    else:
        assert collectionSearch.collections == ansible_collections

# Generated at 2022-06-21 00:23:01.954537
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t.collections is not None

# Generated at 2022-06-21 00:23:02.912618
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch(), '_collections')

# Generated at 2022-06-21 00:23:05.656517
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # input test
    class Base(object):
        pass

    class Host(Base, CollectionSearch):
        pass

    h = Host()
    print(h._collections)

# Generated at 2022-06-21 00:23:16.312105
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # The constructor
    i = CollectionSearch()

    # The field
    #    _collections = FieldAttribute(isa='list', listof=string_types, priority=100,
    #                                  always_post_validate=True, static=True)

    # This is the function that sets up the field
    i._collections.setup(name='collections', parent=i, from_what='constructor')

    # This is the value that the field should be set to - what we want to test
    ds = [
          'ansible.builtin',
          'ansible.legacy',
          'namespace.collection'
         ]

    # This call should set the field
    i._load_collections(name='collections', ds=ds)

    # Check that the field was set to the expected value
    assert i._col

# Generated at 2022-06-21 00:23:17.403107
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs)

# Generated at 2022-06-21 00:23:23.833049
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections is None
    assert c.collections == _ensure_default_collection()

    c = CollectionSearch({'collections': ['ansible.builtin', 'collections.someuser.somecollection']})
    assert c.collections == ['ansible.builtin', 'collections.someuser.somecollection']
    assert c.collections == _ensure_default_collection(c.collections)

    c = CollectionSearch({'collections': ['collections.someuser.somecollection']})
    assert c.collections == ['ansible.builtin', 'collections.someuser.somecollection']
    assert c.collections == _ensure_default_collection(c.collections)

# Generated at 2022-06-21 00:23:35.236856
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    loader = DataLoader()
    play_context = PlayContext()
    play_context.remote_addr = '127.0.0.1'
    play_source =  dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello World!'))),
            dict(action=dict(module='setup', args=dict())),
        ]
    )
    my_coll = CollectionSearch(play=play_source, play_context=play_context, loader=loader, variable_manager=None)
    assert my_coll is not None

# Generated at 2022-06-21 00:23:40.259471
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    #    assert cs.collections == ["ansible.builtin"]

    cs.collections.extend(["ansible_collections.test"])
    #    assert cs.collections == ["ansible_collections.test", "ansible.builtin"]


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:24:03.704843
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch, '_collections'), '_collections not found'
    assert CollectionSearch._collections.isa == 'list', '_collections not a list'
    assert CollectionSearch._collections.listof == string_types, '_collections not string list'
    assert CollectionSearch._collections.priority == 100, '_collections priority not 100'
    assert CollectionSearch._collections.default == _ensure_default_collection, '_collections default not a function'
    assert CollectionSearch._collections.always_post_validate, '_collections not always_post_validate'
    assert CollectionSearch._collections.static, '_collections not static'

    assert hasattr(CollectionSearch, '_load_collections'), '_load_collections not found'

# Generated at 2022-06-21 00:24:04.705794
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj)
    assert('collections' in obj._attributes)

# Generated at 2022-06-21 00:24:06.132922
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cObj = CollectionSearch()
    assert cObj._load_collections("attr", "ds") is None

# Generated at 2022-06-21 00:24:11.690393
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert len(_ensure_default_collection()) == 1
    assert len(_ensure_default_collection(['a.b', 'c.d'])) == 3
    assert len(_ensure_default_collection(['a.b', 'ansible.builtin', 'c.d'])) == 3
    assert len(_ensure_default_collection(['ansible.builtin'])) == 1

# Generated at 2022-06-21 00:24:15.009139
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None
    assert cs._collections == [
        '',
        'ansible.builtin',
        'ansible.legacy'
    ]

# Generated at 2022-06-21 00:24:23.470025
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert "ansible.legacy" in collection._collections
    assert "ansible.builtin" in collection._collections
    assert "ansible_collections.misc" in collection._collections
    assert "ansible.builtin" in collection._load_collections(None, None)
    assert "ansible.legacy" in collection._load_collections(None, None)
    assert "ansible_collections.misc" in collection._load_collections(None, None)

# Generated at 2022-06-21 00:24:31.144722
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test case 1: use alias name
    cs = CollectionSearch(collections='c1')
    assert cs._collections == ['c1']

    # Test case 2: use some invalid alias name
    cs = CollectionSearch(collections='c2')
    assert cs._collections == [None]

    # Test case 3: use real name
    cs = CollectionSearch(collections='ansible.builtin')
    assert cs._collections == ['ansible.builtin']

    # Test case 4: use list of alias and real names
    cs = CollectionSearch(collections=['c1', 'ansible.builtin', 'ansible.builtin'])
    assert cs._collections == ['c1', 'ansible.builtin']

    # Test case 5: use empty list of default
    cs = CollectionSearch(collections=None)
   

# Generated at 2022-06-21 00:24:34.916517
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.get_validated_value('collections', collection_search._collections, 'ansible.builtin') == ['ansible.builtin']

# Generated at 2022-06-21 00:24:39.955377
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    ds = ['ansible.builtin']
    env = Environment()
    assert  is_template('ansible.builtin', env) is False
    assert c._load_collections(attr=None, ds=ds) == ['ansible.builtin']

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:24:41.090596
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:25:01.152519
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Check for collection search for reqs
    # Instantiating the class CollectionSearch
    CollectionSearchObj = CollectionSearch()

    # Call _load_collections to return the default search space
    result = CollectionSearchObj._load_collections('collections', '')

    # Assert to check the result for the default collection
    assert result[0] == 'ansible.builtin, ansible.legacy'


# Generated at 2022-06-21 00:25:04.276607
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test without passing collections
    assert CollectionSearch().collections is None
    # Test passing collections
    cs = CollectionSearch(collections=['collection1'])
    assert cs.collections == ['collection1']

# Generated at 2022-06-21 00:25:12.653707
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.set_loader()

    # Override the FieldAttribute.get_value to call the get_validated_value to use in this test
    cs.get_value = cs.get_validated_value

    # Test the default as a None
    ds = {}
    assert cs.get_value('collections', cs.collections, ds, None) is None

    ds = {'collections': []}
    assert cs.get_value('collections', cs.collections, ds, None) is None

    ds = {'collections': ["my.collection", "my.collection2"]}
    assert cs.get_value('collections', cs.collections, ds, None) == ds['collections']

# Generated at 2022-06-21 00:25:23.398507
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) == ['ansible.builtin', 'ansible.legacy']  # collection_list is None
    assert cs._load_collections(None, []) == ['ansible.builtin', 'ansible.legacy']  # collection_list is []
    assert cs._load_collections(None, ['ns']) == ['ns', 'ansible.builtin', 'ansible.legacy']  # collection_list is ['ns']
    assert cs._load_collections(None, ['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']  # collection_list is ['ansible.builtin']

# Generated at 2022-06-21 00:25:24.053443
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-21 00:25:25.901786
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.get_validated_attr('collections', ['test']) == ['test']

# Generated at 2022-06-21 00:25:27.882365
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    ds = None
    c._load_collections('collections', ds)

# Generated at 2022-06-21 00:25:29.944487
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection(), "Default collection search not set."

# Generated at 2022-06-21 00:25:32.698110
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert not hasattr(a, '_collections_cache')
    assert a._collections is None

# Generated at 2022-06-21 00:25:33.896041
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == cs.collections

# Generated at 2022-06-21 00:26:05.064321
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # AnsibleCollectionConfig.default_collection = 'ansible.legacy'
    class Foo(CollectionSearch):
        pass
    foo = Foo()
    assert len(foo._collections) == 1
    assert foo._collections[0] == 'ansible.legacy'

# Generated at 2022-06-21 00:26:06.853572
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass

    test = TestCollectionSearch()
    assert test.collections == []

# Generated at 2022-06-21 00:26:09.316658
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)


# Test static field initialization

# Generated at 2022-06-21 00:26:11.033870
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections == ['ansible.posix']

# Generated at 2022-06-21 00:26:13.391500
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections._default == _ensure_default_collection

# Generated at 2022-06-21 00:26:14.994888
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   assert CollectionSearch._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:26:16.741168
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-21 00:26:20.730149
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

    collection_search = CollectionSearch(collections=["acme.linux", "acme.windows"])
    assert collection_search._collections == ["acme.linux", "acme.windows", "ansible.legacy"]

# Generated at 2022-06-21 00:26:21.701834
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-21 00:26:24.959431
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections._listof.types == [str], "expected _collections to be [str], but got %s" % (search._collections._listof.types)

# Generated at 2022-06-21 00:27:33.379111
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # We are using the CollectionSearch class
    assert CollectionSearch

# Generated at 2022-06-21 00:27:35.794459
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_obj = CollectionSearch()
    assert collection_search_obj._collections.default == ['ansible.builtin']

# Generated at 2022-06-21 00:27:42.133246
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert issubclass(CollectionSearch, object)
    assert CollectionSearch._collections.field_id is None
    assert CollectionSearch._collections.name == 'collections'
    assert CollectionSearch._collections.always_post_validate
    assert CollectionSearch._collections.static
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.type == 'list'
    assert CollectionSearch._collections.listof == string_types

# Generated at 2022-06-21 00:27:43.379771
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default(None) == AnsibleCollectionConfig.collections

# Generated at 2022-06-21 00:27:46.971281
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == []
    assert obj._load_collections('collections', None) == None
    assert obj._load_collections('collections', []) == []
    assert obj._load_collections('collections', ['local.collections']) == ['local.collections', 'ansible.legacy']

# Generated at 2022-06-21 00:27:47.456247
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-21 00:27:57.017908
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    # Verify that _collections is set to a correct value
    assert isinstance(test_obj._collections, FieldAttribute)
    assert set(test_obj._collections.isa) == set(['list', 'listof'])
    assert test_obj._collections.listof == string_types
    assert test_obj._collections.priority == 100
    assert test_obj._collections.default == _ensure_default_collection
    assert test_obj._collections.always_post_validate is True
    assert test_obj._collections.static is True
    # Verify that _load_collections is set to a correct value
    assert isinstance(test_obj._load_collections, collections.Callable)

# Generated at 2022-06-21 00:28:05.290425
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def _get_attribute_instance(self, name):
        pass

    class Task(CollectionSearch):
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection, always_post_validate=True, static=True)
        def __init__(self, *args, **kwargs):
            super(Task, self).__init__(*args, **kwargs)
            self._get_attribute_instance = _get_attribute_instance

    t = Task()
    t.load({'collections': ['test.collection','test.collection2']})

# Generated at 2022-06-21 00:28:06.660006
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch()._collections, FieldAttribute)

# Generated at 2022-06-21 00:28:14.409336
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.mod_args import ModuleArgsParser

    collection_search_1 = CollectionSearch()
    collection_search_2 = CollectionSearch()

    class SampleAnsibleModule:
        pass

    task_include_1 = TaskInclude()
    task_include_1._parent = SampleAnsibleModule()
    task_include_1._role_name = AnsibleVaultEncryptedUnicode(u'role_name_1')

# Generated at 2022-06-21 00:30:52.915755
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with pytest.raises(Fail) as excinfo:
        CollectionSearch()
    assert "error setting up dynamic fields in class CollectionSearch: " \
           "missing or failed value validation for required attribute 'collections'" in str(excinfo.value)

    # test with static fields
    class CollectionSearchDummy(CollectionSearch):
        def __init__(self):
            super(CollectionSearchDummy, self).__init__()
            self.setup_dynamic_collections()

    # CollectionSearchDummy is equivalent to CollectionSearch, where collection_list = None
    CollectionSearchDummy()

    # test with collection_list (list of collection)
    class CollectionSearchDummyWithCollectionList(CollectionSearch):
        def __init__(self):
            super(CollectionSearchDummyWithCollectionList, self).__init__()
            self.setup_d

# Generated at 2022-06-21 00:30:58.614974
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # Testing for constructor of class CollectionSearch
    assert isinstance(collection_search, CollectionSearch)
    assert isinstance(collection_search._collections, FieldAttribute)
    assert collection_search._collections.listof == string_types

# Generated at 2022-06-21 00:31:01.196561
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections('collections', []) is None

# Generated at 2022-06-21 00:31:09.299211
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # arrange
    collection_search = CollectionSearch()
    collection_search.collection_name = 'collection_name'
    collection_search.collections = ['collections']

    # act
    value = collection_search._load_collections('_load_collections', 'ds')

    # assert
    assert value is not None

# Generated at 2022-06-21 00:31:13.207172
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = dict()
    cs = CollectionSearch()
    cs.populate_obj(ds)
    assert cs._collections == ['ansible_collections.ansible']

# Generated at 2022-06-21 00:31:15.609390
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:31:16.436671
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-21 00:31:19.877450
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()
    assert c._collections == _ensure_default_collection(['test.collection'])
    assert c._collections == _ensure_default_collection([])

# Generated at 2022-06-21 00:31:24.939788
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = CollectionSearch()
    assert isinstance(ds, CollectionSearch)
    assert ds.collections == ['ansible.builtin']

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-21 00:31:28.361998
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections('collections', ['test']) == ['test', 'ansible.builtin', 'ansible.legacy']