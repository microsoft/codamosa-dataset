

# Generated at 2022-06-21 00:21:52.679579
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections is not None

# Generated at 2022-06-21 00:22:03.972018
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.task.include import TaskInclude

    c = CollectionSearch()
    # test that of the default collection list is returned if no collection_list is provided
    default_collection_list = c._ensure_default_collection()
    assert default_collection_list is not None
    assert 'ansible.builtin' in default_collection_list
    assert 'ansible.legacy' in default_collection_list

    # Create a play and test that of the default collection list is returned if no collection_list is provided

# Generated at 2022-06-21 00:22:10.324490
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Verify empty collections list
    collection_search = CollectionSearch()
    collection_search._collections = None
    collection_search._load_collections('collections', None)
    assert collection_search._collections == [] 

    # Verify populated collections list
    collection_search = CollectionSearch()
    collection_search._collections = ['collection1', 'collection2']
    collection_search._load_collections('collections', None)
    assert collection_search._collections == ['collection1', 'collection2']

# Generated at 2022-06-21 00:22:12.945775
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    coll_list = cs._load_collections(None, None)
    print(coll_list)

test_CollectionSearch()

# Generated at 2022-06-21 00:22:15.192686
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    c = CollectionSearch()
    assert c._collections.name == 'collections'
    assert isa(c._collections)

# Generated at 2022-06-21 00:22:17.289117
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()


# Generated at 2022-06-21 00:22:19.272607
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections is None

# Generated at 2022-06-21 00:22:25.537385
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute import FieldAttribute, FieldAttributeImmutability

    # test priority of FieldAttribute
    assert CollectionSearch._collections.priority == 100

    # test always_post_validate of FieldAttribute
    assert CollectionSearch._collections.always_post_validate == True

    # test if FieldAttributeImmutability is copied
    assert CollectionSearch._collections.immutability == FieldAttributeImmutability.IMMUTABLE

# Generated at 2022-06-21 00:22:27.233890
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:22:28.619396
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections is not None

# Generated at 2022-06-21 00:22:42.973507
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Without collection list
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()

    # With default collection
    cs = CollectionSearch()
    cs.collections = ['namespace.collection_name']
    assert cs.collections == ['namespace.collection_name', 'ansible.builtin']

    # With default and legacy
    cs = CollectionSearch()
    cs.collections = ['namespace.collection_name', 'namespace.collection_name2']
    assert cs.collections == ['namespace.collection_name', 'namespace.collection_name2', 'ansible.builtin']

    # With default and legacy
    cs = CollectionSearch()
    cs.collections = ['namespace.collection_name', 'namespace.collection_name2']

# Generated at 2022-06-21 00:22:46.749114
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c1 = CollectionSearch()
    print(c1._collections)
    print(c1._collections.default)


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:22:54.373258
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test with no collections
    no_collections = CollectionSearch()
    assert no_collections._collections == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible.legacy']

    # Test with collections
    collections = CollectionSearch(collections=['ansible_collections.acme'])
    assert collections._collections == ['ansible_collections.acme', 'ansible_collections.ansible.builtin',
                                        'ansible_collections.ansible.legacy']

# Generated at 2022-06-21 00:22:55.924859
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    display.display(obj)
    display.display('succeed')



# Generated at 2022-06-21 00:22:58.201118
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default() == _ensure_default_collection(None)



# Generated at 2022-06-21 00:23:01.339294
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = 'testdata'
    c1 = CollectionSearch()
    c1._collections = ds

    assert(c1._collections == ds)

# Generated at 2022-06-21 00:23:03.458497
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection([])  # a list of strings

# Generated at 2022-06-21 00:23:05.855346
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:23:06.908079
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    assert collectionsearch

# Generated at 2022-06-21 00:23:17.597761
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    # The constructor is strange in that it has no input parameter yet calls _load_collections
    # _load_collections is a bit complex due to being shared with other classes
    # which call it via _get_value_from_ds with an input that are not used by _load_collections
    # The constructor calls it with ds=None and attr=None and the _load_collections attempts to
    # validate this with the class variable _collections which is a FieldAttribute
    # Note for now we do not handle static (static=True) as that does not apply here.
    # FieldAttribute has a length of 2, but we don't yet handle storing and using the isa and listof
    assert len(search._collections) == 2
    assert search._collections[0] == 'ana'
    assert search._collections

# Generated at 2022-06-21 00:23:25.688819
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._load_collections(0,None)

# Generated at 2022-06-21 00:23:34.227526
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    module = CollectionSearch()
    module.post_validate()
    module._collections = ["Ansible.awx"]
    ansible_collections = ["ansible.builtin", "Ansible.awx"]
    assert module.collections == ansible_collections, "Collection Search should contain Ansible.awx and ansible.builtin"

    module.post_validate()
    module._collections = ["Ansible.awx"]
    assert module.collections == ansible_collections, "Collection Search should contain Ansible.awx and ansible.builtin"

# Generated at 2022-06-21 00:23:43.037572
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print('##############')
    print('### 1 ###')
    print('##############')
    # Test 'collections' attribute
    ds = {'collections': ['col1', 'col2']}
    ds_validated = CollectionSearch().get_validated_value('collections', CollectionSearch._collections, ds, None)
    print(ds_validated)
    assert ds_validated == ['col1', 'col2', 'ansible.builtin'] or \
           ds_validated == ['col1', 'col2', 'ansible.legacy']

    print('##############')
    print('### 2 ###')
    print('##############')
    ds = {'collections': ['col1', 'col2'], 'other': 'value'}

# Generated at 2022-06-21 00:23:45.335326
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj.post_validate(obj._valid_attrs['collections'], None)

# Generated at 2022-06-21 00:23:55.448498
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    if not cs:
        raise Exception('cs is None')
    collections = cs._load_collections(None,None)
    if not collections:
        raise Exception('collections is None')
    if collections[0] == 'ansible.builtin':
        raise Exception('collection_list is expected to contain ansible.builtin as the first item')
    if collections[0] == 'ansible.legacy':
        raise Exception('collection_list is expected to contain ansible.legacy as the first item')
    if collections[0] != 'Ansible.Default':
        raise Exception('collection_list is expected to contain Ansible.Default as the first item')

# Generated at 2022-06-21 00:24:03.322953
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Override FieldAttribute's priority
    cs._collections = {'default': _ensure_default_collection}
    cs.post_validate()
    if cs.collections is None:
        raise Exception("collections is None")
    elif len(cs.collections) > 1:
        raise Exception("There are more than 1 collection: %s" % cs.collections)
    elif cs.collections[0] != 'ansible.builtin':
        raise Exception("First collection is not 'ansible.builtin'")
    else:
        print("collections: %s" % cs.collections)

# Generated at 2022-06-21 00:24:07.700653
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearch_tester(CollectionSearch, object):
        def __init__(self, *args, **kwargs):
            return super(CollectionSearch_tester, self).__init__(*args, **kwargs)

    class Base_tester(object):
        pass

    a = CollectionSearch_tester(Base_tester())
    assert a._load_collections(None, None) == ['ansible_collections.ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:24:10.064463
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs=CollectionSearch()
    #Test for  the correct behavior of class constructor
    assert cs._collections==_ensure_default_collection()

# Generated at 2022-06-21 00:24:12.878736
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search)
    print(collection_search.collections)

# test the the function _ensure_default_collection()

# Generated at 2022-06-21 00:24:14.710173
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:24:29.759528
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections.default is None


# Generated at 2022-06-21 00:24:32.454021
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection()
    assert CollectionSearch('ansible.builtin')._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:24:36.516313
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ['ansible_namespace.collection']
    attr, ds = 'collections', None
    cs._load_collections(attr, ds)

# Generated at 2022-06-21 00:24:46.244463
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude

    config = AnsibleCollectionConfig()
    config.search_paths = ['./my-collections']

    block = Block()
    block._role = RoleInclude()
    block._role.collections = ['my_namespace.my_collection']

    play = Play()
    play.block = block

    assert play.collections == ['my_namespace.my_collection']
    display.warning.reset_mock()

    play.collections = []
    assert play.collections == ['ansible.legacy']
    display.warning.assert_called_once()

    display.warning.reset_mock()

# Generated at 2022-06-21 00:24:57.455104
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    # Check the constructor of class CollectionSearch
    assert c._collections is not None, '_collections should not be None'
    assert c._collections.isa == 'list', '_collections.isa should be \'list\''
    assert c._collections.listof == string_types, '_collections.listof should be an instance of string_types'
    assert c._collections.default == _ensure_default_collection, '_collections.default should be _ensure_default_collection'
    assert c._collections.always_post_validate is True, '_collections.always_post_validate should be True'
    assert c._collections.static is True, '_collections.static should be True'
    # Check the constructor of class FieldAttribute
    assert c._collections.name

# Generated at 2022-06-21 00:24:59.489812
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_object = CollectionSearch()
    assert collection_search_object._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:25:09.815594
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = None
    class _TestCollectionSearch(CollectionSearch):
        class_object_role = FieldAttribute(isa='list', static=True)

    for v in [None, [None], [None, None], [], [[]], [[], []]]:
        if v is None:
            assert _ensure_default_collection(None) == ([AnsibleCollectionConfig.default_collection]
                                                         if AnsibleCollectionConfig.default_collection is not None
                                                         else [])
        else:
            assert _ensure_default_collection(v) == [AnsibleCollectionConfig.default_collection]
            if AnsibleCollectionConfig.default_collection is None:
                AnsibleCollectionConfig.default_collection = 'ansible.builtin'
            else:
                AnsibleCollectionConfig.default_collection = None

    assert _ensure

# Generated at 2022-06-21 00:25:16.494323
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.helpers import ModuleDeprecationWarning
    from ansible.module_utils.six import string_types
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.template import is_template, Environment
    from ansible.utils.display import Display
    import pytest
    import sys
    import warnings
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins

    class MockDisplay(object):
        def __init__(self):
            self.warning = False

        def warning(self, msg):
            self.warning = True

    display1 = MockDisplay()


# Generated at 2022-06-21 00:25:23.582822
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import json
    t = CollectionSearch()
    t.collections = ['col1', 'col2']
    t.post_validate(None, None)
    assert t.collections == ['col1', 'col2']

    t = CollectionSearch()
    t.collections = json.loads('["col1","col2"]')
    t.post_validate(None, None)
    assert t.collections == ['col1', 'col2']


# Generated at 2022-06-21 00:25:24.911910
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    csearch = CollectionSearch()
    assert csearch._collections == None



# Generated at 2022-06-21 00:25:53.194575
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None
    cs._load_collections('collections', ['collections'])
    assert cs._collections == ['collections']

# Generated at 2022-06-21 00:26:00.827403
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def make_collection_search(collections):
        class Foo(object, CollectionSearch):
            pass

        cs = Foo()
        cs.all_vars = dict(collections=collections,)

        return cs

    # empty collections are converted to None
    cs = make_collection_search(collections=[])
    assert cs._load_collections('collections', {}) is None

    # a single string is converted to a list of strings
    cs = make_collection_search(collections='foo')
    assert cs._load_collections('collections', {}) == ['foo']

    # a list of strings is left alone
    cs = make_collection_search(collections=['foo', 'bar'])
    assert cs._load_collections('collections', {}) == ['foo', 'bar']

# Generated at 2022-06-21 00:26:02.401886
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections

# Generated at 2022-06-21 00:26:04.233069
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.__getattribute__('collections') == None

# Generated at 2022-06-21 00:26:07.106562
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    expected_collections = ['ansible.builtin', 'ansible.legacy']
    assert collection_search._collections == expected_collections

# Generated at 2022-06-21 00:26:08.138745
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj

# Generated at 2022-06-21 00:26:09.316592
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch()._collections, FieldAttribute)



# Generated at 2022-06-21 00:26:14.948663
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = 'a'
    b = 'b'
    c = 'c'
    collection_search = CollectionSearch()
    collection_search.collections = [a, b, c]
    assert collection_search.collections == [a, b, c]
    collection_search.collections = None
    assert collection_search.collections is None

# Generated at 2022-06-21 00:26:20.502257
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with pytest.raises(AttributeError):
        variable = CollectionSearch("ansible.builtin")
        variable2 = CollectionSearch("ansible.ansible_collections.network.nxos.plugins.modules.nxos_static_routes")
        assert variable.collections
        assert variable2.collections == ['ansible.builtin', 'ansible_collections.network.nxos.plugins.modules.nxos_static_routes']

# Generated at 2022-06-21 00:26:23.671668
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    path = 'test_path'
    collection_search = CollectionSearch(path)
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']
    assert collection_search._path == 'test_path'

# Generated at 2022-06-21 00:27:31.427948
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs

# Generated at 2022-06-21 00:27:34.010159
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, object) and obj._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:27:41.485566
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    data_set = {
        'collections': ['foo.bar']
    }

    data_set_empty = {
        'collections': 'default'
    }

    cs = CollectionSearch()
    display.test_test_set_var('collections', ['foo.bar'], cs.get_validated_value('collections', cs._collections, data_set, None))
    display.test_test_set_var('collections', ['foo.bar'], cs.get_validated_value('collections', cs._collections, data_set_empty, None))

# Generated at 2022-06-21 00:27:43.422298
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    if collection._collections == _ensure_default_collection():
        assert True
    else:
        assert False

# Generated at 2022-06-21 00:27:45.666487
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj is not None
    assert test_obj._collections is not None
    assert callable(test_obj._collections)

# Generated at 2022-06-21 00:27:48.436257
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role import Role
    role = Role()
    role.name = 'some_role'
    role.collections = ['some_collection']
    assert role._collections == ['some_collection']
    assert role.collections == ['ansible.builtin', 'some_collection']

# Generated at 2022-06-21 00:27:49.955020
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    assert test_instance._collections is not None

# Generated at 2022-06-21 00:27:57.017910
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    play_context = PlayContext()
    task_include = TaskInclude()
    block = Block()
    role = Role()

    assert play_context._collections != None
    assert task_include._collections != None
    assert block._collections != None
    assert role._collections != None

# Generated at 2022-06-21 00:27:58.502283
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    print(collections.collections)

# Generated at 2022-06-21 00:27:59.703314
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()

# Generated at 2022-06-21 00:30:25.605276
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert not collection_search.collections

# Generated at 2022-06-21 00:30:27.400252
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:30:30.602186
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.collections == ['ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-21 00:30:35.595766
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print('Testing construction of class CollectionSearch')
    c = CollectionSearch()
    assert c._collections.always_post_validate is True
    assert c._collections.default_collection is not None


# Generated at 2022-06-21 00:30:37.569560
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c=CollectionSearch()
    c._load_collections(None, None)

# Generated at 2022-06-21 00:30:44.058438
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections._listof == string_types
    assert collection_search._collections._isa == 'list'
    assert collection_search._collections._priority == 100
    assert collection_search._collections._default == _ensure_default_collection
    assert collection_search._collections._always_post_validate is True
    assert collection_search._collections._static is True
    assert collection_search._collections.value is None
    assert collection_search._collections._name == 'collections'
    assert collection_search._collections._parent is collection_search


# Generated at 2022-06-21 00:30:46.762750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch({"collections": ['test']})
    assert d is not None, "instance of CollectionSearch not created"

# Generated at 2022-06-21 00:30:56.397839
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    list_collection = CollectionSearch()
    default_collection_list = list_collection._ensure_default_collection()
    if 'ansible.builtin' in default_collection_list or 'ansible.legacy' in default_collection_list:
        assert True
    else:
        assert False
    collection_list = ['collection1', 'collection2']
    new_collection_list = list_collection._ensure_default_collection(collection_list)
    if 'ansible.builtin' in new_collection_list or 'ansible.legacy' in new_collection_list:
        assert True
    else:
        assert False

# Generated at 2022-06-21 00:30:58.653284
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default() == _ensure_default_collection()

# Generated at 2022-06-21 00:31:11.609967
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    try:
        # Create an object of CollectionSearch
        no_collections = CollectionSearch()
        assert no_collections is not None , "Empty object creation failed for CollectionSearch"

        # Print elements of the object
        assert no_collections.collections is not None , "Empty object creation failed for CollectionSearch"
        assert no_collections.collections is not None , "Empty object creation failed for CollectionSearch"
        assert no_collections.collections is not None , "Empty object creation failed for CollectionSearch"
        assert no_collections.collections is not None , "Empty object creation failed for CollectionSearch"
        assert no_collections.collections is not None , "Empty object creation failed for CollectionSearch"
        assert no_collections.collections is not None , "Empty object creation failed for CollectionSearch"

    except Exception as err:
        raise Ass