

# Generated at 2022-06-21 00:21:51.609059
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == [u'ansible.builtin'] and hasattr(obj, '_load_collections')

# Generated at 2022-06-21 00:21:54.842353
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block

    b = Block()
    cs = CollectionSearch()

    cs.post_validate()
    cs._load_collections(None, None)
    b.post_validate()
    b.load()

# Generated at 2022-06-21 00:21:57.117554
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	cs = CollectionSearch()
	assert cs._collections == ['ansible_collections.nsweb.kubernetes']

# Generated at 2022-06-21 00:22:07.924004
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class MockCollectionSearch(CollectionSearch):
        def __init__(self, vault_password, new_init=None):
            super(MockCollectionSearch, self).__init__(vault_password=vault_password)
            self.new_init = new_init

    assert MockCollectionSearch.tasks is None
    assert MockCollectionSearch.roles is None
    assert MockCollectionSearch.module_utils is None
    assert MockCollectionSearch.lookup_plugins is None
    assert MockCollectionSearch.filter_plugins is None
    assert MockCollectionSearch.test_plugins is None
    assert MockCollectionSearch.action_plugins is None
    assert MockCollectionSearch.connection_plugins is None
    assert MockCollectionSearch.strategy_plugins is None
    assert MockCollectionSearch.collections is None


# Generated at 2022-06-21 00:22:09.905871
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections(None, None) == _ensure_default_collection()

# Generated at 2022-06-21 00:22:10.825986
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None

# Generated at 2022-06-21 00:22:13.108203
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearchObj = CollectionSearch()
    assert test_CollectionSearchObj._load_collections(None, None) is None

# Generated at 2022-06-21 00:22:24.743282
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection(['my_coll']) == ['my_coll', 'ansible.builtin']
    assert _ensure_default_collection(['my_coll', 'ansible.builtin']) == ['my_coll', 'ansible.builtin']
    assert _ensure_default_collection(['ansible.builtin', 'my_coll']) == ['ansible.builtin', 'my_coll']
    assert _ensure_default_collection(['ansible.builtin']) == ['ansible.builtin']
    assert _ensure_default_collection(['ansible.legacy']) == ['ansible.legacy']
    assert _ensure_default_collection(['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-21 00:22:34.115170
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from .. import Task
    from .. import Role
    from .. import TaskInclude

    search_task = CollectionSearch()
    assert len(search_task.get_attribute_class('collections')) == 100

    assert Task().get_attribute_class('collections') == FieldAttribute(isa='list', listof=string_types, priority=100,
                                                                       default=_ensure_default_collection,
                                                                       always_post_validate=True, static=True)
    assert Role().get_attribute_class('collections') == FieldAttribute(isa='list', listof=string_types, priority=100,
                                                                       default=_ensure_default_collection,
                                                                       always_post_validate=True, static=True)
    assert TaskInclude().get_attribute_class('collections') == Field

# Generated at 2022-06-21 00:22:36.875167
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.get_validated_value('collections', cs._collections, 'test') == ['test', 'ansible.builtin']

# Generated at 2022-06-21 00:22:47.017424
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    
    # Create class object and check that it was initialized correctly
    _collectionSearch = CollectionSearch()

    assert _collectionSearch._collections is not None
    assert _collectionSearch._collections.listof == string_types
    assert _collectionSearch._collections.priority == 100
    assert _collectionSearch._collections.default == _ensure_default_collection
    assert _collectionSearch._collections.always_post_validate
    assert _collectionSearch._collections.static

# Generated at 2022-06-21 00:22:49.624402
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections == ['ansible_collections.vmware.vmware_rest']

# Generated at 2022-06-21 00:22:54.720248
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.legacy']
    c.collections = ['zoo']
    assert c.collections == ['zoo', 'ansible.legacy']
    c.collections = ['zoo', 'bear']
    assert c.collections == ['zoo', 'bear', 'ansible.legacy']

# Generated at 2022-06-21 00:23:01.549913
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test 1
    collection = CollectionSearch()
    assert collection._collections == ['ansible.builtin', 'ansible.legacy']

    # Test 2
    collection = CollectionSearch(collections=['hello'])
    assert collection._collections == ['hello', 'ansible.builtin', 'ansible.legacy']

    # Test 3
    collection = CollectionSearch(collections=[])
    assert collection._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:23:04.631602
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pb_path = "/etc/ansible/playbooks/test.yml"
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:06.440724
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._load_collections(None, None) == _ensure_default_collection()

# Generated at 2022-06-21 00:23:08.360315
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Class being tested
    obj = CollectionSearch()

    # Ensure _collections is none
    assert obj._collections is None

# Generated at 2022-06-21 00:23:09.954984
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    _ensure_default_collection()

# Generated at 2022-06-21 00:23:11.791309
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.post_validate()
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-21 00:23:13.337437
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-21 00:23:22.751457
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections == None
    assert a._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:29.004721
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Test case 1: Default value of _collections is loaded.
    assert cs._collections == ['ansible_collections.default.default']

    # Test case 2: _collections is defined and default collection name is prepended to the list.
    cs._collections = ['my_collection.my_namespace.my_name']
    assert cs._collections == ['ansible_collections.default.default', 'my_collection.my_namespace.my_name']

# Generated at 2022-06-21 00:23:31.459727
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class TestClass:
        pass

    t=TestClass()
    assert isinstance(t,CollectionSearch)

# Generated at 2022-06-21 00:23:33.252853
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin']

# Generated at 2022-06-21 00:23:34.318921
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs

# Generated at 2022-06-21 00:23:41.733835
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-21 00:23:48.086485
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("Testing constructor of class CollectionSearch")

    test_CollectionSearch = CollectionSearch()

    print("Testing object type of class CollectionSearch")
    if isinstance(test_CollectionSearch, CollectionSearch):
        print("Passed")
    else:
        print("Failed")

    print("Testing collections attribute")
    if isinstance(test_CollectionSearch._collections, FieldAttribute):
        print("Passed")
    else:
        print("Failed")

test_CollectionSearch()


# Generated at 2022-06-21 00:23:50.244079
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()
    assert col_search._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:24:01.571010
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    #collection_list = ['galaxy.serialization.safe', 'galaxy.serialization.json', 'galaxy.serialization.yaml', 'galaxy.serialization.ini', 'galaxy.serialization.msgpack', 'ansible.legacy_collections', 'ansible.builtin']
    #assert cs._collections.post_validate() == collection_list
    #assert cs._collections.default() == collection_list
    #cs._collections.set_value(collection_list)
    # assert cs._collections.get_value() == collection_list
    # assert cs._collections.value == collection_list
    # assert cs.get_deprecated_values('collections') == collection_list
    # assert cs.get_removed_values('collections') == collection_list

# Generated at 2022-06-21 00:24:04.524786
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    search_paths = loader.get_collections_paths()

    test_case = unittest.TestCase()
    test_case.assertEqual(CollectionSearch()._collections.default(), _ensure_default_collection())
    test_case.assertEqual(CollectionSearch(loader=loader)._collections.default(), search_paths)

# Generated at 2022-06-21 00:24:20.512047
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None
    assert cs._collections == _ensure_default_collection
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:24:25.081987
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # pylint: disable=protected-access
    assert CollectionSearch._collections._value == ['ansible.builtin', 'ansible.legacy']
    assert CollectionSearch().collections in [None, []]
    assert CollectionSearch(_collections=['foo', 'bar']).collections == ['foo', 'bar']

# Generated at 2022-06-21 00:24:26.624068
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()

    assert collection_search.collections == []

# Generated at 2022-06-21 00:24:29.425267
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Foo(CollectionSearch):
        pass

    foo = Foo()
    assert foo._load_collections('foo', 'bar') is None
    assert foo.collections is None

# Generated at 2022-06-21 00:24:31.356074
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:24:31.951625
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-21 00:24:34.547923
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search._load_collections(attr=None, ds=None)

# Generated at 2022-06-21 00:24:36.280493
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:24:38.028628
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == collection_search._ensure_default_collection()

# Generated at 2022-06-21 00:24:47.348636
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.errors import AnsibleError

    # Test with a string-type value
    test_string = "collection_name"
    loader = AnsibleLoader(None, None, None)
    templar = Templar(loader=loader)
    collection_search = CollectionSearch()
    collection_search.post_validate({"collections": test_string}, templar)

    # Test with a list-type value
    test_list = ["collection_name_1", "collection_name_2"]
    loader = AnsibleLoader(None, None, None)
    templar = Templar(loader=loader)
    collection

# Generated at 2022-06-21 00:25:15.352062
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch({
        "collections": "collection_local",
    })
    assert collections._collections == ['collection_local']

# Generated at 2022-06-21 00:25:16.963349
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-21 00:25:18.729871
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(None, None) is not None

# Generated at 2022-06-21 00:25:20.630055
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch()
    assert d._collections.default == 'ansible.builtin'

# Generated at 2022-06-21 00:25:22.345623
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is not None

# Generated at 2022-06-21 00:25:28.270480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collectionSearch = CollectionSearch()
    assert collectionSearch._load_collections(None, []) == None
    assert collectionSearch._load_collections(None, ['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']
    assert collectionSearch._load_collections(None, ['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:25:35.208679
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()
    assert test_object.collections == ['ansible.builtin']

    # test get_validated_value
    assert test_object.get_validated_value('collections', FieldAttribute(isa='list', listof=string_types), ['ansible.builtin'], None) == ['ansible.builtin']
    assert test_object.get_validated_value('collections', FieldAttribute(isa='list', listof=string_types), None, None) == ['ansible.builtin']

# Generated at 2022-06-21 00:25:36.377142
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is None

# Generated at 2022-06-21 00:25:41.988037
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block

    cs = CollectionSearch()
    ds = Block()
    ds._ds = {"collections": ["ansible.builtin", "foo.bar"]}
    cs.load_attr_from_ds(ds, "collections")
    assert cs._collections == ds._ds["collections"]



# Generated at 2022-06-21 00:25:45.392749
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    try:
        assert isinstance(collection_search._load_collections('collections','ansible.builtin'), object)
    except NameError:
        assert True


# Generated at 2022-06-21 00:26:39.816455
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:26:42.422224
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    This is a unit test for constructor of class CollectionSearch.
    """
    print("Inside the test_CollectionSearch function")
    test_obj = CollectionSearch()
    print(test_obj._collections)

# Generated at 2022-06-21 00:26:44.097898
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    dictionary = {}
    collection_search = CollectionSearch(dictionary)
    assert collection_search._collections == ['ansible_collections.asb.google_sql_db']

# Generated at 2022-06-21 00:26:44.812878
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()


# Generated at 2022-06-21 00:26:48.540544
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ds = {'collections': ['ansible.builtin']}
    collections = cs._load_collections(None, ds)
    assert collections == ['ansible.builtin']
    ds = {'collections': ['ansible.builtin', 'community.general']}
    collections = cs._load_collections(None, ds)
    assert collections == ['ansible.builtin', 'community.general']

# Generated at 2022-06-21 00:26:49.080761
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch

# Generated at 2022-06-21 00:26:53.831672
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert(cs._load_collections('collections', ['test', 'ansible.builtin']) == ['test', 'ansible.builtin'])

# Generated at 2022-06-21 00:26:55.785754
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collections = CollectionSearch()

    assert test_collections._collections is not None
    assert test_collections._collections._default is not None

# Generated at 2022-06-21 00:27:01.081065
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections('collections', 'my_collection') == ['my_collection']
    assert collection_search._load_collections('collections', ['my_collection', 'your_collection']) == ['my_collection', 'your_collection']
    assert collection_search._load_collections('collections', None) == None

# Generated at 2022-06-21 00:27:02.174818
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Tests the constructor of CollectionSearch"""
    collectionSearch=CollectionSearch()

# Generated at 2022-06-21 00:29:18.376782
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.utils.collection_loader import AnsibleCollectionRef, AnsibleCollectionRefList

    cs = CollectionSearch()

    # test the default behavior of _ensure_default_collection()
    assert cs._collections.get_default() == _ensure_default_collection()

    # test the mixin behavior for the collections attribute
    # which will have a default value of None
    assert cs.collections is None

    # test the to_data() method of FieldAttribute
    assert cs._collections.to_data(cs.get_values_from_datastruct()) == cs.get_values_from_datastruct()['collections']

    # test AnsibleCollectionRef compatability
    # AnsibleCollectionRef() uses the _ensure_default_collection() method when
    # a 'collections' argument not passed
    assert AnsibleCollectionRef

# Generated at 2022-06-21 00:29:20.220693
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == _ensure_default_collection()
    assert test._load_collections('collections',[]) == _ensure_default_collection()

# Generated at 2022-06-21 00:29:23.031945
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = display.Display()
    args = {'_collections': ['collections']}
    res = CollectionSearch(args, d)
    assert isinstance(res, CollectionSearch)

# Generated at 2022-06-21 00:29:24.806739
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_obj = CollectionSearch()
    expected = "ansible.builtin"
    actual = search_obj._collections.default

    assert expected == actual

# Generated at 2022-06-21 00:29:28.508290
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        d = Display()
        c = CollectionSearch()
        c._load_collections(attr='collections', ds='ansible.builtin')
    except Exception as e:
        print("Exception in unit test: " + str(e))

# Generated at 2022-06-21 00:29:35.470397
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.get_validated_value('collections', a._collections, None, None) == []
    assert a.get_validated_value('collections', a._collections, [], None) == []
    assert a.get_validated_value('collections', a._collections, ['jstest'], None) == ['jstest', 'ansible.legacy']
    assert a.get_validated_value('collections', a._collections, ['jstest', 'internaltest'], None) == ['jstest', 'internaltest', 'ansible.legacy']

# Generated at 2022-06-21 00:29:37.247421
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    c.collections = ["foo.bar"]
    assert c.collections == ["foo.bar"]

# Generated at 2022-06-21 00:29:38.521260
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections == None

# Generated at 2022-06-21 00:29:39.448872
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.__dict__['_collections'] == _ensure_default_collection()

# Generated at 2022-06-21 00:29:41.303833
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # assert cs.collections == ['ansible.builtin']
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']