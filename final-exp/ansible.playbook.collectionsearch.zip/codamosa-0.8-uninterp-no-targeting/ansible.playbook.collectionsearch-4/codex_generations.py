

# Generated at 2022-06-21 00:22:02.264202
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # test with no input
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

    # test with valid collection_list
    cs = CollectionSearch(collections=['collection_list'])
    assert cs._collections == _ensure_default_collection(collection_list=['collection_list'])

    # test with invalid collections
    collections = 0
    try:
        cs = CollectionSearch(collections=collections)
    except Exception:
        assert True
    else:
        assert False, "should not reach here"

# Generated at 2022-06-21 00:22:03.274966
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs

# Generated at 2022-06-21 00:22:07.219675
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test the constructor of CollectionSearch without any parameter
    obj = CollectionSearch()
    assert obj.__dict__ == {'parent': None}

    # Test the constructor of CollectionSearch with parameter 'parent'
    obj = CollectionSearch(parent=True)
    assert obj.parent == True

# Generated at 2022-06-21 00:22:09.232259
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    object = CollectionSearch()
    assert object._collections == ['ansible_collections.ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:22:15.667926
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    '''
    Tests that the CollectionSearch() class in ansible.playbook.roles.collection_search
    can be created with a value for the collections variable.
    '''

    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']

    cs = CollectionSearch(collections=['ansible.builtin'])
    assert cs.collections == ['ansible.builtin']

    cs = CollectionSearch(collections=['mycol'])
    assert cs.collections == ['ansible.builtin', 'mycol']

    cs = CollectionSearch(collections=['ansible.builtin', 'mycol2'])
    assert cs.collections == ['ansible.builtin', 'mycol2']

    cs = CollectionSearch(collections=['mycol3', 'mycol4'])
    assert cs

# Generated at 2022-06-21 00:22:17.421736
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert not collectionSearch._collections.default is None

# Generated at 2022-06-21 00:22:20.759873
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x.get_validated_value('collections', x._collections, "test", None) is None

# Generated at 2022-06-21 00:22:31.157571
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test _collections assignment
    search = CollectionSearch()
    assert isinstance(search._collections, FieldAttribute)

    # test load_collections
    # set a list and ensure the default collection is in the list
    search._collections = [u'collectionx', u'collectiony']
    ds = dict(collections=search._collections)
    search._load_collections(u'collections', ds)
    assert search._collections[0] != u'collectionx'
    search._collections = None
    ds = dict(collections=search._collections)
    search._load_collections(u'collections', ds)
    # ensure the default is not in the list
    assert search._collections[0] == u'collectionx'

    # test _ensure_default_collection()
    #

# Generated at 2022-06-21 00:22:41.309058
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
      Test that the constructor of CollectionSearch class 
      initialises the _collections attribute as expected
      when a default value is specified
    """
    search = CollectionSearch()
    # The search._collections attribute must be a list containing
    # 'ansible.builtin' or 'ansible.legacy' and 'ansible.builtin'.
    # The order of the collections does not matter since
    # _ensure_default_collection() calls insert() for the default collection.
    builtin = 'ansible.builtin'
    legacy = 'ansible.legacy'
    collections = search._collections

    assert(isinstance(collections, list))
    assert(len(collections) == 2)
    assert(builtin in collections)
    assert(legacy in collections)

# Generated at 2022-06-21 00:22:44.693828
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        CollectionSearch()
    except Exception as ex:
        assert False, "Exception raised: {}".format(str(ex))

# Test field attribute _collections of class CollectionSearch

# Generated at 2022-06-21 00:22:53.577953
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    item = CollectionSearch()
    assert item._collections is not None
    assert len(item._collections) == 1

# Generated at 2022-06-21 00:22:55.227007
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    assert col._load_collections('', '')


# Generated at 2022-06-21 00:22:56.009308
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch._collections, FieldAttribute)

# Generated at 2022-06-21 00:22:58.305316
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:23:03.963368
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with pytest.raises(TypeError):
        CollectionSearch()

    class Test(CollectionSearch):
        pass

    assert Test()._get_parent_attribute('collections') == _ensure_default_collection()

    class Test2(CollectionSearch):
        pass

    assert Test2()._get_parent_attribute('collections') == _ensure_default_collection()

# Generated at 2022-06-21 00:23:05.299142
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-21 00:23:07.605222
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test that it is initialized as expected
    csearch = CollectionSearch()
    assert(csearch._collections is None)

# Generated at 2022-06-21 00:23:10.723318
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collect_search = CollectionSearch()
    # Since the constructor does not accept any input, the default value is applied
    assert collect_search.collections == ['ansible_collections.azure.azcollection']

# Generated at 2022-06-21 00:23:13.045855
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    module = CollectionSearch()
    assert module._collections == _ensure_default_collection()
    assert module.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:14.912458
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    context = CollectionSearch()
    assert isinstance(context, CollectionSearch), "Context should be instance of CollectionSearch"

# Generated at 2022-06-21 00:23:30.137104
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert cs._collections is not None

# Generated at 2022-06-21 00:23:32.013742
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == 'ansible.legacy'

# Generated at 2022-06-21 00:23:33.442255
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Constructor of class CollectionSearch
    assert cs is not None

# Generated at 2022-06-21 00:23:35.432046
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()
    assert col_search.collections == ['ansible.builtin']

# Generated at 2022-06-21 00:23:39.321845
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs._load_collections('collections', ['ansible-collections.test']), list)

# Generated at 2022-06-21 00:23:45.594483
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   
    # With no arguments
    decorator = CollectionSearch()

    # With arguments
    decorator = CollectionSearch(collections = ['one', 'two', 'three'])
    collections = decorator.collections
    assert collections == ['one', 'two', 'three']

    # With keyword arguments
    collections = ['one', 'two', 'three']
    decorator = CollectionSearch(collections=collections)
    collections = decorator.collections
    assert collections == ['one', 'two', 'three']

# Generated at 2022-06-21 00:23:47.341977
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert len(cs._collections) > 0

# Generated at 2022-06-21 00:23:59.256001
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.plays import Play
    from ansible.playbook.roles import Roles
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.include.static import IncludeStatic
    from ansible.playbook.include.vars import IncludeVars
    from ansible.playbook.include.role import IncludeRole
    from ansible.playbook.include.tasks import IncludeTasks
    from ansible.playbook.include.tasks import IncludeTasks

# Generated at 2022-06-21 00:24:00.294201
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()

# Generated at 2022-06-21 00:24:07.954449
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.plugins.loader import collection_loader
    from ansible.template import Templar

    class AddCollectionSearch(Base, CollectionSearch):
        pass

    # Simulate cli argument provided.
    vault_collection = False
    my_collection = AnsibleCollectionConfig(collections=[], vault_password_files=[], vault_ids=[])

    # Simulate an empty list is provided for constructor
    # DS will be an empty list
    ds = []
    my_add_collection_search = AddCollectionSearch(ds)
    # Assert the "collections" field matches the expectations
    # Expectation:
    #   - ansible.legacy collection is always included in the list
    #   - ansible.builtin collection is always included in the list
    assert my_add_collection_search

# Generated at 2022-06-21 00:24:29.102577
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                              always_post_validate=True, static=True)
    ds1 = 'ds1'
    ds2 = 'ds2'
    task = CollectionSearch()
    assert task.collections == _ensure_default_collection()
    task._collections = ds1
    ds1 = task._load_collections('_collections', ds1)
    assert task._collections == ds1
    task._collections = ds2
    ds2 = task._load_collections('_collections', ds2)
    assert task._collections == ds2

# Generated at 2022-06-21 00:24:39.524759
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.get_value('collections') == [AnsibleCollectionConfig.default_collection]

    # Test with a single collection name, which should remain unchanged
    collection_name = 'my.collection.name'
    c = CollectionSearch(collections=collection_name)
    assert c.get_value('collections') == [AnsibleCollectionConfig.default_collection, collection_name]

    # Test with multiple collection names, which should remain unchanged.
    collection_list = ['my.collection.name', 'another.collection.name']
    c = CollectionSearch(collections=collection_list)
    assert c.get_value('collections') == [AnsibleCollectionConfig.default_collection, 'my.collection.name', 'another.collection.name']

# Generated at 2022-06-21 00:24:40.447097
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections.name == 'collections'

# Generated at 2022-06-21 00:24:44.283194
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collectionSearch = CollectionSearch()
    
    # check instance
    assert isinstance(collectionSearch, CollectionSearch)

    # check init value, should be 'ansible.builtin'
    assert 'ansible.builtin' == collectionSearch._collections

# Generated at 2022-06-21 00:24:46.962612
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._collections == _ensure_default_collection(collection_list=None)
    assert cs._collections == ['ansible.builtin']

# Generated at 2022-06-21 00:24:58.171959
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base

    class TestCollectionSearch(Base, CollectionSearch):
        pass

    # Test the default value
    test_class_instance = TestCollectionSearch({'collections': None})
    assert test_class_instance._collections == _ensure_default_collection()

    # Test the value set by the user
    test_class_instance = TestCollectionSearch({'collections': ['test']})
    assert test_class_instance._collections == _ensure_default_collection(['test'])

    # Test the template warning
    test_class_instance = TestCollectionSearch({'collections': ['{{ ansible_host }}']})
    assert test_class_instance._collections == _ensure_default_collection(['{{ ansible_host }}'])

    # Test the template warning
    test_class_

# Generated at 2022-06-21 00:25:09.374488
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    # Testing function _ensure_default_collection
    assert _ensure_default_collection(["ansible_namespace.role_name"]) == [AnsibleCollectionConfig.default_collection,
                                                                           "ansible_namespace.role_name"]
    assert _ensure_default_collection([]) == [AnsibleCollectionConfig.default_collection]
    assert _ensure_default_collection(None) == [AnsibleCollectionConfig.default_collection]
    # Testing attribute _collections
    assert [AnsibleCollectionConfig.default_collection,
            "ansible_namespace.role_name"] == test_instance._load_collections(None,
                                                                              ["ansible_namespace.role_name"])

# Generated at 2022-06-21 00:25:11.146225
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    object_instance = CollectionSearch()

    assert object_instance._collections is not None
    assert object_instance._collections.get_default() is not None

# Generated at 2022-06-21 00:25:13.979060
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection.collections == _ensure_default_collection()

    collection.collections = None
    assert collection.collections is None
    collection.collections = ['/etc/ansible/my_collections/']
    assert collection.collections == _ensure_default_collection(['/etc/ansible/my_collections/'])
    collection.collections = ['/etc/ansible/my_collections/', '/tmp/my_temp_collection/']
    assert collection.collections == _ensure_default_collection(['/etc/ansible/my_collections/', '/tmp/my_temp_collection/'])



# Generated at 2022-06-21 00:25:15.890789
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:25:47.758703
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = {'collections': ['test_collection']}

    obj = CollectionSearch()
    print("Value of _collections: %r" % (obj._collections))
    obj.post_validate(ds, False)
    print("Value of collections: %r" % (obj.get_validated_value('collections', obj._collections, ds, None)))
    print("Collections list: %r" % (ds['collections']))



# Generated at 2022-06-21 00:25:57.942368
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.utils.collection_loader import AnsibleCollectionFinder
    # Construct a PlaybookExecutor
    tqm = TaskQueueManager(PlaybookExecutor('inventory', 'playbook', tqm, 0))
    # Construct a Block

# Generated at 2022-06-21 00:26:02.049154
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    # test __init__ method, by verifying that the static field was processed
    assert collections._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:26:13.291357
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    # Test playbook name
    playbook_path = "playbooks/test/test_templating.yml"
    playbook_name = "test_templating"

    # Test write_to_file
    test_write_to_file = "tests/test_write_to_file.txt"

    # Test all templates
    # the template is supposed to be generated here
    ansible_template_path = "tests/template_files/ansible_template.yml"


# Generated at 2022-06-21 00:26:23.648818
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   if __name__ == '__main_':
       from ansible.plugins.loader import ModuleLoader
       from ansible.utils.collection_loader import AnsibleCollectionConfig
       from ansible.vars.clean import module_response

       collections = ['test', 'tmp']
       ds = module_response.ModuleResponse.dict_class()
       ds.update({'collections': collections})
       AnsibleCollectionConfig.default_collection = 'test'

       # test the basic attr flow
       cs = CollectionSearch()
       assert cs.collections is None  # doesn't work without a loader
       cs.set_loader(ModuleLoader())
       # __init__() sets the value directly, which we don't want to
       del cs._collections.value
       result = cs._load_collections(None, ds)

# Generated at 2022-06-21 00:26:25.519037
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:26:35.617461
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible.legacy']
    assert collection_search._load_collections('collections', []) == None
    assert collection_search._load_collections('collections', ['ansible_collections.foo.bar']) == ['ansible_collections.foo.bar', 'ansible_collections.ansible.builtin', 'ansible_collections.ansible.legacy']

# Generated at 2022-06-21 00:26:39.044117
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = None
    assert cs.collections == ['ansible.builtin']
    cs.collections = ['my.collection']
    assert cs.collections == ['my.collection', 'ansible.builtin']

# Generated at 2022-06-21 00:26:42.145723
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    #print(dir(collections))
    #print(collections.__dict__)
    assert collections._collections == collections.get_static_attribute('_collections')
    assert collections._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:26:43.643507
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(CollectionSearch._load_collections("collections",["ansible.builtin"]) == ["ansible.builtin"])

# Generated at 2022-06-21 00:27:50.569738
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search._collections = ['ansible.builtin','ansible.legacy','ansible.base']
    assert search._collections == ['ansible.builtin','ansible.legacy','ansible.base']
    assert search._load_collections(None, ['ansible.builtin','ansible.legacy','ansible.base']) == ['ansible.builtin','ansible.legacy','ansible.base']

    # Test with empty list
    search = CollectionSearch()
    search._collections = []
    assert search._collections == []
    assert search._load_collections(None, ['ansible.builtin','ansible.legacy','ansible.base']) == ['ansible.builtin','ansible.legacy','ansible.base']

    # Test with None
    search = Collection

# Generated at 2022-06-21 00:27:53.407869
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test(CollectionSearch):
        def __init__(self):
            self._collections = None

    assert Test().collections == ['ansible.builtin']

# Generated at 2022-06-21 00:27:57.251209
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	from ansible.playbook.attribute import FieldAttribute
	assert CollectionSearch.__dict__['_collections'] == FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection, always_post_validate=True, static=True)

# Generated at 2022-06-21 00:27:59.945505
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default is _ensure_default_collection
    assert CollectionSearch._collections.static is True
    assert CollectionSearch._collections.always_post_validate is True

# Generated at 2022-06-21 00:28:00.542998
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-21 00:28:01.950769
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_instance = CollectionSearch()
    return my_instance


# Generated at 2022-06-21 00:28:11.137004
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.task.include import TaskInclude
    from ansible.utils.collection_loader import _make_collections_list_relative

    def _insert_collections_into_attribute(base, attr_name, collection_list):
        setattr(base, attr_name, _make_collections_list_relative(collection_name_list=collection_list))

    class TestAnsiblePlaybook(CollectionSearch, Base):
        __slots__ = CollectionSearch._slots + Base._slots

        # A list of fields that this module class should get copied into
        _copy_attributes = CollectionSearch._copy_attributes + Base._copy_attributes

        # field that controls whether or not the class will be included as part of a task or not
        _task_

# Generated at 2022-06-21 00:28:12.977250
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass
    test_CollectionSearch = TestCollectionSearch()
    test_CollectionSearch._load_collections('collections',None)

# Generated at 2022-06-21 00:28:14.989126
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    data = {'collections': ['test_collection']}
    ds = CollectionSearch()
    ds.post_validate(data)
    assert data['collections'] == ['test_collection']

# Generated at 2022-06-21 00:28:19.075259
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search._collections = ['ansible.builtin', 'ansible.netcommon']
    assert search.collections == ['ansible.builtin', 'ansible.netcommon']

# Generated at 2022-06-21 00:30:53.200749
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # FIXME: this is hackish
    # the constructor has no args, so we can just override a collections.list
    # attribute and call ctor to set the class attribute
    from ansible.playbook.task_include import TaskInclude

    # expected values, after setting collections.list
    target_collections = ['ansible.builtin', 'ansible.test', 'ansible.builtin']

    # fake the collections.list with a custom TaskInclude
    class FakeTaskInclude(TaskInclude):
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                      always_post_validate=True, static=True)


# Generated at 2022-06-21 00:30:57.095027
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cls = CollectionSearch()
    assert 'ansible.builtin' in cls._load_collections(None, None)
    assert 'ansible.builtin' in cls._load_collections(None, ['foo'])
    assert 'ansible.builtin' in cls._load_collections(None, ['foo', 'bar'])
    assert 'ansible.builtin' not in cls._load_collections(None, [])
    assert not cls._load_collections(None, [])

# Generated at 2022-06-21 00:30:58.335919
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-21 00:31:00.960598
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class Inherits(object, CollectionSearch):
        pass

    instance = Inherits()
    # If a field does not exist in the object but it has a default,
    # then the default will be returned
    assert instance._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:31:12.589326
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    '''
    This class is responsible for searching ansible-collections for a role/task/etc
    '''
    # Importing necessary modules
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # Testing with the supported collection name
    collection_name = 'ansible_collections.community.general'

    # Calling the constructor of class CollectionSearch
    collection_search = CollectionSearch()

    test_obj = AnsibleCollectionConfig.default_collection
    collection_search._ensure_default_collection(test_obj)

    # Testing with the supported collection name
    collection_search._ensure_default_collection([collection_name])

    # Testing with the supported collection name
    test_obj.insert(0, collection_name)
    collection_search._ensure_default_collection(test_obj)

    # Testing with the supported

# Generated at 2022-06-21 00:31:15.537678
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:31:21.199812
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.__class__.__name__ == "_Attribute"
    assert CollectionSearch._collections.name == 'collections'
    assert CollectionSearch._collections.listof == string_types
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.always_post_validate
    assert CollectionSearch._collections.static
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.isa == 'list'

# Generated at 2022-06-21 00:31:23.255027
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)

# Generated at 2022-06-21 00:31:26.066692
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    tc = CollectionSearch()
    assert tc.collections == [AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-21 00:31:29.794963
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']
    cs.collections = ['my_collection']
    assert cs.collections == ['my_collection', 'ansible.builtin', 'ansible.legacy']