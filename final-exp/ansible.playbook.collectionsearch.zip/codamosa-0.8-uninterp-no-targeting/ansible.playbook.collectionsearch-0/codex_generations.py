

# Generated at 2022-06-21 00:21:52.265042
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()
    default_collection = AnsibleCollectionConfig.default_collection
    if default_collection:
        assert cs._collections == [default_collection]
    else:
        assert cs._collections == []

# Generated at 2022-06-21 00:21:57.284421
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch._collections = FieldAttribute(isa='list', listof=string_types,
                                                   priority=100, default=_ensure_default_collection,
                                                   always_post_validate=True, static=True)
    c = CollectionSearch()
    assert c._collections.default == _ensure_default_collection

# Generated at 2022-06-21 00:21:59.394063
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch_obj = CollectionSearch()
    assert isinstance(collectionsearch_obj._collections, object)

# Generated at 2022-06-21 00:22:01.491862
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.value == _ensure_default_collection()

# Generated at 2022-06-21 00:22:11.100305
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.template import Environment
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader.api import CollectionLoader
    from ansible.utils.display import Display

    test_args = ['foobar']

    collections = _ensure_default_collection(test_args)

    # setting up CollectionLoader, AnsilbeCollectionConfig and Display
    loader = CollectionLoader()
    loader.set_collection_paths()
    AnsibleCollectionConfig(loader).__init__()
    Display().__init__()

    # setting up CollectionSearch
    class Test(Base, CollectionSearch):
        pass

    # CollectionSearch should be a subclass of Base
    assert issubclass(CollectionSearch, Base)
    # test_CollectionSearch should be a subclass of Base

# Generated at 2022-06-21 00:22:12.408514
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections

# Generated at 2022-06-21 00:22:14.693747
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections_search = CollectionSearch()
    assert collections_search.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:22:17.599729
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._load_collections(None, None) == None


if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-21 00:22:19.693055
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:22:21.121457
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()

# Generated at 2022-06-21 00:22:35.527699
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.role import Role
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.become import Become
    from ansible.playbook.connection import Connection

    Base.register_attribute(FieldAttribute('collections', isa='list', listof=string_types, priority=100,
                                           default=_ensure_default_collection, always_post_validate=True, static=True))

    # set up the class
    class MyClass(Base, CollectionSearch):
        _name = 'myclass'

    # create an instance
    myclass = MyClass()

    # set attribute

# Generated at 2022-06-21 00:22:36.922261
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)


# Generated at 2022-06-21 00:22:38.744697
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._load_collections(None, None) is None

# Generated at 2022-06-21 00:22:41.840701
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        s = CollectionSearch(collections=['test_col'])
        assert False
    except (AssertionError, TypeError):
        assert True
    except:
        assert False

# Generated at 2022-06-21 00:22:43.476792
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections is None

# Generated at 2022-06-21 00:22:46.209590
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_search = CollectionSearch()

    # Should not raise exception
    coll_search._load_collections(None, None)



# Generated at 2022-06-21 00:22:48.053848
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:22:55.868511
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections == ['ansible.builtin', 'ansible_collections.test.test_ns.test_coll']
    assert search._collections.attributes['always_post_validate'] == True
    assert search._collections.attributes['default'] == _ensure_default_collection
    assert search._collections.attributes['listof'] == string_types
    assert search._collections.attributes['priority'] == 100
    assert search._collections.attributes['static'] == True
    assert search._collections.attributes['isa'] == 'list'


# Generated at 2022-06-21 00:23:01.497245
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.post_validation_static is True
    assert obj._collections.priority == 100
    assert obj._collections.default == _ensure_default_collection
    assert not hasattr(obj, '_collections')
    assert obj._load_collections('collections', []) is None

# Generated at 2022-06-21 00:23:07.446753
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute_container import AttributeContainer
    from ansible.playbook.task_include import TaskInclude

    task_include = TaskInclude()
    task_include._collections = ['ansible.posix', 'ansible.builtin']

    assert isinstance(task_include, AttributeContainer)
    assert task_include._collections == ['ansible.posix', 'ansible.builtin']



# Generated at 2022-06-21 00:23:22.918384
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    # c._load_collections()
    print(c)

# Generated at 2022-06-21 00:23:24.383595
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:23:29.988252
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():    
    # Initialize some parameters for constructor of class CollectionSearch
    display = Display()

    result = CollectionSearch()

    # Check the output of constructor of class CollectionSearch
    #assert result._collections == "ansible.builtin"
    assert result._collections == None
    assert result._load_collections('_collections', {}) == "ansible.builtin"

# Generated at 2022-06-21 00:23:36.360380
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    csTest = CollectionSearch()
    assert csTest._collections == _ensure_default_collection()
    assert csTest._load_collections(FieldAttribute, ['namespace.share_net_name']) == ['namespace.share_net_name', 'ansible.builtin', 'ansible.legacy']
    assert csTest._load_collections(FieldAttribute, []) == None

# Generated at 2022-06-21 00:23:39.450583
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

    cs = CollectionSearch(collections=["test"])
    assert cs._collections == _ensure_default_collection(["test"])

# Generated at 2022-06-21 00:23:41.171027
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_search = CollectionSearch()
    assert str(my_search.collections) == "['ansible.builtin']"

# Generated at 2022-06-21 00:23:42.725120
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:23:44.463804
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:46.115495
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    assert test_instance
    assert test_instance._collections is not None

# Generated at 2022-06-21 00:23:47.079495
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert s is not None

# Generated at 2022-06-21 00:24:13.796066
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_collection = CollectionSearch()
    assert search_collection

# Generated at 2022-06-21 00:24:17.544957
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs_dict = cs._load_collections('collections', ['test', 'test1'])
    assert cs_dict == ['test', 'test1', 'ansible.builtin']

# Generated at 2022-06-21 00:24:18.505260
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)

# Generated at 2022-06-21 00:24:20.567039
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:24:22.770154
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch([ansible.builtin])
    assert cs._collections == [ansible.builtin]


# Generated at 2022-06-21 00:24:24.616400
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._load_collections() == _ensure_default_collection()

# Generated at 2022-06-21 00:24:25.907476
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a=CollectionSearch()
    print(a._collections)

# Generated at 2022-06-21 00:24:29.770438
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_search = CollectionSearch()
    # Check if Collections object is created
    assert test_collection_search is not None
    assert test_collection_search._collections is not None
    assert test_collection_search._collections.default is not None
    assert test_collection_search._collections.default() is not None
    assert test_collection_search._load_collections is not None

# Generated at 2022-06-21 00:24:31.306160
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert(search.collections == ['ansible.builtin', 'ansible.legacy'])

# Generated at 2022-06-21 00:24:32.652807
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:25:28.072752
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    fixture = CollectionSearch()

    result = fixture._load_collections(attr=None, ds=None)
    assert result == [default_collection] or result == ['ansible.legacy']

# Generated at 2022-06-21 00:25:31.132209
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    value = CollectionSearch()
    value._load_collections('collections', [])
    default_collection = AnsibleCollectionConfig.default_collection
    if default_collection:
        assert value._collections.default_value[0] == default_collection

# Generated at 2022-06-21 00:25:31.562913
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert Vie

# Generated at 2022-06-21 00:25:39.629141
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.task.meta import TaskMetadata
    test_instance = CollectionSearch()
    assert test_instance.get_validated_value('collections', 'ansible.builtin', None, None) == ['ansible.builtin']

    test_instance.collections = ['ansible_collections.test_namespace.test_collection']
    assert test_instance.collections == ['ansible_collections.test_namespace.test_collection']

    test_instance.collections = 'ansible_collections.test_namespace.test_collection'
    assert test_instance.collections == ['ansible_collections.test_namespace.test_collection']


# Generated at 2022-06-21 00:25:51.120731
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Method to set up the CollectionSearch class with arguments to test __init__()
    def setup_CollectionSearch(args):
        CollectionSearch.__init__(CollectionSearch, args)

    # Method to test __init__() when the required argument is not passed
    def test_no_required_argument_passed():
        args = {}
        with pytest.raises(Exception) as excinfo:
            setup_CollectionSearch(args)
        assert 'the following arguments are required: collections' in str(excinfo.value)

    # Method to test __init__() when a non-string object is passed in 'collections'
    def test_pass_non_string_object_in_collections():
        args = {'collections': []}
        with pytest.raises(Exception) as excinfo:
            setup_CollectionSearch(args)


# Generated at 2022-06-21 00:25:52.895063
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    if not isinstance(obj, CollectionSearch):
        raise AssertionError()

# Generated at 2022-06-21 00:25:56.817761
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    
    assert not CollectionSearch().collections
    assert CollectionSearch().collections == ['ansible.legacy']
    assert CollectionSearch().collections == ['ansible_collections.nti310.nti310.plugins.modules.custom_plugin', 'ansible.legacy']

# Generated at 2022-06-21 00:26:05.758325
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Load a class object of CollectionSearch
    class TestCollectionSearch(CollectionSearch):
        pass
    # Create a instance of TestCollectionSearch
    test_collection_search = TestCollectionSearch()
    # Test _load_collections method
    test_collection_search._load_collections('collections', 'ansible.posix')
    # Test __repr__ method
    assert str(test_collection_search) == "TestCollectionSearch()"
    # Test __eq__ method
    assert test_collection_search == test_collection_search

# Generated at 2022-06-21 00:26:16.862952
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    msg = "instance of type 'CollectionSearch' has no len()"
    with pytest.raises(TypeError, match=msg):
        # No len() method, so len(instance) raises TypeError
        len(instance)
    # len() is a special method in Python, and so to check that it exists,
    # you must use the hasattr() function
    assert not hasattr(instance, "__len__")
    # Similarly, the instance does not have a getitem()
    msg = "instance of type 'CollectionSearch' has no __getitem__()"
    with pytest.raises(TypeError, match=msg):
        instance[1]
    assert not hasattr(instance, "__getitem__")
    # The instance is not subscriptable

# Generated at 2022-06-21 00:26:22.040711
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.mod_args import ModuleArgsParser

    # If a constructor uses a dict or a list extracted from another dict, then we need to pass a dict
    # That has the key with empty value
    args = dict(collections=[])
    b = ModuleArgsParser(data=args)

    assert _ensure_default_collection(collection_list=b.collections) == ['ansible.legacy', 'ansible_collections.nsweb.test']

# Generated at 2022-06-21 00:27:30.261656
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()

    assert c._load_collections('collections', None) is None

# Generated at 2022-06-21 00:27:33.268445
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch(collections=[])
    assert collection_search.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:27:35.297556
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == cs._load_collections(None, None)

# Generated at 2022-06-21 00:27:36.954504
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert "testcollection" == CollectionSearch._load_collections(None, ["testcollection"])

# Generated at 2022-06-21 00:27:39.816891
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # This is what we are testing, we want the ansible.builtin collection to be added to the list.
    assert 'ansible.builtin' in cs._load_collections(attr='collections', ds=[])

# Generated at 2022-06-21 00:27:42.091326
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c_search = CollectionSearch()
    c_search._load_collections(None, None)
    assert c_search is not None

# Generated at 2022-06-21 00:27:43.694284
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:27:47.332207
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    # Test 1: test default value of "collections" attribute
    assert t._collections == _ensure_default_collection()

    # Test 2: test when "collections" attribute is an empty list
    ds1 = []
    t._load_collections(None, ds1)
    assert t._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:27:48.082245
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)

# Generated at 2022-06-21 00:27:50.229555
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Test when attr is None
    assert cs._load_collections(None, None) is None

# Generated at 2022-06-21 00:30:20.303931
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    item_list = []
    c1 = ["foo", "bar"]
    c2 = "baz"
    c3 = None
    item_list.append(c1)
    item_list.append(c2)
    item_list.append(c3)
    for i in item_list:
        cs = CollectionSearch()
        print(cs._load_collections("collections", i))


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:30:26.687204
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    assert test_instance.collections == [], "Setting collection to empty list failed"
    assert test_instance.collections == [], "Default collection is not set"
    test_instance.collections = ["collection"]
    assert test_instance.collections == ["collection"], "Collection is not set"

# Generated at 2022-06-21 00:30:27.971566
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-21 00:30:31.206514
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:30:32.584945
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.collections == ['ansible_namespace.name_of_collection', 'ansible.builtin']

# Generated at 2022-06-21 00:30:40.683354
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    print('Hello World!')
    print('This is program to test CollectionSearch')

    collectionSearch = CollectionSearch()

    _collections1 = collectionSearch._collections
    print(_collections1)

    # FIXME
    # In the future, need to add more testing for the function '_ensure_default_collection'
    # Now we only tested the assignment
    _collections2 = collectionSearch._ensure_default_collection()

    print(_collections2)


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:30:48.396905
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import IncludeRole
    # test for class being created for first time
    a = CollectionSearch()
    # test for it being created a second time
    b = CollectionSearch()
    # test that id's are the same if the class is created a second time
    assert(id(a) == id(b))

# Generated at 2022-06-21 00:30:50.474582
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds=CollectionSearch()
    print(ds._load_collections("collections", ds))
    print("All tests for CollectionSearch passed :)")

#test_CollectionSearch()

# Generated at 2022-06-21 00:30:51.377608
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()

# Generated at 2022-06-21 00:30:57.266858
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    if not isinstance(collection_search, CollectionSearch):
        raise Exception('Object is of type {} and not CollectionSearch'.format(type(collection_search)))

if __name__ == '__main__':
    collection_search = CollectionSearch()
    test_CollectionSearch()