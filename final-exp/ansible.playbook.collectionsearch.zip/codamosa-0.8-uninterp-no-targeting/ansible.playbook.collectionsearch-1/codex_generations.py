

# Generated at 2022-06-21 00:21:53.168597
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest

    with pytest.raises(SystemExit) as e:
        CollectionSearch()
    assert e.value.code == 1

    result = CollectionSearch()
    assert result._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:21:57.327324
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert 'ansible.builtin' in cs._collections or 'ansible.legacy' in cs._collections
    assert len(cs._collections) > 0

# Generated at 2022-06-21 00:21:59.855667
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:22:02.219848
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        CollectionSearch()
    except Exception:
        assert False, 'Unit test for constructor of class CollectionSearch failed'


# Generated at 2022-06-21 00:22:04.069246
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == _ensure_default_collection()


# Generated at 2022-06-21 00:22:04.672587
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-21 00:22:07.023347
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections("collections", ["ansible.builtin", "ansible.netcommon"])

# Generated at 2022-06-21 00:22:14.453341
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.playbook.role.definition import RoleDefinition

    class MyObj(Base, CollectionSearch):
        _collections = [
            'collection_1',
            'collection_2',
            'collection_3',
        ]

    assert isinstance(MyObj._collections, FieldAttribute)

    def _ensure_default_collection(collection_list):
        if collection_list is None:
            collection_list = []

        if not collection_list or 'collection_1' not in collection_list:
            collection_list.insert(0, 'collection_1')

        return collection_list

    obj = MyObj()
    assert obj.collections == _ensure_default_collection(MyObj._collections)

    #

# Generated at 2022-06-21 00:22:22.585396
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert isinstance(search._collections, FieldAttribute)
    assert isinstance(search._collections.default, Callable)
    assert search._collections.static == True
    assert search._collections.always_post_validate == True
    assert isinstance(search._collections.isa, str)
    assert isinstance(search._collections.listof, type)
    assert search._collections.priority == 100
    assert isinstance(search._load_collections, Callable)

# Generated at 2022-06-21 00:22:23.630047
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   assert isinstance(CollectionSearch(), CollectionSearch)

# Generated at 2022-06-21 00:22:32.132546
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    obj = CollectionSearch()
    assert obj._collections.name == 'collections'
    assert 'ansible.legacy' in obj._collections.default

# Generated at 2022-06-21 00:22:35.407382
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.__setattr__('collections', 'ansible.builtin')
    assert collection_search._load_collections('collections', 'ansible.builtin') is not None

# Generated at 2022-06-21 00:22:43.869383
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert isinstance(instance._collections, FieldAttribute)
    assert instance._collections.name == 'collections'
    assert instance._collections.isa == 'list'
    assert isinstance(instance._collections.listof, string_types)
    assert instance._collections.priority == 100
    assert instance._collections.default is _ensure_default_collection
    assert instance._collections.always_post_validate is True
    assert instance._collections.static is True
    assert instance._collections.deprecated_aliases == []
    assert instance._collections.aliases == []

# Generated at 2022-06-21 00:22:45.575976
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert isinstance(search, CollectionSearch)


# Generated at 2022-06-21 00:22:48.053620
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search._load_collections('collections', None)

# Generated at 2022-06-21 00:22:56.477750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # importing class CollectionSearch to test constructor
    from ansible.playbook.role.definition import CollectionSearch
    # test for collection_list=None
    col_search = CollectionSearch()
    if col_search._collections.default(col_search).collections != "ansible.builtin":
        raise AssertionError("_ensure_default_collection() test failed")
    # test for collection_list=["test1","test2"]
    col_search = CollectionSearch(["test1","test2"])
    if col_search._collections.default(col_search).collections != "ansible.builtin":
        raise AssertionError("_ensure_default_collection() test failed")

# Generated at 2022-06-21 00:22:58.098713
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-21 00:22:59.954738
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search=CollectionSearch()
    collection_search._load_collections([])
    print(collection_search)

# Generated at 2022-06-21 00:23:02.207987
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    print(a._load_collections(None, None))


# Generated at 2022-06-21 00:23:12.854366
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.definition import RoleDefinition

    # For __init__()
    # Need a playbook object for __init__()
    play_name = "test_play_name"
    play_hosts = "test_play_hosts"
    play_roles = "test_play_roles"
    play_tasks = "test_play_tasks"
    play_handlers = "test_play_handlers"
    play_vars = "test_play_vars"
    play_vars_prompt = "test_play_vars_prompt"

# Generated at 2022-06-21 00:23:32.103608
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search=CollectionSearch()
    print(type(search))
    print(search.collections)
    print(type(search.collections))
    print(CollectionSearch._collections)
    print(type(CollectionSearch._collections))
    print(search._load_collections('collections', ['collection1', 'collection2']))
if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:23:41.847318
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest

    from ansible.playbook.role import Role
    from ansible.playbook.tasks import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.template import get_template_class

    r = Role()
    r._collections = ['col1','col2']

    t = Task()
    t._collections = ['col3','col4']

    h = Handler()
    h._collections = ['col5','col6']

    b = Block(task_include='task')

    # with pytest.raises(TypeError) as excinfo:
    #     b._collections = ['col7', 'col8']
    # assert "can't set attribute" in str(excinfo.value)

    # assert r._collections ==

# Generated at 2022-06-21 00:23:45.552820
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Unit test for constructor of class CollectionSearch"""
    module = CollectionSearch()
    print("\n name = ", module.name)
    print("\n version = ", module.version)
    print("\n plugin_type = ", module.plugin_type)


# Generated at 2022-06-21 00:23:48.083293
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    clz = CollectionSearch()
    attr = clz._collections
    ds = None
    assert clz._load_collections(attr, ds) == attr.default

# Generated at 2022-06-21 00:23:56.207487
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert (c._collections._default == [])
    assert (c._collections._name == "collections")
    assert (c._collections._always_post_validate is True)
    assert (c._collections._static is True)
    assert (c._collections._priority == 100)
    assert (c._collections._listof == string_types)
    assert (c._collections._isa == 'list')
    assert (c._load_collections == None)

# Generated at 2022-06-21 00:24:05.356305
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    result = c._load_collections(attr=None, ds=None)
    assert isinstance(result, list) and len(result) == 1 and result == ['ansible.builtin']
    result = c._load_collections(attr=None, ds=["ansible_collections.org"])
    assert isinstance(result, list) and len(result) == 2 and result == ['ansible_collections.org', 'ansible.builtin']
    result = c._load_collections(attr=None, ds=["ansible_collections.org", "something else"])
    assert isinstance(result, list) and len(result) == 3 and result == ['ansible_collections.org', 'something else', 'ansible.builtin']

# Generated at 2022-06-21 00:24:07.030061
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #raise Exception("Test not yet implemented")
    obj = CollectionSearch()
    print(obj)

# Generated at 2022-06-21 00:24:18.226265
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test empty string and None
    test = CollectionSearch()
    assert test._collections.default == _ensure_default_collection()

    # Test with a valid value
    test = CollectionSearch(collections=['some.collection'])
    assert isinstance(test._collections.default, list)
    assert 'some.collection' in test._collections.default
    assert 'ansible.builtin' in test._collections.default
    assert 'ansible.legacy' in test._collections.default

    # Test with a list
    test = CollectionSearch(collections=['some.collection', 'some.other.collection'])
    assert isinstance(test._collections.default, list)
    assert 'some.collection' in test._collections.default
    assert 'some.other.collection' in test._collections.default
   

# Generated at 2022-06-21 00:24:19.911954
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is not None

# Generated at 2022-06-21 00:24:25.081612
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    for i in ["ansible.builtin", "ansible.legacy"]:
        assert(i in c._collections)
    for i in c._collections:
        assert(i in [ "ansible.builtin", "ansible.legacy"])

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:24:51.549406
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    return c._collections

# Generated at 2022-06-21 00:24:53.001081
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _ = CollectionSearch()
    assert _.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:24:54.958795
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("Testing constructor of CollectionSearch")
    cs = CollectionSearch()
    print(cs)


# Generated at 2022-06-21 00:24:56.462788
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)

# Generated at 2022-06-21 00:24:57.504582
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search

# Generated at 2022-06-21 00:24:59.192834
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:25:09.622270
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj.__dict__['_collections'] = None
    obj.__dict__['_collections_value'] = None

    # Template string for testing
    str1 = 'test_ansible_collections.test_ns.test_coll.test_playbook'
    str2 = 'test_ansible_collections.test_ns.test_coll.test_playbook.test_role'
    str3 = 'test_ansible_collections.test_ns.test_coll.test_playbook.test_plugin'
    str4 = 'test_ansible_collections.test_ns.test_coll.test_playbook.test_module'
    str5 = 'test_ansible_collections.test_ns.test_coll.test_playbook.test_filter_plugin'

    #

# Generated at 2022-06-21 00:25:10.128190
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

# Generated at 2022-06-21 00:25:11.260479
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), AnsibleCollectionConfig)


# Generated at 2022-06-21 00:25:13.263299
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    # default value of _collections
    assert obj._collections == _ensure_default_collection()
    # _collections is list



# Generated at 2022-06-21 00:26:07.250338
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   if not hasattr(CollectionSearch,'_collections'):
      assert False,'No _collections defined for CollectionSearch'

if __name__ == '__main__':
   test_CollectionSearch()

# Generated at 2022-06-21 00:26:08.299709
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-21 00:26:09.690467
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection

# Generated at 2022-06-21 00:26:11.468583
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch, '_collections')

# Generated at 2022-06-21 00:26:18.078346
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test that collections is automatically parsed out of the constructor
    cs = CollectionSearch(collections=["foo_collection"])
    assert cs.collections == ["foo_collection"]

    # test that collections is parsed without the default of legacy
    cs = CollectionSearch(collections=[])
    assert cs.collections == []

    # test that collections is parsed with the default of legacy
    cs = CollectionSearch(collections=None)
    assert cs.collections == ["ansible.legacy"]

# Generated at 2022-06-21 00:26:18.605810
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-21 00:26:22.118884
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    b = Block(block=dict())
    rd = RoleDefinition()
    rd._load_collections(['test'], [])
    b._load_collections(['test'], [])

# Generated at 2022-06-21 00:26:30.350358
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is None
    assert cs.get_validated_value('collections', cs._collections, ['ansible.builtin'], None) == ['ansible.builtin']
    assert cs.get_validated_value('collections', cs._collections, None, None) is None
    assert cs.get_validated_value('collections', cs._collections, None, None) is None
    assert cs.get_validated_value('collections', cs._collections, ['ansible.builtin'], None) == ['ansible.builtin']

# Generated at 2022-06-21 00:26:34.493690
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(None, []) == ['ansible.builtin', 'ansible.legacy']
    assert CollectionSearch()._load_collections(None, ['ansible_namespace.collection_name']) == ['ansible_namespace.collection_name', 'ansible.legacy']

# Generated at 2022-06-21 00:26:36.673435
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    expected_collections = _ensure_default_collection()
    actual_collections = CollectionSearch().collections
    assert actual_collections == expected_collections

# Generated at 2022-06-21 00:27:42.386668
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert not hasattr(collection_search, '_collections')

# Generated at 2022-06-21 00:27:47.586536
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)

    collectionsearch = CollectionSearch()
    collectionsearch._collections = _collections

    # Test the constructor of CollectionSearch
    assert type(collectionsearch._collections) is not None
    assert collectionsearch._collections == _collections
    assert type(collectionsearch._collections) is FieldAttribute


# Generated at 2022-06-21 00:27:49.994407
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class test(CollectionSearch):
        def __init__(self):
            pass

    obj = test()
    assert(obj._collections == ['ansible.legacy'])

# Generated at 2022-06-21 00:27:51.626879
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == ['ansible.builtin']



# Generated at 2022-06-21 00:27:55.071839
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection.collections == ['ansible.builtin', 'ansible.legacy']
    collection.collections = []
    assert collection.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:27:55.729520
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-21 00:27:59.563849
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.__dict__['_collections'].default() is None
    assert isinstance(collection_search.__dict__['_collections'].default(), list)


# Generated at 2022-06-21 00:28:01.286237
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    collections._collections = None
    assert collections._collections == None

# Generated at 2022-06-21 00:28:08.153674
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert (CollectionSearch._load_collections(None, ['ansible.builtin']) == ['ansible.builtin'])
    assert (CollectionSearch._load_collections(None, ['dummy']) == ['dummy'])

    assert (CollectionSearch._load_collections(None, [None]) == None)
    assert (CollectionSearch._load_collections(None, []) == None)

    assert (CollectionSearch._load_collections(None, ['dummy','ansible.builtin']) == ['dummy','ansible.builtin'])

# Generated at 2022-06-21 00:28:15.393790
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an instance of class CollectionSearch
    collection_search = CollectionSearch()
    # check the type of variable
    assert type(collection_search) == CollectionSearch
    # check the variable is an instance of class
    assert isinstance(collection_search, CollectionSearch)
    # check the type of attribute '_collections'
    assert type(collection_search._collections) == FieldAttribute
    # check the type of attribute '_collections.isa'
    assert type(collection_search._collections.isa) == str
    # check the value of attribute '_collections.listof'
    assert collection_search._collections.listof == string_types
    # check the value of attribute '_collections.priority'
    assert collection_search._collections.priority == 100
    assert callable(collection_search._collections.default)

# Generated at 2022-06-21 00:30:39.986987
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert isinstance(a, CollectionSearch)

# Generated at 2022-06-21 00:30:52.651550
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    obj = {'collections': [u'ansible.builtin',u'ansible.legacy']}
    ds = cs.post_validate(obj, None)
    cs._load_collections('collections', ds)

    obj = {'collections': [u'ansible.builtin']}
    ds = cs.post_validate(obj, None)
    cs._load_collections('collections', ds)

    obj = {'collections': [u'ansible.builtin',u'community.azure']}
    ds = cs.post_validate(obj, None)
    cs._load_collections('collections', ds)

    obj = {'collections': []}
    ds = cs.post_validate(obj, None)


# Generated at 2022-06-21 00:30:55.783422
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert len(_ensure_default_collection()) == 1
    assert 'ansible.legacy' in _ensure_default_collection()

# Generated at 2022-06-21 00:31:00.225526
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    tp = CollectionSearch()
    assert tp._validate_collections(None) is None
    assert tp._validate_collections([]) is None
    assert tp._validate_collections(["col1", "col2"]) == ["col1", "col2", "ansible.legacy"]

# Generated at 2022-06-21 00:31:03.928778
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    # Test the constructor of CollectionSearch
    if test_instance:
        print('ok: object of class CollectionSearch')

# Generated at 2022-06-21 00:31:09.526159
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = {"collections": ['one', 'two']}
    col_srch = CollectionSearch()
    col_srch._load_collections('collections', ds)
    assert col_srch._collections == ['one', 'two', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:31:11.758349
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is None

# Generated at 2022-06-21 00:31:18.861606
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections.default == _ensure_default_collection
    assert collection.collections == _ensure_default_collection()
    assert collection.collections == [AnsibleCollectionConfig.default_collection]
    assert collection.get_validated_value('collections', collection._collections, [], None) is None


# Generated at 2022-06-21 00:31:21.860396
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    print(c._collections)
    
    

# Generated at 2022-06-21 00:31:25.411528
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections("collections", "ansible.builtin") is not None
