

# Generated at 2022-06-21 00:21:57.033093
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default() == _ensure_default_collection()

# Generated at 2022-06-21 00:22:02.941587
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    collections = ['custom.collection']
    Setup = type(
        'Setup',
        (Base, CollectionSearch),
        {'_collections': collections}
    )
    s = Setup()
    assert s._loaded_collections == collections

# Inject an empty default collection list

# Generated at 2022-06-21 00:22:04.720742
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:22:12.389006
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection(collection_list=None)

    cs = CollectionSearch()
    cs._collections = None
    assert cs._collections == _ensure_default_collection(collection_list=None)

    cs = CollectionSearch()
    cs._collections = ['ansible.builtin']
    assert cs._collections == _ensure_default_collection(collection_list=None)

    cs = CollectionSearch()
    cs._collections = ['ansible.builtin', 'test']
    assert cs._collections == _ensure_default_collection(collection_list=['test'])


# Generated at 2022-06-21 00:22:13.836367
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:22:17.074953
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_object = CollectionSearch()
    assert collection_search_object is not None
    assert collection_search_object._collections is not None
    assert type(collection_search_object._collections) == type(list())

# Generated at 2022-06-21 00:22:21.326773
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    collections = ['ansible.builtin', 'ansible.legacy', 'namespace.collection1']
    cs._load_collections('collections', collections)
    assert collections == cs.collections

# Generated at 2022-06-21 00:22:23.548011
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Pass no parameter
    assert 'ansible.builtin' in cs._load_collections('collections', None)

# Generated at 2022-06-21 00:22:27.181853
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test constructor of CollectionSearch class
    test_obj = CollectionSearch()
    assert test_obj._collections.static
    assert test_obj._collections.name == 'collections'
    assert test_obj._collections.listof == string_types

# Generated at 2022-06-21 00:22:30.542616
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Test empty constructor
    ds = CollectionSearch()

    #Test the constructor with value of 'collections' attr
    collections = ['one.collections', 'two.collections']
    ds = CollectionSearch(collections)

# Generated at 2022-06-21 00:22:38.291309
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections

# Generated at 2022-06-21 00:22:39.854659
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:22:50.199977
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # initialize CollectionSearch
    collection_search = CollectionSearch()
    if(type(collection_search) != CollectionSearch):
        raise AssertionError('CollectionSearch() does not initialize correctly')
    # ensure that the default collection is specified in the list
    if('ansible.builtin' not in collection_search._collections):
        raise AssertionError('CollectionSearch() does not contain "ansible.builtin" in its collection list')
    # ensure that the second item in the list is a valid collection
    collection_search._collections.insert(1, 'test.collection')
    if(len(collection_search._collections) != 2):
        raise AssertionError('CollectionSearch() does not contain a valid collection in its collection list')

# Generated at 2022-06-21 00:22:56.443328
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    #test for FieldAttribute class for _collections
    assert isinstance(obj._collections, FieldAttribute)
    #test attributes of _collections
    assert obj._collections.default == _ensure_default_collection
    assert obj._collections.static == True
    assert obj._collections.listof == string_types
    assert obj._collections.priority == 100
    assert obj._collections.always_post_validate == True
    assert obj._collections.isa == "list"

# Generated at 2022-06-21 00:22:57.427123
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections is not None

# Generated at 2022-06-21 00:22:59.855765
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections._get_data(collection_search) == _ensure_default_collection()

# Generated at 2022-06-21 00:23:06.589844
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections._name == "collections"
    assert collection_search._collections._isa == "list"
    assert collection_search._collections._listof == string_types
    assert collection_search._collections._priority == 100
    assert collection_search._collections._default == _ensure_default_collection
    assert collection_search._collections._attributes == dict()
    assert collection_search._collections._static == True

# Generated at 2022-06-21 00:23:08.168837
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    t._load_collections(1,2)

# Generated at 2022-06-21 00:23:11.791951
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections is None
    assert obj._collections is not None
    assert len(obj._collections.fields) == 1
    assert obj._collections.fields[0].name == 'collections'

# Generated at 2022-06-21 00:23:14.251576
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible_collections.some_namespace.some_collection']

test_CollectionSearch()

# Generated at 2022-06-21 00:23:34.654651
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an instance of class Collection
    collection_search = CollectionSearch()

    # For unit test, call the _ensure_default_collection method to add the default
    # collection to the default_collections attribute
    _ensure_default_collection(collection_search._collections)

    # Verify that the default and passed collection names are present in the
    # default_collection attribute after running _ensure_default_collection method
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:23:39.491017
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.role.include import RoleInclude

    a = Base()
    b = RoleInclude()
    assert a.collections == ['ansible_collections.ansible.builtin']
    assert b.collections == ['ansible_collections.ansible.builtin']

# Generated at 2022-06-21 00:23:41.694383
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    dmm = CollectionSearch()
    dmm._collections = []
    assert dmm._load_collections("collections", []) is None

# Generated at 2022-06-21 00:23:43.361635
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert _ensure_default_collection() == cs._load_collections(None, None)

# Generated at 2022-06-21 00:23:44.897491
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is None

# Generated at 2022-06-21 00:23:56.412889
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook_context import PlaybookContext
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.playbook import Playbook
    from ansible.utils.vars import combine_vars

    collections = [{
        "name": "my_collection",
        "path": "/home/username/project/my_collection",
    }]

    loader = None
    task_queue_manager = TaskQueueManager(loader=loader, inventory=None, variable_manager=None)


# Generated at 2022-06-21 00:23:58.658257
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        p = CollectionSearch()
        assert (p is not None)
    except SystemExit as e:
        assert False, 'should not throw exception'

# Generated at 2022-06-21 00:24:00.639087
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections._value == ['ansible.builtin']

# Generated at 2022-06-21 00:24:05.597812
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    assert collection_search._collections.default == _ensure_default_collection
    assert collection_search._collections.listof == string_types
    assert collection_search._collections.isa == 'list'
    assert collection_search._collections.priority == 100
    assert collection_search._collections.always_post_validate is True
    assert collection_search._collections.static is True


# Generated at 2022-06-21 00:24:16.742469
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    ds = [
        'ansible.builtin',
        'ansible.builtin.collections'
    ]

    collection_search = CollectionSearch()
    val = collection_search._load_collections(None, ds)
    assert val == ds

    collection_search = CollectionSearch()
    ds = [
        'ansible.legacy'
    ]
    val = collection_search._load_collections(None, ds)
    assert val == ds

    collection_search = CollectionSearch()
    ds = [
        'ansible.builtin'
    ]
    val = collection_search._load_collections(None, ds)
    assert val == ds

    collection_search = CollectionSearch()

# Generated at 2022-06-21 00:24:44.406195
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    assert cs._load_collections('collections', None) == cs._collections

# Generated at 2022-06-21 00:24:45.786967
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test1 = CollectionSearch()
    assert test1._collections == ['collection1', 'collection2']

# Generated at 2022-06-21 00:24:48.147980
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:24:49.625503
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a=CollectionSearch()
    assert a._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:24:52.087965
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections is not None
    assert obj.collections == ['ansible.builtin']

# Generated at 2022-06-21 00:24:54.341443
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()
    assert c._collections == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-21 00:24:57.602704
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class DummyClass(CollectionSearch):
        pass
    dummyClass = DummyClass()
    assert dummyClass._collections.value == _ensure_default_collection()

# Generated at 2022-06-21 00:25:08.505559
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    import pytest

    test_yaml = """
    test_yaml:
      collections:
      - os
      - rahul.rajput
      - ansible.posix
      - ansible.windows
      - ansible.builtin
      - ansible.netcommon
      - ansible.io
      - ansible.network
      - ansible.icx
      - ansible.nxos
      - ansible.fortios
      - ansible.junos
    """

    from ast import literal_eval
    ds = literal_eval(test_yaml)

    collectionsearch = CollectionSearch()
    collectionsearch._collections = ds['test_yaml']['collections']


# Generated at 2022-06-21 00:25:14.183096
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    ds = AnsibleLoader(None, None).construct_mapping(None, [('collections', ['test_collection', 'ansible.builtin'])])
    inst = CollectionSearch()
    inst.post_validate({}, ds)
    assert isinstance(ds, AnsibleMapping)
    assert len(ds.keys()) == 1
    assert 'collections' in ds
    assert len(ds['collections']) == 2

# Generated at 2022-06-21 00:25:19.587866
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs
    assert cs.collections == _ensure_default_collection()

    cs = CollectionSearch(collections=['namespaced'])
    assert cs
    assert cs.collections == _ensure_default_collection(['namespaced'])

# Generated at 2022-06-21 00:26:20.069278
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import Include
    from ansible.playbook.taggable import Taggable

    test_collections = _ensure_default_collection()
    Block().__class__ = type('Block', (Block, CollectionSearch), {})
    test_block = Block(collections=test_collections)
    assert test_block._collections == test_collections

    RoleDefinition().__class__ = type('RoleDefinition', (RoleDefinition, CollectionSearch), {})
    test_role_definition = RoleDefinition(collections=test_collections)
    assert test_role_definition._collections == test_collections


# Generated at 2022-06-21 00:26:21.145497
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert isinstance(collection, CollectionSearch)

# Generated at 2022-06-21 00:26:22.108922
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # TODO(kolya): implement unit test for constructor of class CollectionSearch
    assert False

# Generated at 2022-06-21 00:26:25.053120
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollections(CollectionSearch):
        pass
    
    c = TestCollections()
    c._load_collections(None, ['collections.galaxy.example.test'])

# Generated at 2022-06-21 00:26:26.523433
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections == ['ansible.posix']

# Generated at 2022-06-21 00:26:30.899021
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition

    test_col = RoleDefinition()
    assert isinstance(test_col.collections, list)
    assert len(test_col.collections) == 1
    assert test_col.collections[0] == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-21 00:26:33.962755
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()
    assert cs._load_collections(None, ['a', 'b', 'c']) is None

# Generated at 2022-06-21 00:26:38.396229
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._collections.default is not None
    assert callable(cs._collections.default)
    assert isinstance(cs._collections.default, type(cs._ensure_default_collection))


# Generated at 2022-06-21 00:26:40.053639
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:26:42.317856
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)
    assert isinstance(CollectionSearch(), object)
    assert isinstance(CollectionSearch(), FieldAttribute)


# Generated at 2022-06-21 00:27:46.866982
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch(collections=['chandrahallaballi.cicd-role'])
    assert x.collections == ['chandrahallaballi.cicd-role']

# Generated at 2022-06-21 00:27:48.442849
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = None
    obj = CollectionSearch()
    assert obj is not None
    assert obj.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:27:50.267759
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()

    # Test that the constructor doesn't throw exception
    assert(collection is not None)

# Generated at 2022-06-21 00:27:53.839073
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_obj = CollectionSearch()
    assert search_obj._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:27:55.540246
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    #assert collection_search._collections.default == ['ansible.builtin']

# Generated at 2022-06-21 00:28:01.540855
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    adict1 = {'c1': 'my_first_collection',
              'c2': ['my_second_collection', 'my_third_collection'],
              'c3': 'my_fourth_collection'}
    a = CollectionSearch()
    a.post_validate(adict1, None)
    assert a.collections == ['ansible.builtin']
    assert a.post_validate(adict1, []) is None

# Generated at 2022-06-21 00:28:04.669446
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an instance of class CollectionSearch
    collection_search = CollectionSearch()
    # Output the value of "_collections"
    print(collection_search._collections)
# test_CollectionSearch()

# Generated at 2022-06-21 00:28:11.348472
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.playbook.role_include import IncludeRole
    from collections import namedtuple

    attr = namedtuple('attr', 'name')
    class_var = attr(name='collections')
    ds = attr(name='Ansible.Role.Collection')

    cr = CollectionSearch()
    cr._load_collections(class_var, ds)
    assert(cr.collections[0] == 'Ansible.Role.Collection')
    assert(cr.collections[1] == 'ansible.builtin')
    assert(cr.collections[2] == 'ansible.legacy')

# Generated at 2022-06-21 00:28:19.106000
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_data_1 = {'collections': ['us.ansible.collections.example', 'ansible.builtin']}
    test_data_2 = {'collections': ['us.ansible.collections.example', 'ansible.builtin', 'ansible.legacy']}
    test_data_3 = {'collections': ['ansible.builtin']}
    test_data_4 = {'collections': ['ansible.legacy']}
    test_data_5 = {'collections': ['us.ansible.collections.example']}
    test_data_6 = {'collections': ['ansible.builtin', 'ansible.legacy']}
    test_data_7 = {'collections': ['ansible.builtin', 'us.ansible.collections.example']}
   

# Generated at 2022-06-21 00:28:21.558238
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()
    assert obj._collections.default == _ensure_default_collection()

# Generated at 2022-06-21 00:30:44.641584
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.always_post_validate
    assert collection_search._collections.default == 'ansible_collections.test_namespace.test_collection'

# Generated at 2022-06-21 00:30:47.596444
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Unit test for constructor of class CollectionSearch"""
    collection_search = CollectionSearch()
    assert collection_search

# Generated at 2022-06-21 00:30:51.584849
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test for the constructor
    assert CollectionSearch._collections.default() == _ensure_default_collection()
    assert CollectionSearch._collections.default([]) == ['ansible.legacy']

    # Test for the _load_collections method
    assert CollectionSearch()._load_collections("collections", None) is None

# Generated at 2022-06-21 00:30:52.620602
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is not None

# Generated at 2022-06-21 00:30:58.533998
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import iteritems
    base = Base.load(dict(), collection_list=['ansible.builtin'], task_loader=None, variable_manager=None, loader=None)
    assert base is not None, 'Error creating Base class'
    base.post_validate(validate_templated_fields=False)
    assert 'ansible.builtin' == base._collections[0], 'Error in initializing expected value'
    base = Base.load(dict(), collection_list=None, task_loader=None, variable_manager=None, loader=None)
    assert base is not None, 'Error creating Base class'

# Generated at 2022-06-21 00:31:00.358306
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == 'ansible.builtin' or obj._collections == 'ansible.legacy'
    print(obj._collections)

# Generated at 2022-06-21 00:31:12.354951
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._load_collections('collections', [])
    assert cs._collections == None or len(cs._collections) == 0
    cs._load_collections('collections', ['test.collection'])
    assert cs._collections == ['test.collection']
    assert cs.get_validated_value('collections', cs._collections, ['test.collection'], None) == ['test.collection']
    cs._load_collections('collections', ['test.collection', 'test.collection2'])
    assert cs._collections == ['test.collection', 'test.collection2']
    assert cs.get_validated_value('collections', cs._collections, ['test.collection', 'test.collection2'], None) == ['test.collection', 'test.collection2']
    cs._load_

# Generated at 2022-06-21 00:31:14.688630
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections is None

# Generated at 2022-06-21 00:31:19.805938
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    assert issubclass(TaskInclude, CollectionSearch)
    assert issubclass(TaskInclude, AnsibleBaseYAMLObject)
    assert isinstance(TaskInclude().collections, list)

# Generated at 2022-06-21 00:31:20.839970
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()