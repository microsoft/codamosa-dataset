

# Generated at 2022-06-21 00:21:51.101551
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections is not None

# Generated at 2022-06-21 00:21:51.612646
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-21 00:21:52.984426
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch(collections=None)
    assert collection_search.collections is not None

# Generated at 2022-06-21 00:21:53.485708
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-21 00:21:57.284614
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Arrange
    x = CollectionSearch()

    # Act
    y = x._load_collections(attr='collections', ds='ansible.builtin')

    # Assert
    assert y

# Generated at 2022-06-21 00:21:59.001380
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert(search.collections != [])

# Generated at 2022-06-21 00:21:59.649834
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()

# Generated at 2022-06-21 00:22:04.068823
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch, 'collections')
    assert callable(CollectionSearch.collections.fset)
    assert callable(CollectionSearch.collections.fget)
    assert callable(CollectionSearch.collections.fdel)
    assert callable(CollectionSearch.collections.post_validate)

# Generated at 2022-06-21 00:22:05.445522
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()
    assert test_object.collections is not None

# Generated at 2022-06-21 00:22:13.663635
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    ds = {}
    F = CollectionSearch()
    ds = F.post_validate(ds, PlayContext())
    print('ds: ', ds)
    assert ds['collections'] == _ensure_default_collection()
    assert ds['collections'] == ds.get('collections')
    assert ds['collections'] != ds.get('block')
    assert ds['collections'] != ds.get('tasks')
    assert ds['collections'] != ds.get('role_name')
    assert ds['collections'] != ds.get('role_collections')
    assert d

# Generated at 2022-06-21 00:22:18.342607
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()


# Generated at 2022-06-21 00:22:29.823349
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test for collections as a list
    test_obj_1 = CollectionSearch(collections=['collections.ansible'])
    assert test_obj_1._load_collections(None, test_obj_1.collections) == ['collections.ansible']

    # test for collections as a string
    test_obj_2 = CollectionSearch(collections='collections.ansible')
    assert test_obj_2._load_collections(None, test_obj_2.collections) == ['collections.ansible']

    # test for collections with default value
    test_obj_3 = CollectionSearch()
    assert test_obj_3._load_collections(None, test_obj_3.collections) == ['ansible.builtin']

    # test for collections with templated value
    test_obj_4 = CollectionSearch

# Generated at 2022-06-21 00:22:31.157483
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:22:38.241875
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.taggable import Taggable

    try:
        class A(Taggable, Block, RoleInclude, CollectionSearch):
            pass
    except Exception as e:
        assert isinstance(Exception(), e)
    assert issubclass(A, Taggable)
    assert issubclass(A, Block)
    assert issubclass(A, RoleInclude)
    assert issubclass(A ,CollectionSearch)

# Generated at 2022-06-21 00:22:50.042778
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.task.loop_control import LoopControl
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.tasks.task_include import TaskInclude
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.lookup_loader import LookupLoader
    from pprint import pprint

    # Modified constructor of class CollectionSearch
    # to print out collections
    def modified_CollectionSearch___init__(self):
        super(CollectionSearch, self).__init__()
        self._collections = [default_collection]
        pprint(self._collections)

    #

# Generated at 2022-06-21 00:22:52.951067
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()
    assert collection_search._collections == _ensure_default_collection(None)

# Generated at 2022-06-21 00:22:53.788962
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_search = CollectionSearch()
    assert test_search is not None

# Generated at 2022-06-21 00:23:00.854082
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    arg = ['ansible.netcommon', 'ansible.builtin']
    import collections
    if not isinstance(arg, collections.Iterable):
        raise AssertionError("CollectionSearch()", "arg should be a collection type")

    if not isinstance(arg[0], str):
        raise AssertionError("CollectionSearch()", "arg should be a str type")

    if not isinstance(arg[1], str):
        raise AssertionError("CollectionSearch()", "arg should be a str type")

# Generated at 2022-06-21 00:23:05.156239
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection = CollectionSearch()
    x = test_collection._collections._validate()
    assert x is None
    x = test_collection._collections._validate(['xyz.namespace.name'])
    assert x == ['xyz.namespace.name', 'ansible.builtin']

# Generated at 2022-06-21 00:23:05.810359
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-21 00:23:14.610407
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # init an object of CollectionSearch
    collection_search = CollectionSearch()

    # init collection_search._collections
    collection_search.post_validate(collection_search.collections, None)

    # test _load_collections
    collection_search._load_collections('collections', None)

# Generated at 2022-06-21 00:23:16.909745
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    tmp = CollectionSearch()
    assert tmp is not None
    assert tmp.collections == ['ansible.builtin']

# Generated at 2022-06-21 00:23:22.235301
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    assert(collectionsearch.__dict__['_collections'].default() == None)
    assert(collectionsearch.__dict__['_collections'].always_post_validate == True)
    assert(collectionsearch.__dict__['_collections'].priority == 100)
    assert(collectionsearch.__dict__['_collections'].static == True)
    assert(collectionsearch.__dict__['_collections'].attrname == 'collections')


# Generated at 2022-06-21 00:23:24.306480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible_collections.my_namespace.my_collection']

# Generated at 2022-06-21 00:23:25.688018
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert len(search.collections) == 1

# Generated at 2022-06-21 00:23:37.837368
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    options = AttrDict()
    options.connection = 'local'
    options.module_path = ''
    options.forks = 10
    options.become = None
    options.become_method = None
    options.become_user = None
    options.check = False
    options.diff = False
    options.listhosts = None
    options.listtasks = None
    options.listtags = None
    options.syntax = None
    options.tags = []

    loader = DataLoader()

# Generated at 2022-06-21 00:23:39.379150
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_CollectionSearch = CollectionSearch()
    except Exception as e:
        print("Constructor of CollectionSearch class not working as expected.")

# Generated at 2022-06-21 00:23:47.988553
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook import PlayContext
    from ansible.module_utils.six.moves import configparser
    from ansible.config.parser import ConfigParser
    config = configparser.ConfigParser()
    config.read('test.cfg')
    config_parser = ConfigParser(config, 'defaults')
    collection_search = CollectionSearch(play_context=PlayContext(config_parser, '/path/to/play'), all_vars={'foo': 'bar'})
    assert collection_search.collections == ['ansible.builtin', 'ansible_builtin']
    assert collection_search._collections == ['ansible_builtin', 'ansible_collections.ansible.builtin']

# Generated at 2022-06-21 00:23:59.986146
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest

    test_obj = CollectionSearch()
    val1 = 'ansible.builtin'
    val2 = 'example.collection'
    with pytest.raises(AttributeError) as excinfo:
        test_obj._collections.post_validate(val1)
    assert "because it is static" in str(excinfo.value)

    value = test_obj._load_collections(None, val1)
    assert isinstance(value, list)
    assert val1 in value
    assert 'ansible.legacy' in value
    assert len(value) == 2

    value = test_obj._load_collections(None, [val1, val2])
    assert isinstance(value, list)
    assert val1 in value
    assert val2 in value
    assert 'ansible.legacy' in value

# Generated at 2022-06-21 00:24:04.678750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestClass(CollectionSearch):
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                      always_post_validate=True, static=True)
        def __init__(self,collections=None):
            if collections is not None:
                self.collections = collections

    TestClass()


test_CollectionSearch()

# Generated at 2022-06-21 00:24:19.958685
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cls = CollectionSearch()
    assert cls.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:24:20.569354
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-21 00:24:22.061601
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search == None

# Generated at 2022-06-21 00:24:26.667623
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    # test the constructor of class CollectionSearch
    assert test is not None
    # test the _collections property of class CollectionSearch
    assert len(test._collections) > 0
    # test the _load_collections method of class CollectionSearch
    assert test._load_collections(None, None) is not None

# Generated at 2022-06-21 00:24:28.483717
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_obj = CollectionSearch()
    assert collection_search_obj._collections == _ensure_default_collection

# Generated at 2022-06-21 00:24:29.870554
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)



# Generated at 2022-06-21 00:24:31.810236
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj
    assert test_obj._collections is not None


# Generated at 2022-06-21 00:24:35.371055
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert(isinstance(collection_search._collections, FieldAttribute))
    assert(isinstance(collection_search._load_collections, object))

# Generated at 2022-06-21 00:24:37.296408
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = _ensure_default_collection()
    assert collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:24:42.917254
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()

    # Constructor should set _collections to 'ansible.builtin', 'ansible.legacy'
    assert isinstance(cs._collections, list)
    assert len(cs._collections) == 2
    assert cs._collections[0] == 'ansible.builtin'
    assert cs._collections[1] == 'ansible.legacy'


# Generated at 2022-06-21 00:25:09.551842
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:25:11.030782
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print ('The constructor of class CollectionSearch is success')


# Generated at 2022-06-21 00:25:12.166975
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    Collections = CollectionSearch()
    assert Collections._collections.default == ['ansible.ping']

# Generated at 2022-06-21 00:25:12.949637
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    x = CollectionSearch()

# Generated at 2022-06-21 00:25:23.877499
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection = CollectionSearch()

    # Return None if collection list is empty
    assert collection._load_collections(None, []) is None

    # Return a new collection list with the default collection if not empty
    assert collection._load_collections(None, ['test_collection1', 'test_collection2']) == ['ansible.builtin', 'test_collection1', 'test_collection2']

    # Return None if collection list is empty
    assert collection._collections(None, None, None) is None

    # Return a collection list with the default collection if not empty
    assert collection._collections(None, None, ['test_collection1', 'test_collection2']) == ['ansible.builtin', 'test_collection1', 'test_collection2']

# Generated at 2022-06-21 00:25:27.837040
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch(play=dict(collections=["tom.col1", "tom.col2"]))
    collection_list = [cs.collections]
    assert collection_list == [["tom.col1", "tom.col2"]]
    return 0



# Generated at 2022-06-21 00:25:29.179978
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    item = CollectionSearch()
    print(item._collections)

# Generated at 2022-06-21 00:25:29.772277
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-21 00:25:38.645513
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollection(CollectionSearch):
        # this needs to be populated before we can resolve tasks/roles/etc
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection, always_post_validate=True, static=True)

    temp_obj = TestCollection()
    assert temp_obj._load_collections() == ['ansible_collections.community.general']
    temp_obj = TestCollection(collections=[])
    assert temp_obj._load_collections() == ['ansible_collections.community.general']
    temp_obj = TestCollection(collections=['foo.bar'])
    assert temp_obj._load_collections() == ['foo.bar', 'ansible_collections.community.general']

# Generated at 2022-06-21 00:25:40.562393
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().get_validated_value('collections', CollectionSearch._collections, None, None) is None

# Generated at 2022-06-21 00:26:35.463606
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections('collections',['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-21 00:26:36.883383
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:26:38.396414
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections == _ensure_default_collection

# Generated at 2022-06-21 00:26:39.743456
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert isinstance(collectionSearch, CollectionSearch)

# Generated at 2022-06-21 00:26:40.894158
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin']

# Generated at 2022-06-21 00:26:42.798011
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    '''
    Test for constructor
    '''
    collection_search = CollectionSearch()
    assert collection_search  # will return None if the collection is empty

# Generated at 2022-06-21 00:26:48.204631
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Initialize the class
    cs = CollectionSearch()

    # Try to set an attribute of the instance that doesn't exist
    try:
        cs.wrong_attr = 'does not exist'
    except AttributeError:
        pass

    # Print the instance
    display.display(cs)

    # Set a new attribute of the instance
    cs.collections = ['fake_collection']

    # Print the instance
    display.display(cs)

    # Get an attribute of the instance
    display.display(cs.collections)

# Import this plugin for use
if __name__ == '__main__':
    # Declare the class used for this file
    test_CollectionSearch()

# Generated at 2022-06-21 00:26:49.356243
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Check for constructor for class CollectionSearch
    instances = [CollectionSearch()]

# Generated at 2022-06-21 00:26:51.768642
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch is not None, "CollectionSearch() failed"



# Generated at 2022-06-21 00:27:01.194740
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test constructor without arguments
    without_arguments = CollectionSearch()
    assert without_arguments._collections == _ensure_default_collection()

    # test constructor with argument collections
    test_collections = ['test.collection', 'test_collection.nested']
    with_arguments = CollectionSearch(_collections=test_collections)
    assert with_arguments._collections == test_collections
    assert with_arguments.collections == test_collections

    # test constructor when collections is not a list
    not_a_list = CollectionSearch(_collections='not_a_list')
    assert not_a_list._collections == _ensure_default_collection()
    assert not_a_list.collections == _ensure_default_collection()

    # test constructor when collections is a list but with wrong type

# Generated at 2022-06-21 00:29:11.116809
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch,object)

# Generated at 2022-06-21 00:29:12.468313
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert(collection._collections == ['ansible.builtin', 'ansible.legacy'])

# Generated at 2022-06-21 00:29:13.498007
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # check the object is CollectionSearch
    assert isinstance(CollectionSearch(), CollectionSearch)

# Generated at 2022-06-21 00:29:15.379784
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default is _ensure_default_collection
    assert cs.collections is _ensure_default_collection()

# Generated at 2022-06-21 00:29:21.217653
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.block import Block

    # Above class is not a Base class, so we only create an instance of it
    collection_search = CollectionSearch()
    # Checking the "collections" attribute for the class
    assert(collection_search._collections == {
        'static': True, 'priority': 100, 'isa': 'list', 'listof': string_types, 'default': _ensure_default_collection,
        'display': 'collections', 'always_post_validate': True
    })

    # Checking the definition of the method _load_collections

# Generated at 2022-06-21 00:29:31.297873
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.playbook.block import Block

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task import Task
    from ansible.plugins.loader import collections_loader
    from ansible.plugins.parser import Parser
    from ansible.vars.manager import VariableManager

    # Test for __init__
    # Test for _load_collections

    # base_parser = Parser()
    # variable_manager = VariableManager()

# Generated at 2022-06-21 00:29:37.570678
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # Check initialization of _collections
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']
    # check that _ensure_default_collection() works when called with
    # a collection_list that is None and with another collection
    default_collection = AnsibleCollectionConfig.default_collection
    if default_collection:
        collection_search._ensure_default_collection(collection_list=['mycollection'])
        assert collection_search._collections == ['mycollection', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:29:38.863066
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert 'ansible' in cs._collections

# Generated at 2022-06-21 00:29:41.303027
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest
    class test_CollectionSearch(unittest.TestCase):
        def test_pre_init(self):
            collection_search = CollectionSearch()

    mytest = test_CollectionSearch()
    mytest.test_pre_init()

# Generated at 2022-06-21 00:29:43.068000
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None
    assert cs._load_collections('collections', None) == ['ansible.builtin', 'ansible.legacy']