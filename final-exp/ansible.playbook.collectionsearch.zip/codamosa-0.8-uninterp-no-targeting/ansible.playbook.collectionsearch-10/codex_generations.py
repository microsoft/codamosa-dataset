

# Generated at 2022-06-21 00:22:03.324732
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()

# Generated at 2022-06-21 00:22:06.870879
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections is not None
    assert x._load_collections('collections', 'ansible.builtin') == ['ansible.builtin']
    assert x._load_collections('collections', '') is None

# Generated at 2022-06-21 00:22:09.323774
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test for constructor of class CollectionSearch
    # Initializing the class
    CollectionSearchObject = CollectionSearch()
    # Act
    CollectionSearchObject._ensure_default_collection()

# Generated at 2022-06-21 00:22:13.085112
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    colection_search = CollectionSearch()
    assert colection_search._collections.default == _ensure_default_collection()


'''
colection_search = CollectionSearch()
colection_search._load_collections(None, None)
'''

# Generated at 2022-06-21 00:22:21.609739
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import collections

    # Instantiate CollectionSearch class object
    collection_search_obj = CollectionSearch()

    # Verify the constructor of CollectionSearch creates instance variable _collections
    assert isinstance(collection_search_obj._collections, collections.Sequence)

    # Verify the constructor of CollectionSearch creates instance variable attr_list
    assert isinstance(collection_search_obj.attr_list, collections.Sequence)

    # Verify the constructor of CollectionSearch creates instance variable attr_set
    assert isinstance(collection_search_obj.attr_set, collections.Set)

# Generated at 2022-06-21 00:22:23.553084
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook import Task
    from ansible.playbook.play_context import PlayContext

    x = Task()
    assert not x.collections
    assert x._collections.default == _ensure_default_collection

    x.load_context(PlayContext())
    assert x.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:22:24.832341
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    sut = CollectionSearch()
    assert sut is not None

# Generated at 2022-06-21 00:22:28.619414
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert s._collections == ['ansible.builtin']

    s = CollectionSearch(collections=['ansible.collection'])
    assert s._collections == ['ansible.collection', 'ansible.legacy']

# Generated at 2022-06-21 00:22:32.748873
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()

    # Test on isinstance of tests class
    assert isinstance(test_obj, CollectionSearch), 'Object of class CollectionSearch does not instantiate.'

    # Test constructor of class CollectionSearch
    assert test_obj.__class__.__name__ == 'CollectionSearch', 'Object of class CollectionSearch does not instantiate.'

# Generated at 2022-06-21 00:22:34.114218
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs

# Generated at 2022-06-21 00:22:42.252525
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert s._collections == _ensure_default_collection()



# Generated at 2022-06-21 00:22:54.070510
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import copy
    import os
    import tempfile

    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.playbook.play_context import PlayContext

    collections = ['ansible.builtin', 'my_collection']
    ns_prefix = 'ansible_my_collection'
    collection_role_path = 'my_collection.my_role'

    temp_dir = tempfile.mkdtemp()
    orig_collection_path = os.environ.get('ANSIBLE_COLLECTIONS_PATHS', None)
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = temp_dir

    context = PlayContext()
    context.CLIARGS = {}

    # Write out a collection file
    collection

# Generated at 2022-06-21 00:22:55.425665
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:02.055525
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    default_collection = AnsibleCollectionConfig.default_collection
    task_include = TaskInclude()
    assert isinstance(task_include.collections, list)
    assert task_include.collections[0] == default_collection
    # TODO: fix this and enable it
    # assert task_include.collections == ['ansible.builtin', default_collection]

# Generated at 2022-06-21 00:23:06.687236
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert 'ansible.builtin' in obj._collections
    assert 'ansible.legacy' in obj._collections
    assert 'ansible.builtin' in obj._load_collections('collections', None)
    assert 'ansible.legacy' in obj._load_collections('collections', None)

# Generated at 2022-06-21 00:23:07.122619
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch(), 'collections')

# Generated at 2022-06-21 00:23:09.956033
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert 'ansible.builtin' == a._collections[0]
    assert 1 == len(a._collections)



# Generated at 2022-06-21 00:23:11.378222
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:16.549711
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    
    col_search = CollectionSearch()
    print("Testing class: CollectionSearch")
    # print("collections: " + str(_collections))
    # if col_search._load_collections:
    #     print("_load_collections exists")
    # else:
    #     print("_load_collections doesn't exist")

test_CollectionSearch()

# Generated at 2022-06-21 00:23:17.694454
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test

# Generated at 2022-06-21 00:23:31.659429
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #test the constructor
    cs = CollectionSearch()
    assert cs._collections is None

# Generated at 2022-06-21 00:23:33.066576
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.post_validate({})
    assert search.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:41.689265
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base, BaseVars
    from ansible.parsing.vault import VaultLib, VaultSecret

    BaseVars._vault = VaultLib([VaultSecret(None)])
    base = Base()
    base.register_loader_option('collections', '_collections')
    base.post_validate(base.ds, [])

    c = CollectionSearch()
    c._collections = base._collections
    c._load_collections('_collections', base.ds)
    print(c._collections)
    assert c._collections == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible.legacy']

# Generated at 2022-06-21 00:23:42.490680
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-21 00:23:48.654109
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.collections == ['ansible.builtin', 'ansible.legacy']
    assert a._collections.default == ['ansible.builtin', 'ansible.legacy']
    assert a._collections.priority == 100
    assert a._collections.listof == string_types
    assert a._collections.static == True
    assert a.collections == _ensure_default_collection()
    assert isinstance(a, CollectionSearch)

# Generated at 2022-06-21 00:23:49.624479
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs

# Generated at 2022-06-21 00:23:52.408671
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()
    assert coll._collections(ds=None, ds_type='attributes') is None

# Generated at 2022-06-21 00:23:54.703305
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)


# Generated at 2022-06-21 00:23:56.156703
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)



# Generated at 2022-06-21 00:24:00.899444
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import collections
    test_attr = {'collections': ['skeleton.user']}

    search = CollectionSearch()
    assert search.post_validate(test_attr, None) is None

    assert isinstance(search._collections.patt, collections.Callable)
    assert search._collections.value == ['skeleton.user']

# Generated at 2022-06-21 00:24:27.441806
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert isinstance(x, CollectionSearch)


# Generated at 2022-06-21 00:24:29.377709
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj._collections)

# Generated at 2022-06-21 00:24:32.843903
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_search = CollectionSearch()
    coll_search.path = "ansible.legacy"
    assert coll_search.get_validated_value('collections', coll_search._collections, "ansible.legacy", None) == ["ansible.legacy"]

# Generated at 2022-06-21 00:24:36.128481
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print (cs._collections)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:24:39.424080
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.utils.display import Display
    collection_search = CollectionSearch()
    display = Display()
    collection_search._load_collections("collections", "_collections")
    # If an empty collection list is passed, then the default list should be returned
    assert collection_search._load_collections("collections", None) == _ensure_default_collection()
    assert collection_search._load_collections("collections", ['ansible.builtin', 'nsbl.collection_1']) == ['ansible.builtin', 'nsbl.collection_1']

# Generated at 2022-06-21 00:24:41.219275
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cl = CollectionSearch()
    collections = []
    # cl._validate_collections(collections)
    print(collections)

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-21 00:24:43.656010
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t._collections._default == _ensure_default_collection()




# Generated at 2022-06-21 00:24:47.207505
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search=CollectionSearch()
    assert search._load_collections(search,'ansible.builtin') is None
    assert 'ansible.builtin' in search._load_collections(search,'ansible.builtin')
    assert 'geerlingguy.apache' in search._load_collections(search,'geerlingguy.apache')

# Generated at 2022-06-21 00:24:49.138156
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    test_role = RoleDefinition()
    assert test_role

# Generated at 2022-06-21 00:24:52.024898
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test1 = CollectionSearch()
    test2 = CollectionSearch(collections=['community.general'])
    assert test1._collections is not None
    assert test2._collections is not None

# Generated at 2022-06-21 00:25:44.926100
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert type(collectionSearch) == CollectionSearch

# Generated at 2022-06-21 00:25:48.572857
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections._value == _ensure_default_collection()
    assert cs.get_validated_value('collections', cs._collections, None, None) == cs._collections._value

# Generated at 2022-06-21 00:25:57.388098
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.field_name == 'collections'
    assert type(cs._collections.isa) is type
    assert type(cs._collections.listof) is type
    assert cs._collections.priority == 100
    assert cs._collections.default == _ensure_default_collection
    assert cs._collections.always_post_validate
    assert cs._collections.static
    assert cs._collections.default_path == 'collections'

    assert hasattr(cs, '_load_collections')
    assert type(cs._load_collections) is function
    assert hasattr(cs, 'get_validated_value')

# Generated at 2022-06-21 00:25:59.954751
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()

# Generated at 2022-06-21 00:26:05.362515
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

    # Test using a template for the collection name
    cs = CollectionSearch(collections=['{{ foo }}'])
    assert cs._collections == ['{{ foo }}']

# Generated at 2022-06-21 00:26:16.530751
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.when import When
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.config.manager import ConfigManager
    from ansible.vars.manager import VariableManager

    display = Display()
    config_manager = ConfigManager()
    data_loader = DataLoader()

# Generated at 2022-06-21 00:26:17.742818
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    module = CollectionSearch()
    assert hasattr(module, '__post_validate__')

# Generated at 2022-06-21 00:26:18.287321
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-21 00:26:20.309038
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections(None, None) == ['ansible.legacy']

# Generated at 2022-06-21 00:26:25.052572
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Initialize instance of CollectionSearch class
    collection_search = CollectionSearch()

    # Test the static method _ensure_default_collection
    assert _ensure_default_collection() == ['ansible.legacy']
    assert _ensure_default_collection('test') == ['test', 'ansible.legacy']
    assert _ensure_default_collection(['test1', 'test2']) == ['test1', 'test2', 'ansible.legacy']

# Generated at 2022-06-21 00:27:34.460443
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ['ansible.builtin']

# Generated at 2022-06-21 00:27:41.530360
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with open('test_data.txt', 'r') as file:
        data = file.readlines()
        test_data = [line.rstrip('\n') for line in data]
    obj = CollectionSearch()
    assert str(obj._load_collections('collections', test_data)) == "['ansible.builtin', 'ansible_collections.microsoft.windows']"
    assert str(obj._load_collections('collections', None)) == "['ansible.builtin', 'ansible_collections.microsoft.windows']"

# Generated at 2022-06-21 00:27:43.818157
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    new_collectionSearch = CollectionSearch()
    #Expected Result is a Object with class CollectionSearch
    assert type(new_collectionSearch) == CollectionSearch


# Generated at 2022-06-21 00:27:45.787468
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections is not None
    assert test._collections == _ensure_default_collection()


# Generated at 2022-06-21 00:27:46.696752
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections() == _ensure_default_collection()

# Generated at 2022-06-21 00:27:47.975501
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert result._collections._value == ['ansible.builtin']

# Generated at 2022-06-21 00:27:49.235116
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch()._collections, FieldAttribute)

# Generated at 2022-06-21 00:27:53.838027
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.collections = _ensure_default_collection()
    assert search.collections == search._load_collections(None, search.collections)

# Generated at 2022-06-21 00:27:55.115856
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-21 00:27:58.801874
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search._load_collections(attr='collections', ds="../roles/default_collection")
    assert _ensure_default_collection(ds) == "../roles/default_collection"



# Generated at 2022-06-21 00:30:27.175321
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search._load_collections

# Generated at 2022-06-21 00:30:35.739811
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute import FieldAttribute
    c = CollectionSearch()
    assert c.__doc__ == "Placeholder for code to resolve collections."
    assert c._collections == FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection, always_post_validate=True, static=True)
    assert c._load_collections == None

# Generated at 2022-06-21 00:30:44.176623
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Unit test for constructor of class CollectionSearch
    :return: None
    """
    # Test for invalid input for class CollectionSearch

    def test_for_invalid_args():
        collections = 'Invalid'
        obj = CollectionSearch(collections)  # pylint: disable=no-value-for-parameter

    from ansible.module_utils.six import assertRaisesRegex
    with assertRaisesRegex(AssertionError, r'Invalid CollectionSearch argument'):
        test_for_invalid_args()

    # Test for valid input for class CollectionSearch
    # pylint: disable=no-value-for-parameter
    obj = CollectionSearch(['collections'])

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:30:46.213187
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:30:49.453329
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    o = CollectionSearch()
    assert o._collections.default == _ensure_default_collection
    assert o.post_validate.lists == ['collections']

# Generated at 2022-06-21 00:31:01.371405
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_list = ['ansible.builtin', 'ansible.legacy']
    res = _ensure_default_collection(collection_list)
    assert res == collection_list

    # test by default:
    default_collection = 'ansible.collections.somewhat_collection'
    res = _ensure_default_collection()
    assert res == [default_collection, 'ansible.builtin', 'ansible.legacy']

    # test with empty list
    res = _ensure_default_collection([])
    assert res == [default_collection, 'ansible.builtin', 'ansible.legacy']

    # test with non-empty list

# Generated at 2022-06-21 00:31:12.752064
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def get_ds():
        class DummyDS:
            def __init__(self):
                self._ds = {
                    'collections': None
                }

            def get(self, attr, defval):
                return self._ds.get(attr, defval)

            def set(self, attr, value):
                self._ds[attr] = value

            def __getitem__(self, item):
                return self._ds[item]

        # Create dummy ds object
        ds = DummyDS()

        # Test has()
        assert ds.get('collections') == None

        return ds

    # Test __init__()
    def test_init(ds):
        collection_search_obj = CollectionSearch()
        assert collection_search_obj.collections == []
        assert collection_search_obj

# Generated at 2022-06-21 00:31:17.919816
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._collections = None
    cs.collections = ["a", "b", "c"]
    assert cs._collections == _ensure_default_collection(["a", "b", "c"])

# Generated at 2022-06-21 00:31:23.981600
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # No collections specified
    cs.post_validate()

    # Add a collection name to the collections list
    assert cs.collections == [AnsibleCollectionConfig.default_collection]
    cs.collections.append('test_collection')
    cs.post_validate()
    assert cs.collections == ['test_collection', AnsibleCollectionConfig.default_collection]

    # Try to add a duplicate collection name to the collections list and
    # see if it is rejected
    cs.collections.append('test_collection')
    cs.post_validate()
    assert cs.collections == ['test_collection', AnsibleCollectionConfig.default_collection]

    # Remove the last collection name and make sure it is removed
    cs.collections.pop()

# Generated at 2022-06-21 00:31:27.758615
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # verify that a list is returned from _load_collections
    assert isinstance(cs._load_collections("", None), list)