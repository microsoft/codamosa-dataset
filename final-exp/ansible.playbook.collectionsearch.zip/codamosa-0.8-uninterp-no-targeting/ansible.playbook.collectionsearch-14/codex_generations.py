

# Generated at 2022-06-21 00:21:57.244978
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()



# Generated at 2022-06-21 00:22:01.249087
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search._load_collections("collections", None)
    assert search.get_validated_value("collections", search._collections, None, None) == ["ansible.builtin", "ansible.legacy"]

# Generated at 2022-06-21 00:22:03.373853
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection = CollectionSearch()
    # To ensure the constructor of class CollectionSearch is not empty.
    assert hasattr(test_collection, "_collections")

# Generated at 2022-06-21 00:22:05.156271
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    cs = CollectionSearch()
    assert isinstance(cs, Block)

# Generated at 2022-06-21 00:22:07.518862
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    a = TaskInclude()
    assert a.collections is None

# Generated at 2022-06-21 00:22:14.745306
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.playbook.task
    import ansible.playbook.task_include
    import ansible.playbook.role
    import ansible.playbook.block
    test_object = CollectionSearch()

    # check if it is an instance of CollectionSearch
    if isinstance(test_object, CollectionSearch):
        print("test_init: test_object is an instance of CollectionSearch")

    # check if it is an instance of FieldAttribute
    if isinstance(test_object, FieldAttribute):
        print("test_init: test_object is an instance of FieldAttribute")

    # check if it is an instance of Base
    if isinstance(test_object, ansible.playbook.task.Base):
        print("test_init: test_object is an instance of task.Base")

    # check if it is an instance of Block
   

# Generated at 2022-06-21 00:22:16.633061
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == [('ansible.builtin'), ('ansible.legacy')]

# Generated at 2022-06-21 00:22:20.530148
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()
    assert cs.collections != _ensure_default_collection(['foo'])

# Generated at 2022-06-21 00:22:30.964762
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()
    assert collection_search._collections == _ensure_default_collection()
    assert collection_search._load_collections('collections', None) == AnsibleCollectionConfig.default_collection
    assert collection_search.collections == AnsibleCollectionConfig.default_collection
    assert collection_search._collections == AnsibleCollectionConfig.default_collection
    assert collection_search._load_collections('collections', ['collection1']) == ['collection1', AnsibleCollectionConfig.default_collection]
    assert collection_search.collections == ['collection1', AnsibleCollectionConfig.default_collection]
    assert collection_search._collections == ['collection1', AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-21 00:22:32.893272
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_search = CollectionSearch()
    assert(coll_search._collections.static is True)
    assert(isinstance(coll_search._collections.default, list))

# Generated at 2022-06-21 00:22:43.425779
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj
    assert obj._collections
    # verify CollectionSearch._collections is always a list of string
    assert isinstance(obj._collections, list)
    assert isinstance(obj._collections[0], str)

# Generated at 2022-06-21 00:22:45.076264
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:22:48.854813
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    test = cs.get_validated_value('collections',cs._collections, None, None)
    assert isinstance(test, list)
    assert len(test) > 0

# Generated at 2022-06-21 00:22:52.345751
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    #call the private method
    _collections = search._load_collections(None, [])
    #assert that it is not None
    assert _collections is not None

# Generated at 2022-06-21 00:22:54.024574
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj1 = CollectionSearch()
    assert obj1._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:04.954238
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # This implements the structure of a Block (which is a BaseYAMLObject).
    # It was necessary to create this to test the usage of the CollectionSearch class.
    class BlockYAML(AnsibleBaseYAMLObject, Block, CollectionSearch):
        pass

    # The following is the structure of the actual task.
    # This should be enough to validate the "collections" attribute
    # See: ansible/playbook/block.py:Block._load_attr() method
    block = BlockYAML()
    block._ds = {
        'collections': None
    }

    # This calls the _load_collections() method above

# Generated at 2022-06-21 00:23:06.342738
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None


# Generated at 2022-06-21 00:23:07.857885
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection
    assert collection._collections is not None

# Generated at 2022-06-21 00:23:10.595179
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    # This will return the same values as there are no default values for collection_list
    assert test_obj._ensure_default_collection(None) is None

# Generated at 2022-06-21 00:23:20.708045
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requiremenets import RoleRequirement

    # Test CollectionSearch. __init__
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection(None)  # pylint: disable=protected-access

    # Test CollectionSearch._collections
    data = [1, 2, 3]
    cs = CollectionSearch()

# Generated at 2022-06-21 00:23:36.404644
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:37.867871
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:46.887477
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = dict()
    cs = CollectionSearch()

    # check for value
    assert cs._collections is not None
    # check for type
    assert isinstance(cs._collections, FieldAttribute)
    # check for type of data
    assert isinstance(cs._collections.default, list)
    # check for type of value in data
    assert isinstance(cs._collections.default[0], str)

    # check for load_collections
    assert cs._load_collections is not None
    # check for type
    assert isinstance(cs._load_collections, collections.Callable)
    # check for type of data
    assert cs._load_collections('_collections', ds) is None

    # check for _ensure_default_collection
    assert _ensure_default_collection() is not None
   

# Generated at 2022-06-21 00:23:49.109666
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._load_collections(None, None) is None

# Generated at 2022-06-21 00:23:51.759967
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections is not None
    assert CollectionSearch()._load_collections is not None

# Generated at 2022-06-21 00:23:57.605902
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    result = test._collections
    expected = _ensure_default_collection()
    
    if result == expected:
        print("Test set constructor of class CollectionSearch passed")
    else:
        print("Test set constructor of class CollectionSearch failed")
        print("Expected: " + str(expected))
        print("Result: " + str(result))


# Generated at 2022-06-21 00:23:59.521721
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:24:01.159205
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.default_value == _ensure_default_collection

# Generated at 2022-06-21 00:24:02.083688
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)

# Generated at 2022-06-21 00:24:06.460916
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search= CollectionSearch()
    assert collection_search._load_collections('collections', []) == None
    assert collection_search._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin']
    assert collection_search._load_collections('collections', ['ansible.builtin', 'test.test']) == ['ansible.builtin', 'test.test']

# Generated at 2022-06-21 00:24:35.253861
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.__dict__.get('_collections').get('default') == _ensure_default_collection()

# Generated at 2022-06-21 00:24:39.317625
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch()

    assert d._collections is not None
    d._collections = None

    assert d._collections == None

    assert d.collections is not None
    d.collections = None

    assert d.collections == None

# Generated at 2022-06-21 00:24:41.730355
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    assert isinstance(test_instance._collections, FieldAttribute)
    assert test_instance._load_collections(attr=None, ds=None) is None
    assert test_instance._load_collections(attr=None, ds=['test']) is None

# Generated at 2022-06-21 00:24:49.124161
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']

    cs = CollectionSearch(collections=[])
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']

    cs = CollectionSearch(collections=['ansible_collection.collection1'])
    assert cs.collections == ['ansible_collection.collection1', 'ansible.builtin', 'ansible.legacy']

    cs = CollectionSearch(collections=['ansible_collection.collection2', 'ansible_collection.collection1'])
    assert cs.collections == ['ansible_collection.collection2', 'ansible_collection.collection1', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:24:53.584555
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search._load_collections("collections",["ansible.builtin","ansible.legacy"])

    collection_search = CollectionSearch()
    collection_search._load_collections("collections",["test.test1", "test.test2", "test.test3"])

# Generated at 2022-06-21 00:24:55.166514
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    assert col._collections is not None

# Generated at 2022-06-21 00:24:56.231822
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:24:56.845016
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-21 00:24:59.291919
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        obj = CollectionSearch()
    except Exception:
        assert False, "Unexpected exception thrown"
# End unit test.

# Generated at 2022-06-21 00:25:00.198568
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-21 00:25:54.570976
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.load_data({'collections': ['my.collection']})

    assert cs._collections.final_value == ['my.collection', 'ansible.builtin']

# Generated at 2022-06-21 00:25:56.118552
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = CollectionSearch()
    assert ds is not None


# Generated at 2022-06-21 00:26:08.774429
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()

    # CollectionSearch.__init__()
    """
    collectionSearch.__init__()
    assert not hasattr(collectionSearch, '_collections')
    """

    # CollectionSearch._load_collections()
    assert collectionSearch._load_collections(None, []) == []
    assert collectionSearch._load_collections(None, ['geerlingguy.docker']) == ['geerlingguy.docker']
    assert collectionSearch._load_collections(None, ['geerlingguy.docker', 'ansible.builtin']) == ['geerlingguy.docker',
                                                                                                  'ansible.builtin']

# Generated at 2022-06-21 00:26:10.318633
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)


# Generated at 2022-06-21 00:26:14.130009
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # test constructor without input arg
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections == ['ansible_collections.ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-21 00:26:15.457079
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch();
    assert collection_search._collections ==  'ansible_collections.default.ansible_os_family'
# test_CollectionSearch()

# Generated at 2022-06-21 00:26:17.204196
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.get_field_value('collections') is None


# Generated at 2022-06-21 00:26:21.459270
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # assert that the constructor works when the collections attribute is not passed to it
    collection_search = CollectionSearch()
    assert collection_search.collections == ["ansible.builtin"]
    # assert that the constructor works when the collections attribute is passed to it
    collection_search = CollectionSearch(collections=["test.test"])
    assert collection_search.collections == ["test.test"]

# Generated at 2022-06-21 00:26:28.130892
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Initialize CollectionSearch with a list of collections
    search_for_tasks = CollectionSearch(collections=["ansible.builtin", "ansible.posix"])
    
    # initialize CollectionSearch without the list of collections
    search_for_tasks = CollectionSearch()
    
    # Assert _collections attribute is valid
    assert(search_for_tasks._collections == ['ansible_collections.hashicorp.vault'])
    
    # no need of assert statement for _load_collections method

# Generated at 2022-06-21 00:26:31.907444
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_obj = CollectionSearch()
    assert search_obj._collections is None

    search_obj.set_loader(None)

    search_obj.collections = 'test_collection'
    assert search_obj.collections == 'test_collection'

# Generated at 2022-06-21 00:28:40.286650
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    print(x)

# Generated at 2022-06-21 00:28:41.616031
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.default is _ensure_default_collection

# Generated at 2022-06-21 00:28:45.005123
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    load_collections = CollectionSearch()
    class_test = load_collections._load_collections(None,None)
    default_test = _ensure_default_collection(None)

    assert class_test == default_test

# Generated at 2022-06-21 00:28:48.641044
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    # Call the method _load_collections
    curr_collections = collection_search._load_collections(collection_search, "")
    assert(curr_collections[0] == "ansible_collections.ansible")

# Test method _ensure_default_collection

# Generated at 2022-06-21 00:28:49.641596
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_collection = CollectionSearch()
    assert my_collection._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:28:50.470814
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is not None

# Generated at 2022-06-21 00:28:51.415584
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections is None

# Generated at 2022-06-21 00:28:51.850781
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()

# Generated at 2022-06-21 00:28:57.748246
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d =  {"collections":["test_collection"]}
    cs = CollectionSearch()
    assert cs._load_collections('collections',d) is not None, \
    "_load_collections() should return the collections list"
    assert cs._load_collections('collections',d) == ["ansible_collections.test_collection.test_collection"], \
    "_load_collections() should return the collections list after assigning the default collection namespace"
    assert collections._load_collections('collections',d) == ["ansible_collections.test_collection.test_collection"], \
    "_load_collections() should return the collections list after assigning the default collection namespace"

# Generated at 2022-06-21 00:28:59.263085
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()