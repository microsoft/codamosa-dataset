

# Generated at 2022-06-21 00:21:57.721081
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play import Play
    t = Play()
    t.collections = ['test_col1', 'test_col2']
    assert t.collections == ['test_col1', 'test_col2']

# Generated at 2022-06-21 00:21:59.805600
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    

# Generated at 2022-06-21 00:22:01.867219
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection(None)

# Generated at 2022-06-21 00:22:02.890689
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None

# Generated at 2022-06-21 00:22:05.881526
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    print(collections._load_collections(None, ['geerlingguy.ansible-role-apach']))

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:22:09.989828
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection([]) == ['ansible.builtin']
    assert _ensure_default_collection(['test']) == ['test', 'ansible.builtin']
    assert _ensure_default_collection(['test', 'test1']) == ['test', 'test1']

# Generated at 2022-06-21 00:22:12.896926
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = _ensure_default_collection(collection_list = None)
    collection = 'ansible.builtin'
    assert collection == 'ansible.builtin'

# Generated at 2022-06-21 00:22:14.744902
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections('collections', None) is None

# Generated at 2022-06-21 00:22:16.703082
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = _ensure_default_collection()

    assert collection == 'ansible.builtin.tasks'

# Generated at 2022-06-21 00:22:21.015929
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections == ['ansible.builtin', 'ansible.legacy']

    underTest = search._load_collections(None, [])
    assert underTest == None

# Generated at 2022-06-21 00:22:29.117143
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:22:30.494064
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections is not None


# Generated at 2022-06-21 00:22:32.051840
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    loader = CollectionSearch()
    assert loader._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:22:39.276334
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs1 = CollectionSearch()
    cs2 = CollectionSearch(collections=["ansible.builtin"])
    cs3 = CollectionSearch(collections=["ansible.builtin","custom.collection"])
    assert cs1.collections == ['ansible.builtin','ansible.legacy']
    assert cs2.collections == ['ansible.builtin','ansible.legacy']
    assert cs3.collections == ['ansible.builtin','ansible.legacy','custom.collection']

# Generated at 2022-06-21 00:22:46.268437
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()
    assert cs._collections == cs.collections == _ensure_default_collection()
    assert cs._load_collections('collections', 'foo') == ['foo']
    assert cs.get_validated_value('collections', cs._collections, 'foo', None) == cs._collections == ['foo']
    assert cs.path == 'foo'
    assert cs.name == cs.short == 'foo'
    assert cs.collection is None

# Generated at 2022-06-21 00:22:47.077002
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-21 00:22:51.293637
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections_1 = CollectionSearch()
    assert _ensure_default_collection(collection_list=None) == collections_1._collections
    assert _ensure_default_collection(collection_list=[]) == collections_1._load_collections("collections", collections_1._collections)

# Generated at 2022-06-21 00:22:53.753845
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch1 = CollectionSearch()
    assert collectionSearch1._load_collections(None, None) == None


# Generated at 2022-06-21 00:22:59.172081
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    # test _collections
    assert test._collections.default == 'ansible.legacy'
    assert test._collections.priority == 100
    assert test._collections.listof == string_types
    assert test._collections.isa == 'list'
    assert test._collections.always_post_validate == True
    assert test._collections.static == True

# Generated at 2022-06-21 00:23:00.507157
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs

# Generated at 2022-06-21 00:23:22.147913
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # create hostvars
    hostvars = HostVars(hostname='localhost')
    hostvars._variable_manager.extra_vars = dict(
        ansible_collections='["my.namespace"]'
        )

    # create task_include object
    task_include = TaskInclude()
    task_include._load_name = AnsibleUnicode('example')

# Generated at 2022-06-21 00:23:24.305891
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default() == 'ansible.legacy'

# Generated at 2022-06-21 00:23:36.450188
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = []
    cs.post_validate({}, {})
    assert cs.collections == ["ansible_collections.ansible.builtin"]

    cs = CollectionSearch()
    cs.collections = ["ansible_collections.ansible.builtin"]
    cs.post_validate({}, {})
    assert cs.collections == ["ansible_collections.ansible.builtin"]

    cs = CollectionSearch()
    cs.collections = ["collections.test"]
    cs.post_validate({}, {})
    assert cs.collections == ["ansible_collections.ansible.builtin", "collections.test"]

    # Test case with an empty list, it will not be added to the list
    cs = CollectionSearch()

# Generated at 2022-06-21 00:23:37.568941
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance is not None

# Generated at 2022-06-21 00:23:40.190170
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch is not None

    # Test the _load_collections call
    assert collectionSearch._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-21 00:23:41.025506
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()


# Generated at 2022-06-21 00:23:42.258309
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)

# Generated at 2022-06-21 00:23:44.290978
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert not collection_search._load_collections('collections', [])

# Generated at 2022-06-21 00:23:54.287258
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = _ensure_default_collection()
    assert 'ansible.builtin' in ds
    assert 'ansible.legacy' in ds
    assert 'ansible.builtin' not in ['ansible.legacy']
    assert 'ansible.legacy' not in ['ansible.builtin']
    ds = ['ansible.legacy']
    ds = _ensure_default_collection(ds)
    assert 'ansible.builtin' in ds
    assert 'ansible.legacy' in ds
    assert 'ansible.builtin' not in ['ansible.legacy']
    assert 'ansible.legacy' not in ['ansible.builtin']

# Generated at 2022-06-21 00:24:00.210596
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        def __init__(self, *args, **kwargs):
            super(TestCollectionSearch, self).__init__(*args, **kwargs)

    search_collection = TestCollectionSearch()
    assert search_collection._load_collections(None, ['foo.bar', 'ansible.builtin']) == ['foo.bar', 'ansible.builtin']



# Generated at 2022-06-21 00:24:27.552380
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)
    assert obj.collections == ['ansible_collections.ansible.builtin']



# Generated at 2022-06-21 00:24:32.794911
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Foobar(CollectionSearch):
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100,
                                      default=_ensure_default_collection, always_post_validate=True, static=True)

    a = Foobar()
    assert a.get_validated_value('collections', a._collections, None) is None

# Generated at 2022-06-21 00:24:36.065756
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    # Test that default value get set on instantiation
    assert a._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:24:45.914867
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.utils.hashing import change_hash_for_dict_keys
    from ansible.utils.collection_loader import AnsibleCollectionConfig


    import os
    import sys

    if sys.version_info >= (3, 0):
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    # Mock of Collection.__init__
    class MockCollection:
        def __init__(self, collection_name):
            self.collection_name = collection_name

    # Mock of AnsibleCollectionConfig.__init__
    class AnsibleCollectionConfig_Mock:
        def __init__(self, collection_list = None):
            self.collection_list = _ensure_default

# Generated at 2022-06-21 00:24:47.983901
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == [ 'ansible.builtin' ]



# Generated at 2022-06-21 00:24:54.178158
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testobj = CollectionSearch()
    assert testobj is not None
    assert testobj._collections is not None
    assert _ensure_default_collection() == testobj._collections
    assert testobj._collections.default is not None
    assert testobj._collections.default == _ensure_default_collection
    assert testobj._collections.static is True
    assert testobj._collections.get_default_value() == _ensure_default_collection()

# Generated at 2022-06-21 00:24:58.225982
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    coll = CollectionSearch()
    s = coll._load_collections(None, ['community.general[0]'])
    display.info(s)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:25:04.793720
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch()
    d.add_field('collections', listof=string_types)

    ds = {'collections': ['"ansible.builtin", "ansible.posix"', 'ansible.builtin', 'ansible.posix']}
    assert d.post_validate(ds, 'collections') == ["ansible.builtin", "ansible.posix", "ansible.builtin", "ansible.posix"]

# Generated at 2022-06-21 00:25:06.023742
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch(None, None, None)

# Generated at 2022-06-21 00:25:12.837025
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Unit test - constructor of CollectionSearch class.
    """
    default_collection = AnsibleCollectionConfig.default_collection
    collections = _ensure_default_collection(None)
    if default_collection and default_collection not in collections:
        collections.insert(0, default_collection)
    collection_search = CollectionSearch()
    assert collection_search._collections is None
    collection_search.post_validate(collection_search._collections, collections)
    assert collection_search._collections is not None
    assert collection_search._collections == default_collection

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-21 00:25:40.696469
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._load_collections("collections", ["my.collection"]) == ["my.collection"]

# Generated at 2022-06-21 00:25:42.467318
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-21 00:25:43.921993
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    module = CollectionSearch()
    print(module.__dict__)

# Generated at 2022-06-21 00:25:46.298821
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch), "CollectionSearch object was not created"

# Generated at 2022-06-21 00:25:49.242457
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    collections = CollectionSearch()
    ds_list = ['test_collection', 'test_collection1']
    assert collections._load_collections(None, ds_list) == ds_list

# Generated at 2022-06-21 00:25:57.579147
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()

    # This should work, as the default value is a list
    collection_search.set_to_attribute('collections', ['foo'])

    # This should also work, we're not changing the value, just setting it
    collection_search.set_to_attribute('collections', ['foo'])

    # This should fail, as the default value is not a dict
    try:
        collection_search.set_to_attribute('collections', {'foo': 'bar'})
        assert False
    except:
        pass

    # Test default value assignment
    assert isinstance(collection_search.collections, list)

# Generated at 2022-06-21 00:25:58.531578
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-21 00:26:10.316801
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest
    import yaml

    # Test for case where collections is specified
    ds_collections_specified = yaml.safe_load("""
    collections:
      - test.collection.one
      - test.collection.two
      - test.collection.three
    """)
    test_collections_specified = CollectionSearch(ds=ds_collections_specified)
    assert test_collections_specified.collections == ['test.collection.one',
                                                      'test.collection.two',
                                                      'test.collection.three']

    # Test for case where collections is not specified
    ds_collections_not_specified = yaml.safe_load("""
    """)
    test_collections_not_specified = CollectionSearch(ds=ds_collections_not_specified)
    assert test_col

# Generated at 2022-06-21 00:26:14.130602
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    output = test_obj._load_collections('collections', ['ansible.builtin'])
    assert output == ['ansible.builtin']


# Generated at 2022-06-21 00:26:15.344319
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    arg_data = {}
    obj = CollectionSearch(None, "name", **arg_data)
    assert obj._collections == ['ansible.builtin']

# Generated at 2022-06-21 00:27:20.185595
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        def __init__(self):
            self.collections = _ensure_default_collection()

    test_collection_search = TestCollectionSearch()
    assert test_collection_search.collections == _ensure_default_collection()


# Generated at 2022-06-21 00:27:23.484616
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search=CollectionSearch()
    # Test for class attributes
    assert(collection_search._collections == _ensure_default_collection())


# Generated at 2022-06-21 00:27:24.827790
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert result._collections == _ensure_default_collection

# Generated at 2022-06-21 00:27:27.097753
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a_collection_search = CollectionSearch()
    assert a_collection_search._collections is None

# Generated at 2022-06-21 00:27:38.474819
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import collections
    import json

    # Testing the constructor
    # Success user wants to define the collection list
    # User wants to define the collection list
    pre_existing_config = {
        'collections': [
            'my_namespace.my_role', 'my_other_namespace.my_role',
            'my_namespace.my_module_utils', 'my_namespace.my_module_utils_2'
        ]
    }
    my_collection_search = CollectionSearch(collections.deque(), pre_existing_config)
    my_collection_search.post_validate()
    assert json.dumps(my_collection_search.collections) == json.dumps(pre_existing_config['collections'])

    # Success user does not want to define the collection list
    # User does not want to define

# Generated at 2022-06-21 00:27:47.192010
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import types
    import inspect
    import pytest

    # test init
    colsearch = CollectionSearch()
    colsearch._load_collections

    assert colsearch._load_collections(colsearch._collections, None) is None

    # test _load_collections func
    colsearch._collections = None
    assert colsearch._load_collections(colsearch._collections, None) is None

    colsearch._collections = ['']
    assert colsearch._load_collections(colsearch._collections, None) is None

    colsearch._collections = ['ansible.builtin', 'ansible.legacy']

    with pytest.warns(UserWarning):
        colsearch._load_collections(colsearch._collections, None)


# Generated at 2022-06-21 00:27:48.888409
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_class = CollectionSearch()
    assert test_class
    assert test_class._fields['collections']['default'] == _ensure_default_collection

# Generated at 2022-06-21 00:27:53.967597
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import collections
    a = CollectionSearch()
    assert None is a._load_collections("collections", None)

    # Check that the collections module is a subclass of CollectionSearch.
    assert isinstance(collections, CollectionSearch)

    # Check that the collections module is a subclass of CollectionSearch.
    assert isinstance(a, Collections)

# Generated at 2022-06-21 00:27:56.127609
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections == ['ansible.builtin']
    assert x._collections is not None

# Generated at 2022-06-21 00:28:02.078641
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # create an instance of class CollectionSearch
    cs = CollectionSearch()
    # check if the default collection is loaded correctly
    assert cs._load_collections(None, None) == _ensure_default_collection()
    # check if the collection is loaded correctly when there is a collection list
    assert cs._load_collections(None, ['ansible.builtin']) == _ensure_default_collection(['ansible.builtin'])

# Generated at 2022-06-21 00:30:21.612070
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-21 00:30:23.563922
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   collection = CollectionSearch()
   list_names = ['ansible.builtin', 'ansible.legacy', 'yudlou2.collection']
   result = collection._load_collections(None, list_names)
   print('result is:', result)


# Generated at 2022-06-21 00:30:32.561763
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections("collections", ["foo", "bar", "ansible.builtin"]) == ["foo", "bar"]
    assert CollectionSearch()._load_collections("collections", ["foo", "bar", "ansible.builtin", "ansible.builtin"]) == ["foo", "bar"]
    assert CollectionSearch()._load_collections("collections", ["foo", "bar", "ansible.builtin", "ansible.builtin", "ansible.legacy"]) == ["foo", "bar"]
    assert CollectionSearch()._load_collections("collections", ["foo", "bar"]) == ["foo", "bar", "ansible.builtin"]

# Generated at 2022-06-21 00:30:43.331702
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = dict()
    ds['collections'] = ['ansible.builtin', 'ansible.posh']
    test_case = CollectionSearch()
    assert test_case._collections.post_validate(ds=ds) == ['ansible.builtin', 'ansible.posh']
    ds['collections'] = ['ansible.posh']
    test_case = CollectionSearch()
    assert test_case._collections.post_validate(ds=ds) == ['ansible_collections.ansible.builtin', 'ansible.posh']
    ds['collections'] = []
    test_case = CollectionSearch()
    assert test_case._collections.post_validate(ds=ds) == ['ansible_collections.ansible.builtin']
    ds['collections'] = None

# Generated at 2022-06-21 00:30:48.161258
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs._collections, FieldAttribute)
    assert isinstance(cs._collections.isa, str)
    assert cs._collections.static


# Generated at 2022-06-21 00:30:52.190745
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass
    test_obj = TestCollectionSearch()
    assert test_obj._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:30:57.000297
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    obj = CollectionSearch()

    assert obj._attributes['collections'].priority == 100
    assert obj._attributes['collections'].post_validate == obj._load_collections
    assert obj._attributes['collections'].isa == 'list'

# Generated at 2022-06-21 00:30:59.291473
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert 'ansible.builtin' == obj._collections()[0]

# Generated at 2022-06-21 00:31:02.266749
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:31:08.226694
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    res = CollectionSearch()
    assert len(res._collections) == 1
    assert 'ansible.builtin' in res._collections
    assert 'ansible.legacy' in res._collections
    assert 'ansible.builtin' not in res.collections