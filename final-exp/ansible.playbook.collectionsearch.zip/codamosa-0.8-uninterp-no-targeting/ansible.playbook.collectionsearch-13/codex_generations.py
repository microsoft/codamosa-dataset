

# Generated at 2022-06-21 00:21:59.550969
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default() == _ensure_default_collection()
    assert cs._load_collections("collections", ["my.collection"]) == ["my.collection"]
    assert cs._load_collections("collections", 2018) == (2018,)

# Generated at 2022-06-21 00:22:06.326041
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c1 = CollectionSearch()

    c1.collections = ['ansible.builtin', 'ansible.posix']
    assert c1.collections == ['ansible.builtin', 'ansible.posix']

    c1.collections = ['ansible.builtin']
    assert c1.collections == ['ansible.builtin']

    c1.collections = ['ansible.builtin', 'ansible.windows']
    assert c1.collections == ['ansible.builtin', 'ansible.windows']

# Generated at 2022-06-21 00:22:09.323760
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_search = CollectionSearch()
    assert coll_search._collections == _ensure_default_collection()
    assert coll_search._collections.name == 'collections'

# Generated at 2022-06-21 00:22:15.705609
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.dataloader import DataLoader

    #setup test object
    ds = DataLoader()
    obj = CollectionSearch()

    #test empty list
    #assert _ensure_default_collection() == ['ansible.builtin']
    assert obj._load_collections('collections', []) is None

    #test list without default collection name
    assert obj._load_collections('collections', ['x.y']) == ['x.y', 'ansible.builtin']

    #test list with default collection name
    assert obj._load_collections('collections', ['ansible.builtin', 'x.y']) == ['ansible.builtin', 'x.y']

    #test list with legacy collection name

# Generated at 2022-06-21 00:22:17.426790
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._load_collections(None, []) is not None

# Generated at 2022-06-21 00:22:18.566646
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert len(CollectionSearch._collections) != 0

# Generated at 2022-06-21 00:22:25.288941
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    if 'ansible.builtin' in a._collections:
        if 'ansible.legacy' in a._collections:
            if 'ansible_collections.sensu.sensu_go.plugins.tasks' in a._collections:
                print('PASS')
            else:
                print('FAIL')
        else:
            print('FAIL')
    else:
        print('FAIL')

# Generated at 2022-06-21 00:22:27.029609
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # TODO: assert the result of _load_collections

# Generated at 2022-06-21 00:22:33.815803
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest

    collection_search = CollectionSearch()

    # FieldAttribute object
    assert isinstance(collection_search._collections, FieldAttribute)

    # Collections list
    assert collection_search.collections == ['ansible.builtin', 'ansible.legacy']

    # Set collections
    collection_search.collections = ['collections.example.collection1']
    assert collection_search.collections == ['collections.example.collection1', 'ansible.builtin', 'ansible.legacy']


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-21 00:22:35.791464
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	cs = CollectionSearch()
	assert (cs.collections == ['ansible.builtin'])



# Generated at 2022-06-21 00:22:50.250502
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        from ansible.playbook.role_include import IncludeRole
    except ImportError:
        # IncludeRole doesn't exist on Ansible 2.8
        return

    class TestCollectionSearch(CollectionSearch):
        pass

    role = IncludeRole(dict(name='test_role', collections=['community.general']), task_loader=None)
    assert role.get_value('collections') == ['community.general', 'ansible.builtin']

# Generated at 2022-06-21 00:22:53.139445
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    o = CollectionSearch() # pylint: disable=no-value-for-parameter
    assert o._collections[0] == 'ansible.builtin'

# Generated at 2022-06-21 00:22:57.393923
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()
    assert collection_search._load_collections("collections", None) == _ensure_default_collection(None)

    role_name = 'testrole'
    assert collection_search._load_collections("collections", role_name) == _ensure_default_collection([role_name])

# Generated at 2022-06-21 00:23:06.050548
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()

    playbook_path = ''

    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext(loader=loader, inventory=inventory, variable_manager=variable_manager)

    search = CollectionSearch()

    search.post_validate(play_context)

# Generated at 2022-06-21 00:23:08.309802
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-21 00:23:11.160457
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']  # default values
    assert cs._collections.default == ['ansible.builtin']

# Generated at 2022-06-21 00:23:12.431948
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:13.497065
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    print(x._collections)

# Generated at 2022-06-21 00:23:15.008949
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default is not None

# Generated at 2022-06-21 00:23:18.573557
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    # Deconstruct the constructor
    # collection_search.__init__()

    # Test the iterator of this class
    # for item in collection_search: print(item, end="\n")

# Generated at 2022-06-21 00:23:37.825742
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    if hasattr(instance, '_load_collections'):
        print("Class %s has method _load_collections" % (instance.__class__.__name__))
    else:
        print("Class %s doesn't have method _load_collections" % (instance.__class__.__name__))

# Generated at 2022-06-21 00:23:44.333222
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_obj = CollectionSearch()
    collections = collection_search_obj._load_collections('collections', ['ansible_collections.org'])
    assert collections is not None
    assert len(collections) == 2
    assert collections[0] == AnsibleCollectionConfig.default_collection
    assert collections[1] == 'ansible_collections.org'

    collections = collection_search_obj._load_collections('collections', None)
    assert collections is not None
    assert len(collections) == 1
    assert collections[0] == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-21 00:23:44.900555
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = Collec

# Generated at 2022-06-21 00:23:46.204229
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search)

# Generated at 2022-06-21 00:23:57.225639
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CS = CollectionSearch()
    print(CS)

print("*"*100)
print("start to test CollectionSearch...")
print("*"*100)
print("Create CollectionSearch object...")
CS = CollectionSearch()
print("print CS: ")
print(CS)
print("\n")
print("*"*100)
print("test private method _load_collections...")
cs = CS._load_collections("collections", ['/root/.ansible/collections/ansible_collections/vpn/test/test.py'])
print("print cs: ")
print(cs)
print("\n")
print("*"*100)
print("finish testing CollectionSearch...")
print("*"*100)

# Generated at 2022-06-21 00:24:01.741585
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    o = CollectionSearch()
    result = o._collections
    expected = AnsibleCollectionConfig.default_collection
    assert(result == expected)

    result = o._load_collections('collections', ['test'])
    expected = ['test', AnsibleCollectionConfig.default_collection]
    assert(result == expected)


# Generated at 2022-06-21 00:24:04.318592
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    ds = ['collection1', 'collection2']
    ret_ds = search._load_collections(None, ds)
    assert ret_ds == ['collection1', 'collection2', 'ansible.legacy']
    ret_ds = search._load_collections(None, None)
    assert ret_ds == ['ansible.default', 'ansible.legacy']

# Generated at 2022-06-21 00:24:05.439598
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()

# Generated at 2022-06-21 00:24:10.359985
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _ds = {'collections': ['foo.collection']}
    _cs = CollectionSearch()
    _cs._load_collections('collections', _ds)
    _ds = {}
    _cs.collections = _cs._load_collections('collections', _ds)
    assert _cs.collections == ['foo.collection']

test_CollectionSearch()

# Generated at 2022-06-21 00:24:12.034023
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert cs.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:24:40.648538
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testObject = CollectionSearch()
    if not hasattr(testObject,"_collections"):
        raise Exception('_collections attr not generated : %s' % dir(testObject))

# Generated at 2022-06-21 00:24:42.586194
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default() == ['ansible_collections.builtin']

# Generated at 2022-06-21 00:24:46.495310
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    temp = CollectionSearch()
    assert type(temp) == CollectionSearch
    assert isinstance(temp, CollectionSearch)

    assert temp.collections == ['ansible.builtin', 'ansible.legacy']
    assert 'ansible.builtin' in temp.collections
    assert 'ansible.legacy' in temp.collections



# Generated at 2022-06-21 00:24:47.651410
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection
    assert collection.collections is not None

# Generated at 2022-06-21 00:24:49.195286
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections._default == _ensure_default_collection()

# Generated at 2022-06-21 00:24:51.693624
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    result = cs.__class__.__name__
    assert result == "CollectionSearch"


# Generated at 2022-06-21 00:24:55.018029
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.get_validated_value('collections', collection_search._collections, [], None) == ['ansible.builtin']

# Generated at 2022-06-21 00:24:56.016434
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

# Generated at 2022-06-21 00:25:07.226511
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    test_variable_manager = dict()

# Generated at 2022-06-21 00:25:08.504999
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:25:37.686873
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # test _collections
    assert collection_search._collections is not None

# Test for _load_collections() of class CollectionSearch

# Generated at 2022-06-21 00:25:46.254946
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    _ensure_default_collection()
    assert cs._load_collections(None, ['ansible.builtin', 'ansible_collections.community.foobar'])['collections'] == \
           ['ansible_collections.community.foobar', 'ansible.builtin']
    assert cs._load_collections(None, ['ansible_collections.community.foobar', 'ansible.builtin'])['collections'] == \
           ['ansible_collections.community.foobar', 'ansible.builtin']

# Generated at 2022-06-21 00:25:50.359319
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    c._load_collections('collections', None)

    c = CollectionSearch()
    c._load_collections('collections', [])

    c = CollectionSearch()
    c._load_collections('collections', ['foo'])



# Generated at 2022-06-21 00:25:52.114613
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testobj=CollectionSearch()
    assert testobj._collections.default() == ['ansible.builtin']

# Generated at 2022-06-21 00:25:54.984893
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    collection = 'ansible'
    search.collections = collection
    assert search.collections == collection

# Generated at 2022-06-21 00:25:56.698764
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.__dict__['_collections'] == _ensure_default_collection()

# Generated at 2022-06-21 00:26:09.130256
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    from ansible.templating.template import Templating
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.playbook.attribute import FieldAttribute

    assert CollectionSearch.__name__ == 'CollectionSearch'
    assert len(CollectionSearch.__dict__) == 4
    assert not CollectionSearch.__dict__['_collections'].is_templateable
    assert CollectionSearch.__dict__['_collections'].always_post_validate is True
    assert CollectionSearch.__dict__['_collections'].static is True

    with pytest.raises(AttributeError):
        assert CollectionSearch.__dict__['_test_attr'] is None

# Generated at 2022-06-21 00:26:11.765390
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs._load_collections('collections', ['ansible.legacy', 'my.collections']), list)

# Generated at 2022-06-21 00:26:14.708416
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    assert cs._collections != None

# Generated at 2022-06-21 00:26:16.121013
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:27:33.056835
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    from ansible.parsing.yaml.objects import AnsibleUnicode
    assert CollectionSearch()._load_collections(None, []) == _ensure_default_collection()
    assert CollectionSearch()._load_collections(None, ['test.test']) ==['test.test', 'ansible.builtin','ansible.builtin','ansible.legacy']
    if 'ANSIBLE_COLLECTIONS_PATHS' in os.environ:
        assert CollectionSearch()._load_collections(None, []) == _ensure_default_collection()
        assert CollectionSearch()._load_collections(None, ['test.test']) ==['test.test', 'ansible.legacy']
    assert CollectionSearch()._load_collections(None, [AnsibleUnicode('test.test')])

# Generated at 2022-06-21 00:27:34.059006
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    C = CollectionSearch()
    return(C)

# Generated at 2022-06-21 00:27:34.720905
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-21 00:27:39.315554
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()
    assert collection_search._load_collections(None, []) == None
    assert collection_search._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']
    assert collection_search._load_collections(None, ['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']
    assert collection_search._load_collections(None, ['ansible.legacy', 'ansible.builtin']) == ['ansible.legacy', 'ansible.builtin']

# Generated at 2022-06-21 00:27:41.199460
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()

    # Testing the default constructor of class CollectionSearch
    assert test._collections is not None

# Generated at 2022-06-21 00:27:42.427329
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-21 00:27:43.546166
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is None



# Generated at 2022-06-21 00:27:52.332005
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    import sys
    import unittest
    import yaml

    from ansible.module_utils.six.moves import cStringIO

    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.errors import AnsibleError

    from ansible.galaxy import Galaxy

    from ansible.cli.galaxy import GalaxyCLI
    from ansible.cli.galaxy.collection_info import CollectionInfo, CollectionInfoCLI
    from ansible.module_utils._text import to_bytes, to_text

    from ansible_collections.ansible.builtin.plugins.module_utils.common.validation import (
        validate_collection_name,
        validate_collection_version_format,
    )


# Generated at 2022-06-21 00:27:57.017035
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """ This function performs unit test for constructor of class CollectionSearch """
    collection_search = CollectionSearch()
    assert(collection_search._collections.default(_ensure_default_collection) == _ensure_default_collection())
    assert(collection_search._load_collections({}, 'ansible.builtin') == "ansible.builtin")

# Generated at 2022-06-21 00:28:07.295211
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.plugins.loader import _get_collection_info

    # Set fixture to test CollectionSearch()

# Generated at 2022-06-21 00:29:31.373790
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test initializing with list
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin'], "Collections not set to builtin"

    # Test initializing with empty list
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin'], "Collections not set to builtin"

    # Test initializing with None
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin'], "Collections not set to builtin"

# Generated at 2022-06-21 00:29:38.422475
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection1 = CollectionSearch()
    print(collection1._collections)

    collection2 = CollectionSearch()
    if collection1._collections is collection2._collections:
        print("collection_list addr is same")
    else:
        print("collection_list addr is not same")
    print(collection1._collections)

    collection = CollectionSearch(collections=[])
    if collection1._collections is collection._collections:
        print("collection_list addr is same")
    else:
        print("collection_list addr is not same")
    print(collection._collections)
    return


if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-21 00:29:39.827117
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    # No error means no error
    assert collection_search is not None

# Generated at 2022-06-21 00:29:42.101663
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']
    assert cs.fake_collection is None
    assert cs.fake_collection_list == []

# Generated at 2022-06-21 00:29:48.721997
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Unit test for constructor of class CollectionSearch"""
    ds = {}
    # Test with default argument
    c = CollectionSearch()
    c._load_collections('collections', ds)
    # Test with a value
    ds = {'collections': ['test']}
    c = CollectionSearch()
    c._load_collections('collections', ds)
    assert c.collections == ['test', 'ansible.builtin']

# Generated at 2022-06-21 00:29:50.674325
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:29:55.398607
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.default == _ensure_default_collection()
    assert c.collections is None
    assert c.collections == _ensure_default_collection()
    assert c._collections.default == _ensure_default_collection()

# Generated at 2022-06-21 00:29:57.573406
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    collection_search = CollectionSearch(TaskInclude._attributes)
    collection_search._collections = _ensure_default_collection([])

# Generated at 2022-06-21 00:30:00.891961
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test constructor of class CollectionSearch
    _collectionsearch = CollectionSearch()
    assert _collectionsearch._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:30:03.537375
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections is None