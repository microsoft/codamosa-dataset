

# Generated at 2022-06-21 00:21:57.678514
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testCollectionSearch = CollectionSearch()
    assert testCollectionSearch._load_collections('collections', 'testCollectionSearch') is not None


# Generated at 2022-06-21 00:21:59.382045
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t._collections == ['ansible.builtin']

# Generated at 2022-06-21 00:22:03.818373
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']
    assert collection_search._load_collections(None, 'ansible.builtin') == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:22:05.590409
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections([]) == None

# Generated at 2022-06-21 00:22:13.751683
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    # should be ['ansible.builtin', 'ansible.legacy', 'ansible.builtin']
    assert _ensure_default_collection() == c._collections.default
    # should be ['test_collection', 'ansible.builtin', 'ansible.legacy', 'ansible.builtin']
    assert _ensure_default_collection(['test_collection']) == ['test_collection'] + c._collections.default
    # should be ['ansible.builtin', 'ansible.legacy', 'ansible.builtin']
    assert _ensure_default_collection(['ansible.builtin', 'ansible.legacy']) == c._collections.default
    # should be ['test_collection', 'ansible.builtin', 'ansible.legacy', 'ansible.built

# Generated at 2022-06-21 00:22:15.608229
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj.collections == _ensure_default_collection()

# Generated at 2022-06-21 00:22:20.103498
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test for constructor of class CollectionSearch
    mock_ds = [ 'test_collection' ]
    collectionSearch = CollectionSearch(collections = mock_ds)
    # verify "collections"
    assert collectionSearch._collections == mock_ds


# Generated at 2022-06-21 00:22:30.820402
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin', 'ansible.legacy']

    # Test with ansible.builtin and ansible.legacy are not in the list
    collection_search.collections = ['collection1', 'collection2']
    assert collection_search.collections == ['collection1', 'collection2', 'ansible.legacy']

    # Test with ansible.builtin is in the list
    collection_search.collections = ['ansible.builtin']
    assert collection_search.collections == ['ansible.builtin', 'ansible.legacy']

    # Test with ansible.legacy is in the list
    collection_search.collections = ['ansible.legacy']

# Generated at 2022-06-21 00:22:36.641396
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections == 'ansible.builtin'
    assert 'ansible.builtin' in collectionSearch._collections
    assert 'ansible.builtin' in collectionSearch._collections
    assert 'ansible.builtin' in collectionSearch._load_collections('', '')
    assert 'ansible.builtin' not in collectionSearch._load_collections('', '')
    assert collectionSearch._load_collections('', '') is not None
    assert collectionSearch.get_validated_value('collections', collectionSearch._collections, '', None) is not None
    assert collectionSearch.get_validated_value('collections', collectionSearch._collections, '', None) == 'ansible.builtin'

# Generated at 2022-06-21 00:22:37.936459
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert type(CollectionSearch().collections) == list

# Generated at 2022-06-21 00:22:46.747618
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # check if the variable _collections is None
    assert cs._collections is not None

# Generated at 2022-06-21 00:22:50.198114
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ob = CollectionSearch()
    assert ob._collections is None
    ob._collections = ['col1', 'col2']
    assert ob._collections == ['col1', 'col2']


# Generated at 2022-06-21 00:22:57.214605
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    test_block = Block()
    test_role = Role()
    test_task = TaskInclude()
    test_role_include = RoleInclude()

    assert test_block.collections is None
    assert test_role.collections is None
    assert test_task.collections is None
    assert test_role_include.collections is None


# Generated at 2022-06-21 00:23:02.964030
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute import Attribute
    from ansible.playbook.base import Base
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    role = Role()
    task = Task()
    assert isinstance(task.collections, Attribute)
    assert isinstance(role.collections, Attribute)

# Generated at 2022-06-21 00:23:06.490016
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections (test_obj, '') == ['ansible.builtin']
    test_obj.set_loader(object())
    assert test_obj.collections == ['ansible.builtin']

# Generated at 2022-06-21 00:23:09.473218
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cS = CollectionSearch()
    cS.collections = 'test1'
    cS.collections = ['test1', 'test2']
    cS.collections = None

# Generated at 2022-06-21 00:23:19.721139
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._load_collections(None, None) == ['ansible.legacy']
    assert c._load_collections(None, []) == ['ansible.legacy']
    assert c._load_collections(None, ['my.collection']) == ['my.collection', 'ansible.legacy']
    assert c._load_collections(None, ['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']
    assert c._load_collections(None, ['my.collection', 'ansible.builtin']) == ['my.collection', 'ansible.builtin', 'ansible.legacy']
    assert c._load_collections(None, ['my.collection', 'ansible.legacy']) == ['my.collection', 'ansible.legacy']

# Generated at 2022-06-21 00:23:20.661779
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-21 00:23:24.261712
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test for specifing a list of collections
    assert CollectionSearch(collections=['namespace.collection'])
    # Test for not specifying a list of collections
    assert CollectionSearch(collections=None)

# Generated at 2022-06-21 00:23:25.607031
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch(), '_load_collections')

# Generated at 2022-06-21 00:23:39.349859
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:23:49.094471
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    base = Base()
    base.collection_list = 'test_collection_list'

    role_include = RoleInclude()
    role_include.vars = 'test_vars'
    role_include.deps = 'test_deps'
    role_include.collections = 'test_collections'
    base.role_includes.append(role_include)

    task_include = TaskInclude()
    task_include.vars = 'test_vars'
    task_include.loop = 'test_loop'
    task_include.collections = 'test_collections'

# Generated at 2022-06-21 00:23:56.071895
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

	import unittest

	class CollectionSearchInitTest(unittest.TestCase):

		def test_no_arg(self):
			assert CollectionSearch() is not None

	suite = unittest.TestLoader().loadTestsFromTestCase(CollectionSearchInitTest)
	unittest.TextTestRunner(verbosity=2).run(suite)

test_CollectionSearch()


# Generated at 2022-06-21 00:23:57.976008
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-21 00:24:04.078864
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test 1
    ds = dict()
    collection_search = CollectionSearch()
    assert collection_search._load_collections('', ds) == _ensure_default_collection()

    # Test 2
    ds = dict()
    collection_search = CollectionSearch()
    ds = dict(collections=['somecollection', 'someothercollection'])
    assert collection_search._load_collections('', ds) == ['somecollection', 'someothercollection', 'ansible.builtin']

# Generated at 2022-06-21 00:24:06.428123
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    if cs._load_collections is None:
        print("CollectionSearch - load_collections method is not defined")
    else:
        print("CollectionSearch - load_collections method is defined")

# Generated at 2022-06-21 00:24:09.670396
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert len(cs._collections) == 1
    assert 'ansible.builtin' in cs._collections


# Generated at 2022-06-21 00:24:10.690448
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert(obj)

# Generated at 2022-06-21 00:24:12.656461
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections() == _ensure_default_collection()

# Generated at 2022-06-21 00:24:18.363160
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    new_collection = CollectionSearch()

    collection_list = ['ansible.builtin', 'ansible.builtin.tasks']

    collections = new_collection._ensure_default_collection(collection_list)

    assert collections == collection_list

    collections = new_collection._ensure_default_collection(None)
    assert collections[0] == 'ansible.builtin'

# Generated at 2022-06-21 00:24:50.004003
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Takes list of type string and check if all are valid collections.
    assert _ensure_default_collection(["ansible_collections.my_namespace.my_collection"]) == ["ansible_collections.my_namespace.my_collection", 'ansible.legacy']
    # Taking list of invalid collection.
    assert _ensure_default_collection([1]) == ['ansible.legacy']
    # Taking list of type dict.
    assert _ensure_default_collection([{}]) == ['ansible.legacy']
    # Taking list of invalid collections.
    assert _ensure_default_collection([1, {}]) == ['ansible.legacy']
    # Taking list of integer.
    assert _ensure_default_collection([1,0]) == ['ansible.legacy']
    # Taking list of list.

# Generated at 2022-06-21 00:24:51.645333
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    assert col._collections == _ensure_default_collection()

# Generated at 2022-06-21 00:24:54.279686
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, []) is not None
    assert cs._load_collections(None, ['collections']) is not None

# Generated at 2022-06-21 00:25:06.078374
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.module_utils.common._collections_compat import CollectionLoader
    loader = CollectionLoader()
    loader.resolve_collections([])
    collections_search = CollectionSearch()
    display = Display()
    context = PlayContext()
    collection_search = CollectionSearch()
    block = Block(name='test_task_list', parent_block=None, role=None, task_include=None, use_handlers=False,
                  variable_manager=None, loader=loader, play_context=context,
                  ordered_tasks=[Task()])
    assert isinstance(collection_search.collections, list)

# Generated at 2022-06-21 00:25:07.826650
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == [ "ansible.posix" ]



# Generated at 2022-06-21 00:25:10.009494
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = "frappe.arrk.awesome"
    assert cs.collections == collections == ["frappe.arrk.awesome"]

# Generated at 2022-06-21 00:25:14.597972
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert type(test_obj._collections) == FieldAttribute
    assert test_obj._collections.isa == 'list'
    assert test_obj._collections.listof == string_types
    assert test_obj._collections.priority == 100
    assert test_obj._collections.default == _ensure_default_collection
    assert test_obj._collections.always_post_validate == True
    assert test_obj._collections.static == True

# Generated at 2022-06-21 00:25:19.107515
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    c.collections = 'ansible_collections.namespace.collection.plugin_name'
    assert c.collections == 'ansible_collections.namespace.collection.plugin_name'

# Generated at 2022-06-21 00:25:21.393506
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.post_validate(ds=None, var_name='collections', attributes=None, play=None)

# Generated at 2022-06-21 00:25:23.369564
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("Testing: CollectionSearch")
    test_CollectionSearch = CollectionSearch()
    test_CollectionSearch._load_collections()

# Generated at 2022-06-21 00:26:17.280470
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None, '_collections is None'
    assert collection_search._load_collections is not None, '_load_collections is None'
    assert collection_search.collections is None, 'collections is not None'

# Generated at 2022-06-21 00:26:18.805618
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections is not None


# Generated at 2022-06-21 00:26:19.848770
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test the constructor of class CollectionSearch
    CollectionSearch()

# Generated at 2022-06-21 00:26:24.002919
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  test = CollectionSearch(collections=['test1', 'test2'])
  test1 = test._load_collections('collections', [])
  assert test1 == ['test1', 'test2']
'''
  # How to run the unit test
  test = CollectionSearch()
  test._load_collections('collections', [])
  test._load_collections('collections', ['test1', 'test2'])
'''

# Generated at 2022-06-21 00:26:25.931000
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x=CollectionSearch()
    x._load_collections(0,0)
    x.collections

# Generated at 2022-06-21 00:26:28.130958
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._post_validate()


__all__ = ('CollectionSearch', '_ensure_default_collection')

# Generated at 2022-06-21 00:26:32.690092
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections is search.collections
    assert search.collections._name == 'collections'
    assert isinstance(search.get_validated_value('collections',
                                            search._collections,
                                            [],
                                            None), list)

# Generated at 2022-06-21 00:26:35.384870
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ansible_collection_config = AnsibleCollectionConfig()
    collection_search = CollectionSearch()
    collection_search._load_collections(AnsibleCollectionConfig.COLLECTION_PATHS, ansible_collection_config)

# Generated at 2022-06-21 00:26:37.607324
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.__class__.__name__ == "CollectionSearch"


# Generated at 2022-06-21 00:26:41.634659
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # Assertion for fields
    assert collection_search.fields['collections']
    # Assertion for static attributes
    assert collection_search.static_attrs['_collections']
    # Assertion for post_validate() method
    assert collection_search.post_validate(['test'])

# Generated at 2022-06-21 00:28:50.620114
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ds = {
        "collections": [
            "ansible_collections.notstdlib.moveit.plugins.module_utils.network.nxos.argspec",
            "ansible_collections.notstdlib.moveit.plugins.modules.nxos_ntp",
            "ansible.builtins"
        ]
    }
    cs.post_validate(ds, {})
    assert len(ds["collections"]) == 3
    assert ds["collections"][0] == "ansible_collections.notstdlib.moveit.plugins.modules.nxos_ntp"
    assert ds["collections"][1] == "ansible_collections.notstdlib.moveit.plugins.module_utils.network.nxos.argspec"


# Generated at 2022-06-21 00:28:55.858286
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base

    class MyBase(CollectionSearch, Base):
        def __init__(self, base_ds):
            super(MyBase, self).__init__(base_ds)

    class MyBase2(Base, CollectionSearch):
        def __init__(self, base_ds):
            super(MyBase2, self).__init__(base_ds)

    base = MyBase({})
    base2 = MyBase2({})

    # this exists because we can't instantiate a class with a field_name that
    # has not been defined
    assert base.collections
    assert base2.collections

# Generated at 2022-06-21 00:29:03.776041
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()
    collections = ['common', 'extra', 'ansible.builtin']
    c = CollectionSearch(collections=collections)
    assert c._collections == _ensure_default_collection(collections)
    collections = ['common', 'extra']
    c = CollectionSearch(collections=collections)
    assert c._collections[0] == 'common'
    assert c._collections[1] == 'extra'
    assert c._collections[2] == 'ansible.builtin'
    assert len(c._collections) == 3

# Generated at 2022-06-21 00:29:04.874710
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search._collections)

# Generated at 2022-06-21 00:29:07.384189
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == _ensure_default_collection()
    c.collections = []
    assert c.collections == _ensure_default_collection([])

# Generated at 2022-06-21 00:29:09.744009
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._load_collections('collections', ['demo_collection', 'demo_collection2']) == ['demo_collection', 'demo_collection2']

# Generated at 2022-06-21 00:29:12.287618
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()

    # Test static field
    collection_list = instance._collections
    assert collection_list is not None
    assert 'ansible.default' in collection_list or 'ansible.legacy' in collection_list

# Generated at 2022-06-21 00:29:13.034167
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()


# Generated at 2022-06-21 00:29:19.531543
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base

    base = Base()
    assert isinstance(base, Base)
    assert isinstance(base, CollectionSearch)

    # test _collections attribute is set
    assert base._collections is not None
    assert base._collections == _ensure_default_collection()
    assert base._collections == _ensure_default_collection([])
    assert base._collections != ['']
    assert base._collections != ''
    # FIXME: add test when default_collection is not set or default_collection is set in config

    # test _load_collections method
    assert base._load_collections(None, base._collections) is not None
    assert base._load_collections(None, base._collections) == _ensure_default_collection()
    assert base._load_collections

# Generated at 2022-06-21 00:29:21.966914
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search=CollectionSearch()
    assert collection_search._load_collections(collection_search._collections, None) == ['ansible.builtin', 'ansible.legacy']