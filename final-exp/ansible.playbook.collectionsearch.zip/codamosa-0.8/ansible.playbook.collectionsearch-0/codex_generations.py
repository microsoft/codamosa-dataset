

# Generated at 2022-06-22 13:51:09.719881
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections is not None
    assert search._collections.default == _ensure_default_collection

# Generated at 2022-06-22 13:51:10.359365
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-22 13:51:11.810977
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    assert CollectionSearch._collections._default == _ensure_default_collection
    assert CollectionSearch.get_value('collections', None) == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-22 13:51:13.767488
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_cls = CollectionSearch()
    search_cls._load_collections(None, None)

# Generated at 2022-06-22 13:51:17.003240
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.get_validated_value(name='collections', validator=cs._collections,
                           value=None, task_vars={}, default_attribute=None)

# Generated at 2022-06-22 13:51:18.840776
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None

# Generated at 2022-06-22 13:51:29.764847
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    obj = CollectionSearch()

    # Check _collections default value
    assert obj._collections.default == _ensure_default_collection

    # Check _load_collections()

    # Mock object says, the "collections" attribute will be
    # None.
    obj.get_validated_value = lambda x,y,z,w : None
    assert obj._load_collections("attr", "ds") is None

    # Mock object says, the "collections" attribute will be
    # ['ansible.builtin', 'ansible.legacy']
    obj.get_validated_value = lambda x,y,z,w : ['ansible.builtin', 'ansible.legacy']
    assert obj._load_collections("attr", "ds") == ['ansible.builtin', 'ansible.legacy']

    #

# Generated at 2022-06-22 13:51:31.578533
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.collections is not None
    assert isinstance(a.collections, list)

# Generated at 2022-06-22 13:51:39.569891
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   search = CollectionSearch()
   assert search._load_collections('collections',{'collections':['my_collection']}) == ['my_collection']
   assert search._load_collections('collections',{'collections':['my_collection','ansible.builtin']}) == ['my_collection','ansible.builtin']
   assert search._load_collections('collections',{'collections':['my_collection','ansible.builtin','ansible.legacy']}) == ['my_collection','ansible.builtin','ansible.legacy']
   assert search._load_collections('collections',{'collections':['my_collection','ansible.builtin','ansible.legacy','ansible.builtin']}) == ['my_collection','ansible.builtin','ansible.legacy','ansible.builtin']

# Generated at 2022-06-22 13:51:46.034969
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestClass():
        def __init__(self):
            self._collections = None
            self.collections = self.get_validated_value('collections', self._collections, ["collection1", "collection2"], None)
            if not self.collections:
                self.collections = None

    test_obj = TestClass()
    assert test_obj.collections == ["collection1", "collection2"]

# Generated at 2022-06-22 13:52:03.290404
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print('test_CollectionSearch')
    collection_search = CollectionSearch()

    assert collection_search._collections.default == [
        'ansible_collections.nsxt.nsxt_collection.plugins.modules.nsxt_*',
        'ansible_collections.nsxt.nsxt_collection.plugins.module_utils.network.nsxt.nsxt',
        'ansible.legacy']
    assert collection_search._collections.always_post_validate == True
    assert collection_search._collections.static == True
    assert collection_search._collections.priority == 100


if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-22 13:52:05.526472
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   tets = CollectionSearch()
   assert tets._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:52:10.345599
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This object is not yet instantiated directly, but calling the constructor of the base class
    # will initialize the object and we can get the collection_name to be used further.
    search = CollectionSearch(None)
    collection_name = search._collections.get_value()
    # Default collection name must not be none
    assert collection_name

# Generated at 2022-06-22 13:52:13.417351
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._collections == _ensure_default_collection(collection_list=None)



# Generated at 2022-06-22 13:52:20.451172
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    # No value assigned to collection
    ds = None
    collection_search._load_collections(None, ds)
    assert collection_search._collections == _ensure_default_collection(ds)

    # User assigned value to collection
    ds = ["my_collection"]
    collection_search._load_collections(None, ds)
    assert collection_search._collections == _ensure_default_collection(ds)

# Generated at 2022-06-22 13:52:22.107970
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
     obj = CollectionSearch()
     assert obj._collections == "ansible.builtin"

# Generated at 2022-06-22 13:52:28.816371
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test_CollectionSearch(CollectionSearch):
        def __init__(self, col_list=None):
            self.collections = col_list
    test_collection = Test_CollectionSearch()
    assert test_collection.collections == _ensure_default_collection()

    test_collection = Test_CollectionSearch(['test.collection'])
    assert test_collection.collections == ['test.collection', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:52:34.326182
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()
    assert col_search._collections == _ensure_default_collection([])
    assert col_search._collections == _ensure_default_collection(None)
    maps = col_search._load_collections('collections', col_search._collections)
    assert maps == _ensure_default_collection(None)

# Generated at 2022-06-22 13:52:35.963291
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs._collections, FieldAttribute)

# Generated at 2022-06-22 13:52:38.965772
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearchObj = CollectionSearch()
    collectionSearchObj.collections = ['ansible.test']
    assert collectionSearchObj.collections == ['ansible.test', 'ansible.builtin']

# Generated at 2022-06-22 13:52:53.651190
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:52:55.553405
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-22 13:53:01.620941
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections['value_type'] == 'list'
    assert cs._collections['isa'] == 'list'
    assert cs._collections['default'] == _ensure_default_collection

    #assert cs._load_collections({}, []) == _ensure_default_collection()


if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-22 13:53:03.357104
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:53:04.936468
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()



# Generated at 2022-06-22 13:53:11.677666
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.get_validated_value('collections', c._collections, ['test'], None) == ['test']
    assert c.get_validated_value('collections', c._collections, None, None) is None
    assert c.get_validated_value('collections', c._collections, None, None) is None
    assert c.get_validated_value('collections', c._collections, ['test1','test2'], None) == ['test1','test2']
    assert c.get_validated_value('collections', c._collections, list(), None) is None
    assert c.get_validated_value('collections', c._collections, [], None) is None

# Generated at 2022-06-22 13:53:15.790026
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create a CollectionSearch object
    s = CollectionSearch()
    # Verify that the collection list is populated with the default collection
    assert s._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:53:24.140280
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        def __init__(self, collection_list=None):
            self._collections = collection_list

    assert TestCollectionSearch()._load_collections(None, None) == ['ansible.builtin', 'ansible.legacy']
    assert TestCollectionSearch(['my.collection'])._load_collections(None, None) == \
        ['my.collection', 'ansible.builtin', 'ansible.legacy']
    assert TestCollectionSearch(['my.collection', 'ansible.legacy'])._load_collections(None, None) == \
        ['my.collection', 'ansible.legacy']

# Generated at 2022-06-22 13:53:27.943150
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_lib = CollectionSearch()
    # isinstance() returns true if the object is an instance of the class
    # or other classes derived from it.
    assert isinstance(test_lib, CollectionSearch)

# Generated at 2022-06-22 13:53:32.907334
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class testClass(CollectionSearch):
        def __init__(self):
            self.collections=None
            super(CollectionSearch, self).__init__()
            self.attributes = {'collections': self._collections}

    t=testClass()
    t.post_validate()
    assert not t.collections

# Generated at 2022-06-22 13:54:00.742800
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:54:02.724582
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:54:03.983832
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    
    assert collectionSearch

# Generated at 2022-06-22 13:54:05.655848
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection

# Generated at 2022-06-22 13:54:10.448229
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test with a list of collections
    ds = ["ansible_collections.community.general"]
    cs = CollectionSearch(collections=ds)
    assert cs._collections == ds

    # Test with no list of collections
    cs = CollectionSearch(collections=None)
    assert cs._collections == ['ansible_collections.ansible.builtin']

# test for constructor with list of collections

# Generated at 2022-06-22 13:54:11.769871
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    answer = instance._ensure_default_collection(None)
    assert answer is not None

# Generated at 2022-06-22 13:54:15.152541
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_list=['ansible.builtin']

    cs = CollectionSearch()
    assert cs._collections == None
    assert cs._load_collections(None, collection_list) == ['ansible.builtin']

# Generated at 2022-06-22 13:54:16.605984
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:54:18.019163
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:54:26.529062
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    
    # instantiate an object of class CollectionSearch
    collection_search = CollectionSearch()
    # call a private method _load_collections
    test_collection_list = collection_search._load_collections('collections', None)
    print(test_collection_list)
    
    # test mixin class Base
    base_obj = Base()
    base_obj.collections = ['namespace.name']
    test_collections = base_obj._load_collections('collections', base_obj.collections)
    print(test_collections)

    # test subclass class Role
    role_obj = Role()
    role_obj.collections = ['namespace.name']

# Generated at 2022-06-22 13:54:52.681691
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:54:55.985494
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert (CollectionSearch.__bases__[0].__name__ == 'Base')
    assert (CollectionSearch.__dict__['_collections'] == FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection, always_post_validate=True,static=True))



# Generated at 2022-06-22 13:54:58.504467
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    is_col = CollectionSearch()
    assert is_col._collections == _ensure_default_collection()


# Generated at 2022-06-22 13:55:00.104918
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ['ansible_collections.ns.test_ns.test_coll']

# Generated at 2022-06-22 13:55:05.183228
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #empty collection list
    #should return None
    assert CollectionSearch._collections.default(None) == None

    #check if default collection added
    default_col="ansible.builtin"
    assert CollectionSearch._collections.default([default_col]) == [default_col]

# Generated at 2022-06-22 13:55:08.245986
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections("attr", []) == ['ansible.builtin']
    assert CollectionSearch()._load_collections("attr", None) == ['ansible.builtin']

# Generated at 2022-06-22 13:55:09.903367
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, object)


# Generated at 2022-06-22 13:55:16.929192
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._load_collections('collections', []) == ['ansible.builtin','ansible.legacy']

    c = CollectionSearch()
    assert c._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin','ansible.legacy']

    c = CollectionSearch()
    assert c._load_collections('collections', ['ansible.collection']) == ['ansible.collection','ansible.legacy']

# Generated at 2022-06-22 13:55:17.459740
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections is not None

# Generated at 2022-06-22 13:55:26.058093
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test default value
    t = CollectionSearch()
    assert t._collections == ['ansible_collections.notmintest.not_a_real_collection', 'ansible.builtin', 'ansible.legacy']
    assert t.collections == ['ansible_collections.notmintest.not_a_real_collection', 'ansible.builtin', 'ansible.legacy']

    # Test setting a list of collections
    t = CollectionSearch()
    t.collections = ['frobnitz.plugins.modules', 'ansible.builtin', 'ansible.legacy']
    assert t.collections == ['frobnitz.plugins.modules', 'ansible.builtin', 'ansible.legacy']

    # Test setting a single collection
    t = CollectionSearch()

# Generated at 2022-06-22 13:56:27.771482
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # set collections to ['ansible.collection1', 'ansible.collection2']
    # expect a warning that 'collections' is not templatable
    # expect a warning that 'ansible.legacy' is not templated
    # expect the final collections value to be the same as the test
    cs = CollectionSearch()
    cs.attributes['collections'].post_validate(vars={'collections': ['ansible.collection1', 'ansible.collection2']})

    # set collections to ['ansible.collection1', 'ansible.collection2']
    # expect a warning that 'collections' is not templatable / expect a warning that 'ansible.legacy' is not templated
    # expect the final collections value to be the same as the test
    cs = CollectionSearch()

# Generated at 2022-06-22 13:56:32.027241
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert 'ansible.builtin' in search._load_collections('collections', None), 'Load built-in collection if none was specified.'
    assert 'ansible.builtin' in search._load_collections('collections', [])

# Generated at 2022-06-22 13:56:33.129215
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    assert collection_search._collections is None

# Generated at 2022-06-22 13:56:34.261817
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections["default"] == _ensure_default_collection()

# Generated at 2022-06-22 13:56:38.520677
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs
    assert cs._collections.default == cs._ensure_default_collection
    assert cs._collections.default == _ensure_default_collection

# Generated at 2022-06-22 13:56:39.171216
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch

# Generated at 2022-06-22 13:56:41.766934
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == 'ansible.builtin' or cs.collections == 'ansible.legacy', "Validation of collections failed"

# Generated at 2022-06-22 13:56:45.379140
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_dict = {'_collections':['ansible.builtin', 'ansible.posix']}
    collection_search = CollectionSearch(task_ds=test_dict)
    assert dict(collection_search) == test_dict

# Generated at 2022-06-22 13:56:46.676104
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    result = cs.collections
    assert result

# Generated at 2022-06-22 13:56:49.682457
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test with no argument
    test_search = CollectionSearch()

    # Test with collections parameter
    test_search = CollectionSearch(collections = ['ansible.builtin'])
    assert test_search._collections == ['ansible.builtin']

# Generated at 2022-06-22 13:58:36.858767
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections
    assert CollectionSearch()._load_collections(attr='collections', ds=[])

# Generated at 2022-06-22 13:58:39.298827
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._collections == _ensure_default_collection()



# Generated at 2022-06-22 13:58:41.917227
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test creating CollectionSearch without providing collections
    assert not CollectionSearch(collections=None).collections

    # Test creating CollectionSearch with collections provided
    assert CollectionSearch(collections=['test.collection']).collections

# Generated at 2022-06-22 13:58:43.384656
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()

    assert c.collections == ['ansible.legacy']

# Generated at 2022-06-22 13:58:45.453559
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass

    obj = TestCollectionSearch()
    assert obj.collections == [AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-22 13:58:56.034224
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Testing the constructor of CollectionSearch
    cs = CollectionSearch()

    # Testing the FieldAttribute for the collection
    assert isinstance(cs._collections.field, FieldAttribute)

    # Testing the isa field of FieldAttribute
    assert cs._collections.field.isa == 'list'

    # Testing the priority field of FieldAttribute
    assert cs._collections.field.priority == 100

    # Testing the default field of FieldAttribute
    assert cs._collections.field.default == _ensure_default_collection

    # Testing the always_post_validate field of FieldAttribute
    assert cs._collections.field.always_post_validate == True

    # Testing the static field of FieldAttribute
    assert cs._collections.field.static == True

# Generated at 2022-06-22 13:58:57.931575
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_test = CollectionSearch()
    assert search_test.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:59:00.583949
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an object of the CollectionSearch class
    cs = CollectionSearch()
    # Assert that the type of the object is the same as the type of the class
    assert isinstance(cs, CollectionSearch)

# Generated at 2022-06-22 13:59:01.915575
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    url = CollectionSearch()
    url._load_collections(url._collections.name, ['test'])

# Generated at 2022-06-22 13:59:02.965427
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()