

# Generated at 2022-06-22 13:51:09.395674
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:12.301639
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search = CollectionSearch()
    except:
        collection_search = None

    assert(collection_search is not None)

# Generated at 2022-06-22 13:51:16.397616
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    if (t.collections == _ensure_default_collection()):
        print("OK")
    else:
        print("FAIL")

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:51:18.694069
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-22 13:51:19.255238
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-22 13:51:21.335977
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def_collection_search = CollectionSearch()
    assert def_collection_search._collections.default == ['ansible.builtin,ansible.legacy']

# Generated at 2022-06-22 13:51:25.623540
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collections_list = ["ansible.builtin", "001_role_from_collection"]
    test_collections = CollectionSearch(collections=test_collections_list)
    assert test_collections.collections == test_collections_list

# Generated at 2022-06-22 13:51:27.258830
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:34.669334
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    a.post_validate({}, None)
    assert isinstance(a.collections, list)
    assert len(a.collections) == 1 and 'ansible.legacy' in a.collections

    a = CollectionSearch(collections='abc')
    a.post_validate({}, None)
    assert isinstance(a.collections, list)
    assert len(a.collections) == 2
    assert 'ansible.legacy' in a.collections
    assert 'abc' in a.collections


# Generated at 2022-06-22 13:51:36.498362
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin', 'ansible.test_collection_test']

# Generated at 2022-06-22 13:51:45.836645
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections is _ensure_default_collection()
    assert CollectionSearch()._load_collections(attr=None, ds=[]) is None

# Generated at 2022-06-22 13:51:49.093491
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    m = CollectionSearch()
    # Test for default constructor
    assert m._load_collections(attr='collections', ds=None) == 'ansible_collections.ansible.builtin'



# Generated at 2022-06-22 13:51:51.557367
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class MyTest(CollectionSearch):
        pass
    test_obj = MyTest()
    assert test_obj

# Generated at 2022-06-22 13:51:53.685273
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = CollectionSearch()
    ds._collections = _ensure_default_collection()
    assert ds._collections is not None

# Generated at 2022-06-22 13:51:55.520918
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:57.330385
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:58.926773
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    assert isinstance(test_instance, CollectionSearch)

# Generated at 2022-06-22 13:51:59.926854
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    data = CollectionSearch()
    assert data

# Generated at 2022-06-22 13:52:11.306609
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import json
    from ansible.playbook.play_context import PlayContext

    from units.mock.loader import DictDataLoader

    name = 'test_CollectionSearch'
    loader = DictDataLoader({name: "{'collections': [".format(name)})

    current_context = PlayContext()

    def run(collections):
        ds = {'collections': collections, 'name': "test_CollectionSearch"}
        current_context.name_to_path(name, os.path.realpath(name))
        current_context.set_loader(loader)

        c = CollectionSearch()
        c.load_from_datastore(ds, current_context)
        return c
    # Test invalid input: collections is not a list.
    c = run("foo")
    assert c.collections == None

   

# Generated at 2022-06-22 13:52:15.669621
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearch_Test(CollectionSearch):
        pass

    search = CollectionSearch_Test()
    assert isinstance(search._collections, FieldAttribute)
    assert search._load_collections('collections', 'ansible.builtin') is None

# Generated at 2022-06-22 13:52:40.240742
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # no collections
    cs = CollectionSearch()
    assert len(cs.collections) == 2
    assert 'ansible.builtin' in cs.collections
    assert 'ansible.legacy' in cs.collections

    # valid collections
    cs = CollectionSearch(collections=['foo.bar', 'baz.qux'])
    assert len(cs.collections) == 4
    assert 'foo.bar' in cs.collections
    assert 'baz.qux' in cs.collections
    assert 'ansible.builtin' in cs.collections
    assert 'ansible.legacy' in cs.collections

    # default collection (no collections provided)
   

# Generated at 2022-06-22 13:52:41.720108
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.posix']

# Generated at 2022-06-22 13:52:43.700807
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:52:46.813431
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search._collections = ['collections']
    print(collection_search.collections)


# Generated at 2022-06-22 13:52:50.582554
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert len(collectionSearch._collections) == 1
    assert collectionSearch._collections[0] == 'ansible.builtin'
    assert collectionSearch._load_collections != None


# Generated at 2022-06-22 13:52:51.186259
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-22 13:52:51.817594
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    print(test_CollectionSearch._collections)

# Generated at 2022-06-22 13:53:03.359152
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Default collections
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin', 'ansible.legacy']

    # User collections
    collection_search = CollectionSearch(collections=['1', '2'])
    assert collection_search.collections == ['1', '2', 'ansible.builtin', 'ansible.legacy']

    # Check if non-collection names are not added to the collection list
    collection_search = CollectionSearch(collections=['1', '2', '/home/user/collections/3'])
    assert collection_search.collections == ['1', '2', 'ansible.builtin', 'ansible.legacy']

    # Check if default collection is added to the collection list
    collection_search = CollectionSearch(collections=[])

# Generated at 2022-06-22 13:53:04.614103
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    print(c._collections)

test_CollectionSearch()

# Generated at 2022-06-22 13:53:08.811963
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude

    t = TaskInclude(name='test', delegate_to='test_host', collections=['ansible.builtin'])
    assert t.collections[0] == 'ansible.builtin'

# Generated at 2022-06-22 13:53:46.088629
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        from ansible.module_utils.ansible_release import __version__ as ansible_version
    except ImportError:
        ansible_version = '2.8.0'

    if not ansible_version.startswith('2.10.'):
        # This is how to work with pre-2.10

        # test _ensure_default_collection
        assert _ensure_default_collection() == ['ansible.legacy', 'ansible_collections.ansible']
        assert _ensure_default_collection(['ns.name']) == ['ns.name', 'ansible.legacy', 'ansible_collections.ansible']

        cs = CollectionSearch()

        # test _load_collections
        assert cs._load_collections(None, None) is None
        assert cs._load_collections

# Generated at 2022-06-22 13:53:46.666820
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-22 13:53:47.602456
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test that the constructor works
    CollectionSearch()

# Generated at 2022-06-22 13:53:49.055079
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is None

# Generated at 2022-06-22 13:53:51.552130
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #check to make sure that _collections is initialized and a list
    se = CollectionSearch()
    assert isinstance(se._collections, list)

# Generated at 2022-06-22 13:53:57.544996
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert result is not None
    assert result.collections == ['ansible_collections.nsxt', 'ansible_collections.vmware', 'ansible_collections.juniper', 'ansible_collections.notmintest', 'ansible_collections.community', 'ansible_collections.misc', 'ansible.builtin']

# Generated at 2022-06-22 13:54:00.337551
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)
    assert obj._collections == ['ansible.builtin','ansible.legacy']

# Generated at 2022-06-22 13:54:02.302361
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestConstructor(CollectionSearch):
        def __init__(self):
            super(TestConstructor, self).__init__()

    TestConstructor()

# Generated at 2022-06-22 13:54:04.497224
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == ['ansible.netcommon']

# Generated at 2022-06-22 13:54:12.785300
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.utils.vars import combine_vars

    task = 'name: test\ntasks:\n- debug:\n    msg: hello\n'
    data = dict(
        task=dict(
            vars=dict(msg='world'),
            collections='ansible_namespace.collection_name',
        )
    )

    loader, _, _ = Base.load(data, play_context={'vault_password': 'pass'}, task_vars=combine_vars(loader=None,
                                                                                                templar=None,
                                                                                                variables={},
                                                                                                task_vars={}))

# Generated at 2022-06-22 13:55:12.935170
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create a object to test the constructor for
    collectionSearch = CollectionSearch()

    assert collectionSearch._collections is not None
    assert collectionSearch._collections == _ensure_default_collection()
    assert collectionSearch._collections[0] == 'ansible.builtin'
    assert collectionSearch._collections[1] is not 'ansible.builtin'
    assert collectionSearch._collections[2] == 'ansible.ansible_collections.nsxt.ansible_collections.nsxt.tasks'
    assert collectionSearch._collections[3] == 'ansible.ansible_collections.nsxt.ansible_collections.nsxt.plugins'
    assert collectionSearch._collections[4] == 'ansible.ansible_collections.nsxt.ansible_collections.nsxt.modules'
    assert collectionSearch

# Generated at 2022-06-22 13:55:13.734632
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-22 13:55:17.282787
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections._value is not None
    assert search._collections._value[0] is not None
    assert search._collections._value[0] == "ansible.builtin"

# Generated at 2022-06-22 13:55:18.977194
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()
    assert hasattr(collection_search, '_collections')

# Generated at 2022-06-22 13:55:21.368824
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    a = CollectionSearch()
    assert a
    assert isinstance(a._collections, list)
    assert isinstance(a._collections[0], string_types)

# Generated at 2022-06-22 13:55:22.346915
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    x = CollectionSearch()
    assert x._collections

# Generated at 2022-06-22 13:55:23.319280
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    res = CollectionSearch()
    assert res is not None

# Generated at 2022-06-22 13:55:25.366591
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    b = CollectionSearch()
    print("\ntest done")


CollectionSearch()._load_collections(None, None)

# Generated at 2022-06-22 13:55:27.617300
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections() == None

# Generated at 2022-06-22 13:55:38.262794
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    from ansible.playbook.attribute import FieldAttribute

    search = CollectionSearch()


    # Test _collections
    collections = getattr(search, '_collections')
    assert isinstance(collections, FieldAttribute)
    pytest.raises(TypeError, collections.validate, 'ansible.builtin')
    pytest.raises(TypeError, collections.validate, [1])
    pytest.raises(TypeError, collections.validate, ['ansible.builtin', 1])
    pytest.raises(TypeError, collections.validate, ['ansible.builtin', 'ansible.builtin', 1])
    pytest.raises(TypeError, collections.validate, ['ansible.builtin', 'ansible.builtin', 'ansible.builtin', 1])


#

# Generated at 2022-06-22 13:57:24.953191
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    foo = CollectionSearch()
    assert foo._load_collections('_collections', []) is None
    assert foo._load_collections('_collections', ['ansible.builtin']) == ['ansible.builtin']
    assert foo._load_collections('_collections', ['fod.builtin']) == ['fod.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:57:27.608272
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.collections = ['ansible.builtin', 'ansible.legacy']
    assert collection_search.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:57:30.760358
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert type(test_CollectionSearch) == CollectionSearch
    assert test_CollectionSearch._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:57:32.361252
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is not None, "Expected valid lists"

# Generated at 2022-06-22 13:57:34.251246
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        CollectionSearch()
    except:
        assert False, 'CollectionSearch() failed'

# Generated at 2022-06-22 13:57:38.531975
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # test that there is one collection in the list and that it is 'ansible.builtin'
    assert len(collection_search.collections) == 1
    assert collection_search.collections[0] == 'ansible.builtin'

# Generated at 2022-06-22 13:57:41.884620
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert len(AnsibleCollectionConfig.default_collection) > 0
    print("Unit test for constructor of class CollectionSearch passed")


# Generated at 2022-06-22 13:57:42.896316
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch()


# Generated at 2022-06-22 13:57:47.811149
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass
    test_obj = TestCollectionSearch()

    # Check if class successfully adds new field
    if 'collections' not in test_obj._attributes:
        raise AssertionError("class CollectionSearch did not add new field.")
    collection = test_obj._attributes['collections']

    # Check if class correctly sets attribute
    if collection.default != _ensure_default_collection:
        raise AssertionError("class CollectionSearch did not set default correctly.")


# Generated at 2022-06-22 13:57:49.740785
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert(collection_search._collections==_ensure_default_collection())