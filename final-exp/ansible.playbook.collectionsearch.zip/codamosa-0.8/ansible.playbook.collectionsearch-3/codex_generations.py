

# Generated at 2022-06-22 13:51:08.902620
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()


# Generated at 2022-06-22 13:51:10.804427
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:20.833220
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    assert AnsibleCollectionConfig.default_collection is None

    class Test(CollectionSearch):
        pass

    t = Test()

    # Should be no default collection
    assert t._collections is not None
    assert len(t._collections) == 0

    # Validate it. This will call _ensure_default_collection
    t.get_validated_value('collections', t._collections, None, None)

    # User did not specify a value, so we should have added 'ansible.builtin' or 'ansible.legacy'
    assert t._collections is not None
    assert len(t._collections) == 1
    assert 'ansible.legacy' in t._collections or 'ansible.builtin' in t._collections

    # Now that the default is a list, setting it to None will still cause it to

# Generated at 2022-06-22 13:51:28.365526
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text

    c = CollectionSearch()
    ds = dict()
    ds['collections'] = ['test_collection']

    try:
        c._load_collections('collections', ds)
        pytest.fail(to_text("'collections' did not error when missing required fields."))
    except AnsibleError as e:
        assert to_text(e).startswith("The 'collections' field is required")

# Generated at 2022-06-22 13:51:30.532959
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert(x._collections == ['ansible.builtin', 'ansible.legacy'])

# Generated at 2022-06-22 13:51:31.916717
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert isinstance(collection, CollectionSearch)

# Generated at 2022-06-22 13:51:33.270495
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None

# Generated at 2022-06-22 13:51:34.583093
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:37.037775
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch(loader=None, variable_manager=None, collection_list=None)
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-22 13:51:40.587004
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        cs = CollectionSearch()
    except Exception:
        print("Exception in constructor of class CollectionSearch")
    else:
        print("Constructor of class CollectionSearch works fine.")

# Generated at 2022-06-22 13:51:48.796415
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:52.405106
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    collection._load_collections(attr='collections', ds=[])
    #collection._job_vars.update({'collection_list': ['ansible.builtin']})

# Generated at 2022-06-22 13:51:54.152252
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible_collections.community.general']

# Generated at 2022-06-22 13:51:57.076974
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class test(CollectionSearch):
        pass

    x = test()
    assert x._collections is not None



# Generated at 2022-06-22 13:51:59.877898
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # Test attribute
    collection_search._collections = 'ansible.builtin'
    assert collection_search._collections == 'ansible.builtin'

# Generated at 2022-06-22 13:52:06.709682
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestClass(CollectionSearch):
        pass
    test_class = TestClass()
    assert test_class._collections.default_value == _ensure_default_collection()
    # _collections is an attribute
    assert test_class._collections.name == 'collections'
    # _collections is a field and not an attribute
    assert test_class._collections.is_field is True

# Generated at 2022-06-22 13:52:08.451446
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == ['ansible.posix']

# Generated at 2022-06-22 13:52:10.773921
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _CollectionSearch = CollectionSearch()
    _CollectionSearch._collections = _ensure_default_collection()
    assert _CollectionSearch._collections == ['ansible.builtin']

# Generated at 2022-06-22 13:52:23.046607
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.module_utils.connection as connection
    from ansible.module_utils.collection_loader import AnsibleCollectionLoader

    loader = AnsibleCollectionLoader()
    connection_loader = connection.ConnectionLoader()


# Generated at 2022-06-22 13:52:25.305581
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search._collections)


# Generated at 2022-06-22 13:52:40.622902
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    collections.collections = ['collection1', 'collection2']



# Generated at 2022-06-22 13:52:52.743585
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest
    unittest.TestCase().assertEqual(_ensure_default_collection(collection_list=None), ['ansible.legacy'])
    unittest.TestCase().assertEqual(_ensure_default_collection(collection_list=['ansible.legacy']), ['ansible.legacy'])
    unittest.TestCase().assertEqual(_ensure_default_collection(collection_list=['ansible.builtin']), ['ansible.builtin'])
    unittest.TestCase().assertEqual(_ensure_default_collection(collection_list=['ansible.builtin', 'ansible.legacy']), ['ansible.builtin'])

# Generated at 2022-06-22 13:52:56.293848
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

    # test that _collections DataAttribute is initialized correctly
    assert search._collections.name == 'collections'
    assert search._collections.isa == 'list'
    assert search._collections.listof == string_types
    assert search._collections.default == 'ansible.builtin'
    assert search._collections.always_post_validate
    assert search._collections.static


# Generated at 2022-06-22 13:52:58.841642
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ds = cs._load_collections('collections', None)
    #print(ds)



# Generated at 2022-06-22 13:53:01.572808
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    role = CollectionSearch()
    if role._collections == _ensure_default_collection():
        print("Role import test passed")
    else:
        print("Role import test failed")

# Generated at 2022-06-22 13:53:03.357351
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:53:05.467068
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default() == ['ansible.builtin']

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:53:09.620981
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task import Task
    t = Task()
    assert t._collections == None


# Generated at 2022-06-22 13:53:12.381316
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs._load_collections, type(cs._collections.post_validate))

# Generated at 2022-06-22 13:53:23.713995
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == ['ansible.builtin']
    assert obj._load_collections('_collections', ['test1']) == ['test1', 'ansible.builtin']
    assert obj._load_collections('_collections', []) == ['ansible.builtin']
    assert obj._load_collections('_collections', None) == ['ansible.builtin']
    assert obj.get_validated_value('collections', obj._collections, None, None) == ['ansible.builtin']
    assert obj.get_validated_value('collections', obj._collections, [], None) == []
    assert obj.get_validated_value('collections', obj._collections, ['test1'], None) == ['test1', 'ansible.builtin']
   

# Generated at 2022-06-22 13:53:53.127767
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    test_base = Base()

    test_base.post_validate(dict(), [])
    assert test_base._collections == ['ansible.builtin']

# Generated at 2022-06-22 13:53:57.643007
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default == ['ansible.builtin']
    assert collection_search._collections.listof == string_types
    assert collection_search._collections.priority == 100
    assert collection_search._collections.static == True

# Generated at 2022-06-22 13:54:02.596240
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    colsearch = CollectionSearch()
    assert issubclass(CollectionSearch, object)
    assert (colsearch._collections is None)
    assert colsearch._load_collections(None, None) is None
    colsearch._collections = ['ansible.builtin']
    assert colsearch._load_collections(None, None) is None

# Generated at 2022-06-22 13:54:08.363768
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test with no collection_list argument
    x = CollectionSearch()
    assert x._collections == _ensure_default_collection(collection_list=None)

    # Test with collection_list argument
    collection_list = ['test_collection']
    x = CollectionSearch(collection_list=collection_list)
    assert x._collections == _ensure_default_collection(collection_list=collection_list)

# Generated at 2022-06-22 13:54:09.249894
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    # CollectionSearch class should have the attribute _collections
    assert hasattr(obj,'_collections')

# Generated at 2022-06-22 13:54:10.276567
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections(None, None) == _ensure_default_collection()

# Generated at 2022-06-22 13:54:12.750728
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance._collections.default == _ensure_default_collection
    assert instance._collections.isa == 'list'
    assert instance._collections.listof == string_types
    assert instance._collections.priority == 100
    assert instance._collections.always_post_validate is True
    assert instance._collections.static is True


# Generated at 2022-06-22 13:54:20.534409
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an object
    test = CollectionSearch()
    assert test is not None

    # Check fields
    assert isinstance(test._collections, FieldAttribute)
    assert test._collections.name == 'collections'
    assert test._collections.isa == 'list'
    assert test._collections.listof == string_types
    assert test._collections.priority == 100
    assert test._collections._default_msg is None
    assert test._collections.default == _ensure_default_collection
    assert test._collections.always_post_validate is True
    assert test._collections.static is True

# Generated at 2022-06-22 13:54:22.112230
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible.builtin']

# Generated at 2022-06-22 13:54:22.651406
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

# Generated at 2022-06-22 13:55:18.321727
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == [None] # _ensure_default_collection() >>> collection_list is None
    assert collection_search._load_collections(1,1) == None

# Generated at 2022-06-22 13:55:21.225470
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

    # test default value of collection is None
    assert obj._collections is None

    # test default value after post validation
    obj.post_validate()
    assert obj.collections is None

# Generated at 2022-06-22 13:55:26.990089
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert isinstance(instance._collections, FieldAttribute)
    assert instance._collections.name == 'collections'
    assert instance._collections.isa == 'list'
    assert instance._collections.listof == string_types
    assert instance._collections.default == _ensure_default_collection
    assert instance._collections.always_post_validate == True
    assert instance._collections.static == True
    # assert instance._collections.post_validate(ds) == None
    # CollectionSearch._collections.load and CollectionSearch._collections.store are not implemented

# Generated at 2022-06-22 13:55:29.516326
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    colection_obj = CollectionSearch()
    ds = colection_obj._load_collections('collections', 'ds')
    print(ds)

# Generated at 2022-06-22 13:55:35.609225
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    assert col.get_validated_value('collections', col._collections, None, None) is None
    assert col.get_validated_value('collections', col._collections, [], None) == []
    assert col.get_validated_value('collections', col._collections, ['my_collection'], None) == ['my_collection', 'ansible.builtin']

# Generated at 2022-06-22 13:55:39.409686
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    fieldattribute = FieldAttribute()
    fields = dict()
    fieldattribute.assign_field(fields, {"isa": "list", "listof": string_types, "priority": 100, "default": _ensure_default_collection, "always_post_validate": True, "static": True}, 'collections')
    assert fields == CollectionSearch._collections

# Generated at 2022-06-22 13:55:40.580539
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-22 13:55:43.631566
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.__dict__['_collections'] == _ensure_default_collection()


# Generated at 2022-06-22 13:55:44.935136
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    a._load_collections('collections', [])

# Generated at 2022-06-22 13:55:47.878667
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Given
    collection_loader = CollectionSearch()

    # When
    collections = collection_loader._load_collections(None, 'test')

    # Then
    assert collections == ['test']

# Generated at 2022-06-22 13:57:46.121339
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a=CollectionSearch()
    print(a.collections)

# Generated at 2022-06-22 13:57:50.038947
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    expected_value = 'ansible.builtin'
    collection_search = CollectionSearch()
    assert collection_search._collections.default()[0] == expected_value

# Generated at 2022-06-22 13:57:52.125416
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:57:52.784260
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-22 13:57:53.313326
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(CollectionSearch())

# Generated at 2022-06-22 13:57:54.703050
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections is not None

# Generated at 2022-06-22 13:57:56.233918
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:57:58.301116
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        CollectionSearch()
        assert True
    except Exception as e:
        assert False
# Unit test result: Pass


# Generated at 2022-06-22 13:58:01.778806
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection
    assert cs._collections.always_post_validate == True
    assert cs._collections.static == True

# Generated at 2022-06-22 13:58:03.498327
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None