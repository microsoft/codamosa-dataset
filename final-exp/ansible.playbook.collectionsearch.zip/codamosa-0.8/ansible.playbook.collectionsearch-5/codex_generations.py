

# Generated at 2022-06-22 13:51:13.057857
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance._collections is not None
    assert instance._collections.default == _ensure_default_collection
    assert instance._collections.always_post_validate
    assert instance._collections.static
    assert instance._load_collections is not None


# Generated at 2022-06-22 13:51:15.578919
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:27.388866
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collections = ['ansible.posix']
    test_object = CollectionSearch(collections=test_collections)

    # If a user specifies a collection, ensure default is not added
    assert sorted(test_collections) == sorted(test_object.collections)

    # If a user doesn't specify a collection, ensure default is added
    test_object = CollectionSearch()
    default_collection = AnsibleCollectionConfig.default_collection
    assert sorted(test_object.collections) == sorted(['ansible.legacy', default_collection])

    # When user passes in an empty collection, ensure default is added
    test_collections = []
    test_object = CollectionSearch(collections=test_collections)
    assert sorted(test_object.collections) == sorted(['ansible.legacy', default_collection])

# Generated at 2022-06-22 13:51:31.028733
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ## Unit Test for the Construction of the class CollectionSearch

    # Check the field '_collections'
    cs = CollectionSearch()
    assert isinstance(cs._collections, FieldAttribute)
    assert cs._collections.isa == 'list'

# Generated at 2022-06-22 13:51:39.262692
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Case 1: No collection_list is given
    obj_col_list_none = CollectionSearch()
    assert obj_col_list_none.collections == 'None'

    # Case 2: Default Collection is given
    obj_default_collection = CollectionSearch(collections=['ansible.builtin'])
    assert obj_default_collection.collections == 'ansible.builtin'
    obj_default_collection = CollectionSearch(collections=['ansible.builtin', 'test_collection'])
    assert obj_default_collection.collections == 'ansible.builtin, test_collection'

    # Case 3: Multiple collections are given
    obj_multiple_collections = CollectionSearch(collections=['test_collection1', 'test_collection2'])

# Generated at 2022-06-22 13:51:51.444856
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("\nInside CollectionSearch:test_CollectionSearch()")

    # No args passed
    obj = CollectionSearch()
    print('obj - ', obj)
    print('obj._collections - ', obj._collections)
    print('obj._component_loader - ', obj._component_loader)
    print('obj._collection_loader - ', obj._collection_loader)

    # Only collections passed
    obj = CollectionSearch(collections="test")
    print('obj - ', obj)
    print('obj._collections - ', obj._collections)
    print('obj._component_loader - ', obj._component_loader)
    print('obj._collection_loader - ', obj._collection_loader)

    # All args passed
    obj = CollectionSearch(collections="test", component_loader="test",
                           collection_loader="test")

# Generated at 2022-06-22 13:51:58.978989
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None
    assert cs._collections_role_dirs is None
    assert cs._collections_module_dirs is None
    assert cs._collections_filter_plugins is None
    assert cs._collections_lookup_plugins is None
    assert cs._collections_vars_plugins is None
    assert cs._collections_shell_plugins is None
    assert cs._collections_terminal_plugins is None
    assert cs._collections_doc_fragments is None

# Generated at 2022-06-22 13:52:00.740213
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) is None

# Generated at 2022-06-22 13:52:02.024587
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']
    assert cs._collections.default() == cs.collections

# Generated at 2022-06-22 13:52:03.572241
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_test_var = CollectionSearch()
    my_test_var._collections()

# Generated at 2022-06-22 13:52:12.061662
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_list = CollectionSearch()
    assert collection_list._collections == _ensure_default_collection

# Generated at 2022-06-22 13:52:24.198527
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create class CollectionSearch
    collection_search = CollectionSearch()

    # Create a fake attribute 'collections' from class FieldAttribute
    attr_collections = 'collections'
    attr_collections_type = 'list'
    attr_collections_listof = 'string_type'
    attr_collections_priority = 100
    attr_collections_default = ['ansible.builtin', 'ansible.legacy']
    attr_collections_always_post_validate = True
    attr_collections_static = True

# Generated at 2022-06-22 13:52:26.173245
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test the constructor of CollectionSearch
    expected = CollectionSearch()
    print(expected.__dict__)
    assert expected.collections is None


# Generated at 2022-06-22 13:52:31.972461
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test with default parameter values
    col_search = CollectionSearch()
    assert col_search.collections == _ensure_default_collection()

    # Test with explicit collections parameter
    collections = ['foo', 'bar']
    col_search = CollectionSearch(collections=collections)
    assert col_search.collections == _ensure_default_collection(collections)

# Generated at 2022-06-22 13:52:33.546864
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs._collections)



# Generated at 2022-06-22 13:52:38.763612
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections('collections', [
        'example.awesome',
        'example.dangerous',
    ]) == [
        'example.awesome',
        'example.dangerous',
        'ansible.builtin',
        'ansible.legacy',
    ]



# Generated at 2022-06-22 13:52:40.284214
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
        obj = CollectionSearch()
        print(obj._collections)

# Generated at 2022-06-22 13:52:44.917018
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an instance of class CollectionSearch
    collection_search = CollectionSearch()
    # Get the default value of constructor
    collection_list = collection_search._load_collections(None, _ensure_default_collection())
    assert collection_list == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:52:46.970128
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search._load_collections()

# Generated at 2022-06-22 13:52:48.618422
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-22 13:53:05.972896
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) == ['ansible.builtin', 'ansible.legacy']
    assert cs._load_collections(None, []) == ['ansible.builtin', 'ansible.legacy']
    assert cs._load_collections(None, ['my.collection']) == ['my.collection', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:53:08.402525
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    This is the unit test for CollectionSearch class
    """
    cs = CollectionSearch()

    # TODO: write some test case to prove the collection_list

# Generated at 2022-06-22 13:53:10.707635
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections[0] == "ansible.builtin"

# Generated at 2022-06-22 13:53:13.403153
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None



# Generated at 2022-06-22 13:53:15.248390
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Host(CollectionSearch):
        pass
    assert Host()._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:53:15.845073
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-22 13:53:21.079517
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.context import CLIARGS

    # Test when CLIARGS.collections is None
    CLIARGS.collections = None
    cs = CollectionSearch()
    assert cs.collections == []

    # Test when CLIARGS.collections is not None
    CLIARGS.collections = ['test1', 'test2']
    cs = CollectionSearch()
    assert cs.collections == ['test1', 'test2']

test_CollectionSearch()

# Generated at 2022-06-22 13:53:21.781662
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-22 13:53:24.378671
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Checking the contructor of CollectionSearch class
    assert isinstance(CollectionSearch, object) is True

# Generated at 2022-06-22 13:53:26.333519
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:53:55.282768
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        x = CollectionSearch()
    except Exception as e:
        print("Error: %s" % e)
        assert False

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-22 13:53:56.664932
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t._collections is not None

# Generated at 2022-06-22 13:53:59.975916
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """This test case ensures that the constructor of the class CollectionSearch
    works as expected.
    """
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:54:09.234910
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(_ensure_default_collection(), list)
    assert 'ansible.builtin' in _ensure_default_collection()
    assert 'ansible.legacy' in _ensure_default_collection()
    assert len(_ensure_default_collection()) == 2
    assert isinstance(_ensure_default_collection(['ns.collection', 'ns.collection2']), list)
    assert 'ns.collection' in _ensure_default_collection(['ns.collection', 'ns.collection2'])
    assert 'ns.collection2' in _ensure_default_collection(['ns.collection', 'ns.collection2'])
    assert 'ansible.builtin' not in _ensure_default_collection(['ns.collection', 'ns.collection2'])
    assert 'ansible.legacy' in _ensure_

# Generated at 2022-06-22 13:54:18.943335
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    # testing with None
    assert cs._load_collections(None, None) is None

    # testing with a list
    csl = ['payal.collection', 'demo.collection']
    assert cs._load_collections(None, csl) == csl
    # testing with a str
    css = 'demo.collection'
    assert cs._load_collections(None, css) == [css]

    # ensure ansible.builtin is always in the list
    ab = 'ansible.builtin'
    assert _ensure_default_collection([css])[0] == ab
    assert _ensure_default_collection(['abc.builtin'])[0] == ab

# Generated at 2022-06-22 13:54:19.875723
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()


# Generated at 2022-06-22 13:54:27.716632
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = {}
    host = Host("localhost", port=22)
    host.set_variable("ansible_password", "pass123")
    group = Group("my_group")
    group.add_host(host)

# Generated at 2022-06-22 13:54:28.202051
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-22 13:54:34.677517
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest.mock as mock
    display_mock = mock.Mock()
    display_mock.error = mock.Mock()
    display_mock.warning = mock.Mock()
    display_mock.deprecated = mock.Mock()
    display_mock.deprecated_args = mock.Mock()
    setattr(display, "error", display_mock.error)
    setattr(display, "warning", display_mock.warning)
    setattr(display, "deprecated", display_mock.deprecated)
    setattr(display, "deprecated_args", display_mock.deprecated_args)
    collection_search = CollectionSearch()
    test_base_attr = {'collections': "collection1"}

# Generated at 2022-06-22 13:54:39.966557
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class Plugin(CollectionSearch):
        def __init__(self):
            super(Plugin, self).__init__()
            self._collections = ['test_collection']

    # initialize plugin with fields populated
    plugin = Plugin()

    # get the plugin name
    plugin_name = plugin.name

    # test the constructor(__init__ method)
    assert plugin_name == 'Plugin'

# Generated at 2022-06-22 13:55:39.611676
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class MyClass(object):
        def __init__(self, collections=None):
            self.collections = collections

    # default
    c = CollectionSearch()
    assert c._ensure_default_collection() == ['ansible.builtin']

    # empty
    c = CollectionSearch()
    assert c._ensure_default_collection([]) == ['ansible.builtin']

    # role task
    c = CollectionSearch()
    assert c._ensure_default_collection(['ansible.builtin']) == ['ansible.builtin']

    # default collection
    c = CollectionSearch()
    default_collection = AnsibleCollectionConfig.default_collection
    if default_collection:
        assert c._ensure_default_collection([default_collection]) == [default_collection]

    # different collection
    c = CollectionSearch()


# Generated at 2022-06-22 13:55:41.837653
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections is not None

# Generated at 2022-06-22 13:55:43.424224
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    m = CollectionSearch()
    assert m._collections is not None
    assert m.collections != m._collections

# Generated at 2022-06-22 13:55:52.176592
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import sys
    # Check the module has been initialized without errors
    from ansible.errors import AnsibleError
    class MyObject(CollectionSearch):
        pass
    try:
        MyObject()
    except (AnsibleError, AttributeError) as e:
        sys.exit("Initialization of class CollectionSearch failed: %s" % e)

    # Check that attributes are initialized properly
    assert MyObject._collections.name == "collections"
    assert MyObject._collections.isa == "list"
    assert MyObject._collections.default == "__ansible_collections_ensure_default_collection_default"


# Generated at 2022-06-22 13:55:54.418460
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # creates class object
    obj = CollectionSearch()

    # executes method and checks it against expected result
    assert obj._load_collections('collections', ['collection1']) == ['collection1']

# Generated at 2022-06-22 13:55:56.293832
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # call _load_collections
    collection_search._load_collections(None, None)

# Generated at 2022-06-22 13:56:03.141852
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #def __init__(self):
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    assert cs._load_collections('collections', None) == [_ensure_default_collection()]
    print('test_CollectionSearch completed successfully')

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-22 13:56:13.604637
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def test_collections_post_validate(self, ds):
        # First, the collections to use must be specified
        if not ds:
            raise ValueError('collections required')

        # Next, we must have a search path, and it must only contain strings
        ds = self._collections.post_validate(self, ds, [])
        if not ds:
            raise ValueError('Invalid collection specification')
        if not isinstance(ds, list):
            raise ValueError('collections must be a list')
        if any([not isinstance(x, string_types) for x in ds]):
            raise ValueError('collections must only contain strings')
        return ds

    cs = CollectionSearch()
    cs._collections.post_validate = test_collections_post_validate

# Generated at 2022-06-22 13:56:16.527151
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = []
    _ensure_default_collection(collection_list=ds)
    assert ds

# Generated at 2022-06-22 13:56:22.074768
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """This function performs unit test for constructor of class CollectionSearch."""
    col_search = CollectionSearch()
    assert col_search._collections is not None
    assert col_search._collections is not []
    _ensure_default_collection(collection_list=col_search._collections)
    assert col_search._collections is not []


# Generated at 2022-06-22 13:57:23.553788
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert s.collections is not None
    assert len(s.collections) == 2
    assert s.collections[0] == 'ansible_collections.ansible.builtin'
    assert s.collections[1] == 'ansible.legacy'
    s.collections = ['a.b.c.d', 'e.f.g.h']
    assert s.collections is not None
    assert len(s.collections) == 2
    assert s.collections[0] == 'a.b.c.d'
    assert s.collections[1] == 'e.f.g.h'
    s.collections = []
    assert s.collections is None
    s.collections = None
    assert s.collections is None

# Generated at 2022-06-22 13:57:29.752979
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute_loader import AttributeLoader
    attr_loader = AttributeLoader()
    collections = CollectionSearch()

    ds = {u'collections': [u'ansible.legacy']}
    attr_loader._populate(ds, collections, 'collections')
    collections._initialize_vars()
    assert collections.collections == [u'ansible.legacy']

    ds = {u'collections': [u'ansible.legacy']}
    attr_loader._populate(ds, collections, 'collections')
    collections._initialize_vars()
    assert collections.collections == [u'ansible.legacy']

# Generated at 2022-06-22 13:57:31.409606
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    expected = AnsibleCollectionConfig.default_collection
    assert collection_list == expected

# Generated at 2022-06-22 13:57:33.934697
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    testCollectionSearchObject = CollectionSearch()
    assert testCollectionSearchObject
    assert testCollectionSearchObject.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:57:42.316504
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def dummy1(attr, ds):
        return None
    def dummy2(attr, ds):
        return None
    def dummy3(attr, ds):
        return None
    test_obj = CollectionSearch()
    test_obj._load_collections = dummy1
    test_obj._collections = dummy2
    test_obj.get_validated_value = dummy3
    assert test_obj._load_collections is not None
    assert test_obj._collections is not None
    assert test_obj.get_validated_value is not None

# Generated at 2022-06-22 13:57:43.982818
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == ['ansible_collections.communal.general']

# Generated at 2022-06-22 13:57:45.506205
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch._collections is not None

# Generated at 2022-06-22 13:57:48.819473
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections == ['ansible.builtin,ansible.legacy']

# Generated at 2022-06-22 13:57:52.592039
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearchTest(CollectionSearch):
        def __init__(self):
            super(CollectionSearchTest, self).__init__()
    cst = CollectionSearchTest()
    assert cst._load_collections(None, None) is None

# Generated at 2022-06-22 13:57:54.135794
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ["ansible.builtin"]

# Generated at 2022-06-22 13:59:48.000943
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible_collections.testns.testcoll.plugins.module_utils.common import CollectionSearch
    from ansible.module_utils.six import string_types
    from ansible.playbook.attribute import FieldAttribute

    basic_data = {'collections': None}
    cSearch = CollectionSearch()
    cSearch._load_collections( 'collections', basic_data)
    assert isinstance(cSearch.collections, list)
    assert isinstance(cSearch.collections[0], string_types)

# Generated at 2022-06-22 13:59:49.340032
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    collections = cs._load_collections('collections', ['ansible.builtin'])
    assert collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:59:52.100561
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Verify that the default value is set appropriately
    assert cs._collections.default == _ensure_default_collection()

# Generated at 2022-06-22 13:59:59.268132
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_search = CollectionSearch()
    assert isinstance(test_search, CollectionSearch)
    assert isinstance(test_search._collections, FieldAttribute)
    """
    No value passed in
    """
    assert test_search._load_collections('collections', None) == None

    """
    Value passed in is a str
    """
    assert test_search._load_collections('collections', 'ansible.builtin') == ['ansible.builtin']

    """
    Value passed in is an array
    """
    assert test_search._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-22 14:00:02.953021
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collectionsearch = CollectionSearch()
    test_collection_list = test_collectionsearch._load_collections('collections', [['ansible.builtin', 'ansible.legacy']])
    assert test_collection_list == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 14:00:05.372626
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test for constructor of CollectionSearch
    class Test(CollectionSearch):
        pass
    assert Test.collections is not None

# Generated at 2022-06-22 14:00:15.599667
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #case1:
    #_collections=[AnsibleCollectionConfig.default_collection, 'ansible.builtin', 'ansible.legacy']
    collection_search = CollectionSearch()
    assert collection_search._load_collections('collections', None) == ['ansible.builtin', AnsibleCollectionConfig.default_collection, 'ansible.legacy']


    #case2:
    #_collections=[AnsibleCollectionConfig.default_collection, 'ansible.legacy']
    collection_search = CollectionSearch()
    assert collection_search._load_collections('collections', [AnsibleCollectionConfig.default_collection, 'ansible.legacy']) == [AnsibleCollectionConfig.default_collection, 'ansible.legacy']


    #case3:
    #_collections=[AnsibleCollectionConfig.

# Generated at 2022-06-22 14:00:17.537675
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None

# Generated at 2022-06-22 14:00:18.870397
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test for constructor
    test_obj = CollectionSearch()
    assert isinstance(test_obj, CollectionSearch)  # test for constructor

# Generated at 2022-06-22 14:00:21.087506
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t._collections == _ensure_default_collection()
    assert t._load_collections(None, None) == _ensure_default_collection()