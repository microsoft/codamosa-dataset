

# Generated at 2022-06-22 13:51:12.142587
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    This method is used for Unit-testing of class CollectionSearch
    No input is passed as this is just for testing the constructor
    """
    a = CollectionSearch()
    assert a._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:17.741931
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display_object = Display()
    display_object.display("Unit test for class CollectionSearch")

    test_object = CollectionSearch()

    # Print the values for a field in the class using the __dict__
    print("Value of collections in CollectionSearch:")
    print(test_object.__dict__['collections'])

    return

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-22 13:51:18.449390
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  cs = CollectionSearch()

# Generated at 2022-06-22 13:51:29.273596
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert cs._collections == _ensure_default_collection()
    assert cs._collections is not _ensure_default_collection()
    assert cs._collections is not _ensure_default_collection(collection_list=['a.b'])
    assert cs._collections == _ensure_default_collection()

    assert cs.get_validated_value('collections', cs._collections, ['a.b'], None) == ['a.b']
    assert cs.get_validated_value('collections', cs._collections, None, None) is None

    # Check that the default collection is included
    AnsibleCollectionConfig.default_collection = 'default_collection.x'
    cs = CollectionSearch()

    assert cs._collections == _ensure_default_collection()
    assert cs._col

# Generated at 2022-06-22 13:51:29.869316
# Unit test for constructor of class CollectionSearch

# Generated at 2022-06-22 13:51:30.487694
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-22 13:51:34.148550
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == None
    cs.collections = ["my.collection"]
    assert cs.collections == ['my.collection', 'ansible.builtin'] or cs.collections == ['my.collection', 'ansible.legacy']

# Generated at 2022-06-22 13:51:34.504898
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()

# Generated at 2022-06-22 13:51:37.544378
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_class = CollectionSearch()
    test_class.collections = ['collection']
    assert test_class.collections == ['collection']
    assert test_class._collections_validated_value == ['collection']
    assert test_class._collections_is_validated is True

# Generated at 2022-06-22 13:51:42.355945
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    instance = CollectionSearch()

    # instance default
    assert instance.collections_list == ['ansible.builtin']

    # instance with a value
    instance = CollectionSearch(collections_list=['test.collection'])
    assert instance.collections_list == ['test.collection', 'ansible.builtin']

# Generated at 2022-06-22 13:51:55.782155
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test __init__ method of class CollectionSearch when used as a superclass for HostVars
    # HostVars does not have any key-value attributes. So, it does not add any key-value attribute to
    # CollectionSearch. __init__ method of class CollectionSearch is defined in superclass FieldAttribute.
    class HostVars(CollectionSearch):
        pass
    obj = HostVars()
    assert obj.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:52:08.124843
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    class MyPlay(CollectionSearch, Play):
        pass

    my_play = MyPlay('test')
    # Test empty collection list
    assert my_play._collections is None

    # Test non-empty collection list
    my_play = MyPlay('test', collections=['something'])
    assert isinstance(my_play._collections, list)
    assert my_play._collections == ['something']

    # Test constructor with a list of collection names

# Generated at 2022-06-22 13:52:09.895548
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# unit test for method load_collections of class CollectionSearch

# Generated at 2022-06-22 13:52:11.067530
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert 'ansible.legacy' in search._collections

# Generated at 2022-06-22 13:52:12.020850
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-22 13:52:13.040975
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections

# Generated at 2022-06-22 13:52:17.444107
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # First, create an object by instantiating the class.
    cs = CollectionSearch()
    # All attributes with a priority of 100 will be initialized.
    # We can then use the object to access these attributes.
    assert cs.collections == ['ansible_collections.nokia.sros']

# Generated at 2022-06-22 13:52:26.949327
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    default_collection = AnsibleCollectionConfig.default_collection
    collection_search = CollectionSearch()

    # Case 1:
    # Test case when default_collection is not populated
    AnsibleCollectionConfig.default_collection = None
    assert collection_search._load_collections(None, None) is None

    # Case 2:
    # Test case when 'collections' param is populaed with a value and default
    # collection is populated
    AnsibleCollectionConfig.default_collection = default_collection
    assert collection_search._load_collections(None, 'test.collection') == ['test.collection', 'ansible.legacy']

# Generated at 2022-06-22 13:52:31.484012
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()
    assert collection_search._load_collections is not None
    assert isinstance(collection_search, Block)

# Generated at 2022-06-22 13:52:33.900144
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    role = CollectionSearch()
    assert role._collections == _ensure_default_collection()
    assert role.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:52:48.937602
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert isinstance(test_obj, CollectionSearch)


# Generated at 2022-06-22 13:52:52.403437
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.post_validate(loader=None, tmp=None, parent_ds=None)
    assert len(collection_search.collections) > 0

# Generated at 2022-06-22 13:52:55.756707
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    test_collection_search_obj = CollectionSearch()

    assert test_collection_search_obj._collections.default == test_collection_search_obj._ensure_default_collection()

# Generated at 2022-06-22 13:52:58.896714
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._collections.value = ['ansible.builtin']
    assert cs._collections.value == ['ansible.builtin']

# Generated at 2022-06-22 13:53:03.677346
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    tester = CollectionSearch()
    print("Tester we got from CollectionSearch: " + str(tester))
    print("Is Tester we got from CollectionSearch an instance of CollectionSearch: " + str(isinstance(tester, CollectionSearch)))
    ds = ["ansible.posix"]
    print("ds we got from CollectionSearch tester: " + str(tester._load_collections("collections", ds)))
    print("Attribute collections in CollectionSearch: " + str(dir(CollectionSearch._collections)))


if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-22 13:53:05.981364
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert len(obj._collections) == 1


# Generated at 2022-06-22 13:53:15.149153
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_obj = CollectionSearch()
    assert type(collection_obj._collections) is FieldAttribute
    display.deprecated("Deprecated collection paths will be removed in version 2.10. "
                       "See https://docs.ansible.com/ansible/latest/reference_appendices/deprecated_features.html#deprecated-collection-paths", version="2.9")
    assert collection_obj._collections.default() == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:53:18.247885
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    '''
    Unit test for constructor of class CollectionSearch
    '''
    test_collection_search = CollectionSearch()
    assert test_collection_search is not None
    assert test_collection_search._collections is not None

# Generated at 2022-06-22 13:53:19.504089
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections
    assert c._load_collections

# Generated at 2022-06-22 13:53:21.729450
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    loader = CollectionSearch()
    assert loader._collections() == []  # default value

# Generated at 2022-06-22 13:53:50.835536
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_list = []
    assert CollectionSearch._ensure_default_collection(collection_list) == ['ansible.builtin']

# Generated at 2022-06-22 13:53:52.426749
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:54:02.638064
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    names = CollectionSearch()
    assert (names.collections == ['ansible.legacy'])

    names = CollectionSearch()
    names.collections = None
    assert (names.collections == ['ansible.legacy'])

    names = CollectionSearch()
    names.collections = []
    assert (names.collections == ['ansible.legacy'])

    names = CollectionSearch()
    names.collections = ["ansible.legacy"]
    assert (names.collections == ["ansible.legacy"])

    names = CollectionSearch()
    names.collections = ["ansible.legacy", "test"]
    assert (names.collections == ["test", "ansible.legacy"])

# Generated at 2022-06-22 13:54:06.910021
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    if not isinstance(obj, CollectionSearch):
        raise AssertionError("Expected an instance of CollectionSearch class")
    if hasattr(obj, "collections"):
        raise AssertionError("Expected an instance of CollectionSearch class")



# Generated at 2022-06-22 13:54:08.279856
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()
    assert isinstance(coll, CollectionSearch)


# Generated at 2022-06-22 13:54:17.937773
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    b = a._collections
    assert b == ['ansible.builtin', 'ansible.legacy']
    a._collections = 'ansible.builtin'
    assert a._collections == 'ansible.builtin'
    a._collections = ['foo', 'bar']
    assert a._collections == ['foo', 'bar', 'ansible.builtin', 'ansible.legacy']
    a._collections = ['foo', 'bar', 'ansible.builtin', 'ansible.legacy']
    assert a._collections == ['foo', 'bar', 'ansible.builtin', 'ansible.legacy']
    a._collections = ['foo', 'bar', 'ansible']

# Generated at 2022-06-22 13:54:21.017807
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()
    assert coll._collections.name == 'collections'
    assert coll._collections.default == _ensure_default_collection()
    assert coll._load_collections('collections', None) is None

# Generated at 2022-06-22 13:54:26.369106
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({
        "test.yml": """
        collections:
        - collection1
        - collection2
        - collection3
        """,
    })

    cs1 = CollectionSearch(loader=loader, file_name="test.yml")
    cs2 = CollectionSearch(loader=loader, file_name="test.yml", collections=["collection4", "collection5"])

    assert True, "CollectionSearch constructor is successful"

# Generated at 2022-06-22 13:54:28.685145
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.post_validate()
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:54:32.292437
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search._collections = ['ansible.builtin', 'ansible.legacy', 'astron.test']

    result = collection_search._load_collections(None, None)
    assert result == ['ansible.builtin', 'ansible.legacy', 'astron.test']

# Generated at 2022-06-22 13:55:02.380390
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test the constructor
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)

# Generated at 2022-06-22 13:55:04.096218
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    instance._load_collections("collections",[])

# Generated at 2022-06-22 13:55:06.384185
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Unit test for constructor of class CollectionSearch"""
    collection_search = CollectionSearch()
    collection_search.post_validate()

# Generated at 2022-06-22 13:55:08.292607
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default == _ensure_default_collection

# Generated at 2022-06-22 13:55:09.550673
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_class = CollectionSearch()
    assert test_class

# Generated at 2022-06-22 13:55:11.678540
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """ This is a simple test for the constructor of class CollectionSearch
    """
    assert (CollectionSearch().__class__.__name__ == 'CollectionSearch')

# Generated at 2022-06-22 13:55:12.153561
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-22 13:55:14.490097
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections is None
    assert obj.collections is not True

# Generated at 2022-06-22 13:55:18.361880
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections(collection_search._collections, None) == None
    assert collection_search._load_collections(collection_search._collections, []) == ['ansible.legacy']

# Generated at 2022-06-22 13:55:21.701333
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    ds = c._load_collections(None, 'ansible.builtin')
    print(ds)
    assert 'ansible.builtin' in ds or 'ansible.legacy' in ds

# Generated at 2022-06-22 13:56:16.971813
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:56:21.265140
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert collection_search._collections == collection_search.collections
    assert collection_search.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:56:23.413351
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:56:27.730820
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(object):
        __metaclass__ = CollectionSearch
    testObject = TestCollectionSearch()
    print("Printing dir: ",dir(testObject))
    print("Printing type: ",type(testObject))
    print("Printing testObject: ",testObject)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:56:31.131708
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Setup
    ansible_collections = ['ansible.legacy']

    # Test
    collection_search = CollectionSearch()
    collection_search.collections = ansible_collections

    # Assert
    assert ansible_collections == collection_search._collections
    assert ansible_collections == collection_search.collections

# Generated at 2022-06-22 13:56:33.886369
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    c = CollectionSearch()
    a = Play(play_context=PlayContext())
    a.load()
    assert c._load_collections(a.collections, []) == _ensure_default_collection()

# Generated at 2022-06-22 13:56:36.681789
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:56:40.834620
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    x = cs._load_collections("collections", [])
    assert x is None
    x = cs._load_collections("collections", ['foo.bar'])
    assert x == ['ansible.builtin', 'foo.bar']



# Generated at 2022-06-22 13:56:43.364212
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']
    assert cs._collections is not None

# Generated at 2022-06-22 13:56:45.550726
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    default_list = _ensure_default_collection()
    assert test._collections == default_list

# Generated at 2022-06-22 13:58:37.272804
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    result = search._load_collections(None, None)
    assert result is not None

# Generated at 2022-06-22 13:58:40.428269
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible.legacy']


# Generated at 2022-06-22 13:58:43.591864
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = dict()
    ds['collections'] = list()
    ds['collections'].append('testing')

    t = CollectionSearch()
    t._collections = ds['collections']
    t.post_validate()

# Generated at 2022-06-22 13:58:48.062161
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _CollectionSearch = CollectionSearch()

    ds = ['ansible.builtin', 'ansible.legacy', 'rnelson0.systemd']
    # ds = None
    # ds  # this evaluates to [] when used in _load_collections which avoids the _ensure_default_collection call
    # Call the constructor and make sure it returns a list of the collections
    assert _CollectionSearch._load_collections('_collections', ds) == ['ansible.builtin', 'ansible.legacy', 'rnelson0.systemd']

# Generated at 2022-06-22 13:58:50.509280
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    result = cs.get_validated_value("collections", cs._collections, None, None)
    assert result == _ensure_default_collection()

# Generated at 2022-06-22 13:59:01.623343
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    import ansible.utils.collection_loader
    with pytest.raises(AttributeError) as excinfo:
        c = CollectionSearch()
        c.collections = None
    assert 'may not be None' in str(excinfo.value)
    with pytest.raises(AttributeError) as excinfo:
        c = CollectionSearch()
        c.collections = [None]
    assert 'may not contain None' in str(excinfo.value)
    with pytest.raises(AttributeError) as excinfo:
        c = CollectionSearch()
        c.collections = [1]
    assert 'contains a non-string value' in str(excinfo.value)
    with pytest.raises(AttributeError) as excinfo:
        c = CollectionSearch

# Generated at 2022-06-22 13:59:04.435294
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test(CollectionSearch):
        pass
    test_objects = Test()
    print(test_objects._load_collections("collections", ["ansible.builtin", "ansible.posix", "ansible.legacy"]))

# test_CollectionSearch()

# Generated at 2022-06-22 13:59:05.463573
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:59:07.889034
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pdb; pdb.set_trace()
    ds = CollectionSearch()

# Generated at 2022-06-22 13:59:09.215097
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch._collections.default, type(list()))