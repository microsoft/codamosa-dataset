

# Generated at 2022-06-22 13:51:08.481663
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	cs = CollectionSearch()
	assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:51:14.143418
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test no collections
    collections = CollectionSearch()
    assert collections._collections == _ensure_default_collection()

    # Test with collections
    collections = CollectionSearch(collections=['collection1', 'collection2'])
    assert collections._collections == ['collection1', 'collection2', 'ansible.legacy']

# Generated at 2022-06-22 13:51:26.752008
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import json
    from ansible.init import collection_loader
    from ansible.collections import CollectionsManager
    from ansible.plugins.loader import fragment_loader

    # collect plugins
    fragment_loader.add_directory(collection_loader, '/test')
    fragment_loader.scan_paths()

    class TestCollectionSearch(CollectionSearch):
        pass

    test = TestCollectionSearch()


# Generated at 2022-06-22 13:51:27.643505
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch() is not None

# Generated at 2022-06-22 13:51:29.272861
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None

# Generated at 2022-06-22 13:51:31.476771
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections == [AnsibleCollectionConfig.default_collection] or search._collections == None

# Generated at 2022-06-22 13:51:34.669048
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        task = CollectionSearch()
        print("test_CollectionSearch success")
    except:
        print("test_CollectionSearch failed")


if __name__ == "__main__":
    # Unit test
    test_CollectionSearch()

# Generated at 2022-06-22 13:51:38.213126
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search.collections, list)
    assert len(collection_search.collections) == 1
    assert collection_search.collections[0] == 'ansible.builtin'



# Generated at 2022-06-22 13:51:44.793390
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)
    assert obj._collections.listof is string_types
    assert obj._collections.isa is list
    assert obj._collections.default is _ensure_default_collection
    assert obj._collections.always_post_validate is True
    assert obj._collections.static is True
    assert obj._collections.priority is 100


# Generated at 2022-06-22 13:51:47.249545
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    collection._collections = _ensure_default_collection()
    assert collection._load_collections(collection._collections, None)

# Generated at 2022-06-22 13:51:54.011281
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # When no collections are specified, a warning is written to stdout
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._collections == _ensure_default_collection(None)

# Generated at 2022-06-22 13:52:06.710314
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include.static import TaskInclude
    from ansible.playbook.role.static import Role
    from ansible.playbook.role_include.static import RoleInclude

    cs = CollectionSearch()

    for attr in ['collections', 'name']:
        assert attr in cs._attributes

    assert isinstance(cs.collections, list)
    assert isinstance(cs.name, string_types)
    assert cs.name == ''

    # this shouldn't have a default value; the default should have been applied
    # when the default was set up by the field attribute constructor
    assert cs.collections == []

    # check that the default collection is then set in the list
    cs = CollectionSearch(collections=['my.collection', 'my.other.collection'])

# Generated at 2022-06-22 13:52:08.848254
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()

    assert collection_search._collections == ['ansible.builtin']

# Generated at 2022-06-22 13:52:11.351484
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    default_collection = AnsibleCollectionConfig.default_collection
    collection_search = CollectionSearch()
    collections = collection_search._load_collections(None, None)
    assert collections[0] == default_collection

# Generated at 2022-06-22 13:52:14.849907
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == ['ansible.legacy'] or CollectionSearch()._collections == ['ansible.builtin']

# Unit test of default_collection

# Generated at 2022-06-22 13:52:23.879005
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Test normal case
    col_srch_obj_1 = CollectionSearch()
    col_srch_obj_1.collections = ['col_1', 'col_2', 'col_3']

    #Test default case
    col_srch_obj_2 = CollectionSearch()

    # Test duplicate
    col_srch_obj_3 = CollectionSearch()
    col_srch_obj_3.collections = ['col_1', 'col_2', 'col_3']
    col_srch_obj_3.collections = ['col_1', 'col_2', 'col_3']

# Generated at 2022-06-22 13:52:25.661016
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections._value is None

# Generated at 2022-06-22 13:52:26.321428
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-22 13:52:28.127827
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()


# Generated at 2022-06-22 13:52:29.270835
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs  = CollectionSearch()
    assert cs

# Generated at 2022-06-22 13:52:44.663534
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.plugins.loader import collection_loader
    from ansible.plugins.task import TaskBase
    from ansible.inventory.host import Host

    collection_search = CollectionSearch()
    collection_search._collections = ['foo.bar']

    collection_loader.set_collection_paths(['foo.bar'])
    task = TaskBase()
    host = Host('localhost')
    assert collection_search._load_collections(
        'collections', task.load(host=host, task=task)) == ['foo.bar', 'ansible.legacy']

# Generated at 2022-06-22 13:52:46.074968
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_obj = CollectionSearch()

# Generated at 2022-06-22 13:52:48.759900
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collectionSearch = CollectionSearch()
    except:
        assert False, "Fail to construct class CollectionSearch"


# Generated at 2022-06-22 13:52:54.069725
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_obj = CollectionSearch()
    collection_search_obj_collections = collection_search_obj._collections
    test_collections = ['ansible.builtin', 'ansible_ansible_builtin_mazer_collection']
    assert test_collections == collection_search_obj_collections


# Generated at 2022-06-22 13:52:58.452388
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == None
    assert cs.collections == None
    cs.collections = ['foo.bar']
    assert cs._collections == ['foo.bar']
    assert cs.collections == ['foo.bar']

# Generated at 2022-06-22 13:53:00.839164
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_search = CollectionSearch()

    assert test_collection_search.collections == ['ansible_collections.netapp.netapp_eseries']

# Generated at 2022-06-22 13:53:01.815487
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass



# Generated at 2022-06-22 13:53:02.447330
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    temp = CollectionSearch()

# Generated at 2022-06-22 13:53:03.701883
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:53:04.903044
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

    assert obj is not None

# Generated at 2022-06-22 13:53:18.382218
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # A valid list
    assert isinstance(CollectionSearch._collections, tuple)

    # A list of integers
    assert _ensure_default_collection(collection_list=[1, 2]) == [1, 2]

    # A list of integers and strings
    assert _ensure_default_collection(collection_list=[1, 2, 'ansible.collection']) == [1, 2, 'ansible.collection']

# Generated at 2022-06-22 13:53:19.932244
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ['collection_list']
    assert len(cs.collections) > 0

# Generated at 2022-06-22 13:53:25.401385
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj1 = CollectionSearch()
    assert obj1.collections == _ensure_default_collection()
    obj2 = CollectionSearch(collections=['nsweb.f5_3_0'])
    assert obj2.collections == ['nsweb.f5_3_0']

# Generated at 2022-06-22 13:53:28.626922
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    obj = CollectionSearch()
    obj.collections = ["network.nxos", "native"]

    assert obj.collections == ["network.nxos", "native"]

# Generated at 2022-06-22 13:53:30.311397
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test for CollectionSearch constructor. No exception should occur.
    collection_search = CollectionSearch()
    assert collection_search

# Generated at 2022-06-22 13:53:35.363296
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection([]) == ['ansible.builtin']
    assert _ensure_default_collection is CollectionSearch._ensure_default_collection
    assert _ensure_default_collection() == CollectionSearch._collections.default
    assert _ensure_default_collection(['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-22 13:53:37.496883
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == []

# Generated at 2022-06-22 13:53:41.695517
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, object)
    assert isinstance(cs.collections, list)
    assert len(cs.collections) == 1
    assert cs.collections[0] == 'ansible.builtin'


# Generated at 2022-06-22 13:53:42.981438
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert issubclass(CollectionSearch, AnsibleCollectionConfig)

# Generated at 2022-06-22 13:53:50.356518
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    type_collection = CollectionSearch()
    id_collection = id(type_collection)
    assert type_collection.static is True
    assert type_collection._collections.always_post_validate is True
    assert type(type_collection._collections) is FieldAttribute
    assert isinstance(type_collection._collections.default, type(type_collection._ensure_default_collection))
    assert type_collection._collections.default(['test1','test2']) == type_collection._ensure_default_collection(['test1','test2'])

# Generated at 2022-06-22 13:54:06.616786
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible.posix', 'ansible.builtin']

# Generated at 2022-06-22 13:54:08.320020
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert isinstance(x, CollectionSearch), 'Failed to create CollectionSearch instance'

# Generated at 2022-06-22 13:54:11.195457
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()

    collection = CollectionSearch()

    collection.post_validate()

    display.display("collection info: {0}".format(collection))

# Run init test
if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:54:13.113412
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Test constructor of class CollectionSearch."""
    # FIXME: implement unit test
    assert True, "FIXME: Implement unit test for constructor of class CollectionSearch."

# Generated at 2022-06-22 13:54:15.509969
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection(collection_list=None)

# Generated at 2022-06-22 13:54:18.180348
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin', 'ansible.legacy']
    assert c.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:54:23.991521
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, []) == _ensure_default_collection()

    assert isinstance(cs._load_collections(None, ['asdf']), list)

    environment = Environment()
    assert cs._load_collections(None, ['asdf', '{{abc}}']) == ['asdf', '{{abc}}']
    assert isinstance(cs._load_collections(None, ['asdf', environment.from_string('{{abc}}')]), list)

# Generated at 2022-06-22 13:54:25.720983
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Unit test for constructor of class CollectionSearch
    """
    c_search = CollectionSearch()
    assert c_search._collections._static

# Generated at 2022-06-22 13:54:27.701017
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections(None, []) is not None

# Generated at 2022-06-22 13:54:29.821987
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections ==  ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:55:00.794525
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Test for _collections
    assert cs._collections == _ensure_default_collection
    # Test for _load_collections
    ds = ['my_collections']
    assert cs._load_collections('_collections', ds) == ds

# Generated at 2022-06-22 13:55:04.761368
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testObj = CollectionSearch()
    testObj._load_collections(None, None)
    string_types = (str,)
    assert testObj._collections == {
        'isa': 'list',
        'listof': string_types,
        'priority': 100,
        'default': _ensure_default_collection,
        'always_post_validate': True,
        'static': True}
    assert isinstance(testObj.collections, list)
    assert 'ansible.builtin' in testObj.collections
    assert 'ansible.legacy' in  testObj.collections

# Generated at 2022-06-22 13:55:05.452645
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-22 13:55:10.325650
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    #print("collections", obj._collections)
    #print("collection_list", obj._collections._collection_list)
    #print("default = ", obj._collections.default(None))


# vim: set ansible-inventory-module_utils=ansible_collections.ansible.builtin:module_utils

# Generated at 2022-06-22 13:55:20.660393
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    def test_empty_collection_list_success():
        actual = _ensure_default_collection(collection_list=None)

        assert actual is not None

    test_empty_collection_list_success()

    def test_non_empty_collection_list_success():
        actual = _ensure_default_collection(collection_list=['foo.bar', 'baz.qux'])
        assert actual == ['foo.bar', 'baz.qux', 'ansible.legacy']

    test_non_empty_collection_list_success()

    def test_default_collection_already_in_collection_list_success():
        actual = _ensure_default_collection(collection_list=['foo.bar', 'ansible.builtin', 'baz.qux'])

# Generated at 2022-06-22 13:55:28.249195
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    display.deprecated = None
    display.deprecated = True

    class StubClass(CollectionSearch):
        __slots__ = ()

    # Test when collections=None
    obj = StubClass()
    assert obj._collections is None

    # Test when collections=[]
    obj = StubClass()
    obj.collections = []
    assert obj._collections == []

    # Test when collections is a list
    obj = StubClass()
    obj.collections = ['test']
    assert obj._collections == ['test']

# Generated at 2022-06-22 13:55:29.364453
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs)

# Generated at 2022-06-22 13:55:33.254494
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class MyClass(CollectionSearch):
        pass

    # Tests default value of field "collections"
    inst = MyClass()
    default_value = inst._collections.default(inst=inst)
    assert isinstance(default_value, list)

# Generated at 2022-06-22 13:55:37.450377
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #_collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
    #                              always_post_validate=True, static=True)

    t = CollectionSearch()
    print(t._collections)

test_CollectionSearch()

# Generated at 2022-06-22 13:55:43.125803
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    collection._collections = ["ansible.builtin", "nsbl.new_collection"]
    assert collection._load_collections("collections", "collections") == ["nsbl.new_collection",
                                                                         "ansible.builtin"]

# Generated at 2022-06-22 13:56:47.931870
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = 'ansible.builtin'
    # Call function with default ds
    cs = CollectionSearch()
    cs._load_collections(None, ds)
    assert cs._collections == ds

    # Call function with empty ds
    cs = CollectionSearch()
    ds = []
    cs._load_collections(None, ds)
    assert cs._collections == ['ansible.builtin']

    # Create string
    ds = 'ansible.builtin'
    cs = CollectionSearch()
    cs._load_collections(None, ds)
    assert cs._collections == ds

    # Create list
    ds = ['ansible.builtin', 'ansible.legacy']
    cs = CollectionSearch()
    cs._load_collections(None, ds)
    assert cs

# Generated at 2022-06-22 13:56:49.883332
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Test for constructor of class CollectionSearch
    """
    c = CollectionSearch()
    assert c.__dict__.get('collections') is None

# Generated at 2022-06-22 13:56:53.456031
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj._load_collections('collections', [])
    obj._load_collections('collections', None)



# Generated at 2022-06-22 13:57:00.149770
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # get the object from module
    instance = CollectionSearch()

    # get the value used for the default of constructor
    default = instance._load_collections(attr={"isa": "list", "listof": string_types, "priority": 100, "default": _ensure_default_collection, "always_post_validate": True, "static": True}, ds=None)

    # check if the default value is as expected
    assert default == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible.community.system']


# Generated at 2022-06-22 13:57:02.358904
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default() == _ensure_default_collection()

# Generated at 2022-06-22 13:57:05.054996
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections == [ansible_builtin_collection]

# Generated at 2022-06-22 13:57:08.636124
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert not hasattr(instance, '_collections')
    result = instance.get_validated_value('collections', instance._collections, None, None)
    assert result == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:57:12.695093
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default is not None
    assert callable(cs._collections.default)
    assert cs._collections.default.__module__ == 'ansible.playbook.base'
    assert cs._collections.default.__name__ == '_ensure_default_collection'
    assert cs._collections.default is _ensure_default_collection


# Generated at 2022-06-22 13:57:13.733959
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-22 13:57:14.539112
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()

# Generated at 2022-06-22 13:59:11.453248
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    object = CollectionSearch()
    assert object._collections is not None
    assert object._collections.default == _ensure_default_collection
    assert object._collections.listof == string_types
    assert object._collections.static == True
    assert object._collections.always_post_validate == True

# Generated at 2022-06-22 13:59:16.417258
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._ensure_default_collection(collection_list=['collection1', 'collection2']) == ['collection1', 'collection2', 'ansible.builtin']
    assert CollectionSearch._ensure_default_collection(collection_list=None) == ['ansible.builtin']
    assert CollectionSearch._ensure_default_collection(collection_list=[]) == ['ansible.builtin']

# Generated at 2022-06-22 13:59:18.100704
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection([])

# Generated at 2022-06-22 13:59:22.285722
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.always_post_validate == True
    assert isinstance(CollectionSearch._collections, FieldAttribute)
    assert CollectionSearch._collections.isa == 'list'
    assert CollectionSearch._collections.listof == string_types
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.static == True

# Generated at 2022-06-22 13:59:24.585002
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_collection = CollectionSearch()
    assert isinstance(my_collection, CollectionSearch)

# Generated at 2022-06-22 13:59:25.351629
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print (CollectionSearch)

# Generated at 2022-06-22 13:59:26.907885
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch is not None

# Generated at 2022-06-22 13:59:29.869692
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    result = cs.__dict__
    assert '_collections' in result
    # TODO: should we check the data type of result['_collections']?
    # This will be an instance of a class ansible.playbook.attribute.FieldAttribute

# Generated at 2022-06-22 13:59:31.194985
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_search = CollectionSearch()
    test_collection_search.__init__()

# Generated at 2022-06-22 13:59:32.646062
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections == [AnsibleCollectionConfig.default_collection]