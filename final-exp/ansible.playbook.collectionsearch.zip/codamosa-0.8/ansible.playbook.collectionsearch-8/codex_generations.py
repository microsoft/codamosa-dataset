

# Generated at 2022-06-22 13:51:07.237820
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:10.144607
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    temp = CollectionSearch()
    print(temp)
    
if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:51:20.604764
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    include = TaskInclude()
    include._load_role = lambda *args: None
    tasks = [include]
    play_context = PlayContext()
    block = Block(task_include=TaskInclude())
    play = Play()
    task = Task()
    task._get_parent_attribute = lambda *args, **kwargs: block
    task.action = 'include'
    play._load_included_file = lambda *args: Task()
    task._play = play
    task._tqm = None
    task._host = None
   

# Generated at 2022-06-22 13:51:23.518506
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    check_collection_serch = CollectionSearch()
    assert check_collection_serch._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:29.671560
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # The default value of _collections is [].
    assert cs._collections == []
    assert cs._valid_attrs._attrs['_collections'].static is True

    # Passing value when constructing object will overwrite the default value.
    cs1 = CollectionSearch(collections=["a.b"])
    assert cs1._collections == ["a.b"]
    assert cs1._valid_attrs._attrs['_collections'].static is True

    # Passing value when constructing object will overwrite the default value.
    cs2 = CollectionSearch(collections=['ansible.builtin'])
    assert cs2._collections == ['ansible.builtin']
    assert cs2._valid_attrs._attrs['_collections'].static is True

    # _ensure_default_collection
   

# Generated at 2022-06-22 13:51:36.459103
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

    # Check if collection name is returned by function get_validated_value
    assert search.get_validated_value('collections', search._collections, ['ansible.builtin', 'ansible.legacy'], None) == ['ansible.builtin', 'ansible.legacy']

    # Check if the collection list is returned by function _load_collections
    assert search._load_collections(search._collections, ['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:51:37.540782
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:51:40.635786
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    object1 = CollectionSearch()
    object1._collections=['collections']
    object1._load_collections(attr=None, ds=['collections'])


# Generated at 2022-06-22 13:51:42.146797
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:44.643832
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Make sure we get an instance of CollectionSearch
    x = CollectionSearch()
    assert isinstance(x, CollectionSearch)

# Generated at 2022-06-22 13:51:48.702256
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-22 13:51:52.667779
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Initialize the object
    collection_search = CollectionSearch()

    # Get the value of the field
    field = collection_search._load_collections(None, None)

    # Check that the field value is a list
    assert isinstance(field, list)

# Generated at 2022-06-22 13:52:05.153121
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import IncludeTask
    import os

    collections_path = os.path.join(os.path.dirname(__file__), '../../../../../../local_collections')

    loader = AnsibleCollectionConfig(collections_path=collections_path)

    # check IncludeRole
    collection_role = IncludeRole()
    block = Block()
    block.set_loader(loader)
    collection_role.set_loader(loader)
    collection_role.post_validate(block)
    assert type(collection_role.get_loader()) == type(AnsibleCollectionConfig())

    # check IncludeTask
    collection_task = IncludeTask()
    block = Block()


# Generated at 2022-06-22 13:52:13.376405
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ["ansible.base", "test.collection"]
    #
    # Uncomment to debug output of all class variables
    #
    # print("\n***\nClass: %s" % class_var)
    # print("Dictionary: %s" % cs.__dict__)
    # print("Keys: %s" % cs.__dict__.keys())
    # print("Attributes: %s" % dir(cs))
    # print("Variables: %s\n***\n" % (cs._variables))
    #
    # Uncomment to debug output of all class variables for classes up the inheritance tree
    #
    # for class_var in cs.__class__.__bases__:
    #     print("\n***\nClass: %s" % class_

# Generated at 2022-06-22 13:52:15.925049
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    display.display("collectionSearch._collections: %s" % collectionSearch._collections)


# Generated at 2022-06-22 13:52:17.771925
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection



# Generated at 2022-06-22 13:52:21.577642
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search_obj = CollectionSearch()
        assert True, "Successfully created CollectionSearch"
    except:
        assert False, "Failed to create CollectionSearch"


# Generated at 2022-06-22 13:52:26.577301
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collsearch = CollectionSearch()
    # Set the value of collection_list to the empty list
    collection_list = []
    # Call the _ensure_default_collection method from CollectionSearch class
    _ensure_default_collection(collection_list)
    assert isinstance(collection_list, list)

# Generated at 2022-06-22 13:52:38.102104
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest

    class CollectionSearchTest(unittest.TestCase):
        #TODO: test for _load_collections doesn't work as it is not exposed.
        #def test_load_collections(self):
        #    collection_search = CollectionSearch()
        #    self.assertEqual(collection_search._load_collections(collections=["test.collections", "test.collections2", "test.collections3"]),
        #                     ["test.collections", "test.collections2", "test.collections3"])

        def test_ensure_default_collection(self):
            collection_search = CollectionSearch()
            self.assertNotEqual(collection_search._ensure_default_collection(), [])

    # Run Test
    unittest.main()

# Generated at 2022-06-22 13:52:43.700624
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # if _collections is not None, the _load_collections method will be called
    test_collections = ['test_collect1', 'test_collect2']
    collection_search.__dict__['_collections'] = test_collections
    # call the _load_collections method
    collection_search._load_collections('collections', [])

# Generated at 2022-06-22 13:52:53.846084
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """ Unit test for constructor of class CollectionSearch."""
    collection_search = CollectionSearch()
    setattr(collection_search, 'collections', None)
    assert collection_search.collections is None

# Generated at 2022-06-22 13:52:59.628516
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch, 'collections')
    assert hasattr(CollectionSearch, '_load_collections')
    assert hasattr(CollectionSearch._load_collections, '__call__')
    assert hasattr(CollectionSearch, '_ensure_default_collection')
    assert hasattr(CollectionSearch._ensure_default_collection, '__call__')

# Generated at 2022-06-22 13:53:02.970013
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections == ['ansible.builtin', 'ansible.legacy']
    # The following code is not working
    # search.collections = ["test"]
    # assert search.collections == ["test"]

# Generated at 2022-06-22 13:53:09.836958
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition

    # Prepare collection search with collection list
    collection_search = CollectionSearch()
    role_definition = RoleDefinition.load("test.yml", collections="test_collection")
    role_definition.post_validate(mock=True)
    collection_search.collections = role_definition.collections

    # Assert the collection list of collection_search
    assert collection_search.collections is not None
    assert len(collection_search.collections) == 1
    assert collection_search.collections[0] == "test_collection"

# Generated at 2022-06-22 13:53:11.947559
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = Base()
    assert obj._collections.value == _ensure_default_collection()


# Generated at 2022-06-22 13:53:14.786760
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()
    assert col_search.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:53:19.338711
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections(None, []) == ['ansible.legacy']
    assert collection_search._load_collections(None, ['test']) == ['test', 'ansible.legacy']
    assert collection_search._load_collections(None, [None]) == None

# Generated at 2022-06-22 13:53:21.515055
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == 'ansible.builtin'

# Generated at 2022-06-22 13:53:27.710997
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_col_search = CollectionSearch()

    # Ensure that a list created by calling the constructor appears to be a list
    assert isinstance(test_col_search._collections, list)

    # Ensure that no errors are thrown when _ensure_default_collection is called
    assert isinstance(test_col_search._ensure_default_collection(), list)

# Generated at 2022-06-22 13:53:29.024511
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)

# Generated at 2022-06-22 13:53:43.784539
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is None

# Generated at 2022-06-22 13:53:45.910165
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:53:47.213716
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:53:48.679931
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:53:51.974917
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Trying to instantiate class CollectionSearch
    #collection_search = CollectionSearch()
    #assert collection_search._collections is _ensure_default_collection()
    assert True #for the time being

# Generated at 2022-06-22 13:53:53.672971
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is not None

# Generated at 2022-06-22 13:54:04.492391
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.datastructure import DataLoader
    from ansible.errors import AnsibleError
    import sys
    import os

    mock_loader = DataLoader()
    mock_path = os.path.join(os.path.dirname(__file__), '/../../playbooks/../playbooks/')
    sys.path.append(mock_path)

    try:
        import ansible.modules.collection_search  # pylint: disable=unused-import
    except AnsibleError:
        # The error we are looking for
        pass

    mock_loader.set_basedir('/ansible_home')
    # pylint: disable=protected-access
    mock_cs = CollectionSearch(loader=mock_loader, attribute_name_something='collections')

# Generated at 2022-06-22 13:54:06.524913
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:54:09.258729
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    col.collections = ['ansible.builtin']
    assert col.collections == ['ansible.builtin']

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-22 13:54:10.305954
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:54:29.361135
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    try:
        assert cs._collections == None
        assert cs._load_collections('collections', ['test']) == ['test']
    except Exception as message:
        print("Error: " + str(message))
    else:
         print("Test1: Class 'CollectionSearch' init works.")


# Generated at 2022-06-22 13:54:41.179602
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    # Validate static attribute exists
    assert hasattr(instance,'_collections')
    # Validate static attribute has a FieldAttribute instance
    assert isinstance(instance._collections,FieldAttribute)
    # Validate static attribute isa
    assert instance._collections.isa == 'list'
    # Validate static attribute listof
    assert instance._collections.listof == string_types
    # Validate static attribute priority
    assert instance._collections.priority == 100
    # Validate static attribute default
    assert instance._collections.default == _ensure_default_collection
    # Validate static attribute always_post_validate
    assert instance._collections.always_post_validate is True
    # Validate static attribute static
    assert instance._collections.static is True

    # Verify that _collections is not

# Generated at 2022-06-22 13:54:45.825616
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection = CollectionSearch()
    # test if the default value of _collections is correctly set
    collections = test_collection._collections.get_value_for(test_collection)
    assert collections[0] == AnsibleCollectionConfig.default_collection
    assert len(collections) == 1

    # test if the shared function is used
    _ensure_default_collection(test_collection)

# Generated at 2022-06-22 13:54:47.912793
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections([], None) == None

# Generated at 2022-06-22 13:54:51.443279
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._collections.default is not None
    assert isinstance(cs._collections.default, type(cs._ensure_default_collection()))

# Generated at 2022-06-22 13:54:55.354624
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.plugins.loader import collection_loader

    collection_loader.set_collection_paths([])

    c = CollectionSearch()

    assert c.collections == ["ansible.legacy"]

    collection_loader.set_collection_paths(["somedir"])
    c = CollectionSearch()
    assert c.collections == ["ansible.legacy", "somedir"]

# Generated at 2022-06-22 13:54:57.738675
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # Test initialization of scls
    assert cs._collections == [], 'Failed to initialize _collections'

# Generated at 2022-06-22 13:54:59.268341
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    b = CollectionSearch()
    assert b.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:55:03.980422
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_class = CollectionSearch()
    ds = {'collections': ['my_collection']}
    expected = ['my_collection', 'ansible.builtin']
    assert test_class._load_collections(None, ds) == expected

# Generated at 2022-06-22 13:55:05.497771
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs.collections)

# Generated at 2022-06-22 13:55:33.587152
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:55:35.645914
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible_collections.test.test1']

# Generated at 2022-06-22 13:55:44.563673
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert list == type(obj.collections)
    assert 2 == len(obj.collections)
    assert 'ansible.builtin' in obj.collections
    assert 'ansible.legacy' in obj.collections

    obj.collections = None
    assert list == type(obj.collections)
    assert 2 == len(obj.collections)
    assert 'ansible.builtin' in obj.collections
    assert 'ansible.legacy' in obj.collections

# Generated at 2022-06-22 13:55:46.107389
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections == ("ansible.builtin", "ansible.legacy")

# Generated at 2022-06-22 13:55:48.065221
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:55:56.505183
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import collection_loader
    test_dict = dict(
        collections=['invalidname.test'],
    )
    try:
        block = Block(name='testblock', parent=Task(), role=None, task_include=None, block=None)
        handler = Handler()
        handler.load_from_file_args(task=None, args=test_dict, variable_manager=None, loader=None)
        handler.post_validate(collection_loader)
        assert True
    except:
        assert False

# Generated at 2022-06-22 13:55:58.838926
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This test only proves we can instantiate the class.
    c = CollectionSearch()

# Generated at 2022-06-22 13:56:02.107170
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._load_collections('collections', []) is not None

# Generated at 2022-06-22 13:56:12.153466
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Obj:
        def __init__(self):
            super(Obj, self).__init__()
            self._collections = CollectionSearch._collections.default()
        collections = CollectionSearch._collections.notify_on_change(lambda s, d: s._load_collections('collections', d))
    obj = Obj()
    assert obj.collections == ['ansible.posix']

    obj.collections = []
    assert obj.collections == ['ansible.posix']

    obj.collections = ['foo']
    assert obj.collections == ['foo', 'ansible.posix']

    obj.collections = ['foo', 'bar']
    assert obj.collections == ['foo', 'bar', 'ansible.posix']

# Generated at 2022-06-22 13:56:13.655435
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c=CollectionSearch()
    assert c._collections == _ensure_default_collection()


# Generated at 2022-06-22 13:57:08.216722
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("This is CollectionSearch test")

# Generated at 2022-06-22 13:57:10.220917
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._load_collections("collections", ['ansible.builtin']) is not None

# Generated at 2022-06-22 13:57:16.212522
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert result is not None

    assert result.data is not None
    assert result.data[
        '_collections'] == (AnsibleCollectionConfig.default_collection,)

    result.data['collections'] = True

    result.post_validate([], None)
    assert result.data['_collections'] == (
        AnsibleCollectionConfig.default_collection,)

    result.data['collections'] = [AnsibleCollectionConfig.default_collection]
    result.post_validate([], None)

    assert result.data['_collections'] == (
        AnsibleCollectionConfig.default_collection,)

    if AnsibleCollectionConfig.default_collection:
        result.data['collections'] = []
        result.post_validate([], None)

# Generated at 2022-06-22 13:57:17.993699
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == 'ansible.builtin'

# Generated at 2022-06-22 13:57:21.362005
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.plugins.loader import role_loader
    role_name = "test_role"

    role_obj = role_loader._get_role_definition(role_name, None)
    assert isinstance(role_obj, CollectionSearch)

# Generated at 2022-06-22 13:57:27.009067
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.module_utils.six import PY2
    if PY2:
        from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    else:
        from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject as AnsibleBaseYAMLObject

    tcs = CollectionSearch()
    if not isinstance(tcs, AnsibleBaseYAMLObject):
        raise AssertionError('type of CollectionSearch is not AnsibleBaseYAMLObject')

# Generated at 2022-06-22 13:57:28.387900
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_obj = CollectionSearch()
    assert my_obj._collections is not None

# Generated at 2022-06-22 13:57:31.174645
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert 'ansible.legacy' == collection._load_collections(attr=None, ds=None)

# Generated at 2022-06-22 13:57:34.881879
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.get_value('collections') == ['ansible.builtin', 'ansible.legacy']
    assert obj._collections.value == ['ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-22 13:57:37.105797
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs.collections)

# Generated at 2022-06-22 13:59:29.307207
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-22 13:59:30.192789
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None

# Generated at 2022-06-22 13:59:33.747499
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    collection.collections = [ 'test_collection_1' ]
    assert collection.collections == [ 'test_collection_1' ]

    # Test for case when collection is None
    collection.collections = None
    assert collection.collections == None

# Generated at 2022-06-22 13:59:36.553572
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.post_validate()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:59:38.197612
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ret = cs.collections
    assert ret == _ensure_default_collection()

# Generated at 2022-06-22 13:59:38.817258
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert 1==1

# Generated at 2022-06-22 13:59:49.323562
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext

    class FakeModule:
        class FakeClass:
            _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                          always_post_validate=True, static=True)

            def __init__(self):
                self._collections = self._ensure_default_collection()

            def _ensure_default_collection(self):
                default_collection = AnsibleCollectionConfig.default_collection
                collection_list = []
                self.collection_list = collection_list

                # FIXME: exclude role tasks?
                if default_collection and default_collection not in collection_list:
                    collection_list.insert(0, default_collection)

                # if there's something in the list, ensure

# Generated at 2022-06-22 13:59:52.059791
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert _ensure_default_collection(collection_list=None) == collection_search.collections

# Generated at 2022-06-22 13:59:53.793399
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._load_collections('collections', None) == _ensure_default_collection(None)

# Generated at 2022-06-22 13:59:54.304087
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print (CollectionSearch())