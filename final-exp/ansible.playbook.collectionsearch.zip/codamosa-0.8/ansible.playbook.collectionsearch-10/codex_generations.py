

# Generated at 2022-06-22 13:51:17.664239
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # _collections is static=True, so it will be None when
    # _load_collections is called
    cs = CollectionSearch()
    assert cs._load_collections('collections', None) is None
    cs = CollectionSearch(collections=['awx.awx'])
    assert cs._load_collections('collections', ['awx.awx']) == ['awx.awx', 'ansible.builtin', 'ansible.legacy']
    cs = CollectionSearch(collections=['awx.awx', 'ansible.builtin'])
    assert cs._load_collections('collections', ['awx.awx', 'ansible.builtin']) == ['awx.awx', 'ansible.builtin', 'ansible.legacy']
    cs = CollectionSearch(collections=[])
   

# Generated at 2022-06-22 13:51:20.641391
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()
    assert collection_search._load_collections(" ", " ") is None


# Generated at 2022-06-22 13:51:26.820747
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)
    assert obj._collections == _ensure_default_collection()
    assert obj._collections == _ensure_default_collection([])
    assert obj._collections == _ensure_default_collection(['ansible.builtin'])
    assert obj._collections == _ensure_default_collection(collection_list=['ansible.builtin'])

# Generated at 2022-06-22 13:51:36.809661
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    class TestCollectionSearch(unittest.TestCase):

        def test_collection_search(self):
            # init
            AnsibleCollectionConfig.default_collection = 'ansible.builtin'
            collection_search = CollectionSearch()

            # test
            # collections has default value, which is [ 'ansible.builtin' ]
            self.assertEqual(collection_search._collections, [ 'ansible.builtin' ])
            my_variable = {
                'collections': None
            }
            self.assertEqual(collection_search._load_collections('collections', my_variable), None)


# Generated at 2022-06-22 13:51:44.846276
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections == ['ansible.builtin', 'ansible.legacy']

    # test with collection list
    search = CollectionSearch(collections=['ansible_namespace.collection', 'ansible_namespace.collection_two'])
    assert search._collections == ['ansible_namespace.collection', 'ansible_namespace.collection_two']

    # test with empty collection list
    search = CollectionSearch(collections=[])
    assert search._collections == []

# Generated at 2022-06-22 13:51:51.557954
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search._collections = ['ansible.builtin']
    assert collection_search._collections == ['ansible.builtin']
    assert collection_search._load_collections('_collections', 'ansible.builtin') == ['ansible.builtin']
    assert collection_search._load_collections('_collections', ['ansible.builtin']) == ['ansible.builtin']


# Generated at 2022-06-22 13:51:53.326894
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()

# Generated at 2022-06-22 13:52:01.370207
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # ensure the required argument 'collections' is not missing
    try:
        obj1 = CollectionSearch()
    except TypeError as msg:
        assert '__init__() missing 1 required positional argument: \'collections\'' in str(msg)

    # ensure the required argument 'collections' is not empty
    obj2 = CollectionSearch([])
    assert obj2.collections is None

    # ensure the required argument 'collections' is not None
    obj3 = CollectionSearch([])
    assert len(obj3._collections) == 0

# Generated at 2022-06-22 13:52:03.171482
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:52:08.124129
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class MyCollectionSearchType(CollectionSearch):
        def get_validated_value(self, key, var, ds, value):
            return ['ansible.builtin', 'ansible.network.network']

    search = MyCollectionSearchType()
    assert search._load_collections(None, None)

# Generated at 2022-06-22 13:52:14.116692
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:52:16.075313
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.collections = []
    assert search.collections == 'ansible.builtin'

# Generated at 2022-06-22 13:52:17.551361
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs1 = CollectionSearch()
    print(cs1.collections)

# Generated at 2022-06-22 13:52:18.809407
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections is not None

# Generated at 2022-06-22 13:52:19.395447
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print(CollectionSearch)

# Generated at 2022-06-22 13:52:21.628971
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections._value is None

# Generated at 2022-06-22 13:52:33.599660
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # 1. No collection names are provided.
    #    1.1 __init__() is called implicitly.
    #    1.2 get_validated_value() is called implicitly.
    #    1.3 _ensure_default_collection() is called in load_collections().
    #    1.4 collections = ['ansible.builtin']
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']

    # 2. Collection names are provided.
    #    2.1 __init__() is called explicitly.
    #    2.2 get_validated_value() is called implicitly.
    #    2.3 _ensure_default_collection() is called in load_collections().
    #    2.4 collections[0] = 'ansible.builtin'
    #    2.5 collections[1

# Generated at 2022-06-22 13:52:35.275903
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.collections = ['test']

# Generated at 2022-06-22 13:52:36.602686
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ['ansible.builtin']

# Generated at 2022-06-22 13:52:40.968015
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Can create CollectionSearch
    cs = CollectionSearch()

    # Returned list contains ansible.builtin
    collections = cs._load_collections(attr='collections', ds=[])
    assert collections == ['ansible.builtin', 'ansible.builtin']

# Generated at 2022-06-22 13:52:50.699186
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.value == ['ansible.community']
    assert cs._collections.post_validate_method == _ensure_default_collection
    assert cs._collections.static
    def set_test(self, value):
        assert value == ['test']
    cs._collections.set(set_test, 'test')

# Generated at 2022-06-22 13:53:02.620812
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    b = CollectionSearch()
    assert b.collections == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible_legacy.builtin', 'ansible_collections.ansible.builtin']
    #test when collection_list is None
    b = CollectionSearch(collection_list=None)
    assert b.collections == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible_legacy.builtin', 'ansible_collections.ansible.builtin']
    #test when collection_list is not None
    b = CollectionSearch(collection_list=['collection_name'])
    assert b.collections == ['collection_name', 'ansible_collections.ansible_legacy.builtin']
    #test when collection_list is empty list
   

# Generated at 2022-06-22 13:53:08.278338
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass

    # No default value
    t = TestCollectionSearch()
    assert t.collections is None, "collections attribute if not specified should be None"
    # Specify collection list
    t.collections = ['ansible.builtin', 'ansible.legacy']
    assert t.collections == ['ansible.builtin', 'ansible.legacy'], \
        "collections attribute if specified should be {}, but you get {}".format(
        ['ansible.builtin', 'ansible.legacy'], t.collections
    )



# Generated at 2022-06-22 13:53:09.698722
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None

# Generated at 2022-06-22 13:53:14.477308
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ['ansible.builtin', 'foo']
    assert cs._collections == ['ansible.builtin', 'foo']
    _ = cs.collections  # trigger post_validate

# Generated at 2022-06-22 13:53:15.508765
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()


# Generated at 2022-06-22 13:53:16.874193
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert len(collection._collections) > 0

# Generated at 2022-06-22 13:53:19.504074
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch()
    assert d.collections == ['ansible.builtin']
    d.collections = ['mini']
    assert d.collections == ['mini']

# Generated at 2022-06-22 13:53:32.189947
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest
    import inspect
    from ansible.playbook.attribute import FieldAttribute

    class C():
        pass

    # Test to make sure '_collections' member was added
    try:
        C._collections
    except AttributeError:
        raise unittest.SkipTest("Attribute \'_collections\' not found in class C")

    # Test _collections is FieldAttribute
    if not isinstance(C._collections, FieldAttribute):
        raise unittest.FailTest("Attribute \'_collections\' is not FieldAttribute type")

    # Test to make sure '_collections' has correct values
    if not isinstance(C._collections.isa, (tuple, list)):
        raise unittest.FailTest("Attribute \'_collections\' does not contain \'isa\' attribute")

# Generated at 2022-06-22 13:53:37.930553
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute_container import AttributeContainer
    c = CollectionSearch()
    assert c.constructor_args[AttributeContainer.FIELD_ATTRIBUTES]['collections'].kwargs['weakref_key'] == 'collections'
    assert c.constructor_args[AttributeContainer.FIELD_ATTRIBUTES]['collections'].kwargs['always_post_validate'] == True
    assert c.constructor_args[AttributeContainer.FIELD_ATTRIBUTES]['collections'].kwargs['priority'] == 100

# Generated at 2022-06-22 13:53:54.682816
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()
    # Verify that _load_collections returns None
    assert test_object._load_collections(None, None) is None

# Generated at 2022-06-22 13:53:58.120632
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    ansible_collections = collection_search._collections._get_default_value() 
    current_collection = collection_search._collections.default
    assert ansible_collections == [current_collection]

# Generated at 2022-06-22 13:54:07.363406
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._collections = 'fake_collection'
    result = cs._load_collections(None, None)
    assert result is None
    cs._collections = []
    result = cs._load_collections(None, None)
    assert result is None
    cs._collections = None
    result = cs._load_collections(None, None)
    assert result is None
    cs._collections = ['ansible.builtin']
    result = cs._load_collections(None, None)
    assert result == ['ansible.builtin']
    cs._collections = ['fake_collection']
    result = cs._load_collections(None, None)
    assert result == ['fake_collection', 'ansible.legacy']

# Generated at 2022-06-22 13:54:08.668286
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    assert col._collections == None

# Generated at 2022-06-22 13:54:11.514039
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = {"collections": []}
    c = CollectionSearch(d)
    assert len(c._field_names)  == 1
    assert c._field_names[0] == "collections"
    assert c._collections == []



# Generated at 2022-06-22 13:54:13.533373
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    # Test static field _collections
    assert obj._collections is not None

# Generated at 2022-06-22 13:54:18.723820
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.playbook.attribute as ap
    module = ap.FieldAttribute.add_type(ap.FieldAttribute.STRING, 'list', None, True)
    assert module.name == 'list'
    assert module.isa == 'list'
    assert module.priority == 100
    assert module.default == _ensure_default_collection
    assert module.always_post_validate == True
    assert module.static == True

# Generated at 2022-06-22 13:54:23.876878
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test1 = CollectionSearch()
    test2 = CollectionSearch()
    test2._collections = []
    assert test2._collections == []
    assert test1._collections == ['ansible.builtin']
    test1._collections = ['geerlingguy.java']
    assert test1._collections == ['geerlingguy.java', 'ansible.builtin']
    assert test2._collections == []


# Generated at 2022-06-22 13:54:25.529958
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None

# Generated at 2022-06-22 13:54:26.782361
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections.default() is None

# Generated at 2022-06-22 13:54:58.108626
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections == ['ansible_collections.nsweb.kubernetes.plugins.tasks', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:54:59.485252
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections=CollectionSearch()
    assert isinstance(collections, CollectionSearch)


# Generated at 2022-06-22 13:55:09.055382
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.playbook.base import Base
    import inspect

    test_class = Base()
    test_class.collections = _ensure_default_collection()

    assert isinstance(test_class.collections[0], AnsibleCollectionRef)
    assert inspect.isclass(test_class.collections[0].collection)
    assert test_class.__class__.__name__ == 'Base'
    assert test_class.collections[0].collection.__name__ == 'AnsibleCollectionConfig'



# Generated at 2022-06-22 13:55:10.662530
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert _ensure_default_collection() == x._load_collections('collections', None)

# Generated at 2022-06-22 13:55:17.032947
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test constructor of class CollectionSearch
    search = CollectionSearch()
    assert search._collections == _ensure_default_collection()
    assert search._collections is not _ensure_default_collection()

    search = CollectionSearch()
    search._collections = ["collection1", "collection2"]
    assert search._collections == ["collection1", "collection2"]
    assert search._collections is not ["collection1", "collection2"]



# Generated at 2022-06-22 13:55:22.330712
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        def __init__(self):
            self._collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)

    tcs = TestCollectionSearch()
    assert isinstance(tcs._load_collections('collections', []), list)

# Generated at 2022-06-22 13:55:23.827749
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible_collections.notstdlib.moveit']

# Generated at 2022-06-22 13:55:26.465425
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()

# Generated at 2022-06-22 13:55:29.257737
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections.value is None
    assert search._collections.default(_ensure_default_collection) is None

# Generated at 2022-06-22 13:55:31.238273
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:56:27.769966
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == _ensure_default_collection()
    assert c._collections.default == _ensure_default_collection
    assert c._collections.priority == 100
    assert c._collections.static

# Generated at 2022-06-22 13:56:30.065161
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert isinstance(search, object)
    assert search._collections == ['ansible_collections.some_namespace.some_collection']
    assert search._collections != []

# Generated at 2022-06-22 13:56:36.835498
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # check if constructor works correctly
    # check if constructor works correctly
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.always_post_validate == True
    assert CollectionSearch._collections.static == True
    assert CollectionSearch._collections.priority == 100

    assert CollectionSearch._collections.isa == 'list'
    assert (CollectionSearch._collections.listof == string_types)

# Generated at 2022-06-22 13:56:40.610596
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection()
    assert cs._collections.always_post_validate is True
    assert cs._collections.static is True


# Generated at 2022-06-22 13:56:41.536379
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a

# Generated at 2022-06-22 13:56:45.244565
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test_CollectionSearch_basic
    class DummyClass(CollectionSearch):
        pass
    obj = DummyClass()
    assert isinstance(obj, CollectionSearch)
    assert obj._collections._default == _ensure_default_collection

# Generated at 2022-06-22 13:56:46.634649
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Testing constructor of collection search
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:56:57.364440
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    temp = CollectionSearch()
    assert temp._collections._initial_value == _ensure_default_collection(collection_list=None)
    temp.collections = ['ansible.builtin', 'ansible.legacy']
    assert temp.collections == ['ansible.builtin', 'ansible.legacy']
    assert temp._collections._initial_value == _ensure_default_collection(collection_list=['ansible.builtin', 'ansible.legacy'])
    temp.collections = None
    assert temp.collections ==  None
    assert temp._collections._initial_value == _ensure_default_collection(collection_list=None)
    temp.collections = ['']
    assert temp.collections == ['']
    assert temp._collections._initial_value == _ens

# Generated at 2022-06-22 13:57:00.528046
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Init a CollectionSearch object
    cs = CollectionSearch()
    cs.__post_init__()

    # Test constructor
    assert cs.__class__.__name__ == 'CollectionSearch'

    # Test post_init
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:57:03.079213
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections.value == ['ansible.builtin']

# Generated at 2022-06-22 13:57:59.741352
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    base = CollectionSearch()
    assert base._collections.default() == _ensure_default_collection()

# Generated at 2022-06-22 13:58:04.344141
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_search = CollectionSearch()
    assert my_search._collections == ['ansible_collections.ansible.builtin']

    my_search = CollectionSearch()
    assert my_search._collections == ['ansible_collections.ansible.builtin']

# Generated at 2022-06-22 13:58:05.368670
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj._load_collections('collections',{'collections':['geerlingguy.java']}))

# Generated at 2022-06-22 13:58:06.740361
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['ansible_builtin']

# Generated at 2022-06-22 13:58:09.926888
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch._collections
    assert cs.name == 'collections'
    assert cs.listof == string_types
    assert cs.always_post_validate is True
    assert cs.static is True

# Generated at 2022-06-22 13:58:12.618386
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    obj = CollectionSearch()
    assert obj._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:58:14.655589
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Foo(CollectionSearch):
        pass
    assert isinstance(Foo._collections, FieldAttribute)

# Generated at 2022-06-22 13:58:17.175897
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # GIVEN
    test_CollectionSearch = CollectionSearch()
    # WHEN
    # THEN
    assert isinstance(test_CollectionSearch, CollectionSearch)

# Generated at 2022-06-22 13:58:17.827930
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search._collections)

# Generated at 2022-06-22 13:58:19.405316
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print(CollectionSearch()._load_collections('collections', ['ansible.builtin']))

# Generated at 2022-06-22 14:00:15.417440
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections == ["ansible.posix.collection", "ansible.builtin", "ansible.legacy"]

# Generated at 2022-06-22 14:00:23.000239
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collectionSearch = CollectionSearch()
    assert test_collectionSearch._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']
    assert test_collectionSearch._load_collections(None, ['nsxt.collection']) == ['nsxt.collection']
    assert test_collectionSearch._load_collections(None, []) == ['ansible.legacy']
    assert test_collectionSearch._load_collections(None, None) == ['ansible.legacy']


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 14:00:23.962489
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print(collectionSearch.CollectionSearch())

# Generated at 2022-06-22 14:00:28.792600
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Creating a object of CollectionSearch class
    obj = CollectionSearch()

    display.warning = Mock()
    collection_search = obj._load_collections(None, ['ansible.builtin'])
    assert isinstance(collection_search, list)
    assert collection_search == ['ansible.builtin', 'ansible.legacy']
    collection_search = obj._load_collections(None, None)
    assert isinstance(collection_search, list)
    assert collection_search == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-22 14:00:33.505810
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   import json
   dict = {
      "collections": [
         "ansible.builtin"
      ]
   }

   # Creating a CollectionSearch instance
   collectionSearch = CollectionSearch(**dict)
   print(json.dumps(json.loads(json.dumps(collectionSearch, default=lambda o: o.__dict__)), indent=4, sort_keys=True))

   assert collectionSearch.collections == ['ansible.builtin']
   #assert "collectionSearch = CollectionSearch(**dict)" in str(CollectionSearch.__init__)
   #assert "self.collections = collections" in str(CollectionSearch.__init__)
   #assert "self._collections = _collections" in str(CollectionSearch.__init__)
   #assert "attr = 'collections'" in str(CollectionSearch._load_collections)

# Generated at 2022-06-22 14:00:34.973828
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None


# Generated at 2022-06-22 14:00:44.003189
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    #Create object for the constructor
    collectionSearch = CollectionSearch()

    # Check the properties of CollectionSearch
    assert hasattr(collectionSearch, '_collections')
    assert hasattr(collectionSearch, '_load_collections')
    assert hasattr(collectionSearch, '_search_paths')
    assert hasattr(collectionSearch, 'NAME')
    assert hasattr(collectionSearch, '__init__')
    assert hasattr(collectionSearch, '_add_search_path')
    assert hasattr(collectionSearch, '_filter_collection_result')
    assert hasattr(collectionSearch, '_get_basename')
    assert hasattr(collectionSearch, '_get_collection_config')
    assert hasattr(collectionSearch, '_get_collection_name')
    assert hasattr(collectionSearch, '_get_collection_path')
   

# Generated at 2022-06-22 14:00:45.080971
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)

# Generated at 2022-06-22 14:00:45.541459
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

# Generated at 2022-06-22 14:00:46.995769
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert len(search._collections) == len(_ensure_default_collection())