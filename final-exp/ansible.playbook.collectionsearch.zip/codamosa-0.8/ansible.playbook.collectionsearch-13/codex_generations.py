

# Generated at 2022-06-22 13:51:14.189086
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    result = obj._load_collections(None, None)  # pylint: disable=protected-access
    assert result is not None

    result = obj._load_collections(None, '')  # pylint: disable=protected-access
    assert result is not None

    result = obj._load_collections(None, [])  # pylint: disable=protected-access
    assert result is not None

# Generated at 2022-06-22 13:51:17.342043
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = CollectionSearch()
    collections = ds._load_collections("collections", ["a.b.c"])
    assert collections == ["a.b.c", "ansible.builtin"]

# Generated at 2022-06-22 13:51:18.926266
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == {}


# Generated at 2022-06-22 13:51:20.296504
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        CollectionSearch()
    except Exception as e:
        print(e)

# Generated at 2022-06-22 13:51:30.137818
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    assert collection_search._collections._default is _ensure_default_collection

    attr = None
    ds = None

    # case None
    collection_load = collection_search._load_collections(attr, ds)
    assert collection_load is None

    # case []
    ds = []
    collection_load = collection_search._load_collections(attr, ds)
    assert collection_load is None

    # case ['ansible.builtin']
    ds = ['ansible.builtin']
    collection_load = collection_search._load_collections(attr, ds)
    assert collection_load == ['ansible.builtin']

# Generated at 2022-06-22 13:51:38.740807
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.AnsibleCollectionConfig.default_collection = 'ansible_namespace.collection_name'

    # Load collections, by CollectionSearch constructor
    s_ed = CollectionSearch()

    # Validate static value is being set only once
    assert s_ed._collections.static

    # Validate always_post_validate
    assert s_ed._collections.always_post_validate

    # Validate we are in fact getting back 'ansible_namespace.collection_name'
    # This is the value of default_collection
    assert s_ed._collections.default()[0] == 'ansible_namespace.collection_name'

    # Confirm static property of the field
    assert s_ed._collections.static

    # If we are setting

# Generated at 2022-06-22 13:51:46.175314
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Test1: No input
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()
    #Test2: Input is empty list
    cs = CollectionSearch(collections=[])
    assert cs.collections == _ensure_default_collection()
    #Test3: Input is list, contain default collection
    cs = CollectionSearch(collections=_ensure_default_collection())
    assert cs.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:51.613480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = {"collections": ["ansible_namespace.collection_name"]}

    class testClass(CollectionSearch):
        def __init__(self, ds):
            self._load_collections("collections", ds)
    obj = testClass(ds)
    assert obj._collections == ["ansible_namespace.collection_name"]

# Generated at 2022-06-22 13:51:54.732876
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Testing constructor
    collSearch = CollectionSearch()
    assert collSearch is not None
    assert collSearch._collections is not None
    assert collSearch._collections == _ensure_default_collection()


# Generated at 2022-06-22 13:52:06.362758
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import json
    import os
    import sys

    from ansible_collections.ansible_collections_company.collection1 import collection1
    from ansible.module_utils._text import to_bytes
    result = {}

    if not __file__.endswith('json'):
        os.chdir('test/units/module_utils/ansible_collections/ansible_collections_company/collection1')
        sys.path.append('../../../../..')

    test_instance = CollectionSearch()
    result['collections'] = test_instance._collections.value

    print(to_bytes(json.dumps({'failed': False, 'msg': result}, ensure_ascii=False, indent=4)))



# Generated at 2022-06-22 13:52:16.658520
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t.collections is None

    t = CollectionSearch(collections=['ansible.builtin'])
    assert t.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:52:26.048227
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import IncludeRole

    collections = ['test.collection', 'test.collection2']
    role_name = 'test'
    role_path = 'testpath/testrole'

    # test with list
    include_role = IncludeRole(role_name, collections=collections, role_path=role_path)
    assert include_role._collections == collections

    # test with non-existing list
    include_role = IncludeRole(role_name, collections=None, role_path=role_path)
    assert include_role._collections == ['ansible.builtin']

# Generated at 2022-06-22 13:52:28.662749
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs._collections, FieldAttribute)
    assert isinstance(cs._collections.default, type(cs._ensure_default_collection))
    assert isinstance(cs._collections.always_post_validate, bool)


# Generated at 2022-06-22 13:52:40.036496
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Test the value returned by _ensure_default_collection().
    assert cs._load_collections(None, ['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']
    assert cs._load_collections(None, ['my.test.collection', 'ansible.builtin']) == ['my.test.collection', 'ansible.builtin', 'ansible.legacy']
    assert cs._load_collections(None, ['ansible.builtin', 'my.test.collection']) == ['ansible.builtin', 'my.test.collection', 'ansible.legacy']
    # Test the case when collection_list is None.
    assert cs._load_collections(None, None) == ['ansible.legacy']

# Generated at 2022-06-22 13:52:43.656295
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert type(cs) == CollectionSearch
    assert cs._collections == _ensure_default_collection()
    print("test_CollectionSearch - passed")

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:52:47.170351
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # this tests that we can change the collection parameter
    search = CollectionSearch({'collections': ['test_collection']})
    assert search.collections == ['test_collection']


# Generated at 2022-06-22 13:52:57.162808
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # checking the case where the collection list is empty
    temp_class = type('temp_class', (object,), dict(_collections=dict()))
    collection_search = CollectionSearch()
    assert collection_search._load_collections(temp_class._collections, []) is None

    # checking the case where the collection list is not empty
    collection_list = ['ansible.builtin', 'ansible.legacy', 'mw.proxmox', 'mw.grafana', 'galaxy-admin.test_collection']
    assert collection_search._load_collections(temp_class._collections, collection_list) == collection_list

# Generated at 2022-06-22 13:53:00.053177
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch._collections._field_type, list)
    assert 'ansible.builtin' in _ensure_default_collection()

# Generated at 2022-06-22 13:53:07.395250
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    # sets the module_utils._collections property to
    # ansible.builtin ansible.legacy ansible_collections.notstdlib.moveit.plugins.module_utils
    assert c._collections[0] == 'ansible.builtin'
    assert c._collections[1] == 'ansible.legacy'
    assert c._collections[2] == 'ansible_collections.notstdlib.moveit.plugins.module_utils'
    assert len(c._collections) == 3

# Generated at 2022-06-22 13:53:10.512992
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    print(test._collections)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:53:28.806420
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c1_obj = CollectionSearch()

    # created object
    assert c1_obj

    # validate it has the collection
    assert c1_obj._collections == AnsibleCollectionConfig.default_collection

    # validate has required methods
    assert callable(getattr(c1_obj, '_load_collections', None))

# Generated at 2022-06-22 13:53:36.223428
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch._collections, FieldAttribute)
    assert len(CollectionSearch._collections.isa) == 1
    assert CollectionSearch._collections.isa[0] == 'list'
    assert len(CollectionSearch._collections.listof) == 1
    assert CollectionSearch._collections.listof[0] == string_types
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.always_post_validate
    assert CollectionSearch._collections.static

# Generated at 2022-06-22 13:53:38.472572
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._load_collections(None,None) is not None

# Generated at 2022-06-22 13:53:40.291726
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) == ['ansible.builtin']

# Generated at 2022-06-22 13:53:46.262875
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs=CollectionSearch()
    assert cs._collections.default() == ["ansible.builtin"]
    assert cs._collections.default(["ansible.posix"]) == ["ansible.posix"]
    assert cs._collections.default(["ansible.posix","ansible.builtin"]) == ["ansible.posix","ansible.builtin"]

# Generated at 2022-06-22 13:53:51.929956
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    #Test initialization of attributes
    assert isinstance(collectionSearch._collections,FieldAttribute)
    assert collectionSearch._collections.isa == 'list'
    assert collectionSearch._collections.listof == string_types
    assert collectionSearch._collections.priority == 100
    assert collectionSearch._collections.default == _ensure_default_collection
    assert collectionSearch._collections.static == True

# Generated at 2022-06-22 13:54:02.240181
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert type(collection_search).__name__ == 'CollectionSearch'
    assert type(collection_search.collections).__name__ == 'FieldAttribute'
    assert collection_search.collections.name == 'collections'
    assert collection_search.collections.isa == 'list'
    assert collection_search.collections.listof == string_types
    assert collection_search.collections.priority == 100
    assert collection_search.collections.default == _ensure_default_collection
    assert collection_search.collections.always_post_validate == True
    assert collection_search.collections.static == True
    assert collection_search.collections.optional == False



# Generated at 2022-06-22 13:54:07.179742
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection1 = CollectionSearch()
    assert collection1._collections == _ensure_default_collection()

    collection2 = CollectionSearch(collections=['new_collection'])
    assert collection2.collections == ['new_collection', 'ansible.builtin']

    collection3 = CollectionSearch(collections=None)
    assert collection3._collections == _ensure_default_collection()


# Generated at 2022-06-22 13:54:16.767231
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    import tempfile
    import pytest
    from ansible.playbook.play_context import PlayContext

    (fd, pb_path) = tempfile.mkstemp()

    with open(pb_path, "w") as pb_file:
        pb_file.write("""
        ---
        - hosts: localhost
          connection: local
          gather_facts: false
          collections:
            - test.my_collection
        """)

    # Create a collection in /tmp based on the test collection
    collection_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "units")
    test_dir = tempfile.mkdtemp(prefix="test_collections")
    collection_paths = [collection_dir, test_dir]
    collection_

# Generated at 2022-06-22 13:54:20.395501
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch.collections is not None
    assert isinstance(collectionSearch.collections, list)
    assert len(collectionSearch.collections) > 0
    assert collectionSearch.collections[0] == 'ansible.builtin'

# Generated at 2022-06-22 13:54:51.127851
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None
    assert isinstance(collection_search._collections, list)
    assert len(collection_search._collections) == 2

# Generated at 2022-06-22 13:54:56.657664
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # pylint: disable=unused-variable
    my_collection = type('CollectionSearch',
                         (CollectionSearch, object),
                         {})()
    x = my_collection._collections
    assert x.default == _ensure_default_collection()
    assert x.always_post_validate is True
    assert x.static is True
    assert x.listof is string_types
    assert x.priority == 100
    assert x.isa == 'list'
    assert x.name == 'collections'
    assert x.private == False
    assert x.parent is None

# Generated at 2022-06-22 13:54:59.528515
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Check to see if the class has been initialized with default values or not
    collection = CollectionSearch()
    assert collection._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:55:05.593600
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    t = CollectionSearch()
    t._collections = []
    t._collections = [
        'ansible.builtin',
        'my_namespace.my_collection',
        'ansible.netcommon'
    ]

    assert t.collections == t._load_collections(attr='collections', ds=t._collections)

# Generated at 2022-06-22 13:55:11.034273
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = {}
    data = {}
    res = CollectionSearch()
    res._load_collections(None, ds)
    assert(res._collections.default(data) == _ensure_default_collection())
    assert(len(res._collections.default(data)) == 1)
    assert(res._load_collections(None, ds) == _ensure_default_collection())

# Generated at 2022-06-22 13:55:12.114505
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.posix']

# Generated at 2022-06-22 13:55:22.418202
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    '''Unit test CollectionSearch'''
    module_name1 = 'test_CollectionSearch'
    collection_name1 = 'test_CollectionName'
    collection_name2 = 'test_CollectionName'
    test = CollectionSearch()
    assert test._load_collections(None, [module_name1]) == _ensure_default_collection([module_name1])
    assert test._load_collections(None, [module_name1, collection_name1]) == _ensure_default_collection([module_name1, collection_name1])
    assert test._load_collections(None, [module_name1, collection_name1, collection_name2]) == _ensure_default_collection([module_name1, collection_name1, collection_name2])

# Generated at 2022-06-22 13:55:26.518479
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert isinstance(collection_search.collections, FieldAttribute)
    #assert isinstance(collection_search.collections.default, func)

# Generated at 2022-06-22 13:55:28.873611
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    c._load_collections('collections', None)


# Generated at 2022-06-22 13:55:33.185213
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    output = c._load_collections(None, ["ansible.builtin","ansible.legacy"])
    assert output == ["ansible.builtin","ansible.legacy"]

# Check if default value would work without any collection name

# Generated at 2022-06-22 13:56:30.771831
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default(None) == _ensure_default_collection()
    assert collection_search._collections.default(None) == ['ansible.legacy']

# Generated at 2022-06-22 13:56:41.769461
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Default value for collections is correct
    assert CollectionSearch._collections.default() == [
        'ansible.builtin',
        'ansible.legacy'
    ]

    c = CollectionSearch()

    # Test the default value of collections if no value was specified
    assert c._collections == [
        'ansible.builtin',
        'ansible.legacy'
    ]

    # Test the value of collections if a value was specified
    with_specified_value = ['ansible.builtin', 'my_collection']
    c._collections = with_specified_value
    assert c._collections == with_specified_value

    # Test the value of collections if a value was specified with the default
    # value within

# Generated at 2022-06-22 13:56:46.477343
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()
    assert test_object is not None
    assert test_object._collections is not None
    assert test_object._collections.value is not None
    assert type(test_object._collections.value) is list
    assert len(test_object._collections.value) == 1


# Generated at 2022-06-22 13:56:49.801191
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Instantiate CollectionSearch with _collections param
    my_collection = CollectionSearch(collections=['ansible.builtin'])
    # Check if the static attribute _collections exists in the CollectionSearch object
    assert my_collection._collections is not None


# Generated at 2022-06-22 13:56:54.007886
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    colls = CollectionSearch()
    assert colls._collections is None
    # Test if _ensure_default_collection is working
    assert colls._collections == _ensure_default_collection()

# Test_load_collections

# Generated at 2022-06-22 13:56:56.927788
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_name = CollectionSearch()
    collection_name._load_collections('collections', [])
    assert collection_name._collections == 'ansible.legacy'

# Generated at 2022-06-22 13:56:58.762734
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    if not hasattr(collectionSearch, '_collections'):
        print("Fail to construct the CollectionSearch")

# Generated at 2022-06-22 13:57:00.391916
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible_collections.azure.azcollection']

# Generated at 2022-06-22 13:57:09.531910
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._validate_collections('ansible.builtin') == ['ansible.builtin']
    assert cs._validate_collections(['ansible.builtin', 'ansible.builtin.plugins']) == ['ansible.builtin', 'ansible.builtin.plugins']
    assert cs._validate_collections() == ['ansible.builtin']
    assert cs._validate_collections(None) == ['ansible.builtin']
    assert cs._validate_collections([]) == ['ansible.builtin']

# Generated at 2022-06-22 13:57:11.001669
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert not hasattr(instance, '_collections')



# Generated at 2022-06-22 13:59:03.703741
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _collection_search = CollectionSearch()

# Generated at 2022-06-22 13:59:07.998559
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ansible_test = CollectionSearch()

    # Test private access
    assert isinstance(ansible_test.get_validated_value('_collections', ansible_test._collections, None, None), list)

    # Test public access
    assert ansible_test._load_collections('_collections', None) is None

# Generated at 2022-06-22 13:59:09.324825
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-22 13:59:11.974913
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # FIXME: validate_collections() should be called first
    cs.post_validate(ds=[], var_name='collections')

# Generated at 2022-06-22 13:59:15.079705
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    c = collection_search._load_collections('', {})
    assert type(c) is list
    assert next(iter(c)) == 'ansible.builtin'

# Generated at 2022-06-22 13:59:16.454484
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test assertions
    assert(CollectionSearch() is not None)

# Generated at 2022-06-22 13:59:19.681190
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    for key in obj.__dict__.keys():
        assert key in ['_collections'], "Attribute %s is in the instance of CollectionSearch but is not defined in CollectionSearch" % key

# Unit test to see if the attributes of class CollectionSearch is same as defined above

# Generated at 2022-06-22 13:59:22.458556
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections.default == _ensure_default_collection()
    assert a._collections.isa == 'list'
    assert a._collections.listof == string_types
    assert a._collections.priority == 100
    assert a._collections.always_post_validate == True
    assert a._collections.static == True

# Generated at 2022-06-22 13:59:25.604446
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    d = {}
    assert c._load_collections(None, d) is None


# Generated at 2022-06-22 13:59:30.226335
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a is not None
    assert len(a._collections.validators) == 1
    assert len(a._collections.always_post_validate) == 1
    assert len(a.field_names) == 1
    assert len(a._fields) == 1
    assert len(a._field_names_and_types) == 1