

# Generated at 2022-06-22 13:51:05.823306
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:12.555596
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections._priority == 100
    assert a._collections._is_static_value == True
    assert a._collections.invalid("{{ hostvars['localhost']['ansible_facts']['distribution'] }}") == False
    assert a._collections.invalid("") == False


# Generated at 2022-06-22 13:51:24.532030
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.__post_validate__({'collections': ['ansible.builtin']})
    assert cs.collections == ['ansible.builtin']

    cs = CollectionSearch()
    cs.__post_validate__({'collections': ['ansible_namespace.collection_name']})
    assert cs.collections == ['ansible_namespace.collection_name']

    cs = CollectionSearch()
    cs.__post_validate__({'collections': ['ansible.builtin', 'ansible_namespace.collection_name']})
    assert cs.collections == ['ansible.builtin', 'ansible_namespace.collection_name']

    cs = CollectionSearch()

# Generated at 2022-06-22 13:51:27.215074
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Test the constructor of class CollectionSearch
    """
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()


# Generated at 2022-06-22 13:51:28.464680
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ('ansible.builtin',)

# Generated at 2022-06-22 13:51:30.684189
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default(None) == _ensure_default_collection()

# Generated at 2022-06-22 13:51:39.070435
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role import Role
    from ansible.playbook.role.task import Task
    from ansible.playbook.role.include import Include
    from ansible.playbook.tasks import Task as BaseTask
    from ansible.playbook.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    import ansible.playbook.play_context

    env = Environment()
    tmp = Templar(loader=None, variables=(), shared_loader_obj=env.loader)

    app = CollectionSearch()
    assert app._collections is not None
    assert app._collections == _ensure_default_collection()

    attr = {}
    ds = []


# Generated at 2022-06-22 13:51:44.328178
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    test_CollectionSearch.post_validate()
    # TODO: Add tests to validate the collection_list with the name "ansible.builtin" or "ansible.legacy"
    #       is always present in the collection_list and the default collection is also present
    #     

# Generated at 2022-06-22 13:51:47.188358
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections == ['ansible_collections.nsxt.components.ansible_module_nsxt_ns_service_components.plugins']

# Generated at 2022-06-22 13:51:58.492605
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Fail case
    coll_search = CollectionSearch()
    coll_search._collections = 'ansible.builtin'
    defaults = coll_search._collections.post_validate(coll_search, 'collections')
    assert defaults == ['ansible.builtin']
    assert coll_search.collections == ['ansible.builtin']

    # Pass case
    coll_search = CollectionSearch()
    coll_search._collections = ['ansible.builtin', 'ansible.legacy']
    defaults = coll_search._collections.post_validate(coll_search, 'collections')
    assert defaults == ['ansible.builtin', 'ansible.legacy']
    assert coll_search.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:52:06.363137
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("CollectionSearch test passed")

# Generated at 2022-06-22 13:52:07.404752
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    checks = CollectionSearch()
    assert checks._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:52:11.533882
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = CollectionSearch()
    # test initialize
    ds.collections = ['collection-name']
    assert ds.collections == ['collection-name']

    # test load_collections()
    ds.collections = None
    res = ds._load_collections(attr='collections', ds=None)
    assert res is None

# Generated at 2022-06-22 13:52:14.015747
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible_ansible_collection']

# Generated at 2022-06-22 13:52:16.411610
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # pass
    f = CollectionSearch()
    f.collections = ['collections.nsxt']
    f.post_validate(from_task=False)
    assert f.collections == ['collections.nsxt', 'ansible.builtin']
    # fail
    f = CollectionSearch()
    f.collections = ['collections.nsxt', 'ansible.builtin']
    f.post_validate(from_task=False)
    assert f.collections == None

# Generated at 2022-06-22 13:52:18.651480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-22 13:52:21.299480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections(None) == _ensure_default_collection()


# Generated at 2022-06-22 13:52:23.933284
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    actual_result = collection_search._load_collections("collections", ["ansible.posix"])
    expected_result = ["ansible.posix", "ansible.legacy"]
    assert actual_result == expected_result

# Generated at 2022-06-22 13:52:25.714810
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ['ansible.builtin']

# Generated at 2022-06-22 13:52:27.213389
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is not None

# Generated at 2022-06-22 13:52:36.280669
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert 'ansible.builtin' == cs._load_collections('collections', [])[0]

# Generated at 2022-06-22 13:52:48.383525
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

    # Calling get_validated_value for a string without template
    # will return the same string
    result = cs.get_validated_value('collections', cs._collections, 'ansible.builtin', None)
    assert result == 'ansible.builtin'

    # Calling with a list of strings should return a list 
    result = cs.get_validated_value('collections', cs._collections, ['ansible.builtin'], None)
    assert result == ['ansible.builtin']

    # Test _load_collections function when collection_list is None
    result = cs._load_collections('collections', None)
    assert result == cs._collections 

    # Test _load_collections function when collection_

# Generated at 2022-06-22 13:52:52.818156
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    # Test init of the attributes

    # Test the post_validate method
    collection.set_data({'collections': None})
    display.visible.collections = True
    _ensure_default_collection(collection.get_data())

# Generated at 2022-06-22 13:52:55.557900
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == ['ansible_collections.sensu.sensu_go.plugins', 'ansible.legacy']

# Generated at 2022-06-22 13:52:57.412476
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections is None

# Generated at 2022-06-22 13:53:04.643915
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert result._collections.default == ['ansible.posix.windows']
    result = CollectionSearch(collections=['ansible.posix.windows', 'test'])
    assert result._collections.default == ['test', 'ansible.posix.windows']
    result = CollectionSearch(collections=['test'])
    assert result._collections.default == ['test', 'ansible.posix.windows']
    result = CollectionSearch(collections=[])
    assert result._collections.default == ['ansible.posix.windows']

# Generated at 2022-06-22 13:53:10.237626
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class MyClass(CollectionSearch):
        pass

    class MyClass2(CollectionSearch):
        def __init__(self):
            self.collections = ['ansible_col']

    my_class = MyClass()
    assert my_class.collections == ['ansible.builtin', 'ansible.legacy']

    my_class2 = MyClass2()
    assert my_class2.collections == ['ansible_col', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:53:15.363599
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()
    assert c._load_collections("_collections","my-collections") == None
    assert c._collections == _ensure_default_collection(["my-collections"])

# Generated at 2022-06-22 13:53:19.504264
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create a new instance of CollectionSearch class
    collection_search = CollectionSearch()
    # Collections should be a list of string
    assert isinstance(collection_search._collections, list)
    for collection in collection_search._collections:
        assert isinstance(collection, string_types)



# Generated at 2022-06-22 13:53:32.190149
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    b = Block()
    col = CollectionSearch()
    assert col._collections == _ensure_default_collection()
    assert col.attributes._load_field_attributes['collections'] is col._collections

    env = Environment()
    # If the collection name is not a template then display warning
    col.collections = ['ansible.builtin', 'ansible.legacy', 'ansible.builtin']
    assert col.get_validated_value('collections', col._collections, col.collections, None) == ['ansible.builtin', 'ansible.legacy']
    # If the collection name is a template then it is not templated and not
    #  displayed the warning

# Generated at 2022-06-22 13:53:45.912164
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-22 13:53:52.369411
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext

    test = TaskQueueManager()
    test_pb = PlayContext()
    test.play_context = test_pb
    test_collection = CollectionSearch()
    test_collection._load_collections('collections', ['ansible.builtin'])
    test_collection._collections = None
    test_collection._load_collections('collections', None)

# Generated at 2022-06-22 13:53:55.487520
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections is None
    assert CollectionSearch(collections=['a']).collections == ['a', 'ansible.builtin']

# Generated at 2022-06-22 13:53:59.531347
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cls = CollectionSearch()
    cls._collections = _ensure_default_collection()

    if type(cls._collections) is list:
        print ("Pass")
    else:
        print ("Fail")
    
test_CollectionSearch()

# Generated at 2022-06-22 13:54:04.041699
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    test_display = Display()
    setattr(collection_search, 'display', test_display)
    collection_search.post_validate({'collections': ['ansible.builtin', 'ansible.posix']}, None)

# Generated at 2022-06-22 13:54:04.649120
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()

# Generated at 2022-06-22 13:54:06.006708
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	obj = CollectionSearch()
	assert obj is not None

# Generated at 2022-06-22 13:54:06.958816
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections

# Generated at 2022-06-22 13:54:09.341055
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == ['ansible.builtin']
    assert obj._collections == ['ansible.builtin']


# Generated at 2022-06-22 13:54:10.421123
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:54:26.110866
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(None, None) == _ensure_default_collection()

# Generated at 2022-06-22 13:54:28.433882
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:54:32.396780
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert 'ansible.builtin' in test._load_collections('collections', ['foo', 'foo.bar'])
    assert 'ansible.legacy' in test._load_collections('collections', ['foo', 'foo.bar'])
    assert 'ansible.legacy' in test._load_collections('collections', None)

# Generated at 2022-06-22 13:54:36.401807
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert(cs._collections.default == ['ansible_collections.ansible.builtin'])

# Generated at 2022-06-22 13:54:38.999064
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    a.collections = ['collection1']
    assert len(a.collections) == 1
    assert a.collections[0] == 'collection1'

# Generated at 2022-06-22 13:54:39.921872
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test constructor
    collection_search = CollectionSearch()

# Generated at 2022-06-22 13:54:41.057823
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch != None


# Generated at 2022-06-22 13:54:41.627087
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-22 13:54:45.505206
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible_collections.ansible.builtin.plugins.module_utils.network.common.utils import CollectionSearch

    cs = CollectionSearch()

    # Check if default collection attribute is correctly set
    assert cs._collections == ['ansible.netcommon'], 'Default collections not set correctly!'

# Generated at 2022-06-22 13:54:48.286573
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default == _ensure_default_collection

# Generated at 2022-06-22 13:55:19.730494
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # When:
    search = CollectionSearch(collections=None)
    # Then:
    assert search.collections == ['ansible.builtin']

    # When:
    search = CollectionSearch(collections=['my_collection'])
    # Then:
    assert search.collections == ['my_collection', 'ansible.builtin']

# Generated at 2022-06-22 13:55:27.416767
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude

    # Normal usage with collections specified
    search = CollectionSearch()
    search.collections = ['my_collection', 'my_other_collection']
    collections = search._load_collections('collections', search.collections)
    assert collections == ['my_collection', 'my_other_collection']

    # Normal usage without collections specified
    search = CollectionSearch()
    collections = search._load_collections('collections', search.collections)
    assert collections is None

    # We support builtin, so this should work
    search = TaskInclude()
    assert search.collections == ['ansible.builtin']

    # We support legacy, so this should work
    search = RoleInclude()
    assert search

# Generated at 2022-06-22 13:55:34.524456
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()

    # check if the given value is returned
    assert x.get_validated_value('collections', x._collections, [], None) == []

    # check if the default returned value is a string
    assert isinstance(x.get_validated_value('collections', x._collections, None, None), str)

    # check if the default returned value is a list
    assert isinstance(x._load_collections('collections', None), list)

# Generated at 2022-06-22 13:55:41.875481
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import json

    c = CollectionSearch()
    d = c._collections
    n = d.name
    #  c._load_collections(attr=None, ds=None)
    print(isinstance(c,CollectionSearch))
    # test class filed
    print(isinstance(d,FieldAttribute))
    print(isinstance(d.default,type(_ensure_default_collection)))

    #  test default of field
    ret = d.default
    print(isinstance(ret,type(_ensure_default_collection)))
    print(isinstance(ret(),list))
    #  test default method
    ret = _ensure_default_collection()
    print(ret)
    # test load_collections
    ret = c._load_collections(attr=None, ds=None)
    print(ret)



# Generated at 2022-06-22 13:55:45.347678
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch()._collections, FieldAttribute)
    assert CollectionSearch()._collections.isa == 'list'
    assert CollectionSearch()._collections.listof == string_types
    assert CollectionSearch()._collections.priority == 100
    assert CollectionSearch()._collections.default == _ensure_default_collection
    assert CollectionSearch()._collections.always_post_validate == True
    assert CollectionSearch()._collections.static == True

# Generated at 2022-06-22 13:55:46.945664
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search._collections)

test_CollectionSearch()

# Generated at 2022-06-22 13:55:57.016679
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.become import Become
    from ansible.playbook.group import Group

    default_collection = AnsibleCollectionConfig.default_collection
    assert default_collection is not None

    # test base
    base_collection = Base(dict(_collections=None))
    assert base_collection._collections == [default_collection, 'ansible.legacy']
    base_collection = Base(dict(_collections=[]))
    assert base_collection._collections == [default_collection, 'ansible.legacy']
    base_collection = Base(dict(_collections=['ansible.builtin']))
    assert base

# Generated at 2022-06-22 13:55:59.295207
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # should be empty
    assert CollectionSearch._collections.default() == _ensure_default_collection()

# Generated at 2022-06-22 13:56:10.411542
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    # Test if _collections is set to default value of _ensure_default_collection()
    assert collection._collections == "ansible.builtin"
    assert collection._collections == "ansible.legacy"
    assert collection._collections == "ansible.builtin"
    # Test if _collections is a list
    assert isinstance(collection._collections, list)
    assert "ansible.builtin" in collection._collections
    assert "ansible.legacy" in collection._collections
    assert "ansible.builtin" in collection._collections
    # Test if _collections is not empty
    assert len(collection._collections) > 0
    # Test if _collections is a list of string
    assert all(isinstance(item, str) for item in collection._collections)


# Generated at 2022-06-22 13:56:12.432897
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)


# Generated at 2022-06-22 13:57:09.654623
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    spec = {'collections': [], 'key': 'value'}

    # initialize a class
    test_class = CollectionSearch()

    # check the constructor of the class
    assert test_class.__class__.__name__ == 'CollectionSearch'

# Generated at 2022-06-22 13:57:11.714135
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert repr(CollectionSearch()) == '<CollectionSearch (collections=None)>'

# Generated at 2022-06-22 13:57:14.693893
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:57:16.649241
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch(collections=["collection1"]).collections == ["collection1"]

# Generated at 2022-06-22 13:57:22.517754
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test 2: Collection list is empty
    test_obj1 = CollectionSearch()
    assert sorted(test_obj1._load_collections(attr=None,ds=[])) == ['ansible.legacy']

    # Test 3: Collection list is not empty
    test_obj2 = CollectionSearch()
    assert sorted(test_obj2._load_collections(attr=None,ds=['ansible.collections.my_collection'])) == [
        'ansible.collections.my_collection', 'ansible.legacy']

# Generated at 2022-06-22 13:57:25.934892
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an object of class CollectionSearch.
    cs = CollectionSearch()

    # Get the value of the variable _collections and store the result in variable x.
    x = cs._collections

    # Perform a predicate test asserting that the variable x is not None.
    assert x is not None

# Generated at 2022-06-22 13:57:31.073115
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == cs._load_collections(None, None)
    assert cs._collections == ['ansible_collections.somerandomname.somewhere']
    assert cs._collections == cs.post_validate({}, 'collections', cs._collections)

# Generated at 2022-06-22 13:57:32.523035
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch, object)

# Generated at 2022-06-22 13:57:35.368783
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch(collections=['ansible.builtin', 'ansible.kubernetes'])
    assert obj._collections == ['ansible.builtin', 'ansible.kubernetes']

# Generated at 2022-06-22 13:57:38.734161
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    base = AnsibleCollectionConfig()
    base._collections = None
    base.collections = ['ttt']
    assert base.collections == ['ttt']

# Generated at 2022-06-22 13:59:40.926542
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_finder = CollectionSearch()
    valid_collections_list = ['test_collection_1', 'test_collection_2']
    default_collections_list = ['ansible.builtin', 'ansible.legacy', 'test_collection_1', 'test_collection_2']

    # test with only the default collection
    test_finder.collections = None
    assert test_finder.collections == ['ansible.builtin', 'ansible.legacy']

    # test with explicitly given collections
    test_finder.collections = valid_collections_list
    assert test_finder.collections == default_collections_list

    # test with given collections and default collection
    test_finder.collections = default_collections_list
    assert test_finder.collections == default_collections_list

    # test with invalid collection


# Generated at 2022-06-22 13:59:43.359396
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default(_ensure_default_collection)

# Generated at 2022-06-22 13:59:53.423539
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.attribute import Attribute
    Attribute.initialize()

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import IncludeTask

    # test constructor of RoleDefinition

# Generated at 2022-06-22 13:59:57.523370
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test = CollectionSearch()
        assert test._collections == _ensure_default_collection(), 'test variable must be declared to run the tests'
        assert test._collections == test._load_collections(test._collections, test._collections), 'test variable must be declared to run the tests'
    except:
        print('There was some unexpected error')

# Generated at 2022-06-22 13:59:59.698587
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection

# Generated at 2022-06-22 14:00:00.226712
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-22 14:00:01.466283
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _CollectionSearch = CollectionSearch()
    assert(_CollectionSearch is not None)

# Generated at 2022-06-22 14:00:03.080272
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch.collections._default == _ensure_default_collection

# Generated at 2022-06-22 14:00:05.158587
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-22 14:00:08.457152
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class Test(CollectionSearch):
        pass

    default_collection = AnsibleCollectionConfig.default_collection
    test = Test()
    assert test._collections.default == [default_collection]