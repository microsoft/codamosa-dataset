

# Generated at 2022-06-22 13:51:09.030143
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():    
    test_obj = CollectionSearch()

    assert hasattr(test_obj, '_collections')


# Generated at 2022-06-22 13:51:12.903196
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    if instance._collections != ['ansible_collections.ansible.builtin']:
        raise AssertionError("Failed to initialize CollectionSearch")
    return True

# Generated at 2022-06-22 13:51:17.940265
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """ Test for collection search"""

    # Test case for default constructor
    cs = CollectionSearch()
    assert cs._collections._contents is None

    # Test case for constructor with params
    cs = CollectionSearch(collections=['collection1'])
    assert cs._collections._contents == ['collection1']
    assert cs._collections._validated_data is None

# Generated at 2022-06-22 13:51:20.163260
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch._collections == _ensure_default_collection()



# Generated at 2022-06-22 13:51:23.797800
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    value = CollectionSearch()
    assert(isinstance(value._collections, list))
    assert(len(value._collections) == 1)
    assert(value._collections[0] == 'ansible.internal.collection')

# Generated at 2022-06-22 13:51:25.814958
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == ["ansible_collections.ansible.builtin"]


# Generated at 2022-06-22 13:51:27.474416
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(None, []) == _ensure_default_collection()

# Generated at 2022-06-22 13:51:34.540521
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Test for setter of _collections
    cs.collections = ['test1', 'test2']
    assert cs.collections == ['test1', 'test2']

    # Test for getter of _collections
    assert cs._collections is not None

    # Test for _load_collections()
    assert cs._load_collections(None, None) == ['test1', 'test2']

    # Test for default value of _collections
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:35.272191
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   ds = CollectionSearch()
   assert ds

# Generated at 2022-06-22 13:51:45.050928
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest

    class CollectionSearchTest(unittest.TestCase):

        def test_invalid_collections(self):
            collection_search = CollectionSearch()
            with self.assertRaises(ValueError):
                collection_search.set_data({'collections': []})
            with self.assertRaises(ValueError):
                collection_search.set_data({'collections': 'something'})
            with self.assertRaises(ValueError):
                collection_search.set_data({'collections': ['foo', 42]})

    unittest.main()

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:51:55.467088
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test.collections == _ensure_default_collection()
    assert test._collections == _ensure_default_collection()
    test.collections = ['nsweb.test']
    assert test.collections == ['nsweb.test']

# Generated at 2022-06-22 13:52:02.223732
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections(None, []) == _ensure_default_collection()
    assert collection_search._load_collections(None, ['windows.microsoft.windows.win_package']) == [
        'windows.microsoft.windows.win_package', 'ansible.legacy']


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:52:04.605900
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default == _ensure_default_collection

# Generated at 2022-06-22 13:52:05.951854
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()
    collection_name =  collection_search._load_collections('collections', ['ansible.builtin', 'ansible.legacy'])
    assert collection_name == None

# Generated at 2022-06-22 13:52:08.896744
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    display.display(str(collection_search._collections))
    display.display(str(collection_search._collections.value))

# Generated at 2022-06-22 13:52:12.193805
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.__class__.__name__ == 'CollectionSearch'
    assert collection_search.__class__.__bases__ == (object,)
    assert hasattr(collection_search, '_collections')

# Generated at 2022-06-22 13:52:13.749713
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-22 13:52:15.725451
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Action should fail without
    with pytest.raises(AttributeError):
        CollectionSearch()

# Generated at 2022-06-22 13:52:19.539932
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    test_value = ['foo','bar']
    search.collections = test_value
    assert search.collections == test_value
    search2 = CollectionSearch()
    assert search2.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:52:24.148198
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = object()
    test_attr = object()
    test_ds = object()
    test_collections_search = CollectionSearch()
    assert test_collections_search._load_collections(test_attr, test_ds) == None

# Generated at 2022-06-22 13:52:38.262242
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections is None

# Generated at 2022-06-22 13:52:42.029265
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert collection_search._collections is not None
    assert collection_search._collections() == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:52:43.216840
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass


# Generated at 2022-06-22 13:52:47.613991
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    try:
        assert c._collections is not None
    except AssertionError:
        print("_collections is None.")

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:52:49.388500
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection(collection_list=['ansible_namespace.collection']) == ['ansible_namespace.collection', 'ansible.builtin']

# Generated at 2022-06-22 13:52:51.960068
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections_search_obj = CollectionSearch()
    assert collections_search_obj._collections is None
    assert collections_search_obj._data is None

# Generated at 2022-06-22 13:52:54.073709
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # assert that the _collections field is populated
    assert CollectionSearch._collections.default

# Generated at 2022-06-22 13:52:55.952405
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is _ensure_default_collection

# Generated at 2022-06-22 13:53:07.196076
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test collection_list with AnsibleCollectionConfig and simple list
    collection_list_none = None
    collection_list_legacy = ['ansible.builtin', 'ansible.legacy']
    collection_list_default = ['ansible.builtin', 'community.general']
    collection_list_default_with_legacy = ['ansible.builtin', 'community.general', 'ansible.legacy']
    collection_list_with_empty = ['ansible.builtin', 'community.general', 'ansible.legacy', None]
    collection_list_with_empty_none = ['ansible.builtin', 'community.general', 'ansible.legacy', None, None]

# Generated at 2022-06-22 13:53:14.527910
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch(collections=['ansible.builtin', 'ansible.legacy', 'nsxt_edge_nodes'])
    assert 'ansible.builtin' in search.collections
    assert 'ansible.legacy' in search.collections
    assert 'nsxt_edge_nodes' in search.collections
    assert len(search.collections) == 3

# Generated at 2022-06-22 13:53:29.283565
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    tester = CollectionSearch()
    assert tester._collections.default == _ensure_default_collection(collection_list=None)

# Generated at 2022-06-22 13:53:31.244724
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        cs = CollectionSearch()
    except NameError as e:
        assert False
    assert cs

# Generated at 2022-06-22 13:53:34.256569
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._load_collections is not None
# end Unit test


if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-22 13:53:38.471901
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
        Constructor of class CollectionSearch is tested.
    """
    try:
        cs = CollectionSearch()

    except Exception as e:
        raise AssertionError('CollectionSearch() constructor fails with error: %s' % e)



# Generated at 2022-06-22 13:53:39.878554
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None


# Generated at 2022-06-22 13:53:44.400746
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Play(CollectionSearch):
        field_one = FieldAttribute(isa='int', default=5)
        field_two = FieldAttribute(isa='str')

    play = Play()
    assert play.field_one == 5
    assert play.field_two is None

# Generated at 2022-06-22 13:53:47.162100
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_search = CollectionSearch()
    assert coll_search._collections == [AnsibleCollectionConfig.default_collection, 'ansible.legacy']

# Generated at 2022-06-22 13:53:49.010474
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert getattr(obj, 'collections') == ['ansible.builtin']

# Generated at 2022-06-22 13:53:51.017103
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

if __name__ == "__main__":
    cs = CollectionSearch()

# Generated at 2022-06-22 13:53:53.621922
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Obj(CollectionSearch):
        collections = ["foo"]

    obj = Obj()
    assert obj.collections == ["foo"]

# Generated at 2022-06-22 13:54:20.664623
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    if display is None:
        raise AssertionError(display)



# Generated at 2022-06-22 13:54:22.236433
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == [AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-22 13:54:25.089508
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    res = CollectionSearch()._load_collections(None, ["my.collection"])
    assert res == ["my.collection", "ansible.builtin"]

# Generated at 2022-06-22 13:54:28.717959
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search=CollectionSearch()
    search._load_collections("collections","abc.def")
    assert search._collections == ["abc.def", "ansible.builtin"]

# Generated at 2022-06-22 13:54:32.325979
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # create a new object using CollectionSearch class
    collection_search_obj = CollectionSearch()
    collection_search_obj.collections = ['namespace.collection']
    assert collection_search_obj.collections == ['namespace.collection']
    collection_search_obj.collections = None
    assert collection_search_obj.collections is None

# Generated at 2022-06-22 13:54:44.715284
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.executor.task_queue_manager import TaskQueueManager
    if hasattr(TaskQueueManager, '_collections'):
        TaskQueueManager._collections.default = False
    else:
        TaskQueueManager._collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=False,
                                                       always_post_validate=True, static=True)

    from ansible.playbook.role.definition import RoleDefinition
    if hasattr(RoleDefinition, '_collections'):
        RoleDefinition._collections.default = False
    else:
        RoleDefinition._collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=False,
                                                     always_post_validate=True, static=True)


# Generated at 2022-06-22 13:54:49.713957
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    if collection._collections != AnsibleCollectionConfig.default_collection:
        raise AssertionError('Test failed: _collection parameter is not set correctly')

# Generated at 2022-06-22 13:54:51.359102
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    c = CollectionSearch()

    assert c._collections.default == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-22 13:54:52.559092
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.post_validate()

# Generated at 2022-06-22 13:54:54.896468
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   collection_search = CollectionSearch()
   assert collection_search.collections == ['ansible_ansible_collections.sensu.sensu_go', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:55:45.348657
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-22 13:55:45.880152
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

# Generated at 2022-06-22 13:55:47.293013
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    ds = ['ansible']
    result = test._load_collections('collections', ds)
    assert result == ['ansible']

# Generated at 2022-06-22 13:55:48.960389
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:55:51.146209
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:55:52.952496
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This is a test, so just check that the constructor doesn't die
    coll = CollectionSearch()

# Generated at 2022-06-22 13:55:56.921883
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Initialize class object that extends CollectionSearch
    class MyClass(CollectionSearch):
        pass

    # Check that the list of collections is returned
    assert(MyClass()._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin'])
    assert(MyClass()._load_collections('collections', []) == ['ansible.legacy'])

# Generated at 2022-06-22 13:56:04.606444
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection([]) == ['ansible.builtin']
    assert _ensure_default_collection(['ansible.builtin']) == ['ansible.builtin']
    assert _ensure_default_collection(['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']
    assert _ensure_default_collection(['community.general']) == ['community.general', 'ansible.legacy']

# Generated at 2022-06-22 13:56:05.249809
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = _ensure_default_collection()
    assert result is not None

# Generated at 2022-06-22 13:56:12.920672
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._collections == ['ansible.builtin']
    cs = CollectionSearch(collections=['ansible.builtin'])
    assert cs._collections is not None
    assert cs._collections == ['ansible.builtin']
    cs = CollectionSearch(collections=['ansible.not_there', 'ansible.builtin'])
    assert cs._collections is not None
    assert cs._collections == ['ansible.builtin', 'ansible.not_there']

# Generated at 2022-06-22 13:57:57.013333
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_search = CollectionSearch()
    assert test_search.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:58:03.612825
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test:
        def __init__(self, ds):
            self.collections = CollectionSearch()
            self.collections.post_validate([], ds)

    t1 = Test(ds=None)
    assert t1.collections._collections == _ensure_default_collection()

    t2 = Test(ds=['collection1'])
    assert t2.collections._collections == ['collection1']

# Generated at 2022-06-22 13:58:12.529238
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CS(CollectionSearch):
        pass

    cs = CS()
    cs.collections = 'ansible.builtin'
    assert cs.collections == ['ansible.builtin']

    assert cs._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']

    cs.collections = 'ansible.builtin, ansible.posix'
    assert cs.collections == ['ansible.builtin', 'ansible.posix']

    assert cs._load_collections(None, ['ansible.builtin', 'ansible.posix']) == ['ansible.builtin', 'ansible.posix']

# Generated at 2022-06-22 13:58:14.570489
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()

# Generated at 2022-06-22 13:58:16.449130
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cls = CollectionSearch()
    assert cls._collections is not None

# Generated at 2022-06-22 13:58:17.662807
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testObj = CollectionSearch()
    print(testObj.__dict__)

# Generated at 2022-06-22 13:58:23.650586
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c1 = CollectionSearch()
    c1._load_collections(None, [])
    c1._load_collections(None, ["ansible_namespace.collection"])
    c1._load_collections(None, ["ansible.builtin"])
    c1._load_collections(None, ["ansible.module_utils"])
    c1._load_collections(None, ["ansible.builtin", "ansible.module_utils"])
    c1._load_collections(None, ["ansible_namespace.collection", "ansible.builtin", "ansible.module_utils"])
    c1._load_collections(None, None)
    c1._load_collections(None, ["ansible_namespace.collection", "ansible.module_utils"])

# Generated at 2022-06-22 13:58:25.058262
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch(collections=['swan.tasks'])

# Generated at 2022-06-22 13:58:34.491705
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    default_collections = CollectionSearch._collections.get_default_value(static=True)
    #default_collections = CollectionSearch._collections.get_default_value(static=True)
    #assert(default_collections=None)
    #assert(type(default_collections) == list)
    #assert('ansible.builtin' in default_collections)
    #assert('ansible.legacy' in default_collections)
    assert(default_collections is not None)
    #assert('ansible.builtin' in default_collections)
    assert('ansible.legacy' in default_collections)
    #class_instance = CollectionSearch(default_collections, [])
    class_instance = CollectionSearch(**{'collections': default_collections})
    class_instance_ds = class_

# Generated at 2022-06-22 13:58:39.340202
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    test_CollectionSearch.collections = ['test_namespace.test_collection', 'ansible.builtin']
    test_CollectionSearch._load_collections('collections', test_CollectionSearch._collections.post_validate(test_CollectionSearch, 'collections'))