

# Generated at 2022-06-22 13:51:10.198508
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.value is not None
    assert 'ansible.builtin' in collection_search._collections.value or 'ansible.legacy' in collection_search._collections.value
    assert collection_search._collections.value[0] == 'ansible.builtin'

# Generated at 2022-06-22 13:51:12.195427
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection(collection_list = None) is not None

# Generated at 2022-06-22 13:51:14.141729
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:51:26.751881
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create a CollectionSearch instance
    cs = CollectionSearch()
    # Check if the value of _collections is None
    assert cs._collections is None
    # Check if the value of _collections is equal to ['ansible.builtin']
    cs._collections = ['ansible.builtin']
    assert cs._collections == ['ansible.builtin']
    # Check if the value of _collections is equal to ['ansible.legacy']
    cs._collections = ['ansible.legacy']
    assert cs._collections == ['ansible.legacy']
    # Check if the value of _collections is equal to ['ansible.builtin','ansible.legacy']
    cs._collections = ['ansible.builtin','ansible.legacy']

# Generated at 2022-06-22 13:51:27.974660
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:51:32.502917
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    collection_search = CollectionSearch()

    # Populate the _collections field
    collection_search._collections(play_context, None)

    assert collection_search._ds['collections'] is None

# Generated at 2022-06-22 13:51:33.126172
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert isinstance(collection, CollectionSearch)

# Generated at 2022-06-22 13:51:33.786762
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:35.001678
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert len(_ensure_default_collection()) == 1

# Generated at 2022-06-22 13:51:45.100117
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ds = cs._load_collections(None, ['ansible.builtin', 'ansible_collections.test.test_collection'])
    assert ds == ['ansible_collections.test.test_collection', 'ansible_collections.ansible.builtin', 'ansible.builtin']

    ds = cs._load_collections(None, ['ansible_collections.test.test_collection', 'ansible.builtin'])
    assert ds == ['ansible_collections.test.test_collection', 'ansible_collections.ansible.builtin', 'ansible.builtin']


# Generated at 2022-06-22 13:51:52.202957
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_collection = CollectionSearch()

    # check the constructor's result
    assert search_collection._collections == ['ansible_collections.test.test_collection','ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:51:55.520629
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = CollectionSearch()
    assert type(ds) == CollectionSearch
    assert ds._collections is _ensure_default_collection
    assert ds._collections() is _ensure_default_collection()

# Generated at 2022-06-22 13:51:57.777500
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections("collections", "_ensure_default_collection") == ['ansible.netcommon']

# Generated at 2022-06-22 13:51:59.331780
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections  == ['ansible.builtin']

# Generated at 2022-06-22 13:52:01.173090
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:52:02.944646
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default() == _ensure_default_collection()

# Generated at 2022-06-22 13:52:04.803782
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-22 13:52:10.740472
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Dummy:
        def __init__(self):
            self.collections = None

    d = Dummy()
    c = CollectionSearch()
    c.post_validate(d, "collections", [])
    assert d.collections == []

    d = Dummy()
    c.post_validate(d, "collections", None)
    assert d.collections == ['ansible_collections.ansible.builtin']

# Generated at 2022-06-22 13:52:14.165436
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj=CollectionSearch()
    assert not hasattr(obj, '_collections')
    assert obj.to_simple(obj.to_data()) == obj.to_data()

# Generated at 2022-06-22 13:52:15.670884
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    print(x)


# Generated at 2022-06-22 13:52:23.934866
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is not None
    #assert c.collections is not None

# Generated at 2022-06-22 13:52:26.998723
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj)


if __name__ == '__main__':
    # Unit test for class CollectionSearch
    test_CollectionSearch()

# Generated at 2022-06-22 13:52:29.323624
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert isinstance(test_obj.collections, list)
    assert len(test_obj.collections) == 1

# Generated at 2022-06-22 13:52:31.744364
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == _ensure_default_collection()


# Generated at 2022-06-22 13:52:33.751769
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert(a.collections == _ensure_default_collection.default)

# Generated at 2022-06-22 13:52:45.120282
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #
    # case: a collection list is not provided
    #
    # expected: we get a list containing a single element, the default
    #           collection
    #
    cs = CollectionSearch()
    assert cs.collections == [AnsibleCollectionConfig.default_collection]

    #
    # case: a collection list is provided, but no elements match the default
    #
    # expected: we get a list containing the default collection in the first
    #           position, followed by the provided collections
    #
    cs = CollectionSearch(collections=['foo.bar', 'baz.quz'])
    assert cs.collections == [AnsibleCollectionConfig.default_collection, 'foo.bar', 'baz.quz']

    #
    # case: a collection list is provided and the first element matches the
    #       default collection


# Generated at 2022-06-22 13:52:51.758693
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search._collections, FieldAttribute)
    assert collection_search._collections.isa == 'list'
    assert collection_search._collections.listof == string_types
    assert collection_search._collections.priority == 100
    assert collection_search._collections.always_post_validate == True
    assert collection_search._collections.static == True

# Generated at 2022-06-22 13:52:55.156181
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch(): # test method, should start with "test_"
    search = CollectionSearch()
    assert search, "_ensure_default_collection(collection_list=None) should not return None"

# Generated at 2022-06-22 13:52:57.861594
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    obj = CollectionSearch()
    collections = obj._collections
    assert collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:52:58.470473
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search

# Generated at 2022-06-22 13:53:15.304744
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert isinstance(search._load_collections('collections', ['test.collection1', 'test.collection2']), list)

# Generated at 2022-06-22 13:53:16.637105
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-22 13:53:21.882358
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert isinstance(s, CollectionSearch)
    assert s.collections is not None
    s.collections = ["ansible_test.test_collection"]
    assert isinstance(s.collections, list)
    assert s.collections[0] == "ansible_test.test_collection"

# Generated at 2022-06-22 13:53:24.440028
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert result._collections._data == _ensure_default_collection()

# Generated at 2022-06-22 13:53:26.784585
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-22 13:53:34.719203
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    c = CollectionSearch()
    assert c._load_collections(None, None) == None
    assert isinstance(c._load_collections(None, []), list)
    assert c._load_collections(None, []) == []
    with pytest.raises(TypeError):
        c._load_collections(None, 'foo')
    with pytest.raises(TypeError):
        c._load_collections(None, ['foo', 1])
    assert c._load_collections(None, ['foo']) == ['foo']



# Generated at 2022-06-22 13:53:37.496087
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)

# Generated at 2022-06-22 13:53:48.629788
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Test post_validate return a list of default collection
    cs.post_validate()
    assert cs._collections == ['ansible_collections.ansible.builtin']

    # Test constructor populate valid attributes
    cs = CollectionSearch(collections=['my_collections', 'my_other_collections'], _load_collections=_ensure_default_collection)
    assert cs.collections == ['my_collections', 'my_other_collections']

    # Test constructor validates attributes
    default_collection = AnsibleCollectionConfig.default_collection
    assert default_collection == 'ansible_collections.ansible.builtin'
    cs = CollectionSearch()
    # Playbook validates whether or not 'collections' field is a list.

# Generated at 2022-06-22 13:53:50.133245
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()
    assert CollectionSearch().collections is not None

# Generated at 2022-06-22 13:53:51.703338
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections is not None

# Generated at 2022-06-22 13:54:21.653210
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CS = CollectionSearch()
    assert CS.collections == [ 'ansible.builtin', 'ansible.legacy']
    assert CS._collections == [ 'ansible.builtin', 'ansible.legacy']

# test _load_collections function

# Generated at 2022-06-22 13:54:24.271737
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    if c._collections is None:
        assert "c._collections is default true"


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:54:29.654235
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch): pass
    tcs = TestCollectionSearch({'collections': ['foo.bar', 'bar.baz']})
    assert tcs._collections == ['foo.bar', 'bar.baz']
    assert tcs.collections == ['foo.bar', 'bar.baz', 'ansible.builtin']

# Generated at 2022-06-22 13:54:30.961916
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is not None

# Generated at 2022-06-22 13:54:34.136992
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == "ansible.legacy"

# Generated at 2022-06-22 13:54:38.015265
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert 'ansible.legacy' in search.collections
    assert 'ansible.builtin' in search.collections
    assert 'ansible.builtin' in search.collections

# Test default collection name

# Generated at 2022-06-22 13:54:46.703857
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    from ansible.module_utils.six import string_types

    # Test constructor
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    _collections = cs._collections

    # Test FieldAttribute: _collections
    assert isinstance(_collections, FieldAttribute)
    assert _collections.name == '_collections'
    # FieldAttribute._valid_attributes_keys
    _valid_attributes_keys = _collections._valid_attributes_keys
    assert len(_valid_attributes_keys) == 5
    assert 'listof' in _valid_attributes_keys
    assert 'static' in _valid_attributes_keys
    assert 'always_post_validate' in _valid_attributes_keys
    assert 'default' in _valid_attributes_keys

# Generated at 2022-06-22 13:54:55.985677
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # tests run in a subdirectory, path contains collection name
    cs._collections = ['./test/test_collection']
    cs._load_collections('collections', None)
    assert cs.collections == ['./test/test_collection', 'ansible.builtin', 'ansible.legacy']
    # subdirs are OK in paths, but not names
    cs._collections = ['./test/test_collection/subdir']
    cs._load_collections('collections', None)
    assert cs.collections == ['./test/test_collection/subdir', 'ansible.builtin', 'ansible.legacy']
    cs._collections = ['test/test_collection']
    cs._load_collections('collections', None)

# Generated at 2022-06-22 13:54:59.614568
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections._default == _ensure_default_collection
    assert collection_search._collections._always_post_validate == True
    assert collection_search._collections._static == True

# Generated at 2022-06-22 13:55:11.145822
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # assert that we get a list back
    assert isinstance(cs._load_collections('collections', None), list)
    # assert that list only contains the ful collection name
    # FIXME: this should be the default collection name at the very least
    assert cs.get_validated_value('collections', cs._collections, None, None) is None
    # assert that we get a list back, and it's the default collection name
    assert cs.get_validated_value('collections', cs._collections, 'default', None) == ['ansible.builtin']
    # assert that we get a list back, and it's the default collection name,
    # but we also get the provided collection name

# Generated at 2022-06-22 13:56:07.603366
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:56:09.571380
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Test constructor of CollectionSearch class"""
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()


# Generated at 2022-06-22 13:56:12.003235
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ["ansible.builtin", "ansible_community.windows"]

# Generated at 2022-06-22 13:56:13.956690
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == []
    assert collection_search.get_validated_value('collections', collection_search.collections, [], None) == []

# Generated at 2022-06-22 13:56:16.524339
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:56:17.403983
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()

# Generated at 2022-06-22 13:56:21.309526
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections("collections", ["ansible_test","test_collection_1"]) == ['ansible_test', 'test_collection_1']

# Generated at 2022-06-22 13:56:30.240712
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Successfully create an instance of CollectionSearch
    try:
        collection_search = CollectionSearch()
        assert collection_search
    except Exception as ex:
        assert False, "Error occurred while instantiating CollectionSearch class. Error: " + str(ex)

    # Successfully validate collection search class
    try:
        collection_search.validated()
        assert collection_search
    except Exception as ex:
        assert False, "Error occurred while validating CollectionSearch class. Error: " + str(ex)

    # Fail to initialise collection search with invalid data structure
    try:
        collection_search = CollectionSearch(collections={"ansible.builtin": ["tasks"]})
        assert False, "Expected error: Failed to initialise collection search with invalid data structure"
    except Exception as ex:
        assert True

    # Successfully initialise collection search

# Generated at 2022-06-22 13:56:33.334799
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None
    assert str(type(obj)) == "<class 'ansible.playbook.collection_search.CollectionSearch'>"
    assert obj._collections is not None
    assert str(type(obj._collections)) == "<class 'ansible.playbook.attribute.FieldAttribute'>"


# Generated at 2022-06-22 13:56:33.814142
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-22 13:57:32.831041
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin']

# Generated at 2022-06-22 13:57:35.330414
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    collection_list = search._collections.default
    assert collection_list == ['ansible.builtin', 'ansible.community', 'ansible.legacy']

# Generated at 2022-06-22 13:57:45.130945
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create instance of CollectionSearch
    search_instance = CollectionSearch()
    # create ansible_collections config object
    ansible_collection_config = AnsibleCollectionConfig()
    # set the default collection in the ansible_collection_config
    ansible_collection_config.set_default_collection("/home/user/collections/ansible_collections/user/collection/")
    # get the value of _collections
    collection_list = search_instance._load_collections(None, None)
    # check the value of _collections
    assert collection_list[0] == "/home/user/collections/ansible_collections/user/collection/"

# Generated at 2022-06-22 13:57:46.294361
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:57:50.821057
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.__class__.__name__ == "CollectionSearch"
    assert isinstance(cs, CollectionSearch)
    assert cs.collections == ["ansible.builtin"]
    return

# Generated at 2022-06-22 13:57:53.237479
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        CollectionSearch()
    except TypeError:
        assert False, "Failed to instantiate CollectionSearch"
    else:
        assert True, "CollectionSearch instantiated successfully"

# Generated at 2022-06-22 13:57:56.397576
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearch_ins(CollectionSearch):
        pass

    a = CollectionSearch_ins()
    assert isinstance(a._load_collections('collections', None), list)
    assert isinstance(a._load_collections('collections', []), list)

# Generated at 2022-06-22 13:57:56.809685
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-22 13:57:57.997201
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    assert test_instance

# Generated at 2022-06-22 13:57:59.341474
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections is not None

# Generated at 2022-06-22 14:00:07.037191
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.tasks.task_include import TaskInclude
    import yaml
    yaml_text = u'''
    - include_tasks: abc.yml
      collections:
        - testcoll.testcoll
        - testcoll2.testcoll2
    '''
    yaml_data = yaml.full_load(yaml_text)
    role = RoleDefinition.load(yaml_data[0], None, None, 0)
    assert role.get_validated_value('collections', role._collections, role._ds, None) == ['testcoll.testcoll', 'testcoll2.testcoll2']
    # Default collection is builtin

# Generated at 2022-06-22 14:00:11.618030
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    task1 = {
        "collections": [
            "test.ns1.role1",
            "test.ns2.role2",
            "test.ns3.role3"
        ]
    }
    obj = CollectionSearch()
    obj.post_validate(task1, None)
    assert obj.collections == task1['collections']


# Generated at 2022-06-22 14:00:17.011407
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class DataSet(Base, CollectionSearch):
        pass

    ds = DataSet()

    # validate the collection
    assert ds.get_validated_value('collections', None, None, None) is not None

    # validate the collection
    assert ds.get_validated_value('collections', None, None, None) is not None

# Generated at 2022-06-22 14:00:21.235555
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collections = _ensure_default_collection()
    assert 'ansible.builtin' in test_collections and 'ansible.legacy' not in test_collections
    assert _ensure_default_collection(['test_collections'])[0] == 'test_collections'

# Generated at 2022-06-22 14:00:24.067490
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Check for _collections attribute and value
    assert cs._collections == _ensure_default_collection()
    # Check for _load_collections method
    assert hasattr(cs, '_load_collections')

# Generated at 2022-06-22 14:00:26.505635
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']
    assert collection_search.collections == None
    assert collection_search.collections == None

# Generated at 2022-06-22 14:00:33.926622
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Test FieldAttribute isa list of strings
    assert isinstance(cs._collections, FieldAttribute)
    assert isinstance(cs._collections.isa, list)
    assert cs._collections.isa[0] == string_types
    assert isinstance(cs._collections.listof, str)
    assert cs._collections.listof == string_types
    # Test FieldAttribute priority and default
    assert cs._collections.priority == 100
    assert cs._collections.default == _ensure_default_collection
    assert isinstance(cs._collections.default, collections.Callable)
    # Test FieldAttribute attribute always_post_validate and static
    assert cs._collections.always_post_validate == True
    assert cs._collections.static == True


# Generated at 2022-06-22 14:00:40.619023
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_search = CollectionSearch()
    assert isinstance(test_collection_search._collections, FieldAttribute)
    assert test_collection_search._collections.isa == 'list'
    assert test_collection_search._collections.listof == string_types
    assert test_collection_search._collections.priority == 100
    assert test_collection_search._collections.always_post_validate == True
    assert test_collection_search._collections.static == True

# Generated at 2022-06-22 14:00:44.525352
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    mixin = CollectionSearch()
    base = Base()
    # We use Base to mimic a class with _collections as a valid field attribute
    mixin.post_validate(base)
    assert isinstance(mixin._collections, FieldAttribute)
    assert isinstance(mixin.collections, list)
    assert 'ansible.builtin' in mixin.collections or 'ansible.legacy' in mixin.collections

# Generated at 2022-06-22 14:00:46.610556
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    task_collection = CollectionSearch()
    expected_default = "ansible.builtin,ansible.legacy"
    assert task_collection._collections.default == expected_default