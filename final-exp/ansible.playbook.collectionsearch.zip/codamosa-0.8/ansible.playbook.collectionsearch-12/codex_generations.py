

# Generated at 2022-06-22 13:51:11.020916
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch, "_collections"), "Attribute '_collections' is not present"
    assert hasattr(CollectionSearch, "_load_collections"), "Method '_load_collections' is not present"

# Generated at 2022-06-22 13:51:20.373946
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestClass(CollectionSearch):
        def __init__(self, collections=None, a=None, b=None, taskname=None):
            self.collections = collections
            self.a = a
            self.b = b
            self.taskname = taskname
            super(TestClass, self).__init__()
            self.post_validate([], {})
        def get_validated_value(self, key, value, data, validate_data):
            return value
    sc = TestClass(collections=['ansible.builtin'], a='a', b=1)
    assert sc.collections == ['ansible.builtin']
    assert sc.a == 'a'
    assert sc.b == 1

# Generated at 2022-06-22 13:51:31.426454
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Lets first import the modules we want to test
    from ansible.playbook.role_includes import RoleInclude
    from ansible.plugins.loader import callback_loader, lookup_loader

    # Test init with no parameters
    collectionTask = CollectionSearch()
    assert collectionTask

    # Test init with parameters
    collectionTask = CollectionSearch(collections=[])
    assert collectionTask

    # Test init with parameters
    collectionTask = CollectionSearch(collections=[ 'ansible.builtin', 'ansible.legacy'])
    assert collectionTask

    # Test _load_collections with no parameters
    collections = collectionTask._load_collections(None, None)
    assert collections is None

    # Test _load_collections with parameters

# Generated at 2022-06-22 13:51:33.979452
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections == ['ansible.builtin', 'ansible.legacy', 'ansible_collections.notcommons']

# Generated at 2022-06-22 13:51:35.213098
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x.attributes['collections']


# Generated at 2022-06-22 13:51:36.372535
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default() == _ensure_default_collection()

# Generated at 2022-06-22 13:51:38.309925
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # The list should have an element 'ansible.builtin' in it
    assert 'ansible.builtin' in cs._collections[0]

# Generated at 2022-06-22 13:51:40.938260
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	collection_search = CollectionSearch()
	print(vars(collection_search))

if __name__ == '__main__':
	test_CollectionSearch()

# Generated at 2022-06-22 13:51:52.754726
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test when the collection list is None
    collection_search = CollectionSearch()
    results = collection_search._load_collections(None, None)
    assert len(results) == 1
    assert results[0] == 'ansible.builtin'

    # Test when the collection list is empty
    collection_search = CollectionSearch()
    results = collection_search._load_collections(None, [])
    assert len(results) == 1
    assert results[0] == 'ansible.builtin'

    # Test when the collection_list only has one item
    collection_search = CollectionSearch()
    results = collection_search._load_collections(None, ['none'])
    assert len(results) == 2
    assert results[0] == 'none'
    assert results[1] == 'ansible.builtin'

    # Test

# Generated at 2022-06-22 13:51:55.782249
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    test_collection_search = CollectionSearch()

    assert "ansible.builtin" in test_collection_search._load_collections("collections", ["ansible.builtin"])

# Generated at 2022-06-22 13:52:08.748518
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, ["foo","bar"]) == ["foo", "bar", "ansible.legacy"]
    assert cs._load_collections(None, []) == ["ansible.builtin" , "ansible.legacy"]
    assert cs._load_collections(None, None) == ["ansible.builtin" , "ansible.legacy"]

# Generated at 2022-06-22 13:52:09.951270
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:52:18.169359
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create a object of class CollectionSearch
    cm = CollectionSearch()
    # get a non-default collection list
    x = cm._load_collections('collections', 'collections')
    assert type(x) == list
    assert 'ansible.legacy' in x
    assert 'ansible.builtin' not in x
    # get a default collection list
    x = cm._load_collections('collections', None)
    assert type(x) == list
    assert 'ansible.legacy' in x
    assert 'ansible.builtin' in x

# Generated at 2022-06-22 13:52:23.096825
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()
    coll.set_loader()
    assert coll._collections == _ensure_default_collection()
    assert coll._collections == _ensure_default_collection([])
    assert coll._collections == _ensure_default_collection(['collection'])

# Generated at 2022-06-22 13:52:34.829165
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert(_ensure_default_collection() == a._load_collections('collections',None))

    # Test if collections are specified
    assert(['ansible.builtin', 'ansible.posix'] == a._load_collections('collections',['ansible.posix']))
    assert(['ansible.builtin', 'ansible.posix'] == a._load_collections('collections',['ansible.posix', None]))
    assert(['ansible.builtin', 'ansible.posix'] == a._load_collections('collections',['ansible.posix', 'ansible.windows']))

    # Test for multiple collections specified

# Generated at 2022-06-22 13:52:46.762427
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.utils import collection_loader
   
    optional_spec = {
        
    }
    required_spec = {
        'collections': {'type': 'list', 'elements': 'string', 'default': collection_loader.AnsibleCollectionConfig.default_collection, 'always_post_validate': True},
    }

    class TestCollectionSearch(unittest.TestCase):

        def setUp(self):
            self.cs = CollectionSearch()


        def test__init__(self):
            self.assertIsNone(self.cs.collections)
            for key in self.cs._valid_attrs:
                self.assertIn(key, self.cs.__dict__)


# Generated at 2022-06-22 13:52:48.430352
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections == _ensure_default_collection

# Generated at 2022-06-22 13:52:49.965007
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections is not None

# Generated at 2022-06-22 13:52:52.451122
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test for simple constructor and init value
    obj = CollectionSearch()
    assert(obj._collections == ['ansible.builtin'])

# Generated at 2022-06-22 13:52:55.444749
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    default_collection = AnsibleCollectionConfig.default_collection
    # Test template found in the colection_name
    collection_name = "mytempalte"
    if default_collection and default_collection not in ds:
        assert collection_name != None

# Generated at 2022-06-22 13:53:06.140772
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test the constructor if no arg provided
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()

    # Test the constructor if arg provided
    cs = CollectionSearch(collections=["some.collection"])
    assert cs.collections == ["some.collection"]

# Generated at 2022-06-22 13:53:09.063364
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default is _ensure_default_collection

# Generated at 2022-06-22 13:53:11.897835
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch.collections == ['ansible_internal.ansible_collections']

# Generated at 2022-06-22 13:53:14.730085
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert ['ansible.builtin'] == collection_search._collections

# Generated at 2022-06-22 13:53:17.829474
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    # test _load_collections
    assert collection._load_collections(None, _ensure_default_collection()) == [AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-22 13:53:20.901022
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Check constructor of class CollectionSearch
    assert cs
    assert cs._collections
    assert cs._load_collections

# Generated at 2022-06-22 13:53:24.981744
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = "ansible.builtin"
    object = CollectionSearch()
    assert object._load_collections(None, ds) == ["ansible.builtin", "ansible.builtin"]



# Generated at 2022-06-22 13:53:27.897436
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert cs.collections == ['ansible_collections.foo.bar']

# Generated at 2022-06-22 13:53:29.151891
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['ansible.builtin']

# Generated at 2022-06-22 13:53:33.999942
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = {'collections': 'col1'}
    name = 'user_name'
    collection_search = CollectionSearch(name)
    result = collection_search._load_collections(collection_search._collections, ds)
    assert(result == ['col1', 'ansible.builtin'])

# Generated at 2022-06-22 13:53:48.259259
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)


# Generated at 2022-06-22 13:53:51.134334
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    assert cs._load_collections("chocolate", "chocolate") is not None

# Generated at 2022-06-22 13:53:52.695331
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    assert col.collections == ['ansible']

# Generated at 2022-06-22 13:53:55.282525
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    assert col.collections is None, "collections should be none if not set"

# Generated at 2022-06-22 13:53:59.242595
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()
    collection_search.post_validate({'collections': ['my.collection']})

    # test the value of post_validate
    assert collection_search.collections == ['my.collection', 'ansible.legacy']

# Generated at 2022-06-22 13:54:01.285674
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert s._collections.name == 'collections'

# Generated at 2022-06-22 13:54:02.195245
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj

# Generated at 2022-06-22 13:54:10.600850
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    dataloader = DataLoader()
    collection_names = ['role1', 'role2']
    collection_names_dict = {'collections': collection_names}
    collection_names_yaml = AnsibleLoader(collection_names_dict).get_single_data()
    variable_manager = VariableManager()
    variable_manager._fact_cache = {'nested': {'val': collection_names}, 'dict': collection_names_dict, 'list': collection_names, 'yaml': collection_names_yaml, 'str': 'str', 'num': 1}

    collection_search = CollectionSearch()
    collection_search._variable

# Generated at 2022-06-22 13:54:11.116567
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

# Generated at 2022-06-22 13:54:13.031636
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass

    obj = TestCollectionSearch()
    assert obj._collections == ['ansible.builtin']

# Generated at 2022-06-22 13:54:40.889268
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # TO-DO: This class is used as a Base class for the TaskBase class
    # and the RoleBase class and cannot be tested by itself
    pass

# Generated at 2022-06-22 13:54:43.343011
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Assertion : Checks the default constructor for CollectionSearch
    assert(CollectionSearch is not None)

# Generated at 2022-06-22 13:54:49.024148
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class AnsibleModule(CollectionSearch):
        def __init__(self, *args, **kwargs):
            super(AnsibleModule, self).__init__(*args, **kwargs)

    m = AnsibleModule()
    assert m.value('collections') is None

# Generated at 2022-06-22 13:54:50.224204
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-22 13:54:51.869099
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert(search.collections == ['ansible.builtin'])

# Generated at 2022-06-22 13:55:02.617899
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) is None
    cs = CollectionSearch(collections=['geerlingguy.nginx'])
    assert cs._load_collections(None, None) == ['geerlingguy.nginx']
    cs = CollectionSearch(collections=[])
    assert cs._load_collections(None, None) is None
    cs = CollectionSearch(collections=['geerlingguy.nginx', 'ansible_collections.geerlingguy.postgresql'])
    assert cs._load_collections(None, None) == ['ansible.legacy', 'geerlingguy.nginx', 'ansible_collections.geerlingguy.postgresql']
    cs = CollectionSearch(collections=['ansible.builtin'])
    assert cs._

# Generated at 2022-06-22 13:55:05.971659
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role import Role
    cs = CollectionSearch()
    role = Role()
    # testing collection in role
    assert cs._load_collections('collections', [role]) == [role]

# Generated at 2022-06-22 13:55:09.005211
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search._collections = ["collection_name"]
    answer = collection_search._collections
    assert answer == ["collection_name"]

# Generated at 2022-06-22 13:55:10.323888
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:55:10.856016
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-22 13:55:39.741567
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch._collections = _ensure_default_collection()

# Test role constructor
test_CollectionSearch()

# Generated at 2022-06-22 13:55:51.766108
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Call to constructor without any parameters
    cs = CollectionSearch()
    assert cs is not None
    assert cs.__class__.__name__ == 'CollectionSearch'

    # Call to constructor with collections=[]
    cs = CollectionSearch(collections=[])
    assert cs is not None
    assert cs.__class__.__name__ == 'CollectionSearch'
    assert cs.collections == []

    # Call to constructor with collections=['community.general']
    cs = CollectionSearch(collections=['community.general'])
    assert cs is not None
    assert cs.__class__.__name__ == 'CollectionSearch'
    assert cs.collections == ['community.general']

    # Call to constructor with collections=['community.general','ansible.builtin']

# Generated at 2022-06-22 13:55:53.078764
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:55:59.411616
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.playbook.task.include import TaskInclude

    task = TaskInclude(
        parent=dict(
            _role=dict(
                _role={}
            )
        ),
        role_namespace='test_ns',
        task_with_role_name='test_twr_name',
        role_name='test_name',
        task_name='test_task',
        role_path='test_path',
        role_params='test_params',
        role_default_vars='test_default_vars',
        role_tasks_mapping='test_tasks_mapping',
        role_context_aware_default_vars='test_ca_default_vars',
        role_metadata_files=[],
        role_files=['role_files']
    )


# Generated at 2022-06-22 13:56:02.151278
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    '''
    Testcase for CollectionSearch
    '''
    collection_search = CollectionSearch()

# Generated at 2022-06-22 13:56:12.815602
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    data = '''
    collections:
        - "lib.aws_submodules"
        - "lib.microsoft.azure"
    '''

    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.iimport_role import RoleImport
    from ansible.playbook.role import Role

    role_include = RoleInclude.load(data)
    task_include = TaskInclude.load(data)
    block = Block.load(data)
    task = Task.load(data)
    role_import = RoleImport.load(data)
    role = Role.load(data)

    assert role_include.get_

# Generated at 2022-06-22 13:56:16.377510
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection(collection_list=None)
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:56:21.890054
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Arrange
    ansible_collections_paths = AnsibleCollectionConfig().get_collections_paths()

    # Act
    r = CollectionSearch()

    # Assert
    assert r._collections == ['ansible.builtin', 'ansible.builtin']
    assert r._collections.paths == ansible_collections_paths

# Generated at 2022-06-22 13:56:23.499398
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search

test_CollectionSearch()

# Generated at 2022-06-22 13:56:29.917149
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    import tempfile

    # In order to test a class constructor we need a temporary directory
    with tempfile.TemporaryDirectory() as tmp_dir_name:
        # create a fake collection name
        cid = os.path.join(tmp_dir_name, 'namespace', 'collection')
        # create the fake collection
        os.makedirs(cid)

        # test class constructor
        cs = CollectionSearch()
        assert cs.get_collections() == None
        assert cs.set_collections(cid) == True
        assert cs.get_collections() == [cid]

# Generated at 2022-06-22 13:57:29.940677
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    collection_search.collections = _ensure_default_collection(None)
    assert collection_search.collections == ['ansible.builtin', 'ansible.legacy']

    collection_search.collections = _ensure_default_collection(['test'])
    assert collection_search.collections == ['test', 'ansible.builtin', 'ansible.legacy']

    # values shouldn't be set from the default_collection
    collection_search.collections = _ensure_default_collection([])
    assert collection_search.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:57:33.007813
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class Test(CollectionSearch):
        def __init__(self):
            super(Test, self).__init__()

    test = Test()

    # object has default value
    assert test.collections == ['ansible_collections.rh_sosreport']

# Generated at 2022-06-22 13:57:38.729371
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj1 = CollectionSearch()
    print(obj1._collections)
    obj2 = CollectionSearch()
    print(obj2._collections)
    obj3 = CollectionSearch()
    print(obj3._collections)
    obj4 = CollectionSearch()
    print(obj4._collections)
    obj5 = CollectionSearch()
    print(obj5._collections)


# Generated at 2022-06-22 13:57:42.316433
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()

    ds = ['ansible.builtin']
    result = collectionSearch._load_collections('collections', ds)
    assert result == ds

# Generated at 2022-06-22 13:57:45.773660
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import RoleInclude
    obj = RoleInclude(
        collection_list=['ansible.builtin', 'ansible.posix'],
    )
    assert obj.collections == ['ansible.builtin', 'ansible.posix', 'ansible.legacy']

# Generated at 2022-06-22 13:57:48.312356
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections

# Generated at 2022-06-22 13:57:50.038913
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:57:53.592760
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    result = collection_search._load_collections(0, 'ansible.builtin')
    assert result[0] == 'ansible.builtin'
    assert result[1] == 'ansible.builtin'

# Generated at 2022-06-22 13:57:56.746357
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    model = CollectionSearch()
    model.collections = ['basicCollection']
    assert model.collections == ['basicCollection']
    model.collections = ['basicCollection', 'anotherCollection']
    assert model.collections == ['basicCollection', 'anotherCollection']

# Generated at 2022-06-22 13:57:59.300343
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()

    default_collection = AnsibleCollectionConfig.default_collection
    assert collections.collections == [default_collection] or collections.collections is None

# Generated at 2022-06-22 13:59:57.801603
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        CollectionSearch()
    except TypeError as e:
        # This should fail, because CollectionSearch is an abstract class
        assert e.message == "Can't instantiate abstract class CollectionSearch with abstract methods get_collection_loader, get_extension_loader, get_roles_loader, get_tasks_loader"
    except Exception as e:
        assert False, 'TypeError was expected, but other exception was raised: %s' % e.message

# Generated at 2022-06-22 13:59:59.120469
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _ensure_default_collection()

# Generated at 2022-06-22 14:00:05.711479
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create object of class CollectionSearch
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

    # Check if _collections is defined as an attribute of class CollectionSearch
    assert hasattr(collection_search, '_collections')

    # Check if _load_collections is defined as an attribute of class CollectionSearch
    assert hasattr(collection_search, '_load_collections')


# Call the unit test
test_CollectionSearch()

# Generated at 2022-06-22 14:00:08.607951
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    aCollectionSearch = CollectionSearch()
    print(aCollectionSearch)

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-22 14:00:09.992857
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        obj1 = CollectionSearch()
    except:
        obj1 = None
    assert obj1 is not None

# Generated at 2022-06-22 14:00:13.096531
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible_collections.ansible.builtin.plugins.module_utils.common.collections import CollectionSearch
    cs = CollectionSearch()
    assert cs.collections is None


# Generated at 2022-06-22 14:00:19.325306
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t._load_collections('collections', ['ansible_collections.acme.foo']) == ['ansible_collections.acme.foo', 'ansible.builtin']
    assert t._load_collections('collections', []) == ['ansible.builtin']
    assert t._load_collections('collections', None) == ['ansible.builtin']

# Generated at 2022-06-22 14:00:21.490426
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()
    assert isinstance(cs._collections, FieldAttribute)
    assert not cs.validate()

# Generated at 2022-06-22 14:00:22.959347
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections.value == ['ansible_galaxy.collection']

# Generated at 2022-06-22 14:00:25.078120
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.default == ['ansible_collections.test_namespace.test_collection']