

# Generated at 2022-06-22 13:51:07.833576
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs.collections is not None

# Generated at 2022-06-22 13:51:14.141784
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.collections = [
        "myorg.mycollection1", "myorg.mycollection2", "myorg.mycollection3"
    ]
    assert collection_search._collections == [
        "myorg.mycollection1", "myorg.mycollection2", "myorg.mycollection3"
    ]

# Generated at 2022-06-22 13:51:16.614439
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    print(collection)

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-22 13:51:21.390414
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._load_collections(None, ['namespace.collection'])

    # Calling the post validate method will cause the default collection
    # to be appended to the list
    cs.post_validate()
    assert cs.collections[0] == 'ansible.builtin'

# Generated at 2022-06-22 13:51:32.453718
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    required_value = {
        'collections': [
            'a.b',
            'ansible.builtin',
            'ansible.legacy'
        ]
    }

    assert required_value['collections'] == CollectionSearch()._load_collections('collections', required_value)

    invalid_value_1 = {
        'collections': [
            'a.b',
            'ansible.builtin',
            'ansible.legacy',
            'a.b',  # duplicate
        ]
    }
    with pytest.raises(ValueError):
        CollectionSearch()._load_collections('collections', invalid_value_1)


# Generated at 2022-06-22 13:51:33.801269
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert_input_equals_output(CollectionSearch, '_collections')

# Generated at 2022-06-22 13:51:35.373355
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    if c._collections != None:
        raise Exception("CollectionSearch Constructor Failed")

# Generated at 2022-06-22 13:51:36.888248
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection1 = CollectionSearch()
    assert collection1._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:38.533575
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert (_(ensure_default_collection))

    assert (_(collections))

# Generated at 2022-06-22 13:51:49.725508
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearchTest(CollectionSearch):
        pass

    assert CollectionSearchTest._collections.default == _ensure_default_collection
    assert CollectionSearchTest._collections.always_post_validate is True
    assert CollectionSearchTest._collections.static is True
    assert CollectionSearchTest._collections._priority == 100
    assert CollectionSearchTest._collections._name == 'collections'
    assert CollectionSearchTest._collections._value is None
    assert CollectionSearchTest._collections.attribute_type == 'list'
    assert CollectionSearchTest._collections.isa == 'list'
    assert CollectionSearchTest._collections.listof == string_types
    assert hasattr(CollectionSearchTest, 'post_validate')
    assert hasattr(CollectionSearchTest, '_load_collections')

# Generated at 2022-06-22 13:51:54.591119
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Testing the constructor
    collection_search = CollectionSearch()

# Generated at 2022-06-22 13:51:57.459288
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search=CollectionSearch()
    assert collection_search._collections.field_name == 'collections'
    assert collection_search._collections.static

# Generated at 2022-06-22 13:52:00.301998
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert AnsibleCollectionConfig.default_collection == 'ansible.builtin'
    search = CollectionSearch()
    assert search._collections == 'ansible.builtin'

# Generated at 2022-06-22 13:52:11.470161
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    Base.collections = _ensure_default_collection()
    from ansible.plugins.loader import task_loader
    from ansible.plugins.loader import role_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader

    assert(task_loader.collection_list == ['ansible.builtin', 'ansible.legacy'])
    assert(role_loader.collection_list == ['ansible.builtin', 'ansible.legacy'])
    assert(lookup_loader.collection_list == ['ansible.builtin', 'ansible.legacy'])
    assert(filter_loader.collection_list == ['ansible.builtin'])

# Generated at 2022-06-22 13:52:13.418215
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections._default == ['ansible.builtin']

# Generated at 2022-06-22 13:52:16.328539
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # CollectionSearch.collections is static attr, so it won't be included.
    assert set() == set(collection_search.__dict__)

# Generated at 2022-06-22 13:52:19.346240
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()
    collections_list = collection_search._collections.default()
    assert collections_list == ['ansible_collections.test_collection.test_namespace.test_plugin']

# Generated at 2022-06-22 13:52:23.045886
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # collections is a static attribute and is not templatable
    cs.collections = ["test"]
    assert cs.collections == ["test"]

# Generated at 2022-06-22 13:52:32.642800
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class CollectionSearchTest(object):

        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                      always_post_validate=True, static=True)

        def __init__(self):
            self.__collections = self._collections

        @classmethod
        def get_member_names(cls, exclude=None):
            return ['_collections']

    cst = CollectionSearchTest()
    assert cst.__collections is not None
    assert len(cst.__collections) > 1

# Generated at 2022-06-22 13:52:37.298909
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    # check the filter
    obj._load_collections("collections", [])
    obj._load_collections("collections", [{'name':'foo'}, 'ansible.builtin', 'ansible.legacy'])
    obj._load_collections("collections", ['foo.bar'])
    collection_list = ['foo.bar', 'foo.baz', 'ansible.builtin']
    obj._load_collections("collections", collection_list)
    assert collection_list[-1] == 'ansible.builtin'

# Generated at 2022-06-22 13:52:47.666539
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test(CollectionSearch):
        def __init__(self):
            self._collections = ['test']

    assert Test()._load_collections(None, None) == ['test']

# Generated at 2022-06-22 13:52:48.696848
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    assert col.collections is not None


# Generated at 2022-06-22 13:52:50.639330
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.__class__.__name__ == 'CollectionSearch'

# Generated at 2022-06-22 13:52:53.335469
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert collection_search.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:53:04.401765
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Exercise code
    colsearch = CollectionSearch()

    # Ensure both empty and None are changed to [ansible.builtin]
    assert colsearch._load_collections(None, None) == ['ansible.builtin']
    assert colsearch._load_collections(None, []) == ['ansible.builtin']

    # Ensure ["ansible.builtin"] and ["ansible.legacy"] are unchanged
    assert colsearch._load_collections(None, ["ansible.builtin"]) == ['ansible.builtin']
    assert colsearch._load_collections(None, ["ansible.legacy"]) == ['ansible.legacy']

    # Ensure ["ansible.builtin", "foo.bar"] is changed to ["foo.bar", "ansible.builtin"]

# Generated at 2022-06-22 13:53:06.498779
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_ = CollectionSearch()
    assert search_._load_collections(0, [])

# Generated at 2022-06-22 13:53:11.292488
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll_search = CollectionSearch()
    assert coll_search._collections == _ensure_default_collection()
    assert coll_search._load_collections('collections', coll_search.collections) == _ensure_default_collection()

# Generated at 2022-06-22 13:53:13.878380
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections == None

# Generated at 2022-06-22 13:53:16.825876
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Testing the second constructor
    a = CollectionSearch()
    assert isinstance(a._collections, list)
    # Assert the length of List
    assert len(a._collections) == 1

# Generated at 2022-06-22 13:53:23.818832
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    assert(collection_search._collections.always_post_validate)
    assert(collection_search._collections.static)
    assert(collection_search._collections.default is _ensure_default_collection)
    assert(collection_search.collections is None)

    # This is to cover anything that's not in _collections
    collection_search.collections = list('abc')
    assert(collection_search.collections == list('abc'))


# Generated at 2022-06-22 13:53:32.428692
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-22 13:53:37.831446
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("Unit test for CollectionSearch")
    class TestCollectionSearch(CollectionSearch):
        def __init__(self, item):
            super(TestCollectionSearch, self).__init__()
            self._data_parsed = item
    # Test _collections is list of string_types
    testItem = {"collections": 3}
    testObject = TestCollectionSearch(testItem)
    assert testObject._collections.validate_datastructure(testItem, None) is False
    print("Unit test for CollectionSearch done")

# Generated at 2022-06-22 13:53:43.978001
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test successful _load_collections function
    value = 'test'
    collection_search = CollectionSearch()
    assert 'test' == collection_search._load_collections('', value)

    # Test successful _load_collections function with empty value
    value = ''
    assert None == collection_search._load_collections('', value)


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:53:45.728949
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == ['ansible.builtin']

# Generated at 2022-06-22 13:53:57.065395
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.plugins.loader import task_loader
    from ansible.playbook.play_context import PlayContext

    test_play = Block()
    play_context = PlayContext(play=test_play)

    ds = {'always_run': False, 'register': 'test', 'name': 'test'}
    task = task_loader.get('raw', play_context=play_context, variable_manager=None)

    # test _load_collections()
    play_context.collection_name = None
    task.load_collections(ds)
    assert task._collections == ['ansible.legacy']

    play_context.collection_name = 'namespace.collection'
    task.load_collections(ds)

# Generated at 2022-06-22 13:53:59.534246
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None
    assert cs._collections._static is True

# Generated at 2022-06-22 13:54:01.511846
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass
    obj = TestCollectionSearch()
    assert obj._collections == []


# Generated at 2022-06-22 13:54:03.654595
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs1 = CollectionSearch()
    assert cs1.collections is None or cs1.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:54:05.794386
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj.__dict__)

# unit test for function _ensure_default_collection()

# Generated at 2022-06-22 13:54:10.914561
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    assert s._collections.field_name == 'collections'
    assert s._collections.isa == 'list'
    assert s._collections.listof == string_types
    assert s._collections.priority == 100
    assert s._collections.default == _ensure_default_collection
    assert s._collections.always_post_validate == True
    assert s._collections.static == True


# Generated at 2022-06-22 13:54:29.861789
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == ['ansible.builtin', 'ansible.legacy']
    assert _ensure_default_collection(['my.collection']) == ['my.collection', 'ansible.builtin', 'ansible.legacy']
    assert _ensure_default_collection() == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:54:31.949480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj.collections is not None

# Unit tests for function _load_collections inside class CollectionSearch

# Generated at 2022-06-22 13:54:34.809393
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == _ensure_default_collection()

# Generated at 2022-06-22 13:54:39.309307
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role import Role
    r = Role()
    assert not (r._collections is None)
    assert isinstance(r._collections, list)
    assert ('ansible.builtin' in r._collections)
    assert ('ansible.legacy' in r._collections)

# Generated at 2022-06-22 13:54:40.839026
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == 'ansible.builtin'

# Generated at 2022-06-22 13:54:42.144944
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:54:45.107325
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    colsearch = CollectionSearch()
    colsearch.collections = ['test']
    assert colsearch._collections.do_post_validate('test') == ['test']


# Generated at 2022-06-22 13:54:48.255466
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    result = _ensure_default_collection()
    assert result == x._collections

# Generated at 2022-06-22 13:54:55.355300
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    base = Base()

    base.collect_all_roles = lambda: None
    base.load_collections = lambda x, y: None

    a = CollectionSearch()
    a._config_data = base
    assert a.collections == ['ansible.builtin', 'ansible.legacy']

    a.collections = ['some.namespace']
    assert a.collections == ['some.namespace', 'ansible.builtin', 'ansible.legacy']


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:54:56.971288
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert repr(CollectionSearch()) == '<CollectionSearch (collections=None)>'

# Generated at 2022-06-22 13:55:29.028863
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections_test = CollectionSearch()
    collections_test.collections = ['ansible.builtin', 'test.test']
    collections = collections_test.collections
    assert collections == ['test.test', 'ansible.builtin']

# Generated at 2022-06-22 13:55:30.552198
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()

# Generated at 2022-06-22 13:55:39.060751
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj.get_validated_value('default_collection', obj._collections, [], None)
    test_value = [{'namespace': 'ansible_namespace', 'name': 'my_collection', 'version': '1.2.3'}]
    if obj._collections != test_value:
        raise AssertionError()
    obj._load_collections(None, None)
    if obj._collections != test_value:
        raise AssertionError()
    obj._load_collections(None, [])
    test_value[0]['version'] = '2.3.4'
    if obj._collections != test_value:
        raise AssertionError()

# Generated at 2022-06-22 13:55:40.043930
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-22 13:55:51.852749
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from collections import namedtuple, OrderedDict
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.block import Block
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task.include import TaskInclude

    class Dummy(object):
        pass

    ds = namedtuple('ds', ['defaults', 'vars', 'tasks'])
    collection_list = []
    ds.defaults = OrderedDict()
    ds.vars = OrderedDict()
    ds.tasks = []

# Generated at 2022-06-22 13:55:53.165337
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections._value == [None]

# Generated at 2022-06-22 13:55:55.329803
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with pytest.raises(Exception) as excinfo:
        CollectionSearch()
    assert 'object() takes no parameters' in str(excinfo.value)

# Generated at 2022-06-22 13:55:56.462752
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    print(search.collections)

# Generated at 2022-06-22 13:55:59.757058
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:56:02.458863
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.value is not None
# Unit test end.

# Generated at 2022-06-22 13:56:31.681594
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
	instance = CollectionSearch()
	assert instance

# Generated at 2022-06-22 13:56:32.404456
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch, 'collections') is True

# Generated at 2022-06-22 13:56:33.614781
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj1 = CollectionSearch()
    assert obj1._load_collections('collections', None) is None

# Generated at 2022-06-22 13:56:37.218719
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test the collection search when no value is provided
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()

    # Test the collection search when empty list is provided
    collection_search = CollectionSearch(collections=[])
    assert collection_search.collections == _ensure_default_collection()

    # Test the collection search when list is provided
    collection_search = CollectionSearch(collections=['test', 'ansible.builtin'])
    assert collection_search.collections == ['test', 'ansible.builtin']

# Generated at 2022-06-22 13:56:41.313848
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    def _ensure_default_collection(collection_list):
        if collection_list is None:
            collection_list = []
        return collection_list

    assert obj._collections.default == _ensure_default_collection



# Generated at 2022-06-22 13:56:43.908803
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:56:54.313107
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search._collections.default, type(_ensure_default_collection))
    assert len(collection_search._collections.default()) == 1
    assert len(collection_search._collections.default([])) == 1
    assert len(collection_search._collections.default([collection_search._collections.default()[0]])) == 1

    c = collection_search._collections.default([])
    c.append('ansible.builtin')
    collection_search = CollectionSearch(collections=c)
    assert len(collection_search._collections.default()) == 2
    assert len(collection_search._collections.default([])) == 2

    c = collection_search._collections.default([])
    c.append('ansible.builtin')
    collection_

# Generated at 2022-06-22 13:56:56.049643
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.set_loader(None)
    search.post_validate(None)

# Generated at 2022-06-22 13:57:01.588252
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy', 'ansible_collections.nsweb.kubernetes']
    assert cs._load_collections(None, 'ansible_collections.nsweb.kubernetes') == 'ansible_collections.nsweb.kubernetes'
    assert cs._load_collections(None, ['ansible_collections.nsweb.kubernetes']) == ['ansible_collections.nsweb.kubernetes']



# Generated at 2022-06-22 13:57:09.573804
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test(CollectionSearch):
        _collections = ['default.collection']

    assert isinstance(Test._collections, FieldAttribute)
    assert hasattr(Test._collections, 'value')
    assert Test._collections.value == ['default.collection']
    assert Test().collections == ['default.collection']
    assert Test(collections=[]).collections == ['default.collection']
    assert Test(collections=['collection1', 'collection2']).collections == ['collection1', 'collection2', 'default.collection']


# Generated at 2022-06-22 13:58:12.275439
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search._collections)
    print(collection_search._load_collections('collections', {'collections': ['ansible_collections.namespace.collection']}))
    print(collection_search.__dict__)

# Generated at 2022-06-22 13:58:16.695350
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    data = CollectionSearch()
    # Data of no collections was passed
    assert data._load_collections(None, None) is None
    # Data of no collections was passed
    assert data._load_collections(None, []) is None

test_CollectionSearch()

# Generated at 2022-06-22 13:58:23.156363
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # accept a valid collection name
    obj = CollectionSearch(collection_list=['foo.bar'])
    assert obj._collections.value == ['foo.bar', 'ansible.builtin']

    # accept a valid collection name along with the default one
    obj = CollectionSearch(collection_list=['foo.bar', 'ansible.builtin'])
    assert obj._collections.value == ['foo.bar', 'ansible.builtin']

    # accept a valid collection name without the default one
    obj = CollectionSearch(collection_list=['foo.bar', 'ansible.builtin'])
    assert obj._collections.value == ['foo.bar', 'ansible.builtin']

    # accept valid collection names
    obj = CollectionSearch(collection_list=['foo.bar', 'ansible.builtin'])
    assert obj._

# Generated at 2022-06-22 13:58:27.287742
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    ds = []
    # test_collection = AnsibleCollectionConfig("collection_name")
    # ds.append(test_collection)
    c._load_collections("collections", ds)

# Generated at 2022-06-22 13:58:30.794908
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    display.vvvv(collectionSearch)
    assert collectionSearch._collections.value == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible.builtin.legacy']

# Generated at 2022-06-22 13:58:32.900839
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.default == ['ansible_collections.umccr.umccr']
    assert obj._collections.priority == 100

# Generated at 2022-06-22 13:58:43.630145
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test_collections_default_for_tasks
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

    # test_collections_default_for_tasks
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection()

    # test_collection_list_with_an_empty_list_will_be_ignored
    obj = CollectionSearch()
    collection_list = []
    obj._collections = collection_list
    obj._collections = []

    # test_collection_list_with_an_empty_list_will_be_ignored
    obj = CollectionSearch()
    obj.collections = {}
    assert obj._collections == []

    # test_collections_will_be_returned_if_its_not_empty
   

# Generated at 2022-06-22 13:58:44.486289
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-22 13:58:46.419029
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()


# Generated at 2022-06-22 13:58:57.745938
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()
    test_collection_search = CollectionSearch()

    # Test for initializing collections
    test_CollectionSearch_collections = collection_search._collections
    assert isinstance(test_CollectionSearch_collections, FieldAttribute)
    assert test_CollectionSearch_collections.isa == 'list'
    assert isinstance(test_CollectionSearch_collections.listof, string_types)
    assert test_CollectionSearch_collections.priority == 100
    assert test_CollectionSearch_collections.default == _ensure_default_collection
    assert test_CollectionSearch_collections.always_post_validate is True
    assert test_CollectionSearch_collections.static is True

    # Test for default collection
    collection_list = ['test_collection']
    assert _ensure_default_collection(collection_list) == Ans

# Generated at 2022-06-22 14:00:57.250742
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj.collections.post_validate([], None)
    assert obj.collections.data == ['ansible.legacy']

# Generated at 2022-06-22 14:00:59.853096
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default() == ['ansible_collections.ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 14:01:01.627161
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    CollectionSearch should have attribute named as collection and its initialization
    """
    c = CollectionSearch()
    attrs = dir(c)
    assert '_collections' in attrs