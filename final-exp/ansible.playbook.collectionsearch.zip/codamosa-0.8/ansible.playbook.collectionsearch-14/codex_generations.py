

# Generated at 2022-06-22 13:51:13.057896
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Check fields initialized in __init__() method."""

    cs = CollectionSearch()

    assert cs._collections.default() == ['ansible.builtin']
    assert cs._collections.listof() == string_types
    assert cs._collections.priority == 100
    assert cs._collections.static() == True
    assert cs._collections.always_post_validate() == True

# Generated at 2022-06-22 13:51:14.624324
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ls = CollectionSearch()
    _ensure_default_collection()

# Generated at 2022-06-22 13:51:19.492255
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    empty_search = CollectionSearch()
    assert empty_search._collections.value == ['ansible_collections.ansible.builtin', 'ansible_collections.community.general']

    search = CollectionSearch(collections=['ns.mycollection'])
    assert search._collections.value == ['ns.mycollection', 'ansible_collections.ansible.builtin', 'ansible_collections.community.general']

# Generated at 2022-06-22 13:51:26.406520
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys
    import json

    # set up the module args that would be passed into lib
    if len(sys.argv) > 1:
        module_args = json.loads(to_bytes(sys.argv[1]))
    else:
        module_args = dict(
            a=dict(default="Hello", type='str'),
        )

    # create a config object
    config = dict()

    # initialize the module with all the parameters above
    module = AnsibleModule(argument_spec=module_args,
                           supports_check_mode=True)
    pathname = os.path.dirname(sys.modules[__name__].__file__)

# Generated at 2022-06-22 13:51:28.889319
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test = CollectionSearch()
        assert test.collections is not None # Has default value
        test2 = CollectionSearch(collections=[_ensure_default_collection, 'test.test']) # Has custom list
        assert test2.collections == ['test.test']
    except:
        raise Exception

# Generated at 2022-06-22 13:51:36.577673
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    assert test_instance._collections == _ensure_default_collection()
    assert 'ansible.builtin' not in test_instance._collections
    assert 'ansible.legacy' in test_instance._collections
    test_instance._collections = ['ansible.builtin']
    assert test_instance._collections == ['ansible.builtin', 'ansible.legacy']
    test_instance._collections = ['ansible.builtin', 'ansible.legacy']
    assert test_instance._collections == ['ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-22 13:51:41.851952
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = [
        "my_namespace.my_collection",
        "my_other_namespace.my_other_collection",
        ]
    assert cs.collections == [
        "my_namespace.my_collection",
        "my_other_namespace.my_other_collection",
        ]

# Generated at 2022-06-22 13:51:43.947096
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test that the constructor does not fail
    assert CollectionSearch() is not None

# Generated at 2022-06-22 13:51:47.244643
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert issubclass(CollectionSearch, object)


# Unit test to check the method _load_collections of class CollectionSearch
# To check the method _load_collections.
# Checks the method works correctly or not.

# Generated at 2022-06-22 13:51:50.376374
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()
    assert isinstance(cs.collections, list)
    assert len(cs.collections) == 1



# Generated at 2022-06-22 13:52:04.051706
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class FakeImport:
        # class attribute
        collections = ['collections', 'collections2']
        _collections = ['collections', 'collections2']

    # Instantiate test class
    t = CollectionSearch()
    # Get attribute collections
    attr = t.get_attr_value('collections', fake_import=FakeImport())

    # Compare values
    assert attr == ['collections', 'collections2']

# Generated at 2022-06-22 13:52:05.999042
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch), "Invalid type for CollectionSearch()"

# Generated at 2022-06-22 13:52:16.279316
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test _ensure_default_collection()
    collection = CollectionSearch()
    collection_list = None
    result = collection._ensure_default_collection(collection_list)
    assert result == ['ansible_collections.ansible.builtin']

    # test _collections()
    collection_list = ['ansible_collections.example_collection.example_role']
    collection._collections = collection_list
    assert collection._collections == collection_list

    # test _load_collections()
    attr = None
    ds = 'ansible_collections.ansible.builtin'
    result = collection._load_collections(attr, ds)
    assert result == ['ansible_collections.example_collection.example_role', 'ansible_collections.ansible.builtin']

# Generated at 2022-06-22 13:52:21.300624
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ["ansible_namespace1.collection1"]
    ansible_namespace, collection = cs.collections[0].split('.')
    assert (ansible_namespace == "ansible_namespace1")
    assert (collection == "collection1")

# Generated at 2022-06-22 13:52:27.164557
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task import Task
    my_task = Task()
    my_task.collections = ['test.collection1', 'test.collection2']
    assert 2 == len(my_task.collections)
    assert 'test.collection1' == my_task.collections[0]
    assert 'test.collection2' == my_task.collections[1]

# Generated at 2022-06-22 13:52:29.220932
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with pytest.raises(ValueError) as err:
        search = CollectionSearch()
    assert 'collections cannot be templated and must be a list.' in err.value.args[0]

# Generated at 2022-06-22 13:52:31.214243
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert isinstance(search, CollectionSearch)



# Generated at 2022-06-22 13:52:33.235133
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default == _ensure_default_collection

# Generated at 2022-06-22 13:52:34.272734
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search

# Generated at 2022-06-22 13:52:37.031393
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_dict = {'collections': ['test_collection1']}
    collections = CollectionSearch()
    collections._load_collections(attr='collections', ds=test_dict)

# Generated at 2022-06-22 13:52:51.458973
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert(isinstance(obj,CollectionSearch))

# Generated at 2022-06-22 13:52:57.760946
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        ds = ['ansible_collections.azure.azcollection.azure']
        display.warning("hi")
        obj = CollectionSearch()
        obj._load_collections("collections", ds)
    except Exception as e:
        print(e)
        

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:53:02.578714
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test function call without collections
    cs = CollectionSearch()
    assert (cs._collections == 'ansible.legacy')

    # test function call with collections
    cs = CollectionSearch(collection_list=['foo.bar', 'ansible.legacy'])
    assert (cs._collections == 'foo.bar')


# Generated at 2022-06-22 13:53:03.421125
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-22 13:53:04.395477
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test is not None

# Generated at 2022-06-22 13:53:05.467258
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection

# Generated at 2022-06-22 13:53:08.945330
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # this is a weak test
    assert cs._load_collections(None, None) is None

# Generated at 2022-06-22 13:53:11.656613
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == cs._load_collections('collections', {'collections': None})

# Generated at 2022-06-22 13:53:16.874049
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test Case 1:
    # Correct Argument
    CollectionSearch(_collections = ['ansible'])
    # Test Case 2:
    # InCorrect Argument
    #CollectionSearch(_collections = {})
    # Expected result:
    # Error Result is expected as _collections is expected to be a list

# Generated at 2022-06-22 13:53:20.419041
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # Test the static attribute collections is populated 
    assert cs._collections.default() == ['ansible.builtin.tasks', 'ansible.legacy']

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-22 13:53:37.936591
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible_collections.ansible.builtin']
    assert cs._collections
    assert cs._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-22 13:53:38.423457
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()

# Generated at 2022-06-22 13:53:43.734073
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # pre-declaring the default collection is not required.
    # But we want to test the implicit default collection.
    test_case = CollectionSearch(collections=['my.awesome.collection', 'ansible.builtin'])
    assert test_case._collections == ['my.awesome.collection', 'ansible.builtin', 'ansible.posix']

# Generated at 2022-06-22 13:53:48.536391
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("-")
    print("CollectionSearch()")
    task = CollectionSearch()
    print("-")
    print("task.collections = ['test']")
    task.collections = ['test']
    print("-")
    print("task.collections:", task.collections)
    print("-")


test_CollectionSearch()

# Generated at 2022-06-22 13:54:00.563872
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test case: No collection specified
    # Expect: Use default collection as the one and only collection
    test_CollectionSearch_no_collection = CollectionSearch()
    assert len(test_CollectionSearch_no_collection._collections) == 1
    assert test_CollectionSearch_no_collection._collections[0] == AnsibleCollectionConfig.default_collection

    # Test case: collections specified when initializing object
    # Expect: Collections specified to be used
    test_collections = ['col1', 'col2']
    test_CollectionSearch_with_specified_collections = CollectionSearch(collections=test_collections)
    assert len(test_CollectionSearch_with_specified_collections._collections) == 2
    assert test_CollectionSearch_with_specified_collections._collections[0] == test_collections[0]
    assert test_Collection

# Generated at 2022-06-22 13:54:02.195761
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:54:05.872059
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.playbook.role
    collection_search = CollectionSearch()
    collection_search.post_validate(collection_search._collections, [])
    assert AnsibleCollectionConfig.default_collection
    assert AnsibleCollectionConfig.default_collection in collection_search._collections

# Generated at 2022-06-22 13:54:15.636620
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    fake_loader = AnsibleCollectionConfig()
    fake_loader.names = set(['test1.test1', 'test2.test2', 'ansible.builtin'])
    fake_loader.collection_paths = {}

    # Test default value
    ds1 = CollectionSearch()
    assert ds1.collections == ['test1.test1', 'test2.test2', 'ansible.builtin', 'ansible.legacy']

    # Test a few invalid inputs
    invalid_inputs = [['ansible'], 'a.b', (1, 2, 3), 1, {'a': 'b'}]
    for invalid_input in invalid_inputs:
        try:
            ds1.collections = invalid_input
            assert False, invalid_input
        except AttributeError:
            pass

   

# Generated at 2022-06-22 13:54:21.863846
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs1 = CollectionSearch()
    cs1.collections = ['col1']
    assert cs1._collections == ['col1']
    assert cs1.collections == ['col1']

    cs2 = CollectionSearch()
    cs2.collections = None
    assert cs2._collections == ['ansible.builtin']
    assert cs2.collections == ['ansible.builtin']

    cs3 = CollectionSearch()
    cs3.collections = []
    assert cs3.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:54:32.024924
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testcs = CollectionSearch()
    testcs.collections = ['ansible.builtin','ansible.posix','ansible.windows','ansible.network.common','ansible.amazon.aws','ansible.microsoft.windows','ansible.microsoft.azure','ansible.google.google','ansible.kubernetes','ansible.packaging','ansible.database.common','ansible.netcommon','ansible.misc','ansible.posix','ansible.windows','ansible.posix','ansible.windows','ansible.zip','ansible.archive','ansible.netconf','ansible.linux.systemd','ansible.powertools','ansible.files','ansible.posix','ansible.windows','ansible.system','ansible.posix','ansible.windows','ansible.legacy']

# Generated at 2022-06-22 13:55:01.102631
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    colSearch = CollectionSearch()
    colSearch._load_collections("collections", [])
    return colSearch.collections == ['ansible.legacy']

# Generated at 2022-06-22 13:55:02.915522
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    obj = CollectionSearch()
    assert isinstance(obj._collections, FieldAttribute)

# Generated at 2022-06-22 13:55:05.140763
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.default == _ensure_default_collection



# Generated at 2022-06-22 13:55:13.683776
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                      always_post_validate=True,
                                      static=True)

        def __init__(self, *args, **kwargs):
            super(TestCollectionSearch, self).__init__(*args, **kwargs)

    class TestCollectionSearchEmpty(TestCollectionSearch):
        pass

    class TestCollectionSearchList(TestCollectionSearch):
        _collections = ['collection1']

    class TestCollectionSearchTuple(TestCollectionSearch):
        _collections = ('collection1',)

    # when passing no values we will get back the default 'ansible_collections.bar.baz'
    t = TestCollectionSearchEmpty()
    assert t.get

# Generated at 2022-06-22 13:55:15.896138
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.__dict__ = dict()
    cs.__post_validate__()

# Generated at 2022-06-22 13:55:22.744013
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _collections = CollectionSearch()
    print(_collections)


# from ansible.parsing.mod_args import ModuleArgsParser
#
# class RoleModuleArgsParser(ModuleArgsParser):
#
#     def __init__(self, role_name, role_results, role_params, task, fail_on_undefined=False,
#                  convert_bare_vars=True, fail_on_empty_vars=True, support_check_mode=True,
#                  context_marker='', task_vars=None, **kwargs):
#         super().__init__(fail_on_undefined=fail_on_undefined, convert_bare_vars=convert_bare_vars,
#                          fail_on_empty_vars=fail_on_empty_vars, support_check_mode=

# Generated at 2022-06-22 13:55:32.476841
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_list = ['ansible.builtin']
    collection_obj = CollectionSearch()
    assert(collection_obj._collections._default == _ensure_default_collection)

    # test _ensure_default_collection() when collection_list is non-empty
    collection_list = ['ansible.builtin']
    ret = _ensure_default_collection(collection_list)
    assert(ret == collection_list)

    # test _ensure_default_collection() when collection_list is empty
    collection_list = []
    ret = _ensure_default_collection(collection_list)
    assert(ret == [])

# Generated at 2022-06-22 13:55:35.166665
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # assert return value from _load_collections()
    # assert type(collection_search._load_collections(None, [''])) == 'list'

# Generated at 2022-06-22 13:55:39.933075
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == None
    # assert cs.set_collections([]) == None
    # assert cs.collections == []
    # assert cs.set_collections(['ansible.builtin']) == ['ansible.builtin']
    # assert cs.collections == ['ansible.builtin']
    # assert cs.set_collections([]) == None
    # assert cs.collections == []

# Generated at 2022-06-22 13:55:41.505504
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_search = CollectionSearch()

# Generated at 2022-06-22 13:56:39.803158
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert 'ansible.builtin' in _ensure_default_collection(['test1.test2'])
    assert 'ansible.builtin' not in _ensure_default_collection(None)
    assert 'ansible.builtin' in _ensure_default_collection()

# Generated at 2022-06-22 13:56:40.828723
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert result

# Generated at 2022-06-22 13:56:47.892777
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    expected_result = ['ansible_collections.cisco.asa']

    return_value = AnsibleCollectionConfig.default_collection
    print('Collections default value is: ' + return_value)

    injected_value = 'ansible_collections.cisco.asa'
    print('Injected value is: ' + injected_value)
    expected_result.append(injected_value)

    print('Expected Result: ' + str(expected_result))


# print("Testing " + __file__)
# test_CollectionSearch()

# Generated at 2022-06-22 13:56:51.449843
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()
    collection_search._collections = 'test_val'
    collection_search._load_collections(attr='_collections', ds='test_val')
    assert 'test_val' == collection_search._collections

# Generated at 2022-06-22 13:56:55.003915
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.collections = ['ansible.builtin', 'ansible.legacy']
    search.collections = _ensure_default_collection(['ansible.builtin', 'ansible.legacy'])

# Generated at 2022-06-22 13:57:02.710734
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test using default collection
    obj = CollectionSearch()
    obj.post_validate({}, True)
    assert obj.collections == _ensure_default_collection()

    # Test with empty collection list
    obj = CollectionSearch()
    obj.post_validate({'collections': []}, True)
    assert obj.collections == _ensure_default_collection([])

    # Test with some collection list
    obj = CollectionSearch()
    obj.post_validate({'collections': ['test', 'test2']}, True)
    assert obj.collections == ['test', 'test2', 'ansible.builtin']

    # Test with default collection list
    obj = CollectionSearch()
    obj.post_validate({'collections': _ensure_default_collection()}, True)
    assert obj.collections == _ens

# Generated at 2022-06-22 13:57:05.407295
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj._collections)
#test_CollectionSearch()

# Generated at 2022-06-22 13:57:10.343857
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._ensure_default_collection(['col1', 'col2']) == ['col1', 'col2', 'ansible.legacy']
    assert CollectionSearch._ensure_default_collection([]) == ['ansible.legacy']
    assert CollectionSearch._ensure_default_collection(['ansible.builtin']) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:57:21.940096
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    ds = collection._collections
    x = ds.construct(None)
    assert x == _ensure_default_collection()
    x = ds.construct([])
    assert x == _ensure_default_collection([])
    x = ds.construct(['collections.ns.organization.collection_name'])
    assert x == _ensure_default_collection(['collections.ns.organization.collection_name'])
    x = ds.construct(['mycollection'])
    assert x == _ensure_default_collection(['mycollection'])
    x = ds.construct(['mycollection', 'yourcollection'])
    assert x == _ensure_default_collection(['mycollection', 'yourcollection'])

# Generated at 2022-06-22 13:57:24.324541
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == ['ansible.builtin']
    assert _ensure_default_collection(['ansible.posix']) == ['ansible.posix', 'ansible.builtin']

# Generated at 2022-06-22 13:59:21.140460
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play import Play 
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Constructor of ansible.parsing.yamlobjects.AnsibleBaseYAMLObject.__init__()
    # It just sets the _ds, _ds_pos and _ds_hash attributes of the object.
    # These are the default values.
    obj = AnsibleBaseYAMLObject({}, (None, -1), 0)

    # Constructor of ansible.playbook.base.Base.__init__()
    # For the collection_list parameter, it checks if it is None,
    # The value passed is None.
    # It does not set the collection_list attribute.
    base_obj = Base(obj)

    # Constructor of ansible.playbook.

# Generated at 2022-06-22 13:59:25.012719
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections.default == _ensure_default_collection

# Generated at 2022-06-22 13:59:28.239375
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert 'ansible.builtin' == _ensure_default_collection()[0]
    assert ['my_collections'] == _ensure_default_collection(['my_collections'])[1:]

# Generated at 2022-06-22 13:59:32.412169
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    assert cs._collections.static == True
    assert cs._collections.listof == string_types
    assert cs._collections.priority == 100
    assert cs._collections.always_post_validate == True
    assert cs._collections.default == _ensure_default_collection()

# Generated at 2022-06-22 13:59:35.007018
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj.collections is not None
    assert len(obj.collections) == 1
    assert obj.collections[0] == 'ansible.builtin'

# Generated at 2022-06-22 13:59:40.392144
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    assert cs._load_collections(None, []) == _ensure_default_collection()
    assert cs._load_collections(None, ['ansible.test']) == ['ansible.test'] + _ensure_default_collection()

# Generated at 2022-06-22 13:59:42.443736
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs._load_collections('collections',None))

# Generated at 2022-06-22 13:59:45.401168
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.collections = [
        'my_namespace.my_collection',
        'other_namespace.other_collection',
        'ansible.builtin'
    ]

# Generated at 2022-06-22 13:59:54.953181
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Task
    from ansible.playbook.task.include import Include
    from ansible.playbook.become import Become
    from ansible.playbook.connection.ssh import Connection as ConnectionSsh
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    # TODO: This data should be loaded from yaml files instead of hardcoding.
    #
    # Data taken from block_test.yaml
    # This data is created according to the logic in TaskBlock.load, so
    # it's directly equivalent to the data that would have been
    # loaded.
    #
    # For reference:
    #   name: block_test
    #   connection: local
    #

# Generated at 2022-06-22 13:59:58.723185
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    ds = ["ansible_my_collection"]
    c._load_collections("collections", ds)
    assert c._collections == [
        "ansible_my_collection", "ansible.builtin", "ansible.legacy"
    ]