

# Generated at 2022-06-22 13:51:12.456034
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Test for __init__() with no arguments
    assert cs._collections == _ensure_default_collection()
    # Test for __init__() with argument
    cs = CollectionSearch(collections=['foo'])
    assert cs._collections == _ensure_default_collection(['foo'])

# Generated at 2022-06-22 13:51:15.887855
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # Checking the default value of _collections
    assert cs._collections._value is None

    # Checking _load_collections method
    assert cs._load_collections(None, None) is None

# Generated at 2022-06-22 13:51:21.336765
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Unit test for constructor of class CollectionSearch
    """
    class TestCollectionSearch(CollectionSearch):
        def __init__(self, attr, ds):
            self._collections = self._load_collections(attr, ds)

    _CollectionSearch = TestCollectionSearch(
        attr=None,
        ds=None
    )

# Generated at 2022-06-22 13:51:32.403951
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext

    class Mixin(CollectionSearch):
        pass

    class TaskWithMixin(Base, Mixin, Task):
        # this will override the collection on Base, which is what we want to test
        _collections = [
            "ns1.test1",
            "test1.collection1",
            "test1.collection2",
        ]

    task = TaskWithMixin()
    assert task.collections == task._collections

    # check class inheritance
    assert issubclass(TaskWithMixin, Base)
    assert issubclass(TaskWithMixin, Task)

# Generated at 2022-06-22 13:51:33.012862
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, None) is None

# Generated at 2022-06-22 13:51:34.076516
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible_collections.test_collections.namespace.test', 'ansible.builtin']

# Generated at 2022-06-22 13:51:39.040691
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin']
    assert c.get_validated_value('collections', c._collections, ['test'], None) == ['test', 'ansible.builtin']
    assert c.get_validated_value('collections', c._collections, None, None) is None
    assert c.get_validated_value('collections', c._collections, ['test'], None) == ['test', 'ansible.builtin']

# Generated at 2022-06-22 13:51:51.002028
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    play_context = PlayContext()
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    play = Play().load(play_source, variable_manager=None, loader=None)

# Generated at 2022-06-22 13:51:52.845121
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_cs = CollectionSearch()
    assert test_cs._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:51:54.921489
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    task = CollectionSearch()

    assert task._collections == 'ansible.builtin,ansible.legacy'

# Generated at 2022-06-22 13:52:03.228083
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default

# Generated at 2022-06-22 13:52:09.122784
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    # test default attribute - collections
    assert isinstance(instance._collections, FieldAttribute)
    assert instance._collections.default == _ensure_default_collection
    # test default attribute - name
    assert instance._name is None
    # test default attribute - task
    assert isinstance(instance._task, FieldAttribute)
    assert instance._task.default is None

# Generated at 2022-06-22 13:52:10.304592
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    assert collectionsearch is not None

# Generated at 2022-06-22 13:52:12.600227
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection(collection_list=None)

# Generated at 2022-06-22 13:52:14.694757
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    assert isinstance(test_instance, CollectionSearch)

# Generated at 2022-06-22 13:52:15.307333
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()

# Generated at 2022-06-22 13:52:18.367330
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch(_collections=['r1'])._collections == ['r1']
    assert CollectionSearch(_collections=['r1', 'r2'])._collections == ['r1', 'r2']



# Generated at 2022-06-22 13:52:28.235030
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def test_create_instance(collection_list=None):
        collection_search = CollectionSearch()
        assert collection_search._collections is None
        # Always include default collection
        assert collection_search._load_collections('collections', collection_list) == _ensure_default_collection(collection_list)
    test_create_instance()
    test_create_instance(['foo', 'bar'])
    test_create_instance(['foo', 'bar', 'ansible.builtin', 'ansible.legacy'])
    test_create_instance(['foo', 'bar', 'ansible.builtin', 'ansible.legacy', 'foo'])

# Generated at 2022-06-22 13:52:29.378990
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch,'_collections')

# Generated at 2022-06-22 13:52:31.378717
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:52:52.062111
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert (CollectionSearch._collections.default(None) ==
            AnsibleCollectionConfig.default_collection)

    c = CollectionSearch()
    assert c._load_collections('collections', ['my_namespace.my_collection', 'my_namespace.my_other_collection']) == \
        ['my_namespace.my_collection', 'my_namespace.my_other_collection']

    assert c._load_collections('collections', []) is None

# Generated at 2022-06-22 13:52:55.853959
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    collection.post_validate( {}, {}, {}, {} )
    #print("collection value;",vars(collection))

    #assert collection.collections == ['ansible.builtin']

# Generated at 2022-06-22 13:52:58.585416
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections is None
    assert a._load_collections('collections', 'ansible.builtin') is None

# Generated at 2022-06-22 13:52:59.079175
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    var1 = CollectionSearch()
    assert var1

# Generated at 2022-06-22 13:53:08.878747
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.abstract import PlayContext
    from ansible.playbook.play_context import PlayContext

    attrs = PlayContext._get_attributes()

    assert attrs
    assert isinstance(attrs, dict)
    assert attrs.get('collections')
    assert isinstance(attrs.get('collections'), FieldAttribute)
    assert attrs.get('collections').default == _ensure_default_collection
    assert attrs.get('collections').priority == 100
    assert attrs.get('collections').static
    assert attrs.get('collections').listof is str

    # TODO: Write a test case to check the other methods in the class
    obj = CollectionSearch()
    # TODO: Write a test to check the collection name is not a template

# Generated at 2022-06-22 13:53:14.377795
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    #assert cs.collections is None
    #assert cs._collections is None
    #assert cs._validated_attributes.get('collections') is None
    assert cs._collections(collections=None) == ['ansible.builtin']

# Generated at 2022-06-22 13:53:16.162262
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    inst = CollectionSearch()
    assert inst.collections == ['ansible_collections.nsg.network']

# Generated at 2022-06-22 13:53:17.729550
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    print(collectionSearch.__dict__)

# Generated at 2022-06-22 13:53:19.041105
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:53:21.054179
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()
    assert isinstance(coll, CollectionSearch)

# Generated at 2022-06-22 13:53:49.105446
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections == collectionSearch._ensure_default_collection()

# Generated at 2022-06-22 13:54:01.085278
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    from ansible.playbook.attribute import FieldAttribute
   
    class Mock:
        # the mock data that this class needs to define 
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                      always_post_validate=True, static=True)
        def get_validated_value(self, name, attr, value, validate_filters=None, context=None):
            return value

    test_instance = CollectionSearch()
    test_instance.__class__ = Mock

    # test that the post validate method adds the default collection to the front of the list
    test_instance._validated_value('collections', ['ansible.posix'])

# Generated at 2022-06-22 13:54:09.300391
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.utils.collection_loader
    loader = ansible.utils.collection_loader.AnsibleCollectionConfig
    loader._default_collection = 'ansible.collections.ansible_collections.testing.test_collection'

    search_obj = CollectionSearch()
    with_default_collection = search_obj._load_collections(None, ['ansible.builtin', 'ansible.legacy'])
    assert with_default_collection[0] == loader._default_collection

    no_default_set = search_obj._load_collections(None, [])
    assert no_default_set[0] == 'ansible.builtin'

    loader._default_collection = None

# Generated at 2022-06-22 13:54:10.091920
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    print(search._collections)

# Generated at 2022-06-22 13:54:11.477134
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert(a.collections == _ensure_default_collection())

# Generated at 2022-06-22 13:54:14.513057
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

    print('Search collections = %s' % search.collections)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-22 13:54:17.230365
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == cs.collections
    assert cs.collections == ['ansible.builtin']
    assert not cs.collections == ['ansible.built']


# Generated at 2022-06-22 13:54:21.779363
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    attr = 'collections'
    ds = AnsibleSequence([AnsibleUnicode('ansible.builtin'), AnsibleUnicode('collection_name')])
    cs = CollectionSearch()
    cs._load_collections(attr, ds)

# Generated at 2022-06-22 13:54:23.751458
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()
    assert c._collections_list is None



# Generated at 2022-06-22 13:54:24.902249
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    module = CollectionSearch()
    assert module._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:55:18.126463
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    return c

# Generated at 2022-06-22 13:55:26.412168
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()

# Generated at 2022-06-22 13:55:27.403888
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-22 13:55:35.729802
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collections = collection_search._load_collections('test', ['dummy_collection'])
    assert collections == None
    collections = collection_search._collections
    assert collections == None
    collections = collection_search._load_collections('test', None)
    assert collections == None
    collections = collection_search._load_collections('test', [])
    assert collections == None
    collections = collection_search._collections
    assert collections == None
    collections = collection_search._load_collections('test', None)
    assert collections == None

# Generated at 2022-06-22 13:55:42.358920
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import collection_loader

    import ansible.constants
    ansible.constants.COLLECTIONS_PATHS = ['ansible_collections', 'test/test_plugins/test_collections']

    collection_loader.clear_collection_resolver_cache()
    collection_loader.get_all_plugin_loaders()

    base_dir = 'test/test_plugins/test_collections/ansible_ns.test_coll/tasks/'

    # Test without collections option
    task_vars = dict(
        target_host='testhost',
        ansible_collection_name='ansible_ns.test_coll'
    )
    play_context = PlayContext()
    loader, inventory, variable_

# Generated at 2022-06-22 13:55:44.031167
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collectionsearch_obj = CollectionSearch()
    assert test_collectionsearch_obj._collections is not None

# Generated at 2022-06-22 13:55:46.942259
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    dummy = CollectionSearch()
    # the following assert statement keeps track of values initialized in constructor
    assert dummy.collections == ['ansible_collections.community.general']
    assert dummy._collections == ['ansible_collections.community.general']

# Generated at 2022-06-22 13:55:57.017977
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test empty collection list, None
    test_collection_search = CollectionSearch()
    assert test_collection_search._load_collections(None, None) == None

    # test collection list, None
    test_collection_search = CollectionSearch()
    assert test_collection_search._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']

    # test empty collection list, []
    test_collection_search = CollectionSearch()
    assert test_collection_search._load_collections(None, []) == None

    # test collection list, ['ansible.builtin']
    test_collection_search = CollectionSearch()
    assert test_collection_search._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']

    # test collection list, ['ansible.leg

# Generated at 2022-06-22 13:56:07.387710
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test a valid collection list
    search = CollectionSearch()
    search.collections = ['foo', 'bar']
    assert search.collections == ['foo', 'bar']
    assert len(search.collections) == 2

    # test a valid collection list with the default collection.
    search = CollectionSearch()
    search.collections = ['foo']
    assert search.collections == ['foo']
    assert len(search.collections) == 1

    # test an invalid collection list
    search = CollectionSearch()
    search.collections = ['!@#$']
    assert search.collections == ['!@#$']
    assert len(search.collections) == 1


# Generated at 2022-06-22 13:56:09.740083
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections is not None
    assert len(CollectionSearch._collections._constructor_args) > 0

# Generated at 2022-06-22 13:57:57.707163
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-22 13:57:59.341301
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-22 13:58:00.598335
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections.patt

# Generated at 2022-06-22 13:58:12.405870
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # What if I pass a list?
    collection = CollectionSearch(collections=['my.collection'])
    assert collection._validated_attributes['collections'] == ['my.collection', 'ansible.builtin', 'ansible.legacy']

    # What if I don't pass a list?
    collection = CollectionSearch()
    assert collection._validated_attributes['collections'] == ['ansible.builtin', 'ansible.legacy']

    # What if I pass a string?
    collection = CollectionSearch(collections='my.collection')
    assert collection._validated_attributes['collections'] == ['my.collection', 'ansible.builtin', 'ansible.legacy']

    # What if I don't pass anything?
    collection = CollectionSearch()

# Generated at 2022-06-22 13:58:18.440097
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    role_definition = RoleDefinition()
    assert role_definition.collections is not None
    assert role_definition.collections.listof is string_types
    assert role_definition.collections.default == _ensure_default_collection()
    assert role_definition.collections._attribute_class is FieldAttribute
    assert isinstance(role_definition.collections, FieldAttribute)

# Generated at 2022-06-22 13:58:24.070655
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test parameter name = collections, run post_validate function, expected result: default value of parameter collections
    assert _ensure_default_collection(collection_list=None) == ['ansible.builtin']

    # test parameter name = collections, run post_validate function, expected result: return collection_list
    collection_list = ['ansible.builtin', 'ansible.builtin']
    assert _ensure_default_collection(collection_list) == ['ansible.builtin', 'ansible.builtin']

    # test parameter name = collections, run post_validate function, expected result: collection_list append 'ansible.legacy'
    collection_list = ['ansible.builtin']
    assert _ensure_default_collection(collection_list) == ['ansible.builtin', 'ansible.legacy']

# Unit test

# Generated at 2022-06-22 13:58:27.235562
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._load_collections('collections', []) == ['ansible.builtin']

# Generated at 2022-06-22 13:58:28.745935
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == 'ansible.builtin'

# Generated at 2022-06-22 13:58:30.300072
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t._collections == 'ansible.legacy'

# Generated at 2022-06-22 13:58:31.605701
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    m = CollectionSearch()
    assert m.collections is None