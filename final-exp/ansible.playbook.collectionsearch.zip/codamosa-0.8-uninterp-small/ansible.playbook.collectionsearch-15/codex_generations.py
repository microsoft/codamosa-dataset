

# Generated at 2022-06-25 05:03:27.227071
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()



# Generated at 2022-06-25 05:03:29.935408
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_obj = CollectionSearch()
    assert(collection_search_obj is not None)

# Generated at 2022-06-25 05:03:30.769788
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0.collections == _ensure_default_collection()

# Generated at 2022-06-25 05:03:37.256661
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert(collection_search._collections == _ensure_default_collection())
    assert(collection_search._collections.priority == 100)
    assert(collection_search._collections.default == _ensure_default_collection)
    assert(collection_search._collections.always_post_validate)
    assert(collection_search._collections.static)



# Generated at 2022-06-25 05:03:40.419447
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == _ensure_default_collection()



# Generated at 2022-06-25 05:03:42.331166
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Testing constructor of class CollectionSearch
    collection_search_1 = CollectionSearch()
    # Assert of attribute collections
    assert isinstance(collection_search_1._collections, dict)



# Generated at 2022-06-25 05:03:43.251873
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()

    # test return value
    assert(isinstance(collection_search_0, CollectionSearch))

# Generated at 2022-06-25 05:03:44.573333
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_case_0()
    except Exception:
        assert False

# Generated at 2022-06-25 05:03:45.297525
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print(CollectionSearch)

# Generated at 2022-06-25 05:03:46.807375
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert collection_search_0._collections == []
    assert collection_search_0.search_path == []


# Generated at 2022-06-25 05:03:56.721045
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Will create a new class dynamically to use for the unit test
    class MockCollectionSearch(CollectionSearch):

        # This is a class that needs to be populated before we can resolve tasks/roles/etc
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                      always_post_validate=True, static=True)
    mock_collection_search = MockCollectionSearch()
    assert mock_collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:03:58.426472
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collections = collection_search._load_collections(0, ['ansible.legacy'])
    expected = ['ansible.builtin', 'ansible.legacy']
    assert collections == expected

# Generated at 2022-06-25 05:03:59.666773
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(CollectionSearch._collections.default() == _ensure_default_collection())

# Generated at 2022-06-25 05:04:05.141166
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("Testing CollectionSearch constructor")
    co = CollectionSearch()
    co._load_collections('test', 'testcommand')
    assert(co._collections == _ensure_default_collection('testcommand'))


# Generated at 2022-06-25 05:04:05.995167
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearchObj = CollectionSearch()
    assert collectionSearchObj._collections == ['ansible.builtin']

# Generated at 2022-06-25 05:04:15.040893
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole

    class MyClass(Base):
        # FIXME: this is a hack so we can use this class to test the attribute:
        #        we need to add it as a child role so the loader will load it

        _load_priority = 1000
        _roles = FieldAttribute(isa='list', default=[], listof='Role')

        def __init__(self):
            self._roles = IncludeRole()

    # FIXME: this should really be in the loader
    my_class = MyClass()
    if my_class._roles:
        my_class._roles.resolve_parent()
    assert my_class.collections is not None

    my_class.col

# Generated at 2022-06-25 05:04:16.895136
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    csr = CollectionSearch()
    assert csr._collections == ['ansible.builtin']
    assert isinstance(csr._collections, list)

# Generated at 2022-06-25 05:04:22.068578
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = AnsibleCollectionConfig.default_collection
    search = CollectionSearch()
    assert search._collections.default() == [test]

# Generated at 2022-06-25 05:04:24.350582
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search is not None
    assert search.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:04:27.473163
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)


# Generated at 2022-06-25 05:04:35.622765
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    #check if the field is initialized correctly
    assert type(result._collections) is FieldAttribute

# Generated at 2022-06-25 05:04:38.422262
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        def __init__(self):
            super(TestCollectionSearch, self).__init__()

    tcs = TestCollectionSearch()

    assert tcs.__dict__.get('_collections') == ['ansible.builtin']

# Generated at 2022-06-25 05:04:40.963662
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['ansible_collections.craigdallimore.log_capture']

# Generated at 2022-06-25 05:04:43.868435
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()
    # set value
    coll.collections = [ 'ansible.builtin', 'ansible.netcommon' ]
    assert coll.collections == ['ansible.builtin', 'ansible.netcommon']
    # get value
    assert coll.get_value('collections') == ['ansible.builtin', 'ansible.netcommon']

# Generated at 2022-06-25 05:04:47.428758
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch._ensure_default_collection, Callable)


# Generated at 2022-06-25 05:04:56.229872
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Test the constructor for CollectionSearch
    """
    # Check that the _collections variable is a FieldAttribute with the correct attributes
    assert isinstance(CollectionSearch._collections, FieldAttribute)
    assert CollectionSearch._collections.isa == 'list'
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.listof == string_types
    assert CollectionSearch._collections.always_post_validate is True
    assert CollectionSearch._collections.static is True



# Generated at 2022-06-25 05:04:58.111002
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_defaul

# Generated at 2022-06-25 05:05:04.018836
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    CollectionSearch class constructor test
    """
    import pytest
    from ansible.playbook.role.definition import RoleDefinition
    base_obj = RoleDefinition()
    col_search_obj = CollectionSearch()
    col_search_obj._collections = base_obj._collections
    col_search_obj._load_collections

# Generated at 2022-06-25 05:05:12.644651
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Constructor of class CollectionSearch
    cs = CollectionSearch()
    cs.post_validate(ds={}, var_name='collections')

    # Test Case 1: Check variable _collections set correctly with default value
    assert cs.post_validate(ds={'collections': 'ansible.legacy'}, var_name='collections') == 'ansible.legacy'

    # Test Case 1: Check variable _collections set correctly with user defined value
    assert cs.post_validate(ds={'collections': 'ansible_collections.nsot.collectionz'}, var_name='collections') == 'ansible_collections.nsot.collectionz'

# Generated at 2022-06-25 05:05:13.814384
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-25 05:05:30.558467
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch(vars={})

    if cs._collections.default() != _ensure_default_collection():
        return False
    else:
        return True


# Generated at 2022-06-25 05:05:32.649697
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Test for constructor of class CollectionSearch
    """
    assert CollectionSearch
    assert CollectionSearch._collections



# Generated at 2022-06-25 05:05:34.080114
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections._default == _ensure_default_collection

# Generated at 2022-06-25 05:05:37.107932
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    assert cs._load_collections('collections', None) is None
    assert cs._load_collections('collections', []) == []
    assert cs._load_collections('collections', ['ns']) == ['ns']

# Generated at 2022-06-25 05:05:42.372843
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.display import Display
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collections_loader import _get_collection_roles
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-25 05:05:45.621878
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections is not None
    assert collection._collections == ['ansible_collections.ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:05:51.467934
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Arrange
    expected = ['foo', 'bar', 'ansible.builtin']

    # Act
    actual = CollectionSearch._ensure_default_collection(expected)

    # Assert
    assert actual == expected

# Generated at 2022-06-25 05:06:01.513113
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    loader = CollectionSearch()
    loader.collections = ['test']
    # Test for validation of collections for ansible.builtin and ansible.legacy collection

# Generated at 2022-06-25 05:06:02.431757
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-25 05:06:07.928992
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert isinstance(a._collections, list)
    assert isinstance(a._collections[0], string_types)

# Generated at 2022-06-25 05:06:38.470292
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    object = CollectionSearch()

    collections = object.collections
    collection_list = collections.default(object, None)

    assert 'ansible.builtin' in collection_list
    assert 'ansible.legacy' in collection_list
    assert 'ansible_collections.galaxyproject.io.ansible_collections.azure' in collection_list

# Generated at 2022-06-25 05:06:43.897533
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.__class__.__name__ == "CollectionSearch"
    assert c._collections == _ensure_default_collection()


# Generated at 2022-06-25 05:06:46.368660
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test for FieldAttribute
    d = CollectionSearch()
    ds = dict()
    assert ds == d._collections
    ds = dict(collections=['1', '2'])
    assert ds == d._collections

# Generated at 2022-06-25 05:06:48.390872
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection([]) == ['ansible.builtin','ansible.legacy']
    assert _ensure_default_collection(None) == ['ansible.builtin','ansible.legacy']

# Generated at 2022-06-25 05:06:54.781202
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    t.from_yaml('- foo.bar')
    assert t.collections == ['foo.bar']
    assert t.from_yaml(['foo.bar']).collections == ['foo.bar']


if __name__ == '__main__':
    c = CollectionSearch()
    c.from_yaml('azure_preview_modules')
    print(c.collections)

# Generated at 2022-06-25 05:06:59.005421
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # We are always a mixin with Base, so we can validate this untemplated
    # field early on to guarantee we are dealing with a list.
    # ds = self.get_validated_value('collections', self._collections, ds, None)

    assert cs._collections == _ensure_default_collection()
    assert cs._collections != _ensure_default_collection([])
    assert cs._collections is not None

# Generated at 2022-06-25 05:07:09.428021
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # collection_list = None
    collection_search = CollectionSearch()
    assert collection_search.get_validated_value('collections', collection_search._collections, None, None) == ["ansible_collections.ansible.builtin"]

    # collection_list = ['collection_name']
    collection_search = CollectionSearch()
    ds = ['collection_name']
    assert collection_search.get_validated_value('collections', collection_search._collections, ds, None) == ["collection_name", "ansible_collections.ansible.builtin"]

    # collection_list = ['collection_1', 'collection_2']
    collection_search = CollectionSearch()
    ds = ['collection_1', 'collection_2']

# Generated at 2022-06-25 05:07:11.004093
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default() == ['ansible.builtin']



# Generated at 2022-06-25 05:07:14.665928
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class A(CollectionSearch):
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)
    d = {}
    A(ds=d)

# Generated at 2022-06-25 05:07:16.727632
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == None
    assert cs._load_collections(attr = None, ds = None) == None


# Generated at 2022-06-25 05:08:26.776561
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    #constructor should set collections value to ansible.legacy
    assert instance._collections == ['ansible.legacy']

# Generated at 2022-06-25 05:08:27.789975
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    newCollectionSearch = CollectionSearch()
    assert newCollectionSearch._collections == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-25 05:08:30.743719
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display.warning("CollectionSearch unit test not implemented yet")

# Generated at 2022-06-25 05:08:33.355441
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections("test", ["collection"]) == ["collection"]

# Generated at 2022-06-25 05:08:35.064827
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections is not None

# Generated at 2022-06-25 05:08:45.201993
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        @property
        def collections(self):
            return self._collections

        def get_validated_value(self, attr, ds, value_name, value, validate_conditions=None):
            return super(TestCollectionSearch, self).get_validated_value(attr, ds, value_name, value, validate_conditions)

    test_collection_search = TestCollectionSearch()

    class TestDS:
        def __init__(self, task_name):
            self._ds = {
                'name': task_name,
                'collections': 'test_collection',
            }

        def __getattr__(self, att):
            return self._ds[att]

    test_ds = TestDS('test_ds')
    assert test_collection_search.get_valid

# Generated at 2022-06-25 05:08:46.648395
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert result.__dict__['_collections']._default == _ensure_default_collection, "Should not be None"

# Generated at 2022-06-25 05:08:53.834201
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch._load_collections(None, "test") == ['test']
    assert test_CollectionSearch._load_collections(None, []) is None
    assert test_CollectionSearch._load_collections(None, None) == ['ansible.builtin']
    assert test_CollectionSearch._load_collections(None, ['test', 'test1']) == ['test', 'test1']
    assert test_CollectionSearch._load_collections(None, "ansible.builtin") == ['ansible.builtin']
    assert test_CollectionSearch._load_collections(None, ["ansible.builtin", 'test1']) == ['ansible.builtin', 'test1']

# Generated at 2022-06-25 05:08:56.957585
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is not None


# Generated at 2022-06-25 05:09:00.106502
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == [AnsibleCollectionConfig.default_collection]
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:11:35.629027
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections == _ensure_default_collection()
    assert a._load_collections(None, None) == _ensure_default_collection()

# Generated at 2022-06-25 05:11:45.868483
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert(cs._collections is cs.collections)
    assert(cs._collections.name == 'collections')
    assert(cs._collections.isa == 'list')
    assert(cs._collections.listof == string_types)
    assert(cs._collections.priority == 100)
    assert(cs._collections.is_identity is False)
    assert(cs._collections.is_data is False)
    assert(cs._collections.is_template is False)
    assert(cs._collections.is_static is True)
    assert(cs._collections.parent is None)
    assert(cs._collections.keys() == [])
    assert(cs._collections.default == _ensure_default_collection)

# Generated at 2022-06-25 05:11:49.363391
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert(isinstance(collection_search, CollectionSearch))

# Generated at 2022-06-25 05:11:55.570153
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    task_include = TaskInclude(task=Task())

    # Default value of collections
    assert task_include.collections == _ensure_default_collection()

# Generated at 2022-06-25 05:11:59.292888
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    target = CollectionSearch()
    assert isinstance(target.collections, list)
    assert len(target.collections) >= 1
    assert 'ansible.builtin' in target.collections
    assert 'ansible.legacy' not in target.collections

# Generated at 2022-06-25 05:12:02.861711
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()
    if(test_object):
        assert True
    else:
        assert False

# Generated at 2022-06-25 05:12:05.139693
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections is None


# Generated at 2022-06-25 05:12:10.024601
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # The first item of list is `ansible.builtin` or `ansible.legacy`
    assert collection_search._collections[0] == 'ansible.builtin' or \
            collection_search._collections[0] == 'ansible.legacy'
    # The second item of list is the default collection
    assert collection_search._collections[1] == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-25 05:12:14.452561
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(type(obj))
    print(type(obj._collections))
    print(type(obj._load_collections))



# Generated at 2022-06-25 05:12:15.656091
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Load class
    cs = CollectionSearch()
    assert cs._collections is _ensure_default_collection