

# Generated at 2022-06-25 05:03:34.435848
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    collection_search_0.post_validate()
    if collection_search_0._collections != _ensure_default_collection():
        raise AssertionError("Field collections is not equal to expected result")
    collection_search_1 = CollectionSearch(collections=['ansible.builtin'])
    collection_search_1.post_validate()
    if collection_search_1._collections != ['ansible.builtin']:
        raise AssertionError("Field collections is not equal to expected result")
    collection_search_2 = CollectionSearch(collections=['ansible.builtin', 'ansible.builtin'])
    collection_search_2.post_validate()
    if collection_search_2._collections != ['ansible.builtin']:
        raise Assert

# Generated at 2022-06-25 05:03:34.900634
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:03:35.968971
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    q = CollectionSearch()
    assert type(q) == CollectionSearch

# Generated at 2022-06-25 05:03:43.219165
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == ['ansible.builtin', 'ansible.legacy']
    ds_0 = [u'{{ ansible_collections.nginx }}']
    collection_search_0._collections = collection_search_0._load_collections(_, ds_0)
    assert collection_search_0._collections == ds_0

# Generated at 2022-06-25 05:03:44.127722
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert(collection_search_0._collections.default_factory() == _ensure_default_collection())

# Generated at 2022-06-25 05:03:51.535937
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    cs = CollectionSearch()

    assert cs._load_collections("collections", "ansible.builtin") == "ansible.builtin"
    assert cs._load_collections("collections", ["ansible.builtin"]) == ["ansible.builtin"]

    assert cs._load_collections("collections", None) == ["ansible.builtin", "ansible.legacy"]
    assert cs._load_collections("collections", []) == ["ansible.builtin", "ansible.legacy"]
    assert cs._load_collections("collections", ["ansible.builtin", "ansible.legacy"]) == ["ansible.builtin", "ansible.legacy"]

# Generated at 2022-06-25 05:03:53.048270
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:03:54.175352
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    assert collection_search.collections == ['ansible.builtin']

# Generated at 2022-06-25 05:03:57.443266
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search


# Generated at 2022-06-25 05:03:58.994256
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert isinstance(collection_search_0, CollectionSearch)

# Generated at 2022-06-25 05:04:09.051085
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0.collections == None
    assert collection_search_0._collections == _ensure_default_collection()


# Generated at 2022-06-25 05:04:10.362303
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()

# Generated at 2022-06-25 05:04:12.230554
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        #Unit test for constructor of class CollectionSearch
        test_case_0()
    except Exception as e:
        print("Exception in creating object for the class CollectionSearch",e)

# Generated at 2022-06-25 05:04:13.652264
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()

if __name__ == '__main__':
    test_case_0()
    test_CollectionSearch()

# Generated at 2022-06-25 05:04:16.124418
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()


# Generated at 2022-06-25 05:04:17.600656
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # default value
    assert CollectionSearch().collections == _ensure_default_collection()


# Generated at 2022-06-25 05:04:25.429044
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # When there is no value for attribute 'collections'
    collection_search_1 = CollectionSearch()
    assert collection_search_1.get_value('collections') == ['ansible_collections.ansible.builtin', 'ansible.legacy']
    # When there is a value for attribute 'collections'
    collection_search_2 = CollectionSearch(collections=['collections.test'])
    assert collection_search_2.get_value('collections') == ['collections.test', 'ansible_collections.ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:04:31.927362
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']
    assert cs._load_collections(1, 2) == None

    # Set _collections to a non-empty list and test if it is set correctly
    cs = CollectionSearch()
    cs._collections = ['col1']
    assert cs._collections == ['col1']
    assert cs._load_collections(1, 2) == ['col1']

# Generated at 2022-06-25 05:04:34.161056
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == _ensure_default_collection()


# Generated at 2022-06-25 05:04:35.916380
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections.default == _ensure_default_collection()


# Generated at 2022-06-25 05:04:50.682689
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:04:54.261303
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = dict(
        collections=['collection1', 'collection2', 'collection3']
    )
    collection_search = CollectionSearch()
    collection_search._load_collections(None, ds)
    assert collection_search.collections == ds['collections']


# Generated at 2022-06-25 05:04:55.080494
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:05:06.658254
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test 1
    collection_search_1 = CollectionSearch()
    assert collection_search_1._collections == _ensure_default_collection()

    # Test 2
    collection_search_2 = CollectionSearch(collections=['my.collection'])
    assert collection_search_2._collections == _ensure_default_collection(['my.collection'])

    # Test 3
    collection_search_3 = CollectionSearch(collections=['my.collection'])
    ds = {
        'collections': ['test.test'],
    }

    assert collection_search_3._load_collections('collections', ds) == _ensure_default_collection(['test.test'])

    # Test 4
    collection_search_4 = CollectionSearch(collections=['my.collection'])

# Generated at 2022-06-25 05:05:12.055997
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Calling the constructor of the class CollectionSearch
    collection_search_0 = CollectionSearch()

    # Getting the value of attribute _collections of instance collection_search_0
    value = collection_search_0._collections

    # Getting type of attribute _collections
    type = collection_search_0._get_fields()['_collections'].get_type()

    # Checking if value and type are equal to their expected values
    assert value == _ensure_default_collection() and type == "list"


# Generated at 2022-06-25 05:05:16.370326
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    # test __init__()
    assert collection_search_0.__init__()
    # test _load_collections()
    assert collection_search_0._load_collections()
    # test _ensure_default_collection()
    assert _ensure_default_collection()

# Generated at 2022-06-25 05:05:21.027514
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0.collections == _ensure_default_collection()



# Generated at 2022-06-25 05:05:22.906402
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()


# Generated at 2022-06-25 05:05:33.305837
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Case 1: collections is None
    result = collection_search_0.get_validated_value('collections', collection_search_0._collections, None, None)
    assert result == ['ansible.builtin', 'ansible.legacy']
    result = collection_search_0._load_collections(collection_search_0._collections, None)
    assert result == None
    # Case 2: collections is empty array
    result = collection_search_0.get_validated_value('collections', collection_search_0._collections, [], None)
    assert result == ['ansible.builtin', 'ansible.legacy']
    result = collection_search_0._load_collections(collection_search_0._collections, None)
    assert result == None
    # Case 3: collections is empty list
    result

# Generated at 2022-06-25 05:05:34.400897
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1 is not None

# Generated at 2022-06-25 05:06:01.329228
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0.__doc__ is not None



# Generated at 2022-06-25 05:06:02.884486
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert(collection_search_1._collections == ['ansible.builtin', 'ansible.legacy'])


# Generated at 2022-06-25 05:06:05.730661
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-25 05:06:07.418591
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:06:08.927480
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:06:10.130080
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    test_case_0()

# Generated at 2022-06-25 05:06:11.249383
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch, "_collections")

# Generated at 2022-06-25 05:06:13.615081
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0.collections == "_ensure_default_collection()"

# Generated at 2022-06-25 05:06:18.342228
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert type(collection_search_1.collections) == type([])
    assert collection_search_1.collections == ['ansible_collections.ansible.builtin']


# Generated at 2022-06-25 05:06:22.988364
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    attr = None
    ds = None
    result = collection_search_0._load_collections(attr, ds)
    assert result is None

# Generated at 2022-06-25 05:06:53.037970
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search_0 = CollectionSearch()
    except Exception as err:
        assert False, "Unexpected exception raised during construction of class CollectionSearch: " + str(err)


# Generated at 2022-06-25 05:06:54.205424
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    results = CollectionSearch()
    assert results is not None


# Generated at 2022-06-25 05:06:58.165175
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert isinstance(collection_search_0, CollectionSearch)


# Generated at 2022-06-25 05:07:02.584526
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    collection_search_2 = CollectionSearch()


# Generated at 2022-06-25 05:07:09.274703
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    before_0 = collection_search_0.collections
    assert before_0 is None

    after_0 = collection_search_0._load_collections('collections', [])
    assert after_0 == []
    assert collection_search_0.collections == after_0

    after_1 = collection_search_0._load_collections('collections', None)
    assert after_1 == []
    assert collection_search_0.collections == after_1

# Generated at 2022-06-25 05:07:11.171722
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch(collections=None)
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:07:12.495563
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()

    assert collection_search_1 is not None

# Generated at 2022-06-25 05:07:15.387252
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_case_0()
    except:
        print("Testcase 0 failed")


if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-25 05:07:18.216338
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Arrange
    collection_search = CollectionSearch()
    # Act

    # Assert


# Generated at 2022-06-25 05:07:20.532605
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections is not None


# Generated at 2022-06-25 05:08:30.057228
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:08:30.930967
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()


# Generated at 2022-06-25 05:08:33.397582
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None


# Generated at 2022-06-25 05:08:35.736272
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(CollectionSearch)

# Unit tests for field _collections
# of class CollectionSearch

# Case1: Empty value for field "collections"

# Generated at 2022-06-25 05:08:39.153159
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print('Test constructor of class CollectionSearch')
    collection_search_0 = CollectionSearch()
    assert collection_search_0
    assert collection_search_0._collections == ["ansible.builtin"]


# Generated at 2022-06-25 05:08:46.149277
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # creating an object of class CollectionSearch
    collection_search = CollectionSearch()

    # expected output: <ansible.module_utils.collection_loader._AnsibleCollectionLoader object at 0x7fbcb1f2c518>
    print(collection_search._loader)

    # expected output: <dict_keyiterator at 0x7fbcb1f2c3a8>
    print(collection_search._collections_to_load)

    # expected output: <ansible.module_utils.collection_loader.AnsibleCollectionConfig object at 0x7fbcb1f2c588>
    print(collection_search.collection_config)

    # expected output: <ansible.module_utils.collection_loader._AnsibleCollectionLoader object at 0x7fbcb1f2c5f8>

# Generated at 2022-06-25 05:08:47.934921
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(isinstance(test_case_0()._collections, FieldAttribute))

# Generated at 2022-06-25 05:08:53.509580
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

    # Test for static attribute collections
    for i in ('ansible.builtin', 'ansible.legacy', 'ansible_collections.nsxt.nsxt', 'ansible_collections.vmware.nsxt'):
        assert i in collection_search.collections


# Generated at 2022-06-25 05:08:57.960762
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Unit test for constructor of class CollectionSearch
    """
    # Test function arguments
    collection_search = CollectionSearch()
    assert collection_search is not None


# Generated at 2022-06-25 05:08:58.548736
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:10:08.117827
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-25 05:10:14.003192
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections.value == AnsibleCollectionConfig.default_collection
    assert search._collections.value == AnsibleCollectionConfig.default_collection
    assert search._collections.value == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-25 05:10:22.222084
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Faux(object):
        def post_validate(self, attr, ds):
            return ds
    try:
        items = ['collection_name', 'collection_name_1']
        Faux.collections = CollectionSearch._collections
        Faux.collections.post_validate = CollectionSearch._load_collections
        x = Faux()
        y = dict()
        y['collections'] = items
        x.post_validate(None, y)
        assert(x.collections == ['collection_name', 'collection_name_1', 'ansible.legacy'])
    except Exception as e:
        raise e

# Generated at 2022-06-25 05:10:22.853212
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-25 05:10:32.110488
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.template import JinjaTemplateError
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    # Test constructor
    c = CollectionSearch()
    assert c

    # Test resolve_task_connection
    c.task_vars = dict(ansible_connection=dict(default='foo'))
    c.task_var_comp

# Generated at 2022-06-25 05:10:37.623476
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create object and initialize fields.
    cs = CollectionSearch()
    cs.get_validated_value = lambda *args: 1
    cs._load_collections('collections', 1)
    assert cs._attributes['collections'].value == 1

# Generated at 2022-06-25 05:10:40.259855
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def _ensure_default_collection():
        pass

    testObject = CollectionSearch()
    assert testObject
    assert testObject._collections.isa == 'list'
    assert testObject._collections.listof == string_types
    assert testObject._collections.default == _ensure_default_collection

# Generated at 2022-06-25 05:10:47.818125
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.module_utils.six import text_type
    from collections import namedtuple
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.plugins.loader import all as plugins_list
    from ansible.plugins.loader import module_loader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars, set_hash_behaviour
    from ansible.vars import VariableManager
    from ansible.utils.display import Display

# Generated at 2022-06-25 05:10:52.212513
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test for class instantiation and field default values.
    # If the constructor can instantiate the class, then we can assume
    # that the fields were initialized with the correct default values.

    cs = CollectionSearch()
    assert(cs._collections._post_validate_data(None, None) == \
           _ensure_default_collection(collection_list=None))

# Generated at 2022-06-25 05:11:02.217147
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from collections import namedtuple
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play import Play
    
    # AnsibleModule is a base class for all Ansible Modules. 
    # AnsibleModule creates an object that is used to define the runtime environment for the module.
    # Inherit AnsibleModule to be used in python unit tests
    class TestClass(AnsibleModule):
        def __init__(self):
            pass
    
    # Test: Testcase to test CollectionSearch constructor
    test_play = TestClass()
    result = CollectionSearch(play=test_play)
    assert result.__class__ == namedtuple('CollectionSearch', ['_collections']).__class__