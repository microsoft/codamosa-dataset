

# Generated at 2022-06-25 05:03:27.337336
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-25 05:03:28.932919
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert test_case_0() == None

# Generated at 2022-06-25 05:03:35.799352
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # test the case where collection is an empty list, collections should return 'ansible.builtin'
    test_case_1 = CollectionSearch()
    test_case_1.collections = []
    collections = test_case_1.collections
    assert collections == ['ansible.builtin']

    # test the case where collections is a list with one element, which is not a collection
    test_case_2 = CollectionSearch()
    test_case_2.collections = ['test_collection']
    collections = test_case_2.collections
    assert collections == ['test_collection', 'ansible.builtin']

# Generated at 2022-06-25 05:03:39.545564
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x.collections == list()


# Generated at 2022-06-25 05:03:40.686340
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test to assert that the constructor name matches the class name
    assert CollectionSearch.__name__ == 'CollectionSearch'

# Generated at 2022-06-25 05:03:42.708750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search_0 = CollectionSearch()

    # Collections is an empty list
    assert(collection_search_0.collections, None)

# Generated at 2022-06-25 05:03:44.406677
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0.collections == None
    collection_search_1 = CollectionSearch()
    assert collection_search_1.collections == None



# Generated at 2022-06-25 05:03:51.758319
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin', 'ansible.legacy']
    assert collection_search._collections.default == ['ansible.builtin', 'ansible.legacy']
    assert collection_search._collections.default('foo') == ['ansible.builtin', 'ansible.legacy']
    assert collection_search._collections.default([]) == ['ansible.builtin', 'ansible.legacy']
    assert collection_search._collections.default(['ansible.netcommon']) == ['ansible.netcommon', 'ansible.builtin', 'ansible.legacy']
    assert collection_search._collections.default(None) == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-25 05:03:56.876616
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with pytest.raises(TypeError) as excinfo:
        collection_search=CollectionSearch(collections='ansible.posix')
    assert 'Initialization takes no parameters' in str(excinfo.value)
    collection_search=CollectionSearch()
    assert collection_search._collections == ['ansible.posix']
    assert collection_search.collections is None


# Generated at 2022-06-25 05:04:00.935499
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    #assert collection_search_0._collections == _ensure_default_collection()
    assert collection_search_0._collections == ['ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network', 'ansible.builtin']



# Generated at 2022-06-25 05:04:08.321774
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch, object)

# Generated at 2022-06-25 05:04:11.457265
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj is not None
    assert _ensure_default_collection() == obj.collections


test_CollectionSearch()

# Generated at 2022-06-25 05:04:20.448251
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    env_expect = Environment()
    _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)
    ds = ['ansible.builtin', 'ansible.builtin.collections']
    _ds = _ensure_default_collection(collection_list=ds)
    for collection_name in _ds:
        if is_template(collection_name, env_expect):
            display.warning('"collections" is not templatable, but we found: %s, it will not be templated and will be '
                            'used "as is".' % (collection_name))
    # call constructor
    collection_search = CollectionSearch()
    # set up
    collection_search

# Generated at 2022-06-25 05:04:23.090399
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    assert test_instance._collections == 'ansible.builtin'
    assert test_instance._load_collections(collection_list=None) == 'ansible.builtin'

# Generated at 2022-06-25 05:04:26.740805
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible_collections.ansible.builtin']

# Generated at 2022-06-25 05:04:35.331300
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    class CollectionSearchInstance(CollectionSearch):
        def __init__(self, collections=None):
            super(CollectionSearchInstance, self).__init__()
            self._collections = collections

    obj = CollectionSearchInstance(['geerlingguy.docker'])
    if PY3:
        assert obj._collections == ['geerlingguy.docker']
    else:
        assert obj._collections == ['geerlingguy.docker']

    obj = CollectionSearchInstance()
    assert obj._collections == ['geerlingguy.docker']

    obj = CollectionSearchInstance(['geerlingguy.docker', 'geerlingguy.git'])

# Generated at 2022-06-25 05:04:37.655956
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    # print('c.__dict__ is: ', c.__dict__)
    assert 'collections' == c._collections.field_name
    assert 'list' == c._collections.isa

# Generated at 2022-06-25 05:04:41.883580
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default() == [
        "ansible_collections.community.general",
        "ansible_collections.ansible.builtin",
        "ansible_collections.ansible.legacy"
    ]

# Generated at 2022-06-25 05:04:44.043221
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Check that the constructor of class CollectionSearch
    # raises the right exception when called with
    # the wrong type of arguments.
    import pytest
    with pytest.raises(TypeError):
        ansible_base_collection = CollectionSearch(['a', 1], [])

# Generated at 2022-06-25 05:04:47.795220
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearchTest(CollectionSearch):
        pass
    obj = CollectionSearchTest()
    assert obj._collections == ['ansible.builtin']

# Generated at 2022-06-25 05:04:56.643292
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default() == _ensure_default_collection()


# Generated at 2022-06-25 05:05:00.361831
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections == _ensure_default_collection()
    assert x._load_collections('collections', None) == _ensure_default_collection()

# Generated at 2022-06-25 05:05:02.262089
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c=CollectionSearch()
    assert c._collections is not ''

# Generated at 2022-06-25 05:05:03.593678
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:05:07.257857
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-25 05:05:11.286987
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    print("Default Collections: %s" % c._collections)
    print("None Collections: %s" % c._load_collections('collections', None))
    print("Empty List: %s" % c._load_collections('collections', []))

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-25 05:05:14.050725
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is not None

# Generated at 2022-06-25 05:05:15.636964
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass

    x = TestCollectionSearch()
    assert x.collections == []

# Generated at 2022-06-25 05:05:19.102295
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == ['ansible.builtin']
    assert c._load_collections('collections', None) == ['ansible.builtin']

# Generated at 2022-06-25 05:05:24.956323
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    blk = Block()
    task1 = Task()
    blk.add_task(task1)
    Base._default_collection = 'testcollection'
    blk.post_validate()
    assert blk._collections == 'testcollection'

# Generated at 2022-06-25 05:05:39.626804
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None

# Generated at 2022-06-25 05:05:42.134768
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        pass
    test = TestCollectionSearch()
    assert test.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:05:44.249015
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Create the class object
    CollectionSearch()

# Generated at 2022-06-25 05:05:51.656584
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Set a collection name to be put on top of the list of collection names
    # to be used to search a role.
    ansible_collections="ansible.builtin"

    # Instantiate an object of the class CollectionSearch to be used in the
    # unit test.
    c = CollectionSearch()

    # This is the output of the function _ensure_default_collection.
    # It uses the default value of the collection list to be used by Ansible.
    # It is different than the above defined ansible_collections.
    output_default_collection_list = ['ansible.builtin', 'ansible.builtin.role_tasks', 'ansible.legacy']

    assert c._ensure_default_collection() == output_default_collection_list
    # Add the ansible_collections to the collection list.

# Generated at 2022-06-25 05:05:56.050385
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = AnsibleCollectionConfig()
    assert obj._collections is not None

# Generated at 2022-06-25 05:05:57.086582
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch(name='test', attr='collections')


# Generated at 2022-06-25 05:06:04.542291
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(None, None) == _ensure_default_collection()
    assert CollectionSearch()._load_collections(None, ['ansible.builtin']) == _ensure_default_collection(['ansible.builtin'])

# Generated at 2022-06-25 05:06:06.376800
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test for constructor
    assert CollectionSearch()



# Generated at 2022-06-25 05:06:08.402406
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible.builtin']

# Generated at 2022-06-25 05:06:12.300892
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test constructor
    collection_search = CollectionSearch()
    assert collection_search is not None, 'Constructor failed.'
    assert type(collection_search) is CollectionSearch, 'Constructor failed.'
    # test _load_collections()
    ds = caller._load_collections(None, None)
    assert ds is not None, 'Failed to get collections list.'

# Generated at 2022-06-25 05:06:43.176047
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_obj = CollectionSearch()
    assert _ensure_default_collection() == search_obj.collections

# Generated at 2022-06-25 05:06:50.043714
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create a CollectionSearch object and set a collection list
    # on it
    collectionManager = CollectionSearch()
    collectionManager.collections = ['ansible.builtin', 'ansible.collection1', 'ansible.collection2']
    assert collectionManager.collections == ['ansible.builtin', 'ansible.collection1', 'ansible.collection2']

# Generated at 2022-06-25 05:06:52.827490
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # If we are using the default, there should only be one collection: ansible.legacy
    p = CollectionSearch()
    assert p._collections == ['ansible.legacy']

# Generated at 2022-06-25 05:06:56.909410
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # Testing class attribute '_collections'
    assert collection_search._collections.listof == string_types
    assert collection_search._collections.default == _ensure_default_collection
    assert collection_search._collections.priority == 100
    assert collection_search._collections.always_post_validate
    assert collection_search._collections.static



# Generated at 2022-06-25 05:06:59.921521
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a.get_value_from_datastructure("collections") == "ansible.legacy"

# Generated at 2022-06-25 05:07:05.682826
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._load_collections('collections', [ 'collection1', 'collection2', 'collection3' ]) == [ 'collection1', 'collection2', 'collection3' ]
    assert CollectionSearch._load_collections('collections', None) is not None
    assert CollectionSearch._load_collections('collections', []) is not None
    assert len(CollectionSearch._load_collections('collections', None)) == 1
    assert CollectionSearch._load_collections('collections', None)[0] == AnsibleCollectionConfig.default_collection
    assert CollectionSearch._load_collections('collections', [])[0] == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-25 05:07:07.732790
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None

# Generated at 2022-06-25 05:07:12.092434
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Example of how to use CollectionSearch class
    print("Testing CollectionSearch Class\n")
    collectionSearchExample = CollectionSearch()
    print(collectionSearchExample)

# driver program
if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:07:13.334705
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-25 05:07:18.095770
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test the constructor of class CollectionSearch
    obj = CollectionSearch()
    assert obj._collections == ['ansible.builtin']
    # Test the constructor of class CollectionSearch
    obj = CollectionSearch(collections=['ansible.builtin'])
    assert obj._collections == ['ansible.builtin']
    # Test the constructor of class CollectionSearch
    obj = CollectionSearch(collections=['ansible.builtin', 'ansible.builtin'])
    assert obj._collections == ['ansible.builtin', 'ansible.builtin']


# Generated at 2022-06-25 05:08:28.776607
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection.collections==['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-25 05:08:31.077955
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    # Test the class constructor
    assert x._collections()

# Generated at 2022-06-25 05:08:33.061688
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-25 05:08:34.353994
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test to initialize the class
    obj = CollectionSearch()
    print(obj)

# Generated at 2022-06-25 05:08:45.177300
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test with a completely fresh object
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection(collection_list=None)

    # Test that it handles the wierd case of ['', 'acme.role1']
    cs = CollectionSearch(collections=['', 'acme.role1'])
    assert cs.collections == _ensure_default_collection(collection_list=['', 'acme.role1'])

    # Test with a basic collection
    cs = CollectionSearch(collections=['ansible.builtin'])
    assert cs.collections == _ensure_default_collection(collection_list=['ansible.builtin'])

    # Test with a basic collection with a dependency
    cs = CollectionSearch(collections=['my_namespace.my_collection'])
    assert cs

# Generated at 2022-06-25 05:08:49.885652
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections('collections', ['ansible.builtin', 'test.test1']) == ['ansible.builtin', 'test.test1']
    assert cs._load_collections('collections', None) == ['ansible.builtin', 'ansible.legacy']
    assert cs._load_collections('collections', []) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:08:52.501619
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search_collections_list = collection_search._load_collections(None, None)
    assert 'ansible.builtin' in collection_search_collections_list or 'ansible.legacy' in collection_search_collections_list

# Generated at 2022-06-25 05:08:53.957819
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    print(a)


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:08:56.958352
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(None, None) is not None

# Generated at 2022-06-25 05:09:01.259342
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch(collections=['my.collection'], collections_paths=['/home/daniel', '/etc/ansible/collections'])
    assert cs.collections == ['my.collection']
    assert cs.collections_paths == ['/home/daniel', '/etc/ansible/collections']

# Generated at 2022-06-25 05:11:38.922452
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ansible_module_utils_path = os.path.dirname(os.path.abspath(__file__))
    my_loader = DataLoader(path_list=[ansible_module_utils_path])
    plugin_manager = PluginLoader(
        class_name='CollectionSearch',
        package_name='ansible.playbook.attribute_loader',
        config={},
        collection_list=[],
        loader=my_loader
    )

    my_collections = plugin_manager.get(class_name='CollectionSearch')
    print(my_collections)

# Generated at 2022-06-25 05:11:46.063569
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import json

    # Success for valid input
    tasks = CollectionSearch()
    tasks.collections = "dummy_collection"
    assert json.dumps(tasks.collections) == json.dumps(["dummy_collection"])

    # Success for valid input
    tasks = CollectionSearch()
    tasks.collections = ["dummy_collection"]
    assert json.dumps(tasks.collections) == json.dumps(["dummy_collection"])

    # Success for valid input
    tasks = CollectionSearch()
    tasks.collections = ["dummy_collection1", "dummy_collection2"]
    assert json.dumps(tasks.collections) == json.dumps(["dummy_collection1", "dummy_collection2"])

    # Failure for invalid input

# Generated at 2022-06-25 05:11:49.971345
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)

# Generated at 2022-06-25 05:11:56.837522
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os
    import shutil

    test_collection = os.path.join(os.path.dirname(__file__), 'test_data', 'collection')
    env_paths = [os.path.join(os.path.dirname(__file__), 'test_data', 'env_path')]

    # ensure other collections don't exist
    if os.path.exists('collection_2'):
        shutil.rmtree('collection_2', ignore_errors=True)
    assert 'collection_2' not in AnsibleCollectionConfig.collection_paths

    collection_finder = CollectionSearch()
    collection_finder._collections = [test_collection]
    assert test_collection in AnsibleCollectionConfig.collection_paths

    # ensure the default collection is loaded too
    assert 'ansible.builtin' in Ansible

# Generated at 2022-06-25 05:12:04.135604
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collections = ['test.test_collection']

    cs_instance = CollectionSearch(collections)
    assert cs_instance._collections == ['test.test_collection']

    cs_instance = CollectionSearch()
    assert cs_instance._collections == ['ansible.builtin']

    cs_instance = CollectionSearch([])
    assert cs_instance._collections == ['ansible.builtin']

# Generated at 2022-06-25 05:12:12.484494
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.metadata import MetaDataParser
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import task_loader
    from ansible.executor.playbook_executor import PlaybookExecutor

    variable_manager = VariableManager()
    executor = PlaybookExecutor()

    task_loader.add_directory(task_loader.find_plugin_dirs(''))

    variable_manager.set_inventory(executor._inventory)

    task_result = TaskResult('print_message', None)

# Generated at 2022-06-25 05:12:15.857328
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case = CollectionSearch()
    collection_search = test_case._load_collections(attr=None, ds=None)

    if collection_search is not None and 'ansible.builtin' in collection_search:
        print("CollectionSearch class constructor test passed")
    else:
        print("CollectionSearch class constructor test failed")

# Generated at 2022-06-25 05:12:22.285349
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an instance of the class CollectionSearch and assert that each instance has the same default value of
    # attributes.
    a = CollectionSearch()
    b = CollectionSearch()
    assert a._collections == b._collections == _ensure_default_collection(), \
        'The default value of attributes is not the same.'


# Generated at 2022-06-25 05:12:30.385326
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import json
    import tempfile
    temp_file = tempfile.NamedTemporaryFile()
    temp_file.write(json.dumps({"collections": ["ansible_collections.testnamespace.testpkg"]}).encode())
    temp_file.seek(0)
    collsearch = CollectionSearch(play=None, file_name=temp_file.name)
    collsearch.post_validate(play=None, file_name=temp_file.name)
    collsearch._load_collections('collections', {})

# Generated at 2022-06-25 05:12:35.193241
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test default values
    c_search = CollectionSearch()
    assert c_search._collections is None
    assert c_search._collections_loader is None
    assert c_search._collections_paths is None
    assert c_search._collections_role_paths is None
    assert c_search._collections_task_paths is None

    # test that a None value does not overwrite the None value
    c_search._collections = 'foo'
    c_search.collections = None
    assert c_search._collections == 'foo'