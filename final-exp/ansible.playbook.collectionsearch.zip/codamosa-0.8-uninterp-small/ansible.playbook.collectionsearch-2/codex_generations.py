

# Generated at 2022-06-25 05:03:25.193510
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def test_unit():
        assert collection_search_0.get_validated_value('collections', collection_search_0._collections, 'ansible.awx.plugins.notify', None) == 'ansible.awx.plugins.notify'

if __name__ == '__main__':
    test_case_0()
    test_CollectionSearch()

# Generated at 2022-06-25 05:03:26.667550
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Case 0: No argument provided
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == ['ansible.legacy']

# Generated at 2022-06-25 05:03:31.148108
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # create an object for class CollectionSearch
    collection_search_0 = CollectionSearch()

    # check type of object
    assert isinstance(collection_search_0, CollectionSearch)


# Generated at 2022-06-25 05:03:33.991697
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert issubclass(CollectionSearch, object)
    collection_search_0 = CollectionSearch()
    assert not collection_search_0.__dict__
    assert collection_search_0._collections == _ensure_default_collection()


# Generated at 2022-06-25 05:03:35.936301
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert _ensure_default_collection(None) is not None
    assert isinstance(_ensure_default_collection(None), list)

# Generated at 2022-06-25 05:03:40.373533
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1 is not None
    assert isinstance(collection_search_1, CollectionSearch)

# Generated at 2022-06-25 05:03:48.552315
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test AnsibleCollectionConfig.default_collection is not none
    AnsibleCollectionConfig.default_collection = "test_value"
    test_CollectionSearch_0 = CollectionSearch()
    assert test_CollectionSearch_0 is not None

    # Test AnsibleCollectionConfig.default_collection is none and valid input for collections
    AnsibleCollectionConfig.default_collection = None
    test_CollectionSearch_1 = CollectionSearch(collections=["test_value"])
    assert test_CollectionSearch_1 is not None

    # Test AnsibleCollectionConfig.default_collection is none and invalid input for collections
    AnsibleCollectionConfig.default_collection = None
    test_CollectionSearch_2 = CollectionSearch(collections=1)
    assert test_CollectionSearch_2 is not None


# Generated at 2022-06-25 05:03:52.963778
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    result = collection_search_0._load_collections('collections', [])
    assert result is None


# Generated at 2022-06-25 05:03:58.138460
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search_0 = CollectionSearch()
    collection_search_0._collections = ['ansible.builtin']
    assert collection_search_0._collections == ['ansible.builtin']
    assert collection_search_0.get_validated_value('collections', collection_search_0._collections, True, None) == ['ansible.builtin']
    assert collection_search_0._load_collections('collections', True) is None
    assert collection_search_0._collections == ['ansible.builtin']

# Generated at 2022-06-25 05:04:00.798885
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Simple constructor test
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False
    assert True


# Generated at 2022-06-25 05:04:08.890542
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()



# Generated at 2022-06-25 05:04:11.076832
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search_0 = CollectionSearch()
    except Exception as e:
        assert False, "Exception unexpected"


# Generated at 2022-06-25 05:04:12.061274
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_1()
    test_case_0()



# Generated at 2022-06-25 05:04:16.231248
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch, '_collections')

# Generated at 2022-06-25 05:04:19.974470
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    # Test if the constructed value of the object is equal to itself
    assert collection_search_1._collections == collection_search_1._collections

if __name__ == '__main__':
    test_case_0()
    test_CollectionSearch()

# Generated at 2022-06-25 05:04:22.400727
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()


# Generated at 2022-06-25 05:04:24.877498
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().__dict__.keys() == {'_collections'}



# Generated at 2022-06-25 05:04:30.120264
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search_0 = CollectionSearch()
        assert collection_search_0.__class__.__name__ == 'CollectionSearch'
    except (SystemExit, KeyboardInterrupt, GeneratorExit):
        raise
    except Exception as ex:
        display.error(str(ex))
        pytest.fail("Test CollectionSearch failed")



# Generated at 2022-06-25 05:04:31.378406
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs is not None

# Generated at 2022-06-25 05:04:33.321841
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections is not None

# Generated at 2022-06-25 05:04:49.509191
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test collection_search_0
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:04:51.394990
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search


# Generated at 2022-06-25 05:04:53.974240
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert loader.find_plugin("action", "ping") is not None
    assert hasattr(collection_search_0, "_collections")

# Generated at 2022-06-25 05:05:04.434168
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    collection_search_0.__class__._collections.post_validate(collection_search_0, 0, None)
    collection_search_0.__class__._collections.post_validate(collection_search_0, 0, [])
    collection_search_0.__class__._collections.post_validate(collection_search_0, 0, ['ansible_collections.namespace.collection'])
    collection_search_0.__class__._collections.post_validate(collection_search_0, 0, ['ansible_collections.namespace.collection', 'ansible_collections.namespace.collection'])

# Generated at 2022-06-25 05:05:09.569712
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()

    assert collection_search._collections.value is None
    assert collection_search._collections.priority == 100
    assert collection_search._collections.always_post_validate
    assert collection_search._collections.private

# Generated at 2022-06-25 05:05:15.091112
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    attr = FieldAttribute()
    ds = None
    collection_search_0 = CollectionSearch()
    assert collection_search_0._load_collections(attr, ds) == None

# Generated at 2022-06-25 05:05:17.712849
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:05:20.270896
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0.get_values_for_attribute('collections') == ['ansible.builtin','ansible.legacy']

# Generated at 2022-06-25 05:05:22.736960
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()


if __name__ == '__main__':
    # unit test goes here
    test_CollectionSearch()

# Generated at 2022-06-25 05:05:24.431034
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    collection_search_0.__init__()

# Generated at 2022-06-25 05:05:51.376108
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:05:53.749222
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:05:57.480578
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    collection_search_1 = CollectionSearch(collections=['ansible.builtin', 'ansible.netcommon', 'ansible.legacy', 'my.collection'])
    collection_search_2 = CollectionSearch(collections=['ansible.builtin', 'ansible.netcommon', 'ansible.legacy'])

# Generated at 2022-06-25 05:06:05.934002
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # If it is initialized with no attribute, then the collections field is set to default value i.e. ['ansible_collections.ansible.builtin', 'ansible_collections.ansible.legacy']
    assert collection_search.collections == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible.legacy']

#Unit test for _load_collections()

# Generated at 2022-06-25 05:06:10.777526
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

    # Test for get_validated_value()
    attr = 'collections'
    ds = ['ansible.builtin']

    result = search.get_validated_value(attr, search._collections, ds, None)
    assert result == ds



# Generated at 2022-06-25 05:06:14.507409
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create test object
    collection_search_1 = CollectionSearch()
    assert collection_search_1.collections == ['ansible.builtin']

# Add unit test for __init__()

# Generated at 2022-06-25 05:06:17.957957
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    print("In test_CollectionSearch")

    # [Test-case 1]
    collection_search_0 = CollectionSearch()


if __name__ == '__main__':
    test_case_0()
    test_CollectionSearch()

# Generated at 2022-06-25 05:06:22.197367
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Arrange
    collection_search = CollectionSearch()

    # Act and Assert
    assert collection_search is not None

# Generated at 2022-06-25 05:06:22.928132
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-25 05:06:25.443923
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search_1 = CollectionSearch()

    assert collection_search_1.__class__.__name__ == "CollectionSearch"
    assert collection_search_1._collections == ['ansible.builtin']

# Generated at 2022-06-25 05:07:20.530490
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1.collections is not None


# Generated at 2022-06-25 05:07:22.221008
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search_0 = CollectionSearch()
    except Exception as e:
        raise AssertionError(e)


# Generated at 2022-06-25 05:07:25.719098
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert True
    collection_search_0 = CollectionSearch()
    collection_search_0._load_collections('_collections',None)

# Generated at 2022-06-25 05:07:26.564284
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:07:27.721961
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Default case
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:07:29.851678
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    test_case_0()

    test_case_1()



# Generated at 2022-06-25 05:07:30.806864
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search

# Generated at 2022-06-25 05:07:31.380674
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:07:33.759720
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Initialize collection_search_0
    collection_search_0 = CollectionSearch()
    assert 'ansible.legacy' in collection_search_0._collections


# Generated at 2022-06-25 05:07:34.885230
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(collection_search_0, CollectionSearch)


# Generated at 2022-06-25 05:09:44.956805
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_simple = CollectionSearch()
    assert collection_search_simple.collections is None


# Generated at 2022-06-25 05:09:46.011911
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-25 05:09:48.245070
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display.display("Testing Constructor for class CollectionSearch")
    collection_search_o = CollectionSearch()
    display.display("Testing Constructor for class CollectionSearch - Successful")


# Generated at 2022-06-25 05:09:50.379538
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-25 05:09:54.385203
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch



# Generated at 2022-06-25 05:09:56.875940
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    assert collection_search._collections.priority == 100
    assert collection_search._collections.default() == AnsibleCollectionConfig.default_collection or []

    assert collection_search._collections
    assert collection_search._collections == []

# Generated at 2022-06-25 05:09:58.303861
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print("Validating CollectionSearch constructor")
    assert hasattr(collection_search, '_collections')
    print("Test Passed")


# Generated at 2022-06-25 05:09:58.981244
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert test_case_0() == None

# Generated at 2022-06-25 05:10:02.911147
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch, '_collections'), "No valid '_collections' attribute, got %s" % (
        ','.join(CollectionSearch.__dict__.keys()))

# Generated at 2022-06-25 05:10:04.527459
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    '''
    Constructor of class CollectionSearch
    '''
    # initialize the object attribute
    collection_search = CollectionSearch()
    assert isinstance(collection_search._collections, FieldAttribute) == True



# Generated at 2022-06-25 05:12:41.325650
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Should not be None if there is a default collection set
    from ansible.module_utils._text import to_text
    default_collection = to_text(AnsibleCollectionConfig.default_collection)
    if default_collection:
        assert CollectionSearch()._collections is not None
    else:
        assert CollectionSearch()._collections is None


# Generated at 2022-06-25 05:12:41.744011
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch() # expected no exception
    assert True

# Generated at 2022-06-25 05:12:42.027479
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

# Generated at 2022-06-25 05:12:49.893944
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Constructor for the class CollectionSearch
    collectionSearch = CollectionSearch()
    # Populating the list of collections with 'ansible_collections.ansible.tests.test_collection'
    collectionSearch._collections = ['ansible_collections.ansible.tests.test_collection']
    # Sorting out the collections which are not in the list with the default collection which is going to be added
    _ensure_default_collection()
    # Calling the function _load_collections
    collectionSearch._load_collections('collections', collectionSearch._collections)
    print(collectionSearch)

# Generated at 2022-06-25 05:12:55.831105
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print('Default value of collection is %s', collection_search.collections)
    l1 = ['ansible', 'ansible.builtin']
    collection_search.collections = l1
    print('Modified value of collection is %s', collection_search.collections)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:12:56.683245
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-25 05:12:58.232887
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._load_collections('collections', None) is None

# Generated at 2022-06-25 05:13:04.982807
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert(test_obj._collections.default == _ensure_default_collection)
    assert(test_obj._collections.static == True)
    assert(test_obj._collections.always_post_validate == True)
    assert(test_obj._collections.priority == 100)
    assert(test_obj._collections.isa == 'list')
    assert(test_obj._collections.listof == string_types)

# Generated at 2022-06-25 05:13:05.777663
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == 'ansible.builtin'

# Generated at 2022-06-25 05:13:09.916266
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = None
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']
    cs.collections = ['ns.collection_name_1', 'ns.collection_name_2.lovestory']
    assert cs.collections == ['ns.collection_name_1', 'ns.collection_name_2.lovestory', 'ansible.builtin', 'ansible.legacy']