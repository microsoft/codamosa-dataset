

# Generated at 2022-06-25 05:03:29.533527
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert (not collection_search_0._collections)



# Generated at 2022-06-25 05:03:31.532455
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin']

# Generated at 2022-06-25 05:03:33.730006
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert collection_search.collections == _ensure_default_collection()


# Generated at 2022-06-25 05:03:35.109339
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert type(collection_search_1) == CollectionSearch

# Generated at 2022-06-25 05:03:41.317862
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    assert CollectionSearch.__doc__ == 'Class to handle the search path for collections.', \
        'The CollectionSearch docstring is incorrect!'

    assert CollectionSearch._collections.field_name == 'collections', \
        'Class CollectionSearch is missing the attribute "collections"!'

    # test the default value of collections
    assert collection_search_0._collections() == ['local'], \
        'The default value of "collections" is incorrect!'

    # test the setter of collections
    collection_list = ['foo', 'bar']
    collection_search_0._collections = collection_list
    assert collection_search_0.collections == collection_list, \
        'The setter for "collections" does not work as expected!'

    # test the getter of collections
    assert collection_search_0._collections == collection_search

# Generated at 2022-06-25 05:03:41.950454
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    test_case_0()


# Generated at 2022-06-25 05:03:43.015362
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-25 05:03:43.829298
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(isinstance(CollectionSearch, type))


# Generated at 2022-06-25 05:03:49.434504
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Initialize the instance of class CollectionSearch with default values
    c = CollectionSearch()
    # assert that the class attribute '_collections' has been initialized with a list containing 'ansible.legacy'
    assert c.collections == ['ansible.legacy'], "the default list for attribute '_collections' is wrong."


# Generated at 2022-06-25 05:03:52.779399
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    collection_search_0._collections  # pylint: disable=protected-access

# Generated at 2022-06-25 05:04:01.483836
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-25 05:04:05.551626
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    collection_search_0 = CollectionSearch()
    with pytest.warns(None) as record:
        collection_search_0._load_collections('collections', None)
    assert len(record) == 0

# Generated at 2022-06-25 05:04:08.686175
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert(isinstance(collection_search_1, CollectionSearch))
    assert(isinstance(collection_search_1, dict))

# Generated at 2022-06-25 05:04:11.674937
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == _ensure_default_collection()


# Generated at 2022-06-25 05:04:17.501802
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert not hasattr(collection_search, '_collections')
    assert collection_search.collections == ["ansible_collections.default"]

    # Add a collection manually
    collection_search.collections = ["ansible_collections.other"]
    assert len(collection_search.collections) == 2
    assert "ansible_collections.default" in collection_search.collections
    assert "ansible_collections.other" in collection_search.collections

    # Add a collection through constructor
    collection_search = CollectionSearch(collections=["ansible_collections.another_1", "ansible_collections.another_2"])
    assert len(collection_search.collections) == 2
    assert "ansible_collections.another_1" in collection_search.collections


# Generated at 2022-06-25 05:04:18.995419
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0.get_value_of_parameter('collections') is None


# Unit tests for get_value_of_parameter() of class CollectionSearch

# Generated at 2022-06-25 05:04:21.640498
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1 is not None

# Generated at 2022-06-25 05:04:22.912479
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Unit test for empty constructor
    args = ()

    collection_search = CollectionSearch(*args)

    assert collection_search

# Generated at 2022-06-25 05:04:26.900293
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == _ensure_default_collection()



# Generated at 2022-06-25 05:04:30.912206
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    attribute_list = collection_search.__dict__.keys()
    assert '_collections' in attribute_list
    assert collection_search._collections == _ensure_default_collection()
    assert collection_search._collections is not None

# Generated at 2022-06-25 05:04:43.530526
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    display.display("Executing test case 1")
    col_obj = CollectionSearch()
    assert col_obj
    
    display.display("Executing test case 2")
    assert col_obj._ensure_default_collection(["ansible"]) == ["ansible"]
    
    display.display("Executing test case 3")
    assert col_obj._ensure_default_collection(["test.test"]) == ["test.test"]
    
    display.display("Executing test case 4")
    assert col_obj._ensure_default_collection(["test.test","test2.test"]) == ["test.test","test2.test"]
    
    display.display("Executing test case 5")

# Generated at 2022-06-25 05:04:44.791567
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch.collections.default, type(lambda: 0))
    obj = CollectionSearch()
    assert obj.collections is None

# Generated at 2022-06-25 05:04:47.252381
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == []

# Generated at 2022-06-25 05:04:47.844942
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-25 05:04:56.473972
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    default_collections = cs.get_default_value('collections')
    assert default_collections is None or isinstance(default_collections, list)
    # verify _load_collections() method
    # test 1: input is None
    collections = cs._load_collections('collections', None)
    assert collections is None
    # test 2: input is list
    collections = cs._load_collections('collections', ['collection1', 'collection2'])
    assert collections == ['collection1', 'collection2']
    # test 3: input is ansible.builtin
    collections = cs._load_collections('collections', ['ansible.builtin'])
    assert collections == ['ansible.builtin']
    # test 4: input is ansible.legacy
    collections = cs._load_

# Generated at 2022-06-25 05:05:04.840639
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import types
    from ansible.playbook.attribute import FieldAttribute

# Generated at 2022-06-25 05:05:08.299949
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections.value == ['ansible_collections.azure.azcollection']

# Generated at 2022-06-25 05:05:10.388603
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testcollections = CollectionSearch()
    assert isinstance(testcollections.collections, list)
    assert testcollections.collections[0] == 'ansible.builtin'

# Generated at 2022-06-25 05:05:13.484506
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)

# Generated at 2022-06-25 05:05:15.810069
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Initialize an object of class CollectionSearch
    instance = CollectionSearch()

    # Assert that the instance of class CollectionSearch is an object
    assert isinstance(instance, object) == True

# Generated at 2022-06-25 05:05:33.616298
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = {}
    def _post_validate_collections_called(*args, **kwargs):
        return 'post_validate_collections_called'
    cs = CollectionSearch()
    cs.post_validate_collections = _post_validate_collections_called
    assert cs.collections == 'post_validate_collections_called'

# Generated at 2022-06-25 05:05:37.953820
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    assert issubclass(CollectionSearch, AnsibleBaseYAMLObject)
    assert hasattr(CollectionSearch, '_collections')

    collection_search = CollectionSearch()
    assert collection_search is not None
    assert collection_search._collections is not None

    assert collection_search.get_validated_value('collections', collection_search._collections, None, None) is not None

# Generated at 2022-06-25 05:05:49.362305
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.role.definition import RoleDefinition
    # This is a very basic unit test to ensure constructor works
    # Setting value of collections to test the constructor
    Base._collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                       always_post_validate=True, static=True)
    Base._collections = ['my.test.collection']
    assert hasattr(Base, '_collections'), 'Collections not set'
    assert Base._collections == ['my.test.collection'], 'Collections are not equal'
    assert RoleDefinition._collections == ['my.test.collection'], 'Collections are not equal'

# Generated at 2022-06-25 05:05:53.715217
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    my_obj = CollectionSearch()
    print("test _load_collections(): ", my_obj._load_collections('_collections', None))
    print("test _collections: ", my_obj._collections)

test_CollectionSearch()

# Generated at 2022-06-25 05:05:54.957067
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()

    assert search._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:05:56.781125
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection1 = CollectionSearch()
    assert collection1.collections == []
    assert isinstance(collection1.collections[0], string_types)


# Generated at 2022-06-25 05:05:57.844884
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections.default


# Generated at 2022-06-25 05:06:01.956369
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CS = CollectionSearch()
    assert CS._collections.__dict__ == CS._collections.default



# Generated at 2022-06-25 05:06:04.766769
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    y = CollectionSearch()
    a = y._collections._validate([{'name': 'test'}])
    assert a == y.collections

# Generated at 2022-06-25 05:06:08.227632
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = dict(collections=['test1','test2','test3','test4'])
    class TestCollectionSearch(CollectionSearch):
        pass
    temp = TestCollectionSearch(ds)
    assert temp.get_validated_value('collections',temp._collections,ds,None) == ['test1','test2','test3','test4']


# Generated at 2022-06-25 05:06:43.936397
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

    # Validate when collections is None
    obj.set_defaults()
    obj.post_validate()
    ds = obj.get_value('collections')
    if ds != ['ansible.builtin']:
        raise AssertionError('Expected collections == ["ansible.builtin"] but got %s instead' % ds)

    # Validate when collections is empty list
    obj.set_value('collections', [])
    obj._load_collections('collections', [])
    obj.post_validate()
    ds = obj.get_value('collections')
    if ds != ['ansible.builtin']:
        raise AssertionError('Expected collections == ["ansible.builtin"] but got %s instead' % ds)

    # Validate when

# Generated at 2022-06-25 05:06:46.223836
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.default() == ['ansible.builtin.tags', 'ansible.builtin.tasks', 'ansible.builtin.filters']

# Generated at 2022-06-25 05:06:47.027093
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()


# Generated at 2022-06-25 05:06:51.122060
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-25 05:06:53.642313
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert "ansible.builtin" in CollectionSearch._ensure_default_collection(["ansible.builtin"])



# Generated at 2022-06-25 05:06:56.190020
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default(_ensure_default_collection) == ['test_ansible.example']

# Generated at 2022-06-25 05:06:57.541112
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    print(t)
    print(t.__dict__)


# Generated at 2022-06-25 05:06:59.944697
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert(cs.get_value('collections') == ['ansible_collections.foo.bar'])

# Generated at 2022-06-25 05:07:10.257548
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    data_structure = {
            "collections": [ #FIXME: Make sure that the following collection is used
                    "ansible.builtin"
            ]
    }

    # Test with a name that has not been templated
    test_collection = 'ansible_collection.my_network.my_collection'
    display.verbosity = 4
    #
    test_collection_search = CollectionSearch(data_structure, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert test_collection in test_collection_search.collections
    display.verbosity = 0
    # Test with a name that has been templated
    #FIXME: This does not work as expected
    # test_collection = '{{ collection_name }}'
    # display.verbosity

# Generated at 2022-06-25 05:07:13.376896
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    assert cs._load_collections(None, []) is None
    assert cs._load_collections(None, ["foo"]) == ["foo", "ansible.legacy"]

# Generated at 2022-06-25 05:08:22.447820
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()
    assert collections.collections == ['ansible.builtin']
    assert not collections.get_field_value('collections')

# Generated at 2022-06-25 05:08:25.527594
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj_1 = CollectionSearch()
    assert obj_1.collections[0] == "_ansible"
    obj_2 = CollectionSearch({"collections": "namespace.collection"})
    assert obj_2.collections[0] == "namespace.collection"
    assert obj_2.collections[1] == "_ansible"

# Generated at 2022-06-25 05:08:28.970584
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #This test case is used to check the constructor initialization 
    try:
        test_cs = CollectionSearch()
        assert True
    except Exception as e:
        assert False, 'Test case is failed : %s' % e


# Generated at 2022-06-25 05:08:33.233660
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestClass(CollectionSearch):
        """Mock class for testing CollectionSearch class"""
        pass
    test_class = TestClass()
    assert test_class.collections == ['ansible.builtin']

# Generated at 2022-06-25 05:08:39.574842
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Check that CollectionSearch is creating a reference to AnsibleCollectionConfig
    assert isinstance(CollectionSearch._collections, FieldAttribute)
    assert isinstance(CollectionSearch._collections.default, AnsibleCollectionConfig)
    # Check result of post-validation of the _collections attribute of CollectionSearch
    collection_search = CollectionSearch()
    ds = None
    collection_list_validated = collection_search._load_collections('collections', ds)
    assert len(collection_list_validated) == 1
    assert collection_list_validated[0] == 'ansible.builtin.core'

# Generated at 2022-06-25 05:08:42.014464
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # create instance of class CollectionSearch
    obj = CollectionSearch()
    assert obj.collections == 'ansible.legacy'
    obj.collections = 'ansible.modules.system'
    assert obj.collections == 'ansible.modules.system'

# Generated at 2022-06-25 05:08:42.982765
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is None

# Generated at 2022-06-25 05:08:44.262870
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_class = CollectionSearch()
    test_class.collections = ['my.collection', 'my.other.collection']

# Generated at 2022-06-25 05:08:48.296060
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert not search._collections
    assert search._load_collections(None, None) is None



# Generated at 2022-06-25 05:08:56.003484
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    search = CollectionSearch()

    # FIXME: move to a test with setup_loader, when we start supporting
    # being called with None
    dummy_collection = '/tmp/does-not-exist/ansible_collections/some_collection/some_ns/some_name'
    search.collections = [dummy_collection]
    assert search.collections == [dummy_collection]

    # calling the property will set self.collections to the post_validated value
    search.collections
    assert search.collections == [dummy_collection, 'ansible.legacy']

# Generated at 2022-06-25 05:11:20.317100
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    name = 'test_name'
    default = ['ansible.builtin']
    priority = 100
    collection = CollectionSearch(name=name, default=default, priority=priority)

    assert collection.name == name
    assert collection.default == default
    assert collection.priority == priority
    assert collection.always_post_validate == True
    assert collection.static == True

# Test for _ensure_default_collection with default parameters

# Generated at 2022-06-25 05:11:26.176813
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.role import Role
    from ansible.parsing.dataloader import DataLoader

    collections = [
        'ansible.builtin',
        'ansible.legacy',
        'myns.mycoll',
        'myns.othercoll',
        'anotherns.mycoll',
    ]
    loader = DataLoader()
    coll_search = CollectionSearch(loader, collections)
    assert coll_search.collections == collections
    assert coll_search.loader == loader

    # Test attribute setter/getter
    coll_search.collections = ['ansible.builtin', 'ansible.legacy']
    assert coll_search.collections == ['ansible.builtin', 'ansible.legacy']
    assert coll_search.loader == loader

    # Test attribute setter/

# Generated at 2022-06-25 05:11:31.581659
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import sys
    import os
    import django
    sys.path.append("../")
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "fosstask.settings")
    django.setup()
    from task.utils.collection_loader import CollectionSearch
    from task.models import CollectionSearch as CollectionSearchModel
    try:
        collection = CollectionSearch.objects.get(id=1)
        print("\nCollectionSearch object already exists")
        return 0
    except:
        print("Creating CollectionSearch object")
    try:
        collection = CollectionSearch(id=1)
        collection.save()
        print("Created CollectionSearch object with id = 1")
        return 1
    except Exception as e:
        print("Exception: ", e)
        return 0


# Generated at 2022-06-25 05:11:35.523908
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = ['some_collection']
    assert cs._load_collections(None, 'some_collection') == ['some_collection']

# Generated at 2022-06-25 05:11:40.721922
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.value == ['ansible.builtin']
    assert 'ansible.builtin' in collection_search.collections

# Generated at 2022-06-25 05:11:46.424424
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    test_dict = {'collections': ['test', 'test2']}
    test_result = cs._load_collections('collections', test_dict)
    assert test_result, ['test', 'test2']

# Generated at 2022-06-25 05:11:50.884587
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._load_collections(None, None) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:11:54.332599
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    #print("cs=",cs)


# Generated at 2022-06-25 05:11:58.150968
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # 1. Test that the class can be initialized
    collection_search = CollectionSearch()
    # 2. Test that ansible.builtin is always present in collections
    assert 'ansible.builtin' in collection_search._collections._get_value('collections', None)
    # 3. Test that if no collection is provided ansible.legacy is the only collection
    assert len(collection_search._collections._get_value('collections', None)) == 1

# Generated at 2022-06-25 05:12:01.221971
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == None, "Instantiate CollectionSearch class failed"