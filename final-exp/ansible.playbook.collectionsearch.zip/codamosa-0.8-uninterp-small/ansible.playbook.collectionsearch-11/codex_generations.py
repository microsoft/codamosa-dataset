

# Generated at 2022-06-25 05:03:24.233533
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections is None


# Generated at 2022-06-25 05:03:27.748160
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    assert collection_search._collections



# Generated at 2022-06-25 05:03:30.911421
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1.collections == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-25 05:03:38.041702
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()
    fields = tuple(CollectionSearch.fields)
    assert fields == ('collections',)
    collection_search = CollectionSearch()
    static_attrs = tuple(getattr(CollectionSearch, attr_name) for attr_name in dir(CollectionSearch) if isinstance(getattr(CollectionSearch, attr_name), staticmethod) and getattr(CollectionSearch, attr_name).__name__.startswith("_static_fields_"))
    assert static_attrs == ()

# Generated at 2022-06-25 05:03:39.341804
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:03:40.320734
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()

# Generated at 2022-06-25 05:03:41.499266
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert(isinstance(collection_search_1, CollectionSearch))

# Generated at 2022-06-25 05:03:42.603624
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search_1 = CollectionSearch()
    assert collection_search_1.collections == _ensure_default_collection()

# Generated at 2022-06-25 05:03:43.450212
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None


# Generated at 2022-06-25 05:03:46.775326
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c is not None
    # Test the _load_collections
    c.collections = 'ansible.builtin'
    assert c.get_value('collections') == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-25 05:03:58.425044
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search_1 = CollectionSearch()
    except Exception as err:
        print(str(err))
        assert False


# Generated at 2022-06-25 05:04:00.334161
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    # This is an instance of the CollectionSearch class
    assert isinstance(collection_search_0, CollectionSearch)

# Generated at 2022-06-25 05:04:03.483559
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


if __name__ == "__main__":
    test_case_0()
    test_CollectionSearch()

# Generated at 2022-06-25 05:04:14.834355
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert type(collection_search_1._collections) is FieldAttribute
    assert type(collection_search_1._collections.isa) is type
    assert collection_search_1._collections.isa == 'list'
    assert type(collection_search_1._collections.listof) is type
    assert collection_search_1._collections.listof == string_types
    assert type(collection_search_1._collections.priority) is int
    assert collection_search_1._collections.priority == 100
    assert type(collection_search_1._collections.default) is type
    assert collection_search_1._collections.default == _ensure_default_collection
    assert type(collection_search_1._collections.always_post_validate) is bool
    assert collection_

# Generated at 2022-06-25 05:04:15.805967
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0


# Generated at 2022-06-25 05:04:16.913949
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-25 05:04:21.359712
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c is not None


# Generated at 2022-06-25 05:04:22.912033
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None
    assert collection_search.collections is None



# Generated at 2022-06-25 05:04:26.433896
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:04:29.485987
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    try:
        assert collection_search_0 is not None
    except Exception:
        print("Can't create an instance of a class CollectionSearch")
        assert False


# Generated at 2022-06-25 05:04:46.488434
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    #Test __init__()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 05:04:47.280577
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert isinstance(collection_search_1, CollectionSearch)


# Generated at 2022-06-25 05:04:49.910350
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.post_validate(None)
    assert collection_search.collections is not None


# Generated at 2022-06-25 05:04:52.232679
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        # Test for normal constructor
        test_case_0()
        print("Test: CollectionSearch class constructor success")
    except:
        print("Test: CollectionSearch class constructor fail")


test_CollectionSearch()

# Generated at 2022-06-25 05:04:53.780213
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch.__doc__ == 'Class to search for a collection'

# Generated at 2022-06-25 05:04:55.297448
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:04:58.160231
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()

    assert(isinstance(collection_search_0, CollectionSearch))


# Generated at 2022-06-25 05:05:02.215049
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:05:04.220516
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search_0 = CollectionSearch()
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-25 05:05:07.011140
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #
    #collection_search_0 = CollectionSearch()
    collection_search_0 = CollectionSearch()
    #
    #collection_search_1 = CollectionSearch()
    collection_search_1 = CollectionSearch()
    #
    assert True

# Generated at 2022-06-25 05:05:22.906785
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = CollectionSearch()

    # Test FieldAttribute
    assert d._collections._is_static

    # Test __init__()
    assert not d._collections._value



# Generated at 2022-06-25 05:05:27.264823
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections('collections', ['ansible.collection_foo']) == ["ansible.collection_foo", "ansible.legacy"]
    assert cs._load_collections('collections', ['ansible.collection_foo', 'ansible.builtin']) == ["ansible.collection_foo", "ansible.builtin"]

# Generated at 2022-06-25 05:05:28.099228
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-25 05:05:31.187404
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    if collectionsearch:
        assert type(collectionsearch) == CollectionSearch
    else:
        assert False


# Generated at 2022-06-25 05:05:32.571971
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == ['ansible_collections.ansible']

# Generated at 2022-06-25 05:05:34.002856
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.value == _ensure_default_collection(None)

# Generated at 2022-06-25 05:05:37.538723
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # Try to set the "collections" value of the CollectionSearch class.
    collection_search._collections = 'ansible.builtin'
    # Call the _load_collections() with the attribute and value to be set for that attribute.
    collection_search._load_collections("collections", "ansible.builtin")



# Generated at 2022-06-25 05:05:39.963497
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert isinstance(result, CollectionSearch)

# Generated at 2022-06-25 05:05:41.259856
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert not collection.post_validate()

# Generated at 2022-06-25 05:05:45.500245
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections._constructor('collection')
    assert CollectionSearch._collections._constructor(['ansible_collections.some.nested.collection'])

# Generated at 2022-06-25 05:06:11.992095
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  assert CollectionSearch()

# Generated at 2022-06-25 05:06:13.718909
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._load_collections(None, None) is None

# Generated at 2022-06-25 05:06:17.016276
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(CollectionSearch._collections.default == _ensure_default_collection)

# Generated at 2022-06-25 05:06:18.067985
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert isinstance(collection, CollectionSearch)

# Generated at 2022-06-25 05:06:23.190987
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)
    default_collection_name = AnsibleCollectionConfig.default_collection
    assert obj._collections.default == [default_collection_name]


# Generated at 2022-06-25 05:06:24.432774
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin']

# Generated at 2022-06-25 05:06:29.454312
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    default_collection = "ansible.builtin"
    # For testing purpose, we set the default collection to be ansible.builtin
    class MockAnsibleCollectionConfig(object):
        @property
        def default_collection(self):
            return default_collection
    AnsibleCollectionConfig.default_collection = MockAnsibleCollectionConfig().default_collection
    cs._collections = _ensure_default_collection()
    assert cs._collections == ['ansible.builtin']


# Generated at 2022-06-25 05:06:32.017979
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections == _ensure_default_collection()
    assert not search._collections



# Generated at 2022-06-25 05:06:36.480493
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import yaml

    yaml_str = '''
    collections:
    - collection_name
    '''
    yaml_bytes = yaml.dump(yaml.load(yaml_str))
    assert CollectionSearch()._load_collections(None, yaml_bytes) == ['collection_name']

# Generated at 2022-06-25 05:06:38.537243
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections == []
    assert x._collections is not None


# Generated at 2022-06-25 05:07:33.253538
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection.collections == _ensure_default_collection()

# Generated at 2022-06-25 05:07:35.079271
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj1 = CollectionSearch()
    assert obj1._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:07:39.944668
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj1 = CollectionSearch()
    test_obj2 = CollectionSearch()
    assert test_obj1._collections.field_name == 'collections'
    assert test_obj1._collections.default == test_obj2._collections.default

# Generated at 2022-06-25 05:07:41.525180
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default == _ensure_default_collection

# Generated at 2022-06-25 05:07:43.437776
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collections = collection_search.collections
    assert collections == []

# Generated at 2022-06-25 05:07:45.270000
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections("attr", None) == ['ansible_collections.ansible.builtin', 'ansible.legacy']
    assert CollectionSearch()._load_collections("attr", []) == ['ansible_collections.ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:07:46.492349
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible_collections.ansible']

# Generated at 2022-06-25 05:07:49.853933
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    test_object = cs._load_collections("collections", ["matty"])
    assert test_object == ['matty', 'ansible.builtin'], 'Error: CollectionSearch failed to initialize'

# Generated at 2022-06-25 05:07:51.122234
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    task = CollectionSearch()
    assert task._collections.get_default_value() == _ensure_default_collection()

# Generated at 2022-06-25 05:07:55.537036
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections == _ensure_default_collection()
    x = CollectionSearch(collections=['foo'])
    assert x._collections == _ensure_default_collection(['foo'])


# Unit tests for _ensure_default_collection

# Generated at 2022-06-25 05:10:13.365444
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearchTest(CollectionSearch):
        pass

    cst = CollectionSearchTest()
    assert _ensure_default_collection(cst.collections)

# Generated at 2022-06-25 05:10:14.918727
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    object = CollectionSearch()
    print("_collections of CollectionSearch is: " + str(object._collections))

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:10:18.252908
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is not None



# Generated at 2022-06-25 05:10:21.261618
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs1 = CollectionSearch()
    assert cs1.collections == ['ansible.builtin', 'ansible.legacy']

    cs2 = CollectionSearch(collections=['awesome.powertools.alpha'])
    assert cs2.collections == ['awesome.powertools.alpha', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:10:22.385404
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        cs = CollectionSearch()
        assert cs.collections == ['ansible.builtin', 'ansible.legacy']
    except NameError:
        pass

# Generated at 2022-06-25 05:10:23.497662
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    #collection_search._load_collections(attr, ds)

# Generated at 2022-06-25 05:10:28.683805
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection() == ['ansible.legacy']
    assert _ensure_default_collection(collection_list=['collections.foo']) == ['collections.foo', 'ansible.legacy']

# Generated at 2022-06-25 05:10:34.885765
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t._collections is t.__class__._collections
    assert t._collections.name == 'collections'
    assert t._collections.isa == 'list'
    assert t._collections.listof == string_types
    assert t._collections.priority == 100
    assert t._collections.default == _ensure_default_collection
    assert t._collections.always_post_validate is True
    assert t._collections.static is True

# Generated at 2022-06-25 05:10:39.615051
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections = [1, 2, 3]
    assert cs.collections == [1, 2, 3]
    assert cs._collections == [1, 2, 3]



# Generated at 2022-06-25 05:10:42.993014
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections, _ensure_default_collection()