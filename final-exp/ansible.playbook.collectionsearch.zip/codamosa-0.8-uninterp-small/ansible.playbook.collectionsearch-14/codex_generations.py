

# Generated at 2022-06-25 05:03:26.616124
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search)
    print(type(collection_search))
    print(isinstance(collection_search, CollectionSearch))

# Generated at 2022-06-25 05:03:30.215594
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1.collections == ['ansible_collections.community.general']

# Generated at 2022-06-25 05:03:32.715104
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_case_0()
    except Exception as Here:
        print(Here)


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:03:39.506599
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Set up the class
    collection_search = CollectionSearch()

    # Assert values of class attributes
    assert collection_search._collections == 'ansible.builtin'

    # Assert that if the collection_list is none, that it is replaced with the default collection
    collection_list = []
    assert collection_search._ensure_default_collection(collection_list) == 'ansible.builtin'

    # assert that if there is a collection_list that it gets added to if it wasn't there before
    collection_list.append('test')
    assert collection_search._ensure_default_collection(collection_list) == ['ansible.builtin', 'test']

    # assert that if there is a collection_list that the default collection gets added to if it wasn't there before
    collection_list.pop(0)
    assert collection_search

# Generated at 2022-06-25 05:03:42.334530
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Case 0: no arguments are passed in constructor
    test_case_0()


if __name__ == '__main__':
    # Unit tests to check the correctness of this class
    test_CollectionSearch()

# Generated at 2022-06-25 05:03:43.553710
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(collection_search_1, CollectionSearch)


# Generated at 2022-06-25 05:03:49.349989
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()

    #assert collection_search_0._collections._validate_func == _ensure_default_collection
    assert collection_search_0._collections._default == _ensure_default_collection
    assert collection_search_0._collections._priority == 100
    assert collection_search_0._collections._isa == 'list'
    assert collection_search_0._collections._listof == string_types
    assert collection_search_0._collections._always_post_validate
    assert collection_search_0._collections._static



# Generated at 2022-06-25 05:03:54.393911
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1.collections == _ensure_default_collection()
    assert collection_search_1.collections == [u'ansible.builtin', u'ansible.legacy']
    

# Generated at 2022-06-25 05:04:05.093618
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from types import ModuleType
    from ansible.module_utils.six import PY3
    if PY3:
        built_in_module = 'builtins'
    else:
        built_in_module = '__builtin__'
    collection_search_1 = CollectionSearch(collections=['ansible.builtin'])
    assert isinstance(collection_search_1._collections, list)
    collection_search_2 = CollectionSearch(collections=['ansible.builtin', 'ansible.legacy'])
    assert isinstance(collection_search_2._collections, list)
    collection_search_3 = CollectionSearch(collections=['test.test'])
    assert isinstance(collection_search_3._collections, list)

# Generated at 2022-06-25 05:04:14.984061
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch(collections=['collection1', 'collection2', 'collection3'])

    # Whether spec_collection_list is empty or not
    assert collection_search.collections == ['collection1', 'collection2', 'collection3']

    # Case where spec_collection_list is None
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin']

    # Case where spec_collection_list contains only one collection
    collection_search = CollectionSearch(collections=['collection1'])
    assert collection_search.collections == ['collection1', 'ansible.builtin']

    # Case where spec_collection_list is a list which is in wrong sequence
    collection_search = CollectionSearch(collections=['collection1', 'collection2', 'collection3', 'ansible.builtin'])

# Generated at 2022-06-25 05:04:22.807473
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None


# Test case for constructor of class CollectionSearch

# Generated at 2022-06-25 05:04:25.855995
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search



# Generated at 2022-06-25 05:04:26.899732
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()

# Generated at 2022-06-25 05:04:28.671395
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("Testing CollectionSearch constructor")
    collection_search_0 = CollectionSearch()



# Generated at 2022-06-25 05:04:31.462762
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ["/etc/ansible/ansible.cfg", "ansible.builtin", "ansible.legacy"]

# Generated at 2022-06-25 05:04:36.191999
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_case_0()
        assert True
    except AssertionError as e:
        assert False, "Failed to create instance of class CollectionSearch: " + str(e)
    except TypeError as e:
        assert False, "Failed to create instance of class CollectionSearch: " + str(e)
    except Exception:
        assert False, "Failed to create instance of class CollectionSearch"

# Generated at 2022-06-25 05:04:40.514456
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    collection_search_0.collections = [u'foo']

# Generated at 2022-06-25 05:04:46.099874
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible import collection_loader

    # We will capture the log messages through a logger
    from io import StringIO
    import logging
    logger = logging.getLogger('ansible')
    capture = StringIO()
    logger.addHandler(logging.StreamHandler(capture))

    # Mock the class loader to check the collections loaded
    original_load_collections = collection_loader.load_collections
    def my_load_collections(collections, override=False, include_path=None,
                            collection_list_cache=None, path_only=False,
                            ignore_deprecations=False):
        # Check the collection list
        assert collections == ['collection']
        # Check the include path
        assert include_path == '/path/to/my/plugin/path'
        # Make the call to the real method
       

# Generated at 2022-06-25 05:04:47.529752
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    print('Test CollectionSearch')
    collection_search_0 = CollectionSearch()
    print(collection_search_0)
    collection_search_0.post_validate()
    collection_search_0.post_validate()


# Generated at 2022-06-25 05:04:50.412248
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    if isinstance(collection_search_1, CollectionSearch):
        print("Unit test for class CollectionSearch constructor passed.")


# Generated at 2022-06-25 05:05:11.763050
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()

    # Testing the default value set for collections
    # It matches the predefined default value
    assert isinstance(collection_search_0._collections, list), '_collections is not a list.'
    collections_value_expected = ['ansible.builtin']
    assert collection_search_0._collections == collections_value_expected, '_collections value not set to expected.'
    expected_value = ['ansible.builtin']
    actual_value = _ensure_default_collection()
    assert actual_value == expected_value, 'Expected default value for collections must be [ansible.builtin]'

    # Testing the default value for method _load_collections
    # It matches the predefined default value

# Generated at 2022-06-25 05:05:13.442903
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:05:24.723025
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes

    class Connection(object):
        def __init__(self):
            self._play_context = PlayContext()

        def get_option(self, option):
            return getattr(self._play_context, option)

    class PlayContext(object):
        def __init__(self):
            self.remote_addr = None

        def __getattr__(self, item):
            return None

    class Options(object):
        def __init__(self):
            self.syntax = False
            self.listhosts = None
            self.listtasks = None
            self.listtags = None
            self.v2_playbook = False
            self.ask_pass = None
            self.vault_

# Generated at 2022-06-25 05:05:26.720161
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch(collections=["ansible.builtin"])
    assert collection_search.collections == ["ansible.builtin"]


# Generated at 2022-06-25 05:05:29.933986
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert isinstance(collection_search_0, CollectionSearch) == True


# Generated at 2022-06-25 05:05:31.333125
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:05:34.619967
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:05:45.521928
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """ Test constructor for class CollectionSearch.

            Test the arguments for class CollectionSearch:
                attr - isa, listof, priority, default, always_post_validate, static
    """
    # Test Class args: attr - isa
    assert CollectionSearch._collections.isa == 'list'
    # Test Class args: attr - listof
    assert CollectionSearch._collections.listof == string_types
    # Test Class args: attr - priority
    assert CollectionSearch._collections.priority == 100
    # Test Class args: attr - default
    assert CollectionSearch._collections.default == _ensure_default_collection
    # Test Class args: attr - always_post_validate
    assert CollectionSearch._collections.always_post_validate
    # Test Class args: attr - static
    assert CollectionSearch._col

# Generated at 2022-06-25 05:05:49.399020
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search=CollectionSearch()
    assert(collection_search)


# Generated at 2022-06-25 05:05:52.850920
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert(collection_search is not None)


# Generated at 2022-06-25 05:06:10.025603
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    objects = CollectionSearch()
    attr, ds = "collections", None
    # TODO: Fix kwargs that are not getting passed
    #objects._load_collections(attr, ds)

# Generated at 2022-06-25 05:06:11.782051
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    search = CollectionSearch()

    # check for instance of class
    assert isinstance(search, CollectionSearch)

# Generated at 2022-06-25 05:06:20.678342
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    task = CollectionSearch()
    default_collection = AnsibleCollectionConfig.default_collection
    # default value
    assert task._collections.default == _ensure_default_collection()
    # default value of collections field is _ensure_default_collection
    assert task._collections.default == _ensure_default_collection()
    # make sure it support empty list
    assert task.get_validated_value('collections', task._collections, None, None) == _ensure_default_collection()
    # make sure it support single item list
    assert task.get_validated_value('collections', task._collections, [default_collection], None) == default_collection


test_CollectionSearch()

# Generated at 2022-06-25 05:06:22.504807
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch(collections=['test.test1', 'test2.test3'])

# Generated at 2022-06-25 05:06:26.580024
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is not None
    # 'ansible.builtin' or 'ansible.legacy' will be in the list when builtin collection exists
    assert isinstance(cs.collections, list) and (cs.collections[0] == 'ansible.builtin' or cs.collections[0] == 'ansible.legacy')

# Generated at 2022-06-25 05:06:29.491918
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class DummyClass:
        # noinspection PyUnusedLocal
        def __init__(self, *args, **kwargs):
            self._collections = []

    col = CollectionSearch()
    col.post_validate(DummyClass(), None, None)

# Generated at 2022-06-25 05:06:32.949116
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_search = CollectionSearch()
    assert test_collection_search.collections == ['ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-25 05:06:37.281216
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest

    with pytest.raises(ValueError):
        CollectionSearch()

# Generated at 2022-06-25 05:06:40.099634
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_collections = ['Ansible.builtin']
        CollectionSearch(collections=test_collections)
    except Exception as err:
        print("Error Message: {}".format(err))
        print("CollectionSearch constructor failed.")

# Generated at 2022-06-25 05:06:43.720965
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search.post_validate()
    assert search._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:07:17.424433
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test collection search object creation
    collection_search = CollectionSearch()
    default_collection = AnsibleCollectionConfig.default_collection
    collection = 'ansible.builtin'
    assert (collection_search._collections._default is None)
    assert (collection_search._load_collections(collection_search._collections, None) == [collection])
    assert (collection_search._load_collections(collection_search._collections, []) == [collection])
    assert (collection_search._load_collections(collection_search._collections, [collection_search._collections._default]) == [collection_search._collections._default])
    assert (collection_search._load_collections(collection_search._collections, [collection]) ==
           [collection])

# Generated at 2022-06-25 05:07:20.734637
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.default == _ensure_default_collection
    assert c._collections.default == AnsibleCollectionConfig.default_collection

# Generated at 2022-06-25 05:07:25.345435
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    test._load_collections(None, [])
    # This is an invalid collection name, so an exception should be raised
    assert test._load_collections(None, ['a-collection-that-does-not-exist']) is None

# Generated at 2022-06-25 05:07:26.525674
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert isinstance(x, CollectionSearch)

# Generated at 2022-06-25 05:07:27.965372
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Verify constructor of class CollectionSearch
    c = CollectionSearch()
    assert(c is not None)

# Generated at 2022-06-25 05:07:29.276186
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible_collections.test.test_ns.test_coll_1']

# Generated at 2022-06-25 05:07:31.765000
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().get_validated_value('collections', CollectionSearch._collections, None, None) is None

# Generated at 2022-06-25 05:07:33.105867
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:07:38.103460
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default is None
    del cs._collections  # Test the property is correctly set.


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:07:41.894796
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search._collections, FieldAttribute)

# Generated at 2022-06-25 05:09:00.172083
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # The isa of collections is list, so we are passing list to constructor
    c = CollectionSearch(collections=['ansible.builtin'], collection_list=None)
    assert c.collections == ['ansible.builtin', 'ansible.builtin']
    # The above is to check the special case being handled in
    # _ensure_default_collection() of collection_list == None
    c = CollectionSearch(collections=['ansible.builtin'])
    assert c.collections == ['ansible.builtin', 'ansible.builtin']
    # The above is to check the special case being handled in
    # _ensure_default_collection() of collection_list == []
    c = CollectionSearch(collections=['ansible.builtin', 'community.actions'])

# Generated at 2022-06-25 05:09:08.507306
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Test a raw, empty CollectionSearch instance
    cs = CollectionSearch()

    #Test that the collections field is populated as expected
    assert cs._valid_attrs == {'collections': ['ansible_collections.ansible.builtin', 'ansible.legacy']}
    assert cs._collections.static
    assert cs._collections._field_name == 'collections'

    #Test that populating the 'collections' field with a list doesn't change things
    cs = CollectionSearch(collections=['one', 'two'])
    assert cs._valid_attrs == {'collections': ['one', 'two', 'ansible.legacy']}

    #Test that a non-list type for 'collections' raises an exception

# Generated at 2022-06-25 05:09:16.887484
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch._collections, FieldAttribute) is True
    assert CollectionSearch._collections.always_post_validate is True
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.kv is False
    assert CollectionSearch._collections.listof == string_types
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.static is True

# Generated at 2022-06-25 05:09:24.329710
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()

    # test 'collections'
    collection_list = ['foobar', 'ansible.builtin']
    collections._collections.post_validate(collection_list, None, None)
    assert collections.collections == collection_list
    assert collections._collections.value == collection_list

    collection_list = ['foobar', 'ansible.builtin']
    collections._collections.post_validate(collection_list, None, None)
    assert collections.collections == collection_list
    assert collections._collections.value == collection_list

# Generated at 2022-06-25 05:09:34.037750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()

    # Should return a list containing the first to last elements

# Generated at 2022-06-25 05:09:37.239114
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)

    # check values
    assert obj.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:09:40.482482
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch._collections is not None

# Generated at 2022-06-25 05:09:42.412553
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:09:44.555277
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col = CollectionSearch()
    if col._collections is None:
        print('Test_CollectionSearch success!')
    else:
        print('Test_CollectionSearch failed!')


# Generated at 2022-06-25 05:09:49.685712
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   def constructor_test():
       collection_search = CollectionSearch()
       ds = {'_collections': ['one', 'two']}

       # initialize collections list
       collection_search._load_collections(None, ds)

       # get collections list
       collections_result = collection_search._collections

       assert collections_result == ['one', 'two', 'ansible.builtin'], "collections list failed to initialize"

# Generated at 2022-06-25 05:12:30.734399
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections._default == _ensure_default_collection()

# Generated at 2022-06-25 05:12:32.470210
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections('collections', ['test_collection']) == ['test_collection']

# Generated at 2022-06-25 05:12:37.145882
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = [
        "old_collection",
        "new_collection",
        "ansible.builtin"
    ]
    assert _ensure_default_collection(collection_list=collections) == collections
    assert _ensure_default_collection(collection_list=None) == []
    assert _ensure_default_collection(collection_list=[]) == ['ansible.builtin']
    assert _ensure_default_collection(collection_list=["ansible.builtin"])
    assert _ensure_default_collection(collection_list=["ansible.builtin", "ansible.legacy"])

# Generated at 2022-06-25 05:12:38.170324
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.__dict__['_collections'].default() == None

# Generated at 2022-06-25 05:12:45.984471
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    # Test the use of default value
    assert collection_search.collections == _ensure_default_collection()

    # Test the use of a empty list
    collection_search = CollectionSearch(collections=[])
    assert collection_search.collections == _ensure_default_collection()

    # Test the use of a list of collections
    collection_search = CollectionSearch(collections=["collection"])
    assert collection_search.collections == _ensure_default_collection(collection_list=["collection"])

# Generated at 2022-06-25 05:12:50.793103
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   ds = {'collections': ['ansible_collections.nsweb.foo_collection'], 'roles': ['foo_role']}
   search = CollectionSearch()
   search._load_collections(None, ds)
   assert search._collections == ['ansible_collections.nsweb.foo_collection', 'ansible.builtin', 'ansible.legacy']
   search._load_collections(None, {'roles': ['foo_role']})
   assert search._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:12:55.293891
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.static == True
    assert c._collections.default == _ensure_default_collection
    assert c._collections.always_post_validate == True
    assert len(c._collections.choices) == 0
    assert c._collections.listof == string_types
    assert c._collections.private == False
    assert c._collections.required == False
    assert c._collections.priority == 100
    assert c._collections.isa == 'list'

# Generated at 2022-06-25 05:12:57.445144
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert isinstance(instance, CollectionSearch)


# Generated at 2022-06-25 05:13:04.172741
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext
    collection_search = CollectionSearch()
    assert collection_search.name == 'CollectionSearch'
    assert collection_search.collections == [None, 'ansible.builtin', 'ansible.legacy']
    assert collection_search.name == 'CollectionSearch'
    #assert collection_search.name == 'CollectionSearch'
    #assert collection_search.name == 'CollectionSearch'



# Generated at 2022-06-25 05:13:06.284720
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cls = CollectionSearch()
    cls._load_collections(None, None)
    assert cls.collections