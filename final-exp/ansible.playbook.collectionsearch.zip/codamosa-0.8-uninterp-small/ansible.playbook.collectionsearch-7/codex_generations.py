

# Generated at 2022-06-25 05:03:21.660725
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1 is not None


# test get_validated_value function of class CollectionSearch

# Generated at 2022-06-25 05:03:26.192184
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    if hasattr(CollectionSearch, '_collections'):
        assert isinstance(CollectionSearch._collections, FieldAttribute)
        assert CollectionSearch._collections.name == 'collections'
    collection_search_0 = CollectionSearch()
    assert hasattr(collection_search_0, '_collections')



# Generated at 2022-06-25 05:03:29.180726
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def test_cases():
        case_0()

    return test_cases

# Generated at 2022-06-25 05:03:29.890077
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)


# Generated at 2022-06-25 05:03:31.941673
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test_case_0
    collection_search_0 = CollectionSearch()
    assert collection_search_0.collections == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible.legacy']

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-25 05:03:34.997947
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0 is not None
    assert collection_search_0.collections is not None
    assert collection_search_0.collections == ['ansible_collections.nsweb.network']


# Generated at 2022-06-25 05:03:35.480972
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:03:39.234633
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search_0 = CollectionSearch()
    assert collection_search_0 is not None
    # TODO: add test to see if data_struct was updated to reflect a value was passed in.  Would
    # assert on collection_search_0._collections, but this is a hidden attr and covered by
    # FieldAttribute class.

    collection_search_1 = CollectionSearch()
    collection_search_1.collections = None
    assert collection_search_1.collections is None

    collection_search_2 = CollectionSearch()
    collection_search_2.collections = ['junk', 'ansible.builtin']
    assert not collection_search_2.collections
    assert collection_search_2.collections == ['ansible.builtin']

    collection_search_3 = CollectionSearch()
    collection_search_3.collections

# Generated at 2022-06-25 05:03:40.609838
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test with empty collection list
    test_case_0()

# Generated at 2022-06-25 05:03:41.260140
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()

# Generated at 2022-06-25 05:03:51.750473
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:03:53.444745
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == _ensure_default_collection()


# Generated at 2022-06-25 05:03:54.146553
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:03:57.854100
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    v_c = CollectionSearch()
    assert v_c.__class__.__name__ == 'CollectionSearch'

# Generated at 2022-06-25 05:03:58.386887
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-25 05:04:00.553485
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("\n--- Executing test_CollectionSearch_0 ---")
    test_case_0()

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:04:08.205591
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    collection_search_2 = CollectionSearch()
    assert collection_search_1.collections == collection_search_2.collections
    collection_search_1.collections = ['ansible.builtin', 'ansible.legacy']
    collection_search_2.collections = ['nsbl.modular_testing', 'nsbl.network_testing']
    assert collection_search_1.collections != collection_search_2.collections

# Generated at 2022-06-25 05:04:10.400085
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections.conf['default'] == _ensure_default_collection()

# Generated at 2022-06-25 05:04:11.728820
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    # Make sure __init__() returned something.
    assert collection_search_0

# Generated at 2022-06-25 05:04:15.870992
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()

    assert collection_search.collections



# Generated at 2022-06-25 05:04:32.092985
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert _ensure_default_collection(collection_list=None) == ['ansible.legacy']
    assert _ensure_default_collection(collection_list=[]) == ['ansible.legacy']
    assert _ensure_default_collection(collection_list=['ansible.builtin']) == ['ansible.builtin']
    assert _ensure_default_collection(collection_list=['sample.contrib']) == ['sample.contrib', 'ansible.legacy']
    assert _ensure_default_collection(collection_list=['ansible.builtin', 'sample.contrib']) == ['ansible.builtin', 'sample.contrib']

# Generated at 2022-06-25 05:04:37.936325
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # need to import here because of circular reference problem
    from ansible.plugins.loader import collection_loader

    test_data = dict()
    test_data['collections'] = None

    # The constructor of class CollectionSearch should call _ensure_default_collection()
    # to fill in a default value
    collection_search = CollectionSearch(Validatable.load(test_data))
    assert collection_loader.default_collection in collection_search.collections
    assert collection_loader.get_collections() in collection_search.collections

# Generated at 2022-06-25 05:04:40.311516
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    var = {'collections': ['ansible_namespace.role_name']}
    ds = CollectionSearch().get_datastructure(var)
    assert ds.get('collections') == ['ansible_namespace.role_name']

# Generated at 2022-06-25 05:04:40.775914
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()

# Generated at 2022-06-25 05:04:42.419343
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Creates CollectionSearch class object
    """
    cs_obj = CollectionSearch()
    print (type(cs_obj))
    print (cs_obj)

# Generated at 2022-06-25 05:04:45.061311
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This will be an empty list anyway
    ds = None
    display = Display()
    # TODO: This is a quick test, add before and after to test the result of _ensure_default_collection
    cs1 = CollectionSearch(ds, display)
    assert cs1._collections == _ensure_default_collection(ds)

# Generated at 2022-06-25 05:04:52.339142
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == []
    c = CollectionSearch(collections=['ansible.builtin'])
    assert c.collections == ['ansible.builtin']
    assert c._load_collections
    c = CollectionSearch(collections=['ansible.builtin', 'ansible_collections.test_collection'])
    assert c.collections == ['ansible_collections.test_collection', 'ansible.builtin']
    assert c._load_collections

# Generated at 2022-06-25 05:04:54.160615
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:05:00.313647
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create a instance of CollectionSearch
    collection_search = CollectionSearch()
    # Verify that the field collections is defined and has value of ansible.builtin
    assert collection_search._collections.name == 'collections'
    assert collection_search._collections["default"] == ['ansible.builtin']
    assert collection_search._collections.static is True

# Generated at 2022-06-25 05:05:04.475755
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ds = {'collections': ['test']}
    assert cs._load_collections(None, ds) == ['test']
    ds = {'collections': None}
    assert cs._load_collections(None, ds) is None

# Generated at 2022-06-25 05:05:20.351468
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()


# Generated at 2022-06-25 05:05:22.825278
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class_obj=CollectionSearch()
    class_obj._load_collections('attr',None)
    _ensure_default_collection()

# Generated at 2022-06-25 05:05:25.153978
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_key = CollectionSearch()
    assert search_key._collections._value == ['ansible_collections.ansible.builtin']

# Generated at 2022-06-25 05:05:26.096066
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    result = CollectionSearch()
    assert result

# Generated at 2022-06-25 05:05:29.100231
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    stmts = [
        dict(
            action=dict(
                module='test',
                args=dict(
                    test_arg=1,
                )
            )
        )
    ]
    cs = CollectionSearch()
    cs.post_validate(stmts, False)
    assert cs.collections == ['ansible_collections.ansible.builtin']

# Generated at 2022-06-25 05:05:36.998613
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    x = CollectionSearch()
    assert x is not None
    assert x.collections == _ensure_default_collection()

    # try loading collections
    x.collections = ['ansible_namespace.new_collection', 'ansible_namespace.old_collection']
    assert x.get_validated_value('collections', x._collections,
                                 x.collections, None) == ['ansible_namespace.new_collection', 'ansible_namespace.old_collection']
    assert x.collections == ['ansible_namespace.new_collection', 'ansible_namespace.old_collection']

    # try loading collections
    x.collections = ['ansible_namespace.new_collection']

# Generated at 2022-06-25 05:05:40.865473
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # set collections value
    cs._collections = [ "test.collection1", "test.collection2" ]
    assert cs._collections == [ "test.collection1", "test.collection2" ]
    # set collections value empty
    cs._collections = []
    # set collection_loader and call _load_collections
    # We expect that the default ansible collection is added
    cs.collection_loader = None
    assert _ensure_default_collection(collection_list=cs._collections) == [ "ansible.builtin" ]
    # set _collections with value and call _load_collections
    # We expect that the default ansible collection is still there
    cs._collections = [ "test.collection1", "test.collection2" ]

# Generated at 2022-06-25 05:05:47.409632
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections._static == True
    assert cs._collections._always_post_validate == True
    assert cs._collections._priority == 100
    assert cs._collections._default == _ensure_default_collection
    assert cs._collections._isa == 'list'
    assert cs._collections._listof == string_types()

# Generated at 2022-06-25 05:05:51.582495
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()
    collection_search._collections = ['ansible.builtin', 'ansible.legacy']

    assert collection_search._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:05:55.418806
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test the constructor
    try:
        cs = CollectionSearch()
    except Exception as e:
        assert False, "Unexpected error occurred creating an instance of CollectionSearch class: " + str(e)

    assert cs is not None, "Test for instance of class CollectionSearch is not initialized"
    assert isinstance(cs, CollectionSearch), "Test for instance of class CollectionSearch is failed"

# Generated at 2022-06-25 05:06:23.590902
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default is None
    assert type(cs._collections.default) is list


# Generated at 2022-06-25 05:06:24.702354
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        a = CollectionSearch()
        assert True
    except:
        assert False

# Generated at 2022-06-25 05:06:31.187271
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(CollectionSearch._collections.default is _ensure_default_collection)
    assert('ansible.builtin' in CollectionSearch._collections.default)
    assert('ansible.legacy' in CollectionSearch._collections.default)
    assert(CollectionSearch._collections.static is True)
    assert(CollectionSearch._collections.always_post_validate is True)
    assert(CollectionSearch._collections.priority == 100)
    assert(CollectionSearch._collections.isa == 'list')
    assert(isinstance(CollectionSearch._collections.listof, type(string_types)))


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 05:06:39.665350
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()

    # Test that _ensure_default_collection adds the default collection
    assert c._ensure_default_collection([])[0] == AnsibleCollectionConfig.default_collection

    # Test that _ensure_default_collection keeps the value in place if it is already there
    assert c._ensure_default_collection([AnsibleCollectionConfig.default_collection]) == [AnsibleCollectionConfig.default_collection]

    # Test that _ensure_default_collection adds the default collection when it is not in the list
    assert c._ensure_default_collection([AnsibleCollectionConfig.default_collection, "collection2"]) == [AnsibleCollectionConfig.default_collection, "collection2"]

    # Test that _ensure_default_collection does not add anything when the list does not contain anything
    # and the default collection

# Generated at 2022-06-25 05:06:44.121583
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    attr = 'collections'

    # data is none
    ds = None
    result = search._load_collections(attr, ds)
    assert result is None

    # data is not none
    ds = 'ansible.builtin:ansible_test'
    result = search._load_collections(attr, ds)
    assert result[0] == 'ansible.builtin'
    assert result[1] == 'ansible_test'

# Generated at 2022-06-25 05:06:46.037346
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert ['ansible_collections.ansible'] == obj._load_collections(None, ['ansible'])
    assert [None] == obj._load_collections(None, [])

# Generated at 2022-06-25 05:06:53.828472
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    global display
    display = Display()
    assert display is not None
    assert CollectionSearch._ensure_default_collection(None) == ['ansible_collections.ansible']
    assert CollectionSearch._ensure_default_collection(['ansible_collections.ns.collection']) == ['ansible_collections.ns.collection', 'ansible_collections.ansible']
    assert CollectionSearch._ensure_default_collection(['ansible_collections.ns.collection', 'ansible_collections.mo.another_collection']) == ['ansible_collections.ns.collection', 'ansible_collections.mo.another_collection', 'ansible_collections.ansible']

    # test with the ansible collection not being the default
    AnsibleCollectionConfig.default_collection = None
    assert CollectionSearch._ensure_default_collection

# Generated at 2022-06-25 05:06:55.210112
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection()

# Generated at 2022-06-25 05:06:59.977657
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collections = collection_search._load_collections('collections', None)
    assert collections is not None
    print(collections)
test_CollectionSearch()

# Generated at 2022-06-25 05:07:02.268410
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible_collections.community.general']

# Generated at 2022-06-25 05:08:00.554375
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search._collections = ['a', 'b']
    assert collection_search._collections == ['a', 'b']

# Generated at 2022-06-25 05:08:07.769230
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        obj = CollectionSearch(module=None)
        #test _load_collections()
        assert obj._load_collections(attr='collections', ds=['ansible.builtin']) == ['ansible.builtin']
        assert obj._load_collections(attr='collections', ds=[]) == None
    except Exception:
        raise Exception("collectionsearch module is broken")

# Generated at 2022-06-25 05:08:15.408334
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.field_type is not None
    assert collection_search._collections.priority == 100
    assert collection_search._collections.isa == 'list'
    assert collection_search._collections.listof == string_types
    assert collection_search._collections.default == _ensure_default_collection
    assert collection_search._collections.always_post_validate
    assert collection_search._collections.static
    assert collection_search._collections.always_post_validate
    assert collection_search._collections.static
    assert collection_search.collections == _ensure_default_collection()


# Generated at 2022-06-25 05:08:15.873956
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(_ensure_default_collection(), list)

# Generated at 2022-06-25 05:08:16.596975
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:08:18.079754
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_list = _ensure_default_collection()

    assert 'ansible.builtin' in collection_list or 'ansible.legacy' in collection_list

# Generated at 2022-06-25 05:08:20.765706
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-25 05:08:24.760761
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._load_collections(None, ['ansible.builtin','ansible.legacy']) == ['ansible.builtin','ansible.legacy']
    assert search._load_collections(None, []) == ['ansible.builtin','ansible.legacy']
    assert search._load_collections(None, None) == ['ansible.builtin','ansible.legacy']

# Generated at 2022-06-25 05:08:28.732184
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ansible_collection_config = CollectionSearch()

    assert ansible_collection_config.collections == ['ansible.builtin', 'ansible.legacy']
    assert ansible_collection_config._load_collections({},['ansible.builtin', 'ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']
    assert ansible_collection_config._load_collections({}, ['ansible.legacy']) == ['ansible.builtin', 'ansible.legacy']


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:08:33.134142
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Entity(object):
        collection_list = None

    c = CollectionSearch()
    c._collections = Entity()
    c.post_validate(c._collections, None)
    assert c.collections == ['ansible.builtin', 'ansible.default']
    return


# Generated at 2022-06-25 05:10:48.561960
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    resp = instance._load_collections(attr='collections', ds=None)
    assert resp is None

# Generated at 2022-06-25 05:10:53.550679
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj._collections == []
    assert test_obj._load_collections('_collections',['ansible_collections.my_namespace.my_collection','ansible.builtin']) == ['ansible_collections.my_namespace.my_collection','ansible.builtin']
    assert test_obj._load_collections('_collections',['ansible.builtin','ansible_collections.my_namespace.my_collection']) == ['ansible_collections.my_namespace.my_collection','ansible.builtin']
    assert test_obj._load_collections('_collections',['ansible.builtin']) == ['ansible.builtin']

# Generated at 2022-06-25 05:10:55.509263
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    s = CollectionSearch()
    s._load_collections("collections",["ansible.legacy"])

# Generated at 2022-06-25 05:10:56.043061
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert True

# Generated at 2022-06-25 05:11:02.249505
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    my_collection_search = CollectionSearch()
    my_collection_search._collections = []

    result = my_collection_search._load_collections(None, None)
    assert result == _ensure_default_collection(collection_list=None)

    result = my_collection_search._load_collections(None, ['collection_1', 'collection_2'] )
    assert result == ['collection_1', 'collection_2', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:11:04.071545
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is None

# Generated at 2022-06-25 05:11:06.538211
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class UserClass(CollectionSearch):
        pass

    c = UserClass()
    # constructor should have set the default already
    assert c._collections == _ensure_default_collection()

    # test that it can be set by the user
    c.collections = 'foo'
    assert c.collections == ['foo']

# Generated at 2022-06-25 05:11:07.321535
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections is None

# Generated at 2022-06-25 05:11:11.249745
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.default() == _ensure_default_collection()

# Generated at 2022-06-25 05:11:15.981333
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    print(cs)

if __name__ == "__main__":
    test_CollectionSearch()