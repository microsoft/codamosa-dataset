

# Generated at 2022-06-25 05:03:27.599474
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()



# Generated at 2022-06-25 05:03:30.314203
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:03:32.222168
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    print("\nCollectionSearch")
    print("Collections:", c._collections)
    print("Collections:", c.collections)
    print("Collections:", c._attributes)


# Generated at 2022-06-25 05:03:33.069348
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert True



# Generated at 2022-06-25 05:03:35.656709
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin', 'ansible.legacy'] or \
           collection_search.collections == ['ansible.builtin']


# Generated at 2022-06-25 05:03:43.786679
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_case_0()
    except Exception as err:
        print("Error occurred while testing CollectionSearch():")
        print(err)
        return False
    else:
        return True

if __name__ == '__main__':
    result = test_CollectionSearch()
    if not result:
        print("CollectionSearch() class test failed!")
        exit(1)

    print("CollectionSearch() class test passed!")
    exit(0)

# Generated at 2022-06-25 05:03:46.773935
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert len(collection_search_0.collections) == 1
    collection_search_0.collections = ["cool.meh"]
    assert collection_search_0._collections == ["cool.meh"]

# Generated at 2022-06-25 05:03:48.948286
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    # FIXME: CollectionSearch._collections.post_validate() was called
    assert collection_search_0._collections == _ensure_default_collection()



# Generated at 2022-06-25 05:03:52.145759
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll = CollectionSearch()
    assert coll._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:03:52.926551
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:03:57.986431
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert isinstance(a, CollectionSearch)



# Generated at 2022-06-25 05:04:00.526200
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    attr = 'collections'
    ds = []
    collection = CollectionSearch()
    collections = collection._load_collections(attr, ds)
    assert collections in (None, [])

# Generated at 2022-06-25 05:04:06.701762
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext

    collection_search = CollectionSearch()
    play_context = PlayContext()
    ds = "my.collection"
    attr = 'collections'

    collection_search.post_validate({attr: ds}, play_context)
    assert collection_search._collections == ds

# Generated at 2022-06-25 05:04:10.803441
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c1 = CollectionSearch()
    c2 = CollectionSearch(collections=['ansible.builtin'])
    assert c1._collections == ['ansible.builtin']
    assert c2._collections == ['ansible.builtin']

# Generated at 2022-06-25 05:04:18.094389
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collections = [
        "collection_one",
        "collection_two"
    ]
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    cs._collections = test_collections
    assert cs._collections == _ensure_default_collection(collection_list=test_collections)



# Generated at 2022-06-25 05:04:26.744485
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # create an instance of CollectionSearch
    search = CollectionSearch()
    # get the value of static attribute _collections
    result = search._collections
    # assert if the value of static attribute _collections is a valid data structure
    assert isinstance(result, FieldAttribute)
    # assert if the value of static attribute _collections is a list
    assert isinstance(result.listof, type)
    assert result.listof == string_types
    # assert if the value of static attribute _collections is 100
    assert result.priority == 100
    # assert if the value of static attribute _collections is True
    assert result.always_post_validate == True
    # assert if the value of static attribute _collections is True
    assert result.static == True
    # assert if the value of static attribute _collections is _ensure_default_collection

# Generated at 2022-06-25 05:04:36.347890
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def _ensure_default_collection_2(collection_list=None):
        default_collection = AnsibleCollectionConfig.default_collection

        # Will be None when used as the default
        if collection_list is None:
            collection_list = []

        # FIXME: exclude role tasks?
        if default_collection and default_collection not in collection_list:
            collection_list.insert(0, default_collection)

        # if there's something in the list, ensure that builtin or legacy is always there too
        if collection_list and 'ansible.builtin' not in collection_list and 'ansible.legacy' not in collection_list:
            collection_list.append('ansible.legacy')

        return collection_list

    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import is_template
   

# Generated at 2022-06-25 05:04:38.005815
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == _ensure_default_collection(), 'CollectionSearch test failed'

# Generated at 2022-06-25 05:04:44.085642
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search = CollectionSearch()
        assert collection_search
    except:
        assert False, 'Failed to create a collection_search object.'

    try:
        collection_search.collections = 'my_collection'
        assert False, 'Failed to raise an assertion error when attempting to assign a non-list value to the collection_search' \
                      'collections field.'
    except:
        assert True, 'Successfully raised an assertion error when attempting to assign a non-list value to the ' \
                     'collection_search collections field.'

    try:
        collection_search.collections = ['my_collection']
        assert collection_search.collections == ['my_collection']
    except:
        assert False, 'Failed to assign a value to the collections field.'



# Generated at 2022-06-25 05:04:47.509269
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert not hasattr(collection_search, '_collections')



# Generated at 2022-06-25 05:04:56.470062
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin']

# Generated at 2022-06-25 05:04:57.171943
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()

# Generated at 2022-06-25 05:05:00.361909
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Role(CollectionSearch):
        pass
    task = Role()
    assert task._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:05:04.364198
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    try:
        c.collections
        raise AssertionError('Missing required constructor parameter "collections"')
    except AttributeError:
        pass
    c.collections = ['collections.test']
    assert c.collections == ['collections.test']

# Generated at 2022-06-25 05:05:09.253644
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # We are always a mixin with Base, so we can validate this untemplated
    # field early on to guarantee we are dealing with a list.
    ds = CollectionSearch()


# Generated at 2022-06-25 05:05:13.131471
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with pytest.raises(TypeError):
        CollectionSearch()

# Generated at 2022-06-25 05:05:14.664070
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:05:18.685111
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display = Display()
    display.columns = 80
    display.verbosity = 2
    display.verbosity = 2
    display.verbosity = 2
    display.verbosity = 2
    assert isinstance(CollectionSearch, object)



# Generated at 2022-06-25 05:05:20.504942
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, object)
    assert isinstance(cs._collections, FieldAttribute)

# Generated at 2022-06-25 05:05:23.744154
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    '''
    test_CollectionSearch class ensures that constructor of class CollectionSearch
    which is used for collection search on server,
    '''

    assert CollectionSearch._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:05:39.820178
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    assert t.__dict__['_collections'] is not None

# Generated at 2022-06-25 05:05:41.108631
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch('myplay')
    assert cs is not None

# Generated at 2022-06-25 05:05:45.773527
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #Test instantiation of class
    assert CollectionSearch('collections',[]) is not None
    #Test if collection actually returns something
    assert CollectionSearch('collections',[])._load_collections([]) is not None

# Generated at 2022-06-25 05:05:49.149342
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert 240 == len(CollectionSearch._get_attributes())

# Generated at 2022-06-25 05:05:53.247995
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    attr = 'collections'
    value = ['ansible.posix']
    ds = dict(collections=value)
    cs = CollectionSearch()
    cs._load_collections(attr, ds)

# Generated at 2022-06-25 05:06:00.082076
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import Include
    from ansible.playbook.task.action import Action
    from ansible.playbook.block import Block

    class TestClass(object):
        def __init__(self, body, role=None, collection_list=None, task_name=None):
            if collection_list is None:
                collection_list = []
            if role is None:
                role = RoleDefinition()
            if body is None:
                body = Block()
            if task_name is None:
                task_name = 'test_task'

            self.collection_list = collection_list
            self.task_name = task_name
            self.body = body
            self.role = role


# Generated at 2022-06-25 05:06:01.217620
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert not hasattr(collection_search, '_collections')

# Generated at 2022-06-25 05:06:01.834658
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections is None

# Generated at 2022-06-25 05:06:02.976771
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible_collections.test.test_loader.tasks.test import CollectionSearch

# Generated at 2022-06-25 05:06:08.451597
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch(collections=['ansible_collections.namespace.collection'])
    assert cs._collections == ['ansible_collections.namespace.collection', 'ansible.legacy']

# Generated at 2022-06-25 05:06:40.790148
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search1 = CollectionSearch()
    # search1 should not be none
    assert search1 is not None
    # search1 should have a collections attribute
    assert hasattr(search1, '_collections'), 'CollectionSearch does not have a collections attribute'
    # collections should be a string
    assert isinstance(search1._collections, string_types), 'CollectionSearch._collections should be a string'

# Generated at 2022-06-25 05:06:46.514193
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test empty collection list
    search = CollectionSearch(collections=[])
    assert search.collections == []

    # test None collection list
    search = CollectionSearch(collections=None)
    assert search.collections == ['ansible.builtin']

    # test non-empty collection list
    search = CollectionSearch(collections=['ansible.builtin'])
    assert search.collections == ['ansible.builtin']

# Generated at 2022-06-25 05:06:47.918447
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search_obj = CollectionSearch()
    assert _ensure_default_collection(collection_list=search_obj.collections) == search_obj.collections

# Generated at 2022-06-25 05:06:53.206859
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    obj = CollectionSearch()
    # Check if the object is an instance of CollectionSearch
    assert isinstance(obj, CollectionSearch)

    # Check if the object is an instance of FieldAttribute
    assert isinstance(obj._collections, FieldAttribute)

# Generated at 2022-06-25 05:06:56.086688
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    c.collections = [ 'collection1', 'collection2']
    assert c.collections == [ 'collection1', 'collection2']
    c.collections = None
    assert c.collections == [ 'ansible_collections.ansible']

# Generated at 2022-06-25 05:07:05.408931
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    # Test the constructor of class CollectionSearch
    assert CollectionSearch(parent=None, loader=None)

    # Test the constructor of class CollectionSearch
    # collection_list will be None
    assert CollectionSearch._ensure_default_collection()

    # Test the constructor of class CollectionSearch
    # collection_list will not be empty
    collection_list = ['system']
    assert CollectionSearch._ensure_default_collection(collection_list)

    # Test the constructor of class CollectionSearch
    collections = collection_list
    base = Base()
    assert CollectionSearch._load_

# Generated at 2022-06-25 05:07:10.150629
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  #NOTE: It seems that I cannot access to self._collections from here...
  #collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
  #                                always_post_validate=True, static=True)
  #print(type(collections))
  #print(collections._get_default())
  cs = CollectionSearch()
  print(cs._collections._get_default())

# Execute the test
test_CollectionSearch()

# Generated at 2022-06-25 05:07:19.965220
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # 1. test collections field, ensure it was initialized with ansible.builtin
    expected_collections = ['ansible.builtin']
    cs = CollectionSearch()
    actual_collections = cs.collections
    assert expected_collections == actual_collections

    # 2. test _load_collections function with valid collections param
    test_collections = ['ansible.builtin', 'mytest']
    actual_collections = cs._load_collections(None, test_collections)
    assert test_collections == actual_collections

    # 3. test _load_collections function with invalid collections param
    test_collections = ''
    actual_collections = cs._load_collections(None, test_collections)
    assert test_collections == actual_collections

test_CollectionSearch()

# Generated at 2022-06-25 05:07:22.323440
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class MyCollectionSearch(CollectionSearch):
        pass

    my_collection_search = MyCollectionSearch()
    assert(my_collection_search._load_collections(attr=None, ds=None) is None)

# Generated at 2022-06-25 05:07:23.814778
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs != None

# Generated at 2022-06-25 05:08:34.150727
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Search(CollectionSearch):
        pass
    search = Search()
    assert search.collections == ['ansible.builtin']

# Generated at 2022-06-25 05:08:37.180656
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections == _ensure_default_collection()
    search.collections = ['test']
    assert search._collections == _ensure_default_collection(['test'])



# Generated at 2022-06-25 05:08:38.462786
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:08:41.080425
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_class = CollectionSearch()
    test_attr = 'collections'
    test_ds = ''
    assert test_class._load_collections(test_attr, test_ds) == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:08:50.941937
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Using constructor of class CollectionSearch
    cs = CollectionSearch()
    # Did the object get created?
    assert type(cs).__name__ == 'CollectionSearch'
    # Now see if the object type is correct
    assert isinstance(cs, CollectionSearch)

    # Extracting the value of _collections
    col = cs._collections
    # Did the value get extracted?
    assert type(col).__name__ == 'FieldAttribute'
    # Now see if the field has the correct value
    assert col.name == 'collections'
    assert col.priority == 100
    assert col.static is True
    assert col.always_post_validate is True
    assert col.default == _ensure_default_collection
    assert col.isa == 'list'
    assert col.listof == string_types


# Generated at 2022-06-25 05:08:52.209207
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections() == ['ansible_collections.ansible.builtin']

# Generated at 2022-06-25 05:08:56.611670
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """make sure that the CollectionSearch constructor works as expected
    """
    collection_search = CollectionSearch()
    print(collection_search._collections)

if __name__ == '__main__':
    """
    POC to run this module as stand alone script
    """
    test_CollectionSearch()

# Generated at 2022-06-25 05:09:03.494524
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    coll=CollectionSearch()
    attr = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)
    #ds = coll.get_validated_value('collections',attr,[],None)
    ds = coll.get_validated_value('collections',attr,[],None)
    #print("ds is:",ds)
    #print("type is:",type(ds))

#test_CollectionSearch()

# Generated at 2022-06-25 05:09:04.892632
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch()._collections.default_for, list)


# Generated at 2022-06-25 05:09:09.258751
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_obj = CollectionSearch()
    assert test_obj.collections == []
    assert test_obj._load_collections(None, None) == None

# Generated at 2022-06-25 05:11:41.513590
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search.collections == ['ansible_collections.ansible.builtin', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:11:46.310708
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default_value == _ensure_default_collection()

# Generated at 2022-06-25 05:11:55.847680
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    RoleInclude.__bases__ = (CollectionSearch, )
    test_block = Block()

    test_block.collections = [
        'Admin.dbbackup',
        'Admin.dbserver'
        ]
    test_block.post_validate()

    assert test_block.collections == [
        'Admin.dbbackup',
        'Admin.dbserver',
        'ansible.legacy'
        ]
    test_block.collections = None
    test_block.post_validate()

    assert test_block.collections == 'ansible.legacy'
    test_block.collections = 'Admin.dbserver'
    test_block.post_validate()

# Generated at 2022-06-25 05:12:06.727316
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.roles_manager import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from collections import namedtuple
    dataset = namedtuple('dataset', 'task_ds task_include_ds role_ds')

    # Testing with 'collections' unset
    tasks = [Task().load(dataset(task_ds={}, task_include_ds={}, role_ds={}))]
    test_search = CollectionSearch()
    test_search._collections = _ensure_default_collection()
    assert test_search._load_collections("collections", dataset(task_ds={}, task_include_ds={}, role_ds={})) is not None

    # Testing

# Generated at 2022-06-25 05:12:10.738573
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._load_collections() == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:12:14.835451
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """ This function performs unit test for constructor of class CollectionSearch. """
    a = CollectionSearch()
    assert a is not None

# Generated at 2022-06-25 05:12:17.677876
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = 'ansible.builtin'
    assert _ensure_default_collection() == [ds]
    assert _ensure_default_collection(['ansible.builtin']) == [ds]
    assert _ensure_default_collection([]) == [ds]
    assert _ensure_default_collection(None) == [ds]

# Generated at 2022-06-25 05:12:20.816589
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj.get_validated_value('collections', obj._collections, None, None)

# Generated at 2022-06-25 05:12:28.900779
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #case 1: test default value in constructor
    cs = CollectionSearch()
    assert 'ansible.builtin' in cs._collections or 'ansible.legacy' in cs._collections
    assert 'ansible.builtin' in cs._collections or 'ansible.legacy' in cs._collections

    #case 2: test constructor with specific value
    cs = CollectionSearch(collections=['test'])
    assert 'test' in cs._collections
    assert 'ansible.builtin' in cs._collections or 'ansible.legacy' in cs._collections

# Generated at 2022-06-25 05:12:33.670296
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # testing the default constructor -> .collections should be a list with one element (ansible.builtin)
    c = CollectionSearch()
    assert c.collections == ['ansible.builtin']
    # testing the constructor with a list as parameter -> .collections should be a list of 2 elements
    c = CollectionSearch(collection_list=['ansible.linux', 'ansible.builtin'])
    assert c.collections == ['ansible.linux', 'ansible.builtin']