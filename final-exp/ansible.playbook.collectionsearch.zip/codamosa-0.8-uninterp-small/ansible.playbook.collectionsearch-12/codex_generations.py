

# Generated at 2022-06-25 05:03:24.688300
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert not hasattr(collection_search_0, 'collections')
    assert not hasattr(collection_search_0, '_collections')
    assert not hasattr(collection_search_0, '_loader')


# Generated at 2022-06-25 05:03:28.110988
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Constructing the collection_search object
    collection_search = CollectionSearch()


# Generated at 2022-06-25 05:03:30.266927
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1.collections is None

# Generated at 2022-06-25 05:03:33.692831
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    collection_search_1 = CollectionSearch()

    assert collection_search_0 == collection_search_1

    collection_search_1 = CollectionSearch({})

    assert collection_search_0 == collection_search_1



# Generated at 2022-06-25 05:03:35.935913
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search_0 = CollectionSearch()
    except Exception:
        assert False, "Unexpected error"
    else:
        assert True, "Constructor of CollectionSearch class is working"

# Generated at 2022-06-25 05:03:45.337564
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with pytest.raises(TypeError):
        display.warning = MagicMock()
        collection_search_1 = CollectionSearch()
        collection_search_1._load_collections('collections', ['collection1', 'collection2'])
        display.warning.assert_has_calls([call('"collections" is not templatable, but we found: collection1, it will not be templated and will be used "as is".'), call('"collections" is not templatable, but we found: collection2, it will not be templated and will be used "as is".')])


# Generated at 2022-06-25 05:03:47.798215
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)

# Generated at 2022-06-25 05:03:58.432964
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test default collections
    collection_search = CollectionSearch()
    ds = {
        'collections': [
            'test.Collection1',
            'test.Collection2',
            'test.Collection3',
        ]
    }

    # Test collections as None, then lists
    assert collection_search._load_collections('collections', ds) == [
        'test.Collection3',
        'test.Collection2',
        'test.Collection1',
        'ansible.builtin',
    ]

    ds['collections'] = None
    assert collection_search._load_collections('collections', ds) == [
        'ansible.builtin',
    ]

    # Test collections with only the default collections
    ds['collections'] = [
        'ansible.builtin',
    ]
   

# Generated at 2022-06-25 05:03:59.406589
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()

    assert isinstance(collection_search_0, CollectionSearch)

# Generated at 2022-06-25 05:04:02.503300
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection

# Generated at 2022-06-25 05:04:09.072019
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs=CollectionSearch()
    assert cs._load_collections(None, None) is not None

# Generated at 2022-06-25 05:04:12.028656
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.collections = ['jrambah', 'jrambah.network']
    # Expected to return list of collections
    assert collection_search.collections == ['jrambah', 'jrambah.network']

# Generated at 2022-06-25 05:04:17.755820
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t = CollectionSearch()
    t.post_validate()
    assert t.collections
    assert t.collections[0] == 'ansible.builtin'
    assert 'ansible.builtin' in t.collections

# Generated at 2022-06-25 05:04:20.741751
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()

# Generated at 2022-06-25 05:04:23.758101
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class FakeParent:
        def __init__(self):
            self.collections = ['collection1', 'collection2']

    c = CollectionSearch()
    c._validate_attributes(None, FakeParent())
    assert isinstance(c.collections, list)

# Generated at 2022-06-25 05:04:28.069576
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    src = CollectionSearch()
    print(src._collections)
    src = CollectionSearch(collections=['windows.jd'])
    print(src._collections)



# Generated at 2022-06-25 05:04:29.438864
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-25 05:04:32.413464
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_obj1 = CollectionSearch()
    col_dict = col_obj1.deprecated_evaluate_deprecated_attrs()
    assert col_dict == col_obj1._attributes_class.defaults

# Generated at 2022-06-25 05:04:35.714119
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin','ansible.legacy']

# Generated at 2022-06-25 05:04:38.480803
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    ds = dict()
    ds['collections'] = ['xxx', 'ansible.builtin']
    ds = c._load_collections('collections', ds)
    assert ds == ['ansible.builtin']

# Generated at 2022-06-25 05:04:50.835565
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # todo: add unit test for all functions
    a = CollectionSearch()
    assert a._load_collections('attr', ['collections.azure.azcollection']) == ['collections.azure.azcollection', 'ansible.builtin']
    assert a._collections._default == ['ansible.builtin']

# Generated at 2022-06-25 05:04:52.720707
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert instance is not None
    assert isinstance(instance,CollectionSearch)

# Generated at 2022-06-25 05:04:57.939588
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Foo(CollectionSearch):
        pass
    foo = Foo({'collections': 'ansible.posix'})
    assert foo._collections == 'ansible.posix'
    assert foo.collections == 'ansible.posix'

# Generated at 2022-06-25 05:05:01.523666
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs1 = CollectionSearch()
    assert cs1

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-25 05:05:03.020585
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch()._collections, FieldAttribute)

# Generated at 2022-06-25 05:05:04.257619
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()
    assert col_search is not None

# Generated at 2022-06-25 05:05:05.340109
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch({})
    assert collections._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:05:07.104038
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-25 05:05:09.839729
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()
    assert collection_search.get_default_attr_value('collections') == _ensure_default_collection()

# Generated at 2022-06-25 05:05:15.920618
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()

# Generated at 2022-06-25 05:05:32.531092
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections.default == _ensure_default_collection()
    assert c._collections.static == True
    assert c._collections.always_post_validate == True



# Generated at 2022-06-25 05:05:34.265724
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections is not None
    print("Unit test for constructor of class CollectionSearch")


# Generated at 2022-06-25 05:05:35.055316
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch.collections(None)

# Generated at 2022-06-25 05:05:39.302687
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)

# Generated at 2022-06-25 05:05:43.544544
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()

    assert collectionSearch._collections is not None

    assert collectionSearch._collections.default == _ensure_default_collection
    assert collectionSearch._collections.default() == ['ansible.builtin']
    # assert collectionSearch._collections.default() == ['collection']
    assert collectionSearch._collections.final == ['ansible.builtin']

# Generated at 2022-06-25 05:05:50.785664
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #test init
    test_collections = CollectionSearch()
    assert test_collections._collections.default == _ensure_default_collection
    assert [test_collections.collections] == [_ensure_default_collection()]

    # test updating values for collections
    test_collections._collections.default = ['ansible.builtin', 'ansible.legacy']
    assert [test_collections.collections] == [['ansible.builtin', 'ansible.legacy']]
    test_collections._collections.default = 'test.test.test'
    assert [test_collections.collections] == [['test.test.test']]


if __name__ == "__main__":
    # Unit tests
    test_CollectionSearch()

    # Integration tests

# Generated at 2022-06-25 05:05:52.270138
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections == [AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-25 05:05:53.662676
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

# Generated at 2022-06-25 05:05:55.159053
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible_collections.dwharder.foo_bar']

# Generated at 2022-06-25 05:05:56.644292
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_test = CollectionSearch()
    assert collection_search_test._collections is not None

# Generated at 2022-06-25 05:06:30.499002
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """ Unit test for constructor of class CollectionSearch and it's functionality. """
    # test for constructor
    # testing for object creation
    try:
        CollectionSearch(collections=['ansible.builtin'])
        assert True
    except Exception:
        assert False

    # testing for object creation by passing only collections
    try:
        CollectionSearch(collections=['ansible.builtin', 'ansible.legacy'])
        assert True
    except Exception:
        assert False

    # testing for object creation by passing both collections and variables
    try:
        CollectionSearch(collections=['ansible.builtin', 'ansible.legacy'], variables={'var_key': 'var_value'})
        assert True
    except Exception:
        assert False

    # testing for object creation by passing both collections, variables, and _host

# Generated at 2022-06-25 05:06:34.092682
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearchTest(CollectionSearch):
        pass

    collection_search = CollectionSearchTest()
    assert collection_search._load_collections(None, None) == _ensure_default_collection(None)

# Generated at 2022-06-25 05:06:38.568571
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch(collections=['test'])
    assert obj.collections == ['test', 'ansible.legacy']

# Generated at 2022-06-25 05:06:46.587190
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_coll = CollectionSearch()
    ret = test_coll._load_collections(attr='collections', ds='ansible.builtin')
    assert ret == ['ansible.builtin', 'ansible.legacy']
    ret = test_coll._load_collections(attr='collections', ds='ansible.posix')
    assert ret == ['ansible.posix', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:06:54.343737
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class TestCollectionSearch(CollectionSearch):
        pass

    test_obj = TestCollectionSearch()

    assert test_obj._load_collections('collections', ['awx.awx']) == ['awx.awx', 'ansible.builtin']

    test_obj = TestCollectionSearch(collections='awx.awx')
    assert test_obj._load_collections('collections', test_obj) == ['awx.awx', 'ansible.builtin']

    test_obj = TestCollectionSearch(collections=['awx.awx', 'another_collection'])
    assert test_obj._load_collections('collections', test_obj) == ['awx.awx', 'another_collection', 'ansible.builtin']

# Generated at 2022-06-25 05:06:58.945212
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from types import MethodType
    _test = MethodType(_load_collections, None, CollectionSearch)
    _test(None, None, None)

# Generated at 2022-06-25 05:07:05.771605
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        cs = CollectionSearch()
        if not isinstance(cs, CollectionSearch):
            raise Exception("Object is not an instance of class CollectionSearch: %s" % cs)
    except Exception as e:
        display.warning("Error in unit test 'CollectionSearch': %s" % e)
        return False

    return True

# Unit test _load_collections() with arg 'None'

# Generated at 2022-06-25 05:07:07.338588
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Asserted true if a constructor is working.
    assert CollectionSearch

# Generated at 2022-06-25 05:07:18.022393
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    import inspect
    assert cs.collections == inspect.cleandoc("""
        # Collection to use for this task. If not set, will fall back to the
        # `collections` value in `ansible.cfg`. Multiple collections can be
        # specified as a list.

        collections:
          - 'ansible.builtin'
          - 'community.general'
          - 'ansible_namespace.collection_name'
    """).strip()
    assert str(cs.collections) == 'ansible.builtin'
    # assert cs.collections.static == True
    assert cs.collections.always_post_validate == True


###################################################################
#                                                                 #
#                get_collection_roles_list                        #
#                                                                 #
###################################################################


# Generated at 2022-06-25 05:07:20.488835
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role import Role
    role = Role()
    assert role._collections == []

# Generated at 2022-06-25 05:08:33.640379
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:08:35.656746
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(attr=None, ds=None) is None

# Generated at 2022-06-25 05:08:45.247245
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude
    assert issubclass(TaskInclude, CollectionSearch)
    task_obj = TaskInclude.load(dict(name='task name', with_items='some_var'),
                                collection_list=['some_collection'])

    assert issubclass(RoleDefinition, CollectionSearch)
    role_obj = RoleDefinition.load(dict(name='role name', become='true'),
                                   task_blocks=['some_task'],
                                   collection_list=['some_collection'])

    assert task_obj['collections'] == ['some_collection', 'ansible.builtin']
    assert role_obj['collections'] == ['some_collection', 'ansible.builtin']

    # validate that the error message

# Generated at 2022-06-25 05:08:45.764639
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch

# Generated at 2022-06-25 05:08:47.910974
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None

# Generated at 2022-06-25 05:08:51.612574
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._load_collections(None,[]) is None
    assert c._load_collections(None,None) is not None

# Generated at 2022-06-25 05:08:55.746065
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    d = {
        "collections": [
            'foo.collection'
        ]
    }
    cs = CollectionSearch()
    assert cs.collections == ['foo.collection', 'ansible.builtin']

# Generated at 2022-06-25 05:08:58.278607
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default_value == ['ansible_collections.ansible.builtin', 'ansible.builtin']

# Generated at 2022-06-25 05:09:05.011631
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()
    assert c._load_collections('collections', None) == _ensure_default_collection()
    assert c._load_collections('collections', '') == _ensure_default_collection()
    assert c._load_collections('collections', []) == _ensure_default_collection()
    assert c._load_collections('collections', ['col1', 'col2']) == ['col1', 'col2', 'ansible.builtin']

# Generated at 2022-06-25 05:09:06.334573
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search is not None

# Generated at 2022-06-25 05:11:45.774050
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin']
    cs._collections = ['ansible.builtin', 'ansible.builtin.legacy']
    cs.collections = None
    assert cs.collections == ['ansible.builtin', 'ansible.builtin.legacy']
    assert cs._collections == ['ansible.builtin', 'ansible.builtin.legacy']
    cs.collections = ['ansible.builtin']
    assert cs.collections == ['ansible.builtin']
    assert cs._collections == ['ansible.builtin']
    cs.collections = ['ansible.builtin', 'ansible.builtin.legacy']
    assert cs.collections == ['ansible.builtin', 'ansible.builtin.legacy']

# Generated at 2022-06-25 05:11:49.777267
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections is _ensure_default_collection(collection_list=None)

# Generated at 2022-06-25 05:11:50.233599
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-25 05:11:52.329283
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_collection_search = CollectionSearch()
    except Exception as err:
        print("Exception while creating object CollectionSearch")
        print("Exception: "+str(err))


# Generated at 2022-06-25 05:11:55.083044
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is not None
    assert collection_search._load_collections is not None

# Generated at 2022-06-25 05:12:03.064957
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    display_constructor = Display()  # To suppress the constructor output in unit testing
    global display  # To suppress the output in unit testing
    display = display_constructor

    # Constructor of class CollectionSearch, which is a mixin with Base, should load the collections attribute
    # instantiate one CollectionSearch object, and the class member _collections should be set to be _ensure_default_collection(None)
    # which is ['ansible.builtin', 'ansible.legacy']
    collection_search_obj = CollectionSearch()
    assert collection_search_obj._collections == ['ansible.builtin', 'ansible.legacy']

    # Constructor of class CollectionSearch, which is a mixin with Base, should load the collections attribute
    # instantiate one CollectionSearch object, and the class member _collections should be set to be _ensure_

# Generated at 2022-06-25 05:12:10.344585
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()

    # Test for _load_collections() function
    assert col_search._load_collections(None, None) == None

    # Test for _ensure_default_collection() function
    default_collection = AnsibleCollectionConfig.default_collection
    collection_list = None
    _ensure_default_collection(collection_list)
    assert collection_list == [default_collection]

    collection_list = ['a.yml']
    default_collection = None
    _ensure_default_collection(collection_list)
    assert collection_list == ['a.yml']

# Generated at 2022-06-25 05:12:14.129835
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-25 05:12:17.045993
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == (AnsibleCollectionConfig.default_collection, 'ansible.builtin', 'ansible.legacy')
    cs.collections = ['ansible.builtin']
    assert cs.collections == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-25 05:12:22.139732
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # FIXME: assert type of _collections?
    cs.get_validated_value('collections', cs._collections, [], None)
    cs.get_validated_value('collections', cs._collections, ['ansible.posix'], None)
