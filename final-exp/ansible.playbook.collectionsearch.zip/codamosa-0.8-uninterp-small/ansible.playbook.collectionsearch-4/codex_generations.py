

# Generated at 2022-06-25 05:03:24.965337
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Normal Execution Path
    result = CollectionSearch()
    assert result
    print("TestCase for constructor of class CollectionSearch successful")


# Generated at 2022-06-25 05:03:27.820876
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert isinstance(obj, CollectionSearch)


# Generated at 2022-06-25 05:03:31.277457
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    if (collection_search_0._collections == None):
        print("Pass")
    else:
        print("Fail")

test_case_0()

# Generated at 2022-06-25 05:03:40.152768
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # should just return empty list for defaults
    for v in [None, []]:
        assert CollectionSearch()._load_collections('collections', v) == []

    assert CollectionSearch()._load_collections('collections', ['ansible.builtin']) == ['ansible.builtin']

    # ensure we get builtin added to a single collection
    assert CollectionSearch()._load_collections('collections', ['dummy']) == ['dummy', 'ansible.builtin']

    # ensure we get builtin added to a collection list
    assert CollectionSearch()._load_collections('collections', ['foo', 'bar']) == ['foo', 'bar', 'ansible.builtin']

    # ensure we get builtin added to a collection list and ensure order is preserved

# Generated at 2022-06-25 05:03:42.260423
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


if __name__ == "__main__":
    # Unit test for constructor of class CollectionSearch
    test_CollectionSearch()
    # Unit test for attribute _collections of class CollectionSearch
    test_case_0()

# Generated at 2022-06-25 05:03:43.133795
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()



# Generated at 2022-06-25 05:03:43.987515
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    res = CollectionSearch()
    assert res is not None

# Generated at 2022-06-25 05:03:45.338086
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = collection_search.CollectionSearch()


# Generated at 2022-06-25 05:03:50.532621
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections.priority == 100
    assert collection_search_0._collections.always_post_validate is True
    assert collection_search_0._collections.default == _ensure_default_collection


# Generated at 2022-06-25 05:03:51.295906
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:03:59.667082
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_obj = CollectionSearch()
    assert isinstance(collection_search_obj, CollectionSearch)

# Generated at 2022-06-25 05:04:02.552113
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:04:14.226361
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    # test for constructor by checking for class variables
    assert type(collection_search_0.__dict__['_collections']['_default']) == list
    assert str(collection_search_0.__dict__['_collections']['_always_post_validate']) == 'True'
    assert str(collection_search_0.__dict__['_collections']['_static']) == 'True'
    assert collection_search_0.__dict__['_collections']['_priority'] == 100
    assert type(collection_search_0.__dict__['_collections']['_isa']) == list
    assert type(collection_search_0.__dict__['_collections']['_listof']) == string_types

# Test for adding an

# Generated at 2022-06-25 05:04:16.791804
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    _load_collections = collection_search_0._load_collections
    
    # Test attribute 'collections'
    assert len(_ensure_default_collection()) == 1
    assert _load_collections('collections', None) is None

# Generated at 2022-06-25 05:04:22.068953
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == _ensure_default_collection()


# Generated at 2022-06-25 05:04:23.089524
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:04:26.688833
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0 is not None



# Generated at 2022-06-25 05:04:27.718119
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()



# Generated at 2022-06-25 05:04:29.014521
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:04:32.132535
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    try:
        assert collection_search_1._collections == None
    except:
        print("Test failed")
        assert False


# Generated at 2022-06-25 05:04:49.406614
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_test_0 = CollectionSearch()
    assert collection_search_test_0._collections == ['ansible.builtin', 'ansible.legacy']


# Generated at 2022-06-25 05:04:51.676447
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert getattr(test_case_0, '_collections')
    assert getattr(test_case_0, '_load_collections')


# Generated at 2022-06-25 05:04:54.376972
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search.get_validated_value()
    collection_search.post_validate()

# Generated at 2022-06-25 05:04:57.506949
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0.__dict__.get('_collections') == _ensure_default_collection()


# Generated at 2022-06-25 05:05:00.360610
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert isinstance(collection_search_0, CollectionSearch)

# Generated at 2022-06-25 05:05:03.557744
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1._static_attrs_to_unset == ['collections']

# Generated at 2022-06-25 05:05:08.519456
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

test_case_0()
test_CollectionSearch()

# Generated at 2022-06-25 05:05:16.088324
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    default_collection = AnsibleCollectionConfig.default_collection
    collection_search_1 = CollectionSearch()
    collection_search_1.set_loader(None)
    collection_search_1.post_validate(dict(), 'collections')
    collection_list = ['ansible_testing.bar', 'ansible_testing.foo']
    collection_list_1 = _ensure_default_collection(collection_list)
    assert (collection_list_1 == [default_collection, 'ansible_testing.bar', 'ansible_testing.foo'])
    collection_list = []
    collection_list_2 = _ensure_default_collection(collection_list)
    assert (collection_list_2 == [default_collection, 'ansible.builtin'])
    collection_list = None
    collection_list_3 = _ensure

# Generated at 2022-06-25 05:05:20.913936
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    if not collection_search_1._collections:
        collection_search_1._collections = _ensure_default_collection()
    assert type(collection_search_1._collections) is list


# Generated at 2022-06-25 05:05:22.780411
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1 is not None


# Generated at 2022-06-25 05:05:50.036910
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_loader_0 = CollectionSearch()


# Generated at 2022-06-25 05:05:53.417466
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_case_0()
    except Exception as e:
        print("Built-in Exception:", e)

# Generated at 2022-06-25 05:05:54.884253
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_case_0()
    except Exception:
        assert False



# Generated at 2022-06-25 05:05:56.712624
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = test_case_0()
    # call to method _load_collections
    assert not collection_search_0._load_collections()

# Generated at 2022-06-25 05:05:57.778589
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-25 05:06:01.955403
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.__str__() == '_collections'

# Generated at 2022-06-25 05:06:05.580511
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1._collections.default == ['ansible.builtin', 'ansible.legacy']


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:06:09.951203
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    result = CollectionSearch()
    print("\n Result of calling constructor of class CollectionSearch: ", result)
    assert(result is not None)
    assert(result._collections is not None)
    assert(result._collections == [])


# Generated at 2022-06-25 05:06:14.638371
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    msg = "*** Test Cases For CollectionSearch ***"
    print(msg)

    test_case_0()

    msg = "*** End Test Cases ***"
    print(msg)


# The following statement will call the test method
test_CollectionSearch()

# Generated at 2022-06-25 05:06:17.120210
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    # FIXME: This defaults to 'foo' in an empty playbook.
    #assert collection_search_0.get_validated_value('collections', collection_search_0._collections, None, None) == ['ansible.builtin']
    assert collection_search_0.get_validated_value('collections', collection_search_0._collections, None, None) == ['ansible.legacy']

# Generated at 2022-06-25 05:07:13.074647
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == [None]


# Generated at 2022-06-25 05:07:14.058198
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:07:14.832243
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert isinstance(collection_search_0,CollectionSearch)

# Generated at 2022-06-25 05:07:15.516353
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:07:17.622602
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()

# Generated at 2022-06-25 05:07:21.571742
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = ['ansible.builtin', 'ansible.legacy', 'ansible.posix']
    collection_list = collection_search_0._load_collections(collections)
    assert collections == collection_list


# Generated at 2022-06-25 05:07:25.924656
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Create an instance of class CollectionSearch
    collection_search_0 = CollectionSearch()

    # This attribute is set by default, no need to set any value
    assert collection_search_0._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:07:27.719545
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display.info('*Testing Constructor of Class CollectionSearch*')
    test_case_0()
    display.info('*Success*')



# Generated at 2022-06-25 05:07:30.235913
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_case_0()
    except Exception as exception:
        assert False, exception.args

# Generated at 2022-06-25 05:07:31.958942
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert not (CollectionSearch is None)


# Generated at 2022-06-25 05:08:44.418720
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        field = CollectionSearch()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True



# Generated at 2022-06-25 05:08:45.597745
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert cs._collections is not None

# Generated at 2022-06-25 05:08:48.171332
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = CollectionSearch()

    assert collections._collections.default == _ensure_default_collection

# Generated at 2022-06-25 05:08:52.922896
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class CollectionSearchTest(CollectionSearch):
        _collections = ['ansible.test.test_target', 'ansible.test.test_target2']

    test_obj = CollectionSearchTest(0)
    result = test_obj._load_collections(None, ['ansible.test.test_target', 'ansible.test.test_target2'])
    assert result == ['ansible.test.test_target', 'ansible.test.test_target2']

# Generated at 2022-06-25 05:08:58.163792
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test construct
    collection_search = CollectionSearch()
    # Test attribute: collections
    assert collection_search.collections == ['ansible.legacy', 'ansible_collections.sensu.sensu']

# Generated at 2022-06-25 05:09:01.163286
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search._collections)

### Unit tests for _ensure_default_collection(collection_list):

# Generated at 2022-06-25 05:09:03.569396
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task import Task

    class MyTask(Task, CollectionSearch):
        pass

    task = MyTask()
    assert task.collections is None

# Generated at 2022-06-25 05:09:06.604231
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Verify if the collections attribute is a list
    assert isinstance(cs._collections, list)
    # Verify if the collections attribute contains the default collection
    assert AnsibleCollectionConfig.default_collection in cs._collections[0]

# Generated at 2022-06-25 05:09:09.453353
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs
    assert 'ansible.builtin' in cs.collections or 'ansible.legacy' in cs.collections

# Generated at 2022-06-25 05:09:12.308308
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == _ensure_default_collection()
    assert CollectionSearch(collections=[])._collections == _ensure_default_collection()
    assert CollectionSearch(collections=['foo', 'bar'])._collections == ['foo', 'bar']

# Generated at 2022-06-25 05:11:55.230877
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Create a class to test the constructor of CollectionSearch
    class Test:
        pass

    test = Test()
    # Test the constructor of CollectionSearch
    CollectionSearch(test)

# Generated at 2022-06-25 05:11:58.556208
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-25 05:11:59.144111
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-25 05:12:02.456551
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj._load_collections(None, None)

# Generated at 2022-06-25 05:12:04.856165
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._collections is None


# Generated at 2022-06-25 05:12:07.129464
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(CollectionSearch, '_collections')
    assert callable(hasattr(CollectionSearch, '_load_collections'))

# Generated at 2022-06-25 05:12:14.596651
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # create a new CollectionSearch with default value of collections
    x = CollectionSearch()
    assert [x.collections] == _ensure_default_collection(), "CollectionSearch does not have the default value for collections."

    x = CollectionSearch(collections=[])
    assert [x.collections] == _ensure_default_collection(collection_list=[]), "CollectionSearch does not handle an empty collection list."

    x = CollectionSearch(collections=['some.collection', 'other.collection'])
    assert [x.collections] == _ensure_default_collection(collection_list=['some.collection', 'other.collection']), "CollectionSearch does not handle a non-empty collection list."

# Generated at 2022-06-25 05:12:18.093079
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert(not cs._collections.value)
    # Search for test task in default collection
    task_file = cs.find_file(filename='test-task.yml')
    assert(task_file)
    # Search for test task in test collection
    cs._collections.value = ['test']
    task_file = cs.find_file(filename='test-task.yml')
    assert(task_file)

# Generated at 2022-06-25 05:12:19.072086
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    assert collectionSearch._collections.default() == _ensure_default_collection()

# Generated at 2022-06-25 05:12:19.879925
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default() == ['ansible.builtin.core']