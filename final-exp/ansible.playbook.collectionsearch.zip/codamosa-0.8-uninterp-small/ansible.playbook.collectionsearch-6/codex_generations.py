

# Generated at 2022-06-25 05:03:25.860194
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()



# Generated at 2022-06-25 05:03:29.078952
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0.collecti

# Generated at 2022-06-25 05:03:30.615170
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch(
        collections=None
    )
    collection_search_1 = CollectionSearch(
        collections=None
    )
    collection_search_2 = CollectionSearch(
        collections=''
    )


# Generated at 2022-06-25 05:03:34.585434
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None


# Generated at 2022-06-25 05:03:35.796672
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert isinstance(collection_search_0, CollectionSearch)
    assert isinstance(collection_search_0._collections, FieldAttribute)



# Generated at 2022-06-25 05:03:40.320718
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Validate instance of CollectionSearch
    assert isinstance(collection_search_0, CollectionSearch)

#Unit test for method _load_collections

# Generated at 2022-06-25 05:03:42.334325
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert(collection_search_0.collections == _ensure_default_collection())

# Generated at 2022-06-25 05:03:43.400356
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == _ensure_default_collection()

# Generated at 2022-06-25 05:03:47.494063
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search = CollectionSearch()
    assert not collection_search._collections

    # Testing if 'collections' initialized correctly
    assert collection_search.collections is None

    # Testing if '_collections' assigned correctly
    collection_search._collections = ['ansible.foo']
    assert collection_search.collections == ['ansible.foo']

    # Testing if '_collections' assigned correctly
    collection_search._collections = ['ansible.foo', 'ansible.bar']
    assert collection_search.collections == ['ansible.foo', 'ansible.bar']



# Generated at 2022-06-25 05:03:52.035602
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None


# Generated at 2022-06-25 05:04:00.625823
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections is _ensure_default_collection


# Generated at 2022-06-25 05:04:01.176305
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:04:12.816799
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # test if class CollectionSearch has been instantiated
    assert collection_search._collections.name == 'collections'
    assert collection_search._collections.listof == string_types
    assert collection_search._collections.list_index == 0
    assert collection_search._collections.static == True
    assert collection_search._collections.priority == 100
    assert collection_search._collections.aliases == []
    assert collection_search._collections.always_post_validate == True
    assert collection_search._collections.always_post_coerce == False
    assert collection_search._collections.attrtype == 'collection'

# Generated at 2022-06-25 05:04:17.382328
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search_1 = CollectionSearch()
    except SystemExit:
        pass
    else:
        raise AssertionError("Raise SystemExit")



# Generated at 2022-06-25 05:04:20.037194
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_list = ["ansible.builtin"]
    collection_search_1 = CollectionSearch(collection_list)
    assert collection_search_1._collections == collection_list

# test for _ensure_default_collection()

# Generated at 2022-06-25 05:04:25.348423
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert not hasattr(collection_search_1, '_collections')
    assert not hasattr(collection_search_1, '_static_fields')
    assert not hasattr(collection_search_1, '_attribute_fields')
    assert not hasattr(collection_search_1, '_data')
    assert not hasattr(collection_search_1, '_mixed_class')
    assert not hasattr(collection_search_1, '_always_post_validate')


# Generated at 2022-06-25 05:04:34.275867
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # create an empty CollectionSearch() object
    collection_search_1 = CollectionSearch()

    # create a full CollectionSearch() object
    collection_search_2 = CollectionSearch()
    collection_search_2._collections = ['ansible.builtin', 'ansible.legacy', 'ansible.builtin']
    collection_search_2._collections = ['ansible.builtin', 'ansible.legacy', 'ansible.builtin']

    assert(collection_search_1.collections == ['ansible.legacy'])
    assert(collection_search_2.collections == ['ansible.builtin', 'ansible.legacy'])


# Generated at 2022-06-25 05:04:38.540980
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    global collection_search_0
    collection_search_0 = CollectionSearch()
    if isinstance(collection_search_0._collections, string_types):
        display.warning("CollectionSearch._collections._value = %s, and isinstance(CollectionSearch._collections._value, string_types) = %s" %
                        (collection_search_0._collections, isinstance(collection_search_0._collections, string_types)))


# Generated at 2022-06-25 05:04:40.249540
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == 'ansible.builtin,ansible.legacy'


# Generated at 2022-06-25 05:04:41.656737
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

    assert collection_search._collections == _ensure_default_collection()


# Generated at 2022-06-25 05:04:57.410238
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None

# Generated at 2022-06-25 05:05:01.380912
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert collection_search._load_collections(None, None) is None

# Generated at 2022-06-25 05:05:04.221004
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.__doc__ == """
This needs to be populated before we can resolve tasks/roles/etc
    """, "Unit test for constructor of class CollectionSearch failed"



# Generated at 2022-06-25 05:05:05.094948
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search


# Generated at 2022-06-25 05:05:06.798365
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = 'collections'
    collection_search = CollectionSearch(collections=collections)
    assert collection_search.collections == collections

# Generated at 2022-06-25 05:05:07.813115
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()
    # TODO: add other cases here
    # assert something

# Generated at 2022-06-25 05:05:10.031098
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # This returns a function.
    assert callable(collection_search._load_collections)



# Generated at 2022-06-25 05:05:15.402828
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    if test_case_0():
        print("Unit test for constructor of class CollectionSearch: PASSED")
    else:
        print("Unit test for constructor of class CollectionSearch: FAILED")


# Generated at 2022-06-25 05:05:19.150403
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test for the default value of 'collections'
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == _ensure_default_collection(collection_list=None)

# Generated at 2022-06-25 05:05:22.191062
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Check for created object
    assert collection_search_0 is not None
    # Check for type of object
    assert isinstance(collection_search_0, CollectionSearch)

# Generated at 2022-06-25 05:05:42.832473
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c_loaded_data = {}
    c_validated_data = {}
    collection_search = CollectionSearch(c_loaded_data, c_validated_data)

    assert collection_search._validated_data == {}
    assert collection_search._loaded_data == {}
    assert collection_search._collections.static
    assert collection_search._collections.always_post_validate

# Generated at 2022-06-25 05:05:44.020515
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-25 05:05:45.223027
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert cs.collections == _ensure_default_collection()

# Generated at 2022-06-25 05:05:54.727001
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    # Check when collections are not set
    assert None == instance._load_collections(attr='collections', ds={})
    # Check when collections is set to a list
    assert ['ansible.builtin'] == instance._load_collections(attr='collections', ds={'collections': ['ansible.builtin']})
    # Check when collections is set to a non-list
    assert ['ansible.builtin'] == instance._load_collections(attr='collections', ds={'collections': 'ansible.builtin'})

# Generated at 2022-06-25 05:06:01.188594
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.template import is_template, Environment
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.module_utils.six import string_types

    base = Base()
    assert base._collections is None

    # Check the case when "collections" is not specified
    base.post_validate()

    display = Display()
    assert display.warning.call_count == 0
    assert base._collections == _ensure_default_collection()

    # Check the case where "collections" is empty
    base._collections = []
    base.post_validate()
    assert display.warning.call_count == 0


# Generated at 2022-06-25 05:06:04.731103
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()
    c = CollectionSearch(collections=['test_col'])
    assert c._collections == ['test_col']

# Generated at 2022-06-25 05:06:13.572533
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest.mock as mock
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    import ansible.playbook.block as block
    import ansible.playbook.task as task
    import ansible.playbook.role as role
    import ansible.playbook.handler as handler
    import ansible.playbook.task_include as task_include

    display = Display()
    display.verbosity = 0

    class MockBase(Base):
        def __init__(self, *args, **kwargs):
            super(MockBase, self).__init__(*args, **kwargs)
            self._ds = dict()

        def get_ds(self):
            return self._ds

        def set_ds_value(self, name, value):
            self._ds

# Generated at 2022-06-25 05:06:22.105948
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        def __init__(self, col_list=None):
            self._collections = col_list

    assert TestCollectionSearch()._collections == _ensure_default_collection(None)
    assert TestCollectionSearch(None)._collections == _ensure_default_collection(None)
    assert TestCollectionSearch(['ansible.builtin'])._collections == ['ansible.builtin', 'ansible.legacy']
    assert TestCollectionSearch(['not.a.collection'])._collections == ['not.a.collection', 'ansible.legacy']
    assert TestCollectionSearch(['ansible.builtin', 'not.a.collection'])._collections == ['ansible.builtin', 'not.a.collection', 'ansible.legacy']

# Generated at 2022-06-25 05:06:24.938963
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c_search = CollectionSearch()
    print('Collections: %s' % c_search._collections)
    print('Collections: %s' % c_search.collections)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:06:27.593992
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert(collection._collections == _ensure_default_collection(None))
    assert(collection._collections == [AnsibleCollectionConfig.default_collection, 'ansible.legacy'])


# Generated at 2022-06-25 05:07:00.791535
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)
'''
    test_CollectionSearch = CollectionSearch()

    #test_CollectionSearch.collections = "hi"

    #test_CollectionSearch.collections = ["hi"]

    #test_CollectionSearch.collections = ["hi", "hello"]

    tasks = test_CollectionSearch.get_tasks()

    roles = test_CollectionSearch.get_roles()

    modules = test_CollectionSearch.get_modules()
'''

# Generated at 2022-06-25 05:07:03.980043
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()
    result = test_object._collections
    assert result.__class__.__name__ == "FieldAttribute"
    assert result.contained == 'list'

# Generated at 2022-06-25 05:07:09.980401
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.name == 'collections'
    assert CollectionSearch._collections.serialize == False
    assert CollectionSearch._collections.always_post_validate == True
    assert CollectionSearch._collections.static == True
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.default == None
    assert CollectionSearch._collections.isa == 'list'
    assert CollectionSearch._collections.listof == string_types



# Generated at 2022-06-25 05:07:11.476958
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collection == "ansible.builtin"
    pass

# Generated at 2022-06-25 05:07:13.557457
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(obj._collections)
    print(obj._load_collections(None, obj._collections))

# Generated at 2022-06-25 05:07:14.034642
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass
# except:
#     pass

# Generated at 2022-06-25 05:07:16.544644
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    result = cs._load_collections('attr', ['test'])
    assert result == ['test', 'ansible.builtin']
    result = cs._load_collections('attr', [])
    assert result == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:07:17.805890
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.__dict__['_is_static']

# Generated at 2022-06-25 05:07:28.524541
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test with empty constructor
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

    # test with valid string
    cs = CollectionSearch(collections="my.namespace")
    assert cs._collections == _ensure_default_collection(["my.namespace"])

    # test with invalid string
    cs = CollectionSearch(collections=1)
    assert cs._collections == _ensure_default_collection()

    # test with valid list
    cs = CollectionSearch(collections=["my.namespace"])
    assert cs._collections == _ensure_default_collection(["my.namespace"])

    # test with invalid list
    cs = CollectionSearch(collections=[1])
    assert cs._collections == _ensure_default_collection(["1"])

    # test

# Generated at 2022-06-25 05:07:31.821150
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.name == 'collections'
    assert collection_search._collections.isa == 'list'
    assert collection_search._collections.listof == string_types
    assert collection_search._collections.priority == 100
    assert collection_search._collections.default == _ensure_default_collection
    assert collection_search._collections.always_post_validate == True
    assert collection_search._collections.static == True

# Generated at 2022-06-25 05:08:45.352084
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections._parent is cs

# Generated at 2022-06-25 05:08:47.513750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = dict()

    cs = CollectionSearch()

    # Test the _collections field attribute
    attr = cs._collections.get_value(ds=ds)
    cs._load_collections('collections', ds)

# Generated at 2022-06-25 05:08:48.632900
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-25 05:08:53.750918
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Instantiate class CollectionSearch (used by AnsibleCollectionConfig)
    x = CollectionSearch()
    # Call _load_collections with arg1 as 'collections', an empty dict, and arg3 as None
    default_collection_list = x._load_collections('collections', {})
    assert default_collection_list == [''], 'Default collection list is wrong'

# Generated at 2022-06-25 05:09:00.632768
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.static == True
    assert cs._collections.default == _ensure_default_collection()
    assert cs._collections.priority == 100
    assert isinstance(cs._collections.listof, type)
    assert cs._collections.listof == string_types
    assert cs._collections.always_post_validate == True

# Generated at 2022-06-25 05:09:08.762371
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test the default case: default_collection is 'ansible_collections.nsbl.roles', collection_list is None
    _ensure_default_collection(None)
    # Test the case: collection_list is not None and default_collection is 'ansible_collections.nsbl.roles', but collection_list already has 'ansible_collections.nsbl.roles'
    collection_list = ['ansible_collections.nsbl.roles']
    _ensure_default_collection(collection_list)
    # Test the case: collection_list is not None and default_collection is 'ansible_collections.nsbl.roles', but collection_list has no 'ansible_collections.nsbl.roles'
    collection_list = ['ansible_collections.nsbl.roles2']
    _ensure

# Generated at 2022-06-25 05:09:18.994245
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play import Play
    from ansible.playbook.become import Become
    from ansible.playbook.become_method import BecomeMethod
    from ansible.playbook.connection.network_cli import ConnectionNetworkCLI
    from ansible.playbook.hosts.group import Group
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.role.include import RoleInclude


# Generated at 2022-06-25 05:09:28.046277
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    from ansible.playbook import Base
    from ansible.module_utils._text import to_text

    ds = AnsibleCollectionConfig.default_collection

    # This should not fail, and should not return an empty yaml.
    # We are doing
    #   Base -> CollectionSearch -> Base -> Base
    t = Base.load(dict(collections=[ds]), variable_manager=None, loader=None)

    # If you're expecting a value, it should be a list
    assert isinstance(t.collections, list)

    # Do not expect an empty list
    assert len(t.collections) > 0

    # The first element should be the default collection
    assert t.collections[0] == ds

    # If you're not expecting a value, it should be None

# Generated at 2022-06-25 05:09:29.206139
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Object creation is necessary for testing module functionality
    test = CollectionSearch()
    test.set_value('collections', ['ansible.builtin', 'ansible.posix'])

# Generated at 2022-06-25 05:09:31.076646
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import RoleInclude
    ri = RoleInclude() 
    assert ri.collections is None

# Generated at 2022-06-25 05:12:16.176995
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    parent_obj = object()
    collection_search = CollectionSearch(parent_obj)
    assert collection_search._collections == _ensure_default_collection()
    assert collection_search.ds == {}
    assert collection_search.parent == parent_obj

# Generated at 2022-06-25 05:12:24.563687
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.plugins.loader import find_collection_role_path
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    collections = [
        './test/collections/ansible_collections/testns/testcoll/',
        './test/test_template_plugin/testcollections/testns/testcoll/'
    ]

    for collection in collections:
        coll_role_path = find_collection_role_path(collection)
        assert coll_role_path, 'find_collection_role_path returned None for collection path %s' % collection

        col_search = CollectionSearch(loader, VariableManager(), col_list=[coll_role_path])

        assert col_search._collections == _ensure_default_collection

# Generated at 2022-06-25 05:12:27.824100
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Arrange
    c_search = CollectionSearch()

    # Act
    c_search._load_collections(None, None)

# Generated at 2022-06-25 05:12:29.297649
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    x = CollectionSearch()
    assert x._collections['default'] == _ensure_default_collection()

# Generated at 2022-06-25 05:12:31.041021
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible_collections.notstdlib.moveit.plugins']

# Generated at 2022-06-25 05:12:33.298693
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    obj = CollectionSearch()
    obj.post_validate()
    assert obj._collections
    assert obj._collections == [AnsibleCollectionConfig.default_collection, 'ansible.legacy']

# Generated at 2022-06-25 05:12:34.917033
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection = CollectionSearch()

    if(type(collection) is CollectionSearch):
        print('test_CollectionSearch passed')
    else:
        print('test_CollectionSearch failed')

# Generated at 2022-06-25 05:12:36.227939
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Unit test for constructor of class CollectionSearch
    # The result should be a valid instance of class CollectionSearch
    collection_search = CollectionSearch()

# Generated at 2022-06-25 05:12:39.079321
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class collection_search(CollectionSearch):
        def __init__(self):
            self.collections = ['fake_collection']

    cs = collection_search()
    if len(cs.collections) != len(['fake_collection']):
        raise AssertionError()
    # We should always have ansible.builtin or ansible.legacy,
    # so if len() is 2, that means we passed
    if len(cs.collections) != 2:
        raise AssertionError()

# Generated at 2022-06-25 05:12:41.733189
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    # build a data structure which will be passed to load_collections
    ds = {'collections': []}
    print(ds)
    obj._load_collections('collections', ds)
    print(ds)


# test code
if __name__ == '__main__':
    test_CollectionSearch()