

# Generated at 2022-06-25 05:03:34.480511
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("\nTesting constructor")
    expected_collections = None
    collection_search = CollectionSearch()
    assert collection_search._collections == expected_collections

    print("\nTesting _load_collections")
    # Case - 1: No datasource
    expected_collections = None
    ds = None
    collection_search = CollectionSearch()
    assert collection_search._load_collections(None, ds) == expected_collections

    # Case - 2: datasource is not a list
    ds = "ansible.builtin"
    expected_collections = None
    collection_search = CollectionSearch()
    assert collection_search._load_collections(None, ds) == expected_collections

    # Case - 3: datasource is a list
    ds = ["ansible.builtin"]
    expected_

# Generated at 2022-06-25 05:03:38.907609
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # check attribute values in constructor
    assert isinstance(CollectionSearch._collections, FieldAttribute)
    assert CollectionSearch._collections.name == 'collections'
    assert CollectionSearch._collections.isa == 'list'
    assert CollectionSearch._collections.listof == string_types
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.default == _ensure_default_collection
    assert CollectionSearch._collections.always_post_validate is True
    assert CollectionSearch._collections.static is True


# Generated at 2022-06-25 05:03:39.932640
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(collection_search_0, CollectionSearch)

# Generated at 2022-06-25 05:03:41.319923
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch
    assert CollectionSearch.__name__ == "CollectionSearch"
    assert CollectionSearch.__module__ == __name__



# Generated at 2022-06-25 05:03:45.337468
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert isinstance(collection_search_1.collections, list)
    assert 'ansible.builtin' in collection_search_1.collections
    assert 'ansible.legacy' in collection_search_1.collections
    assert AnsibleCollectionConfig.default_collection in collection_search_1.collections

# Generated at 2022-06-25 05:03:47.168750
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)
    assert isinstance(collection_search._collections, FieldAttribute)

# Generated at 2022-06-25 05:03:48.240205
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert hasattr(test_case_0, "collections")

# Generated at 2022-06-25 05:03:52.368786
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Instantiate an instance of the CollectionSearch class
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:03:53.100799
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  collection_search_0 = CollectionSearch()

# Generated at 2022-06-25 05:03:58.271223
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # repr(string) should not show u'..' when running on Python 2. For
    # details see: https://docs.python.org/3/whatsnew/3.0.html#text-vs-data-instead-of-unicode-vs-8-bit
    assert repr('..') == str(repr('..'))
    # Instance of class CollectionSearch has to be created
    collection_search_1 = CollectionSearch()
    assert collection_search_1._collections == ['ansible.builtin', 'ansible.legacy']
    # Instance of class CollectionSearch has to be created
    collection_search_2 = CollectionSearch()
    assert collection_search_2._collections == ['ansible.builtin', 'ansible.legacy']
    # _collections: isa='list', listof=string_types,

# Generated at 2022-06-25 05:04:07.169990
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.post_validate() is None  # should not raise error

    # following 2 assertions should not raise any error
    assert cs.post_validate({'collections': []}) is None
    assert cs.post_validate({'collections': [{'foo': 'bar'}]}) is None



# Generated at 2022-06-25 05:04:14.177541
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import json

    # Create a data structure containing the collection name to be searched
    ds = "ansible_collections.cloud.some_collection"

    # Create an instance of class CollectionSearch
    collection_search = CollectionSearch()

    # Load the collection search in the data structure
    loaded_collections = collection_search._load_collections("collections", ds)

    # The fields of the _collections should match with the loaded collection
    assert loaded_collections == (ds,)

# Generated at 2022-06-25 05:04:15.922984
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections = ['ansible.posix']
    ds = [collections]
    test = CollectionSearch()
    res = test._load_collections(collections, ds)
    assert res == ds

# Generated at 2022-06-25 05:04:18.390235
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections._default() == ['ansible_collections.oneview.ov.tests.ansible_collections']

# Generated at 2022-06-25 05:04:21.540371
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    obj._load_collections(None, [])

# Generated at 2022-06-25 05:04:32.689768
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test that the search_path is built correctly.
    #  1. when there are no collections defined
    #  2. when there is a default and no collection
    #  3. when there is a default and a collection
    #  4. when there is no default and a collection
    #  5. when there is no default and multiple collections

    display.verbosity = 1
    display.deprecate_warnings = False

    # 1
    a = CollectionSearch()
    assert a._collections == _ensure_default_collection()

    # 2
    AnsibleCollectionConfig.default_collection = 'ansible.builtin'
    b = CollectionSearch()
    assert b._collections == _ensure_default_collection()
    AnsibleCollectionConfig.default_collection = None  # reset for future tests

    # 3
    c = Collection

# Generated at 2022-06-25 05:04:37.337052
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    expects = 'ansible.builtin'
    actuals = CollectionSearch.default_collection
    assert expects == actuals

    expects = 'ansible.legacy'
    actuals = CollectionSearch.default_collection
    assert expects == actuals

#Unit test for _ensure_default_collection of class CollectionSearch

# Generated at 2022-06-25 05:04:43.613262
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.base import Base
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.module_utils._text import to_text

    collection_name = 'test_collection'
    collection_path = '/var/ansible/collections/ansible_namespace/collection_name'
    collection_config = AnsibleCollectionConfig('test_collection')
    collection_config.prefix = 'ansible_namespace.collection_name'
    collection_config.path = collection_path
    AnsibleCollectionConfig.collection_dirs[collection_path] = collection_config
    AnsibleCollectionConfig.collections[collection_name] = collection_config

    base = Base()
    base.collections = ['test_collection']
    base._ensure_collections_loaded()
    base._validate_col

# Generated at 2022-06-25 05:04:51.522958
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(CollectionSearch):
        # this needs to be populated before we can resolve tasks/roles/etc
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)
    test_obj = TestCollectionSearch()
    assert test_obj._collections == ['ansible/base', 'ansible/base']



# Generated at 2022-06-25 05:04:53.340567
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == 'ansible.builtin,ansible.legacy'

# Generated at 2022-06-25 05:05:03.040861
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with pytest.raises(TypeError):
        CollectionSearch()



# Generated at 2022-06-25 05:05:11.555970
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import unittest
    from ansible.errors import AnsibleError

    class TestCollectionSearch(unittest.TestCase):
        def setUp(self):
            self.collections = CollectionSearch()

        def test_collection_search(self):
            given = {'collections': [
                'my.collection',
                'my.other.collection',
                'my.third.collection',
            ]}

            self.collections.set_attributes_from_dict(given)
            self.assertEqual(self.collections.collections, given['collections'])

        def test_no_collection_search(self):
            self.collections.set_attributes_from_dict({})
            self.assertEqual(self.collections.collections, None)

            self.collections.set_attributes_from

# Generated at 2022-06-25 05:05:14.681500
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == ['ansible_collections.nsweb.files']

# Generated at 2022-06-25 05:05:15.809940
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()
    print(collectionSearch._collections)

# Generated at 2022-06-25 05:05:24.306256
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch._load_collections(None, None) is None

    result = test_CollectionSearch._load_collections(None, None)
    result = _ensure_default_collection(result)
    assert result == ['ansible.builtin', 'ansible.legacy']

    result = test_CollectionSearch._load_collections(None, None)
    result = _ensure_default_collection(result)
    assert result == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:05:27.150333
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()

    assert(a._load_collections([],None) == None)
    assert(a._load_collections('test',None) == None)

# Generated at 2022-06-25 05:05:34.301859
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    class MockDataContainer:
        def __init__(self, attr, ds):
            self.attr = attr
            self.ds = ds

    # Case 1: ds = ['foo']
    mock_data_container = MockDataContainer('_collections', 'foo')

    ds = cs._load_collections('_collections', mock_data_container.ds)
    assert ds == _ensure_default_collection(mock_data_container.ds)

# Generated at 2022-06-25 05:05:42.208511
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_search = CollectionSearch()
    test_collection_search._collections = [
        'ansible.builtin',
        'ansible.legacy',
        'my.collection',
    ]
    assert test_collection_search._load_collections('collections', 'my.collection') == [
        'my.collection',
        'ansible.builtin',
        'ansible.legacy',
    ]

# Generated at 2022-06-25 05:05:43.242359
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role.include import RoleInclude
    cs = CollectionSearch()
    assert isinstance(cs,RoleInclude)

# Generated at 2022-06-25 05:05:44.264076
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.default() == _ensure_default_collection
    assert cs.collections is None

# Generated at 2022-06-25 05:05:59.146416
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    assert search._load_collections(None, None) == ['ansible.builtin',
            'ansible.legacy',
            'ansible_collections.notmintest.not_a_real_collection']

# Generated at 2022-06-25 05:06:02.751859
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    testCollectionSearch = CollectionSearch()
    testCollectionSearch._collections = ['test_collection']
    assert testCollectionSearch.post_validate() is None

# Generated at 2022-06-25 05:06:12.584399
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test.collections == _ensure_default_collection()
    assert isinstance(test.collections, list)
    assert 'ansible.builtin' in test.collections
    assert 'ansible.legacy' in test.collections
    assert 'ansible.netcommon' in test.collections
    test.collections = ['collections.test_collection']
    assert test.collections == ['collections.test_collection']
    test.collections = ['collections.test_collection', 'test_collection2']
    assert test.collections == ['collections.test_collection', 'test_collection2']


# Generated at 2022-06-25 05:06:16.440504
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections
    assert c._collections is not None
    #assert c._load_collections(None, None)

# Generated at 2022-06-25 05:06:17.539991
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Python 2.7 return is list
    # Python 3.8 return is None
    cs._collections
    cs._load_collections(None, None)

# Generated at 2022-06-25 05:06:18.390172
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections
    assert cs._load_collections('collections', None)

# Generated at 2022-06-25 05:06:19.014582
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    print(collection)

# Generated at 2022-06-25 05:06:21.749562
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    tc = CollectionSearch()
    assert tc._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:06:23.377666
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch_obj = CollectionSearch()
    assert collectionsearch_obj._collections == [], "Collections list must be empty"

# Generated at 2022-06-25 05:06:25.481145
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible_collections.test.test_utils.test_runner import CollectionSearch
    collection_search = CollectionSearch()
    assert collection_search is not None


# Generated at 2022-06-25 05:06:55.721773
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # check the same result with
    # ansible-playbook --version | grep -Eo "collections: ([^)]+)" | cut -d : -f 2 |  sed -e 's/^[[:space:]]*//'
    collections = CollectionSearch().collections
    print(collections)


if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:06:59.811972
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is collection_search._load_collections(None, None)

# Generated at 2022-06-25 05:07:05.467933
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    # _collections should be a list
    assert isinstance(collection_search._collections, list), '_collections is not a list'
    # _collections should not be empty
    assert len(collection_search._collections) > 0, '_collections is empty'

# Generated at 2022-06-25 05:07:09.977042
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import os.path
    c = CollectionSearch()
    # Check the default path
    defaultpath_collection = c._collections
    assert defaultpath_collection==[_ensure_default_collection()]
    # Check the resulting path
    resultpath_collection = c._load_collections('collections', None)
    assert resultpath_collection!=None
    assert resultpath_collection==[_ensure_default_collection()]

# Generated at 2022-06-25 05:07:16.831305
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("Test case 1: Normal case")
    search = CollectionSearch()
    print(search._collections)
    test_var = search._collections
    assert isinstance(test_var, list)
    assert isinstance(test_var[0], str)
    assert test_var[0] == "ansible.builtin"
    print("Test case 1: passed")


# Generated at 2022-06-25 05:07:18.781097
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert obj._collections.default == _ensure_default_collection(collection_list=None)

# Generated at 2022-06-25 05:07:27.084061
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test __init__ without default
    obj = CollectionSearch()
    assert obj._collections == _ensure_default_collection(collection_list=None)

    # test __init__ with default
    obj = CollectionSearch(collections=['test1', 'test2'])
    assert obj._collections == _ensure_default_collection(collection_list=['test1', 'test2'])

    # test specific case for _ensure_default_collection
    obj = CollectionSearch(collections=['test1'])
    assert obj._collections == ['test1', 'ansible.builtin']

    # test post_validate
    obj = CollectionSearch(collections=['test1'])
    obj.post_validate(None)
    assert obj._collections == ['test1', 'ansible.builtin']

    # test

# Generated at 2022-06-25 05:07:28.211446
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Call constructor of class CollectionSearch
    CollectionSearch()

# Generated at 2022-06-25 05:07:33.031570
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_instance = CollectionSearch()
    print(test_instance)
    print(type(test_instance))
    print(test_instance.__doc__)
    c = test_instance._load_collections("test", list())
    print(c, type(c))

# Generated at 2022-06-25 05:07:44.120551
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import copy
    import sys

    sys.path.append('../')
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.taggable import Taggeable
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.action import Action
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-25 05:08:54.571451
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == _ensure_default_collection()

# Generated at 2022-06-25 05:08:57.665648
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    search._collections = ['mytestcollection']
    search._load_collections('collections', ['mytestcollection'])

# Generated at 2022-06-25 05:09:01.307031
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs._collections = None
    cs.collections = ["col.wip.yamllint"]
    print(cs.collections)

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-25 05:09:01.933345
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    pass

# Generated at 2022-06-25 05:09:09.395358
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    def testMethod(a, b, c=2):
        print(a + b + c)

    tm = testMethod

    tm.foo = "some value"   #this adds attribute foo only to tm -- it doesn't exist in testMethod
    testMethod.bar = "other value" #this adds attribute bar to both testMethod and tm

    tm.__name__ = "another name" #this changes the name of the method

    print(tm.__name__) #another name
    print(tm.foo) #some value
    print(tm.bar) #other value

    testMethod(1, 2) # prints 5
    tm(1, 2) # prints 6!

# test_CollectionSearch()

# Generated at 2022-06-25 05:09:10.345084
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collections_search = CollectionSearch()
    assert collections_search._load_collections(FieldAttribute(), []) == None

# Generated at 2022-06-25 05:09:12.308032
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    b = CollectionSearch()
    if b._collections == _ensure_default_collection():
        print("Search for default collection")
    else:
        print("No default collection found")

# Generated at 2022-06-25 05:09:14.913608
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    _collections = CollectionSearch()._collections
    assert len(_collections) == 1

# Generated at 2022-06-25 05:09:16.879246
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections._static

    assert collection_search._collections._validate_data(None) == [], "Collection_list should be empty"
    assert collection_search._collections._validate_data(['collection_name']) == ['collection_name'], "Collection_list should not be empty"

# Generated at 2022-06-25 05:09:18.257394
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections is None

# Generated at 2022-06-25 05:11:51.388507
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

# Generated at 2022-06-25 05:11:55.304074
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test for successful constructor for CollectionSearch class.
    test_instance = CollectionSearch(dict(collections=['ansible.builtin']))
    assert test_instance._collections is None

# Generated at 2022-06-25 05:11:59.133536
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """AnsibleCollectionLoader - an object of class CollectionSearch is created with collection_list"""
    def _ensure_default_collection(collection_list, expected):
        assert _ensure_default_collection(collection_list) == expected

    _ensure_default_collection(collection_list=['namespace.collection'], expected=['namespace.collection', 'ansible.builtin'])
    _ensure_default_collection(collection_list=[], expected=['ansible.builtin'])
    _ensure_default_collection(collection_list=None, expected=['ansible.builtin'])

test_CollectionSearch()

# Generated at 2022-06-25 05:12:08.190225
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    collection_search = cs._collections
    assert isinstance(collection_search, FieldAttribute)
    assert collection_search.isa == 'list'
    assert collection_search.listof == string_types
    assert collection_search.priority == 100
    assert collection_search.default == _ensure_default_collection
    assert collection_search.always_post_validate is True
    assert collection_search.static is True
    assert collection_search.private is False
    assert collection_search.no_log is False
    assert collection_search.omit is False
    assert collection_search.vars is False
    assert collection_search.elements is None
    assert collection_search.ignore_errors is None
    assert collection_search.required_one_of is None
    assert collection_search.required_together is None


# Generated at 2022-06-25 05:12:10.358768
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    ds = 'some collection'
    col_search = CollectionSearch()
    col_search._collections = None
    assert col_search._load_collections(None, ds) == _ensure_default_collection(collection_list=ds)

# Generated at 2022-06-25 05:12:16.870981
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    print(dir(obj))
    print(obj.__dict__)
    print(obj._collections)
    print(obj._load_collections(obj._collections, "ansible.builtin,ansible.legacy"))
    print(obj._load_collections(obj._collections, "ansible.builtin"))

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-25 05:12:21.708691
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_class = CollectionSearch()
    assert test_class.collections() == ['ansible.builtin']
    assert test_class.collections(collection_list=['test_collection']) == ['test_collection', 'ansible.builtin']

# Generated at 2022-06-25 05:12:25.692218
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    This function is to unit test constructor for class CollectionSearch.
    """
    collection_search = CollectionSearch()
    assert collection_search.collections == ['ansible.builtin']
    print("Test passed")

# Generated at 2022-06-25 05:12:28.910295
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default() == _ensure_default_collection()
    assert CollectionSearch()._collections.default() == _ensure_default_collection()

# Generated at 2022-06-25 05:12:32.817744
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.plugins import get_all_plugin_loaders, plugin_loader_class
    loader = get_all_plugin_loaders()[plugin_loader_class]
    cs = CollectionSearch(parent_object=loader)
    assert cs.collections != []
    assert 'ansible.builtin' in cs.collections or 'ansible.legacy' in cs.collections