

# Generated at 2022-06-25 05:03:27.894148
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    instance = CollectionSearch()
    assert hasattr(instance, "collections")
    assert hasattr(instance, "_collections")

# Generated at 2022-06-25 05:03:30.996856
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # test_case_0
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == [AnsibleCollectionConfig.default_collection]

# Generated at 2022-06-25 05:03:38.495014
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert '_collections' in collection_search_1.__dict__.keys()
    assert '_load_collections' in collection_search_1.__dict__.keys()
    assert 'get_validated_value' in collection_search_1.__dict__.keys()
    assert isinstance(collection_search_1._collections, FieldAttribute)
    assert isinstance(collection_search_1._load_collections, collections.Callable)
    assert isinstance(collection_search_1.get_validated_value, collections.Callable)

# Generated at 2022-06-25 05:03:39.884110
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:03:44.311021
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # assert construction of class CollectionSearch is successful with no arguments
    collection_search_0 = CollectionSearch()
    assert (type(collection_search_0) == CollectionSearch)

    # assert construction of class CollectionSearch is successful with correct
    # arguments
    collection_search_0 = CollectionSearch(collections={})
    assert (type(collection_search_0) == CollectionSearch)

# Generated at 2022-06-25 05:03:45.338087
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert not hasattr(CollectionSearch, '_collections')

# Generated at 2022-06-25 05:03:49.354746
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search_func = CollectionSearch()
    assert collection_search == collection_search_func, "constructor of class CollectionSearch returns different objects"


# Generated at 2022-06-25 05:03:54.380935
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0=CollectionSearch()
    assert collection_search_0 is not None, "Failed to instantiate CollectionSearch"
    assert collection_search_0._collections == ['ansible.builtin', 'ansible.legacy'], \
                    "Collection_search list not getting populated"

# Generated at 2022-06-25 05:03:58.505183
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == 'ansible.builtin'  # test for static attribute


# Generated at 2022-06-25 05:04:03.678702
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Testing __init__() of CollectionSearch
    # No value passed
    collection_search = CollectionSearch()
    assert collection_search._collections == collection_search.default_values['_collections']

    # Value passed
    collection_search = CollectionSearch(collections=['ansible.builtin'])
    assert collection_search._collections == ['ansible.builtin']

# Generated at 2022-06-25 05:04:11.174877
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Default case
    collection_search_0 = CollectionSearch()

    # Without default
    collection_search_1 = CollectionSearch(collections=[])

    # With default
    collection_search_2 = CollectionSearch(collections=['ansible.builtin', 'ansible.legacy'])

# Generated at 2022-06-25 05:04:14.130629
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    collection_search_0._load_collections(attr='collections', ds=['ansible.builtin'])

    collection_search_1 = CollectionSearch()
    collection_search_1._load_collections(attr='collections', ds=['ansible.builtin'])

# Generated at 2022-06-25 05:04:14.778755
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch


# Generated at 2022-06-25 05:04:15.600955
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch()._collections, FieldAttribute)


# Generated at 2022-06-25 05:04:16.894490
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()

    assert collection_search_1._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:04:21.724796
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1._collections is not None


# Generated at 2022-06-25 05:04:25.918257
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_case_0()
    except:
        assert False, "Failed to create CollectionSearch"

if __name__ == "__main__":
    test_CollectionSearch()

# Generated at 2022-06-25 05:04:27.367335
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:04:29.057233
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 05:04:31.839880
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections.value == ['ansible_collections.foobar.baz']

# Generated at 2022-06-25 05:04:36.270416
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:04:43.171299
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    # Test when no collection specified
    _collections = CollectionSearch._collections.post_validate({})
    assert _collections == _ensure_default_collection()

    # Test when collections is specified
    _collections = CollectionSearch._collections.post_validate({'collections': ['one', 'two', 'three']})
    assert _collections == ['one', 'two', 'three'] + _ensure_default_collection(['one', 'two', 'three'])

# Generated at 2022-06-25 05:04:47.795064
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()

    cs = CollectionSearch(collections=['test.collection'])
    assert cs.collections == _ensure_default_collection(['test.collection'])

# Generated at 2022-06-25 05:04:53.454930
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_CollectionSearch = CollectionSearch()
    assert test_CollectionSearch._collections
    assert not test_CollectionSearch._collections.default

    test_CollectionSearch = CollectionSearch(collections=True)
    assert test_CollectionSearch._collections
    assert test_CollectionSearch._collections.default

    test_CollectionSearch = CollectionSearch(collections=[])
    assert test_CollectionSearch._collections
    assert test_CollectionSearch._collections.default

# Generated at 2022-06-25 05:05:02.309354
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # _collections = ['ansible.legacy', 'ansible.builtin', 'ansible.posix']
    assert isinstance(CollectionSearch()._collections, list)
    # _collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
    #                               always_post_validate=True, static=True)
    assert isinstance(CollectionSearch().get_default_attr('_collections'), list)

# Generated at 2022-06-25 05:05:05.392418
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()
    cs = CollectionSearch(collections=['namespace.collection'])
    assert cs._collections == _ensure_default_collection(['namespace.collection'])

# Generated at 2022-06-25 05:05:10.716170
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections.listof == string_types
    assert collection_search._collections.default == ['ansible.builtin']
    assert collection_search._collections.static is True
    assert collection_search._collections.always_post_validate is True
    assert isinstance(collection_search._collections.priority, int)
    assert collection_search._collections.private_value is None
    assert collection_search._collections.key == 'collections'
    assert collection_search._collections.default_inherit == True
    assert collection_search._collections.path == ['collections']
    assert collection_search._collections.parent is None
    assert collection_search._collections.post_validate is None

# Generated at 2022-06-25 05:05:14.539918
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:05:20.190523
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # Ensure that the _collections field static attribute is set to the default value if no value is specified
    assert cs._collections is _ensure_default_collection

    # Ensure that the _collections field static attribute is set to the default value if an empty collection list is specified
    assert cs._collections([]) is _ensure_default_collection([])

# Generated at 2022-06-25 05:05:26.617647
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == _ensure_default_collection()
    cs = CollectionSearch(collections=['myco.mycoll'])
    assert cs.collections == ['myco.mycoll']
    cs = CollectionSearch(collections=['myco.mycoll', 'myco.mycoll2'])
    assert cs.collections in (['myco.mycoll', 'myco.mycoll2'], ['myco.mycoll2', 'myco.mycoll'])

# Generated at 2022-06-25 05:05:35.055003
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import RoleInclude
    role_include = RoleInclude()
    assert role_include._load_collections(None, None) is None

# Generated at 2022-06-25 05:05:41.979888
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._load_collections(None, []) == [None]
    assert cs._load_collections(None, ['test_collection']) == ['test_collection', None]
    assert cs._load_collections(None, None) == [None]

# Generated at 2022-06-25 05:05:50.869500
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible
    from ansible.cli import CLI
    from ansible.plugins.loader import collect_all_plugins, add_all_plugin_dirs
    from ansible.plugins.loader import add_builtin_plugin_dirs, add_collection_plugin_dirs
    import os

    collection_name = "test_collection"

    # Initialization
    ansible.config.CLI.collections_paths = []
    add_all_plugin_dirs()
    add_builtin_plugin_dirs()
    ansible.module_utils.module_finder._module_finder_cache = {}
    plugin_loader = ansible.plugins.loader.PluginLoader()

    # Generate temporary collections dir
    # Directory structure would be:
    # test_collection/
    #   test_collection.tar.gz
    #


# Generated at 2022-06-25 05:05:53.226279
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create a CollectionSearch object
    collection_search_obj = CollectionSearch()
    display.vvv(collection_search_obj)
    # Check that _collections field was set
    assert collection_search_obj._collections is not None

# Generated at 2022-06-25 05:05:58.439735
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """ This is to test whether the class CollectionSearch constructs the role name correctly """

    # Initializing an instance of class CollectionSearch
    obj = CollectionSearch()

    # The collection name constructed if there is no collection name specified
    default_collection_name = obj._collections(None)
    assert default_collection_name == ['ansible.builtin']

    # The collection name constructed if there is a collection name specified
    sample_collection_name = obj._collections(['ansible.builtin'])
    assert sample_collection_name == ['ansible.builtin']


# Generated at 2022-06-25 05:06:05.808094
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Constructor of class CollectionSearch
    """

    # Test case when collection_list is None
    my_collections = CollectionSearch(None)

    # Test case when collection_list is empty list
    my_collections1 = CollectionSearch([])

    # Test case when ci_list is list
    my_collections2 = CollectionSearch(['foo', 'bar'])

# Generated at 2022-06-25 05:06:13.819303
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is not None
    assert cs._collections == _ensure_default_collection()
    cs.collections = ['my_collection']
    assert cs.collections == _ensure_default_collection(cs.collections)
    cs.collections = []
    assert cs.collections == _ensure_default_collection(cs.collections)
    cs.collections = None
    assert cs.collections == _ensure_default_collection()
    # Test the mechanism to read a string instead of a list
    cs.collections = 'ansible.legacy'
    assert cs.collections == ['ansible.legacy']
    # Test the mechanism to read a list of strings instead of a list
    cs.collections = ['my_collection', 'test_collection']

# Generated at 2022-06-25 05:06:22.278848
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections.validate() is None
    assert cs._collections.value is None
    assert cs.get_validated_value('collections', cs._collections, ['one.two'], None) == ['one.two']
    assert cs.get_validated_value('collections', cs._collections, ['one.two', 'ansible.builtin'], None) == ['one.two', 'ansible.builtin']
    assert cs.get_validated_value('collections', cs._collections, ['ansible.builtin', 'one.two'], None) == ['ansible.builtin', 'one.two']
    # If a list is given without 'ansible.builtin', it's added to first place

# Generated at 2022-06-25 05:06:27.036618
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    #GIVEN
    class Test(CollectionSearch):
        pass

    test = Test()
    test._attributes = {'collections': test._collections}

    #WHEN
    ds = {'collections': ['my.ansible.collections']}
    test.post_validate(ds, 'collections')

    #THEN
    assert ds['collections'] == ['my.ansible.collections', 'ansible.builtin']

# Generated at 2022-06-25 05:06:28.710347
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    c = collection_search._load_collections('collections', None)
    assert c is None


# Generated at 2022-06-25 05:06:43.945595
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:06:51.622932
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import PY3
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    class MyTask(CollectionSearch, Task):
        pass

    action = ActionBase()
    task = MyTask()
    task.set_loader(action)
    task._parent = 'parent'
    task._role = None
    task._collections = []
    task

# Generated at 2022-06-25 05:06:54.168978
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections._default == _ensure_default_collection and cs._collections._default.__closure__ is not None

# Generated at 2022-06-25 05:06:55.374340
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    f = CollectionSearch()
    f.post_validate(None, None, None)

# Generated at 2022-06-25 05:07:01.911921
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class testclass(CollectionSearch):
        def __init__(self):
            self._collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                            always_post_validate=True, static=True)
            self.collections = None
    x = testclass()
    x.collections = [1,2,3]
    assert x._collections == [1,2,3]

# Generated at 2022-06-25 05:07:03.053366
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)

# Generated at 2022-06-25 05:07:06.970654
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.role_include import IncludeRole
    
    i = IncludeRole()
    assert(i.collections == [])

# Generated at 2022-06-25 05:07:10.212366
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.collections == _ensure_default_collection()

# Generated at 2022-06-25 05:07:12.960503
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    expected_output = ["ansible.base_3.3.0", "ansible.builtin", "ansible.legacy"]
    assert c.collections == expected_output

# Generated at 2022-06-25 05:07:14.182187
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs=CollectionSearch()
    assert cs._load_collections('collections', []) == None

# Generated at 2022-06-25 05:07:48.881510
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test(CollectionSearch):
        pass
    test = Test(None)
    data = test._load_collections('_collections', None)
    assert data == ['ansible.builtin', 'ansible.legacy']
    data = test._load_collections('_collections', 'test')
    assert data == ['test', 'ansible.builtin', 'ansible.legacy']
    data = test._load_collections('_collections', ['test'])
    assert data == ['test', 'ansible.builtin', 'ansible.legacy']
    data = test._load_collections('_collections', ['test', 'test2'])
    assert data == ['test', 'test2', 'ansible.builtin', 'ansible.legacy']

    test2 = Test(None)
    data = test2

# Generated at 2022-06-25 05:07:51.544277
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None
    assert cs._load_collections(None, None) is None
    assert cs._load_collections(None, []) is None
    assert cs._load_collections(None, ['a']) == ['a']

# Generated at 2022-06-25 05:07:55.938951
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch=CollectionSearch()
    assert collectionsearch._load_collections(None,None) == ['ansible_collections.test.test_collection']
    assert collectionsearch._load_collections(None,['ansible_collections.test.test_collection']) == ['ansible_collections.test.test_collection']

# Generated at 2022-06-25 05:08:00.242451
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c.get_validated_value('collections', c._collections, ['foo'], None) == ['foo']
    assert c.get_validated_value('collections', c._collections, ['foo', None], None) == ['foo']

    assert c.get_validated_value('collections', c._collections, None, None) == _ensure_default_collection()

# Generated at 2022-06-25 05:08:03.463372
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)

# Generated at 2022-06-25 05:08:05.195716
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._load_collections(None, None) is None

# Generated at 2022-06-25 05:08:06.521536
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default == _ensure_default_collection()

# Generated at 2022-06-25 05:08:09.705118
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_collection_search = CollectionSearch()
    assert test_collection_search._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:08:15.304857
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    with display.override_display(False):
        class Class:
            def __init__(self):
                self.__dict__ = {}
                self._collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                  always_post_validate=True, static=True)
        Class.__bases__ = (CollectionSearch,)
        cs = Class()
        cs.collections = ["test"]
        assert cs.collections == ["test"]

# Generated at 2022-06-25 05:08:17.921127
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print((CollectionSearch()).get_validated_value('collections', CollectionSearch._collections, ['ansible.builtin'], None))
    # print((CollectionSearch()).get_validated_value('collections', [], ['ansible.builtin'], None))

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:09:19.992378
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class Test_CollectionSearch(CollectionSearch):
        _collections = FieldAttribute(isa='list', listof=string_types, priority=100,
                                      always_post_validate=True, static=True)

    test_collection_search = Test_CollectionSearch()
    print(test_collection_search._collections)

# Generated at 2022-06-25 05:09:24.203853
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    default_collection = AnsibleCollectionConfig.default_collection
    ansible_collections = ['ansible.builtin']
    if default_collection:
        ansible_collections.insert(0, default_collection)
    assert cs._collections.default == ansible_collections

# Generated at 2022-06-25 05:09:25.493636
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-25 05:09:26.664784
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()

# Generated at 2022-06-25 05:09:29.230396
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:09:31.087419
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == "ansible.builtin"

# Generated at 2022-06-25 05:09:36.468215
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.legacy']


# Generated at 2022-06-25 05:09:44.451984
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch._collections.default(_ensure_default_collection) == _ensure_default_collection(None)

    # Test when the default collection is None
    default_collection_backup = AnsibleCollectionConfig.default_collection
    AnsibleCollectionConfig.default_collection = None

    assert CollectionSearch._collections.default(_ensure_default_collection) == _ensure_default_collection(None)

    AnsibleCollectionConfig.default_collection = default_collection_backup

# Generated at 2022-06-25 05:09:51.319302
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None
    assert cs._load_collections('collections', 'ansible.builtin') == ['ansible.builtin']
    assert cs._load_collections('collections', ['a', 'b']) == ['a', 'b', 'ansible.legacy']
    assert cs._load_collections('collections', ['ansible.builtin', 'a']) == ['ansible.builtin', 'a']
    assert cs._load_collections('collections', ['a', 'ansible.builtin']) == ['a', 'ansible.builtin']

# Generated at 2022-06-25 05:09:54.682038
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections is None

# Generated at 2022-06-25 05:12:29.181742
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """
    Unit test for constructor of class CollectionSearch
    """
    assert isinstance(CollectionSearch(), CollectionSearch)

# Generated at 2022-06-25 05:12:35.918645
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    #test_val = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                              #always_post_validate=True, static=True)
    print("-------------testing CollectionSearch class---------")
    yaml_str = """
    -  name: Create a new tenant.
       collections:
         - community.general
         - cisco.asa
    """
    test_val = CollectionSearch()
    res = test_val.load(yaml_str)
    collections = res.get_value("collections")
    print("collections: " , collections)
    for collection in collections:
        print("collection: " , collection)
    assert collections is not None
    assert len(collections) == 2

# Generated at 2022-06-25 05:12:36.697356
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:12:38.623881
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    data_struct = {"collections": ['ansible.netcommon']}
    obj.get_validated_value("collections", obj._collections, data_struct)

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:12:47.095927
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # must be able to pass in a list of strings to the constructor
    t = CollectionSearch(collections=['test'])
    assert t.collections == ['test']

    # must be able to pass in a list of collections
    t = CollectionSearch(collections=['test.my.collection'])
    assert t.collections == ['test.my.collection']

    # if no collection is provided, default to ansible.legacy
    t = CollectionSearch()
    assert t.collections == ['ansible.legacy']

    # template collection names
    t = CollectionSearch()
    t.collections.append('{{ fake_collection }}')
    assert t.collections == ['{{ fake_collection }}']

# Generated at 2022-06-25 05:12:48.264243
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert cs.collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:12:50.490727
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert _ensure_default_collection(['ansible.builtin','ansible.legacy','ansible.community.general']) == [
        'ansible.community.general', 'ansible.builtin', 'ansible.legacy']



# Generated at 2022-06-25 05:12:55.639305
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.play_context import PlayContext

    t = CollectionSearch()
    assert isinstance(t, CollectionSearch)
    assert t._collections is None
    #assert t._collections == ['ansible_collections.ns_ansible.plugins.module_utils.network.asa']

    try:
        t.post_validate(dict(), PlayContext())
    except:
        pass  # expect to raise error for no collections
    t._collections = ['ansible_collections.ns_ansible.plugins.module_utils.network.asa']
    t.post_validate(dict(), PlayContext())

# Generated at 2022-06-25 05:13:04.980850
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    search = CollectionSearch()
    collections = search._load_collections(None,["ansible.builtin", "ansible_collections.my_namespace.my_collection", "ansible_collections.my_namespace.my_collection.my_role"])
    assert collections[0] == "ansible.builtin"
    assert collections[1] == "ansible_collections.my_namespace.my_collection"
    assert collections[2] == "ansible_collections.my_namespace.my_collection.my_role"
    col = search._load_collections(None,None)
    assert col[0] == "ansible.builtin"

# Generated at 2022-06-25 05:13:06.323542
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections._default is not None