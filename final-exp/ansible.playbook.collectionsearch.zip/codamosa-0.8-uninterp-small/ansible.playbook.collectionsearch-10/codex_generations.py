

# Generated at 2022-06-25 05:03:30.319875
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    collection_search_0 = CollectionSearch()
    collection_search_0.collections = ['collection1', 'collection2']
    print("collections field: ")
    print(collection_search_0.collections)
    # Asserting the value of field "collections"
    assert collection_search_0.collections == ['collection1', 'collection2']
    print('test_CollectionSearch passed!')

if __name__ == '__main__':

    test_case_0()
    test_CollectionSearch()

# Generated at 2022-06-25 05:03:31.259653
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None


# Generated at 2022-06-25 05:03:34.754172
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    CollectionSearch()


# TODO: Need to be implement

# Generated at 2022-06-25 05:03:36.301632
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()

    if collection_search_0 == None:
        return True
    else:
        return False


# Generated at 2022-06-25 05:03:40.420005
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections.default == ['ansible.posix']

# Generated at 2022-06-25 05:03:46.849635
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # create an object of the class
    collection_search = CollectionSearch()
    print(collection_search)
    # test if the class variable collections of the class CollectionSearch is equal to a list
    assert type(collection_search) == 'list', "collections variable of class CollectionSearch not equal to a list"
    # test if the class variable collections of the class CollectionSearch is equal to a list containing the value
    # 'ansible.builtin'
    assert 'ansible.builtin' in collection_search, "collections variable of class CollectionSearch not " + "duplicated"


# Generated at 2022-06-25 05:03:47.647359
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()

# Generated at 2022-06-25 05:03:51.740393
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch() is not None


# Generated at 2022-06-25 05:03:52.997988
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display.display("Test CollectionSearch")
    test_case_0()

# Generated at 2022-06-25 05:03:53.614652
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert test_case_0() == None

# Generated at 2022-06-25 05:04:05.135966
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        test_case_0()
    except Exception as e:
        print('FAIL: %s' % str(e))
        return 1


if __name__ == '__main__':
    exit(test_CollectionSearch())

# Generated at 2022-06-25 05:04:06.017062
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:04:16.204691
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Test Case 1:
    # Testing the default collections
    collection_search = CollectionSearch()
    assert collection_search.collections == collection_search._ensure_default_collection()

    # Test Case 2:
    # Testing if empty list is passed as argument
    collection_search = CollectionSearch(['ansible_namespace.collection_name'])
    assert collection_search.collections == ['ansible_namespace.collection_name']

    # Test Case 3:
    # Testing if the default collection is overridden
    collection_search = CollectionSearch(['ansible_namespace.collection_name', 'ansible.legacy'])
    assert collection_search.collections == ['ansible_namespace.collection_name', 'ansible.legacy']

# Generated at 2022-06-25 05:04:17.440764
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    collection_search_1 = CollectionSearch()
    assert collection_search_1



# Generated at 2022-06-25 05:04:17.978414
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()



# Generated at 2022-06-25 05:04:21.500304
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert type(collection_search) == CollectionSearch

# Generated at 2022-06-25 05:04:22.227673
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:04:23.266672
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None


# Generated at 2022-06-25 05:04:27.767952
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0.collections == _ensure_default_collection()


# test for method load_collections

# Generated at 2022-06-25 05:04:31.969287
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    co_search_0 = CollectionSearch()
    assert co_search_0._collections == ['ansible.builtin']         # Unit test for testing value of attribute _collections after its call
    assert co_search_0._collections is not None                    # Unit test for testing value of attribute _collections after its call

# Generated at 2022-06-25 05:04:51.636860
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    collection_search_1.collections = ['collection1']
    assert collection_search_1.collections == ['collection1']
    collection_search_2 = CollectionSearch()
    collection_search_2.collections = ['collection1', 'collection2']
    assert collection_search_2.collections == ['collection1', 'collection2']


# Generated at 2022-06-25 05:04:54.023443
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    """Unit test for constructor of class AnsibleCollectionConfig"""

    collection_search_1 = CollectionSearch()

    if collection_search_1 is None:
        raise AssertionError()

# Generated at 2022-06-25 05:04:58.499854
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == ['ansible_collections.ansible.builtin', 'ansible_collections.ansible.builtin.legacy', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:05:01.835904
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1.__dict__ == {}

# Generated at 2022-06-25 05:05:02.819101
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:05:04.650810
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    collection_search_0.collections = 'foo'
    collection_search_1 = CollectionSearch()
    collection_search_1.collections = _ensure_default_collection()

# Generated at 2022-06-25 05:05:06.620483
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0.get_static_attr_value('collections') == _ensure_default_collection()

# Generated at 2022-06-25 05:05:07.436454
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:05:11.196752
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display.warning = _fake_warning
    collection_search = CollectionSearch()

    # test whether collection_search is an instance of class CollectionSearch
    assert isinstance(collection_search, CollectionSearch)

    # test whether colletion_search is an instance of Base
    assert isinstance(collection_search, AnsibleCollectionConfig)


# Generated at 2022-06-25 05:05:13.561252
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    assert cs.collections is None


# Generated at 2022-06-25 05:05:40.209761
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections == _ensure_default_collection()


# Generated at 2022-06-25 05:05:45.068459
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert (collection_search_0._ensure_default_collection == _ensure_default_collection)

# Generated at 2022-06-25 05:05:53.569391
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        # Test setting a value for field 'collections'
        collection_search_1 = CollectionSearch()
        collection_search_1._collections = ["ansible"]

        # Test setting a value for field 'collections'
        collection_search_2 = CollectionSearch()
        collection_search_2._collections = []

    except Exception as e:
        raise AssertionError("Failed to test class CollectionSearch. Error: {0}".format(str(e)))

# Generated at 2022-06-25 05:05:56.950463
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections is not None
    assert collection_search_0.__dict__['_collections'].__class__.__name__ == 'FieldAttribute'
    assert collection_search_0.__dict__['_collections']._data_name == 'collections'

# Generated at 2022-06-25 05:05:57.744874
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch() is not None


# Generated at 2022-06-25 05:06:02.271111
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0 is not None

# Unit tests for _load_collections

# Generated at 2022-06-25 05:06:08.283625
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert not hasattr(collection_search, '_collections')

    collection_search._collections = [
        'ansible_collections.foo.bar',
        'ansible_collections.baz.baz',
        'ansible_collections.qux.qux',
    ]
    assert collection_search._collections == [
        'ansible_collections.foo.bar',
        'ansible_collections.baz.baz',
        'ansible_collections.qux.qux',
    ]

# Generated at 2022-06-25 05:06:11.770987
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    expected_result = 'ansible.builtin'
    # call the constructor of the class
    collection_search_0 = CollectionSearch()
    actual_result = collection_search_0._collections.default()
    assert type(actual_result) == list
    assert actual_result[0] == expected_result


# Generated at 2022-06-25 05:06:18.571274
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Create an instance of the class
    collection_search = CollectionSearch()
    # Check whether the object is an instance of the class
    assert isinstance(collection_search, CollectionSearch)
    # Check whether the object is an instance of the Base class
    # from which the CollectionSearch class inherits
    from ansible.playbook.base import Base

    assert isinstance(collection_search, Base)


# Generated at 2022-06-25 05:06:28.397572
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1._collections == _ensure_default_collection(collection_list=None)
    assert collection_search_1._load_collections(attr=None, ds=None) is None

    # ds will be a list of collections like ["ansible.builtin", "ansible_collections.foo.bar"]
    collection_list = ['ansible.builtin', 'ansible_collections.foo.bar']
    assert collection_search_1._load_collections(attr=None, ds=collection_list) == collection_list

    collection_list = ['ansible_collections.foo.bar', 'ansible_collections.foo.baz']

# Generated at 2022-06-25 05:07:25.638436
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # Instantiate object
    collection_search_0 = CollectionSearch()
    # Test attribute 'collections'
    assert collection_search_0._load_collections('collections', None) == ['ansible.builtin', 'ansible.legacy']
    # Test attribute 'collections' with user specified value
    assert collection_search_0._load_collections('collections', "my.collection") == ['my.collection', 'ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:07:26.782060
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert(hasattr(CollectionSearch, '_collections'))


# Generated at 2022-06-25 05:07:27.685326
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    t1 = test_case_0()

# Generated at 2022-06-25 05:07:32.056908
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search_0 = CollectionSearch()
        assert True
    except:
        assert False

if __name__ == '__main__':
    test_case_0()
    test_CollectionSearch()

# Generated at 2022-06-25 05:07:34.650124
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display.display("##### BEGIN test_CollectionSearch() #####")
    test_case_0()
    display.display("##### END test_CollectionSearch() #####")

if __name__ == '__main__':
    test_CollectionSearch()

# Generated at 2022-06-25 05:07:35.467564
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()

# Generated at 2022-06-25 05:07:38.349726
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()



# Generated at 2022-06-25 05:07:40.098576
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search_0 = CollectionSearch()
    except Exception:
        assert False



# Generated at 2022-06-25 05:07:40.959519
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()

# Generated at 2022-06-25 05:07:42.571957
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1 is not None


# Generated at 2022-06-25 05:08:52.819254
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.module_utils.six import PY3
    if PY3:
        collection_search_0 = CollectionSearch()
    else:
        try:
            collection_search_0 = CollectionSearch()
        except TypeError as e:
            raise Exception("Failed due to Exception: {0}".format(e))


# Generated at 2022-06-25 05:08:54.254202
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections.default == _ensure_default_collection()


# Generated at 2022-06-25 05:09:05.066044
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # check for collection list values
    collection_search_0 = CollectionSearch()
    assert collection_search_0.collections == ['ansible_collections.ansible.builtin', 'ansible.builtin']

    # check for collections iterable
    collection_search_1 = CollectionSearch()
    collection_search_1.collections = ['ansible_collections.ansible.builtin', 'ansible.builtin']
    assert collection_search_1.collections == ['ansible_collections.ansible.builtin', 'ansible.builtin']

    # check for collections list
    collection_search_2 = CollectionSearch()
    collection_search_2.collections = ['ansible_collections.ansible.builtin', 'ansible.builtin']

# Generated at 2022-06-25 05:09:05.618614
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()



# Generated at 2022-06-25 05:09:10.775269
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch(), CollectionSearch)
    assert isinstance(CollectionSearch._collections, FieldAttribute)
    assert isinstance(CollectionSearch._collections.isa, type(None))
    assert isinstance(CollectionSearch._collections.listof, str)
    assert CollectionSearch._collections.priority == 100
    assert CollectionSearch._collections.default == []
    assert CollectionSearch._collections.always_post_validate
    assert CollectionSearch._collections.static
    # test _load_collections()
    assert CollectionSearch()._load_collections(CollectionSearch._collections, []) == None
    assert CollectionSearch()._load_collections(CollectionSearch._collections, [["ansible.builtin"]]) == ["ansible.builtin"]

# Generated at 2022-06-25 05:09:12.815197
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert(isinstance(collection_search_1._collections, list))
    assert(isinstance(collection_search_1._collections[0], str))


# Generated at 2022-06-25 05:09:14.851821
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0 is not None
    assert collection_search_0._collections == 'ansible.builtin'

if __name__ == '__main__':
    test_case_0()
    test_CollectionSearch()

# Generated at 2022-06-25 05:09:18.215566
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert len(collection_search._collections) == 1
    assert collection_search._collections[0] == 'ansible.legacy'


# Generated at 2022-06-25 05:09:19.349812
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
   assert CollectionSearch()


# Generated at 2022-06-25 05:09:22.473743
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    display.display("Testing class CollectionSearch")

    # Testing constructor 'CollectionSearch'
    collection_search_0 = CollectionSearch()
    assert isinstance(collection_search_0._collections, FieldAttribute)



# Generated at 2022-06-25 05:11:59.278533
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1 is not None


# Generated at 2022-06-25 05:11:59.950394
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()


# Generated at 2022-06-25 05:12:03.289506
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    collection_search_2 = CollectionSearch()

    assert collection_search_1 is collection_search_2

# Generated at 2022-06-25 05:12:05.163404
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0 is not None


# Generated at 2022-06-25 05:12:08.756314
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections is None
    assert collection_search_0._attributes == {'collections': {'always_post_validate': True, 'default': [], 'static': True, 'priority': 100}}

# Generated at 2022-06-25 05:12:10.402208
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search._collections == None

# Generated at 2022-06-25 05:12:14.216632
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()



# Generated at 2022-06-25 05:12:16.396646
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert(collection_search_1 is not None)
    assert(collection_search_1._collections == ['ansible_collections.acme.foobar'])


# Generated at 2022-06-25 05:12:22.307337
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search.get_validated_value('collections', _ensure_default_collection, None, None) != ['collections']
    assert collection_search.get_validated_value('collections', _ensure_default_collection, None, ['collections']) == ['collections']

# Generated at 2022-06-25 05:12:23.806155
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    print(collection_search)