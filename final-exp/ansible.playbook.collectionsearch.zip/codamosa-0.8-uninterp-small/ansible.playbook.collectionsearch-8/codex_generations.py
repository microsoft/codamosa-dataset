

# Generated at 2022-06-25 05:03:24.736603
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1._collections_static

    # TODO: Add more test cases for method '_load_collections'


if __name__ == "__main__":
    test_case_0()
    test_CollectionSearch()

# Generated at 2022-06-25 05:03:27.556264
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search_0 = CollectionSearch()
    except Exception as e:
        print('Error in CollectionSearch class constructor!')
        print(e)
    else:
        print('CollectionSearch test case passed')

if __name__ == "__main__":
    test_CollectionSearch()
    test_case_0()

# Generated at 2022-06-25 05:03:31.229116
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == _ensure_default_collection()
    assert CollectionSearch(collections=['foo','bar']).collections == ['foo','bar']
    assert CollectionSearch(collections=None).collections == _ensure_default_collection()

# Generated at 2022-06-25 05:03:32.831818
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:03:33.654208
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_case_0()



# Generated at 2022-06-25 05:03:35.902103
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections is None

#    def _load_collections(self, attr, ds):



# Generated at 2022-06-25 05:03:39.192666
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()

# Generated at 2022-06-25 05:03:47.999530
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible import constants
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.six import string_types
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.display import Display

    collection_search_0 = CollectionSearch()
    assert collection_search_0.fieldnames is None
    assert collection_search_0._attributes is None
    assert collection_search_0._field_names is None
    assert collection_search_0._field_values is None
    assert collection_search_0._loaded_attrs is None
    assert collection_search_0._ds is None
    assert collection_search_0._ds_type is None
    assert collection

# Generated at 2022-06-25 05:03:55.072238
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("\n\n")
    print("************************************************************************")
    print("*************          Test Case for Collection Search       ***********")
    print("************************************************************************")
    print("\n\n")
    collection_search_0 = CollectionSearch()
    print("\n\n")


# Test Case 0
test_case_0()

# Unit Test
test_CollectionSearch()

# Generated at 2022-06-25 05:03:57.986090
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert_raises(TypeError, CollectionSearch)
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:04:08.960783
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)


# Generated at 2022-06-25 05:04:11.141995
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        collection_search_0 = CollectionSearch()
    except Exception:
        assert False
    assert True


# Generated at 2022-06-25 05:04:12.128549
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()


# Generated at 2022-06-25 05:04:15.416835
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert collection_search_0._collections.default == _ensure_default_collection
    assert collection_search_0._collections.type == 'list'
    assert collection_search_0._collections.always_post_validate
    assert collection_search_0._collections.static
    assert collection_search_0._collections.priority == 100


# Generated at 2022-06-25 05:04:16.446089
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("UNIT TEST - Constructor")
    print()
    test_case_0()


# Generated at 2022-06-25 05:04:17.222556
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(test_case_0(), CollectionSearch)


# Generated at 2022-06-25 05:04:24.024016
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1.collections == _ensure_default_collection()
    collection_search_2 = CollectionSearch()
    collection_search_2.collections = ['foo', 'bar']
    assert collection_search_2.collections == ['foo', 'bar', 'ansible.builtin']


# Generated at 2022-06-25 05:04:26.899763
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1 is not None

# Generated at 2022-06-25 05:04:29.015384
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert collection_search_1.collections == _ensure_default_collection()


# Generated at 2022-06-25 05:04:30.785902
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    id_0 = CollectionSearch()
    assert type(id_0) is CollectionSearch

# Generated at 2022-06-25 05:04:47.474000
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    col_search = CollectionSearch()
    assert isinstance(col_search, CollectionSearch)



# Generated at 2022-06-25 05:04:49.510186
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    assert isinstance(collection_search_1, CollectionSearch) is True

# Generated at 2022-06-25 05:04:51.385271
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert collection_search is not None



# Generated at 2022-06-25 05:04:52.196310
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch



# Generated at 2022-06-25 05:04:56.199993
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert 'FieldAttribute'
    assert 'isa'
    assert 'list'
    assert 'listof'
    assert 'priority'
    assert '100'
    assert 'default'
    assert '_ensure_default_collection'
    assert 'always_post_validate'
    assert 'True'
    assert 'static'
    assert 'True'


# Generated at 2022-06-25 05:04:58.449395
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    print("Heil")
    collection_search_0 = CollectionSearch()
    print(collection_search_0._collections)


# Generated at 2022-06-25 05:05:01.738394
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search = CollectionSearch()
    assert isinstance(collection_search, CollectionSearch)


# Generated at 2022-06-25 05:05:04.908551
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()

    # Testing to see that the class has been initialized as it should
    assert collection_search_1 is not None
    assert isinstance(collection_search_1, CollectionSearch)


# Generated at 2022-06-25 05:05:12.725959
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_1 = CollectionSearch()
    if collection_search_1._collections:
        collection_search_1._collections = None
    if isinstance(collection_search_1._collections, string_types):
        raise AssertionError()
    if not isinstance(collection_search_1._collections, list):
        raise AssertionError()
    if 'ansible_collections.username.role_name' not in collection_search_1._collections:
        raise AssertionError()
    if 'ansible.builtin' not in collection_search_1._collections:
        raise AssertionError()
    if 'ansible.legacy' not in collection_search_1._collections:
        raise AssertionError()

# Generated at 2022-06-25 05:05:15.517099
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection_search_0 = CollectionSearch()
    assert isinstance(collection_search_0, CollectionSearch) 
    assert isinstance(collection_search_0.collections, list)

# Generated at 2022-06-25 05:05:30.848629
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    obj = CollectionSearch()
    assert(obj._collections == _ensure_default_collection)

# Generated at 2022-06-25 05:05:36.984738
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections is None
    assert cs._load_collections(None, None) == ['ansible.builtin']
    assert cs._collections == ['ansible.builtin']
    assert cs._load_collections(None, ['ansible.builtin']) == ['ansible.builtin']
    assert cs._collections == ['ansible.builtin']
    assert cs._load_collections(None, ['my.collection']) == ['my.collection', 'ansible.builtin']
    assert cs._collections == ['my.collection', 'ansible.builtin']

# Generated at 2022-06-25 05:05:37.659563
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionSearch = CollectionSearch()


# Generated at 2022-06-25 05:05:38.937581
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    default_collection = AnsibleCollectionConfig.default_collection
    assert c.collections.data == [default_collection]

# Generated at 2022-06-25 05:05:40.676371
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert isinstance(cs, CollectionSearch)
    assert isinstance(cs, Base)

# Generated at 2022-06-25 05:05:44.780536
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test_object = CollectionSearch()
    assert test_object is not None 
    assert test_object.collections is not None

# Generated at 2022-06-25 05:05:46.678445
# Unit test for constructor of class CollectionSearch

# Generated at 2022-06-25 05:05:53.431188
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class MyCollectionSearch(CollectionSearch):
        # a list of Ansible collections in which we will look for possible modules
        collections = FieldAttribute(isa='list', listof=string_types, priority=100, default=_ensure_default_collection,
                                     always_post_validate=True, static=True)

    ds = dict()
    cs = MyCollectionSearch()
    cs._load_collections('collections', ds)

# Generated at 2022-06-25 05:05:57.413766
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # This tests that the constructor of CollectionSearch correctly sets
    # self._collections to the default value when no argument is given.
    collection = CollectionSearch()
    assert collection._collections == ['ansible_collections.foo.bar']
    assert collection.get_validated_value('collections', collection._collections, ['ansible_collections.foo.bar'], None) == ['ansible_collections.foo.bar']

# Generated at 2022-06-25 05:06:08.580521
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():

    class Test(CollectionSearch):
        pass

    c = Test(dict())

    # test a simple search command
    c._collections = ['ansible_community.general']
    c.get_validated_value('collections', c._collections, {}, None)
    assert c._collections == ['ansible_community.general']

    # test a search command with deprecation warning
    c._collections = ['ansible.legacy']
    c.get_validated_value('collections', c._collections, {}, None)
    assert c._collections == ['ansible_community.general', 'ansible.legacy']

    # test a search command with deprecation warning and warning
    c._collections = ['ansible_community.general', 'ansible.legacy']

# Generated at 2022-06-25 05:06:38.324123
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collectionsearch = CollectionSearch()
    assert collectionsearch._collections is not None
    assert collectionsearch.collection_loader is not None

# Generated at 2022-06-25 05:06:49.295127
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import ansible.playbook
    import ansible.plugins
    import ansible.plugins.loader
    import ansible.playbook.role
    import collections

    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.display import Display
    display = Display()

    try:
        collection_list = AnsibleCollectionConfig.default_collection
    except AttributeError:
        collection_list = None
    display.v("before: collection_list: %s" % (collection_list))
    col = ansible.plugins.collection.CollectionLoader()
    col.load_collections([collection_list])
    display.v("after: collection_list: %s" % (collection_list))
    display.v("after: resource_paths: %s" % (col.collections_paths))
   

# Generated at 2022-06-25 05:06:51.667498
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    try:
        CollectionSearch()
    except:
        assert 0, "CollectionSearch constructor is throwing exception"

# Generated at 2022-06-25 05:06:53.576760
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == ['ansible.builtin', 'ansible.legacy']

# Generated at 2022-06-25 05:07:02.299749
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    # _collections = FieldAttribute(isa='list',
    #                               listof=string_types,
    #                               priority=100,
    #                               default=_ensure_default_collection,
    #                               always_post_validate=True,
    #                               static=True)
    y = CollectionSearch()
    assert y._collections.isa == 'list'
    assert y._collections.listof == string_types
    assert y._collections.priority == 100
    assert y._collections.default == _ensure_default_collection
    assert y._collections.always_post_validate is True
    assert y._collections.static is True


# Generated at 2022-06-25 05:07:05.147958
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    assert test._collections == _ensure_default_collection()
    assert test._load_collections('_collections', test._collections) == _ensure_default_collection()

# Generated at 2022-06-25 05:07:07.373549
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    a = CollectionSearch()
    assert a._collections._default == a._ensure_default_collection

# Generated at 2022-06-25 05:07:12.349997
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == _ensure_default_collection()
    assert CollectionSearch(collections=None).collections == _ensure_default_collection(collection_list=None)
    assert CollectionSearch(collections=[]).collections == _ensure_default_collection([])

# Generated at 2022-06-25 05:07:13.852476
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._load_collections(None, None) == ['ansible.builtin']

# Generated at 2022-06-25 05:07:18.569626
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs.collections == ['ansible_collections.foo.bar.tasks']
    # when no default collection is specified
    cs.set_loader(None)
    cs.post_validate()
    assert cs.collections is None

# Generated at 2022-06-25 05:08:31.373867
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    import pytest
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:08:33.601333
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    assert cs._collections == 'ansible.builtin'

# Generated at 2022-06-25 05:08:37.559812
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    class TestCollectionSearch(Base, CollectionSearch):
        def __init__(self, ds):
            Base.__init__(self, ds)

    c = TestCollectionSearch({'collections': []})

    assert c.collections == ['ansible.builtin']
    assert c.__class__.__name__ == 'TestCollectionSearch'

# Generated at 2022-06-25 05:08:44.649991
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch().collections == ['ansible.builtin']
    assert CollectionSearch()._load_collections(None, None) is None
    assert CollectionSearch().load({'collections': None})[0] is None
    assert CollectionSearch().load({'collections': []})[0] is None
    assert CollectionSearch().load({'collections': ['namespace.collection']})[0] == ['namespace.collection']
    assert CollectionSearch().load({'collections': ['namespace.collection', 'namespace2.collection2']})[0] == ['namespace.collection', 'namespace2.collection2']

# Generated at 2022-06-25 05:08:46.117242
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    unit = CollectionSearch()
    test = unit._load_collections('collections','ansible.builtin')
    assert test == None

# Generated at 2022-06-25 05:08:48.205321
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()

    # Collections is the only parameter that is needed
    assert cs.collections is not None

# Generated at 2022-06-25 05:08:50.329452
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs1 = CollectionSearch()
    assert isinstance(cs1, CollectionSearch)

# Generated at 2022-06-25 05:08:55.970962
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import RoleInclude
    # Test constructor with calling tasks
    res = CollectionSearch(Task(), Task())
    assert res.__class__.__name__ == 'CollectionSearch'
    # Test constructor with calling tasks
    res = CollectionSearch(RoleInclude(), RoleInclude())
    assert res.__class__.__name__ == 'CollectionSearch'



# Generated at 2022-06-25 05:09:00.543736
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    assert c._collections == _ensure_default_collection()

# Generated at 2022-06-25 05:09:02.281775
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    cs.collections
    cs.collections = ['testCollection']
    cs.collections

# Generated at 2022-06-25 05:11:37.892284
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    collection = CollectionSearch()
    assert collection._collections.default == ['ansible.builtin']
    assert collection._collections.static == True
    assert collection._collections.always_post_validate == True
    assert collection._collections.priority == 100
    assert collection._collections.listof == string_types
    assert collection._collections.isa == 'list'


# Generated at 2022-06-25 05:11:41.657761
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    test = CollectionSearch()
    ds = [0, 1, 2]
    assert isinstance(test._load_collections(None, ds), list)
    test = CollectionSearch()
    ds = None
    assert isinstance(test._load_collections(None, ds), list)

# Generated at 2022-06-25 05:11:46.610492
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    c = CollectionSearch()
    c.collections = ['a', 'b']
    assert c.collections == ['a', 'b']

# Generated at 2022-06-25 05:11:48.184166
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    colsearch = CollectionSearch()
    ds = colsearch._collections
    assert(ds == _ensure_default_collection())

# Generated at 2022-06-25 05:11:50.749455
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert CollectionSearch()._collections == ['ansible_collections.some.collection']

# Generated at 2022-06-25 05:11:53.309582
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    ds = {'collections': ['daemon_collection']}
    ds = cs.post_validate(ds, partial=None)
    assert ds['collections'] == ['daemon_collection', 'ansible.builtin']

# Generated at 2022-06-25 05:11:54.293464
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    assert isinstance(CollectionSearch._collections, FieldAttribute)

# Generated at 2022-06-25 05:11:57.458788
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    role_collection = CollectionSearch()

    # Initialize _collections variable by passing empty list
    role_collection._collections = []

    # Apply post validation logic
    collection_list = role_collection._load_collections("collections", [])

    # Assert if ansible.builtin is present
    assert "ansible.builtin" in collection_list

# Generated at 2022-06-25 05:11:58.046360
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
  pass


# Generated at 2022-06-25 05:12:04.584330
# Unit test for constructor of class CollectionSearch
def test_CollectionSearch():
    cs = CollectionSearch()
    # Base class is initialized with an empty data structure
    assert cs.ds == {}
    cs = CollectionSearch(ds={'collections':['collection1', 'collection2']})
    # We expect data structure to be set from the argument
    assert cs.ds == {'collections':['collection1', 'collection2']}