

# Generated at 2022-06-12 19:00:17.582105
# Unit test for function parseOpts
def test_parseOpts():
#    from .compat import compat_str
    def compat_str(u):
        if sys.version_info < (3,):
            return u.encode('ascii')
        return u
    def compat_expanduser(u):
        if sys.version_info < (3,):
            return u.encode(preferredencoding(), 'replace')
        return os.path.expanduser(u)

    def _readOptions(filename):
        try:
            f = open(filename)
            text = f.read()
            f.close()
        except IOError:
            return []
        else:
            # compatibility with Windows paths like C:\something
            text = text.replace('\\', '/')
            # remove all carriage returns
            text = text.replace('\r', '')
            # ignore everything after

# Generated at 2022-06-12 19:00:26.764698
# Unit test for function parseOpts
def test_parseOpts():

    assert parseOpts(['--username=user', '--password=33ad6372f795694b333ec5d3c519ba26ceee190e', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].username == 'user'
    assert parseOpts(['--username=user', '--password=33ad6372f795694b333ec5d3c519ba26ceee190e', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].password == '33ad6372f795694b333ec5d3c519ba26ceee190e'

    # Python 2.X

# Generated at 2022-06-12 19:00:37.918760
# Unit test for function parseOpts

# Generated at 2022-06-12 19:00:46.916734
# Unit test for function parseOpts
def test_parseOpts():
    def check_parseOpts(args, expected):
        parser, _, out = parseOpts(args)
        assert out == expected, 'parseOpts(%s) -> %s, expected %s' % (args, out, expected)

    check_parseOpts(['-f', 'best', 'foo', 'bar'], ['foo', 'bar'])
    check_parseOpts(['-f', 'best', 'foo', '-f', 'best', 'bar'], ['foo', '-f', 'best', 'bar'])



# Generated at 2022-06-12 19:00:59.068960
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'http://www.youtube.com/watch?v=BaW_jenozKc', '-i', '-v'])
    assert opts.format == 'best'
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format_limit == None
    assert opts.outtmpl == None
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forceduration == False


# Generated at 2022-06-12 19:01:00.960872
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

# Generated at 2022-06-12 19:01:13.803186
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--get-id', '--get-title', '--yes-playlist', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert(opts.getid == True)
    assert(opts.gettitle == True)
    assert(opts.yesplaylist == True)
    assert(args[0] == "http://www.youtube.com/watch?v=BaW_jenozKc")

    parser, opts, args = parseOpts(['-g', '-e', '--yes-playlist', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert(opts.getid == True)
    assert(opts.gettitle == True)

# Generated at 2022-06-12 19:01:27.238308
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    if opts.usenetrc:
        write_string('usenetrc = ' + opts.usenetrc + '\n')
    write_string('username = ' + opts.username + '\n')
    write_string('password = ' + opts.password + '\n')
    write_string('video_password = ' + opts.video_password + '\n')
    write_string('ap_username = ' + opts.ap_username + '\n')
    write_string('ap_password = ' + opts.ap_password + '\n')
    write_string('ap_mso = ' + opts.ap_mso + '\n')

# Generated at 2022-06-12 19:01:38.016623
# Unit test for function parseOpts
def test_parseOpts():
    def check_parsing(args, check):
        args = args.split()
        parser, opts, _ = parseOpts(args)
        assert(check(opts) is True)
    check_parsing('-v',               lambda o: o.verbose)
    check_parsing('--verbose',        lambda o: o.verbose)
    check_parsing('--no-verbose',     lambda o: not o.verbose)
    check_parsing('--username=foo',   lambda o: o.username == 'foo')
    check_parsing('--username',       lambda o: o.username is None)
    check_parsing('--password=foo',   lambda o: o.password == 'foo')

# Generated at 2022-06-12 19:01:40.847622
# Unit test for function parseOpts
def test_parseOpts():
    from .update import update_self
    parser, opts, args = parseOpts(overrideArguments=['--update'])
    if len(args) != 1:
        print('TEST FAILED: update-self test')
        exit(1)
    print('Test passed')


# Generated at 2022-06-12 19:02:11.477804
# Unit test for function parseOpts
def test_parseOpts():
    class MockArgument(object):
        def __init__(self, value):
            self.value = value

    class MockOptionGroup(object):
        def __init__(self, title):
            self.title = title
            self.option_list = []

        def add_option(self, *args, **kwargs):
            self.option_list.append((args[0], kwargs.get('dest', None)))
            self.option_list.append(('--%s' % (kwargs.get('dest')) , kwargs.get('dest', None)))

    class MockOptParse(object):
        def __init__(self):
            self.option_groups = []

        def add_option_group(self, option_group):
            self.option_groups.append(option_group)


# Generated at 2022-06-12 19:02:23.267290
# Unit test for function parseOpts
def test_parseOpts():
    if sys.argv[0].endswith('__main__.py'):
        usage = 'usage: __main__.py [options] url [url...]'
    else:
        usage = 'usage: youtube-dl [options] url [url...]'
    parser, opts, _ = parseOpts(usage)
    parser, opts, _ = parseOpts(usage, ['-U', 'ytdl', '-v', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    parser, opts, _ = parseOpts(usage, ['--verbose', '-u', 'user', '--password', 'pass', '-i', '_fT_ax1xvlk'])

# Generated at 2022-06-12 19:02:36.390332
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import match_filter_func
    parser, opts, args = parseOpts(['--match-title', 'regexp', 'http://w.yt-dl.org/bug'])
    assert(match_filter_func(opts)({'title': 'abc'}))
    assert(not match_filter_func(opts)({'title': 'def'}))
    parser, opts, args = parseOpts(['-j', 'http://w.yt-dl.org/bug'])
    assert(opts.outtmpl == '%(id)s')

# Generated at 2022-06-12 19:02:40.844698
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-i', '-v', '--username=user', '--password=pass', '--verbose'])
    assert opts.verbose == True
    assert opts.username == "user"
    assert opts.password == "pass"


# Generated at 2022-06-12 19:02:46.106496
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    sys.argv = [sys.argv[0], '-c', '--extract-audio', '--batch-file', '-']
    parser, opts, args = parseOpts()
    print(opts)
    assert opts.cookiefile == '-'
    assert opts.batchfile == '-'
    assert opts.extractaudio == True

# TODO: remove the following code

# Generated at 2022-06-12 19:02:59.490532
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test(argv, expected):
        parser, opts, args = parseOpts(argv.split())
        out = []
        for short_a, long_a, dest in parser.option_list:
            out.append((short_a, long_a, getattr(opts, dest)))
        if out != expected:
            raise ValueError('%r != %r' % (out, expected))
    _test([], [])
    _test(['-b', '-'], [('-b', '--batch-file', '-')])
    _test(['-b', '-'], [('-b', '--batch-file', '-')])

# Generated at 2022-06-12 19:03:04.099420
# Unit test for function parseOpts
def test_parseOpts():
    from . import update
    import doctest
    parser, opts, args = parseOpts([])
    sys.argv = ['']
    update.noninteractive_update(parser, opts)
    return doctest.testmod()



# Generated at 2022-06-12 19:03:14.386769
# Unit test for function parseOpts
def test_parseOpts():
    for s in ['--username=user', '--username', 'user', '--username', 'user', 'arg']:
        parser, opts, args = parseOpts([s])
        assert opts.username == 'user'
        assert args == ['arg']
    for s in ['--password=pass', '--password', 'pass', '--password', 'pass', 'arg']:
        parser, opts, args = parseOpts([s])
        assert opts.password == 'pass'
        assert args == ['arg']
    for s in ['--ap-password=pass', '--ap-password', 'pass', '--ap-password', 'pass', 'arg']:
        parser, opts, args = parseOpts([s])
        assert opts.ap_password == 'pass'
        assert args == ['arg']

# Generated at 2022-06-12 19:03:24.870869
# Unit test for function parseOpts
def test_parseOpts():
    def test_parse_opts(args, expected_opts):
        """
        args: List of arguments to parse.
        expected_opts: Parsed opts from running parseOpts() with the given args.
        """
        parser, opts, _ = parseOpts(overrideArguments=args)
        for attr, expected_value in expected_opts.items():
            assert getattr(opts, attr) == expected_value, \
                'Expected {}={}, but it was {}={}'.format(
                    attr, expected_value, attr, getattr(opts, attr))


# Generated at 2022-06-12 19:03:26.359498
# Unit test for function parseOpts
def test_parseOpts():
    write_string(repr(parseOpts([])))


# Generated at 2022-06-12 19:03:45.501662
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print(parser)
    print(opts)

# Generated at 2022-06-12 19:03:54.194207
# Unit test for function parseOpts
def test_parseOpts():
    d = args2url('-f mp4 http://www.youtube.com/watch?v=BaW_jenozKc')
    assert d == 'http://www.youtube.com/watch?v=BaW_jenozKc'

    d = args2url('-f 22 url_with_underscores')
    assert d == 'url_with_underscores'

    d = args2url('-o dest the_rest')
    assert d == 'the_rest'

    d = args2url('--max-downloads 1 random_args1 random_args2')
    assert d == 'random_args1'

    d = args2url('--output-template %(id)s.%(ext)s random_args1 random_args2')
    assert d == 'random_args1'
# Return the full path to

# Generated at 2022-06-12 19:03:59.138130
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.version == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.search_archives == True


# Generated at 2022-06-12 19:04:04.443481
# Unit test for function parseOpts
def test_parseOpts():
    opts, _ = parseOpts()
    assert opts.username == None
    assert opts.usernames == None
    opts, _ = parseOpts(["-u", "foo", "--username", "bar"])
    assert opts.username == "foo"
    assert opts.usernames == ["foo", "bar"]


# Generated at 2022-06-12 19:04:16.299483
# Unit test for function parseOpts
def test_parseOpts():
    def test(*args, **kwargs):
        print('Testing with %s %s' % (args, kwargs))
        parser, opts, args = parseOpts(*args, **kwargs)
        print('opts: %s' % opts)
        print('args: %s' % args)
    test()
    test('-i', '-u', 'user', '-p', 'pass', '--yes-playlist', 'foo', 'bar', '-f', '37', '-f', '38', 'https://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-12 19:04:19.559200
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert parser
    assert opts
    assert args

# Download a given URL.  Returns a list of FileDownloads.

# Generated at 2022-06-12 19:04:32.367338
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = _parseOpts(args)
        assert vars(opts) == expected_opts
        assert args == expected_args


# Generated at 2022-06-12 19:04:35.766260
# Unit test for function parseOpts
def test_parseOpts():
    # I don't know how to write unit test for this function,
    # since it is strongly affected by the values of variables
    # like "preferredencoding" and "sys.argv"
    pass


# Generated at 2022-06-12 19:04:46.167481
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-i', '-vf', '-a', 'abc'])
    assert opts.ignoreerrors
    assert opts.verbose
    assert opts.simulate
    assert opts.geturl
    assert opts.gettitle
    assert opts.getid
    assert opts.getthumb
    assert opts.getdescription
    assert opts.getfilename
    assert opts.get_format
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.videopassword is None
    assert opts.ap_username is None
    assert opts.ap_password is None
    assert opts.usenetrc is False
    assert opts.proxy is None
    assert opts

# Generated at 2022-06-12 19:04:55.864517
# Unit test for function parseOpts
def test_parseOpts():
    from .compat import is_py2

    parser, opts, args = parseOpts(
        ['--verbose', '--extract-audio', '-i', '--batch-file=-', '-o', '%(title)s-%(id)s.%(ext)s', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.extractaudio
    assert opts.simulate
    assert not opts.forcejson
    assert opts.ignoreerrors
    assert opts.skip_download
    assert not opts.nooverwrites
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'

# Generated at 2022-06-12 19:05:36.897431
# Unit test for function parseOpts
def test_parseOpts():
    if __name__ == '__main__':
        opt = None
        parseOpts(['--format', '132+140', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
        parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc'])


# Generated at 2022-06-12 19:05:41.374682
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([
        '--output=%(uploader)s/%(title)s-%(id)s.%(ext)s',
        'https://www.youtube.com/watch?v=BaW_jenozKc'
    ])
    assert opts.outtmpl == os.path.expanduser('%(uploader)s/%(title)s-%(id)s.%(ext)s')


# Generated at 2022-06-12 19:05:48.502964
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-U', '"My User-Agent"'])
    assert opts.user_agent == 'My User-Agent'

    parser, opts, args = parseOpts(['-R', '5'])
    assert opts.retries == 5

    parser, opts, args = parseOpts(['--max-filesize', '1M'])
    assert opts.max_filesize == 1

    parser, opts, args = parseOpts(['--test'])
    assert opts.test

    parser, opts, args = parseOpts(['--playlist-start', '12'])
    assert opts.playliststart == 12

    parser, opt

# Generated at 2022-06-12 19:05:59.235725
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    fd, tmp_filename = tempfile.mkstemp()
    os.write(fd, b'--username="a" --password="b"\n')
    os.close(fd)

    def parse_with_conf_file(args, expected_args, expected_username, expected_password):
        parser, opts, new_args = parseOpts(args)
        os.unlink(tmp_filename)
        assert args[1:] == expected_args
        assert new_args[:-2] == expected_args
        assert new_args[-2] == expected_username
        assert new_args[-1] == expected_password

    os.environ['YOUTUBE_DL_CONFIG_FILE'] = tmp_filename

# Generated at 2022-06-12 19:06:04.828962
# Unit test for function parseOpts
def test_parseOpts():
    def _to_utf8(s):
        return s.encode('utf-8') if sys.version_info < (3,) else s

    def _normalize_args(args):
        return _hide_login_info(args)

    def _check_arguments(args, opt_name, opt_val):
        parsed_parser, parsed_opts, parsed_args = parseOpts(args)
        assert hasattr(parsed_opts, opt_name)
        assert getattr(parsed_opts, opt_name) == opt_val
        assert _normalize_args(args) == _normalize_args(parsed_args)

    _check_arguments(['--yes-playlist'], 'yes_playlist', True)

# Generated at 2022-06-12 19:06:08.130035
# Unit test for function parseOpts
def test_parseOpts():
    opts = None
    # TODO: More tests
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'cachedir': False})
    _parseOpts(ydl)
    assert opts is not None


# Generated at 2022-06-12 19:06:14.993159
# Unit test for function parseOpts
def test_parseOpts():
    'Test parseOpts by printing opts'
    print()

    import sys

    print(('python' + ' ' + sys.argv[0]))
    parser, opts, args = parseOpts([])
    print()
    print('opts:')
    print((opts))
    print()
    print('args:')
    print((args))
    print()


# Generated at 2022-06-12 19:06:24.453006
# Unit test for function parseOpts
def test_parseOpts():
    _, opts, _ = parseOpts([])
    assert opts and isinstance(opts, optparse.Values)
    _, opts, _ = parseOpts(['-h'])
    assert opts and isinstance(opts, optparse.Values)
    _, opts, _ = parseOpts(['--version'])
    assert opts and isinstance(opts, optparse.Values)
    _, opts, _ = parseOpts(['-U', 'foobar', '--no-warnings', 'bar'])
    assert opts and isinstance(opts, optparse.Values)
    assert opts.username == 'foobar'
    assert opts.password == 'bar'
    assert not opts.noprogress
    assert opts.verbose
    assert opts.quiet


# Generated at 2022-06-12 19:06:28.576966
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)
    opts, args = parseOpts(['--youtube-skip-dash-manifest'])
    assert opts.youtube_skip_dash_manifest

# Generated at 2022-06-12 19:06:40.870773
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeArgument
    parser, opts, args = parseOpts(overrideArguments=['--retries', '100', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert opts.retries == 100
    assert len(args) == 1
    parser, opts, args = parseOpts(overrideArguments=['--format', 'best', encodeArgument('--username'), 'foo', '--password', 'bar', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert len(args) == 1
    assert opts.usenetrc
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    from .compat import compat_getenv

# Generated at 2022-06-12 19:08:09.404183
# Unit test for function parseOpts
def test_parseOpts():
    # Unit test for function parseOpts

    def _normalize_opts(opts):
        return dict((k, v) for k, v in vars(opts).items() if k != 'proxies')

    def _test(args, expected_opts):
        parser, opts, args = parseOpts(args)
        assert not args
        actual_opts = _normalize_opts(opts)
        assert expected_opts == actual_opts


# Generated at 2022-06-12 19:08:11.985916
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: More tests
    parseOpts(['--version'])


# Generated at 2022-06-12 19:08:19.380361
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.verbose
    assert opts.outtmpl == '%(title)s.f%(format_id)s.%(ext)s'
    assert opts.age_limit == 18
    assert opts.usenetrc
    assert opts.noplaylist
    assert opts.retries >= 10
    assert opts.batchfile == '-'
    assert args == ['http://youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-12 19:08:27.211790
# Unit test for function parseOpts
def test_parseOpts():
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import _eligible_filename

    # Test output template
    parser, opts, args = parseOpts(['-o', 'abc%(autonumber)s-%(id)s-%(upload_date)s-%(title)s-%(alt_title)s-%(uploader)s-%(uploader_id)s.%(ext)s', 'url'])
    assert opts.outtmpl == 'abc%(autonumber)s-%(id)s-%(upload_date)s-%(title)s-%(alt_title)s-%(uploader)s-%(uploader_id)s.%(ext)s'
    assert args == ['url']

    #

# Generated at 2022-06-12 19:08:34.223360
# Unit test for function parseOpts
def test_parseOpts():
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument('--youtube-skip-dash-manifest')
    args = '--youtube-skip-dash-manifest'.split(' ')
    args = parser.parse_args(args)
    assert getattr(args, 'youtube_skip_dash_manifest'), "--youtube-skip-dash-manifest not set"


# Generated at 2022-06-12 19:08:44.438155
# Unit test for function parseOpts
def test_parseOpts():
    _, opts, _ = parseOpts(['-o', '%(artist)s - %(title)s.%(ext)s', '--no-mtime', '--metadata-from-title', '%(artist)s - %(title)s'])
    assert opts.outtmpl == '%(artist)s - %(title)s.%(ext)s'
    assert opts.metafromtitle == '%(artist)s - %(title)s'
    assert not opts.updatetime

# Global
params = None
fd = None

# Clean and unescape HTML strings

# Generated at 2022-06-12 19:08:54.996817
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parseOpts(arguments, expectedResult):
        # Unit test for function parseOpts
        parser, opts, args = parseOpts(arguments)
        # result = opts.__dict__
        result = {}
        for key in list(opts.__dict__):
            result[key] = opts.__dict__[key]
        assert result == expectedResult

# Generated at 2022-06-12 19:09:06.094689
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best' and opts.proxy == None and opts.simulate == False
    assert set(opts.extract_flat) == {'requested_formats', 'requested_subtitles'}

    # Test precedence (issue #47)
    parser, opts, args = parseOpts(['-f', 'best', '-c', '--no-continue',
                                    'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.continue_dl == False

# Generated at 2022-06-12 19:09:11.461219
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import path
    from tempfile import mkdtemp
    from shutil import rmtree
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import get_filesystem_encoding

    def _test_parseOpts(config):
        prevArgs = argv[1:]
        argv[1:] = config
        parser, opts, args = parseOpts()
        assert prevArgs == argv[1:]
        return parser, opts, args


# Generated at 2022-06-12 19:09:18.908822
# Unit test for function parseOpts
def test_parseOpts():
    parser, options, args = parseOpts(['-v', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(options, optparse.Values)
    assert options.verbose == True
    assert options.quiet == False
    assert options.verbose == True
    assert options.simulate == False
    assert options.geturl == False
    assert options.gettitle == False
    assert options.getid == False
    assert options.getthumb == False
    assert options.getdescription == False
    assert options.getfilename == False
    assert options.getformat == False
    assert options.usetitle == False
    assert options.autonumber == False
    assert options.autonumber_size == None
    assert options