

# Generated at 2022-06-12 19:00:03.900761
# Unit test for function parseOpts
def test_parseOpts():
    def test(opts, args, expected_opts, expected_args):
        # Dev note: in order to avoid tracking version changes
        # in the unit test data, the version is removed from the
        # opts.version in the expected_opts object.
        expected_opts = expected_opts.copy()
        expected_opts['version'] = None

        parser, opts, args = parseOpts(opts)
        assert vars(opts) == expected_opts
        assert args == expected_args


# Generated at 2022-06-12 19:00:13.748252
# Unit test for function parseOpts
def test_parseOpts():
    args = ['--username=foo', '--password=bar', 'https://www.youtube.com/watch?v=BaW_jenozKc']
    config = []
    opts = _real_main(parseOpts(args, config), args)
    assert config == []
    assert opts.username == 'foo'
    assert opts.password == 'bar'

    config = ['--username=foo_config']
    opts = _real_main(parseOpts(args, config), args)
    assert config == ['--username=foo_config']
    assert opts.username == 'foo'
    assert opts.password == 'bar'

    config = ['--username=foo_config', '--password=bar_config']
    opts = _real_main(parseOpts(args, config), args)

# Generated at 2022-06-12 19:00:24.396561
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['--match-title', 'ok'])[1].matchtitle == ['ok']
    assert parseOpts(['--format', 'best'])[1].format == 'best'
    assert parseOpts(['--format=best'])[1].format == 'best'
    assert parseOpts(['--get-url'])[1].geturl
    assert parseOpts(['--get-id'])[1].getid
    assert parseOpts(['--get-title'])[1].gettitle
    assert parseOpts(['--get-thumbnail'])[1].getthumbnail
    assert parseOpts(['--get-description'])[1].getdescription

# Generated at 2022-06-12 19:00:37.008942
# Unit test for function parseOpts
def test_parseOpts():
    # examples for tests
    _test_parseOpts_urls = (
        'https://www.youtube.com/watch?v=BaW_jenozKc',
        'http://youtube.com/v/BaW_jenozKc?version=3&hl=en_US',
        'http://youtu.be/BaW_jenozKc',
        'http://www.youtube.com/watch#!v=BaW_jenozKc',
    )

# Generated at 2022-06-12 19:00:49.826263
# Unit test for function parseOpts
def test_parseOpts():
    def s(opts):
        return ''.join(opts)

    assert s(parseOpts(['-v'])) == 'v'
    assert s(parseOpts(['-f', 'best', '-vv'])) == 'vfv'
    assert s(parseOpts(['--verbose'])) == 'v'
    assert s(parseOpts(['--output', 'test.%(ext)s'])) == 'o'
    assert s(parseOpts(['--output', 'test.%(ext)s', '--verbose'])) == 'ovo'
    assert s(parseOpts(['--output', 'test.%(ext)s', '-f', 'best'])) == 'of'

# Generated at 2022-06-12 19:00:58.951195
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--dump-user-agent', '--list-extractors'])
    assert opts.dump_user_agent
    assert opts.list_extractors
    assert not opts.usenetrc

    parser, opts, args = parseOpts(['--usenetrc', '--dump-user-agent', 'plop'])
    assert opts.dump_user_agent
    assert opts.usenetrc
    assert not opts.username
    assert not opts.password

    parser, opts, args = parseOpts(['-u', 'plop', '-p', 'plip'])
    assert opts.username == 'plop'
    assert opts.password == 'plip'


# Generated at 2022-06-12 19:01:12.089856
# Unit test for function parseOpts
def test_parseOpts():
    # Initialize
    import optparse
    from youtube_dl.utils import preferredencoding
    # Test loadOptions(self, optionsFile)
    assert _readOptions('test/youtube-dl.conf') == [u'--username=user', u'--password=pwd', u'--verbose']
    assert _readOptions('test/youtube-dl-bad.conf') == []
    assert _readOptions('test/youtube-dl-bad2.conf') == []
    # Test readUserConf()
    assert _readUserConf() == []
    # Test parseOpts()
    parser, opts, args = parseOpts(['--username=user', '--password=pwd', '--verbose'])
    assert isinstance(parser, optparse.OptionParser)
    assert opts.username == 'user'

# Generated at 2022-06-12 19:01:16.640884
# Unit test for function parseOpts
def test_parseOpts():
    #Test that the output is correct
    parser, opts, args = parseOpts()
    assert isinstance(parser,optparse.OptionParser)
    assert isinstance(opts,optparse.Values)
    assert isinstance(args,list)


# Generated at 2022-06-12 19:01:22.209840
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["--username", "mts", "--password", "mtspass", "--verbose"])
    assert opts.username == "mts"
    assert opts.password == "mtspass"
    assert opts.verbose == True


test_parseOpts()


# Generated at 2022-06-12 19:01:29.049045
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(overrideArguments = ['--verbose', '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1].verbose == True
    assert parseOpts(overrideArguments = ['--get-url', '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1].geturl == True
    assert parseOpts(overrideArguments = ['-4', '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1].forceipv4 == True
    assert parseOpts(overrideArguments = ['-6', '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1].forceipv

# Generated at 2022-06-12 19:01:52.154590
# Unit test for function parseOpts
def test_parseOpts():
    # Testing all the entries in the config file
    # From here: https://github.com/rg3/youtube-dl/blob/master/youtube_dl/YoutubeDL.py
    sys.argv = ['test']
    # Numeric parameters
    assert parseOpts(['-v'])[1].verbose == 1
    assert parseOpts(['--verbose'])[1].verbose == 1
    assert parseOpts(['-v', '-v'])[1].verbose == 2
    assert parseOpts(['-v', '-v', '--verbose', '--verbose'])[1].verbose == 4
    assert parseOpts(['--playlist-start', '42'])[1].playliststart == 42

# Generated at 2022-06-12 19:01:54.130283
# Unit test for function parseOpts
def test_parseOpts():
    global youtube_dl
    from youtube_dl import YoutubeDL
    youtube_dl = YoutubeDL()
    #parseOpts(None)

# Generated at 2022-06-12 19:01:57.943062
# Unit test for function parseOpts
def test_parseOpts():
    if __name__ == '__main__':
        try:
            if sys.argv[1] in ('-t', '--test'):
                assert parseOpts(['-t'])
                # TODO: add more tests
                exit(0)
        except (KeyboardInterrupt, EOFError):
            exit(1)



# Generated at 2022-06-12 19:01:59.299215
# Unit test for function parseOpts
def test_parseOpts():
    raise NotImplementedError
    #_parseOpts()


# Generated at 2022-06-12 19:02:09.121355
# Unit test for function parseOpts

# Generated at 2022-06-12 19:02:20.230848
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-e'])
    assert(opts.extract_flat is True)

    parser, opts, args = parseOpts(['--no-continue'])
    assert(opts.continue_dl is False)

    parser, opts, args = parseOpts(['--limit-rate', '10M'])
    assert(opts.ratelimit == '10M')

    parser, opts, args = parseOpts(['-c'])
    assert(opts.continue_dl is True)

    parser, opts, args = parseOpts(['-4'])
    assert(opts.forceipv4 is True)

    parser, opts, args = parseOpts(['-6'])
    assert(opts.forceipv6 is True)

   

# Generated at 2022-06-12 19:02:24.030846
# Unit test for function parseOpts
def test_parseOpts():
    # Initialize
    parser, opts, args = parseOpts()
    # Run test
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)


# Parse the command line arguments

# Generated at 2022-06-12 19:02:35.305539
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--get-url', '-v'])
    assert opts.geturl
    assert opts.verbose
    assert opts.usenetrc == False
    assert len(args) == 0

    parser, opts, args = parseOpts(['-u', 'testusr', '-p', 'testpwd', 'youtube.com'])
    assert opts.username == 'testusr'
    assert opts.password == 'testpwd'
    assert opts.usenetrc == False
    assert len(args) == 1
    assert args[0] == 'youtube.com'


# Generated at 2022-06-12 19:02:42.144004
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--verbose', '--extract-audio', '--audio-format', 'best', '--audio-quality', '0'])
    assert opts.verbose, "Should be true"
    assert opts.extractaudio, "Should be true"
    assert opts.audioformat == 'best', "Should be 'best'"
    assert opts.audioquality == '0', "Should be '0'"


# Generated at 2022-06-12 19:02:55.438833
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(overrideArguments=["-v", "--no-check-certificate", "--rate-limit", "90k", "https://www.youtube.com/watch?v=Ik-RsDGPI5Y"])
    assert opts.verbose is True, 'Error: opts.verbose is not set properly.'
    assert opts.nocheckcertificate is True, 'Error: opts.nocheckcertificate is not set properly.'
    assert opts.ratelimit == '90k', 'Error: opts.ratelimit is not set properly.'
    assert args == ['https://www.youtube.com/watch?v=Ik-RsDGPI5Y'], 'Error: args is not set properly.'


# Generated at 2022-06-12 19:03:29.353883
# Unit test for function parseOpts
def test_parseOpts():
    test_file = os.path.join(os.getcwd(), "test_parseOpts.txt")
    test_file_url = "https://raw.githubusercontent.com/ytdl-org/youtube-dl/master/README.md"
    test_file_url_2 = "https://raw.githubusercontent.com/ytdl-org/youtube-dl/master/LICENCE"
    test_file_url_3 = "https://youtube.com"
    with open(test_file, "w") as f:
        f.write(test_file_url + "\n")
        f.write(test_file_url_2 + "\n")
        f.write(test_file_url_3 + "\n")

# Generated at 2022-06-12 19:03:36.632226
# Unit test for function parseOpts
def test_parseOpts():
    getopt_err = None
    def getopt_sideeffect(a, b):
        if getopt_err is not None:
            raise getopt_err
        return [], []
    optparse_err = None
    def optparse_sideeffect():
        if optparse_err is not None:
            raise optparse_err
        return None, None, None
    with closing(StringIO()) as out:
        # Test handling of OptionError
        optparse_err = optparse.OptionError('test', 'msg')
        with patch('youtube_dl.YoutubeDL.parseOpts') as mock_parse_opts:
            mock_parse_opts.side_effect = optparse_sideeffect
            with patch('sys.stderr', out):
                with self.assertRaises(SystemExit):
                    parseOpts()


# Generated at 2022-06-12 19:03:37.692890
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts()


# Generated at 2022-06-12 19:03:48.042179
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--quiet', '--', 'http://github.com'])
    assert opts.quiet == True
    assert opts.verbose == False
    assert opts.forceurl == False
    assert args == ['http://github.com']

    opts.quiet = False
    opts.verbose = True
    opts.forceurl = True
    parser, opts, args = parseOpts(['--ignore-config', '--username', 'uname', '--password', 'pwd', '-g', '--get-url', '--', 'http://youtube.com'])
    assert opts.username == 'uname'
    assert opts.password == 'pwd'
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opt

# Generated at 2022-06-12 19:03:49.372615
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts()

# Unit tests for function _readOptions

# Generated at 2022-06-12 19:03:57.022432
# Unit test for function parseOpts

# Generated at 2022-06-12 19:04:08.527780
# Unit test for function parseOpts

# Generated at 2022-06-12 19:04:20.848532
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info[0] < 3:
        return

    import io
    import unittest.mock
    from tempfile import NamedTemporaryFile

    from .compat import compat_str


# Generated at 2022-06-12 19:04:23.718868
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-U'])[1]
    assert opts.usenetrc
test_parseOpts()


# Generated at 2022-06-12 19:04:36.050000
# Unit test for function parseOpts
def test_parseOpts():
    from .__main__ import parseOpts
    from .common import AgeRestrictedError

    parser, opts, args = parseOpts([
        '--username=foo', '--password=bar',
        '--youtube-skip-dash-manifest', '--no-check-certificate',
        'http://youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.skip_dash_manifest
    assert not opts.check_certificate
    assert args == ['http://youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-12 19:05:59.109808
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-U', 'foo', '-P', 'bar', '-p', 'x', 'y'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.playliststart == 'x'
    assert opts.playlistend == 'y'
    assert opts.ratelimit == '1.0'

    opts, args = parseOpts(['-i', '-r', '10.1'])
    assert opts.usenetrc
    assert opts.ratelimit == '10.1'

    opts, args = parseOpts(['-v'])
    assert opts.verbose

    opts, args = parseOpts(['-q'])
    assert opts.quiet

    opts.format

# Generated at 2022-06-12 19:06:09.708725
# Unit test for function parseOpts
def test_parseOpts():
    def _getArgv(opts):
        opts_str = []
        for opt in opts:
            opts_str.append(opt)
            if len(opt) > 2 and opt[:2] == '--':
                pos = opt.find('=')
                if pos != -1:
                    opts_str.append(opt[pos+1:])
        return opts_str

    def _getOpts(parser, opts_str):
        return parser.parse_args(_getArgv(opts_str))[0]

    def _checkOpts(parser, opts_str, opts):
        parsed_opts = _getOpts(parser, opts_str)
        test_str = 'fails for "%s"' % ' '.join(opts_str)

# Generated at 2022-06-12 19:06:21.926223
# Unit test for function parseOpts

# Generated at 2022-06-12 19:06:32.325827
# Unit test for function parseOpts
def test_parseOpts():
    conf_location = os.path.join('tests', 'test.conf')
    conf_content = ['--username', 'dummy', '--password', 'dummy', '-v']

    with open(conf_location, 'w') as f:
        f.write('\n'.join(conf_content))

    opts, args = parseOpts([
        '-u', 'dummy', '-p', 'dummy', '--no-warnings',
        '--config-location', conf_location,
        'dummy_url'])

    os.remove(conf_location)

    assert opts.username == 'dummy'
    assert opts.password == 'dummy'
    assert opts.noprogress == False

# So that we don't have to handle errors when testing

# Generated at 2022-06-12 19:06:43.968950
# Unit test for function parseOpts
def test_parseOpts():
    def _get_conf(conf):
        CONF_BASENAME = 'youtube-dl.conf'
        conf_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), CONF_BASENAME)
        lines = open(conf_path).readlines()[1:]
        assert lines[0].startswith('#')
        lines = lines[1:]
        lines = [re.sub(r'^ *#.*$', '', l) for l in lines]
        conf_str = '\n'.join(lines)
        conf = re.sub(r'\n *\n', '\n', conf_str).strip()

# Generated at 2022-06-12 19:06:56.615211
# Unit test for function parseOpts
def test_parseOpts():

    def _hide_login_info(args):
        if args:
            args_wo_secret = re.sub(r'--username .*? --password .*? ', '--username XXXXXXXX --password XXXXXXXX ', ' '.join(args), flags=re.M)
            args_wo_username = re.sub(r'--username .*? ', '--username XXXXXXXX ', args_wo_secret, flags=re.M)
            args_wo_videopassword = re.sub(r'--video-password .*? ', '--video-password XXXXXXXX ', args_wo_username, flags=re.M)

# Generated at 2022-06-12 19:07:08.182528
# Unit test for function parseOpts

# Generated at 2022-06-12 19:07:11.254531
# Unit test for function parseOpts
def test_parseOpts():
    result = parseOpts(['-f', '22/18/17/best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert result[2] == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    assert result[1].format == '22/18/17/best'


# Generated at 2022-06-12 19:07:23.660992
# Unit test for function parseOpts
def test_parseOpts():
    from nose.tools import assert_equal
    from os.path import expanduser
    from .compat import compat_expanduser

    opts = parseOpts(['-UUSR', '-P'])[1]
    assert_equal(opts.username, 'USR')
    assert_equal(opts.password, None)

    opts = parseOpts(['-o', 'dummy.txt'])[1]
    assert_equal(opts.outtmpl, 'dummy.txt')

    opts = parseOpts(['-o', '$HOME/dummy.txt'])[1]
    assert_equal(opts.outtmpl, expanduser('$HOME/dummy.txt'.replace('$HOME', '~')))


# Generated at 2022-06-12 19:07:27.149906
# Unit test for function parseOpts
def test_parseOpts():
    try:
        import pytest
        assert parseOpts
    except ImportError:
        if os.environ.get('TRAVIS', False):
            return
        assert False
    assert parseOpts()
# This is used when running the program from the command line.

# Generated at 2022-06-12 19:08:55.977789
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username is None, 'parseOpts failed'



# Generated at 2022-06-12 19:09:02.349228
# Unit test for function parseOpts
def test_parseOpts():
    # Does not work for non-ASCII arguments
    # since that would require a dummy sys.argv
    # overrideArguments = ['--no-check-certificate', '--', 'абвгд']
    # parseOpts(overrideArguments)

    overrideArguments = ['--', '--batch-file', '-']
    _, opts, _ = parseOpts(overrideArguments)
    assert opts.batchfile == '-'



# Generated at 2022-06-12 19:09:04.507984
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)


# Generated at 2022-06-12 19:09:13.836331
# Unit test for function parseOpts
def test_parseOpts():
    from types import GeneratorType

    opts = parseOpts([])[1]
    assert opts.usenetrc is None
    assert opts.username is None
    assert opts.password is None
    assert opts.videopassword is None

    opts = parseOpts(['-u', 'foo', '--password', 'bar'])[1]
    assert opts.usenetrc is False
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.videopassword is None

    opts = parseOpts(['--username', 'foo', '--videopassword', 'bar'])[1]
    assert opts.usenetrc is False
    assert opts.username == 'foo'
    assert opts.password is None

# Generated at 2022-06-12 19:09:25.022736
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts( ['-o', '/foo/bar.txt', 'http://www.youtube.com/watch?v=BaW_jenozKc'] )
    assert opts.outtmpl == '/foo/bar.txt'
    #assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'

    parser, opts, args = parseOpts( ['-o', '/foo/bar.txt', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'] )
    assert opts.outtmpl == '/foo/bar.txt'
    #assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'

    parser, opts, args = parseOpt