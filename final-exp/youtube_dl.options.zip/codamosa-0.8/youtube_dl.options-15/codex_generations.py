

# Generated at 2022-06-12 19:00:13.779264
# Unit test for function parseOpts
def test_parseOpts():
    class Options:
        def __init__(self, *args, **kwargs):
            self.__dict__.update(*args, **kwargs)

    def test_batchfile_content(batchfile_content):
        opts, args, _ = parseOpts(['--batch-file', '-'], overrideArguments=[batchfile_content])
        return (opts, args)


# Generated at 2022-06-12 19:00:24.439520
# Unit test for function parseOpts
def test_parseOpts():
    help_re = re.compile(r'^[Uu]sage:', re.MULTILINE)
    options_re = re.compile(r'^(Options|[Uu]sage):', re.MULTILINE)

    def assertEmptyUsage(parser):
        assert not help_re.search(parser.format_help())

    def assertOptions(parser, *args):
        intro, options = options_re.split(parser.format_help(), maxsplit=1)
        assert 'Options:\n' in intro
        assert options.startswith('\n'.join(args))

    parser, opts, args = parseOpts()

    # Test default
    assertEmptyUsage(parser)

    # Test --help
    parser, opts, args = parseOpts(['--help'])
    assertEmpty

# Generated at 2022-06-12 19:00:37.003917
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import OptionParser
    parser, opts, args = parseOpts(['--username', 'test', '--password', 'test', 'http://test.com'])
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert args == ['http://test.com']
    parser, opts, args = parseOpts(['-f', '22/18/17/best', 'http://test.com'])
    assert opts.format == '22/18/17/best'
    parser, opts, args = parseOpts(['--format=22/18/17/best', 'http://test.com'])
    assert opts.format == '22/18/17/best'

# Generated at 2022-06-12 19:00:40.164512
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)
    assert 'youtube-dl' in opts.user_agent


# Generated at 2022-06-12 19:00:52.810832
# Unit test for function parseOpts
def test_parseOpts():
    from .YoutubeDL import YoutubeDL

# Generated at 2022-06-12 19:00:55.037289
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-v'])[1].verbose



# Generated at 2022-06-12 19:01:07.916827
# Unit test for function parseOpts
def test_parseOpts():
    # Test fix for
    # http://code.google.com/p/youtube-dl/issues/detail?id=1905
    # https://github.com/rg3/youtube-dl/issues/4923
    def _test(opts, conf_filename, conf_data, conf_options, conf_args, expected_output_options, expected_output_args):
        write_string = _encodeFilename(sys.stdout)
        opts = opts or []
        conf_data = conf_data or []

        def _raise(s):
            raise ValueError(s)

        def _readOptions(fn):
            if fn == '/etc/youtube-dl.conf':
                return list(opts + conf_data)
            elif fn == conf_filename:
                return conf_options

# Generated at 2022-06-12 19:01:20.843509
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: Use unittest & run this test in Travis
    def opts_arg(option, return_first=True):
        if option in sys.argv:
            index = sys.argv.index(option)
            if index + 1 < len(sys.argv):
                if return_first:
                    return sys.argv[index + 1]
                else:
                    return sys.argv[index + 1: ]
        return None

    if '--test-parseOpts' not in sys.argv:
        return
    elif opts_arg('--test-parseOpts') == '-':
        sys.argv.remove('--test-parseOpts')
    elif opts_arg('--test-parseOpts'):
        sys.argv.remove('--test-parseOpts')


# Generated at 2022-06-12 19:01:33.262595
# Unit test for function parseOpts
def test_parseOpts():
    # Test for "--verbose"
    ydl = YoutubeDL({ 'verbose': True })
    parser, opts, _ = parseOpts(ydl, overrideArguments=['--verbose'])
    assert opts.verbose
    ydl = YoutubeDL({ 'verbose': False })
    parser, opts, _ = parseOpts(ydl, overrideArguments=['--verbose'])
    assert opts.verbose
    ydl = YoutubeDL({ 'verbose': True })
    parser, opts, _ = parseOpts(ydl)
    assert opts.verbose
    ydl = YoutubeDL({ 'verbose': False })
    parser, opts, _ = parseOpts(ydl)
    assert not opts.verbose

    # Test for "--yes-playlist"

# Generated at 2022-06-12 19:01:35.908216
# Unit test for function parseOpts
def test_parseOpts():
    parser, t_opts, t_args = parseOpts([])
    assert t_opts == parser.get_default_values()
test_parseOpts()



# Generated at 2022-06-12 19:01:58.039360
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = [sys.argv[0]]
    print(parseOpts())
    print(sys.argv)
    sys.argv = sys.argv[:1]
    print(parseOpts(['-h']))
    print(sys.argv)
#test_parseOpts()


# Generated at 2022-06-12 19:02:07.915727
# Unit test for function parseOpts
def test_parseOpts():
    # test with empty overrideArguments
    overrideArguments = []
    parser, opts, args = parseOpts(overrideArguments)
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.ap_password == None
    assert opts.ap_username == None
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.quiet == False
    assert opts.get_duration == False
    assert opts.simulate == False
    assert opts.skip_download == False
   

# Generated at 2022-06-12 19:02:15.124100
# Unit test for function parseOpts
def test_parseOpts():
    def check(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected
        assert not opts.usenetrc
    check(['-f', '22/mp4/720p'], {'format': '22/mp4/720p', 'forceformat': False, 'outtmpl': u'%(id)s.%(ext)s', 'usenetrc': False, 'progress_with_newline': True})
    check(['--username', 'foo', '--password', 'bar'], {'username': 'foo', 'password': 'bar', 'usenetrc': False, 'progress_with_newline': True})

# Generated at 2022-06-12 19:02:25.418658
# Unit test for function parseOpts
def test_parseOpts():
    global _opts
    global _args
    global _write_string

    # Run unit tests with a fake sys.argv
    def mock_parse_args(argv):
        global _opts
        global _args
        parser, opts, args = parseOpts(overrideArguments=argv)
        _opts = opts
        _args = args
        return None, None

    tempstr = 'running'
    def mock_write_string(s):
        global tempstr
        tempstr += s

    # Setup the mock
    _write_string = mock_write_string
    sys.argv = ['youtube-dl', '--version']
    sys.modules['__main__']._opts = None
    sys.modules['__main__']._args = None

# Generated at 2022-06-12 19:02:30.734299
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(overrideArguments = [])


# Modified version of urlparse.urljoin (issue #1735)
# Python 2.7.9 and 3.4.3 do not tacle ':' in relative paths

# Generated at 2022-06-12 19:02:42.546309
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['--format=22/18'])[1].format == ['22', '18']
    assert parseOpts(['--format=22/mp4/18/flv/best'])[1].format == ['22/mp4', '18/flv', 'best']
    assert parseOpts(['--format=22/mp4/18/flv/best/'])[1].format == ['22/mp4', '18/flv', 'best']
    assert parseOpts(['--format=22/mp4/18/flv/best'])[1].outtmpl == '%(id)s.%(ext)s'

# Generated at 2022-06-12 19:02:56.144856
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--simulate', '--get-title', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.simulate
    assert opts.gettitle
    assert len(args) == 1

    parser, opts, args = parseOpts(['-v', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert len(args) == 1

    parser, opts, args = parseOpts(['--username', 'hdsjkfhsdfjkhsf', '--password', '1234', '-v', 'https://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-12 19:03:08.392915
# Unit test for function parseOpts
def test_parseOpts():
    if __name__ == '__main__':
        opts, args = parseOpts(['url1', 'url2'])
        assert opts.processes == 1
        assert args == ['url1', 'url2']

        opts, args = parseOpts(['url1', '--get-title', 'url2'])
        assert opts.gettitle
        assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
        assert args == ['url1', 'url2']

        opts, args = parseOpts(['--get-id', 'url1'])
        assert opts.getid
        assert opts.outtmpl == '%(id)s'
        assert args == ['url1']


# Generated at 2022-06-12 19:03:14.089697
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(overrideArguments = ['-v', '-U', 'naughtybot', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'naughtybot'
    assert opts.verbose == True
    assert opts.extractaudio == False
    assert opts.simulate == False


# Generated at 2022-06-12 19:03:21.679077
# Unit test for function parseOpts
def test_parseOpts():
    try:
        parser, opts, args = parseOpts(overrideArguments = ['-F', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    except (optparse.OptionError, TypeError) as err:
        assert False, 'parseOpts raised an exception: %r' % (err)

test_parseOpts()
# Functions for writing strings and bytes to stdout/stderr, handling encodings and removing BOM
# The following code is partially from http://stackoverflow.com/a/4546129/35070
# Some code is from http://stackoverflow.com/a/17974659/35070
# Some code (write_bytes) is from http://stackoverflow.com/a/3693879/35070

# Generated at 2022-06-12 19:03:49.973622
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parseOpts(args, expected_opts):
        expected_opts = expected_opts.copy()
        parser, opts, args = parseOpts(overrideArguments=args)
        for k, v in expected_opts.items():
            expected_opts[k] = getattr(opts, k)

# Generated at 2022-06-12 19:03:54.089499
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose == True
# end unit test



# Generated at 2022-06-12 19:04:06.471450
# Unit test for function parseOpts
def test_parseOpts():
    """
        Unit test for youtube_dl.parseOpts
    """
    # Check the default values
    parser, opts, args = parseOpts([])
    assert opts.quiet == False
    assert opts.verbose == False
    assert opts.username == None
    assert opts.password == None
    assert opts.usenetrc == False
    assert opts.verbose_count == 0
    assert opts._print_debug_header == False
    assert opts._print_debug_header_updated == True

    # Check the verbose options
    parser, opts, args = parseOpts(['-v'])
    assert opts.quiet == False
    assert opts.verbose == True
    assert opts.verbose_count == 1


# Generated at 2022-06-12 19:04:18.035558
# Unit test for function parseOpts
def test_parseOpts():
    from getpass import getpass

    parser, opts, args = parseOpts(['--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose

    parser, opts, args = parseOpts(['--username', 'foo', '--password', 'bar'])
    assert opts.username == 'foo'
    assert opts.password == getpass('Type account password and press return:')

    parser, opts, args = parseOpts(['--verbose', '--format', '42', '--format', '51', '--get-url', '--get-title', 'spam'])
    assert opts.format == ['42', '51']
    assert opts.geturl

# Generated at 2022-06-12 19:04:30.951740
# Unit test for function parseOpts
def test_parseOpts():
    # Tests with reading from the config file
    # Returns a tuple of 3 elements: (parser, options, arguments)
    # <Test 1: no overrideArguments>
    parser, opts, args = parseOpts (
        overrideArguments = None
    )
    # <Test 2: with overrideArguments>
    parser, opts, args = parseOpts (
        overrideArguments = ['-u', 'myuser', '-p', 'mypassword']
    )
    # <Test 3: with an invalid argument>
    parser, opts, args = parseOpts (
        overrideArguments = ['-z']
    )
    # <Test 4: with an invalid argument>

# Generated at 2022-06-12 19:04:37.417588
# Unit test for function parseOpts
def test_parseOpts():
    import argparse
    argv = ['--username=foo', '--password=bar', '--extract-audio', '--audio-format', 'mp3', '--audio-quality', '9', '--no-post-overwrites', '--verbose']
    a = parseOpts(overrideArguments=argv)
    print(a)


# Generated at 2022-06-12 19:04:44.582905
# Unit test for function parseOpts
def test_parseOpts():
    # assert parseOpts('-U a -P b'.split(' '))[1].username == 'a'
    assert parseOpts('-u a -p b'.split(' '))[1].username == 'a'
    assert parseOpts('-u a -p b'.split(' '))[1].password == 'b'
    assert parseOpts('--username a --password b'.split(' '))[1].username == 'a'
    assert parseOpts('--username a --password b'.split(' '))[1].password == 'b'



# Generated at 2022-06-12 19:04:54.924851
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import SearchInfoExtractor
    from youtube_dl.extractor import gen_extractors
    _downloader = YoutubeDL(params={'simulate': True})
    _default_search_extractor = SearchInfoExtractor()
    _available_extractors = gen_extractors()

    # Basic tests
    (_, opts, args) = parseOpts(['-v', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert len(args) == 1
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'

    # Test that --version option works
    (_, opts, _) = parseOpt

# Generated at 2022-06-12 19:05:06.031566
# Unit test for function parseOpts
def test_parseOpts():
    from io import BytesIO
    from tempfile import mkstemp
    import os

    try:
        import gzip
    except ImportError:
        gzip = None

    try:
        import bz2
    except ImportError:
        bz2 = None

    def _test_parse_opts(args, expected_result):
        expected_result = compat_str(expected_result)
        if sys.version_info >= (3,):
            expected_result = expected_result.encode(preferredencoding())

        temp_fd, temp_filename = mkstemp()
        os.close(temp_fd)

# Generated at 2022-06-12 19:05:12.171615
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(
        ['--simulate', 'http://foo.com/watch?v=BaW_jenozKc'])
    eq(opts.simulate, True)
    eq(opts.format, None)
    eq(opts.geturl, False)
    eq(opts.nooverwrites, False)
    eq(opts.quiet, False)
    eq(opts.outtmpl, None)
    eq(opts.ratelimit, None)
    eq(opts.retries, 10)
    eq(opts.skip_download, False)
    eq(opts.dump_intermediate_pages, False)
    eq(opts.write_intermediate_pages, False)
    eq(opts.max_sleep_interval, None)


# Generated at 2022-06-12 19:05:40.749713
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import prepend_extension
    parser, opts, args = parseOpts()
    assert opts.simulate
    assert opts.format == 'best'
    assert opts.max_filesize == '10m'
    assert opts.outtmpl == '%(stitle)s-%(id)s.%(ext)s'
    assert opts.autonumber_size == 2
    assert opts.autonumber_start == 42
    assert opts.writedescription
    assert opts.writeinfojson
    assert opts.writethumbnail
    assert opts.write_all_thumbnails
    assert opts.call_home
    assert opts.embedsubtitles
    assert opts.ignoreerrors
    assert opts.ratelimit == '4200k'
    assert opt

# Generated at 2022-06-12 19:05:46.777502
# Unit test for function parseOpts

# Generated at 2022-06-12 19:05:58.019091
# Unit test for function parseOpts
def test_parseOpts():
    def _test(test_case, expected):
        if not os.path.exists(fname):
            with open(fname, 'wb') as f:
                f.write(test_case)
        write_string = io.BytesIO()
        if sys.version_info >= (3,):
            write_string = io.StringIO()
        _, opts, _ = parseOpts(['--config-location', fname], write_string)
        assert write_string.getvalue() == expected
    fname = os.path.join(os.path.dirname(__file__), 'test_parseOpts.conf')

# Generated at 2022-06-12 19:06:09.021727
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info < (3,):
        def u(s):
            return s.decode('unicode_escape')
    else:
        def u(s):
            return s

    # Test --ignore-config
    assert parseOpts(['--ignore-config', '--extract-audio'])[2] == []
    assert parseOpts(['--ignore-config', '--no-playlist', '--yes-playlist'])[2] == []
    assert parseOpts(['--ignore-config', '--yes-playlist', '--no-playlist'])[2] == []
    assert parseOpts(['--ignore-config', '--no-playlist'])[2] == ['--no-playlist']

# Generated at 2022-06-12 19:06:21.153202
# Unit test for function parseOpts
def test_parseOpts():
    import warnings
    warnings.simplefilter('error')
    test_parseOpts.count += 1
    print("[a-zA-Z0-9]*Test #%d" % test_parseOpts.count)
    parser, opts, args = parseOpts(shlex.split("-v"))
    assert opts.verbose == True
    parser, opts, args = parseOpts(shlex.split("-v -v -v"))
    assert opts.verbose == True
    parser, opts, args = parseOpts(shlex.split("--verbose"))
    assert opts.verbose == True
    parser, opts, args = parseOpts(shlex.split("--no-verbose"))
    assert opts.verbose == False

# Generated at 2022-06-12 19:06:25.783428
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    if opts.extractaudio and opts.audioformat == "best":
        opts.audioformat = None
    if not opts.outtmpl:
        opts.outtmpl = "%(title)s-%(id)s.%(ext)s"
    opts.outtmpl = opts.outtmpl.replace("%(stitle)s", "%(title)s")

# Generated at 2022-06-12 19:06:38.263708
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(overrideArguments=['-h'])[1]
    assert opts.help == True
    opts = parseOpts(overrideArguments=['-v'])[1]
    assert opts.verbose == True
    opts = parseOpts(overrideArguments=['--v'])[1]
    assert opts.verbose == True
    opts = parseOpts(overrideArguments=['--v','--version'])[1]
    assert opts.verbose == True
    assert opts.version == True
    if locale.getlocale() == (None, None):
        locale.setlocale(locale.LC_ALL, str('en_US.UTF-8'))

# Generated at 2022-06-12 19:06:50.631613
# Unit test for function parseOpts
def test_parseOpts():
    assert len(sys.argv) == 1
    sys.argv = ['youtube-dl']
    parser, opts, args = parseOpts()
    assert len(sys.argv) == 1
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.usenetrc_machine == None
    assert opts.proxy == None
    assert opts.noprogress == False
    assert opts.playliststart

# Generated at 2022-06-12 19:06:59.813114
# Unit test for function parseOpts
def test_parseOpts():
    from types import ModuleType
    import unittest
    from . import _download_retry

    # Increase the maximum number of writes to stdout/err to test debug output
    unittest.util._MAX_LENGTH = 10000


    class FakeModule:
        def __init__(self, name):
            self.__name__ = name

    class FakeInfoModule(FakeModule):
        def __init__(self):
            FakeModule.__init__(self, 'youtube_dl.extractor.common')
            self.params = {
                'username': 'test',
                'password': 'test',
                'videopassword': 'test',
                'access_token': 'test',
                'client_secret': 'test',
            }
            self.IE_DESC = 'FAKE'


# Generated at 2022-06-12 19:07:10.319474
# Unit test for function parseOpts
def test_parseOpts():
    # test_parseOpts_default_params
    opts, args = parseOpts()
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.no_warnings is False
    assert opts.forceurl is False
    assert opts.forcetitle is False
    assert opts.forcethumbnail is False
    assert opts.forcedescription is False
    assert opts.forcefilename is False
    assert opts.forcejson is False
    assert opts.dump_single_json is False
    assert opts.geo_bypass is False
    assert opts.no_geo_bypass is False
    assert opts.geo_verification_proxy is None
    assert opts.username is None
    assert opts.password is None
    assert opts.twof

# Generated at 2022-06-12 19:08:03.726938
# Unit test for function parseOpts
def test_parseOpts():
    parser, options, args = parseOpts(overrideArguments=['-h'])

    assert(options.help == True)

    parser, options, args = parseOpts(overrideArguments=['--proxy', 'localhost'])

    assert(options.proxy == 'localhost')

    parser, options, args = parseOpts(overrideArguments=['--version'])

    assert(options.version == True)

    parser, options, args = parseOpts(overrideArguments=['-U', 'bogususeragent'])

    assert(options.user_agent == 'bogususeragent')

    parser, options, args = parseOpts(overrideArguments=['--ignore-errors'])

    assert(options.ignoreerrors == True)


# Generated at 2022-06-12 19:08:09.586499
# Unit test for function parseOpts
def test_parseOpts():
    # parseOpts, parse_codecs_list
    _, opt, _ = parseOpts(['-F', '-f', 'bestvideo', '--format', 'bestvideo+bestaudio'])
    assert opt.format == 'best'

    _, opt, _ = parseOpts(['-F', '-f', 'bestvideo', '--format', 'bestvideo+bestaudio/best'])
    assert opt.format == 'best'

    _, opt, _ = parseOpts(['-F', '-f', 'bestvideo', '--format', 'bestvideo+bestaudio/best/worst[protocol^=http_dash_segments]'])
    assert opt.format == 'best/worst[protocol^=http_dash_segments]'


# Generated at 2022-06-12 19:08:21.551859
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import prepend_extension
    from youtube_dl.compat import compat_str

    parser, opts, args = parseOpts(['--max-filesize', '2', 'm', '-o', '%(title)s-%(id)s.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    assert opts.max_filesize == '2m'
    # assert opts.outtmpl == compat_str(u'%(title)s-%(id)s.%(ext)s')

# Generated at 2022-06-12 19:08:33.911407
# Unit test for function parseOpts
def test_parseOpts():
    """
    Test the correct options parsing of parseOpts
    """


# Generated at 2022-06-12 19:08:35.306766
# Unit test for function parseOpts
def test_parseOpts():
    pass

# Function to start youtube-dl

# Generated at 2022-06-12 19:08:47.959328
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO

    def parseOpts(*args, **kwargs):
        opts = parseOpts_orig(*args, **kwargs)
        return opts[0], opts[1]

    orig_stderr = sys.stderr
    orig_stdout = sys.stdout
    sys.stderr = StringIO()
    sys.stdout = StringIO()

# Generated at 2022-06-12 19:08:56.141083
# Unit test for function parseOpts
def test_parseOpts():
    opt_parser = optparse.OptionParser()
    opt_parser.add_option('-C', dest='call_home', action='store_true')
    opt_parser.add_option('-d', dest='debug_printtraffic', action='store_true')
    (_, opts, t_args) = parseOpts(['-d','--call-home','--no-check-certificate'])
    assert(opts.debug_printtraffic == True)
    assert(opts.call_home == True)
    assert(opts.nocheckcertificate == True)
    assert(t_args == [])


# Generated at 2022-06-12 19:08:59.752879
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-i', '-v', '--no-progress', '--'] + (['-u'] * 200) + (['http://www.youtube.com/watch?v=BaW_jenozKc'] * 200))

# Generated at 2022-06-12 19:09:08.549272
# Unit test for function parseOpts
def test_parseOpts():
    # Test without environment variables
    # Test with YOUTUBE_DL_CONFIG
    os.environ['YOUTUBE_DL_CONFIG'] = '/dev/null'
    # Test with and without --ignore-config
    # Test with --config-location
    # Test with and without --ignore-config
    # Test with YOUTUBE_DL_CONFIG and --ignore-config
    os.environ['YOUTUBE_DL_CONFIG'] = '/dev/null'
    # Test with YOUTUBE_DL_CONFIG and --config-location
    os.environ['YOUTUBE_DL_CONFIG'] = '/dev/null'



# Generated at 2022-06-12 19:09:16.463921
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    import shutil
    import os
    import sys
    tmpdir = tempfile.mkdtemp()
    system_conf = os.path.join(tmpdir, 'system_config')
    user_conf = os.path.join(tmpdir, 'user_config')
    custom_conf = os.path.join(tmpdir, 'custom_config')
    with open(system_conf, 'w') as f:
        f.write('--system-config\n')
    with open(user_conf, 'w') as f:
        f.write('--user-config\n')
    with open(custom_conf, 'w') as f:
        f.write('--custom-config\n')
