

# Generated at 2022-06-12 19:00:05.636002
# Unit test for function parseOpts
def test_parseOpts():
    opts1, args1 = parseOpts([
        '-u', 'testuser', '-p', 'testpass', '-v', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts1.username == 'testuser'
    assert opts1.password == 'testpass'
    assert opts1.verbose == True
    assert args1 == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    opts2, args2 = parseOpts([
        '--username', 'testuser', '--password', 'testpass', '--verbose', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts2.username == 'testuser'
    assert opts2.password

# Generated at 2022-06-12 19:00:14.585674
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', '--no-color', '-f', 'best', '--no-playlist', 'https://www.youtube.com/watch?v=jaJklRhzItM', '-c', 'http://www.youtube.com/watch?v=jaJklRhzItM'])
    assert opts.username == 'ytuser'
    assert opts.password == 'ytpass'
    assert opts.usenetrc is False
    assert opts.noplaylist is True
    assert opts.forceformat == 'best'
    assert opts.simulate is False
    assert opts.nocolor is True
    assert opts.outtmpl == '/dev/null'
    assert opts.quiet is False
    assert opts.verbose is False


# Generated at 2022-06-12 19:00:24.894028
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.extractor.youtube import YoutubeIE
    ie = YoutubeIE()
    def f(args, expected, desc):
        parser, opts, args = parseOpts(args)
        ret = [parser, opts, args]
        if ret != expected:
            err_fmt = 'parseOpts(%s) failed!\n\nGot:\n%s\n\nExpected:\n%s\n'
            raise AssertionError(err_fmt % (repr(args), pprint.pformat(ret), pprint.pformat(expected)))
    # Option value
    f(['-i'], [None, optparse.Values({'usenetrc': True}), []], 'usenetrc=True')
    # Alternative short option name

# Generated at 2022-06-12 19:00:37.050202
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.ap_username is None
    assert opts.ap_password is None
    if sys.platform == 'win32':
        assert opts.youtubedl_username is None
        assert opts.youtubedl_password is None


# Generated at 2022-06-12 19:00:49.877734
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    orig_argv = argv
    argv = 'youtube-dl -v --no-warnings foo bar'.split()
    assert parseOpts()[0].prog == 'youtube-dl'
    argv = 'youtube-dl'.split()
    assert parseOpts()[2] == []
    argv = 'youtube-dl -v --no-warnings foo bar'.split()
    assert parseOpts()[2] == ['foo', 'bar']
    argv = 'youtube-dl -v --no-warnings -f mp4 -F foo bar'.split()
    assert parseOpts()[1].format == 'mp4'
    argv = 'youtube-dl -v --no-warnings -f 0 -F foo bar'.split()

# Generated at 2022-06-12 19:00:59.051299
# Unit test for function parseOpts
def test_parseOpts():
    # Invalid:
    # --proxy socks5://192.168.3.1:9050 --proxy http://192.168.3.1:8192
    # --yes-playlist --no-playlist
    # --match-title a --no-match-title
    # --playlist-items 1 --playlist-items 1-3,7,10-
    assert parseOpts(['-vf', 'bestvideo[height<=720]+bestaudio/best[height<=720]']) == \
        parseOpts(['--recode-video', 'mp4', '--prefer-free-formats'])

# Generated at 2022-06-12 19:01:06.451831
# Unit test for function parseOpts
def test_parseOpts():
    p, o, a = parseOpts(['-u', 'user', '-p', 'pass',
                         'https://www.xxx.com/watch?v=BaW_jenozKc'])
    assert o.username == 'user'
    assert o.password == 'pass'
    assert a == ['https://www.xxx.com/watch?v=BaW_jenozKc']

# }}}

# {{{ Exit handling

# Generated at 2022-06-12 19:01:11.627340
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts()[1]
    assert opts.username is None
    opts = parseOpts(['--username', 'foo'])[1]
    assert opts.username == 'foo'
# /Unit test for function parseOpts


# Generated at 2022-06-12 19:01:15.594428
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts()
    assert opts.verbose
    assert opts.prefer_ffmpeg
    assert opts.retries == DEFAULT_RETRIES

# Generated at 2022-06-12 19:01:28.115682
# Unit test for function parseOpts
def test_parseOpts():
    conf1 = ['--username', 'foo', '--password', 'bar', '-i', '--yes-playlist', 'http://www.youtube.com/watch?v=BaW_jenozKc']
    conf2 = ['-v', '--username', 'foo', '--password', 'bar', '-i', 'foobar', '--yes-playlist', 'http://www.youtube.com/watch?v=BaW_jenozKc']
    conf3 = ['--youtube-skip-dash-manifest', 'http://www.youtube.com/watch?v=BaW_jenozKc']
    conf4 = ['-v', '--extract-audio', '--audio-format', 'mp3', 'http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-12 19:01:55.182617
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from os.path import isfile

#     # Test verbosity
#     argv[1:] = '-v'.split()
#     parser, opts, args = parseOpts()
#     assert opts.verbose == True
#     argv[1:] = '-q'.split()
#     parser, opts, args = parseOpts()
#     assert opts.verbose == False
#     argv[1:] = '--verbose'.split()
#     parser, opts, args = parseOpts()
#     assert opts.verbose == True
#     argv[1:] = '--quiet'.split()
#     parser, opts, args = parseOpts()
#     assert opts.verbose == False
#
#     # Test update


# Generated at 2022-06-12 19:02:02.134256
# Unit test for function parseOpts
def test_parseOpts():
    """
    Unit test for parseOpts
    """
    def test_parseOpts_impl(argv):
        parser, opts, _ = parseOpts(argv)
        if opts.format:
            if opts.format.startswith('+') or ('-' in opts.format and opts.format.startswith('mp4')):
                for opt in ('format_limit', 'listformats', 'list_thumbnails'):
                    if getattr(opts, opt):
                        parser.error('--format option (as well as + and mp4 options) is not allowed in combination with --%s.' % opt)

# Generated at 2022-06-12 19:02:11.977916
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeArgument
    from .extractor import gen_extractors
    utf8_bom = b'\xef\xbb\xbf'

# Generated at 2022-06-12 19:02:23.570316
# Unit test for function parseOpts
def test_parseOpts():
    # Test 1
    # Test cmd line args
    out = io.StringIO()
    sys.stdout = out
    parser, opts, args = parseOpts(['-F', '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    sys.stdout = sys.__stdout__

# Generated at 2022-06-12 19:02:36.807778
# Unit test for function parseOpts
def test_parseOpts():
    enc = preferredencoding()
    if enc is None:
        return
    if not os.path.isfile('test_utils.py'):
        return
    from .compat import compat_shlex_quote
    conf_dir = 'mydir'
    conf_file = os.path.join(conf_dir, 'youtube-dl.conf')
    # make the test work even if the user has youtube-dl.conf in the current directory
    os.mkdir(conf_dir)
    # Don't use write_string for this file as it would remove the quote character

# Generated at 2022-06-12 19:02:46.483435
# Unit test for function parseOpts
def test_parseOpts():
    from os.path import realpath, dirname, join, exists, basename
    from sys import modules
    tests_dir = dirname(realpath(__file__))
    opts_fname = join(tests_dir, 'options')
    opts_json_fname = opts_fname + '.json'
    if not exists(opts_json_fname):
        print('To test parseOpts() please place a plain text file named options in the tests directory containing a list of command line arguments, each of which should be quoted, e.g. --extract-audio --audio-format mp3')
    opts_str = open(opts_fname).read()
    command_line_conf = parse_qs(opts_str.replace(' ', '&'))

# Generated at 2022-06-12 19:02:55.603899
# Unit test for function parseOpts
def test_parseOpts():
    case0_overrideArguments = ['--version']
    expected0_parser = _getParser()
    expected0_opts = expected0_parser.get_default_values()
    expected0_args = []
    actual0_parser, actual0_opts, actual0_args = parseOpts(overrideArguments=case0_overrideArguments)
    assert actual0_parser == expected0_parser
    assert actual0_opts == expected0_opts
    assert actual0_args == expected0_args

# Generated at 2022-06-12 19:03:07.744692
# Unit test for function parseOpts
def test_parseOpts():
    dummy_sys = DummySystemModule()

# Generated at 2022-06-12 19:03:17.549721
# Unit test for function parseOpts
def test_parseOpts():
    '''
    parseOpts() behaves the same whether or not the user actually has a ~/.config/youtube-dl/config file
    '''
    # Define a config file
    config = [
        '[general]',
        '# This is a comment',
        'verbose = true',
        '',
        '[network]',
        'rate-limit = 42.0',
        'proxy = abc',
        '',
        '[geo-bypass]',
        'bypass-country = AU,DE,UA',
        'bypass-ip-block = True'
    ]

    # Create a fake user home directory and the fake .config/youtube-dl folder
    user_home_directory = tempfile.TemporaryDirectory(prefix='home')

# Generated at 2022-06-12 19:03:28.951183
# Unit test for function parseOpts
def test_parseOpts():
  from os.path import dirname, join

  test_file = join(dirname(__file__), 'test', 'opts_test.txt')
  test_output = join(dirname(__file__), 'test', 'opts_test_output.txt')
  opts_output = open(test_output).readlines()
  test_opts = open(test_file).readlines()
  test_opts = [o.strip() for o in test_opts]

  parser, opts, _ = parseOpts(test_opts)
  test_opts = sorted(str(o).strip() for o in parser.option_list)
  test_opts = '\n'.join(test_opts)
  assert opts_output == test_opts



# Generated at 2022-06-12 19:03:43.141524
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass


# Generated at 2022-06-12 19:03:45.300770
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts()

# Fix the optparse results
# Fixes the capitalisation of certain options that are returned by parseOpts()

# Generated at 2022-06-12 19:03:52.469725
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import NamedTemporaryFile
    from sys import version_info

    f = NamedTemporaryFile(mode='wt', delete=False)
    try:
        f.write(
            '--username "foo" --password "bar"'
            + ('' if version_info < (3,) else ' --encoding utf8')
        )
        f.close()
        _, opts, _ = parseOpts(['--config-location', f.name])
        assert opts.username == 'foo'
        assert opts.password == 'bar'
    finally:
        os.remove(f.name)

# Generated at 2022-06-12 19:03:58.942184
# Unit test for function parseOpts
def test_parseOpts():
    def test_opt(opts, name, value):
        opt = getattr(opts, name, None)
        if opt != value:
            raise ValueError('Invalid value for %s: got %r, expected %r' % (name, opt, value))

    parser, opts, _ = parseOpts([])

    test_opt(opts, 'usenetrc', False)
    test_opt(opts, 'username', None)
    test_opt(opts, 'password', None)
    test_opt(opts, 'verbose', False)
    test_opt(opts, 'quiet', False)
    test_opt(opts, 'simulate', False)
    test_opt(opts, 'skip_download', False)
    test_opt(opts, 'format', None)
    test_

# Generated at 2022-06-12 19:04:10.364733
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.usenetrc is None
    assert not hasattr(opts, 'username')
    parser, opts, args = parseOpts(['--username', 'foouser', '--password', 'foopass'])
    assert opts.username == 'foouser'
    assert opts.password == 'foopass'
    parser, opts, args = parseOpts(['--usenetrc'])
    assert opts.username is None
    assert opts.password is None
    assert opts.usenetrc

    parser, opts, args = parseOpts(['--usenetrc', '--username', 'baruser', '--password', 'barpass'])
    assert opts.username == 'baruser'
    assert opt

# Generated at 2022-06-12 19:04:22.725870
# Unit test for function parseOpts
def test_parseOpts():
    from unit import set_unit_testing
    set_unit_testing()

    # Check if youtube-dl.conf contains any sensitive data
    def has_sensitive_data(filename):
        try:
            with open(filename, 'r') as fd:
                content = fd.read()
                return any(s in content for s in ('username', 'password', 'login'))
        except (IOError, OSError):
            return False

    testdesc = 'Test parsing of options'
    test = lambda: do_test_parsing(arguments=['-U', 'FooBar'], exp_username='FooBar')
    yield test, testdesc

    testdesc = 'Test format selection of the main file'

# Generated at 2022-06-12 19:04:35.327398
# Unit test for function parseOpts
def test_parseOpts():
    from .common import get_synthesized_opts

    def run_test(opts_str, override_argv=None):
        parser, opts, args = parseOpts(override_argv)
        if override_argv is not None:
            override_argv = [a.decode(preferredencoding()) for a in override_argv]
        opts_exp = get_synthesized_opts(
            argv=override_argv, load_defaults=False,
            use_yt_dl=False, parse=parser.parse_args)

# Generated at 2022-06-12 19:04:45.885680
# Unit test for function parseOpts
def test_parseOpts():
    def get_parseOpts_config(conf):
        _, opts, _ = parseOpts([a.encode('utf-8') for a in conf])
        return opts

    def assert_parseOpts(conf, key, value):
        assert get_parseOpts_config(conf)[key] == value

    assert_parseOpts(['-o', 'ok'], 'outtmpl', 'ok')
    assert_parseOpts(['--yes-playlist'], 'noplaylist', False)
    assert_parseOpts(['--min-sleep-interval', '0.5'], 'min_sleep_interval', 0.5)
    assert_parseOpts(['--playlist-reverse'], 'playlistreverse', True)

# Generated at 2022-06-12 19:04:47.070872
# Unit test for function parseOpts
def test_parseOpts():
    parseOpts()



# Generated at 2022-06-12 19:04:47.781432
# Unit test for function parseOpts
def test_parseOpts():
    return


# Generated at 2022-06-12 19:05:21.681483
# Unit test for function parseOpts
def test_parseOpts():
    # 1. --- Test if override argument is set and it is valid
    _, opts, args = parseOpts(['-U', 'myuseragent'])
    assert opts.user_agent == 'myuseragent'

    # 2. --- Test if override argument is set and it is invalid
    try:
        _, opts, args = parseOpts(['-U'])
    except SystemExit:
        assert True
    else:
        assert False

    # 3. --- Test if command line arguments are valid (i.e. do not throw
    # exception)
    _, opts, args = parseOpts()

    # 4. --- Test if command line arguments are invalid (i.e. throw exception)

# Generated at 2022-06-12 19:05:25.221262
# Unit test for function parseOpts
def test_parseOpts():
    opts = {}
    args = {}
    try:
        opts, args = parseOpts()
        opts.verify_ssl_certificates = False
    except IOError as e:
        pass

    return opts, args



# Generated at 2022-06-12 19:05:35.718612
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = [sys.argv[0], '-i', '-u', 'up', '-p', 'pw', '-o', '%(id)s.%(ext)s', 'foo', 'bar']
    parser, opts, args = compat_parseOpts()
    assert opts.username == 'up'
    assert opts.password == 'pw'
    assert opts.outtmpl == '%(id)s.%(ext)s'
    assert args == ['foo', 'bar']
    assert '-u' not in sys.argv

    sys.argv = [sys.argv[0], '--username', 'up', '--password', 'pw', '--output', '%(id)s.%(ext)s', 'foo', 'bar']
    parser, opt

# Generated at 2022-06-12 19:05:41.415706
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    #assert parser == optparse.OptionParser()
    print("type(opts): " + str(type(opts)))
    print("type(args): " + str(type(args)))
    assert type(args) == type([])
    print("opts: " + str(opts))
    print("args: " + str(args))
    
# test_parseOpts()

# Generated at 2022-06-12 19:05:48.525623
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeArgument

    # Basic test
    assert parseOpts([])[1].getopt == []
    # Test that short options are expanded
    assert parseOpts(['-i', '-u', 'user', '-p', 'pass', '--get-url', 'www.youtube.com'])[1].getopt == [
        '--username=user', '--password=pass', '--get-url',
        '--youtube-skip-dash-manifest', 'www.youtube.com']
    # Test that long options are canonicalized
    assert parseOpts(['--ignore-errors'])[1].ignoreerrors == True
    assert parseOpts([encodeArgument('--ignore-errors')])[1].ignoreerrors == True

# Generated at 2022-06-12 19:05:59.235913
# Unit test for function parseOpts
def test_parseOpts():
    class FakeOptionParser(object):
        def __init__(self):
            self.option_groups = []

        def add_option_group(self, *args, **kwargs):
            group = FakeOptionGroup(*args, **kwargs)
            self.option_groups.append(group)
            return group

        def parse_args(self, *args, **kwargs):
            return ('opts', 'args')

    class FakeOptionGroup(object):
        def __init__(self, *args, **kwargs):
            self.options = []

        def add_option(self, *args, **kwargs):
            option = FakeOption(*args, **kwargs)
            self.options.append(option)
            return option


# Generated at 2022-06-12 19:06:04.800949
# Unit test for function parseOpts
def test_parseOpts():
    from nose.tools import raises
    from youtube_dl.YoutubeDL import YoutubeDL
    from optparse import OptionValueError

    opts0 = YoutubeDL().params
    for attr in opts0:
        if attr.startswith('_'):
            continue
        if hasattr(opts0[attr], '__call__'):
            continue
        assert getattr(parseOpts([])[1], attr) == opts0[attr], attr

    parser, opts, args = parseOpts(['-U', 'foobar', 'baz'])
    assert opts.usernames == ['foobar']
    assert opts.passwords == []
    assert opts.playliststart == 1
    assert opts.playlistend == 0
    assert args == ['baz']


# Generated at 2022-06-12 19:06:10.298573
# Unit test for function parseOpts
def test_parseOpts():
    from . import YoutubeDL
    opts_dict = {}
    opts_dict.update(YoutubeDL().default_params)
    for opt in opts_dict:
        if getattr(YoutubeDL().params, opt) != opts_dict[opt]:
            print(opt, getattr(YoutubeDL().params, opt), opts_dict[opt])
            assert False
# -#



# ##################################################################################################################
# YoutubeDL，下载器类
# ##################################################################################################################

# Generated at 2022-06-12 19:06:22.463752
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv, version_info
    if version_info >= (3,):
        # Test against a Python 3 command line
        parseOpts(argv=['-U', 'unit_tester', '-P', '1234', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    else:
        # Test against a Python 2 command line
        parseOpts(argv=['-U'.decode('utf-8'), 'unit_tester', '-P'.decode('utf-8'), '1234', 'https://www.youtube.com/watch?v=BaW_jenozKc'.decode('utf-8')])

    # Need a better integration test for parseOpts, as it doesn't
    #  return any value
    return True


# Generated at 2022-06-12 19:06:27.050735
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = ['youtube-dl', '-U','-o','%(id)s']
    parser, opts, args = parseOpts()
    print("test_parseOpts")
    print("opts.update_self:",opts.update_self)
    print("opts.outtmpl:",opts.outtmpl)

# Generated at 2022-06-12 19:07:31.844977
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = ['youtube-dl', 'https://www.youtube.com/watch?v=BaW_jenozKc', '-i', '-j', '--flat-playlist', '--dump-user-agent', '--ignore-config', '--rm-cache-dir']
    parser, opts, args = parseOpts()
    assert not opts.ignoreerrors
    assert opts.simulate
    assert opts.format == '0'
    assert opts.outtmpl == '%(id)s.%(ext)s'
    assert opts.ignoreconfig
    assert not opts.usenetrc
    assert opts.verbose
    assert opts.retries == 10
    assert opts.continuedl
    assert not opts.noprogress
    assert not opts.playlist

# Generated at 2022-06-12 19:07:39.921427
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert not hasattr(opts, 'matchtitle')
    assert not hasattr(opts, 'username')
    assert not hasattr(opts, 'verbose')

    parser, opts, args = parseOpts(['--username=test'])
    assert not hasattr(opts, 'username')
    assert opts.verbose == False

    parser, opts, args = parseOpts(['--verbose'])
    assert opts.username == None
    assert opts.verbose == True

    parser, opts, args = parseOpts(['--username=test', '--verbose'])
    assert opts.username == 'test'
    assert opts.verbose == True


# Generated at 2022-06-12 19:07:42.296421
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--autonumber-size=5', 'test'])
    assert opts.autonumber_size == 5


# Generated at 2022-06-12 19:07:49.486278
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([])[0].format_description('foo') == 'foo'
    assert parseOpts([])[1].verbose == False
    assert parseOpts([])[1].ignore_config == False
    assert parseOpts([])[1].simulate == False
    assert parseOpts(['-i'])[1].ignore_config == True
    assert parseOpts(['-s'])[1].simulate == True
    assert parseOpts(['--simulate'])[1].simulate == True
    assert parseOpts(['-v'])[1].verbose == True
    assert parseOpts(['--verbose'])[1].verbose == True


# from http://coreygoldberg.blogspot.de/2009/05/python-singleton-pattern_04.html

# Generated at 2022-06-12 19:08:00.759876
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from types import ListType
    try:
        from urllib.request import urlopen
    except:
        from urllib2 import urlopen
    from tempfile import NamedTemporaryFile
    from doctest import testmod
    parser, opts, args = parseOpts()
    assert type(args) == ListType, 'args is not a list'
    assert not args, 'arguments left in args'
    assert opts.usenetrc is False, '--no-usenetrc should be False by default'
    assert opts.verbose is False, '--verbose should be False by default'
    assert opts.quiet is False, '--quiet should be False by default'
    assert opts.simulate is False, '--simulate should be False by default'
    assert opts.skip

# Generated at 2022-06-12 19:08:10.230296
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert opts.format == None, "Assert format is empty"
    assert opts.proxy == None, "Assert proxy is empty"
    assert opts.username == None, "Assert username is empty"
    assert opts.password == None, "Assert password is empty"
    assert opts.outtmpl == '%(id)s', "Assert outtmpl is id"
    assert opts.usetitle == False, "Assert useTitle is false"
    assert opts.extractaudio == False, "Assert extractaudio is false"
    assert opts.audioformat == 'best', "Assert audioformat is best"
    assert opts.recodevideo == None, "Assert recodevideo is empty"

# Generated at 2022-06-12 19:08:21.595200
# Unit test for function parseOpts
def test_parseOpts():
    opts, _ = parseOpts('-f 22'.split())
    assert opts.format == '22'

    opts, _ = parseOpts('-f 22 -f best'.split())
    assert opts.format == 'best'

    opts, _ = parseOpts('-o -'.split())
    assert opts.outtmpl == '-'

    opts, _ = parseOpts('-o - -f 22'.split())
    assert opts.outtmpl == '-'
    assert opts.format == '22'

    opts, _ = parseOpts('-o - http://youtube.com'.split())
    assert opts.outtmpl == '-'
    assert opts.usenetrc is False
    assert opts.username is None
    assert opts.password is None
    assert opts

# Generated at 2022-06-12 19:08:26.157792
# Unit test for function parseOpts
def test_parseOpts():
    (p, o, a) = parseOpts()
    assert isinstance(p, optparse.OptionParser)
    assert isinstance(o, optparse.Values)
    assert isinstance(a, list)
    assert a == []
# test_parseOpts


# Generated at 2022-06-12 19:08:35.069890
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-x', '--verbose', '--username', 'test', '--password', 'pw', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.extractaudio is True
    assert opts.verbose == True
    assert opts.username == 'test'
    assert opts.password == 'pw'
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-12 19:08:47.683343
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import tempfile
    import shutil
    import os
    #import youtube_dl
    import traceback
    def _test_parseOpts(args, overrideArguments=None, retCode=0, confArgs=''):
        orig_stdout = sys.stdout
        fd, name = tempfile.mkstemp(prefix='youtube-dl-test-', suffix='.out')
        outfile = os.fdopen(fd, 'w')