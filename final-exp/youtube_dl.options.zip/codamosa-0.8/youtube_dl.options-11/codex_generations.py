

# Generated at 2022-06-12 19:00:07.711149
# Unit test for function parseOpts
def test_parseOpts():

    # This test will fail when any setting is changed in parseOpts
    sys.argv = ['youtube-dl', '-U']
    opts = parseOpts()[1]
    assert opts.version
    assert not opts.verbose
    assert not opts.quiet
    assert not opts.simulate
    assert not opts.format
    assert not opts.listformats
    assert not opts.username
    assert not opts.password
    assert not opts.twofactor
    assert not opts.videopassword
    assert not opts.ap_mso
    assert not opts.ap_username
    assert not opts.ap_password
    assert not opts.ratelimit
    assert not opts.nooverwrites
    assert not opts.retries
    assert not opts

# Generated at 2022-06-12 19:00:15.697854
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: test with file input and '-a' argument
    def getopts(args):
        parser, opts, args = parseOpts(args)
        return opts

    # test categories
    assert getopts(['--category', '22'])                      # int
    assert getopts(['--category', '1'])                       # one digit
    assert getopts(['--category', '10'])                      # two digits
    assert getopts(['--category', '1,2'])                     # two values
    assert getopts(['--category', '1', '--category', '2'])    # two values, separate options

    # test unknown arguments handling
    _, opts, _ = parseOpts(['--htmltitle'])
    assert opts.writedescription is True

# Generated at 2022-06-12 19:00:25.518078
# Unit test for function parseOpts
def test_parseOpts():
    def check_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args.split())
        if vars(opts) == expected_opts:
            write_string('Test passed: %s\n' % repr(args))
        else:
            write_string('Test failed: %s\n' % repr(args))


# Generated at 2022-06-12 19:00:37.173948
# Unit test for function parseOpts
def test_parseOpts():
    def assertEqualOptions(opt1, opt2):
        assertEqual = lambda x, y: assertEqual(x, y, '%s != %s' % (x, y))
        assertEqual(opt1.age_limit, opt2.age_limit)
        assertEqual(opt1.batchfile, opt2.batchfile)
        assertEqual(opt1.call_home, opt2.call_home)
        assertEqual(opt1.cachedir, opt2.cachedir)
        assertEqual(opt1.format, opt2.format)
        assertEqual(opt1.format_limit, opt2.format_limit)
        assertEqual(opt1.headers, opt2.headers)
        assertEqual(opt1.ignoreerrors, opt2.ignoreerrors)

# Generated at 2022-06-12 19:00:50.038226
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.username == None
    assert opts.password == None
    assert opts.write_sub == False
    assert opts.write_auto_sub == False
    assert opts.listformats == False
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumburl == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.get_format_descriptions == False
    assert opts

# Generated at 2022-06-12 19:00:58.393400
# Unit test for function parseOpts
def test_parseOpts():
    class FakeParser:
        def __init__(self):
            self.option_groups = []

        def add_option(self, *w, **kw):
            pass

        def add_option_group(self, group):
            self.option_groups.append(group)

        def parse_args(self, args):
            return (None, args)

    parser = FakeParser()
    opts, args = parseOpts(None, parser)
    assert opts == None
    assert args == []

    for group in parser.option_groups:
        assert len(group.option_list) > 0
        for option in group.option_list:
            assert isinstance(option, optparse.Option)


# Generated at 2022-06-12 19:01:11.577023
# Unit test for function parseOpts
def test_parseOpts():
    def test_output_template(output_template, expected_template):
        if isinstance(expected_template, tuple):
            expected_template, expected_downloader = expected_template
        else:
            expected_downloader = None

        _, opts, _ = parseOpts(['-o', output_template])
        assert opts.outtmpl == expected_template
        if expected_downloader:
            assert opts.postprocessor_args[0] == '-x'
            assert opts.postprocessor_args[1] == expected_downloader
        else:
            assert not opts.postprocessor_args

    test_output_template('abc', 'abc')

    # Correctly handles quotation marks
    test_output_template("'abc'", "abc")
    test_output_template("\"abc\"", "abc")



# Generated at 2022-06-12 19:01:18.347668
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.utils import _hide_login_info
    from youtube_dl.postprocessor import FFmpegMergerPP
    import os
    import tempfile
    import shutil

    def _readOptions(fname):
        """
        Read options from config file
        """
        options = []
        try:
            with open(compat_expanduser(fname), 'r') as config_file:
                options = config_file.read().split()
            if type(options) is str:
                options = options.decode('utf-8')
        except (IOError, OSError):
            return []
        return _hide_login_info(options)


# Generated at 2022-06-12 19:01:30.831171
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    the_args = ['--username', 'foo', '--password', 'bar']
    parser, opts, args = parseOpts(the_args)
    assert opts.username == 'foo' and opts.password == 'bar', 'Bug in option parsing'
    the_args = ['--usenetrc']
    parser, opts, args = parseOpts(the_args)
    assert opts.usenetrc is True and opts.username is None, 'Bug in option parsing'
    the_args = ['--username', 'foo', '--password', 'bar', '--usenetrc']
    parser, opts, args = parseOpts(the_args)
    assert opts.username == 'foo' and opts.password == 'bar', 'Bug in option parsing'

# Generated at 2022-06-12 19:01:40.174299
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-f', '1/2'])
    assert len(args) == 0
    assert '1/2' in opts.format
    assert opts.outtmpl == '%(id)s'

    opts, args = parseOpts(['-f', '1/2', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert len(args) == 1
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'
    assert '1/2' in opts.format


# Generated at 2022-06-12 19:02:13.171544
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import os
    import shutil
    import tempfile
    from .extractor import get_info_extractor
    from .compat import (
        compat_urlparse,
        compat_urllib_parse_unquote,
        compat_expanduser,
    )

    # Test compat_expanduser
    if sys.platform == 'win32':
        assert compat_expanduser('~') == os.path.expandvars(r'%USERPROFILE%')
        assert compat_expanduser(r'\~') == r'\~'
    else:
        assert compat_expanduser('~') == os.environ['HOME']

    # Test compat_urlparse

# Generated at 2022-06-12 19:02:24.564480
# Unit test for function parseOpts
def test_parseOpts():
    # Save the original stdout channel
    stdout_channel = sys.stdout

    # Mock stdout and optparse.OptionParser
    class StreamMock(object):
        def __init__(self):
            self.content = ""

        def write(self, stuff):
            self.content = self.content + stuff

    class OptionParserMock(object):
        def __init__(self):
            self.content = StreamMock()

        def print_help(self, file=None):
            if file is None:
                file = self.content
            file.write("Help")

        def error(self, msg):
            self.content.write("Error")

        def parse_args(self, args, values=None):
            return None

    sys.stdout = StreamMock()

    # Test that parseOpts displays the

# Generated at 2022-06-12 19:02:38.016260
# Unit test for function parseOpts
def test_parseOpts():
    write_string('Testing parseOpts\n')
    opts_str_list = ['--help', '-i', '-u', 'user', '-p', 'pass', '-x', '-f', 'best', '--max-filesize', '100KiB', '--min-filesize', '10KiB']
    parser, opts, args = parseOpts(opts_str_list)
    assert(opts.username == 'user')
    assert(opts.password == 'pass')
    assert(opts.format == 'best')
    assert(opts.max_filesize == 102400)
    assert(opts.min_filesize == 10240)
    # Test the function with another option list.
    # An example of the usage of the function parseOpts
    # The argument overrideArguments

# Generated at 2022-06-12 19:02:41.260513
# Unit test for function parseOpts
def test_parseOpts():
    from os.path import dirname, join
    testConfig = join(dirname(__file__), "testConf.conf")
    _configuration, opts, args = parseOpts([testConfig])
    assert opts.username == "myUsername"
    assert opts.password == "myPassword"
    assert opts.sleep_interval == 1337
    assert opts.proxy == "http://localhost:8080/"



# Generated at 2022-06-12 19:02:54.118701
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--version'])
    assert opts.print_version
    parser, opts, args = parseOpts([])
    assert not opts.verbose
    parser, opts, args = parseOpts(['-a', '-'])
    assert opts.batchfile == '-'
    assert opts.usenetrc
    parser, opts, args = parseOpts(['--username', 'me', '--password', 'secret'])
    assert opts.username == 'me'
    assert opts.password == 'secret'

# Generated at 2022-06-12 19:03:06.764715
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(overrideArguments=['--get-title', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.geturl
    assert opts.flat_playlist
    assert opts.format == 'bestvideo+bestaudio'
    assert opts.no_warnings
    assert opts.gettitle
    assert opts.getid
    assert opts.get_thumbnail
    assert opts.get_description
    assert opts.get_filename
    assert opts.youtube_include_dash_manifest
    assert opts.write_all_thumbnails
    assert not opts.extractaudio
    assert not opts.noplaylist
    assert not opts.usenetrc
    assert not opts.verbose


# Generated at 2022-06-12 19:03:16.923726
# Unit test for function parseOpts
def test_parseOpts():
    if True:
        write_string('SKIP: Test parsing of command-line options (needs working installation of youtube-dl)\n')
        return
    parser, opts, args = parseOpts()
    assert not opts.call_home

    parser, opts, args = parseOpts(['--call-home'])
    assert opts.call_home
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.matchtitle == None
    assert opts.writethumbnail == False
    assert opts.listformats == False

    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-4'])
    assert opts.force

# Generated at 2022-06-12 19:03:27.937244
# Unit test for function parseOpts
def test_parseOpts():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    from youtube_dl.extractor import gen_extractors
    gen_extractors()

    old_stderr = sys.stderr
    old_stdout = sys.stdout

    sys.stderr = StringIO()
    sys.stdout = StringIO()


# Generated at 2022-06-12 19:03:35.899440
# Unit test for function parseOpts
def test_parseOpts():
    from .compat import compat_shlex_split

    def _assert_parse(args, expected_dict, expected_rest):
        with compat_shlex_split(args) as cmd_line_conf:
            parser, opts, rest = parseOpts(cmd_line_conf)
            assert rest == expected_rest
            for k, v in expected_dict.items():
                actual_v = getattr(opts, k)
                if k == 'format':
                    if isinstance(v, list):
                        actual_v = [f['format_id'] for f in actual_v]
                    else:
                        actual_v = actual_v['format_id']
                if k == 'include_ads':
                    assert bool(getattr(opts, 'include_ads')) == bool(v)
                else:
                    assert actual

# Generated at 2022-06-12 19:03:46.169088
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import NamedTemporaryFile
    from argparse import ArgumentParser
    from itertools import chain

    DEFAULT_URL = 'https://www.youtube.com/watch?v=BaW_jenozKc'

    def _get_key(args, key):
        for arg in reversed(args):
            if '=' not in arg:
                continue
            akey, aval = arg.split('=', 1)
            if akey == key:
                return aval
        return None

    def _verify_options(args, opts, expected):
        for key, value in expected.items():
            if hasattr(opts, key):
                value = str(value)
                if getattr(opts, key) is None:
                    assert _get_key(args, key) == value

# Generated at 2022-06-12 19:04:42.321145
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing parseOpts...')
    import sys
    import os
    import shutil
    import tempfile

    try:
        old_argv = sys.argv
        sys.argv = [sys.argv[0], '-v']
        (parser, opts, args) = parseOpts()
        if opts.verbose:
            print('\nRegular run: pass')
        else:
            print('\nRegular run: fail')
    finally:
        sys.argv = old_argv


# Generated at 2022-06-12 19:04:51.096007
# Unit test for function parseOpts
def test_parseOpts():
    from types import GeneratorType
    from sys import version_info
    from locale import getpreferredencoding

    # Test attribute 'help' for option '--format'
    option = '--format'
    assert parseOpts([option])[2][0] == option
    assert parseOpts([option])[2][1] == 'bestvideo+bestaudio/best'

    # Test attribute 'help' for option '--all-formats'
    option = '--all-formats'
    assert parseOpts([option])[2][0] == option
    assert parseOpts([option])[2][1] is True

    # Test attribute 'help' for option '--list-formats'
    option = '--list-formats'
    assert parseOpts([option])[2][0] == option
    assert parseOpts([option])

# Generated at 2022-06-12 19:04:55.056929
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    if sys.version_info < (3,):
        return
    arguments = sys.argv[1:]
    for permutation in permutations(arguments):
        try:
            parseOpts(list(permutation))
        except:
            print('A problem happened with this permutation: %s' % permutation)
            raise



# Generated at 2022-06-12 19:05:06.154852
# Unit test for function parseOpts
def test_parseOpts():
    write_string('Testing parseOpts\n')

    youtube_dl.utils.std_headers['Test'] = 'pass'
    parser, opts, args = parseOpts(['-i', '--no-check-certificate',
                                    '--socket-timeout', '666',
                                    '--source-address', '1.2.3.4',
                                    '--user-agent', 'testua',
                                    '--test-option', '--no-test-option',
                                    '--verbose',
                                    'http://www.youtube.com/watch?v=BaW_jenozKc',
                                    '--proxy', '1.2.3.4:8888',
                                    '--test-option'])
    assert opts.proxy == '1.2.3.4:8888'
   

# Generated at 2022-06-12 19:05:16.481103
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    # Unit test for function _match_entry
    import unittest
    class TestRegexp(unittest.TestCase):
        def test_match_entry(self):
            # -3-, -2-, -1-
            # --3-
            # -3
            # -42
            # -42-
            # -42--
            # --42-
            # --42
            # --42--
            # -4-2-
            import re
            for i in range(100):
                print(re.match(r'^-(\d+)(?:-(\d+))?$', str(i)))

    unittest.main(failfast=True, exit=False)
    print(opts)
    print(opts.call_home)


# Generated at 2022-06-12 19:05:21.298507
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts()
    parser, opts, _ = parseOpts(['http://example.com'])
    parser, opts, _ = parseOpts(['http://example.com', '-q'])
    parser, opts, _ = parseOpts(['http://example.com', '--quiet'])
    parser, opts, _ = parseOpts(['http://example.com', '--username', 'foo', '--password', 'bar'])
    parser, opts, _ = parseOpts(['http://example.com', '--no-check-certificate'])



# Generated at 2022-06-12 19:05:26.308792
# Unit test for function parseOpts
def test_parseOpts():
    # Test for Infinite recursion
    def _test(overrideArguments):
        if overrideArguments is not None:
            sys.argv = sys.argv[0:1] + overrideArguments
        else:
            sys.argv = sys.argv[0:1]
        try:
            parseOpts()
        except:
            raise
        else:
            raise AssertionError(
                'It is expected parseOpts() to fail with these options: %r'
                % overrideArguments)

    _test(['--config-location', 'youtube-dl.conf'])
    _test(['--config-location', 'youtube-dl.conf', '-c', 'youtube-dl.conf'])

# Generated at 2022-06-12 19:05:31.310186
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.ratelimit == '0'
    parser, opts, args = parseOpts(['-R', '20'])
    assert opts.ratelimit == '20'



# Generated at 2022-06-12 19:05:40.676043
# Unit test for function parseOpts

# Generated at 2022-06-12 19:05:47.198662
# Unit test for function parseOpts
def test_parseOpts():
    for cmdline in (
            '-i -v --get-url --get-title --get-id --get-thumbnail --get-description --get-filename --get-format --no-warnings --no-playlist --age-limit 18 --download-archive archive.txt url1 url2',
            '-i -v --abort-on-error --dump-user-agent',
            '-i -v --all-subs --write-sub --write-auto-sub --sub-format srt --sub-lang fr,en --username user --password pass http://url'):
        parser, opts, args = parseOpts(shlex.split(cmdline))
        assert not args



# Generated at 2022-06-12 19:07:25.340214
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts()
    assert opts.username is None
    parser, opts, _ = parseOpts(['--username', 'foo'])
    assert opts.username == 'foo'
    parser, opts, _ = parseOpts(['--username', 'foo', '--password', 'bar'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    parser, opts, _ = parseOpts(
        ['--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.format == 'bestvideo+bestaudio/best'
    parser, opts, _ = parseOpts(['--format', '22'])


# Generated at 2022-06-12 19:07:26.584296
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.usenetrc

# End unit test for function parseOpts



# Generated at 2022-06-12 19:07:35.671722
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.version import __version__
    opts = parseOpts(['-h'])[1]
    assert opts.version == __version__

    opts = parseOpts(['--extract-audio'])[1]
    assert opts.extractaudio

    opts = parseOpts(['--yes-playlist'])[1]
    assert not opts.noplaylist

    opts = parseOpts(['--yes-playlist', '--no-playlist'])[1]
    assert opts.noplaylist

    opts = parseOpts([])[1]
    assert opts.ratelimit is None

    opts = parseOpts(['--rate-limit', '1.5M'])[1]
    assert opts.ratelimit == '1.5M'

# Generated at 2022-06-12 19:07:45.929474
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import mkstemp
    from os import fdopen, remove
    from os.path import exists
    # Parse, use a custom config file, and read it back
    handle, filename = mkstemp()
    file = fdopen(handle, 'w')
    file.write("-i\n-o test_output\n")
    file.close()
    argv[1:] = ['--config-location', filename]
    parser, opts, args = parseOpts()
    assert opts.outtmpl == 'test_output', opts.outtmpl
    assert opts.ignoreerrors, opts.ignoreerrors
    remove(filename)
    # Parse, and ignore the config file
    handle, filename = mkstemp()

# Generated at 2022-06-12 19:07:56.900137
# Unit test for function parseOpts
def test_parseOpts():
    # test when overrideArguments is not None
    opts = youtube_dl.options.parseOpts(['-o', '/tmp/a.flv', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1]
    assert opts.outtmpl == '/tmp/a.flv'
    assert opts.verbose is False
    assert opts.quiet is False

    # test when overrideArguments is None
    # _readOptions function is mocked to return values
    opts = youtube_dl.options.parseOpts(['-o', '/tmp/a.flv', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1]
    assert opts.outtmpl == '/tmp/a.flv'
    assert opts.verbose

# Generated at 2022-06-12 19:08:02.202824
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert opts.default_search is None
    opts, args = parseOpts(['-a', 'test.txt'])
    assert opts.default_search == 'auto'
    opts, args = parseOpts(['--default-search', 'ytsearch'])
    assert opts.default_search == 'ytsearch'
    assert opts.match_filter == '!is_live'
    opts, args = parseOpts(['--match-filter', '!is_live or has_subtitles'])
    assert opts.match_filter == '!is_live or has_subtitles'
    opts, args = parseOpts([])
    assert opts.match_filter == '!is_live'

# Generated at 2022-06-12 19:08:04.305574
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([]) is not None
    
try:
    unicode
except NameError:
    unicode = str


# Generated at 2022-06-12 19:08:08.448748
# Unit test for function parseOpts
def test_parseOpts():
    args = ['--prefer-ffmpeg', '--format', 'best', 'http://youtube.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts(args)

    assert opts.prefer_ffmpeg == True
    assert opts.format == 'best'
    assert args[0] == 'http://youtube.com/watch?v=BaW_jenozKc'

if __name__=='__main__':
    test_parseOpts()

# Generated at 2022-06-12 19:08:15.807584
# Unit test for function parseOpts
def test_parseOpts():
    from ytdl import extractor

    parser, opts, args = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == False
    assert opts.verbose_count == 0
    assert opts.username is None
    assert opts.password is None
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forcet

# Generated at 2022-06-12 19:08:17.868559
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod(sys.modules[__name__])

