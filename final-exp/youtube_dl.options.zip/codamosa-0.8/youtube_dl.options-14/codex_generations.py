

# Generated at 2022-06-12 19:00:04.376335
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-v'])[1].verbose == True
    assert parseOpts(['--verbose'])[1].verbose == True
    assert parseOpts(['-i'])[1].ignoreerrors == True
    assert parseOpts(['--ignore-errors'])[1].ignoreerrors == True
    assert parseOpts(['-r'])[1].ratelimit == '1.0'
    assert parseOpts(['--rate-limit', '1.1'])[1].ratelimit == '1.1'
    assert parseOpts(['-a', 'file'])[1].batchfile == 'file'
    assert parseOpts(['--batch-file', 'file'])[1].batchfile == 'file'

# Generated at 2022-06-12 19:00:14.061912
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_os_name
    import sys
    if compat_os_name == 'nt':
        ENC = 'mbcs'
    else:
        ENC = 'utf-8'
    FLAGS = [
        '--write-description',
        '--write-info-json',
        '--write-annotations',
        '--write-thumbnail',
        '--extract-audio',
        '--embed-thumbnail',
        '--embed-subs',
        '--add-metadata',
        '--xattrs',
        '--prefer-ffmpeg',
    ]

# Generated at 2022-06-12 19:00:24.554709
# Unit test for function parseOpts
def test_parseOpts():
    import unittest
    # TODO: Test for quoting
    class TestParseOpts(unittest.TestCase):
        def test_version(self):
            parser, opts, args = parseOpts(['--version'])
            self.assertTrue(opts.version)
            self.assertEqual(args, [])

        def test_help(self):
            parser, opts, args = parseOpts(['--help'])
            self.assertTrue(opts.help)
            self.assertEqual(args, [])
            parser, opts, args = parseOpts(['-h'])
            self.assertTrue(opts.help)
            self.assertEqual(args, [])

        def test_dump_user_agent(self):
            parser, opts, args = parseOpts

# Generated at 2022-06-12 19:00:37.004787
# Unit test for function parseOpts
def test_parseOpts():
    """ Unit test for function parseOpts."""
    m = _test_parseOpts
    # test overrideArguments
    m(overrideArguments=['--socks-proxy', 'example.com', '-k', '--format', '22/mp4'],
      expected_out_config={'socks_proxy': 'example.com', 'keepvideo': True, 'format': '22/mp4'})
    # test existing config-location
    m(overrideArguments=['--config-location', os.path.join(os.path.dirname(__file__), 'test_data', 'config_location', 'youtube-dl.conf')],
      expected_out_config={'limit_rate': '1000k', 'socks_proxy': 'foobar.com:123'})
    # test missing config-location
   

# Generated at 2022-06-12 19:00:41.570009
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    parser, opts, args = parseOpts(overrideArguments = ['-v', '--skip-download', '--write-pages', '--youtube-include-dash-manifest', '--embed-thumbnail'])
    assert parser
    assert opts.verbose == True
    assert opts.skip_download == True
    assert opts.write_pages == True
    assert opts.youtube_include_dash_manifest == True
    assert opts.embedthumbnail == True
    assert len(args) == 0
    
    parser, opts, args = parseOpts(overrideArguments = ['-v', '--skip-download', '--write-pages', '--youtube-include-dash-manifest', '--embed-thumbnail', '--write-info-json'])
    assert parser


# Generated at 2022-06-12 19:00:54.734739
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeFilename
    from .compat import compat_getenv
    from .extractor import gen_extractors

    opts, args = parseOpts('-v --ignore-config --no-mtime --dump-user-agent --list-extractors'.split())
    assert opts.verbose is True
    assert opts.ignoreconfig is True
    assert opts.updatetime is False
    assert opts.dump_user_agent is True
    assert opts.list_extractors == True

    opts, args = parseOpts('-v --encoding UTF-8 --ignore-config --format "bestvideo[height<=?360]+bestaudio/best"'.split())
    assert opts.verbose is True
    assert opts.ignoreconfig is True

# Generated at 2022-06-12 19:01:07.190131
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumburl == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_list

# Generated at 2022-06-12 19:01:12.532235
# Unit test for function parseOpts
def test_parseOpts():
    from .compat import PY2
    if PY2:
        return
    import io
    import sys

    stdout = sys.stdout
    sys.stdout = io.StringIO()
    try:
        import doctest
        doctest.testmod()
    finally:
        sys.stdout = stdout

# Generated at 2022-06-12 19:01:25.981921
# Unit test for function parseOpts
def test_parseOpts():
    import re
    import unittest
    assert _encodeFilename('foo') == 'foo'
    assert _encodeFilename('foo"bar') == 'foo%22bar'
    assert _encodeFilename('foo%20bar') == 'foo%20bar'
    assert _encodeFilename(u'føø') == u'f%C3%B8%C3%B8'
    assert _encodeFilename(u'føø'.encode('utf-8')) == u'f%C3%B8%C3%B8'
    assert _decodeFilename('f%C3%B8%C3%B8') == u'føø'
    assert _decodeFilename('f%C3%B8%C3%B8'.encode('utf-8')) == u'føø'


# Generated at 2022-06-12 19:01:37.005441
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'testuser', '-P', 'testpass', 'testurls'])
    parser, opts, args = parseOpts(['-u', 'testuser', '-p', 'testpass', 'testurls'])
    parser, opts, args = parseOpts(['--username', 'testuser', '--password', 'testpass', 'testurls'])
    parser, opts, args = parseOpts(['-4', '-f', 'best', 'testurls'])
    parser, opts, args = parseOpts(['--prefer-insecure', '-f', 'best', 'testurls'])

# Generated at 2022-06-12 19:02:00.891365
# Unit test for function parseOpts

# Generated at 2022-06-12 19:02:10.498789
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import copy
    sys.argv = ['youtube-dl',
                'http://youtube.com/watch?v=BaW_jenozKc',
                '--username=foo', '--password=bar']
    parser, opts, args = parseOpts()
    assert opts.username == 'foo'
    assert opts.password == 'bar'

    sys.argv = ['youtube-dl',
                'http://youtube.com/watch?v=BaW_jenozKc',
                '--dump-user-password', '--dump-interactive']
    parser, opts, args = parseOpts()
    assert not opts.password


# Generated at 2022-06-12 19:02:22.471544
# Unit test for function parseOpts
def test_parseOpts():
    # Test for missing delimiter between opt and arg
    assert parseOpts(['-oout'])[1].outtmpl == 'out'

    # Test for missing arg
    assert parseOpts(['-o'])[1].outtmpl == '%(title)s-%(id)s.%(ext)s'

    # Test for missing value in
    assert parseOpts(['--output-template'])[1].outtmpl == '%(title)s-%(id)s.%(ext)s'

    # Test for invalid long option
    assert parseOpts(['--invalid-long-option'])[2] == ['--invalid-long-option']

    # Test for invalid short options

# Generated at 2022-06-12 19:02:27.143310
# Unit test for function parseOpts
def test_parseOpts():
    class MockOptionParser(): pass
    class MockParser():
        def __init__(self, *args): pass
        def add_option_group(self, *args): return MockOptionParser()
        def parse_args(self, *args): return (MockOptionParser(), [])
    return MockParser()

# Monkey patching
parseOpts = test_parseOpts()



# Generated at 2022-06-12 19:02:41.133857
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    import os
    import shutil
    test_dir = tempfile.mkdtemp(prefix='youtubedl-test-')
    conf_file = os.path.join(test_dir, 'test.conf')
    args_file = os.path.join(test_dir, 'args')
    with open(args_file, 'w') as args:
        args.write('')
    with open(conf_file, 'w') as conf:
        conf.write('')
    args = ['--config-location', conf_file, '--username', 'foo',
            '--password', 'bar', '-a', args_file, '--verbose']
    parser, opts, _ = parseOpts(args)
    assert opts.username == 'foo'

# Generated at 2022-06-12 19:02:48.660174
# Unit test for function parseOpts
def test_parseOpts():
    def check_parse(argv, expected):
        return expected == dict(parseOpts(argv)['opts'].__dict__)

# Generated at 2022-06-12 19:03:02.256274
# Unit test for function parseOpts
def test_parseOpts():
    # Testing --extract-audio as it's the most complicated
    # The function parseOpts is not used in the tests
    # I just isolated the parser logic here so that it
    # is easier to test it
    parser, opts, _ = parseOpts(['--extract-audio', '--audio-format', 'mp3', '--audio-quality', '0'])
    assert opts.extractaudio == True
    assert opts.audioformat == 'mp3'
    assert opts.audioquality == '0'

    parser, opts, _ = parseOpts(['--extract-audio', '--audio-format', 'mp3', '--audio-quality', '0', '--recode-video', 'mp4'])
    assert opts.extractaudio == True

# Generated at 2022-06-12 19:03:03.000333
# Unit test for function parseOpts
def test_parseOpts():
    pass



# Generated at 2022-06-12 19:03:03.725617
# Unit test for function parseOpts
def test_parseOpts():
    assert True


# Generated at 2022-06-12 19:03:13.350328
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    import shutil


# Generated at 2022-06-12 19:03:36.523858
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts(['-v', '-i', '--no-color'])
    assert opts.verbose
    assert opts.ignoreerrors
    assert opts.no_color

    parser, opts, _ = parseOpts(['-f', '18'])
    assert opts.given_format == '18'

    parser, opts, _ = parseOpts(['-4', '--prefer-ipv4'])
    assert opts.prefer_ipv4 is True
    parser, opts, _ = parseOpts(['-6', '--prefer-ipv6'])
    assert opts.prefer_ipv6 is True

    parser, opts, _ = parseOpts(['-F', 'bestvideo+bestaudio/best'])
    assert opt

# Generated at 2022-06-12 19:03:46.751134
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.ratelimit == '0'
    assert opts.simulate
    assert not opts.quiet
    assert not opts.dump_intermediate_pages
    assert not opts.print_traffic
    assert not opts.noplaylist
    assert not opts.playlistend
    assert not opts.playlistreverse
    assert opts.playliststart == 1
    assert not opts.playlistrandom
    assert not opts.nooverwrites
    assert opts.writedescription
    assert not opts.writesubtitles
    assert not opts.writeautomaticsub
    assert not opts.allsubtitles
    assert not opts.listsubtitles

# Generated at 2022-06-12 19:03:55.362025
# Unit test for function parseOpts
def test_parseOpts():
    import re
    from collections import namedtuple
    from unittest import TestCase

    Option = namedtuple('Option', ['dest', 'default'])
    Options = namedtuple('Options', ['__dict__'])

    def _parse_opt(opts, args):
        optparser, opts, args = parseOpts(overrideArguments=args)
        return Options(optparser.defaults), Options(vars(opts)), args

    def _get_opt(opts, name):
        return opts.__dict__.get(name)

    optparser, opts, args = parseOpts(overrideArguments=[])

    Cookie = re.compile('^--cookie "(.+?)=(.+?)"$')

# Generated at 2022-06-12 19:04:08.039681
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from tempfile import NamedTemporaryFile

    opts_str = '--username=user --password=pwd -i --proxy=127.0.0.1'
    parser, opts, args = parseOpts(opts_str.split())
    assert opts.username == 'user', opts
    assert opts.password == 'pwd', opts
    assert opts.proxy == '127.0.0.1', opts

    with NamedTemporaryFile(mode='wt', delete=True) as f:
        f.write('--username=user2\n')
        f.write('--password=pwd2\n')
        f.write('--proxy=127.0.0.2\n')
        f.flush()

# Generated at 2022-06-12 19:04:20.263451
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import NamedTemporaryFile
    from shutil import copyfileobj

    fd, tmpfn = NamedTemporaryFile(delete=False, mode='w')
    fd.write('# Minimal config file\n')
    fd.write('--format=best\n')
    fd.write('-o /tmp/%(title)s-%(id)s.%(ext)s\n')
    fd.write('--batch-file=/tmp/somefile\n')
    fd.write('--verbose\n')

    fd.close()


# Generated at 2022-06-12 19:04:33.136671
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    def test_opts(opts, keys, boolopts=()):
        for key in keys:
            assert hasattr(opts, key)
        for key in boolopts:
            assert hasattr(opts, key)
            assert getattr(opts, key) in (True, False)
    # Test without any config or cmd line argument
    ydl = YoutubeDL({})
    assert ydl.params == {}
    assert ydl.outtmpl == '%(id)s.%(ext)s'
    # Test with cmd line options
    (parser, opts, args) = parseOpts(['-f', '22/18/17/best', '--proxy', '1.1.1.1:8080'])

# Generated at 2022-06-12 19:04:35.607713
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)


# Generated at 2022-06-12 19:04:39.062547
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert bool(parser)

# Generated at 2022-06-12 19:04:47.285130
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-u', 'a', '-p', 'b', '--', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'a'
    assert opts.password == 'b'
    assert args[0] == 'http://youtube.com/watch?v=BaW_jenozKc'
    parser, opts, args = parseOpts(['-4', '-g', '-i', '-f', 'best', 'https://youtube.com/watch?v=BaW_jenozKc'])
    assert opts.noplaylist is True
    assert opts.age_limit is 18
    assert opts.usenetrc is True
    assert opts.format == 'best'

# Generated at 2022-06-12 19:04:56.422390
# Unit test for function parseOpts
def test_parseOpts():
    from os.path import join
    from sys import argv
    args = ['--test']
    parser, opts, args = parseOpts(args)
    assert opts.test == True
    assert args == []
    args = ['--test', 'foo']
    parser, opts, args = parseOpts(args)
    assert opts.test == True
    assert args == ['foo']
    args = ['--test', 'foo', '--test', 'bar']
    parser, opts, args = parseOpts(args)
    assert opts.test == 'bar'
    assert args == ['foo']
    assert opts.verbose == False
    args = ['--no-verbose', 'foo', '--verbose', '--test', 'bar']
    parser, opts, args = parseOpts(args)


# Generated at 2022-06-12 19:05:29.811941
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts()



# Generated at 2022-06-12 19:05:34.782095
# Unit test for function parseOpts
def test_parseOpts():
    from .__main__ import youtube_dl as yt

    parser, opts, args = parseOpts(['-v', '--ignore-config', '-o', '%(id)s.%(ext)s', 'foo'])
    assert(opts.verbose == True)
    assert(opts.ignoreconfig == True)
    assert(opts.outtmpl == '%(id)s.%(ext)s')
    assert(args == ['foo'])

# Generated at 2022-06-12 19:05:40.057967
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-h'])
    opts, args = parseOpts(['--version'])
    opts, args = parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc'])
    opts, args = parseOpts(['--list-extractors'])



# Generated at 2022-06-12 19:05:47.706267
# Unit test for function parseOpts
def test_parseOpts():
    def _test_config_location(config_location, expected_config_location):
        try:
            os.environ.pop('XDG_CONFIG_HOME')
            opts, args = parseOpts(['--config-location', config_location])
            assert opts.config_location == expected_config_location
            return 0
        except SystemExit:
            return 1

    from tempfile import mkstemp
    from shutil import rmtree

    config_values = {'abc': 'def', 'foobar': 'foo'}

    # Write configuration file
    config_file_descriptor, config_file_path = mkstemp()

# Generated at 2022-06-12 19:05:58.761610
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = ['youtube-dl']
    parser, opts, args = parseOpts()
    assert opts.outtmpl == '%(id)s.%(ext)s'
    assert opts.ignoreerrors is False
    assert opts.ratelimit == '0.0'
    assert opts.usenetrc is False
    assert opts.verbose is False
    assert opts.no_warnings is False
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.format is None
    assert opts.listformats is False
    assert opts.logtostderr is False
    assert opts.conversion_format == 'best'
    assert opts.nooverwrites is False
    assert opts.retries == 10

# Generated at 2022-06-12 19:06:09.549920
# Unit test for function parseOpts
def test_parseOpts():
    def test_config_file(filename, expected_conf):
        with temp_filename(filename) as filename:
            parser, _, _ = parseOpts(['--config-location', filename])
            assert expected_conf == parser.get_config_from_filename(filename)

    test_config_file('ignore-config.conf', [])
    test_config_file('empty.conf', [])
    test_config_file('whitespace.conf', [])
    test_config_file('comments.conf', [])
    test_config_file('option-value.conf', ['--output', '"%(id)s.%(ext)s"'])
    test_config_file('multiple-lines.conf', ['--output', '"%(id)s.%(ext)s"'])

# Generated at 2022-06-12 19:06:21.757775
# Unit test for function parseOpts
def test_parseOpts():
    def test_opt(name, *args, **kwargs):
        if 'config_location' in kwargs:
            return '--config-location', kwargs['config_location']
        return '--' + name.replace('_', '-'), ''

    orig_open = builtins.open
    def open_side(path, mode='r', encoding=None):
        if path == 'does/not/exist':
            raise OSError('No such file or directory')
        return orig_open(path, mode, encoding=encoding)

    def r(v):
        if isinstance(v, str):
            return v.encode('UTF-8')
        else:
            return v


# Generated at 2022-06-12 19:06:24.106674
# Unit test for function parseOpts
def test_parseOpts():
    # Simple unit test to ensure defaults arent broken
    opts = parseOpts(['url'])[1]
    assert opts.noplaylist is False
    assert opts.cachedir is not None


# Generated at 2022-06-12 19:06:25.347478
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    return doctest.testmod()


# Generated at 2022-06-12 19:06:37.747200
# Unit test for function parseOpts
def test_parseOpts():
  parser, opts, args = parseOpts(['-h'])
  assert parser
  assert opts
  assert args
  parser, opts, args = parseOpts(['--no-config-location'])
  assert parser
  assert opts
  assert args
  parser, opts, args = parseOpts(['--version'])
  assert parser
  assert opts
  assert args
  parser, opts, args = parseOpts(['--config-location', '/etc/youtube-dl.conf'])
  assert parser
  assert opts
  assert args
  parser, opts, args = parseOpts(['--config-location', './test.conf'])
  assert parser
  assert opts
  assert args

# This function is called when the user is using --cookies
# It reads the lines of

# Generated at 2022-06-12 19:07:56.509702
# Unit test for function parseOpts
def test_parseOpts():
    from argparse import ArgumentParser
    from nose.tools import assert_raises, eq_
    from youtube_dl.compat import compat_str

    assert opts.default_search == 'auto'
    assert opts.outtmpl == '%(id)s.%(ext)s'
    assert opts.quiet == False

    assert_raises(SystemExit, parseOpts, ['--extract-audio'])
    opts, args = parseOpts([])
    assert opts.extractaudio == False
    assert opts.quiet == False
    assert opts.format is None
    assert opts.listformats is None
    assert opts.simulate is None
    assert opts.ignoreerrors is None
    assert opts.geturl is None
    assert opts.gettitle is None

# Generated at 2022-06-12 19:08:01.816621
# Unit test for function parseOpts
def test_parseOpts():
    def _test(args, expected):
        assert '--no-playlist' not in expected
        assert '--playlist-start' not in expected
        assert '--playlist-end' not in expected
        parser, opts, _ = parseOpts(args)
        if args is None and expected is None:
            assert opts == None
            return

        assert opts != None
        opts_dict = dict(opts.__dict__)
        assert 'config_location' in opts_dict
        del opts_dict['config_location']
        assert opts_dict == expected

    _test(None, None)


# Generated at 2022-06-12 19:08:04.659840
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = _parseOpts()
    assert opts.format in ['best', 'bestvideo', 'worst', 'worstvideo']

# =============================================================================
#
# =============================================================================



# Generated at 2022-06-12 19:08:13.485199
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.compat import compat_urlextract
    parser, opts, args = parseOpts(['-g'])
    assert opts.geturl
    parser, opts, args = parseOpts(['http://www.youtube.com'])
    assert args[0] == 'http://www.youtube.com'
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-U', '--no-verbose', '-q'])
    assert opts.verbose == False
    assert opts.quiet == True
    parser, opts, args = parseOpts(['-u', 'username', '-p', 'password', 'http://www.youtube.com'])
    assert opts.username == 'username'
    assert opts.password == 'password'


# Generated at 2022-06-12 19:08:24.283079
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['--proxy', '1.2.3.4:3128'])[1].proxy == '1.2.3.4:3128'
    assert parseOpts(['--help'])[0].print_help.called
    assert parseOpts(['-h'])[0].print_help.called
    assert parseOpts(['-U', 'FooBar'])[1].user_agent == 'FooBar'
    assert parseOpts(['--user-agent', 'FooBar'])[1].user_agent == 'FooBar'
    assert parseOpts(['-4'])[1].forceipv4 is True
    assert parseOpts(['--force-ipv4'])[1].forceipv4 is True

# Generated at 2022-06-12 19:08:27.333697
# Unit test for function parseOpts
def test_parseOpts():
    parser,opts,args = parseOpts()
    assert parser is not None
    assert opts is not None
    assert args is not None

# test_parseOpts()


# Generated at 2022-06-12 19:08:35.500031
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-F', '-f', 'mp4', '-i', '-w', '--no-overwrites', '--write-description'])
    assert opts.simulate
    assert opts.format == 'mp4'
    assert opts.usenetrc
    assert opts.nooverwrites
    assert opts.writedescription
    assert not opts.verbose
    assert not opts.quiet

# Generated at 2022-06-12 19:08:41.940655
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(
        ['-i', '--yes-playlist', '--sleep-interval', '5',
         'https://www.youtube.com/watch?v=BaW_jenozKc',
         'https://www.youtube.com/watch?v=kJQP7kiw5Fk',
         'https://www.youtube.com/watch?v=yZ-K7nCVnBI'])
    assert args == \
        ['https://www.youtube.com/watch?v=BaW_jenozKc',
         'https://www.youtube.com/watch?v=kJQP7kiw5Fk',
         'https://www.youtube.com/watch?v=yZ-K7nCVnBI']
    assert opts.sleep_inter

# Generated at 2022-06-12 19:08:49.077067
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts(['--no-check-certificate', '--verbose', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.nocheckcertificate == True
    assert args == ['http://youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-12 19:08:58.145439
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert not opts.ignoreerrors
    assert opts.verbose
    assert not opts.quiet


    parser, opts, args = parseOpts(['-h'])
    assert not opts.ignoreerrors
    assert not opts.verbose
    assert not opts.quiet


    parser, opts, args = parseOpts(['--ignore-errors'])
    assert opts.ignoreerrors
    assert not opts.verbose
    assert not opts.quiet


    parser, opts, args = parseOpts(['--verbose'])
    assert not opts.ignoreerrors
    assert opts.verbose
    assert not opts.quiet


    parser, opts, args = parseOpts(['--quiet'])
   