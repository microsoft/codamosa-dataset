

# Generated at 2022-06-12 19:00:05.673580
# Unit test for function parseOpts
def test_parseOpts():
    rtn = parseOpts(['-u', 'user', '-p', 'pass', '--no-warnings', '--no-check-certificate', 'http://youtube.com'])
    assert rtn[0].get_prog_name() == 'youtube-dl'
    assert rtn[1].username == 'user'
    assert rtn[1].password == 'pass'
    assert rtn[1].nocheckcertificate
    assert rtn[1].noprogress
    assert not rtn[1].verbose
    assert rtn[2][0] == 'http://youtube.com'
    # Check if the http proxy was correctly parsed (see https://github.com/rg3/youtube-dl/issues/5221)

# Generated at 2022-06-12 19:00:14.618823
# Unit test for function parseOpts
def test_parseOpts():
    # Test --no-mtime
    sys.argv = ['-v', '--no-mtime', 'http://wwww.youtube.com/watch?v=BaW_jenozKc']
    assert parseOpts()[1].updatetime is False

    # Test -o
    sys.argv = ['-o', '/tmp/%(upload_date)s-%(title)s-%(id)s.%(ext)s', 'http://wwww.youtube.com/watch?v=BaW_jenozKc']
    assert parseOpts()[1].outtmpl == '/tmp/%(upload_date)s-%(title)s-%(id)s.%(ext)s'

    # Test --no-warnings

# Generated at 2022-06-12 19:00:24.927851
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.extractor import gen_extractors
    gen_extractors()

    def t(args, opts, outtmpl = False, verbose = False):
        parser, opts_, args_ = parseOpts(args)
        assert opts == opts_
        assert args == args_
        if outtmpl is not False:
            assert outtmpl == opts_.outtmpl
        if verbose is not False:
            assert verbose == opts_.verbose
    # Basic
    t(['-o', 'ok'], ['output'], 'ok')
    t(['--output', 'ok'], ['output'], 'ok')
    # No argument
    t(['--no-call-home'], ['nocallhome'], False, False)
    # Short + argument
    t

# Generated at 2022-06-12 19:00:37.048430
# Unit test for function parseOpts
def test_parseOpts():
    class Object(object):
        pass
    opts = Object()
    opts.username = 'foo'
    opts.password = 'bar'
    opts.verbose = True
    parser, opts, args = parseOpts([
        '-v',
        '--username', 'foo',
        '--password', 'bar',
        'arg0', 'arg1'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose
    assert args == ['arg0', 'arg1']
    video_format.add_option(
        '--format',
        dest='format', metavar='FORMAT', default=None,
        help='Video format code')

# Generated at 2022-06-12 19:00:49.878036
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import format_bytes

    parser, opts, args = parseOpts(
        ['--proxy=socks5://1.2.3.4:1080', '--format=bestvideo[height<=?1080]+bestaudio/best', 'https://www.youtube.com/watch?v=BaW_jenozKc', '-o', '%(title)s-%(id)s.%(ext)s'])
    assert opts.proxy == 'socks5://1.2.3.4:1080'
    assert opts.format == 'bestvideo[height<=?1080]+bestaudio/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-12 19:00:59.016924
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parseOpts(args, expected):
        parser, opts, _args = parseOpts(args)
        assert vars(opts) == expected

# Generated at 2022-06-12 19:01:12.149171
# Unit test for function parseOpts
def test_parseOpts():
    if False:
        _getOption = optparse.OptionContainer._get_opt_string
        a = parseOpts([])
        print(_getOption(a.network, 'noproxy'))
        print(_getOption(a.network, 'no_check_certificate'))
        print(_getOption(a.network, 'proxy'))
        print(_getOption(a.network, 'user-agent'))
        print(_getOption(a.network, 'referer'))
        print(_getOption(a.network, 'dump-user-agent'))

        print(_getOption(a.selection, 'playlist-start'))
        print(_getOption(a.selection, 'playlist-end'))
        print(_getOption(a.selection, 'match-title'))

# Generated at 2022-06-12 19:01:25.154768
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import *
    import sys
    import os
    import tempfile
    temp = tempfile.NamedTemporaryFile(mode='wt', delete=False, suffix='.conf', prefix='youtube-dl')
    try:
        # Create a config file
        temp.write('--min-sleep-interval 2\n--max-sleep-interval 4\n')
        temp.close()
        sys.argv = [sys.argv[0], '--min-sleep-interval', '1', '--max-sleep-interval', '8', 'pl','videoid']
        _, opts, _ = parseOpts()
        assert opts.min_sleep_interval == 2 and opts.max_sleep_interval == 4
    finally:
        os.unlink(temp.name)

# Generated at 2022-06-12 19:01:36.598880
# Unit test for function parseOpts
def test_parseOpts():
    class FakeOption(object):
        def __init__(self, val):
            self.val = val
    class FakeOpts(object):
        def __init__(self, val):
            self.verbose = False
    def fake_parser_parse(args, **kargs):
        return FakeOpts(args)
    def fake_readOptions(filename):
        return [ '--ignore-config' ]
    def fake_expanduser(path):
        return path

    # Test download-archive handling
    _conf_filename = FakeOption(None)
    _opts = FakeOption(None)
    _args = []
    _parse = FakeOption(fake_parser_parse)
    _readOptions = FakeOption(fake_readOptions)
    _expanduser = FakeOption(fake_expanduser)


# Generated at 2022-06-12 19:01:44.383232
# Unit test for function parseOpts
def test_parseOpts():
    class AttributeDict(dict):
        __getattr__ = dict.__getitem__
        __setattr__ = dict.__setitem__


# Generated at 2022-06-12 19:02:14.547709
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts()
test_parseOpts()


# Generated at 2022-06-12 19:02:25.383023
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-h'])
    opts, args = parseOpts(['youtube-dl', '-h'])
    opts, args = parseOpts(['youtube-dl', '-h'])
    opts, args = parseOpts(['--version'])
    opts, args = parseOpts(['--extract-audio', '--audio-format', 'mp3'])
    opts, args = parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc'])
    opts, args = parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-12 19:02:37.823872
# Unit test for function parseOpts
def test_parseOpts():
    opts, _ = parseOpts(['-v'])
    eq_(opts.verbose, 1)
    opts, _ = parseOpts(['--quiet'])
    eq_(opts.quiet, True)
    eq_(opts.verbose, 0)
    opts, _ = parseOpts(['-v', '-v', '-v'])
    eq_(opts.verbose, 3)
    opts, _ = parseOpts(['--no-progress'])
    eq_(opts.progress_with_newline, False)
    opts, _ = parseOpts([])
    eq_(opts.progress_with_newline, True)
    eq_(opts.verbose, 0)



# Generated at 2022-06-12 19:02:47.118784
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([])
    assert parseOpts(['--youtube-skip-dash-manifest'])
    assert parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc', '--list-formats'])
    # assert parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc', '--format=bestvideo[ext=mp4]+bestaudio[ext=m4a]'])
    # assert parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc', '--format=bestvideo[height<=?720]+bestaudio/best'])

# Generated at 2022-06-12 19:02:49.369053
# Unit test for function parseOpts
def test_parseOpts():
    return False
    # TODO: provide unit test for function parseOpts

# Unit tests

# Generated at 2022-06-12 19:03:02.987359
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    class Options:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    class FakeParser:
        def __init__(self):
            self.option_list = []
        def add_option(self, *args, **kwargs):
            self.option_list.append(Options(kwargs))
        def add_option_group(self, *args, **kwargs):
            pass
        def parse_args(self, args):
            return Options(), args
    import types
    class FakeModule:
        def __init__(self, d):
            self.__dict__.update(d)
    import sys
    setattr(sys, 'argv', ['youtube-dl'] + argv)

# Generated at 2022-06-12 19:03:07.968274
# Unit test for function parseOpts
def test_parseOpts():
    print("Testing " + c.bold + c.underline + "parseOpts" + c.reset + " function")
    parser, opts, args = parseOpts(["--help"])
    print("Tested " + c.bold + c.underline + "parseOpts" + c.reset + " function")
#test_parseOpts()



# Generated at 2022-06-12 19:03:16.122792
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["-h"])
    assert parser is not None
    assert opts is not None
    assert args is not None

    #parser, opts, args = parseOpts(["-s"])
    #Traceback (most recent call last):
       #File "<stdin>", line 1, in <module>
       #File "youtube_dl\YoutubeDL.py", line 659, in parseOpts
         #help='Do not skip existing files')
    #optparse.OptionError: option -s: invalid choice: '' (choose from '--no-skip-download')


# Generated at 2022-06-12 19:03:26.897556
# Unit test for function parseOpts
def test_parseOpts():
    opts = testutils.dummy_opts()
    opts.extractaudio = True
    opts.audioformat = 'best'
    opts.audioquality = '5'
    opts.recodevideo = None
    opts.keepvideo = False
    opts.embedsubtitles = False
    opts.embedthumbnail = False
    opts.subtitleslang = 'en'
    opts.subtitlesformat = 'best'

    parser, opts, args = parseOpts(overrideArguments=['--extract-audio', '--audio-format', 'best', '--audio-quality', '5', '--sub-lang', 'en', '--sub-format', 'best'])


# Generated at 2022-06-12 19:03:35.005149
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '-o', '/dev/null', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'
    parser, opts, args = parseOpts(['-i', '--yes-playlist', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.ignoreerrors == True
    assert opts.noplaylist == False
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'


# Generated at 2022-06-12 19:04:35.327748
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([sys.argv[0], '-h'])
    assert parseOpts([sys.argv[0], '--version'])
    with pytest.raises(SystemExit) as excinfo:
        parseOpts([sys.argv[0], '--no-version'])
    assert excinfo.value.code == 0
    assert parseOpts([sys.argv[0], '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert parseOpts([sys.argv[0], '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc', '--verbose'])

# Generated at 2022-06-12 19:04:45.885611
# Unit test for function parseOpts
def test_parseOpts():
    def test_parsing_arguments(args, expected, conf=None):
        parser, opts, _args = parseOpts(args.split(), conf)

        for prop, value in expected.items():
            assert hasattr(opts, prop) and getattr(opts, prop) == value, 'Expected %s=%s but got %s=%s' % (prop, value, prop, getattr(opts, prop))

    # http://github.com/rg3/youtube-dl/issues/3148
    test_parsing_arguments(
        '--proxy 127.0.0.1:3128 -x --audio-format mp3 URL',
        {'proxy': '127.0.0.1:3128', 'extractaudio': True, 'audioformat': 'mp3'})



# Generated at 2022-06-12 19:04:47.058546
# Unit test for function parseOpts
def test_parseOpts():
    """Check whether parseOpts returns the correct type"""
    assert type(_real_main([])) == tuple


# Generated at 2022-06-12 19:04:58.278157
# Unit test for function parseOpts
def test_parseOpts():
    class MockOptionParser(object):
        def __init__(self):
            self.add_option_group = MockOptionParser()

    class MockOptionGroup(object):
        def __init__(self):
            self.add_option = MockOptionParser()

    class MockOption(object):
        def __init__(self):
            self.dest = 'merge_output_format'
            self.default = None

    class MockOptionValue(object):
        def __init__(self):
            self.merge_output_format = 'mkv'

    cli_args = ['--merge-output-format', 'mkv']

    _, opts, _ = parseOpts(overrideArguments=cli_args)

    assert opts.merge_output_format == 'mkv'

# Generated at 2022-06-12 19:05:09.232765
# Unit test for function parseOpts
def test_parseOpts():
    from compat import compat_getenv, compat_shlex_split, compat_configparser

    # Test --ignore-config
    assert parseOpts(['--username', 'foouser', '--password', 'foopass', '--ignore-config', '-U', 'baruser', '-P', 'barpass', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].username == 'baruser'

    # Test empty user config
    assert parseOpts(['--no-check-certificate', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].nocheckcertificate == False

    # Test user config with empty --no-check-certificate

# Generated at 2022-06-12 19:05:18.887445
# Unit test for function parseOpts
def test_parseOpts():
    def _testconf(conf):
        _, opts, args = parseOpts(conf)
        if opts.verbose:
            write_string('[debug] Options: ' + repr(_hide_login_info(opts)) + '\n')
            write_string('[debug] Args: ' + repr(_hide_login_info(args)) + '\n')
        return opts
    _testconf(['--verbose'])
    _testconf(['-v'])
    _testconf(['--verbose', '--ignore-config', '-v'])

    co = _testconf(['--username', 'foo', '--password', 'bar'])
    assert co.username == u'foo'
    assert co.password == u'bar'
    assert co.usenetrc is False

    co

# Generated at 2022-06-12 19:05:22.695499
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = [sys.argv[0], '-i', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = _real_parseOpts()
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-12 19:05:34.814949
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    _, opts, _ = parseOpts(['-F', '--yes-playlist', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.usenetrc == False
    assert opts.verbose == False
    assert opts.username == None
    assert opts.password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.usenetrc_machine == None
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False

# Generated at 2022-06-12 19:05:44.545285
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import gen_extractors
    (parser, opts, _) = parseOpts("--extractor-descriptions")
    extractors = gen_extractors()
    s = set()
    for ie in extractors:
        s = s.union(ie.IE_NAME)
    s = s.union([ie.IE_NAME for ie in gen_extractors()])
    for groupname, group in opts.__dict__.items():
        if group is None:
            continue
        for keyname, key in group.__dict__.items():
            if key == 'US' and keyname in s:
                import sys
                print(keyname)
                sys.exit(1)

    (parser, opts, _) = parseOpts(["--extractor-descriptions"])


# Generated at 2022-06-12 19:05:56.779617
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4', 'https://www.youtube.com/watch?v=BaW_jenozKc'])

    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4', 'The user overrided the format'

    parser, opts, args = parseOpts(['--format', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4', 'https://www.youtube.com/watch?v=BaW_jenozKc'])

    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4', 'The user overrided the format'



# Generated at 2022-06-12 19:07:45.833762
# Unit test for function parseOpts
def test_parseOpts():
    from xml.dom import minidom

    # Tests if youtube-dl stops on wrong options
    for wrongOpt in ['-l']:
        try:
            parseOpts([wrongOpt])
            assert(False)
        except (optparse.OptionValueError, optparse.OptionError):
            pass

    # Tests if youtube-dl parses right options
    (parser, opts, args) = parseOpts(['-v'])
    assert(opts.verbose)
    assert(not opts.quiet)
    assert(not opts.no_warnings)
    assert(opts.format == None)
    assert(opts.outtmpl == '%(id)s.%(ext)s')
    assert(opts.ignoreerrors)
    assert(not opts.forceurl)

# Generated at 2022-06-12 19:07:52.682784
# Unit test for function parseOpts
def test_parseOpts():
    try:
        parser, opts, args = parseOpts(['-U', 'test_username', '--password', 'test_password', 'test_url'])
    except SystemExit as se:
        if se.code != 0:
            return False
    return True
import os.path
import urllib.parse
import random
import string
import time
import datetime
import re
import unicodedata
import html.entities
import xml.etree.ElementTree
import io


# Generated at 2022-06-12 19:07:54.862784
# Unit test for function parseOpts
def test_parseOpts():
    parseOpts(None)
    
#command line parser

# Generated at 2022-06-12 19:08:05.008235
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from argparse import Namespace
    from types import ModuleType
    from types import FunctionType
    from types import BuiltinFunctionType
    from types import MethodType
    from types import BuiltinMethodType
    opts = Namespace()
    opts.username = 'username'
    opts.password = 'password'
    opts.ap_mso = 'apmso'
    opts.ap_username = 'apusername'
    opts.ap_password = 'appassword'
    opts.extract_flat = 'youtube'
    opts.write_sub = 'sub.vtt'
    opts.write_auto_sub = 'auto.vtt'
    opts.date_after = '20130101'

# Generated at 2022-06-12 19:08:13.770604
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])

    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.format == 'best'
    assert opts.usenetrc is False
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.simulate is False
    assert opts.format_limit is None
    assert opts.nooverwrites is False
    assert opts.playliststart is 1
    assert opts.playlistend is None
    assert opts.matchtitle is None
    assert opts.rejecttitle is None
    assert opts.max_downloads

# Generated at 2022-06-12 19:08:24.462305
# Unit test for function parseOpts
def test_parseOpts():
    class MockOptionParser(object):
        def __init__(self, opts):
            self.opts = opts
            self.groups = []

        def add_option_group(self, *args, **kwargs):
            self.groups.append((args, kwargs))

        def parse_args(self, argv):
            self.argv = argv
            return self.opts, []
    parser = MockOptionParser([])
    myopts, myargs = parseOpts(parser, ['--username=user', '--password=pass'])
    assert parser.argv == ['--username=user', '--password=pass']
    assert myopts.verbose
    assert myopts.username == 'user'
    assert myopts.password == 'pass'

# Generated at 2022-06-12 19:08:36.634281
# Unit test for function parseOpts
def test_parseOpts():
    def check(argv, expected):
        parser, options, args = parseOpts(argv.split())
        actual = dict([(opt, getattr(options, opt)) for opt in options.defaults])
        assert actual == expected, '%s != %s' % (actual, expected)


# Generated at 2022-06-12 19:08:44.687305
# Unit test for function parseOpts
def test_parseOpts():
    from .YoutubeDL import parseOpts
    res = parseOpts(['--username=foo', '--password=bar', '--no-check-certificate'])
    assert res[0].has_option('--username')
    assert not res[0].has_option('--usename')
    assert len(res) == 3
    assert res[1].username == 'foo'
    assert res[1].password == 'bar'
    assert res[1].nocheckcertificate



# Generated at 2022-06-12 19:08:46.575838
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.usagestr is None

# Generated at 2022-06-12 19:08:49.671418
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts(None)
    assert opts.source_address

# Download a given URL.  Returns a list of FileDownload objects.