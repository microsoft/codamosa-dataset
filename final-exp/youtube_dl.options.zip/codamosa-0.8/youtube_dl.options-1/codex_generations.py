

# Generated at 2022-06-12 19:00:23.516907
# Unit test for function parseOpts

# Generated at 2022-06-12 19:00:36.957128
# Unit test for function parseOpts
def test_parseOpts():
    # Simple test with a lot of arguments
    testargs = ['-i', '--yes-playlist', '--get-url', '--get-title', ' http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(overrideArguments=testargs)
    assert opts.geturl
    assert opts.gettitle
    assert not opts.getid
    assert opts.usenetrc
    assert opts.noplaylist
    assert len(args) == 1
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'

    # Test to parse short options

# Generated at 2022-06-12 19:00:49.772273
# Unit test for function parseOpts
def test_parseOpts():
    def _test_readoptions(filename, contents):
        if filename == 'youtube-dl.conf':
            return contents.split()
        return []
    with mock.patch('os.path.exists', return_value=False):
        _readOptions = mock.Mock(side_effect=_test_readoptions)
        with mock.patch('youtube_dl.YoutubeDL.parseOpts', wraps=parseOpts) as po_mock:
            po_mock.side_effect = lambda *args: parseOpts(*args, _readOptions=_readOptions)
            # Test parsing system config
            parser, opts, args = parseOpts(['--config-location=/etc'])

# Generated at 2022-06-12 19:00:58.879912
# Unit test for function parseOpts
def test_parseOpts():
    import unittest
    import tempfile

    class TestParseOpts(unittest.TestCase):
        """ TestCase for parseOpts() """

        conf = {'outtmpl': '%(id)s', 'username': 'dummy', 'password': 'dummy', 'verbose': True}
        parser, opts, args = parseOpts([])
        for key, value in conf.items():
            assert getattr(opts, key) == value
        assert args == []

        def test_parse_opts_plain(self):
            assert self.parser.has_option('--output')

        def test_parse_opts_override(self):
            parser, opts, args = parseOpts(['-o', 'OVERRIDDEN'], overrideArguments=True)

# Generated at 2022-06-12 19:01:12.040159
# Unit test for function parseOpts

# Generated at 2022-06-12 19:01:25.014892
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeFilename

    encodeFilename('\u2605')
    encodeFilename('\u2605'.encode('utf-8'))
    encodeFilename('\u2605'.encode('utf-8').decode('ascii'))

    parser, opts, args = parseOpts(['-i', '--no-warnings', '--socket-timeout=0'])
    assert opts.ignoreerrors
    assert opts.no_warnings
    assert opts.socket_timeout == 0
    assert args == []

    parser, opts, args = parseOpts(['--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.ignoreerrors
    assert opts.no_warnings
    assert opts.socket_timeout == 300


# Generated at 2022-06-12 19:01:31.866337
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-v', '--verbose', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.geturl == True
    assert opts.writeinfojson == False


if __name__ == '__main__':
    test_readOptions()

# Generated at 2022-06-12 19:01:40.713728
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = ['youtube-dl','yq3FJWacrOc']
    parser, opts, args = parseOpts()
    assert opts.write_sub != True, "Write Sub True"
    assert opts.write_auto_sub != True, "Write Auto Sub True"
    assert opts.write_all_subs != True, "Write All Subs True"
    assert opts.list_subs != True, "list_subs True"
    assert opts.write_annotations != True, "Write annotations True"
    assert opts.write_info_json != True, "write_info_json True"
    assert opts.write_thumbnail != True, "Write thumbnail True"
    assert opts.write_all_thumbnails != True, "Write all thumbnail True"
    assert opts.list

# Generated at 2022-06-12 19:01:50.037568
# Unit test for function parseOpts
def test_parseOpts():
    from os.path import expanduser
    from nose.tools import eq_
    from nose import SkipTest
    def _parseOpts(arguments):
        parser, opts, args = parseOpts(arguments)
        return parser, opts.__dict__, args

    # Test if the ytdl binary overrides the config
    try:
        eq_(_parseOpts(['--verbose'])[1]['verbose'], True)
    except IOError:
        # If we cannot find the config file, then it must be located in a
        # different directory than where the tests are running. Skip the tests
        # that rely on the config file.
        raise SkipTest('Config file not found')
    else:
        eq_(_parseOpts(['--no-verbose'])[1]['verbose'], False)


# Generated at 2022-06-12 19:01:59.453885
# Unit test for function parseOpts
def test_parseOpts():
    # pylint: disable=unused-variable
    from collections import UserDict
    import tempfile
    from os.path import exists, join
    from sys import argv
    from types import SimpleNamespace

    def _make_parser():
        class FakeParser(SimpleNamespace):
            def __init__(self):
                self.option_groups = []

            def add_option_group(self, optgroup):
                self.option_groups.append(optgroup)
                return optgroup

            def error(self, msg):
                raise ValueError(msg)

        return FakeParser()

    def _make_optgroup(*opts):
        class FakeOptionGroup(SimpleNamespace):
            def __init__(self, *opts):
                self.option_list = list(opts)


# Generated at 2022-06-12 19:02:25.485284
# Unit test for function parseOpts
def test_parseOpts():
    def fake_input(s):
        assert s.startswith('youtube-dl:')
        print(s)
        return ' '

    from types import ModuleType
    class MockInputModule(ModuleType):
        def __init__(self):
            super(MockInputModule, self).__init__('getpass')

        def getpass(*args, **kwargs):
            return 'password'

    mock_modules = {'getpass': MockInputModule()}

    def test_input_override(capsys):
        parseOpts(['--username', 'user', '--password', 'passwd'])
        out, _ = capsys.readouterr()
        assert '--username has been deprecated, use --username or --netrc instead.' in out

# Generated at 2022-06-12 19:02:39.224424
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    # Test parsing the output template
    opts, _ = parseOpts(['-o', '%(uploader)s/%(upload_date)s-%(title)s-%(id)s.%(ext)s'])
    assert opts.outtmpl == '%(uploader)s/%(upload_date)s-%(title)s-%(id)s.%(ext)s'
    opts, _ = parseOpts(['--output', '%(uploader)s/%(upload_date)s-%(title)s-%(id)s.%(ext)s'])

# Generated at 2022-06-12 19:02:47.698042
# Unit test for function parseOpts
def test_parseOpts():
    """Unit tests for parseOpts function."""

    assert parseOpts(['-f', '18', '-g', 'foo'])[1].format == '18'
    assert parseOpts(['-f', '18', '-f', 'mp4'])[1].format == 'mp4'
    assert parseOpts(['--format=18', '--format=mp4'])[1].format == 'mp4'
    assert parseOpts(['--help'])[0] == 2
    assert parseOpts(['--get-url', '--get-title', 'foo'])[1].simulate
    assert parseOpts(['--get-url', '--get-title', '--get-id', 'foo'])[1].simulate

# Generated at 2022-06-12 19:03:01.300359
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'abc'
    assert opts.password == 'def'
    assert opts.usenetrc == False
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forceduration == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.format_limit is None

# Generated at 2022-06-12 19:03:02.662664
# Unit test for function parseOpts
def test_parseOpts():
    # FIXME
    pass



# Generated at 2022-06-12 19:03:11.972475
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["-i", "-c", "--no-progress", "--console-title"])
    assert(not opts.noprogress)
    assert(opts.verbose)
    assert(opts.cookiefile == None)
    assert(args == [])
    parser, opts, args = parseOpts(["--ignored-config", "-i", "-c", "--no-progress", "--console-title"])
    assert(opts.ignored_config)
    parser, opts, args = parseOpts(["--config-location", "~/youtube-dl.conf", "-i", "-c", "--no-progress", "--console-title"])
    assert(opts.config_location.endswith("youtube-dl.conf"))

# Generated at 2022-06-12 19:03:20.373316
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.version import __version__
    from youtube_dl.utils import get_cachedir
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == 1
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber == False
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.usetitle == False
    assert opts.useid == False
    assert opts.writedescription == False
    assert opts.writeannotations == False
    assert opt

# Generated at 2022-06-12 19:03:30.900513
# Unit test for function parseOpts
def test_parseOpts():
    ## Test-1:
    #  Test if the default values are returned.
    import sys

    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import match_filter_func, parse_resolution

    parser, _opts, _args = parseOpts([])

    # General Options
    assert YoutubeDL.params['verbose'] == False
    assert not sys.argv[0:1] or YoutubeDL.params['usenetrc'] == True
    assert YoutubeDL.params['username'] == None
    assert YoutubeDL.params['password'] == None
    assert YoutubeDL.params['twofactor'] == None
    assert YoutubeDL.params['videopassword'] == None
    assert YoutubeDL.params['ap_mso'] == None
    assert YoutubeDL.params['ap_username'] == None

# Generated at 2022-06-12 19:03:42.101221
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import gen_extractors
    _A_common_opts = [
        '--format=best',
        '--merge-output-format=mkv',
        '--no-mtime',
        '--retries=10',
        '--no-overwrites',
        '--no-post-overwrites',
        '--ffmpeg-location=/home/user/bin/ffmpeg',
        '--call-home',
    ]
    parser, opts, args = parseOpts(['-o', 'myoutputfilename', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.outtmpl == 'myoutputfilename'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']



# Generated at 2022-06-12 19:03:44.299309
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    opts, args = parseOpts()
    doctest.testmod(verbose=opts.verbose)



# Generated at 2022-06-12 19:04:16.245495
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    parser, opts, args = parseOpts()
    doctest.testmod(optionflags=doctest.ELLIPSIS)


# For backwards compatibility

# Generated at 2022-06-12 19:04:18.951256
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: "python setup.py test" can't test this function
    #       because it is not in any module.
    pass



# Generated at 2022-06-12 19:04:31.684522
# Unit test for function parseOpts
def test_parseOpts():
    from .common import compat_urllib_parse
    from .extractor import gen_extractors
    from .utils import encodeFilename, url_basename
    from .extractor.common import InfoExtractor
    from .compat import str, compat_str, compat_urllib_parse_urlparse
    from .downloader.http import HttpFD
    # import inspect
    # for line in inspect.getsource(parseOpts).splitlines():
    #     print(line)
    
    # Note: -u is required or extractor will quit
    _opts, _args = parseOpts(['-u', 'https://www.youtube.com/playlist?list=PLwiyx1dc3P2JR9N8gQaQN_BCvlSlap7re'])

# Generated at 2022-06-12 19:04:43.676649
# Unit test for function parseOpts
def test_parseOpts():
    # Test some trivial stuff
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose

    parser, opts, args = parseOpts(['--username=ytdl'])
    assert opts.username == 'ytdl'

    # Test overriding (global) options
    parser, opts, args = parseOpts(['--username=foo', '--username=bar'])
    assert opts.username == 'bar'

    # Test ignoring config files
    parser, opts, args = parseOpts(['--ignore-config', '--username=foo'])
    assert opts.username == 'foo'

    # Test overriding config files
    parser, opts, args = parseOpts(['--config-location=./youtube-dl.conf', '--username=foo'])
   

# Generated at 2022-06-12 19:04:52.726844
# Unit test for function parseOpts
def test_parseOpts():
    class AttributeDict(dict):
        __getattr__ = dict.__getitem__
        __setattr__ = dict.__setitem__
        __delattr__ = dict.__delitem__

    parser, opts, args = parseOpts(['-f', '36'])
    assert opts.format == '36'
    parser, opts, args = parseOpts(['--format=36'])
    assert opts.format == '36'
    parser, opts, args = parseOpts(['--format=m4a+bestaudio'])
    assert opts.format == 'm4a+bestaudio'
    optdict = AttributeDict(vars(opts))
    assert optdict['format'] == ['m4a', 'bestaudio', 'best']


# Compat methods for optparse


# Generated at 2022-06-12 19:05:04.553075
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    testargs = ['--username=foo', '--password=bar', '--verbose']
    assert parseOpts(testargs)[2] == argv[1:]
    testargs = ['--usenetrc', '--username=foo', '--password=bar', '--verbose']
    assert parseOpts(testargs)[2] == argv[1:]
    testargs = ['--username', 'foo', '--password', 'bar', '--verbose']
    assert parseOpts(testargs)[2] == argv[1:]
    try:
        testargs = ['--username', '--password', 'bar', '--verbose']
        parseOpts(testargs)
        assert True == False, 'parseOpts should have raised an error'
    except:
        pass

# Generated at 2022-06-12 19:05:10.358306
# Unit test for function parseOpts
def test_parseOpts():
    def _parse_opts(override_arguments):
        parser, opts, args = parseOpts(override_arguments)
        def _convert(val):
            if isinstance(val, compat_str):
                return val.encode('ascii')
            elif isinstance(val, int):
                return str(val)
            else:
                return val
        return [(opt.dest, _convert(getattr(opts, opt.dest)))
                for opt in parser.option_list
                if opt.dest is not None]

    assert _parse_opts([]) == []
    assert _parse_opts(['-h']) == [
        ('help', True), ('verbose', False), ('quiet', False)]

# Generated at 2022-06-12 19:05:19.694437
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing parseOpts')
    assert(parseOpts(['-h'])[2] == None)
    assert(parseOpts(['-u', 'testuser', '-p', 'testpass', '-i', 'youtube.com/channel/UC_x5XG1OV2P6uZZ5FSM9Ttw', '--get-id'])[2] == ['youtube.com/channel/UC_x5XG1OV2P6uZZ5FSM9Ttw'])

# Generated at 2022-06-12 19:05:20.135538
# Unit test for function parseOpts
def test_parseOpts():
    pass


# Generated at 2022-06-12 19:05:25.448448
# Unit test for function parseOpts
def test_parseOpts():
    class Opener(object):
        def __init__(self, *args):
            pass
        def open(self, url):
            return Opener()
        def info(self):
            return str()
        read = open
    compat_urllib_request.build_opener = Opener

    test_args=['-F','-v','https://www.youtube.com/watch?v=hHW1oY26kxQ']
    parser, opts, args = parseOpts(test_args)
    output = sys.stdout.getvalue().strip()
    assert opts.format == 'best'

# Generated at 2022-06-12 19:06:33.289997
# Unit test for function parseOpts
def test_parseOpts():
    def testOpts(opts):
        import random
        random.seed(0)
        parser, opts, args = parseOpts(opts)
        assert opts.username == 'u'
        assert opts.password == 'p'
        assert opts.twofactor == '2fac'
        assert opts.videopassword == 'videopassword'
        assert opts.ap_username == 'uap'
        assert opts.ap_password == 'pap'
        assert opts.nopart
        assert opts.verbose
        assert opts.ap_mso == 'apmso'
        assert opts.ap_current_credentials
        assert opts.retries == 10
        assert opts.playliststart == 1
        assert opts.playlistend == 2


# Generated at 2022-06-12 19:06:45.727133
# Unit test for function parseOpts
def test_parseOpts():
    def check_opts(argv, conf):
        parser, opts, args = parseOpts(argv)
        assert opts.__dict__ == conf
    # Valid values

# Generated at 2022-06-12 19:06:50.787614
# Unit test for function parseOpts
def test_parseOpts():
    from getpass import getuser

    from youtube_dl.utils import setup_opener

    from .compat import compat_getpass

    def test(s, expected_value):
        parser, opts, args = parseOpts(s.split())
        assert opts.usernames == expected_value

    test("--username user1 --username user2", ['user1', 'user2'])
    test("--username=user1 --username user2", ['user1', 'user2'])
    test("--username=user1 --username=user2", ['user1', 'user2'])
    test("--username='user 1' --username user2", ['user 1', 'user2'])


# Generated at 2022-06-12 19:06:59.878611
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-f', '22/18/17/best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].format == ['22', '18', '17', 'best']
    assert parseOpts(['-f', '22/18/17/best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].extractaudio == False
    assert parseOpts(['-f', '22/18/17/best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].ignoreerrors == False
    assert parseOpts(['-f', '22/18/17/best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-12 19:07:10.386105
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = common.parseOpts(['-V'])
    assert opts.verbose
    assert opts.verbose_count == 1
    opts, args = common.parseOpts(['-VVV', '-q'])
    assert opts.verbose_count == 3
    assert opts.quiet
    opts, args = common.parseOpts(['-o', 'a', '-o', 'b', 'x'])
    assert opts.outtmpl == 'a'
    assert args == ['b', 'x']

    opts, args = common.parseOpts(['--geo-bypass-country', 'US'])
    assert opts.geo_bypass_country == 'US'

# Generated at 2022-06-12 19:07:15.378268
# Unit test for function parseOpts
def test_parseOpts():
    from .common import compat_str
    from .compat import compat_expanduser
    from .compat import compat_getenv
    from .compat import compat_os_name
    from .compat import compat_setenv

    temp_home_dir = tempfile.mkdtemp()
    compat_setenv('HOME', temp_home_dir)

    opts, args = parseOpts([])
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.videopassword is None

    opts, args = parseOpts([
        '-u', 'user',
        '-p', 'pass',
        '-2', '2fac',
        '--video-password', 'vpass',
    ])
    assert opts.username

# Generated at 2022-06-12 19:07:26.122095
# Unit test for function parseOpts
def test_parseOpts():
    import sys

    # Since parseOpts() is not unit testable, use the next best thing:
    # set the program name to 'python -m youtube_dl.__main__'
    # If a test fails, we get a traceback starting at the correct line
    sys.argv[0] = 'python -m youtube_dl.__main__'

    old_argv = sys.argv
    sys.argv = sys.argv[:1]
    sys.argv += '-v -i --yes-playlist --flat-playlist -o "asdf%(title)sasdf" -a t.txt -s --sub-format ttml'.split()

# Generated at 2022-06-12 19:07:28.363068
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.verbose == False

# Allow unit test to access _readUserConf

# Generated at 2022-06-12 19:07:32.409040
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--dump-user-agent'])
    assert opts.dump_user_agent
    parser, opts, args = parseOpts(['-r', 'http://example.com'])
    assert opts.ratelimit == 'http://example.com'


# Generated at 2022-06-12 19:07:39.136375
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-i'])
    assert opts.noplaylist is True
    opts, args = parseOpts(['-I'])
    assert opts.noplaylist is False
    opts, args = parseOpts(['-i', '--yes-playlist'])
    assert opts.noplaylist is False
    opts, args = parseOpts(['--no-playlist', '--yes-playlist'])
    assert opts.noplaylist is False
# End of unit test for function parseOpts ##################
