

# Generated at 2022-06-12 19:00:05.930505
# Unit test for function parseOpts
def test_parseOpts():
    res = parseOpts(["--proxy", "http://www.youtube.com/watch?v=BaW_jenozKc"])
    return res
# --- END FUNCTIONS ---



# Generated at 2022-06-12 19:00:07.708922
# Unit test for function parseOpts
def test_parseOpts():
    assert len(parseOpts()) == 3


# Generated at 2022-06-12 19:00:18.034354
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.username is None
    assert opts.password is None

    parser, opts, args = parseOpts(['-u', 'foobar'])
    assert opts.username == 'foobar'
    assert opts.password is None

    parser, opts, args = parseOpts(['-u', 'foobar', '-p', 'p4ssw0rd'])
    assert opts.username == 'foobar'
    assert opts.password == 'p4ssw0rd'

    os.environ['YTDL_USERNAME'] = 'environment'
    parser, opts, args = parseOpts([])
    assert opts.username == 'environment'
    assert opts.password is None

# Generated at 2022-06-12 19:00:26.998571
# Unit test for function parseOpts
def test_parseOpts():
    class Struct:
        pass
    opts = Struct()
    opts.verbose = True
    opts.quiet = False
    opts.no_warnings = True
    opts.cachedir = False
    opts.call_home = False
    opts.username = None
    opts.password = None
    args = ['https://youtu.be/BaW_jenozKc']

    parser, opts, args = parseOpts(['--cachedir', '/tmp'])
    assert opts.cachedir == '/tmp'

    parser, opts, args = parseOpts(['--no-cachedir'])
    assert not opts.cachedir

    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose

    parser, opts, args

# Generated at 2022-06-12 19:00:38.113719
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    sys.stderr = StringIO()
    sys.stdout = StringIO()
    parser, opts, args = parseOpts([])
    assert opts.get('format') == None
    assert opts.get('autonumber') == False
    assert opts.get('usetitle') == False
    assert opts.get('verbose') == False

    parser, opts, args = parseOpts(['-v'])
    assert opts.get('verbose') == True

    parser, opts, args = parseOpts(['-f', '38'])
    assert opts.get('format') == '38'

    parser, opts, args = parseOpts(['-l'])
    assert opts.get('usetitle') == True

    parser, opts,

# Generated at 2022-06-12 19:00:40.164549
# Unit test for function parseOpts
def test_parseOpts():
    import doctest, _parseOpts
    return doctest.testmod(_parseOpts)


# Generated at 2022-06-12 19:00:52.810859
# Unit test for function parseOpts
def test_parseOpts():
    from pprint import pprint

    parser, opts, args = parseOpts(['--min-filesize', '1Ki', '--verbose'])
    pprint(opts.__dict__)
    # {'age_limit': 0,
    #  'ap_mso': '',
    #  'ap_password': '',
    #  'ap_username': '',
    #  'autonumber': False,
    #  'autonumber_size': 0,
    #  'autonumber_start': 1,
    #  'batchfile': None,
    #  'call_home': False,
    #  'cachedir': None,
    #  'cookiefile': None,
    #  'continuedl': True,
    #  'convertsubtitles': None,

# Generated at 2022-06-12 19:01:05.737275
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import Option
    from sys import argv
    from time import time



# Generated at 2022-06-12 19:01:19.205924
# Unit test for function parseOpts
def test_parseOpts():
    def check(testargs, expected):
        parser, opts, args = parseOpts(testargs)
        actual = opts.__dict__
        assert actual == expected, 'Expected %r but got %r with args %r' % (expected, actual, args)

    # Test parsing of different types for integer/float options
    # https://github.com/rg3/youtube-dl/issues/5465
    check(['--rate-limit', '1'], {'ratelimit': '1'})
    check(['--rate-limit', '1.0'], {'ratelimit': '1.0'})
    check(['--retries', '1'], {'retries': 1})
    check(['--retries', '1.0'], {'retries': 1})

# Generated at 2022-06-12 19:01:31.697078
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import chdir
    from os.path import abspath, dirname
    from shutil import rmtree
    from tempfile import mkdtemp
    from youtube_dl.version import __version__
    from youtube_dl.utils import encodeArgument


# Generated at 2022-06-12 19:02:01.275242
# Unit test for function parseOpts
def test_parseOpts():
    class _FakeOptionParser(object):
        class Option(object):
            SUPPRESS_HELP = object()
            NO_DEFAULT = object()
            def __init__(self, dest, action, default, type, help):
                self.dest = dest
                self.action = action
                self.default = default
                self.type = type
                self.help = help
            def get_opt_string(self):
                return self.dest
        class OptionGroup(object):
            def __init__(self, title):
                self.title = title
                self.option_list = []
            def add_option(self, *args, **kwargs):
                if 'help' in kwargs:
                    assert kwargs['help'] is not self.Option.SUPPRESS_HELP

# Generated at 2022-06-12 19:02:10.983112
# Unit test for function parseOpts
def test_parseOpts():
    # Empty
    parseOpts([])
    # Verbosity
    parseOpts(['-v'])
    parseOpts(['--verbose'])
    parseOpts(['-vvvvvv'])
    # Username & Password
    parseOpts(['--username', 'n', '--password', 'p'])
    # Non-ASCII Username & Password
    parseOpts(['--username', '\u043F', '--password', '\u043F'])
    # Output Template
    parseOpts(['-o', 'p'])
    # Non-ASCII Output Template
    parseOpts(['-o', '\u043F'])
    # Proxy
    parseOpts(['--proxy', 'p'])

# Generated at 2022-06-12 19:02:21.399334
# Unit test for function parseOpts
def test_parseOpts():
    result = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc', '-f', 'best'])
    expected = _YoutubeDL, _opts, ['https://www.youtube.com/watch?v=BaW_jenozKc']
    assert result == expected

# Match single quotes, double quotes, and octothorpes.
# Outside quotes, octothorpes denote comments.
_shlex_quote = re.compile(r'(?P<quote>["\']).*?(?<!\\)(?P=quote)|(?P<octo>#).*?$')


# Generated at 2022-06-12 19:02:23.445453
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.ignoreerrors == True

# parseOpts()


# Generated at 2022-06-12 19:02:25.616233
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(overrideArguments=['--no-check-certificate'])
    assert parser
    assert opts
    assert args

# Generated at 2022-06-12 19:02:39.371068
# Unit test for function parseOpts
def test_parseOpts():
    # confirm that -h/--help works
    try:
        parseOpts(['-h'])
    except SystemExit as se:
        assert se.code == 0

    try:
        parseOpts(['--help'])
    except SystemExit as se:
        assert se.code == 0

    # confirm that -U/--update works
    try:
        parseOpts(['-U'])
    except SystemExit as se:
        assert se.code == 0

    try:
        parseOpts(['--update'])
    except SystemExit as se:
        assert se.code == 0

    # confirm that -i/--ignore-errors works
    parser, opts, _ = parseOpts([])
    assert opts.ignoreerrors == False


# Generated at 2022-06-12 19:02:47.783092
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['UCfcRTQwvC1cT1rgtobCzlWw'])
    assert(opts.username == 'youtube-dl')
    parser, opts, args = parseOpts(['--username', 'test', 'UCfcRTQwvC1cT1rgtobCzlWw'])
    assert(opts.username == 'test')
    parser, opts, args = parseOpts(['--dump-intermediate-pages', 'UCfcRTQwvC1cT1rgtobCzlWw'])
    assert(opts.write_pages == True)
    parser, opts, args = parseOpts(['--extract-audio', 'UCfcRTQwvC1cT1rgtobCzlWw'])
   

# Generated at 2022-06-12 19:03:01.363483
# Unit test for function parseOpts
def test_parseOpts():
    import datetime
    assert parseOpts(['-o', 'test.%(ext)s']).outtmpl == 'test.%(ext)s'
    assert parseOpts(['--dateafter', '2030-01-01']).dateafter == datetime.date(2030, 1, 1)
    assert parseOpts(['--dateafter', 'tomorrow']).dateafter == datetime.date.fromordinal(datetime.date.today().toordinal() + 1)
    assert parseOpts(['--datebefore', '2030-01-01']).datebefore == datetime.date(2030, 1, 1)
    assert parseOpts(['--datebefore', 'yesterday']).datebefore == datetime.date.fromordinal(datetime.date.today().toordinal() - 1)

# Generated at 2022-06-12 19:03:11.320807
# Unit test for function parseOpts
def test_parseOpts():
    o, a = parseOpts(['-i', '-v', '--no-check-certificate', '--username', 'foo', '--password', 'bar', '--ignore-config', '-a', '-o', '-'])
    assert o.verbose == True
    assert o.quiet == False
    assert o.ignoreerrors == True
    assert o.forceurl == False
    assert o.forcetitle == False
    assert o.forcethumbnail == False
    assert o.forcedescription == False
    assert o.forcefilename == False
    assert o.forcejson == False
    assert o.simulate == False
    assert o.skip_download == False
    assert o.format == None
    assert o.listformats == False
    assert o.outtmpl == '-'

# Generated at 2022-06-12 19:03:20.021437
# Unit test for function parseOpts
def test_parseOpts(): #TODO
    pass

    
#TODO: re-write this function
# def print_reads(self, data, byte_counter=None):
#     if byte_counter is not None:
#         byte_counter[0] += len(data)
#     if opts.quiet:
#         return
#     if not self.screen_file:
#         return
#     if self.progress_indicator is None:
#         progress = self.calc_percent(byte_counter[0])
#         self.progress_indicator = progress
#     elif self.progress_indicator != '-':
#         progress = self.calc_percent(byte_counter[0])
#         if self.progress_indicator != progress:
#             self.progress_indicator = progress
#             write_string('\r[download

# Generated at 2022-06-12 19:03:42.945900
# Unit test for function parseOpts
def test_parseOpts():
    from compat import unittest

    class TestYDL(unittest.TestCase):
        def test_readOptions(self):
            self.assertEqual(_readOptions(['--verbose']), ['--verbose'])
            self.assertEqual(_readOptions('--verbose'), ['--verbose'])
            self.assertEqual(_readOptions('--verbose\n--ignore-config'), ['--verbose', '--ignore-config'])
            self.assertEqual(_readOptions(b'--verbose\n--ignore-config'), ['--verbose', '--ignore-config'])
            self.assertEqual(_readOptions(b'--username\nfoo\n--password\nbar'), ['--username', 'foo', '--password', 'bar'])


# Generated at 2022-06-12 19:03:51.120603
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['-v', '-o', 'bar'])
    assert opts.verbose
    assert opts.outtmpl == 'bar'
    parser, opts, args = parseOpts(['--verbose', '--output', 'foo'])
    assert opts.verbose
    assert opts.outtmpl == 'foo'
    parser, opts, args = parseOpts(['--verbose', '--output', '"foo"'])
    assert opts.verbose
    assert opts.outtmpl == 'foo'
    parser, opts, args = parseOpts(['-v', '-o"foo"'])
    assert opts.verbose


# Generated at 2022-06-12 19:03:55.052787
# Unit test for function parseOpts
def test_parseOpts():
    # Output template
    opts, args = parseOpts(['-o', '%(title)s_%(uploader)s_%(autonumber)s.%(ext)s'])
    assert opts.outtmpl == '%(title)s_%(uploader)s_%(autonumber)s.%(ext)s'
# end of test_parseOpts()


# Generated at 2022-06-12 19:04:07.641868
# Unit test for function parseOpts
def test_parseOpts():
    """Unit test for parseOpts."""
    from os import path
    from subprocess import CalledProcessError
    from sys import platform, executable
    from tempfile import NamedTemporaryFile

    def _main():
        opts = parseOpts([])
        assert opts['username'] == None
        assert opts['password'] == None
        assert opts['usenetrc'] == False
        assert opts['quiet'] == False
        assert opts['verbose'] == False
        assert opts['ratelimit'] == None
        assert opts['retries'] == 10
        assert opts['continuedl'] == True
        assert opts['noprogress'] == False
        assert opts['playliststart'] == 1
        assert opts['playlistend'] == None
        assert opts['matchtitle'] == None
        assert opt

# Generated at 2022-06-12 19:04:19.769645
# Unit test for function parseOpts
def test_parseOpts():
    class Opt:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    opts = Opt(verbose=True, username='foo', password='bar')
    parser, opts, args = parseOpts([
        '--verbose', '--username=foo', '--password=bar'])
    assert opts.__dict__ == opts.__dict__

    opts = Opt(verbose=True, username='foo', password='bar')
    parser, opts, args = parseOpts([
        '--ignore-config', '--verbose', '--username=foo', '--password=bar'])
    assert opts.__dict__ == opts.__dict__

    opts = Opt()

# Generated at 2022-06-12 19:04:23.513606
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts()[1]

    if opts.verbose:
        write_string(u'[debug] %s\n' % repr(opts.__dict__))

# Generated at 2022-06-12 19:04:35.867451
# Unit test for function parseOpts
def test_parseOpts():
    def test_impl(overrideArguments, expected_config, expected_cookiefile_set=False, expected_outtmpl_set=False):
        parser, opts, args = parseOpts(overrideArguments)
        assert opts.__dict__ == expected_config
        if expected_outtmpl_set:
            assert opts.outtmpl is not None
        else:
            assert opts.outtmpl is None
        if expected_cookiefile_set:
            assert opts.cookiefile is not None
        else:
            assert opts.cookiefile is None

# Generated at 2022-06-12 19:04:39.975159
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-12 19:04:51.975775
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts([])[1]

    assert opts.default_search == 'auto', opts.default_search  # default default_search
    assert opts.verbose == False, opts.verbose  # default verbose
    assert opts.quiet == False, opts.quiet  # default quiet

    opts = parseOpts(['--default-search', 'ytsearch', '-v'])[1]

    assert opts.default_search == 'ytsearch', opts.default_search
    assert opts.verbose == True, opts.verbose
    assert opts.quiet == False, opts.quiet

    opts = parseOpts(['--default-search', 'auto', '-v', '-q'])[1]


# Generated at 2022-06-12 19:05:03.722744
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl import YoutubeDL
    from optparse import OptionGroup
    from optparse import OptionParser
    from optparse import SUPPRESS_HELP

    opts, _args = youtube_dl.parseOpts(['--cachedir', '/video/cache', '-f', '22', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert isinstance(opts, youtube_dl.YoutubeDL), 'Result should be of type YoutubeDL'
    assert opts._default_downloader == 'f4m'

    # Testing -i option
    opts, _args = youtube_dl.parseOpts(['--ignore-config', '-i', '-i', '--hls-prefer-native', '-i', '--hls-prefer-ffmpeg'])
   

# Generated at 2022-06-12 19:05:34.940226
# Unit test for function parseOpts

# Generated at 2022-06-12 19:05:37.729098
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert type(opts) is optparse.Values
# parseOpts()


# Generated at 2022-06-12 19:05:46.173268
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts()[1]

# Generated at 2022-06-12 19:05:57.476882
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile

    def parse(s, *args):
        with tempfile.NamedTemporaryFile(mode='w+', suffix='.conf') as conf:
            conf.write(s)
            conf.flush()
            conf.seek(0)
            return parseOpts(*args, overrideArguments=['--config-location', conf.name])[0:3]

    p, o, a = parse('')
    if sys.version_info < (3,):
        assert o.ignoreconfig == 'utf-8'
    else:
        assert o.ignoreconfig == 'utf-8', type(o.ignoreconfig)
    assert o.logtostderr == 0, o.logtostderr
    assert o.forceurl == 0, o.forceurl

# Generated at 2022-06-12 19:05:58.609580
# Unit test for function parseOpts
def test_parseOpts():
    p, o, a = parseOpts(['-h'])


# Generated at 2022-06-12 19:06:09.453785
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-i', '-v', '--dump-user-agent', '--dump-interfaces', '--all-subs', '--extract-audio', '--verbose', '--restrict-filenames', '--list-extractors'])
    assert(opts.usenetrc == False)
    assert(opts.verbose == True)
    assert(opts.dump_user_agent == True)
    assert(opts.print_traffic == True)
    assert(opts.restrictfilenames == True)
    assert(opts.extractaudio == True)
    assert(opts.allsubtitles == True)
    assert(opts.dump_interfaces == True)
    assert(opts.list_extractors == True)

#

# Generated at 2022-06-12 19:06:18.058116
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', '22/17/best', 'rl0eVT0ONlI'])
    assert opts.format == ['22/17/best']
    assert args == ['rl0eVT0ONlI']
    parser, opts, args = parseOpts(['-f', 'best', '-f', 'worst', 'rl0eVT0ONlI'])
    assert opts.format == ['best', 'worst']
    assert args == ['rl0eVT0ONlI']


# Generated at 2022-06-12 19:06:26.527072
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(None)
    assert not opts.usenetrc
    assert not opts.verbose
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    parser, opts, args = parseOpts(['-h'])
    assert opts.help
    parser, opts, args = parseOpts(['--usenetrc', '--verbose', '--verbose', 'foobar', '-o', 'ok.%(ext)s'])
    assert opts.usenetrc
    assert opts.verbose == 2
    assert opts.outtmpl == 'ok.%(ext)s'
    parser, opts, args = parseOpts(['--verbose', '--help'])


# Generated at 2022-06-12 19:06:30.755023
# Unit test for function parseOpts
def test_parseOpts():
    _, opts, _args = _real_initialize()
    assert opts.outtmpl == (u'%(title)s-%(id)s-%(format)s.%(ext)s')


# Generated at 2022-06-12 19:06:42.396045
# Unit test for function parseOpts
def test_parseOpts():

    if '--no-unit-test' in sys.argv:
        return

    from optparse import Option
    from tempfile import mkdtemp
    from shutil import rmtree

    tmpdir = mkdtemp(prefix='youtube-dl-test-config-')

# Generated at 2022-06-12 19:07:35.414205
# Unit test for function parseOpts
def test_parseOpts():
    def test_parse_config(s, allow_no_value=True):
        class FakeOpts:
            def __init__(self):
                self.verbose = False
        opts = FakeOpts()
        class FakeParser:
            def parse_args(argv):
                return opts, []
            def error(msg):
                raise optparse.OptionValueError(msg)
        parser, opts, args = parseOpts(FakeParser(), overrideArguments=s.split(' '))
        return opts

    opts = test_parse_config('--username asdf --password asdf')
    assert opts.username == 'asdf'
    assert opts.password == 'asdf'

    opts = test_parse_config('--username asdf --password-file ./passwords')

# Generated at 2022-06-12 19:07:45.893866
# Unit test for function parseOpts
def test_parseOpts():
    from io import BytesIO
    from tempfile import mktemp
    f = BytesIO()
    f.write(b"--no-playlist --yes-playlist")
    f.seek(0)
    filename = mktemp(prefix="youtube-dl-test")
    with open(filename, "wb") as f2:
        f2.write(b"--username=test\n--password=test")

# Generated at 2022-06-12 19:07:56.901758
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.ratelimit == None
    assert opts.retries == 10
    assert opts.buffer_size == 1024
    assert opts.noresizebuffer == False
    assert opts.playliststart == 1
    assert opts.playlistend == None
    assert opts.playlistreverse == False
    assert opts.playlistrandom == False
    assert opts.noplaylist == False
    assert opts.matchtitle == None
    assert opts.rejecttitle == None
    assert opts.max_downloads == None
    assert opts.min_filesize == None
    assert opts.max_filesize == None
    assert opts.date == None
    assert opt

# Generated at 2022-06-12 19:08:07.134796
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import os

# Generated at 2022-06-12 19:08:15.054179
# Unit test for function parseOpts
def test_parseOpts():
    # Test 1
    opt_args = ["-v"]

    parser, opts, args = parseOpts(opt_args)

    assert opts.verbose == True
    assert opts.verbose_count == 1

    # Test 2
    opt_args = ["-vv"]

    parser, opts, args = parseOpts(opt_args)

    assert opts.verbose == True
    assert opts.verbose_count == 2

    # Test 3
    opt_args = ["--verbose"]

    parser, opts, args = parseOpts(opt_args)

    assert opts.verbose == True
    assert opts.verbose_count == 1

    # Test 4
    opt_args = ["-q"]

    parser, opts, args = parseOpts(opt_args)

    assert opts

# Generated at 2022-06-12 19:08:19.559461
# Unit test for function parseOpts
def test_parseOpts():
  opts = parseOpts()
  if opts is None:
    print('parseOpts returned None')
    return False
  print('opts is:')
  import pprint
  pprint.pprint(opts[1])
  return True

test_parseOpts()
 


# Generated at 2022-06-12 19:08:30.478676
# Unit test for function parseOpts
def test_parseOpts():
    def check_parse(args, expected_attrs):
        parser, opts, args = parseOpts(args)
        for attr, value in expected_attrs.items():
            assert getattr(opts, attr) == value, 'Attribute %s is %s, expected %s' % (attr, getattr(opts, attr), value)
    check_parse(['-i'], {'ignoreerrors': True})
    check_parse(['--ignore-errors'], {'ignoreerrors': True})
    check_parse(['--max-filesize', '2g'], {'max_filesize': 2 * 1024 * 1024 * 1024})
    check_parse(['-r', '10'], {'ratelimit': '10'})

# Generated at 2022-06-12 19:08:37.552512
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts([
        '-f', 'best',
        '--no-playlist',
        'http://www.youtube.com/watch?v=BaW_jenozKc'
    ]))
    # print(parseOpts(['--dump-user-agent']))

# ---------------------------------------------
# 				Url handling
# ---------------------------------------------
# Extracts video ids from a given string

# Generated at 2022-06-12 19:08:44.231875
# Unit test for function parseOpts
def test_parseOpts():
    """
    Unit test for function parseOpts
    :return:
    """
    # TODO: MAKE MORE TESTING
    # Test: Parse arguments and extract useful info
    args = ['-f', '241', 'https://www.youtube.com/watch?v=BaW_jenozKc', '2>log_stderr.txt',
            '--proxy', '127.0.0.1:8123',
            '--username', 'username', '--password', 'password',
            '--sleep-interval', '60', '--max-sleep-interval', '180',
            '--min-filesize', '2048', '--max-filesize', '4194304',
            '--playlist-start', '-1', '--playlist-end', '10']

# Generated at 2022-06-12 19:08:46.129929
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    parser, opts, args = parseOpts(argv)
