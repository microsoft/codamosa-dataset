

# Generated at 2022-06-12 18:59:57.716568
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-h'])

# Generated at 2022-06-12 19:00:01.677799
# Unit test for function parseOpts
def test_parseOpts():
    opts = []
    args = []
    try:
        parser, opts, args = parseOpts()
    except (OptionError, argparse.ArgumentError) as err:
        assert False, 'Parsing commandline options failed: %s' % str(err)
    assert opts.__dict__
    assert args


# Generated at 2022-06-12 19:00:11.585285
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-i', '-v'])[1].verbose  # Multiple short options can be combined

    assert parseOpts(['--verbose', '--format=bestvideo'])[1].verbose and \
        parseOpts(['--verbose', '--format', 'bestvideo'])[1].verbose  # Long options can have values

    fatals = ['--ignore-batsignal', '--ignore-config', '--no-continue', '--no-part']
    for fatal in fatals:
        assert not parseOpts([fatal])[1].verbose  # Fatal options should never emit debug output

    assert parseOpts(['--verbose'])[0].parse_args(['-v']).verbose  # Check if parser retains -v


# Generated at 2022-06-12 19:00:23.559896
# Unit test for function parseOpts

# Generated at 2022-06-12 19:00:37.004304
# Unit test for function parseOpts
def test_parseOpts():
    parser, opt, _ = parseOpts(['--username=testuser', '--password=testpass', '--video-password=testpass2', 'http://example.com'])
    assert 'testuser' in repr(parser.option_list)
    assert 'testpass' in repr(parser.option_list)
    assert 'testpass2' not in repr(parser.option_list)
    assert opt.username == 'testuser'
    assert opt.password == 'testpass'
    assert opt.videopassword == 'testpass2'

    parser, opt, _ = parseOpts(['--verbose', '--no-check-certificate', '--', 'http://example.com'])
    assert opt.verbose
    assert opt.nocheckcertificate
    assert opt.prefer_insecure

    parser,

# Generated at 2022-06-12 19:00:41.569863
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'UNIT TEST'])
    assert opts.username == 'UNIT TEST'

    parser, opts, args = parseOpts(['--proxy', 'socks5://bar.com:1080',
                                    '--no-check-certificate', '--verbose',
                                    '--ignore-config', '--extract-audio',
                                    '--audio-format', 'ogg',
                                    '--audio-quality', '9',
                                    '--recode-video', 'mp4',
                                    '--prefer-ffmpeg'])
    assert opts.proxy == 'socks5://bar.com:1080'
    assert opts.nocheckcertificate is True
    assert opts.verbose is True
    assert opts.extractaudio is True

# Generated at 2022-06-12 19:00:45.009996
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(None) is None
    assert parseOpts() is None
    assert parseOpts([]) is None

# Unit tests for function sanitize_open

# Generated at 2022-06-12 19:00:57.876992
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import orderedSet
    from collections import Iterable

    def test_parseOpts_one(opts, result):
        if not isinstance(opts, Iterable) or isinstance(opts, basestring):
            opts = [opts]
        parser, actual, args = parseOpts(opts)
        errmsg = '\nInput: %s\nExpected: %s\nActual:   %s' % (opts, result, actual)
        assert actual.usenetrc == result['usenetrc'], 'usenetrc %s' % errmsg
        assert actual.username == result['username'], 'username %s' % errmsg
        assert actual.password == result['password'], 'password %s' % errmsg

# Generated at 2022-06-12 19:01:09.479823
# Unit test for function parseOpts
def test_parseOpts():
    args = shlex.split('--proxy 127.0.0.1:3128 -f best,worst -o "/some/path/%(uploader)s/%(upload_date)s - %(title)s-%(id)s.%(ext)s"')
    opts = parseOpts(args)[1]

    assert opts.proxy == '127.0.0.1:3128'
    assert opts.outtmpl == '/some/path/%(uploader)s/%(upload_date)s - %(title)s-%(id)s.%(ext)s'
    assert opts.format == ['best', 'worst']

# Parse arguments and run the program

# Generated at 2022-06-12 19:01:19.040497
# Unit test for function parseOpts
def test_parseOpts():

    # Variables to store vars from parseOpts
    _, opts, args = parseOpts(['-f', '18', 'http://www.youtube.com/watch?v=BaW_jenozKc'])

    # Check Opts
    assert opts.format == '18'

    # Check Args
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    return

# Test parseOpts
if __name__ == '__main__':
    test_parseOpts()


# Generated at 2022-06-12 19:01:40.509381
# Unit test for function parseOpts

# Generated at 2022-06-12 19:01:49.701325
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.format is None
    assert opts.no_warnings is False
    assert opts.extract_flat is False
    assert opts.outtmpl is None
    assert opts.simulate is False
    assert opts.listformats is False
    assert opts.usagetitle is True
    assert opts.usenetrc is False
    assert opts.username is None
    assert opts.password is None
    assert opts.quiet is False
    assert opts.no_progress is False
    assert opts.console_title is False
    assert opts.noplaylist is False
    assert opts.playlist_start is 1
    assert opts.playlist_end is None
    assert opts.matchtitle is None
   

# Generated at 2022-06-12 19:01:59.263686
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import os

    def _test_parse_opts(self, *args, **kwargs):
        class TestParser(object):
            def error(self, msg):
                raise Exception(msg)

        class TestOpts(object):
            pass

        if kwargs.get('overrideArguments'):
            original = sys.argv[1:]
            sys.argv = sys.argv[:1] + kwargs.pop('overrideArguments')
        parser = TestParser()
        opts = TestOpts()
        args = []
        return parseOpts(parser=parser, opts=opts, args=args, *args, **kwargs)
    update_wrapper(_test_parse_opts, parseOpts)


# Generated at 2022-06-12 19:02:05.016185
# Unit test for function parseOpts
def test_parseOpts():
    continue_dl = True
    opts = Options()
    parser, _, _ = parseOpts(['-v'], opts)
    assert opts.verbose
    assert parser.has_option('-v')
    
    opts = Options()
    parser, _, _ = parseOpts(['--verbose'], opts)
    assert opts.verbose
    assert parser.has_option('-v')
    
    opts = Options()
    parser, _, _ = parseOpts(['--no-verbose'], opts)
    assert not opts.verbose
    assert parser.has_option('-v')
    
    opts = Options()
    parser, _, _ = parseOpts(['--no-continue'], opts)
    assert not continue_dl
    assert not opt

# Generated at 2022-06-12 19:02:12.828693
# Unit test for function parseOpts
def test_parseOpts():
    import YoutubeDL
    youtube_dl = YoutubeDL.YoutubeDL()
    parser, opts, args = parseOpts(overrideArguments=['-v','https://www.youtube.com/watch?v=U8HYbWV7v3s'])
    youtube_dl.process_ie_result(youtube_dl.extract_info('https://www.youtube.com/watch?v=U8HYbWV7v3s'))
    for opt in opts.__dict__:
        if getattr(opts, opt) != youtube_dl.params[opt]:
            print(opt,opts.__dict__[opt],youtube_dl.params[opt])
# END test_parseOpts()


# Generated at 2022-06-12 19:02:24.239189
# Unit test for function parseOpts
def test_parseOpts():
    # Make sure configuration processing works
    # (e.g. --no-check-certificate is not present in
    #  opts.specials as a side-effect of configuration parsing)
    parser, opts, args = parseOpts([
        '--username=foo', '--', 'bar', '-v', '--no-check-certificate', 'baz'])
    assert opts.username == 'foo'
    assert opts.specials == []
    assert args == ['bar', '-v', '--no-check-certificate', 'baz']
    parser, opts, args = parseOpts(['--', '--username=foo', 'bar', '-v', '--no-check-certificate', 'baz'])
    assert opts.username == None

# Generated at 2022-06-12 19:02:26.243164
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts()[1]
    assert opts.cachedir is not None




# Generated at 2022-06-12 19:02:30.858083
# Unit test for function parseOpts
def test_parseOpts():
    print(download_main(['-e','http://www.youtube.com/watch?v=BaW_jenozKc'],True))


# Generated at 2022-06-12 19:02:33.894918
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()
    return
# End of function test_parseOpts
# End of function parseOpts


# Generated at 2022-06-12 19:02:44.458431
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-F', 'youtubeurl'])
    assert opts.format == 'best'
    assert opts.extract_flat == 'best'
    assert opts.usenetrc is True
    assert opts.username == None
    assert opts.password == None
    assert opts.video_password == None
    assert args == ['youtubeurl']
    assert opts.playliststart == 1
    assert opts.playlistend == None

    parser, opts, args = parseOpts(['-F', 'youtubeurl1', 'youtubeurl2'])
    assert opts.format == 'best'
    assert args == ['youtubeurl1', 'youtubeurl2']

    parser, opts, args = parseOpts(['--format=22', 'youtubeurl'])

# Generated at 2022-06-12 19:03:02.108911
# Unit test for function parseOpts
def test_parseOpts():
    arguments = []
    parser, opts, args = parseOpts(arguments)
    assert opts.verbose is False
    assert opts.format is None
    assert opts.verbosity is 0
    assert opts.simulate is False
    assert opts.outtmpl is None
    assert opts.logtostderr is False
    assert opts.noprogressbar is False
    assert opts.encoding is None
    assert opts.writedescription is False
    assert opts.writeinfojson is False
    assert opts.writethumbnail is False
    assert opts.writesubtitles is False
    assert opts.writeautomaticsub is False
    assert opts.allsubtitles is False
    assert opts.listsubtitles is False
    assert opts.subtitleslang

# Generated at 2022-06-12 19:03:11.637615
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    p1, p1_filename = tempfile.mkstemp(suffix='.conf')
    p2, p2_filename = tempfile.mkstemp(suffix='.conf')
    with open(p1_filename, 'w') as f:
        f.write('-o "/tmp/%(playlist_index)s-%(title)s-%(id)s.%(ext)s"')

    with open(p2_filename, 'w') as f:
        f.write('-w')


# Generated at 2022-06-12 19:03:13.205059
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert opts.auto_number



# Generated at 2022-06-12 19:03:21.195194
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print(repr(parser), repr(opts), repr(args))
    parser, opts, args = parseOpts(['--get-title', '--get-thumbnail', '--get-id', 'https://www.youtube.com/watch?v=f_Gp6V9X6pI'])
    print(repr(parser), repr(opts), repr(args))
    parser, opts, args = parseOpts(['-q', '--dump-single-json', 'https://www.youtube.com/watch?v=f_Gp6V9X6pI'])
    print(repr(parser), repr(opts), repr(args))

test_parseOpts()


# Generated at 2022-06-12 19:03:31.552649
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeArgument

    def check_parse(args, expected):
        if isinstance(expected, dict):
            parser, opts, args = parseOpts(args)
            for prop, value in expected.items():
                eq_(getattr(opts, prop), value)
        else:
            opts, args = parseOpts(args)[1:]
            eq_(expected, args)
        return opts

    opts = check_parse(['-i', '--username', 'user', '--password', 'pass', 'yo'], [])
    assert not opts.username
    assert not opts.password
    assert opts.nopart

    check_parse(['-4', '--no-check-certificate'], dict(nocheckcertificate=True))

# Generated at 2022-06-12 19:03:40.729326
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from inspect import getsourcefile
    from os.path import abspath
    from os.path import dirname

    this_module_abspath = abspath(getsourcefile(lambda: 0))
    this_module_dirname = dirname(this_module_abspath)
    if not this_module_dirname in sys.path:
        sys.path.append(this_module_dirname)

    opts = parseOpts(argv)
    print("opts: ", opts) #.__dict__)


test_parseOpts()

#------------------------------------------------------------------------------


# Generated at 2022-06-12 19:03:50.429034
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.compat import compat_expanduser, compat_getenv

    fakehome = os.path.join(os.path.dirname(__file__), 'fakehome')
    fakeenv = os.path.join(fakehome, 'fakeenv')
    fakeconf = os.path.join(fakehome, 'fakeconf')
    fakeconf2 = os.path.join(fakehome, 'fakeconf2')
    fakeconf3 = os.path.join(fakehome, 'fakeconf3')
    fakeuserconf = os.path.join(fakehome, 'fakeuserconf')
    fakeuserconf2 = os.path.join(fakehome, 'fakeuserconf2')
    fakeuserconf3 = os.path.join(fakehome, 'fakeuserconf3')

# Generated at 2022-06-12 19:03:57.697960
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--ignore-config', '--username', 'foo', '--password', 'bar', '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio', '--output', '%(uploader)s/%(upload_date)s - %(title)s.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert not opts.usenetrc
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.outtmpl == '%(uploader)s/%(upload_date)s - %(title)s.%(ext)s'


# Generated at 2022-06-12 19:04:09.029044
# Unit test for function parseOpts
def test_parseOpts():
    def test_parse(args, expected):
        config, _ = parseOpts(args)
        assert expected == config

    # Test singlge-word options with the same name as the long option
    test_parse(['-o', 'val'], {'outtmpl': 'val'})
    test_parse(['--no-warnings'], {'noprogress': True})

    # Test that -o behaves like --output
    test_parse(['-o', 'val'], {'outtmpl': 'val'})

    parser, config, _ = parseOpts(['--get-title', '-v'])
    assert config.verbose
    assert config.gettitle
    assert config.noplaylist == parser.get_option('--no-playlist').default

    # Test no-option
    parser,

# Generated at 2022-06-12 19:04:18.552212
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.simulate == False

    opts, args = parseOpts(['-v'])
    assert opts.verbose == True

    opts, args = parseOpts(['--verbose'])
    assert opts.verbose == True

    opts, args = parseOpts(['-s'])
    assert opts.simulate == True

    opts, args = parseOpts(['--simulate'])
    assert opts.simulate == True
# Command-line program


# Generated at 2022-06-12 19:04:43.147141
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(["-v"])[1:]
    assert opts.verbose

    opts, args = parseOpts(["-w"])[1:]
    assert opts.nooverwrites

    opts, args = parseOpts(["--ignore-config"])[1:]
    assert opts.ignoreconfig

    opts, args = parseOpts(["--format", "22"])[1:]
    assert opts.format == ["22"]

    opts, args = parseOpts(["--format", "22/44/18"])[1:]
    assert opts.format == ["22/44/18"]

    opts, args = parseOpts(["--format", "22-18"])[1:]
    assert opts.format == ["22-18"]

    opts, args = parseOpt

# Generated at 2022-06-12 19:04:54.054131
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import mkstemp
    from textwrap import dedent
    from os import remove, close, environ

    # Setup a fake config file
    handle, configfile = mkstemp()
    config = "# Fake config\n-f 22\n-o /dev/null\n"
    fileobj = os.fdopen(handle, 'w')
    fileobj.write(dedent(config))
    fileobj.close()

    # Test reading the config file
    parser, opts, args = parseOpts(overrideArguments=["--config-location=%s" % configfile])
    assert opts.format == "22"
    assert opts.outtmpl == "/dev/null"

    # Test with --ignore-config

# Generated at 2022-06-12 19:05:05.331528
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import std_headers
    parser, opts, _ = parseOpts([])
    assert not opts.usenetrc
    assert opts.nocheckcertificate
    assert opts.min_filesize == 0
    assert opts.max_filesize == 0
    assert opts.writedescription
    assert opts.writeinfojson
    assert opts.writeannotations
    assert opts.sleep_interval == 300
    assert opts.retries == 10
    assert opts.continuedl
    assert opts.noprogress
    assert opts.keepvideo
    assert opts.ratelimit == '0'
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'

# Generated at 2022-06-12 19:05:07.629593
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts()
    
    print('[debug] Options: ', opts)
    print('[debug] Arguments: ', args)

# Generated at 2022-06-12 19:05:17.967845
# Unit test for function parseOpts

# Generated at 2022-06-12 19:05:22.091376
# Unit test for function parseOpts
def test_parseOpts():
    if '--noprogress' not in sys.argv:
        sys.argv.append('--noprogress')
    if '--verbose' not in sys.argv:
        sys.argv.append('--verbose')
    if '--dump-user-agent' not in sys.argv:
        sys.argv.append('--dump-user-agent')
    parseOpts()
# End of unit test for function parseOpts


# Generated at 2022-06-12 19:05:29.579492
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.noplaylist is False
    assert opts.usenetrc is False
    assert opts.login_username == 'test'
    assert opts.login_password == '12345'
    assert opts.password == '67890'

test_parseOpts()

# Generated at 2022-06-12 19:05:36.717851
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.usenetrc == False
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.dump_intermediate_pages == False
    assert opts.debug_printtraffic == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.restrictfilenames == False
    assert opts.nooverwrites == False
    assert opts.continuedl == True

# Generated at 2022-06-12 19:05:45.800750
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-f', '18', 'http://youtu.be/BaW_jenozKc'])[2] == ['http://youtu.be/BaW_jenozKc']
    assert parseOpts(['http://www.youtube.com/user/Scobleizer#p/u/1/1p3vcRhsYGo'])[2] == ['http://www.youtube.com/user/Scobleizer#p/u/1/1p3vcRhsYGo']

# Generated at 2022-06-12 19:05:50.232665
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    opts, _, _ = parseOpts(['-h'])
    if opts.help:
        print('%s: error: option -h/--help: ignored explicit argument' % argv[0])
    sys.exit(2)
#

# Generated at 2022-06-12 19:06:25.319973
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts([])
    assert opts.max_downloads is None
    assert opts.min_sleep_interval is None
    assert opts.max_sleep_interval is None
    parser, opts, _ = parseOpts(['--sleep-interval', '0.5'])
    assert opts.min_sleep_interval == 0.5
    assert opts.max_sleep_interval == 0.5
    parser, opts, _ = parseOpts(['-n', '10'])
    assert opts.max_downloads == 10
    parser, opts, _ = parseOpts(['--sleep-interval', '0.5-1.5'])
    assert opts.min_sleep_interval == 0.5
    assert opts.max_sleep

# Generated at 2022-06-12 19:06:37.689871
# Unit test for function parseOpts
def test_parseOpts():
    import argparse
    opts, args = parseOpts(
        ['--help', '--list-extractors'], overrideArguments=['-c', '--yes-playlist'])
    assert opts.cookiefile is None
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.videopassword is None
    assert not opts.usenetrc
    assert not opts.verbose
    assert not opts.quiet
    assert opts.ignoreerrors
    assert opts.forceurl
    assert opts.forcetitle
    assert opts.forceid
    assert opts.forcethumbnail
    assert not opts.forcedescription
    assert opts.simulate
    assert not opts.skip_download


# Generated at 2022-06-12 19:06:39.104692
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts()
# End of unit test for function parseOpts



# Generated at 2022-06-12 19:06:41.783991
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(None)[1]
    assert opts.call_home == True
    assert opts.no_call_home == False


# Generated at 2022-06-12 19:06:54.109471
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-g', '--get-url', '-e', '--get-title', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.geturl == True
    assert opts.gettitle == True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts(['-g', '--get-url', '-e', '--get-title', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.geturl == True
    assert opts.gettitle == True

# Generated at 2022-06-12 19:07:01.897256
# Unit test for function parseOpts
def test_parseOpts():
    from six import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import opts2dict
    with capture_stdout() as stdout:
        parseOpts(['--simulate', '-i', '--username', 'foo', '--password', 'bar'])
    assert '-i' in stdout
    assert '--username' not in stdout
    assert '--password' not in stdout

    with capture_stdout() as stdout:
        parseOpts(['-v', '--simulate', '-U'])
    assert '-U' in stdout

    with capture_stdout() as stdout:
        parseOpts(['-U', '--simulate'])
    assert '-U' not in stdout


# Generated at 2022-06-12 19:07:09.928310
# Unit test for function parseOpts
def test_parseOpts():
    from collections import namedtuple
    class Options(namedtuple('Options', 'urls username password verbose')):
        pass
    parser, opts, args = parseOpts([
        'http://example.com',
        'http://example2.com',
        '-u', 'user',
        '-p', 'pass',
        '-v'])
    options = Options(opts.urls, opts.username, opts.password, opts.verbose)
    assert options == Options(['http://example.com', 'http://example2.com'], 'user', 'pass', True)


# Generated at 2022-06-12 19:07:15.458369
# Unit test for function parseOpts
def test_parseOpts():
    # This function only tests the parsing of the arguments
    # Actual testing of the behaviour is done in test_YoutubeDL.test_parseOpts
    from tempfile import NamedTemporaryFile
    import youtube_dl.version

    def _get_args(argv):
        parser, opts, args = parseOpts(argv)
        return opts, args

    opts, args = _get_args([])
    assert opts.verbose is False, '--verbose should be False by default'
    assert opts.simulate is False, '--simulate should be False by default'
    assert opts.quiet is False, '--quiet should be False by default'
    assert opts.no_warnings is False, '--no-warnings should be False by default'

# Generated at 2022-06-12 19:07:21.205081
# Unit test for function parseOpts
def test_parseOpts():
    # Initialize the parser and check if the error exit status is correct
    parser, _, _ = parseOpts(overrideArguments=['-cfoo'])
    assert parser.exit_status == 2
    parser, _, _ = parseOpts(overrideArguments=['-h'])
    assert parser.exit_status == 0


# Generated at 2022-06-12 19:07:24.811884
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([
        '--download-archive', 'archive.txt',
        '--dump-user-agent',
        '--list-extractors',
        'https://youtube.com/watch?v=BaW_jenozKc'])
    assert parser
    assert opts
    assert args

# Actually execute the options

# Generated at 2022-06-12 19:07:58.792702
# Unit test for function parseOpts
def test_parseOpts():
    def test_parseSubOption(opts, exp_sublangs, exp_subformat, exp_subenc, exp_subcaps):
        sublangs, subformat, subenc, subcaps = _parseSubOption(opts)
        assert sublangs == exp_sublangs
        assert subformat == exp_subformat
        assert subenc == exp_subenc
        assert subcaps == exp_subcaps

    parser, opts, args = parseOpts(overrideArguments=['-f','18', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '18'
    assert not opts.usenetrc
    assert not opts.noprogress
    assert not opts.listformats
    assert not opts.list_thumbnails

# Generated at 2022-06-12 19:08:08.683969
# Unit test for function parseOpts
def test_parseOpts():
  # Testing the general options parsing
  opts, args = parseOpts([])
  assert(opts.username == None)
  assert(opts.password == None)
  assert(opts.quiet == False)
  assert(opts.verbose == False)
  assert(opts.simulate == False)
  assert(opts.geturl == False)
  assert(opts.gettitle == False)
  assert(opts.getid == False)
  assert(opts.getthumburl == False)
  assert(opts.getdescription == False)
  assert(opts.getfilename == False)
  assert(opts.getformat == False)
  assert(opts.no_warnings == False)
  assert(opts.ignoreerrors == False)

# Generated at 2022-06-12 19:08:14.201375
# Unit test for function parseOpts
def test_parseOpts():
    '''
    >>> old_stdout = sys.stdout
    >>> sys.stdout = StringIO()
    >>> opts, args = parseOpts(['--output', '%(title)s-%(id)s.%(ext)s', '--verbose'])
    >>> sys.stdout = old_stdout
    >>> opts.outtmpl
    '%(title)s-%(id)s.%(ext)s'
    >>> opts.verbose
    True
    '''


# Generated at 2022-06-12 19:08:19.125704
# Unit test for function parseOpts
def test_parseOpts():
    try:
        from io import StringIO
    except ImportError:  # The io module is new in 2.6
        from cStringIO import StringIO

    def assert_parse_args(args, expected_opts, expected_args=[]):
        import warnings
        warnings.filterwarnings('ignore', '.*imp module.*',)
        try:
            parser, opts, args = parseOpts(args)
        finally:
            warnings.resetwarnings()
        assert opts.__dict__ == expected_opts.__dict__
        assert sorted(args) == sorted(expected_args)

    orig_stdout = sys.stdout
    orig_stderr = sys.stderr

# Generated at 2022-06-12 19:08:29.461128
# Unit test for function parseOpts
def test_parseOpts():
    from .YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    from .postprocessor import PostProcessor
    from .downloader import HttpFD
    from .utils import DateRange
    import sys

    def _get_default_opts():
        opts, args = parseOpts([])
        newopts = optparse.Values(opts.defaults)
        newopts.__dict__.update(opts.__dict__)
        return newopts

    ydl = YoutubeDL(_get_default_opts())

    # Tests that the default values are properly set
    assert ydl.params['writedescription'] == False
    assert ydl.params['writeinfojson'] == False
    assert ydl.params['writesubtitles'] == False

# Generated at 2022-06-12 19:08:41.864402
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import escape_url
    import xml.etree.ElementTree as ET

    opts = [
        '--no-playlist',
        '--match-filter', '(^a|^b)',
        '--limit-rate', '5.5M',
        '--proxy', 'localhost:8080',
        'https://www.youtube.com/watch?v=BAhbBJ-x8xI',
        'https://www.youtube.com/watch?v=A0mYmZqfzmU',
        'http://example.com/'
    ]
    parser, opts, args = parseOpts(overrideArguments=opts)
    assert opts.ignoreerrors
    assert opts.no_warnings
    assert not opts.simulate
    assert opts

# Generated at 2022-06-12 19:08:53.359385
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-F', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1]

    assert(opts.format == 'bestvideo+bestaudio')
    opts = parseOpts(['-f', '22/18', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1]
    assert(opts.format == '22/18')

    opts = parseOpts(['-f', '22/bestvideo+bestaudio', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1]
    assert(opts.format == '22/bestvideo+bestaudio')

# ------------------------------------------------------------------------------


# Generated at 2022-06-12 19:09:00.658826
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1].format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4'
    assert parseOpts(['-g', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1].extract_flat == True
    assert parseOpts(['--netrc', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1].usenetrc == True
    # test for youtube-dl/youtube_dl#3588

# Generated at 2022-06-12 19:09:10.996735
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import format_bytes
    from youtube_dl.utils import match_filter_func

    # Test simulating an user configuration file
    # Simple test to detect errors in the options parser
    opts, args = _parseOpts(['-o', 'testing.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.outtmpl == 'testing.%(ext)s', 'Output template must be set correctly'

    opts, args = _parseOpts(['-o', 'testing.%(ext)s', '-o', 'testing2.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-12 19:09:13.177802
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(["-v"])[1]
    assert opts.verbose == True

# vi:noet:sw=4:ts=4

