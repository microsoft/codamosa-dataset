

# Generated at 2022-06-12 19:00:16.965287
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-F'])[1]
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'

    opts = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]'])[1]
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]'

    opts = parseOpts(['--prefer-free-formats'])[1]
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'


# Generated at 2022-06-12 19:00:26.367897
# Unit test for function parseOpts
def test_parseOpts():
    def _test(args, code, stdout='', stderr=''):
        code = os.path.join('test', code)
        args = ['--no-warnings', code] + args
        sys.argv = ['youtube-dl'] + args
        if os.path.exists(code):
            os.remove(code)
        assert not os.path.exists(code)
        parser, opts, args = parseOpts()

# Generated at 2022-06-12 19:00:37.628436
# Unit test for function parseOpts
def test_parseOpts():
    assert getopt(['-h'])[1].help == getopt(['--help'])[1].help

    (parser, opts, args) = getopt([])
    assert opts.usenetrc is False
    assert opts.username is None
    assert opts.password is None

    (parser, opts, args) = getopt(['--no-check-certificate'])
    assert opts.no_check_certificate is True

    (parser, opts, args) = getopt(['--verbose'])
    assert opts.verbose == 'True'

    (parser, opts, args) = getopt(['--quiet'])
    assert opts.quiet is True

    (parser, opts, args) = getopt(['-4'])
    assert opts.forceipv4

# Generated at 2022-06-12 19:00:50.579190
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(
        ['--proxy', '1.1.1.1:1234', '--playlist-reverse', 'foo.com',
         '--user', 'login', '--password', 'hunter2',
         '--username', 'l', '--password', 'p',
         '--username', 'l', '--password', 'p',
         'bar', '--', '--foo', 'bar'])
    assert opts.proxy == '1.1.1.1:1234'
    assert 'foo.com' in args
    assert opts.username == 'l'
    assert opts.password == 'p'
    assert '--playlist-reverse' not in args
    assert '--foo' in args
    assert 'bar' in args

    parser, opts, args = parse

# Generated at 2022-06-12 19:00:52.875534
# Unit test for function parseOpts
def test_parseOpts():
    parser_dummy, opts_dummy, args_dummy = parseOpts()

# }}}

# {{{ YoutubeDL


# Generated at 2022-06-12 19:01:05.807593
# Unit test for function parseOpts

# Generated at 2022-06-12 19:01:19.255627
# Unit test for function parseOpts
def test_parseOpts():
    _, opts, args = parseOpts(
        ['--username', 'foo', '--password', 'bar', 'arg'])
    assert len(args) == 1 and args[0] == 'arg'
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    _, opts, args = parseOpts(
        ['--cookies', 'cookies.txt', 'arg'])
    assert len(args) == 1 and args[0] == 'arg'
    assert opts.cookiefile == 'cookies.txt'
    _, opts, args = parseOpts(
        ['--ignore-config', '--default-search', 'ytdl', 'arg'])
    assert len(args) == 1 and args[0] == 'arg'
    assert opts.default_search

# Generated at 2022-06-12 19:01:27.374858
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.usenetrc == False
    parser, opts, args = parseOpts([])
    assert opts.username == None
    parser, opts, args = parseOpts([])
    assert opts.password == None
    parser, opts, args = parseOpts([])
    assert opts.twofactor == None
    parser, opts, args = parseOpts([])
    assert opts.videopassword == None


# Generated at 2022-06-12 19:01:35.610911
# Unit test for function parseOpts
def test_parseOpts():
    test_parseOpts_parser, test_parseOpts_opts, test_parseOpts_args = parseOpts()
    test = ['--verbose',
            '--get-url',
            'https://www.youtube.com/watch?v=OOHnNFf9MxA',
            '-o',
            'A:/video.mp4']
    test_parseOpts_parser, test_parseOpts_opts, test_parseOpts_args = parseOpts(overrideArguments = test)
# End of unit test for parseOpts


# Generated at 2022-06-12 19:01:44.087360
# Unit test for function parseOpts
def test_parseOpts():
    class Namespace(object):
        pass
    # Expand ~ to home directory
    opts = Namespace()
    opts.username = 'foo'
    opts.password = 'bar'
    opts.verbose = True
    opts.outtmpl = u'%(autonumber)s-%(title)s.%(ext)s'
    opts.autonumber_size = 2
    _, opts, _ = parseOpts(['--username=foo', '--password=bar', '--verbose', '-o', u'%(autonumber)s-%(title)s.%(ext)s', '--autonumber-size=2'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose is True
   

# Generated at 2022-06-12 19:02:08.856258
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts
    assert args
    # Testing the authentication option
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.videopassword is None
# testing parseOpts()
test_parseOpts()


# Generated at 2022-06-12 19:02:19.775033
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['--list-formats', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.list_formats
    opts, args = parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc', '-f', '5'])
    assert opts.format == '5'
    opts, args = parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert len(args) == 2

# Generated at 2022-06-12 19:02:20.770637
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass



# Generated at 2022-06-12 19:02:24.842530
# Unit test for function parseOpts
def test_parseOpts():
    from doctest import testmod
    results = testmod()
    if not results[0]:
        raise AssertionError('Unit test for parseOpts() in '
                             '__main__.py: %s failures, %s tests' % (results[1],results[0]))

# This function is used by parseOpts to read the configuration file

# Generated at 2022-06-12 19:02:28.483739
# Unit test for function parseOpts
def test_parseOpts():
    with patch('sys.argv', ['__main__']):
        parser, opts, _ = parseOpts()
        assert parser.has_option('-v')
        assert not parser.has_option('--default-search')


# Generated at 2022-06-12 19:02:42.008866
# Unit test for function parseOpts
def test_parseOpts():
    #values are separated by semicolons
    assert parseOpts('youtube-dl --format=[0];--extract-audio') ==  ['youtube-dl', '--format=[0]', '--extract-audio']
    assert parseOpts('youtube-dl --format=[0];--extract-audio --audio-format=mp3') == ['youtube-dl', '--format=[0]', '--extract-audio', '--audio-format=mp3']
    assert parseOpts('youtube-dl --format=[0];youtube-dl --format=[0]') == ['youtube-dl', '--format=[0]', 'youtube-dl', '--format=[0]']
    #no semicolons

# Generated at 2022-06-12 19:02:43.970957
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(overrideArguments =['--verbose', '-i'])
    print(opts)


# Generated at 2022-06-12 19:02:56.782936
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts([
        '--username', 'foo', '--password', 'bar',
        '--verbose', '--get-url',
        '--no-warnings',
        '--no-check-certificate',
        'http://example.com/foo', 'http://example.com/bar'])
    assertEqual(opts.username, 'foo')
    assertEqual(opts.password, 'bar')
    assertEqual(opts.verbose, True)
    assertEqual(opts.geturl, True)
    assertEqual(opts.nocheckcertificate, True)
    assertEqual(opts.quiet, False)
    assertEqual(opts.no_warnings, True)

# Generated at 2022-06-12 19:03:08.908420
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parseOpts_helper(args):
        parser, opts, args = parseOpts(args)
        return dict((k, v) for k, v in opts.__dict__.items() if not k.startswith('_'))

# Generated at 2022-06-12 19:03:18.593334
# Unit test for function parseOpts
def test_parseOpts():
    # create config file
    config = '--username testuser --password qwerty'
    with open(os.path.expanduser('~/.config/youtube-dl/config'), 'w') as f:
        f.write(config)
    # parse config file
    parser, opts, args = parseOpts()
    assert opts.username == 'testuser'
    assert opts.password == 'qwerty'
    # config file is ignored by default
    # parse commandline arguments
    parser, opts, args = parseOpts(['--username', 'testuser', '--password', 'qwerty'])
    assert opts.username == 'testuser'
    assert opts.password == 'qwerty'
    # overwrite config file

# Generated at 2022-06-12 19:03:47.342292
# Unit test for function parseOpts
def test_parseOpts():
    # Empty options
    parser, opts, args = parseOpts([])
    assert not opts.username
    assert not opts.password
    assert not opts.usenetrc
    assert opts.quiet
    assert opts.format == 'bestvideo+bestaudio'
    assert not opts.outtmpl
    assert opts.ignoreerrors
    assert not opts.geturl
    assert not opts.gettitle
    assert not opts.getid
    assert not opts.getthumbnail
    assert not opts.getdescription
    assert not opts.getfilename
    assert not opts.get_format_limit
    assert not opts.forceduration
    assert not opts.forcefilename
    assert not opts.forcejson
    assert not opts.simulate
    assert not opts.skip_download


# Generated at 2022-06-12 19:03:55.153922
# Unit test for function parseOpts
def test_parseOpts():
    assert '--config-location' not in sys.argv
    assert '--ignore-config' not in sys.argv
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False

    sys.argv = sys.argv + ['--config-location=/home/user/youtube-dl.conf',
                           '--ignore-config', '--format', '37']
    parser, opts, args = parseOpts()
    assert opts.format == '37'
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False


# Generated at 2022-06-12 19:04:07.781013
# Unit test for function parseOpts
def test_parseOpts():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'verbose': True})

    # No arguments
    parser, opts, args = parseOpts(ydl)
    assert args == []

# Generated at 2022-06-12 19:04:10.267980
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert(opts, type(parseOpts()) is tuple )


# Generated at 2022-06-12 19:04:22.617161
# Unit test for function parseOpts
def test_parseOpts():
    from . import YoutubeDL
    from .extractor import gen_extractors
    from .utils import get_cachedir, get_exe_version
    from .compat import str_or_none
    from .compat import urlopen
    from .postprocessor import supported_extensions
    from .version import __version__

    global opts, args

    try:
        from functools import reduce
    except ImportError:
        pass

    def _test_boolean_option(opt, expected_value=True):
        opts.__dict__[opt] = not expected_value
        opts, args = parseOpts(['--' + opt, '--verbose'])
        assert opts.__dict__[opt] is expected_value


# Generated at 2022-06-12 19:04:24.458345
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()


# Generated at 2022-06-12 19:04:28.568134
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod(
        name="parseOpts",
        optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS
    )



# Generated at 2022-06-12 19:04:34.973471
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test_value'])
    assert opts.username == 'unit_test_value'
    assert args == []
    parser, opts, args = parseOpts(['http://www.youtube.com/'])
    assert opts.username is None
    assert args == ['http://www.youtube.com/']

# Generated at 2022-06-12 19:04:40.224403
# Unit test for function parseOpts
def test_parseOpts():
    """
    Unit test for function parseOpts
    """
    parser, opts, args = parseOpts([])
    assert(opts is not None)
    assert(parser is not None)
    assert(args == [])



# Generated at 2022-06-12 19:04:52.296350
# Unit test for function parseOpts
def test_parseOpts():
    opt, args = parseOpts(['-h'])
    assert opt.help
    opt, args = parseOpts(['--version'])
    assert opt.version
    opt, args = parseOpts(['-U', 'xxx'])
    assert opt.usenetrc
    opt, args = parseOpts(['--usenetrc-file', 'xxx'])
    assert opt.usenetrc_file == 'xxx'
    opt, args = parseOpts([])
    assert opt.username is None
    opt, args = parseOpts(['-u', 'xxx'])
    assert opt.username == 'xxx'
    opt, args = parseOpts(['--username', 'xxx'])
    assert opt.username == 'xxx'
    opt, args = parseOpts(['--username', 'xxx'])

# Generated at 2022-06-12 19:05:37.889500
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts([])
    assert opts.extract_flat == 'in_playlist'
    assert opts.writethumbnail
    assert opts.writedescription
    assert opts.writeannotations
    assert opts.listformats
    assert opts.usenetrc
    assert opts.convertsubtitles
    assert opts.keepvideo
    assert opts.verbose
    assert opts.matchtitle == 'I know what you did last night'
    assert opts.matchfilter == '!is_live'
    assert opts.matchfilter == '!is_live'
    assert opts.matchfilter == '!is_live'
    assert opts.matchfilter == '!is_live'
    assert opts.matchfilter == '!is_live'


# Generated at 2022-06-12 19:05:43.408761
# Unit test for function parseOpts
def test_parseOpts():
    overrideArguments = None
    if sys.version_info < (3,):
        overrideArguments = [a.decode(preferredencoding()) for a in overrideArguments]

    parser, opts, args = parseOpts(overrideArguments)
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)

#Unit test for function _real_main

# Generated at 2022-06-12 19:05:50.779952
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)

# The command line argument --get-url is special
# it should not conflict with any of the other arguments,
# as it only makes sense on its own.
#
# This method does not return, it ends the program.

# Generated at 2022-06-12 19:06:01.081577
# Unit test for function parseOpts
def test_parseOpts():
    from .update import update_self
    from .utils import DEFAULT_OUTTMPL, DEFAULT_EXTRACT_AUDIO_FORMAT, DEFAULT_AUDIO_QUALITY, std_headers
    from .utils import encodeFilename
    from .extractor import gen_extractors
    from .postprocessor import gen_postprocessors

    # avconv
    opts, _ = parseOpts(['-f', 'best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.prefer_ffmpeg is False

    # ffmpeg
    opts, _ = parseOpts(['--prefer-ffmpeg', '-f', 'best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.prefer_

# Generated at 2022-06-12 19:06:07.185324
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', '-i', 'foo', '-f', 'best', 'bar'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.usenetrc == False
    assert opts.format == 'best'

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 19:06:19.359039
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import NamedTemporaryFile
    from os.path import basename

    def _check_option_parsing(argv, expected):
        parser, opts, args = parseOpts(argv)
        if expected != vars(opts):
            print('Expected %s, got %s' % (expected, vars(opts)))
            exit(1)
        if args != []:
            print('Expected [], got %s' % repr(args))
            exit(1)


# Generated at 2022-06-12 19:06:26.889430
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-f', '22', '-i', 'a'])[1]
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors
    assert opts.usenetrc
    assert opts.listformats == 22
    assert opts.usetitle
    try:
        opts = parseOpts(['-f', 'sdfsdfsdfsdf', 'a', 'b', 'c'])[1]
        assert False
    except SystemExit:
        pass

    opts = parseOpts(['-a', 'asdf'])[1]
    assert opts.batchfile == 'asdf'

    opts = parseOpts(['-i', '--max-filesize', '5m'])[1]

# Generated at 2022-06-12 19:06:35.138913
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    sys.argv=['youtube-dl', 'you.com', '-i', '--rate-limit', '20', '--proxy', 'http://localhost']

    from youtube_dl.options import parseOpts
    parser, opts, args = parseOpts()

    assert len(args) == 1
    assert args[0] == 'you.com'
    assert opts.proxy == 'http://localhost'
    assert opts.ratelimit == '20'
    assert opts.ignoreerrors == True

    return True
# parseOpts()


# Generated at 2022-06-12 19:06:47.467725
# Unit test for function parseOpts
def test_parseOpts():
    for opt, val in [('username', 'user'),
                     ('password', 'pwd'),
                     ('video_password', 'pass')]:
        parser, opts, args = parseOpts([opt, val], print_out=False)
        assert vars(opts)[opt] == val
        parser, opts, args = parseOpts([opt, '--' + opt, val], print_out=False)
        assert vars(opts)[opt] == val

        parser, opts, args = parseOpts([], overrideArguments=[opt, val], print_out=False)
        assert vars(opts)[opt] == val

        parser, opts, args = parseOpts([opt, '--' + opt, val], overrideArguments=[opt, val], print_out=False)

# Generated at 2022-06-12 19:06:50.472480
# Unit test for function parseOpts
def test_parseOpts():
    result = parseOpts()
    if result==False:
        return False
    else:
        return True

# Generated at 2022-06-12 19:08:06.179490
# Unit test for function parseOpts
def test_parseOpts():
    # Run parseOpts with an empty override argument list
    _parseOpts([])

# Return the unified version of all configuration files

# Generated at 2022-06-12 19:08:14.461747
# Unit test for function parseOpts
def test_parseOpts():
    from unittest import TestCase
    from collections import namedtuple
    from io import StringIO

    class Option(object):
        Atributes = ('dest', 'default', 'action', 'nargs', 'const', 'choices', 'help', 'metavar')

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __repr__(self):
            return '<%s %s %s %s>' % (
                self.__class__.__name__,
                self.dest,
                ' '.join('%s=%r' % (a, getattr(self, a)) for a in self.Atributes if getattr(self, a) is not None),
                self.help)


# Generated at 2022-06-12 19:08:24.614502
# Unit test for function parseOpts
def test_parseOpts():
    # FIXME: Should use unittest
    # Test unicode output
    sys.argv = ['you-get']
    sys.argv += ['-i']
    sys.argv += ['--json']
    sys.argv += ['https://www.youtube.com/watch?v=gq4F7VpbwP4']
    parser, opts, _ = parseOpts()
    # Test json output
    sys.argv = ['you-get']
    sys.argv += ['--info']
    sys.argv += ['https://www.youtube.com/watch?v=gq4F7VpbwP4']
    parser, opts, _ = parseOpts()
    # Test verbose output
    sys.argv = ['you-get']
    sys.argv += ['--verbose']

# Generated at 2022-06-12 19:08:37.553018
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts(['-F', 'http://url-to/video'])
    assert opts.format == 'best'
    assert opts.simulate is False
    assert opts.geturl is False
    assert opts.gettitle is False
    assert opts.getid is False
    assert opts.getthumb is False
    assert opts.getdescription is False
    assert opts.getfilename is False
    assert opts.get_format_preference is False
    assert opts.usenetrc is False
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.no_warnings is False
    assert opts.dump_user_agent is False
    assert opts.list_extractors is False
    assert opts.default_

# Generated at 2022-06-12 19:08:50.079771
# Unit test for function parseOpts

# Generated at 2022-06-12 19:08:57.561294
# Unit test for function parseOpts
def test_parseOpts():
    comma_separated_args = {
        'youtube-dl': ['--match-title', 'abc', '--match-title', '123', '--yes-playlist', 'https://www.youtube.com/watch?v=BaW_jenozKc'],
        'youtube-dl-2': ['--match-title', 'abc,123', '--yes-playlist', 'https://www.youtube.com/watch?v=BaW_jenozKc'],
    }
    for expected_args, argv in comma_separated_args.items():
        assert repr(parseOpts(argv.copy())[2]) == expected_args



# Generated at 2022-06-12 19:09:08.207335
# Unit test for function parseOpts
def test_parseOpts():
    # Test without arguments
    try:
        _, opts, args = parseOpts([])
        assert False, 'not supposed to reach this line'  # The previous line should throw an ValueError
    except ValueError:
        pass
    except:
        assert False, 'wrong exception'

    # Test with valid arguments
    _, opts, args = parseOpts(['url1', 'url2'])
    assert not opts.usenetrc
    assert not opts.verbose
    assert not opts.quiet
    assert not opts.no_warnings
    assert not opts.dump_user_agent
    assert not opts.dump_intermediate_pages
    assert not opts.write_pages
    assert not opts.search
    assert not opts.playliststart
    assert not opts.playlistend

# Generated at 2022-06-12 19:09:11.032648
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-f', '22/18/37', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[2] == ['22/18/37']



# Generated at 2022-06-12 19:09:15.662167
# Unit test for function parseOpts

# Generated at 2022-06-12 19:09:27.536705
# Unit test for function parseOpts
def test_parseOpts():
    from .__main__ import parseOpts

    err = 'usage: youtube-dl [options] url [url...]'

    old_stderr = sys.stderr
    sys.stderr = io.BytesIO()
    try:
        parseOpts([])
    except SystemExit as sys_e:
        assert sys_e.code == 2
    assert sys.stderr.getvalue().splitlines()[0].decode('utf-8') == err
    sys.stderr = old_stderr
# Parse arguments
parser, opts, args = parseOpts()

if opts.verbose:
    write_string('%s: Executing command \'youtube-dl\' with arguments:\n' % datetime.datetime.now().isoformat())