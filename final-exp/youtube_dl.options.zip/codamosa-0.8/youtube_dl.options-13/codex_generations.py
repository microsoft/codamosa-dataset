

# Generated at 2022-06-12 18:59:53.618809
# Unit test for function parseOpts
def test_parseOpts():
    create_temp_file('.conf', '-ci', '&&', '&&', 'listformats')
    with patch('sys.stderr', new_callable=io.StringIO) as stderr:
        with patch('sys.stdout', new_callable=io.StringIO) as stdout:
            _, __, ___ = parseOpts()
    assert stderr.getvalue() == u'ERROR: Invalid value for "--default-search"\n'
    assert stdout.getvalue() == u'usage: youtube-dl [options] url [url...]\n\n'



# Generated at 2022-06-12 18:59:57.613471
# Unit test for function parseOpts
def test_parseOpts():
	p, o, a = parseOpts()
	print([p, o, a])

#test_parseOpts()


# Generated at 2022-06-12 19:00:07.469628
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO

    class FakeOption (object):
        args = ''
        def __init__(self, **kw):
            vars(self).update(kw)

        def __repr__(self):
            return '%s(%s)' % (self.__class__.__name__, self.args)

    class FakeParser (object):
        class error (Exception):
            pass

        def __init__(self, **kw):
            vars(self).update(kw)

        def add_option(self, *args, **kwargs):
            self.option = FakeOption(args=args, kwargs=kwargs)
            return self.option


# Generated at 2022-06-12 19:00:14.673280
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    return doctest.testmod(parseOpts)
if __name__ == '__main__' and not os.environ.get('YTDL_NO_RUN') == '1':
    if sys.argv[1:2] == ['--test']:
        # Note: In order to add tests to this function, you must also update the
        # __doc__ (Doctest) of the function in order to have the tests run. You
        # can see an example of this in the __main__ of utils.py
        test_parseOpts()
    else:
        # Allow unit testing of the main by setting the environment variable
        # YTDL_NO_RUN to 1.
        main()

# Generated at 2022-06-12 19:00:22.880557
# Unit test for function parseOpts
def test_parseOpts():
    import urllib, urlparse

    parser, opts, args = parseOpts(['-i', '-f', '37/22/18', '-u', 'user', '-p', 'pass', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.format == ['37/22/18']
    assert opts.outtmpl == '%(stitle)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.sim

# Generated at 2022-06-12 19:00:29.341663
# Unit test for function parseOpts
def test_parseOpts():
    if os.name == 'nt':
        return
    class MockArgv(object):
        def __init__(self, argv):
            self.argv = argv

        def __call__(self, i):
            return self.argv[i]

        def __iter__(self):
            return iter(self.argv)

        def __len__(self):
            return len(self.argv)

    def _test(argv, expected_opts):
        with temp_file('config') as config_f:
            write_string(config_f.name, '[yt]\nusername = foo\npassword = bar\n')
            for i, a in enumerate(argv):
                if a == '%config':
                    argv[i] = '--config-location=%s' % config_

# Generated at 2022-06-12 19:00:39.873856
# Unit test for function parseOpts
def test_parseOpts():

    def check(data):
        parser, args = parseOpts(data)
        if sys.version_info < (3,):
            args = {k.decode('utf-8'): v.decode('utf-8') for k, v in args.__dict__.items()}
        return parser, args

    def check_eq(data, **assumptions):
        parser, args = check(data)
        for k, v in assumptions.items():
            assert args[k] == v

    # Check --autonumber
    check_eq(['-o', '%(autonumber)s-%(id)s.%(ext)s', '-a', '-'], outtmpl='1-%(id)s.%(ext)s', autonumber_start=1)

# Generated at 2022-06-12 19:00:52.544433
# Unit test for function parseOpts
def test_parseOpts():
    from types import SimpleNamespace
    # Some config files contain non-ASCII characters
    # Regression test for issue #1647
    from io import open
    with io.open('nonascii_config', 'wb') as f:
        f.write(
            compat_b('\n'.join((
                '-o "TEST \xc3\x8c"',
                '-a "test \xc3\x8c"'))))
    parser, opts, args = parseOpts([])
    assert (not args)
    assert opts.outtmpl == u'"TEST \xcc\x88"'
    assert opts.batchfile == 'test \xcc\x88'
    os.remove('nonascii_config')


# Generated at 2022-06-12 19:01:05.478657
# Unit test for function parseOpts
def test_parseOpts():
    def check_opts(opts):
        # get the default values
        default_values = default_opts.__dict__.copy()
        _add_default_args(default_values)
        # check if the options are the same as the defaults
        return opts == default_values

    parser, opts, _ = parseOpts(['--no-check-certificate', '--ignore-config'])

    if not check_opts(opts.__dict__):
        errstr = '--ignore-config does not have the same effect as if no config files were present:\n'

# Generated at 2022-06-12 19:01:06.260544
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

# Generated at 2022-06-12 19:01:33.419151
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from unittest import TestCase
    from io import StringIO

    class T(TestCase):
        def _t(self, args, exp_opts, exp_args):
            sys.argv = ['youtube-dl'] + args
            parser, opts, args = parseOpts()
            for attr, val in exp_opts.items():
                self.assertEqual(getattr(opts, attr), val)
            self.assertEqual(args, exp_args)


# Generated at 2022-06-12 19:01:42.302888
# Unit test for function parseOpts
def test_parseOpts():
    # test if the default value is set
    parser, opts, _ = parseOpts()
    assert opts.outtmpl == u'%(id)s.%(ext)s'
    assert opts.autonumber_size == 3
    assert opts.autonumber_start == 1

    # no test for autonumber option

    # test long options
    parser, opts, _ = parseOpts(['--no-check-certificate'])
    assert opts.nocheckcertificate

    parser, opts, _ = parseOpts(['--youtube-skip-dash-manifest'])
    assert opts.ydl_opts['youtube_skip_dash_manifest']

    parser, opts, _ = parseOpts(['--add-header', 'Foo:Bar'])
    assert opts

# Generated at 2022-06-12 19:01:50.205915
# Unit test for function parseOpts
def test_parseOpts():
    options = parseOpts(overrideArguments=['-i', '--verbose', '--get-url', '--list-formats', '--youtube-skip-dash-manifest', '-o', '%(id)s.f%(format_id)s.%(ext)s', '--', 'http://youtube.com/watch?v=BaW_jenozKc'])[1]
    assert options.verbose==True
    assert options.geturl==True
    assert options.listformats==True
    assert options.youtube_skip_dash_manifest==True
    assert options.outtmpl=='%(id)s.f%(format_id)s.%(ext)s'


# Generated at 2022-06-12 19:01:55.805864
# Unit test for function parseOpts
def test_parseOpts():
    args = ['--newline', '--no-progress', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc']
    res = parseOpts(args)
    for i in ['newline', 'noprogress']:
        assert getattr(res[1], i)
# End Unit test for function parseOpts



# Generated at 2022-06-12 19:02:02.559320
# Unit test for function parseOpts
def test_parseOpts():
    exit_called = False
    def _fake_exit(val):
        assert val == 1
        global exit_called
        exit_called = True
    def _fake_parser_error(parser, msg):
        assert parser == 'errmsg'
    def _fake_getprog_tuple():
        return 'yt-dl', 'yt-dl', '1.2.3'
    def _fake_write_string(s):
        assert s.strip().endswith('errmsg')
    class _fake_optparse_OptionParser(object):
        def add_option(self, *args, **kwargs):
            pass
    class _fake_optparse_Option(object):
        def __init__(self, *args, **kwargs):
            pass

# Generated at 2022-06-12 19:02:12.244401
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.usenetrc == False
    assert opts.password == None
    assert opts.username == None
    assert opts.ap_password == None
    assert opts.ap_username == None
    assert opts.usenetrc_machine == None
    assert opts.usenetrc_password == None
    assert opts.usenetrc_username == None
    assert opts.no_check_certificate == False
    assert opts.format == None
    assert opts.match_filter == None
    assert opts.reject_filter == None
    assert opts.list_extractors == False
    assert opts.list_formats == False
    assert opts.list_subtitles == False
    assert opts.writeaut

# Generated at 2022-06-12 19:02:23.653018
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(overrideArguments=['-v', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

    opts, args = parseOpts(overrideArguments=['https://www.youtube.com/watch?v=BaW_jenozKc', '-v'])
    assert opts.verbose == False
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

    opts, args = parseOpts()
    assert opts.verbose == False
    assert args == []


# Generated at 2022-06-12 19:02:37.007579
# Unit test for function parseOpts
def test_parseOpts():
    parser,opts,args = parseOpts()
    # test if opts.subtitle is True, so that the caption could be downloaded
    assert opts.subtitle == True
    # test if the opts.verbose is False, so the youtube-dl is running in quiet mode.
    assert opts.verbose == False
    # test if the opts.outtmpl is None, so that the default name will be used for the caption download.
    assert opts.outtmpl == None
    # test if the opts.writesubtitles is True, so that the caption file will be downloaded.
    assert opts.writesubtitles == True
    # test if the opts.subtitleslangs is not None, so that the caption will be downloaded in the specified language.
    assert opts.subtitleslangs != None


# Generated at 2022-06-12 19:02:46.614641
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeArgument
    from .extractor.common import InfoExtractor
    import tempfile
    import os
    import shutil

    (fd1, file1) = tempfile.mkstemp(prefix='ytdl_test_')
    (fd2, file2) = tempfile.mkstemp(prefix='ytdl_test_')
    (fd3, file3) = tempfile.mkstemp(prefix='ytdl_test_')

    os.write(fd1, '-i\n')
    os.write(fd1, '-v\n'.encode(preferredencoding()))
    os.write(fd2, '-i\n')

    os.write(fd3, (encodeArgument('-i') + '\n').encode('utf-8'))

   

# Generated at 2022-06-12 19:02:49.911284
# Unit test for function parseOpts
def test_parseOpts():
    print('Parse command-line arguments')
    parser, opts, args = parseOpts()
    assert opts.verbose
    assert opts.usenetrc

# Generated at 2022-06-12 19:03:29.355078
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import list_extractors
    import tempfile

    with tempfile.TemporaryFile('w+t') as tfile:
        tfile.write('--extractor-descriptions\n')
        tfile.seek(0)
        parser, opts, args = parseOpts(overrideArguments=tfile)
        for ie in list_extractors(age_limit=0):
            ie_desc = ie.IE_DESC
            ie_desc = ie_desc[0].upper() + ie_desc[1:].lower()
            ie_desc = re.sub(r'(?<!\n)\n(?!\n)', ' ', ie_desc)
            ie_desc = re.sub(r'\n\n+', '\n\n', ie_desc)
            ie_desc

# Generated at 2022-06-12 19:03:40.129963
# Unit test for function parseOpts
def test_parseOpts():
    def test(args):
        parser, opts, _ = parseOpts(args)
        return parser, opts

    from nose.tools import assert_equal

    parser, opts = test(['--username', 'foo', '--password', 'bar', '--verbose', 'BgIUQ0bRM6M'])
    assert_equal(opts.verbose, True)
    assert_equal(opts.username, 'foo')
    assert_equal(opts.password, 'bar')

    parser, opts = test(['--username', 'foo', '--password', 'bar', '--verbose', 'BgIUQ0bRM6M', '--config-location', '/tmp/alt.conf'])
    assert_equal(opts.verbose, True)

# Generated at 2022-06-12 19:03:49.889168
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import mkdtemp
    from shutil import rmtree
    def _test_parseOpts(conf, expected):
        opts, _, _ = parseOpts(conf)
        for k, v in expected.items():
            assert v == getattr(opts, k), 'Conflict for option %s' % k
    _test_parseOpts(['--username', 'foo', '--password', 'bar'],
                    {'username': 'foo', 'password': 'bar'})
    _test_parseOpts(['--username', 'foo', '--password', 'bar', '--usenetrc'],
                    {'username': None, 'password': None})

# Generated at 2022-06-12 19:03:57.399613
# Unit test for function parseOpts
def test_parseOpts():
    def assert_raises(args, error):
        parser, opts, args = parseOpts(args.split(' '))
        try:
            parser.error(error)
        except:
            pass

    assert_raises('-f 22', 'illegal -f argument')
    assert_raises('--format 22', 'illegal --format argument')
    assert_raises('-f 22 -f 23', 'illegal -f argument')
    assert_raises('--format 22 --format 23', 'illegal --format argument')
    assert_raises('-f bestvideo+bestaudio', 'illegal -f argument')
    assert_raises('--format bestvideo+bestaudio', 'illegal --format argument')
    assert_raises('-f bestvideo -f bestaudio', 'conflicting --format options')

# Generated at 2022-06-12 19:04:08.841596
# Unit test for function parseOpts
def test_parseOpts():
    opts, _args = parseOpts([])
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'

# Generated at 2022-06-12 19:04:21.149555
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts([])
    assert opts.simulate is False
    assert opts.geturl is False
    assert opts.gettitle is False
    assert opts.getid is False
    assert opts.getthumb is False
    assert opts.getdescription is False
    assert opts.getfilename is False
    assert opts.getformat is False
    assert opts.userto is False
    assert opts.user is False
    assert opts.playingurl is False
    assert opts.listsubtitles is False
    assert opts.listsizes is False
    assert opts.verbose is False
    assert opts.dump_intermediate_pages is False
    assert opts.writeinfojson is False
    assert opts.writedescription is False

# Generated at 2022-06-12 19:04:33.900644
# Unit test for function parseOpts
def test_parseOpts():
    # Test help generation
    parser, opts, args = parseOpts(['--help'])
    if '-h' in sys.argv:
        parser.print_help()
    assert opts is None
    assert args is None
    # Test parsing
    opts1 = _parseOpts(['url1', 'url2'])
    assert opts1.default_search == 'auto'
    opts2 = _parseOpts(['-g', 'url1', 'url2'])
    assert opts2.default_search == 'fixup_error'
    opts3 = _parseOpts(['url1', 'url2', '--no-playlist'])
    assert opts3.noplaylist is True

# Generated at 2022-06-12 19:04:35.025801
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts)



# Generated at 2022-06-12 19:04:42.684586
# Unit test for function parseOpts
def test_parseOpts():
    test_output_template = 'output_template'
    test_args = ['-f', 'best', '-o', test_output_template, 'https://www.youtube.com/watch?v=BaW_jenozKc']
    _, opts, args = parseOpts(test_args)
    assert opts.outtmpl == test_output_template
    assert opts.format == 'best'
    assert opts.usenetrc == False


# Generated at 2022-06-12 19:04:53.642722
# Unit test for function parseOpts

# Generated at 2022-06-12 19:06:01.384033
# Unit test for function parseOpts
def test_parseOpts():
    # Example 1
    # Input
    # Expected Output:
    #    Error during parsing options
    try:
        parser, opts, args = parseOpts(overrideArguments=['--username', '-i'])
    except SystemExit:
        raise AssertionError('Failed to parse option')

    # Example 2
    # Input
    # Expected Output:
    #    Error during parsing options
    try:
        parser, opts, args = parseOpts(overrideArguments=['--username', '', '-i'])
    except SystemExit:
        raise AssertionError('Failed to parse option')

    # Example 3
    # Input
    # Expected Output:
    #    Error during parsing options

# Generated at 2022-06-12 19:06:06.956779
# Unit test for function parseOpts
def test_parseOpts():
    url = 'https://www.youtube.com/watch?v=_HSylqgVYQI'
    assert parseOpts([url])[2] == [url]

    url = 'https://www.youtube.com/watch?v=_HSylqgVYQI&feature=youtu.be&t=83'
    assert parseOpts([url])[2] == [url]

    url = 'https://www.youtube.com/watch?v=GiPixZO_x28'
    assert parseOpts([url, '-o', '%(id)s-%(title)s.%(ext)s'])[2] == [url]
    assert parseOpts([url, '-o', '@%(id)s.%(ext)s'])[2] == [url]

# Generated at 2022-06-12 19:06:19.359963
# Unit test for function parseOpts
def test_parseOpts():
    # Testing --version
    # _, opts, _ = parseOpts(['--version'])
    # assert opts.version is True
    # _, opts, _ = parseOpts(['-U'])
    # assert opts.version is True
    # _, opts, _ = parseOpts(['--update'])
    # assert opts.version is True

    # Testing --extract-audio
    _, opts, _ = parseOpts(['--extract-audio'])
    assert opts.extractaudio is True

    # Testing -x
    _, opts, _ = parseOpts(['-x'])
    assert opts.extractaudio is True

    # Testing --audio-format

# Generated at 2022-06-12 19:06:27.924169
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    # Test the initializing function
    try:
        parseOpts()
    except SystemExit as e:
        return e.code
    # Test indivisual options
    assert parseOpts(['-h'])[0].help == False
    assert parseOpts(['-v'])[0].verbose == 1
    assert parseOpts(['-u', 'xXxXxXxXx'])[0].username == 'xXxXxXxXx'
    assert parseOpts(['-p', 'xXxXxXxXx'])[0].password == 'xXxXxXxXx'
    assert parseOpts(['-s'])[0].simulate == True

# Generated at 2022-06-12 19:06:40.137573
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import match_filter_func
    from youtube_dl.YoutubeDL import YoutubeDL
    import inspect
    import sys
    from io import StringIO
    import os

    test_args = ['-ciw', '--no-warnings', '--ignore-errors', '--flat-playlist', '--match-filter', '(?<=hello).*', '--', 'http://www.my-example.com/video.mp4', 'http://www.youtube.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts(test_args)

    assert opts.verbose is False
    assert opts.ignoreerrors is True
    assert opts.dump_intermediate_pages is True
    assert opts.writeinfojson is True
    assert opts.us

# Generated at 2022-06-12 19:06:52.674976
# Unit test for function parseOpts
def test_parseOpts():
    # I've just copied and pasted this test from the previous versions of parseOpts
    from io import StringIO
    orig_stdout = sys.stdout
    orig_stderr = sys.stderr
    sys.stdout = stdout = StringIO()
    sys.stderr = stderr = StringIO()

    try:
        import getpass
        user_name = getpass.getuser()
    except ImportError:
        user_name = 'test'

    parser, opts, args = parseOpts(['-i', '--username', user_name])
    assert opts.username == user_name
    assert opts.password == None
    parser, opts, args = parseOpts(['-i', '--username', user_name, '--password', 'blabla'])
    assert opts

# Generated at 2022-06-12 19:06:54.893504
# Unit test for function parseOpts
def test_parseOpts():
    try:
        init()
        parser, opts, args = parseOpts()
    except:
        return False

# Create a youtube-dl instance from command line arguments

# Generated at 2022-06-12 19:07:02.324267
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', '37/22/18', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == ['37/22/18']
    assert opts.youtube_include_dash_manifest is True
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert opts.youtube_include_dash_manifest is True
    assert opts.usenetrc is True
    assert opts.default_search == 'auto'
    assert opts.password is None
    assert opts.dump_intermediate_pages is False
    assert opts.no_warnings is False
    assert opts.postprocessor_args is None
    assert opts.skip_download

# Generated at 2022-06-12 19:07:06.787460
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import OptionParser
    parser, opts, args = parseOpts(['-v'])
    assert(isinstance(parser, OptionParser))
    assert(opts.verbose)
    assert(not args)


# Return the value of the --output parameter

# Generated at 2022-06-12 19:07:17.146500
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'testusr', '-P', 'testpass', '-i', 'test'])
    assert opts.username == 'testusr'
    assert opts.password == 'testpass'
    assert opts.usenetrc == False

    parser, opts, args = parseOpts(['-n', '-u', 'testusr', '-p', 'testpass', '-i', 'test'])
    assert opts.username == 'testusr'
    assert opts.password == 'testpass'
    assert opts.usenetrc == True

    parser, opts, args = parseOpts(['-i', 'test'])
    assert opts.username == None
    assert opts.password == None

# Generated at 2022-06-12 19:08:26.359091
# Unit test for function parseOpts
def test_parseOpts():
    from StringIO import StringIO

    class Args(object):
        def __init__(self, s):
            self.args = s

        def __iter__(self):
            for arg in self.args:
                yield arg

        def __getitem__(self, key):
            return self.args[key]

    def run_parseOpts(args, overrideArguments=None):
        orig_stderr = sys.stderr
        orig_stdout = sys.stdout
        orig_argv = sys.argv
        sys.stderr = stderr = StringIO()
        sys.stdout = stdout = StringIO()
        sys.argv = Args(args)
        p, o, a = parseOpts(overrideArguments)
        sys.stderr = orig_stderr


# Generated at 2022-06-12 19:08:30.799235
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(overrideArguments=None)
    if opts.verbose:
        write_string('[debug] Reference config: ' + repr(_hide_login_info(sys.argv[1:])) + '\n')


# Generated at 2022-06-12 19:08:42.609914
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts([
        '--sleep-interval', '60',
        'https://www.youtube.com/watch?v=BaW_jenozKc'
    ])
    assert(opts.sleep_interval == 60)
    assert(args[0] == 'https://www.youtube.com/watch?v=BaW_jenozKc')
    opts, args = parseOpts([
        'https://www.youtube.com/watch?v=BaW_jenozKc'
    ])
    assert(opts.sleep_interval == 1)
    assert(args[0] == 'https://www.youtube.com/watch?v=BaW_jenozKc')




# Generated at 2022-06-12 19:08:54.187542
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(None)
    assert opts.verbose == False
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert opts.usetitle == False
    assert opts.noplaylist == True
    assert opts.format == None
    assert opts.format_limit == None
    
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert opts.usetitle == False
    assert opts.noplaylist == True
    assert opts.format == None
    assert opts.format_limit == None
    
    parser, opts, args = parseOpt

# Generated at 2022-06-12 19:09:05.885956
# Unit test for function parseOpts
def test_parseOpts():
    from nose.tools import assert_equal
    from nose.tools import assert_true
    from nose.tools import assert_false

# Generated at 2022-06-12 19:09:07.263979
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod(option_parsing)


# Generated at 2022-06-12 19:09:15.531230
# Unit test for function parseOpts
def test_parseOpts():
    # Test user_conf
    with patch('os.path.expanduser', return_value='/home/youtube-dl/youtube-dl.conf'):
        with patch('youtube_dl.options.open', create=True) as mock_open:
            mock_open.side_effect = [
                io.StringIO('--ign'),
                io.StringIO('--no-conf --conf-second end'),
                io.StringIO('--conf-first '),
            ]
            _, opts, _ = parseOpts(['-U'])
            assert opts.username == '-U'
            assert opts.password == ''
            assert not opts.nopart
            assert not opts.verbose
            assert opts.ratelimit == '0'
            assert opts.retries == 10

# Generated at 2022-06-12 19:09:27.375807
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def check(args, exp):
        parser, opts, args = parseOpts(args)
        for key in exp:
            assert getattr(opts, key) == exp[key], 'Expected %s != %s for option %s' % (exp[key], getattr(opts, key), key)
        if '_args' in exp:
            assert args == exp['_args'], 'Expected %s != %s for positional args' % (exp['_args'], args)