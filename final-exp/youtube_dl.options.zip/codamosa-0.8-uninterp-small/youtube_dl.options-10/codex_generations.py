

# Generated at 2022-06-26 13:33:56.212947
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert len(parser.option_groups) == 27
    assert len(parser.option_list) == 98
    assert not opts.autonumber
    assert opts.no_warnings
    assert not args


# Generated at 2022-06-26 13:33:59.338550
# Unit test for function parseOpts
def test_parseOpts():
    # Test cases
    test_case_0()

    if __name__ == '__main__':
        test_parseOpts()
        print("Unit test completed.")

# Generated at 2022-06-26 13:34:04.075364
# Unit test for function parseOpts
def test_parseOpts():
    # print ('*******Starting test of function parseOpts')

    test_case_0()
    # print ('*******End of test of function parseOpts')


# Generated at 2022-06-26 13:34:09.383537
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except Exception as e:
        print('[!] Exception for parseOpts()')
        print('Exception:', e)


if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:34:12.852856
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:34:23.499287
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

    # Test default arguments
    assert not opts.getwebpage
    assert not opts.geturl
    assert not opts.gettitle
    assert not opts.getthumbnail
    assert not opts.getdescription
    assert not opts.getfilename
    assert not opts.get_format
    assert not opts.get_id
    assert not opts.getduration
    assert not opts.dump_single_json
    assert not opts.dump_json
    assert not opts.dump_single_json
    assert not opts.dump_intermediate_pages
    assert not opts.print_stdout
    assert not opts.simulate
    assert not opts.skip_download
    assert not opts.quiet
    assert opts.format == None
   

# Generated at 2022-06-26 13:34:30.313967
# Unit test for function parseOpts
def test_parseOpts():
    print("Start function test for function parseOpts")
    print(time.strftime('%X %x %Z'))
    test_case_0()
    print(time.strftime('%X %x %Z'))
    print("End test case")

# Test
test_parseOpts()

# Generated at 2022-06-26 13:34:32.845366
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except Exception:
        import traceback
        traceback.print_exc()

# Profiling unit test for function parseOpts

# Generated at 2022-06-26 13:34:35.751277
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts())
    print('Tests for parseOpts passed')

# Generated at 2022-06-26 13:34:37.286115
# Unit test for function parseOpts
def test_parseOpts():
    var_1 = parseOpts()

# ad-hoc test
# test_case_0()


# Generated at 2022-06-26 13:35:13.011720
# Unit test for function parseOpts
def test_parseOpts():
    assert_raises(TypeError, test_case_0)

# Generated at 2022-06-26 13:35:15.008260
# Unit test for function parseOpts
def test_parseOpts():
    import logging.config
    logging.basicConfig(level=logging.ERROR)
    test_case_0()

#
# Run unit tests
#

# Generated at 2022-06-26 13:35:16.933448
# Unit test for function parseOpts
def test_parseOpts():
    ## Test Case 0
    yield test_case_0



# Generated at 2022-06-26 13:35:28.524985
# Unit test for function parseOpts
def test_parseOpts():
    # Do not test the function if it is not called.
    if parseOpts.called == False:
        print('\033[31m' + "parseOpts() is not called" + '\033[0m')
        return
    # Do not test the function if it is not called with expected number of arguments.
    if parseOpts.num_args != 3:
        print('\033[31m' + "parseOpts() does not have the expected number of arguments" + '\033[0m')
        return

    parser = optparse.OptionParser()
    opts = argparse.Namespace()
    args = []
    opts_parseOpts = parseOpts(parser, opts, args)
    
    # The value returned by parseOpts.
    parseOpts_return = [parser, opts, args]


# Generated at 2022-06-26 13:35:39.084402
# Unit test for function parseOpts
def test_parseOpts():

    #test 1
    (parser, opts, args) = parseOpts(['-h'])
    assert opts.help == True
    assert opts.h == True

    #test 2
    (parser, opts, args) = parseOpts(['--verbose'])
    assert opts.verbose == True
    assert opts.v == True

    #test 3
    (parser, opts, args) = parseOpts(['-f'])
    assert opts.format == None

    #test 4
    (parser, opts, args) = parseOpts(['--no-playlist'])
    assert opts.noplaylist == True

    #test 5
    (parser, opts, args) = parseOpts(['--playlist-start'])

# Generated at 2022-06-26 13:35:40.707863
# Unit test for function parseOpts
def test_parseOpts():
    # Test case 0
    print ('Testing case 0')
    var_0 = parseOpts()

if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:35:46.980102
# Unit test for function parseOpts
def test_parseOpts():
    if not hasattr(sys, 'frozen'):
        # Skip the test if this frozen binary was not compiled with pyo
        test_case_0()

if __name__ == "__main__":
    if sys.argv[1] =='test':
        test_parseOpts()
    else:
        parseOpts(sys.argv[1:])

# Generated at 2022-06-26 13:35:47.751762
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:35:49.354063
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:35:51.179264
# Unit test for function parseOpts
def test_parseOpts():
    print('test_parseOpts() being used')
    test_case_0()


# Generated at 2022-06-26 13:36:28.126979
# Unit test for function parseOpts
def test_parseOpts():
    assert test_case_0() == None


# Generated at 2022-06-26 13:36:31.853837
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing function parseOpts ...')

    # Call test case function
    test_case_0()

    print('Testing function parseOpts ... PASSED')


# Generated at 2022-06-26 13:36:38.325089
# Unit test for function parseOpts
def test_parseOpts():
    vq = printWithColor
    timeFormat = '%Y-%m-%d %H:%M:%S'
    curDate = time.strftime(timeFormat)
    runTestCase(test_case_0, {'printWithColor':vq, 'timeFormat':timeFormat, 'curDate':curDate})


# Generated at 2022-06-26 13:36:42.072470
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:36:51.841841
# Unit test for function parseOpts
def test_parseOpts():
    print('Start to test parseOpts')
    test_case_0()
    print('Finish test parseOpts')
#
# def _real_initialize():
#     parser, opts, args = parseOpts()
#     opts.password = compat_str_type(opts.password)
#
#     if opts.version:
#         print(__version__)
#         sys.exit()
#
#     if opts.extract_flat:
#         print('--extract-flat is deprecated, use "-J" instead')
#         opts.extract_flat = False
#         opts.print_json = True
#
#     if opts.print_json and not opts.outtmpl:
#         opts.outtmpl = '-'
#
#     return parser, opts,

# Generated at 2022-06-26 13:36:53.762915
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Main function

# Generated at 2022-06-26 13:36:59.126558
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = None
    var_1 = parseOpts(var_0)
    assert var_1

# End of test_parseOpts

if __name__ == '__main__':
    test_parseOpts()
    test_case_0()
    pass

# Generated at 2022-06-26 13:37:02.209686
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert(opts.username == 'foo')


# Generated at 2022-06-26 13:37:08.307228
# Unit test for function parseOpts
def test_parseOpts():
    self_get_0 = test_case_0()
    assert_equal(self_get_0, ('self', {}, ['']))
    assert_equal(self_get_0, ('self', {}, ['']))

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:37:12.053571
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:38:32.598112
# Unit test for function parseOpts
def test_parseOpts():
    print("test_parseOpts()")
    test_case = unittest.TestSuite()
    test_case.addTest(TestCase("test_case_0"))
    result = unittest.TextTestRunner(verbosity=2).run(test_case)

    print(result)
    if result.failures:
        sys.exit(1)

if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:38:35.859622
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    return var_0


# Default options, already processed by parseOpts
default_options = None



# Generated at 2022-06-26 13:38:37.933310
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()


# Generated at 2022-06-26 13:38:42.304478
# Unit test for function parseOpts
def test_parseOpts():
    parser, options, args = test_case_0()
    if parser == True and options == True and args == True:
        print('test_parseOpts: Success')
    else:
        print('test_parseOpts: Fail')

test_parseOpts()

# Generated at 2022-06-26 13:38:49.955202
# Unit test for function parseOpts
def test_parseOpts():
    funcName = sys._getframe().f_code.co_name
    
    print(funcName + ":")
    test_case_0()
    return 0

# Program entrance
if __name__ == '__main__':
    try:
        test_parseOpts()
    except:
        traceback.print_exc()

# Generated at 2022-06-26 13:38:50.626148
# Unit test for function parseOpts
def test_parseOpts():
    print(test_case_0())


# Generated at 2022-06-26 13:38:52.779517
# Unit test for function parseOpts
def test_parseOpts():
    # Test case 0:
    test_case_0()

if __name__ == "__main__":
    test_parseOpts()
    sys.exit(1)

# Generated at 2022-06-26 13:38:57.079215
# Unit test for function parseOpts
def test_parseOpts():
    assert 'parseOpts' in globals(), 'Function "parseOpts" is not defined'
    test_case_0()
    test_case_0()


# Generated at 2022-06-26 13:39:02.838270
# Unit test for function parseOpts

# Generated at 2022-06-26 13:39:06.207774
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = [sys.argv[0]]

    test_case_0()

    return


# Generated at 2022-06-26 13:41:48.338261
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing parseOpts...')
    test_case_0()
    print('Done!')

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:41:51.721276
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    assert var_0 != None 

if __name__ == "__main__":
    var_0 = parseOpts()
    print(var_0)

# Generated at 2022-06-26 13:42:03.930082
# Unit test for function parseOpts
def test_parseOpts():
    # mock of sys.argv
    sys.argv = ['http://www.youtube.com/watch?v=BaW_jenozKc']
    # mock of sys.stderr
    sys.stderr = StringIO()
    # mock of sys.stdin
    sys.stdin = StringIO()
    # mock of sys.stdout
    sys.stdout = StringIO()
    # mock of sys.version_info
    sys.version_info = (2, 7, 13, 'final', 0)
    # mock of sys.version
    sys.version = "2.7.13 (default, Jul 18 2017, 09:17:00) \n[GCC 4.2.1 Compatible Apple LLVM 8.1.0 (clang-802.0.42)]"

# Generated at 2022-06-26 13:42:08.274284
# Unit test for function parseOpts
def test_parseOpts():
    func = parseOpts
    func_name = 'parseOpts'
    func_args = [ ]
    # Call function
    try:
        func(*func_args)
    except:
        # Print traceback if needed
        traceback.print_exc()
        # Raise an error
        raise ValueError('Test failure in function <%s>' % func_name)
    # Return args
    return func_args



# Generated at 2022-06-26 13:42:11.686666
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing parseOpts')
    test_case_0()

if sys.version_info[0] > 2:
    unicode = str

# Function to strip HTML tags from a given string

# Generated at 2022-06-26 13:42:15.545612
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

if __name__ == '__main__':
    # test_parseOpts()
    pass

# Generated at 2022-06-26 13:42:23.656481
# Unit test for function parseOpts
def test_parseOpts():
    if not (hasattr(os, '_wrapped')):
        os.environ['PYTHONPATH'] = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
    #check the function works correctly
    test_case_0()

if __name__ == '__main__' and __package__ is None:
    test_parseOpts()

# Generated at 2022-06-26 13:42:25.541039
# Unit test for function parseOpts
def test_parseOpts():
    print("Test parseOpts")
    parseOpts()


# Generated at 2022-06-26 13:42:30.166169
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: Add command line arguments and execute test in the next line.
    # assert test_case_0() == None
    print("This test function hasn't been properly implemented yet.")


# Generated at 2022-06-26 13:42:32.337628
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()