

# Generated at 2022-06-26 13:34:02.880085
# Unit test for function parseOpts

# Generated at 2022-06-26 13:34:04.519211
# Unit test for function parseOpts
def test_parseOpts():
    assert_equals(test_case_0(),None)

# Generated at 2022-06-26 13:34:07.250646
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()

# Test function parseOpts
test_parseOpts()


# Generated at 2022-06-26 13:34:09.487062
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Print statement for the function parseOpts

# Generated at 2022-06-26 13:34:14.890227
# Unit test for function parseOpts
def test_parseOpts():
    print('=== Testing function ' + test_case_0.__name__)
    test_case_0()
    print('=== Test passed')
# -------------------------------------------------------- 9


# -------------------------------------------------------- 10

# Generated at 2022-06-26 13:34:23.050261
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    if opts.version:
        print('%s %s' % (__title__, __version__))
    elif not opts.playlist_start > 0:
        opts.playlist_start = 1
    if opts.prefer_insecure:
        opts.prefer_ffmpeg = True
    if opts.simulate:
        opts.quiet = True
    if opts.dump_intermediate_pages:
        opts.verbose = True
    if opts.nooverwrites:
        opts.ignoreerrors = True
    if opts.skip_download:
        opts.quiet = True
    if opts.writeinfojson:
        opts.quiet = True
    if opts.writedescription:
        opts

# Generated at 2022-06-26 13:34:35.189788
# Unit test for function parseOpts
def test_parseOpts():
    _input = ['--match-filter', 'speed>0.2', 'https://www.youtube.com/watch?v=tvukPmVxBGs']
    _input = [
        '--match-filter', 'speed>0.2',
        '--match-filter', 'speed<0.2',
        '--match-filter', 'speed=0.2',
        '--match-filter', 'speed!=0.2',
        '--match-filter', 'speed>=0.2',
        '--match-filter', 'speed<=0.2',
        'https://www.youtube.com/watch?v=tvukPmVxBGs'
    ]

# Generated at 2022-06-26 13:34:45.722331
# Unit test for function parseOpts
def test_parseOpts():
    test_passed = True
    test_failed = False

    try:
        test_case_0()
    except Exception as e:
        test_passed = False
        write_string('\nFAILURE - EXCEPTION THROWN WHILE TESTING parseOpts()\n')
        write_string(str(e))
        write_string('\nLINENO - {0}\n'.format(sys.exc_info()[2].tb_lineno))
        write_string('\nCALL STACK\n')
        for line in traceback.format_stack():
            write_string(line)
        write_string('\n\n------\n\n')
    except AssertionError as e:
        test_passed = False

# Generated at 2022-06-26 13:34:49.225564
# Unit test for function parseOpts
def test_parseOpts():
    assert callable(parseOpts)

#
# Specific tests for individual functions in parseOpts
#

import sys


# Generated at 2022-06-26 13:34:53.096697
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    assert (var_0 == (parseOpts, parseOpts, parseOpts))

######### End of parseOpts


######### test_case_1

# Generated at 2022-06-26 13:35:12.638810
# Unit test for function parseOpts
def test_parseOpts():
    # Make sure we have a test case for each of the possible paths in parseOpts
    # This test will fail when new branches are added
    # Add new test cases as needed to get 100% branch coverage
    try:
        test_case_0()
    except:
        pass



# Generated at 2022-06-26 13:35:14.215869
# Unit test for function parseOpts
def test_parseOpts():
    assert func_name.get_func_name() == 'test_parseOpts'


# Generated at 2022-06-26 13:35:26.985847
# Unit test for function parseOpts
def test_parseOpts():
    try:
        assert( not os.path.exists('test_parseOpts.out') )
    except OSError as e:
        unittest.skip("I/O error({0}): {1}".format(e.errno, e.strerror))

    sys.argv = ['youtube-dl', '--help']
    parseOpts()
    assert( os.path.exists('test_parseOpts.out') )
    with open("test_parseOpts.out", "r") as f:
        content = f.read()
    assert("--hls-prefer-native" in content)
    assert("--xattr-set-filesize" in content)
    os.remove("test_parseOpts.out")


# Generated at 2022-06-26 13:35:36.043145
# Unit test for function parseOpts
def test_parseOpts():
    from inspect import getargspec, getmembers, isfunction

    # First, let's make sure this is a function
    assert isfunction(parseOpts)

    # The number of arguments should be 3
    assert len(getargspec(parseOpts)[0]) == 1

    # Make sure we use the right number of arguments
    try:
        parseOpts(1)
    except TypeError:
        pass
    else:
        assert False, "parseOpts() didn't use the right number of arguments"



# Generated at 2022-06-26 13:35:43.139132
# Unit test for function parseOpts
def test_parseOpts():
    # Test case 0
    try:
        test_case_0()
        write_string("Test Case 0 passed.\n")
    except Exception:
        write_string("Test Case 0 failed.\n")

# Main
if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:35:49.179959
# Unit test for function parseOpts
def test_parseOpts():

    ret_1 = test_case_0()
    return

if __name__ == '__main__':
    import sys

    # If this script is called by itself, run all tests.
    # Otherwise, run specific function.

    args = sys.argv
    args = args[1:]

    if 'test_parseOpts' in args:
        test_parseOpts()
    else:
        print('Error: No test case.')
        print('Please specify a test case.')
        print('For example: "python ydl_opts.py test_parseOpts".')

# Generated at 2022-06-26 13:35:50.105050
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()
    return True


# Generated at 2022-06-26 13:35:53.542272
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing for parseOpts ... ', end='')
    try:
        test_case_0()
        print('Pass')
    except:
        print('Fail')
        exit()

# Utility functions for unit test

# Generated at 2022-06-26 13:35:55.245297
# Unit test for function parseOpts
def test_parseOpts():
    print(">>> Unit test for parseOpts")
    test_case_0()
    print(">>> Unit test for parseOpts is done")


# Generated at 2022-06-26 13:36:01.245596
# Unit test for function parseOpts
def test_parseOpts():

    test_case_0()


import platform
PY_MAJOR, PY_MINOR, PY_MICRO = sys.version_info[0:3]

# Compat hack until we can support Python 2.6
if sys.version_info < (2, 7):
    import struct
    import functools

    # _find_unsafe is copied from Python 3.2.3's urllib.parse.
    def _find_unsafe(s, charset):
        """Return character that are not in a given charset.

        This function returns characters from s that are not in charset.
        charset may be a str, a bytes-like object or a callable. Function
        is inspired by the re.escape function.

        """
        if isinstance(charset, str):
            unsafe_chars = set

# Generated at 2022-06-26 13:36:23.404184
# Unit test for function parseOpts
def test_parseOpts():
    for i in range(1):
        try:
            test_case_0()
        except Exception as e:
            print('Test Exception : ' + str(e))
            raise
        else:
            print('Test Case 0 : Pass')


# Generated at 2022-06-26 13:36:28.220907
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    # Test to check if this is a tuple
    if not isinstance(var_0, tuple):
        raise TypeError("value expected to be {0}, is {1}".format(
            tuple, type(var_0)))
    # Test to check if the length is 3
    if len(var_0) != 3:
        raise ValueError("value expected to have 3 elements, has {0}".format(len(var_0)))
    # Test to check if this is an instance of optparse.OptionParser
    if not isinstance(var_0[0], optparse.OptionParser):
        raise ValueError("value expected to be {0}, is {1}".format(
            optparse.OptionParser, type(var_0[0])))
    # Test to check if this is an instance of optparse

# Generated at 2022-06-26 13:36:32.571735
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts() == None

if __name__ == '__main__':
    test_case_0()
    #test_parseOpts()

# vim: expandtab shiftwidth=4 tabstop=4

# Generated at 2022-06-26 13:36:43.918943
# Unit test for function parseOpts
def test_parseOpts():
    x = parseOpts()
    assert x[0] is not None
    assert x[1].usenetrc is not False
    assert x[1].call_home is not None
    assert x[1].outtmpl is not None
    assert x[1].outtmpl_na_placeholder is "NA"
    assert x[1].autonumber_size is None
    assert x[1].autonumber_start is 1
    assert x[1].restrictfilenames is False
    assert x[1].useid is False
    assert x[1].autonumber is False
    assert x[1].usetitle is False
    assert x[1].continue_dl is True
    assert x[1].nooverwrites is False
    assert x[1].nopart is False
    assert x[1].up

# Generated at 2022-06-26 13:36:58.387043
# Unit test for function parseOpts
def test_parseOpts():
    class TestFailed(Exception):
        pass

    parser = argparse.ArgumentParser()
    parser.add_argument('-b', '--blah', action='store_true')
    parser.add_argument('-c', '--cblah', nargs='?', default='abc')
    parser.add_argument('-d', '--dblah')
    parser.add_argument('-a', '--ablah', action='store_true', dest='a')
    parser.add_argument('--blah0', action='append')
    parser.add_argument('--blah1', action='append', default=[1])
    parser.add_argument('--blah2', action='append', default=[1, 2])
    parser.add_argument('--blah3', action='append', default=[1, 2, 3])

# Generated at 2022-06-26 13:37:03.455462
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import io
    input = sys.stdin.read()
    sys.stdin = io.StringIO(input)
    test_case_0()

# Unit testing for function _parse_date

# Generated at 2022-06-26 13:37:05.733706
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except Exception:
        print("Fail: ")
        traceback.print_exc()
    else:
        print("Pass")

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:37:13.410826
# Unit test for function parseOpts
def test_parseOpts():
    import os
    import shutil
    # we use a temporary directory to raise exceptions in case we
    # have state leaks
    os.mkdir('test_parseopts')
    os.mkdir('test_parseopts/temp/a data dir')
    shutil.copyfile('README.md', 'test_parseopts/temp/a data dir/non empty file')
    os.mkdir('test_parseopts/temp/a data dir/temp')

# Generated at 2022-06-26 13:37:19.051756
# Unit test for function parseOpts
def test_parseOpts():
    with open("parseOpts_unitTest.txt", "w") as output:
        old_stdout = sys.stdout
        sys.stdout = output
        
        test_case_0()
        
        sys.stdout = old_stdout

test_parseOpts()

# Generated at 2022-06-26 13:37:22.787731
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()

    # var_0 is a OptionParser
    assert isinstance(var_0, OptionParser)


# Generated at 2022-06-26 13:37:45.473545
# Unit test for function parseOpts
def test_parseOpts():
    print("*** Testing function 'parseOpts'")
    test_case_0()


# Generated at 2022-06-26 13:37:47.347001
# Unit test for function parseOpts
def test_parseOpts():
    test_cases = [0]
    for test_case in test_cases:
        if test_case == 0:
            test_case_0()


# Generated at 2022-06-26 13:37:51.379922
# Unit test for function parseOpts
def test_parseOpts():
    # Test for parsing command-line arguments
    test_case_0()



# No arguments

# Generated at 2022-06-26 13:37:53.708277
# Unit test for function parseOpts
def test_parseOpts():
    case_0()

# End of file test


# Generated at 2022-06-26 13:37:57.110356
# Unit test for function parseOpts
def test_parseOpts():
    print ("test_parseOpts")
    test_case_0()
    print ("test_parseOpts done.")


# Generated at 2022-06-26 13:38:00.646695
# Unit test for function parseOpts
def test_parseOpts():
    print('Starting test test_parseOpts ')
    test_case_0()
    print('Test OK')

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:38:06.370407
# Unit test for function parseOpts
def test_parseOpts():
    # var_0 = parseOpts()
    # assert_equal(var_0, '__main__.parseOpts')
    test_case_0()

if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:38:14.472855
# Unit test for function parseOpts
def test_parseOpts():
    cli_args = None
    var_0 = parseOpts(cli_args)
    var_1 = parseOpts(cli_args)
    var_2 = parseOpts(cli_args)
    var_3 = parseOpts(cli_args)
    var_4 = parseOpts(cli_args)
    var_5 = parseOpts(cli_args)
    var_6 = parseOpts(cli_args)
    var_7 = parseOpts(cli_args)
    var_8 = parseOpts(cli_args)
    var_9 = parseOpts(cli_args)
    var_10 = parseOpts(cli_args)
    var_11 = parseOpts(cli_args)
    var_12 = parseOpts(cli_args)

# Generated at 2022-06-26 13:38:25.958166
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing function: parseOpts... ', end='', flush=True)

    actual_file_name = 'test_parseOpts.actual'
    sys.argv[0] = 'youtube-dl'
    sys.argv[1:] = [
        '--playlist-start', '1',
        '--playlist-end', '3']
    test_case_0()
    with open(actual_file_name, 'r', encoding='utf-8') as actual_file:
        actual_value = actual_file.read()
    expected_file_name = 'test_parseOpts.expected'
    with open(expected_file_name, 'r', encoding='utf-8') as expected_file:
        expected_value = expected_file.read()
    os.remove(actual_file_name)

# Generated at 2022-06-26 13:38:28.453678
# Unit test for function parseOpts
def test_parseOpts():
    var = parseOpts()
    assert type(var) is tuple


# Generated at 2022-06-26 13:39:07.591073
# Unit test for function parseOpts
def test_parseOpts():
    for i in range(10):
        test_case_0()
    var_9 = parseOpts()


# Generated at 2022-06-26 13:39:11.004047
# Unit test for function parseOpts
def test_parseOpts():
    print("---------------")
    print("test_parseOpts")
    test_case_0()
    print("---------------")



# Generated at 2022-06-26 13:39:19.560066
# Unit test for function parseOpts

# Generated at 2022-06-26 13:39:23.717606
# Unit test for function parseOpts
def test_parseOpts():
    try:
        if callable(parseOpts):
            test_case_0()
    except IOError as e:
        print (str(e))


# Generated at 2022-06-26 13:39:30.763662
# Unit test for function parseOpts
def test_parseOpts():
    from random import randint
    from copy import copy

    # test default options
    parser, opts, args = parseOpts()
    assert opts.usenetrc is False
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.simulate is False
    assert opts.format is None
    assert opts.listformats is False
    assert opts.forceformat is False
    assert opts.geturl is False
    assert opts.gettitle is False
    assert opts.getid is False
    assert opts.default_search is 'auto'
    assert opts.nooverwrites is False
    assert opts.playliststart is 1
    assert opts.playlistend is 0
    assert opts.playlistreverse is False
    assert opts.playlist

# Generated at 2022-06-26 13:39:35.352422
# Unit test for function parseOpts
def test_parseOpts():
    # parseOpts without parameter.
    #
    # Try to parse some options without parameters.
    try:
        test_case_0()
    except Exception as exc:
        print('Error: ' + str(exc))

# Generated at 2022-06-26 13:39:38.886029
# Unit test for function parseOpts
def test_parseOpts():
    print('>>> test_parseOpts <<<')
    test_case_0()
    print('=== done with test_parseOpts ===')


# Generated at 2022-06-26 13:39:50.116942
# Unit test for function parseOpts

# Generated at 2022-06-26 13:39:55.636623
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
        assert True
    except AssertionError:
        print("Error occurred in testing function parseOpts")

if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:40:01.790673
# Unit test for function parseOpts
def test_parseOpts():
    print('\n  Test for parseOpts')
    print('  Calling: test_case_0()')
    test_case_0()
    print('\n  Test for parseOpts succeed!\n')


# Generated at 2022-06-26 13:41:26.281889
# Unit test for function parseOpts
def test_parseOpts():
  a = parseOpts()
  assert(a != None)

if __name__ == '__main__':
    #test_case_0()
    test_parseOpts()
    print('Test succeded')

# Generated at 2022-06-26 13:41:28.520627
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()


# Generated at 2022-06-26 13:41:30.106334
# Unit test for function parseOpts
def test_parseOpts():
    print("Test parseOpts")
    test_case_0()


# Generated at 2022-06-26 13:41:35.726915
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing unit for function parseOpts')
    try:
        test_case_0()
    except:
        return -1
    print('Test case finished without error')
    return 0


# Generated at 2022-06-26 13:41:37.862848
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    assert var_0 == 0


# Generated at 2022-06-26 13:41:39.967106
# Unit test for function parseOpts
def test_parseOpts():

    try:
        # Test case 0
        assert(test_case_0() == 
            'Test case 0 failed'
        )
    except:
        # Test case 0
        print('Test case 0 failed')

# Generated at 2022-06-26 13:41:45.867885
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing parseOpts function')
    print('\tTest 1, write your own test case here')
    test_case_0()

# Unit test runs only when the module is run stand-alone
if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:41:49.081058
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts(['-h'])
    assert (var_0[0].has_option('-h'))
    assert (var_0[0].has_option('--help'))
    assert (var_0[1].help == True)


# Generated at 2022-06-26 13:41:55.558432
# Unit test for function parseOpts

# Generated at 2022-06-26 13:42:00.942255
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
        print('[+] Test for function parseOpts success')
    except:
        print('[-] Test for function parseOpts failed')

# Main function of the module

# Generated at 2022-06-26 13:43:06.745365
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import inspect

    def fn():
        def func_1(arg):
            return test_case_0()

        if sys.version_info < (3,):
            func_1(u'--extract-audio')
        else:
            func_1('--extract-audio')
    test_cases = [fn]
    for index, test_case in enumerate(test_cases):
        if sys.version_info >= (3,):
            test_case_name = 'test_case_%d' % index
            test_case.__name__ = test_case_name

# Generated at 2022-06-26 13:43:14.902638
# Unit test for function parseOpts
def test_parseOpts():
    global var_0
    global var_1
    var_1 = None
    var_1 = None
    var_1 = None
    var_0 = None
    var_0 = None
    var_1 = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    var_0 = parseOpts(var_1)
    print(str(var_0))

# Main started from here


# Generated at 2022-06-26 13:43:18.984282
# Unit test for function parseOpts
def test_parseOpts():
    assert True == True

if __name__ == '__main__':
    test_parseOpts()
    test_case_0()

# Generated at 2022-06-26 13:43:20.894828
# Unit test for function parseOpts
def test_parseOpts():
    pass  # TODO: Write unit test


# Generated at 2022-06-26 13:43:29.451717
# Unit test for function parseOpts
def test_parseOpts():
    lib_path = os.path.abspath('.')
    sys.path.append(lib_path)

    import youtube_dl
    from youtube_dl.YoutubeDL import YoutubeDL

    if not hasattr(youtube_dl, '__version__'):
        print('version not found')
        sys.exit(1)

    # Setup options
    opt_parser, opts, args = parseOpts()
    ydl = YoutubeDL(opts)

    if hasattr(opts, 'simulate'):
        ydl.params['simulate'] = opts.simulate

    if hasattr(opts, 'quiet'):
        ydl.params['quiet'] = opts.quiet