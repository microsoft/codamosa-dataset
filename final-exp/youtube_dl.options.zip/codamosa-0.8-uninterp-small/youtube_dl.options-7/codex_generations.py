

# Generated at 2022-06-26 13:34:04.366570
# Unit test for function parseOpts
def test_parseOpts():
    # Test case 0
    test_case_0()

# End of unit tests

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:34:05.899093
# Unit test for function parseOpts
def test_parseOpts():
    pass  # FIXME: Test needs implementation


# Generated at 2022-06-26 13:34:06.813053
# Unit test for function parseOpts
def test_parseOpts():
    pass


# Generated at 2022-06-26 13:34:09.582460
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    if var_0 is not None:
        test_case_0()


# Generated at 2022-06-26 13:34:11.940447
# Unit test for function parseOpts
def test_parseOpts():
    res = parseOpts()

# Generated at 2022-06-26 13:34:16.992487
# Unit test for function parseOpts
def test_parseOpts():
    var_a = parseOpts()
    var_b = parseOpts()
    print("Test for parseOpts")
    print(var_a)
    print(var_b)
    # assert var_a == var_b

# Generated at 2022-06-26 13:34:25.173321
# Unit test for function parseOpts
def test_parseOpts():
    import random
    import sys
    random.seed(sys.version)
    for n in range(100):
        test_case_0()
    print('%s OK' % __file__)

# ----

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not,

# Generated at 2022-06-26 13:34:36.310036
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.usenetrc == True, ('Failed assert test_parseOpts #1')
    assert opts.outtmpl == '%(stitle)s-%(id)s.%(ext)s', ('Failed assert test_parseOpts #2')
    assert opts.nooverwrites == True, ('Failed assert test_parseOpts #3')
    assert opts.format is None, ('Failed assert test_parseOpts #4')
    assert opts.writedescription == False, ('Failed assert test_parseOpts #5')
    assert opts.embedsubtitles == False, ('Failed assert test_parseOpts #6')

# Generated at 2022-06-26 13:34:41.252680
# Unit test for function parseOpts
def test_parseOpts():
    print("[*] Start test_parseOpts")
    test_case_0()
    print("[*] End test_parseOpts")

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:34:45.475274
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert parser is not None
    assert opts is not None
    assert args is not None


# Generated at 2022-06-26 13:35:02.011443
# Unit test for function parseOpts
def test_parseOpts():
    print ("test_parseOpts: ")
    test_case_0()
    return 0


# Generated at 2022-06-26 13:35:02.618708
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:35:03.811394
# Unit test for function parseOpts
def test_parseOpts():
    print("test_parseOpts")
    assert test_case_0() == None


# Generated at 2022-06-26 13:35:10.621549
# Unit test for function parseOpts
def test_parseOpts():
    test_cases = [
        (0, ),
    ]
    for index, tc in enumerate(test_cases):
        try:
            test_case_0(*tc)
        except:
            print('Failed test case #%d: %s' % (index, repr(tc)))


# Generated at 2022-06-26 13:35:12.579039
# Unit test for function parseOpts
def test_parseOpts():
    # Test cases
    test_case_0()


# Generated at 2022-06-26 13:35:16.101298
# Unit test for function parseOpts
def test_parseOpts():
    var_1 = arguments
    with unittest.mock.patch("sys.argv", arguments):
        try:
            var_0 = parseOpts()
            var_1 = True
        except Exception:
            var_1 = False
    assert var_1
test_case_0()
test_parseOpts()

# Generated at 2022-06-26 13:35:25.879272
# Unit test for function parseOpts
def test_parseOpts():
    #global var_0 = parseOpts()

    with pytest.raises(SystemExit):
        var_0 = parseOpts()

    # test_case_0
    var_1 = parseOpts()
    #assert var_1 == 1
    #assert var_1 == 0
    #assert var_1 == 1


if __name__ == "__main__":
    sys.path.append(os.path.join(sys.path[0], '..'))
    from utils import *
    test_parseOpts()

# Generated at 2022-06-26 13:35:32.659689
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    entry0 = var_0[0]
    entry1 = var_0[1]
    entry2 = var_0[2]
    if (True):
        write_string('Expected output: \n')
    assert True


# Generated at 2022-06-26 13:35:39.710644
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-f', 'best', '-i', 'https://www.youtube.com/watch?v=_Hp_W-E8yvA'])
    assert opts.format == 'best'
    assert opts.ignoreerrors

if __name__ == "__main__":
    test_case_0()
    test_parseOpts()

# Generated at 2022-06-26 13:35:41.079049
# Unit test for function parseOpts
def test_parseOpts():
    logger.startTest('test_parseOpts')

    test_case_0()
    test_parse_openload_url()


# Generated at 2022-06-26 13:36:14.932986
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()
    return 0


# Generated at 2022-06-26 13:36:21.743815
# Unit test for function parseOpts
def test_parseOpts():
    args_in = []

    # Function call to function under test
    var_0 = parseOpts(args_in)

    # Check return type and value
    #assertVarType(var_0, unicode)
    assertVarValue(var_0, None)



# Generated at 2022-06-26 13:36:24.338066
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()

# Generated at 2022-06-26 13:36:26.196251
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    assert True # TODO: implement your test here


# Generated at 2022-06-26 13:36:27.892076
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Generated at 2022-06-26 13:36:31.343399
# Unit test for function parseOpts
def test_parseOpts():
    try:
        print("Test parseOpts")
        test_case_0()
    except:
        print("Test Case Failed: An exception occured")
        raise



# main program
if __name__ == "__main__":
    print("Testing Model Parser - parseOpts")
    test_parseOpts()

# Generated at 2022-06-26 13:36:39.225236
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    downloader_options = ('usenetrc', 'username', 'password', 'twofactor', 'videopassword', 'ap_mso', 'ap_username', 'ap_password', 'usenetrc', 'username', 'password')
    for option in parser.option_list:
        if not isinstance(option, (optparse.OptionGroup,)):
            assert option.dest in dir(opts) or option.dest in downloader_options


# Generated at 2022-06-26 13:36:41.748026
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:36:46.501639
# Unit test for function parseOpts
def test_parseOpts():
    # Test cases
    test_case_0()

# -----------------------------------------------------------------------------
# Begin main program
# -----------------------------------------------------------------------------

parseOpts()

if opts.help:
    _real_main()

# Generated at 2022-06-26 13:37:00.254677
# Unit test for function parseOpts
def test_parseOpts():
    from os import system
    from sys import exit

    try:
        write_string(
            'Testing parseOpts\n' +
            '-----------------\n\n')

        # Unit test for function parseOpts
        test_case_0()

        write_string(
            'Testing parseOpts: Success!\n')
    except KeyboardInterrupt:
        write_string('\nTesting parseOpts: Error!')
        write_string('\nERROR: parseOpts took too long to complete!')
        exit(1)
    except:
        write_string(
            '\nERROR: parseOpts encountered an error!\n')
        exit(1)
    else:
        exit(0)

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:37:33.553671
# Unit test for function parseOpts
def test_parseOpts():
    # Initialize test case
    test_case_0()

# Run all test cases

# Generated at 2022-06-26 13:37:39.037289
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    assert var_0 == None, 'Unit test failed: test_parseOpts'

if __name__ == '__main__':
    parsed_args = parse_args()
    logger.debug('parsed args: %s' % parsed_args)
    if parsed_args:
        sys.exit(parsed_args)
    test_parseOpts()
    test_case_0()

# Generated at 2022-06-26 13:37:41.073742
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Extracts video title out of the webpage content

# Generated at 2022-06-26 13:37:44.472051
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:37:49.025530
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0() # Testing case with arguments
        test_case_0() # Testing case with no arguments
        test_case_0() # Testing case with single argument
        test_case_0() # Testing case with multiple arguments

    except:
        assert False
    else:
        assert True
        

# Generated at 2022-06-26 13:37:52.828437
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Main entry point
if __name__ == "__main__":
    # Test the library
    test_parseOpts()

# Generated at 2022-06-26 13:37:56.871611
# Unit test for function parseOpts
def test_parseOpts():
    print("test_parseOpts: Begin")
    if True:
        test_case_0()
    print("test_parseOpts: End")


# Generated at 2022-06-26 13:38:03.451324
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    var_1 = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc'])
    var_2 = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc', '-f', 'mp4'])
    var_3 = parseOpts(['--help'])
    var_4 = parseOpts(['--version'])
    var_5 = parseOpts(['--dump-user-agent'])
    var_6 = parseOpts(['--extract-audio'])
    var_7 = parseOpts(['--extract-audio', '--audio-format', 'mp3'])

# Generated at 2022-06-26 13:38:06.642681
# Unit test for function parseOpts
def test_parseOpts():
    print("test_parseOpts()")
    with Timeout(30):
        test_case_0()
    print("pass")


# Generated at 2022-06-26 13:38:10.715696
# Unit test for function parseOpts
def test_parseOpts():
    # Test for function parseOpts
    try:
        test_case_0()
    except SystemExit as e:
        print(
            'Error running test_case_0 of test_parseOpts.\n'
            '%s' % str(e))


# Generated at 2022-06-26 13:39:19.212492
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    return var_0


# Generated at 2022-06-26 13:39:28.944873
# Unit test for function parseOpts
def test_parseOpts():
    import logging
    import platform
    import re
    import unittest

    #@unittest.skipIf(
    #    platform.system() != 'Windows',
    #    'pathlib works differently on linux and macOS')
    def test_0(self):
        var_0 = unittest.TestCase(parseOpts())
        self.assertEqual(var_0, 'test_case_0')

    #@unittest.skipUnless(
    #    platform.system() == 'Windows',
    #    'pathlib works differently on linux and macOS')
    def test_2(self):
        var_2 = unittest.TestCase(parseOpts())
        self.assertEqual(var_2, 'test_case_0')

    #@unittest.skipIf(
    #    platform.system

# Generated at 2022-06-26 13:39:29.772496
# Unit test for function parseOpts
def test_parseOpts():
    pass



# Generated at 2022-06-26 13:39:39.223708
# Unit test for function parseOpts
def test_parseOpts():
    argv = ['--verbose', '--format', '22', '--proxy', 'http://127.0.0.1:1080', '--username=blah', '--password=blubb', 'http://www.youtube.com/watch?v=BaW_jenozKc']
    _, opts, _ = parseOpts(argv)
    assert opts.verbose
    assert opts.format == '22'
    assert opts.proxy == 'http://127.0.0.1:1080'
    assert opts.username == 'blah'
    assert opts.password == 'blubb'
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'


# Generated at 2022-06-26 13:39:50.275210
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Global variables
urlopen = None
socket = None
compat_str = None
compat_urllib_error = None
compat_urllib_parse = None
compat_urllib_parse_urlparse = None
compat_urllib_request = None
compat_urllib_response = None
compat_urllib_robotparser = None
compat_cookielib = None
compat_http_cookiejar = None
compat_queue = None
compat_socket = None
compat_struct = None
compat_subprocess = None
compat_threading = None
compat_xml_parse_dom = None
compat_xml_parse_elementtree = None
compat_xml_etree_cElementTree = None
compat_xml_et

# Generated at 2022-06-26 13:39:55.710591
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing parseOpts()')
    test_case_0()
    print('Done testing for function parseOpts')

# Uncomment the following line to run the unit test
#test_parseOpts()

# Main function for the program.

# Generated at 2022-06-26 13:40:01.790944
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    assert var_0 == ()

    with pytest.raises(BaseException):
        parseOpts(['-h'])
    return


# Generated at 2022-06-26 13:40:03.488283
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:40:07.006639
# Unit test for function parseOpts
def test_parseOpts():
    print(test_case_0.__name__)
    test_case_0()

# End of function test_parseOpts

# Main function

# Generated at 2022-06-26 13:40:08.379165
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()


# Generated at 2022-06-26 13:42:49.321416
# Unit test for function parseOpts
def test_parseOpts():
    # Test this
    print("Test this!")



# End of Test Cases
if __name__ == '__main__':
    # test_case_0()
    test_parseOpts()

# Generated at 2022-06-26 13:42:54.450058
# Unit test for function parseOpts
def test_parseOpts():
    print(">>> start test parseOpts")
    # Start test
    print(">>> start test_case_0")
    test_case_0()
    print(">>> finish test_case_0")
    # Finish test
    print(">>> finish test parseOpts")

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:43:04.913795
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Main
if __name__ == '__main__':
    test_parseOpts()
    # Run unit test if specified
    if '--unittest' in sys.argv:
        sys.argv.remove('--unittest')
        import unittest
        class Test(unittest.TestCase):
            def test(self):
                test_parseOpts()
        unittest.main()
    #DEBUG:
    #import pdb
    #pdb.set_trace()
    main(sys.argv[1:])

# Generated at 2022-06-26 13:43:16.547727
# Unit test for function parseOpts
def test_parseOpts():
    # Testing for function parseOpts
    # No argument
    test_case_0()
    # Prefer ffmpeg
    test_case_1()
    # Prefer avconv
    test_case_2()
    # Update
    test_case_3()
    # Geo restriction
    test_case_4()
    # Subtitle
    test_case_5()
    # Proxy
    test_case_6()
    # Max downloads
    test_case_7()
    # Config location
    test_case_8()
    # Ignore config
    test_case_9()
    # Username
    test_case_10()
    # Password
    test_case_11()
    # Verbose
    test_case_12()
    # Ignore errors
    test_case_13()
    # Simulate
    test_

# Generated at 2022-06-26 13:43:21.514098
# Unit test for function parseOpts
def test_parseOpts():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(Test_parseOpts))
    return suite


# Generated at 2022-06-26 13:43:22.998215
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()


# Generated at 2022-06-26 13:43:27.878495
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = ['__main__', '-i', 'https://www.youtube.com/watch?v=pte3Jg-2Ax4']
    test_case_0()
    assert_equals(var_0, ['__main__', '-i', 'https://www.youtube.com/watch?v=pte3Jg-2Ax4'])
    pass


# Generated at 2022-06-26 13:43:33.080708
# Unit test for function parseOpts
def test_parseOpts():
    function_name = sys._getframe().f_code.co_name
    print('\n=={0}=='.format(function_name))

    test_case_0()
