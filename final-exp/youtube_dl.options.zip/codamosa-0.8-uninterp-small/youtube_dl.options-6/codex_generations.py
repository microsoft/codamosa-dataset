

# Generated at 2022-06-26 13:33:55.853184
# Unit test for function parseOpts
def test_parseOpts():
    if(test_case_0() == 0):
        print("Pass")
    else:
        print("Fail")


# Generated at 2022-06-26 13:34:00.737053
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.outtmpl, 'youtube-dl outtmpl is empty!'
    assert len(args) == 1, 'youtube-dl url is incorrect!'
    return

if __name__ == "__main__":
    test_case_0()
    test_parseOpts()

# Generated at 2022-06-26 13:34:02.271095
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:34:05.363577
# Unit test for function parseOpts
def test_parseOpts():
    parseOpts()
    return 0

# Test case 1 for function getInfoExtractor

# Generated at 2022-06-26 13:34:14.174394
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import io
    import test_cases.test_cases_parseOpts
    old_stdout, sys.stdout = sys.stdout, io.StringIO()
    test_cases.test_cases_parseOpts.test_case_0()
    sys.stdout = old_stdout
    assert open("test_cases_output/test_case_0.txt",
                encoding='utf-8').read().splitlines() == test_cases.test_cases_parseOpts.old_stdout.getvalue().splitlines()


# Generated at 2022-06-26 13:34:16.133781
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    return var_0


# Generated at 2022-06-26 13:34:17.019297
# Unit test for function parseOpts
def test_parseOpts():
    print(test_case_0())


# Generated at 2022-06-26 13:34:18.747623
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts())
    print()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:34:21.059068
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: ' + str(e))


# Generated at 2022-06-26 13:34:22.665706
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Generated at 2022-06-26 13:34:59.134959
# Unit test for function parseOpts
def test_parseOpts():
    _unittest.test_case_0(test_case_0)


# Generated at 2022-06-26 13:35:05.942436
# Unit test for function parseOpts
def test_parseOpts():
    test_cases = [
        [0],
    ]

    for test_case in test_cases:
        try:
            test_case_0(*test_case)
        except Exception as e:
            print('\033[1;31m%s\033[0m' % e)
        else:
            print('\033[1;32m%s\033[0m' % 'Test Success.')


if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:35:06.835325
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:35:09.347452
# Unit test for function parseOpts
def test_parseOpts():
    print("Test case 0")
    test_case_0()



# Generated at 2022-06-26 13:35:10.561538
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Generated at 2022-06-26 13:35:15.898982
# Unit test for function parseOpts
def test_parseOpts():
    # Error-free path
    func_name = 'youtube_dl.parseOpts'
    func_args = []
    func_return = None
    assert_results(func_name, func_args, func_return)
    # Error path
    func_name = 'youtube_dl.parseOpts'
    func_args = []
    func_return = None
    assert_results(func_name, func_args, func_return)


# Generated at 2022-06-26 13:35:27.562423
# Unit test for function parseOpts
def test_parseOpts():

    # Test with args
    test_case_0()

    # Test with kwargs
    test_case_0(overrideArguments=None)
    test_case_0(overrideArguments=[])
    test_case_0(overrideArguments=[])
    test_case_0(overrideArguments=['--verbose'])
    test_case_0(overrideArguments=['-v'])
    test_case_0(overrideArguments=['--username=foo', '--password=bar'])
    test_case_0(overrideArguments=['--username', 'foo', '--password', 'bar'])
    test_case_0(overrideArguments=['--username=foo', '--password', 'bar'])

# Generated at 2022-06-26 13:35:32.667015
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    if ((not hasattr(var_0, '__iter__')) or (len(var_0) != 3)):
        raise AssertionError()


# FIXME

# Generated at 2022-06-26 13:35:34.224642
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:35:35.205482
# Unit test for function parseOpts
def test_parseOpts():

    test_case_0()


# Generated at 2022-06-26 13:36:44.125236
# Unit test for function parseOpts
def test_parseOpts():
    from click.testing import CliRunner
    import ytdl

    runner = CliRunner()
    result = runner.invoke(ytdl.cli, ['--version'])
    assert result.exit_code == 0
    #assert result.output == '<function parseOpts at <some address> 0>\n'
    assert "Usage: youtube-dl [OPTIONS]" in result.output

if __name__ == "__main__":
    import sys
    import nose

    argv = sys.argv[:]
    argv.append('--nocapture')
    argv.append('--nologcapture')
    nose.main(argv=argv, defaultTest=__file__)

# Generated at 2022-06-26 13:36:45.709264
# Unit test for function parseOpts
def test_parseOpts():
    print("Test case 0")
    test_case_0()


# Generated at 2022-06-26 13:36:51.980979
# Unit test for function parseOpts
def test_parseOpts():
    test_cases = [
        # NOTE: Test case 0 is an example. Replace it with your tests.
        
        # (- Fill in here -)
    ]
    test_case_0()
    for idx, test_case in enumerate(test_cases):
        try:
            print('Running test case #{}'.format(idx))
            assert test_case()
            print('Test case #{} passed!'.format(idx))
        except AssertionError as e:
            print('Test case #{} failed!'.format(idx))
            print(e)
            sys.exit(1)



# Generated at 2022-06-26 13:36:56.467808
# Unit test for function parseOpts
def test_parseOpts():
    with pytest.raises(TypeError):
        parseOpts()
    with pytest.raises(TypeError):
        parseOpts(overrideArguments=None)



# Generated at 2022-06-26 13:36:58.551289
# Unit test for function parseOpts
def test_parseOpts():
    if __name__ != '__main__':
        test_case_0()


# Generated at 2022-06-26 13:37:00.108897
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:37:03.909685
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except SystemExit:
        pass

# Incase of a system exit (error)

# Generated at 2022-06-26 13:37:10.995139
# Unit test for function parseOpts
def test_parseOpts():
    if os.name == 'nt':
        return

    stdout = sys.stdout

    # Try function with out arguments
    # Try function with arg 'return_value'
    # Try function with arg 'override_arguments'
    if __name__ == '__main__':
        # Redirect stdout and run
        sys.stdout = open(os.devnull, 'w')
        test_case_0()
        sys.stdout.close()
        sys.stdout = stdout


# Generated at 2022-06-26 13:37:21.097641
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    print('parseOpts returned %s' % var_0)
    if var_0[0] == None:
        print('parseOpts does not return anything')
    if not isinstance(var_0[0], optparse.OptionParser):
        print('parseOpts does not return an instance of %s' % optparse.OptionParser)
    if not isinstance(var_0[1], optparse.Values):
        print('parseOpts does not return an instance of %s' % optparse.Values)
    if not isinstance(var_0[2], list):
        print('parseOpts does not return an instance of %s' % list)


# Generated at 2022-06-26 13:37:25.798730
# Unit test for function parseOpts
def test_parseOpts():
    print("Test Case 0...")
    test_case_0()
    print("Test Case 1...")
    test_case_1()
    print("Test Case 2...")
    test_case_2()


# --- TEST CASE 2 ---

# Generated at 2022-06-26 13:38:27.782014
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing function parseOpts')

    test_case_0()

# Generated at 2022-06-26 13:38:29.619838
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = test_case_0()
    # >>>


if __name__ == '__main__':
    parser, opts, args = parseOpts()

# Generated at 2022-06-26 13:38:31.797074
# Unit test for function parseOpts
def test_parseOpts():
    var_1 = parseOpts()
    assert not var_1, 'var_1'


# Generated at 2022-06-26 13:38:34.590776
# Unit test for function parseOpts
def test_parseOpts():
    # Error: variable 'opts' might be referenced before assignment
    test_case_0()


# Generated at 2022-06-26 13:38:40.786012
# Unit test for function parseOpts
def test_parseOpts():
    import test_utils
    import unittest
    class parseOptions(unittest.TestCase):
        def test_case_0(self):
            test_case_0()
    test_utils.run_suite('parseOpts', parseOptions.test_case_0)


# Generated at 2022-06-26 13:38:44.628937
# Unit test for function parseOpts
def test_parseOpts():
    print(">>> STARTED test_parseOpts")

    test_case_0()

    print("<<< FINISHED test_parseOpts")




# Generated at 2022-06-26 13:38:47.578119
# Unit test for function parseOpts
def test_parseOpts():
    pass


#
# Command line interaction
#


# Generated at 2022-06-26 13:38:49.037157
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()


# Generated at 2022-06-26 13:38:49.612825
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()



# Generated at 2022-06-26 13:38:51.170769
# Unit test for function parseOpts
def test_parseOpts():
    assert True


# Generated at 2022-06-26 13:39:55.368444
# Unit test for function parseOpts
def test_parseOpts():
    pass


# Generated at 2022-06-26 13:40:05.281087
# Unit test for function parseOpts
def test_parseOpts():
    assert callable(parseOpts), 'parseOpts is not callable'
    if zuk_path != 'python.exe':
        try:
            test_case_0()
        except:
            print(zuk_path)
            assert False, 'parseOpts fails for given input'

if __name__ == '__main__':
    test_parseOpts()
    print('PASSED ALL TEST CASES')

# Generated at 2022-06-26 13:40:07.878114
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print(opts)

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:40:10.640055
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 13:40:11.530916
# Unit test for function parseOpts
def test_parseOpts():
    pass

# Generated at 2022-06-26 13:40:14.696354
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
        print("Pass")
    except Exception as e:
        print("Fail")

test_parseOpts()

# Generated at 2022-06-26 13:40:16.801522
# Unit test for function parseOpts
def test_parseOpts():
    assert test_case_0() == None, 'parseOpts is failed'


# Generated at 2022-06-26 13:40:19.686841
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:40:26.992499
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Main function

# This enables setuptools to install youtube-dl as console_script (youtube-dl)
# and it is also used by the internal test function test_parseOpts
if __name__ == '__main__':
    parser, opts, args = parseOpts()
    del(parser, opts, args)

# Generated at 2022-06-26 13:40:29.770840
# Unit test for function parseOpts
def test_parseOpts():
    # test_case_0()
    pass

# if __name__ == "__main__":
#     test_parseOpts()