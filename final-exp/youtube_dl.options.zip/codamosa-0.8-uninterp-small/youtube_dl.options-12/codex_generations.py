

# Generated at 2022-06-26 13:33:57.945062
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()
    sys.exit(0)

# Generated at 2022-06-26 13:34:00.054184
# Unit test for function parseOpts
def test_parseOpts():
    var_1 = parseOpts()

# Generated at 2022-06-26 13:34:03.696326
# Unit test for function parseOpts
def test_parseOpts():
    assert var_0 != None

# remove comment
if __name__ == "__main__":
    pytest.main([__file__])

# Generated at 2022-06-26 13:34:07.776242
# Unit test for function parseOpts
def test_parseOpts():
    var_1 = test_case_0()


# Unit testing of instances :
if __name__ == "__main__":
    main()
    test_parseOpts()

# Generated at 2022-06-26 13:34:12.000243
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)
        assert False

    assert True

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:34:12.868472
# Unit test for function parseOpts
def test_parseOpts():
    pass



# Generated at 2022-06-26 13:34:14.322657
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:34:18.283264
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    if __name__ == '__main__':
        print(var_0)
    assert var_0


# Generated at 2022-06-26 13:34:19.773747
# Unit test for function parseOpts
def test_parseOpts():
    assert test_case_0() == None


# Generated at 2022-06-26 13:34:24.892636
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except Exception as exception:
        print('Exception: ' + str(exception))
        assert False


# Generated at 2022-06-26 13:34:53.011841
# Unit test for function parseOpts
def test_parseOpts():
    # Application entry point
    try:
        test_case_0()
    except:
        import sys, traceback
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_exception(exc_type, exc_value, exc_traceback)
        return False
    else:
        return True

# Class to hold options

# Generated at 2022-06-26 13:35:00.177208
# Unit test for function parseOpts
def test_parseOpts():
    # Test 0: Run test_case_0
    test_case_0()
    # Clear the parser variable
    parser = None
    # Clear the opts variable
    opts = None
    # Clear the args variable
    args = None

# Run the unit tests
test_parseOpts()

# Generated at 2022-06-26 13:35:04.061761
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    assert var_0[0]
    assert var_0[1]
    assert var_0[2]


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:35:09.136754
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except SystemExit as e:
        print('Test case 0 failed: %s' %e)
    except:
        print('Test case 0 failed: %s' %sys.exc_info()[0])
    else:
        print('Test case 0 passed.')

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:35:12.095902
# Unit test for function parseOpts
def test_parseOpts():
    print('Test parseOpts')
    print('\tCase 0')
    test_case_0()

# Main function
if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:35:13.615693
# Unit test for function parseOpts
def test_parseOpts():
    assert(type(parseOpts()) == tuple)


# Generated at 2022-06-26 13:35:16.105144
# Unit test for function parseOpts
def test_parseOpts():
    print("==== Test case 0 =====")
    test_case_0()


# Generated at 2022-06-26 13:35:17.446687
# Unit test for function parseOpts
def test_parseOpts():
    print("Begin test_parseOpts")
    test_case_0()
    print("End test_parseOpts")


# Generated at 2022-06-26 13:35:18.991633
# Unit test for function parseOpts
def test_parseOpts():
    test_parseOpts_0()


# Generated at 2022-06-26 13:35:22.584212
# Unit test for function parseOpts
def test_parseOpts():
    # This is a sample test case
    var_0 = parseOpts()
    assert var_0 != None, "Cannot perform test"


# Generated at 2022-06-26 13:36:06.436698
# Unit test for function parseOpts
def test_parseOpts():
    var_1 = parseOpts()
    return (var_1)


# Generated at 2022-06-26 13:36:13.097773
# Unit test for function parseOpts
def test_parseOpts():
    import nose
    from nose import with_setup

    # Note: Test Framework is not required for documenation generation
    try:
        import test_framework
    except ImportError:
        return
    test_framework.run_test(test_case_0, func_name = 'parseOpts')



# Generated at 2022-06-26 13:36:14.223722
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing test_parseOpts ...', end='')
    test_case_0()
    print('Passed!')


# Generated at 2022-06-26 13:36:17.700759
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing \'parseOpts\' with input "None"')
    test_case_0()


# Generated at 2022-06-26 13:36:23.404414
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
        print('Test case [0] passed successfully.')
    except Exception as e:
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:36:25.352820
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Suite of unit tests

# Generated at 2022-06-26 13:36:27.987077
# Unit test for function parseOpts
def test_parseOpts():
    # test with no arguments
    assert parseOpts()


# Generated at 2022-06-26 13:36:35.882065
# Unit test for function parseOpts
def test_parseOpts():
    system_conf = user_conf = custom_conf = []
    system_conf = _readOptions('/etc/youtube-dl.conf')
    if '--ignore-config' not in system_conf:
        user_conf = _readUserConf()

    argv = system_conf + user_conf + custom_conf
    parser, opts, args = parseOpts(argv)
    assert parser is not None
    assert opts is not None
    assert args is not None

# Generated at 2022-06-26 13:36:39.276380
# Unit test for function parseOpts
def test_parseOpts():
    # exceptions
    assertRaises(Exception, test_case_0)

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:36:42.745685
# Unit test for function parseOpts
def test_parseOpts():
    import test
    import sys

    if sys.version_info < (2,7):
        test.test_set = [test_case_0]
        test.run_tests()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:38:07.822077
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()

################################################################################
# Functions for test case 1


# Generated at 2022-06-26 13:38:10.175847
# Unit test for function parseOpts
def test_parseOpts():
    print('Unit test for parseOpts is running')
    test_case_0()
    print('Unit test for parseOpts passed')

# Generated at 2022-06-26 13:38:12.598838
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    assert isinstance(var_0, tuple)


# Generated at 2022-06-26 13:38:25.491292
# Unit test for function parseOpts
def test_parseOpts():
    print('Running unit test for function parseOpts:')
    var_0 = parseOpts()
    if isinstance(var_0, tuple):
        var_0, var_1, var_2 = var_0
    else:
        var_1 = var_0.var_1
        var_2 = var_0.var_2
        var_0 = var_0.var_0
    if isinstance(var_2, str):
        var_2 = var_2.encode('utf-8')
    assert (var_0.var_0 == False)
    assert (var_0.var_1 == False)
    assert (var_0.var_2 == False)
    assert (var_0.var_3 == False)
    assert (var_0.var_4 == False)

# Generated at 2022-06-26 13:38:27.562838
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()



# Generated at 2022-06-26 13:38:29.126653
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()


# Generated at 2022-06-26 13:38:32.430961
# Unit test for function parseOpts
def test_parseOpts():
    print('test_parseOpts ... start')

    test_case_0()

    print('test_parseOpts ... end')

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:38:34.792783
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    return


# Generated at 2022-06-26 13:38:36.127160
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:38:45.615949
# Unit test for function parseOpts
def test_parseOpts():
    # Parameter list for parseOpts
    testcase_num = 0
    test_case = []
    test_case.append(0)

    # Uncomment this line to print all testcase data
    # print(test_case)

    print("-------------------------------------------------")
    print("Running test case #0")
    print("-------------------------------------------------")
    # Test case #0:
    # script_main() {
    #     opts, args = parseOpts()
    #     try:
    #         opts.func(opts, args)
    #     except DownloadError:
    #         sys.exit(1)
    #     except SameFileError:
    #         sys.exit(2)
    #     except KeyboardInterrupt:
    #         sys.exit(2)
    #     except MaxDownloadsReached:
    #

# Generated at 2022-06-26 13:41:58.105480
# Unit test for function parseOpts
def test_parseOpts():
    if (not os.path.exists('/usr/bin/youtube-dl')):
        print('Required file /usr/bin/youtube-dl could not be found, skipping test case 0')
    else:
        test_case_0()


if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:41:59.465874
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:42:02.579091
# Unit test for function parseOpts
def test_parseOpts():
    print('test_parseOpts...')

    test_case_0()

    print('Done')

if __name__ == '__main__':

    test_parseOpts()

# vim: set ts=4 sw=4 et:

# Generated at 2022-06-26 13:42:13.971906
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-h'])
    assert parser.get_prog_name() == 'youtube-dl'
    assert opts.help == True
    assert opts.version == False
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.ignoreerrors == False
    assert opts.forcejson == False
    assert opts.noprogress == False
    assert opts.nopart == False
    assert opts.nocheckcertificate == False
    assert opts.no_color == False
    assert opts.proxy == None
    assert opts.bidi_workaround == False
    assert opts.sleep_interval == None
    assert opts.max_sleep_interval == None

# Generated at 2022-06-26 13:42:25.486823
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()

# Generated at 2022-06-26 13:42:28.413823
# Unit test for function parseOpts
def test_parseOpts():
    pass

#===============================================================================
#
# Main program
#
#===============================================================================


# Generated at 2022-06-26 13:42:32.012413
# Unit test for function parseOpts

# Generated at 2022-06-26 13:42:36.558814
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    var_1 = []
    while ((((var_1 is None) or (var_1 == [])) or (len(var_1) < 2)) or (len(var_1) > 2)):
        var_0 = parseOpts('-h')
        var_1 = var_0

# Generated at 2022-06-26 13:42:46.593355
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts(['--rate-limit', '250k'])
    var_1 = parseOpts(['--no-rate-limit'])
    var_2 = parseOpts(['--approximate-rate-limit', '250k'])
    var_3 = parseOpts(['--quality', '17'])
    var_4 = parseOpts(['--no-mtime'])
    var_5 = parseOpts(['--write-all-thumbnails'])
    var_6 = parseOpts(['-f', '34'])
    var_7 = parseOpts(['-f', '17'])
    var_8 = parseOpts(['-f', '34', '-f', '18'])

# Generated at 2022-06-26 13:42:56.655890
# Unit test for function parseOpts
def test_parseOpts():
    global args

    # Allow print statements
    test_case_0()

    # Verify parses
    if args.verbose:
        if args.verbosity > 0:
            write_string('[debug] Debug mode enabled')
        if args.verbosity > 1:
            write_string('[debug] Console encoding: %s' % repr(preferredencoding()))
            write_string('[debug] System encoding: %s' % repr(sys.getfilesystemencoding()))
            write_string('[debug] File system encoding: %s' % repr(sys.getfilesystemencoding()))
            write_string('[debug] requests version: %s' % repr(requests.__version__))
