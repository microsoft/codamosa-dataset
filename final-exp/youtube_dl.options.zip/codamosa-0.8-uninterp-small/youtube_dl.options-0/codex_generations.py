

# Generated at 2022-06-26 13:33:58.229384
# Unit test for function parseOpts
def test_parseOpts():
    print("Running function test_parseOpts")
    test_case_0()



# Generated at 2022-06-26 13:34:00.890877
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    print(var_0)
    print(type(var_0))
    print(len(var_0))
    assert len(var_0) > 0


# Generated at 2022-06-26 13:34:07.777121
# Unit test for function parseOpts
def test_parseOpts():
    print("Testing test_parseOpts")
    var_0 = parseOpts()
    print(var_0)

# Test case for above code
if (__name__ == '__main__'):
    print("Running unit tests")
    print("Running test for function parseOpts")
    test_parseOpts()

# Generated at 2022-06-26 13:34:13.572600
# Unit test for function parseOpts
def test_parseOpts():
    import nose
    import sys
    if sys.argv[0].endswith('__main__.py'):
        argv = ['youtube-dl', '--help']
    else:
        argv = [sys.argv[0], '--help']
    nose.runmodule('youtube_dl.__main__', argv=argv)



# Generated at 2022-06-26 13:34:23.819735
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert opts.config_location == '~/.config/youtube-dl/config'
    assert opts.cachedir == '~/.cache/youtube-dl/'
    assert opts.nocache_dir == False
    assert opts.cachedir_readonly == False
    assert opts.no_check_certificate == False
    assert opts.prefer_insecure == False
    assert opts.proxy == None
    assert opts.socket_timeout == 300
    assert opts.bidi_workaround == True
    assert opts.user_agent == 'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0 (Chrome)'
    assert opts.referer == None


# Generated at 2022-06-26 13:34:26.722329
# Unit test for function parseOpts
def test_parseOpts():
    print("Test Parse Opts")
    var_0 = parseOpts()
    test_case_0()


# Generated at 2022-06-26 13:34:30.390006
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except Exception as e:
        print('Caught exception: ' + str(e))



# Generated at 2022-06-26 13:34:31.572112
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:34:35.046063
# Unit test for function parseOpts
def test_parseOpts():
    errors = []
    test_case_0()
    if errors:
        raise AssertionError("Errors in parsing youtube-dl options")


# Generated at 2022-06-26 13:34:37.868444
# Unit test for function parseOpts
def test_parseOpts():
    # Test case 0
    try:
        test_case_0()
    except Exception:
        assert False


# Generated at 2022-06-26 13:35:11.188232
# Unit test for function parseOpts
def test_parseOpts():
    # Test case 0 - no arguments
    test_case_0()


######################################################################


# Generated at 2022-06-26 13:35:15.178064
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import io

    saved_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out

        test_case_0()
    finally:
        sys.stdout = saved_stdout

    assert True



# Generated at 2022-06-26 13:35:16.576247
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Main function

# Generated at 2022-06-26 13:35:22.725410
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

if __name__ == '__main__':
    import sys
    if len(sys.argv) == 1:
        test_parseOpts()
    else:
        out = getopt(sys.argv[1:])
        print(out)

# Generated at 2022-06-26 13:35:25.671913
# Unit test for function parseOpts

# Generated at 2022-06-26 13:35:38.151086
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username is None
    
    _reset_opts(parser, opts)
    parser, opts, args = parseOpts(['username'])
    assert opts.username == 'username'
    
    _reset_opts(parser, opts)
    parser, opts, args = parseOpts(['--username=foo'])
    assert opts.username == 'foo'
    assert opts.password is None
    
    _reset_opts(parser, opts)
    parser, opts, args = parseOpts(['--password=bar'])
    assert opts.password == 'bar'
    assert opts.username is None
    
    _reset_opts(parser, opts)
    parser, opts, args = parse

# Generated at 2022-06-26 13:35:40.049267
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    assert var_0 == (None, True, None)

if __name__ == '__main__':
    test_case_0()
    test_parseOpts()

# Generated at 2022-06-26 13:35:40.736201
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()




# Generated at 2022-06-26 13:35:41.367075
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:35:45.670473
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, tuple)


# Generated at 2022-06-26 13:36:47.024471
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing function: parseOpts')

    # Find out whether the function can be called correctly.


    test_case_0()
    print('  All tests OK')

# Generated at 2022-06-26 13:36:50.227654
# Unit test for function parseOpts
def test_parseOpts():
    # Test case 0
    # Testing with the following:
    #    < empty >
    test_case_0()



# Main function

# Generated at 2022-06-26 13:36:54.926083
# Unit test for function parseOpts
def test_parseOpts():
    # print("Testing parseOpts...")
    test_case_0()

# Run test suite
if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:36:57.244298
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    assert var_0 is not False


# Generated at 2022-06-26 13:37:00.057953
# Unit test for function parseOpts
def test_parseOpts():
    pass
    # TODO
    assert test_case_0() == 0, 'test case 0 failed'

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Generated at 2022-06-26 13:37:04.447934
# Unit test for function parseOpts
def test_parseOpts():
    # Test case 0
    try:
        test_case_0()
    except Exception as ex:
        print('Test case 0 failed: ' + str(ex))


# Generated at 2022-06-26 13:37:05.984598
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:37:07.586479
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:37:11.121574
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing function parseOpts')
    test_case_0()


# Print the usage of the programm

# Generated at 2022-06-26 13:37:14.823213
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: add code for testing the parseOpts function here
    print('Test parseOpts')
    test_case_0()


# Generated at 2022-06-26 13:39:21.208302
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print(opts)
    print(args)


# Generated at 2022-06-26 13:39:23.736236
# Unit test for function parseOpts
def test_parseOpts():
    # Test case 0
    var_0 = ('test_case_0', 'test/src/test_cases/test_case_0', 'test_case_0')
    assert_match(var_0, 'test_case_0')

# Generated at 2022-06-26 13:39:24.639717
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = test_case_0()


# Generated at 2022-06-26 13:39:38.051730
# Unit test for function parseOpts
def test_parseOpts():
    import io
    import sys
    import unittest

    class parseOptsTest(unittest.TestCase):
        def setUp(self):
            self.save_stdin = sys.stdin
            self.save_stdout = sys.stdout
            self.save_stderr = sys.stderr

            sys.stdout = io.StringIO()
            sys.stderr = io.StringIO()


        def tearDown(self):
            sys.stdin = self.save_stdin
            sys.stdout = self.save_stdout
            sys.stderr = self.save_stderr


        def test_no_args(self):
            sys.stdin = io.StringIO('http://example.com')
            sys.argv = ['youtube-dl']
            parser, opt

# Generated at 2022-06-26 13:39:39.949757
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()

# Test parseOpts. Unit test

# Generated at 2022-06-26 13:39:42.499914
# Unit test for function parseOpts
def test_parseOpts():
    parseOpts()


# Generated at 2022-06-26 13:39:50.491355
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing function parseOpts')
    test_cases = [(0,)]
    passed = 0
    failed = 0

    for test_case in test_cases:
        try:
            test_case_0(*test_case)
            passed += 1
        except Exception:
            failed += 1
            print('Exception thrown for test case ' + str(test_case))

    print('Passed ' + str(passed) + ' out of ' + str(passed + failed))
    return passed == len(test_cases)

if __name__ == '__main__':
    test_parseOpts()
# End of tests

# vim:set shiftwidth=4 softtabstop=4 expandtab textwidth=79:

# Generated at 2022-06-26 13:39:55.434775
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing parseOpts()')
    print('\tTest case 0')
    test_case_0()
    print('\tTest case 1')
    test_case_1()


# Generated at 2022-06-26 13:40:00.120846
# Unit test for function parseOpts
def test_parseOpts():
    test_cases = []
    test_cases.append(test_case_0)
    for f in test_cases:
        f()


# Generated at 2022-06-26 13:40:07.402249
# Unit test for function parseOpts
def test_parseOpts():
    import random
    import time
    print('Executing unit test for function parseOpts')
    start_time = time.time()
    test_case_0()
    end_time = time.time()
    print('Elapsed time for test case 0 for function parseOpts: ' + str(end_time - start_time) + 's')


# Generated at 2022-06-26 13:42:33.156451
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import StringIO
    old_output = sys.stdout
    sys.stdout = StringIO.StringIO()
    try:
        test_case_0()
    finally:
        sys.stdout = old_output



# Generated at 2022-06-26 13:42:35.933470
# Unit test for function parseOpts
def test_parseOpts():
    print(test_case_0())

# End of test for parseOpts


# Generated at 2022-06-26 13:42:37.583199
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:42:39.692054
# Unit test for function parseOpts
def test_parseOpts():
    go_0 = test_case_0()
    return go_0


# Generated at 2022-06-26 13:42:47.560721
# Unit test for function parseOpts
def test_parseOpts():
    import logging
    import sys
    import unittest

    
    class TestCase0(unittest.TestCase):
        def executeTest(self):
            parseOpts()

    class TestCase1(unittest.TestCase):
        def executeTest(self):
            parseOpts(['youtube-dl'])

    class TestCase2(unittest.TestCase):
        def executeTest(self):
            parseOpts([])

    class TestCase3(unittest.TestCase):
        def executeTest(self):
            parseOpts(['--config-location'])

    class TestCase4(unittest.TestCase):
        def executeTest(self):
            parseOpts(['--free-form-login'])


# Generated at 2022-06-26 13:42:49.967099
# Unit test for function parseOpts
def test_parseOpts():
    assert True == True

# main() entry point

# Generated at 2022-06-26 13:42:53.404311
# Unit test for function parseOpts
def test_parseOpts():
    print("\nTest 1:",end = '')
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:42:56.411848
# Unit test for function parseOpts
def test_parseOpts():
    print ("[Unit Test]: Running parseOpts")
    test_case_0()

#########################################

# Generated at 2022-06-26 13:43:01.562434
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = " --h"
    var_1 = parseOpts(var_0.split())
    if (var_1[1].help == True):
        print('Pass')
    else:
        print('False')


# Generated at 2022-06-26 13:43:04.914172
# Unit test for function parseOpts
def test_parseOpts():
    print("Testing function parseOpts")
    test_case_0()
    print("Test of function parseOpts is complete!")


import math
import string

# Class for function get_subtitles