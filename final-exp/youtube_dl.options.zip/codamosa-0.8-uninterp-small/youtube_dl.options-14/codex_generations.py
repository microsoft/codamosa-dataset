

# Generated at 2022-06-26 13:33:50.205791
# Unit test for function parseOpts
def test_parseOpts():
    pass

# Generated at 2022-06-26 13:34:02.096403
# Unit test for function parseOpts
def test_parseOpts():
    pass

# find_executable

# expand_path

# post_processing

# run_youtube_dl

# youtube_dl

# version_date

# version

# warning

# std_headers

# make_HTTPS_handler

# make_cookie_header

# std_headers_robot

# robot_check

# replace_escape_chars

# clean_html

# extract_attributes

# url_basename

# url_basename_from_url

# extract_flat_attributes

# sanitized_Request

# get_video_id

# prepare_filename

# is_outtmpl_usable

# is_writable

# mkdir_p

# write_string

# write_json_file

# read

# Generated at 2022-06-26 13:34:06.505076
# Unit test for function parseOpts
def test_parseOpts():
    # test_case_0
    try:
        test_case_0()
    except:
        print('FAILED: test_case_0')


# Generated at 2022-06-26 13:34:11.947924
# Unit test for function parseOpts
def test_parseOpts():
    args = ["https://www.youtube.com/watch?v=zVb4Y4JPZ7o"]
    parser, options, _ = parseOpts(args)

    assert isinstance(options, optparse.Values)
    assert options.verbose == False



# Generated at 2022-06-26 13:34:21.127946
# Unit test for function parseOpts
def test_parseOpts():

    # Create test cases
    test_cases = [("Test Case #0", test_case_0)]
    test_results = []

    # Run test cases
    for test_name, test_func in test_cases:
        print("Running ", test_name)
        try:
            test_func()
            test_results.append("PASS")
        except AssertionError as e:
            print(" FAIL Assertion Error:",e)
            test_results.append("FAIL")
        except Exception as e:
            print(" FAIL Exception:",e)
            test_results.append("FAIL")

    print("==== Results for function parseOpts ====")
    for res in test_results:
        print(res)


if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:34:23.433177
# Unit test for function parseOpts
def test_parseOpts():
    # Test cases
    test_case_0()




# Generated at 2022-06-26 13:34:26.954500
# Unit test for function parseOpts
def test_parseOpts():
    return


# Utility function to run the unit tests
# Exit with 0 if all tests passed
# Exit with 1 if some test failed

# Generated at 2022-06-26 13:34:29.925146
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except:
        print('Test Failed')
        raise


# Generated at 2022-06-26 13:34:33.844674
# Unit test for function parseOpts
def test_parseOpts():
    assert_equals(parseOpts.func_code.co_argcount, 0)
    assert_equals(parseOpts.func_code.co_varnames, ('',))
    assert_equals(parseOpts.func_code.co_filename, __file__)


# Generated at 2022-06-26 13:34:36.524861
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()
# End of test cases for function parseOpts

# Test case for function build_request

# Generated at 2022-06-26 13:35:02.439944
# Unit test for function parseOpts
def test_parseOpts():
    try:
        print("Test Case 1")
        test_case_0()
    except SystemExit as e:
        if e.code == 0:
            print("Test Case 1: Accepted")
            return
    except:
        print("Test Case 1: Failed")
        return
    print("Test Case 1: Failed")

# Driver Code
if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:35:04.278639
# Unit test for function parseOpts
def test_parseOpts():
    print('Test #0 - create unit test for function parseOpts')
    test_case_0()
    print('Success!')
    return True


# Generated at 2022-06-26 13:35:09.422536
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)
    assert str(parser) == '<optparse.OptionParser instance at 0x7f647da9c680>'
    assert len(args) == 0


# Generated at 2022-06-26 13:35:13.772722
# Unit test for function parseOpts
def test_parseOpts():
    with patch('smo.ui.console.parseOpts') as mock_parseOpts:
        mock_parseOpts.return_value = (1, 2, 3)
        assert parseOpts() == (1, 2, 3)
        mock_parseOpts.assert_called_with()


# Generated at 2022-06-26 13:35:19.141496
# Unit test for function parseOpts
def test_parseOpts():
    print("Test parseOpts:")
    test_case_0()
    print("add @ok")
    print("add @pass")
    print("add @total:1")
    print("add @correct:1")
    return True

# Generated at 2022-06-26 13:35:22.158907
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:35:26.648973
# Unit test for function parseOpts
def test_parseOpts():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(test_case_0))
    runner = unittest.TextTestRunner()
    runner.run(suite)

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:35:29.493055
# Unit test for function parseOpts
def test_parseOpts():
    print("test function parseOpts")
    for i in range(1):
        test_case_0()

main()

# Generated at 2022-06-26 13:35:30.296066
# Unit test for function parseOpts
def test_parseOpts():
    print("Unit test for function parseOpts")
    test_case_0()


# Generated at 2022-06-26 13:35:31.622283
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    if var_0 != 'No return value':
        print("Error parsing arguments!")


# Generated at 2022-06-26 13:36:09.696883
# Unit test for function parseOpts
def test_parseOpts():
    var_1 = parseOpts()
    assert isinstance(var_1, tuple)


# Generated at 2022-06-26 13:36:20.138194
# Unit test for function parseOpts
def test_parseOpts():
    assert func_0() is not None, 'Parser created'
    assert func_0() is not None, 'Opts created'
    assert func_0() is not None, 'Args created'
    # assert func_0() == 'System config: []\n', '0'
    # assert func_0() == 'User config: []\n', '1'
    # assert func_0() == 'Custom config: []\n', '2'
    # assert func_0() == 'Command-line args: [\'--version\', \'--dump-user-agent\']\n', '3'

if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1:
        result = test_case_0()
        sys.exit(0)
    else:
        import nose
        test

# Generated at 2022-06-26 13:36:24.125526
# Unit test for function parseOpts
def test_parseOpts():
    try:
        pass
    except Exception as err_0:
        print("Testcase 0 FAILED: " + str(err_0))

# Main program

# Generated at 2022-06-26 13:36:26.391258
# Unit test for function parseOpts
def test_parseOpts():
    print("test function parseOpts")
    test_case_0()
    print("test finish")

# Main function

# Generated at 2022-06-26 13:36:29.491884
# Unit test for function parseOpts
def test_parseOpts():
    # Add your own test cases here.
    try:
        test_case_0()
    except Exception:
        import traceback
        ex = traceback.format_exc()
        print(ex)
        assert False, 'unit test failed'
    assert True, 'unit test done'


# Generated at 2022-06-26 13:36:33.200136
# Unit test for function parseOpts
def test_parseOpts():
    print("test_parseOpts")
    test_case_0()
    print("test_parseOpts done")


# Do not print anything when using the --test-argcomplete parameter

# Generated at 2022-06-26 13:36:39.265761
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except Exception:
        print("Test Case 0 failed")

if __name__ == "__main__":
    import sys
    import doctest
    reload(sys)
    sys.setdefaultencoding("UTF-8")
    doctest.testmod()
    test_parseOpts()

# Generated at 2022-06-26 13:36:49.400565
# Unit test for function parseOpts
def test_parseOpts():
    assert True in (str(var_0) == str(var_1) and str(var_0) == str(var_2) and str(var_0) == str(var_3) for var_0, var_1, var_2, var_3 in ((test_case_0(), test_case_0(), test_case_0(), test_case_0()), (test_case_0(), test_case_0(), test_case_0(), test_case_0()), (test_case_0(), test_case_0(), test_case_0(), test_case_0())))


# Generated at 2022-06-26 13:36:55.248138
# Unit test for function parseOpts
def test_parseOpts():
    # Initialization code
    import sys
    import YoutubeDL as ydl
    from YoutubeDL import logger
    sys.argv = ['youtube-dl', '-c', '-o', '%(title)s-%(id)s.%(ext)s', '--restrict-filenames', '--no-part', '--proxy', '192.168.0.1']
    var_0 = parseOpts()
    assert var_0[1].outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert var_0[1].nopart == True
    assert var_0[1].restrictfilenames == True
    assert var_0[1].proxy == '192.168.0.1'


# Generated at 2022-06-26 13:37:02.942024
# Unit test for function parseOpts
def test_parseOpts():
    args = ['youtube-dl', 'www.youtube.com/watch?v=BaW_jenozKc']
    _, opts, _ = parseOpts(args)
    assert opts.usenetrc == True
    assert opts.username is None
    assert opts.password is None
    assert opts.video_password is None
    assert opts.quiet == False
    assert opts.forceurl is False
    assert opts.forcetitle is False
    assert opts.forceid is False
    assert opts.forcethumbnail is False
    assert opts.forcedescription is False
    assert opts.forcefilename is False
    assert opts.forcejson is False
    assert opts.dump_single_json == False
    assert opts.dump_json == False

# Generated at 2022-06-26 13:38:06.428145
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()

# Test: func parseOpts, branch coverage: 100%

# Generated at 2022-06-26 13:38:07.986871
# Unit test for function parseOpts
def test_parseOpts():
    print('Start test_parseOpts')
    test_case_0()
    print('Finishe test_parseOpts')

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:38:14.983162
# Unit test for function parseOpts
def test_parseOpts():
    # Default values
    var_0 = parseOpts()
    var_1 = parseOpts([])
    var_2 = parseOpts(None)
    # Positive tests
    var_3 = parseOpts(['--', 'argument'])
    var_4 = parseOpts(['-h'])
    var_5 = parseOpts(['-c', 'test'])
    var_6 = parseOpts(['-u', 'test'])
    var_7 = parseOpts(['-p', 'test'])
    var_8 = parseOpts(['-v'])
    var_9 = parseOpts(['--version'])
    var_10 = parseOpts(['--no-playlist'])
    var_11 = parseOpts(['--no-progress'])

# Generated at 2022-06-26 13:38:24.321094
# Unit test for function parseOpts
def test_parseOpts():
    argv = ["-x", "--audio-format=mp3", "--audio-quality=5"]
    parser, opts, args = parseOpts(argv)
    if not (opts.extractaudio == True and opts.audioformat == 'mp3' and opts.audioquality == '5'):
        raise RuntimeError('Wrong arguments parsing, expected: [True, mp3, 5], got: %s' % [opts.extractaudio, opts.audioformat, opts.audioquality])
    return 0

if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:38:27.783305
# Unit test for function parseOpts
def test_parseOpts():
    print()
    print("Test case 1")
    test_case_0()




# Generated at 2022-06-26 13:38:36.204435
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(overrideArguments=['-x'])
    assert opts.extractaudio
    parser, opts, args = parseOpts(overrideArguments=['--extract-audio'])
    assert opts.extractaudio
    parser, opts, args = parseOpts(overrideArguments=['--extract-audio', '--audio-format', 'aac'])
    assert opts.extractaudio
    assert opts.audioformat == 'aac'
    parser, opts, args = parseOpts(overrideArguments=['--extract-audio', '-f', 'aac'])
    assert opts.extractaudio
    assert opts.audioformat == 'aac'

# Generated at 2022-06-26 13:38:40.826059
# Unit test for function parseOpts
def test_parseOpts():
    print("Beginning Test case 0")
    test_case_0()
    print("End Test case 0")

# Begin Test
import time
test_parseOpts()



# End Test

# Generated at 2022-06-26 13:38:46.575188
# Unit test for function parseOpts
def test_parseOpts():
    """
    Unit test for function parseOpts
    """
    print('test_parseOpts...')
    print('TODO')

#################################
if __name__ == "__main__":
    print('Testing...')

    test_parseOpts()

    print('DONE')

# Generated at 2022-06-26 13:38:51.766349
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
        print('[+] Test case 0 passed')
    except:
        print('[-] Test case 0 failed')

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:38:59.895765
# Unit test for function parseOpts
def test_parseOpts():
    # Tests for function 'parseOpts'.
    #Installed function
    function_ = parseOpts()
    assert function_ is None
    assert function_ is None
    assert function_ is None
    assert function_ is None
    assert function_ is None
    assert function_ is None
    assert function_ is None



# Generated at 2022-06-26 13:41:22.770640
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(None)

    # No errors
    assert len(parser.formatter.errors) == 0

    # No arguments
    assert len(args) == 0

    # There are 24 groups of options
    assert len(parser.option_groups) == 24

    # Option --geo-bypass is true
    var_1 = opts.geo_bypass
    assert var_1 == False

    # Option --geo-bypass-ip-block is None
    var_2 = opts.geo_bypass_ip_block
    assert var_2 == None

    # Option --geo-bypass-country is None
    var_3 = opts.geo_bypass_country
    assert var_3 == None

    # Option --match-title is None

# Generated at 2022-06-26 13:41:24.196226
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:41:27.712465
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()


if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:41:32.341465
# Unit test for function parseOpts
def test_parseOpts():
    # test case for the default values
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()
    print('Done')

# Generated at 2022-06-26 13:41:34.483016
# Unit test for function parseOpts
def test_parseOpts():
    var = test_case_0()
    assert var == True

# Generated at 2022-06-26 13:41:36.815360
# Unit test for function parseOpts
def test_parseOpts():
    pass

# Temporary python test for function _real_main

# Generated at 2022-06-26 13:41:39.533517
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

tests = [
  test_parseOpts
]


# Generated at 2022-06-26 13:41:46.958806
# Unit test for function parseOpts
def test_parseOpts():
    try:
        var_0 = parseOpts()
    except (TypeError, AttributeError, IOError, AttributeError) as e:
        raise e
    else:
        pass
    try:
        test_case_0()
    except (TypeError, AttributeError, IOError, AttributeError) as e:
        raise e
    else:
        pass

# Generated at 2022-06-26 13:41:50.557926
# Unit test for function parseOpts
def test_parseOpts():
    # Sanity check on inputs
    assert True
    # Test cases
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:41:51.558902
# Unit test for function parseOpts
def test_parseOpts():
    assert(test_case_0()) == 0
