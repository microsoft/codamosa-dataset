

# Generated at 2022-06-26 13:33:52.901566
# Unit test for function parseOpts
def test_parseOpts():
    print("Unit test for parseOpts")
    test_case_0()

# Unit test

# Generated at 2022-06-26 13:33:54.347282
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()


# Generated at 2022-06-26 13:34:03.605473
# Unit test for function parseOpts
def test_parseOpts():
    import random
    import tempfile

    # Config location
    config_location = tempfile.mkdtemp()
    location = os.path.join(config_location, 'youtube-dl.conf')
    f = open(location, 'wb')
    f.write(b'--username USER\n')
    f.write(b'--password PASS\n')
    f.write(b'--sleep-interval 1\n')
    f.close()
    os.chmod(location, stat.S_IREAD)
    parser, opts, args = parseOpts(['--config-location', config_location])
    assert opts.username == 'USER'
    assert opts.password is None
    assert opts.sleep_interval == 1

# Generated at 2022-06-26 13:34:07.100976
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()
    test_case_1()
    test_case_2()

# Unit tests for function _print_default_format

# Generated at 2022-06-26 13:34:17.977008
# Unit test for function parseOpts
def test_parseOpts():
    from random import Random
    from sources import youtube_dl

    # See test_main() in YoutubeDL

    rng = Random()
    options = [
        [],
        ['--proxy', 'socks5://127.0.0.1:1080'],
    ]
    for i in range(100):
        opts = ['--%s' % k for k in youtube_dl.params if rng.randint(0, 1) and k not in ['outtmpl', 'username', 'password', 'twofactor', 'ap_mso', 'ap_username', 'ap_password', 'ap_listing_id', 'ap_device_id', 'kerberos_ccache']]
        opts += options[rng.randint(0, len(options) - 1)]

# Generated at 2022-06-26 13:34:19.685340
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts is not None
    assert args != []


# Generated at 2022-06-26 13:34:22.121038
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except Exception as e:
        print("Test failed: " + str(e))
        return
    print("Success.")

print("Testing for Function parseOpts")
test_parseOpts()

# Generated at 2022-06-26 13:34:24.485447
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing function parseOpts')
    test_case_0()


# Generated at 2022-06-26 13:34:25.360697
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:34:26.345643
# Unit test for function parseOpts
def test_parseOpts():
    pass



# Generated at 2022-06-26 13:34:48.167071
# Unit test for function parseOpts

# Generated at 2022-06-26 13:34:51.216966
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:34:53.054757
# Unit test for function parseOpts
def test_parseOpts():
    print("Test for function parseOpts")
    test_case_0()

test_parseOpts()

# Generated at 2022-06-26 13:34:57.258506
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except:
        print('Fail: test_case_0()')


# Generated at 2022-06-26 13:34:58.996487
# Unit test for function parseOpts
def test_parseOpts():
    print("#1 output: ")
    test_case_0()
    print("#2 output: ")
    test_case_1()
    print("#3 output: ")
    test_case_2()


# Generated at 2022-06-26 13:35:02.572986
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    if not var_0:
        assert False, 'Return value is false!'


# Generated at 2022-06-26 13:35:04.045629
# Unit test for function parseOpts
def test_parseOpts():
 
    print ("Running parseOpts function test")
    print ("No error case")
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:35:16.098025
# Unit test for function parseOpts
def test_parseOpts():
  from system_testing import main
  from optparse import OptionParser
  parser = OptionParser()
  parser.add_option("-v","--verbose",action="store_true",default=False)
  parser.add_option("-t","--time",dest="time",default=0.0)
  parser.add_option("-r","--rand",dest="rand",default=0)
  parser.add_option("--run",dest="run",default=True,action="store_true")
  parser.add_option("--no-run",dest="run",action="store_false")

  main(parser,test_case_0,["--verbose","--time","0.23","-r","0","--run"])

# Generated at 2022-06-26 13:35:19.470059
# Unit test for function parseOpts
def test_parseOpts():
    # check the type of return value
    assert isinstance(parseOpts(), tuple), \
        "Function parseOpts should return a tuple"


# Generated at 2022-06-26 13:35:29.446856
# Unit test for function parseOpts
def test_parseOpts():
    print("Testing function parseOpts")

    try:
        test_case_0()
    except:
        print("Error running test case")
        print(sys.exc_info()[0])
        raise



# Generated at 2022-06-26 13:36:07.752838
# Unit test for function parseOpts

# Generated at 2022-06-26 13:36:09.766334
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    return None


# Generated at 2022-06-26 13:36:20.165502
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()


VERSION = '2018.10.11'
USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20150101 Firefox/47.0 (Chrome)'

# Support Python 2 and 3
try:
    compat_str = compat_str
except NameError:
    compat_str = str
    compat_str_type = str

    def compat_expanduser(p):
        return os.path.expanduser(p)

    if sys.version_info < (3, 0):
        def compat_urllib_request_getproxies():
            return urllib.getproxies()
        def compat_urllib_request_urlopen(*args, **kwargs):
            return urllib

# Generated at 2022-06-26 13:36:23.578513
# Unit test for function parseOpts
def test_parseOpts():
    try:
        var_0 = parseOpts()
    except Exception:
        import sys
        import traceback
        exc_type, exc_value, exc_traceback = sys.exc_info()
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)

# Generated at 2022-06-26 13:36:26.115675
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print("opts: ", opts)
    print("args: ", args)


# Generated at 2022-06-26 13:36:28.061355
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except:
        sys.exit(1)

if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:36:36.161910
# Unit test for function parseOpts
def test_parseOpts():
    try:
        print("Test case 0: ")
        test_case_0()
        print("\nTest case 1: ")
        test_case_1()
        print("\nTest case 2: ")
        test_case_2()
    except Exception as inst:
        print("\nError :  " + str(inst))
    except:
        print("\nError :  Unexpected error!")


if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:36:41.025645
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

    test_case_0()

if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:36:45.847017
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except Exception as err:
        print("[FAIL] parseOpts failed with Exception: " + str(err))

# end of unit test cases


# Generated at 2022-06-26 13:36:47.552094
# Unit test for function parseOpts
def test_parseOpts():
    print("##### In test_parseOpts() #####")

    test_case_0()


# Generated at 2022-06-26 13:37:59.719781
# Unit test for function parseOpts
def test_parseOpts():
    # set these values of parameters as you wish :)
    var_0 = ''
    # call function with arguments
    var_1 = parseOpts(var_0)
    # we need to test here if function raised some exception and if it is the desired one
    if var_1:
        print('Test failed')
    else:
        print('Test passed')


# Generated at 2022-06-26 13:38:01.397222
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()


# Generated at 2022-06-26 13:38:06.427133
# Unit test for function parseOpts
def test_parseOpts():
    assert True

if __name__ == "__main__":
    import sys
    import doctest
    test_case_0()
    doctest.testmod(sys.modules[__name__], verbose = True)

# Generated at 2022-06-26 13:38:14.496770
# Unit test for function parseOpts
def test_parseOpts():
    #test_case_0()
    test_case_0()

##########
# File: ydl.py
# Config: /home/travis/build/rg3/youtube-dl/youtube_dl/extractor/common.py
# Last Generated: 2017-11-13 22:45:11.547824
# Total Functions: 1
# Total Instructions: 4
# This file is autogenerated please do not edit it directly.
# Generated by a defective version of method_analyzer.py
##########

import urllib.parse
import re
import json
import ssl
import locale
import os
import os.path
import sys
import ctypes
import ctypes.util
import socket
import tempfile
import shutil
import subprocess
import hashlib
import xml.etree.ElementTree
import random
import string

# Generated at 2022-06-26 13:38:25.993102
# Unit test for function parseOpts
def test_parseOpts():
    p = optparse.OptionParser()
    p.add_option('-a', '--address', dest='address', help='Specifies the location of the interface')
    p.add_option('-b', '--block', dest='block', help='Specifies the block number of the interface')
    p.add_option('-c', '--channel', dest='channel', help='Specifies the channel number of the interface')
    p.add_option('-d', '--debug', dest='debug', help='Displays more detailed information')
    opts, args = p.parse_args(['-a', '192.168.1.1', '-c', '2', '-b', '10', '-d'])

    assert(opts.address == '192.168.1.1')
    assert(opts.debug)
   

# Generated at 2022-06-26 13:38:27.428899
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Wrapper to process a test case

# Generated at 2022-06-26 13:38:36.076711
# Unit test for function parseOpts
def test_parseOpts():
    if "--no-check-certificate" in sys.argv:
        return test_case_0()

# Command line options
parser, opts, args = parseOpts()

if opts.verbose:
    writeToStdout('[debug] System config: %s' % repr(_hide_login_info(sys.argv)))

if opts.version:
    print('youtube-dl version %s' % __version__)
    sys.exit(0)

if opts.default_search == 'auto':
    opts.default_search = 'ytsearch' if len(args) < 2 else 'ytdl'

if opts.usenetrc and not opts.username:
    parser.error('Using .netrc credentials requires giving username with --username.')


# Generated at 2022-06-26 13:38:38.700150
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Unit test runner

# Generated at 2022-06-26 13:38:42.449839
# Unit test for function parseOpts
def test_parseOpts():
    test_cases = [0]
    for t in test_cases:
        print('Test case ' + str(t) + ' for function parseOpts')
        test_case_0()
        print('----------------------------------------------------------------------')


# Generated at 2022-06-26 13:38:45.795122
# Unit test for function parseOpts
def test_parseOpts():
    print("------Testing function: parseOpts")

    test_case_0()
    print("------End of testing function: parseOpts")

# Generated at 2022-06-26 13:41:14.988765
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = test_case_0()

# Generated at 2022-06-26 13:41:19.054337
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

if __name__ == '__main__':
    if test_parseOpts():
        sys.exit(0)
    else:
        sys.exit(1)

# Generated at 2022-06-26 13:41:20.957251
# Unit test for function parseOpts
def test_parseOpts():
    print('Uni test for function parseOpts...')
    test_case_0()
    print('Done.')


# Generated at 2022-06-26 13:41:31.875708
# Unit test for function parseOpts
def test_parseOpts():
    # Parser instance returned by parseOpts
    parseOpts_parser = None

    # Options instance returned by parseOpts
    parseOpts_opts = None

    # Argument list returned by parseOpts
    parseOpts_args = None

    # Option values
    # opts.simulate=None
    # opts.skip_download=None
    # opts.format=None
    # opts.listformats=None
    # opts.list_thumbnails=None
    # opts.usenetrc=None
    # opts.password=None
    # opts.username=None
    # opts.videopassword=None
    # opts.ap_mso=None
    # opts.ap_username=None
    # opts.ap_password=None
    # opts.ap

# Generated at 2022-06-26 13:41:37.700630
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.encoding == 'utf-8'
    assert opts.outtmpl == '%(id)s.%(ext)s'
    assert opts.dump_user_agent == ''
    assert opts.proxy == ''
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumburl == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == ''
    assert opts.password == ''
    assert opts.twofactor == ''
    assert opts.videopassword == ''
    assert opts.ap_username == ''
   

# Generated at 2022-06-26 13:41:41.245739
# Unit test for function parseOpts
def test_parseOpts():
    try:
        var_0 = parseOpts()
        print("SUCCESS")
    except:
        print("FAILED")


if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:41:49.078549
# Unit test for function parseOpts
def test_parseOpts():
    # Fails because of _fixup_opt_parse
    # Not sure how to fix: _fixup_opt_parse depends on 
    # _unescapePercent

    return

    print("\n Testing parseOpts")
    print("---------------------")
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:41:51.219580
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    assert type(var_0) == parseOpts



# Generated at 2022-06-26 13:41:54.227361
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:42:04.680919
# Unit test for function parseOpts
def test_parseOpts():
    # No input 
    var_0 = parseOpts()
    # No input 
    var_1 = parseOpts([])
    # Input with a space
    var_2 = parseOpts(["Youtube-dl is a great tool"])
    # No input 
    var_3 = parseOpts([" "])
    # No input 
    var_4 = parseOpts(["   "])
    # Input with an equal sign
    var_5 = parseOpts(["Youtube-dl downloads the best url with a url=http://www.youtube.com/watch?v=TnCd7Y8yhns"])
    # Input with an equal sign