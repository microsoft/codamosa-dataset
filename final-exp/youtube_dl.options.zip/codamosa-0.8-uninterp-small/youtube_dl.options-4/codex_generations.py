

# Generated at 2022-06-26 13:34:11.521352
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert type(opts) == tuple
    assert len(opts) == 3
    assert type(args) == list



# Generated at 2022-06-26 13:34:14.119009
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:34:20.686608
# Unit test for function parseOpts
def test_parseOpts():
    try:
        var = parseOpts()
    except Exception as e:
        print ('%s' % e)
        sys.ext()

# The following code is used to test your function locally.
# You can either invoke it by typing 'python -m youtube_dl.YoutubeDL.parseOpts' or
# 'python YoutubeDL.py' in the current directory

# Generated at 2022-06-26 13:34:23.186217
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    return var_0


# Generated at 2022-06-26 13:34:25.462127
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

test_parseOpts()

# Generated at 2022-06-26 13:34:26.422957
# Unit test for function parseOpts
def test_parseOpts():
    pass


# Generated at 2022-06-26 13:34:35.718249
# Unit test for function parseOpts
def test_parseOpts():
    import random
    import string

    ADDITIONAL_TESTS = 10

    def genRandomString(length=10):
        return "".join(random.choice(string.ascii_letters) for i in range(length))

    print("Test #0: ")
    test_case_0()
    print("")

    for test in range(ADDITIONAL_TESTS):
        print("Test #%d: " % (test + 1))
        arguments = random.sample(string.ascii_letters, random.randrange(10, 100))
        parseOpts(arguments)
        print("")

# vim: expandtab ts=4 sw=4 sts=4

# Generated at 2022-06-26 13:34:41.564217
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing function parseOpts')
    start = time.time()
    test_case_0()
    end = time.time()
    print('Elapsed time: ' + str(end - start) + 's')

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:34:52.882932
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    try:
        assertNotEqual(var_0, var_0, msg='Test failed: var_0 = parseOpts()')
    except AssertionError:
        print('Test failed: var_0 = parseOpts()')
        print_error_unexpected('AssertionError')
    else:
        print('Test passed: var_0 = parseOpts()')

# Test run:
if __name__ == '__main__':
    print('# Unit test for function parseOpts')
    test_parseOpts()

# Generated at 2022-06-26 13:34:56.823543
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()

# Verify whether function test_case_0 is working properly

# Generated at 2022-06-26 13:35:20.755715
# Unit test for function parseOpts
def test_parseOpts():
    print("Test test_parseOpts() ...")
    test = Test()
    test.test_parseOpts = test_case_0
    test.run()


# Generated at 2022-06-26 13:35:22.514702
# Unit test for function parseOpts
def test_parseOpts():

    test_case_0()


# Generated at 2022-06-26 13:35:30.343554
# Unit test for function parseOpts

# Generated at 2022-06-26 13:35:30.960945
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()


# Generated at 2022-06-26 13:35:35.408565
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except IOError as error:
        print('[ERROR]: ' + str(error))

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:35:40.635407
# Unit test for function parseOpts
def test_parseOpts():
    # parameters
    ###########
    # return
    ###########
    # test_case_0
    test_case_0()

if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:35:43.444929
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing function parseOpts for now...')
    test_case_0()
    print('Done!')


# Generated at 2022-06-26 13:35:47.417735
# Unit test for function parseOpts
def test_parseOpts():
    # test case 0
    suite_0 = unittest.TestSuite()
    suite_0.addTest(TestSuit1('test_case_0'))
    runner = unittest.TextTestRunner()
    runner.run(suite_0)


# Generated at 2022-06-26 13:35:50.515389
# Unit test for function parseOpts
def test_parseOpts():
    opts = []
    var_0 = parseOpts(opts)
    var_2 = parseOpts(opts)
    return var_2


# Generated at 2022-06-26 13:35:54.782724
# Unit test for function parseOpts
def test_parseOpts():
    from tests.testcases import parseOpts_testcases

    for tested_args, expected_parser, expected_opts, expected_args in parseOpts_testcases:
        parser, opts, args = parseOpts(tested_args)

        assert parser == expected_parser
        assert opts == expected_opts
        assert args == expected_args


# Generated at 2022-06-26 13:36:17.601252
# Unit test for function parseOpts
def test_parseOpts():
    print('Test # 0')
    test_case_0()


# Generated at 2022-06-26 13:36:29.044284
# Unit test for function parseOpts
def test_parseOpts():
    # Test cases
    var_2 = '--proxy'
    var_3 = '127.0.0.1:9050'
    var_4 = '--extract-audio'
    var_5 = '--audio-format'
    var_6 = 'mp3'
    var_7 = '--audio-quality'
    var_8 = '0'
    var_9 = '--ignore-errors'
    var_10 = '--add-metadata'
    var_11 = '--write-thumbnail'
    var_12 = '--write-info-json'
    var_13 = '--flat-playlist'
    var_14 = '--match-filter'
    var_15 = 'is_live'
    var_16 = '--youtube-skip-dash-manifest'

# Generated at 2022-06-26 13:36:32.213726
# Unit test for function parseOpts
def test_parseOpts():
    for i in range(100):
        test_case_0()

if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:36:36.769824
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:36:38.348085
# Unit test for function parseOpts
def test_parseOpts():
    assert test_case_0() == None


# Generated at 2022-06-26 13:36:44.740443
# Unit test for function parseOpts
def test_parseOpts():
  print('Case 0')
  test_case_0()

# Program entry point.
if __name__ == '__main__':
    test_parseOpts()


#------------------------------------------------------------------------------#
#                                                                              #
#------------------------------------------------------------------------------#


# Generated at 2022-06-26 13:36:47.302232
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    if var_0 == 0:
        assert True
    else:
        assert False


# Generated at 2022-06-26 13:36:52.964377
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except:
        import traceback
        print(traceback.format_exc())
        assert False

if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:37:02.289471
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()


# Generated at 2022-06-26 13:37:03.269079
# Unit test for function parseOpts
def test_parseOpts():
    # Check if function can return a value
    var_0 = parseOpts()
    assert(var_0 != None)

# Generated at 2022-06-26 13:37:48.731599
# Unit test for function parseOpts
def test_parseOpts():
    print("Start test 1")
    test_case_0()
    print("End test 1")


# Generated at 2022-06-26 13:37:53.424393
# Unit test for function parseOpts
def test_parseOpts():
    print()
    print('Test function parseOpts')
    test_case_0()

# End of file
if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:37:55.616450
# Unit test for function parseOpts
def test_parseOpts():
    #assert <expr>, <msg>
    test_case_0()


# Generated at 2022-06-26 13:38:00.891213
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

    # Test function attribute assertions
    assert hasattr(parseOpts, '__module__')
    
    # Test attribute assertions
    assert hasattr(parser, 'defaults')
    
    # Test type assertions
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)
    assert isinstance(parser, optparse.OptionParser)

# Generated at 2022-06-26 13:38:04.881405
# Unit test for function parseOpts
def test_parseOpts():
    print('> Testing test_parseOpts')
    test_case_0()
    print('')


# This function parses the output template.

# Generated at 2022-06-26 13:38:13.294493
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts(['--version'])

test_case_0()

# Encapsules code to be executed at program shutdown
# The 'atexit' module is not available at least on appengine
if False:
    def _atexit_register(func, *targs, **kargs):
        # Function from the 'atexit' module
        atexit.register(func, *targs, **kargs)
else:
    _atexit_register = None

# Once all WAS_AT_EXIT_REGISTERED functions are executed the program
# exits with the given EXIT_CODE
WAS_AT_EXIT_REGISTERED = []
EXIT_CODE = 0


# Generated at 2022-06-26 13:38:17.841006
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()
    assert 'parser' in var_0
    assert 'opts' in var_0
    assert 'args' in var_0


# Generated at 2022-06-26 13:38:20.177259
# Unit test for function parseOpts
def test_parseOpts():
    # zero
    test_case_0()

test_args = []
test()

# Generated at 2022-06-26 13:38:22.146802
# Unit test for function parseOpts
def test_parseOpts():
    assert_equals(test_case_0(), None)




# Generated at 2022-06-26 13:38:25.388536
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except SystemExit as e:
        return
    except:
        return

    raise Exception("Test case failed")

# Generated at 2022-06-26 13:39:52.779358
# Unit test for function parseOpts
def test_parseOpts():
    test_case_0()

# Generated at 2022-06-26 13:39:57.010258
# Unit test for function parseOpts
def test_parseOpts():
    # Default test case
    print('Running default test case')
    test_case_0()

    # Custom test case
    # print('Running custom test case')
    # test_case_X()


if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-26 13:40:00.746048
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing function parseOpts')
    test_case_0()

if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-26 13:40:03.398321
# Unit test for function parseOpts
def test_parseOpts():
    var_0 = parseOpts()

# ------------------------------------------------------------------------


# Generated at 2022-06-26 13:40:08.292513
# Unit test for function parseOpts
def test_parseOpts():
    print('test_parseOpts started')
    print('test_parseOpts completed')

# Run function test_case_0
test_case_0()

# Run function test_parseOpts
test_parseOpts()

if __name__ == '__main__':
    import doctest
    print(doctest.testmod())

# Generated at 2022-06-26 13:40:18.889613
# Unit test for function parseOpts
def test_parseOpts():
    # save current sys.argv
    current_argv = sys.argv
    # Add command line arguments
    sys.argv = (sys.argv[0], '-V', '--version')
    aParser, anOpts, anArgs = parseOpts()
    # restore sys.argv
    sys.argv = current_argv
    assert '-V' in sys.argv
    assert '--version' in sys.argv
    # assert parsed arguments
    assert isinstance(aParser, optparse.OptionParser)
    assert isinstance(anOpts, optparse.Values)
    assert anArgs == []



# Generated at 2022-06-26 13:40:27.708623
# Unit test for function parseOpts
def test_parseOpts():
    print("\n\n*** Unit Test : parseOpts")
    print("*** Unit Test : parseOpts\n")
    print("Test Case 0")
    try:
        test_case_0()
    except:
        print("*** TestCase 0 : Fail")
        return

    print("*** TestCase 0 : Pass")
    return

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-26 13:40:30.053925
# Unit test for function parseOpts
def test_parseOpts():
    print('test 1')
    test_case_0()


# Generated at 2022-06-26 13:40:32.940790
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test_case_0()
    except:
        pass


# Generated at 2022-06-26 13:40:35.861955
# Unit test for function parseOpts
def test_parseOpts():
    # Test Case 0
    var_0 = parseOpts()
    assert var_0 is not None
