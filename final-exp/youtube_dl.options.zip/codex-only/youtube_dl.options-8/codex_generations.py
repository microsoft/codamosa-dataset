

# Generated at 2022-06-24 14:00:33.660029
# Unit test for function parseOpts
def test_parseOpts():
    from unittest import TestCase
    from optparse import OptionConflictError
    class TestParseOpts(TestCase):
        def test_basic(self):
            parser, opts, args = parseOpts()
            self.assertTrue(hasattr(opts, 'verbose'))
            self.assertTrue(hasattr(opts, 'usenetrc'))
            self.assertTrue(hasattr(opts, 'username'))
            self.assertTrue(hasattr(opts, 'password'))
            self.assertTrue(hasattr(opts, 'twofactor'))
            self.assertTrue(hasattr(opts, 'videopassword'))
            self.assertTrue(hasattr(opts, 'writedescription'))

# Generated at 2022-06-24 14:00:35.741607
# Unit test for function parseOpts
def test_parseOpts():
    from test import test_parseOpts
    test_parseOpts.test_parseOpts()

#}}}

#{{{def list_extractors(age_limit):

# Generated at 2022-06-24 14:00:38.850742
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print(opts)
    print(args)

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-24 14:00:50.448033
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    print('Old argv: '+ str(argv))
    oldArgs = argv[1:]
    print('Old args: '+ str(oldArgs))
    testArgs = ['--verbose','--username','qa','--password','test','--get-url','https://www.youtube.com/watch?v=nfWlot6h_JM']
    testArgs2 = ['--verbose','--username','qa','--password','test','--get-url','https://www.youtube.com/watch?v=nfWlot6h_JM','--no-post-overwrites']

# Generated at 2022-06-24 14:00:53.000096
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert opts.ignoreerrors


# Generated at 2022-06-24 14:00:54.512233
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

# Generated at 2022-06-24 14:01:05.890763
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv as sys_argv
    from locale import getpreferredencoding
    from os.path import expanduser

    def fake_parser():
        return object()

    def fake_opts():
        return object()

    def fake_args():
        return object()

    def fake_compat_expanduser(path):
        return expanduser(path.encode(getpreferredencoding()))

    def fake_config_location():
        return expanduser(b'~/.youtube-dl/config').decode(getpreferredencoding())

    def fake_readOptions(path):
        return [path]

    def fake_readUserConf():
        return ['--ignore-config']

    # Test 1: opts is None, no override arguments
    sys_argv_copy = sys_argv.copy()
   

# Generated at 2022-06-24 14:01:15.481091
# Unit test for function parseOpts
def test_parseOpts():

    print('Testing parsing options')

    parser, options, _ = parseOpts(['--version'])
    assert options.version

    parser, options, _ = parseOpts(['--extract-audio', '--audio-format', 'ogg'])
    assert options.extractaudio
    assert options.audioformat == 'ogg'

    parser, options, _ = parseOpts(['--audio-quality', '10'])
    assert options.audioquality == '10'

    parser, options, _ = parseOpts(['--audio-quality', '0'])
    assert options.audioquality == '0'

    parser, options, _ = parseOpts(['--audio-quality', 'a'])
    assert options.audioquality == 'a'

    parser, options, _ = parseOpts(['--retries', '0'])


# Generated at 2022-06-24 14:01:18.173098
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-U', 'foobar', '-p', 'pass', 'bar'])[2][0] == 'bar'


# Generated at 2022-06-24 14:01:26.225811
# Unit test for function parseOpts
def test_parseOpts():
    with tempfile.NamedTemporaryFile() as t:
        t.write(b'--outtmpl=%(uploader)s')
        t.flush()
        
        args = ['--no-color', '-o', '%(id)s', '--config-location', t.name,
                'url1', 'url2']
        _, opts, _ = parseOpts(args)
        assert opts.outtmpl == '%(uploader)s'
        assert opts.color == False
        assert 'url1' in args
        assert 'url2' in args

if __name__ == '__main__':
    sys.stdout.buffer.write(b'Unit test for function parseOpts\n')
    test_parseOpts()

# Generated at 2022-06-24 14:01:33.056007
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = ['test', '-U', 'test_user', '-P', 'test_pass', '--verbose']
    parser, opts, args = parseOpts()
    assert opts.username == 'test_user'
    assert opts.password == 'test_pass'
    assert '-U test_user' not in str(parser.get_usage())
    assert '-P test_pass' not in str(parser.get_usage())

# Retrieve info for videos

# Generated at 2022-06-24 14:01:34.337656
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts([]))

test_parseOpts()


# Generated at 2022-06-24 14:01:41.663807
# Unit test for function parseOpts
def test_parseOpts():
    from six.moves import urllib
    from six import text_type
    from sys import version_info
    from types import ModuleType

    class _Module(ModuleType):
        def __init__(self, name):
            ModuleType.__init__(self, name)
            self.__file__ = '<%s>' % name
    sys = _Module('sys')
    sys.version_info = version_info
    urllib.parse = _Module('urllib.parse')
    urllib.parse.urlencode = lambda x: text_type(x)
    youtube_dl = _Module('youtube_dl')
    youtube_dl.version = '2017.6.25'
    youtube_dl.YOUTUBE_DL_VERSION = '2017.6.25'

    saved = sys.argv


# Generated at 2022-06-24 14:01:52.452874
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parse_opts(args, expected_result):
        _, opts, _ = parseOpts(args.split())
        result = {}
        for attr in dir(opts):
            if not attr.startswith('_'):
                result[attr] = getattr(opts, attr)
        assert result == expected_result

    _test_parse_opts('--no-cache-dir --default-search "auto"', {'nocachedir': True, 'default_search': 'auto'})


# Generated at 2022-06-24 14:01:53.635952
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts()

# End unit test


# Generated at 2022-06-24 14:02:02.384914
# Unit test for function parseOpts
def test_parseOpts():
    prog = 'youtube-dl'
    stdout = sys.stdout
    stderr = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

    for opt, val in [('-q', None), ('-q', '1'), ('--no-warnings', None),
                     ('--no-warnings', '1'),
                     ('--ignore-config', None), ('--ignore-config', '1'),
                     ('--config-location', '/path/to/youtube-dl.conf')]:
        conf = ['--verbose'] if val is not None else []
        conf.extend([opt, val]) if val is not None else conf
        conf = [prog] + conf


# Generated at 2022-06-24 14:02:09.023509
# Unit test for function parseOpts
def test_parseOpts():
    # Simulate that this was called via the command line (so it doesn't try to read in system/user/custom config files)
    sys.argv = [sys.argv[0]]
    override = ['-i', '--cache-dir', '/tmp']

    parser, opts, args = parseOpts(overrideArguments=override)
    assert(opts.ignoreerrors)
    assert(opts.cachedir == '/tmp')


# Generated at 2022-06-24 14:02:10.953330
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-h'])
    assert opts.help

# Authorized downloaders

# Generated at 2022-06-24 14:02:22.492906
# Unit test for function parseOpts
def test_parseOpts():
    assert(parseOpts([
        '-f', '18',
        '-o', '/tmp/test.%(ext)s',
        'http://www.youtube.com/watch?v=BaW_jenozKc'])
        == ('/tmp/test.%(ext)s', {'format': '18'}, ['http://www.youtube.com/watch?v=BaW_jenozKc']))

# Generated at 2022-06-24 14:02:27.724525
# Unit test for function parseOpts
def test_parseOpts():
    assert(parseOpts([])[2] == [])
    assert(parseOpts(['-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[2] == ['http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert(parseOpts(['--dump-user-agent'])[1].dump_user_agent == True)
    assert(parseOpts([])[1].dump_user_agent == False)

# Grab the url from argv if present, otherwise return None.

# Generated at 2022-06-24 14:02:29.483128
# Unit test for function parseOpts
def test_parseOpts():
    pass

# }}}


# {{{ Compatibility functions


# Generated at 2022-06-24 14:02:40.989152
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--verbose', '--ignore-config', '--config-location=/etc/nothing'])
    assert not opts.ignoreconfig
    assert opts.config_location == '/etc/nothing'
    assert opts.verbose == '-v'
    assert opts.listformats == 'true'

    parser, opts, args = parseOpts(['--write-all-thumbnails'])
    assert opts.write_all_thumbnails == True

    parser, opts, args = parseOpts(['--format='])
    assert opts.format == 'best'


# Silently remove basic auth from a URL

# Generated at 2022-06-24 14:02:51.602953
# Unit test for function parseOpts
def test_parseOpts():
    assert len(parseOpts(["--list-extractors"])) == 3


# Generated at 2022-06-24 14:03:02.423887
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DEFAULT_OUTTMPL
    def getopts(args):
        parser, opts, args = parseOpts(args)
        opts.format = 'mp4'
        return opts

    opts = getopts([])
    _ = YoutubeDL(opts)
    assert opts.outtmpl == DEFAULT_OUTTMPL
    assert not opts.usenetrc
    assert getattr(opts, 'username', False)
    assert getattr(opts, 'password', False)

    opts = getopts(['--username', 'user', '--password', 'passwd'])
    assert opts.username == 'user'
    assert opts.password == 'passwd'

   

# Generated at 2022-06-24 14:03:14.079629
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: Remove this function
    opts, args = parseOpts()


# Generated at 2022-06-24 14:03:23.815665
# Unit test for function parseOpts
def test_parseOpts():
    def assertParsed(opts, expected):
        assert vars(opts) == expected

    parser, opts, args = parseOpts([])

# Generated at 2022-06-24 14:03:32.908980
# Unit test for function parseOpts
def test_parseOpts():
    conf = {
        '--simulate': None,
        '--get-filename': None,
        '--skip-download': None,
        '-a': 'test.txt'
    }

    # Setup simulation of optparse
    OptionGroup = namedtuple('OptionGroup', 'title')
    optparse.Option = namedtuple('Option', 'dest action')
    optparse.OptionGroup = lambda self, parser: OptionGroup(parser)
    optparse.OptionGroup.add_option = lambda self, *args: None
    optparse.OptionGroup.__init__ = lambda self, parser, title: self
    optparse.OptionGroup.__init__.__defaults__ = ()
    optparse.OptionParser.__init__ = lambda self: None
    optparse.OptionParser.__init__.__defaults__ = ()
    opt

# Generated at 2022-06-24 14:03:33.635806
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass


# Generated at 2022-06-24 14:03:39.380413
# Unit test for function parseOpts
def test_parseOpts():
    def _test(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected_opts
    _test(['-f', '91,92', '-f', '93'], {'format': ['91', '92', '93'], 'outtmpl': '%(id)s.%(ext)s'})
    _test(['-f', '91,92', '-f', '93', '-o', 'foo.%(ext)s'], {'format': ['91', '92', '93'], 'outtmpl': 'foo.%(ext)s'})



# Generated at 2022-06-24 14:03:49.313990
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import tempfile
    opts = None

# Generated at 2022-06-24 14:03:55.272212
# Unit test for function parseOpts
def test_parseOpts():
    # No arguments
    _parser, _opts, _args = parseOpts([])

    # Basic
    _parser, _opts, _args = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert _opts.outtmpl == u'%(id)s'
    assert _args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

    # Simplest test
    _parser, _opts, _args = parseOpts(['-o', '%(title)s-%(id)s.%(ext)s', 'https://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-24 14:04:02.445564
# Unit test for function parseOpts
def test_parseOpts():
    options = ['--verbose',
               '--username', 'utName',
               '--password', 'p@ssw0rd!']
    opt_parser, opts, args = parseOpts(options)

    assert opt_parser.has_option('--verbose')
    assert opt_parser.has_option('--username')
    assert opt_parser.has_option('--password')

    assert opts.verbose
    assert opts.username=='utName'
    assert opts.password=='p@ssw0rd!'
    assert args == []


# Generated at 2022-06-24 14:04:08.779792
# Unit test for function parseOpts
def test_parseOpts():
    def test(args, expected):
        parser, actual, _ = parseOpts(args)
        assertEquals(actual, expected)
    test([], {})
    test(['-i'], {'ignoreerrors': True})
    test(['-f', 'best'], {'format': 'best'})
    test(['--dump-user-agent'], {'dump_user_agent': True})
    test(['--recode-video', 'mp4'], {'recodevideo': 'mp4'})


# Generated at 2022-06-24 14:04:15.792260
# Unit test for function parseOpts
def test_parseOpts():
    import re
    import tempfile
    import shutil
    import platform
    import random
    import string
    import youtube_dl.utils

    if os.path.exists(os.path.expanduser('~/.config/youtube-dl')):
        configdir = os.path.expanduser('~/.config/youtube-dl')
    else:
        configdir = os.path.expanduser('~/.youtube-dl')

    def random_string(n=8):
        return ''.join(random.choice(string.ascii_lowercase) for _ in range(n))

    def random_username():
        return random_string()

    def random_password():
        return random_string()


# Generated at 2022-06-24 14:04:25.214675
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["-f", "mp4", "-f", "best", "--download-archive", "archive"])
    assert opts.format == ['mp4', 'best']
    assert opts.download_archive == 'archive'

    parser, opts, args = parseOpts(["-f", "best[height<=1080][filesize<5000000]"])
    assert opts.format == ['best[height<=1080][filesize<5000000]']

    parser, opts, args = parseOpts(["-f", "[height>=1080]best"])
    assert opts.format == ['[height>=1080]best']

    parser, opts, args = parseOpts(["-f", "bestvideo"])
    assert opts.format == ['bestvideo']

   

# Generated at 2022-06-24 14:04:35.569251
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['--username', 'foo', 'bar'])[2] == ['bar']
    assert parseOpts(['-u', 'foo', 'bar'])[2] == ['bar']
    assert parseOpts(['--password', 'foo', 'bar'])[2] == ['bar']
    assert parseOpts(['-p', 'foo', 'bar'])[2] == ['bar']
    assert parseOpts(['--video-password', 'foo', 'bar'])[2] == ['bar']
    assert parseOpts(['--netrc', 'bar'])[2] == ['bar']
    assert parseOpts(['--no-check-certificate', 'bar'])[2] == ['bar']

# Generated at 2022-06-24 14:04:47.118905
# Unit test for function parseOpts
def test_parseOpts():
    # Test empty args
    parseOpts([])

    # Test some options
    opts, _ = parseOpts([
        '-x',
        '--verbose',
        '--format', 'best',
        '--dump-user-agent',
        '--youtube-skip-dash-manifest', '--skip-download',
        '--no-color',
        '--all-subs',
        '--prefer-free-formats',
        '--match-filter', 'type=video',
        '--delete-after',
        '--no-progress',
    ])
    assert opts.verbose == True
    assert opts.format == 'best'
    assert opts.dump_user_agent == True
    assert opts.youtube_skip_dash_manifest == True
    assert opts.usen

# Generated at 2022-06-24 14:04:48.629860
# Unit test for function parseOpts
def test_parseOpts(): pass
# }}}


# Generated at 2022-06-24 14:04:53.431224
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from tempfile import NamedTemporaryFile

    name = NamedTemporaryFile(delete=False)
    name.close()

# Generated at 2022-06-24 14:05:04.367664
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-i', '--ignore-errors', '--get-url', 'http://youtube.com/watch?v=BaW_jenozKc'])[1]
    assert opts.ignoreerrors
    assert opts.geturl
    assert opts.url == 'http://youtube.com/watch?v=BaW_jenozKc'

    opts = parseOpts(['--dump-user-agent'])[1]
    assert opts.dump_user_agent

    opts = parseOpts(['-v'])[1]
    assert opts.verbose == 1

    opts = parseOpts(['-v', '-v'])[1]
    assert opts.verbose == 2

    opts = parseOpts(['-q'])[1]
   

# Generated at 2022-06-24 14:05:05.851632
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()


# Command-line argument parsing

# Generated at 2022-06-24 14:05:15.206398
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--extract-audio', '--no-mtime', '--audio-format', 'best', '--audio-quality', '6', '--write-description', '--write-info-json', '--write-annotations', '--skip-download', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    print(opts.__dict__)
    assert opts.quiet == False
    assert opts.verbose == True
    assert opts.verbose_count == 1
    assert opts.format == None
    assert opts.postprocessor_args == None
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts

# Generated at 2022-06-24 14:05:18.314117
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print(parser.get_option_group('verbosity'))

if __name__ == '__main__':
    test_parseOpts()
    #print(parseOpts())



# Generated at 2022-06-24 14:05:27.618214
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info[0] >= 3:
        return
    from io import BytesIO
    # Build the command line arguments
    cmdline = '--no-mtime --output "test title-%(display_id)s-.mp3" -v --verbose --username "nico" --password "nico"'

    # Parse the command line arguments using parseOpts
    f_in = BytesIO(cmdline.encode('utf-8'))
    parser, opts, args = parseOpts([f_in])

    # Test the content of values
    assert opts.outtmpl == 'test title-%(display_id)s-.mp3'
    assert opts.username == 'nico'
    assert opts.password == 'nico'
    assert opts.verbose == 2
    assert opt

# Generated at 2022-06-24 14:05:32.792420
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import os
    import pprint

    sys.argv = [sys.argv[0]]
    sys.argv.extend(["-v"])

    pp = pprint.PrettyPrinter()
    (parser, opts, args) = parseOpts()
    pp.pprint((opts, args))

### END PARSER


# Generated at 2022-06-24 14:05:38.619943
# Unit test for function parseOpts
def test_parseOpts():
    # Test for the first use case
    if True:
        # Setup
        import sys
        # Exercise
        parser, opts_, args_ = parseOpts()
        # Verify
        # print(opts_)
        # Teardown
        pass


# parseOpts may return any of these types.  They are defined here so that
# unit tests can create mock instances of them as needed.

# Generated at 2022-06-24 14:05:48.129100
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--no-warnings', '--dump-user-agent', '--referer', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert not opts.nooverwrites
    assert opts.dump_user_agent
    assert opts.referer
    assert opts.noplaylist

    parser, opts, args = parseOpts(['--no-warnings', '--ignore-config', '--referer', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert not opts.nooverwrites
    assert opts.referer
    assert opts.noplaylist


# Generated at 2022-06-24 14:05:54.864961
# Unit test for function parseOpts
def test_parseOpts():
    def compat_configparser(parser):
        if sys.version_info < (3,):
            return parser
        return compat_configparser_sectionproxy(parser)

    import os
    from io import open
    from tempfile import mkstemp
    from functools import partial

    test_conf = u'--proxy 127.0.0.1\n-o /dev/null\n.ext:\n-r 10\nhttp://example.com/:\n-f 5\n'
    parser, opts, args = parseOpts([])
    assert not opts.proxy
    assert opts.outtmpl == '%(id)s'
    assert not opts.ratelimit
    assert not opts.format

# Generated at 2022-06-24 14:05:55.711010
# Unit test for function parseOpts
def test_parseOpts():
    pass



# Generated at 2022-06-24 14:06:03.599200
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from contextlib import contextmanager
    import io
    import sys

    @contextmanager
    def stdout_redirector(stream):
        old_stdout = sys.stdout
        sys.stdout = stream
        try:
            yield
        finally:
            sys.stdout = old_stdout

    class FakeYDL(YoutubeDL):
        def __init__(self, pars, opt, args):
            YoutubeDL.__init__(self)
            self._fake_pars = pars
            self._fake_opt = opt
            self._fake_args = args
            self._fake_info = {}
        def params(self):
            return self._fake_pars

# Generated at 2022-06-24 14:06:09.744005
# Unit test for function parseOpts
def test_parseOpts():
    opts = ['--usenetrc', '--username', 'foo', '--password', 'bar',
            'http://example.com/video']
    parser, opts, args = parseOpts(opts)
    assert opts.usenetrc
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://example.com/video']

    opts = ['--username', 'foo', '--password', 'bar',
            '--no-usenetrc', '--help']
    parser, opts, args = parseOpts(opts)
    assert not opts.usenetrc
    assert args == ['--help']


# Generated at 2022-06-24 14:06:19.149983
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    sys.argv = ['test']
    parser, opts, args = parseOpts([])
    assert not opts.verbose
    assert opts.username is None
    assert opts.password is None
    assert opts.usenetrc is True
    sys.argv = ['test', '-v']
    parser, opts, args = parseOpts([])
    assert opts.verbose
    sys.argv = ['test', '--verbose']
    parser, opts, args = parseOpts([])
    assert opts.verbose

    with tempfile.NamedTemporaryFile(delete=False) as tf:
        tf.write(b'-v\n')
        tf.write(b'--username=user1\n')

# Generated at 2022-06-24 14:06:25.826879
# Unit test for function parseOpts
def test_parseOpts():
    Parser, Opts, Arguments = parseOpts([])
    assert(Opts.usenetrc == True)
    assert(Opts.username == None)
    assert(Opts.password == None)

    Parser, Opts, Arguments = parseOpts(['--username', 'unit_test', '--password', 'unit_test'])
    assert(Opts.usenetrc == False)
    assert(Opts.username == 'unit_test')
    assert(Opts.password == 'unit_test')


# Generated at 2022-06-24 14:06:30.736561
# Unit test for function parseOpts
def test_parseOpts():
    def parse(args, overrideArguments=None):
        parser, opts, args = parseOpts(overrideArguments)
        return [opts.__dict__[a] for a in args]

    assert parse([]) == []
    assert parse(['-h']) == [True]
    assert parse(['-i']) == [True]
    assert parse(['-u', 'user']) == ['user']
    assert parse(['-p', 'pass']) == ['pass']

    if os.name == 'nt':
        assert parse(['-o', 'a']) == ['a.flv']
        assert parse(['-o', 'a.%(ext)s']) == ['a.%(ext)s']

# Generated at 2022-06-24 14:06:32.969691
# Unit test for function parseOpts
def test_parseOpts():
    opts = []
    args = []
    parser = None
    parser, opts, args = parseOpts(opts, args, parser)
    return parser, opts, args
# parseOpts()

from . import update


# Generated at 2022-06-24 14:06:40.374319
# Unit test for function parseOpts
def test_parseOpts():
    def test(argv, exp_outputs, **kwargs):
        class opts:
            pass
        parser, opts, args = parseOpts(argv, opts, **kwargs)
        assert opts.verbose == exp_outputs['verbose']
        assert opts.ignoreerrors == exp_outputs['ignoreerrors']
        assert opts.usenetrc == exp_outputs['usenetrc']
        assert opts.username == exp_outputs['username']
        assert opts.password == exp_outputs['password']
        assert opts.twofactor == exp_outputs['twofactor']
        assert opts.videopassword == exp_outputs['videopassword']


# Generated at 2022-06-24 14:06:46.254841
# Unit test for function parseOpts
def test_parseOpts():
    print("Testing function: parseOpts")
    parser, opts, args = parseOpts(overrideArguments=None)
    print("Options obtained:")
    print(parser)
    print("Options:")
    print(opts)
    print("Arguments:")
    print(args)

if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-24 14:06:54.164326
# Unit test for function parseOpts
def test_parseOpts():
    def check_opts(opts, expected):
        for name, value in expected:
            assert (getattr(opts, name) == value)
    def check(override, expected):
        parser, opts, _ = parseOpts(override)
        check_opts(opts, expected)
    # Test 1: option values
    check(['--prefer-free-formats'], [('prefer_free_formats', True)])
    check(['--no-prefer-free-formats'], [('prefer_free_formats', False)])
    check(['--proxy', '1.2.3.4:3128'], [('proxy', '1.2.3.4:3128')])

# Generated at 2022-06-24 14:06:57.677487
# Unit test for function parseOpts
def test_parseOpts():
    print('====== test_parseOpts ======')
    parser, opts, args  = parseOpts()
    print(parser)
    print(opts)
    print(args)


# Generated at 2022-06-24 14:07:06.404102
# Unit test for function parseOpts
def test_parseOpts():
    import sys

    if sys.version_info < (3,):
        # noinspection PyUnresolvedReferences
        reload(sys)
        # noinspection PyUnresolvedReferences
        sys.setdefaultencoding('utf-8')

    # First we try it with the usual configuration
    parser, opts, args = parseOpts(None)
    assert opts.verbose == False
    assert args == []

    # Now we create a specific configuration
    parser, opts, args = parseOpts(['-f', '18', '-v', 'https://www.youtube.com/watch?v=BaW_jenozKc'])

    # And we check that the config was taken into account
    assert opts.verbose == True
    assert opts.format == ['18']

# Generated at 2022-06-24 14:07:09.447402
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--verbose', '--prefix', 'START ', 'https://www.youtube.com/watch?v=_HSylqgVYQI'])
    assert opts.prefix == 'START '
    assert opts.verbose == True
    assert args == ['https://www.youtube.com/watch?v=_HSylqgVYQI']


# Generated at 2022-06-24 14:07:20.836575
# Unit test for function parseOpts
def test_parseOpts():

    # Test for function _readUserConf()
    def test_readUserConf():
        fd, f = tempfile.mkstemp()
        f = io.open(f, 'w', encoding='utf-8')
        f.write(
            u'# This is a user configuration file\n'
            u'--proxy http://proxy.example.org:3128\n'
            u'--verbose\n')
        f.close()
        user_conf = _readOptions(f.name)
        os.close(fd)
        os.remove(f.name)
        assert user_conf == [u'--proxy', u'http://proxy.example.org:3128', u'--verbose']


    test_readUserConf()

    # Test for function _hide_login_info()

# Generated at 2022-06-24 14:07:32.254807
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args =  parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.get_format_limit == None
    assert opts.verbosity_level == 0
    assert opts.dump_user_agent == False
    assert opts.list_extractors == False
    assert opts.default_search == 'auto'
    assert opts.use_manual_captions == False
    assert opts

# Generated at 2022-06-24 14:07:33.258095
# Unit test for function parseOpts
def test_parseOpts():
    print("1")

# Generated at 2022-06-24 14:07:41.664767
# Unit test for function parseOpts
def test_parseOpts():
    from .YoutubeDL import parseOpts
    from .utils import prepend_extension
    # Test URL
    url = 'http://www.youtube.com/user/TheLinuxFoundation'
    # Test output template
    outtmpl = '%(uploader)s/%(upload_date)s - %(title)s.%(ext)s'
    # Test argv
    argv = ['--usenetrc', '--username', 'ytdluser', '--password', 'ytdlpass', '--format', 'best', '--download-archive', 'archive.log', '--output', outtmpl, url]
    # Test parser
    parser, opts, args = parseOpts(argv)
    # Test values
    assert opts.usenetrc

# Generated at 2022-06-24 14:07:46.027588
# Unit test for function parseOpts
def test_parseOpts():
    def parse(args):
        parser, opts, args = parseOpts(overrideArguments = args)
        return vars(opts)

    # Parse options with empty arguments
    assert(parse([]) == {})

    # Parse no arguments
    assert(parse(None) == {})

# Parse a string

# Generated at 2022-06-24 14:07:58.507832
# Unit test for function parseOpts
def test_parseOpts():
    # Test parsing
    def parseOptTest(args, kwargs):
        kwargs['overrideArguments'] = args
        return parseOpts(**kwargs)
    parser, opts, args = parseOptTest(['-U', 'FooBar', '-f', '22', '-g', '60', '-b', '22k', '-x', '-o', ''], {})
    assert opts.username == 'FooBar'
    assert opts.format == '22'
    assert opts.min_filesize == '60'
    assert opts.max_filesize == '22k'
    assert opts.extractaudio
    assert opts.nooverwrites

# Generated at 2022-06-24 14:08:09.807578
# Unit test for function parseOpts
def test_parseOpts():

    # Check if --get-version works
    opts, args = parseOpts(['--get-version'])
    assert getattr(opts, 'getversion', None)

    # Test --match-title option
    opts, args = parseOpts(['--match-title', 'test'])
    assert opts.matchtitle == ['test']
    opts, args = parseOpts(['--match-title', 'test1', '--match-title', 'test2'])
    assert opts.matchtitle == ['test1', 'test2']
    opts, args = parseOpts(['--match-title', 'test1', '--no-match-title', '--match-title', 'test2'])
    assert opts.matchtitle == ['test2']

# Generated at 2022-06-24 14:08:13.262305
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts(overrideArguments = ['--verbose'])
    assert opts.verbose is True

# ----------------------------------------------------------------------------- 
# test_parseOpts
#
# Test suite for the parseOpts function.
# ----------------------------------------------------------------------------- 

# Generated at 2022-06-24 14:08:20.875176
# Unit test for function parseOpts
def test_parseOpts():
    def assert_equal(a, b, desc=None):
        if desc is not None:
            desc = ' (%s)' % desc
        if a != b:
            raise AssertionError('%s != %s%s' % (repr(a), repr(b), desc))

    def assert_raises(exception, function, *args, **kwargs):
        try:
            function(*args, **kwargs)
        except exception as e:
            return e
        else:
            raise AssertionError('No exception was raised')

    def assert_not_raises(function, *args, **kwargs):
        try:
            function(*args, **kwargs)
        except Exception:
            raise AssertionError('Unexpected exception was raised')


# Generated at 2022-06-24 14:08:30.945839
# Unit test for function parseOpts
def test_parseOpts():

    # Dummy settings
    setattr(opts, 'username', 'dummyusername')
    setattr(opts, 'password', 'dummypassword')
    setattr(opts, 'ap_username', 'dummyusername')
    setattr(opts, 'ap_password', 'dummypassword')

    # Test default parse of options
    parser, opts, args = parseOpts()
    assert(getattr(opts, 'username') is None)
    assert(getattr(opts, 'password') is None)
    assert(getattr(opts, 'ap_username') is None)
    assert(getattr(opts, 'ap_password') is None)

    # Test parse of options with override

# Generated at 2022-06-24 14:08:42.169805
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(["-h"])[1] is None
    assert parseOpts(["--username=a","--password","b"])[1].username == "a"
    assert parseOpts(["--username=a","--password","b"])[1].password == "b"
    assert parseOpts(["--username","b"])[1].username is None
    assert parseOpts(["--password","b"])[1].password is None
    assert parseOpts(["--username","b","--password","c"])[1].username is None
    assert parseOpts(["--username","b","--password","c"])[1].password is None
    assert parseOpts(["--username","b","-p","c"])[1].username is None
    assert parseOpts(["--username","b","-p","c"])[1].password

# Generated at 2022-06-24 14:08:44.440304
# Unit test for function parseOpts
def test_parseOpts():
    opts, _ = parseOpts([])
    assert 'verbose' in opts.__dict__
    assert 'proxy' in opts.__dict__
    # TODO: Add more unit tests



# Generated at 2022-06-24 14:08:55.186724
# Unit test for function parseOpts
def test_parseOpts():
    opts = namedtuple('Options', ['username', 'password', 'ap_username', 'ap_password', 'embedthumbnail'])
    opts.username = 'myuser'
    opts.password = 'mypass'
    opts.ap_username = None
    opts.ap_password = None
    opts.embedthumbnail = False

    opts_repr = repr(opts)
    opts_repr_exp = "Options(ap_password=None, ap_username=None, password='mypass', username='myuser', embedthumbnail=False)"

# Generated at 2022-06-24 14:09:02.516735
# Unit test for function parseOpts
def test_parseOpts():
    # This method tests parseOpts() but also depends on write() and
    # compat_expanduser(), because the arguments it parses in one way
    # or another lead to calls to those functions.
    #
    # We can only test that the parsing does not cause errors and
    # does not throw exceptions, in the active code path for
    # most parameters.  However, to improve code coverage, we
    # over-test some parameters (by passing them invalid values,
    # expecting an exception).  Those are marked with TODO.

    old_stdout = sys.stdout
    sys.stdout = io.BytesIO() # We don't actually care about the output

# Generated at 2022-06-24 14:09:14.021619
# Unit test for function parseOpts
def test_parseOpts():
    # Test the parsing of config and command-line arguments
    assert parseOpts(['-U', '--username', 'user', '--', '--no-playlist'])[1].username == 'user'
    assert parseOpts(['--username=user', '--', '--no-playlist'])[1].username == 'user'
    assert parseOpts(['--username=user,pass', '--', '--no-playlist'])[1].username == 'user,pass'
    assert parseOpts(['--username=user,pass', '-p', 'pass2', '--', '--no-playlist'])[1].username == 'user,pass'

# Generated at 2022-06-24 14:09:19.384612
# Unit test for function parseOpts
def test_parseOpts():
    old_sys_argv = sys.argv
    old_environ_HOME = os.environ.get('HOME')
    old_environ_COOKIEFILE = os.environ.get('COOKIEFILE')
    old_environ_COOKIEDIR = os.environ.get('COOKIEDIR')
    old_environ_XDG_CACHE_HOME = os.environ.get('XDG_CACHE_HOME')
    old_environ_YOUTUBE_DL_CONFIG_PATH = os.environ.get('YOUTUBE_DL_CONFIG_PATH')

# Generated at 2022-06-24 14:09:28.039827
# Unit test for function parseOpts
def test_parseOpts():
    if __name__ == '__main__':
        parser, opts, args = parseOpts([])
        assert(opts.version)
        parser, opts, args = parseOpts(['-U'])
        assert(opts.update_self)
        parser, opts, args = parseOpts(['-v'])
        assert(opts.verbose)
        parser, opts, args = parseOpts(['-h'])
        assert(opts.help)
#
#
#
#
# }}}
#
# {{{ youtube-dl main program

# Generated at 2022-06-24 14:09:33.386678
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    argv = [argv[0]] + ['-o', 'test']
    parser, opts, args = parseOpts()
    assert 'test' == opts.outtmpl
    assert not opts.usenetrc


# Generated at 2022-06-24 14:09:35.009088
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()
# End of function test_parseOpts

# Generated at 2022-06-24 14:09:45.713556
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info >= (3,):
        return
    parser, opts, args = parseOpts([])
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.forceurl is False
    assert opts.forcetitle is False
    assert opts.forceratelimit is None
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.format is None
    assert opts.listformats is False
    assert opts.matchtitle is None
    assert opts.rejecttitle is None
    assert opts.max_downloads is -1
    assert opts.prefer_insecure is False
    assert opts.proxy is None
    assert opts.extract_flat is None
    assert opts.age_limit

# Generated at 2022-06-24 14:09:47.599335
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    parser, opts, args = parseOpts()
    print(opts.verbose)
    sys.exit()

# demo for youtube
# test_parseOpts()


# Generated at 2022-06-24 14:09:58.120914
# Unit test for function parseOpts
def test_parseOpts():
    # A very simple test:
    # parseOpts should return 3 values,
    # where the second and the third value
    # aren't the same (opts is different
    # from args).

    import sys
    import optparse

    parser, opts, args = parseOpts()

    assert isinstance(parser, optparse.OptionParser)
    assert opts != args
    for v in 'parser opts args'.split():
        locals()[v] = 'PASS'
    write_string('[debug] Unit test for parseOpts: %s, %s, %s\n' % (parser, opts, args))

try:
    import hashlib
    md5 = lambda s: hashlib.md5(s.encode('utf-8')).hexdigest()
except ImportError:
    import md5
    md

# Generated at 2022-06-24 14:10:09.268090
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import Option, OptionValueError
    class OptionError(Exception):
        pass
    class MockOption(Option):
        ACTIONS = Option.ACTIONS + ("test",)
        STORE_ACTIONS = Option.STORE_ACTIONS + ("test",)
        TYPED_ACTIONS = Option.TYPED_ACTIONS + ("test",)
        ALWAYS_TYPED_ACTIONS = Option.ALWAYS_TYPED_ACTIONS + ("test",)
        def take_action(self, action, dest, opt, value, values, parser):
            if action == "test":
                if value is None:
                    raise OptionValueError("need a test value")
                setattr(values, dest, value)
                parser.values.ensure_value("testvalue", "testing")

# Generated at 2022-06-24 14:10:18.125710
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts([])
    assert opts.username is None and opts.password is None and opts.usenetrc is False
    opts, args = parseOpts(['-uadmin', '-padminpass'])
    assert opts.username == 'admin' and opts.password == 'adminpass' and opts.usenetrc is False
    opts, args = parseOpts(['--username=regularuser', '--password=regularpass'])
    assert opts.username == 'regularuser' and opts.password == 'regularpass' and opts.usenetrc is False
    opts, args = parseOpts(['--usenetrc'])
    assert opts.username is None and opts.password is None and opts.usenetrc is True



# Generated at 2022-06-24 14:10:29.411202
# Unit test for function parseOpts
def test_parseOpts():
    import youtube_dl.YoutubeDL
    import optparse