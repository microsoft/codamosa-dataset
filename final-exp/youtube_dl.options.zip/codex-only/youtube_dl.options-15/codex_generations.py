

# Generated at 2022-06-24 14:00:33.961435
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'noproblem'
    assert opts.verbose == 1
    assert opts.quiet == True
    assert opts.forceurl == True
    assert opts.forcetitle == True
    assert opts.simulate == True
    assert opts.skip_download == True
    assert opts.format == 'best'
    assert opts.listformats == True
    assert opts.outtmpl == '%(title)s-%(id)s-%(autonumber)s.%(ext)s'
    assert opts.ignoreerrors == True
    assert opts.forcefilename == True
    assert opts.usenetrc == True
    assert opts.verbose == True
    assert opts.quiet == True


# Generated at 2022-06-24 14:00:45.053326
# Unit test for function parseOpts

# Generated at 2022-06-24 14:00:57.277140
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-h'])
    opts, args = parseOpts(['--help'])
    opts, args = parseOpts(['--version'])
    opts, args = parseOpts(['-U', 'unknown_user_agent'])
    opts, args = parseOpts(['--user-agent', 'unknown_user_agent'])
    opts, args = parseOpts(['-R', '100'])
    opts, args = parseOpts(['--rate-limit', '100'])
    opts, args = parseOpts(['-r', '100'])
    opts, args = parseOpts(['--retries', '100'])
    opts, args = parseOpts(['--dump-user-agent'])
    opts,

# Generated at 2022-06-24 14:01:08.844462
# Unit test for function parseOpts
def test_parseOpts():
    """Parse the command line options."""
    # Test the help
    def testHelp():
        print(testHelp.__name__)
        parser, opts, args = parseOpts(['-h'])
        parser, opts, args = parseOpts(['--no-version-check'])
        parser, opts, args = parseOpts(['-U'])
        parser, opts, args = parseOpts(['--update'])
        parser, opts, args = parseOpts(['-v'])
        parser, opts, args = parseOpts(['--verbose'])
        parser, opts, args = parseOpts(['-q'])
        parser, opts, args = parseOpts(['--quiet'])

# Generated at 2022-06-24 14:01:19.373225
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(overrideArguments=['-F'])[1].format == 'best'
    assert parseOpts(overrideArguments=['--format=bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])[1].format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert parseOpts(overrideArguments=['--format=bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]'])[1].format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]'

# Generated at 2022-06-24 14:01:20.689194
# Unit test for function parseOpts
def test_parseOpts():
    # Test
    opts, args = parseOpts(['-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])


# Generated at 2022-06-24 14:01:27.689203
# Unit test for function parseOpts
def test_parseOpts():
    # Basic sanity test for parseOpts
    from six import StringIO
    returncode = -1
    try:
        stdout = sys.stdout
        sys.stdout = StringIO()
        parser, opts, args = parseOpts()
        returncode = 0
    except SystemExit as e:
        returncode = 2 if e.code != 0 else 0
    sys.stdout = stdout
    return 'parseOpts', returncode
if __name__ == '__main__':
    print('Testing %s ...' % __name__)
    test_functions = []
    test_functions.append(test_parseOpts)
    for test_func in test_functions:
        print('%s: %s' % test_func())
    print('%s: All tests passed!' % __name__)

# Generated at 2022-06-24 14:01:29.452005
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    print(doctest.testmod(sys.modules[__name__]))



# Generated at 2022-06-24 14:01:38.553853
# Unit test for function parseOpts
def test_parseOpts():
    class Struct:
        pass
    fake_args = Struct()
    fake_args.cookiefile = None
    fake_args.nopart = False
    fake_args.continuedl = False
    fake_args.nooverwrites = False
    fake_args.format = None
    fake_args.listformats = None
    fake_args.outtmpl = None
    fake_args.ignoreerrors = False
    fake_args.forceurl = False
    fake_args.forcetitle = False
    fake_args.forceid = False
    fake_args.forcefilename = False
    fake_args.simulate = False
    fake_args.format_limit = None
    fake_args.verbose = False
    fake_args.dump_user_agent = False
    fake_args.list_extractors

# Generated at 2022-06-24 14:01:47.905745
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import *
    from youtube_dl.version import __version__
    import locale
    import sys
    import os

    # python 2.x seems to ignore the locale environment var from
    # the nosetests config
    if sys.version < '3':
        os.environ['LC_ALL'] = 'en_US.UTF-8'
        os.environ['LANG'] = 'en_US.UTF-8'

    # Test --get-url and --get-title
    assert parseOpts(['--get-url', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1].geturl
    assert parseOpts(['--get-title', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1].get

# Generated at 2022-06-24 14:01:57.106052
# Unit test for function parseOpts

# Generated at 2022-06-24 14:02:04.900363
# Unit test for function parseOpts
def test_parseOpts():
    def _compare(a, b):
        return set(a) == set(b)
    parser, opts, args = parseOpts()
    opts_valid = True
    for opt in parser.option_list:
        if opt.dest is not None:
            if opt.default is not None and getattr(opts, opt.dest) != opt.default:
                opts_valid = False
                break
    if not opts_valid:
        write_string('[runtime error] Options default value mismatch\n')
        write_string('[runtime error] Please check with upstream and report a bug if needed.\n')

    if opts.download_archive and not opts.continue_dl:
        opts.continue_dl = True


# Generated at 2022-06-24 14:02:13.394142
# Unit test for function parseOpts
def test_parseOpts():
    args = ['--username=user', '--password=12345', 'http://www.youtube.com/watch?v=BaW_jenozKc']
    parser,opts,args = parseOpts(args)

    assert opts.username == 'user'
    assert opts.password == '12345'
    assert opts.usenetrc == False
    assert opts.noplaylist == False
    assert opts.age_limit == None
    assert opts.download_archive == None
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == None

# Generated at 2022-06-24 14:02:23.174116
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info < (3,):
        return
    from io import StringIO

    out = StringIO()

    # Load conf from disk
    # TODO: Create conf file, use _readOptions
    #opts, args = parseOpts(['-o', 'out'], out)
    #assert opts.outtmpl == 'out'
    #assert args == []
    #assert opts.verbose == False

    # Load conf from argv
    opts, args = parseOpts(['--ignore-config', '-o', 'out'], out)
    assert opts.outtmpl == 'out'
    assert args == []
    assert opts.verbose == False

    # Override conf, ignore argv

# Generated at 2022-06-24 14:02:26.556691
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["-v", "--verbose", "-u", "--username", "foo", "-p", "--password", "bar", "-i", "--ignore-errors", "--flat-playlist", "--no-color"])
    print("parser: ", parser, " opts: ", opts, "args: ", args)

# Generated at 2022-06-24 14:02:38.111291
# Unit test for function parseOpts
def test_parseOpts():
    assert(parseOpts(['-f', '18/22/37/38/best', '-g', 'BV1A941127jf']) ==
        parseOpts(['--format', '18/22/37/38/best', '--get-id', 'BV1A941127jf']))
    assert(parseOpts(['-f', 'av01']) == parseOpts(['--format', 'av01']))
    assert(parseOpts(['--format', 'av01/mp4']) == parseOpts(['--format', 'av01', '--format', 'mp4']))

# Generated at 2022-06-24 14:02:45.477032
# Unit test for function parseOpts
def test_parseOpts():
    opts = ['--username', 'foo', '--password', 'bar']
    parser, opts, args = parseOpts(opts)
    assert opts.username == 'foo'
    assert opts.password == 'bar'

# Parse arguments
parser, opts, args = parseOpts(None)

if opts.help:
    parser.print_help()
    sys.exit(0)

if opts.version:
    write_string('youtube-dl %s\n' % __version__)
    sys.exit(0)



# Generated at 2022-06-24 14:02:57.043508
# Unit test for function parseOpts
def test_parseOpts():
    class MockParse(object):
        def __init__(self):
            self.opts = None
            self.args = None

        def parse_args(self, argv):
            self.args = argv[1:]
            return self.opts, self.args

    mp = MockParse()
    mp.opts, mp.args = parseOpts(mp, overrideArguments=['--username', 'myname', '--password', 'mypw'])
    assert mp.args == ['--username', 'myname', '--password', 'mypw']
    assert mp.opts.username == 'myname'
    assert mp.opts.password == 'mypw'

    mp.opts, mp.args = parseOpts(mp, overrideArguments=[])
    assert mp.args == []


#

# Generated at 2022-06-24 14:02:59.505258
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = [sys.argv[0]]
    sys.argv += '--help'.split()
    parseOpts()

if __name__ == '__main__':
    test_parseOpts()


# Generated at 2022-06-24 14:03:10.726082
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    import sys

    parser, opts, args = parseOpts(['--no-warnings', '--quiet', 'http://www.youtube.com/watch?v=BaW_jenozKc'])

    if len(args) <= 0:
        sys.exit()

    def warn(msg, *a, **ka):
        print('warning:', msg % a % ka)

    ydl = YoutubeDL(opts, warn)

    try:
        ydl.download(args)
    except DownloadError as de:
        if de.exc_info[0] is KeyboardInterrupt:
            sys.exit(1)
        elif de.exc_info[0] is MaxDownloadsReached:
            sys.exit(2)
        else:
            raise

# Generated at 2022-06-24 14:03:20.333839
# Unit test for function parseOpts
def test_parseOpts():
    argv = ["-f", "18", "-i", "--get-url", "--get-title", "--get-id",
    "--get-thumbnail", "--get-description", "--get-filename", "--get-format",
    "--get-duration", "-v", "--no-warnings", "--skip-download", "--output",
    "test.%(ext)s", "https://www.youtube.com/watch?v=BaW_jenozKc",
    "https://www.youtube.com/watch?v=BQ0mxQXmLsk"]
    parser, opts, args = parseOpts(argv)
    assert opts.outtmpl == 'test.%(ext)s', opts.outtmpl
    assert opts.format == '18', opts.format

# Generated at 2022-06-24 14:03:28.018780
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor.youtube import YoutubeIE
    from .downloader.external import YoutubeDLCookieJar

    def _parse(args, *a, **k):
        return info_dict, parseOpts(args=args, *a, **k)

    #
    # Test:
    #   - required options
    #   - non-required options
    #   - get_opts
    #   - conflicting options
    #   - noprogress
    #   - verbose
    #   - quiet
    #   - default values
    #   - override configuration files
    #   - -i
    #
    #   - merge_output_format
    #   - match_filter
    #   - postprocessors
    #   - extractors
    #   - proxies
    #
    # Some parsing-related tests are in test

# Generated at 2022-06-24 14:03:34.000118
# Unit test for function parseOpts
def test_parseOpts():
    def check_parseOpts(args, exc=None):
        parser, opts, args = parseOpts(args)
        if exc is not None:
            assert exc in str(e), str(e)

    for args, exc in [
            (['--extract-audio'], '--extract-audio'),
            (['--embed-subs', '--embed-thumbnail'], '--embed-thumbnail'),
            (['--add-metadata', '--embed-thumbnail'], '--embed-thumbnail'),
            ]:
        try:
            check_parseOpts(args, exc)
        except Exception as e:
            pass
        else:
            assert False, 'Expected exception not raised'
    check_parseOpts(['--extract-audio', '--no-post-overwrites'])
   

# Generated at 2022-06-24 14:03:40.784621
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from tempfile import mkstemp
    from os import close, remove
    from shutil import rmtree
    from os.path import exists, join
    from os import mkdir
    from urllib import quote
    from sys import version_info

    fd, fname = mkstemp()
    close(fd)
    def removeFile():
        if exists(fname):
            remove(fname)

# Generated at 2022-06-24 14:03:50.600604
# Unit test for function parseOpts
def test_parseOpts():
    def _test_opts_with_value(opts):
        assert opts.outtmpl == '%(title)s.f%%'
        assert opts.verbose == 4
        assert opts.quiet == True
        assert opts.username == 'ytdl'
        assert opts.password == 'ytpass'
        assert opts.ap_mso == 'ap_mso_value'
        assert opts.ap_username == 'ap_username_value'
        assert opts.ap_password == 'ap_password_value'
        assert opts.usenetrc == True
        assert opts.no_check_certificate == True
        assert opts.list_extractors == True
        assert opts.dump_intermediate_pages == True
        assert opts.write_pages == True

# Generated at 2022-06-24 14:04:00.966608
# Unit test for function parseOpts
def test_parseOpts():
    from types import ModuleType
    from youtube_dl.compat import compat_str
    from youtube_dl.utils import encodeArgument
    from youtube_dl.version import __version__

    # Test options that change the code flow
    # The expected string is: 'youtube-dl version VERSION'
    args = ['--version']
    mod = ModuleType('__main__')
    mod.__file__ = './youtube-dl'
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = StringIO()
    sys.stderr = StringIO()
    try:
        parseOptions(args, mod)
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr
    assert sys.stderr.getvalue

# Generated at 2022-06-24 14:04:07.750097
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--no-check-certificate', '--youtube-skip-dash-manifest', '--cookies', '/tmp/youtube-dl/cookies.txt', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.cookiefile == '/tmp/youtube-dl/cookies.txt'
    assert opts.nocheckcertificate == True
    assert opts.youtubeskipdashmanifest == True
    assert opts.ignoreerrors == True



# Generated at 2022-06-24 14:04:09.809182
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.test_bool == False
    assert opts.test_string == "test"
    assert opts.test_int == 0

# Generated at 2022-06-24 14:04:12.110235
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts is not None
    assert args is not None
test_parseOpts.unit = True
test_parseOpts()


# Generated at 2022-06-24 14:04:24.506367
# Unit test for function parseOpts
def test_parseOpts():
    from io import BytesIO
    from argparse import SUPPRESS
    from youtube_dl.compat import compat_str

    def _parseOpts(line):
        opts_dict = {}
        for optstr in line.split(' '):
            if '=' in optstr:
                option, value = optstr.split('=')
                opts_dict[option] = value
            else:
                opts_dict[optstr] = None
        return opts_dict


# Generated at 2022-06-24 14:04:28.317602
# Unit test for function parseOpts
def test_parseOpts():
    """
    Unit test for function parseOpts
    """
    parser, opts, args = parseOpts()
    assert(parser)
    assert(opts)
    assert(args)


# Generated at 2022-06-24 14:04:31.603817
# Unit test for function parseOpts
def test_parseOpts():
    try:
        return None, parseOpts(overrideArguments=['-U', '-p', 'plop']), []
    except SystemExit as e:
        return e.args[0], None, None


# Generated at 2022-06-24 14:04:34.345197
# Unit test for function parseOpts
def test_parseOpts():
    print('parseOpts')
    #assert parseOpts() == None

# Main function, which is run when this script is invoked

# Generated at 2022-06-24 14:04:45.702153
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['--no-color', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.no_color
    assert opts.verbose is False
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    opts, args = parseOpts(['--no-color', '-v', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.no_color
    assert opts.verbose is True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-24 14:04:56.577134
# Unit test for function parseOpts
def test_parseOpts():
    from compat import compat_shlex_split
    from optparse import OptionValueError

    opts, args = parseOpts(overrideArguments=['-h'])
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)
    assert opts.help
    assert not opts.username

    opts, args = parseOpts(overrideArguments=['-U', 'foo'])
    assert not opts.help
    assert opts.username == 'foo'

    # Test with wrong password
    opts, args = parseOpts(overrideArguments=['-u', 'foo', '-p', 'bar'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'

    # Test with correct password
    opts, args = parseOpts

# Generated at 2022-06-24 14:05:07.325114
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-h'])
    assert parseOpts(['--help'])
    assert parseOpts(['-U', 'testuser', '-P', 'testpasswd', '-v', 'www.youtube.com'])
    assert parseOpts(['--username', 'testuser', '--password', 'testpasswd',
                      '--verbose', 'www.youtube.com'])
    # Test https proxy
    assert parseOpts(['--proxy', 'https://1.1.1.1:8080', 'www.youtube.com'])
    assert parseOpts(['--proxy', '1.1.1.1:8080', 'www.youtube.com'])
    assert parseOpts(['--proxy', '1.1.1.1', 'www.youtube.com'])

# Generated at 2022-06-24 14:05:10.570672
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert type(parser) == optparse.OptionParser
    assert type(opts) == optparse.Values
    assert type(args) == list


# Generated at 2022-06-24 14:05:13.833409
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.usenetrc is True


# Generated at 2022-06-24 14:05:23.497959
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import Values
    from types import ModuleType
    from youtube_dl.utils import decode_compat_str

    # Regular invocation
    assert parseOpts()[1].quiet == False
    assert parseOpts(['-q'])[1].quiet == True
    assert parseOpts(['--quiet'])[1].quiet == True

    # Override config
    assert parseOpts(['--quiet'], overrideArguments=['-q'])[1].quiet == True
    assert parseOpts(['--quiet'], overrideArguments=['-i'])[1].quiet == False

    # Deprecated
    assert parseOpts(['--get-url'])[1].extract_flat == 'in_playlist'

# Generated at 2022-06-24 14:05:31.054689
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from copy import copy
    testargs = copy(argv)
    testargs.extend(['-f', 'bestvideo[filesize<700M]+bestaudio[filesize<700M]/best[filesize<700M]'])
    testargs.extend(['-f', 'mp4'])
    testargs.extend(['-f', '[filesize<700M]'])
    testargs.extend(['-f', '[ext=mp4]'])
    testargs.extend(['-f', 'bestvideo[ext=mp4][height<=1080]+bestaudio[ext=m4a]/best[ext=mp4][height<=1080]'])

# Generated at 2022-06-24 14:05:42.164645
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["--version"])
    assert opts.version  # "--version" option is parsed correctly
    parser, opts, args = parseOpts(["--usenetrc", "--username", "user", "--password", "passwd", "youtube.com/watch?v=-J8BVg2rt0M"])
    assert opts.username == "user" and opts.password == "passwd"
    parser, opts, args = parseOpts(["--usenetrc", "--netrc", "youtube.com/watch?v=-J8BVg2rt0M"])
    assert opts.username == "alice" and opts.password == "hunter1"
    parser, opts, args = parseOpts()
    assert opts.call_home

# Generated at 2022-06-24 14:05:52.400390
# Unit test for function parseOpts
def test_parseOpts():
    try:
        os.unlink(os.path.expanduser('~' + '/.config/youtube-dl/config'))
    except OSError:
        pass

    if '--get-title' in sys.argv:
        # Testing title extraction
        sys.argv = [sys.argv[0], '--get-title'] + sys.argv[sys.argv.index('--get-title') + 1:]
    else:
        # Testing full download
        sys.argv = [sys.argv[0]] + sys.argv[sys.argv.index('--test') + 1:]

    parser, opts, args = parseOpts()

    write_string(u'Testing with config: ' + repr(_hide_login_info(sys.argv)) + '\n')


# Generated at 2022-06-24 14:05:54.386831
# Unit test for function parseOpts
def test_parseOpts():
    parseOpts(['--no-check-certificate', '--verbose'])


# Generated at 2022-06-24 14:06:02.258038
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import gen_extractor_classes
    from .extractor.common import InfoExtractor

    args = ['-U', '--youtube-skip-dash-manifest', '--dump-intermediate-pages', 'http://www.youtube.com/watch?v=BaW_jenozKc', '--', '--arg']

    opts, _ = parseOpts.parseArgs(args)
    assert opts.usenetrc is True
    assert opts.skip_dash_manifest is True
    assert opts.dump_intermediate_pages is True
    assert opts.noplaylist is False
    assert opts.max_downloads is None
    assert opts.playlist_reverse is False
    assert opts.playlist_start is 1
    assert opts.playlist_end is None

# Generated at 2022-06-24 14:06:08.915227
# Unit test for function parseOpts
def test_parseOpts():
    import sys

    conf = ['-v', '--proxy', 'http://127.0.0.1:1234']
    parser, opts, _ = parseOpts(overrideArguments=conf)
    assert opts.proxy.strip() == 'http://127.0.0.1:1234'

    conf = ['-v', '--proxy', 'http://foo:bar@127.0.0.1:1234']
    parser, opts, _ = parseOpts(overrideArguments=conf)
    assert opts.proxy.strip() == 'http://foo:bar@127.0.0.1:1234'

    conf = ['-v', '--proxy', 'socks5://foo:bar@127.0.0.1:1234']

# Generated at 2022-06-24 14:06:14.744386
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv, stderr

    argv = ['-i', 'https://www.youtube.com/watch?v=BaW_jenozKc', '--no-warnings']

    parser, opts, args = parseOpts(argv)
    stderr.write(repr(opts.__dict__) + "\n")

test_parseOpts()


# Generated at 2022-06-24 14:06:26.819177
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert not opts.extractaudio
    assert not opts.writeautomaticsub
    assert opts.skip_download
    assert not opts.simulate
    assert not opts.format

    opts, args = parseOpts(['-a', '-'])
    assert opts.batchfile == '-'
    assert not opts.simulate
    assert not opts.format

    opts, args = parseOpts(['--min-filesize', '100k'])
    assert opts.min_filesize == 102400

    opts, args = parseOpts(['--no-playlist'])
    assert opts.noplaylist


# Generated at 2022-06-24 14:06:34.929642
# Unit test for function parseOpts
def test_parseOpts():
    from xml.dom import minidom
    from xml.etree import ElementTree
    from xml.dom.minidom import parseString
    import sys
    import os
    import subprocess
    # Parse arguments and return all the options
    parser, opts, args = parseOpts()
    # Check if command entered was YouTube URL/webpage
    if not args:
        parser.print_usage()
        sys.exit(1)
    # Set the output option
    if opts.quiet:
        sys.stdout = open(os.devnull, 'w')
    # Set the proxy option
    if opts.proxy:
        if opts.verbose:
            write_string('[debug] Proxy map: ' + repr(opts.proxy) + '\n')
    # Set the verbosity

# Generated at 2022-06-24 14:06:47.284870
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i'])
    assert opts.ignoreerrors

    parser, opts, args = parseOpts(['--no-color'])
    assert opts.nocolor

    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-h'])
    assert opts.help

    parser, opts, args = parseOpts(['--update'])
    assert opts.update_self

    parser, opts, args = parseOpts(['--print-traffic'])
    assert opts.print_traffic

    parser, opts, args = parseOpts(['--ignore-config'])
    assert opts.ignoreconfig

    # Due to getprox

# Generated at 2022-06-24 14:06:49.417804
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts is not None
    assert parser is not None
    assert args is not None

# Generated at 2022-06-24 14:07:00.703182
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-c', '-b', 'foo'])[1].call_home
    assert not parseOpts(['--no-call-home'])[1].call_home
    assert parseOpts(['--flat-playlist'])[1].noplaylist
    assert parseOpts(['--no-flat-playlist'])[1].noplaylist
    assert parseOpts(['-i'])[1].ignoreerrors
    assert parseOpts(['--abort-on-error'])[1].ignoreerrors
    assert parseOpts(['--dump-user-agent'])[1].dump_user_agent
    assert parseOpts(['-U', 'youtube-dl test ua'])[1].user_agent == 'youtube-dl test ua'

# Generated at 2022-06-24 14:07:08.703638
# Unit test for function parseOpts
def test_parseOpts():
    # Test basic parsing
    parser, opts, args = parseOpts(['-f', '37', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '37'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    # Test multiple values
    parser, opts, args = parseOpts(['-f', '37', '-f', '22', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == ['37', '22']

    # Test default parsing
    parser, opts, args = parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts

# Generated at 2022-06-24 14:07:14.652912
# Unit test for function parseOpts
def test_parseOpts():
    try:
        opt_parser, opts, args = parseOpts(None)
    except OptionError as err:
        print('ERROR:', err)
    else:
        print('OPTIONS:')
        for k, v in vars(opts).items():
            print('%s: %s' % (k, repr(v)))
        print('ARGUMENTS:', args)

# parseOpts()


# Generated at 2022-06-24 14:07:25.632904
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeFilename
    from youtube_dl.YoutubeDL import YoutubeDL
    parser, opts, args = parseOpts(['-o', '%(stitle)s-%(id)s.%(ext)s', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.outtmpl == encodeFilename('%(stitle)s-%(id)s.%(ext)s')
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    assert isinstance(opts.ydl_opts, dict)
    assert isinstance(opts.params, dict)
    assert isinstance(YoutubeDL(opts.ydl_opts), YoutubeDL)


# Generated at 2022-06-24 14:07:30.705410
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument


# Generated at 2022-06-24 14:07:35.480361
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info < (2, 7):
        return

    parser, opts, args = parseOpts(['--ignore-config'], None)
    assert not opts.noplaylist

    opts, args = parseOpts(['-i'], None)
    assert opts.noplaylist
# End unit test for function parseOpts


# https://github.com/rg3/youtube-dl/issues/374

# Generated at 2022-06-24 14:07:43.418768
# Unit test for function parseOpts
def test_parseOpts():
    url = "https://www.youtube.com/watch?v=9bZkp7q19f0"
    parser, opts, args = parseOpts(['-v','-o','%(title)s.%(ext)s',url])
    assert url in args
    assert opts.verbose == True
    assert opts.outtmpl == '%(title)s.%(ext)s'
    #assert opts.verbose == False
    #assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'

# Generated at 2022-06-24 14:07:51.575691
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-h'])
    assert not args

    parser, opts, args = parseOpts(['-v'])
    assert not args

    parser, opts, args = parseOpts(['-h'])
    assert not args

    parser, opts, args = parseOpts(['-U', 'test_user_agent'])
    assert not args

    parser, opts, args = parseOpts(['-o', 'test_output'])
    assert not args

    parser, opts, args = parseOpts(['--default-search', 'test_search'])
    assert not args

    parser, opts, args = parseOpts(['-a', 'test_file'])
    assert not args


# Generated at 2022-06-24 14:08:02.333924
# Unit test for function parseOpts
def test_parseOpts():
    test_mod_downloader = 'wget'
    test_mod_format = 'best'
    test_mod_outtmpl = '%(stitle)s-%(id)s.%(ext)s'
    test_mod_usenetrc = True
    test_mod_username = 'judas'
    test_mod_password = 'satan'
    test_mod_verbose = True
    
    test_mod_override = ['-v', '-c', '-f', test_mod_format, '--no-continue', '-o', 
                         test_mod_outtmpl, '--netrc', '--username', test_mod_username,
                         '--password', test_mod_password, '--verbose', '--downloader', test_mod_downloader]
    
    parser,

# Generated at 2022-06-24 14:08:05.753815
# Unit test for function parseOpts
def test_parseOpts():
    (p, o, a) = parseOpts(['--format=22'])
    assert o.format == '22'

# End of unit test for function parseOpts


# Generated at 2022-06-24 14:08:11.843146
# Unit test for function parseOpts
def test_parseOpts():
    def parseAndCheck(args, results):
        parser, opts, args = parseOpts(args)
        for key, value in results.items():
            assert getattr(opts, key) == value, \
                    '%s: %s != %s' % (key, getattr(opts, key), value)
    parseAndCheck(['-o', 'ok'], {'outtmpl': 'ok'})


# Generated at 2022-06-24 14:08:22.083764
# Unit test for function parseOpts
def test_parseOpts():
    import sys

    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        for name in expected:
            assert(getattr(opts, name))
        for name in set(opts.__dict__) - set(expected):
            assert(not getattr(opts, name))

    # General
    _test(['-h'], [])
    _test(['--help'], [])
    _test(['--version'], [])
    _test(['--ignore-config'], ['ignoreconfig'])
    _test(['--no-check-certificate'], ['nocheckcertificate'])
    _test(['--no-color'], ['nocolor'])
    _test(['--encoding', 'UTF-8'], ['encoding'])


# Generated at 2022-06-24 14:08:31.551719
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([])
    assert parseOpts(['-h'])
    assert parseOpts(['-v'])
    assert parseOpts(['-U', 'unit user-agent'])
    assert parseOpts(['-f', 'bestvideo+bestaudio'])
    assert parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=mp4]/best[ext=mp4]/best'])
    assert parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/bestvideo+bestaudio/best'])

# Generated at 2022-06-24 14:08:33.693441
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.run_docstring_examples(parseOpts, globals())


# Generated at 2022-06-24 14:08:44.296960
# Unit test for function parseOpts
def test_parseOpts():
    with youtube_dl.FdIsMysteryIO(): # this is needed as of python 3.4
        opts, args = parseOpts(['-U', '--youtube-skip-dash-manifest', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == False
    assert opts.username == None
    assert opts.password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == True
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False


# Generated at 2022-06-24 14:08:51.608881
# Unit test for function parseOpts
def test_parseOpts():
    from six.moves.urllib.parse import parse_qs
    parser, opts, args = parseOpts(
    ['--username', 'user', '--password', 'pass', '--yes-playlist', r'https://www.youtube.com/watch?v=BaW_jenozKc&list=RDQM1vJ8b5Si5M'])
    assert args==['https://www.youtube.com/watch?v=BaW_jenozKc&list=RDQM1vJ8b5Si5M']
    #assert opts.usenetrc
    assert opts.username=='user'
    assert opts.password=='pass'
    assert opts.yes_playlist==True
    assert opts.noplaylist==False

    parser, opts, args = parseOpt

# Generated at 2022-06-24 14:09:02.673958
# Unit test for function parseOpts
def test_parseOpts():
    # Remove the global vars first.
    globals().pop('socket_equiv_domains', None)
    globals().pop('socket_equiv_name', None)
    # Test the socket equivalence
    class FakeSocket(object):
        def settimeout(self, timeout):
            pass
        def connect(self, sockaddr):
            pass
        def getpeername(self):
            return ('youtube.fake', 80)
    socket_equiv_name = 'youtube.fake'
    socket_equiv_domains = {}
    assert parseOpts(overrideArguments=['--socket-timeout=5', '--host-address=youtube.fake'])[2] == ['--socket-timeout=5', '--host-address=youtube.fake']

# Generated at 2022-06-24 14:09:10.840673
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from sys import stdout
    from tempfile import mkstemp
    my_fp = StringIO()
    old_fp = stdout

# Generated at 2022-06-24 14:09:19.823205
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.extractaudio == False
    parser, opts, args = parseOpts(['-x'])
    assert opts.extractaudio == True
    parser, opts, args = parseOpts([])
    assert opts.nooverwrites == False
    parser, opts, args = parseOpts(['-w'])
    assert opts.nooverwrites == True
    parser, opts, args = parseOpts([])
    assert opts.nopart == False
    parser, opts, args = parseOpts(['--no-part'])
    assert opts.nopart == True
    parser, opts, args = parseOpts([])
    assert opts.updatetime == True
    parser, opts,

# Generated at 2022-06-24 14:09:28.339884
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = ['youtube-dl', '-U']
    parser, opts, args = parseOpts()
    assert opts.update_self
    assert opts.nocheckcertificate

    sys.argv = ['youtube-dl', '-U', '--no-check-certificate']
    parser, opts, args = parseOpts()
    assert opts.update_self
    assert not opts.nocheckcertificate

    sys.argv = ['youtube-dl', '--ignore-config', '--username', 'foo']
    parser, opts, args = parseOpts()
    assert opts.username == 'foo'

    sys.argv = ['youtube-dl', '--ignore-config', '--username', 'foo',
                '--config-location', './test/test-config/config']

# Generated at 2022-06-24 14:09:40.287733
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-i', '--yes-playlist', '--username=foo', 'bar'])
    assert opts.usenetrc == False
    assert opts.username == 'foo'
    assert opts.ignoreerrors == True
    assert opts.download_archive == None
    assert opts.playliststart == 1
    assert opts.playlistend == None
    assert opts.playlistreverse == False
    assert opts.playlistrandom == False
    assert opts.noplaylist == False
    assert opts.yes_playlist == True
    assert opts.matchtitle == None
    assert opts.rejecttitle == None
    assert opts.max_downloads == None
    assert opts.prefer_free_formats == False
    assert opts.verbose

# Generated at 2022-06-24 14:09:42.182436
# Unit test for function parseOpts
def test_parseOpts():
    # For now, only checks that the parser does not crash
    parseOpts()
# parseOpts



# Generated at 2022-06-24 14:09:52.050212
# Unit test for function parseOpts
def test_parseOpts():
    # Test without authentification
    parser, opts, args = parseOpts(['-u', 'myuser', '-p', 'mypass'])
    assert (opts.username == 'myuser' and opts.password == 'mypass') or (opts.netrc)
    parser, opts, args = parseOpts(['--username', 'myuser', '--password', 'mypass'])
    assert (opts.username == 'myuser' and opts.password == 'mypass') or (opts.netrc)
    parser, opts, args = parseOpts(['--username', 'myuser', '--password', 'mypass', '-n'])
    assert opts.netrc
    # Test with authentification

# Generated at 2022-06-24 14:10:00.359392
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-h'])
    assert opts.help
    assert not args

    parser, opts, args = parseOpts(['--get-title', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.geturl
    assert opts.gettitle
    assert not opts.getid
    assert not opts.getthumb
    assert not opts.getdescription
    assert not opts.getfilename
    assert not opts.get_format
    assert not opts.usenetrc
    assert not opts.quiet
    assert not opts.get_type
    assert not opts.get_duration
    assert not opts.get_licence
    assert len(args) == 1
    assert args[0]

# Generated at 2022-06-24 14:10:12.302114
# Unit test for function parseOpts
def test_parseOpts():
    def check(args, expected):
        parser, opts, _args = parseOpts(overrideArguments=args)
        opts = dict(opts.__dict__) # optparse.Values is not hashable
        assert opts == expected

    assert '%%' not in parseOpts()[0].get_usage()

    check(['-U', 'a', '-P', 'b'], {
        'usenetrc': False,
        'username': 'a',
        'password': 'b',
    })
    check(['-ns'], {
        'quiet': True,
        'simulate': True,
    })
    check(['--playlist-reverse'], {
        'playlistreverse': True,
    })

# Generated at 2022-06-24 14:10:23.512048
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-o', '%(id)s.%(ext)s', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.usenetrc_machine == None
    assert opts.ap_mso == None
    assert opts.ap_listing == None
    assert opts.ap_thumbnail == False
    assert opts.ap_prefer_in_band_meta == False
    assert opt

# Generated at 2022-06-24 14:10:33.644424
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    (parser, opts, args) = parseOpts()
    assert opts.geturls == True
    assert opts.verbose == True
    assert opts.nooverwrites == False
    assert opts.continue_dl == True
    assert opts.nopart == False
    assert opts.updatetime == True
    assert opts.writedescription == False
    assert opts.writeinfojson == False
    assert opts.writeannotations == False
    assert opts.load_info_filename == None
    assert opts.cookiefile == None
    assert opts.cachedir == None
    assert opts.rm_cachedir == False
    assert opts.writethumbnail == False
    assert opts.write_all_thumbnails == False
    assert opts.list_thumbnails