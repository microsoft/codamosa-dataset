

# Generated at 2022-06-24 14:00:28.966406
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    return doctest.testmod()
# vim: set ts=4 sw=4 tw=0 noet :

# Generated at 2022-06-24 14:00:35.600772
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(overrideArguments=['--get-id'])[1]
    assert opts.geturls
    assert opts.simulate
    assert opts.nooverwrites
    assert opts.quiet
    assert opts.format is None
    assert opts.format_limit is None

    opts = parseOpts(overrideArguments=['-v'])[1]
    assert opts.verbose
    assert opts.quiet is False

    opts = parseOpts(overrideArguments=['-q'])[1]
    assert opts.quiet
    assert opts.verbose is False

    opts = parseOpts(overrideArguments=['--no-continue'])[1]
    assert opts.continue_dl is False
    assert opts.nop

# Generated at 2022-06-24 14:00:36.800800
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()


# Generated at 2022-06-24 14:00:37.660367
# Unit test for function parseOpts
def test_parseOpts():
    pass



# Generated at 2022-06-24 14:00:39.327320
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-i', '-v', 'http://www.youtube.com'])


# Generated at 2022-06-24 14:00:50.865898
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts()[1]
    assert len(opts.prefer_ffmpeg) == 1
    assert len(opts.format) == 1
    assert not opts.getatext
    assert opts.username == "username"
    assert opts.password == "password"
    assert opts.maxquality == "22"
    assert opts.nooverwrites
    assert opts.writeannotations
    assert opts.prefer_ffmpeg
    assert opts.format == "22"
    assert not opts.writedescription
    assert not opts.writeinfojson
    assert not opts.verbose
    assert not opts.writesubtitles
    assert not opts.writeautomaticsub
    assert not opts.usenetrc
    assert opts.list_thumbnails


# Generated at 2022-06-24 14:01:01.233470
# Unit test for function parseOpts
def test_parseOpts():
    try:
        from urllib.parse import urlparse, parse_qs
    except ImportError:
        from urlparse import urlparse, parse_qs

    # Test that -F can be specified by -f, --list-formats
    parser, opts, args = parseOpts(['-f', '22/18', '-F', 'foobar'])
    assert opts.usenetrc is False
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.videopassword is None
    assert opts.ap_mso is None
    assert opts.ap_username is None
    assert opts.ap_password is None
    assert opts.simulate is False
    assert opts.format == '22/18'
   

# Generated at 2022-06-24 14:01:05.915453
# Unit test for function parseOpts
def test_parseOpts():
    from xml.etree import ElementTree
    from xml.dom import minidom
    parser, opts, args = parseOpts()

    # We can't test everything but we can test the main things
    # General tests
    assert opts.ap_mso is None
    assert opts.ap_username is None
    assert opts.ap_password is None
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.twofactor_code is None
    assert opts.videopassword is None
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts

# Generated at 2022-06-24 14:01:14.671436
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.writedescription == False
    assert opts.writeinfojson == False
    assert opts.writeannotations == False
    assert opts.embedsubtitles == False
    assert opts.embedthumbnail == False
    assert opts.allsubtitles == False
    assert opts.listsubtitles == False
    assert opts.subtitleslangs == None
    assert opts.usetitle == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.writethumbnail == False
    assert opts.listthumbnails == False
   

# Generated at 2022-06-24 14:01:20.483262
# Unit test for function parseOpts
def test_parseOpts():
    p, o, a = parseOpts(['-U', 'UNIT TEST 1', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert o.usernames
    assert o.usernames[0] == 'UNIT TEST 1'
    assert a
    assert a[0] == 'https://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-24 14:01:27.566065
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test_user_agent', 'pl', 'ytsearch:"roflmao"'])
    assert opts.usenetrc, 'parseOpts does not return --usenetrc, or --no-usenetrc is set.'
    assert opts.username is None, 'parseOpts does not return --username=None, or --username is set.'
    assert opts.password is None, 'parseOpts does not return --password=None, or --password is set.'
    assert opts.ap_username is None, 'parseOpts does not return --ap-username=None, or --ap-username is set.'
    assert opts.ap_password is None, 'parseOpts does not return --ap-password=None, or --ap-password is set.'
   

# Generated at 2022-06-24 14:01:37.142234
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = prepare_args(['-g', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.simulate is True
    assert opts.quiet is False
    assert opts.geturl is True
    assert opts.gettitle is False
    assert opts.getid is False
    assert opts.getthumb is False
    assert opts.getdescription is False
    assert opts.getfilename is False
    assert opts.get_format is False
    assert opts.usenetrc is False
    assert opts.password is None
    assert opts.username is None
    assert opts.videopassword is None
    assert opts.ratelimit is None
    assert opts.retries is 10
    assert opts.buffersize

# Generated at 2022-06-24 14:01:42.622361
# Unit test for function parseOpts
def test_parseOpts():
    # Test 1
    test1_opt, test1_arg = parseOpts(['-h'])
    assert test1_opt.__class__.__name__ == 'Values'
    assert test1_arg == []
    # Test 2
    test2_opt, test2_arg = parseOpts(['--version'])
    assert test2_opt.__class__.__name__ == 'Values'
    assert test2_arg == []
    # Test 3
    test3_opt, test3_arg = parseOpts([])
    assert test3_opt.__class__.__name__ == 'Values'
    assert test3_arg == []

# Generated at 2022-06-24 14:01:53.383240
# Unit test for function parseOpts
def test_parseOpts():
    from os import name
    from sys import executable
    from sys import platform
    from sys import stdin
    from sys import stdout

    from collections import namedtuple
    from tempfile import gettempdir
    from tempfile import mkdtemp
    from tempfile import mkstemp
    from textwrap import dedent

    from .utils import strip_jsonp

    from .compat import compat_shlex_quote
    from .compat import compat_urlretrieve
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .postprocessor.ffmpeg import FFmpegPostProcessor
    from .postprocessor.ffmpeg import FFmpegMergerPP
    from .postprocessor.execafterdownload import ExecAfterDownloadPP

    from .downloader.common import FileDownloader


# Generated at 2022-06-24 14:02:02.150109
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose is True

# Command-line argument handling
parser, opts, args = parseOpts()

if hasattr(opts, 'help') and opts.help:
    parser.print_help()
    sys.exit()

if opts.version:
    sys.exit('youtube-dl ' + __version__)

# Set user agent
if opts.user_agent is not None:
    YoutubeDL.user_agent = opts.user_agent

if opts.extract_flat and opts.simulate:
    parser.error('Using both --flat-playlist and --simulate is not supported.')


# Generated at 2022-06-24 14:02:12.117070
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import tempfile
    _, conf_file = tempfile.mkstemp()
    def _write_config(data):
        """Write configuration data to a temporary file."""
        with open(conf_file, 'wb') as conf_fh:
            conf_fh.write(data.encode('utf-8'))
    def _read_config():
        """Read current configuration data from the temporary file."""
        with open(conf_file, 'rb') as conf_fh:
            return conf_fh.read().decode('utf-8')

    opts = [
        '--username', 'foo',
        '--password', 'bar',
        '--proxy', '1.2.3.4'
    ]

    # Check that options are correctly read from the configuration file
    _write_config

# Generated at 2022-06-24 14:02:23.068364
# Unit test for function parseOpts
def test_parseOpts():
    # call with all parameters set to false
    _, opts, _ = parseOpts(['--no-version-check', '--no-progress', '--quiet', '--no-warnings', '--no-call-home', '--ignore-errors', '--dump-user-agent', '--no-playlist'])
    assert opts.version
    assert opts.progress_with_newline is None
    assert opts.noprogress is None
    assert opts.quiet
    assert opts.noplaylist
    assert opts.dump_user_agent
    assert opts.ignoreerrors
    assert opts.call_home
    assert opts.nocheckcertificate
    assert not opts.noprogress
    assert not opts.proxy
    assert not opts.version
    assert not opts

# Generated at 2022-06-24 14:02:24.690272
# Unit test for function parseOpts
def test_parseOpts():
    global opts
    global args
    parser, opts, args = parseOpts()
# Subtitle options

# Generated at 2022-06-24 14:02:26.854403
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert(parser)
    assert(opts)
    assert(args)


# Generated at 2022-06-24 14:02:38.061351
# Unit test for function parseOpts
def test_parseOpts():
    from compat import argv
    from sys import argv
    try:
        sys.argv = sys.argv[0:1] + [
            '-i', '--no-warnings',
            '--get-title', '--get-description', '--get-filename',
            '--get-format', '--no-playlist',
            '--output=%(title)s-%(id)s-%(format_id)s.%(ext)s',
            '--newline',
            'rBaZwk2Ij8Y']
        parseOpts()
    except SystemExit as e:
        assert(e.code == 0)
        return
    raise AssertionError('Expected to exit normally')
# end unit test


# Generated at 2022-06-24 14:02:47.479061
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

    if opts.verbose:
        write_string('[debug] System config: %s\n' % repr(['--output', '%(title)s-%(upload_date)s.%(ext)s', '--restrict-filenames']))
        write_string('[debug] User config: %s\n' % repr([]))
        write_string('[debug] Custom config: %s\n' % repr([]))

# Generated at 2022-06-24 14:02:58.673624
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.compat import parseOpts
    from youtube_dl.utils import encodeArgument
    from tempfile import gettempdir
    import sys
    import os

    if sys.version_info < (2, 7):
        print('parseOpts() test skipped due to python-2.6')
        return

    def test_parsing(cli_args, expected_args, expected_opts):
        cli_args = [a if isinstance(a, compat_str) else encodeArgument(a) for a in cli_args]
        parser, actual_opts, actual_args = parseOpts(cli_args)

# Generated at 2022-06-24 14:03:09.847334
# Unit test for function parseOpts
def test_parseOpts():

    from io import StringIO
    from tempfile import NamedTemporaryFile

    # Run with empty argv
    parser, opts, args = parseOpts([])
    assert len(args) == 0

    # Run with some options and arguments
    parser, opts, args = parseOpts(['-o', 'out.%(ext)s', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert len(args) == 1
    assert args[0] == 'http://youtube.com/watch?v=BaW_jenozKc'
    assert opts.outtmpl == 'out.%(ext)s'

    # Test --ignore-config

# Generated at 2022-06-24 14:03:17.618220
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])

    # Check if the correct error is raised
    opts = None
    args = None
    try:
        parser, opts, args = parseOpts(['--config-location', '/non-existent'])
        assert False
    except SystemExit as err:
        assert err.code == 2

    # Check if the help is generated for the terminal
    args = None
    try:
        parser, opts, args = parseOpts(['--help'])
        assert False
    except SystemExit as err:
        assert err.code == 0
        assert not err.message


# Generated at 2022-06-24 14:03:26.149576
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.version import __version__
    parser, opts, args = parseOpts()
    assert opts.help
    assert opts.version == __version__
    assert opts.ignore_errors
    assert opts.forceurl
    assert opts.forcethumbnail
    parser, opts, args = parseOpts(['--no-color'])
    assert not opts.color
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--dump-user-agent'])
    assert opts.dump_user_agent
    parser, opts, args = parseOpts([])
    assert opts.socket_timeout == 300
    assert opts.source_address is None
    parser, opts

# Generated at 2022-06-24 14:03:35.017961
# Unit test for function parseOpts
def test_parseOpts():
    """Test parseOpts function"""

    def run_parseOpts(args=None):
        parser, opts, args = parseOpts(args)
        if opts.verbose:
            write_string('[debug] Config: ' + repr(_hide_login_info(parser.option_list)) + '\n')
        if opts.verbose:
            write_string('[debug] Parsed options: ' + repr(opts) + '\n')
        if opts.verbose:
            write_string('[debug] Parsed args: ' + repr(args) + '\n')
        return parser, opts, args

    # Test whether --help and -h work
    parser, opts, args = run_parseOpts(['-h'])

# Generated at 2022-06-24 14:03:41.824654
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parse_opts(command_line_conf, system_conf, user_conf, custom_conf, expected):
        def compat_expanduser(path):
            if sys.version_info < (3,):
                return path
            return path.decode(preferredencoding(), 'replace')

        output = StringIO()
        if custom_conf:
            overrideArguments = ['--config-location', compat_expanduser(opts.config_location)]
            overrideArguments += list(custom_conf)
        else:
            overrideArguments = []

        with contextlib.redirect_stdout(output):
            parser, opts, args = parseOpts(overrideArguments)
        output = output.getvalue()

        assert command_line_conf == ['--dump-user-agent']
        assert system_

# Generated at 2022-06-24 14:03:47.101976
# Unit test for function parseOpts
def test_parseOpts():
    print("Unit test for function parseOpts")
    _,opts,_ = parseOpts(['--proxy', 'http://127.0.0.1:1080', '-i', 'https://youtu.be/QNX9XBfQQZQ','--restrictfilenames','--verbose','--nopart','--sub-lang','en','--max-downloads','1','-o','/Users/ljm/Downloads/test.mp4'])
    assert opts.proxy == 'http://127.0.0.1:1080'
    assert opts.ignoreerrors == True
    assert opts.nopart == True
    assert opts.sub_lang == ['en']
    assert opts.max_downloads == 1
    assert opts.restrictfilenames == True
    assert opts

# Generated at 2022-06-24 14:03:57.705931
# Unit test for function parseOpts
def test_parseOpts():
    # Test parseOpts function
    from sys import argv
    from tempfile import mkdtemp
    from os.path import join
    from shutil import rmtree
    from io import open

    # Need to be imported for side effect
    from youtube_dl.YoutubeDL import YoutubeDL  # NOQA

    def write_conf(conf, location):
        f = open(location, 'w', encoding='utf-8')
        f.write(conf)
        f.close()

    def test(*args, **kwargs):
        parser, opts, _ = parseOpts(*args, **kwargs)
        assert opts.verbose == True
        assert opts.quiet == True
        assert opts.outtmpl == 'outtmpl'
        assert opts.writethumbnail == True
        assert opts.min_

# Generated at 2022-06-24 14:04:04.328847
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-h'])[1].help
    assert parseOpts(['--version'])[1].version
    assert parseOpts(['-u', 'user', '-p', 'pass', 'pl', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].username == 'user'
    assert parseOpts(['-u', 'user', '-p', 'pass', 'pl', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].password == 'pass'
    assert parseOpts(['-v'])[1].verbose



# Generated at 2022-06-24 14:04:08.562306
# Unit test for function parseOpts
def test_parseOpts():
    the_opts = {}
    the_args = []
    the_parser, the_opts, the_args = parseOpts(overrideArguments=['-UG'])
    assert the_args == []
    assert 'proxy' not in the_opts.__dict__ or the_opts.proxy == None
    assert the_opts.usenetrc == False
    assert the_opts.username == None
    assert the_opts.password == None

# Generated at 2022-06-24 14:04:12.358507
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.format == 'mp3'
    assert opts.extractaudio == True
    assert opts.audioformat == 'best'
    assert opts.nopostoverwrites == False
    assert args == ['https://www.youtube.com/watch?v=o93br_bWxKw']

# Set video format, resolution and other video related options

# Generated at 2022-06-24 14:04:15.459785
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts()



# Generated at 2022-06-24 14:04:23.709557
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = [sys.argv[0]] + ['-u', 'user','--password','pwd']
    parser, opts, args = parseOpts()

    assert opts.username == 'user'
    assert opts.password == 'pwd'

    sys.argv = [sys.argv[0]] + ['--username','user','--password','pwd']
    parser, opts, args = parseOpts()

    assert opts.username == 'user'
    assert opts.password == 'pwd'

if __name__ == '__main__':
    test_parseOpts()
    input("Press Enter to continue...")

# Generated at 2022-06-24 14:04:33.792623
# Unit test for function parseOpts
def test_parseOpts():

    # YouTube
    url = "https://m.youtube.com/watch?v=JtiHY4ixeLE"
    parser, opts, args = parseOpts(["-v", url])
    assert args == [url]
    assert opts.verbose

    # Youtube age restricted
    url = "https://www.youtube.com/watch?v=8WbUCiYv5Es"
    parser, opts, args = parseOpts(["-v", url])
    assert args == [url]
    assert opts.verbose

    # Copyrighted video
    url = "https://www.youtube.com/watch?v=HEXWRTEbj1I"
    parser, opts, args = parseOpts(["-v", url])
    assert args == [url]
    assert opts.verbose

   

# Generated at 2022-06-24 14:04:34.666376
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass


# Generated at 2022-06-24 14:04:36.882817
# Unit test for function parseOpts
def test_parseOpts():
    def test_parseOpts(self):
        # TODO add tests
        pass
# unit test for class YoutubeDL

# Generated at 2022-06-24 14:04:45.909529
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-F'])
    assert parseOpts(['--all-formats'])
    assert parseOpts(['-f', '137'])
    assert parseOpts(['--format', '137'])
    assert parseOpts(['--format', '+bestaudio[ext=m4a]'])
    assert parseOpts(['--format', '22/18/137'])
    assert parseOpts(['--playlist-reverse'])
    assert parseOpts(['--playlist-start', '5'])
    assert parseOpts(['--playlist-end', '10'])


# Entry point

# Generated at 2022-06-24 14:04:56.789887
# Unit test for function parseOpts

# Generated at 2022-06-24 14:05:07.556774
# Unit test for function parseOpts
def test_parseOpts():
    def _test(args, result):
        parser, opts, _args = parseOpts(args)
        assert opts == result

# Generated at 2022-06-24 14:05:12.650135
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import subprocess
    sys.argv = ['youtube-dl']
    result = parseOpts()
    if result == 0:
        subprocess.call(['python', 'test_parseOpts.py'])
test_parseOpts()
# #############################################################
# ### Main                                                  ###
# #############################################################



# Generated at 2022-06-24 14:05:18.862229
# Unit test for function parseOpts
def test_parseOpts():
    from .common import args_urls_size

    def _test(args):
        parser, opts, args = parseOpts(args)
        assert opts.usenetrc is False
        assert opts.username == 'username'
        assert opts.password == 'password'
        assert opts.videopassword == 'videopasword'
        assert opts.ap_mso == 'ap_mso'
        assert opts.ap_username == 'ap_username'
        assert opts.ap_password == 'ap_password'
        assert opts.vidoe_password == 'video_password'
        assert opts.ap_mso_id == 'ap_mso_id'
        assert opts.batchfile == 'batchfile'
        assert opts.outtmpl == 'outtmp1'

# Generated at 2022-06-24 14:05:27.884044
# Unit test for function parseOpts
def test_parseOpts():
    # Unit test for function _parseOpts
    def _test_parseOpts_helper(args, should_be):
        # Check if the same options is given in args
        # and should_be
        opts = parseOpts(args.split(' '))[1]
        for attr in should_be:
            assert(getattr(opts, attr) == should_be[attr])

    _test_parseOpts_helper('--min-sleep-interval 1 --max-sleep-interval 3',
                           {'min_sleep_interval': 1, 'max_sleep_interval': 3})
    _test_parseOpts_helper('--min-filesize 1K --max-filesize 2k',
                           {'min_filesize': 1024, 'max_filesize': 2048})
    _

# Generated at 2022-06-24 14:05:38.620124
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-u', 'user','-p', '123456', '--', 'foo', 'bar'])
    assert opts.username == 'user'
    assert opts.password == '123456'
    assert args == ['foo', 'bar']

    parser, opts, args = parseOpts(['-4', '--', 'foo', 'bar'])
    assert opts.player_continuous_http_streaming == True
    assert args == ['foo', 'bar']

    parser, opts, args = parseOpts(['--', 'foo', 'bar'])
    assert opts.player_continuous_http_streaming == False
    assert args == ['foo', 'bar']


# Generated at 2022-06-24 14:05:48.350839
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-u', 'user', '-p', 'pass', '-F', '22', 'http://w.org/23.flv'])
    assert '22' == opts.format
    assert ['http://w.org/23.flv'] == args
    assert 'user' == opts.username
    assert 'pass' == opts.password
    assert opts.forcetitle is None
    assert not opts.simulate
    assert opts.quiet
    assert opts.verbose is None
    assert not opts.geturl
    assert not opts.gettitle
    assert not opts.getthumb
    assert not opts.getdescription
    assert not opts.getfilename
    assert not opts.get_format_limit

# Generated at 2022-06-24 14:05:56.472245
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove, devnull


# Generated at 2022-06-24 14:05:59.976182
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info >= (2, 7):
        import argparse
        parser = argparse.ArgumentParser()
        parser, opts, args = parseOpts(parser)
        assert parser
        assert opts
        assert args
# Unit test function

# Generated at 2022-06-24 14:06:07.147995
# Unit test for function parseOpts
def test_parseOpts():
    def test_parse(args, expect_msg=None, errors_expected=False,
                   expect_warning=None, warning_expected=False,
                   overrideConfig=None):
        from youtube_dl.utils import walk_search_path
        import youtube_dl.extractor.common

        def get_fpath(module_name, fname):
            dirs = []
            dirs.extend(os.path.dirname(os.path.abspath(__file__)))
            dirs.extend(os.path.dirname(os.path.abspath(sys.argv[0])))
            dirs.extend(os.path.expanduser('~'))
            dirs.extend(walk_search_path())
            dirs.extend(['.', ''])

# Generated at 2022-06-24 14:06:13.700770
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-q', '--no-warnings', '--', 'foo']) == (['-q', '--no-warnings', '--', 'foo'], False)
    assert parseOpts(['--dump-user-agent']) == (['--dump-user-agent'], True)
    assert parseOpts(['-U', 'foobar']) == (['-U', 'foobar'], False)
    assert parseOpts(['-u', 'foobar']) == (['-u', 'foobar'], False)
    assert parseOpts(['-p', 'foobar']) == (['-p', 'foobar'], False)

# Inspired from https://github.com/RG3/youtube-dl/issues/5992#issuecomment-143541699

# Generated at 2022-06-24 14:06:21.293623
# Unit test for function parseOpts
def test_parseOpts():
    from os.path import dirname
    from xml.dom.minidom import parseString
    import sys
    from youtube_dl.utils import encodeArgument

    sys.argv = [sys.argv[0]]

    def assert_raises_and_contains(exc, pattern):
        def check(f, *args, **kwargs):
            try:
                f(*args, **kwargs)
                assert False, '%s(%s, %s) did not raise %s' % (
                    f.__name__, args, kwargs, exc)
            except exc as e:
                assert pattern in str(e), (
                    '%s(%s, %s) raised %s which did not contain %s' % (
                        f.__name__, args, kwargs, e, pattern))
        return check

# Generated at 2022-06-24 14:06:23.143285
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
# End

# Downloading functions


# Generated at 2022-06-24 14:06:31.428502
# Unit test for function parseOpts
def test_parseOpts():
    argv_0 = sys.argv[0]
    sys.argv[0] = 'youtube-dl'

    args = ['https://www.youtube.com/watch?v=1234']
    # no config, no argument
    parser, opts, args = parseOpts(args)
    assert opts.format == 'best'
    assert opts.verbose == False
    assert opts.quiet == False
    assert args == ['https://www.youtube.com/watch?v=1234']

    # no config, with argument
    args = ['https://www.youtube.com/watch?v=1234', '-v']
    parser, opts, args = parseOpts(args)
    assert opts.format == 'best'
    assert opts.verbose == True
    assert opts.quiet == False

# Generated at 2022-06-24 14:06:37.341483
# Unit test for function parseOpts
def test_parseOpts():
    import unittest
    class TestParseOpts(unittest.TestCase):
        def test_parseOpts(self):
            pass
    try:
        optparse  # Since optparse is deprecated, it will be removed in the future
    except NameError:
        unittest.main(argv=[sys.argv[0], 'TestCase'])
    else:
        print('WARNING: optparse is deprecated. youtube-dl\'s tests may not work with optparse')

# vim: expandtab:sw=4:ts=4

# Generated at 2022-06-24 14:06:49.248574
# Unit test for function parseOpts
def test_parseOpts():
    # Test for function parseOpts.
    # Part of Youtube-DL test suite

    # TODO: Add unittest for reading and parsing config files

    from tempfile import mkstemp
    from time import time
    from os import remove
    from os.path import isfile
    from shutil import rmtree
    from difflib import ndiff
    from sys import argv as _argv

    from .__main__ import readOptions
    from .utils import determine_ext
    from .postprocessor import aac2mp3PP, ffmpegPostProcessor

    f_out, outfile = mkstemp(prefix = 'youtube-dl_test_out_')
    f_in, infile = mkstemp(prefix = 'youtube-dl_test_in_')


# Generated at 2022-06-24 14:07:00.497985
# Unit test for function parseOpts
def test_parseOpts():
    import mock

    def run(args):
        parser, opts, _args = parseOpts(args)
        return dict((o.dest, getattr(opts, o.dest)) for o in parser.option_list)

    def compat_shlex_quote(astr):
        if sys.version_info < (3,):
            return pipes.quote(astr)
        return shlex.quote(astr)

    assert run(['--version']) == {'version': True}
    assert run(['--no-version']) == {'version': False}
    assert run(['--ignore-config']) == {'ignore_config': True}
    assert run(['--config-location=/tmp/does not exist'])

# Generated at 2022-06-24 14:07:08.610387
# Unit test for function parseOpts
def test_parseOpts():
    testargs = ['-U', 'Safari/537.36',
                '--ignore-config',
                'rtmp://stream.example.org/tv/tv1',
                '--max-downloads', '10',
                '--buffer-size', '8192',
                '--no-part',
                '-c',
                'https://youtube.example.com/watch?v=BaW_jenozKc',
                '--',
                '--playlist-reverse',
                '--xattr-set-filesize',
                'https://youtube.example.com/watch?v=UnWfIS8jKLw',
                '-v']

# Generated at 2022-06-24 14:07:09.728511
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass


# Generated at 2022-06-24 14:07:11.955396
# Unit test for function parseOpts
def test_parseOpts():
    opts = _parseOpts([])
    assert opts != ([], [])

# Generated at 2022-06-24 14:07:22.643867
# Unit test for function parseOpts
def test_parseOpts():
    # noinspection PyUnusedLocal
    def testOpts(argv, expected):
        parser, opts, args = parseOpts(argv)
        test.assertEqual(args, [])
        for k, v in expected.items():
            if hasattr(opts, k):
                opt_value = getattr(opts, k)
                if isinstance(opt_value, (bytes_types, int)):
                    test.assertEqual(opt_value, v)
                else:
                    test.assertEqual(opt_value, compat_str(v))
            else:
                test.assertTrue(getattr(parser.defaults, k) == v)

    testOpts([], {})

    testOpts(['-h'], {'help': True})

# Generated at 2022-06-24 14:07:24.638878
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)

# Generated at 2022-06-24 14:07:35.833392
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--username', 'asd', '--', 'qwe'])
    assert opts.ignoreerrors is True
    assert opts.verbose is True
    assert opts.username == 'asd'
    assert args == ['qwe']
    parser, opts, args = parseOpts(['-i', '--', '-v'])
    assert opts.ignoreerrors is True
    assert opts.verbose is False
    assert args == ['-v']
    parser, opts, args = parseOpts(['-v', '--no-warnings', '--', '-i'])
    assert opts.ignoreerrors is False
    assert opts.verbose is True
    assert opts.no_warnings is True
    assert args

# Generated at 2022-06-24 14:07:37.621774
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts())
#test_parseOpts()
# Function: _handle_args

# Generated at 2022-06-24 14:07:47.111213
# Unit test for function parseOpts
def test_parseOpts():
    def _options(args):
        opts = [a for a in args if a.startswith('--')]
        return ' '.join(opts)


# Generated at 2022-06-24 14:07:58.840145
# Unit test for function parseOpts
def test_parseOpts():
    def check_opts_equals(opts1, opts2):
        for key, val in opts1.__dict__.items():
            if key not in ['ignoreerrors', 'retries', 'skip_unavailable_fragments', 'nooverwrites', 'fragment_retries', 'continuedl', 'noprogress', 'ratelimit']:
                assert val == opts2.__dict__[key]
            elif key in ['ignoreerrors', 'retries']:
                assert ((val == opts2.__dict__[key]) == (val == -1))
            elif key in ['fragment_retries', 'continuedl']:
                assert ((val == opts2.__dict__[key]) == (val == 10))

# Generated at 2022-06-24 14:08:10.200787
# Unit test for function parseOpts
def test_parseOpts():
    import sys

    sys.argv = [
        'youtube-dl',
        'http://youtube.com/watch?v=BaW_jenozKc',
        '-u', 'user', '-p', 'pass',
        '--no-check-certificate', '--socket-timeout', '60']
    parser, opts, args = parseOpts()
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.nocheckcertificate
    assert opts.socket_timeout == 60

    sys.argv = ['youtube-dl',
        'http://youtube.com/watch?v=BaW_jenozKc',
        'http://youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts()

# Generated at 2022-06-24 14:08:13.909708
# Unit test for function parseOpts
def test_parseOpts():
    opts, _args = parseOpts(
        ['--usenetrc', '--username', 'foo', '--password', 'bar', '--ignore-config'])
    assert not opts.usenetrc
    assert opts.username == 'foo'
    assert opts.password == 'bar'



# Generated at 2022-06-24 14:08:14.508395
# Unit test for function parseOpts
def test_parseOpts():
    pass



# Generated at 2022-06-24 14:08:21.911178
# Unit test for function parseOpts
def test_parseOpts(): # pylint: disable=unused-variable
    from sys import argv

    def _test(args, expected):
        def _match(a, b):
            if isinstance(a, tuple):
                a = list(a)
            if isinstance(b, tuple):
                b = list(b)
            return a == b

        parser, opts, args = parseOpts(args)

        assert parser is not None
        assert opts is not None
        assert args is not None


# Generated at 2022-06-24 14:08:24.244938
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print(opts)
    print(opts.proxy)
# test_parseOpts()

# Generated at 2022-06-24 14:08:25.384813
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass



# Generated at 2022-06-24 14:08:33.785073
# Unit test for function parseOpts
def test_parseOpts():
    from unittest import TestCase
    from tempfile import mkstemp
    from os import write, close, remove, path
    #from subprocess import call

    class ParseOptsTest(TestCase):

        @staticmethod
        def create_conf_file(filename, opts, args):
            fd, conf_location = mkstemp()
            cmd_line = [arg.decode('utf-8') if sys.version_info < (3,) and isinstance(arg, str) else arg
                        for arg in sys.argv
                        # skip current script name
                        if arg != sys.argv[0]]
            cmd_line.extend(('--config-location', conf_location))
            #call([sys.executable] + cmd_line)

            assert path.exists(conf_location)

# Generated at 2022-06-24 14:08:44.372398
# Unit test for function parseOpts
def test_parseOpts():
    # Test default options
    opts = parseOpts(['-i'])[1]
    assert opts.usenetrc is True
    assert opts.username is None
    assert opts.password is None
    assert opts.videopassword is None

    # Test login info in arguments
    opts = parseOpts(['--username', 'foo', '--password', 'bar',
                      '--video-password', 'foobar', '-i'])[1]
    assert opts.usenetrc is True
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.videopassword == 'foobar'

    # Test login info in netrc

# Generated at 2022-06-24 14:08:51.670261
# Unit test for function parseOpts
def test_parseOpts():
    p, o, a = parseOpts(['-v', '--extract-audio', '--audio-format=mp3',
                         '--audio-quality=0', '-o', 'myv%(autonumber)s.%(ext)s'])
    assert o.verbose is True
    assert o.extractaudio is True
    assert o.audioformat == 'mp3'
    assert o.audioquality == '0'
    assert o.outtmpl == 'myv%(autonumber)s.%(ext)s'

    p, o, a = parseOpts(['-x', '--audio-format=vorbis', '--audio-quality=9',
                         '-o', 'myv%(autonumber)s.%(ext)s'])
    assert o.verbose is False
   

# Generated at 2022-06-24 14:08:55.861276
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    parser, opts, args = parseOpts()
    if opts.verbose:
        write_string("[debug] EOF marker: " + marker() + "\n")
        write_string("[debug] unit test: " + argv[0] + "\n")
        write_string("[debug] opts: " + str(opts) + "\n")
        write_string("[debug] args: " + str(args) + "\n")
# Unit test: Handle --get-url

# Generated at 2022-06-24 14:09:03.645512
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    from subprocess import Popen, PIPE, STDOUT
    from random import random


# Generated at 2022-06-24 14:09:04.941121
# Unit test for function parseOpts
def test_parseOpts():
    import warnings

# Generated at 2022-06-24 14:09:12.461499
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--username=test', '--password=test', 'plFormatString='])
    assert opts.username == 'test'
    assert opts.password == 'test'
    opts.password = 'test2'
    assert opts.password == 'test2'
    assert opts.plFormatString == ''

    parser, opts, args = parseOpts(['--username=test', '--password=test', '--video-password=test', 'plFormatString='])
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.video_password == 'test'


# Generated at 2022-06-24 14:09:18.426530
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.FileDownloader import FileDownloader
    # Unit test for function parseOpts, it tests the parameters values that are set
    # in the following function call.
    parser, opts, args = parseOpts(['--proxy=some-proxy', '--playlist-reverse', 'some-url'])
    ydl = YoutubeDL(opts)
    fd = FileDownloader(ydl, {})
    assert ydl.params.get('proxy') == 'some-proxy'
    assert ydl.params.get('playliststart') == -1
    assert fd.params.get('playlist_reverse') is True
# TODO: Test for function .format_resolution()
# TODO: Test for function .prepare_filename()



# Generated at 2022-06-24 14:09:28.925067
# Unit test for function parseOpts
def test_parseOpts():
    def _init_opts_and_fake_args(argv):
        opts = parseOpts(argv)[1]
        args = [fake_args[0]] + [url for url in fake_args[1:]
                                 if not url.startswith('-')]
        return opts, args

    # Setting up fake args

# Generated at 2022-06-24 14:09:40.127440
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["-v", "--extract-audio", "--audio-format", "mp3",
                                    "--no-check-certificate", "--proxy", "8.8.4.4",
                                    "https://www.youtube.com/watch?v=BaW_jenozKc&t=1m1s",
                                    "https://soundcloud.com/thastrom/sets/trippin-on-skrillex-dubstep-mix-march-2011"])
    assert not opts.nocheckcertificate
    assert opts.proxy == "8.8.4.4"
    assert opts.extractaudio
    assert opts.audioformat == "mp3"
    assert opts.verbose


# Generated at 2022-06-24 14:09:50.436486
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', '-u', 'user', '-p', 'passwd', '-u', '', '-u', 'user2'])
    assert opts.usenetrc
    assert opts.username == ['user', '', 'user2']
    assert opts.password == ['passwd', '']
    assert opts.external_downloader is None
    assert opts.external_downloader_args is None

    parser, opts, args = parseOpts(['--extract-audio', '--audio-format', 'mp3'])
    assert opts.extractaudio
    assert opts.audioformat == 'mp3'

    parser, opts, args = parseOpts(['--audio-format=mp3'])
    assert opts.extractaudio


# Generated at 2022-06-24 14:09:56.587913
# Unit test for function parseOpts
def test_parseOpts():
    opts, _ = parseOpts([])
    assert opts.usenetrc is False
    opts, _ = parseOpts(['--username', 'foo', '--password', 'bar'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    opts, _ = parseOpts(['--usenetrc'])
    assert opts.username is None
    assert opts.password is None
    assert opts.usenetrc is True
    del os.environ['HOME']
    opts, _ = parseOpts(['--usenetrc'])
    assert opts.usenetrc is False



# Generated at 2022-06-24 14:10:08.349269
# Unit test for function parseOpts
def test_parseOpts():
    def getopts(argstr):
        """Return a dictionary of parsed options."""
        parser, opts, _ = parseOpts(argstr.split())
        return vars(opts)

    assert getopts('--username test --password test') == {
        'username': 'test', 'password': 'test', 'verbose': False}

# Generated at 2022-06-24 14:10:17.501347
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    # Test: parseOpts
    # Expected:
    #     - opts.date = DateRange(None)
    #     - opts.username = 'username'
    #     - opts.verbose = True
    #     - opts.outtmpl = '%(title)s-%(id)s.%(ext)s'
    #     - opts.duration = 1200
    #     - opts.min_views = 100
    #     - opts.format = 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    #     - opts.geo_bypass = False
    #     - opts.geo_bypass_country = 'US'
    #     - opts

# Generated at 2022-06-24 14:10:25.892049
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username=foo', '--password', 'bar', '-f', '1/2/34', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.format == ['1/2/34']
    assert opts.ignoreerrors is True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-24 14:10:35.804456
# Unit test for function parseOpts
def test_parseOpts():
    # Default values
    parser, opts, args = parseOpts()
    assert opts.usenetrc
    assert opts.verbose == 0
    assert opts.quiet == False
    assert opts.simulate == True
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.forceduration == False
    assert opts.forcetitle == False
    assert opts.forceurl == False
    assert opts.forcedl == False
    assert opts.simulate == True
    assert opts.skip_download == False
    assert opts.format == None