

# Generated at 2022-06-24 14:00:35.840386
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert(opts.username is None)
    assert(opts.password is None)
    assert(opts.usenetrc is False)
    assert(opts.quiet is False)
    assert(opts.verbose is False)
    assert(opts.no_warnings is False)
    assert(opts.simulate is False)
    assert(opts.skip_download is False)
    assert(opts.format == '')
    assert(opts.listformats is False)
    assert(opts.outtmpl is None)
    assert(opts.autonumber_size is None)
    assert(opts.autonumber_start == 1)
    assert(opts.restrictfilenames is False)

# Generated at 2022-06-24 14:00:45.456577
# Unit test for function parseOpts
def test_parseOpts():
    # Print command-line arguments
    def _print_args():
        write_string(repr(_hide_login_info(sys.argv)) + '\n')

    _print_args()

    # Initialize and run the downloader
    if sys.version_info < (3, 2):
        parser, opts, args = parseOpts()
    else:
        try:
            from contextlib import suppress
        except ImportError:
            from contextlib2 import suppress

        with suppress(SystemExit):
            parser, opts, args = parseOpts()  # Ignore parse errors

    return parser, opts, args



# Generated at 2022-06-24 14:00:57.621920
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert isinstance(parser, optparse.OptionParser)
    assert opts.verbose == False
    assert opts.username == ''
    assert opts.password == ''
    assert opts.quiet == False
    assert opts.no_warnings == True
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None

# Generated at 2022-06-24 14:01:09.057371
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    parser, opts, args = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose is False
    assert opts.outtmpl == '%(id)s.%(ext)s'
    assert opts.usenetrc is False
    assert opts.age_limit is None
    assert opts.download_archive == encodeArgument('%(id)s.%(ext)s.download_archive')
    assert opts.ignoreerrors is False
    assert opts.forcefilename is False
    assert opts.forcetitle is False
    assert opts.format == None
    assert opts.listformats is False
   

# Generated at 2022-06-24 14:01:19.622730
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    with tempfile.NamedTemporaryFile() as conf:
        conf.write(encodeArgument('--extract-audio'))
        conf.write(encodeArgument('--audio-format mp3'))
        conf.write(encodeArgument('--audio-quality 0'))
        conf.write(encodeArgument('--output "%(title)s.%(ext)s"'))
        conf.flush()
        _, opts, _ = parseOpts(['-x', '-o', '%(id)s.%(ext)s', '--config-location', conf.name, 'foo'])
        assert opts.extractaudio
        assert opts.audioformat == 'mp3'
        assert opts.audioquality == '0'
        assert opt

# Generated at 2022-06-24 14:01:24.258245
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import mkstemp
    from os import close, unlink

    def write_argv(args):
        fd, filename = mkstemp()
        fobj = open(fd, 'w')
        fobj.write('\n'.join(args))
        fobj.close()
        return filename

    def read_config(filename):
        fobj = open(filename)
        args = [l.strip() for l in fobj.readlines()]
        fobj.close()
        return args

    p = lambda *args: (a for a in args)

    argv = ['progname']
    parser, opts, args = parseOpts()
    assert parser
    assert not args
    assert not opts

    argv = ['progname', '-h']
   

# Generated at 2022-06-24 14:01:28.897145
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(
        ['--username', 'user', '--password', 'pass', '--dump-user-agent', '--format', 'best'])[
            1:] == (
                AttributeDict({
                    'username': 'user', 'password': 'pass',
                    'dump_user_agent': True, 'format': 'best'
                }), [])



# Generated at 2022-06-24 14:01:38.192427
# Unit test for function parseOpts

# Generated at 2022-06-24 14:01:44.432645
# Unit test for function parseOpts
def test_parseOpts():
    '''
    Unit test for function parseOpts
    '''
    parser, opts, args = parseOpts()
    assert opts.help is None
    assert args == None
# Test parseOpts
if __name__ == "__main__":
    test_parseOpts()
    print("Unit tests pass")
else:
    parser, opts, args = parseOpts(overrideArguments=['-b'])
    # The actual unit tests are run from __main__
    from . import update
    from .utils import date_from_str
    from .extractor import gen_extractors
    from .compat import compat_str



# Generated at 2022-06-24 14:01:51.019946
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-xu','http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == True
    assert len(args) == 1
    parser, opts, args = parseOpts(None)
    assert len(args) == 0


# Generated at 2022-06-24 14:02:00.050361
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import urlopen

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        _VALID_URL = r'(?i)(?:https?://)?(?:www\.)?dummy'
        _TEST = {
            'url': 'http://www.dummy.com/video.html',
            'info_dict': {
                'id': '1337',
                'ext': 'mp4',
                'title': 'Dummy video',
                'description': 'This is a dummy video',
            },
        }


# Generated at 2022-06-24 14:02:06.681738
# Unit test for function parseOpts

# Generated at 2022-06-24 14:02:07.545288
# Unit test for function parseOpts
def test_parseOpts():
    _run_all_tests(parseOpts)


# Generated at 2022-06-24 14:02:12.872269
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-o', 'test.mp4'])
    assert opts.outtmpl == 'test.mp4' and not args

    parser, opts, args = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert not opts.outtmpl and args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

    # TODO: add more tests



# Generated at 2022-06-24 14:02:23.104807
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.username is None

    parser, opts, args = parseOpts(['-u', 'user', '-p', 'pwd'])
    assert opts.username == 'user'
    assert opts.password == 'pwd'

    parser, opts, args = parseOpts(['-4'])
    assert opts.prefer_ipv4 is True

    parser, opts, args = parseOpts(['--prefer-insecure'])
    assert opts.prefer_insecure is True

    parser, opts, args = parseOpts(['--default-search', 'ytsearch5'])
    assert opts.default_search == 'ytsearch5'


# Generated at 2022-06-24 14:02:26.297089
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    overwriteArguments = ['--username','test','--password','test2','--format=best']
    _, opts, _ = parseOpts(overwriteArguments)
    assert opts.username == 'test'
    assert opts.password == 'test2'
    assert opts.format == 'best'


# Generated at 2022-06-24 14:02:29.571872
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    myargs = [argv[0], '--playlist-start=2', '--playlist-end=5']
    o, a = parseOpts(myargs)

    assert o.playliststart == 2
    assert o.playlistend == 5
    assert o.usetitle == False
    assert o.quiet == False



# Generated at 2022-06-24 14:02:31.160267
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

# Generated at 2022-06-24 14:02:36.337972
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(
        ['--proxy=http://localhost:3128', 'https://youtube.com/watch?v=BaW_jenozKc'])
    assert opts.proxy == 'http://localhost:3128'
    assert args == ['https://youtube.com/watch?v=BaW_jenozKc']



# Generated at 2022-06-24 14:02:46.571424
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import chmod, remove
    from os.path import isfile, join
    fd, fpath = tempfile.mkstemp()
    expected_read_data = b"--ignore-config\n-f best -o %(title)s.%(ext)s"

# Generated at 2022-06-24 14:02:57.745441
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import TemporaryFile
    from os import linesep
    from os.path import basename
    from shutil import rmtree
    from copy import copy
    import youtube_dl

    tfd = TemporaryFile()
    sysargs = ['youtube-dl'] + argv[1:]
    tfd.write(bytes(' '.join(sysargs), 'utf-8'))
    tfd.seek(0)

    parser, opts, args = parseOpts(argv[1:])

    assert opts.simulate
    assert opts.verbose
    assert opts.ignoreerrors
    assert opts.dump_intermediate_pages
    assert opts.writeinfojson
    assert opts.writeannotations
    assert opts.ratelimit == '100k'
    assert opts.retries

# Generated at 2022-06-24 14:03:01.866463
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = _parseOpts(['-o', 'out.%(ext)s', 'http://www.youtube.com/foo#bar'])
    assert opts.outtmpl == 'out.%(ext)s'
    assert args == ['http://www.youtube.com/foo#bar']

# Generated at 2022-06-24 14:03:13.529851
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing parseOpts')

    import tempfile
    temp_conf = tempfile.NamedTemporaryFile(mode='w')
    temp_conf.write('-q --format=bestvideo+bestaudio')
    temp_conf.flush()

    parser, opts, args = parseOpts(['-f', '22', '--format', 'best', '--no-mtime', '--no-config', '--config-location', temp_conf.name])
    assert(opts.quiet == True)
    assert(opts.format == 'best')
    assert(opts.usenetrc == False)
    assert(opts.verbose == False)
    assert(opts.nooverwrites == False)
    assert(opts.ignoreconfig == True)
    assert(opts.simulate == False)

# Generated at 2022-06-24 14:03:23.665602
# Unit test for function parseOpts
def test_parseOpts():

    # test for function _match_entry
    def test_match_entry():
        # test for function _match_entry, base case
        def test_base_case():
            assert _match_entry(['http://www.example.com/1.mp4'], '1.mp4')
            assert _match_entry(['http://www.example.com/1.mp4'], '1.%(ext)s')

        # test for function _match_entry, base case: case insensitive
        def test_case_insensitive():
            assert _match_entry(['http://www.example.com/1.mp4'], '1.MP4')
            assert _match_entry(['http://www.example.com/1.mp4'], '1.%(ext)s')

        # test for function _match_entry,

# Generated at 2022-06-24 14:03:32.665802
# Unit test for function parseOpts
def test_parseOpts():
    def _test(args):
        parser, opts, args = parseOpts(overrideArguments=args)

    _test(['url'])
    _test(['-h'])
    _test(['--help'])
    _test(['-U', '"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22"'])
    _test(['-u', 'user', '-p', 'pass'])
    _test(['--username', 'user', '--password', 'pass'])
    _test(['--usenetrc'])
    _test(['--sleep-interval', '1'])

# Generated at 2022-06-24 14:03:39.389260
# Unit test for function parseOpts
def test_parseOpts():
    p = compat_expanduser('~')
    subprocess.check_call([sys.executable, '-m', 'youtube_dl.__main__',
                           '-U', '-o', p + '/%(autonumber)s-%(title)s-%(id)s.%(ext)s',
                           'http://www.youtube.com/watch?v=BaW_jenozKc'])
    with open(p + '/1-youtube-dl_test_video.mp4') as f:
        assert f.readline() == 'test line\r\n'


# Generated at 2022-06-24 14:03:41.191345
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

# Generated at 2022-06-24 14:03:51.011326
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info[0] == 2:
        reload(sys)
        sys.setdefaultencoding('UTF8')
    try:
        from youtube_dl.update import update_self
    except ImportError:
        # Python 2
        from update import update_self

    # Test for update
    for param in ['-U', '--update']:
        parser, opts, args = parseOpts([param])
        assert opts.update_self == True
        assert args == []
    for param in ['-u', '--username']:
        parser, opts, args = parseOpts([param, 'test', 'url'])
        assert opts.username == 'test'
        assert args == ['url']
    for param in ['-p', '--password']:
        parser, opts, args = parseOpts

# Generated at 2022-06-24 14:03:55.893060
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    old_stdout = sys.stdout
    sys.stdout = StringIO()
    try:
        parser, opts, args = parseOpts(['-h'])
    finally:
        sys.stdout = old_stdout
    assert 'youtube-dl' in sys.stdout.getvalue()


# Generated at 2022-06-24 14:04:05.068725
# Unit test for function parseOpts
def test_parseOpts():
    options = [
        '-v',
        '--output=%(title)s.%(ext)s',
        '--no-check-certificate',
        '--output=%(title)s.%(ext)s',
        '--format=18',
        '--no-playlist',
        '--ffmpeg-location=/bin',
        '--convert-subs=srt',
        '--embed-subs',
        '--write-thumbnail',
        '--write-info',
        '--write-description',
        '--write-annotations',
        '--list-thumbnails',
        '--ignore-config'
    ]
    _, opts, args = parseOpts(options)
    assert opts.verbose
    assert not opts.playliststart
    assert not opts

# Generated at 2022-06-24 14:04:13.269033
# Unit test for function parseOpts
def test_parseOpts():
    def _compare(opts1, opts2):
        if not opts1:
            if not opts2:
                return True
            return False

        if not opts2:
            if not opts1:
                return True
            return False

        if isinstance(opts1, list):
            opts1 = opts1[:]
        if isinstance(opts2, list):
            opts2 = opts2[:]

        for opt in opts2:
            if opt not in opts1:
                return False
            opts1.pop(opts1.index(opt))
        if opts1:
            return False
        return True

    parser, opts, args = parseOpts()
    opts = vars(opts)

# Generated at 2022-06-24 14:04:24.573696
# Unit test for function parseOpts
def test_parseOpts():
    from . import YoutubeDL
    from .utils import DateRange
    ydl = YoutubeDL()
    parser, opts, args = parseOpts(ydl, None)
    assert opts.usenetrc == False
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forcetitle == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats

# Generated at 2022-06-24 14:04:34.636855
# Unit test for function parseOpts
def test_parseOpts():
    def check(args, expected):
        parser, actual, _ = parseOpts(args)
        assert actual == expected

    # Test various field names with different separators
    check(['-o', '%(uploader)s/%(uploader_id)s/%(title)s-%(id)s.%(ext)s'],
          {'outtmpl': u'%(uploader)s/%(uploader_id)s/%(title)s-%(id)s.%(ext)s'})

# Generated at 2022-06-24 14:04:46.011089
# Unit test for function parseOpts
def test_parseOpts():
    opts = {}
    args = []
    assert parseOpts(opts, args) == (opts, args)
    assert parseOpts(opts, args, ['--no-playlist']) == (opts, args)
    assert parseOpts(opts, args, ['--max-downloads', '1']) == (opts, args)

    opts = {}
    args = ['url1', 'url2']
    assert parseOpts(opts, args) == (opts, ['url1', 'url2'])
    assert parseOpts(opts, args, ['--no-playlist']) == (opts, ['url1', 'url2'])

# Generated at 2022-06-24 14:04:49.810835
# Unit test for function parseOpts
def test_parseOpts():
    if __name__ != "__main__":
        pytest.skip("Can only be unit tested when run directly")
    assert parseOpts()[0].get_prog_name() == 'youtube-dl'



# Generated at 2022-06-24 14:04:59.289981
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([
        '-i', '--no-progress',
        '--dump-pages', '--write-description',
        '--write-info-json', '--all-subs',
        '--list-thumbnails', '--username', 'bob',
        '-p', 'hello',
        'https://www.youtube.com/watch?v=_ywHV-h8ys0',
        '-f', 'best[height<=?1080]/best[ext=mp4]/best',
        '--output', '%(id)s.%(ext)s'
    ])
    assert opts.simulate
    assert opts.dump_pages
    assert opts.write_description
    assert opts.writeinfojson
    assert opts.allsubtitles

# Generated at 2022-06-24 14:05:08.824720
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info < (2, 7):
        raise unittest.SkipTest('Skipped because of bugs in OptParse under Python 2.6')

    parser, opts, args = parseOpts()

    # --help
    with temp_filename() as h:
        opts.help = h
        with open(h, 'w') as f:
            parser.parse_args(['--help'], f)

    # --version
    with temp_filename() as v:
        opts.version = v
        with open(v, 'w') as f:
            parser.parse_args(['--version'], f)

    # -U, --update
    opts.update = False
    parser.parse_args(['-U'])
    opts.update = False

# Generated at 2022-06-24 14:05:19.094674
# Unit test for function parseOpts
def test_parseOpts():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import tempfile
    from StringIO import StringIO
    from youtube_dl.compat import str, bytes

    parser, opts, args = parseOpts(['--username', 'foo', '--password', 'bar', 'a', 'b', 'c'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['a', 'b', 'c']

    # No config files when --ignore-config is present
    parser, opts, args = parseOpts(['--ignore-config', 'a', 'b', 'c'])
    assert opts.ignoreconfig is True
    assert args == ['a', 'b', 'c']

    parser, opts, args

# Generated at 2022-06-24 14:05:21.583560
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: Write a real unit test
    parser, opts, args = parseOpts()
    assert opts is not None
# End unit test



# Generated at 2022-06-24 14:05:29.941694
# Unit test for function parseOpts
def test_parseOpts():
    def test_opt_in(args, opt):
        parser, opts, args = parseOpts(args.split(' '))
        assert hasattr(opts, opt) and getattr(opts, opt) == True
    def test_opt_not_in(args, opt):
        parser, opts, args = parseOpts(args.split(' '))
        assert not hasattr(opts, opt)
    def test_opt_eq_to(args, opt, value):
        parser, opts, args = parseOpts(args.split(' '))
        assert hasattr(opts, opt) and getattr(opts, opt) == value

    # Test default values

# Generated at 2022-06-24 14:05:38.047615
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose', '--get-title', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password is None
    assert opts.verbose
    assert not opts.quiet

# test_parseOpts()


# Since we are making youtube-dl a self-contained program instead of a library
# we must take care of setting the logging level ourselves.

# Generated at 2022-06-24 14:05:47.976359
# Unit test for function parseOpts
def test_parseOpts():
    # Dummy sys.argv
    argv = ['--verbose', '--retries', '100']
    # Create known global options
    globalknown = {}
    # Create known downloader options
    downloaderknown = {}
    # Create parser and parse
    parser, opts, args = parseOpts(argv, globalknown, downloaderknown)
    # Assert verbose option was correctly parsed
    assert opts.verbose
    # Assert retries option was correctly parsed
    assert opts.retries == 100
    # Assert help flag was correctly parsed
    assert opts.help == False
    # Assert parsers usage message is correct
    assert parser.usage == 'youtube-dl [OPTIONS] URL [URL...]'
# Test case description
test_parseOpts.description = 'Test parseOpts function'

#

# Generated at 2022-06-24 14:05:54.760734
# Unit test for function parseOpts
def test_parseOpts():
    class Args(object):
        pass
    args = Args()
    args.username = None
    args.password = None
    args.videopassword = None
    args.ap_mso = None
    args.ap_username = None
    args.ap_password = None

    # Test with override arguments
    overrideArguments = ['--username=testuser', '--password=testpass', '--videopassword=foobar', '--ap-mso=dummymso', '--ap-username=testapuser', '--ap-password=testappass', 'http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(overrideArguments)
    assert args.username == 'testuser', "Failed test 1a"
   

# Generated at 2022-06-24 14:06:02.849716
# Unit test for function parseOpts
def test_parseOpts():
    # Test concatenation of user and system config
    with InTemporaryDirectory():
        with open('youtube-dl.conf', 'w') as f:
            f.write('--ignore-config\n')
        with open(expand_path('~/.config/youtube-dl/config'), 'w') as f:
            f.write('--no-check-certificate\n')
        parser, opts, args = parseOpts([])
        assert opts.nocheckcertificate

    # Test overriding of user config
    with InTemporaryDirectory():
        with open('youtube-dl.conf', 'w') as f:
            f.write('--ignore-config\n')

# Generated at 2022-06-24 14:06:09.042665
# Unit test for function parseOpts
def test_parseOpts():
    # Test different argument types

    # Test argument type: Empty
    parser, opts, args = parseOpts([])

    # Test argument type: single argument
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose is True

    # Test argument type: 2 arguments
    parser, opts, args = parseOpts(['-v', '-c'])
    assert opts.verbose is True
    assert opts.continue_dl is True

    # Test argument type: 3 arguments
    parser, opts, args = parseOpts(['-v', '-c', '-g'])
    assert opts.verbose is True
    assert opts.continue_dl is True
    assert opts.geturl is True

    # Test argument type: 4 arguments
    parser, opts,

# Generated at 2022-06-24 14:06:18.707722
# Unit test for function parseOpts
def test_parseOpts():
  opts, args = parseOpts([])
  assert opts.noplaylist is False
  assert opts.usenetrc is False
  assert opts.simulate is False
  assert opts.quiet is False
  assert opts.no_warnings is False
  assert opts.dump_user_agent is False
  assert opts.list_extractors is False
  assert opts.default_search is 'auto'
  assert opts.ignore_errors is False
  assert opts.forceurl is False
  assert opts.forcethumbnail is False
  assert opts.forcetitle is False
  assert opts.forcedescription is False
  assert opts.forcefilename is False
  assert opts.forcejson is False
  assert opts.extract_flat is 'in_playlist'
  assert opt

# Generated at 2022-06-24 14:06:20.661358
# Unit test for function parseOpts
def test_parseOpts():
    print("test_parseOpts")
    parser, opts, args = parseOpts()

# Generated at 2022-06-24 14:06:25.417621
# Unit test for function parseOpts
def test_parseOpts():
    ut_opts = ['--no-check-certificate','--username','USER','--password','PASS','https://www.youtube.com/watch?v=BaW_jenozKc']
    _,opts,_ = parseOpts(overrideArguments=ut_opts)
    assert opts.username == 'USER'
    return True
test_parseOpts()


# Generated at 2022-06-24 14:06:30.092967
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.usenetrc

# Run unit test(s)
if __name__ == '__main__':
    import unittest
    import sys

    def main_func(func):
        def wrapper(*args, **kwargs):
            try:
                func(*args, **kwargs)
                return 0
            except:
                sys.stderr.write('Error in %s\n' % func.__name__)
                import traceback
                traceback.print_exc()
                return 1
        return wrapper


    class TestParseOpts(unittest.TestCase):
        def test_parseOpts(self):
            parser, opts, args = parseOpts(['-U'])

# Generated at 2022-06-24 14:06:38.557919
# Unit test for function parseOpts
def test_parseOpts():
    def doit(args):
        parser, opts, args = parseOpts(args)
        return opts.__dict__

    def assert_equal(first, second):
        if first != second:
            raise AssertionError('%r != %r' % (first, second))

    # Test max_filesize
    opts = doit('-Q --max-filesize 1M'.split())
    assert_equal(opts['format'], None)
    assert_equal(opts['nooverwrites'], False)
    assert_equal(opts['quiet'], False)
    opts = doit('-Q -f 37/22/18 --max-filesize 1k'.split())
    assert_equal(opts['format'], '37/22/18')

# Generated at 2022-06-24 14:06:50.193212
# Unit test for function parseOpts
def test_parseOpts():
    # Save a copy of sys.argv
    old_sys_argv = sys.argv
    # test_parseOpts/test_parseOpts.py --junitxml=TEST-test_parseOpts.xml
    # => options: ['--junitxml=TEST-test_parseOpts.xml'] and args: ['test_parseOpts/test_parseOpts.py']
    # NOTE: All of these lines come from the JUnit XML generator
    sys.argv = [
        '--junitxml=TEST-test_parseOpts.xml',
        'test_parseOpts/test_parseOpts.py'
    ]
    parser, opts, args = parseOpts()
    assert opts.junitxml == 'TEST-test_parseOpts.xml'

# Generated at 2022-06-24 14:06:51.614681
# Unit test for function parseOpts
def test_parseOpts():
    # simple smoke test
    parseOpts()


# Generated at 2022-06-24 14:06:53.346508
# Unit test for function parseOpts
def test_parseOpts():
    pass


# Generated at 2022-06-24 14:07:03.620129
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-i'])[0].get_usage() == _USAGE_STRING_SHORT
    assert parseOpts(['--help'])[0].get_usage() == _USAGE_STRING_LONG
    assert parseOpts(['--help-all'])[0].get_usage() == _USAGE_STRING_ALL

    assert parseOpts(['-U', 'user'])[1].username == 'user'
    assert parseOpts(['-P', 'pass'])[1].password == 'pass'
    assert parseOpts(['--username', 'user'])[1].usernamet == 'user'
    assert parseOpts(['--password', 'pass'])[1].password == 'pass'


# Generated at 2022-06-24 14:07:08.537529
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([
        '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc',
        '-v',
        '--playlist-reverse',
        '--flat-playlist',
    ])
    assert opts.geturl
    assert opts.verbose
    assert opts.playlist_reverse
    assert opts.flat_playlist


# Command-line parsing


# Generated at 2022-06-24 14:07:19.626006
# Unit test for function parseOpts
def test_parseOpts():
    from . import YoutubeDL
    from .extractor.youtube import YoutubeIE
    from .utils import encodeArgument
    from .version import __version__
    parser, opts, args = parseOpts(YoutubeDL)
    for opt in opts.__dict__:
        if opt in ('proxy', 'playliststart', 'playlistend', 'playlist_items', 'playlistreverse',
                   'restrictfilenames', 'writedescription', 'writeinfojson', 'writeannotations',
                   'writethumbnail', 'write_all_thumbnails', 'listthumbnails',
                   'prefer_insecure', 'nocheckcertificate'):
            assert opts.__dict__[opt] is False

# Generated at 2022-06-24 14:07:24.647618
# Unit test for function parseOpts
def test_parseOpts():
    def _do_test(args, expected_opts):
        parser, opts = parseOpts(args)
        assert vars(opts) == expected_opts

    _do_test([], {})
    _do_test([], {})

    # Empty arguments
    _do_test(['--playlist-reverse', '', '--proxy'], {
        'playlistreverse': True, 'proxy': ''})

    # Whitespace trimming
    _do_test(['--playlist-reverse', ' ', '--proxy', ' '], {
        'playlistreverse': True, 'proxy': ''})

    _do_test([], {})

    # Test --help
    _do_test(['--help', '--verbose'], {'verbose': True, 'help': True})

# Generated at 2022-06-24 14:07:31.260040
# Unit test for function parseOpts
def test_parseOpts():
    args = ['--format', '22/18/worst']
    info = parseOpts(args, overrideArguments=args)
    assert info[2] == ['--format', '22/18/worst']
    info = parseOpts(args, overrideArguments=['--format', '22/18/worst'])
    assert info[2] == ['--format', '22/18/worst']
# Method to get the options and arguments

# Generated at 2022-06-24 14:07:32.527045
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass


# Generated at 2022-06-24 14:07:42.269934
# Unit test for function parseOpts
def test_parseOpts():
    for overrideArguments in [None, ['--username', 'me', '--password', 'c0nf1d3nt1al']]:
        parser, opts, args = parseOpts(overrideArguments)
        if opts.verbose:
            write_string('[debug] Max Download: '
                + opts.ratelimit + '\n')
            write_string('[debug] Max Upload: ' + opts.nooverwrites + '\n')
            write_string('[debug] User Agent: '
                + opts.user_agent + '\n')
            write_string('[debug] Force ipv4: ' + opts.proxy + '\n')
            write_string('[debug] Geo Restriction: '
                + opts.geo_verification_proxy + '\n')




# Generated at 2022-06-24 14:07:50.674132
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['--username', 'foo', '--password', 'bar', '--verbose'])
    assert(opts.username == 'foo')
    assert(opts.password == 'bar')
    assert(opts.verbose)
    opts, args = parseOpts(['--verbose'])
    assert(opts.verbose)
    opts, args = parseOpts(['--extract_flat'])
    assert(opts.extract_flat)
    opts, args = parseOpts(['--print-traffic'])
    assert(opts.print_traffic)
    opts, args = parseOpts(['--sleep-interval', '1'])
    assert(opts.sleep_interval == 1)
    opts, args = parseOpts

# Generated at 2022-06-24 14:08:01.642830
# Unit test for function parseOpts

# Generated at 2022-06-24 14:08:12.978017
# Unit test for function parseOpts
def test_parseOpts():
    from nose.tools import *

    eq_('25', _parse_bytes('25'))
    eq_('25000', _parse_bytes('25k'))
    eq_('25000000', _parse_bytes('25m'))
    eq_('25000000000', _parse_bytes('25g'))
    assert_raises(ValueError, _parse_bytes, 'z')
    assert_raises(ValueError, _parse_bytes, '1z')
    assert_raises(ValueError, _parse_bytes, '1.5')

    class FakeSecHead(object):
        def __init__(self, fp):
            pass

        def readline(self):
            return ''

    eq_([], _readOptions('/nonexistentpath'))

# Generated at 2022-06-24 14:08:20.698994
# Unit test for function parseOpts
def test_parseOpts():
    # Test basic parsing
    def t(args, expected):
        parser, opts, _ = parseOpts(args)
        assert expected == vars(opts)


# Generated at 2022-06-24 14:08:30.828696
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts([])[1]

    assert not opts.usenetrc
    assert not opts.password
    assert opts.username == '-'
    assert not opts.verbose
    assert opts.quiet
    assert not opts.no_warnings
    assert opts.forceurl
    assert opts.forcetitle
    assert opts.forcedescription
    assert opts.forcefilename
    assert not opts.simulate
    assert not opts.skip_download
    assert not opts.format
    assert not opts.listformats
    assert not opts.outtmpl
    assert opts.ignoreerrors
    assert not opts.forcejson
    assert not opts.dump_intermediate_pages
    assert opts.writeinfojson
    assert not opts.writedescription


# Generated at 2022-06-24 14:08:42.079753
# Unit test for function parseOpts

# Generated at 2022-06-24 14:08:49.375273
# Unit test for function parseOpts
def test_parseOpts():
    '''
    Test the parseOpts function.
    '''
    test_args = [
        '--no-check-certificate', 'https://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(test_args)
    assert opts.nocheckcertificate and args[0] == test_args[1]

    test_args = [
        '-i', '--output=%(title)s-%(id)s.%(ext)s', '--autonumber-size=5',
        '--autonumber-start=0',
        'https://www.youtube.com/watch?v=BaW_jenozKc',
        'https://youtu.be/dQw4w9WgXcQ'
    ]

# Generated at 2022-06-24 14:08:53.323400
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--youtube-skip-dash-manifest'])
    assert opts.ignoreerrors is True
    assert opts.youtube_skip_dash_manifest is True

# Generated at 2022-06-24 14:09:01.341990
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

    # Check that the output template has been correctly processed
    if opts.usetitle:
        assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    if opts.autonumber:
        assert opts.outtmpl == '%(autonumber)s-%(title)s-%(id)s.%(ext)s'
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None


# Generated at 2022-06-24 14:09:08.635589
# Unit test for function parseOpts
def test_parseOpts():
    class MockParser(object):
        def add_option(*args):
            pass
        def add_option_group(*args):
            pass
        def parse_args(self, argv):
            return argv, []
    mp = MockParser()
    mp.add_option_group = mp
    opts = parseOpts(mp, ['--username=foo', '--password=bar'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'



# Generated at 2022-06-24 14:09:12.536145
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.usenetrc == True
    assert opts.username == 'username'
    assert opts.password == 'password'



# Generated at 2022-06-24 14:09:20.963949
# Unit test for function parseOpts
def test_parseOpts():
    """
    A function that tests the function parseOpts
    """
    
    # Test that the function parseOpts is able to parse the arguments that are in the file "test_parseOpts.txt"
    (p, opts, args) = parseOpts(["-f", "best", "--format", "best", "-c", "-g", "https://www.youtube.com/watch?v=pOtd1cbOP7k", "--get-url", "--get-title", "--get-id", "--get-thumbnail", "--get-description", "--get-duration", "--get-filename", "--get-format", "--no-progress", "-v", "--batch-file", "test_parseOpts.txt"])
    # Test that the attributes of the object opts are set to the values that were set

# Generated at 2022-06-24 14:09:29.143455
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    def get_opts(args):
        parser, opts, _ = parseOpts(overrideArguments=args)
        return parser, opts

    # -F
    parser, opts = get_opts(['-F'])
    assert opts.format == 'best'
    assert opts.list_formats == True

    # -f
    parser, opts = get_opts(['-f', '22/18'])
    assert opts.format == '22/18'

    # -f -
    parser, opts = get_opts(['-f', '-'])
    assert opts.format == 'best'
    assert opts.list_formats == True

    # -f -f
    parser

# Generated at 2022-06-24 14:09:40.520940
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    if not hasattr(sys.stderr, 'isatty'):
        return
    # Test on a single valid opt
    try:
        parser, opts, args = parseOpts(['-i'])
        assert opts.simulate
    except:
        raise
    # These have an execute command, so they will be called
    opts.simulate = True
    # Test with empty execute command
    try:
        opts.exec_cmd = ''
        parser, opts, args = parseOpts(['-i'])
        assert opts.simulate
    except:
        raise
    # Test with a valid execute command

# Generated at 2022-06-24 14:09:50.802605
# Unit test for function parseOpts

# Generated at 2022-06-24 14:09:57.567805
# Unit test for function parseOpts
def test_parseOpts():
    from .compat import parse_qs
    from .compat import compat_urllib_parse_urlparse
    _, opts, _ = parseOpts(['--username=foo', '--password=bar', 'https://example.org/'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'

    _, opts, _ = parseOpts(['--sleep-interval=2'])
    assert opts.sleep_interval == 2

    _, opts, _ = parseOpts(['--min-sleep-interval=4'])
    assert opts.min_sleep_interval == 4

    _, opts, _ = parseOpts(['--max-sleep-interval=6'])
    assert opts.max_sleep_interval == 6

    _,

# Generated at 2022-06-24 14:10:08.769764
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import mkstemp
    from shutil import copyfileobj
    from os import fdopen
    from io import StringIO
    from contextlib import closing
    from unittest import TestCase
    from youtube_dl.YoutubeDL import YoutubeDL
    class TestParseOpts(TestCase):
        def test_parseOpts(self):
            with closing(StringIO()) as buf:
                copyfileobj(open(os.path.join(os.path.dirname(__file__), 'test', 'config'), 'rb'), buf)
                buf.seek(0)
                _, filename = mkstemp(text=True)

# Generated at 2022-06-24 14:10:17.793471
# Unit test for function parseOpts
def test_parseOpts():
    # simple tests
    args = '-o file.ext https://www.youtube.com/watch?v=BaW_jenozKc'.split()
    opts = parseOpts(args)[1]
    assert opts.outtmpl == 'file.ext'
    assert opts.usenetrc == False

    # test reading from stdin
    args = '-o file.ext -a - https://www.youtube.com/watch?v=BaW_jenozKc'.split()
    from io import StringIO
    from youtube_dl.utils import encodeArgument

# Generated at 2022-06-24 14:10:22.731048
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    opts, args = parseOpts(['--verbose'])
    assert opts.verbose == True
    opts, args = parseOpts(['-v', '--retries', '5'])
    assert opts.retries == 5
    opts, args = parseOpts(['-v', '--retries', '5', '--ignore-config'])
    assert opts.retries == 5


# Generated at 2022-06-24 14:10:29.698286
# Unit test for function parseOpts
def test_parseOpts():
    # Parse with no arguments
    parser, opts, args = parseOpts([])
    assert opts.usenetrc is True
    assert opts.username is None
    assert opts.password is None
    assert opts.video_password is None
    assert opts.version is False

    # Parse with no arguments
    parser, opts, args = parseOpts(['--no-version-check'])
    assert opts.version is False
    assert opts.noplaylist is False
    assert opts.usenetrc is True
    assert opts.username is None
    assert opts.password is None
    assert opts.video_password is None

    # Parse with explicit arguments