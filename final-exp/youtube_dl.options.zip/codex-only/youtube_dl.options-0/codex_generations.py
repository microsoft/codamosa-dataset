

# Generated at 2022-06-24 14:00:34.008130
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import urlopen
    from tempfile import TemporaryFile
    from io import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
    import shutil
    from tempfile import mkdtemp
    def common_test_code(conf_lines, key=None, value=None):
        conf_file = StringIO('\n'.join(conf_lines))
        conf_file.seek(0)
        result_file = TemporaryFile()
        ydl = YoutubeDL(params={'logger': _LoggerYoutubedl(result_file)})
        if key is not None:
            assertEqual(ydl.params[key], value)
        else:
            assertFalse(ydl.params)
        return conf_file, result_file, ydl


# Generated at 2022-06-24 14:00:45.156486
# Unit test for function parseOpts
def test_parseOpts():
    opts, _ = parseOpts([])
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.videopassword is None
    assert opts.ap_username is None
    assert opts.ap_password is None
    assert opts.ignoreerrors is False
    assert opts.forceurl is False
    assert opts.forcethumbnail is False
    assert opts.forcetitle is False
    assert opts.forcedescription is False
    assert opts.forcefilename is False
    assert opts.forcejson is False
    assert opts.dump_intermediate_pages is False
    assert opts.writeannotations is False
    assert opts.writedescription is False
    assert opts.writeinfojson is False

# Generated at 2022-06-24 14:00:57.364829
# Unit test for function parseOpts
def test_parseOpts():
    def test_config_location(args, location, exist_flag=True):
        LOGGER.warning('Testing config-location %s on %s' % (location, args))
        parser, opts, _ = parseOpts(args)
        assert opts.config_location == compat_expanduser(location)
        if exist_flag:
            assert os.path.exists(compat_expanduser(location))
        else:
            assert not os.path.exists(compat_expanduser(location))

    test_config_location(['--config-location=/etc/youtube-dl/youtube-dl.conf'],
                         '/etc/youtube-dl/youtube-dl.conf')

# Generated at 2022-06-24 14:01:08.931350
# Unit test for function parseOpts
def test_parseOpts():
    from .common import FILE_PLAYLIST
    opts, _ = parseOpts([FILE_PLAYLIST])
    assert len(opts.extract_flat) > 0
    assert opts.username is None
    assert opts.format is None

    opts, _ = parseOpts(['--username', 'foobar', '--format', 'bestvideo+bestaudio', FILE_PLAYLIST])
    assert len(opts.extract_flat) > 0
    assert opts.username == 'foobar'
    assert opts.format == 'bestvideo+bestaudio'

    opts, _ = parseOpts(['--flat-playlist', '--no-playlist', '--verbose', FILE_PLAYLIST])
    assert not opts.noplaylist
    assert opts.verbose
    return True


# Generated at 2022-06-24 14:01:19.485385
# Unit test for function parseOpts
def test_parseOpts():
    with open(os.path.join(os.getcwd(), 'test.conf')) as f:
        conf = f.read()
    conf_file = tempfile.NamedTemporaryFile(delete=False)
    conf_file.write(conf.encode('utf-8'))
    conf_file.close()

# Generated at 2022-06-24 14:01:24.141718
# Unit test for function parseOpts
def test_parseOpts():
    import os
    import sys

    sys.argv = ['youtube-dl']
    assert(parseOpts()[1].simulate == False)

    sys.argv = ['youtube-dl', '--simulate']
    assert(parseOpts()[1].simulate == True)

    try:
        sys.argv = ['youtube-dl', '--help']
        parseOpts()
        assert(False)
    except SystemExit:
        pass

    try:
        sys.argv = ['youtube-dl', '--version']
        parseOpts()
        assert(False)
    except SystemExit:
        pass

    try:
        sys.argv = ['youtube-dl', '--update']
        parseOpts()
        assert(False)
    except SystemExit:
        pass


# Generated at 2022-06-24 14:01:33.962480
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import OptionValueError
    from nose.tools import assert_raises
    from nose.tools import assert_equals
    from nose.tools import assert_true
    from nose.tools import assert_false
    from nose.tools import assert_in
    from nose.tools import assert_not_in
    from nose.tools import assert_is_instance
    from nose.tools import assert_is_none
    from nose.tools import assert_is
    from nose.tools import assert_dict_equal

    parser, opts, args = parseOpts([])
    assert_false(opts.quiet)
    assert_false(opts.verbose)
    assert_false(opts.noprogress)
    assert_false(opts.usenetrc)
    assert_false(opts.username)
    assert_false

# Generated at 2022-06-24 14:01:41.400047
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('sys.stderr', new=StringIO()) as mock:
        parser, opts, args = parseOpts([])
    assert mock.getvalue() == ''

    with patch('sys.stderr', new=StringIO()) as mock:
        parser, opts, args = parseOpts(['--verbose'])
    assert mock.getvalue() == ''

    with patch('sys.stderr', new=StringIO()) as mock:
        parser, opts, args = parseOpts(['--verbose', '--version'])
    assert mock.getvalue() == 'youtube-dl version 2014.09.20\n'
# downloader.py



# Generated at 2022-06-24 14:01:48.667466
# Unit test for function parseOpts
def test_parseOpts():
    source = ['--username', 'ninja', '--password', 'cat', '%(uploader)s/%(upload_date)s/%(id)s %(title)s.%(ext)s']
    result = _hide_login_info(source)
    assert(result == ['--username', 'USERNAME', '--password', 'PASSWORD', '%(uploader)s/%(upload_date)s/%(id)s %(title)s.%(ext)s'])


# Generated at 2022-06-24 14:01:57.814559
# Unit test for function parseOpts
def test_parseOpts():
    def compat_config(conf):
        if sys.version_info < (3,):
            return [a.encode(preferredencoding(), 'replace') for a in conf]
        return conf

    # Doctest for compat_config
    """
    >>> if sys.version_info < (3,):
    ...     compat_config(['--username=foo', '--password=bar'])
    ... else:
    ...     compat_config(['--username=foo', '--password=bar'])  # doctest: +ELLIPSIS
    [b'--username=foo', b'--password=bar']
    """

    test1 = compat_config(['-f', '18', '-o', 'ok ok.flv', 'blabla'])
    parser, opts, args = parseOpts(test1)


# Generated at 2022-06-24 14:02:09.068085
# Unit test for function parseOpts
def test_parseOpts():
    # pylint: disable=W0108
    # pylint: disable=E1103
    import sys

    assert parseOpts(overrideArguments=['-i', '--username=user', '--password=sekrit'])[2] == []
    assert parseOpts(overrideArguments=['-i', '--dump-user-agent'])[1].dump_user_agent == True
    assert parseOpts(overrideArguments=['-i', '--list-extractors'])[1].list_extractors == True
    assert parseOpts(overrideArguments=['-i', '--extractor-descriptions'])[1].extractor_descriptions == True
    assert parseOpts(overrideArguments=['-i', '--version'])[1].version == True

# Generated at 2022-06-24 14:02:12.418697
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import parseOpts
    if __name__ != '__main__':
        return
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)
    # Just for the coverage
    parseOpts(['--help'])


# Generated at 2022-06-24 14:02:23.110307
# Unit test for function parseOpts
def test_parseOpts():
    print()
    import youtube_dl.extractor.common
    youtube_dl.extractor.common.info = lambda *x: print(*x)

# Generated at 2022-06-24 14:02:30.136325
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from io import StringIO
    from json import loads
    from os.path import isfile
    import tempfile
    from types import SimpleNamespace

    def perform_test(test_args, expected_opts=None, expected_args=[]):
        expected_opts = expected_opts or {}
        test_args = [argv[0]] + test_args + ["--ignore-config"]


# Generated at 2022-06-24 14:02:41.640944
# Unit test for function parseOpts
def test_parseOpts():
    from io import BytesIO
    from io import StringIO
    from youtube_dl.compat import compat_str
    parser, opts, _ = parseOpts(['-U', '"test"'])
    assert(opts.version == '"test"')
    parser, opts, _ = parseOpts(['-u', 'user', '-p', 'pass'])
    assert(opts.username == 'user')
    assert(opts.password == 'pass')
    parser, opts, _ = parseOpts(['--netrc'])
    assert(opts.username is None)
    assert(opts.password is None)
    parser, opts, _ = parseOpts(['--usenetrc'])
    assert(opts.usenetrc)
    parser, opts, _ = parse

# Generated at 2022-06-24 14:02:42.458631
# Unit test for function parseOpts
def test_parseOpts():
    pass


# Functions

# Generated at 2022-06-24 14:02:47.311313
# Unit test for function parseOpts
def test_parseOpts():
    opts_for_test = ['--username','abc','--password','xyz','--verbose','--dump-user-agent']
    parser, opts, args = parseOpts(overrideArguments=opts_for_test)
    assert opts.username=='abc'
    assert opts.password=='xyz'
    assert opts.verbose==True
    assert opts.dump_user_agent==True

# Generated at 2022-06-24 14:02:58.506934
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument, encodeFilename
    from collections import OrderedDict
    from youtube_dl.compat import stdout, file_type
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert (parser.get_usage() + '\n') == parser.format_help()

    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-v', '--retries', '1'])
    assert opts.retries == 1

    parser, opts, args = parseOpts(['--verbose', '--output', '%(id)s', '%(title)s.%(ext)s'])

# Generated at 2022-06-24 14:03:09.660690
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import decodeOption
    from youtube_dl.YoutubeDL import parseOpts
    from collections import namedtuple
    FakeYDL = namedtuple('FakeYDL', 'params')
    ydl = FakeYDL({})
    parser, opts, args = parseOpts(ydl, ['--no-warnings', '--simulate', 'plOpQX8lKPk'])
    assert opts.no_warnings
    assert opts.simulate
    assert opts.quiet
    assert not opts.verbose
    assert opts.vid == decodeOption('plOpQX8lKPk')
    assert opts.ignoreerrors
    assert opts.dump_user_agent
    assert not opts.dump_intermediate_pages


# Options specified at the command line (or in a

# Generated at 2022-06-24 14:03:17.464321
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(default_search='ytsearch', overrideArguments=['--default-search', 'ytsearch10'])
    assert opts.default_search == 'ytsearch10'
    parser, opts, args = parseOpts(default_search='ytsearch', overrideArguments=['--extract-audio'])
    assert not opts.default_search
    parser, opts, args = parseOpts(default_search=None, overrideArguments=['--extract-audio', '--default-search', 'ytsearch5'])
    assert opts.default_search == 'ytsearch5'



# Generated at 2022-06-24 14:03:23.302916
# Unit test for function parseOpts
def test_parseOpts():
    from .compat import compat_shlex_split
    argv = ["--print-traffic", "--no-progress", "--add-header", "'foo: bar'", "--add-header", "'x: y'",
            "--verbose", "--dump-intermediate-pages", "--write-pages", "--sleep-interval", "14",
            "https://www.youtube.com/watch?v=BaW_jenozKc", "--match-title", "foo"]
    _, opts, _ = parseOpts(compat_shlex_split(' '.join(argv)))
    assert opts.print_traffic
    assert not opts.progress_with_newline
    assert opts.sleep_interval == 14

# Generated at 2022-06-24 14:03:24.484301
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass

# For backwards-compatibility; You can now just call parseOpts()

# Generated at 2022-06-24 14:03:27.983583
# Unit test for function parseOpts
def test_parseOpts():
    opts = ['--verbose', '--list-formats', 'https://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(opts)
    assert parser is not None
    assert opts is not None
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-24 14:03:36.392044
# Unit test for function parseOpts

# Generated at 2022-06-24 14:03:43.988091
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    print('Python version: %s %s' % (sys.version, sys.platform))
    print('youtube-dl version: %s' % __version__)
    print('Default downloader: %s' % preferredencoding())
    print('Sys default encoding: %s' % sys.getdefaultencoding())
    print('Ishell encoding: %s' % sys.stdin.encoding)
    print('File system encoding: %s' % sys.getfilesystemencoding())
    parser, opts, args = parseOpts(['-h'])
# parseOpts()

# Extractor classes


# Generated at 2022-06-24 14:03:48.894008
# Unit test for function parseOpts
def test_parseOpts():
    import logging
    import unittest
    from youtube_dl.utils import FakeYDL

    class TestLoggingFilter(logging.Filter):
        def filter(self, record):
            # This filter makes sure that the following messages are
            # actually logged by the logging system:
            # * DEBUG or lower
            # * INFO or WARN if they contain the substring 'test'
            return (
                record.levelno == logging.DEBUG
                or ('test' in record.getMessage() and record.levelno <= logging.INFO))

    class ParseOptsTest(unittest.TestCase):
        def setUp(self):
            self.logger = logging.getLogger(self.__class__.__name__)
            self.logger.addFilter(TestLoggingFilter())


# Generated at 2022-06-24 14:03:54.904064
# Unit test for function parseOpts
def test_parseOpts():
    def testParseOpts(opts, result):
        parser, parsed_opts, args = parseOpts(opts)
        assert repr(parsed_opts) == result

    # NOTE: --output is renamed to --outtmpl in opts
    testParseOpts(['-o'], "'-o'")
    testParseOpts(['blah'], "'-o'=u'%(title)s-%(id)s.%(ext)s'")
    testParseOpts(['-o', '-'], "'-o'='-'")
    testParseOpts(['-o', '-blah'], "'-o'='-blah'")

# Generated at 2022-06-24 14:04:04.443628
# Unit test for function parseOpts
def test_parseOpts():
    from os.path import isfile
    from shutil import copyfile

    def copy(src, dst):
        if isfile(src) and isfile(dst):
            copyfile(src, dst)

    config_file = './.config-youtube-dl'
    user_config_file = './.config-youtube-dl.conf'
    user_config_file_bak = './.config-youtube-dl.conf.bak'
    system_config_file = './youtube-dl.conf'
    system_config_file_bak = './youtube-dl.conf.bak'


# Generated at 2022-06-24 14:04:06.551072
# Unit test for function parseOpts
def test_parseOpts():
    parseOpts(['-v'])
    parseOpts(['-o', 'abc', 'def'])

# Generated at 2022-06-24 14:04:13.108141
# Unit test for function parseOpts
def test_parseOpts():
    # Test different command line arguments
    def test(args, expected):
        parser, opts, args = parseOpts(args.split(' '))
        assert vars(opts) == expected


# Generated at 2022-06-24 14:04:23.669399
# Unit test for function parseOpts
def test_parseOpts():
    import cStringIO
    import sys
    import types
    _real_stdout = sys.stdout
    _real_stderr = sys.stderr
    try:
        sys.stdout = cStringIO.StringIO()
        sys.stderr = cStringIO.StringIO()
        parser, opts, args = parseOpts()
        assert isinstance(opts, optparse.Values)
        assert isinstance(args, list)
        assert not sys.stdout.getvalue()
        assert not sys.stderr.getvalue()
    finally:
        sys.stdout = _real_stdout
        sys.stderr = _real_stderr
test_parseOpts()



# Generated at 2022-06-24 14:04:33.744461
# Unit test for function parseOpts
def test_parseOpts():
    from six.moves import urllib
    url = 'a'
    try:
        from six.moves.http_client import IncompleteRead as httplib_IncompleteRead
    except ImportError:
        httplib_IncompleteRead = None
    try:
        from six.moves.urllib import error as urllib_error
    except ImportError:
        urllib_error = None
    try:
        import OpenSSL
        import ssl
        try:
            ssl_SSLError = ssl.SSLError
        except AttributeError:
            ssl_SSLError = None
    except ImportError:
        OpenSSL = None

    def handler(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGINT, handler)

# Generated at 2022-06-24 14:04:45.010021
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info < (2, 7):
        return
    parser, opts, args = parseOpts([])
    assert opts.extractaudio is False

    parser, opts, args = parseOpts(['-h'])
    assert opts.help

    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-U', 'updateuseragent'])
    assert opts.user_agent == 'updateuseragent'

    parser, opts, args = parseOpts(['-i'])
    assert opts.ignoreerrors is True

    parser, opts, args = parseOpts(['--download-archive', 'archive.txt'])
    assert opts.download_archive == 'archive.txt'



# Generated at 2022-06-24 14:04:56.064558
# Unit test for function parseOpts
def test_parseOpts():

    def getopts(args):
        parser, opts, args = parseOpts(args)
        return opts

    _default_outtmpl = '%(title)s-%(id)s.%(ext)s'
    opts = getopts([])
    assert opts.outtmpl == _default_outtmpl, repr(opts.outtmpl)

    opts = getopts(['--quiet'])
    assert not opts.verbose
    assert not opts.dump_intermediate_pages
    assert not opts.write_pages
    assert not opts.call_home
    assert opts.outtmpl == _default_outtmpl

    opts = getopts(['--verbose'])
    assert opts.verbose


# Generated at 2022-06-24 14:04:57.530299
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts(['-U', 'unit_test', '-P', 'unit_test'])
    assert opts.username == 'unit_test'
    assert opts.password == 'unit_test'



# Generated at 2022-06-24 14:04:58.846729
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts())


# Generated at 2022-06-24 14:05:09.847278
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-f', '17', 'test'])[-1] == ['test']
    assert parseOpts(['-f', 'best'])[-1] == []
    assert parseOpts(['-f', '17/22/34', 'test'])[-1] == ['test']
    assert parseOpts(['-f', '17/22/34', '-f', 'best', 'test'])[-1] == ['test']
    assert parseOpts(['-f', '0/best', 'test'])[-1] == ['test']
    assert parseOpts(['-f', '0/17/best', 'test'])[-1] == ['test']

# Generated at 2022-06-24 14:05:19.127846
# Unit test for function parseOpts
def test_parseOpts():
    import os

    opts = parseOpts(['-i', '--yes-playlist', '--dump-user-agent'])
    assert opts.ignoreerrors == True
    assert opts.call_home == False
    assert opts.nofail == False
    assert opts.simulate == False
    assert opts.quiet == False
    assert opts.outtmpl == os.path.join(os.path.expanduser('~'), '%(title)s-%(id)s.%(ext)s')
    assert opts.ignoreconfig == True
    assert opts.username == None
    assert opts.password == None
    assert opts.usenetrc == False
    assert opts.verbose == False
    assert opts.dump_intermediate_pages == False
    assert opts.write

# Generated at 2022-06-24 14:05:24.921220
# Unit test for function parseOpts
def test_parseOpts():
    def checkOpts(overrideArguments, expected_opts):
        parser, opts, args = parseOpts(overrideArguments)
        assert opts.verbose == expected_opts['verbose']
        assert opts.quiet == expected_opts['quiet']
        assert opts.forceurl == expected_opts['forceurl']
        assert opts.forcetitle == expected_opts['forcetitle']
        assert opts.forceduration == expected_opts['forceduration']
        assert opts.forcethumbnail == expected_opts['forcethumbnail']
        assert opts.forcedescription == expected_opts['forcedescription']
        assert opts.forcefilename == expected_opts['forcefilename']
        assert opts.forcenumbering == expected_opts['forcenumbering']

# Generated at 2022-06-24 14:05:31.816442
# Unit test for function parseOpts
def test_parseOpts():
    # Test extracting the video id
    video_id = 'OEoXaMPEzfM'
    assert video_id == _extract_id(video_id)
    # Test extracting the video id from the full URL
    url = 'http://www.youtube.com/watch?v=OEoXaMPEzfM&feature=feedu'
    assert video_id == _extract_id(url)
    url = 'http://www.youtube.com/v/OEoXaMPEzfM?version=3&amp;hl=en_US'
    assert video_id == _extract_id(url)

# Generated at 2022-06-24 14:05:42.736822
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = _parseOpts(['-f', '22/18/37', '--yes-playlist', 'pl.bbb'])
    assert opts.format == '22/18/37'
    assert opts.noplaylist is False
    assert args == ['pl.bbb']
    opts, args = _parseOpts(['--format', '22/18/37', '--yes-playlist', 'pl.bbb'])
    assert opts.format == '22/18/37'
    assert opts.noplaylist is False
    assert args == ['pl.bbb']
    opts, args = _parseOpts(['--format=22/18/37', '--yes-playlist', 'pl.bbb'])

# Generated at 2022-06-24 14:05:47.820658
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.usenetrc_machine == 'localhost'


# Generated at 2022-06-24 14:05:56.079205
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import _hide_login_info
    from youtube_dl.YoutubeDL import YoutubeDL

    def test_print_debug_header(opts, args, hide_login_info=True,
                                **kwargs):
        def test_write_string(s):
            pass
        def test_writeln_stdout(s):
            pass

        global write_string, writeln_stdout
        write_string = test_write_string
        writeln_stdout = test_writeln_stdout
        old_stdout = sys.stdout
        sys.stdout = StringIO()
        ydl = YoutubeDL(opts)
        ydl.print_debug_header(args, **kwargs)
        debug_info = eval(sys.stdout.getvalue())
        sys.stdout.close

# Generated at 2022-06-24 14:06:03.869959
# Unit test for function parseOpts
def test_parseOpts():
    from urllib.request import parse_http_list
    parser, opts, args = parseOpts()
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.ap_username is None
    assert opts.ap_password is None
    assert opts.verbose == 0
    assert opts.ratelimit == '1M'
    assert opts.retries == 10
    assert opts.buffersize == '1024'
    assert opts.noprogress == False
    assert opts.noresizebuffer == False
    assert opts.playliststart == 1
    assert opts.playlistend == -1
    assert opts.playlist_items == []
    assert opts.playlistreverse == False

# Generated at 2022-06-24 14:06:09.856464
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parseOpts(args, expected, msg=None):
        parser, opts, _ = parseOpts(args)
        actual = dict((k, v) for (k, v) in vars(opts).items() if k != 'verbose')
        assert actual == expected, msg

    _test_parseOpts(
        ['--age-limit=21', '--min-filesize=4M', '--max-filesize=1.4G'],
        {
            'min_filesize': 4194304,
            'max_filesize': 14928128,
            'age_limit': 21,
        })

# Generated at 2022-06-24 14:06:11.175115
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

# Parse command line arguments and return an options object

# Generated at 2022-06-24 14:06:19.728880
# Unit test for function parseOpts
def test_parseOpts():
    def assert_opts_equal(opts1, opts2):
        assert opts1.format == opts2.format
        assert opts1.outtmpl == opts2.outtmpl
        assert opts1.ignoreerrors == opts2.ignoreerrors
        assert opts1.format == opts2.format
        assert opts1.username == opts2.username
        assert opts1.password == opts2.password
        assert opts1.usenetrc == opts2.usenetrc
        assert opts1.verbose == opts2.verbose
        assert opts1.retries == opts2.retries
        assert opts1.continuedl == opts2.continuedl
        assert opts1.noprogress == opts2.noprogress
       

# Generated at 2022-06-24 14:06:24.626515
# Unit test for function parseOpts
def test_parseOpts():
    with tempfile.NamedTemporaryFile('w+t') as temp_file:
        temp_filename = compat_expanduser(temp_file.name)
        try:
            temp_file.write('--proxy 127.0.0.1:8080/\n')
            temp_file.flush()
            parser, opts, args = parseOpts([
                '--config-location', temp_filename,
                'arg1', 'arg2'])
            assert opts.proxy == '127.0.0.1:8080'
            assert len(args) == 2
            assert args[0] == 'arg1'
            assert args[1] == 'arg2'
        finally:
            os.remove(temp_filename)


# Generated at 2022-06-24 14:06:27.130603
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--username', 'user', '--password', 'pass', 'http://wwww.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'user'
    assert opts.password == 'pass'

# Generated at 2022-06-24 14:06:35.686366
# Unit test for function parseOpts
def test_parseOpts():
    from .postprocessor import _parse_format
    from .downloader import _parseOpts
    from .downloader import YoutubeDL
    def compat_opts(o):
        if sys.version_info < (3,):
            return dict([(k, v.encode(preferredencoding())) for k, v in o.__dict__.items() if k in o_keys])
        return o.__dict__

# Generated at 2022-06-24 14:06:47.910656
# Unit test for function parseOpts

# Generated at 2022-06-24 14:06:49.622431
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts({'verbose': 'True'})
    assert opts.verbose


# Generated at 2022-06-24 14:07:00.904403
# Unit test for function parseOpts
def test_parseOpts():
    p, o, a = parseOpts(None)
    assert o.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert o.outtmpl_na_placeholder == 'NA'
    assert o.writethumbnail is False
    assert o.write_all_thumbnails is False
    assert o.list_thumbnails is False
    assert o.autonumber_start == 1
    assert o.autonumber_size == 1
    assert o.restrictfilenames is False
    assert o.no_warnings is False
    assert o.verbose is False
    assert o.quiet is False
    assert o.simulate is False
    assert o.skip_download is False
    assert o.format is None
    assert o.listformats is False
    assert o.usetitle

# Generated at 2022-06-24 14:07:08.827357
# Unit test for function parseOpts
def test_parseOpts():
    opts, _args = parseOpts(['-f', '22/bestvideo+bestaudio', 'thetesttitle'])
    assert opts.format == '22/bestvideo+bestaudio'
    assert opts.usenetrc is False
    assert opts.username is None
    assert opts.password is None

    opts, _args = parseOpts(['-f', '22/bestvideo+bestaudio',
                             '--username', 'myusername',
                             '--password', 'mypassword',
                             'thetesttitle'])
    assert opts.usenetrc is False
    assert opts.username == 'myusername'
    assert opts.password == 'mypassword'


# Generated at 2022-06-24 14:07:19.886614
# Unit test for function parseOpts
def test_parseOpts():
    conf = {
        '--download-archive': '@{}',
        '-v': None,
        '--playlist-items': '1-2,8,10-',
    }
    from sys import executable, path

# Generated at 2022-06-24 14:07:31.061716
# Unit test for function parseOpts
def test_parseOpts():
    from . import compat_str

# Generated at 2022-06-24 14:07:40.359728
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv as sys_argv
    overrideArguments = ['-x', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc',
                         '-o', '%(uploader)s']
    # The following is needed so as to be able to call this unit test standalone
    sys_argv = ['youtube-dl']
    write_string = sys.stdout.write
    orig_stdout = sys.stdout

    class Error(Exception):
        pass

    class MockStdOut(object):
        """
        A class to mock sys.stdout.
        """

        def __init__(self, target=None):
            self.target = target
            self.content = []
            self.closed = False


# Generated at 2022-06-24 14:07:48.409001
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert(opts.version == False)
    assert(opts.nooverwrites == False)
    opts, args = parseOpts(['--no-overwrites'])
    assert(opts.nooverwrites == True)
    opts, args = parseOpts(['--output', 'test.test'])
    assert(opts.outtmpl == 'test.test')
    opts, args = parseOpts(['--output', 'test.test', '--no-overwrites'])
    assert(opts.outtmpl == 'test.test')
    assert(opts.nooverwrites == True)



# Generated at 2022-06-24 14:07:59.912603
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert not opts.username
    assert not opts.password
    assert not opts.twofactor
    assert not opts.videopassword
    assert not opts.ap_mso
    assert not opts.ap_username
    assert not opts.ap_password
    assert len(args) == 0

    parser, opts, args = parseOpts(['--username', 'foo', '--password', 'bar'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.twofactor is None
    assert opts.videopassword is None
    assert opts.ap_mso is None
    assert opts.ap_username is None
    assert opts.ap_password is None

# Generated at 2022-06-24 14:08:03.174453
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts([])
    assert hasattr(parser, 'parse_args')
    assert args is not None

# Generated at 2022-06-24 14:08:14.196649
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.extractor import gen_extractors, list_extractors
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.utils import setup_default_logger

    # Create a parser
    parser = create_main_parser()
    (options, args) = parser.parse_args(['-h'])
    assert options.help

    # Test -v
    (options, args) = parser.parse_args(['-v'])
    assert options.verbose == 1

    # Test -v -v
    (options, args) = parser.parse_args(['-v', '-v'])
    assert options.verbose == 2

    # Test --nocheckcertificate
    (options, args) = parser.parse_args(['--nocheckcertificate'])


# Generated at 2022-06-24 14:08:21.737987
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile

    # Test reading from config file
    with tempfile.NamedTemporaryFile('w') as tf:
        print(
            '\n'.join([
                '-f best',
                '-ciw',  # case-insensitive, no-overwrites, simulate
                '--write-description',
                '--write-info-json',
                '--all-subs',
                '--add-metadata',
                '--no-post-overwrites',
                '--keep-video',
                '-v'
            ]),
            file=tf)
        tf.flush()
        try:
            _, opts, _ = parseOpts(['--config-location', tf.name, 'foo'])
        except (SystemExit, DownloadError):
            pass
        else:
            assert False

# Generated at 2022-06-24 14:08:26.913316
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.compat import argv
    argv.append('-i')
    argv.append('wmXdJh_U2ns')
    try:
        parser, opts, args = parseOpts()
        assert(opts.getTitle() == True)
    finally:
        argv.pop()
        argv.pop()



# Generated at 2022-06-24 14:08:34.757346
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    class Args(list):
        def __init__(self, args):
            if sys.version_info < (3,):
                args = [a.encode(preferredencoding()) for a in args]
            super(Args, self).__init__(args)
        def pop(self, *args):
            if not self:
                raise IndexError()
            return super(Args, self).pop(*args)
    def parseOpts(args):
        parser, opts, args = _real_parseOpts(Args(args))
        return args
    assert parseOpts([]) == []
    assert parseOpts(['foo']) == ['foo']
    assert parseOpts(['--ignore-config']) == []
    assert parseOpts(['--get-url']) == []
    assert parseOpt

# Generated at 2022-06-24 14:08:45.016036
# Unit test for function parseOpts

# Generated at 2022-06-24 14:08:55.917652
# Unit test for function parseOpts
def test_parseOpts():
    """Unit test for parseOpts"""
    options = [
        u'--username', u'abc',
        u'--no-check-certificate',
        u'--output', u'c:/Users/IEUser/Videos/%(autonumber)s-%(uploader)s-%(title)s-%(upload_date)s.%(ext)s',
        u'--print-json',
        u'--verbose',
        u'--no-warnings',
        u'--get-filename',
        u'--restrict-filenames',
        u'--no-progress',
        u'--format', u'251/bestaudio',
        u'-k',
        u'https://www.youtube.com/watch?v=123456789'
    ]
    parsedOptions = parseOpt

# Generated at 2022-06-24 14:09:03.725496
# Unit test for function parseOpts
def test_parseOpts():
    """ Test some error cases of parseOpts()."""
    parser, opts, args = parseOpts(['-h'])
    assert opts.help is True
    assert opts.username is None

    parser, opts, args = parseOpts(['--help'])
    assert opts.help is True

    parser, opts, args = parseOpts(['-U', 'user:pass'])
    assert opts.username == 'user'
    assert opts.password == 'pass'

    parser, opts, args = parseOpts(['--username', 'user:pass'])
    assert opts.username == 'user'
    assert opts.password == 'pass'

    assert parseOpts(['-u'])[1].username is None

# Generated at 2022-06-24 14:09:08.707089
# Unit test for function parseOpts
def test_parseOpts():
    # Arrange
    overrideArguments = ['--verbose', '--sleep-interval=20']

    # Act
    parser, opts, args = parseOpts(overrideArguments)

    # Assert
    assert opts.sleep_interval == 20

# ======================================================================= #
#                                                                         #
#                              External Links                             #
#                                                                         #
# ======================================================================= #

# Function that handles all external links posted in the channel
# Returns None

# Generated at 2022-06-24 14:09:18.845704
# Unit test for function parseOpts
def test_parseOpts():
    def _test(overrideArguments, expected_opts_dict):
        parser, opts, args = parseOpts(overrideArguments)
        assert vars(opts) == expected_opts_dict

    with tmpdir() as d:
        filename = os.path.join(d, 'youtube-dl.conf')
        with open(filename, 'w') as f:
            f.write('--ignore-config\n')
            f.write('--proxy 127.0.0.1\n')
            f.write('--version\n')

# Generated at 2022-06-24 14:09:29.356843
# Unit test for function parseOpts
def test_parseOpts():
    opts, _ = parseOpts(['--version'])
    assert opts.version

    opts, _ = parseOpts(['--help'])
    assert opts.help

    opts, _ = parseOpts(['-4', '--no-check-certificate', '--verbose'])
    assert opts.prefer_insecure
    assert opts.no_check_certificate
    assert opts.verbose

    opts, _ = parseOpts(['--default-search', 'gvsearch1', '--ignore-config',
                         'rattletrap'])
    assert opts.default_search == 'gvsearch1'
    assert opts.ignoreconfig
    assert opts.username is None


# Generated at 2022-06-24 14:09:38.294827
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['--get-title', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert(not opts.usenetrc)
    assert(not opts.verbose)
    assert(not opts.quiet)
    assert(not opts.geturl)
    assert(not opts.getid)
    assert(opts.gettitle)
    assert(not opts.getthumb)
    assert(not opts.getdescription)
    assert(not opts.getfilename)
    assert(not opts.getformat)
    assert(not opts.username)
    assert(not opts.password)
    assert(not opts.twofactor)
    assert(not opts.videopassword)

# Generated at 2022-06-24 14:09:48.575562
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', 'dummy'])
    assert opts.verbose
    assert args == ['dummy']
    parser, opts, args = parseOpts(['--username=baz', '--password=foo', '--extract-audio'])
    assert opts.username == 'baz'
    assert opts.password == 'foo'
    assert opts.format == 'bestaudio/best'
    assert opts.noplaylist
    assert opts.youtube_include_dash_manifest is False
    assert opts.nocheckcertificate

    parser, opts, args = parseOpts(['--username', 'baz', '--password', 'foo', '--extract-audio', '--'])
    assert opts.username == 'baz'
   

# Generated at 2022-06-24 14:09:51.524441
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-x','-t','-c'])

# Added by Xiaochu Dong: function that sets the options in youtube_dl

# Generated at 2022-06-24 14:09:54.995384
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["--console-title"])
    print((opts.console_title))
    print((sys.platform))

if __name__ == "__main__":
    test_parseOpts()


# Generated at 2022-06-24 14:10:00.978753
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import parseOpts
    parser, opts, args = parseOpts([])
    assert not opts.verbose
    assert not opts.quiet

    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    assert not opts.quiet

    parser, opts, args = parseOpts(['--quiet'])
    assert not opts.verbose
    assert opts.quiet

    parser, opts, args = parseOpts(['--ignore-config', '--verbose'])
    assert opts.verbose
    assert not opts.quiet

    parser, opts, args = parseOpts(['--ignore-config', '--quiet'])
    assert not opts.verbose
    assert opts.quiet

# End of

# Generated at 2022-06-24 14:10:06.469305
# Unit test for function parseOpts
def test_parseOpts():
    import re
    import sys
    old_argv = sys.argv

    # Error cases
    sys.argv = old_argv[:1] + ['-U', '--username', 'foo', '--no-check-certificate', 'bar']
    try:
        parseOpts()
        raise Exception('Expected error not raised')
    except (optparse.OptionError, optparse.OptionValueError, UnavailableVideoError) as err:
        assert str(err) in ('option --username: conflicting option string(s): --username', 'invalid choice: bar', 'youtube-dl does not support login to YouTube.')
        pass
    sys.argv = old_argv[:1] + ['-u', 'foo', '-p', 'bar']

# Generated at 2022-06-24 14:10:16.159387
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl import version
    from youtube_dl.YoutubeDL import youtube_dl
    from youtube_dl.compat import compat_str
    import ydl_opts
    import ydl_opts_test
    import hashlib
    import re
    import os
    import shutil
    import subprocess
    import tempfile
    import time
    import urllib.parse
    import sys
    import traceback
    import unittest

    try:
        from unittest import mock
    except ImportError:  # Python 2
        import mock
    opts = lambda *args: youtube_dl.parseOpts(args)[1]


# Generated at 2022-06-24 14:10:19.927537
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.version import __version__
    parser, opts, args = parseOpts()
    assert opts.verbose

# ___________________________________________________________
# set of functions that are useful for testing

# Generated at 2022-06-24 14:10:30.885661
# Unit test for function parseOpts
def test_parseOpts():
    # Non-verbose debug
    try:
        parser, opts, args = parseOpts(overrideArguments=['--verbose'])
        assert opts.verbose
        parser, opts, args = parseOpts(overrideArguments=['--quiet'])
        assert not opts.verbose
    except:
        print('ERROR: test_parseOpts of "--verbose" failed!')
        return
    # Confirm if opts are the same as overrideArguments