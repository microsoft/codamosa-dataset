

# Generated at 2022-06-24 14:00:30.867739
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts([])
    assert opts.usenetrc is True
    assert opts.username is None
    assert opts.password is None
    assert opts.verbose is False

    (parser, opts, args) = parseOpts(['-v'])
    assert opts.verbose is True

# }}}

# {{{ Encoding

# Generated at 2022-06-24 14:00:39.072908
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(
        ['--default-search=ytsearch', '--verbose', '--username=user', '--password=pass',
         '--extract-audio', '--audio-format=mp3', '-w', '-c', '--no-part',
         '--no-check-certificate', '--prefer-ffmpeg',
         '--ffmpeg-location=/home/user/ffmpeg/bin/', '-f', '37/22/18',
         'ytsearch5:python'])
    assert opts.default_search == 'ytsearch'
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.usenetrc == False


# Generated at 2022-06-24 14:00:44.631337
# Unit test for function parseOpts
def test_parseOpts():
    (p, o, a)= parseOpts(['example.com', '--username', 'user', '--password', 'pass'])
    assert o.username == 'user'
    assert o.password == 'pass'
    assert o.usenetrc == False

if __name__ == '__main__':
    test_parseOpts()


# Generated at 2022-06-24 14:00:54.149203
# Unit test for function parseOpts
def test_parseOpts():
    usage = """%prog [OPTIONS] URL [URL...]"""
    parser, opts, args = parseOpts(["-v", "-o", "out.%(ext)s", "-f", "best", "http://www.youtube.com/watch?v=BaW_jenozKc"])
    assert opts.verbose == True
    assert opts.outtmpl == "out.%(ext)s"
    assert opts.format == "best"
    assert args == ["http://www.youtube.com/watch?v=BaW_jenozKc"]
# === End of unit tests ===


# Generated at 2022-06-24 14:01:02.663671
# Unit test for function parseOpts
def test_parseOpts():
    assert(parseOpts()[1].username == 'youtube-dl')
    assert(parseOpts(['-u', 'x'])[1].username == 'x')
    assert(parseOpts(['-v'])[1].verbose)
    assert(parseOpts(['-v', '-v'])[1].verbose == 2)
    assert(parseOpts(['-4'])[1].forceipv4)
    assert(parseOpts(['--force-ipv4'])[1].forceipv4)
    assert(parseOpts(['--no-check-certificate'])[1].no_check_certificate)
    assert(parseOpts(['-i'])[1].ignoreerrors)
    assert(parseOpts(['--ignore-errors'])[1].ignoreerrors)

# Generated at 2022-06-24 14:01:07.039232
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test', '--no-check-certificate', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert(parser)
    assert(opts)
    assert(args)



# Generated at 2022-06-24 14:01:15.498223
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import prepend_extension
    parser, opts, args = parseOpts(['--usenetrc', '-o', '/dev/null', '--prefer-free-formats', 'http://test.com'])
    assert parser
    assert opts
    assert args
    assert opts.usenetrc
    assert opts.outtmpl == '/dev/null'
    assert opts.prefer_free_formats
    assert args == ['http://test.com']
    parser, opts, args = parseOpts(['-o', '/tmp/%(extractor)s-%(id)s-%(autonumber)s-%(title)s.%(ext)s', 'http://test.com'])
    assert parser
    assert opts
    assert args
   

# Generated at 2022-06-24 14:01:24.707212
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import collections
    import unittest

    class FakeOptionParser(object):
        def __init__(self, parser):
            self.parser = parser
            self.refnames = collections.defaultdict(lambda: None)
            for g in self.parser.option_groups:
                if g.title == 'downloader/general options':
                    for opt in g.option_list:
                        if opt._long_opts:
                            self.refnames[opt._long_opts[0].replace('--', '')] = opt
                        elif opt._short_opts:
                            self.refnames[opt._short_opts[0].replace('-', '')] = opt

        def __getattr__(self, attr):
            return getattr(self.parser, attr)


# Generated at 2022-06-24 14:01:34.507027
# Unit test for function parseOpts

# Generated at 2022-06-24 14:01:41.805819
# Unit test for function parseOpts
def test_parseOpts():

    import unittest

    def test_config_location(self):
        self.opts.config_location = self.test_config_file_path.name
        self.argv = ['--config-location', self.opts.config_location,
                     '--ignore-config'] + self.argv
        self.opts, self.args = parseOpts(self.argv)
        self.assertEqual(self.opts.verbose, True)  # verbose is forced on by test.conf

    def _test_override_arguments(self):
        a, self.opts, self.args = parseOpts(self.argv, overrideArguments=['--verbose'])
        self.assertEqual(self.opts.verbose, True)


# Generated at 2022-06-24 14:01:52.624527
# Unit test for function parseOpts

# Generated at 2022-06-24 14:02:01.431865
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import gen_extractors
    from .utils import determine_extractor
    gen_extractors()

    parser, opts, args = parseOpts(['--extractor-descriptions'])
    assert '--extractor-descriptions' in args
    assert opts.verbose is True

    parser, opts, args = parseOpts(['https://youtu.be/BaW_jenozKc'])
    assert opts.verbose is False

    parser, opts, args = parseOpts(['--verbose', 'https://youtu.be/BaW_jenozKc'])
    assert opts.verbose is True

    parser, opts, args = parseOpts(['--verbose', '--ignore-config', 'https://youtu.be/BaW_jenozKc'])

# Generated at 2022-06-24 14:02:05.727470
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--no-progress', '--get-id', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.noprogress
    assert opts.getid
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts([])
    assert not opts.getid
    assert args == []


# Generated at 2022-06-24 14:02:11.255129
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(_encodeArgument(u'-U "Mozilla/5.0 (X11; Linux x86_64; rv:13.0) Gecko/20100101 Firefox/13.0"') + ['-i'])[1].user_agent == u'Mozilla/5.0 (X11; Linux x86_64; rv:13.0) Gecko/20100101 Firefox/13.0'
test_parseOpts()


# Generated at 2022-06-24 14:02:22.695161
# Unit test for function parseOpts
def test_parseOpts():
  parser, opts, args = parseOpts(['-v','-4'])
  assert opts.proxy == "system"
  assert opts.verbose == True
  assert opts.simulate == False
  assert opts.format == "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"
  assert opts.no_warnings == False
  assert opts.verbose_debug == False
  assert opts.skip_download == False
  assert opts.quiet == False
  assert opts.dump_user_agent == False
  assert opts.dump_intermediate_pages == False
  assert opts.write_pages == False
  assert opts.write_info_json == False
  assert opts.write_description == False
  assert opts

# Generated at 2022-06-24 14:02:28.703253
# Unit test for function parseOpts
def test_parseOpts():
    from compat import compat_urllib_request, compat_urllib_parse, compat_urllib_error
    import os.path, tempfile
    test_conf = os.path.join(tempfile.gettempdir(), 'youtube-dl-test.conf')

# Generated at 2022-06-24 14:02:29.645571
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts()

# Generated at 2022-06-24 14:02:35.891081
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import parseOpts
    try:
        import StringIO
    except ImportError:
        import io as StringIO

    # Empty config
    parseOpts([])

    # Empty config with verbose
    parseOpts(['--verbose'])

    # Empty config with config
    parseOpts(['--config-location', '/dev/null'])

    # Empty config with overrides
    parseOpts(['--ignore-config'])

    # Empty config with overrides
    parseOpts(['--ignore-config', '--verbose', '--dump-user-agent'])

    # Empty config with overrides
    parseOpts(['--ignore-config', '--verbose', '--config-location', '/dev/null'])

    # Empty config with overrides

# Generated at 2022-06-24 14:02:42.869291
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from sys import stdout
    stdout_org = stdout
    try:
        stdout = StringIO()
        parseOpts([""])
        stdout = StringIO()
        parseOpts(["--help"])
        stdout = StringIO()
        parseOpts(["--version"])
    finally:
        stdout = stdout_org
# End of test unit for function parseOpts
# End of function parseOpts



# Generated at 2022-06-24 14:02:50.107259
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parse(args):
        options, args = parseOpts(args)
        return options.__dict__


# Generated at 2022-06-24 14:02:55.436096
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
# For a reason this test seems to fail sometimes
# Commenting out for now...
#    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s', repr(opts.outtmpl)


# Generated at 2022-06-24 14:02:57.698853
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert opts.rimraf == 'webm.part'
    assert opts.restrictfilenames == False

# Generated at 2022-06-24 14:03:08.777978
# Unit test for function parseOpts
def test_parseOpts():
    from .YoutubeDL import parseOpts
    import sys
    import os
    import tempfile
    import shutil
    import io

    td = tempfile.mkdtemp(prefix='ytdl-test_parseOpts-')

# Generated at 2022-06-24 14:03:18.798935
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-q', '--verbose', '-v'])._get_kwargs()
    assert 'verbose' in opts and opts['verbose'] == 2
    assert 'quiet' in opts and opts['quiet'] == True
    opts = parseOpts(['-qq', '-vv', '-vvv'])._get_kwargs()
    assert 'verbose' in opts and opts['verbose'] == 6
    assert 'quiet' in opts and opts['quiet'] == True
    opts = parseOpts(['-q', '--no-quiet'])._get_kwargs()
    assert 'verbose' in opts and opts['verbose'] == False
    assert 'quiet' in opts and opts['quiet'] == False
    opts = parseOpts

# Generated at 2022-06-24 14:03:25.266806
# Unit test for function parseOpts
def test_parseOpts():
    import os
    import sys
    import tempfile

# Generated at 2022-06-24 14:03:31.335119
# Unit test for function parseOpts
def test_parseOpts():
    import getpass
    opts, _ = parseOpts(['-u', 'foo', '-p', 'bar', '--no-warnings', '--max-filesize', '20M', '--match-title', 'foobar', '--', 'a', 'b', 'c'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.noplaylist
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert not opts.ignoreerrors
    assert opts.ratelimit == '5.0M'
    assert opts.retries == 10
    assert opts.buffersize == '1024'
    assert opts.nocheckcertificate

# Generated at 2022-06-24 14:03:37.019613
# Unit test for function parseOpts
def test_parseOpts():
    if not os.getenv('CI', None) and not os.getenv('TRAVIS', None):
        from .extractor.common import InfoExtractor, gen_extractors
        ie = InfoExtractor()
        ie._downloader = None
        ie._ies = gen_extractors()

        sys.argv = ['youtube-dl']
        ie._real_initialize()

        assert ie.params['usenetrc'] == False
        assert ie.params['username'] == None
        assert ie.params['password'] == None

        sys.argv = ['youtube-dl', '-u', 'user', '-p', 'pass']
        ie._real_initialize()

        assert ie.params['usenetrc'] == False
        assert ie.params['username'] == 'user'
        assert ie.params['password']

# Generated at 2022-06-24 14:03:47.176673
# Unit test for function parseOpts
def test_parseOpts():
    args = ['https://www.youtube.com/watch?v=tddOvjKqhqo', '--username', 'abc', '--password', 'def']
    parser, opts, args = parseOpts(args)
    assert opts.username == 'abc'
    assert opts.password == 'def'
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.verbose == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.list_thumbnails == False
    assert opts.match_filter == None
    assert opts.retries == 10
    assert opts

# Generated at 2022-06-24 14:03:57.755060
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([])[2] == []
    assert parseOpts(['-h'])[2] == []
    assert parseOpts(['-U', 'X'])[0].get_option('-U').help == 'Account username'
    assert parseOpts(['-u', 'Y'])[0].get_option('-u').help == 'Log in to the site'
    assert parseOpts(['-p', 'Z'])[0].get_option('-p').help == 'Account password'
    assert parseOpts(['--youtube-skip-dash-manifest'])[0].get_option('--youtube-skip-dash-manifest').help == 'Do not download the DASH manifests and related data'

# Generated at 2022-06-24 14:04:01.246659
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from sys import stdout
    import sys
    # Suppress file writing
    sys.stdout = sys.stderr = StringIO()
    # Test with no options
    assert parseOpts()[1].usenetrc == True, 'No option'
    # Test with some options
    sys.stdout = sys.stderr = stdout


# Generated at 2022-06-24 14:04:10.336150
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import OptionGroup
    parser, opts, _ = parseOpts(['-f', 'bestvideo+bestaudio', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo+bestaudio'
    assert parser.get_option('-f').default == 'bestvideo+bestaudio'

    parser, opts, _ = parseOpts(['-f', '--format', 'best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'


# Generated at 2022-06-24 14:04:22.077752
# Unit test for function parseOpts
def test_parseOpts():
    from .common import FileDownloader
    from .compat import argv

    class MockFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            self.params = params
            self.ydl = ydl

    # Run tests
    # Config file is ignored
    sys.argv = ['youtube-dl']
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert 'verbose' not in opts.__dict__
    assert opts.ratelimit == None
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None

    # Config file is not ignored
    sys.argv = ['youtube-dl', '--ignore-config']
    parser, opts, args = parseOpts

# Generated at 2022-06-24 14:04:32.061829
# Unit test for function parseOpts

# Generated at 2022-06-24 14:04:43.773264
# Unit test for function parseOpts
def test_parseOpts():
    from compat import compat_getpass
    argv = ['--username=user', '--password=pwd', '--verbose', 'test_url']
    parser, opts, args = parseOpts(argv)
    assert opts.username == 'user'
    assert opts.password == 'pwd'
    assert opts.verbose
    assert args == ['test_url']
    write_string = getattr(sys.stdout, 'buffer', sys.stdout).write

    class FakePass(object):
        def __init__(self):
            self.called = False
        def getpass(self, *args):
            self.called = True
            return 'pwdfake'

    fp = FakePass()
    orig_getpass = compat_getpass.getpass

# Generated at 2022-06-24 14:04:47.898352
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-U'])[1]
    assert opts.version
    opts = parseOpts(['--help'])[1]
    assert opts.help
# End of unit test


# Generated at 2022-06-24 14:04:49.261270
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts()
    assert opts.username == 'paul'
    assert opts.password == 'Kitten1'

# Generated at 2022-06-24 14:04:58.888544
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange

# Generated at 2022-06-24 14:05:09.926521
# Unit test for function parseOpts
def test_parseOpts():
    def test(args, exp_opts, exp_args):
        opts, args = parseOpts(args.split())
        if isinstance(exp_opts, str):
            assert opts == exp_opts
            assert args == exp_args
        else:
            for key, value in exp_opts.items():
                assert getattr(opts, key) == value
            assert args == exp_args

    # Test simple option
    test(
        '-v',
        {'verbose': True}, [])
    test(
        '-h',
        {'help': True,
         'verbose': False}, [])
    test(
        '-v --help',
        {'help': True,
         'verbose': True}, [])

# Generated at 2022-06-24 14:05:14.940359
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-x', '-o', '/tmp/%(title)s.%(ext)s', '--watch-url', 'https://www.youtube.com/watch?v=BaW_jenozKc' ])
    assert opts.outtmpl == '/tmp/%(title)s.%(ext)s'
    assert opts.extractaudio
    assert opts.watch_url



# Generated at 2022-06-24 14:05:24.722482
# Unit test for function parseOpts
def test_parseOpts():
    r1, _, _ = parseOpts()
    r2, opts, _ = parseOpts(['--verbose', '--format', 'best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    r3, opts, _ = parseOpts(['--ignore-config', '--verbose', '--format', 'best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    r4, opts, _ = parseOpts(['--config-location', '/dev/null', '--verbose', '--format', 'best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-24 14:05:33.351227
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([
        '-f', '18',
        'https://www.youtube.com/watch?v=BaW_jenozKc&t=8s',
        'https://www.youtube.com/watch?v=f_OwT-mBPL0'])
    assert parser is not None
    assert opts.verbose == False
    assert opts.format == '18'
    assert args[0] == 'https://www.youtube.com/watch?v=BaW_jenozKc&t=8s'
    assert args[1] == 'https://www.youtube.com/watch?v=f_OwT-mBPL0'

# Generated at 2022-06-24 14:05:39.731891
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', '22/37/38/82', 'https://www.youtube.com/watch?v=BaW_jenozKc'])

    assert opts.format == '22/37/38/82'
    assert args[0] == 'https://www.youtube.com/watch?v=BaW_jenozKc'

test_parseOpts()

# }}}


# Generated at 2022-06-24 14:05:41.348005
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()


# Generated at 2022-06-24 14:05:50.096452
# Unit test for function parseOpts
def test_parseOpts():
    def testOpt(args, expected):
        print('Testing with ' + str(args))
        parser, opts, _ = parseOpts(args)
        actual = opts.__dict__
        assert actual == expected, '%s != %s' % (actual, expected)
    testOpt(['-v'], {'verbose': True, 'quiet': False, 'no_warnings': False, 'simulate': False, 'player_continuation_playlist': None, 'playlist_items': None, 'playlist_start': 1, 'playlist_end': None, 'playlistreverse': False, 'playlist_random': False, 'nooverwrites': False, 'forcejson': False})

# Generated at 2022-06-24 14:05:52.151837
# Unit test for function parseOpts
def test_parseOpts():
    pass



# Generated at 2022-06-24 14:05:54.105066
# Unit test for function parseOpts
def test_parseOpts():
    # TODO Unit test for function parseOpts
    pass # TODO Remove or implement unit test

# Generated at 2022-06-24 14:06:03.240353
# Unit test for function parseOpts
def test_parseOpts():
    # Test parsing of --add-header
    parser, opts, args = parseOpts(['--add-header', 'a'])
    assert opts.add_header == ['a']
    parser, opts, args = parseOpts(['--add-header', 'a:b'])
    assert opts.add_header == ['a:b']

    # Test parsing of --sleep-interval
    parser, opts, args = parseOpts(['--sleep-interval', '1'])
    assert opts.sleep_interval == 1
    parser, opts, args = parseOpts(['--sleep-interval', '1.1'])
    assert opts.sleep_interval == 1.1

# Generated at 2022-06-24 14:06:10.156132
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import unittest
    import tempfile
    import shutil

    class ParseOptsTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.system_conf_path = os.path.join(self.tempdir, 'system.conf')
            self.user_conf_path = os.path.join(self.tempdir, 'user.conf')
            self.custom_conf_path = os.path.join(self.tempdir, 'custom.conf')
        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-24 14:06:13.867407
# Unit test for function parseOpts
def test_parseOpts():
    for opt, value in (('-i', '1'), ('-c', True), ('-u', 'foo'), ('-p', 'bar')):
        print(parseOpts([opt, value]))
# parseOpts()


# Generated at 2022-06-24 14:06:19.723024
# Unit test for function parseOpts
def test_parseOpts():
    test_cases = [
        # (override_arguments, expected_options)
        (None, {'usenetrc': False, 'update_self': False, 'verbose': False}),
        (['-v'], {'usenetrc': False, 'update_self': False, 'verbose': True}),
        (['--verbose'], {'usenetrc': False, 'update_self': False, 'verbose': True}),
        (['--usenetrc'], {'usenetrc': True, 'update_self': False, 'verbose': False}),
        (['--update-self'], {'usenetrc': False, 'update_self': True, 'verbose': False}),
    ]


# Generated at 2022-06-24 14:06:28.952843
# Unit test for function parseOpts
def test_parseOpts():
    global preferredencoding
    def fake_preferredencoding(do_set=None):
        if do_set is not None:
            assert False
        return 'UTF-8'
    preferredencoding = fake_preferredencoding
    # Test case 1

# Generated at 2022-06-24 14:06:34.199704
# Unit test for function parseOpts
def test_parseOpts():
    newOpts = parseOpts(overrideArguments=['--verbose', '--youtube-skip-dash-manifest'])
    assert newOpts[-1][0].youtube_skip_dash_manifest == True
    assert newOpts[-1][0].verbose == True
#parses arguments given by user
newOpts = parseOpts()

#newOpts[-1][0].outtmpl
#newOpts[-1][0].outtmpl == sys.stdout
#newOpts[-1][0].verbose
#newOpts[-1][0].noplaylist
#newOpts[-1][0].format
#newOpts[-1][0].usenetrc
#newOpts[-1][0].username
#newOpts[-1][0].

# Generated at 2022-06-24 14:06:46.904662
# Unit test for function parseOpts
def test_parseOpts():
    from xml.dom.minidom import parseString
    from xml.parsers.expat import ExpatError

    assert parseOpts(['-i'])[2] == []
    assert parseOpts(['-u', 'user', '-p', 'passwd', 'bar'])[2] == ['bar']
    assert parseOpts(['-u', 'user', '-p', 'passwd', '-i'])[2] == []
    assert parseOpts(['--username', 'user', '--password', 'passwd', 'bar'])[2] == ['bar']
    assert parseOpts(['--username', 'user', '--password', 'passwd', '--ignore-config'])[2] == []
    assert parseOpts(['--max-downloads', '1'])[1].max_

# Generated at 2022-06-24 14:06:53.678401
# Unit test for function parseOpts
def test_parseOpts():
    opts = '--proxy 127.0.0.1:8787 -i --format mp4 --verbose --format bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'.split()
    parser, opts, args = parseOpts(opts)

    assert opts.proxy == "127.0.0.1:8787"
    assert opts.simulate == True
    assert opts.format == ["mp4", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"]
    assert opts.verbose == True

test_parseOpts()


# Generated at 2022-06-24 14:06:59.592249
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv as sys_argv
    sys_argv[1:1] = ['--ignore-config', '--username', 'foo', '--password', 'bar']
    assert parseOpts()[0].has_option('--username')
    opts, args = parseOpts()
    assert opts.username == 'foo'
    assert opts.password == 'bar'


# Generated at 2022-06-24 14:07:07.566754
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import parseOpts
    #    parser, opts, args = parseOpts(shlex.split('-f 22 --download-archive archive.txt -o "%(uploader)s/%(upload_date)s - %(title)s-%(id)s.%(ext)s" hehe url'))
    parser, opts, args = parseOpts(['--download-archive', 'archive.txt',
                                    '-o', '%(uploader)s/%(upload_date)s - %(title)s-%(id)s.%(ext)s',
                                    'hehe',
                                    'url'])

# Generated at 2022-06-24 14:07:19.080676
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import prepare_filename
    def test(a):
        if a is None:
            a = ['--username', 'foo', '--password', 'bar']
        return parseOpts(a)[1].__dict__

    assert test(['--add-metadata'])['addmetadata']
    assert test(['-4'])['noprogress']
    assert test()['username'] == 'foo'
    assert test()['password'] == 'bar'
    assert test(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])['format'] == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'

# Generated at 2022-06-24 14:07:21.721365
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print(opts)

    # parser.print_help()

test_parseOpts()

# exit()



# Generated at 2022-06-24 14:07:24.367284
# Unit test for function parseOpts
def test_parseOpts():
    try:
        parser, opts, args = parseOpts()
    except:
        return False
    return True


# Generated at 2022-06-24 14:07:35.555021
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import gen_extractors
    from .downloader.common import FileDownloader
    from .utils import prepend_extension


# Generated at 2022-06-24 14:07:44.013882
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = [
        'youtubedl',
        'http://www.youtube.com/watch?v=BaW_jenozKc',
        '-i',
        '--no-playlist',
        '--yes-playlist',
        '--output=/tmp/%(id)s.%(ext)s',
        '--get-title',
        '--get-id',
        '--username=user',
        '--password=pass',
        '--ap-password=apass',
        '--ap-username=auser',
        '--autonumber-size=5',
        '--output-template=%(uploader)s/%(upload_date)s-%(title)s.%(ext)s'
    ]
    parser, opts, args = parseOpts()

# Generated at 2022-06-24 14:07:51.677575
# Unit test for function parseOpts

# Generated at 2022-06-24 14:08:02.401259
# Unit test for function parseOpts
def test_parseOpts():
    is_file = lambda p: os.path.isfile(p)

    # --version
    for args in [['--version'], ['--versions']]:
        parser, opts, args = parseOpts(args)
        assert not os.path.isfile('config')
        assert not args
        assert not opts

    # -U
    for args in [['-U', 'FooBar'], ['--update'], ['--update']]:
        parser, opts, args = parseOpts(args)
        assert not os.path.isfile('config')
        assert not args
        assert not opts

    # --no-check-certificate
    for args in [['--no-check-certificate']]:
        parser, opts, args = parseOpts(args)

# Generated at 2022-06-24 14:08:03.549945
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts(None))

# Generated at 2022-06-24 14:08:05.240267
# Unit test for function parseOpts
def test_parseOpts():
    # unit test for this function in main()
    pass


# Generated at 2022-06-24 14:08:15.982590
# Unit test for function parseOpts
def test_parseOpts():
    # Test ',' separator
    parsed = parseOpts(['-f', '34,36,5'])
    assert parsed == ([34, 36, 5], []), parsed
    parsed = parseOpts(['-f', '34,36,5,best'])
    assert parsed == ([34, 36, 5, 'best'], []), parsed
    # Test '+' separator
    parsed = parseOpts(['-f', '34+36+5'])
    assert parsed == ([34, 36, 5], []), parsed
    parsed = parseOpts(['-f', '34+36+5+best'])
    assert parsed == ([34, 36, 5, 'best'], []), parsed
    # Test ':' separator
    parsed = parseOpts(['-f', '34:36:5'])

# Generated at 2022-06-24 14:08:22.857497
# Unit test for function parseOpts
def test_parseOpts():
    youtube_dl.utils.std_headers['User-Agent'] = 'test-user-agent'
    sys.argv = [sys.argv[0], 'http://www.youtube.com/watch?v=BaW_jenozKc', '--verbose']
    parser, opts, args = parseOpts()
    assert opts.verbose
    assert len(args) == 1
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'


# Generated at 2022-06-24 14:08:32.133243
# Unit test for function parseOpts
def test_parseOpts():
    # Parsing empty arguments returns help message
    output = StringIO()
    sys.stdout = output
    parseOpts([])
    assert('--version' in output.getvalue())

    # Parsing help arguments returns help message
    output = StringIO()
    sys.stdout = output
    parseOpts(['-h'])
    assert('--version' in output.getvalue())
    assert('--help' in output.getvalue())

    # Parsing help arguments returns help message
    output = StringIO()
    sys.stdout = output
    parseOpts(['--help'])
    assert('--version' in output.getvalue())
    assert('--help' in output.getvalue())

    # Can't be both quiet and verbose

# Generated at 2022-06-24 14:08:34.124192
# Unit test for function parseOpts
def test_parseOpts():
    assert 1 == 1, 'test_parseOpts : parseOpts is not working properly'


# Generated at 2022-06-24 14:08:44.615757
# Unit test for function parseOpts
def test_parseOpts():
    # Test Unicode
    assert parseOpts(['--output', u'ascii:\u2714'])[1].outtmpl == u'ascii:\u2714'
    assert parseOpts([u'\u2714'])[2] == [u'\u2714']

    # Test invalid options
    print(parseOpts(['--nonexistent']))
    pytest.raises(SystemExit, parseOpts, ['--nonexistent'])

    # Test boolean options
    assert parseOpts(['--no-continue'])[1].continue_dl is False
    assert parseOpts(['--yes-continue'])[1].continue_dl is True
    assert parseOpts(['--continue'])[1].continue_dl is True

# Generated at 2022-06-24 14:08:52.189410
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-c', '--username=foo'])
    assert opts.username == 'foo'
    parser, opts, args = parseOpts(['-c', '--username=foo', '-C', '--username=bar'])
    assert opts.username == 'bar'
    parser, opts, args = parseOpts(['-c', '--username=foo', '--no-check-certificate', '--username=bar'])
    assert opts.username == 'bar'


# Generated at 2022-06-24 14:09:03.220974
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', '22'])
    assert opts.format == '22'

    parser, opts, args = parseOpts(['--format=22'])
    assert opts.format == '22'

    parser, opts, args = parseOpts(['--format=22/44'])
    assert opts.format == '22/44'

    parser, opts, args = parseOpts(['-f', '22', '-f', '44'])
    assert opts.format == '44'

    parser, opts, args = parseOpts(['--format=22', '--format=44'])
    assert opts.format == '44'


# Generated at 2022-06-24 14:09:11.122145
# Unit test for function parseOpts
def test_parseOpts():

    parser, opts, args = parseOpts(['-U', '-4', '-g', 'avg', '-u', 'foouser', '-p', 'foopassword', '-R', '10', '-i', '-e', '-f', '18', '-w', '-a', 'file', '-o', '%(stitle)s.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == True
    assert opts.ipv6 == False
    assert opts.geo_verification_proxy == 'avg'
    assert opts.username == 'foouser'
    assert opts.password == 'foopassword'

# Generated at 2022-06-24 14:09:20.005051
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    original_args = argv[1:]

# Generated at 2022-06-24 14:09:28.477518
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts({'format':'best','verbosity':'normal','outtmpl':'%(extractor)s-%(id)s-%(title)s.%(ext)s','batch-file':'www.youtube.com'})
    assert opts.format == 'best'
    assert opts.verbose == False
    assert opts.outtmpl == "%(extractor)s-%(id)s-%(title)s.%(ext)s"
    assert opts.batchfile == 'www.youtube.com'

# CREATED BY PROGRAMMERBIN:
# Copyright (c) 2013 Programmerbin
# script.module.youtube.dl is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the

# Generated at 2022-06-24 14:09:40.407545
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts([
        '-f', 'best', 'http://example.com/',
        '--get-id',
        '--youtube-print-sig-code',
        '--ignore-config',
        '--no-color'
    ])

# Generated at 2022-06-24 14:09:50.683399
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import OptionParser
    parser, opts, args = parseOpts()
    if parser.parse_args([])[0] == OptionParser().parse_args([]):
        print("Could not parse the arguments you provided. Likely you're missing a url.\nYou can manually test your options by running:\n\tpython -c 'from __main__ import parseOpts; parseOpts()'\nYou can also test your options directly by running:\n\tpython -c 'import sys; from youtube_dl.YoutubeDL import YoutubeDL; YoutubeDL(sys.argv[1:]).parseOpts();'")
        return False
    return True

if __name__ == '__main__':
    vid_urls = []
    # if len(sys.argv) < 2:
    #     sys.exit('Please the URL

# Generated at 2022-06-24 14:09:57.600870
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    assert(parseOpts(['-U', 'UNIT TEST'])[2] == ['UNIT TEST'])
    assert(parseOpts(['-u', 'UNIT', 'TEST'])[2] == ['UNIT', 'TEST'])
    assert(parseOpts(['-g', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[2] == ['http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-24 14:10:00.710984
# Unit test for function parseOpts
def test_parseOpts():
    #
    # TODO:
    #    Currently, the test just verifies that the function does not crash.
    #
    parser, opts, args = parseOpts()
#
# Unit test
#


# Generated at 2022-06-24 14:10:12.653341
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    new_argv = argv
    new_argv += ['-q','-A','--yes-playlist','--youtube-skip-dash-manifest','--add-header','Host: github.com','--abc','abc','--xyz','zxw','--playlist-start','1','--playlist-end','20','--playlist-items','10,20,30','--write-thumbnail','--list-thumbnails','--write-all-thumbnails','--write-info-json','--write-annotations','--write-description','--restrict-filenames','--recode-video','mp4','--audio-format','mp3','-o','%(title)s-%(id)s.%(ext)s']

# Generated at 2022-06-24 14:10:18.365971
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["-i", "--simulate", "-v"])
    if opts.verbose:
        write_string('[debug] opts: ' + repr(opts) + '\n[debug] args: ' + repr(args) + '\n')
    assert opts.simulate and opts.verbose



# Generated at 2022-06-24 14:10:20.783676
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    parseOpts(ydl)


# Generated at 2022-06-24 14:10:23.152151
# Unit test for function parseOpts
def test_parseOpts():
    # test with empty arguments
    parser, opts, args = parseOpts([])
    assert opts.username is None

# Generated at 2022-06-24 14:10:33.410323
# Unit test for function parseOpts
def test_parseOpts():
    def check_parse(args):
        parser, opts, args2 = parseOpts(args)
        # For unknown options the parse raises an error and exits
        # So we should not reach this point
        assert False, 'Unsupported options %s' % repr(args)

    check_parse(['-f', '34'])
    check_parse(['--format', '34'])
    check_parse(['--youtube-skip-dash-manifest'])
    check_parse(['--all-subs'])
    check_parse(['--list-subs'])
    check_parse(['--sub-format', 'srt'])
    check_parse(['--write-sub'])
    check_parse(['--write-auto-sub'])
    check_parse(['--all-subs'])
   