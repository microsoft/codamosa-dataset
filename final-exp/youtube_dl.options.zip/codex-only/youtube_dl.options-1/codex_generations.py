

# Generated at 2022-06-24 14:00:30.053256
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts(['-b', '-BF1V2']))
    print(parseOpts(['--download-archive truedownload_archive',
                     '--batch-file /dev/null'
                     ]))

# Clear configuration file

# Generated at 2022-06-24 14:00:39.040466
# Unit test for function parseOpts
def test_parseOpts():
    from .update import version
    parser, opts, args = parseOpts(['-U', 'test string'])
    assert opts.update_self == True
    assert opts.usenetrc == False
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == ''

# Generated at 2022-06-24 14:00:50.657581
# Unit test for function parseOpts
def test_parseOpts():
    from .version import __version__
    parser, opts, args = parseOpts(['-U', __version__, '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == __version__
    assert opts.password == None
    assert opts.videoid == 'BaW_jenozKc'

    parser, opts, args = parseOpts(['-u', __version__, '-p', 'hunter2', '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == __version__
    assert opts.password == 'hunter2'
    assert opts.videoid == 'BaW_jenozKc'
    return True
test_parseOpts

# Generated at 2022-06-24 14:01:01.174268
# Unit test for function parseOpts
def test_parseOpts():
  parser, opts, args = parseOpts()
  assert(isinstance(parser, optparse.OptionParser))
  assert(isinstance(opts, optparse._PendingDeprecationWarning))
  assert(isinstance(args, list))
  return parser, opts, args
parser, opts, args = test_parseOpts()

print(opts)

for i in args:
  print(i)
print('Max number: ', opts.max_downloads)
print('Min number: ', opts.min_filesize)
print('Show info: ', opts.get_title)
print('List formats: ', opts.list_formats)

print(args)

if opts.geturl and len(args) < 1:
    parser.print_usage()
    sys.exit(1)


# Generated at 2022-06-24 14:01:11.550111
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.extractor import gen_extractors
    gen_extractors()
    _, opts, args = parseOpts(['-i', '-v', '--default-search', 'ytsearch1:blabla'])
    assert opts.ignore_errors
    assert opts.verbose
    assert opts.default_search == 'ytsearch1:blabla'
    assert len(args) == 0
    _, opts, args = parseOpts([])
    assert opts.default_search == 'auto'
    assert len(args) == 0
    _, opts, args = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert len(args) == 1

# Generated at 2022-06-24 14:01:21.101409
# Unit test for function parseOpts
def test_parseOpts():
#    _print_usage()
    from unittest import TestCase, TextTestRunner, TestLoader

    class MyTest(TestCase):
        def test_parseOpts(self):
            self.assertEqual(_parseOpts(['-h']), 0)
            self.assertEqual(_parseOpts(['--help']), 0)
            self.assertEqual(_parseOpts(['-U', '--username', 'toto', '-P', '--password', 'tata', 'http://www.youtube.com/watch?v=BaW_jenozKc']), 0)

    testSuite = TestLoader().loadTestsFromTestCase(MyTest)
    TextTestRunner(verbosity=2).run(testSuite)

# main

# Generated at 2022-06-24 14:01:27.916637
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import TemporaryFile
    from os import path
    from sys import platform, stdout
    from youtube_dl import __version__
    from youtube_dl.version import __version_date__

    stdout = io.BytesIO()
    orig_stderr = sys.stderr
    sys.stderr = stdout

    def reset_stdout():
        stdout.seek(0)
        stdout.truncate()


# Generated at 2022-06-24 14:01:37.452548
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts(['-f', '18', 'http://www.youtube.com/watch?v=BaW_jenozKc']))
    print(parseOpts(['-f', '18', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc']))
    print(parseOpts(['-u', 'foo', '-p', 'bar', 'https://youtube.com/watch?v=BaW_jenozKc']))
    print(parseOpts(['-j', 'http://www.youtube.com/watch?v=BaW_jenozKc']))

# Generated at 2022-06-24 14:01:40.140020
# Unit test for function parseOpts
def test_parseOpts():
    # test for issue https://github.com/rg3/youtube-dl/issues/5284
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        _real_parseOpts()
    assert not w, 'parseOpts() is not supposed to raise warnings'


# Generated at 2022-06-24 14:01:40.851686
# Unit test for function parseOpts
def test_parseOpts():
     # FIXME
     assert True


# Generated at 2022-06-24 14:01:51.748325
# Unit test for function parseOpts
def test_parseOpts():

    parser, opts, _ = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False

    parser, opts, _ = parseOpts(['-v'])
    assert opts.verbose == True
    assert opts.quiet == False

    parser, opts, _ = parseOpts(['-q'])
    assert opts.verbose == False
    assert opts.quiet == True

    parser, opts, _ = parseOpts(['-v', '-q'])
    assert opts.verbose == True
    assert opts.quiet == False

    parser, opts, _ = parseOpts(['--verbose'])
    assert opts.verbose == True
    assert opts.quiet == False


# Generated at 2022-06-24 14:02:00.582796
# Unit test for function parseOpts
def test_parseOpts():
    from collections import namedtuple
    TestCase = namedtuple('TestCase', ['conf', 'expect', 'msg'])


# Generated at 2022-06-24 14:02:10.839850
# Unit test for function parseOpts
def test_parseOpts():
    def opts_to_dict(opts):
        return dict([(x, getattr(opts, x)) for x in opts.__dict__])

    # First, test with no argument
    parser, opts, args = parseOpts([])

# Generated at 2022-06-24 14:02:15.316039
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(overrideArguments=['-i'])
    assert opts.ignoreerrors
test_parseOpts()


# Generated at 2022-06-24 14:02:18.317600
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    sys.argv=['-o', 'out', '/etc/youtube-dl.conf']
    p, opts, args = parseOpts()
    assert opts.outtmpl == 'out'

# parseOpts()



# Generated at 2022-06-24 14:02:27.343723
# Unit test for function parseOpts
def test_parseOpts():
  from youtube_dl.utils import *

  def test(args, conf, expected):
      parser, opts, args = parseOpts(args, conf)
      opts = sorted(vars(opts).items())
      assert opts == expected

  # Test youtube-dl's own options

# Generated at 2022-06-24 14:02:32.549714
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--usenetrc'])
    assert opts.usenetrc
    assert '-o' not in args
    parser, opts, args = parseOpts(['-o', 'test'])
    assert not opts.usenetrc
    assert '-o' in args


# Generated at 2022-06-24 14:02:34.687611
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['foo']) == parseOpts([sys.argv[0], 'foo'])

# Generated at 2022-06-24 14:02:45.396342
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([])[2] == []
    assert parseOpts(['-t', '"a=a"', '-x', '--'])[2] == []
    assert parseOpts(['--dump-user-agent'])[0].has_option('--dump-user-agent')
    assert parseOpts(['--dump-user-agent'])[2] == []
    assert parseOpts(['--dump-user-agent'])[1].dump_user_agent
    assert parseOpts(['--ignore-config'])[1].ignoreconfig
    assert parseOpts(['-h'])[1] is None
    assert parseOpts([])[1].quiet is False
    assert parseOpts(['-h'])[1] is None

# Generated at 2022-06-24 14:02:57.002883
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-q', '-v'])
    assert opts.quiet
    assert opts.verbose
    assert opts.simulate

    parser, opts, args = parseOpts(['-i', '-v', '-v', '-u'])
    assert opts.verbose == 2
    assert opts.simulate
    assert opts.username == '-'

    parser, opts, args = parseOpts(['-i', '-v', '-u', 'blabla', '-p', 'foobar'])
    assert opts.verbose
    assert opts.simulate
    assert opts.username == 'blabla'
    assert opts.password == 'foobar'
    assert opts.password_stdin == False



# Generated at 2022-06-24 14:03:01.391357
# Unit test for function parseOpts
def test_parseOpts():
    try:
        import StringIO
    except ImportError:
        import io as StringIO
    import sys
    oldstderr = sys.stderr
    sys.stderr = StringIO.StringIO()
    try:
        _, opts, args = parseOpts()
        assert opts.username == None
        assert not hasattr(opts, 'password')
    finally:
        sys.stderr = oldstderr

test_parseOpts()


# Generated at 2022-06-24 14:03:02.875242
# Unit test for function parseOpts
def test_parseOpts():
    return None

# ----------------------------------------------------------------------
# Main program


# Generated at 2022-06-24 14:03:14.437402
# Unit test for function parseOpts
def test_parseOpts():

    parser, opts, args = parseOpts(None)
    assert opts.outtmpl == u'%(title)s-%(id)s.%(ext)s'
    assert opts.ratelimit == '1M'
    assert opts.retries == 10
    assert opts.fragment_retries == 10

    parser, opts, args = parseOpts(['--outtmpl', '%(title)s.%(ext)s'])
    assert opts.outtmpl == '%(title)s.%(ext)s'

    parser, opts, args = parseOpts(['--outtmpl', '%(title)s.%(ext)s',
                                    '--usenetrc'])
    assert opts.usenetrc == True

    parser, opts,

# Generated at 2022-06-24 14:03:20.200701
# Unit test for function parseOpts
def test_parseOpts():
    from six.moves import reload_module
    reload_module(compat_configparser)
    config = os.path.join(os.path.dirname(__file__), 'youtube-dl.config.example')
    assert(parseOpts(['--ignore-config', '--max-downloads=dummy',
                      '--config-location=' + config])[1].max_downloads == 10)


# Generated at 2022-06-24 14:03:25.252224
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    _backup = sys.stdout
    sys.stdout = StringIO()
    try:
        _, opts, _ = parseOpts(['--verbose'])
        assert opts.verbose
    finally:
        sys.stdout = _backup

test_parseOpts()


# Generated at 2022-06-24 14:03:26.928578
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-o', 'test.mp4'])
    assert opts.outtmpl == 'test.mp4'


# Generated at 2022-06-24 14:03:27.768270
# Unit test for function parseOpts
def test_parseOpts():
    pass


# Generated at 2022-06-24 14:03:35.161326
# Unit test for function parseOpts
def test_parseOpts():
    class FakeArgv(object):
        def __init__(self, argv):
            self.argv = argv
        def __enter__(self):
            self.old = sys.argv
            sys.argv = ['youtube-dl'] + self.argv
        def __exit__(self, type, value, traceback):
            sys.argv = self.old
    opts = None
    with FakeArgv(['--max-downloads', '12', '--verbose']):
        opts = parseOpts()
    assert opts['max_downloads'] == 12
    assert opts['verbose']
    return True

# Generated at 2022-06-24 14:03:41.965193
# Unit test for function parseOpts
def test_parseOpts():
    def test(arguments, expected):
        sys.argv = ['youtube-dl'] + arguments
        parser, opts, _ = parseOpts()
        actual = {}
        for key in dir(opts):
            if not key.startswith('_'):
                actual[key] = getattr(opts, key)
        assert actual == expected, (arguments, expected, actual)
    test(['--version'], {'version': True})
    test(['-U'], {'update_self': True})
    test(['--no-check-certificate'], {'nocheckcertificate': True})
    test(['--ignore-errors'], {'ignoreerrors': True})
    test(['--no-color'], {'no_color': True})

# Generated at 2022-06-24 14:03:43.118824
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(["--age-limit","20"])
    assert opts.age_limit == 20

# Generated at 2022-06-24 14:03:48.170100
# Unit test for function parseOpts
def test_parseOpts():
    # This is used for unit testing. Should return (parser, option, args).
    # FIXME
    def _readOptions(filename):
        return []
    # FIXME
    def _readUserConf():
        return []
    # FIXME
    def _hide_login_info(args):
        return args
    return parseOpts(None,
        _readOptions=_readOptions,
        _readUserConf=_readUserConf,
        _hide_login_info=_hide_login_info)


# Compatibility fixes for Windows
if sys.platform == 'win32':
    # https://github.com/rg3/youtube-dl/issues/820
    # http://bugs.python.org/issue3905
    import codecs

# Generated at 2022-06-24 14:03:58.813886
# Unit test for function parseOpts
def test_parseOpts():
    def _run_parseOpts(args, overrideArguments=None):
        parser, opts, args = parseOpts(overrideArguments)
        opts = vars(opts)
        return {k: opts.get(k) if opts.get(k) != parser.get_default(k) else None
                for k in opts}

    def _test_parseOpts(args, expected, overrideArguments=None):
        actual = _run_parseOpts(args, overrideArguments)
        assert actual == expected, '%r != %r (args=%r)' % (actual, expected, args)

    # By default

# Generated at 2022-06-24 14:04:03.987461
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.prefer_ffmpeg is True
    assert opts.call_home is False
    parser, opts, args = parseOpts(['--prefer-ffmpeg', 'false'])
    assert opts.prefer_ffmpeg is False
    assert opts.prefer_avconv is True

# Command-line argument parsing  #######################


# Generated at 2022-06-24 14:04:12.506593
# Unit test for function parseOpts
def test_parseOpts():
    inputParseOpts = [
        '-u', 'https://www.youtube.com/watch?v=C0DPdy98e4c&list=PL6gx4Cwl9DGAcbMi1sH6oAMk4JHw91mC_',
        '-o', '~/Downloads/test', '--sleep-interval', '5',
        '--max-sleep-interval', '30', '-f', 'best', '--embed-subs',
        '--write-auto-sub', '--no-post-overwrites', '--match-filter',
        '"duration <= 9000 and age <= 3600"', '--write-annotations',
        '--write-info-json', '--write-thumbnail', '--write-all-thumbnails',
        '--list-thumbnails']


# Generated at 2022-06-24 14:04:24.542864
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import NamedTemporaryFile
    from types import GeneratorType
    from xml.etree.ElementTree import fromstring, tostring

    config = NamedTemporaryFile()


# Generated at 2022-06-24 14:04:35.792058
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-i', '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.default_search == 'auto'
    assert opts.outtmpl == '%(autonumber)s-%(id)s.%(ext)s'
    assert opts.verbose

    opts, args = parseOpts(['-o', 'test.%(ext)s', '--merge-output-format', 'mkv', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.merge_output_format == 'mkv'

   

# Generated at 2022-06-24 14:04:45.753947
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts()[2] == []
    assert parseOpts(['--version'])[2] == []
    assert parseOpts(['-v'])[2] == []
    assert parseOpts(['--help'])[2] == []
    opts, args = parseOpts(['--get-title', '"x"'])[1:]
    assert opts.geturl
    assert opts.gettitle
    assert opts.getid
    assert opts.getthumbnail
    assert not opts.getdescription
    assert not opts.getfilename
    assert not opts.getformat
    assert len(args) == 1
    assert args[0] == 'x'


# Generated at 2022-06-24 14:04:56.619260
# Unit test for function parseOpts
def test_parseOpts():
    from .downloader.common import FileDownloader
    assert parseOpts(['-i', '-o', 'test_outtmpl', 'foo']) == parseOpts(['-io', 'test_outtmpl', 'foo'])
    assert parseOpts(['-i', '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'foo']) == parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'foo'])
    assert parseOpts(['-i', '-f', 'bestvideo,bestaudio/best', 'foo']) == parseOpts(['-f', 'bestvideo,bestaudio/best', 'foo'])
   

# Generated at 2022-06-24 14:05:07.374793
# Unit test for function parseOpts
def test_parseOpts():
    opts, _ = parseOpts(['-U', '--encoding', 'foo'])
    assert opts.user_agent == 'foo'
    assert opts.encoding == 'foo'

    opts, _ = parseOpts(['-4', 'yes'])
    assert opts.prefer_ipv4

    opts, _ = parseOpts(['-6', 'no'])
    assert not opts.prefer_ipv6

    opts, _ = parseOpts(['--list-extractors'])
    assert opts.list_extractors

    opts, _ = parseOpts(['-e', 'foo', '-e', 'bar', '-E'])
    assert opts.extract_flat == ['foo', 'bar']

    opts, _ = parseOpts

# Generated at 2022-06-24 14:05:15.599461
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--version'])
    assert not args
    assert opts.version
    assert not parser.format_help()

    parser, opts, args = parseOpts(['--ignore-config', '--default-search', 'skip'])
    assert not args
    assert opts.ignore_config
    assert opts.default_search == 'skip'
    assert not parser.format_help()

    parser, opts, args = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']
    assert not opts.ignore_config
    assert not parser.format_help()


# Generated at 2022-06-24 14:05:25.266381
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import mkstemp
    import random
    import shutil

    def _get_random_string(n=10):
        return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(n))

    def _remove_temp_file(f):
        if os.path.isfile(f):
            os.remove(f)
        elif os.path.isdir(f):
            shutil.rmtree(f)

    def _test_option(option, values):
        for value in values:
            _, tmp_file = mkstemp(prefix='youtube-dl_test_config')
            # Using 'w' instead of 'wb' because Windows does not support the latter
            # See https://docs.python.org/2/library/tempfile.

# Generated at 2022-06-24 14:05:27.078845
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(["-t"])[1]
    assert opts.usetitle


# Generated at 2022-06-24 14:05:37.633234
# Unit test for function parseOpts

# Generated at 2022-06-24 14:05:47.646068
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import gen_extractors
    from .compat import stdout
    from .utils import UnavailableError

    gen_extractors()
    parser, opts, args = parseOpts(['-v', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.videopassword == None

    parser, opts, args = parseOpts(['--usenetrc','-v','https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == True
    assert opts.username == None
    assert opts

# Generated at 2022-06-24 14:05:54.555078
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])

    assert opts.verbose
    assert opts.quiet is False
    assert opts.username is None
    assert opts.password is None
    assert opts.ap_mso is None
    assert opts.ap_username is None
    assert opts.ap_password is None
    assert opts.nooverwrites is False
    assert opts.ignoreerrors is False
    assert opts.forceurl is False
    assert opts.forcetitle is False
    assert opts.forcedescription is False
    assert opts.forcefilename is False
    assert opts.forcejson is False
    assert opts.dump_single_json is False

# Generated at 2022-06-24 14:05:56.614492
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts is not None
    assert options is not None
    assert args == []

# Generated at 2022-06-24 14:06:05.437149
# Unit test for function parseOpts
def test_parseOpts():
    # call with no arg
    parseOpts()

    # call with arg
    parseOpts(['--youtube-skip-dash-manifest'])

    # call with arg
    parseOpts(['--verbose'])


# Generated at 2022-06-24 14:06:10.126080
# Unit test for function parseOpts
def test_parseOpts():
    def check_parse(args, expected):
        parser, opts, args = parseOpts(args)
        for opt, val in expected.items():
            assert getattr(opts, opt) == val
    # Test 1
    check_parse(
        ['--get-url', '--get-title', 'lol'],
        {'geturl': True, 'gettitle': True, }
    )

    # Test 2

# Generated at 2022-06-24 14:06:14.928261
# Unit test for function parseOpts
def test_parseOpts():
    # test multiple calls
    parseOpts()
    parseOpts()

    # test with override arguments
    try:
        parseOpts(['--extract-audio', '--audio-format', 'mp4'])
    except SystemExit:
        return False
    return True
# parseOpts = test_parseOpts



# Generated at 2022-06-24 14:06:26.819413
# Unit test for function parseOpts
def test_parseOpts():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    # Issue 896: Allow - to read stdin
    input_string = """
https://www.youtube.com/watch?v=BaW_jenozKc
https://www.youtube.com/watch?v=BaW_jenozKc
-
https://www.youtube.com/watch?v=mYbW8tX1VtY
"""
    argv = ['-o', '%(id)s', '--batch-file', '-']
    orig_stdin, sys.stdin = sys.stdin, StringIO(input_string)

# Generated at 2022-06-24 14:06:33.410933
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-c', '--config-location', '/this/is/a/non-existent/path', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.config_location == '/this/is/a/non-existent/path'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-24 14:06:40.644621
# Unit test for function parseOpts
def test_parseOpts():
    """
        mock sys.argv, parse options and check some selected
        attributes
    """
    # encoding
    a = parseOpts(overrideArguments=['--encoding', 'cp1251']).encoding
    assertEqual(a, 'cp1251')

    # output filename
    a = parseOpts(overrideArguments=['-o', '%(ext)s/%(autonumber)s.%(ext)s/%(title)s-%(id)s.%(ext)s/%(uploader)s/%(title)s-%(id)s-%(format_id)s.%(ext)s/%(format_id)s-%(id)s.%(ext)s']).outtmpl

# Generated at 2022-06-24 14:06:51.169845
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts(['-U', 'myuser', '-P', 'mypass', 'youtube.com'])
    assert opts.username == 'myuser'
    assert opts.password == 'mypass'

    parser, opts, _ = parseOpts(['--username', 'myuser', '--password', 'mypass', 'youtube.com'])
    assert opts.username == 'myuser'
    assert opts.password == 'mypass'

    parser, opts, _ = parseOpts(['--username', 'myuser', '--password', 'mypass', '-i', 'my.cnf', 'youtube.com'])
    assert opts.username is None
    assert opts.password is None

    with tempfile.NamedTemporaryFile() as configfile:
        config

# Generated at 2022-06-24 14:07:02.442632
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from datetime import datetime as dt

    parser, opts, args = parseOpts(['-B', '--dateafter', 'yesterday', '--datebefore', 'today',
                                    'https://www.youtube.com/watch?v=BaW_jenozKc'])

    assert isinstance(opts.daterange, DateRange)
    assert opts.daterange.start == dt.now() - DateRange.one_day
    assert opts.daterange.end == dt.now()

    parser, opts, args = parseOpts(['-B', '--dateafter', 'yesterday'])
    assert isinstance(opts.daterange, DateRange)
    assert opts.daterange.start == dt.now() - Date

# Generated at 2022-06-24 14:07:09.704929
# Unit test for function parseOpts
def test_parseOpts():
    from pytest import raises

    opts = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.server_listen == None
    assert opts.server_port == None
    assert opts.server_workdir == None
    assert opts.noplaylist == False
    assert opts.playliststart == 1
    assert opts.playlistend == 0
    assert opts.playlistreverse == False
    assert opts.extract_flat == 'in_playlist'
    assert opts.matchtitle == None
    assert opts.rejecttitle == None
    assert opts.max_downloads == -1
    assert opts.prefer_free_formats == False
    assert opts.verbose_

# Generated at 2022-06-24 14:07:21.032226
# Unit test for function parseOpts
def test_parseOpts():
    # Test YouTube contents
    test_opts = ['--verbose', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc']
    _, opts, args = parseOpts(test_opts)
    assert opts.geturl is True
    assert opts.verbose is True
    assert args[0] is 'http://www.youtube.com/watch?v=BaW_jenozKc'
    # Test empty options and arguments
    _, opts, args = parseOpts()
    assert opts is not None
    assert args is not None
    assert opts.__dict__ is not None
    assert args == []
    # Test if user agent is set
    _, opts, _ = parseOpts()
    assert opts.user_agent is not None

# Generated at 2022-06-24 14:07:26.190708
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'un', '-P', 'pw', 'pl', 'url'])
    assert(isinstance(parser, optparse.OptionParser))
    assert(isinstance(opts, optparse.Values))
    assert(opts.username == 'un')
    assert(opts.password == 'pw')
    assert(opts.playliststart == 1)
    assert(opts.playlistend == 0)
    assert(opts.playlist_items == [])
    assert(opts.playlistreverse == False)
    assert(opts.playlistrandom == False)
    assert(args == ['pl', 'url'])


# Generated at 2022-06-24 14:07:37.420611
# Unit test for function parseOpts
def test_parseOpts():
    import json
    import shutil
    with temp_path() as config_location:
        shutil.copy2(os.path.join(os.path.dirname(__file__), 'config', 'config'), config_location)
        parser, opts, args = parseOpts(['--config-location', config_location])
        assert opts.username == 'unit'
        assert opts.password == 'test'
        assert opts.verbose == 1
        assert json.loads(opts.postprocessor_args) == {}

        parser, opts, args = parseOpts(['--username', 'test_username', '--password', 'test_password'])
        assert opts.username == 'test_username'
        assert opts.password == 'test_password'
        assert opts.verbose == 0
        assert json

# Generated at 2022-06-24 14:07:46.995150
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-U', 'a', 'b', 'c'])[1]
    assert opts.username == 'a'
    assert opts.password == 'b'
    assert opts.ap_username == 'a'
    assert opts.ap_password == 'b'

    opts = parseOpts(['--username', 'a', '--password', 'b'])[1]
    assert opts.username == 'a'
    assert opts.password == 'b'
    assert opts.ap_username == 'a'
    assert opts.ap_password == 'b'

    opts = parseOpts(['--username', 'a', '--password', 'b', '--ap-username', 'c', '--ap-password', 'd'])[1]

# Generated at 2022-06-24 14:07:58.840674
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.skip_download == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.dump_json == False
    assert opts.verbose_dumpjson == False
    assert opts.simulate == False
    assert opts.skip_unavailable_fragments == False
    assert opts.test == False
    assert opts.no_warn

# Generated at 2022-06-24 14:08:07.505298
# Unit test for function parseOpts
def test_parseOpts():
    from collections import namedtuple
    from types import SimpleNamespace
    FakeFile = namedtuple('FakeFile', 'name')
    FakeConfFile = namedtuple('FakeConfFile', 'name readlines')

    # The optparse module uses the first available file of an iterable
    # with the read method as the standard input.
    FakeStdin = FakeFile('<stdin>')

    FakeConfFileContent = ['--username=user', '--password=pass', '--verbose']

    def createFakeStdin(content):
        def _read(self):
            return content

        FakeStdin = FakeFile('<stdin>')
        FakeStdin.read = _read.__get__(FakeStdin)
        return FakeStdin

    def createFakeConfFile(content):
        def _readlines(self):
            return content

# Generated at 2022-06-24 14:08:17.554991
# Unit test for function parseOpts
def test_parseOpts():
    opts,args = parseOpts(['--proxy=1.1.1.1', 'http://www.youtube.com'])
    assert opts.proxy == '1.1.1.1'

    opts,args = parseOpts(['-r', '100', 'http://www.youtube.com'])
    assert opts.ratelimit == '100'

    opts,args = parseOpts(['-l', '1000', 'http://www.youtube.com'])
    assert opts.max_downloads == 1000

    opts,args = parseOpts(['http://www.youtube.com'])
    assert opts.ratelimit == '0'

    opts,args = parseOpts(['-4', 'http://www.youtube.com'])
    assert opts.noprogress == True

# Generated at 2022-06-24 14:08:27.888529
# Unit test for function parseOpts

# Generated at 2022-06-24 14:08:39.900322
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv[0] = 'youtube-dl'
    parser, opts, args = parseOpts()
    assert(parser.values.format is None)
    assert(parser.values.verbose is None)
    assert('-f137+171' not in sys.argv)

    sys.argv[1:1] = ['-f', '137+171']
    parser, opts, args = parseOpts()
    assert(opts.format == '137+171')
    assert('-f137+171' in sys.argv)

    sys.argv[2:2] = ['--verbose']
    parser, opts, args = parseOpts()
    assert(opts.verbose)
    assert('--verbose' in sys.argv)


# Generated at 2022-06-24 14:08:42.018869
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts()
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)



# Generated at 2022-06-24 14:08:49.347246
# Unit test for function parseOpts

# Generated at 2022-06-24 14:08:50.987357
# Unit test for function parseOpts
def test_parseOpts():
    pass

#--[youtube-dl core]------------------------------------------------


# Generated at 2022-06-24 14:08:56.457130
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv as sys_argv
    try:
        sys_argv[1:] = ['http://test.test', '--username', 'test', '--password', 'test']
        parseOpts()
        sys.exit(1)
    except SystemExit:
        return
    except:
        return
    sys.exit(1)



# Generated at 2022-06-24 14:09:07.905682
# Unit test for function parseOpts
def test_parseOpts():
    from six import PY3, b

    def _s2b(s):
        return s.encode('utf-8') if PY3 else s

    # Test overrides
    parser, opts, args = parseOpts([
        '-i',
        '--username=user',
        '--password=pwd',
        '-v',
        'URL',
        'ARG'
    ])
    assert opts.username == 'user'
    assert opts.password == 'pwd'
    assert opts.verbose == True
    assert args == ['URL', 'ARG']

    # Test configuration files
    tmp = tempfile.mkdtemp()
    custom_conf = os.path.join(tmp, 'youtube-dl.conf')

# Generated at 2022-06-24 14:09:18.163406
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parseOpts(args):
        parser, opts, _ = parseOpts(args)
        assert opts.outtmpl == '%(title)s.f%(format_id)s.%(ext)s', opts.outtmpl
        assert opts.forceurl == True, opts.forceurl
        assert opts.forcetitle == True, opts.forcetitle
        assert opts.forcedescription == True, opts.forcedescription
        assert opts.forcefilename == True, opts.forcefilename
        assert opts.forceformat == 'best', opts.forceformat
        assert opts.forcethumbnail == True, opts.forcethumbnail
        assert opts.forceduration == True, opts.forceduration
        assert opts.dump_intermediate_pages == True

# Generated at 2022-06-24 14:09:25.044887
# Unit test for function parseOpts
def test_parseOpts():
    input = ['--call-home']
    parser, opts, args = parseOpts(input)
    assert opts.call_home == True
    input = ['--youtube-password=hello']
    parser, opts, args = parseOpts(input)
    assert opts.youtube_password == 'hello'
    return True
print('testing parseOpts...', end='')
assert test_parseOpts()
print('OK')

# Main downloader code for a single URL

# Generated at 2022-06-24 14:09:33.796995
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([])[0]
    assert parseOpts(['-h'])[0]
    assert parseOpts(['-U'])[0]
    assert parseOpts(['-v'])[0]
    assert parseOpts(['-g', 'sdfsdfsdf'])[0]
    assert parseOpts(['-i'])[0]
    assert parseOpts(['-r', '1'])[0]
    assert parseOpts(['--min-sleep-interval', '10'])[0]
    assert parseOpts(['--max-sleep-interval', '10'])[0]
    assert parseOpts(['-j'])[0]
    assert parseOpts(['--flat-playlist'])[0]

# Generated at 2022-06-24 14:09:36.174903
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts()[1]
    assert opts.playliststart <= opts.playlistend

# Generated at 2022-06-24 14:09:46.554082
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(None)
    assert opts.username is None
    assert opts.password is None
    assert opts.noprogress is True
    assert opts.forcetitle is False
    assert opts.forceid is False
    assert opts.forcethumbnail is False
    assert opts.forcedescription is False
    assert opts.forcefilename is False
    assert opts.forceurl is False
    assert opts.forceformat is None
    assert opts.playliststart is 1
    assert opts.playlistend is 0
    assert opts.matchtitle is None
    assert opts.rejecttitle is None
    assert opts.max_downloads is -1
    assert opts.prefer_free_formats is False
    assert opts.verbose is False

# Generated at 2022-06-24 14:09:49.901788
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts()[1]
    assert opts.max_downloads == '10'

# Generated at 2022-06-24 14:09:59.273456
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeFilename
    parser, opts, args = parseOpts(['-U', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.76 Safari/537.36', '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-o', '%(title)s-%(id)s.%(ext)s', '--verbose', 'https://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-24 14:10:09.820759
# Unit test for function parseOpts
def test_parseOpts():
    """
    Running test for pytube3.parseOpts
    """
    from pytube import parseOpts
    from pytube import __main__
    __main__.write_string = test_parseOpts.write_string
    __main__.preferredencoding = test_parseOpts.preferredencoding
    _opts = ['--verbose', '--extract-audio', '--audio-format=mp3', '--audio-quality=320k']
    _parser, _opts, _args = parseOpts(overrideArguments=_opts)
    assert _opts.verbose == True
    assert _opts.extractaudio == True
    assert _opts.audioformat == 'mp3'
    assert _opts.audioquality == '320k'



# Generated at 2022-06-24 14:10:18.461348
# Unit test for function parseOpts
def test_parseOpts():
    assert(parseOpts([])[1].verbose == False)
    assert(parseOpts(['--verbose'])[1].verbose == True)
    assert(parseOpts(['--extract-audio'])[1].extractaudio == True)
    assert(parseOpts(['--audio-format', 'mp3'])[1].audioformat == 'mp3')
    assert(parseOpts(['--audio-quality', '4'])[1].audioquality == '4')
    assert(parseOpts(['--channel-id', '123'])[1].channelurl == 'https://www.youtube.com/channel/123')
    assert(parseOpts(['--playlist-start', '3'])[1].playliststart == 3)

# Generated at 2022-06-24 14:10:25.530517
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-v', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.simulate is True
    assert opts.ignoreerrors is False
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert opts.verbose is True
    assert opts.nooverwrites is False
    assert opts.username is None
    assert opts.usenetrc is False
    assert opts.password is None
    assert opts.twofactor is None

# Generated at 2022-06-24 14:10:32.523193
# Unit test for function parseOpts
def test_parseOpts():
    def assertOptsEqual(a, b):
        assert isinstance(a, optparse.Values)
        assert isinstance(b, optparse.Values)
        for x, y in zip(a.__dict__.values(), b.__dict__.values()):
            assert x == y

    def assertOptsNotEqual(a, b):
        assert isinstance(a, optparse.Values)
        assert isinstance(b, optparse.Values)
        for x, y in zip(a.__dict__.values(), b.__dict__.values()):
            assert x != y

    parser, opts1, args1 = parseOpts(['-i', '--get-description', '--get-title', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opt