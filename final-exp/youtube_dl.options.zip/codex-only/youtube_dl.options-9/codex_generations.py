

# Generated at 2022-06-24 14:00:36.802247
# Unit test for function parseOpts
def test_parseOpts():
    command_line_conf = ['-h']
    _, opts, _ = parseOpts(command_line_conf)
    assert opts.help

    command_line_conf = ['--dump-user-agent']
    _, opts, _ = parseOpts(command_line_conf)
    assert opts.dump_user_agent

    command_line_conf = ['--version']
    _, opts, _ = parseOpts(command_line_conf)
    assert opts.version

    command_line_conf = ['--extract-audio']
    _, opts, _ = parseOpts(command_line_conf)
    assert opts.extractaudio

    command_line_conf = ['https://www.youtube.com/watch?v=BaW_jenozKc']
    _, opts

# Generated at 2022-06-24 14:00:42.105153
# Unit test for function parseOpts
def test_parseOpts():
    def _test(args, expected):
        parser, opts, args = parseOpts(args)
        got = {key: getattr(opts, key) for key in expected.keys()}
        assert got == expected, 'Got %s, expected %s' % (got, expected)

    _test(['--proxy', '1.2.3.4:5', '--user-agent', '"u a"'],
          {'proxy': '1.2.3.4:5', 'user_agent': '"u a"'})


# Generated at 2022-06-24 14:00:53.889449
# Unit test for function parseOpts
def test_parseOpts():
    from six.moves import StringIO
    
    def check_parseOpts(option, expected, msg):
        args_list = ["--%s" % option, expected]
        _, opts, _ = parseOpts(args_list)
        assert getattr(opts, option) == expected, msg

    # Test empty option
    check_parseOpts("format", "", "Empty option not correctly parsed")

    # Test boolean options
    check_parseOpts("verbose", True, "Bool option not correctly parsed")
    check_parseOpts("verbose", False, "Negative bool option not correctly parsed")

    # Test no-opts
    check_parseOpts("no-check-certificate", True, "Negative option not correctly parsed")

    # Test options with multiple values

# Generated at 2022-06-24 14:01:05.268426
# Unit test for function parseOpts
def test_parseOpts():
    from six.moves import shlex_quote
    import tempfile

    sys.argv = ['__main__', '-u', 'a', '-p', 'b', '--no-playlist']
    _, opts, _ = parseOpts()

    assert opts.username == 'a'
    assert opts.password == 'b'
    assert opts.noplaylist

    fd, fname = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('--username c\n')
    f.write('--password "d d"\n')
    f.close()

    sys.argv = ['__main__', '--config-location', fname, '--no-playlist']
    _, opts, _ = parseOpts()

   

# Generated at 2022-06-24 14:01:06.824328
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod(parseOpts)


# Generated at 2022-06-24 14:01:11.660385
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.verbose == True
    assert opts.nopart == False
    assert opts.playliststart == 1
    assert opts.playlistend == None

# Test
if __name__ == '__main__':
    test_parseOpts()
    write_string("Test for parseOpts() successful\n")

# Generated at 2022-06-24 14:01:18.034718
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-o', 'test.%(ext)s'])[2] == ['test.%(ext)s']
    assert parseOpts(['--no-check-certificate', 'https://example.org/'])[1].nocheckcertificate
    assert parseOpts(['-v'])[1].verbose
    assert parseOpts(['-4'])[1].forcetitle
    assert parseOpts(['-4'])[1].forcethumbnail



# Generated at 2022-06-24 14:01:26.130599
# Unit test for function parseOpts
def test_parseOpts():
    def test(a, o, o2=None):
        parser, opts, args = parseOpts(a.split())
        assert (opts.usenetrc == o)
        assert (opts.verbose == o2 or opts.verbose == o)
    # Test option aliases
    test(['-v'], False)
    test(['--verbose'], False)
    test(['-i'], True)
    test(['--ignore-config'], True)
    test(['-u'], False, True)
    test(['--username'], False, True)
    test(['-p'], False, True)
    test(['--password'], False, True)
    # Test conflicting options

# Generated at 2022-06-24 14:01:36.011973
# Unit test for function parseOpts
def test_parseOpts():
    # Test: Config in home directory
    # Set some environment variables
    if sys.platform == 'win32':
        os.environ['APPDATA'] = 'd:\\temp'
    else:
        os.environ['HOME'] = '/temp'
    os.environ['XDG_CONFIG_HOME'] = '/temp/config'
    os.environ['XDG_CACHE_HOME'] = '/temp/cache'
    # Create temporary config file
    config_file = os.path.join(os.environ['XDG_CONFIG_HOME'], 'youtube-dl.conf')

# Generated at 2022-06-24 14:01:42.807896
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    get_video_id = ydl.extract_id
    opt_parser, opts, args = parseOpts(['-F', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forcethumbnail == False
    assert opts.forced

# Generated at 2022-06-24 14:01:51.702199
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    with tempfile.NamedTemporaryFile(delete=True) as f:
        conf = """
        -A
        --yes-playlist
        --no-continue
        --download-archive %s
        """ % f.name
        conf = [line.strip() for line in conf.strip().splitlines()]
        parser, opts, args = parseOpts(conf)
        assert opts.autonumber
        assert opts.noplaylist is False
        assert opts.noplaylist is False
        assert opts.continue_dl is False
        assert opts.download_archive == f.name



# Generated at 2022-06-24 14:01:55.229771
# Unit test for function parseOpts
def test_parseOpts():
  pass

if __name__ == "__main__":
  test_parseOpts()

# downloader/external.py

''' Module for external downloader integration.
'''
import sys
import os.path
import subprocess
import codecs
import tempfile
import json
import re
import logging


# Generated at 2022-06-24 14:01:58.025646
# Unit test for function parseOpts
def test_parseOpts():
    # Simulates how youtube-dl is called from command line
    sys.argv = ['youtube-dl', '--version']
    parser, opts, args = parseOpts()


# Generated at 2022-06-24 14:02:00.159024
# Unit test for function parseOpts
def test_parseOpts():
    pass
# Function getOptValue
# It retrieves the value of option opt,
#   and returns it
# TODO: Test this function

# Generated at 2022-06-24 14:02:10.600654
# Unit test for function parseOpts
def test_parseOpts():
    class MockParser(optparse.OptionParser):
        def __init__(self):
            optparse.OptionParser.__init__(self)
            self.rargs = []
            self.largs = []
            self.values = optparse.Values()
            self.values.username = []

        def error(self, msg):
            raise optparse.OptionValueError(msg)

        def parse_args(self, args=None, values=None):
            if args is None:
                args = self.rargs
            if values is None:
                values = self.values
            return self._parse_args(args, values)


# Generated at 2022-06-24 14:02:20.430440
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([
        '-v',
        '--config-location=/my/conf',
        '-f', 'bestvideo+bestaudio',
        'https://www.youtube.com/watch?v=BaW_jenozKc'
    ])

    assert '-v' in sys.argv
    assert opts.verbose

    assert parser is not None
    assert args != []
    assert opts.format == ['bestvideo+bestaudio']
    assert 'https://www.youtube.com/watch?v=BaW_jenozKc' in args
# end parseOpts



# Generated at 2022-06-24 14:02:30.148391
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(
        ['-u', 'test_username', '-p', 'test_password', '-i', 'test_video_id']
    )
    assert opts.username == 'test_username'
    assert opts.password == 'test_password'
    assert args == ['test_video_id']

    parser, opts, args = parseOpts(
        ['-u', 'test_username', '-p', 'test_password', '--flat-playlist']
    )
    assert opts.usenetrc == False

    parser, opts, args = parseOpts(
        ['-u', 'test_username', '-p', 'test_password', '--no-usenetrc']
    )
    assert opts.usenetrc == False

    parser

# Generated at 2022-06-24 14:02:33.332158
# Unit test for function parseOpts
def test_parseOpts():
    try:
        parseOpts(['--encoding', 'UTF-8', '--ignore-errors', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    except SystemExit as e:
        if e.code == 0:
            pass
        else:
            raise

test_parseOpts()

# Generated at 2022-06-24 14:02:44.390701
# Unit test for function parseOpts
def test_parseOpts():
    with open(os.devnull, 'w') as nul:
        with contextlib.redirect_stdout(nul), contextlib.redirect_stderr(nul):
            parser, opts, args = parseOpts(['-q', 'foo'])
            assert opts.quiet
            assert opts.verbose == 0
            assert args == ['foo']

            parser, opts, args = parseOpts(['-q', '-v', 'foo'])
            assert opts.quiet
            assert opts.verbose == 1
            assert args == ['foo']

            parser, opts, args = parseOpts(['-vv', 'foo'])
            assert opts.quiet
            assert opts.verbose == 2
            assert args == ['foo']


# Generated at 2022-06-24 14:02:56.807076
# Unit test for function parseOpts
def test_parseOpts():
    # -f, --format FORMAT
    assert opts.format == 'best' or opts.format == 'worst'
    # -F, --list-formats
    assert opts.listformats == True or opts.listformats == False
    # -i, --ignore-errors
    assert opts.ignoreerrors == True or opts.ignoreerrors == False
    # --dump-intermediate-pages
    assert opts.dump_intermediate_pages == True or opts.dump_intermediate_pages == False
    # --write-pages
    assert opts.writepages == True or opts.writepages == False
    # -R, --retries RETRIES
    assert isinstance(opts.retries, int)
    # --buffer-size SIZE

# Generated at 2022-06-24 14:03:04.319747
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile

    _, configfile = tempfile.mkstemp(prefix='youtube-dl-config-')
    tempfiles = [configfile]

# Generated at 2022-06-24 14:03:15.827490
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts([])[1]
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.videopassword is None

    opts = parseOpts(['--username', 'foobar'])[1]
    assert opts.username == 'foobar'
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.videopassword is None

    opts = parseOpts(['--password', 'foobar'])[1]
    assert opts.username is None
    assert opts.password == 'foobar'
    assert opts.twofactor is None
    assert opts.videopassword is None


# Generated at 2022-06-24 14:03:16.450300
# Unit test for function parseOpts
def test_parseOpts():
    pass



# Generated at 2022-06-24 14:03:17.363306
# Unit test for function parseOpts
def test_parseOpts():
    return 'Todo' #TODO


# Generated at 2022-06-24 14:03:18.096784
# Unit test for function parseOpts
def test_parseOpts():
    pass


# Generated at 2022-06-24 14:03:26.427896
# Unit test for function parseOpts
def test_parseOpts():
    from .YoutubeDL import YoutubeDL
    from .extractor import gen_extractors
    from .compat import compat_expanduser

    gen_extractors()
    parser, opts, args = parseOpts(['-f', 'best'])
    assert opts.format == 'best'

    conf_path = os.path.join(os.path.dirname(__file__), 'youtube-dl.conf')
    youtube_dl = YoutubeDL(opts)
    youtube_dl.params['simulate'] = True

    # Test with empty arguments
    assert len(parseOpts([])[2]) == 0

    # Test with a config file
    config_result = parseOpts(['--config-location', conf_path])[2]
    assert len(config_result) == 0

    # Test with a config

# Generated at 2022-06-24 14:03:34.715013
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4'])[1].format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4'
    assert parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4', '-f', 'bestvideo[ext=ogg]+bestaudio[ext=opus]/bestvideo+bestaudio/best'])[1].format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4+bestvideo[ext=ogg]+bestaudio[ext=opus]/bestvideo+bestaudio/best'


# Generated at 2022-06-24 14:03:41.514618
# Unit test for function parseOpts
def test_parseOpts():
    def test_parseOpts_helper(overrideArguments):
        parser, opts, args = parseOpts(overrideArguments)
        if parser is None or opts is None or args is None :
            return 0
        else:
            return 1
    assert test_parseOpts_helper(['-h']) == True
    assert test_parseOpts_helper(['--help']) == True
    assert test_parseOpts_helper(['-v']) == True
    assert test_parseOpts_helper(['--version']) == True
    assert test_parseOpts_helper(['-U']) == True
    assert test_parseOpts_helper(['--update']) == True
    assert test_parseOpts_helper(['-i']) == True
    assert test

# Generated at 2022-06-24 14:03:46.843792
# Unit test for function parseOpts
def test_parseOpts():
    configPath = os.path.join(os.path.split(sys.argv[0])[0], "youtube-dl.conf")
    parser = optparse.OptionParser(usage=YOUTUBE_DL_HELP)
    assert parseOpts(parser, overrideArguments=['-h'])[2] == []
    assert parseOpts(parser, overrideArguments=['--version'])[2] == []
    assert parseOpts(parser, overrideArguments=['--extractor-descriptions'])[2] == []
    assert parseOpts(parser, overrideArguments=['--ignore-config', '-h'])[2] == []
    assert parseOpts(parser, overrideArguments=[configPath, '-h'])[2] == []

# Generated at 2022-06-24 14:03:50.876950
# Unit test for function parseOpts
def test_parseOpts():
    #TODO:
    # - Test for HTTPS
    # - Test for IPv6 enabled or disabled
    # - Test for forceIPv4 or forceIPv6
    # - Test for setting max downloads
    # - Test for rate limiting
    # - Test for config file
    # - Test for proxies
    pass
# Parse the command line arguments
parser, opts, args = parseOpts(['https://www.youtube.com/watch?v=o4F-kp4sYwg'])


# Generated at 2022-06-24 14:03:52.768311
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod(sys.modules[__name__])


# Generated at 2022-06-24 14:04:02.928320
# Unit test for function parseOpts
def test_parseOpts():
    _, opts1, _ = parseOpts(['--usenetrc','--username','test','--password','test','pl','PLMc9HuvlIIeJpukHNcNwsa0W4OVg7SHOj'])
    assert opts1.usenetrc == True
    assert opts1.username == None
    assert opts1.password == None
    _, opts2, _ = parseOpts(['-u','test','-p','test','pl','PLMc9HuvlIIeJpukHNcNwsa0W4OVg7SHOj'])
    assert opts2.usenetrc == False
    assert opts2.username == 'test'
    assert opts2.password == 'test'
    pass


# Generated at 2022-06-24 14:04:09.579353
# Unit test for function parseOpts
def test_parseOpts():
    # Test --ignore-config
    parser, opts, args = parseOpts(['--username', 'foo', '--ignore-config', 'bar'])
    assert not opts.username
    parser, opts, args = parseOpts(['--ignore-config', '--username', 'foo', 'bar'])
    assert opts.username == 'foo'

    # Test --config-location
    parser, opts, args = parseOpts(['--config-location', '/dev/null', '--username', 'foo', 'bar'])
    assert not opts.username


# Generated at 2022-06-24 14:04:16.319523
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from shutil import copy2
    from tempfile import mkdtemp

    def test_case(args, expected_opts):
        parser, opts, _ = parseOpts(args)

        for key in expected_opts:
            assert getattr(opts, key) == expected_opts[key], key + ' should be ' + str(expected_opts[key])

    # Test whether custom config parsing works
    # This test will leave a temporary directory behind, but this should not cause any problems

    temp_dir = mkdtemp(prefix='yl-config-test')
    config_file_name = 'youtube-dl.conf'
    temp_config = os.path.join(temp_dir, config_file_name)

# Generated at 2022-06-24 14:04:18.503563
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.verbose
    return True



# Generated at 2022-06-24 14:04:26.414557
# Unit test for function parseOpts
def test_parseOpts():
    import optparse
    from os.path import dirname

    def check_opts(opts, args, expected_opts, expected_args):
        assert vars(opts) == expected_opts, '\n' + repr(vars(opts)) + '\n\n!=\n\n' + repr(expected_opts)
        assert args == expected_args, '\n' + repr(args) + '\n\n!=\n\n' + repr(expected_args)

    def test(command_line_conf, expected_opts, expected_args):
        parser, opts, args = parseOpts(command_line_conf)
        check_opts(opts, args, expected_opts, expected_args)

    # Test config

# Generated at 2022-06-24 14:04:29.335445
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)



# Generated at 2022-06-24 14:04:40.355950
# Unit test for function parseOpts
def test_parseOpts():

    def check(argv, expected):
        parser, opts, args = parseOpts(argv)
        assert (args == expected[0] and
                sorted(vars(opts).items()) == sorted(expected[1].items()))

    # default
    check(['-v'], ([], {'verbose': True}))

    # overriding
    check(['-v'], ([], {'verbose': True}))
    check(['-v'], ([], {'verbose': True}))
    check(['-v'], ([], {'verbose': True}))
    check(['-v'], ([], {'verbose': True}))

# Generated at 2022-06-24 14:04:52.018390
# Unit test for function parseOpts
def test_parseOpts():
    # Basic test
    try:
        parseOpts()
    except:
        pass

    # Test caching dir
    if os.name == 'posix':
        cachedir = '/tmp/youtube-dl-cache'
        try:
            os.rmdir(cachedir)
        except:
            pass
        if os.path.exists(cachedir):
            assert False
        _, opts, _ = parseOpts(['--cache-dir', cachedir])
        if not os.path.exists(cachedir):
            assert False
        os.rmdir(cachedir)

    # Test --
    _, opts, args = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc', '--', '-x', '--new-option'])

# Generated at 2022-06-24 14:04:59.170062
# Unit test for function parseOpts
def test_parseOpts():
    """Sanity test for parseOpts"""
    # This test will fail if there's no youtube-dl.conf in the current directory
    # First check: Override config
    overrideArguments = ["--dateafter", "20130801"]
    parser, opts, args = parseOpts(overrideArguments)
    assert opts.dateafter == "20130801"
    assert opts.datebefore == None
    # Second check: Command-line config
    parser, opts, args = parseOpts()
    assert opts.dateafter == "20130801"
    assert opts.datebefore == None



# Generated at 2022-06-24 14:05:07.615979
# Unit test for function parseOpts
def test_parseOpts():
    # Function parseOpts is based on the external module optparse.
    # There is no easy way to increase code coverage while skipping initialization of optparse.
    # The following unit test mimics the execution of parseOpts using the
    # official example of optparse module
    # https://docs.python.org/2/library/optparse.html
    import optparse
    usage = "usage: %prog [options]"
    parser = optparse.OptionParser(usage)
    parser.add_option("-f", "--file", dest="filename",
                      help="write report to FILE")
    parser.add_option("-q", "--quiet",
                      action="store_false", dest="verbose", default=True,
                      help="don't print status messages to stdout")
    (options, args) = parser.parse_args([])
   

# Generated at 2022-06-24 14:05:17.137319
# Unit test for function parseOpts
def test_parseOpts():
    try:
        input_ = parseOpts()
        assert(type(input_) == tuple)
    except:
        assert False
    parser = parseOpts()[0]
    assert(type(parser) == optparse.OptionParser)
    opts = parseOpts()[1]
    assert(type(opts) == optparse.Values)
    args = parseOpts()[2]
    assert(type(args) == list)
    assert(len(args) == 0)
    try:
        input_ = parseOpts(['-h'])
        assert(type(input_) == tuple)
    except:
        assert False
    parser = parseOpts(['-h'])[0]
    assert(type(parser) == optparse.OptionParser)

# Generated at 2022-06-24 14:05:18.593330
# Unit test for function parseOpts
def test_parseOpts():
    #TODO: Write unit tests
    pass



# Generated at 2022-06-24 14:05:24.253647
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = _real_main(['-U', 'unit', '-P', 'testing'])
    assert opts.username == 'unit'
    assert opts.password == 'testing'
    assert len(args) == 0
    # -s is a binary flag
    parser, opts, args = _real_main(['-s'])
    assert opts.simulate == True
    assert len(args) == 0


# Generated at 2022-06-24 14:05:24.700369
# Unit test for function parseOpts
def test_parseOpts():
    return

# Generated at 2022-06-24 14:05:34.488912
# Unit test for function parseOpts
def test_parseOpts():
    import os
    import subprocess
    import tempfile
    import copy
    import platform

    # test config file
    config_file = None

# Generated at 2022-06-24 14:05:45.260708
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', '--username', 'foobar'])
    assert opts.usenetrc == True
    assert opts.username == 'foobar'
    assert opts.password == None
    assert opts.video_password == None
    parser, opts, args = parseOpts([
        '--username', 'foobar',
        '-p', 'p4ssw0rd',
        '--video-password', 'v1d34'])
    assert opts.usenetrc == False
    assert opts.username == 'foobar'
    assert opts.password == 'p4ssw0rd'
    assert opts.video_password == 'v1d34'

# Generated at 2022-06-24 14:05:52.955613
# Unit test for function parseOpts
def test_parseOpts():
    def t(args, stdin, expected, expected_msgs, **kwargs):
        # Python 3 compatibility
        if sys.version_info >= (3, 0):
            stdin = stdin.encode('utf-8')
        fd = io.BytesIO(stdin)
        old = sys.stdin
        sys.stdin = fd
        old_stderr = sys.stderr
        sys.stderr = StringIO()
        old_opts = deepcopy(default_opts)
        default_opts.update(kwargs)
        parser, opts, args = compat_parseOpts(args)
        sys.stdin = old
        sys.stderr = old_stderr
        default_opts.clear()
        default_opts.update(old_opts)
       

# Generated at 2022-06-24 14:05:55.163766
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts()
    assert opts.embedthumbnail == False
test_parseOpts()


# Generated at 2022-06-24 14:05:57.684658
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-v'])[1].verbose == True
    assert parseOpts(['--version'])[1].apiversion == False
# End unit test for function parseOpts



# Generated at 2022-06-24 14:06:06.160547
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-f', '22/18/17/best', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '22/18/17/best'
    assert args == ['http://youtube.com/watch?v=BaW_jenozKc']

    opts, args = parseOpts(['-f', '22/18/17/best', '-f', '37/22/18/17/best', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '37/22/18/17/best'
    assert args == ['http://youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-24 14:06:07.976390
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert_true(isinstance(opts, optparse.Values))
    assert_true(isinstance(args, list))


# Generated at 2022-06-24 14:06:18.273242
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts()
    assert parseOpts(['-h'])
    assert parseOpts(['-U'])
    assert parseOpts(['-i'])
    assert parseOpts(['-u', 'user', '-p', 'passwd'])
    assert parseOpts(['-u', 'user-agent', '-u', 'user', '-p', 'passwd'])
    assert parseOpts(['-u', 'user-agent', '--username', 'user', '--password', 'passwd'])
    assert parseOpts(['--username', 'user', '--password', 'passwd', '-u', 'user-agent'])
    assert parseOpts(['-u', 'user-agent'])
    assert parseOpts(['--username', 'user'])
    assert parseOpts

# Generated at 2022-06-24 14:06:20.990485
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert opts.playliststart != 0
    assert opts.playlistend != 0
    test_parseOpts()


# Generated at 2022-06-24 14:06:27.823786
# Unit test for function parseOpts
def test_parseOpts():
    args = 'youtube-dl --username testuser --password testpass -4 --no-check-certificate --verbose --simulate https://www.youtube.com/watch?v=BaW_jenozKc'.split()
    parser, opts, args = parseOpts(args)
    assert opts.username == 'testuser'
    assert opts.password == 'testpass'
    assert opts.verbose
    assert opts.simulate
    assert opts.nocheckcertificate
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']



# Generated at 2022-06-24 14:06:29.137743
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts())

# Generated at 2022-06-24 14:06:30.320122
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts() is not None


# Generated at 2022-06-24 14:06:38.712657
# Unit test for function parseOpts
def test_parseOpts():

    def _check(o, a, k, v):
        assert o and hasattr(o, k)
        assert getattr(o, k) == v, '%s != %s' % (getattr(o, k), v)
        if a:
            assert not a, '%s != []' % a

    arguments = []
    _check(*parseOpts(arguments))
    arguments = ['--format=22', '--format=141', 'bar']
    _check(*parseOpts(arguments), 'format', ['22', '141'])
    arguments = ['--prefer-free-formats']
    _check(*parseOpts(arguments), 'prefer_free_formats', True)
    arguments = ['--format=best[ext=mp4]']

# Generated at 2022-06-24 14:06:40.966762
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts()
    print(opts)



# Generated at 2022-06-24 14:06:50.842565
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.username == None
    assert opts.password == None

    parser, opts, args = parseOpts(['-u', 'foo', '-p', 'bar'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'

    parser, opts, args = parseOpts(['-u'])
    assert opts.username == None
    assert opts.password == None

    parser, opts, args = parseOpts(['-u', 'foo', 'bar', '-p', 'foo', 'bar'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'


# Generated at 2022-06-24 14:06:55.203613
# Unit test for function parseOpts
def test_parseOpts():
    args = ["-f", "bestvideo+bestaudio"]
    _, opts, _ = parseOpts(args)
    assert opts.format == ['bestvideo+bestaudio']

test_parseOpts()


# Generated at 2022-06-24 14:07:04.792789
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import tempfile

    def new_tempfile():
        (handle, fn) = tempfile.mkstemp(suffix='_youtube-dl-test')
        os.close(handle)
        return fn

    def get_environ_var(varname, default=None):
        if varname in os.environ:
            return os.environ[varname]
        return default

    def get_home_dir():
        home_dir = get_environ_var('HOME')
        if home_dir is None:
            home_dir = get_environ_var('USERPROFILE')
        return home_dir


# Generated at 2022-06-24 14:07:11.394774
# Unit test for function parseOpts
def test_parseOpts():
    # Test parseOpts function
    # 1. create temporary config file
    # 2. parse command line arguments including the temporary config file
    # 3. parse command line arguments overriding the temporary config file
    # 4. parse command line arguments overriding the temporary config file
    #    while the temporary config file doesn't exist
    # 5. delete temporary config file

    (fd, conf) = tempfile.mkstemp()

# Generated at 2022-06-24 14:07:19.163849
# Unit test for function parseOpts
def test_parseOpts():
    if os.path.isfile('youtube-dl.conf'):
        # override configuration file location
        command_line_conf = ['--ignore-config', '--config-location=./youtube-dl.conf']
        sp = parseOpts(overrideArguments=command_line_conf)[0]
        # this should raise an error because verbose is not a valid argument
        try:
            sp.parse_args(['-v'])
        except SystemExit:
            pass
        else:
            assert(False)


# Retrieve info for URLs in args

# Generated at 2022-06-24 14:07:22.644309
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert(opts.username == 'anonymous')
    assert(opts.password == 'my_password')

if __name__ == '__main__':
    test_parseOpts() # unit test

# Generated at 2022-06-24 14:07:34.226216
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import NamedTemporaryFile

    parser, opts, args = parseOpts(['-v', '--skip-download', '-g', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.skip_download == True
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts(['-v', '--skip-download', '-g', 'https://www.youtube.com/watch?v=BaW_jenozKc', '--format', 'mp3'])
    assert opts.format == 'mp3'


# Generated at 2022-06-24 14:07:44.294994
# Unit test for function parseOpts
def test_parseOpts():
    test_argv = '--extract-audio --audio-format vorbis --audio-quality 0 --output \'%(id)s.%(ext)s\' https://www.youtube.com/watch?v=MtN1YnoL46Q'.split()

    parser, opts, args = parseOpts(test_argv)

    expected_audioformat = 'vorbis'
    expected_audioquality = '0'
    expected_outtmpl = '%(id)s.%(ext)s'

    assert opts.extractaudio is True
    assert opts.audioformat == expected_audioformat
    assert opts.audioquality == expected_audioquality
    assert opts.outtmpl == expected_outtmpl
    assert opts.verbose is False
    assert opts.quiet is False


# End of

# Generated at 2022-06-24 14:07:52.400435
# Unit test for function parseOpts

# Generated at 2022-06-24 14:07:58.220837
# Unit test for function parseOpts
def test_parseOpts():
    try:
        import youtube_dl.version
        argv = ['--version']
        parser, opts, args = parseOpts(argv)
        sys.exit(0)
    except SystemExit as sys_exit_e:
        assert sys_exit_e.code == 0
        return True
    return False


# Generated at 2022-06-24 14:08:09.438348
# Unit test for function parseOpts
def test_parseOpts():
    class Args(object):
        def __init__(self, *args):
            self.args = args

        def __iter__(self):
            return iter(self.args)

    class Options(object):
        def __init__(self, **kwargs):
            self.kwargs = kwargs

        def __getattr__(self, name):
            if name in self.kwargs:
                return self.kwargs[name]
            raise AttributeError(name)

    class FakeParser(object):
        def __init__(self):
            self.option_groups = []
            self.option_list = []

        def add_option_group(self, *args, **kwargs):
            self.option_groups.append((args, kwargs))


# Generated at 2022-06-24 14:08:18.290947
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.compat import parse_qs

    # For URL
    outtmpl = '%(uploader)s/%(upload_date)s/%(title)s-%(id)s.%(ext)s'
    postprocessing = '%(uploader)s/%(upload_date)s/%(title)s-%(id)s-%(format)s-%(format_id)s.%(ext)s'
    url = 'www.youtube.com/watch?v=BaW_jenozKc'
    fmt = '34/35/5'
    default_search = 'auto'


    # Test with no options
    parser, opts, args = parseOpts([url])

# Generated at 2022-06-24 14:08:19.284147
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts())


# Generated at 2022-06-24 14:08:29.545798
# Unit test for function parseOpts

# Generated at 2022-06-24 14:08:41.464175
# Unit test for function parseOpts
def test_parseOpts():
    global readOptions_cache
    readOptions_cache = {}
    parser, opts, args = parseOpts(['-i', '-f', '22', '-v', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.outtmpl == ('%(id)s.%(ext)s')
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.quiet == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.simulate == False
    assert opts.skip_download

# Generated at 2022-06-24 14:08:48.621410
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert type(parser) == optparse.OptionParser
    assert type(opts) == optparse.Values
    assert type(args) == list

# def parseOpts(overrideArguments=None):
#     """
#     Parse the command line options and return a tuple with
#     an OptionParser object, the parsed options and the
#     args.
#     If overrideArguments is None, use sys.argv[1:],
#     else tokenize the string overrideArguments and use it instead.
#     """
#     if overrideArguments is not None:
#         return _parseOpts_cli(overrideArguments)
#     else:
#         return _parseOpts_conf(overrideArguments)


# Generated at 2022-06-24 14:08:59.651579
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import Values
    import re

    parser, opts, args = parseOpts()

    # Check that options with multiple aliases work as expected (see #2657)

# Generated at 2022-06-24 14:09:11.668829
# Unit test for function parseOpts
def test_parseOpts():
    class Args(object):
        def __init__(self, *args):
            self.args = [a.encode('ascii') for a in args]

        def __getitem__(self, key):
            return self.args[key]

        def __len__(self):
            return len(self.args)

    class FakeOpts(object):
        def __init__(self):
            self.simulate = False
            self.skip_download = False
            self.quiet = False
            self.format = None
            self.no_warnings = False
            self.verbose = False
            self.ignoreconfig = False

    class FakeParser(object):
        def __init__(self):
            self.option_list = [FakeOpts()]

        def error(self, msg):
            pass

       

# Generated at 2022-06-24 14:09:18.039520
# Unit test for function parseOpts
def test_parseOpts():
    class Options(object):
        pass
    opts = Options()
    opts.username = None
    opts.password = None
    opts.video_password = None
    opts.twofactor = None
    opts.ap_mso = None
    opts.ap_username = None
    opts.ap_password = None
    opts.videopassword = None
    return opts

#def _match_entry(info_dict, incomplete_match, incomplete_ok, skip_download):

# Generated at 2022-06-24 14:09:25.716794
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--version'])
    assert opts.version
    parser, opts, args = parseOpts(['--extract-audio', '--audio-format=ogg', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert opts.extractaudio
    assert opts.audioformat == 'ogg'
    assert args == ['http://youtube.com/watch?v=BaW_jenozKc']

# End unit test for function parseOpts


# Generated at 2022-06-24 14:09:34.326065
# Unit test for function parseOpts
def test_parseOpts():
    def _test(args, should_be):
        parser, opts, _ = parseOpts(overrideArguments=args)
        if vars(opts) != should_be:
            raise ValueError('\n' + repr(vars(opts)) + '\nshould be\n' + repr(should_be))

# Generated at 2022-06-24 14:09:37.333283
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print("***** Parser ****")
    print(parser)
    print("***** Opts *****")
    print(opts)
    print("***** Args *****")
    print(args)


# Generated at 2022-06-24 14:09:41.071476
# Unit test for function parseOpts
def test_parseOpts():
    opts_parsed = parseOpts(['-U', 'foo', '-P', 'bar'])
    assert opts_parsed[1].username == 'foo'
    assert opts_parsed[1].password == 'bar'

#def parseOpts(overrideArguments=None):

# Generated at 2022-06-24 14:09:44.366634
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    return doctest.testmod(parseOpts)

if __name__ == '__main__':
    sys.exit(test_parseOpts())

# Generated at 2022-06-24 14:09:51.183535
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['--no-check-certificate', '--no-playlist', '--', 'some_file_or_url'])

    assert opts[0].parser.get_prog_name() == 'youtube-dl'

    assert opts[1].check_certificate == False
    assert opts[1].playliststart == 1
    assert opts[1].playlistend == 0
    assert opts[2] == ['some_file_or_url']

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-24 14:09:53.171150
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-o', '/dev/null', 'youtubeurl'])[1]
    assert opts.outtmpl == '/dev/null'



# Generated at 2022-06-24 14:09:58.585810
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unittest1', '-P', 'unittest2', '-v', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'unittest1', '-U not working'
    assert opts.password == 'unittest2', '-P not working'
    assert opts.verbose == True, '-v not working'
    assert args[0] == 'https://www.youtube.com/watch?v=BaW_jenozKc', 'URL fetching not working'


# Generated at 2022-06-24 14:09:59.796171
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts()

# Generated at 2022-06-24 14:10:11.675537
# Unit test for function parseOpts
def test_parseOpts():
    # Empty command line arguments
    parser, opts, args = parseOpts([])
    assert not args and not hasattr(opts, 'verbose')

    # Normal arguments
    parser, opts, args = parseOpts(['-f', '18', 'https://www.youtube.com/watch?v=BaW_jenozKc', '--no-check-certificate'])
    assert opts.usenetrc is False
    assert opts.password is None
    assert opts.username is None
    assert opts.outtmpl == '%(id)s.%(ext)s'
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.format == '18'
    assert opts.ratelimit is None
    assert opts.nooverwrites is False

# Generated at 2022-06-24 14:10:22.541270
# Unit test for function parseOpts
def test_parseOpts():
    import os.path
    import sys
    import re
    import tempfile
    import shutil
    # Set of cases when youtube-dl should print an error message
    # and exit with status 1

# Generated at 2022-06-24 14:10:29.528054
# Unit test for function parseOpts
def test_parseOpts():
    # The following needs to be None to enable doctest to compare with expected output
    # or we can set --verbose to enable debug output
    # youtube_dl.utils.std_headers["User-Agent"] = "TestCase/1.0"
    # youtube_dl.utils.std_headers["Cookie"] = "Test=case"
    from getpass import getuser
    from time import time
    import os
    import tempfile
    tempdir = tempfile.gettempdir()
    tempdir_normalized = os.path.normcase(tempdir)
    confdir = os.path.expanduser('~')
    if sys.platform == 'win32':
        confdir = os.path.join(confdir, 'Application Data')
        confdir = compat_expanduser(confdir)