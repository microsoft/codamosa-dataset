

# Generated at 2022-06-24 14:00:35.341929
# Unit test for function parseOpts
def test_parseOpts():
    from .compat import compat_shlex_quote
    from .downloader.common import FileDownloader
    for args in [
        ['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'],
        ['-f', 'bestvideo,bestaudio', '--merge-output-format', 'mkv'],
        ['-f', 'bestvideo,bestaudio/best', '--merge-output-format', 'mkv'],
        ['-f', 'bestvideo+bestaudio'],
        ['--list-extractors'],
        ['--extractor-descriptions'],
        ['--version'],
        ['--extractor-descriptions'],
    ]:
        opts = parseOpts(args)

# Generated at 2022-06-24 14:00:37.060458
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(["-g"])

# Generated at 2022-06-24 14:00:48.234772
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import is_py2

# Generated at 2022-06-24 14:00:59.823927
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-U', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36','-q','-f','137/139/best','https://www.youtube.com/watch?v=O4V7pjOvzGw'])

    assert(opts.proxy is None)
    assert(opts.ratelimit is None)
    assert(opts.retries == 10)
    assert(opts.buffersize == 1024)
    assert(opts.noresizebuffer is True)

# Generated at 2022-06-24 14:01:10.524302
# Unit test for function parseOpts
def test_parseOpts():
    def test(args, expected):
        opts = parseOpts(args.split())[1]
        opts_dict = vars(opts)
        for k, v in expected.items():
            assert opts_dict[k] == v, (k, opts_dict[k])


# Generated at 2022-06-24 14:01:20.234414
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-U', 'Mozilla', '-f', '18/22/37', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'Mozilla'
    assert opts.password == None
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.verbose == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == ['18', '22', '37']

# Generated at 2022-06-24 14:01:25.892290
# Unit test for function parseOpts
def test_parseOpts():
    # Run once
    config = read_config()
    common.params = {}
    common.params.update(config)
    common.params.update(params)
    params = common.params

    # A hack to fix a problem when we run tests from Windows command line
    if not sys.argv[0]:
        import os.path
        sys.argv[0] = os.path.abspath('.')
        params['cachedir'] = None
    parser, opts, args = parseOpts(params)
    return parser, opts, args

# Generated at 2022-06-24 14:01:28.528392
# Unit test for function parseOpts
def test_parseOpts():
    # patch sys.argv with some default options
    sys.argv = ['youtube-dl', '--no-warnings', '-v']
    _parseOpts()


# Generated at 2022-06-24 14:01:37.911511
# Unit test for function parseOpts
def test_parseOpts():
    def test(cmdline, expected):
        m, opts, args = parseOpts(cmdline.split())
        assert opts.username == expected['username']
        assert opts.password == expected['password']
        assert opts.volatile_passwords == expected['volatile_passwords']

    test('--username abc --password xyz', {'username': 'abc', 'password': 'xyz', 'volatile_passwords': False})
    test('--volatile-passwords --username abc --password xyz', {'username': 'abc', 'password': 'xyz', 'volatile_passwords': True})
    test('--volatile-passwords --username abc', {'username': 'abc', 'password': None, 'volatile_passwords': True})

# Generated at 2022-06-24 14:01:45.743300
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.version import __version__ as ydl_version
    from youtube_dl.utils import DateRange

    if sys.version_info < (3,):
        return

    class _FakeOptions(object):
        pass

    opts_in = _FakeOptions()
    opts_in.username = 'user'
    opts_in.password = 'p@ss'
    opts_in.twofactor = '2fa'
    opts_in.videopassword = 'videopass'

    opts_out = _FakeOptions()
    opts_out.username = 'user'
    opts_out.usenetrc = True
    opts_out.videopassword = 'videopass'


# Generated at 2022-06-24 14:01:49.278809
# Unit test for function parseOpts
def test_parseOpts():
    parser = parseOpts()[0]
    for opt in parser.option_list:
        if opt.dest:
            assert hasattr(parser.values, opt.dest)



# Generated at 2022-06-24 14:01:58.397856
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    if sys.version_info >= (3,):
        from io import TextIOWrapper
        # http://bugs.python.org/issue12779 on Python 3
        # create a dummy stringio object as TextIOWrapper does not have buffer interface
        buf = StringIO('')
        sys.stdout = TextIOWrapper(buf, encoding='utf-8')
    _, opt = parseOpts(['-q'])
    assert opt.quiet
    _, opt = parseOpts(['-o%(id)s'])
    assert opt.outtmpl == '%(id)s', repr(opt.outtmpl)
    _, opt = parseOpts(['--restrict-filenames'])
    assert opt.restrictfilenames
    _, opt = parseOpt

# Generated at 2022-06-24 14:02:07.530554
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(overrideArguments=['-v', '-u', 'user', '-p', 'pass',
        '--no-color', '--batch-file', '-', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.nocolor is True
    assert opts.batchfile == '-'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']



# Generated at 2022-06-24 14:02:12.750702
# Unit test for function parseOpts
def test_parseOpts():
    try:
        opt = parseOpts(['-U', '--username', 'user', '--password', 'pass', 'arg'])[1]
        print(opt)
        assert False
    except SystemExit as e:
        assert e.code == 0

    try:
        parseOpts(['--get-username'])
        assert False
    except SystemExit as e:
        assert e.code == 1

    if sys.version_info < (3,):
        try:
            parseOpts(['--encoding', 'non-ascii-encoding\xe9'])
            assert False
        except SystemExit as e:
            assert e.code == 2

# Generated at 2022-06-24 14:02:23.105196
# Unit test for function parseOpts

# Generated at 2022-06-24 14:02:30.136327
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv as sys_argv
    sys_argv[1:] = ['-i','--username','--password','--']

    parser, opts, args = parseOpts([])
    assert len(parser.option_groups) == 20
    assert opts.username is None
    assert opts.password is None
    assert args == []

    parser, opts, args = parseOpts(['-i','--username','name','--password','pass','--'])
    assert opts.username == 'name'
    assert opts.password == 'pass'
    assert args == []

    parser, opts, args = parseOpts(['-i','--username','name','--password','pass','--', 'test1', 'test2'])
    assert opts.username == 'name'

# Generated at 2022-06-24 14:02:36.415995
# Unit test for function parseOpts
def test_parseOpts():
    def assertParse(opts, args, conf):
        parser, opts, args = parseOpts(overrideArguments=conf)
        assert opts == opts
        assert args == args
    assertParse({
        'usenetrc': True,
        'username': 'foo',
        'password': 'bar',
        'verbose': True}, ['lol'], [
        '--username', 'foo', '--password', 'bar', '--verbose', 'lol'])

# Generated at 2022-06-24 14:02:46.645975
# Unit test for function parseOpts
def test_parseOpts():
    def _parseOpts(argv):
        parser, opts, _ = parseOpts(argv)
        return opts

    assert _parseOpts([]) is not None
    assert _parseOpts([]) == _parseOpts([])
    assert _parseOpts([]) != _parseOpts(['--cookies=.yt-dl-cookie', '--no-check-certificate'])
    assert _parseOpts(['-h']) != _parseOpts(['-h', 'https://youtube.com/watch?v=BaW_jenozKc'])
    assert _parseOpts(['--version']) != _parseOpts([])
    assert _parseOpts(['--ignore-config']) != _parseOpts([])

# Generated at 2022-06-24 14:02:57.789609
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import prepend_extension
    from youtube_dl.YoutubeDL import YoutubeDL
    tmp_filename = '__test'

# Generated at 2022-06-24 14:03:05.196443
# Unit test for function parseOpts
def test_parseOpts():
    opts = optparse.Values()
    parser, opts, _ = parseOpts(['--dump-user-agent'])
    assert opts.dump_user_agent
    parser, opts, _ = parseOpts(['-U', 'foobar'])
    assert opts.user_agent == 'foobar'
    parser, opts, _ = parseOpts(['-4'])
    assert opts.proxy == '4'
    parser, opts, _ = parseOpts(['-4', '-6'])
    assert opts.proxy == ''
    parser, opts, _ = parseOpts(['-6'])
    assert opts.proxy == '6'
    parser, opts, _ = parseOpts(['--socket-timeout', '10'])
    assert opts.socket_timeout

# Generated at 2022-06-24 14:03:13.814842
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-F', 'myuser', 'mypass', '-F', 'myuser2', 'mypass2', '-F', 'myuser3', 'mypass3', '-a', 'mybatchfile', 'https://youtu.be/BaW_jenozKc'])
    assert opts.username == ['myuser', 'myuser2', 'myuser3']
    assert opts.password == ['mypass', 'mypass2', 'mypass3']
    assert opts.batchfile == 'mybatchfile'
    assert opts.nooverwrites == False
    assert args == ['https://youtu.be/BaW_jenozKc']

# In order to request account credentials to the user in a secure manner,
# we disable input buffering (see
# https://stack

# Generated at 2022-06-24 14:03:23.705389
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import mkstemp
    from os import fdopen
    import shutil
    # We use a temporary directory for user data, so that the tests do not interfere with the user's configuration
    conf_dir = None

# Generated at 2022-06-24 14:03:32.748798
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO

    class DummyOptionParser(object):
        def __init__(self, *args, **kwargs):
            pass

        def add_option(self, *args, **kwargs):
            pass

        def add_option_group(self, *args, **kwargs):
            pass

        def parse_args(self, values):
            return self, values

        def error(self, message):
            raise ValueError(message)

    customconf = b'''\
--username=PEPE
--password=P4S5W0RD
--verbose
--no-color
--dump-user-agent
    '''

    # Test with custom config file
    buf = StringIO(customconf)
    parser = DummyOptionParser()

# Generated at 2022-06-24 14:03:35.536732
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    save_argv = argv
    try:
        sys.argv = ['yt-dl', '--version']
        parser, _, _ = parseOpts()
        assert parser.get_prog_name() == 'yt-dl'
    finally:
        sys.argv = save_argv


# Generated at 2022-06-24 14:03:42.297388
# Unit test for function parseOpts
def test_parseOpts():
    import copy
    from yt_dl_config_helper_functions import compat_expanduser
    def opts_equal(o1, o2):
        o1.__dict__.pop('logger', None)
        o2.__dict__.pop('logger', None)
        return o1.__dict__ == o2.__dict__

    real_opts, _args = parseOpts()
    real_opts = copy.deepcopy(real_opts)

    def _test(overrideArguments, conf_str, conf_file, expect_assertion_error=False):
        try:
            opts, _args = parseOpts(overrideArguments)
            opts = copy.deepcopy(opts)
        except SystemExit:
            if not expect_assertion_error:
                raise

# Generated at 2022-06-24 14:03:47.425626
# Unit test for function parseOpts
def test_parseOpts():
    # Testing hidden options
    args = '--username user --password pass -i -p postprocessor --max-downloads 1'.split()
    parser, opts, args = parseOpts(args)
    assert(opts.username == 'user')
    assert(opts.password == 'pass')
    assert(opts.playliststart == 1)
    assert(opts.playlistend == -1)
    assert(opts.postprocessor_args == 'postprocessor')
    assert(opts.nooverwrites == False)
    assert(opts.max_downloads == 1)
    assert(opts.quiet == False)
    assert(opts.verbose == False)
    assert(opts.usenetrc == False)
    assert(opts.forcetitle == False)

# Generated at 2022-06-24 14:03:48.881841
# Unit test for function parseOpts
def test_parseOpts():
    import pprint
    pprint.pprint(parseOpts())



# Generated at 2022-06-24 14:03:59.527718
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts([])
    assert not opts.username
    assert not opts.password
    assert not opts.twofactor
    assert not opts.videopassword

    opts = parseOpts(['-u', 'foo', '-p', 'bar'])[1]
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert not opts.twofactor
    assert not opts.videopassword

    opts = parseOpts(['-2', 'foo', '-v', 'bar'])[1]
    assert not opts.username
    assert not opts.password
    assert opts.twofactor == 'foo'
    assert opts.videopassword == 'bar'


# Generated at 2022-06-24 14:04:08.616616
# Unit test for function parseOpts
def test_parseOpts():
    import os
    import sys
    argvBackup = sys.argv[:]
    try:
        sys.argv = ['youtube-dl', '--simulate', '--yes-playlist', '-v', 'http://xxxxxxxxxxxx']
        parser, opts, args = parseOpts()
        assert opts.simulate
        assert opts.yes_playlist
        assert opts.verbose
        assert args == ['http://xxxxxxxxxxxx']
        sys.argv = ['youtube-dl', 'http://xxxxxxxxxxxx']
        parser, opts, args = parseOpts()
        assert not opts.simulate
        assert not opts.yes_playlist
        assert not opts.verbose
        assert args == ['http://xxxxxxxxxxxx']
    finally:
        sys.argv = argvBackup
test_parseOpt

# Generated at 2022-06-24 14:04:15.679874
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-b', '--ignore-config', '-v', '-f', 'bestvideo+bestaudio', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.format_limit == 'bestvideo+bestaudio' and opts.ignoreconfig == True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    # Test args override config
    opts, args = parseOpts(['--hls-use-mpegts', '--force-generic-extractor', 'https://www.twitch.tv/videos/564388052'], '--hls-prefer-native')

# Generated at 2022-06-24 14:04:25.151068
# Unit test for function parseOpts
def test_parseOpts():
    """Test parseOpts function"""
    # Test with open-ended arguments
    parser, opts, args = parseOpts(['--get-title', 'blabla-bla'])
    assert opts.gettitle
    assert args == ['blabla-bla']
    parser, opts, args = parseOpts(['--get-id', 'blabla-bla'])
    assert not opts.usenetrc
    assert not opts.password
    assert not opts.username
    assert opts.getid
    assert args == ['blabla-bla']
    parser, opts, args = parseOpts(['--get-url', 'blabla-bla'])
    assert opts.geturl
    assert args == ['blabla-bla']
    parser, opts, args

# Generated at 2022-06-24 14:04:35.473402
# Unit test for function parseOpts
def test_parseOpts():
    # execute: python youtube_dl/YoutubeDL.py --dump-user-agent
    from optparse import OptionParser

# Generated at 2022-06-24 14:04:47.019385
# Unit test for function parseOpts
def test_parseOpts():
    try:
        import argparse
    except ImportError:
        argparse = None
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.utils import unescapeHTML

    def compat_shlex_quote(s):
        return s.replace("\\", "\\\\").replace("'", "\\'")

    def compat_shlex_unquote(s):
        return s.replace("\\'", "'").replace("\\\\", "\\")

    def parametrize(s):
        return compat_shlex_split(s, posix=False)

    def test_shlex_quote_unquote(arg, quoted):
        assert compat_shlex_quote(arg) == quoted
        assert compat_shlex_unquote(quoted) == arg


# Generated at 2022-06-24 14:04:51.133389
# Unit test for function parseOpts
def test_parseOpts():
    try:
        inputs = [None]
        inputs.append(['-c', '--username', 'user', '--password', 'pass'])
        inputs.append(['--config-location', '/path/to/youtube-dl.conf'])
        for inp in inputs:
            print("Testing with input: " + str(inp))
            parser, opts, args = parseOpts(inp)
            assert isinstance(parser, optparse.OptionParser)
            assert isinstance(opts, optparse.Values)
            assert isinstance(args, list)
    except Exception as e:
        print(str(e))
        raise


# Generated at 2022-06-24 14:04:52.214797
# Unit test for function parseOpts
def test_parseOpts():
    main(args=['-U'])



# Generated at 2022-06-24 14:04:56.746985
# Unit test for function parseOpts
def test_parseOpts():
    # Print options at verbose level
    overrideArguments = ['--verbose']
    parser, opts, args = parseOpts(overrideArguments)

    # Print debug output at debug level
    from __main__ import cmd_version
    cmd_version(['--verbose'])
    cmd_version(['--debug'])


# Generated at 2022-06-24 14:04:59.007270
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-h'])
    assert len(args) == 0
# argument printing functions

# Generated at 2022-06-24 14:05:10.044989
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import doctest
    reload(sys)
    sys.setdefaultencoding('UTF8')
    doctest.testmod()

    parser, opts, args = parseOpts([])
    assert opts.verbose == False

    parser, opts, args = parseOpts(['-v', '--dump-user-agent'])
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-v', '-v', '--dump-user-agent'])
    assert opts.verbose == 3

    parser, opts, args = parseOpts(['-q'])
    assert opts.quiet == True

    parser, opts, args = parseOpts(['--dump-intermediate-pages'])
    assert opts.dump_intermediate_pages == True



# Generated at 2022-06-24 14:05:13.282640
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '-f', 'best', '-a'])
    assert opts.verbose == True
    assert opts.format == 'best'
    assert opts.batchfile == '-'
    assert len(args) == 0


# Generated at 2022-06-24 14:05:22.762874
# Unit test for function parseOpts
def test_parseOpts():
    """
    Unit test for function parseOpts, it checks if the right
    arguments are being parsed and if the right exceptions are
    being raised.
    """

    try:
        parseOpts(['-U', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0'])
    except (optparse.OptionError, TypeError) as err:
        raise Exception('Attribute User Agent not properly set')

    overrides = ['--username', 'test', '--no-call-home']
    parser, opts, args = parseOpts(overrides)
    if opts.username != 'test' or opts.call_home != False:
        raise Exception('Commandline override is not working')

    # TODO: test for values instead of

# Generated at 2022-06-24 14:05:30.604869
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    # TODO
    parser, opts, args = parseOpts(['-U', 'UnitTestUserAgent'])
    assert opts.user_agent == 'UnitTestUserAgent'

    parser, opts, args = parseOpts(['--dump-user-agent'])
    assert opts.dump_user_agent

    parser, opts, args = parseOpts(['--list-extractors'])
    assert opts.list_extractors

    parser, opts, args = parseOpts(['--extractor-descriptions'])
    assert opts.print_extractor_descriptions

    parser, opts, args = parseOpts(['-h'])
    assert opts.help

    parser, opts, args = parseOpts(['--version'])
   

# Generated at 2022-06-24 14:05:41.884160
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    outtmpl = opts.outtmpl
    if outtmpl != None:
        if not (outtmpl.find('%(title)s') >= 0 or outtmpl.find('%(id)s') >= 0 or outtmpl.find('%(uploader)s') >= 0 or outtmpl.find('%(autonumber)s') >= 0):
            parser.error('You must specify either --title, --id, --uploader or --autonumber in the output filename template. Read the man page for more information.')
        if outtmpl.find('%(') >= 0:
            print('WARNING: %s %s' % (outtmpl.find('%('),outtmpl.find(')s')), file=sys.stderr)

# Generated at 2022-06-24 14:05:52.085235
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    """
    Check if the various options are correctly parsed.

    In order for this test to be trusted, all the option groups present
    in the call to parseOpts() should be unit tested.
    """

    parser, opts, _ = parseOpts(['--output', 'output', '-v'])
    assert opts.outtmpl == 'output', 'the -o option is not correctly parsed'
    assert opts.verbose == True, 'the -v option is not correctly parsed'

    # Test -U option
    parser, opts, args = parseOpts(['--update'])
    assert opts.update_self
    assert opts.noplaylist is True
    assert opts.ignoreerrors is True
    assert opts.usenetrc is True

   

# Generated at 2022-06-24 14:06:01.599228
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts([])[1]

    assert(opts.usenetrc is False)
    assert(opts.username == None)
    assert(opts.password == None)
    assert(opts.verbose is False)
    assert(opts.quiet is False)
    assert(opts.simulate is False)
    assert(opts.format == None)
    assert(opts.outtmpl == None)
    assert(opts.ignoreerrors is False)
    assert(opts.forceurl is False)
    assert(opts.forcetitle is False)
    assert(opts.forcesubtitle is False)
    assert(opts.forceduration is False)
    assert(opts.forcejson is False)
    assert(opts.dump_single_json is False)
   

# Generated at 2022-06-24 14:06:08.457777
# Unit test for function parseOpts
def test_parseOpts():
    test_opts = ['-f', 'bestvideo+bestaudio']
    parser, opts, _ = parseOpts(overrideArguments=test_opts)
    assert opts.format == ['bestvideo+bestaudio']
    _, opts, _ = parseOpts(overrideArguments=['--format=bestvideo+bestaudio'])
    assert opts.format == ['bestvideo+bestaudio']
    _, opts, _ = parseOpts(overrideArguments=['-f', 'bestvideo+bestaudio'])
    assert opts.format == ['bestvideo+bestaudio']
    test_opts = ['-f', 'bestvideo+bestaudio/best', '--format', 'bestaudio']
    _, opts, _ = parseOpts(overrideArguments=test_opts)
    assert opt

# Generated at 2022-06-24 14:06:16.128821
# Unit test for function parseOpts
def test_parseOpts():
    # youtube-dl 'https://www.youtube.com/watch?v=BaW_jenozKc -f 22'
    parser, opts, _ = parseOpts(overrideArguments=['https://www.youtube.com/watch?v=BaW_jenozKc', '-f', '22'])
    # youtube-dl 'https://www.youtube.com/watch?v=BaW_jenozKc -f 22'
    assert opts.format == '22'

# Merge the results of using parseOpts with the last character of filename

# Generated at 2022-06-24 14:06:26.929492
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import prepend_extension
    opts = AttrDict()

    def test_prepend_extension():
        """Test prepend_extension()."""
        assert prepend_extension('foo.mp3', 'part') == 'foo.part.mp3'
        assert prepend_extension('foo.part.mp3', 'part') == 'foo.part.part.mp3'
        assert prepend_extension('foo', 'part') == 'foo.part'

    def parseOpts(args):
        """Parse command-line options."""
        parser, opts, _ = parseOpts_(args)
        return opts


# Generated at 2022-06-24 14:06:37.116775
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: Refactor this test to use unittest.mock or similar
    # Python 3.3 or newer preferred
    import subprocess
    print('Testing parseOpts')

    # Test default values
    opts = parseOpts()[1]
    assert opts.ratelimit == '0'
    assert opts.nooverwrites is False
    assert opts.playliststart == 1
    assert opts.playlistend == 0
    assert opts.playlist_items is None
    assert opts.matchtitle == None
    assert opts.rejecttitle == None
    assert opts.matchfilter is None
    assert opts.rejectfilter is None
    assert opts.sleepinterval == None
    assert opts.min_sleep_interval == None
    assert opts.max_sleep_interval

# Generated at 2022-06-24 14:06:49.069403
# Unit test for function parseOpts
def test_parseOpts():
    from testClass import TestClass
    from testClass import os


    # Before patching
    ret = parseOpts()
    assert ret.klass == optparse.OptionParser
    assert ret.opts.extractaudio == False
    assert ret.opts.quiet == False
    assert ret.opts.simulate == False

    # Patching
    with TestClass.patch('sys.argv', ['youtube-dl', '-x', '-q', '--simulate', 'https://www.youtube.com/watch?v=BaW_jenozKc']):
        ret = parseOpts()
        assert ret.klass == optparse.OptionParser
        assert ret.opts.extractaudio == True
        assert ret.opts.quiet == True
        assert ret.opts.simulate == True

# Generated at 2022-06-24 14:07:00.277801
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = {}, []
    def get_opts(args, overrideArguments=None):
        parser, opts, args = parseOpts(overrideArguments=overrideArguments)
        return opts

    # Test -h, short and long versions
    assert ['-h'] != []
    opts = get_opts(['-h'])
    assert opts.help == True
    opts = get_opts(['--help'])
    assert opts.help == True

    # Test -U, short and long versions
    assert ['-U'] != []
    opts = get_opts(['--update'])
    assert opts.update_self == True

    # Test -v, short and long versions
    assert ['-v'] != []
    assert ['--version'] != []
    opt

# Generated at 2022-06-24 14:07:08.354466
# Unit test for function parseOpts
def test_parseOpts():
    # test with empty args
    parser, opts, args = parseOpts(None)
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    # opts.usetitle is a short name for opts.literal
    assert opts.usetitle is False
    assert opts.literal is False
    assert opts.autonumber is False
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.format is None
    assert opts.dump_user_agent is False
    assert opts.list_extractors is False
    assert opts.youtube_include_dash_manifest is True
    # opts.us

# Generated at 2022-06-24 14:07:13.427563
# Unit test for function parseOpts
def test_parseOpts():
    """
    A unit test for function parseOpts.
    """
    opts, args = parseOpts(['-h'])
    assert opts.help
    opts, args = parseOpts(['-v'])
    assert opts.verbose
    opts, args = parseOpts([])
    assert not opts.verbose

# Generated at 2022-06-24 14:07:20.434461
# Unit test for function parseOpts
def test_parseOpts():
    # Test without any arguments
    _, opts, args = parseOpts(None)
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert args == []

    # Test with arguments
    _, opts, args = parseOpts(['-o', 'my file.%(ext)s', 'test'])
    assert opts.outtmpl == 'my file.%(ext)s'
    assert args == ['test']


# Generated at 2022-06-24 14:07:25.887381
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _args = parseOpts()

    assert opts.outtmpl == '%(id)s'
    assert opts.format == '22'
    assert opts.playliststart == 1
    assert opts.playlistend == 10
    assert opts.match_filter(
        'http://www.youtube.com/watch?v=BaW_jenozKc',
        {
            'id': 'BaW_jenozKc',
            'upload_date': '20121002',
            'uploader_id': 'HG2FNxxz t',
        })



# Generated at 2022-06-24 14:07:33.248640
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts({})
    assert opts.ratelimit == '0.0'
    assert opts.username == None
    opts, args = parseOpts({'username':'value'})
    assert opts.username == 'value'
    opts, args = parseOpts({'ratelimit':'1.0'})
    assert opts.ratelimit == '1.0'
    return 'OK'
# parseOpts()



# Generated at 2022-06-24 14:07:43.139951
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import format_bytes
    from youtube_dl.extractor import gen_extractors


# Generated at 2022-06-24 14:07:53.191488
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-u', 'user', '-p', 'passwd', 'url'])
    assert(opts.username == 'user')
    assert(opts.password == 'passwd')
    assert(args == ['url'])

    # -u and -p separated
    parser, opts, args = parseOpts(['-u', 'user', 'url', '-p', 'passwd'])
    assert(opts.username == 'user')
    assert(opts.password == 'passwd')
    assert(args == ['url'])

    # --username and --password separated
    parser, opts, args = parseOpts(['--username', 'user', 'url', '--password', 'passwd'])
    assert(opts.username == 'user')

# Generated at 2022-06-24 14:07:57.342277
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    assert parseOpts([encodeArgument('--output=%(uploader)s')])[1].outtmpl == '%(uploader)s'


# Generated at 2022-06-24 14:08:06.518228
# Unit test for function parseOpts
def test_parseOpts():
    test_opts = [
        '--username',
        'user',
        '--password',
        'pass',
        'http://example.com/'
    ]
    parser, opts, args = parseOpts(test_opts)
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.outtmpl == '%(id)s.%(ext)s'
    assert args == ['http://example.com/']
    test_opts.append('--output')
    test_opts.append('test.%(ext)s')
    parser, opts, args = parseOpts(test_opts)
    assert opts.username == 'user'
    assert opts.password == 'pass'

# Generated at 2022-06-24 14:08:16.844280
# Unit test for function parseOpts
def test_parseOpts():
    # Function `parseOpts` output is designed to be inmutable by the caller
    # This means that we cannot directly use the `deepcopy` assertion (it
    # doesn't work at least in python 2.6)
    def deepcopy_mutable(obj, memo=None):
        if memo is None:
            memo = {}
        if isinstance(obj, dict):
            return dict(
                (deepcopy_mutable(k, memo), deepcopy_mutable(v, memo))
                for k, v in obj.items())
        if isinstance(obj, list):
            return list(deepcopy_mutable(i, memo) for i in obj)
        return obj


# Generated at 2022-06-24 14:08:27.244150
# Unit test for function parseOpts
def test_parseOpts():
    args = ['-f', '137+251', 'https://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(overrideArguments=args)
    assert opts.format == '137+251', 'Unable to parse -f FORMAT'
    assert len(args) == 1, 'Expected one argument left'
    assert args[0] == 'https://www.youtube.com/watch?v=BaW_jenozKc', 'Invalid argument'
    assert opts.dump_user_agent, '--dump-user-agent should be enabled by default'
    assert not opts.list_extractors, '--list-extractors should not be enabled by default'

# Generated at 2022-06-24 14:08:29.554406
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.username == None
    assert opts.password == None
    assert opts.usenetrc == False
    assert opts.version == False
    assert opts.help == False


# Generated at 2022-06-24 14:08:41.464771
# Unit test for function parseOpts
def test_parseOpts():
    output = StringIO()

# Generated at 2022-06-24 14:08:49.075066
# Unit test for function parseOpts
def test_parseOpts():
    # None is incompatible with sys.argv
    assert parseOpts(None)[2] == []
    assert parseOpts(None)[1].username == None
    assert parseOpts(None)[1].usernames == []
    # Override arguments
    assert len(parseOpts(['-u', 'test'])[2]) == 0
    assert parseOpts(['-u', 'test'])[1].username == 'test'
    assert parseOpts(['-u', 'test'])[1].usernames == ['test']
    # Multi-byte arguments
    assert parseOpts(['-t', b'\xe4\xb8\xad\xe6\x96\x87'])[1].usernames == [b'\xe4\xb8\xad\xe6\x96\x87']


# Generated at 2022-06-24 14:08:56.354097
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert isinstance(opts.username, str)
    assert isinstance(opts.password, str)
    assert isinstance(opts.twofactor, str)
    assert isinstance(opts.videopassword, str)
    assert isinstance(opts.ap_mso, str)
    assert isinstance(opts.ap_username, str)
    assert isinstance(opts.ap_password, str)


# Generated at 2022-06-24 14:09:07.823995
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from argparse import ArgumentParser
    from pprint import pprint

    text = StringIO()
    _opts, _args = parseOpts(['-v'], _write_string=text.write)
    assert _opts.verbose
    assert not text.getvalue()

    text = StringIO()
    _opts, _args = parseOpts(['--dump-user-agent'], _write_string=text.write)
    assert _opts.dump_user_agent
    assert text.getvalue().startswith('youtube-dl')

    tparser = ArgumentParser(prog='test_parseOpts')
    _opts, _args = parseOpts(['--proxy', '127.0.0.1:8000'], tparser, _write_string=text.write)


# Generated at 2022-06-24 14:09:18.081559
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.videopassword is None

    parser, opts, args = parseOpts(['--username', 'user', '--password', 'pass'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.twofactor is None
    assert opts.videopassword is None

    parser, opts, args = parseOpts(['--username', 'user', '--password', 'pass', '--twofactor', 'two'])
    assert opts.username == 'user'
    assert opts.password == 'pass'

# Generated at 2022-06-24 14:09:28.883779
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info < (3,):
        return
    if not os.path.isdir(__TEST_DATA_DIR__):
        sys.exit('Please run from the repo root')
    args = ['--output=%(uploader)s/%(id)s.%(ext)s', '--ignore-config', '--simulate', 'https://www.youtube.com/watch?v=BaW_jenozKc', 'https://www.youtube.com/watch?v=yXIMA8nQveM']
    parser, opts, args = parseOpts(args)
    assert opts.simulate
    assert opts.outtmpl == '%(uploader)s/%(id)s.%(ext)s'
    assert opts.forceurl
    assert opts.forc

# Generated at 2022-06-24 14:09:40.446455
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.forceurl
    assert opts.forcetitle
    assert opts.simulate
    assert opts.format
    assert opts.geturl
    assert opts.gettitle
    assert opts.getid
    assert opts.getthumb
    assert opts.getdescription
    assert opts.getfilename
    assert opts.getformat
    assert opts.usr_agent
    assert opts.referer
    assert opts.dump_user_agent
    assert opts.list_extractors
    assert opts.extractor_descriptions
    assert opts.proxy
    assert opts.noplaylist
    assert opts.age_limit
    assert opts.videopassword
    assert opts.no_warn

# Generated at 2022-06-24 14:09:50.725093
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([
        b'--max-filesize', b'20m'])[2] == [b'--max-filesize', b'20m']
# }}}

# {{{ options
youtube_dl.utils.abort_work_on_signals()

parser, opts, args = parseOpts()

if opts.fixup != 'detect_or_warn':
    if opts.fixup == 'warn':
        opts.fixup = 'warn'
    else:
        opts.fixup = None

if not opts.format:
    opts.format = None

opts.usenetrc = config.get_config_value('usenetrc', opts.usenetrc)


# Generated at 2022-06-24 14:09:57.658830
# Unit test for function parseOpts

# Generated at 2022-06-24 14:09:58.714417
# Unit test for function parseOpts
def test_parseOpts():
    return parseOpts


# Generated at 2022-06-24 14:10:09.729069
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.playliststart <= opts.playlistend, "playlist start number must be less or equal to end number"
    assert opts.matchtitle == None or opts.matchtitle.startswith('^'), "matchtitle must start with '^'"
    assert opts.rejecttitle == None or opts.rejecttitle.startswith('^'), "rejecttitle must start with '^'"
    assert opts.min_views < opts.max_views, "min_views must be smaller than max_views"
    assert opts.min_upload_date <= opts.max_upload_date, "min_upload_date must be less or equal to max_upload_date"

# Generated at 2022-06-24 14:10:18.408693
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import formats_to_dummy_infos_dicts
    from .extractor.youtube import YoutubeIE


# Generated at 2022-06-24 14:10:29.669899
# Unit test for function parseOpts
def test_parseOpts():
    def _conf(opts, *args):
        conf = ['--%s' % opt for opt in opts.split(' ')]
        for arg in args:
            conf += ['--', arg]
        return conf

    parser, opts, args = parseOpts(
        _conf('--ignore-config', '-i', 'foo'))
    assert opts.ignore_errors
    assert opts.usenetrc
    assert args == ['foo']

    parser, opts, args = parseOpts(
        _conf('--verbose', '--ignore-config', '-i', 'foo'))
    assert opts.verbose
    assert opts.ignore_errors
    assert opts.usenetrc
    assert args == ['foo']
