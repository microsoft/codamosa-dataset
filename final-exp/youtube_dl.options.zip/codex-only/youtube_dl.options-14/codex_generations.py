

# Generated at 2022-06-24 14:00:35.963159
# Unit test for function parseOpts
def test_parseOpts():
    from types import SimpleNamespace
    from collections import namedtuple
    from sys import argv as sys_argv
    from os import environ
    from tempfile import gettempdir
    from shutil import which

    def _opt_eq(opt1, opt2):
        if isinstance(opt1, bytes) or isinstance(opt2, bytes):
            return opt1 == opt2
        elif isinstance(opt1, str) or isinstance(opt2, str):
            return opt1 == opt2
        else:
            return opt1 == opt2


# Generated at 2022-06-24 14:00:47.702428
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert (opts.version == False)
    assert (opts.verbose == False)
    assert (opts.quiet == False)
    assert (opts.simulate == False)
    assert (opts.geturl == False)
    assert (opts.gettitle == False)
    assert (opts.getid == False)
    assert (opts.getthumb == False)
    assert (opts.getdescription == False)
    assert (opts.getfilename == False)
    assert (opts.getformat == False)
    assert (opts.username == None)
    assert (opts.password == None)
    assert (opts.twofactor == None)
    assert (opts.videopassword == None)

# Generated at 2022-06-24 14:00:59.327066
# Unit test for function parseOpts
def test_parseOpts():
    #normal usage
    (parser, opts, args) = parseOpts([])
    assert opts.verbose == False
    assert opts.usenetrc == False
    assert opts.forceduration == False
    assert opts.forcetitle == None
    assert opts.forceurl == None
    assert opts.forceratelimit == 0
    assert opts.forceformat == None
    assert opts.writeautomaticsub == False
    assert opts.allsubtitles == False
    assert opts.skip_download == False
    assert opts.simulate == False
    assert opts.format == None
    assert opts.listformats == None
    assert opts.matchtitle == None
    assert opts.rejecttitle == None
    assert opts.max_downloads == None
    assert opts

# Generated at 2022-06-24 14:01:01.266075
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    run(parser, opts, args)


# Generated at 2022-06-24 14:01:11.586532
# Unit test for function parseOpts
def test_parseOpts():
    old_stdout = sys.stdout
    stdout = io.StringIO()
    setattr(sys, 'stdout', stdout)
    # Tests --help
    try:
        parseOpts(['--help'])
    except SystemExit as e:
        if e.code != 0:
            raise
    # Tests --version
    try:
        parseOpts(['--version'])
    except SystemExit as e:
        if e.code != 0:
            raise
    # Tests -h
    try:
        parseOpts(['-h'])
    except SystemExit as e:
        if e.code != 0:
            raise
    # Tests -v
    try:
        parseOpts(['-v'])
    except SystemExit as e:
        if e.code != 0:
            raise


# Generated at 2022-06-24 14:01:21.141580
# Unit test for function parseOpts
def test_parseOpts():

    cmd_line_input_1 = '-x --audio-format mp3 https://www.youtube.com/watch?v=BaW_jenozKc'
    cmd_line_input_2 = '--extract-audio --audio-format mp3 https://www.youtube.com/watch?v=BaW_jenozKc'
    cmd_line_input_3 = '--extract-audio --audio-format mp3'
    cmd_line_input_4 = '--extract-audio --audio-format mp3 --audio-quality 1'
    cmd_line_input_5 = "-x -f bestaudio --audio-format mp3 https://www.youtube.com/watch?v=BaW_jenozKc"

# Generated at 2022-06-24 14:01:27.936214
# Unit test for function parseOpts
def test_parseOpts():
    # This test is mostly to prevent regressions, as optparse testing is tricky
    from pytest import raises
    parser, opts, args = parseOpts([])
    assert not args
    assert not opts.usenetrc
    assert not opts.verbose
    assert opts.default_search == 'auto'
    assert opts.nooverwrites
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors
    assert opts.forceurl
    assert opts.forcethumbnail
    assert not opts.forceduration
    assert opts.sleep_interval == 300

    parser, opts, args = parseOpts(['--username', 'foo', '--password', 'bar'])

# Generated at 2022-06-24 14:01:29.534959
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert args == ['url']
    assert opts.username == 'u'
    assert opts.password == 'p'


# Generated at 2022-06-24 14:01:34.823482
# Unit test for function parseOpts

# Generated at 2022-06-24 14:01:41.997758
# Unit test for function parseOpts
def test_parseOpts():
    def _YDL(args, opts=None):
        cfg, url, playlist = parseOpts(args, opts=opts)
        return (cfg.__dict__, url, playlist.__dict__)

    def _assert(args, expected_cfg, expected_url, expected_playlist):
        cfg, url, playlist = _YDL(args)
        assert cfg == expected_cfg
        assert url == expected_url
        assert playlist == expected_playlist


# Generated at 2022-06-24 14:01:52.827098
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    from .utils import encodeArgument
    args = [
        encodeArgument(a) for a in
        ['--username', 'foo', '--password', 'bar', '--',
         'https://vimeo.com/110454214', 'https://www.youtube.com/watch?v=BaW_jenozKc']
    ]
    orig_args, sys.argv = sys.argv, [sys.argv[0]] + args
    try:
        parser, opts, args = parseOpts()
    finally:
        sys.argv = orig_args
    assert args == ['https://vimeo.com/110454214', 'https://www.youtube.com/watch?v=BaW_jenozKc']
    assert opts.username == 'foo'

# Generated at 2022-06-24 14:02:01.630631
# Unit test for function parseOpts
def test_parseOpts():
    from .update import update_self
    from .version import __version__


# Generated at 2022-06-24 14:02:03.282790
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    if opts.get_url is True:
        print(args)


# Generated at 2022-06-24 14:02:05.145563
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: write
    pass



# Generated at 2022-06-24 14:02:13.506231
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-F', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc is False
    assert opts.username is None
    assert opts.password is None
    assert opts.video_password is None
    assert opts.ap_mso is None
    assert opts.ap_username is None
    assert opts.ap_password is None
    # FIXME: assert opts.videoformat == ['38', '37', '46', '22', '45', '35', '44', '34', '18', '43', '6', '5', '36', '17', '13']

# Generated at 2022-06-24 14:02:23.206521
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.compat import compat_kwargs
    from youtube_dl.utils import DownloadContext
    from youtube_dl.downloader.http import HttpFD
    from collections import namedtuple
    from tempfile import NamedTemporaryFile
    import inspect

    def get_func_args(funcToCheck):
        '''
        Returns the function argument names (and defaults, if any) of function funcToCheck as a tuple (args, defaults)
        '''
        args, _, _, defaults = inspect.getargspec(funcToCheck)
        return (args, defaults)

    expected_args, _ = get_func_args(parseOpts)
    assert expected_args == ['overrideArguments']

    p, o, a = parseOpts()
    assert o.verbose == False
    assert o.update_self == False

# Generated at 2022-06-24 14:02:30.210334
# Unit test for function parseOpts
def test_parseOpts():
    def get_proxy(opts):
        return opts.proxy

    def set_proxy(opts, value):
        opts.proxy = value

    def get_verbosity(opts):
        return opts.verbose

    def set_verbosity(opts, value):
        opts.verbose = value

    def get_usenetrc(opts):
        return opts.usenetrc

    def set_usenetrc(opts, value):
        opts.usenetrc = value

    def get_nooverwrites(opts):
        return opts.nooverwrites

    def set_nooverwrites(opts, value):
        opts.nooverwrites = value

    def get_cookiefile(opts):
        return opts.cookief

# Generated at 2022-06-24 14:02:41.810233
# Unit test for function parseOpts
def test_parseOpts():
    try:
        # Initialize the module
        sys.modules['__main__'].__dict__.clear()
        import youtube_dl
        sys.modules['__main__'].parseOpts = youtube_dl.parseOpts
        sys.modules['__main__'].FileDownloader = youtube_dl.FileDownloader
    except:
        print('import failed')
        sys.exit(1)
    # Create the default downloader
    ydl = youtube_dl.YoutubeDL({})
    # Now run parseOpts which should not cause any error
    parser, opts, args = parseOpts(ydl, [])
    # Check that at least version has correct value
    try:
        assert(opts.version == youtube_dl.version.__version__)
    except:
        print('parseOpts failed')
       

# Generated at 2022-06-24 14:02:53.300643
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-h'])
    opts.logger.critical('test')
    #parser, opts, args = parseOpts(['-v', '--dump-user-agent'])
    #print (args, opts)

#_HIDDEN_OPTIONS = ['username', 'password', 'twofactor', 'videopassword']
#
#
#def _hide_login_info(opts):
#    """ Hides the login info for safe logging of arguments """
#    for key in _HIDDEN_OPTIONS:
#        opts = [opt if not opt.startswith('--' + key + '=') else '--%s=******' % key for opt in opts]
#    return opts


# Generated at 2022-06-24 14:02:56.249352
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    print(doctest.testmod(parseOpts))
## end of functions used by the main program


# Generated at 2022-06-24 14:03:06.863205
# Unit test for function parseOpts
def test_parseOpts():
    default_opts = ['--username=user', '--password=pass', '--twofactor=code']
    def do_test(args, override_args=None):
        opts = parseOpts(override_arguments=override_args)[1]
        for a in args:
            if not hasattr(opts, a):
                raise Exception('%r not in options' % a)
        for a in default_opts:
            if hasattr(opts, a.lstrip('-')):
                raise Exception('%r unexpectedly in options' % a)
    do_test(['verbose'])
    do_test(['usenetrc'])
    do_test(['username'])
    do_test(['password'])
    do_test(['twofactor'])

    # config-location

# Generated at 2022-06-24 14:03:10.995605
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-F', '--no-mtime', '--no-check-certificate'])[1:] == (
        OptParseDefaultValues({'format': 'best', 'updatetime': False, 'nocheckcertificate': True}),
        [])



# Generated at 2022-06-24 14:03:20.520506
# Unit test for function parseOpts
def test_parseOpts():
    from nose.tools import raises
    from .compat import compat_expanduser

    conf_file = './test/test_conf.conf'
    conf_content = '--default-search isohunt --dump-user-agent'
    open(conf_file, 'w').write(conf_content)

# Generated at 2022-06-24 14:03:26.845930
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-g', '--get-url'])
    assert len(args) == 0
    assert opts.geturl
    assert opts.simulate

    opts, args = parseOpts(['-g', '--get-url', '-e', 'youtube', 'http://vimeo.com/user:pw@youtube.com/watch?v=BaW_jenozKc'])
    assert len(args) == 1
    assert opts.geturl
    assert opts.extract_flat is True
    assert args[0] == 'http://vimeo.com/user:pw@youtube.com/watch?v=BaW_jenozKc'


# Generated at 2022-06-24 14:03:35.672781
# Unit test for function parseOpts
def test_parseOpts():
    """
    Testing the parseOpts() function
    """
    class DummyExitException(Exception):
        """
        Dummy class for simulating sys.exit()
        """

        pass

    def dummy_exit(self, message):
        """
        Dummy function for simulating sys.exit()
        """
        raise DummyExitException(message)

    parser, opts, args = parseOpts()

    if not isinstance(opts, object):

        raise TypeError("The function parseOpts() should return a tuple of an object and two other objects")

    if not isinstance(parser, object):

        raise TypeError("The argument parser should be an object")

    if not isinstance(opts.prefer_ffmpeg, bool):

        raise TypeError("The attribute opts.prefer_ffmpeg should be a boolean")

   

# Generated at 2022-06-24 14:03:43.620881
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.ratelimit is None
    assert opts.retries is None
    assert opts.buffersize is None
    # Test for issue #1501
    assert opts.proxy == '127.0.0.1:1234'
    assert opts.noplaylist is False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.nooverwrites is False
    assert opts.nopart is False
    assert opts.updatetime is True
    assert opts.writedescription is False



# Generated at 2022-06-24 14:03:46.460335
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv as __sys_argv
    __sys_argv += ['--usenetrc', '-v', '--verbose']
    from youtube_dl.YoutubeDL import YoutubeDL
    try:
        YoutubeDL(__sys_argv).params
    finally:
        __sys_argv.pop(); __sys_argv.pop(); __sys_argv.pop()

# Generated at 2022-06-24 14:03:49.939869
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-c', '--no-check-certificate', '--username', 'foo', '--password', 'bar', '--extract-audio'])[1]
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.getpass == False
    assert opts.nocheckcertificate == True
    assert opts.extractaudio == True



# Generated at 2022-06-24 14:03:52.186298
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert len(opts) > 10 and len(args) > 0

# Generated at 2022-06-24 14:03:54.481870
# Unit test for function parseOpts
def test_parseOpts():
    assert('youtube-dl --test-option "test value"'.split() == parseOpts('--test-option "test value"')[2])


# Generated at 2022-06-24 14:04:00.097784
# Unit test for function parseOpts
def test_parseOpts():
    print('--test-parseOpts')
    parser, opts, args = parseOpts([])
    assert opts.usernames == []
    assert opts.passwords == []
    assert opts.videopasswords == []

    parser, opts, args = parseOpts(['--username', 'foo'])
    assert opts.usernames == ['foo']
    assert opts.passwords == []
    assert opts.videopasswords == []

    parser, opts, args = parseOpts(['--username', 'foo',
            '--password', 'bar',
            '--videopassword', 'blah'])
    assert opts.usernames == ['foo']
    assert opts.passwords == ['bar']

# Generated at 2022-06-24 14:04:04.327387
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parseOpts(args):
        parser, opts, args = parseOpts(args)

# Generated at 2022-06-24 14:04:06.089379
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.cvsignore

# Generated at 2022-06-24 14:04:10.212563
# Unit test for function parseOpts
def test_parseOpts():
    ut_config = """
    --proxy 127.0.0.1:8080
    --username=alice
    --password=bob
    """
    parser, opts, _ = parseOpts(shlex.split(ut_config))
    assert opts.username == 'alice'
    assert opts.password == 'bob'
    assert opts.proxy == '127.0.0.1:8080'
    return True
test_parseOpts()


# Generated at 2022-06-24 14:04:16.759809
# Unit test for function parseOpts
def test_parseOpts():

    class DummyParser:
        def __init__(self, opts):
            self.opts = opts

        def add_option(self, *w, **kw):
            pass

        def add_option_group(self, *w, **kw):
            pass

        def parse_args(self, args):
            return self.opts, []

        def error(self, message):
            raise Exception(message)

    class ConfigTest:
        def __init__(self, case, **kw):
            self.case = case
            self.expected = kw

        def __call__(self, parser, args):
            parser, opts, args = parseOpts(parser, args)
            assert opts.username == self.expected.get('username')
            assert opts.password == self.expected.get('password')


# Generated at 2022-06-24 14:04:22.296164
# Unit test for function parseOpts
def test_parseOpts():
    (p, o, a) = parseOpts(['-u', 'testuser', '-p', 'testpass'])
    assert o.username == 'testuser'
    assert o.password == 'testpass'
    assert o.usenetrc is False
    (p, o, a) = parseOpts(['--usenetrc'])
    assert o.usenetrc is True


# Generated at 2022-06-24 14:04:24.212788
# Unit test for function parseOpts
def test_parseOpts():
    from test import parseOpts_test
    parseOpts_test.test_parseOpts()

# Generated at 2022-06-24 14:04:35.460461
# Unit test for function parseOpts

# Generated at 2022-06-24 14:04:39.995009
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts( overrideArguments=[
    '-v',
    '-o', 'outtmpl.txt'
    ])
    assert opts.verbose
    assert opts.outtmpl == 'outtmpl.txt'

#test_parseOpts()



# Generated at 2022-06-24 14:04:50.477734
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.user_agent == 'Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0'
    assert opts.verbose == True
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

test_parseOpts()



# Generated at 2022-06-24 14:05:02.302995
# Unit test for function parseOpts

# Generated at 2022-06-24 14:05:12.816798
# Unit test for function parseOpts
def test_parseOpts():
    if not sys.gettrace():
        parser, opts, args = parseOpts()
        print (opts, args)
        # This should work:
        # --proxy 127.0.0.1:8087 --get-url --get-title --get-id --get-thumbnail --get-description --get-filename --get-format --no-progress --console-title --no-warnings --get-duration --get-filename --get-format --get-start-time
        # This should not work:
        # --proxy 127.0.0.1:8087 --get-url --get-title --get-id --get-thumbnail --get-description --get-filename --get-format --no-progress --console-title --no-warnings --get-duration --get-filename --get-format --get-start-time -e
       

# Generated at 2022-06-24 14:05:22.085090
# Unit test for function parseOpts
def test_parseOpts():
    opts1, args1 = parseOpts(['--write-sub',
                              '--sub-format', 'srt',
                              '--sub-lang', 'en',
                              '--sub-lang', 'pt',
                              '--username', 'user',
                              '--password', 'pass',
                              '--verbose',
                              'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts1.writesubtitles
    assert opts1.subtitlesformat == 'srt'
    assert opts1.subtitleslang == ['en', 'pt']
    assert opts1.username == 'user'
    assert opts1.password == 'pass'
    assert opts1.verbose

    opts2, args2 = parseOpts

# Generated at 2022-06-24 14:05:30.269620
# Unit test for function parseOpts

# Generated at 2022-06-24 14:05:41.603044
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.getproxies == {}

# Generated at 2022-06-24 14:05:51.769075
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    argv = ['youtube-dl']
    parser, opts, args = parseOpts()
    args = ['https://www.youtube.com/watch?v=BaW_jenozKc']
    opts, args = parser.parse_args(args)
    assert opts.quiet is False
    assert opts.verbose is False
    assert opts.dump_user_agent is False
    assert opts.list_extractors is False
    assert opts.extractor_descriptions is False
    assert opts.no_warnings is False
    assert opts.help is False
    assert opts.simulate is False
    assert opts.format is None
    assert opts.listformats is False
    assert opts.merge_output_format is 'mkv'

# Generated at 2022-06-24 14:06:01.446559
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import OptionValueError
    from sys import argv
    os.chdir(os.path.dirname(__file__))
    # test for default values
    assert parseOpts()[1].verbose == False
    assert parseOpts()[1].quiet == False
    assert parseOpts()[1].simulate == False
    assert parseOpts()[1].format == None
    assert parseOpts()[1].format_limit == None
    # test for verbose value
    assert parseOpts(['-v'])[1].verbose == True
    # test for quiet value
    assert parseOpts(['-q'])[1].quiet == True
    # test for simulation value
    assert parseOpts(['-s'])[1].simulate == True
    # test for format value
    assert parseOpt

# Generated at 2022-06-24 14:06:08.947501
# Unit test for function parseOpts
def test_parseOpts():
    import subprocess

    # Test file-like object that can return arbitrary number of lines
    class TestFile(object):
        def __init__(self, lines):
            self.lines = lines
            self.lineno = 0

        def readline(self):
            if self.lineno < len(self.lines):
                line = self.lines[self.lineno]
                self.lineno += 1
                return line
            return ''

        def __iter__(self):
            return self

        def __next__(self):
            return self.next()

        def next(self):
            if self.lineno < len(self.lines):
                line = self.lines[self.lineno]
                self.lineno += 1
                return line
            raise StopIteration

    # Test

# Generated at 2022-06-24 14:06:15.446464
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["--verbose", "-i", "https://www.youtube.com/watch?v=9bZkp7q19f0"])
    assert opts.verbose
    assert opts.ignoreerrors
    assert opts.simulate
    assert opts.verbose
    assert opts.usenetrc
    assert opts.verbose_level == 2
    assert not opts.no_warnings
    assert not opts.quiet
    assert args == [u'https://www.youtube.com/watch?v=9bZkp7q19f0']


# Generated at 2022-06-24 14:06:26.893812
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    def test(args, **kw):
        args = [a.encode('utf-8') if isinstance(a, unicode) else a for a in args]
        sys.argv[1:] = args
        _, opts, _ = parseOpts()
        for k, v in kw.items():
            assert getattr(opts, k) == v
        if args:
            assert opts.verbose
            assert opts.noprogress

    test([])
    test(['-v'], verbose=True)
    test(['-q'], quiet=True)
    test(['-4'], ipv4=True)
    test(['-6'], ipv6=True)
    test(['--no-check-certificate'], nocheckcertificate=True)


# Generated at 2022-06-24 14:06:37.117118
# Unit test for function parseOpts
def test_parseOpts():
    # Test basic option parsing
    parser, opts, args = parseOpts(["-v"])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.write_all_thumbnails == False

    # Test long option parsing
    parser, opts, args = parseOpts(["--write-all-thumbnails"])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.write_all_thumbnails == True

    # Test short option parsing
    parser, opts, args = parseOpts(["-iq"])
    assert opts.verbose == False
    assert opts.quiet == True
    assert opts.write_all_thumbnails == False

    # Test argument parsing

# Generated at 2022-06-24 14:06:49.115144
# Unit test for function parseOpts
def test_parseOpts():

    parser, opts, args = parseOpts(['-x'])
    assert opts.extractaudio

    parser, opts, args = parseOpts(['-i'])
    assert opts.simulate

    parser, opts, args = parseOpts(['--dump-user-agent'])
    assert opts.dump_user_agent

    parser, opts, args = parseOpts(['--list-extractors'])
    assert opts.list_extractors

    parser, opts, args = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.username is None
    assert opts.password is None
    assert opts.videopassword is None # See https

# Generated at 2022-06-24 14:07:00.323511
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    parser, opts, args = parseOpts(['-h'])
    parser, opts, args = parseOpts(['--dump-user-agent'])
    parser, opts, args = parseOpts(['--help-format'])
    parser, opts, args = parseOpts(['--help-extractor'])
    parser, opts, args = parseOpts(['--version'])
    parser, opts, args = parseOpts(['--ignore-config'])
    parser, opts, args = parseOpts(['--dump-intermediate-pages'])
    parser, opts, args = parseOpts(['--encoding', 'utf-8'])

# Generated at 2022-06-24 14:07:08.391043
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv, exit

    def run(overrideArguments=[], expectedReturnCode=0):
        try:
            parseOpts(overrideArguments)
        except SystemExit as err:
            if err.code != expectedReturnCode:
                raise Exception('Expected return code %i, found %i' % (expectedReturnCode, err.code))

    # Empty arguments
    run()

    # --no-warnings
    run(['--no-warnings'])
    run(['--dump-user-agent'])
    run(['--version'])
    run(['-U', 'test'])
    run(['--ignore-config'])
    run(['--no-check-certificate'])
    run(['--encoding', 'utf-8'])

# Generated at 2022-06-24 14:07:14.125116
# Unit test for function parseOpts
def test_parseOpts():
    try:
        import types
        assert isinstance(parseOpts, types.FunctionType)
    except:
        print('*** parseOpts is not a function!')
        raise
    try:
        assert parseOpts()[0].description
    except:
        print('*** parseOpts()[0].description is not a string')
        raise
# Unit test: parseOpts
test_parseOpts()


# Generated at 2022-06-24 14:07:24.824770
# Unit test for function parseOpts
def test_parseOpts():
    # Set up the parser, run the function
    parser, opts, args = parseOpts(['-f', 'MP4', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    # Make sure the right values were parsed
    assert opts.format == 'MP4'
    assert opts.usenetrc == False
    assert args[0] == 'https://www.youtube.com/watch?v=BaW_jenozKc'
    # Run the function with invalid values, check for the expected error
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        parser, opts, args = parseOpts(['-vvvv'])
    assert pytest_wrapped_e.type == SystemExit

# Generated at 2022-06-24 14:07:33.587487
# Unit test for function parseOpts

# Generated at 2022-06-24 14:07:43.558647
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.version import __version__
    from youtube_dl.compat import str_to_bytes
    import os
    import tempfile
    def write_file(filename, content):
        f = open(filename, 'wb')
        if not isinstance(content, bytes):
            content = str_to_bytes(content)
        f.write(content)
        f.close()
    #
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-24 14:07:53.909061
# Unit test for function parseOpts
def test_parseOpts():
    import collections
    import unittest

    class FakeOption(object):
        def __init__(self):
            self.have_setval = False
            self.have_setattr = False
        def __setattr__(self, key, val):
            if key in self.__dict__:
                self.have_setattr = True
            object.__setattr__(self, key, val)
        def set_val(self, val):
            self.have_setval = True
        def reset_val(self):
            self.have_setval = False

    class Container(object):
        def __init__(self):
            self.__dict__['fake'] = FakeOption()

    class FakeParser(object):
        def __init__(self):
            self.option_groups = []
            self.option = collections

# Generated at 2022-06-24 14:08:04.821648
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.compat import parse
    parser, opts, args = parseOpts(['-i', '--no-check-certificate', 'rtsp://example.org/PATH'])
    assert opts.ignoreerrors is True
    assert opts.verbose is False
    assert opts.extractaudio is False
    assert opts.username is None
    assert opts.password is None
    assert opts.noplaylist is False
    assert opts.usenetrc is True
    assert opts.verbose is False
    assert args == ['rtsp://example.org/PATH']
    assert opts.listformats is False
    assert opts.nooverwrites is False
    assert opts.retries == 10
    assert opts.ratelimit == '0'

# Generated at 2022-06-24 14:08:15.759822
# Unit test for function parseOpts
def test_parseOpts():
    test_parser = optparse.OptionParser()
    test_parser.add_option('-a', '--aaaaa', action='store_true', default=False)
    test_parser.add_option('-b', '--bbbbb', action='store_true', default=False)
    test_parser.add_option('-c', '--ccccc', action='store_true', default=False)
    test_parser.add_option('-d', '--ddddd', action='store_true', default=False)
    test_parser.add_option('-e', '--eeeee', action='store_true', default=False)
    opts1, args1 = test_parser.parse_args(['-a', '-b', '-c', '-d'])

# Generated at 2022-06-24 14:08:21.737707
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-f', '18', 'http://www.youtube.com/watch?v=W9n__qIO-QY', '-g'])
    assert 'youtube' in opts.downloader
    assert opts.format == '18'
    assert opts.listformats == True
    assert args == ['http://www.youtube.com/watch?v=W9n__qIO-QY']
test_parseOpts()

# Generated at 2022-06-24 14:08:24.918918
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'Mozilla/5.0'])
    assert opts.user_agent == 'Mozilla/5.0'


# Generated at 2022-06-24 14:08:33.486473
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    orig_argv = sys.argv[:]
    sys.argv = [sys.argv[0], '-c', '--format', 'mp4', '-f', '137+140', 'pl', 'http://example.com/video1']
    parser, opts, _ = parseOpts()
    assert opts.format == 'mp4' and opts.prefer_free_formats is False and opts.format_specific_options == {'137': None, '140': None}
    sys.argv = [sys.argv[0], '-c', '--format', 'best', '-f', 'best[height<=?2560]', 'pl', 'http://example.com/video1']
    parser, opts, _ = parseOpts()

# Generated at 2022-06-24 14:08:44.108483
# Unit test for function parseOpts
def test_parseOpts():
    # This function tests the parseOpts function
    # It is called if you run youtube_dl with the --test-parse-opts
    # command line argument.
    from sys import exit

    if len(sys.argv) == 1:
        sys.argv.append('--test-parse-opts')

    try:
        parser, opts, args = parseOpts()
    except SystemExit:
        exit(1)

    # print opts
    print('opts:')
    maxlen = max([len(option) for option in opts.__dict__])
    fmt = u'%-' + str(maxlen) + 's = %s'
    for option in sorted(opts.__dict__):
        print(fmt % (option, opts.__dict__[option]))

    print()

   

# Generated at 2022-06-24 14:08:54.781639
# Unit test for function parseOpts
def test_parseOpts():
    def check_parse(args, expected):
        parser, opts, args = parseOpts(args)
        assert opts.username == expected[0]
        assert opts.password == expected[1]

    # parseOpts shouldn't generalize on \w
    check_parse(['--username', 'u:name'], ['u:name', None])
    check_parse(['--username', 'u:name', '--password', 'pass:word'], ['u:name', 'pass:word'])


# DEBUG should go before being imported by other components

if __name__ == '__main__':
    # Add a default handler for the root logger
    # otherwise it would print to stderr instead of stdout
    logging.getLogger().addHandler(logging.StreamHandler())

    # Compatibility
    # YouTubeDL.py

# Generated at 2022-06-24 14:09:03.371162
# Unit test for function parseOpts
def test_parseOpts():
    args=(
        '-U "Mozilla/5.0 (iPd; CPU OS 5_1_1 like Mac OS X) AppleWerbKit/534.46 (KHTML, like Gecko) Versio/5.1 Mobile/9B206 Safari/7534.48.3"',
        '--username="test"',
        '--password="123456"',
        '--verbose'
        )
    parser, opts, args=parseOpts(args)
    print(opts)
    assert('--verbose' in args)
#test_parseOpts()


# Generated at 2022-06-24 14:09:11.286173
# Unit test for function parseOpts
def test_parseOpts():
    def test(args, expected):
        parser, opts, _args = parseOpts(args)
        assert vars(opts) == vars(expected)
    from types import SimpleNamespace

# Generated at 2022-06-24 14:09:20.110328
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts([])
    assert opts.usenetrc == True
    assert opts.username == None
    assert opts.password == None

    (parser, opts, args) = parseOpts(['--no-netrc'])
    assert opts.usenetrc == False

    (parser, opts, args) = parseOpts(['--username', 'user1', '--password', 'pass'])
    assert opts.username == 'user1' and opts.password == 'pass'
    assert opts.usenetrc == False

    (parser, opts, args) = parseOpts(['--no-netrc', '--username', 'user1', '--password', 'pass'])
    assert opts.username == 'user1' and opts.password

# Generated at 2022-06-24 14:09:26.261466
# Unit test for function parseOpts
def test_parseOpts():
    try:
        _ = parseOpts([])
        _ = parseOpts(['-h'])
    except SystemExit:
        pass
    else:
        raise Exception('parseOpts with -h did not exit')

    assert parseOpts(['--ignore-config'])[1].ignoreconfig
    assert parseOpts(['--config-location=/some/path/youtube-dl.conf'])[1].config_location == '/some/path/youtube-dl.conf'

# }}}


# {{{ Main function


# Generated at 2022-06-24 14:09:34.707413
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-i'])[1].ignoreerrors == True
    assert parseOpts(['-r','2'])[1].retries == 2
    assert parseOpts(['--max-filesize','20M'])[1].max_filesize == 20971520
    assert parseOpts(['-c'])[1].continue_dl == True
    assert parseOpts(['--no-part'])[1].nopart == True
    assert parseOpts(['-w'])[1].nooverwrites == True
    assert parseOpts(['--no-mtime'])[1].updatetime == False
    assert parseOpts(['-b'])[1].ratelimit == '0'
    assert parseOpts(['-t','3'])[1].test == True
   

# Generated at 2022-06-24 14:09:45.408389
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose

#def parse_qs(url):
#    """
#    Parse the query string of a URL and return it as a dict.
#    In case a parameter has no value, None is used as value.
#    """
#    query = urlparse.urlparse(url).query
#    if sys.version_info >= (3, 3):
#        return urlparse.parse_qs(query, keep_blank_values=True)
#    else:
#        return dict([(k, v if len(v) > 1 else v[0]) for k, v in urlparse.parse_qs(query, True).items()])

#def

# Generated at 2022-06-24 14:09:51.378663
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = ['youtube-dl']
    parser, opts, args = parseOpts()
    assert opts.ratelimit == '1.5M'
    assert opts.min_filesize == 50*1024
    assert opts.max_filesize == 500*1024
    assert opts.playliststart == 1
    assert opts.playlistend == 4
    assert opts.min_views == 0
    assert opts.max_views == 1000000
    assert opts.date == (None, None)
    assert opts.match_filter == ['!is_live']
    assert opts.age_limit == 0
    assert opts.download_archive == None
    assert opts.cookiefile == None
    assert opts.nooverwrites == False
    assert opts.forcetitle == False

# Generated at 2022-06-24 14:09:59.971214
# Unit test for function parseOpts

# Generated at 2022-06-24 14:10:11.881096
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from .compat import bytes

    parser, opts, args = parseOpts(
        ['--sleep-interval', '10', '--min-sleep-interval', '5',
         'https://www.google.com/'])
    assert opts.sleep_interval == 10
    assert opts.min_sleep_interval == 5
    assert opts.extract_flat == 'in_playlist'
    assert opts.match_filter == 'all'
    assert opts.date == DateRange(None)
    assert opts.skip_download is False
    assert opts.playlist_reverse is False
    assert opts.playlist_items is None
    assert opts.playlist_start is None
    assert opts.playlist_end is None

# Generated at 2022-06-24 14:10:22.846905
# Unit test for function parseOpts
def test_parseOpts():
    # Test: --username and --password
    assert parseOpts(['-u', 'foo', '-p', 'bar']).username == 'foo'
    assert parseOpts(['--username', 'foo', '--password', 'bar']).password == 'bar'
    # Test: --format
    assert parseOpts(['-f', '18']).format == '18'
    assert parseOpts(['--format', '18']).format == '18'
    assert parseOpts(['-f', '34/18/5']).format == '34/18/5'
    assert parseOpts(['--format', '34/18/5']).format == '34/18/5'
    assert parseOpts(['-f', 'mp4']).format == 'mp4'

# Generated at 2022-06-24 14:10:26.576744
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(overrideArguments=['-v', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert 'https://www.youtube.com/watch?v=BaW_jenozKc' in args
    test_parseOpts.__doc__ = parseOpts.__doc__
