

# Generated at 2022-06-24 14:00:32.754963
# Unit test for function parseOpts

# Generated at 2022-06-24 14:00:39.904983
# Unit test for function parseOpts
def test_parseOpts():
    usage_str = u'Usage: foo [options] <url>'
    parser, opts, _ = parseOpts([
        '-v', '--no-progress', '--ignore-config',
        'http://fake/url', '--another-opt', '-v'
    ])
    assert parser.usage == usage_str
    assert opts.verbose == 2
    assert opts.progress_with_newline == False
    assert '--ignore-config' in sys.argv
    assert 'http://fake/url' in sys.argv
    assert opts.another_opt == True

# Parse command line arguments
# returns (parser, opts, args)

# Generated at 2022-06-24 14:00:51.541043
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'testuser', '-P', 'testpass', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'testuser'
    assert opts.password == 'testpass'
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'
    assert opts.usenetrc == False

    parser, opts, args = parseOpts(['--max-downloads=1', 'youtube.com/watch?v=BaW_jenozKc', 'youtube.com/watch?v=BaW_jenozKc'])
    assert opts.max_downloads == 1

    parser, opts, args = parseOpts

# Generated at 2022-06-24 14:00:52.899478
# Unit test for function parseOpts
def test_parseOpts():
    return parseOpts(['-h'])

# Generated at 2022-06-24 14:01:02.024585
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import os
    import re

    def ok(opts):
        if not opts.verbose:
            read_data_stream.empty()
        return re.search(r'\bOK\b', read_data_stream.read()) is not None

    from .compat import compat_expanduser

    test_env = {
        'user_conf': compat_expanduser('~/.config/youtube-dl/config'),
    }

    def test_cmdline(cmdline, user_conf=None, expected={}):
        if user_conf is None:
            user_conf = []
        else:
            user_conf = [user_conf.replace('%(user_conf)s', test_env['user_conf'])]
        cmdline = [cmdline]

# Generated at 2022-06-24 14:01:13.150540
# Unit test for function parseOpts
def test_parseOpts():
    # Test help
    with captured_output() as (out, err):
        try:
            parseOpts(['-h'])
        except SystemExit as inst:
            pass
    output = out.getvalue().strip()
    assert re.search(r'usage: [\w.]+ \[OPTIONS\] URL [URL\] \[\.\.\.\]', output)
    assert re.search(r'General Options:', output)
    assert re.search(r'Network Options:', output)
    assert re.search(r'Geo Restriction:', output)
    assert re.search(r'Video Format Options:', output)
    assert re.search(r'Subtitle Options:', output)
    assert re.search(r'Authentication Options:', output)

# Generated at 2022-06-24 14:01:18.823464
# Unit test for function parseOpts
def test_parseOpts():
    opts, _ = parseOpts([])
    assert opts.outtmpl == '%(id)s.%(ext)s'
    opts, _ = parseOpts(['--simulate'])
    assert opts.simulate
    opts, _ = parseOpts(['--sleep-interval=120'])
    assert opts.sleep_interval == 120


# Retrieve information about the given URL.

# Generated at 2022-06-24 14:01:22.808884
# Unit test for function parseOpts
def test_parseOpts():
    try:
        _, opts, _ = parseOpts()

        if opts.verbose:
            print('[debug] Opts: %r' % opts)
            print('[debug] Args: %r' % args)

    except (OptionValueError, TypeError) as err:
        sys.exit(err)



# Generated at 2022-06-24 14:01:27.259849
# Unit test for function parseOpts
def test_parseOpts():
    args = ['-i', '--username', 'user', '--password', 'pass']
    parser, opts, _args = parseOpts(args)
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert not opts.cookies


# Generated at 2022-06-24 14:01:36.976256
# Unit test for function parseOpts
def test_parseOpts():
    argv = ['-f', 'best',
            '--verbose',
            '--dump-intermediate-pages',
            '--write-pages',
            '--write-info-json',
            '--write-description',
            '--write-thumbnail',
            '--extract-audio',
            '--external-downloader', 'curl',
            '--external-downloader-args', '-L -o "%(id)s.%(ext)s"',
            'https://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(argv)
    assert opts.verbose
    assert opts.dump_intermediate_pages
    assert opts.write_pages
    assert opts.writeinfojson
    assert opts.writ

# Generated at 2022-06-24 14:01:44.020325
# Unit test for function parseOpts
def test_parseOpts():
    # Testing for single and double hyphen args
    for args in ['--username Tester --password Password --verbose --simulate --skip-download'.split(),
                 '-u Tester -p Password -v --simulate --skip-download'.split()]:
        parser, opts, args = parseOpts(args=args)
        assert opts.username == 'Tester'
        assert opts.password == 'Password'
        assert opts.verbose
        assert opts.simulate
        assert opts.skip_download

    # Testing for single and double hyphen options
    for args in ['--sleep-interval 15'.split(),
                 '-s 15'.split()]:
        parser, opts, args = parseOpts(args=args)
        assert opts.sleep_interval == 15

    # Testing for --option value syntax


# Generated at 2022-06-24 14:01:54.397538
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([
        '-i', '-o', 'ok.%(ext)s', 'http://example.org/a', '"http://example.org/b?x=1&y=2"',
        'http://example.org/c', '的'])
    assert opts.retries == 10
    assert opts.verbose == False
    assert opts.no_warnings == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False

# Generated at 2022-06-24 14:01:55.310545
# Unit test for function parseOpts
def test_parseOpts():
    # pass
    pass



# Generated at 2022-06-24 14:02:03.698838
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = [sys.argv[0], '-v']
    p, o, a = parseOpts()
    assert p.get_prog_name() == 'youtube-dl'
    assert o.verbose == True
    assert a == []

    sys.argv = [sys.argv[0], '-v', '--username', 'foobar', '--password', 'bazqux']
    p, o, a = parseOpts()
    assert p.get_prog_name() == 'youtube-dl'
    assert o.verbose == True
    assert a == []
    assert o.username == 'foobar'
    assert o.password == 'bazqux'


# Generated at 2022-06-24 14:02:13.069963
# Unit test for function parseOpts
def test_parseOpts():
    #########
    ### Unit test for function parseOpts
    #########
    parser, opts, args = parseArgs()
    assertParserError(parser, '--dump-user-agent')
    assertParserResult(parser, '-U "Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0"', {'dump-user-agent': True, 'user_agent': u'"Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0"'})
    assertParserResult(parser, '--no-check-certificate -i', {'no_check_certificate': True, 'ignoreerrors': True})

###
# Main program
###


# Generated at 2022-06-24 14:02:21.471740
# Unit test for function parseOpts
def test_parseOpts():
    testargs = ["-f", "best[height<=?1080][protocol^=https]", "https://www.youtube.com/watch?v=--AkPuwv2h4", "--yes-playlist"]
    parser, opts, args = parseOpts(testargs)
    assert args == ['https://www.youtube.com/watch?v=--AkPuwv2h4']
    assert opts.format == "best[height<=?1080][protocol^=https]"
    assert opts.yes_playlist

if __name__ == "__main__":
    test_parseOpts()


# Generated at 2022-06-24 14:02:28.081522
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parseOpts(args, overrides):
        parser, opts, args = parseOpts(overrides)
        if args != []:
            return 'Expected empty args list, got %r' % args
        if opts.verbose:
            if not overrides:
                return '--verbose must not be set if no overrides are given'
            if '-v' not in overrides and '--verbose' not in overrides:
                return '--verbose must not be set if no overrides are given'
        for opt_name, opt_value in vars(opts).items():
            if opt_name not in overrides:
                continue
            if opt_name == 'logtostderr':
                if isinstance(opt_value, bool):
                    continue

# Generated at 2022-06-24 14:02:39.850433
# Unit test for function parseOpts
def test_parseOpts():
    video_url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    argv = ['--verbose','--format','mp3','-o','tmp/%(title)s.%(ext)s', video_url]
    parser, opts, args = parseOpts({'proxy':'http://127.0.0.1:8080'})
    assert opts.proxy == 'http://127.0.0.1:8080'

    parser, opts, args = parseOpts()
    assert opts.proxy == None

    parser, opts, args = parseOpts(overrideArguments=argv)
    assert opts.proxy == None
    assert opts.proxy == None
    assert opts.format == 'mp3'

# Generated at 2022-06-24 14:02:48.496327
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(["-i"])
    assert(opts.ignoreerrors)
    assert(not opts.call_home)
    assert(not opts.usenetrc)
    assert(not opts.username)
    assert(not opts.password)
    assert(not opts.twofactor)
    assert(not opts.videopassword)
    assert(opts.ap_mso == '')
    assert(opts.ap_username == '')
    assert(opts.ap_password == '')
    assert(opts.usetitle)
    assert(opts.continuedl)
    assert(not opts.nooverwrites)
    assert(not opts.retries)
    assert(not opts.buffersize)

# Generated at 2022-06-24 14:02:59.598435
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == True
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.nooverwrites == False
    assert opts.continuedl == True
    assert opts.nopart == False
    assert opts.up

# Generated at 2022-06-24 14:03:10.815812
# Unit test for function parseOpts
def test_parseOpts():
    # Create a fake sys.argv[1:]
    sys.argv = ['youtube-dl']

    args = [
        'pl',
        'https://www.youtube.com/watch?v=eKFTSSKCzWA',
        'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        '--username', 'foouser',
        '--password', 'foopassword',
        '--proxy', '127.0.0.1:8118',
        '--format', 'bestvideo+bestaudio/best',
        '--ignore-config',
        '--verbose',
        '--no-check-certificate',
    ]
    parser, opts, args = parseOpts(args)
    assert opts.help is False
    assert opts

# Generated at 2022-06-24 14:03:20.400133
# Unit test for function parseOpts
def test_parseOpts():
    from .__main__ import parseOpts
    from .__main__ import parseOpts
    parser, opts, args = parseOpts([])
    assert opts is not None, 'parseOpts opts is None'
    assert args is not None, 'parseOpts args is None'
    parser, opts, args = parseOpts(['--extract-audio'])
    assert opts.get('extractaudio', False), 'parseOpts extractaudio is False'
    parser, opts, args = parseOpts(['--username=testuser', '--password=testpass'])
    assert opts.get('username', '') == 'testuser', 'parseOpts username is not testuser'
    assert opts.get('password', '') == 'testpass', 'parseOpts password is not testpass'
    parser,

# Generated at 2022-06-24 14:03:26.733038
# Unit test for function parseOpts
def test_parseOpts():
    '''
    Unit test for function parseOpts
    '''
    parser, opts, args = parseOpts([])
    assert opts.usenetrc is False
    assert opts.nocheckcertificate is False
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.no_warnings is False
    assert opts.simulate is False
    assert opts.dump_user_agent is False
    assert opts.dump_intermediate_pages is False
    assert opts.write_pages is False
    assert opts.print_traffic is False
    assert opts.call_home is True
    assert opts.noprogress is False
    assert opts.playliststart is 1
    assert opts.playlistend is 0
    assert opts.playlist

# Generated at 2022-06-24 14:03:35.572541
# Unit test for function parseOpts
def test_parseOpts():
    _config_filename = os.path.join(os.path.expanduser('~'), '.config', 'youtube-dl', 'config')
    config_check_content = '-o "/tmp/%(title)s.%(ext)s"'
    config_check_content_bak = '-i'


# Generated at 2022-06-24 14:03:42.350875
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.dump_intermediate_pages == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forceduration == False
    assert opts.forcefilename == False
    assert opt

# Generated at 2022-06-24 14:03:43.554798
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()

# --------------------------------------------------------------------------

# _sort_formats - Sorts formats by preference

# Generated at 2022-06-24 14:03:49.245395
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(
        ['--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc']
    )
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert len(args) == 1
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-24 14:03:59.772223
# Unit test for function parseOpts
def test_parseOpts():
    opts, _args = parseOpts(['--print-json', '--ignore-config', '-f', 'bestvideo[height<=?1080]+bestaudio/best[height<=?1080]'])
    assert opts.outtmpl == u'%(id)s'
    assert opts.format == ['bestvideo[height<=?1080]+bestaudio/best[height<=?1080]']

    opts, _args = parseOpts(['--format', 'bestvideo[height<=?1080]+bestaudio/best[height<=?1080]', '--yes-playlist', '--output', '%(id)s.%(ext)s'])
    assert opts.yes_playlist


# Generated at 2022-06-24 14:04:08.937367
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', '18/22/37/38', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == ['18/22/37/38']
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-f', '18', '-f', 'mp4', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == ['18', 'mp4']
    parser, opts, args = parseOpts(['-f', '+best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])


# Generated at 2022-06-24 14:04:14.198041
# Unit test for function parseOpts
def test_parseOpts():
    try:
        # Trigger detected error
        parseOpts(["--username", "user", "--password", "pass", "--username", "user2"])
    except (SystemExit, error.Error):
        pass
    else:
        raise

    try:
        # Trigger detected error
        parseOpts(["--no-check-certificate", "--verbose"])
    except (SystemExit, error.Error):
        pass
    else:
        raise

# Running unit tests
if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-24 14:04:18.450040
# Unit test for function parseOpts
def test_parseOpts():
    _, opts, _ = parseOpts()
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None

# Generated at 2022-06-24 14:04:25.818025
# Unit test for function parseOpts
def test_parseOpts():
    flags = ['--username=abc', '--password=def', '--usenetrc',
             '--video-password=ghi', '--netrc-optional']
    parsed_flags = list(map(str.strip, parseOpts(flags)[0].format_help().split('\n')))
    assert '--username ABC' in parsed_flags
    assert '--password DEF' in parsed_flags
    assert '--video-password GHI' in parsed_flags
    assert '-n  Use .netrc authentication data' in parsed_flags
    assert '-N     Deprecated, see --netrc-optional' not in parsed_flags
    assert '--netrc-optional' in parsed_flags


# Generated at 2022-06-24 14:04:36.202242
# Unit test for function parseOpts
def test_parseOpts():
    from .compat import PY2
    from .utils import encodeArgument
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert args == []
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose == True
    assert args == []
    parser, opts, args = parseOpts(['--verbose', '-i', '--'])
    assert opts.verbose == True
    assert opts.simulate == True
    assert opts.ignoreerrors == True
    if PY2:
        assert args == [encodeArgument('--')]
    else:
        assert args == ['--']

# Generated at 2022-06-24 14:04:38.952959
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print(parser)
    print(opts)
    print(args)
#test_parseOpts()


# Generated at 2022-06-24 14:04:50.733567
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import gen_extractor_classes
    for ie in gen_extractor_classes():
        if not ie.working():
            continue
        for t in ie._TEST:
            t = compat_urllib_parse_urlparse(t)
            if t.scheme not in ('http', 'https'):
                continue
            res = ie.suitable(t.url)
            if res is True:
                url = t.url
                break
            elif res is None:
                continue
        else:
            continue
        ydl = FakeYdl()
        ydl.params = {
            'username': 'test',
            'password': 'test',
            'twofactor': 'test',
            'videopassword': 'test',
        }

# Generated at 2022-06-24 14:04:55.202554
# Unit test for function parseOpts
def test_parseOpts():
    write_string('Testing parseOpts\n')

    assert parseOpts()[1].username == None
    assert parseOpts()[1].password == None
    assert parseOpts()[1].verbose == False
    assert parseOpts()[1].outtmpl == '%(id)s.%(ext)s'
    assert parseOpts()[1].simulate == False
    assert parseOpts()[1].format == None
    assert parseOpts()[1].format_limit == None
    assert parseOpts()[1].merge_output_format == None
    assert parseOpts()[1].no_color == False
    assert parseOpts()[1].retries == 10
    assert parseOpts()[1].continuedl == True
    assert parseOpts()[1].nopart == False


# Generated at 2022-06-24 14:05:04.935846
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])

    assert(opts.verbose == 1)

    parser, opts, args = parseOpts(['--no-verbose'])

    assert(opts.verbose == 0)

    parser, opts, args = parseOpts(['--verbose'])

    assert(opts.verbose == 2)

    def test_fix_file_separators():
        def ffs(inp, expected=None, expected_windows=None):
            if expected is None:
                expected = inp
            if expected_windows is None:
                expected_windows = expected

            out = fix_file_separators(inp)
            print(('{0} -> {1}'.format(inp, out)))


# Generated at 2022-06-24 14:05:14.689316
# Unit test for function parseOpts
def test_parseOpts():

    from tempfile import NamedTemporaryFile
    import atexit
    import os
    import shutil
    import sys

    def check_parseOpts(args, expected, message):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected, message

    def read_config(filename):
        with open(filename, 'rb') as f:
            return f.read().decode('utf-8')

    # Test --version
    try:
        parseOpts(['--version'])
        assert False, 'parseOpts did not exit'
    except SystemExit:
        assert True

    # Test parsing

# Generated at 2022-06-24 14:05:20.371431
# Unit test for function parseOpts
def test_parseOpts():
    def test(args, expected_urls, expected_opts):
        parser, opts, urls = parseOpts(args)
        expected_urls = expected_urls.split()
        expected_opts = expected_opts.split()
        assert urls == expected_urls
        assert sorted(vars(opts).keys()) == sorted(expected_opts)

    test('-f 18 youtube-dl http://www.youtube.com/watch?v=W9n__Df5Z6k',
         'http://www.youtube.com/watch?v=W9n__Df5Z6k',
         'format format_limit youtube_include_dash_manifest write_description writeinfojson writeannotations')

# Generated at 2022-06-24 14:05:29.014564
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test'])
    assert opts.username == 'unit_test'
    assert opts.password == None
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.verbose == False
    assert opts.dump_user_agent == False
    assert opts.list_extractors == False
    assert opts.dump_interfaces == False
    assert opts.dump_json == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcedescription == False

# Generated at 2022-06-24 14:05:34.392827
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['--ignored', '--username=test', '--password=test', 'foo', 'bar']) == \
        parseOpts(['--ignored', '--username=test', '--password=test', 'foo', 'bar'], overrideArguments=['--username', 'foo', '--password', 'bar'])

# The actual downloader code

# Generated at 2022-06-24 14:05:45.181473
# Unit test for function parseOpts
def test_parseOpts():
    def check_conf(conf, expected):
        parser, opts, args = parseOpts({'test_parseOpts': True}, conf)
        got = dict((o.dest, getattr(opts, o.dest)) for o in parser.option_list)
        got['args'] = args
        assert expected == got
    check_conf(['-f', '23'],
        dict(format='23', args=[]))
    check_conf(['--format=24'],
        dict(format='24', args=[]))
    check_conf(['--format', '25'],
        dict(format='25', args=[]))
    check_conf(['--format', '25', '--'],
        dict(format='25', args=['--']))

# Generated at 2022-06-24 14:05:52.898341
# Unit test for function parseOpts
def test_parseOpts():
    from compat import is_win32

    import youtube_dl.YoutubeDL as YDL

    if is_win32():
        args = ['-o', r'C:\Users\...\Videos\%(title)s.%(ext)s']
    else:
        args = ['-o', '/Users/.../Videos/%(title)s.%(ext)s']
    opts = YDL().process_args(parseOpts(args)[1])
    assert 'outtmpl' in opts
    assert opts['outtmpl'] == args[1].replace('...', '<...>')

    if is_win32():
        args = ['--batch-file', r'C:\Users\...\text.txt']

# Generated at 2022-06-24 14:06:02.148730
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts([])
    assert opts.outtmpl.count('%') == 2, opts.outtmpl
    opts, args = parseOpts(['-o', '%(title)s.%(ext)s'])
    assert opts.outtmpl == '%(title)s.%(ext)s', opts.outtmpl
    opts, args = parseOpts(['-o', 'foo%(title)sbar.%(ext)s'])
    assert opts.outtmpl == 'foo%(title)sbar.%(ext)s', opts.outtmpl
    opts, args = parseOpts(['-o', 'foo.%(ext)s'])
    assert opts.outtmpl == 'foo.%(ext)s', opt

# Generated at 2022-06-24 14:06:05.771195
# Unit test for function parseOpts
def test_parseOpts():
    from unittest import TestCase
    from unittest.mock import Mock
    BaseTest = TestCase('__init__')
    parser = Mock()
    parseOpts(parser)
    parser.add_option_group.assert_called()

# Create and return an OpenerDirector for retrieving URLs.
#
# This uses the user's options to create a customized OpenerDirector
# with support for HTTP authentication, cookies, proxies, etc.

# Generated at 2022-06-24 14:06:06.590341
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 14:06:08.281715
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts()
    print ('opts = %s' % opts)
    print ('args = %s' % args)



# Generated at 2022-06-24 14:06:18.424043
# Unit test for function parseOpts
def test_parseOpts():
    write_string('Testing parseOpts\n')
    test_cases = [['--dump-user-agent'], ['--list-extractors'],
                  ['-F', 'http://youtube.com/watch?v=BaW_jenozKc'],
                  ['-F', '--playlist-end', '10', 'https://www.youtube.com/playlist?list=PLwiyx1dc3P2JR9N8gQaQN_BCvlSlap7re']]
    for test_case in test_cases:
        write_string('\tTesting parseOpts with args: %s\n' % repr(test_case))
        _, opts, args = parseOpts(test_case)

# Generated at 2022-06-24 14:06:21.930567
# Unit test for function parseOpts
def test_parseOpts():
    try:
        # TODO: Add unit tests for the options here.
        parseOpts(['--verbose'])
    except SystemExit as e:
        assert e.code == 0
    except:
        assert False



# Generated at 2022-06-24 14:06:27.070671
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-U', 'Windows-YouTube-Downloader/1.0.0', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert(opts.usenetrc == False)
    assert(opts.username == None)
    assert(opts.password == None)
    assert(opts.usenetrc_machine == None)



# Generated at 2022-06-24 14:06:35.606297
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    import shutil
    import os
    from sys import argv

    def make_temp_conf(opts):
        tmp = tempfile.NamedTemporaryFile(delete=False)
        try:
            for opt in opts:
                tmp.write(('%s\n' % opt).encode('utf-8'))
            tmp.close()
            return tmp.name
        except:
            tmp.close()
            os.remove(tmp.name)
            raise

    def test(args, expected, expected_args):
        args = [x.encode(preferredencoding()) for x in args]
        _, opts, args = parseOpts(args)
        assert vars(opts) == expected
        assert args == expected_args


# Generated at 2022-06-24 14:06:47.815939
# Unit test for function parseOpts
def test_parseOpts():
    class MockOptionParser(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.opt_groups = []

        @staticmethod
        def error(msg):
            raise optparse.OptionError(msg)

        def add_option_group(self, *args, **kwargs):
            self.opt_groups.append((args, kwargs))

    class MockOptionGroup(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.options = []

        @staticmethod
        def add_option(help, *args, **kwargs):
            return MockOptionGroup.__add_option(help, *args, **kwargs)



# Generated at 2022-06-24 14:06:49.475299
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['--no-check-certificate'])[1]
    assert opts.no_check_certificate


# Generated at 2022-06-24 14:07:00.742476
# Unit test for function parseOpts
def test_parseOpts():
    exit_called = [False]
    def mock_exit(code):
        print('mock_exit, code: {}'.format(code))
        exit_called[0] = True
    def mock_stderr_write(s):
        print('mock_stderr_write: {}'.format(s))

    import sys
    import os.path
    import locale
    locale.setlocale(locale.LC_ALL, 'ja_JP.UTF-8')


# Generated at 2022-06-24 14:07:08.842066
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    class MockOpener(object):
        def __init__(self):
            self.urls = []
            self.count = 0
            return

        def open(self, url, data=None):
            self.count += 1
            self.urls.append(url)
            handler = StringIO(
                '--username="u" --password="p" --ap-mso "xyz" --ap-username "u" --ap-password "p"')
            return handler

    opener = MockOpener()
    compat_urllib_request.install_opener(opener)
    parser, opts, args = parseOpts(['-iu', '-f', 'best', 'plholder'])
    assert(opener.count == 1)

# Generated at 2022-06-24 14:07:19.887262
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from types import ModuleType

    def get_module():
        return ModuleType('__main__')

    # Exercise the options
    # The arguments for the options are tested for a minimum set of options
    # run by each of the executables
    #
    # The valid opts for the parseOpts function are
    #   None or a list of strings

    # Test None argument to parseOpts
    # The purpose of this test is to ensure that the
    # default values are returned
    opts, args = parseOpts(None)
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.updatetime == True
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.list

# Generated at 2022-06-24 14:07:23.938370
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)

# ######################################################################
# ############################## SOCKET ################################
# ######################################################################


# Generated at 2022-06-24 14:07:35.177239
# Unit test for function parseOpts
def test_parseOpts():
    def _test(argstr, expected_res, expected_raise=False, override_args=None):
        try:
            parser, res, args = parseOpts(['-i', '--get-url'] + argstr.split(' '),
                                          overrideArguments=override_args)
            if expected_raise:
                assert False, 'Expected to raise SystemExit'
            assert res.__dict__ == expected_res, repr(res.__dict__) + ' != ' + repr(expected_res)
        except SystemExit as e:
            if expected_raise:
                pass
            else:
                raise

# Generated at 2022-06-24 14:07:38.037413
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert isinstance(opts, object)
    assert isinstance(args, list)
# END parseOpts


# Generated at 2022-06-24 14:07:44.506510
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["--match-filter", "age_limit>18", "https://www.youtube.com/watch?v=M7FIvfx5J10"])
    assert opts.match_filter[0][0] == "age_limit"
    assert opts.match_filter[0][1] == ">"
    assert opts.match_filter[0][2] == "18"
# end of parseOpts(overrideArguments)



# Generated at 2022-06-24 14:07:52.569377
# Unit test for function parseOpts
def test_parseOpts():
    # get the parser and check that -h prints the help text
    parser, opts, args = parseOpts(['-h'])
    assert('lists of video IDs' in parser.format_help())

    # get the parser and check that --version prints the version
    parser, opts, args = parseOpts(['-U', '--version'])
    assert(opts.version == True)

    # get the parser and check that -U and -u don't return an error when empty
    parser, opts, args = parseOpts(['-U', ''])
    parser, opts, args = parseOpts(['-u', ''])

    # check that invalid arguments trigger an error

# Generated at 2022-06-24 14:07:58.414586
# Unit test for function parseOpts
def test_parseOpts():
    import optparse
    parser, opts, args = parseOpts()
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)

# Compat function that returns a urlopen() function that handles
# exceptions and redirects properly

# Generated at 2022-06-24 14:08:09.716576
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(["-h"])[0].get_usage().startswith("Usage:")
    assert parseOpts(["-v"])[1].verbose
    assert not parseOpts(["-q"])[1].verbose
    assert parseOpts(["-u", "us", "-p", "pw"])[1].username == "us"
    assert parseOpts(["-u", "us", "-p", "pw"])[1].password == "pw"
    assert parseOpts(["-o", "out"])[1].outtmpl == "out"
    assert parseOpts(["-a", "file"])[1].batchfile == "file"
    assert parseOpts(["--rate-limit", "limit"])[1].ratelimit == "limit"

# Generated at 2022-06-24 14:08:12.553375
# Unit test for function parseOpts
def test_parseOpts():
    # Test if function parseOpts raise an exception if input argument is None
    try:
        parseOpts(None)
        assert False
    except (SystemExit,ValueError):
        assert True


# Generated at 2022-06-24 14:08:20.356851
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from sys import stderr

    parser, opts, args = parseOpts(['-vvv'])
    assert opts.verbose == 3

    parser, opts, args = parseOpts(['-x', '--write-thumbnail', '--max-filesize', '10m'])
    assert opts.extractaudio
    assert opts.writethumbnail
    assert opts.max_filesize == 10 * 1024 * 1024

    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'

   

# Generated at 2022-06-24 14:08:22.599148
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import gen_extractors
    gen_extractors()
    parseOpts()



# Generated at 2022-06-24 14:08:31.917043
# Unit test for function parseOpts
def test_parseOpts():
    try:
        import nose.tools
    except ImportError:
        raise

    def _test_parse_opts(self, args, expected_opts):
        self.parser, actual_opts, self.args = parseOpts(args)
        self.assertEqual(vars(actual_opts), expected_opts)

    def _test_parse_nopts(self, args, expected_opts):
        self.parser, actual_opts, self.args = parseOpts(args)
        self.assertNotEqual(vars(actual_opts), expected_opts)

    class ParseOptsTest(object):
        def setUp(self):
            self.parser = None
            self.args = None


# Generated at 2022-06-24 14:08:37.049195
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts(['--username', 'user', '--password', 'pass', 'www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
test_parseOpts()


# Generated at 2022-06-24 14:08:46.061931
# Unit test for function parseOpts
def test_parseOpts():
    def _test_argv(argv, expected_opts):
        parser, opts, args = parseOpts(argv)
        assert vars(opts) == expected_opts, (
            '%s != %s' % (vars(opts), expected_opts))
        assert args == []

    def _test_argv_raises(argv):
        parser, opts, args = parseOpts(argv)
        assert False, '%s should have raised an error' % argv

    _test_argv(['-U', 'test'], {'username': 'test', 'usenetrc': False})
    _test_argv(['-u', 'test'], {'username': 'test', 'usenetrc': False})

# Generated at 2022-06-24 14:08:56.729330
# Unit test for function parseOpts
def test_parseOpts():
    def utest(args, expected):
        parser, _, _ = parseOpts(args.split())
        actual = sorted(str(o) for o in parser.option_list)
        assert actual == expected

    utest('-h', ['--help'])
    utest('--version', ['--version'])
    utest('--dump-intermediate-pages', ['--dump-intermediate-pages'])
    utest('--write-pages', ['--write-pages'])
    utest('--debug-printtraffic', ['--debug-printtraffic'])
    utest('--ignore-errors', ['--ignore-errors'])
    utest('--abort-on-error', ['--abort-on-error'])
    utest('--retries RETRIES', ['--retries RETRIES'])


# Generated at 2022-06-24 14:09:08.151823
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-i', '-o', 'test.%(ext)s'])
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.no_warnings is False
    assert opts.simulate is False
    assert opts.format is None
    assert opts.dump_user_agent is False
    assert opts.list_extractors is False
    assert opts.extractor_descriptions is False
    assert opts.forceurl is False
    assert opts.forcethumbnail is False
    assert opts.forceduration is False
    assert opts.forcetitle is False
    assert opts.forcefilename is False
    assert opts.forcejson is False
    assert opts.extract_flat is False
    assert opts

# Generated at 2022-06-24 14:09:12.444837
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--version'])
    assert not opts.verbose
    parser, opts, args = parseOpts(['--verbose', '--version'])
    assert opts.verbose

# Generated at 2022-06-24 14:09:20.905141
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import compat_expanduser
    assert parseOpts(['-v', '--ignore-config'])[2] == []
    assert parseOpts(['--username=user', '--password=pw', '--verbose'])[2] == []
    assert parseOpts(['-v'])[2] == []
    assert parseOpts(['--no-progress'])[2] == []
    assert parseOpts(['--config-location=%s' % compat_expanduser('~')])[2] == []
    assert parseOpts(['--config-location=%s' % compat_expanduser('~/test.conf')])[2] == []
    assert parseOpts(['--config-location=%stemp/test.conf' % os.sep])[2]

# Generated at 2022-06-24 14:09:29.115843
# Unit test for function parseOpts
def test_parseOpts():
    # -l and -t mutually exclude
    opts1, args1 = parseOpts(['-l'])
    assert opts1.usetitle
    opts1, args1 = parseOpts(['-t'])
    assert not opts1.usetitle

    # --cache-dir with no argument
    opts1, args1 = parseOpts(['--cache-dir'])
    assert opts1.cachedir is None

    # --cache-dir with an argument
    opts1, args1 = parseOpts(['--cache-dir', 'foo'])
    assert opts1.cachedir == 'foo'
    opts1, args1 = parseOpts(['--cache-dir=foo'])
    assert opts1.cachedir == 'foo'

    # --no-cache-

# Generated at 2022-06-24 14:09:40.484518
# Unit test for function parseOpts
def test_parseOpts():
    # Check for config location
    with tempfile.NamedTemporaryFile(delete=False) as f:
        sys.argv = ['youtube-dl', '--config-location', f.name, 'arg']
        parser, opts, args = parseOpts()
        assert opts.config_location == f.name
        assert args == ['arg']
    os.remove(f.name)

    sys.argv = ['youtube-dl']
    parser, opts, args = parseOpts()
    assert not opts.user_agent
    assert not opts.password
    assert not opts.username
    # assert not opts.adobepass

    sys.argv = ['youtube-dl', '--user-agent', 'test']
    parser, opts, args = parseOpts()
    assert opts.user_

# Generated at 2022-06-24 14:09:50.763530
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-h'])
    assert opts.help
    assert not opts.usenetrc
    assert not opts.username
    assert not opts.password
    parser, opts, args = parseOpts(['--usenetrc'])
    assert opts.usenetrc
    assert not opts.username
    assert not opts.password
    parser, opts, args = parseOpts(['--username=user', '--password=pwd'])
    assert not opts.usenetrc
    assert opts.username == 'user'
    assert opts.password == 'pwd'
    parser, opts, args = parseOpts(['--username=user', '--password=pwd', '--usenetrc'])

# Generated at 2022-06-24 14:09:54.304988
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.run_docstring_examples(parseOpts, dict(arguments='''\
        -U TestUser  --no-check-certificate --proxy http://localhost:8118 \
        https://www.youtube.com/watch?v=BaW_jenozKc\
        '''.split()))
# / End of parseOpts



# Generated at 2022-06-24 14:10:00.441311
# Unit test for function parseOpts
def test_parseOpts():
    # [0]
    from io import StringIO
    args = ['-i', '--username=foo', '--password=bar', '--verbose', '--extract-audio', '--yes-playlist']
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    try:
        parser, opts, args = parseOpts(args)
    finally:
        sys.stdout = old_stdout
    lines = mystdout.getvalue().strip().split('\n')
    assert lines[-1] == '[debug] Command-line args: [\'-i\', \'--username=foo\', \'--password=bar\', \'--verbose\', \'--extract-audio\', \'--yes-playlist\']'
    assert opts.username == 'foo'

# Generated at 2022-06-24 14:10:12.435999
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import search_dict
    from typing import Dict, Any

    def test_args(args, expected_args, expected_opts):
        # type: (str, str, Dict[str, Any]) -> None
        _, opts, args = parseOpts(args.split())
        assert args == expected_args
        assert search_dict(opts.__dict__, expected_opts)

    # Simple example with empty params
    test_args('-a xxx -b yyy', [], {'a': 'xxx', 'b': 'yyy'})

    # Option with parameters
    test_args('-A', [], {'A': True})
    test_args('-A --', [], {})

    # Short option

# Generated at 2022-06-24 14:10:15.954957
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([]) is not None
    assert parseOpts(['-h']) is not None
    assert parseOpts(['--help']) is not None
    assert parseOpts(['--version']) is not None



# Generated at 2022-06-24 14:10:25.252432
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'user', '-P', 'passwd', '-i', '--no-check-certificate', '-4', '--format', 'best', 'rtmp://example.com/path/file.flv'])
    assert opts.username == 'user'
    assert opts.password == 'passwd'
    assert opts.usenetrc
    assert opts.nocheckcertificate
    assert opts.prefer_insecure
    assert opts.format == 'best'
    assert args == ['rtmp://example.com/path/file.flv']



# Generated at 2022-06-24 14:10:35.385201
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info[0] < 3:
        from io import BytesIO as StringIO
    else:
        from io import StringIO

    def get_opts(overrideArguments=None):
        parser, opts, _ = parseOpts(overrideArguments)
        return parser, opts

    parser, opts = get_opts()
    assert opts.nooverwrites
    assert opts.restrictfilenames

    old = sys.stdout
    sys.stdout = StringIO()
    try:
        parser, opts = get_opts(['--get-url'])
        assert opts.nooverwrites
        assert opts.restrictfilenames
        assert not opts.geturl
        assert opts.verbose
    finally:
        sys.stdout