

# Generated at 2022-06-22 09:11:00.998428
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert not args
    assert opts.ratelimit

    parser, opts, args = parseOpts(['--ratelimit', '50k'])
    assert not args
    assert opts.ratelimit == '50k'

    parser, opts, args = parseOpts(['-R', '50k'])
    assert not args
    assert opts.retries == '50k'


# Generated at 2022-06-22 09:11:06.054365
# Unit test for function parseOpts
def test_parseOpts():
    try:
        test.assertTrue('--extract-audio' in parseOpts()[1].__dict__.keys())
    except AssertionError as e:
        test.assertTrue('--extract-audio' in parseOpts()[1].__dict__.keys())

# Generated at 2022-06-22 09:11:16.646265
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parse(conf_file_arg, expected_refs):
        youtube_dl_args = ['-o', 'bla', '--no-progress', '--ignore-errors', conf_file_arg, 'foo']
        parser, opts, args = parseOpts(youtube_dl_args)
        assert args == ['foo']
        assert opts.outtmpl == 'bla'
        assert opts.ignoreerrors
        assert opts.noprogress
        assert opts.dump_intermediate_pages
        assert opts.format == 'best'
        assert opts.nooverwrites
        assert opts.ratelimit == '0'
        assert opts.retries == 10
        assert not opts.write_sub
        assert opts.max_filesize == '0'
        assert not opt

# Generated at 2022-06-22 09:11:28.295549
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import NamedTemporaryFile
    import re


# Generated at 2022-06-22 09:11:35.032557
# Unit test for function parseOpts
def test_parseOpts():
    from xml.etree import ElementTree

    # Test the help
    parser, opts, _ = parseOpts([])
    assert opts.help
    assert opts.list_extractors

    # Test opts

# Generated at 2022-06-22 09:11:43.827583
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--no-warnings', '-4', '--no-check-certificate', 'BASEURL/VIDEOID'])
    assert opts.nocheckcertificate
    assert opts.proxy is None
    assert opts.noprogress
    assert opts.outtmpl == ('%(id)s.%(ext)s')
    assert opts.ignoreerrors
    assert opts.ratelimit is None
    assert opts.retries == 10
    assert opts.buffersize is None
    assert opts.noresizebuffer
    assert opts.continuedl
    assert opts.nopart
    assert opts.updatetime
    assert opts.test
    assert args == ['BASEURL/VIDEOID']

# Test function _match_entry

# Generated at 2022-06-22 09:11:55.810571
# Unit test for function parseOpts
def test_parseOpts():
    def test_parse_opts(args, expected):
        parser, opts, args = parseOpts(overrideArguments=args)
        actual = _hide_login_info(vars(opts))
        assert actual == expected, (actual, expected)

    def test_parse_args(args, expected):
        parser, opts, args = parseOpts(overrideArguments=args)
        actual = args
        assert actual == expected, (actual, expected)

    # Sanity check

# Generated at 2022-06-22 09:12:05.810028
# Unit test for function parseOpts
def test_parseOpts():
    def assert_options(parser, options, args, expected):
        """
        parser: optparse.OptionParser
        options: optparse.Values
        args: list
        expected: list of tuples
        """
        actual = []
        for opt in parser.option_list:
            if opt.dest is None:
                continue
            if isinstance(opt, optparse.TitledHelpFormatter.IndentedHelpFormatter):
                continue
            actual.append((opt.get_opt_string(), getattr(options, opt.dest)))
        assert actual == expected


# Generated at 2022-06-22 09:12:10.305312
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--simulate', '-q'])
    assert opts.simulate
    assert opts.quiet

    parser, opts, args = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.usenetrc

    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose


# Generated at 2022-06-22 09:12:20.534734
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import Option
    from sys import argv
    from types import ModuleType


# Generated at 2022-06-22 09:12:41.961635
# Unit test for function parseOpts
def test_parseOpts():
    command_line_conf = [b'-i']
    if sys.version_info < (3,):
        command_line_conf = [a.decode(preferredencoding(), 'replace') for a in command_line_conf]
    parser, opts, args = parseOpts(command_line_conf)

# Generated at 2022-06-22 09:12:50.977891
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-F', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best' and not args
    opts, args = parseOpts(['-f', '13', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '13' and not args
    opts, args = parseOpts(['-f', '13/18/22', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '13/18/22' and not args

# Generated at 2022-06-22 09:12:53.685127
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['--abort-on-error'])
    assert vars(opts).get('abort_on_error')


# Proxy support



# Generated at 2022-06-22 09:12:58.097978
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts('-F --format=best'))
    print(parseOpts('-F --format=best -x'))
    print(parseOpts('-F --format=best -x --audio-format=mp3'))
    print(parseOpts('-F --format=best --embed-subs'))
    print(parseOpts('-F --format=best --embed-thumbnail'))


# Generated at 2022-06-22 09:13:09.830591
# Unit test for function parseOpts
def test_parseOpts():
    from .YoutubeDL import parseOpts
    from .utils import compat_expanduser
    from .compat import user_cache_dir
    from .compat import preferredencoding
    if sys.version_info < (3,2):
        return # No test for such ancient Python versions

# Generated at 2022-06-22 09:13:19.017021
# Unit test for function parseOpts
def test_parseOpts():
    class MockOptionParser(object):
        def __init__(self, *args):
            self.opts = []
            self.args = []
            self.stderr = []

        def add_option(self, *args, **kwargs):
            self.opts.append((args, kwargs))

        def parse_args(self, args):
            self.args = args
            return self, self.args

        def error(self, msg):
            self.stderr.append(msg)

    class MockWrapper(object):
        def __init__(self, s):
            self.s = s

        def __str__(self):
            return self.s.encode('ascii')

        def decode(*args, **kwargs):
            return self.s


# Generated at 2022-06-22 09:13:25.759970
# Unit test for function parseOpts
def test_parseOpts():

	# test 1 - no argument
	if not unit_test:
		print("Testing parseOpts method")

	parser, opts, args = parseOpts(None)
	if not unit_test:
		print(opts.simulate)

	# test 2 - with argumen

# Generated at 2022-06-22 09:13:35.816661
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    _parser, opts, _ = parseOpts(['--username', 'user', '-2', '--datebefore', 'yesterday'])
    assert opts.usenetrc
    assert opts.username == 'user'
    assert opts.password == '-'
    assert opts.datebefore == DateRange.day
    _parser, opts, _ = parseOpts(['--usenetrc', '--username', 'user', '-2', '--datebefore', 'yesterday'])
    assert opts.usenetrc == False
    assert opts.username == 'user'
    assert opts.password == '-'
    assert opts.datebefore == None

# Generated at 2022-06-22 09:13:42.889205
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    import tempfile
    from .utils import encodeFilename

    if sys.platform == 'win32':
        assert parseOpts([])[1].outtmpl == '%(title)s-%(id)s.%(ext)s'
    else:
        assert parseOpts([])[1].outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert parseOpts(['-o', 'FOO'])[1].outtmpl == 'FOO'
    assert parseOpts(['-o', encodeFilename('%%')])[1].outtmpl == '%%'
    assert parseOpts(['-o', '%'])[1].outtmpl == '%'

# Generated at 2022-06-22 09:13:44.369537
# Unit test for function parseOpts
def test_parseOpts():
    return parseOpts(['-h'])


# Generated at 2022-06-22 09:14:03.437092
# Unit test for function parseOpts
def test_parseOpts():
    _, opts, _ = parseOpts({'--' : ['foo'], '-f' : [None], '--format' : ['bar']})
    assert opts.format == 'bar'
    _, opts, _ = parseOpts({'--' : ['foo']})
    assert opts.format is None



# Generated at 2022-06-22 09:14:10.652915
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from sys import argv, exit, stdout

    def test_getargs(args):
        args = [a for a in args if a]
        argv[1:] = args
        parser, opts, args = parseOpts()
        return opts, args

    def test_getopts(args):
        opts, _ = test_getargs(args)
        return opts

    def test_equal(args, field, value):
        opts = test_getopts(args)
        if hasattr(opts, field):
            assert getattr(opts, field) == value
        else:
            assert getattr(opts, field) is None

    # Test options
    test_equal([], 'list_extractors', False)

# Generated at 2022-06-22 09:14:21.817891
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])

    assert(opts.verbose == False)

    parser, opts, args = parseOpts(['-v'])
    assert(opts.verbose == True)
    # Test with verbose output
    parser, opts, args = parseOpts(['-v', '-i'])
    assert(opts.verbose == True)
    assert(opts.simulate == True)

    parser, opts, args = parseOpts(['-v', '--simulate'])
    assert(opts.verbose == True)
    assert(opts.simulate == True)

    parser, opts, args = parseOpts(['-v', '-i', '--extract-audio'])
    assert(opts.verbose == True)
   

# Generated at 2022-06-22 09:14:25.125758
# Unit test for function parseOpts
def test_parseOpts():
    # We need to clear the config file in order to test the --ignore-config paramters
    parseOpts(['--ignore-config', '--simulate', '--get-url', 'http://youtube.com/watch?v=BaW_jenozKc'])



# Generated at 2022-06-22 09:14:34.709276
# Unit test for function parseOpts
def test_parseOpts():
    test_val = parseOpts(['--version', '--ignore-config'])
    assert test_val[1].version == True
    assert test_val[1].ignore_config == True

    test_val = parseOpts(['--playlist-start', '1', '--playlist-end', '5', '--match-title', '(?i)test'])
    assert test_val[1].playliststart == '1'
    assert test_val[1].playlistend == '5'
    assert test_val[1].matchtitle == '(?i)test'

    test_val = parseOpts(['--yes-playlist', '--max-downloads', '5'])
    assert test_val[1].yesplaylist == True
    assert test_val[1].max_downloads == 5

    test

# Generated at 2022-06-22 09:14:46.482225
# Unit test for function parseOpts

# Generated at 2022-06-22 09:14:59.553412
# Unit test for function parseOpts
def test_parseOpts():
    import optparse

    assert parseOpts(['-v'])[2] == []
    assert parseOpts(['-v', '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[2] == ['https://www.youtube.com/watch?v=BaW_jenozKc']
    assert parseOpts(['-v', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[2] == ['https://www.youtube.com/watch?v=BaW_jenozKc']
    assert parseOpts(['-v', '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc', 'test'])[2] == ['test']
    assert parseOpts([])[2]

# Generated at 2022-06-22 09:15:10.878279
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-U', 'spam', '-P', 'eggs'])
    assert opts.username == 'spam' and opts.password == 'eggs'
    assert args == ['--username=spam', '--password=eggs']

    opts, args = parseOpts(['--netrc-optional'])
    assert opts.usenetrc == 'optional' and args == ['--usenetrc=optional']

    opts, args = parseOpts(['-4', '--no-check-certificate'])
    assert opts.prefer_ipv4 == True and opts.nocheckcertificate == True
    assert args == ['--prefer-ipv4', '--no-check-certificate']


# Generated at 2022-06-22 09:15:15.601849
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import get_info_extractor
    opts, args = parseOpts(
        ['https://www.youtube.com/watch?v=BaW_jenozKc', '-c',
         '-i', '--flat-playlist', '--no-warnings', '-f', 'bestvideo[height<=480]+bestaudio', '--youtube-skip-dash-manifest'])
    ydl = YoutubeDL(opts)
    assert ydl.params['nooverwrites']
    assert ydl.params['ignoreerrors']
    assert ydl.params['simulate']
    assert ydl.params['quiet']
    assert not ydl.params['outtmpl']
    assert not ydl.params['ignoreconfig']

# Generated at 2022-06-22 09:15:28.360330
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--extract-audio', '--audio-format', 'vorbis',
                                    '--audio-quality', '0', '--recode-video', 'mp4',
                                    '--metadata-from-title', '%(artist)s - %(title)s',
                                    '--output', '%(title)s.%(ext)s', 'url1', 'url2',
                                    '--verbose', '--no-warnings'])

# Generated at 2022-06-22 09:16:04.060991
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts([
        '-c', '--no-warnings',
    ])
    assert not opts.verbose
    assert not opts.simulate
    assert opts.noprogress
    assert opts.quiet
    assert opts.no_warnings
    assert opts.call_home is False
    assert opts.retries == 10
    assert opts.dump_intermediate_pages
    opts, args = parseOpts([
        '-v', '--simulate', '--no-progress', '--get-url', '--get-title',
    ])
    assert opts.verbose
    assert opts.simulate
    assert not opts.noprogress
    assert not opts.quiet
    assert not opts.no_warnings

# Generated at 2022-06-22 09:16:14.093226
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeArgument

    def _test(args, expected):
        (parsed_args, parsed_opts) = parseOpts(args.split(' '))
        assert parsed_opts.__dict__ == expected.__dict__

    _test('-f 22',
        Options(format='22'))
    _test('--format 17',
        Options(format='17'))
    _test('-g',
        Options(geturl=True))
    _test('--get-url',
        Options(geturl=True))
    _test('-i',
        Options(gettitle=True))
    _test('--get-title',
        Options(gettitle=True))
    _test('-e',
        Options(getid=True))

# Generated at 2022-06-22 09:16:24.880795
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts()[1]
    assert opts.verbose == False
    assert opts.username == None
    assert opts.password == None
    assert opts.video_password == None
    #assert opts.dump_user_agent == False
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.list_formats == False
    assert opts.list_extractors == False
    assert opts.youtube_include_dash_manifest == None
    assert opts.extract_flat == None
    assert opts.match_filter == None
    assert opts.no_

# Generated at 2022-06-22 09:16:32.178624
# Unit test for function parseOpts
def test_parseOpts():
    try:
        import __main__
        __main__.__dict__.clear()
        __main__.__dict__.update({
            '__name__': '__main__',
            '__file__': sys.argv[0],
            '__doc__': None,
            '__package__': None,
        })
    except ImportError:
        pass

    parser, opts, args = parseOpts()

    assert opts.version
    parser, opts, args = parseOpts(['-U', 'test'])

# Generated at 2022-06-22 09:16:42.008715
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.dump_json == False
    assert opts.dump_single_json == False

# Generated at 2022-06-22 09:16:46.727609
# Unit test for function parseOpts
def test_parseOpts():
    args = '-o test.avi --format mp4 -v http://www.youtube.com/watch?v=BaW_jenozKc'.split()
    parser, opts, _args = parseOpts(args)
    eq_('test.%(ext)s', opts.outtmpl)
    eq_(opts.format, 'mp4')
    eq_(opts.verbose, 1)


# Generated at 2022-06-22 09:16:53.570540
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info < (2, 7):
        from unittest2 import TestCase, main
    else:
        from unittest import TestCase, main
    import tempfile
    import os
    import shutil

    class ParseOptsTest(TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_no_config_file(self):
            # Test when there is no config file
            argv = ['--quiet', '--no-warnings', '--simulate', '--get-id',
                    'https://www.youtube.com/watch?v=BaW_jenozKc']
            self.assertTrue(parseOpts(argv))

# Generated at 2022-06-22 09:17:00.816563
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import OptionValueError
    class MockParser():
        def error(self, msg):
            raise OptionValueError(msg)

    parser = MockParser()
    opts, args = parseOpts(parser, ['--get-url', 'https://www.youtube.com/watch?v=BaW_jenozKc'])

    assert opts.geturl
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']



# Generated at 2022-06-22 09:17:09.564554
# Unit test for function parseOpts
def test_parseOpts():
    opts = Options()
    
    # Set options using member variables
    opts.verbose = True
    opts.writeinfojson = True
    opts.writesubtitles = True
    opts.username =  'test_user'
    opts.password = 'test_pass'
    opts.skip_download = True
    
    # Pass options to command line arguments
    test_args = ["--verbose", "--write-info-json", "--write-sub", "--username", "test_user", "--password", "test_pass", "--skip-download"]
    parser, opts, args = parseOpts(overrideArguments=test_args)
    
    # Check if options correctly set from command line arguments
    assert opts.verbose == True
    assert opts.writeinfojson == True

# Generated at 2022-06-22 09:17:18.864882
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])

# Generated at 2022-06-22 09:18:43.449694
# Unit test for function parseOpts
def test_parseOpts():
    args = ['--username=foo', '--password=bar', '--', '-u', '--username=baz', '-p', '--password=blick']
    parser, opts, args = parseOpts(args)
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['-u', '--username=baz', '-p', '--password=blick']

    args = ['--username', 'foo', '--password', 'bar', '--', '-u', '--username=baz', '-p', '--password=blick']
    parser, opts, args = parseOpts(args)
    assert opts.username == 'foo'
    assert opts.password == 'bar'

# Generated at 2022-06-22 09:18:55.550388
# Unit test for function parseOpts
def test_parseOpts():

    # testing without override argument
    class MockOptionParser():
        def __init__(self):
            self.has_called = []
        def add_option_group(self,group):
            self.has_called.append(group)
        def parse_args(self, args):
            self.has_called.append((args))
            return [],[]


    # testing with override argument
    class MockOptionParser2():
        def __init__(self):
            self.has_called = []
        def add_option_group(self,group):
            self.has_called.append(group)
        def parse_args(self, args):
            self.has_called.append((args))
            return [],[]


# Generated at 2022-06-22 09:19:01.324836
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import prepend_extension
    from youtube_dl.compat import compat_shlex_quote
    from youtube_dl.version import __version__

    youtube_dl = os.path.basename(sys.argv[0])

# Generated at 2022-06-22 09:19:07.283372
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--no-color', '--socket-timeout', '15', 'https://example.com'])
    assert opts.ignoreerrors is True
    assert opts.nocolor is True
    assert opts.socket_timeout == 15
    assert args == ['https://example.com']


# Generated at 2022-06-22 09:19:14.723379
# Unit test for function parseOpts
def test_parseOpts():
    # ensure that the --playlist-items option file:value1,...,valueN works
    args = ['--playlist-items', 'file', 'value1', 'value2']
    parser, opts, args2 = parseOpts(args)
    assert (args2 == args[1:])
    assert (opts.playliststart == 0)
    assert (opts.playlistend == 2)
    # ensure that the --playlist-items option value1,...,valueN works
    args = ['--playlist-items', 'value1', 'value2']
    parser, opts, args2 = parseOpts(args)
    assert (args2 == args[1:])
    assert (opts.playliststart == 0)
    assert (opts.playlistend == 2)
    # ensure that the --playlist-items

# Generated at 2022-06-22 09:19:25.355259
# Unit test for function parseOpts
def test_parseOpts():
    class LanguageOptionAction(argparse.Action):
        def __call__(self, parser, namespace, values, option_string=None):
            nvalues = set()
            for v in values:
                if v.lower() == 'all':
                    nvalues.update(languages.legacy_names)
                else:
                    m = re.match('^([a-z]{2})(?:(_|-|\+)([a-z]{2}))?$', v.lower())
                    if not m:
                        parser.error('Invalid language code: %s' % v)
                    nvalues.add(v.lower())
            setattr(namespace, self.dest, nvalues)

    parser = argparse.ArgumentParser(description='Smart downloader for YouTube', prog='youtube-dl')

# Generated at 2022-06-22 09:19:34.606260
# Unit test for function parseOpts
def test_parseOpts():
    op, _, _ = parseOpts(['-4', '--max-downloads', '10', '--embed-subs', '--restrict-filenames', '--verbose'])
    assert op.proxy is None
    assert op.noprogress is False
    assert op.numlimit is None
    assert op.min_views is None
    assert op.max_views is None
    assert op.matchtitle is None
    assert op.rejecttitle is None
    assert op.username is None
    assert op.password is None
    assert op.twofactor is None

    op, _, _ = parseOpts(['--proxy', '1.1.1.1:3128'])
    assert op.proxy == '1.1.1.1:3128'

    op, _, _ = parseOpts

# Generated at 2022-06-22 09:19:46.383903
# Unit test for function parseOpts

# Generated at 2022-06-22 09:19:58.200565
# Unit test for function parseOpts
def test_parseOpts():
    class MockParser(object):
        def __init__(self):
            self.option_groups = [MockOptionGroup()]
        def error(self, msg):
            raise ValueError(msg)
        def parse_args(self, args):
            return (MockOpts(), args)
    class MockOptionGroup(object):
        def __init__(self):
            self.options = []
        def add_option(self, *args):
            self.options.append(args)
    class MockOpts(object):
        def __init__(self):
            self.__dict__['key'] = None
        def __setattr__(self, key, value):
            if self.__dict__['key'] is not None:
                raise TypeError
            self.__dict__['key'] = value

# Generated at 2022-06-22 09:20:07.854508
# Unit test for function parseOpts
def test_parseOpts():
    # Test the --version arg
    version_arg = ['--version']
    parser, opts, args = parseOpts(version_arg)
    assert not args
    assert opts.version

    # Test the --help arg
    help_arg = ['--help']
    parser, opts, args = parseOpts(help_arg)
    assert not args
    assert opts.help

    # Test the -h arg
    h_arg = ['-h']
    parser, opts, args = parseOpts(h_arg)
    assert not args
    assert opts.help

    # Test the -U arg
    u_arg = ['-U']
    parser, opts, args = parseOpts(u_arg)
    assert not args
    assert opts.update_self

    # Test the --ignore-config arg