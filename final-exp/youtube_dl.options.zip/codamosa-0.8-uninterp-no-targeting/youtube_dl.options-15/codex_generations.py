

# Generated at 2022-06-22 09:11:02.510056
# Unit test for function parseOpts
def test_parseOpts():
    import shutil
    # Test with config file
    def _test_parseOpts_conf(conf, overrideArguments=None):
        if not isinstance(conf, (str, unicode)):
            conf = '\n'.join(conf)
        def compat_decode(s):
            if sys.version_info < (3,):
                return s.decode('utf-8')
            return s
        conf_handle, conf_filename = compat_tempfile(suffix='.conf', prefix='youtube-dl_test_', dir='.')
        conf_handle.write(compat_decode(conf))
        conf_handle.close()
        try:
            parser, opts, args = parseOpts(overrideArguments)
            return opts
        finally:
            os.remove(conf_filename)
   

# Generated at 2022-06-22 09:11:14.161733
# Unit test for function parseOpts
def test_parseOpts():
    """Unit test for parseOpts"""
    opts = parseOpts(
        ['--username', 'user', '--password', 'pass', '--verbose', '--format', '22/bestvideo+bestaudio', 'PLwiyx1dc3P6D426Lf-bSYVM8g-0BF9FNS'])[1]
    assert opts.usenetrc is False
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.verbose is True
    assert opts.format == ['22/bestvideo+bestaudio']
    assert opts.playlist_items == ['PLwiyx1dc3P6D426Lf-bSYVM8g-0BF9FNS']



# Generated at 2022-06-22 09:11:18.663929
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = ['-U', 'firefox', 'data']
    parser, opts, args = parseOpts()
    assert opts.usenetrc is True
    assert opts.username is None
    assert opts.password is None
    assert opts.video_password is None
    assert opts.ap_username is None
    assert opts.ap_password is None
    parser, opts, args = parseOpts(['-u', 'user', '--password', 'pass', 'data'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.video_password is None
    assert opts.ap_username is None
    assert opts.ap_password is None

# Generated at 2022-06-22 09:11:29.113616
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import NamedTemporaryFile

    config1 = '''
--username=alice
--password=bob
--verbose
--get-filename
'''.split()

    config2 = '''
--username=bob
--password=alice
--get-url
'''.split()

    with NamedTemporaryFile() as f1:
        with NamedTemporaryFile() as f2:
            f1.write('\n'.join(config1).encode('utf-8'))
            f2.write('\n'.join(config2).encode('utf-8'))
            f1.flush()
            f2.flush()

            parser, opts, _ = parseOpts(['--config-location=%s' % f1.name])
            assert opts.verbose
            assert opts.usern

# Generated at 2022-06-22 09:11:35.716753
# Unit test for function parseOpts
def test_parseOpts():
    global ydl
    ydl = YoutubeDL(params={})
    opts, args = ydl.parseOpts(['-i', '-f', 'bestvideo+bestaudio', 'https://www.youtube.com/watch?v=90AiXO1pAiA'])
    assert(not opts.verbose)
    assert(opts.quiet)
    assert(opts.extractaudio)
    assert(opts.noplaylist)
    assert(opts.format == 'bestvideo+bestaudio')
    assert(not opts.usenetrc)
    assert(opts.username is None)
    assert(opts.password is None)
    assert(opts.twofactor is None)
    assert(opts.videopassword is None)

# Generated at 2022-06-22 09:11:44.142456
# Unit test for function parseOpts
def test_parseOpts():
    import sys


# Generated at 2022-06-22 09:11:56.153246
# Unit test for function parseOpts
def test_parseOpts():
    class Opts(object):
        pass

    opts = Opts()
    opts.verbose = False
    parser = optparse.OptionParser()
    testcase = ('-v', '--get-url', '-l', '10', '-f', '18/22/37', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc', 'https://www.youtube.com/watch?v=v1uyQZNg2vE')
    parser, opts, args = parseOpts(parser, opts, testcase)
    assert args == ['--', 'http://www.youtube.com/watch?v=BaW_jenozKc', 'https://www.youtube.com/watch?v=v1uyQZNg2vE']
    assert opts.quiet

# Generated at 2022-06-22 09:12:06.022130
# Unit test for function parseOpts
def test_parseOpts():
    from .compat import code_type

    from .extractor import gen_extractors
    gen_extractors()

    def conf(*args, **kwargs):
        if isinstance(args[0], (list, tuple)):
            args = args[0]
        options = parseOpts(*args, **kwargs)[1]
        options = {k: v for k, v in options.__dict__.items() if k != 'urls'}
        return options


# Generated at 2022-06-22 09:12:13.381676
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import signal
    from .extractor.common import InfoExtractor
    from .utils import encodeArgument
    from .compat import compat_shlex_split
    from .compat import compat_getenv
    from .compat import compat_setenv

    def test_IE_input(ie, url, expected=True, expected_msg=''):
        if hasattr(ie, '_WORKAROUND'):
            ie._WORKAROUND = False
        if expected_msg == '':
            expected_msg = expected
        try:
            ie.suitable(url)
        except ExtractorError as e:
            if expected:
                raise
            if str(e) != expected_msg:
                raise
        else:
            if not expected:
                raise


# Generated at 2022-06-22 09:12:17.713604
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

    if opts.verbose:
        write_string('[debug] Options: ' + repr(opts) + '\n')
        write_string('[debug] Args: ' + repr(args) + '\n')
    return opts, args


# Generated at 2022-06-22 09:12:35.894544
# Unit test for function parseOpts
def test_parseOpts():
    return 0
# Function to generate a dictionary of arguments

# Generated at 2022-06-22 09:12:45.993170
# Unit test for function parseOpts
def test_parseOpts():
    # verbose true
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    # verbose false
    parser, opts, args = parseOpts(['-q'])
    assert opts.verbose == False
    # force ipv4
    parser, opts, args = parseOpts(['-4'])
    assert opts.forceipv4 == True
    # force ipv6
    parser, opts, args = parseOpts(['-6'])
    assert opts.forceipv6 == True
    # no check certificate
    parser, opts, args = parseOpts(['--no-check-certificate'])
    assert opts.nocheckcertificate == True
    # proxy
    parser, opts, args = parseOpts

# Generated at 2022-06-22 09:12:51.240227
# Unit test for function parseOpts
def test_parseOpts():
    # OverrideArgument equal to None
    youtube_dl_parser, opts_1, args_1 = parseOpts(['-i'])
    assert opts_1.ignoreerrors
    assert args_1 == []

    # OverrideArgument not equal to None
    youtube_dl_parser, opts_2, args_2 = parseOpts(['--quiet'], ['--restrict-filenames'])
    assert opts_2.quiet
    assert opts_2.restrictfilenames
    assert args_2 == []

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-22 09:13:03.352572
# Unit test for function parseOpts

# Generated at 2022-06-22 09:13:05.295239
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    print('Opts: ' + str(vars(opts)))
    print('Args: ' + str(args))



# Generated at 2022-06-22 09:13:15.122618
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info >= (3,):
        return
    if os.path.exists('youtube-dl.conf'):
        os.remove('youtube-dl.conf')
    parser, opts, args = parseOpts(['-o', 'test value', 'test url'])
    assert opts.outtmpl == 'test value'
    assert args == ['test url']
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.forceurl is False
    assert opts.forcetitle is False
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.format is None
    assert opts.listformats is False
    assert opts.outtmpl == 'test value'

# Generated at 2022-06-22 09:13:23.655031
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--no-warnings'])
    assert opts.no_warnings
    parser, opts, args = parseOpts(['--playlist-reverse'])
    assert opts.playlist_reverse
    parser, opts, args = parseOpts(['--playlist-random'])
    assert opts.playlist_random
    parser, opts, args = parseOpts(['--writethumbnail'])
    assert opts.writethumbnail
    parser, opts, args = parseOpts(['--write-all-thumbnails'])
    assert opts.write_all_thumbnails

# }}}
_availablethumbnailExtensions = ['webp', 'jpg', 'jpeg', 'gif', 'png']

# Generated at 2022-06-22 09:13:34.568076
# Unit test for function parseOpts
def test_parseOpts():
    # test long opt with '='
    sys.argv=['progname', '--output=file']
    parser, opts, args = parseOpts()
    assert opts.outtmpl == 'file'
    assert args == []
    # test short opts concatenation
    sys.argv=['progname', '-ufoo']
    parser, opts, args = parseOpts()
    assert opts.username == 'foo'
    # test short opt with '='
    sys.argv=['progname', '-U=foo']
    parser, opts, args = parseOpts()
    assert opts.usename == 'foo'
    # test short and long opts concatenation
    sys.argv=['progname', '-u=foo', '--username=bar']
   

# Generated at 2022-06-22 09:13:40.354588
# Unit test for function parseOpts
def test_parseOpts():
    from collections import Counter
    from youtube_dl import YoutubeDL

    parser, opts, args = parseOpts(['--no-warnings', '--dump-intermediate-pages', 'plAdelX1F1M', 'IpCYmZpw4xo'])


# Generated at 2022-06-22 09:13:50.358807
# Unit test for function parseOpts
def test_parseOpts():
    """Check whether the parseOpts function correctly parses the command line arguments"""
    parser, opts, _args = parseOpts(["-v"])
    assert opts.verbose == True

    parser, opts, _args = parseOpts(["-o", "somename"])
    assert opts.outtmpl == "somename"

    with pytest.raises(optparse.OptionValueError):
        parser, opts, _args = parseOpts(["--rate-limit", "123a"])

    with pytest.raises(optparse.OptionValueError):
        parser, opts, _args = parseOpts(["--playlist-items", "1-abc"])

    parser, opts, _args = parseOpts(["--playlist-items", "1-2"])

# Generated at 2022-06-22 09:14:34.642954
# Unit test for function parseOpts
def test_parseOpts():
    def parse_opts(argv):
        parser, opts, args = parseOpts(overrideArguments=argv)
        assert opts.__dict__ == parser.values.__dict__
        return parser, opts, args

    parser, opts, args = parse_opts([])
    assert not opts.verbose

    parser, opts, args = parse_opts(['-v'])
    assert opts.verbose

    parser, opts, args = parse_opts(['--verbose'])
    assert opts.verbose

    parser, opts, args = parse_opts(['--verbose', '--verbose'])
    assert opts.verbose == 2

    parser, opts, args = parse_opts(['-v', '-v'])
    assert opts

# Generated at 2022-06-22 09:14:46.436078
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from argparse import ArgumentTypeError

    # test normal option
    opts = parseOpts(['-v'])[1]
    assert opts.verbose

    # test option with invalid option name
    try:
        parseOpts(['-vb'])
    except SystemExit as e:
        assert e.code == 2

    # test invalid parameter
    try:
        parseOpts(['--datebefore', 'invalid'])
    except ArgumentTypeError:
        pass

    # test aliases
    opts = parseOpts(['-ic'])[1]
    assert not opts.ignoreerrors

    # test compound options
    opts = parseOpts(['-R5'])[1]
    assert opts.retries == 5

    # test compound options with

# Generated at 2022-06-22 09:14:59.409043
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    sys.argv = ['youtube-dl', 'pewpewpew']
    try:
        parser, opts, args = parseOpts()
        assert False
    except SystemExit:
        pass # Function _parseOpts always calls sys.exit

    sys.argv = ['youtube-dl', '--print-json', 'pewpewpew']
    parser, opts, args = parseOpts()
    assert opts.print_json
    assert not opts.dump_json
    assert not opts.forcejson
    assert args == ['pewpewpew']

    sys.argv = ['youtube-dl', '--dump-json', 'pewpewpew']
    parser, opts, args = parseOpts()
    assert not opts.print_json

# Generated at 2022-06-22 09:15:10.879317
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-U', 'FooBot', '-i', '--no-warnings'])[1].user_agent == 'FooBot'
    assert parseOpts(['-4', '--no-check-certificate'])[1].nocheckcertificate
    assert parseOpts(['--no-playlist'])[1].noplaylist
    assert parseOpts(['--yes-playlist'])[1].yesplaylist
    assert parseOpts(['-f', '22/18/17/best'])[1].format == '22/18/17/best'
    assert parseOpts(['--all-subs', '--write-sub', '--write-auto-sub'])[1].writesubtitles

# Generated at 2022-06-22 09:15:12.009499
# Unit test for function parseOpts
def test_parseOpts():
    pass


if __name__ == '__main__':

	test_parseOpts()

# Generated at 2022-06-22 09:15:20.196044
# Unit test for function parseOpts
def test_parseOpts():
    # Test without --config-location
    _, opts, __ = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert(opts.format == ['bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])

    # Test with --config-location
    _, opts, __ = parseOpts(['--config-location', 'tests/youtube-dl-test.conf',
                             '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])

# Generated at 2022-06-22 09:15:31.697332
# Unit test for function parseOpts
def test_parseOpts():
    class W:
        def write(self, *args):
            pass
    parser, opts, args = parseOpts(['-a'], W())
    assert opts.batchfile == '-'

    parser, opts, args = parseOpts(['--batch-file'], W())
    assert opts.batchfile is None

    parser, opts, args = parseOpts(['--batch-file=foo'], W())
    assert opts.batchfile == 'foo'

    parser, opts, args = parseOpts(['--batch-file', 'foo'], W())
    assert opts.batchfile == 'foo'

    parser, opts, args = parseOpts(['blabla'], W())
    assert opts.batchfile is None


# Generated at 2022-06-22 09:15:41.395238
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO

    output = StringIO()

    def _test(opts, args=(), func=lambda: None, override=None,
              extra_args=(), msg=None):
        confargs = ['--%s=%s' % (k, v) for k, v in opts.items()]
        confargs += args
        if override is None:
            override = []
        confargs += override
        confargs += extra_args
        confargs += ['-v']

        o, a, p = parseOpts(confargs)
        p.print_usage = lambda f: f.write(output.getvalue())
        p.print_help = lambda f: f.write(output.getvalue())
        p.exit = lambda x: x
        func()


# Generated at 2022-06-22 09:15:50.718509
# Unit test for function parseOpts
def test_parseOpts():
    try:
        # Check for command line args
        parser, opts, args = parseOpts()
        assert isinstance(parser, optparse.OptionParser)
        assert isinstance(opts, optparse.Values)
        assert isinstance(args, list)

        # Check for override args
        overrideArguments = ['--version', '--yes-playlist']
        parser, opts, args = parseOpts(overrideArguments)
        assert isinstance(parser, optparse.OptionParser)
        assert isinstance(opts, optparse.Values)
        assert isinstance(args, list)
    except AssertionError:
        info = sys.exc_info()
        traceback.print_exception(*info)



# Generated at 2022-06-22 09:16:01.439632
# Unit test for function parseOpts
def test_parseOpts():
    from ..utils import match_filter_func
    parser, opts, args = parseOpts(['url', '-i', '-c', '--no-check-certificate', '--proxy', '1.2.3.4:8080', '--max-filesize', '0', '--match-filter', 'is_live==True'])
    assert opts.proxy == '1.2.3.4:8080'
    assert opts.max_filesize is 0
    assert opts.match_filter == 'is_live==True'
    list = [{'is_live': True, 'foo': 'bar'}, {'is_live': False, 'foo': 'baz'}]
    filter_func = match_filter_func(opts.match_filter)

# Generated at 2022-06-22 09:17:11.757140
# Unit test for function parseOpts
def test_parseOpts():
    from nose.tools import assert_equals
    from nose.tools import assert_true
    from nose.tools import assert_false
    from nose.tools import assert_regexp_matches
    from nose.tools import assert_not_regexp_matches

    # Sanity check
    parser, opts, _ = parseOpts(['-i'])
    assert_equals(opts.ignoreerrors, True)

    # Short options
    parser, opts, _ = parseOpts(['-i', '-v', '-g', '-e', '-f', 'best', '-a', '-b', 'a', '-o', '-', 'url'])
    assert_equals(opts.ignoreerrors, True)
    assert_equals(opts.verbose, True)
    assert_equ

# Generated at 2022-06-22 09:17:20.818632
# Unit test for function parseOpts
def test_parseOpts():
    from .compat import compat_str
    # Simplest possible test:
    parser, opts, _ = parseOpts(['-h'])
    assert opts['username'] is None

    parser, opts, args = parseOpts([
        '--username', 'foouser', '--password', 'foopass', 'plCast', '2.0', '--',
        '--username', 'arguser', '--password', 'argpass', 'argurl'])
    assert opts['username'] == 'foouser'
    assert opts['password'] == 'foopass'
    assert args == ['plCast', '2.0', '--', '--username', 'arguser', '--password', 'argpass', 'argurl']
    # Check that password is hidden in repr

# Generated at 2022-06-22 09:17:26.362500
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    assert not opts.dump__unknown_options
    assert '--verbose' in args
    
    parser, opts, args = parseOpts(['--dump__unknown_options'])
    assert opts.dump__unknown_options
    assert not opts.verbose
    assert len(args) == 0

    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    
    parser, opts, args = parseOpts(['-v', '--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-vblah'])
    assert not opts.verbose
    assert not opts.listformats

# Generated at 2022-06-22 09:17:31.223037
# Unit test for function parseOpts
def test_parseOpts():
    from os.path import dirname
    from sys import argv, version_info

    argv[0] = 'youtube-dl'
    version_info = version_info[:2]

    for args in (
        ['-f', '22/18/17/best'],
        ['-f', 'best/22'],
        ['-f', '17/best/22'],
        ['-f', '17/22/best']
    ):
        opts = YoutubeDL(YoutubeDL.params).parseOpts(args)
        assert opts.format == '17/22/best'

    opts = YoutubeDL(YoutubeDL.params).parseOpts(['-f', 'bestvideo+bestaudio'])
    assert opts.format == 'bestvideo+bestaudio/best'


# Generated at 2022-06-22 09:17:42.189706
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-f', 'flv'])[1].format == 'flv'
    assert parseOpts(['--format', 'flv'])[1].format == 'flv'
    assert parseOpts(['-f', 'flv', '--format', 'mp4'])[1].format == 'mp4'
    assert parseOpts(['--format', 'mp4', '-f', 'flv'])[1].format == 'flv'
    assert parseOpts(['--format', 'bestvideo+bestaudio'])[1].format == 'best'
    assert parseOpts(['-f', 'bestvideo+bestaudio'])[1].format == 'best'
    assert parseOpts(['-F', 'bestvideo+bestaudio'])[1].format == 'best'

# Generated at 2022-06-22 09:17:50.804358
# Unit test for function parseOpts
def test_parseOpts():
    defaults = ['--youtube-skip-dash-manifest']
    # Test reading config files
    def create_conf(conffile, conf):
        basedir = os.path.dirname(conffile)
        if not os.path.exists(basedir):
            os.makedirs(basedir)
        with open(conffile, 'w') as f:
            f.write(conf)
        return conffile

    # Write system config
    sysconf = create_conf('youtube-dl/test/sysconf', '--extract-audio\n--audio-format=best\n')

# Generated at 2022-06-22 09:17:57.417995
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts()[1]
    assert(opts.username is None)
    assert(opts.password is None)
    assert(opts.usenetrc is False)

    opts = parseOpts([])[1]
    assert(opts.username is None)
    assert(opts.password is None)
    assert(opts.usenetrc is False)

    opts = parseOpts(['-u', 'test', '-p', 'testtest'])[1]
    assert(opts.username == 'test')
    assert(opts.password == 'testtest')
    assert(opts.usenetrc is False)

    opts = parseOpts(['--username', 'test', '--password', 'testtest'])[1]

# Generated at 2022-06-22 09:18:07.685253
# Unit test for function parseOpts
def test_parseOpts():
    # Test the system configuration file
    parser, opts, args = parseOpts([])
    assert not opts.ignore_errors
    assert not opts.usenetrc
    assert not opts.verbose
    assert opts.download_archive == '~/.youtube-dl-archive'
    assert opts.help_print_postprocessor_names
    assert opts.no_warnings

    parser, opts, args = parseOpts(['--username', 'foo', '--password', 'bar'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert not opts.noprogress
    assert not opts.nopart

    parser, opts, args = parseOpts(['--username', 'foo', '--password', 'bar', '--verbose'])


# Generated at 2022-06-22 09:18:14.600542
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-o', 'test_output', 'https://youtu.be/9bZkp7q19f0'])
    indexFile = open('test_output', 'r')
    assert indexFile.read() == '\ufeff9bZkp7q19f0', 'parseOpts reads the command line arguments'
    indexFile.close()
    video_files = glob.glob('*.mp4')
    for video_file in video_files:
        os.remove(video_file)
    os.remove('test_output')

################################## main #########################################


# Generated at 2022-06-22 09:18:23.695930
# Unit test for function parseOpts
def test_parseOpts():
    import re
    parser, opts, _ = parseOpts(['-o', '%(uploader)s/%(title)s-%(id)s-%(upload_date)s.%(ext)s',
                                'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == None
    assert opts.password == None
    m = re.match(opts.outtmpl, 'carykh/A Common Wrong Idea about Time-BaW_jenozKc-20130829.%(ext)s')
    assert m
    assert opts.verbose == False
    assert opts.quiet == False

test_parseOpts()

# Dict containing information about formats
# The downloader may use this information to choose a format
#
#