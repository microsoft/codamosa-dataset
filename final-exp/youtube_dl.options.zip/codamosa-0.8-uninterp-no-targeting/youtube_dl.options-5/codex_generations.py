

# Generated at 2022-06-22 09:11:04.241315
# Unit test for function parseOpts
def test_parseOpts():
    print('parseOpts')
    print("- parseOpts() : Testing with all static values")
    parser, opts, args = parseOpts()
    assert(sys.argv[1:] == args)
    assert(opts.usenetrc == False)
    assert(opts.username == "")
    assert(opts.password == "")

    print("- parseOpts() : Testing with overriding arguments")
    parser, opts, args = parseOpts(['--usenetrc', '-u=Me', '-p=MyPassword',
                                    '--username=Me2', '--password=MyPassword2'])
    assert(opts.usenetrc == True)
    assert(opts.username == "Me2")
    assert(opts.password == "MyPassword2")

# Generated at 2022-06-22 09:11:09.036062
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    from youtube_dl.utils import DateRange, DateRangeLimit

    doctest.testmod(
        name='parseOpts',
        extraglobs={'DateRange': DateRange, 'DateRangeLimit': DateRangeLimit},
        verbose=True)



# Generated at 2022-06-22 09:11:18.839909
# Unit test for function parseOpts
def test_parseOpts():
    args = ['--username', 'test_username', '--password', 'test_password']

    parser, _, _ = parseOpts(args)
    og1 = parser.get_option_group('general')
    assert og1.get_option('--username').help == 'Login with this account ID'
    assert og1.get_option('--password').help == 'Account password. (Currently unsupported)'

    args.append('--verbose')
    parser, opts, _ = parseOpts(args)
    assert opts.verbose is True
    assert opts.username == 'test_username'
    assert opts.password == 'test_password'

    # Unit test for function _readUserConf
    args = ['--ignore-config']
    parser, opts, _ = parseOpts(args)
    assert opt

# Generated at 2022-06-22 09:11:21.340402
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()
    return
# parseOpts()

# ========================================================================== #
#


# Generated at 2022-06-22 09:11:31.267495
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    parser, opts, args = parseOpts()
    assert opts.usenetrc
    assert opts.username == None
    assert opts.password == None

    f = tempfile.NamedTemporaryFile(mode='w+t', delete=False)
    f.write('username=foo\n')
    f.write('password=bar\n')
    f.close()

    opts.usenetrc = False
    opts.username = None
    opts.password = None
    opts.netrc_file = f.name

    parser, opts, args = parseOpts(['--ignore-config', '--no-usenetrc'])
    assert opts.usenetrc == False
    assert opts.username == 'foo'

# Generated at 2022-06-22 09:11:36.611028
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    global sys
    sys.argv = ['youtube-dl']
    parser, opts, args = parseOpts()

# Generated at 2022-06-22 09:11:49.930633
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-f', '22/18/17/16'])
    ui, ie = opts.usenetrc, opts.insecure
    # -f
    assert opts.format == '22/18/17/16'
    # --usenetrc
    assert ui == False
    assert ie == False
    # --usenetrc --insecure
    opts, args = parseOpts(['--usenetrc', '--insecure', '-f',
                            '22/18/17/16'])
    assert opts.format == '22/18/17/16'
    assert ui == True
    assert ie == True
    # --no-usenetrc --insecure

# Generated at 2022-06-22 09:12:01.985322
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts([
        '--username', 'foo', '--password', 'bar', '--verbose',
        'http://www.youtube.com/watch?v=BaW_jenozKc'
    ])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose

    parser, opts, _ = parseOpts(['-i', '-f', '37/22/18', 'http://youtu.be/BaW_jenozKc'])
    assert opts.format == '37/22/18'
    assert opts.ignoreerrors

    parser, opts, _ = parseOpts(['--playlist-start', '22', 'http://youtu.be/BaW_jenozKc'])
    assert opt

# Generated at 2022-06-22 09:12:08.234121
# Unit test for function parseOpts
def test_parseOpts():
    class Args:
        pass
    args = Args()
    args.url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    args.verbose = True
    args.proxy = 'http://foo.bar:3128'
    parser, opts, _args = parseOpts(['--verbose', '-g', '--proxy', 'http://foo.bar:3128'] + [args.url])
    assert opts.verbose
    assert opts.geturl
    assert opts.proxy == 'http://foo.bar:3128'
    assert _args == [args.url]


# Options for players

# Generated at 2022-06-22 09:12:15.816678
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--username', 'foo', '--password', 'bar', 'bar', 'foo'])
    assert not opts.username
    assert not opts.password

    parser, opts, args = parseOpts(['-u', 'foo', '-p', 'bar', 'bar', 'foo'])
    assert not opts.username
    assert not opts.password



# Generated at 2022-06-22 09:12:39.727136
# Unit test for function parseOpts

# Generated at 2022-06-22 09:12:48.606755
# Unit test for function parseOpts
def test_parseOpts():
    opts = _GenericOption(verbose=True)
    opts.username = 'u'
    opts.password = 'p'
    opts.twofactor = 't'
    opts.ap_username = 'U'
    opts.ap_password = 'P'
    expected = ('--verbose --username u --password p --twofactor t --ap-username U --ap-password P')
    res = _hide_login_info(['--verbose', '--username', opts.username, '--password', opts.password, '--twofactor', opts.twofactor, '--ap-username', opts.ap_username, '--ap-password', opts.ap_password])
    assert res == expected, 'Failed to hide login info'


# The following functions are used in the command line

# Generated at 2022-06-22 09:13:00.821353
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    sys.argv = [sys.argv[0], '-U', '-F', '-f', 'bestaudio/best', '-o', 'filename', '--autonumber-size=3', '--restrict-filenames', 'pl', 'http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts()
    assert opts.usename == True
    assert opts.format == ['bestaudio/best']
    assert opts.outtmpl == 'filename'
    assert opts.autonumber_size == 3
    assert opts.restrictfilenames == True
    assert opts.simulate == False
    assert opts.simulate == False
    assert opts.quiet == False
    assert opts.geturl

# Generated at 2022-06-22 09:13:12.110398
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor.common import InfoExtractor
    from .downloader.external import ExternalFD
    from .compat import compat_str, compat_expanduser

    def save_opts(parser, opts, args, savename):
        with open(savename, 'wb') as f:
            opts = vars(opts)
            for key in sorted(opts.keys()):
                if not isinstance(opts[key], InfoExtractor) and not isinstance(opts[key], ExternalFD):
                    f.write(('%s: %s\n' % (key, repr(opts[key]))).encode('utf-8'))
            f.write(b'args: ' + repr(args).encode('utf-8'))


# Generated at 2022-06-22 09:13:20.328397
# Unit test for function parseOpts
def test_parseOpts():
    """
    Test on parseOpts
    """
    parser, opts, args = parseOpts([])
    subparser = opts.subparser
    assert subparser is not None
    assert subparser._name == 'youtube-dl'
    assert opts.get_opts_bytes() == b'B'

    parser, opts, args = parseOpts(['--max-downloads', '20', '--playlist-reverse'])
    assert opts.max_downloads == 20
    assert opts.playlistreverse


# Generated at 2022-06-22 09:13:31.680958
# Unit test for function parseOpts
def test_parseOpts():
    # Testing several --verbose level
    for i in range(0, 6):
        opts, args = parseOpts(['-v' * i])
        assert opts.verbose == i

    # Testing boolean flags
    opts, args = parseOpts(['--no-check-certificate'])
    assert opts.nocheckcertificate is True

    opts, args = parseOpts(['--extract-audio'])
    assert opts.extractaudio is True

    opts, args = parseOpts(['--no-playlist'])
    assert opts.noplaylist is True

    opts, args = parseOpts(['--proxy', '1.2.3.4:8080'])
    assert opts.proxy == '1.2.3.4:8080'

    #

# Generated at 2022-06-22 09:13:40.422897
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_expanduser

    assert sys.argv[0] == 'youtube-dl'
    sys.argv = [sys.argv[0], '-v', 'http://google.com/']

# Generated at 2022-06-22 09:13:41.954257
# Unit test for function parseOpts
def test_parseOpts():
    assert len(parseOpts()) == 3


_cachedir = None



# Generated at 2022-06-22 09:13:53.250633
# Unit test for function parseOpts
def test_parseOpts():
    from .common import ArgumentsFake
    # test help option
    parser, opts, args = parseOpts(['-h','--help','list','url1','url2'])
    assert opts.help==True
    assert opts.verbose == False
    assert len(args)==2
    
    # test version option
    parser, opts, args = parseOpts(['-U','--version','list','url1','url2'])
    assert opts.version==True
    assert opts.verbose == False
    assert len(args)==2

    # test verbose option
    parser, opts, args = parseOpts(['-v','--verbose','list','url1','url2'])
    assert opts.verbose == True
    assert len(args)==2

    # test verbose_

# Generated at 2022-06-22 09:13:55.991804
# Unit test for function parseOpts
def test_parseOpts():
    utils.BOX_COMMENT('Testing function parseOpts')
    utils.BOX_COMMENT('Function parseOpts is not tested because it is too complex')
    return


# Generated at 2022-06-22 09:14:20.405798
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v'])
    assert opts.verbose
    assert opts.simulate
    parser, opts, args = parseOpts(['-u', 'user', '-p', 'pass'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    parser, opts, args = parseOpts(['-a', 'file'])
    assert opts.batchfile == 'file'
    parser, opts, args = parseOpts(['-o', 'file'])
    assert opts.outtmpl == 'file'
    parser, opts, args = parseOpts(['--output', 'file'])
    assert opts.outtmpl == 'file'
    parser, opts, args = parseOpt

# Generated at 2022-06-22 09:14:25.332064
# Unit test for function parseOpts
def test_parseOpts():
    # An example
    assert parseOpts(['-f', '139+251'])[1].format == ['139', '251']
    assert parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])[1].format == ['bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best']


# Generated at 2022-06-22 09:14:34.740966
# Unit test for function parseOpts
def test_parseOpts():
    # Test parsing of basic options
    ok = lambda s: parseOpts(s.split())
    ok('-v')
    ok('-i -v')
    ok('-v -a abc')
    ok('-i -v -a abc')
    ok('-v --format mp4')
    ok('--format mp4 -v')
    # Test parsing of options with --
    ok('-v --')
    ok('-v -- -i -v')
    ok('-- -i -v')
    ok('-a abc -- -i -v')
    ok('-v -a abc -- -i -v')
    ok('--format mp4 -- -i -v')
    ok('-v --format mp4 -- -i -v')
    # Test parsing of options after URL

# Generated at 2022-06-22 09:14:46.483027
# Unit test for function parseOpts
def test_parseOpts():
    # Do not import any other items from __main__, it messes up the namespace
    # (e.g. 'opts' gets overwritten) and therefore unit tests.
    # Also, do not use console_print(), as it will mess up the stdout/stderr
    # capture used by unit tests.
    from __main__ import options, _hide_login_info, _match_entry, update_self, _readUserConf, _readOptions, _writeUserConf, write_string, console_print, preferredencoding

    parser, opts, args = parseOpts(overrideArguments=[
        '-i', '--username', 'foo', '--password', 'bar', '--debug-printtraffic'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.debug

# Generated at 2022-06-22 09:14:59.553570
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import NamedTemporaryFile
    from youtube_dl.utils import encodeArgument

    def normalize(s):
        return [encodeArgument(a) for a in s.split(' ')]

    def normalizeOutput(s):
        return s.replace('\r\n', '\n').replace('\r', '\n').split('\n')

    def testParseOpts(conf, overrideArguments, expectedOutput):
        if overrideArguments is None:
            overrideArguments = argv[1:]
        parser, opts, args = parseOpts(conf, overrideArguments)
        expectedOutput = normalizeOutput(expectedOutput)

# Generated at 2022-06-22 09:15:10.890584
# Unit test for function parseOpts
def test_parseOpts():
    def get_args(args):
        parser, opts, _args = parseOpts(args)
        return dict((opt, getattr(opts, opt)) for opt in ('usenetrc', 'username', 'password', 'verbose', 'quiet'))

    assert get_args(['--username', 'foo', '--password', 'bar']) == {
        'usenetrc': True,
        'username': 'foo',
        'password': 'bar',
        'verbose': False,
        'quiet': False,
    }
    assert get_args(['--usenetrc']) == {
        'usenetrc': True,
        'username': None,
        'password': None,
        'verbose': False,
        'quiet': False,
    }

# Generated at 2022-06-22 09:15:19.737507
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-f', 'bestvideo+bestaudio', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == ['bestvideo+bestaudio']
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Options to be used on unit tests
# This code is copied from the original parseOpts code
_READ_OPTS_COMMON = ['-U', 'Mozilla/5.0 (X11; Linux x86_64; rv:37.0) Gecko/20100101 Firefox/37.0 (like Firefox/37.0)', '--no-check-certificate', '--no-color', '--no-progress']
_READ_OPTS

# Generated at 2022-06-22 09:15:31.372605
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([])
    assert parseOpts(['-h'])
    assert parseOpts(['--help'])
    assert parseOpts(['-U', 'foobar'])
    assert parseOpts(['-u', 'foobar'])
    assert parseOpts(['-p', 'foobar'])
    assert parseOpts(['--username', 'foobar'])
    assert parseOpts(['--password', 'foobar'])
    assert parseOpts(['--min-sleep-interval', '1'])
    assert parseOpts(['--max-sleep-interval', '1'])
    assert parseOpts(['--extract-audio'])
    assert parseOpts(['--audio-format', 'mp3'])

# Generated at 2022-06-22 09:15:41.105305
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', '18', 'http://youtube.com/watch?v=BaW_jenozKc', 'ttt'])
    opts.verbose = True
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.download_archive == 'youtube-dl.list'
    assert opts.format == ['18']
    assert opts.outtmpl == '%(id)s%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcefilename == False
    assert opts.forceduration == False
    assert opts

# Generated at 2022-06-22 09:15:50.023263
# Unit test for function parseOpts
def test_parseOpts():
    #from __main__ import *
    print(parseOpts.__doc__)
    action_hooks = []
    parser, opts, args = parseOpts(['-h'], action_hooks)
    parser, opts, args = parseOpts([])
    parser, opts, args = parseOpts(['--version'])
    parser, opts, args = parseOpts(['--extract-audio', '--audio-format', 'mp3', '--audio-quality', '0', '_oOtOd4ekfA', '-w'])
    parser, opts, args = parseOpts(['-f', 'bestaudio/best', '-a', '1.txt'])

# Generated at 2022-06-22 09:16:14.148280
# Unit test for function parseOpts
def test_parseOpts():
    def _test(args, expected):
        expected = dict([(k.replace('-', '_'), v) for k, v in expected.items()])
        opts = optparse.Values(expected)
        parser, opts, _ = parseOpts(args.split())
        for name, value in expected.items():
            attrname = '_'.join(['dest', name])
            assert getattr(opts, attrname) == value, '%s != %s (for %s)' % (getattr(opts, attrname), value, name)

    _test('-i --abbrev-commit --date=raw --local',
          {'abbrev-commit': True, 'date': 'raw', 'i': True, 'local': True})

# Generated at 2022-06-22 09:16:24.542210
# Unit test for function parseOpts
def test_parseOpts():
    #Test the function itself
    parser, opts, args = parseOpts(['-i', '-v'])
    assert opts.get('verbose', False)
    assert opts.get('ignoreerrors', False)
    #Test _hide_login_info
    assert _hide_login_info(['--username', 'foo', '--password', 'bar', '-v']) == [
        '--username', '****', '--password', '****', '-v']
    assert _hide_login_info(['--netrc', '', '-v']) == ['--netrc', '****', '-v']
    assert _hide_login_info(['-v', '--netrc']) == ['-v', '--netrc']



# Generated at 2022-06-22 09:16:33.235607
# Unit test for function parseOpts
def test_parseOpts():
    try:
        old_stderr = sys.stderr
        sys.stderr = stdout = io.BytesIO()
        try:
            parser, opts, args = parseOpts([
                '-v', '--get-url', '--get-title',
                'https://www.youtube.com/watch?v=BaW_jenozKc'])
        finally:
            sys.stderr = old_stderr
        assert opts.verbose == True
        assert opts.geturl == True
        assert opts.gettitle == True
        assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']
    except SystemExit as err:
        assert False, 'parseOpts should not call sys.exit'



# Generated at 2022-06-22 09:16:43.049203
# Unit test for function parseOpts
def test_parseOpts():
    # Make sure it parses a single url
    parser, opts, args = parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    assert opts.usenetrc is False
    assert opts.verbose is False

    # Make sure it doesn't parse a single option
    try:
        parseOpts(['-v'])
        assert False, 'Expected error not thrown'
    except (SystemExit, DownloadError) as err:
        pass

    # Make sure it doesn't parse a single option with a valid url following

# Generated at 2022-06-22 09:16:44.533597
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: figure out a meaningful test case for this function
    pass


# Generated at 2022-06-22 09:16:56.860284
# Unit test for function parseOpts
def test_parseOpts():
    import argparse
    from youtube_dl.utils import youtube_dl_parse_argv
    from optparse import OptionParser

    for parse in (argparse.ArgumentParser(), OptionParser()):
        p, o, a = parseOpts(parse)

        # Assert default is False
        assert o.writedescription is False
        assert o.writeinfojson is False
        assert o.writeannotations is False
        assert o.writethumbnail is False
        assert o.write_all_thumbnails is False
        assert o.list_thumbnails is False
        assert o.writesubtitles is False
        assert o.writedescription is False
        assert o.embedsubtitles is False
        assert o.allsubtitles is False
        assert o.listsubtitles is False
        assert o.listsubtitleslang is False
       

# Generated at 2022-06-22 09:17:00.456198
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    for opt, arg in parseOpts([opt for opt in argv[1:] if opt.startswith('-')])[1].__dict__.items():
        print (opt, arg)

# Generated at 2022-06-22 09:17:09.239459
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', 'https://example.com/'])
    assert opts.verbose
    assert args == ['https://example.com/']

    parser, opts, args = parseOpts(['-v', 'https://example.com/', '-o', 'out.%(ext)s'])
    assert opts.verbose
    assert args == ['https://example.com/']
    assert opts.outtmpl == 'out.%(ext)s'

    # --output is also valid alias
    parser, opts, args = parseOpts(['-v', 'https://example.com/', '--output', 'out.%(ext)s'])
    assert opts.verbose
    assert args == ['https://example.com/']
    assert opts

# Generated at 2022-06-22 09:17:12.203497
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    if __name__ == "__main__":
        print("opts",opts)
        print("args",args)
test_parseOpts()


# Generated at 2022-06-22 09:17:21.182128
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument

    def _test_parse_opts(args, expected_opts):
        args = [encodeArgument(a) for a in args]
        parser, opts, _ = parseOpts(args)
        for key, value in expected_opts.items():
            assert getattr(opts, key) == value

    # Unavailable/deprecated options
    _test_parse_opts(
        ['-U', '-u', 'user:passwd'],
        {'username': 'user', 'password': 'passwd'})

    # Basic options
    _test_parse_opts(
        ['-i', '--yes-playlist'],
        {'ignoreerrors': True, 'extract_flat': True})

    # No options
    _test_parse_

# Generated at 2022-06-22 09:17:45.708923
# Unit test for function parseOpts

# Generated at 2022-06-22 09:17:53.879497
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info < (2, 7):
        print('Test for parseOpts skipped due to too old Python version.')
        return
    def assertEqual(a, b):
        if a != b:
            raise AssertionError('%r != %r' % (a, b))
    class Opts(object):
        def __str__(self):
            return '<dummy opts>'
        def __repr__(self):
            return str(self)
    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        assertEqual(
            {k: v for k, v in vars(opts).items() if k in expected},
            expected)
    print('Testing parseOpts')
    _test(['-h'], {})
   

# Generated at 2022-06-22 09:18:02.904952
# Unit test for function parseOpts
def test_parseOpts():
    _, opts, args = parseOpts([
        '--quiet',
        '--verbose',
        '--ignore-config',
        '--outtmpl', 'abc',
        '--cookies', 'bcd',
        'plop',
        '--',
        'flv',
    ])
    assert opts.quiet
    assert opts.verbose
    assert opts.ignoreconfig
    assert opts.outtmpl == 'abc'
    assert opts.cookiefile == 'bcd'
    assert args == ['plop', '--', 'flv']


# Generated at 2022-06-22 09:18:12.469715
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    from youtube_dl.utils import compat_expanduser
    from youtube_dl.compat import compat_configparser

    test_file_name = 'youtube_dl_opts_test'
    config_file_opts = [
        'youtube-dl --ignore-config',
        'youtube-dl --config-location %s' % compat_expanduser(os.path.sep.join(['~', test_file_name])),
        'youtube-dl --config-location %s' % compat_expanduser(test_file_name),
    ]

    # Set up config file
    config = compat_configparser.ConfigParser()

    # Set some values
    config.add_section('youtube-dl')
    config.set('youtube-dl', 'no-warnings', '')

# Generated at 2022-06-22 09:18:22.400754
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

    # Check that opts without a short option are working
    assert opts.youtube_include_dash_manifest
    assert opts.merge_output_format == 'mkv'

    # # Check that opts with a short option are working
    assert opts.outtmpl == '%(id)s.%(ext)s'
    assert opts.xattrs

    # Check that opts with isworking
    assert opts.usetitle

    # Check that args are working
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# End of Unit test for function parseOpts
test_parseOpts()


# Generated at 2022-06-22 09:18:29.125305
# Unit test for function parseOpts
def test_parseOpts():
    from unittest import TestCase
    class ParseOptsTest(TestCase):
        def _run_parseopts(self, conf, conf_id):
            parser, opts, args = parseOpts({'overrideArguments': conf})
            self.assertEqual(args, [])
            self.assertFalse(hasattr(opts, 'help'))
            self.assertTrue(hasattr(opts, 'usenetrc'))
            self.assertTrue(hasattr(opts, 'verbose'))
            self.assertTrue(hasattr(opts, 'quiet'))
            self.assertTrue(hasattr(opts, 'username'))
            self.assertTrue(hasattr(opts, 'password'))
            self.assertTrue(hasattr(opts, 'ap_username'))
            self

# Generated at 2022-06-22 09:18:41.626778
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-h'])
    parser, opts, args = parseOpts(['--list-extractors'])
    parser, opts, args = parseOpts(
        ['http://www.youtube.com/watch?v=BaW_jenozKc', '--min-filesize', '10k'])
    parser, opts, args = parseOpts(
        ['http://www.youtube.com/watch?v=BaW_jenozKc', '-c', '-b', '10k'])
    parser, opts, args = parseOpts(
        ['http://www.youtube.com/watch?v=BaW_jenozKc', '--no-continue', '-b', '10k'])
    parser, opts, args = parseOpts

# Generated at 2022-06-22 09:18:44.650038
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print(opts)
    assert opts

# Test parseOpts
#test_parseOpts()


# Generated at 2022-06-22 09:18:56.883484
# Unit test for function parseOpts
def test_parseOpts():
    import re
    from io import StringIO
    from types import SimpleNamespace


# Generated at 2022-06-22 09:19:03.992881
# Unit test for function parseOpts
def test_parseOpts():
    def parseOpts_helper(args):
        parser, opts, args = parseOpts(args)
        return list(map(lambda o: o.dest, parser.option_list))
    assert parseOpts_helper(['-h']) == parseOpts_helper([])
    assert parseOpts_helper(['--help']) == parseOpts_helper([])
    assert parseOpts_helper([]) == parseOpts_helper([])



# Generated at 2022-06-22 09:19:51.325813
# Unit test for function parseOpts
def test_parseOpts():
    """
    Returns True iff the command-line arguments are parsed correctly.
    """

    # Run the test for command-line arguments
    argv = ['-f', '22/35/44', 'http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(argv)
    if opts.verbose:
        write_string('[debug] System config: []\n'
                     '[debug] User config: []\n'
                     '[debug] Custom config: []\n'
                     '[debug] Command-line args: [\'-f\', \'22/35/44\', \'http://www.youtube.com/watch?v=BaW_jenozKc\']\n')


# Generated at 2022-06-22 09:20:02.723814
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(overrideArguments=['--version'])[2] == []
    assert parseOpts(overrideArguments=['-h'])[2] == []
    assert parseOpts(overrideArguments=['--ignore-config'])[2] == []
    assert parseOpts(overrideArguments=['--ignore-config', '--version'])[2] == []
    assert parseOpts(overrideArguments=['--config-location=/etc/youtube-dl.conf'])[2] == []
    assert parseOpts(overrideArguments=['--batch-file=' + os.path.join(os.path.dirname(__file__), 'tests', 'batchfile')])[2] == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-22 09:20:13.778552
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([
        '--list-subs',
        'https://www.youtube.com/watch?v=BaW_jenozKc',
        '--username', 'user',
        '--password', 'pass',
        '--proxy', 'proxy',
        '--sub-lang', 'en',
        '--sub-format', 'ass',
        '-o', 'out.%(ext)s',
        '--format', 'bestvideo+bestaudio'
        ])
    assert '--sub-lang' in args and '--sub-format' in args
    assert opts.usenetrc
    assert not opts.nopassword
    assert opts.subtitleslang == 'en'
    assert opts.subtitlesformat == 'ass'

# Generated at 2022-06-22 09:20:20.481058
# Unit test for function parseOpts
def test_parseOpts():
    import sys

    # list all known formats
    def test_list():
        old_formats = list(known_extensions.keys())
        parseOpts(['--list-formats'])
        new_formats = list(known_extensions.keys())
        write_string("All format numbers: %s\n" % list(range(len(old_formats), len(new_formats))))

    test_list()
    sys.exit(1)


# Generated at 2022-06-22 09:20:31.695343
# Unit test for function parseOpts