

# Generated at 2022-06-22 09:11:02.745842
# Unit test for function parseOpts
def test_parseOpts():
    # Test created with "youtube_dl --dump-user-agent"
    DEFAULT_USER_AGENT = b'youtube-dl/2016.11.04'
    assert parseOpts()[1].user_agent == DEFAULT_USER_AGENT
    # Test created with "youtube-dl --simulate"
    # (also tests if string override works)
    assert parseOpts(['--user-agent', 'test'])[1].user_agent == b'test'
    # Test created with "youtube-dl --simulate -i"
    assert parseOpts(['-i'])[1].ignoreerrors


# Generated at 2022-06-22 09:11:14.750012
# Unit test for function parseOpts
def test_parseOpts():
    import youtube_dl
    def _run_test(args):
        parser, opts, args = parseOpts(args)
        return opts.__dict__
    assert _run_test(['-f', 'best'])['format'] is None
    assert _run_test(['-f', 'best', '--', 'a'])['format'] == 'best'
    assert _run_test(['--format=best', '--', '-f', 'best'])['format'] == 'best'
    assert _run_test(['-f', 'best', 'a'])['format'] == 'best'
    assert _run_test(['a', '-f', 'best'])['format'] == 'best'
    assert _run_test([])['verbose'] == False

# Generated at 2022-06-22 09:11:27.216759
# Unit test for function parseOpts
def test_parseOpts():
    from argparse import ArgumentParser
    from . import YoutubeDL
    parser, opts, args = parseOpts(['-U', '-i', '--yes-playlist', '--download-archive', 'archive.txt', '--', 'test'])
    assert type(parser) == ArgumentParser
    assert type(opts) == argparse.Values
    assert type(args) == list
    assert args == ['test']
    assert type(parser) == ArgumentParser
    assert opts.username == 'ytuser'
    assert opts.verbose
    assert opts.ignoreerrors
    assert opts.nooverwrites
    assert opts.download_archive == 'archive.txt'
    assert opts.noplaylist
    assert opts.nocheckcertificate
    ydl = YoutubeDL(opts)

# Generated at 2022-06-22 09:11:31.553951
# Unit test for function parseOpts
def test_parseOpts():

    # params
    parser = optparse.OptionParser()
    parser.add_option('-t', '--test', action='store_true',
                      help='test youtube-dl')
    conf = ['--test', '--verbose']
    # call command
    parser, opts, args = common.parseOpts(parser, conf)
    # handle result
    assert opts.test == True


# handleAttachments

# Generated at 2022-06-22 09:11:42.930866
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-o', '%(title)s.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts(['--audio-quality', '9', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.audioquality == '9'


# Generated at 2022-06-22 09:11:54.587127
# Unit test for function parseOpts
def test_parseOpts():
    def check_opts(conf, expected_opts):
        parser, opts, args = parseOpts(conf)
        real_opts = opts.__dict__
        assert real_opts == expected_opts
    # Test no config location
    check_opts(['-v'], {'verbose':True})
    # Test system config location
    open('/etc/youtube-dl.conf', 'wb').write(b"--username='test_user'\n")
    check_opts(['--username=user'], {'username':'test_user'})
    os.remove('/etc/youtube-dl.conf')
    # Test user config location

# Generated at 2022-06-22 09:12:05.060967
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info.major < 3:
        return
    import locale
    from youtube_dl.compat import argv
    from youtube_dl.utils import encode_compat_str

    def parse_opts(*a, **k):
        parser, opts, args = parseOpts(*a, **k)
        return (parser.format_help(), opts, args)

    def parse_opts_unicode(enc, *a, **k):
        try:
            locale.setlocale(locale.LC_ALL, (enc, 'UTF-8'))
        except locale.Error:
            raise unittest.SkipTest('Encoding %s not supported' % enc)

        args = [encode_compat_str(a, enc) for a in a]

# Generated at 2022-06-22 09:12:16.987902
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import os.path
    if sys.version_info < (3,):
        import codecs
        sys.stdout = codecs.getwriter(preferredencoding())(sys.stdout, errors='replace')
        sys.stderr = codecs.getwriter(preferredencoding())(sys.stderr, errors='replace')
    from youtube_dl.YoutubeDL import YoutubeDL

    sys.argv = ['youtube-dl']
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False


# Generated at 2022-06-22 09:12:26.083204
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing parseOpts:', end=' ')
    # Test 1
    originalArgv = sys.argv
    sys.argv = ['-i', '--no-playlist', '--yes-playlist', '--', 'foo', '--bar-baz']
    try:
        parser, opts, args = parseOpts()
    finally:
        sys.argv = originalArgv
    assert opts.ignoreerrors is True
    assert opts.extractaudio is False
    assert opts.usenetrc is False
    assert opts.ratelimit is None
    assert opts.nooverwrites is False
    assert args == ['foo', '--bar-baz']
    # Test 2
    class FakeOption:
        def __init__(self, value):
            self.value = value
   

# Generated at 2022-06-22 09:12:37.974596
# Unit test for function parseOpts
def test_parseOpts():
    def check_compat(s):
        if sys.version_info < (3,):
            s = s.encode('utf-8')
        return s

    def parse_opts_test(overrideArguments, expected_opts, expected_params=()):
        parser, opts, params = parseOpts(overrideArguments)
        if expected_opts is None:
            assert opts is None
        else:
            assert opts.username == check_compat(expected_opts['username'])
            assert opts.password == check_compat(expected_opts['password'])
            assert opts.usenetrc == expected_opts['usenetrc']
            assert opts.verbose == expected_opts['verbose']
            assert opts.quiet == expected_opts['quiet']

# Generated at 2022-06-22 09:12:55.794460
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)



# Generated at 2022-06-22 09:13:07.720317
# Unit test for function parseOpts
def test_parseOpts():
    _, opts1, _ = parseOpts(['--username', 'user', '--password', 'pass'])
    assert opts1.username == 'user'
    assert opts1.password == 'pass'
    _, opts2, _ = parseOpts(['--get-username'])
    assert opts2.username is None
    assert opts2.password is None
    assert opts2.get_username
    _, opts3, _ = parseOpts(['--get-password'])
    assert opts3.username is None
    assert opts3.password is None
    assert opts3.get_password
    _, opts4, _ = parseOpts(['--usenetrc'])
    assert opts4.usenetrc

# Information extraction

# Generated at 2022-06-22 09:13:15.973622
# Unit test for function parseOpts
def test_parseOpts():
    parser, opt = parseOpts(['-U', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])

    # Can't check the full string because the date keeps changing.
    assert '[debug] System config: []' in opt.__str__()

    #conf_user = os.path.join(os.path.expanduser('~'), '.config', 'youtube-dl', 'config')
    #assert '[debug] User config: ' in opt.__str__()
    #assert conf_user in opt.__str__()


# Generated at 2022-06-22 09:13:18.099497
# Unit test for function parseOpts
def test_parseOpts():
    return

# Function merge_opts

# Generated at 2022-06-22 09:13:29.536138
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import gen_extractors
    gen_extractors() # Ensure that extractors are loaded

    from .extractor.common import InfoExtractor

    def gen(urls):
        for url in urls:
            # Simulate extractor for each URL
            ie = InfoExtractor(
                {'ie_key': 'Test', '_type': 'playlist', 'id': 'dummy', 'title': 'dummy'})
            ie.extractor._ids = lambda *args: [url]
            ie.extractor._real_extract = lambda *args: {'id': url}
            yield ie


# Generated at 2022-06-22 09:13:30.442074
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts())


# Generated at 2022-06-22 09:13:40.536248
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL

    args = sys.argv[1:]

    # get default options
    parser, opts, args = parseOpts(YoutubeDL)

    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert parser._get_all_options()[3].help == 'File containing usernames and passwords for sites requiring authentication'

    # set usenetrc to True
    parser, opts, args = parseOpts(YoutubeDL, overrideArguments=['--usenetrc'])

    assert opts.usenetrc == True
    assert opts.username == None
    assert opts.password == None

# Generated at 2022-06-22 09:13:50.474240
# Unit test for function parseOpts
def test_parseOpts():
    expected_options = {
        'ratelimit': '80k',
        'retries': 10,
        'retrydelay': 10,
        'buffersize': '100M',
        'noresizebuffer': True,
        'test': True,
        'proxy': '',
        'socket_timeout': 600,
        'source_address': '1.2.3.4'
    }
    expected_arguments = ['https://www.youtube.com/watch?v=BaW_jenozKc']

    if is_py2:
        if PY2:
            expected_arguments = [a.decode('utf-8') for a in expected_arguments]

    for option, value in expected_options.items():
        assert getattr(parseOpts()[1], option) == value


# Generated at 2022-06-22 09:13:54.807099
# Unit test for function parseOpts
def test_parseOpts(): # pragma: no cover
    import doctest
    parser, opts, args = parseOpts(['-v'])
    write_string(parser.format_help().decode('ascii', 'ignore'))
    print(opts)
    doctest.testmod()



# Generated at 2022-06-22 09:14:06.001838
# Unit test for function parseOpts
def test_parseOpts():
    # Test when override_arguments is None
    ydl = YoutubeDL({})
    (parser, opts, args) = parseOpts(ydl)
    assert isinstance(parser, optparse.OptionParser)
    assert 'outtmpl' not in opts.__dict__
    assert '--verbose' in args
    # Test when override_arguments is not None
    (parser2, opts2, args2) = parseOpts(ydl, ['--verbose'])
    assert opts.__dict__ == opts2.__dict__
    assert args == args2
    # Test when the config file is not found
    with pytest.raises(SystemExit):
        parseOpts(ydl, ['--config-location=/tmp/nonexistent'])



# Generated at 2022-06-22 09:14:46.280969
# Unit test for function parseOpts
def test_parseOpts():
    # test if options are set correctly
    # first use default configuration
    parser, opts, args = parseOpts([])
    assert not opts.usenetrc, "Default should disable .netrc"
    assert opts.nooverwrites is False, ".part file should be overwritten"

    # then use additional configuration to overwrite defaults
    parser, opts, args = parseOpts(["--username", "ytdl", "--no-overwrites"])
    assert opts.username == "ytdl", "Default should not be overwritten"
    assert opts.nooverwrites is True, "default should be overwritten"


# Generated at 2022-06-22 09:14:59.137735
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.ratelimit == '1.0'
    assert opts.retries == 10
    assert opts.buffersize == '1024'
    assert opts.noresizebuffer == False
    assert opts.usenetrc == True
    assert opts.verbose == False
    assert opts.dump_intermediate_pages == False
    assert opts.write_pages == False
    assert opts.simulate == False
    assert opts.nooverwrites == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.playliststart == 1
    assert opts.playlistend == 0
    assert opts.matchtitle == None
    assert opts.rejecttitle == None

# Generated at 2022-06-22 09:15:06.139852
# Unit test for function parseOpts
def test_parseOpts():
    """
    Test for function parseOpts.
    """
    from youtube_dl.YoutubeDL import YoutubeDL
    opts, _args = parseOpts([])
    assert isinstance(
        opts.ydl_opts,
        YoutubeDL)

    opts, _args = parseOpts(['-4'])
    assert opts.noplaylist is True




# The main Youtube-dl downloader class.

# Generated at 2022-06-22 09:15:14.518428
# Unit test for function parseOpts
def test_parseOpts():
    from .compat import compat_urlparse
    from .downloader import FileDownloader
    from .extractor import get_info_extractor
    from .postprocessor import PostProcessor
    from .utils import DateRange


# Generated at 2022-06-22 09:15:21.890864
# Unit test for function parseOpts
def test_parseOpts():
    def argtest(*args, **kwargs):
        parser, opts, args = parseOpts(*args, **kwargs)
        return parser, opts, args, parser.format_option_help(width=1000)
    #
    # Test %(autonumber)s
    #
    parser, opts, args, _ = argtest(['-o', '"%(autonumber)s.%(ext)s"'])
    assert opts.outtmpl == '%(autonumber)s.%(ext)s'
    parser, opts, args, _ = argtest(['-o', '"%(autonumber)s %(title)s.%(ext)s"'])
    assert opts.outtmpl == '%(autonumber)s %(title)s.%(ext)s'

# Generated at 2022-06-22 09:15:22.714531
# Unit test for function parseOpts
def test_parseOpts():
    #TODO: implement test
    pass


# Generated at 2022-06-22 09:15:31.296435
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-c', '--no-progress', '-v', '-r', '5m', '--match-filter', '"hello"', 'http://example.com'])
    assert opts.ignoreerrors
    assert opts.continuedl
    assert opts.noprogress
    assert opts.verbose == 2
    assert opts.ratelimit == '300k'
    assert opts.match_filter == '"hello"'
    assert args == ['http://example.com']

# Generated at 2022-06-22 09:15:35.215573
# Unit test for function parseOpts
def test_parseOpts():
    # return the opts for -h for the unit test
    inst = YoutubeDL()
    # Fake being called as a cmdline program
    sys.argv[0] = 'youtube-dl'
    return inst._parseOpts(['-h'])


# Generated at 2022-06-22 09:15:44.201559
# Unit test for function parseOpts

# Generated at 2022-06-22 09:15:54.521062
# Unit test for function parseOpts

# Generated at 2022-06-22 09:17:02.870639
# Unit test for function parseOpts
def test_parseOpts():
    class _opts:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    _parseOpts = parseOpts
    try:
        parseOpts = lambda: (_opts(), _opts())
        assert(parseOpts())
    except AssertionError:
        pass
    finally:
        parseOpts = _parseOpts


# Generated at 2022-06-22 09:17:11.787779
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.audioformat == 'best'
    assert opts.audioquality == '5'
    assert opts.retries == 10
    assert opts.continuedl == True
    assert opts.nooverwrites == False
    assert opts.ignoreerrors == False
    assert opts.ratelimit == '0'
    assert opts.nopart == False
    assert opts.updatetime == True
    assert opts.buffersize is None
    assert opts.noresizebuffer == False
    assert opts.playliststart == 1
    assert opts.playlistend == -1
    assert opts.playlistreverse

# Generated at 2022-06-22 09:17:14.266707
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()

_real_main = main


# Generated at 2022-06-22 09:17:18.658484
# Unit test for function parseOpts
def test_parseOpts():
    options = ['--username', 'user', '--password', 'pass', '--verbose']
    parser, opts, args = parseOpts(overrideArguments=options)
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.verbose == True
# End unit test for function parseOpts


# Generated at 2022-06-22 09:17:27.077745
# Unit test for function parseOpts
def test_parseOpts():
    global sys

    assert sys.argv == ['youtube-dl']
    parser, opts, _ = parseOpts(['-h'])
    assert opts.help is True
    parser, opts, _ = parseOpts(['-U'])
    assert opts.update is True
    parser, opts, _ = parseOpts(['-v'])
    assert opts.verbose is True
    parser, opts, _ = parseOpts(['--ignore-config'])
    assert opts.ignoreconfig is True
    parser, opts, _ = parseOpts(['--dump-user-agent'])
    assert opts.dump_user_agent is True
    parser, opts, _ = parseOpts(['-i'])
    assert opts.simulate is True
    parser, opts, _

# Generated at 2022-06-22 09:17:32.327059
# Unit test for function parseOpts
def test_parseOpts():
    parser, opt, args = parseOpts(['-h'])
    parser, opt, args = parseOpts(['--version'])
    parser, opt, args = parseOpts(['--extract-audio', '--audio-format=mp3', '--audio-quality=9', 'https://www.youtube.com/watch?v=A02s8omM_hI'])
    parser, opt, args = parseOpts(['--ffmpeg-location', '/usr/bin/ffmpeg', 'https://www.youtube.com/watch?v=A02s8omM_hI'])
    parser, opt, args = parseOpts(['--add-metadata', 'https://www.youtube.com/watch?v=A02s8omM_hI'])

# Generated at 2022-06-22 09:17:42.271873
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(overrideArguments=['-h'])
    assert(opts.help)
    assert(opts.verbose == False)
    parser, opts, args = parseOpts(overrideArguments=['-v'])
    assert(opts.help == False)
    assert(opts.verbose)

# The main entry point of this module:
#   - Download a media using youtube-dl and post-process it
#   - Download a media with a specific format using youtube-dl and post-process it
#   - Download a media with a specific format and a specific resolution using youtube-dl and post-process it
#   - Download a single media by ID
#   - Download multiple medias by ID

# Generated at 2022-06-22 09:17:44.381912
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'pass'


# Generated at 2022-06-22 09:17:52.854815
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import mkstemp
    from shutil import move
    from os import remove, close

    # Create temporary file
    fd, abs_path = mkstemp()
    new_file = open(abs_path, 'w')
    new_file.write('-o test\n')
    new_file.close()
    # Close opened file
    close(fd)
    # Move new file
    move(abs_path, '/etc/youtube-dl.conf')

    # Test
    parser, opts, args = parseOpts()
    opts.simulate = True
    downloader = YoutubeDL(opts)
    downloader.params['outtmpl'] = 'test'
    opts.usenetrc = True
    opts.username = 'test'
    opts.password = 'test'
   

# Generated at 2022-06-22 09:18:03.910829
# Unit test for function parseOpts
def test_parseOpts():
    # Test parsing of --format
    (parser, opts, args) = parseOpts(['-f','bestvideo'])
    assert opts.format == 'bestvideo'

    # Test parsing of --format
    (parser, opts, args) = parseOpts(['--format','bestvideo+bestaudio'])
    assert opts.format == 'bestvideo+bestaudio'

    # Test parsing of --format
    (parser, opts, args) = parseOpts(['--format','bestvideo[ext=mp4]+bestaudio[ext=m4a]'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]'

    # Test parsing of --format