

# Generated at 2022-06-22 09:10:55.510200
# Unit test for function parseOpts
def test_parseOpts():
    from downloader import YoutubeDL
    ydl = YoutubeDL()
    ydl.params = {}
    ydl.cache.remove()
    opts, args = parseOpts(['--test-option'])
    assert opts.test_option
    ydl.cache.remove()
    opts, args = parseOpts(['--test-option', '--cache-dir', '~/foo'])
    assert opts.test_option
    assert opts.cachedir == os.path.expanduser('~/foo')
    ydl.cache.remove()
    opts, args = parseOpts(['--test-option', '--cache-dir', '~/foo'], overrideArguments = ['--test-option', '--cache-dir', os.path.expanduser('~/.bar')])
    assert opt

# Generated at 2022-06-22 09:11:01.202680
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: Add more tests.
    assert parseOpts(['-v'])[1].verbose is True
    assert parseOpts(['--verbose'])[1].verbose is True
    assert parseOpts(['--proxy', 'http://user:pass@a.com:123'])[1].proxy == 'http://user:pass@a.com:123'
# parseOpts()



# Generated at 2022-06-22 09:11:13.211896
# Unit test for function parseOpts
def test_parseOpts():
    test_args = ['youtube-dl', '-i', '--yes-playlist', '--youtube-skip-dash-manifest', '--no-continue', '--no-check-certificate', '--no-mtime', '--no-part', '--restrict-filenames', '-o', '/media/nas/Music/%(autonumber)s-%(uploader)s/%(uploader)s - %(title)s.%(ext)s', '--max-downloads', '1', '--max-filesize', '1g', '--batch-file', '/mnt/nas/inet/downloads/temp/_playlist_recent_videos.txt']
    _, opts, _ = parseOpts(test_args)
    assert opts.ignoreerrors is True
    assert opts.playliststart

# Generated at 2022-06-22 09:11:17.783665
# Unit test for function parseOpts
def test_parseOpts():
    try:
        opts, args = parseOpts()
    except:
        import traceback
        traceback.print_exc()
test_parseOpts.test = True
test_parseOpts.__doc__ = parseOpts.__doc__


# Generated at 2022-06-22 09:11:28.662183
# Unit test for function parseOpts
def test_parseOpts():
    # Stdout test
    def parseOpts_stdout(args, expected_stdout, message):
        stdout_org = sys.stdout
        sys.stdout = StringIO()

        try:
            parseOpts(args)
        except:
            assert False, message

        sys.stdout.seek(0)
        stdout_res = sys.stdout.read()
        sys.stdout = stdout_org
        assert expected_stdout == stdout_res, message

    # General tests

    parseOpts_stdout(['--version'], __version__ + '\n', "Option --version does not work")
    parseOpts_stdout(['--help'], __version__ + '\n', "Option --help does not work")

# Generated at 2022-06-22 09:11:35.325706
# Unit test for function parseOpts
def test_parseOpts():
    opts = ['-f', 'best', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(None, overrideArguments=opts)
    assert opts.format == 'best'
    assert opts.geturl
    assert not opts.usenetrc
    assert opts.username is None
    assert opts.password is None

    opts = ['--username', 'foo', '--password', 'bar']
    parser, opts, args = parseOpts(None, overrideArguments=opts)
    assert opts.usenetrc
    assert opts.username == 'foo'
    assert opts.password == 'bar'

    opts = ['-f', 'bestvideo+bestaudio']
   

# Generated at 2022-06-22 09:11:45.503898
# Unit test for function parseOpts
def test_parseOpts():
    import io
    import json

    # Check simple positional arguments
    parser, opts, args = parseOpts(['--ignore-config', '--dump-user-agent', 'positional', 'arguments'])
    assert opts.dump_user_agent
    assert args == ['positional', 'arguments']

    # Check simple option arguments
    parser, opts, args = parseOpts(['--ignore-config', '--dump-user-agent'])
    assert opts.dump_user_agent

    # Check short and long option arguments with no- prefix
    parser, opts, args = parseOpts(['--ignore-config', '--no-playlist'])
    assert opts.noplaylist

    parser, opts, args = parseOpts(['--ignore-config', '-i'])
    assert opts

# Generated at 2022-06-22 09:11:57.586246
# Unit test for function parseOpts
def test_parseOpts():
    test_parseOpts.t1 = lambda: parseOpts(['-i', '-f', '22'])[1]
    test_parseOpts.t2 = lambda: parseOpts(['-f', '22', '-i'])[1]
    test_parseOpts.t3 = lambda: parseOpts(['-f', '-1', '--max-downloads=0'])[1]
    assert test_parseOpts.t1().verbose is True
    assert test_parseOpts.t2().verbose is True
    assert test_parseOpts.t1().usenetrc is True
    assert test_parseOpts.t2().usenetrc is True
    assert test_parseOpts.t1().format == '22'
    assert test_parseOpts.t2().format

# Generated at 2022-06-22 09:12:04.098741
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-f22', '--buffer-size', '8192', '--ignore-config', '--no-check-certificate', '--', 'foo', 'bar'])
    assert opts.usenetrc is False
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.videopassword is None
    assert opts.ap_username is None
    assert opts.ap_password is None
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.no_warnings is False
    assert opts.forceurl is False
    assert opts.forcethumbnail is False
    assert opts.forceduration is False
    assert opt

# Generated at 2022-06-22 09:12:12.990496
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encode_compat_str
    opts_list = [
        '--verbose',
        '--get-url',
        'https://www.youtube.com/watch?v=BaW_jenozKc'
    ]

    parser, opts, args = parseOpts(opts_list)
    assert opts.geturl
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']
    assert not opts.gettitle
    assert not opts.getid
    assert not opts.getthumbnail
    assert not opts.getdescription
    assert not opts.getfilename
    assert not opts.getformat
    assert not opts.getduration 
    assert not opts.get_filesize
    assert opts.simulate

# Generated at 2022-06-22 09:12:45.791433
# Unit test for function parseOpts

# Generated at 2022-06-22 09:12:52.338664
# Unit test for function parseOpts
def test_parseOpts():
    def check_parseOpts(overrideArguments):
        (parser, opts, args) = parseOpts(overrideArguments)
        # parsing should be successful
        assert (opts.verbose)
        # arguments should be parsed
        assert (opts.username == 'testname')
        assert (opts.password == 'testpass')
        assert (opts.usenetrc_machine == 'testhost')

    # overriding positional arguments
    check_parseOpts(['-v', '--username=testname', '--password=testpass', '--usenetrc-machine=testhost'])

    # overriding options
    check_parseOpts(['-v', '--ignore-config', 'youtube-dl'])

# Save the command line arguments for other callers

# Generated at 2022-06-22 09:13:04.549963
# Unit test for function parseOpts
def test_parseOpts():
    import optparse
    parser = optparse.OptionParser(add_help_option=False)
    parser.add_option('-h', '--help', action='store_true')
    parser.add_option('-v', '--verbose', action='store_true')
    parser.add_option(
        '-u', '--username', action='store', dest='username', default='')
    parser.add_option(
        '-p', '--password', action='store', dest='password', default='')
    parser.add_option(
        '-f', '--format', action='store', dest='format', default='')

    a = ['-u', 'user', '-p', 'pass', '-f', '33', 'bar']
    b = ['-v']
    c = ['-h']

# Generated at 2022-06-22 09:13:16.540849
# Unit test for function parseOpts
def test_parseOpts():
    args = ['-u', 'user', '-p', 'pass', 'pl', 'http://www.youtube.com/watch?v=BaW_jenozKc', '-o', '%(id)s.%(ext)s', '-a', 'mylist']
    parser, opts, args = parseOpts(args)
    assert(args == ['http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert(opts.username == 'user')
    assert(opts.password == 'pass')
    assert(opts.playliststart == 1)
    assert(opts.playlistend == sys.maxsize)
    assert(opts.usenetrc == False)
    assert(opts.ratelimit == None)

# Generated at 2022-06-22 09:13:22.102974
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['--username', 'foo', '--password', 'bar', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1]
    assert opts.username == 'foo'
    assert opts.password == 'bar'
# test_parseOpts()



# Generated at 2022-06-22 09:13:33.324707
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile


# Generated at 2022-06-22 09:13:35.199375
# Unit test for function parseOpts
def test_parseOpts():
    if __name__ == '__main__':
        print(repr(parseOpts()[0].parse_args(['-U', 'testuser', 'testvals'])))


# Generated at 2022-06-22 09:13:40.461241
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-h'])
    assert opts.help is True

    opts, args = parseOpts(['-u', 'user'])
    assert opts.usenetrc == True
    assert opts.username == 'user'
    assert opts.password == None

    opts, args = parseOpts(['-p', 'pass'])
    assert opts.password == 'pass'
    assert opts.username == None

test_parseOpts()



# Generated at 2022-06-22 09:13:50.417024
# Unit test for function parseOpts
def test_parseOpts():
    # test with no args
    parser, opts, args = parseOpts()
    assert opts.username is None
    assert opts.password is None
    assert opts.ap_password is None
    assert opts.verbose is False

    # test with simple args
    parser, opts, args = parseOpts(overrideArguments=['-u', 'foouser', '-p', 'foopass'])
    assert opts.username == 'foouser'
    assert opts.password == 'foopass'
    assert opts.ap_password is None
    assert opts.verbose is False

    # test with config file
    parser, opts, args = parseOpts(overrideArguments=['--config-location', 'tests/youtube-dl.conf'])

# Generated at 2022-06-22 09:13:58.601085
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os.path import isfile
    from os import remove, mkdir

    # --no-check-certificate
    _, opts, args = parseOpts(['--no-check-certificate'])
    assert opts.nocheckcertificate is True

    # --prefer-insecure
    _, opts, args = parseOpts(['--prefer-insecure'])
    assert opts.prefer_insecure is True
    _, opts, args = parseOpts(['--no-prefer-insecure'])
    assert opts.prefer_insecure is False

    # --video-password
    _, opts, args = parseOpts(['--video-password', '123456'])
    assert opts.videopassword == '123456'


# Generated at 2022-06-22 09:14:28.721205
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args1 = parseOpts([])
    assert opts.preferredcodec == 'mp4'
    assert len(args1) == 0
    parser, opts, args1 = parseOpts(args=['-v'])
    assert opts.preferredcodec == 'mp4'
    assert len(args1) == 0

    parser, opts, args1 = parseOpts(['-4'])
    assert opts.ipv6 == False
    parser, opts, args1 = parseOpts(['--prefer-ipv6'])
    assert opts.ipv6 == True
    parser, opts, args1 = parseOpts(['--no-prefer-ipv6'])
    assert opts.ipv6 == False

    parser, opts, args1 = parseOpt

# Generated at 2022-06-22 09:14:39.155485
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing parseOpts...')
    opts = parseOpts()[1]

    for opt in ('usenetrc', 'password', 'video_password', 'ap_password', 'ap_username',
                'username', 'sleep_interval'):
        if opt in opts.__dict__:
            assert opts.__dict__[opt] is None, \
                '%s option must default to None.' % opt


# Generated at 2022-06-22 09:14:49.472238
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'a', '--debug'])
    assert opts.username == 'a'
    assert opts.usenetrc is False
    assert opts.debug == True

    parser, opts, args = parseOpts(['-u', 'a', '--no-debug'])
    assert opts.username == 'a'
    assert opts.usenetrc is True
    assert opts.debug == False

    parser, opts, args = parseOpts(['-i', '-u', 'a', '--password', 'b'])
    assert opts.username == 'a'
    assert opts.password == 'b'
    assert opts.usenetrc is True

    parser, opts, args = parseOpts([])
    assert opt

# Generated at 2022-06-22 09:15:01.996396
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', '22/37/38', '--max-downloads', '3', 'youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '22/37/38'
    assert opts.usenetrc == False
    assert opts.username is None
    assert opts.password is None
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format_limit == None
    assert opts.listformats == False
    assert opts.list_thumbnails == False
    assert opts.matched_files is None
    assert opts.play

# Generated at 2022-06-22 09:15:06.506184
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == None
    assert opts.password == None
    assert args == []


# Generated at 2022-06-22 09:15:14.820499
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import OptionValueError
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False

    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose == True
    assert opts.quiet == False

    parser, opts, args = parseOpts(['--quiet'])
    assert opts.verbose == False
    assert opts.quiet == True

    # -v has the highest priority
    parser, opts, args = parseOpts(['-v', '-q'])
    assert opts.verbose == True
    assert opts.quiet == False

    # -q has no effect if -v is active

# Generated at 2022-06-22 09:15:28.136807
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv as sys_argv
    from sys import stdout as sys_stdout
    from sys import stderr as sys_stderr
    from tempfile import TemporaryFile
    from copy import copy

    old_sys_argv = copy(sys_argv)
    old_sys_stdout = copy(sys_stdout)
    old_sys_stderr = copy(sys_stderr)

    def setUp():
        sys_stdout = sys_stderr = TemporaryFile()
        sys_argv[:] = ['youtube-dl']
    def tearDown():
        sys_argv[:] = old_sys_argv[:]
        sys_stdout = old_sys_stdout
        sys_stderr = old_sys_stderr


# Generated at 2022-06-22 09:15:30.641024
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    old_argv = argv
    argv = [u'-U', u'unit_test']
    try:
        opts, args = parseOpts()
        assert opts.username == u'unit_test'
    finally:
        argv = old_argv

# Generated at 2022-06-22 09:15:42.893471
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', '18', '-v', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.verbose
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors
    assert opts.nooverwrites
    assert opts.usenetrc
    assert opts.ratelimit == '1M'
    assert not opts.retries
    assert not opts.buffersize
    assert opts.noresizebuffer
    assert opts.proxy
    assert opts.noprogress
    assert not opts.playliststart
    assert opts.playlistend == '1'
    assert opts.n

# Generated at 2022-06-22 09:15:47.063808
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    # test if global --help invokes parser.print_help; see bug #387
    parser.print_help = lambda: None
    parser.print_help = lambda: _real_do_test('global --help')
    parseOpts(['--help'])


# Generated at 2022-06-22 09:16:23.570410
# Unit test for function parseOpts
def test_parseOpts():
    args_input = ['--username', 'user', '--password', 'pass', '--', 'https://www.youtube.com/watch?v=BaW_jenozKc']
    args_output = ['https://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(args_input)
    print('Test case running ... ')
    if len(args) == len(args_output) and args[0] == args_output[0] and opts.username == 'user' and opts.password == 'pass':
        print('Test case passed ...')
        return True
    else:
        print('Test case failed ...')
        return False
# Test case execution
if __name__ == '__main__':
    test_parseOpts()
 
#

# Generated at 2022-06-22 09:16:27.481587
# Unit test for function parseOpts
def test_parseOpts():
    class FakeParser(object):
        def add_option(self, *args, **kargs):
            pass
        def add_option_group(self, *args, **kargs):
            pass
        def parse_args(self, args):
            return [], []
    _parseOpts(FakeParser())



# Generated at 2022-06-22 09:16:35.806757
# Unit test for function parseOpts
def test_parseOpts():
    """Tests if the command line arguments are parsed correctly"""
    import tempfile
    config_file = None

# Generated at 2022-06-22 09:16:38.105503
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert len(args) == 0 or not len(args)
    assert parser.format_help()


# Generated at 2022-06-22 09:16:49.150836
# Unit test for function parseOpts
def test_parseOpts():
    from urllib.parse import parse_qs, urlsplit, parse_qsl, urlunsplit
    usock = open(os.path.devnull, 'r')
    try:
        urllib.request.urlopen('http://youtube.com', timeout=5)
    except (urllib.request.URLError, socket.timeout):
        # Socket is not usable, youtube-dl is probably being tested on a restricted environment
        # Create a fake socket
        usock = open(os.path.devnull, 'r')
        urllib.request.urlopen = lambda *x: usock

    def _qs(url):
        return parse_qsl(urlsplit(url).query)


# Generated at 2022-06-22 09:16:57.738202
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert len(opts.__dict__.keys()) > 10

    # test for custom config
    with make_tempdir() as temp_path:
        config_file = os.path.join(temp_path, 'youtube-dl.conf')
        with open(config_file, 'w') as outf:
            outf.write('--no-playlist')
        parser, opts, args = parseOpts(['-i', '--config-location', config_file])
        assert len(opts.__dict__.keys()) > 10
        assert opts.noplaylist
        assert opts.ignoreconfig

# -- List indexing options


# Generated at 2022-06-22 09:17:06.645176
# Unit test for function parseOpts
def test_parseOpts():
    t1 = ['--verbose', '--dump-user-agent']
    t2 = ['--no-warnings', '--youtube-skip-dash-manifest', '--no-playlist']
    t3 = ['--limit-rate', '1.0M', '--no-mtime', '--no-part']
    t4 = ['--write-description', '--write-info-json', '--no-progress', '--console-title']
    t5 = ['--all-subs', '--skip-download', '--sub-format', 'srt']
    t6 = ['--username', 'toto', '--password', 'tutu']
    t7 = ['--proxy', '1.1.1.1']
    t8 = ['--call-home']

# Generated at 2022-06-22 09:17:16.305894
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    from ytdl.update import update
    from ytdl.util import compat_expanduser, compatible_shell_quote
    from ytdl.YoutubeDL import DEFAULT_OUTTMPL
    from ytdl.extractor import gen_extractors, list_extractors

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    password = '12345'

    parser, opts, _ = parseOpts(['-U'])
    assert opts.update_self
    parser, opts, _ = parseOpts(['-h'])
    assert opts.help

    # Test __num__ placeholder

# Generated at 2022-06-22 09:17:24.874095
# Unit test for function parseOpts

# Generated at 2022-06-22 09:17:30.624772
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-h'])
    assert opts.help

    opts, args = parseOpts(['-U', 'test_username', '-P', 'test_password', 'http://example.org'])
    assert opts.username == 'test_username'
    assert opts.password == 'test_password'
    assert opts.usenetrc == False
    assert 'http://example.org' in args

    opts, args = parseOpts(['-u', 'test_username', '-p', 'test_password', 'http://example.org'])
    assert opts.username == 'test_username'
    assert opts.password == 'test_password'
    assert opts.usenetrc == True
    assert 'http://example.org' in args

    opt

# Generated at 2022-06-22 09:18:30.693494
# Unit test for function parseOpts
def test_parseOpts():
    def assertOpts(args, **kw):
        parser, opts, _args = parseOpts(args)
        for k, v in kw.items():
            assert opts.__dict__[k] == v, '%s: %s != %s' % (k, opts.__dict__[k], v)

    assertOpts([], verbose=False)
    assertOpts(['-v'], verbose=True)
    assertOpts(['--verbose'], verbose=True)
    assertOpts(['-v', '--verbose'], verbose=True)
    assertOpts(['--dump-pages'], dump_pages=True)

# Generated at 2022-06-22 09:18:43.266386
# Unit test for function parseOpts
def test_parseOpts():
    # Test the help message
    with io.BytesIO() as buf, redirect_stdout(buf):
        parser, _, _ = parseOpts(['--help'])
    assert b'--dump-user-agent' in buf.getvalue()

    # Test parsing of non-ascii
    parser, opts, _ = parseOpts(['--encoding', 'utf-8', '-o', '™'])
    assert opts.outtmpl == '™'

    # Test --no-check-certificate
    parser, opts, _ = parseOpts(['--no-check-certificate'])
    assert opts.nocheckcertificate is True
    parser, opts, _ = parseOpts(['--no-check-certificate', '--check-certificate'])
    assert opts.noche

# Generated at 2022-06-22 09:18:46.870080
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert(parser)
    assert(opts)
    assert(args)
# End unit test
# End function parseOpts


# Generated at 2022-06-22 09:18:51.735466
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f','18','https://www.youtube.com/watch?v=BaW_jenozKc'])
# TEST: parseOpts
test_parseOpts()

# Generated at 2022-06-22 09:19:03.751707
# Unit test for function parseOpts

# Generated at 2022-06-22 09:19:12.555433
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    sys.argv = ['youtube-dl']
    # Test for simple option
    sys.argv += ['--version']
    parser, opts, args = parseOpts()
    assert opts.version

    # Test for options with argument
    sys.argv = ['youtube-dl', '--proxy', 'socks5://127.0.0.1:1080']
    parser, opts, args = parseOpts()
    assert opts.proxy == 'socks5://127.0.0.1:1080'

    # Test for option that takes no argument
    sys.argv = ['youtube-dl', '-h']
    out = StringIO()

# Generated at 2022-06-22 09:19:22.676739
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import format_bytes
    from .compat import compat_str
    from .compat import compat_shlex_split
    from .compat import is_py2

    def test(arg):
        global opts
        parser, opts, args = parseOpts(arg)
        assert opts.usenetrc == False
        assert opts.username == None
        assert opts.password == None

    def test_password():
        global opts
        parser, opts, args = parseOpts(arg)
        assert opts.usenetrc == True
        assert opts.username == None
        assert opts.password == '123456'

    def test_username():
        global opts
        parser, opts, args = parseOpts(arg)
        assert opts.usenetrc == True


# Generated at 2022-06-22 09:19:31.366614
# Unit test for function parseOpts

# Generated at 2022-06-22 09:19:43.216639
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encode_str
    from collections import namedtuple
    FakeOptionParser = namedtuple('FakeOptionParser', ['add_option'])
    FakeOption = namedtuple('FakeOption', ['dest', 'type'])
    FakeArgs = namedtuple('FakeArgs', ['__getitem__', '__contains__'])
    FakeGlobalArgs = namedtuple('FakeGlobalArgs', ['__getitem__', '__contains__', '__setitem__'])

    def _setGlobalArgs(args):
        parseOpts.GLOBAL_ARGS = FakeGlobalArgs(
            lambda x: args[x], lambda x: x in args, lambda x, y: setattr(args, x, y))


# Generated at 2022-06-22 09:19:54.635166
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)
    parser, opts, args = parseOpts([])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None

    parser, opts, args = parseOpts(['--usenetrc', '--username=user', '--password=pass'])
    assert opts.usenetrc == True
    assert opts.username == 'user'
    assert opts.password