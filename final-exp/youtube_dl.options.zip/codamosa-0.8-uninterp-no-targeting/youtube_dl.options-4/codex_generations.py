

# Generated at 2022-06-22 09:10:58.208977
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)



# Generated at 2022-06-22 09:11:09.851417
# Unit test for function parseOpts
def test_parseOpts():
    if not os.path.exists('test_parseOpts'):
        os.mkdir('test_parseOpts')


# Generated at 2022-06-22 09:11:11.159771
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.run_docstring_examples(parseOpts, globals())


# Generated at 2022-06-22 09:11:23.594415
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeArgument
    from .compat import compat_getenv

    parser, opts, args = parseOpts(['--username', 'user', '--password', 'hunter2'])
    assert opts.username == 'user'
    assert opts.password == 'hunter2'
    assert not getattr(opts, 'usenetrc', False)
    assert args == []
    assert not opts.noprogress

    parser, opts, args = parseOpts(
        ['--dump-user-agent', '-v', 'https://example.com'], overrideArguments=['--verbose'])
    assert opts.verbose
    assert opts.dump_user_agent
    assert opts.quiet is False
    assert args == ['https://example.com']

    # Test Windows style arguments (

# Generated at 2022-06-22 09:11:25.191424
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass
# }}}

# Retry{{{

# Generated at 2022-06-22 09:11:27.945295
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    #check if parser,opts,args are not none
    assert parser and opts and args is not None

# Command line program

# Generated at 2022-06-22 09:11:32.473574
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert isinstance(parser, ArgumentParser)
    assert isinstance(opts, Namespace)
    assert isinstance(args, list)

# Return a string to be displayed to the user,
# which contains the values of a Namespace object

# Generated at 2022-06-22 09:11:43.043738
# Unit test for function parseOpts

# Generated at 2022-06-22 09:11:55.002484
# Unit test for function parseOpts
def test_parseOpts():
    from .youtube_dl.extractor.youtube import YoutubeIE

    parser, opts, args = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc', 'https://vimeo.com/ondemand/somefilm'])

    assert isinstance(parser, optparse.OptionParser)
    assert args == []
    assert opts.verbose == False

    extractor = YoutubeIE()
    assert opts.forced_urls == [
        (extractor, 'https://www.youtube.com/watch?v=BaW_jenozKc'),
        (extractor, 'https://vimeo.com/ondemand/somefilm')]
    assert opts.playlist_items == None
    assert opts.playlist_start == 1
    assert opts.playlist_end == None

# Generated at 2022-06-22 09:11:58.493894
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.outtmpl == u'defaultTemplate'
# End of unit tests for function parseOpts


# Generated at 2022-06-22 09:12:22.655994
# Unit test for function parseOpts
def test_parseOpts():
    from nose.tools import *
    from sys import argv as sysArgv
    def parseOpts(args, config=None):
        try:
            opts = {}
            if config is not None:
                if not isinstance(config, unicode):
                    config = config.decode('utf-8')
                opts['config_location'] = config

            parser, opts, _ = parseOpts_(args, **opts)

            if opts.subtitleslangs:
                opts.subtitleslangs = opts.subtitleslangs.split(',')
            return opts
        except (SystemExit, ValueError):
            raise Exception('Error parsing arguments')


# Generated at 2022-06-22 09:12:29.102815
# Unit test for function parseOpts
def test_parseOpts():
    # TODO add more unit tests
    from nose.tools import assert_is_instance
    # TODO assert_equal

    parser, opts, args = parseOpts()

    assert_is_instance(parser, optparse.OptionParser)
    assert_is_instance(opts, optparse.Values)
    assert_is_instance(args, list)


# Generated at 2022-06-22 09:12:40.398096
# Unit test for function parseOpts
def test_parseOpts():
    return # TODO: enable it again
    # overrideArguments provided
    import io
    parser, opts, args = parseOpts(['-o', '-', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert_equal(opts.outtmpl, '-')
    assert_equal(len(args), 1)
    assert_equal(args[0], 'http://youtube.com/watch?v=BaW_jenozKc')
    assert_equal(opts.quiet, False)

    # config-location provided and exists
    fd, tmp_filename = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as tmp_conf:
        tmp_conf.write('-o -\n')
    parser, opts, args = parseOpts

# Generated at 2022-06-22 09:12:48.913555
# Unit test for function parseOpts
def test_parseOpts():
    import optparse

    parser = optparse.OptionParser()
    parser.add_option('-t', '--testopt')
    parser.add_option('-o', '--outtmpl')

    # Test config file support
    default_config = compat_expanduser(os.path.join('~', '.config', 'youtube-dl', 'config'))
    with temp_filename('.conf') as config_filename:
        write_string(config_filename, '[youtube]\ntestopt=-T\nouttmpl=%(title)s-%%(id)s')


# Generated at 2022-06-22 09:13:01.216109
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["--username", "Logan", "--password", "1234567890"])
    assert opts.usename == "Logan"
    assert opts.password == "1234567890"

# start
if __name__ == '__main__':
    # Set terminal encoding to support characters from all languages
    # https://bugzilla.gnome.org/show_bug.cgi?id=562106
    # http://stackoverflow.com/a/10746989/35070
    if sys.platform == 'win32':
        import ctypes
        import ctypes.wintypes
        SetConsoleCP = ctypes.windll.kernel32.SetConsoleCP
        SetConsoleCP.argtypes = [ctypes.wintypes.UINT]
        SetConsoleCP.restype

# Generated at 2022-06-22 09:13:11.698167
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert not opts.geturl
    assert opts.gettitle
    assert opts.nooverwrites
    assert opts.autonumber_start == 1
    assert opts.autonumber_size == 2
    assert opts.verbose
    assert opts.quiet
    assert not opts.simulate
    assert opts.get_format
    assert opts.usenetrc
    assert opts.username == 'user'
    assert opts.password == 'pwd'
    assert opts.usetitle
    assert opts.usetitle == opts.literal

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-22 09:13:20.562711
# Unit test for function parseOpts
def test_parseOpts():
    _, opts, args = parseOpts(['-i', '-4', '--no-check-certificate', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.ignoreerrors
    assert opts.source_address == '0.0.0.0'
    assert opts.no_check_certificate
    assert IsType(args, list)
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'

    class ReplacementWriter(object):
        def __init__(self):
            self.bufs = []

        def write(self, s):
            self.bufs.append(s)

        def get(self):
            return ''.join(self.bufs)


# Generated at 2022-06-22 09:13:26.996252
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO

    def _parseOpts(args):
        (parser, opts, _) = parseOpts(args.split())
        stream = StringIO()
        parser.print_help(file=stream)
        return opts, stream.getvalue()

    assert _parseOpts('') == (None, '')
    assert _parseOpts('-h') == (None, '')
    assert _parseOpts('-U abc') == (None, '')
    assert _parseOpts('-U abc -P def') == (None, '')
    assert _parseOpts('-u abc') == (None, '')
    assert _parseOpts('-u abc -p def') == (None, '')

# Generated at 2022-06-22 09:13:36.771405
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts()[1]
    # TODO: Figure out how to test this
    #assert opts.proxy == '127.0.0.1:8118'
    #assert opts.extractaudio is False
    #assert opts.audioformat == 'best'
    #assert opts.outtmpl == '%(title)s-%(id)s-%(format)s.%(ext)s'
    #assert opts.ignoreerrors is False
    #assert opts.ratelimit == 'nolimit'
    #assert opts.quiet is False
    #assert opts.nocheckcertificate is False
    #assert opts.proxy == '127.0.0.1:8118'
    #assert opts.prefer_ffmpeg is False
    #assert opts.pre

# Generated at 2022-06-22 09:13:47.213664
# Unit test for function parseOpts
def test_parseOpts():
    # Test --proxy
    sys.argv = ['youtube-dl', '--proxy', '1.1.1.1:8080', 'video_url']
    parser, opts, args = parseOpts()
    assert opts.proxy == '1.1.1.1:8080'
    # Test --socket-timeout
    for arg in ('--socket-timeout', '--timeout'):
        sys.argv = ['youtube-dl', arg, '10', 'video_url']
        parser, opts, args = parseOpts()
        assert opts.socket_timeout == 10
    # Test --default-search
    sys.argv = ['youtube-dl', '--default-search', 'fixup_error', 'video_url']
    parser, opts, args = parseOpts()
    assert opts.default_

# Generated at 2022-06-22 09:14:05.544128
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass


# Generated at 2022-06-22 09:14:16.201539
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([
        "--ignore-config", "--username", "test", "--password", "test", "--verbose", "--no-warnings",
        "--sub-format", "ass/best",
        "--min-sleep-interval", "1",
        "https://www.youtube.com/watch?v=BaW_jenozKc"])

    assert(parser.get_usage() is not None)
    assert(isinstance(opts, optparse.Values))
    assert(isinstance(args, list))
    assert(opts.username == "test")
    assert(opts.password == "test")
    assert(opts.sub_format == "ass/best")
    assert(opts.min_sleep_interval == 1)

# Generated at 2022-06-22 09:14:23.605183
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.prefer_ffmpeg
    assert 'bestaudio' in opts.format
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert not opts.usenetrc
    assert not opts.writedescription
    assert not opts.writesubtitles
    assert not opts.writeautomaticsub
    assert not opts.allsubtitles
    assert not opts.allsubtitles
    assert not opts.list_thumbnails


# Generated at 2022-06-22 09:14:34.610356
# Unit test for function parseOpts
def test_parseOpts():
    class FakeOptionParser(object):
        def __init__(self):
            self.option_groups = []
        def add_option_group(self, obj):
            self.option_groups.append(obj)
        def _get_all_options(self):
            return sum((group.option_list for group in self.option_groups), [])
        def parse_args(self, args):
            return ([o for e, o in enumerate(self._get_all_options()) if e in args], args)

    parser = FakeOptionParser()
    parseOpts(parser)
    assert len(parser._get_all_options()) == len(set(parser._get_all_options()))
    all_options = parser._get_all_options()

# Generated at 2022-06-22 09:14:46.438311
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv as org_argv
    from youtube_dl.utils import encodeFilename

# Generated at 2022-06-22 09:14:59.412932
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-g', '-v'])
    assert opts.verbose
    assert opts.geturl
    assert not opts.gettitle
    parser, opts, args = parseOpts(['-g', '--get-title'])
    assert opts.geturl
    assert opts.gettitle

    with temp_name('config') as config_file:
        with open(config_file, 'w') as outf:
            outf.write('--get-url\n')
        parser, opts, args = parseOpts(['--config-location=%s' % config_file])
        assert opts.geturl
        parser, opts, args = parseOpts(['--config-location=%s' % config_file, '--ignore-config'])

# Generated at 2022-06-22 09:15:10.878974
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import Option
    from youtube_dl.utils import compat_expanduser

    def assertEqual(a, b):
        if a != b:
            raise AssertionError(a + ' != ' + b)

    def _readOptions(filename):
        filename = compat_expanduser(filename)
        if not os.path.exists(filename):
            return []
        return [u'--%s=%s' % (k.replace('_', '-'), compat_str(v))
                for k, v in readOptions(filename).items()]

    _readOptions('"this" "file" "does" "not" "exist"')
    _readOptions('--this --file --does --not --exist')
    _readOptions('--this --file --does= --not= --exist')
    _read

# Generated at 2022-06-22 09:15:15.640662
# Unit test for function parseOpts
def test_parseOpts():
    import sys, tempfile
    if sys.version_info[0] <= 2:
        from StringIO import StringIO
    else:
        from io import StringIO
    from youtube_dl.compat import compat_expanduser

    def run_parseOpts(overrideArguments=None, stdin=None):
        parser, opts, args = parseOpts(overrideArguments)
        if stdin is not None:
            with tempfile.TemporaryFile(mode='w+b') as f:
                f.write(stdin.encode('utf-8'))
                f.seek(0)
                sys.stdin = f
                opts, args = parser.parse_args(overrideArguments)
        return opts, args


    test_opts = lambda oa, **kwargs: run_parseOpt

# Generated at 2022-06-22 09:15:28.360546
# Unit test for function parseOpts
def test_parseOpts():
    # testing option groups
    assert ('general' in opts_groups
            and 'network' in opts_groups
            and 'geo' in opts_groups
            and 'selection' in opts_groups
            and 'downloader' in opts_groups
            and 'filesystem' in opts_groups
            and 'thumbnail' in opts_groups
            and 'verbosity' in opts_groups
            and 'workarounds' in opts_groups
            and 'video_format' in opts_groups
            and 'subtitles' in opts_groups
            and 'authentication' in opts_groups
            and 'adobe_pass' in opts_groups
            and 'postproc' in opts_groups)
    # testing options

# Generated at 2022-06-22 09:15:36.722380
# Unit test for function parseOpts
def test_parseOpts():
    testargs = ['youtube-dl', 'http://youtu.be/0lPxC9bi9l8',
                '-f', '=22/18/35',
                '--proxy', '1.2.3.4:88',
                '-o', '/tmp/%(autonumber)s-%(title)s-%(id)s.%(ext)s']
    parser, opts, args = parseOpts(testargs)

    assert not opts.verbose
    assert opts.format == '22/18/35'
    assert not opts.noplaylist
    assert opts.proxy == '1.2.3.4:88'

# Generated at 2022-06-22 09:16:04.228166
# Unit test for function parseOpts
def test_parseOpts():
    from StringIO import StringIO
    import sys

    from youtube_dl.utils import encode_compat_str

    # Testing with no configuration file, no --password
    # TODO more tests for this function
    # (fakes a no configuration file and no password on command line)
    sys.argv = ['youtube-dl']
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    try:
        out = StringIO()
        sys.stdout = out
        err = StringIO()
        sys.stderr = err
        opts, args = parseOpts()
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr

    assert opts.password is None
    assert opts.username is None

# Generated at 2022-06-22 09:16:08.891097
# Unit test for function parseOpts
def test_parseOpts():
    import shlex

# Generated at 2022-06-22 09:16:20.149027
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-q'])
    assert opts.quiet
    parser, opts, args = parseOpts(['--no-check-certificate'])
    assert opts.nocheckcertificate
    parser, opts, args = parseOpts(['--max-filesize', '5M'])
    assert opts.max_filesize == '5M'
    parser, opts, args = parseOpts(['--playlist-start', '5'])
    assert opts.playliststart == 5
    parser, opts, args = parseOpts(['--playlist-end', '10'])
    assert opts.playlistend == 10
    parser, opts, args = parseOpts(['--cookies', '/tmp/foo.txt'])
    assert opts

# Generated at 2022-06-22 09:16:30.021119
# Unit test for function parseOpts
def test_parseOpts():
    import youtube_dl.version
    import xml.etree.ElementTree
    print(youtube_dl.version.__version__)
    parser, opts, args = parseOpts(overrideArguments=['-h'])
    # print(help(parser))
    # print(parser.print_help())
    print('opts: ',  opts)
    # print('args: ', args)
    print('opts.format: ', opts.format)
    print('opts.audio_format: ', opts.audio_format)
    print('opts.no_warnings: ', opts.no_warnings)
    print('opts.no_check_certificate: ', opts.no_check_certificate)
    print('opts.proxy: ', opts.proxy)

# Generated at 2022-06-22 09:16:34.267708
# Unit test for function parseOpts
def test_parseOpts():
    import sys

    class ToStr(object):
        def __init__(self, o):
            self.o = o
        def __str__(self):
            return str(self.o)

    # UnicodeEncodeError: 'ascii' codec can't encode character u'\u2588' in position 45: ordinal not in range(128)
    sys.argv = str(sys.argv).encode(preferredencoding()).decode('unicode_escape').split('\\')
    sys.argv = [ToStr(a) for a in sys.argv]
    parser, opts, args = parseOpts()

# _readOptions(filename)
#   Reads an options file (INI format) from the given filename.
#   Returns a list of command-line arguments (i.e. argv)

# Generated at 2022-06-22 09:16:38.412113
# Unit test for function parseOpts
def test_parseOpts():
    _, opts, args = parseOpts()
    assert opts.username == 'unit_test_username'
    assert opts.password == 'unit_test_password'
    assert opts.nopassword is True
    assert opts.videopassword == 'unit_test_videopassword'



# Generated at 2022-06-22 09:16:40.021627
# Unit test for function parseOpts
def test_parseOpts():
    opts_parser, _, _ = parseOpts()
    assert opts_parser



# Generated at 2022-06-22 09:16:51.241898
# Unit test for function parseOpts
def test_parseOpts():
    from optparse import OptionValueError
    from youtube_dl import YoutubeDL
    # Make sure that no exception is raised
    parseOpts()

    # Make sure that parseOpts doesn't accept invalid values
    try:
        parseOpts(['--format=invalid', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
        raise AssertionError("Didn't raise OptionValueError on invalid format value")
    except OptionValueError as oe:
        pass

    # Make sure that parseOpts doesn't accept invalid values

# Generated at 2022-06-22 09:16:53.401820
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts()



# Generated at 2022-06-22 09:17:04.534603
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.video_password == 'abc'
    assert opts.usenetrc == True
    assert opts.no_warnings == True
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == True
    assert opts.skip_download == True
    assert opts.format == 'best'
    assert opts.listformats == False
    assert opts.outtmpl == '/tmp/%(uploader)s/%(title)s-%(id)s-%(format)s.%(ext)s'
    assert opts.ignoreerrors == True
    assert opts.forceurl == True
   

# Generated at 2022-06-22 09:17:50.967570
# Unit test for function parseOpts
def test_parseOpts():

    # Set option help format
    class TestHelpFormatter(optparse.IndentedHelpFormatter):
        def format_option(self, option):
            if option.help:
                help_text = 'options: ' + option.help.strip('. ').capitalize()
            else:
                help_text = ''
            return '{0: <20} {1}\n'.format(str(option).replace('\n', ' '), help_text)

    # True and False are for continue_dl and prefer_ffmpeg
    # since they are stored as Properties and, hence, cannot be
    # compared directly by assertEqual
    # see https://docs.python.org/2/library/unittest.html#unittest.TestCase.assertEqual for details

# Generated at 2022-06-22 09:18:01.475681
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from youtube_dl.utils import encodeArgument

    parser, opts, args = parseOpts(['-o', '%(title)s-%(id)s.%(ext)s'])
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'

    parser, opts, args = parseOpts(['--', encodeArgument('-o'), encodeArgument('%(title)s-%(id)s.%(ext)s')])
    assert opts.outtmpl == '-o'
    assert args == ['%(title)s-%(id)s.%(ext)s']


# Generated at 2022-06-22 09:18:12.277375
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from io import StringIO

    from youtube_dl.compat import PY2

    def parseOpts(args, overrideArguments=None):
        return YoutubeDL.parseOpts(args, overrideArguments)

    class DummyYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            self.params = None
            self.__dict__.update(kwargs)

        def set_downloader(self, *args, **kwargs):
            pass

        def add_default_info_extractors(self):
            pass

        def to_screen(self, *args, **kargs):
            pass

    out = StringIO()
    err = StringIO()
    ydl = DummyYoutubeDL(params={}, output=out, error=err)

# Generated at 2022-06-22 09:18:22.558002
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--no-playlist', '--format=22/18/bestvideo+bestaudio'])
    eq_(args, [])
    eq_(opts.playlist, False)
    eq_(opts.format, ['22', '18', 'bestvideo+bestaudio'])
    parser, opts, args = parseOpts(['-f', '22/18/bestvideo+bestaudio'])
    eq_(opts.format, ['22', '18', 'bestvideo+bestaudio'])
    parser, opts, args = parseOpts(['--format', '22/18/bestvideo+bestaudio'])
    eq_(opts.format, ['22', '18', 'bestvideo+bestaudio'])
# parseOpts()


# Generated at 2022-06-22 09:18:32.630353
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import DEFAULT_OUTTMPL, DEFAULT_DUMP_SINGLE_JSON
    from youtube_dl.postprocessor import DEFAULT_PREFER_FFMPEG
    from youtube_dl.utils import ExtractorError

    # test defaults
    parser, opts, args = parseOpts([])
    assert opts.format == None
    assert opts.outtmpl == DEFAULT_OUTTMPL
    assert opts.ignoreerrors
    assert opts.ratelimit == None
    assert opts.retries == 10
    assert opts.buffersize == '1024'
    assert opts.nooverwrites
    assert opts.continuedl
    assert not opts.nopart
    assert opts.updatetime
    assert opts.test
    assert opts.min_files

# Generated at 2022-06-22 09:18:43.951547
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['--no-warnings', '--get-title', 'http://youtu.be/BaW_jenozKc'])[1]
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == True
    assert opts.geturl == False
    assert opts.gettitle == True
    assert opts.getthumbnail == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.nooverwrites == False
    assert opts.quiet == False
    assert opts.debug_printtraffic == False
    assert opts.simulate == False

# Generated at 2022-06-22 09:18:53.088301
# Unit test for function parseOpts

# Generated at 2022-06-22 09:19:03.801780
# Unit test for function parseOpts
def test_parseOpts():
    overrideArguments = ['--username','test']

    parser, opts, args = parseOpts(overrideArguments)
    assert opts.username == 'test'

    overrideArguments = ['--password','test']

    parser, opts, args = parseOpts(overrideArguments)
    assert opts.password == 'test'

    overrideArguments = ['--usenetrc', 'test']

    parser, opts, args = parseOpts(overrideArguments)
    assert opts.usenetrc == 'test'

# Matching groups for --match-filter
MATCHING_GROUPS = ['filename', 'title', 'id', 'format', 'ext']

# Generated at 2022-06-22 09:19:05.619895
# Unit test for function parseOpts
def test_parseOpts():
    print (parseOpts(None))
    print (parseOpts(['-h']))

# Generated at 2022-06-22 09:19:08.032386
# Unit test for function parseOpts
def test_parseOpts():
    print('test parseOpts()')
    assert None == parseOpts(['-h'])

# Generated at 2022-06-22 09:19:57.529670
# Unit test for function parseOpts
def test_parseOpts():
    old_stdout = sys.stdout
    sys.stdout = open('/dev/null', 'w')
    # Parse options without reading config files
    _, opts, _ = parseOpts(['-o', 'test_output.%(ext)s', '-a', 'test_output.txt', '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.quiet is False
    assert opts.format == None
    assert opts.format_limit == None
    assert opts.listformats is False
    assert opts.outtmpl == 'test_output.%(ext)s'

# Generated at 2022-06-22 09:20:07.043273
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i'])
    assert opts.ignoreerrors
    assert opts.postprocessor_args is None

    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == 1

    parser, opts, args = parseOpts(['-v', '-v'])
    assert opts.verbose == 2

    parser, opts, args = parseOpts(['--playlist-start=2'])
    assert opts.playliststart == 2

    parser, opts, args = parseOpts(['--playlist-end=3'])
    assert opts.playlistend == 3

    parser, opts, args = parseOpts(['--match-title', 're', '--max-downloads', '1'])


# Generated at 2022-06-22 09:20:17.512571
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv

    # Basic test
    argv = ['-i', '-v', '--dump-user-agent']
    parser, opts, args = parseOpts()
    assert opts.dump_user_agent
    assert not opts.ignoreerrors
    assert opts.verbose

    # Ignoring config files
    argv = ['--no-config']
    parser, opts, args = parseOpts()
    assert opts.no_config
    argv = ['--ignore-config']
    parser, opts, args = parseOpts()
    assert opts.ignore_config
    os.environ['XDG_CONFIG_HOME'] = '/nonexistent'
    argv = ['--ignore-config']
    parser, opts, args = parseOpts()
    assert opts.ignore

# Generated at 2022-06-22 09:20:22.469297
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'foo@gmail.com', '-P', 'p@ss'])
    assert opts.username == "foo@gmail.com"
    assert opts.password == "p@ss"

    opts, args = parseOpts(['-x', '-o', 'foo.%(ext)s', '--max-filesize', '1000000000', 'bar'])
    assert opts.outtmpl == "foo.%(ext)s"
    assert opts.extractaudio
    assert opts.max_filesize == 1000000000
    assert args == ['bar']


# Generated at 2022-06-22 09:20:28.070791
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--write-sub', '--sub-lang', 'en,is', '--', 'arg'])
    assert opts.writesub
    assert opts.subtitleslang == ['en', 'is']
    assert args == ['arg']



# Generated at 2022-06-22 09:20:30.498549
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: write unit test
    pass


# Generated at 2022-06-22 09:20:39.905265
# Unit test for function parseOpts
def test_parseOpts():
    test_string = 'youtube-dl -o \'./%(title)s-%(id)s.%(ext)s\' \'http://www.youtube.com/watch?v=BaW_jenozKc\'\nREADY'
    assert parseOpts(test_string) == (
    'youtube-dl -o \'./%(title)s-%(id)s.%(ext)s\' \'http://www.youtube.com/watch?v=BaW_jenozKc\'\n',
    'READY')

# parseOpts: END ##############################################################
