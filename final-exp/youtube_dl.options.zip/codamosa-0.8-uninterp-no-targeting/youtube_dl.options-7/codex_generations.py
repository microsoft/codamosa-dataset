

# Generated at 2022-06-22 09:11:16.052902
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose

    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose

    assert opts.verbose == 1
    parser, opts, args = parseOpts(['--verbose', '-v'])
    assert opts.verbose == 2

    parser, opts, args = parseOpts([])
    assert opts.verbose == 0

    parser, opts, args = parseOpts(['--restrict-filenames'])
    assert opts.restrictfilenames

    parser, opts, args = parseOpts(['-a', 'asdf'])
    assert opts.batchfile == 'asdf'

    parser, opts, args = parseOpt

# Generated at 2022-06-22 09:11:27.974007
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts()
    assert parser
    assert opts
    #assert _ == []
    #assert opts.username
    assert opts.forceurl
    assert opts.forcetitle
    assert opts.forceid
    assert opts.forcedescription
    assert opts.forcethumbnail
    assert opts.forceduration
    assert opts.forcefilename
    assert opts.forcejson
    assert opts.dump_single_json
    assert opts.dump_json
    assert opts.autonumber
    assert opts.usenetrc
    assert opts.call_home
    assert not opts.noplaylist
    assert not opts.playliststart
    assert not opts.playlistend
    assert not opts.matchtitle

# Generated at 2022-06-22 09:11:36.974885
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--username', 'test', '--password', 'test', 'test'])
    # Make sure that --username and --password are not printed
    assert '--username' not in str(parser.format_option_help())
    assert '--password' not in str(parser.format_option_help())
    parser, opts, args = parseOpts(['--verbose', '--format', 'best'])
    assert '--format' in str(parser.format_option_help())
    assert opts.verbose == True
    assert opts.format == 'best'
    return parser, opts, args


# Generated at 2022-06-22 09:11:49.930956
# Unit test for function parseOpts
def test_parseOpts():
    def _test_override_opts(opts, args):
        assert opts.default_search == 'auto'
        assert opts.listformats == False
        assert opts.usenetrc == True
        assert opts.noplaylist == False
        assert opts.playlist_reverse == False
        assert opts.playlist_items is None
        assert opts.playlist_start == 1
        assert opts.min_views is None
        assert opts.max_views is None
        assert opts.date is None
        assert opts.match_filter is None
        assert opts.age_limit is None
        assert opts.download_archive == 'youtube-dl.archive'
        assert opts.include_ads == False
        assert opts.default_search == 'auto'
        assert opts

# Generated at 2022-06-22 09:11:57.687314
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-q', '--no-warnings', 'foo'])[1]
    assert opts.quiet == True
    assert opts.verbose == False
    assert opts.dump_user_agent == False
    assert opts.noplaylist == True
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_mso == None
    assert opts.ap_list == False
    assert opts.allsubtitles == False
    assert opts.listsubtitles == False

# Generated at 2022-06-22 09:12:04.179696
# Unit test for function parseOpts
def test_parseOpts():
    # Test with both short and long options
    testargs = ['-i', 'my_video', '--output', 'my_video.flv', '--write-description', '--write-info-json']
    parser, opts, args = parseOpts(testargs)

    assert(opts.usenetrc == False)
    assert(opts.username == None)
    assert(opts.password == None)
    assert(opts.video_password == None)
    assert(opts.quiet == False)
    assert(opts.forceurl == False)
    assert(opts.forcetitle == False)
    assert(opts.forceid == False)
    assert(opts.forcedescription == False)
    assert(opts.forcefilename == False)
    assert(opts.forceduration == False)

# Generated at 2022-06-22 09:12:10.428368
# Unit test for function parseOpts
def test_parseOpts():
    """
    Test parseOpts
    """
    opts, args = parseOpts(['-h'])
    assert isinstance(opts, optparse.Values)
    opts, args = parseOpts(['-v'])
    assert isinstance(opts, optparse.Values)
    opts, args = parseOpts(['--help'])
    assert isinstance(opts, optparse.Values)
    opts, args = parseOpts(['--ignore-config'])
    assert isinstance(opts, optparse.Values)
    opts, args = parseOpts(['--config-location=/etc/youtube-dl.conf'])
    assert isinstance(opts, optparse.Values)
    opts, args = parseOpts(['--dump-user-agent'])

# Generated at 2022-06-22 09:12:19.239586
# Unit test for function parseOpts
def test_parseOpts():
    from nose.tools import assert_raises

    # Test overriding of arguments
    parser, opts, args = parseOpts(['-i', '--get-url', '--get-title'])
    assert opts.geturl
    assert opts.gettitle

    # Test overriding of config suboptions
    parser, opts, args = parseOpts(
        ['--config-location=/foo/bar.conf'],
        overrideArguments=['-i'])
    assert opts.geturl

    # Test overriding of config suboptions
    parser, opts, args = parseOpts(
        ['--config-location=/foo/bar.conf'],
        overrideArguments=['--ignore-config', '-i'])
    assert not opts.geturl

    # Test overriding of config options

# Generated at 2022-06-22 09:12:21.464785
# Unit test for function parseOpts
def test_parseOpts():
    # parsing an empty list should work
    parseOpts([])


# Generated at 2022-06-22 09:12:24.893746
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert parser is not None
    assert opts is not None
    assert (args is not None) or len(args) == 0


# Generated at 2022-06-22 09:12:49.453659
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    tf = tempfile.NamedTemporaryFile(suffix='.conf')
    tf.write(b'--download-archive archive.txt')
    tf.flush()
    assert parseOpts(['-U', 'pafy', '-o', '%(title)s-%(id)s.%(ext)s',
                      '--config-location', compat_expanduser(tf.name),
                      '--ignore-config',
                      '--get-title', 'https://www.youtube.com/watch?v=9bZkp7q19f0'])
    tf.close()



# Generated at 2022-06-22 09:13:01.987774
# Unit test for function parseOpts
def test_parseOpts():
    # Change global with local variable because in unit test we want to keep the original value
    original_config_location = configLocation
    configLocation = './youtube-dl.conf'
    original_preferredencoding = preferredencoding
    preferredencoding = lambda: 'utf-8'
    # Change global with local variable because in unit test we want to keep the original value
    original_sleep = sleep
    sleep = lambda seconds: None
    original_os_path_exists = os.path.exists
    original_os_path_isdir = os.path.isdir
    os.path.exists = lambda path: True
    os.path.isdir = lambda path: True
    # Change global with local variable because in unit test we want to keep the original value
    original_os_unlink = os.unlink

# Generated at 2022-06-22 09:13:12.751540
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv as sys_argv

# Generated at 2022-06-22 09:13:21.763460
# Unit test for function parseOpts
def test_parseOpts():
    # Test help messages
    parser, opts, args = parseOpts(['-h'])
    assert not opts.usenetrc
    assert opts.noplaylist
    assert opts.outtmpl == '%(id)s.%(ext)s'
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forceduration == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts

# Generated at 2022-06-22 09:13:32.924019
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['https://gist.github.com/9e9f40bfa30fea408e13'])
    assert opts.verbose == False
    assert opts.playliststart == 1
    assert opts.playlistend == 0
    assert opts.writedescription == False
    assert opts.skip_download == False
    assert opts.matchtitle == None
    assert opts.rejecttitle == None
    assert opts.max_downloads == None
    assert opts.test == False
    assert opts.extract_flat == 'in_playlist'
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.autonumber_size == 0
    assert opts.outtmpl == None
    assert opts

# Generated at 2022-06-22 09:13:41.218686
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import mkstemp
    fd, configFile = mkstemp(prefix="youtubedl-test-conf-", suffix=".conf")

# Generated at 2022-06-22 09:13:45.507912
# Unit test for function parseOpts
def test_parseOpts():
    opts = ['--get-title', '--get-description', '--get-filename', '--get-format', '--get-id', '--get-thumbnail', '--get-duration', '--get-uploader']
    parser, opts2, args = parseOpts(opts)
    assert opts == opts2



# Generated at 2022-06-22 09:13:46.181538
# Unit test for function parseOpts
def test_parseOpts():
    pass



# Generated at 2022-06-22 09:13:56.292519
# Unit test for function parseOpts
def test_parseOpts():
    print("==============   TEST_parseOpts   ==============")
    real_parser, real_opts, real_args = parseOpts()

    # test empty args
    test = []
    parser, opts, args = parseOpts( test )
    assert parser == real_parser
    assert opts == real_opts
    assert args == real_args

    # test invalid url
    test = [ "https://www.youtube.com/watch?v=pZfhcq3tqyQ" ]
    parser, opts, args = parseOpts( test )
    assert parser == real_parser
    assert opts != real_opts
    assert opts.urls == ["https://www.youtube.com/watch?v=pZfhcq3tqyQ"]
    assert args == real_args

# Generated at 2022-06-22 09:14:05.673127
# Unit test for function parseOpts
def test_parseOpts():
    def _readOpts(argv):
        parser, opts, args = parseOpts(argv)
        assert args == []
        return opts

    assert not _readOpts([]).verbose
    assert _readOpts(['-v']).verbose
    assert _readOpts(['--verbose']).verbose
    assert _readOpts(['--verbose']).quiet is False
    assert _readOpts(['--verbose', '--quiet']).verbose is False
    assert _readOpts(['--verbose', '--quiet']).quiet
    assert _readOpts(['--default-search', 'skip']).default_search == 'skip'
    assert 'https_proxy' not in _readOpts([]).__dict__
    assert _readOpts(['-4']).prefer

# Generated at 2022-06-22 09:14:50.806376
# Unit test for function parseOpts
def test_parseOpts():
    # Simple
    _, opts, _ = parseOpts([])
    assert opts.verbose == False
    _, opts, _ = parseOpts(['-v'])
    assert opts.verbose == True

    # Advanced
    _, opts, _ = parseOpts(['-f', 'best', '--extract-audio', '-k'])
    assert opts.format == 'best'
    assert opts.extractaudio == True
    assert opts.keepvideo == True

# Generated at 2022-06-22 09:15:03.001568
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.min_views is None
    assert not opts.playlistreverse
    assert not opts.playliststart
    assert not opts.playlistend
    assert not opts.writethumbnail
    assert not opts.write_all_thumbnails
    assert not opts.list_thumbnails
    assert opts.writeannotations == False
    assert opts.writedescription == False
    assert opts.writeinfojson == False
    parser, opts, args = parseOpts([])
    assert opts.writeannotations == False
    assert opts.writedescription == False
    assert opts.writeinfojson == False
    parser, opts, args = parseOpts([])
    assert opts.writeannotations == False
    assert opts.writed

# Generated at 2022-06-22 09:15:13.923470
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-f', '43', '-f', '18', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1]
    assert opts.format == ['43', '18']
    assert opts.ignoreerrors
    assert opts.outtmpl == '%(stitle)s-%(id)s.%(ext)s'
    opts = parseOpts(['--', '-f', '43', '-f', '18', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1]
    assert opts.format == []

# Generated at 2022-06-22 09:15:21.562677
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-i', '--no-warnings'])[1].ignoreerrors is True
    assert parseOpts(['--ignore-errors'])[1].ignoreerrors is True
    assert parseOpts(['--ignore-errors', '--no-ignore-errors'])[1].ignoreerrors is False
    assert parseOpts(['--'])[1].noprogress is None
    assert parseOpts(['-v'])[1].verbose is True
    assert parseOpts(['--verbose'])[1].verbose is True
    assert parseOpts(['--verbose', '--no-verbose'])[1].verbose is False
    assert parseOpts(['--verbose', '--quiet'])[1].quiet is True

# Generated at 2022-06-22 09:15:27.460908
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert not opts.playliststart
    assert not opts.playlistend
    assert not opts.matchtitle
    assert not opts.rejecttitle
    assert opts.playlistreverse
    assert 'file "youtube-dl.py"' in opts.ap_password
    assert 'Description: password for ap' in opts.ap_password



# Generated at 2022-06-22 09:15:37.862238
# Unit test for function parseOpts
def test_parseOpts():
    # Test function parseOpts with no arguments
    # Function parseOpts should return 3 objects:
    # (1) A parser object
    # (2) A opts object
    # (3) A args object
    parser, opts, args = parseOpts()
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)

    # Test function parseOpts with arguments
    # Function parseOpts should return 3 objects:
    # (1) A parser object
    # (2) A opts object
    # (3) A args object
    parser, opts, args = parseOpts(['-h'])
    assert isinstance(parser, optparse.OptionParser)
    assert isinstance(opts, optparse.Values)
   

# Generated at 2022-06-22 09:15:46.330501
# Unit test for function parseOpts
def test_parseOpts():
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    sys.argv = [u'-v']
    parser, opts, args = parseOpts()
    assert(opts.verbose)
    sys.argv = [u'--verbose']
    parser, opts, args = parseOpts()
    assert(opts.verbose)
    sys.argv = [u'--verbose', u'--verbose']
    parser, opts, args = parseOpts()
    assert(opts.verbose)
    sys.argv = [u'--verbose']
    parser, opts, args = parseOpts([u'--verbose', u'--verbose'])
    assert(opts.verbose)

# Generated at 2022-06-22 09:15:47.905489
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([__file__, '-F'])[1].format == 'best'



# Generated at 2022-06-22 09:15:57.172877
# Unit test for function parseOpts
def test_parseOpts():
    from types import ModuleType
    import youtube_dl.YoutubeDL

    parser, opts, args = parseOpts()
    
    if not isinstance(parser, optparse.OptionParser):
        raise AssertionError('[FAILED] parseOpts should return an optparse.OptionParser.')

    if not isinstance(opts, optparse.Values):
        raise AssertionError('[FAILED] parseOpts should return an optparse.Values.')

    if not isinstance(args, list):
        raise AssertionError('[FAILED] parseOpts should return an list.')



# Generated at 2022-06-22 09:16:08.785578
# Unit test for function parseOpts
def test_parseOpts():
    try:
        import nose
        raise nose.SkipTest('Testing parseOpts is not supported with nose')
    except ImportError:
        pass

    # The optionFileContent is intended to be (temporarily)
    # written as ~/.config/youtube-dl/youtube-dl.conf
    optionFileContent = (
        'proxy='
        'max_downloads=10'
        'restrictfilenames'
        'batchfile='
        'ignoreerrors'
        )

    # The commandLineContent is intended to be given as command-line arguments

# Generated at 2022-06-22 09:17:27.139263
# Unit test for function parseOpts
def test_parseOpts():
    tests = {
        '-i': {
            'input': ('-i',),
            'expected': ('-i', '--ignore-errors'),
        }
    }
    for test in tests:
        _, actual, _ = parseOpts(test['input'])
        expected = test['expected']
        assert actual == expected



# Generated at 2022-06-22 09:17:32.014523
# Unit test for function parseOpts
def test_parseOpts():
    def assert_equals(a, b):
        if a == b:
            return
        msg = '%s != %s' % (repr(a), repr(b))
        print(msg)
        assert False, msg
    parser, opts, args = parseOpts(['--username=bar'])
    assert_equals(opts.username, 'bar')
    assert_equals(opts.password, None)

    parser, opts, args = parseOpts(['--get-url'])
    assert_equals(opts.username, None)
    assert_equals(opts.password, None)

    parser, opts, args = parseOpts(['--get-url', '--username=bar'])
    assert_equals(opts.username, None)

# Generated at 2022-06-22 09:17:37.804166
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.verbose
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert opts.usetitle
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.playlist_items == [1, 2, 3]
    assert opts.playlist_start == 5
    assert opts.playlist_end == 6
    assert opts.playlistreverse
    assert opts.matchtitle == 'regex'
    assert opts.rejecttitle == 'regex'
    assert opts.age_limit == 18
    assert not opts.min_views
    assert opts.max_views
    assert not opts.min_upload_date
    assert opts

# Generated at 2022-06-22 09:17:47.662448
# Unit test for function parseOpts
def test_parseOpts():
    argv = ['--list-extractors']
    _, opts, _ = parseOpts(argv)
    assert opts.list_extractors, '--list-extractors failed'
    argv = ['--list-extractors']
    _, opts, _ = parseOpts(argv, overrideArguments=['--sleep-interval=0'])
    assert opts.list_extractors, '--list-extractors failed'
    argv = ['--help']
    _, opts, _ = parseOpts(argv, overrideArguments=['--sleep-interval=0'])
    assert not opts.list_extractors, '--help failed'

# Generated at 2022-06-22 09:17:58.833395
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts()
    assert opts.outtmpl == '%(title)s'

    parser, opts, _ = parseOpts(['-o', '%(id)s.%(ext)s'])
    assert opts.outtmpl == '%(id)s.%(ext)s'

    parser, opts, _ = parseOpts(['--autonumber-size', '3'])
    assert opts.autonumber_size == 3

    parser, opts, _ = parseOpts(['--all-subs'])
    assert opts.allsubtitles

    parser, opts, _ = parseOpts(['--list-formats'])
    assert opts.listformats


# Generated at 2022-06-22 09:18:08.853955
# Unit test for function parseOpts
def test_parseOpts():
    def _readOptions(filename):
        if os.path.exists(filename) and os.access(filename, os.R_OK):
            options = [line.strip().decode('utf-8')
                       for line in open(filename)
                       if re.match(r'^\s*[a-zA-Z0-9_]+\s*=', line)]
            return options
        else:
            return []

    def compat_conf(conf):
        if sys.version_info < (3,):
            return [a.decode(preferredencoding(), 'replace') for a in conf]
        return conf

    # test with no system/user config
    sys.argv = ['youtube-dl', '--help']
    command_line_conf = compat_conf(sys.argv[1:])
    override

# Generated at 2022-06-22 09:18:15.814749
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import gen_extractors

    for ie in gen_extractors():
        ie.extractor.update_options(ie.params)
        parser, _, _ = parseOpts(['--%s-password=pw' % ie.IE_NAME])
        assert not ie.params.get('password', ''), 'Password was leaked'
        parser, _, _ = parseOpts(['--%s-username=u' % ie.IE_NAME])
        assert not ie.params.get('username', ''), 'Username was leaked'

# This function has been copied from youtube-dl/youtube_dl/utils.py
# and slightly modified.

# Generated at 2022-06-22 09:18:18.215443
# Unit test for function parseOpts
def test_parseOpts():
    # [TODO] Add test code here
    pass


SUPPORT_CHECK_OK = True
SUPPORT_CHECK_FAILED = False



# Generated at 2022-06-22 09:18:26.014863
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parseOpts(overrideArguments, expected):
        retval = parseOpts(overrideArguments)
        assert retval == expected

    _test_parseOpts(None, (None, None, None))

    # #REF: http://stackoverflow.com/questions/9904458/python-nested-tuples-map-tuples-to-a-non-tuple-object
    def _test_parseOpts2():
        parser, opts, args = parseOpts(overrideArguments=None)
        retval = (parser, opts, args)
        assert retval == expected


# Generated at 2022-06-22 09:18:31.276075
# Unit test for function parseOpts
def test_parseOpts():
    with pytest.raises(SystemExit):
        parseOpts([])
    with pytest.raises(SystemExit):
        parseOpts(['--extract-audio'])
    with pytest.raises(SystemExit):
        parseOpts(['--version'])
    parseOpts(['--help'])

