

# Generated at 2022-06-22 09:10:55.540588
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    # Add test cases if needed
    pass

# Generated at 2022-06-22 09:10:56.037228
# Unit test for function parseOpts
def test_parseOpts():
    return

# Generated at 2022-06-22 09:11:00.057444
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-x', '-a', '-'])
    assert opts.ignoreerrors
    assert opts.extractaudio
    assert opts.batchfile == '-'


# Generated at 2022-06-22 09:11:10.027021
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    #assert opts.proxy == '0.0.0.0'
    assert opts.outtmpl == '/Downloads/%(title)s-%(id)s.%(ext)s'
    assert opts.username == 'username'
    assert opts.password == 'password'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == True
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forceduration == False
    assert opts.forcejson == False

# Generated at 2022-06-22 09:11:21.702328
# Unit test for function parseOpts
def test_parseOpts():
    assert(parseOpts(['-U', 'foo', 'bar']) == 
           parseOpts(['-U', 'foo', '--username=xxx', 'bar']))
    # -k should be equivalent to --no-post-overwrites
    assert(parseOpts(['-k', 'foo']) == 
           parseOpts(['--no-post-overwrites', 'foo']))
    # --keep-video should be equivalent to --no-post-overwrites
    assert(parseOpts(['--keep-video', 'foo']) == 
           parseOpts(['--no-post-overwrites', 'foo']))
    # --embed-subtitles should be equivalent to --write-sub

# Generated at 2022-06-22 09:11:31.519462
# Unit test for function parseOpts
def test_parseOpts():
    from .common import *
    from .extractor import *

    parser, opts, args = parseOpts()
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL(opts)
    for arg in args:
        print('[debug] testing url: ' + arg)
        if '@' in arg:
            code, info = ydl.extract_info_with_credentials(arg)
            if info is not None:
                print(info)
            else:
                print('Code: ' + code)
        else:
            code, info = ydl.extract_info(arg)
            if info is not None:
                print(info)
            else:
                print('Code: ' + code)
    assert True # got to this point without errors (hopefully)

# Generated at 2022-06-22 09:11:36.611181
# Unit test for function parseOpts
def test_parseOpts():
    # Testing parseOpts
    if __name__ == '__main__':
        import doctest
        doctest.testmod()

# Generated at 2022-06-22 09:11:44.522447
# Unit test for function parseOpts
def test_parseOpts():
    # Test specification of options through environment variables
    opts, args = parseOpts(['-u', 'testuser', '-p', 'testpass', 'testvideo'])
    assert opts.username == 'testuser'
    assert opts.password == 'testpass'
    assert args == ['testvideo']

    opts, args = parseOpts([])
    assert opts.username is None
    assert opts.password is None
    assert args == []

    # Test specification of options through config
    with NamedTemporaryFile() as configfile:
        configfile.write(b'--username testuser\n--password testpass')
        configfile.flush()
        opts, args = parseOpts(['--config-location', configfile.name, 'testvideo'])
        assert opts.username == 'testuser'
       

# Generated at 2022-06-22 09:11:56.510246
# Unit test for function parseOpts

# Generated at 2022-06-22 09:12:06.255970
# Unit test for function parseOpts
def test_parseOpts():
    def checkOpts(opts, opt_dict):
        for k,v in opt_dict.items():
            assert hasattr(opts, k)
            assert getattr(opts, k) == v

    # default options
    (parser, opts, args) = parseOpts([])

# Generated at 2022-06-22 09:12:33.589436
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(overrideArguments=['--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].geturl
    assert parseOpts(overrideArguments=['--get-title', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].gettitle
    assert parseOpts(overrideArguments=['--get-id', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].getid
    assert parseOpts(overrideArguments=['--get-format', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].getformat

# Generated at 2022-06-22 09:12:44.485826
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert args==[]
    assert opts.usenetrc==False
    assert opts.noprogress==False
    assert opts.proxy==None
    assert opts.playliststart==1
    assert opts.playlistend==None
    assert opts.writesubtitles==False
    assert opts.allsubtitles==False
    assert opts.ignoreerrors==False
    assert opts.verbose==False
    assert opts.dump_intermediate_pages==False
    assert opts.write_intermediate_pages==False
    assert opts.utf8_bom==False
    assert opts.sleep_interval==None
    assert opts.forcejson==False
    assert opts.matchtitle==None

# Generated at 2022-06-22 09:12:49.269501
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--min-filesize', '20M', '--max-filesize', '40KiB', '-4', 'http://test.test'])
    assert opts.min_filesize == 20*1024*1024
    assert opts.max_filesize == 40*1024
    assert opts.prefer_ipv4


# Generated at 2022-06-22 09:13:01.758466
# Unit test for function parseOpts
def test_parseOpts():
    try:
        opts, args = parseOpts(['TESTURL', '--username', 'testuser',
            '--password', 'testpass', '--sub-lang', 'en,is', '--',
            '--print-json'])
    except SystemExit as e:
        if e.code != 0:
            raise
        return

    if opts.usenetrc:
        raise Exception('Expected usenetrc to be False')
    if opts.sublang != ['en', 'is']:
        raise Exception('Expected sublang to be en,is')
    if args != ['--print-json']:
        raise Exception('Expected args to be --print-json')


# Generated at 2022-06-22 09:13:07.931082
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts()
    assert opts.username
    assert opts.password
    assert opts.videoid
    assert opts.outtmpl
# extract_count



# http://code.activestate.com/recipes/499305-encoding-conversion-using-the-iconv-library/
# http://www.py2exe.org/index.cgi/Iconv

# Generated at 2022-06-22 09:13:14.550085
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass
# End of unit test for function parseOpts

# parseOpts is imported below by other functions.
# It is declared in this file for these functions to recognize its name at parsing time.
# As parseOpts requires other functions from this file which are declared after its declaration,
# parseOpts itself has to be declared in this file but is defined in other.py.
# This is not done in other.py because of some import trickery.
from .other import parseOpts


# Generated at 2022-06-22 09:13:23.395763
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parseOpts(args, expected_retval):
        parser, opts, args = parseOpts(args)

# Generated at 2022-06-22 09:13:34.530844
# Unit test for function parseOpts
def test_parseOpts():
    from xml.etree.ElementTree import XML
    from tempfile import NamedTemporaryFile
    from contextlib import contextmanager
    from .test.test_utils import get_testdata_file

    config = """\
--proxy http://localhost:3128
-f mp4
--no-check-certificate
--match-title test
-i --username user --password passwd
    """
    with NamedTemporaryFile('w') as conf:
        conf.write(config)
        conf.flush()
        conf.seek(0)

# Generated at 2022-06-22 09:13:40.289076
# Unit test for function parseOpts
def test_parseOpts():
    print("Testing parseOpts()")

    opts = YoutubeDL().params
    parser, opts_parsed, args = parseOpts(['-v'])

    assert opts_parsed.verbose == opts['verbose']
    assert opts_parsed.outtmpl == opts['outtmpl']
    assert opts_parsed.outtmpl_na_placeholder == opts['outtmpl_na_placeholder']

    parser, opts_parsed, args = parseOpts(['-v', '-o', 'myfile.%(ext)s'])
    assert opts_parsed.outtmpl == 'myfile.%(ext)s'

# Generated at 2022-06-22 09:13:43.446707
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

    assert type(parser) == optparse.OptionParser
    assert type(opts) == optparse.Values
    assert type(args) == list

# Generated at 2022-06-22 09:14:16.066376
# Unit test for function parseOpts
def test_parseOpts():
    args = ['--list-formats']
    parser, opts, args = parseOpts(args)

    assert opts.listformats is True
# End of unit test


# Generated at 2022-06-22 09:14:25.594392
# Unit test for function parseOpts
def test_parseOpts():
    def _test(given, expected):
        parser, opts, args = parseOpts(given)
        assert args == []
        for key, value in expected.items():
            assert getattr(opts, key) == value

    _test(['-o', os.path.join(u'привіт', 'out')], {'outtmpl': os.path.join(u'привіт', 'out')})
    _test(['-o', 'my title'], {'outtmpl': 'my title'})
    _test(['-o', '%(uploader)s'], {'outtmpl': '%(uploader)s'})

# Generated at 2022-06-22 09:14:27.412921
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod(option_parsers)
    return



# Generated at 2022-06-22 09:14:35.953709
# Unit test for function parseOpts
def test_parseOpts():
    print('Starting Test parseOpts')
    import argparse
    parser, opts, args = parseOpts()

    parser.add_argument(
        '--ads', default=True,
        help='Pass "Ads" default')
    parser.add_argument(
        '--no-ads', action='store_false', dest='ads',
        help='Pass "Ads" no')

    parser.add_argument(
        '--no-post-overwrites',
        help='Pass "PostOverwrites" no')

    #parser.add_argument('youtube_url', help='URLs to download', nargs='*')
    parser.add_argument('youtube_url', help='URLs to download')

    args = parser.parse_args()
    print('args.ads: ' + str(args.ads))
    print

# Generated at 2022-06-22 09:14:47.603913
# Unit test for function parseOpts
def test_parseOpts():
    opts, _ = parseOpts(['-f','22','--','http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == "22"
    opts, _ = parseOpts(['./LICENSE'])
    assert opts.ignoreerrors
    opts, _ = parseOpts(['./LICENSE','-i'])
    assert opts.ignoreerrors
    opts, _ = parseOpts(['./LICENSE', '--no-ignore-errors'])
    assert not opts.ignoreerrors
    opts, _ = parseOpts(['-U', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:22.0) Gecko/20100101 Firefox/22.0'])
    assert opt

# Generated at 2022-06-22 09:14:51.445541
# Unit test for function parseOpts
def test_parseOpts():
    #def parseOpts(overrideArguments = None):
    parser, opts, args = parseOpts()
    assert opts.cachedir
    assert opts.verbose >= 0
    assert opts.verbose <= 2


# Generated at 2022-06-22 09:15:03.253625
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts(['--help'])
    assert parser
    assert opts

    parser, opts, _ = parseOpts(['--no-warnings', '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert parser
    assert opts

    parser, opts, args = parseOpts()
    assert parser
    assert opts
    assert args == []

    parser, opts, args = parseOpts(['-4', '--max-downloads', '25', 'plop'])
    assert parser
    assert opts
    assert opts.noplaylist is True
    assert opts.proxy is None
    assert opts.max_downloads == 25
    assert args == ['plop']

# Downloader Options


# Generated at 2022-06-22 09:15:12.268856
# Unit test for function parseOpts
def test_parseOpts():
    dummy_parser, opts, args = parseOpts([
        '--dump-user-agent', '',
        '-i', '-f best', '-v',
        'http://www.youtube.com/watch?v=BaW_jenozKc&t=83'])
    assert opts.dump_user_agent
    assert opts.ignoreerrors
    assert opts.format == 'best'
    assert opts.verbose
    assert 'http://www.youtube.com/watch?v=BaW_jenozKc&t=83' in args
# Getting video url and title from given video_id

# Generated at 2022-06-22 09:15:20.493198
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    parser.parse_args()
    parser.parse_args(['--get-id'])
    parser.parse_args(['--version'])
    parser.parse_args(['--test'])
    parser.parse_args(['--youtube-skip-dash-manifest'])
    parser.parse_args(['--youtube-include-dash-manifest'])
    parser.parse_args(['--extractaudio'])
    parser.parse_args(['--audio-quality', '1'])
    parser.parse_args(['--recode-video', 'mp4'])
    parser.parse_args(['--embed-subs'])
    parser.parse_args(['--embed-thumbnail'])

# Generated at 2022-06-22 09:15:31.917319
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    tmp = tempfile.NamedTemporaryFile()

# Generated at 2022-06-22 09:16:37.816030
# Unit test for function parseOpts
def test_parseOpts():
    def test_1(args):
        parser, opts, args = parseOpts(args)
        assert opts.usenetrc == False
        assert opts.username == None
        assert opts.password == None
        assert opts.ap_username == None
        assert opts.ap_password == None
    test_1(['--username=foo', '--password=bar'])
    test_1(['--username=foo', '--no-usenetrc'])
    test_1(['--netrc', '--password=bar'])
    test_1(['--netrc', '--username=foo', '--password=bar'])


# Generated at 2022-06-22 09:16:46.185058
# Unit test for function parseOpts
def test_parseOpts():
    def normalize(arg):
        arg = arg.replace('\r', '').replace('\n', '')
        arg = arg.replace(' ', '_')
        arg = arg.replace(':', '').replace(',', '')
        arg = arg.replace('[', '(').replace(']', ')')
        return arg

    def check_parse_opts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        opt_str = ' '.join('-%s "%s"' % (k, getattr(opts, k)) if type(getattr(opts, k)) == str else '-%s' % k for k in sorted(vars(opts)) if getattr(opts, k) is not None)

# Generated at 2022-06-22 09:16:53.541942
# Unit test for function parseOpts

# Generated at 2022-06-22 09:17:04.668961
# Unit test for function parseOpts
def test_parseOpts():
    # These are just some random old test cases left over from
    # before the full rewrite
    parser, opts, args = parseOpts(['--username', 'user', '--password', 'sekrit',
                                    'pl', '--format', 'best'])
    assert opts.username == 'user'
    assert opts.password == 'sekrit'
    assert opts.playliststart == 1
    assert opts.playlistend == 0
    assert opts.format == ['best']

    parser, opts, args = parseOpts(['--format=22/18/35/34/5', 'pl'])
    assert opts.format == ['22/18/35/34/5']

    parser, opts, args = parseOpts(['-f 22/18/35/34/5', 'pl'])


# Generated at 2022-06-22 09:17:14.577916
# Unit test for function parseOpts
def test_parseOpts():
    if sys.version_info < (3,):
        from youtube_dl.compat import unicode
    args = ['https://www.youtube.com/watch?v=BaW_jenozKc', '-o', 'out', '-c',]
    parser, opts, args = parseOpts(args)
    # test that options are set
    assert(opts.username == None)
    assert(opts.quiet == False)
    assert(opts.verbose == False)
    assert(opts.no_warnings == False)
    assert(opts.forceurl == False)
    assert(opts.forcetitle == False)
    assert(opts.forceid == False)
    assert(opts.forcethumbnail == False)
    assert(opts.forcedescription == False)

# Generated at 2022-06-22 09:17:23.223800
# Unit test for function parseOpts
def test_parseOpts():
    # Test with parameters (overrideArguments = ["--extra-arg1", "--extra-arg2"])
    parser, opts, args = parseOpts(["--extra-arg1", "--extra-arg2"])
    assert parser.has_option("--extra-arg1")
    assert parser.has_option("--extra-arg2")
    assert opts.extra_arg1 is True
    assert opts.extra_arg2 is True
    assert args == ["--extra-arg1", "--extra-arg2"]

    # Test without parameters
    parser, opts, args = parseOpts()
    assert parser.has_option("--extra-arg1")
    assert parser.has_option("--extra-arg2")
    assert opts.extra_arg1 is False

# Generated at 2022-06-22 09:17:27.663895
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(overrideArguments=['--verbose', '--simulate', '--no-warnings', '-o', 'test.%(ext)s', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1]
    assert opts.listformats is True
    assert opts.simulate is True
    assert opts.noprogress is True
    assert opts.outtmpl == 'test.%(ext)s'

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-22 09:17:31.883631
# Unit test for function parseOpts
def test_parseOpts():
    # Test with override_arguments
    original_sys_argv = sys.argv
    # overrideArguments is None
    sys.argv = ['youtube-dl', '-cv']
    assert parseOpts(None)[1].verbose == False
    # overrideArguments is []
    sys.argv = ['youtube-dl', '-cv']
    assert parseOpts(None)[1].verbose == False
    # overrideArguments is ["-cv"]
    sys.argv = ['youtube-dl', '--verbose']
    assert parseOpts(['-cv'])[1].verbose == True
    # overrideArguments is ["--verbose"]
    sys.argv = ['youtube-dl', '-cv']
    assert parseOpts(['--verbose'])[1].verbose == True
    # Restore sys

# Generated at 2022-06-22 09:17:35.302830
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-22 09:17:45.160589
# Unit test for function parseOpts
def test_parseOpts():
    # TODO make this test more thorough
    parser, opts, args = parseOpts(['-g'])
    assert opts.geturl
    parser, opts, args = parseOpts(['-X', 'arg1'])
    assert opts.extractor_opts == {'arg1': ''}
    parser, opts, args = parseOpts(['-x', 'arg1', 'arg2'])
    assert opts.extractor_opts == {'arg1': 'arg2'}
    parser, opts, args = parseOpts(['-s'])
    assert opts.simulate
    parser, opts, args = parseOpts([])
    assert not opts.simulate