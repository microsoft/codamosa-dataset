

# Generated at 2022-06-22 09:10:58.511853
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([
        '-v', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config',
        'http://www.youtube.com/watch?v=BaW_jenozKc',
    ])
    assert opts.verbose == 3
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.ignoreconfig
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts(['-v', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == 1
    assert opts.username is None

# Generated at 2022-06-22 09:11:01.809834
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    try:
        import argparse
        argparse
    except ImportError:
        print('Skipping argparse doctests')
    else:
        doctest.testmod(sys.modules[__name__])


# Generated at 2022-06-22 09:11:13.828542
# Unit test for function parseOpts
def test_parseOpts():
    # TODO Ideally, this should be much more exhaustive
    write_string('TESTING parseOpts...\r')
    parser, opts, args = parseOpts([])
    assert not opts.username
    assert not opts.password
    assert not opts.twofactor
    assert opts.usenetrc
    assert opts.ratelimit == '0'
    assert not opts.retries
    assert not opts.buffersize
    assert not opts.playliststart
    assert not opts.playlistend
    assert not opts.matchtitle
    assert not opts.rejecttitle
    assert not opts.max_downloads
    assert not opts.prefer_free_formats
    assert not opts.verbose
    assert not opts.outtmpl
    assert opts.rest

# Generated at 2022-06-22 09:11:25.633278
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-i', '--no-progress', '--console-title', '--get-title', '--get-id', '--get-thumbnail', '--get-description', '--get-duration', '--get-filename', '--get-format', '--get-url'])[1]
    assert opts.geturls
    assert opts.gettitle
    assert opts.getid
    assert opts.getthumbnail
    assert opts.getdescription
    assert opts.getduration
    assert opts.getfilename
    assert opts.getformat
    assert opts.console_title
    assert not opts.progress_with_newline
    assert opts.quiet
    assert opts.no_warnings


# Generated at 2022-06-22 09:11:36.286522
# Unit test for function parseOpts
def test_parseOpts():
    # This is just an hack to launch the test automatically with nose
    from unittest import TestLoader, TextTestRunner
    from StringIO import StringIO

    class TestParseOpts(unittest.TestCase):
        def test_parseOpts(self):
            self.maxDiff = None
            parser, opts, args = parseOpts([
                '-i', '--no-progress', '--yes-playlist', '-v',
                '--cookies', '/tmp/does/not/exist',
                '--ignore-config',
                '--default-search', 'ytsearch',
                '--format', 'bestvideo+bestaudio',
                '-o', '%(title)s-%(id)s',
            ])

            self.assertTrue(opts.ignoreconfig)

# Generated at 2022-06-22 09:11:48.946412
# Unit test for function parseOpts
def test_parseOpts():
    def test_opt(params):
        if sys.version_info < (3,):
            params = [a.encode(preferredencoding()) for a in params]
        args = sys.argv[0:1] + params
        parser, opts, args = parseOpts(args)
        assert args == []
        return opts

    assert test_opt(['-U', 'myuseragent'])
    assert test_opt(['-w'])
    assert test_opt(['-4'])
    assert test_opt(['-6'])
    assert test_opt(['-c'])
    assert test_opt(['-b', '2048000'])
    assert test_opt(['-i'])
    assert test_opt(['-f', '18'])

# Generated at 2022-06-22 09:12:01.382635
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from tempfile import mkdtemp
    import shutil
    def _capture_stdout(f, *args, **kwargs):
        old_stdout, sys.stdout = sys.stdout, open(os.devnull, 'w')
        try:
            return f(*args, **kwargs)
        finally:
            sys.stdout = old_stdout
    def test_download_extract_info():
        url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
        def _test(ydl_opts, expected_info_dict_keys=('id', 'ext', 'title')):
            tmp

# Generated at 2022-06-22 09:12:07.027130
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts()
    assert opts.usenetrc
    assert opts.username == 'my_username'
    assert opts.password == 'my_password'
    assert opts.download_archive == 'my_download_archive'
    assert opts.geturl
    assert opts.gettitle
    assert opts.getid
    assert opts.getthumb
    assert opts.getdescription
    assert opts.getfilename
    assert opts.getformat
    assert opts.usetitle
    assert opts.nooverwrites == False
    assert opts.forceurl
    assert opts.forcethumbnail
    assert opts.forcedescription
    assert opts.forcefilename == False
    assert opts.simulate
    assert opts.skip_download == False

# Generated at 2022-06-22 09:12:19.129744
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv

# Generated at 2022-06-22 09:12:32.187639
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import parseOpts
    # for testing
    class MyOptParser(object):
        def __init__(self):
            self.option_groups = []
        def add_option_group(self, option_group):
            self.option_groups.append(option_group)
        def parse_args(self, cmd_line_conf):
            return self.cmd_line_conf, []
    my_opt_parser = MyOptParser()
    def _readOptions(path):
        if path == '/etc/youtube-dl.conf':
            return ['--quiet']
        elif path == '~/.config/youtube-dl/config':
            return ['--username', 'user', '--password', 'pass', '--verbose']

# Generated at 2022-06-22 09:13:02.377294
# Unit test for function parseOpts
def test_parseOpts():
    class MockOptionParser(object):
        def __init__(self, conf, **kwargs):
            self.conf = conf
            self.kwargs = kwargs

        def parse_args(self, args):
            self.args = args
            return self.conf, []

        def add_option(self, *args, **kwargs):
            self.kwargs[kwargs['dest']] = kwargs

        def add_option_group(self, *args, **kwargs):
            self.kwargs[kwargs['dest']] = kwargs

    class MockFile(object):
        def __init__(self, lines):
            self.lines = lines

        def readlines(self):
            return self.lines


# Generated at 2022-06-22 09:13:04.110989
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()


# Generated at 2022-06-22 09:13:14.244873
# Unit test for function parseOpts
def test_parseOpts():
    from xml.sax.saxutils import unescape
    import sys
    import os
    import tempfile
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL

    def test(args, exp):
        parser, opts, _ = parseOpts(args)
        c = YoutubeDL(opts)
        got = c.params
        for key, value in exp.items():
            assert value == got[key], 'Parsed options: %s\n' % repr(got) +\
                                      'Options passed: %s\n' % repr(args) +\
                                      'Expected value %s=%r, got %r' % (key, value, got[key])

    test([], {})
    test(['-h'], {})

# Generated at 2022-06-22 09:13:23.242865
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['http://w.com/watch?v=BaW_jenozKc'])
    assert opts.usetitle
    assert opts.nooverwrites
    assert not opts.verbose
    assert not opts.dump_intermediate_pages
    assert parser.get_prog_name() == 'youtube-dl'
    assert args == ['http://w.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts(['-o', '%(title)s-%(id)s.%(ext)s', 'http://w.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-22 09:13:34.530037
# Unit test for function parseOpts
def test_parseOpts():
    print(('General Options:', general.option_list))
    print(('Network Options:', network.option_list))
    print(('Video Format Options:', video_format.option_list))
    print(('Subtitle Options:', subtitles.option_list))
    print(('Authentication Options:', authentication.option_list))
    print(('Adobe Pass Options:', adobe_pass.option_list))
    print(('Geo Restriction Options:', geo.option_list))
    print(('Video Selection Options:', selection.option_list))
    print(('Download Options:', downloader.option_list))
    print(('Verbosity / Simulation Options:', verbosity.option_list))
    print(('Workarounds:', workarounds.option_list))

# Generated at 2022-06-22 09:13:45.817305
# Unit test for function parseOpts
def test_parseOpts():
    class Args:
        def __init__(self, opts=[]):
            self.extract_flat = False
            self.mark_watched = False
            self.nocheckcertificate = False
            self.verbose = False
            self.quiet = False
            self.simulate = False
            self.format = None
            self.listformats = False
            self.usenetrc = False
            self.username = None
            self.password = None
            self.twofactor = None
            self.videopassword = None
            self.ap_username = None
            self.ap_password = None
            self.noplaylist = False
            self.forcestring = []
            self.extractor_key = {}
            self.extractor_proxy = {}
            self.match_filter = None

# Generated at 2022-06-22 09:13:53.281273
# Unit test for function parseOpts
def test_parseOpts():
    res = parseOpts(
        ['http://www.youtube.com/watch?v=BaW_jenozKc',
         '-v', '--file-prefix="tk"']
    )
    parser, opts, args = res
    assert opts.verbose
    assert opts.file_prefix == 'tk'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-22 09:14:05.271207
# Unit test for function parseOpts
def test_parseOpts():
    def check(argv, expected):
        expected = dict((k, v) for k, v in expected.items() if v is not None)
        parser, opts, args = parseOpts(argv)
        actual = dict((k, v) for k, v in vars(opts).items() if v is not None)
        print(actual)
        assert actual == expected, (actual, expected)
        # Test -o help
        assert not opts.outtmpl
        opts, args = parser.parse_args(argv + ['--help'])
        assert not opts.outtmpl


# Generated at 2022-06-22 09:14:15.939591
# Unit test for function parseOpts
def test_parseOpts():
    print('[ Unit testing parseOpts ]\n')

    from youtube_dl.compat import compat_expanduser, compat_getenv, compat_os_name, compat_shlex_split

    # Test whether variables are parsed correctly
    test_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    test_url2 = 'http://www.youtube.com/watch?v=BaW_jenozKc&v=v=up_lNV-yoK4'
    test_url3 = 'https://www.googleapis.com/youtube/v3/videos?part=id&id=1&key=AIzaSyCMAj_UZTpNch5aNfL-qk8cT1TjmSeT6Bg'


# Generated at 2022-06-22 09:14:18.795765
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert opts is not None
    assert args is not None
run_if_tests_enabled(__name__)


# Generated at 2022-06-22 09:14:43.073138
# Unit test for function parseOpts
def test_parseOpts():
    # assert(parseOpts(None, ['--version'])[1:])
    assert(parseOpts(None, ['--ignore-config', '--extract-audio', '--audio-format', 'mp3', '--audio-quality', '0', '--output', '/tmp/%(title)s.%(ext)s', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1:])
    assert(parseOpts(None, ['--ignore-config', '--extract-audio', '--audio-format', 'mp3', '--audio-quality', '0', '--output', '/tmp/%(title)s.%(ext)s', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1:])

# Generated at 2022-06-22 09:14:53.320065
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import gen_extractors
    gen_extractors()

    parser, opts, args = parseOpts(['-U testuser', '-P testpass', '-c', '-f 22/17/18', 'http://example.com/a_video'])
    assert opts.username == 'testuser'
    assert opts.password == 'testpass'
    assert opts.usenetrc
    assert opts.format == '22/17/18'
    assert args == ['http://example.com/a_video']

    parser, opts, args = parseOpts(['-o', '/path/to/%(title)s-%(id)s-%(autonumber)s.%(ext)s', '-i', 'http://example.com/a_video'])


# Generated at 2022-06-22 09:15:03.677892
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose

    parser, opts, args = parseOpts(['--version'], overrideArguments=['-v'])
    assert opts.verbose
    assert opts.version
    assert not opts.noplaylist

    parser, opts, args = parseOpts(['-v', '--extract-audio', '--no-playlist'])
    assert opts.verbose
    assert opts.extractaudio
    assert opts.noplaylist


# Generated at 2022-06-22 09:15:13.551056
# Unit test for function parseOpts
def test_parseOpts():
    from_opts = partial(from_optparse, parseOpts)

    ok = from_opts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4'])
    assert ok['format'] == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4'
    ok = from_opts(['--format', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4'])
    assert ok['format'] == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4'

    ok = from_opts(['-o', '/tmp/%(title)s.webm'])
    assert ok['outtmpl'] == '/tmp/%(title)s.webm'
   

# Generated at 2022-06-22 09:15:26.036192
# Unit test for function parseOpts

# Generated at 2022-06-22 09:15:32.362899
# Unit test for function parseOpts
def test_parseOpts():
    from types import ModuleType
    # Mock module so we won't actually read files
    op = ModuleType('compat_op')
    op.parser = ModuleType('compat_op.parser')
    op.parser.OptionError = Exception
    compat_parseOpts = export_func(parseOpts) # Python 3-proof
    parseOpts_2_1 = lambda *a, **ka: compat_parseOpts(op, *a, **ka)
    def assertEqual(x, y):
        assert x == y, '%r != %r' % (x, y)

# Generated at 2022-06-22 09:15:43.120889
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'foo', '-P', 'bar', '-f', 'best', '-g', 'BESTID'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.usenetrc == False
    assert opts.video_format == 'best'
    assert opts.simulate == False
    assert opts.geturl == True
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumbnail == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.get_format_preference == False

    # Test with direct input of the GET_VIDEO_INFO extractor
    parser, opts, args

# Generated at 2022-06-22 09:15:53.576064
# Unit test for function parseOpts
def test_parseOpts():
    # For human testing, do not use doctest
    parser, opts, args = parseOpts(['-i', '-v', '--username=foo', '--password=bar', '--verbose', 'Blippex'])
    assert opts.noplaylist
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['Blippex']
    assert opts.outtmpl == '%(id)s%(ext)s'
    assert opts.verbosity == 2

    parser, opts, args = parseOpts(['--verbose', '--verbose', '--usenetrc', 'Blippex'])
    assert opts.verbosity == 2


# Generated at 2022-06-22 09:15:55.059503
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    pass


# Generated at 2022-06-22 09:16:04.641542
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from youtube_dl.utils import DateRange

    parser, opts, args = parseOpts()

    opts.simulate = False
    # Dump the result to make it available for further testing
    import pprint
    pprint.pprint(opts.__dict__)
    pprint.pprint(args)

    if not args:
        parser.print_help()
        exit(0)

    if opts.daterange:
        opts.daterange = DateRange(opts.daterange)
    if opts.match_filter:
        match_filter = opts.match_filter

# Generated at 2022-06-22 09:16:34.870747
# Unit test for function parseOpts
def test_parseOpts():
    parser = optparse.OptionParser()
    from youtube_dl.postprocessor import FFmpegMergerPP
    FFmpegMergerPP.add_options(parser)
    parseOpts(parser)


# Generated at 2022-06-22 09:16:37.195392
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()

test_parseOpts()

# The program version
__version__ = '2020.05.21'


# Generated at 2022-06-22 09:16:48.262761
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile

    if sys.version_info >= (3,):
        def u(x):
            return x
    else:
        def u(x):
            return x.decode('utf-8')

    test_conf = u('''\
--proxy
127.0.0.1:3128
-b
130
--youtube-skip-dash-manifest
--
''')
    conf_file = tempfile.NamedTemporaryFile()
    conf_file.write(test_conf.encode('utf-8'))
    conf_file.flush()


# Generated at 2022-06-22 09:16:57.985872
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    errors = StringIO()
    sys.stderr = errors

    parser, opts, args = parseOpts(['-h'])
    assert errors.getvalue() == ''
    assert not opts.verbose
    assert not opts.quiet
    assert not opts.no_warnings

    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert not opts.quiet
    assert not opts.no_warnings
    assert len(errors.getvalue()) > 0

    parser, opts, args = parseOpts(['-q'])
    assert not opts.verbose
    assert opts.quiet
    assert not opts.no_warnings
    assert len(errors.getvalue()) > 0

    parser, opts,

# Generated at 2022-06-22 09:17:07.343152
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    from types import ModuleType

    fake_opts = object()
    fake_args = object()

# Generated at 2022-06-22 09:17:17.024345
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-F', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.password == None
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.format == None
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumburl == False
    assert opts.getdescription == False
    assert opts.getthumbnails == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.outtmpl == None

# Generated at 2022-06-22 09:17:25.558887
# Unit test for function parseOpts
def test_parseOpts():
    import re
    from .compat import compat_shlex_split, compat_configparser

    class FakeOptionParser(object):
        def __init__(self):
            pass

        def parse_args(self, args):
            self.args = args
            return self

        def add_option(self, *args, **kwargs):
            pass

        def add_option_group(self, *args, **kwargs):
            pass

        def error(self, msg):
            pass

        def print_help(self):
            pass

    class FakeOption(object):
        def __init__(self, *args, **kwargs):
            self._short_opts = []
            self._long_opts = []
            self.dest = None
            self.action = None

# Generated at 2022-06-22 09:17:27.329273
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = [sys.argv[0], 'http://youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts()
    assert len(args) == 1
# }}}



# Generated at 2022-06-22 09:17:32.174422
# Unit test for function parseOpts
def test_parseOpts():
    # https://github.com/rg3/youtube-dl/issues/4435
    parser, opts, args = parseOpts('--proxy 127.0.0.1 -F'.split())
    assert opts.proxy == '127.0.0.1'
    assert args == ['-F']

    parser, opts, args = parseOpts('--proxy 127.0.0.1 -F -i'.split())
    assert opts.proxy == '127.0.0.1'
    assert args == ['-F', '-i']

    parser, opts, args = parseOpts('--proxy 127.0.0.1 -F -i --ignore-config'.split())
    assert opts.proxy == '127.0.0.1'

# Generated at 2022-06-22 09:17:42.971639
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.username == ''
    assert opts.password == ''
    assert opts.writedescription == False
    assert opts.usetitle == False
    assert opts.writeinfojson == False
    assert opts.writeannotations == False
    assert opts.writethumbnail == True
    assert opts.write_all_thumbnails == False
    assert opts.writeautomaticsub == False
    assert opts.allsubtitles == False
    assert opts.list_thumbnails == False
    assert opts.listsubtitles == True
    assert opts.subtitlesformat == None
    assert opts.continuedl == True
    assert opts.geturl == False
    assert opts.gettitle == False

# Generated at 2022-06-22 09:18:49.591100
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass


# Generated at 2022-06-22 09:19:01.763860
# Unit test for function parseOpts
def test_parseOpts():
    test_opts = ['-i', '-u', 'username', '-p', 'password', '-f', '43', '-g', '62.42', '--max-downloads', '5',
                 'https://www.youtube.com/watch?v=pfYNV-Ppc6U']
    parser, opts, args = parseOpts(overrideArguments=test_opts)
    assert opts.username == 'username'
    assert opts.password == 'password'
    assert opts.format == '43'
    assert opts.geo_bypass is True
    assert opts.geo_bypass_country == '62.42'
    assert opts.max_downloads == 5

# Generated at 2022-06-22 09:19:11.703487
# Unit test for function parseOpts
def test_parseOpts():
    class Argument:
        def __init__(self):
            self.url = "http://www.youtube.com/watch?v=_JG6Qrul6fI"
            self.outtmpl = "%(id)s"
            self.verbose = True
            self.username = "username"
            self.password = "password"
            self.username_raw = "username_raw"
            self.password_raw = "password_raw"

    arg = Argument()
    opts, args = parseOpts(arg)
    assert opts.username == "username"
    assert opts.password == "password"
    assert opts.username is None
    assert opts.password is None

# TODO: remove once __init__ is loaded from here
# from .extractor import gen_extractor_classes
# from

# Generated at 2022-06-22 09:19:21.921592
# Unit test for function parseOpts
def test_parseOpts():
    res = parseOpts()
    
    # Test if options are parsed correctly
    assert res[0].get_option("--version") is not None
    assert res[1].version is False
    assert res[1].verbose is False
    assert res[1].quiet is False
    assert res[1].usenetrc is False
    assert res[1].username is None
    
    # Test if aliases are correctly handled
    assert res[0].get_option("-U") is not None
    assert res[1].username is None
    assert res[0].get_option("--username") is not None
    assert res[1].username is None
    
    # Test if positional arguments are handled correctly
    assert len(res[2]) == 0

# Generated at 2022-06-22 09:19:30.620333
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.username is None
    assert opts.password is None
    assert opts.usenetrc is False
    parser, opts, args = parseOpts(['-u', 'foo', '-p', 'bar', '--no-usenetrc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.usenetrc is False
    parser, opts, args = parseOpts(['--usenetrc'])
    assert opts.username is None
    assert opts.password is None
    assert opts.usenetrc is True
    test_parser, test_opts, test_args = parseOpts(['--verbose'])
    assert test_opts.verb

# Generated at 2022-06-22 09:19:41.670013
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-h'])
    assert opts.help
    assert not args
    parser, opts, args = parseOpts(['-U', 'foo', 'bar'])
    assert opts.usenetrc == False
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == []
    parser, opts, args = parseOpts(['-f', '37', '-f', '38', '-g', '45', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '37'
    assert opts.all_formats is False
    assert opts.format_limit == '38'
    assert opts.format_limit is not None
   

# Generated at 2022-06-22 09:19:44.338152
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-h'])[1] == parseOpts([
        '--help'])[1]



# Generated at 2022-06-22 09:19:46.486222
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    return (parser, opts, args)

# Generated at 2022-06-22 09:19:58.250008
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import os

    def _parseOpts(args):
        return parseOpts(args, overrideArguments=[args])._get_kwargs()

    if sys.version_info < (3,):
        try:
            opt = _parseOpts(["-c"]).get("username")
            assert(opt is not None)
        except:
            raise
        try:
            opt = _parseOpts(["-c"]).get("password")
            assert(opt is not None)
        except:
            raise
        try:
            opt = _parseOpts(["--cookies", "/dev/null"]).get("username")
            assert(opt is not None)
        except:
            raise

# Generated at 2022-06-22 09:20:07.890693
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-q', '--no-warnings', '--max-downloads=2',
                      '--youtube-skip-dash-manifest', '--write-description', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1] # Don't use sys.argv, see https://github.com/rg3/youtube-dl/issues/1898
    assert opts.quiet
    assert opts.noplaylist
    assert opts.max_downloads == 2
    assert opts.youtube_skip_dash_manifest
    assert opts.writedescription
    assert opts.ignoreerrors

# Parse arguments
parser, opts, args = parseOpts()

if opts.username is not None and opts.password is None:
    opts