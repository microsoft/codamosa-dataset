

# Generated at 2022-06-22 09:11:00.476825
# Unit test for function parseOpts
def test_parseOpts():
    def check_opts(result, assertion):
        opts, leftovers = result
        assert isinstance(result, tuple)
        assert len(result) == 2
        assert isinstance(opts, optparse.Values)
        assert isinstance(leftovers, list)
        for opt, value in assertion.items():
            assert opt in dir(opts), (opt, dir(opts))
            assert getattr(opts, opt) == value, (opt, getattr(opts, opt), value)

    check_opts(
        parseOpts(['--no-check-certificate', 'http://youtube.com/watch?v=BaW_jenozKc']),
        {'nocheckcertificate': True})

# Generated at 2022-06-22 09:11:08.344623
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    argv += ['--ignore-config', '--', 'https://youtube.com/watch?v=BaW_jenozKc',
             '-f', 'best', '-o', '%(id)s.%(ext)s']
    parser, opts, args = parseOpts()
    assert opts.ignore_config == True
    assert args == ['https://youtube.com/watch?v=BaW_jenozKc']
    assert opts.outtmpl == '%(id)s.%(ext)s'

# Generated at 2022-06-22 09:11:18.899889
# Unit test for function parseOpts
def test_parseOpts():
    class Object(object):
        pass
    opts = Object()
    opts.verbose = False
    opts.username = None
    opts.password = None
    opts.ap_mso = None
    opts.ap_username = None
    opts.ap_password = None
    opts.usenetrc = False
    opts.quiet = False
    opts.no_warnings = False
    opts.forceurl = False
    opts.forcetitle = False
    opts.forcethumbnail = False
    opts.forcedescription = False
    opts.simulate = False
    opts.skip_download = False
    opts.format = None
    opts.listformats = False
    opts.outtmpl = '%(id)s'
    opts

# Generated at 2022-06-22 09:11:24.375731
# Unit test for function parseOpts
def test_parseOpts():
    """
    >>> test_parseOpts()
    """
    # We need to generate a configuration file so that it can be passed as argument
    config_file = os.path.join(os.path.dirname(__file__), 'config.conf')
    config = '--proxy http://127.0.0.1:3128 --download-archive archive.txt --prefer-free-formats -i '
    with open(config_file, 'w') as f:
        f.write(config)

    # First we define the command-line argument to be parsed

# Generated at 2022-06-22 09:11:35.150543
# Unit test for function parseOpts
def test_parseOpts():
  opts, args = parseOpts(overrideArguments=['--yes-playlist'])
  assert opts.yes_playlist == True


# Parameters
# ----------
# url: string
#     video url
# outtmpl: string
#     template for output file
# referer: string
#     Referer to use for HTTP requests
# player_url: string
#     URL of the player file if returned by extractor
# ssl_verify: boolean
#     Enable verification of SSL certificates
# verbose: boolean
#     Print additional info to stdout
# quiet: boolean
#     Do not print messages to stdout
# skip_download: boolean
#     Do not download the video
# format: string
#     Video format code
# player_params: dict
#     Additional parameters to be passed to the player
# dump_single

# Generated at 2022-06-22 09:11:43.882802
# Unit test for function parseOpts

# Generated at 2022-06-22 09:11:55.857997
# Unit test for function parseOpts
def test_parseOpts():
    from compat import compat_expanduser
    from youtube_dl.utils import match_filter_func
    from youtube_dl.extractor import gen_extractor_classes
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.downloader import gen_ext_downloader_classes

    parser, opts, args = parseOpts(['--extractor-descriptions'])
    assert opts.print_version
    assert opts.print_extractor_descriptions

    parser, opts, args = parseOpts(['-U'])
    assert opts.update_self

    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == 1

# Generated at 2022-06-22 09:12:02.461442
# Unit test for function parseOpts
def test_parseOpts():
    p, o, a = parseOpts(['-v'])
    assert('help' in o.__dict__)
    assert(o.verbose)

    try:
        p, o, a = parseOpts(['-n'])
    except (optparse.OptionValueError, optparse.OptionError):
        raise AssertionError('numeric options should accept empty strings')
    assert(o.nooverwrites)

    p, o, a = parseOpts(['--proxy', '1.2.3.4:8080'])
    assert(o.proxy == '1.2.3.4:8080')

# Parse arguments
parser, opts, args = parseOpts()

if opts.version:
    compat_print(version_string())
    sys.exit(0)



# Generated at 2022-06-22 09:12:08.393973
# Unit test for function parseOpts
def test_parseOpts():
    # Running this script without arguments
    if __name__ == "__main__":
        parser, opts, args = parseOpts()
        print('opts: ' + str(opts))
        print('args: ' + str(args))
    return True


# Generated at 2022-06-22 09:12:15.383261
# Unit test for function parseOpts
def test_parseOpts():
    cmdargs = ['--no-warnings','https://www.youtube.com/watch?v=F2r0r_GZX-s','--no-playlist']
    parser, opts, _ = parseOpts(cmdargs)
    assert opts.noplaylist
    assert opts.nocheckcertificate
    assert opts.verbose


# Generated at 2022-06-22 09:12:43.879380
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(
        ['--no-warnings', '--output', '/foo/%(title)s-%(id)s.%(ext)s',
         '--format', 'best[height<=720]', '--list-formats', 'bar'])
    assert not opts.verbose
    assert not opts.no_warnings
    assert opts.simulate
    assert opts.format == 'best[height<=720]'
    assert opts.outtmpl == '/foo/%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors
    assert opts.ratelimit == '10240'
    assert opts.retries == 10
    assert opts.playliststart == 1

# Generated at 2022-06-22 09:12:51.976531
# Unit test for function parseOpts
def test_parseOpts():
    def get_args(**kwargs):
        conf = {name: kwargs[name] for name in sorted(kwargs) if name in ('username', 'password', 'ap_password')}
        command_line_conf = ['--' + option for option, value in conf.items() if value]
        username = kwargs['username'] or 'dummyuser'
        password = kwargs['password'] or 'dummypass'
        ap_password = kwargs['ap_password'] or 'dummyap_pass'
        config_text = '--username %s --password %s --ap-password %s' % (username, password, ap_password)
        user_conf = _readOptions(config_text)
        return command_line_conf + user_conf

    # Test from the command line
    # Change the config to match

# Generated at 2022-06-22 09:12:57.897692
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-c', '-o', 'out', '-u', 'user', '-p', 'pass', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    if opts.verbose:
        opts.quiet = False
        opts.no_warnings = True



# Generated at 2022-06-22 09:12:59.005232
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
# End of unit test



# Generated at 2022-06-22 09:13:00.743634
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == None
    assert opts.password == None
    assert opts.usenetrc == False

# Generated at 2022-06-22 09:13:12.065643
# Unit test for function parseOpts
def test_parseOpts():
    """Function to test parseOpts"""
    expected_thumbnail_optgroup = ['-t',
                                   '--title',
                                   '-l',
                                   '--literal',
                                   '-w',
                                   '--no-overwrites',
                                   '-c',
                                   '--continue',
                                   '--no-continue',
                                   '--no-part',
                                   '--no-mtime',
                                   '--write-description',
                                   '--write-info-json',
                                   '--write-annotations',
                                   '--load-info-json',
                                   '--load-info',
                                   '--cookies',
                                   '--cache-dir',
                                   '--no-cache-dir',
                                   '--rm-cache-dir']
    thumbnail_opt

# Generated at 2022-06-22 09:13:22.576959
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.version import __version__
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRangeLimit
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.extractor import gen_extractors
    gen_extractors()
    parser, opts, args = parseOpts(['-i', '--no-playlist', '--min-views', '10',
        '--max-views', '20', '--dateafter', '20130101', '--datebefore', '20130331',
        '--date', '20130210', '--sleep-interval', '2', '--no-color'])
    assert opts.simulate is True
    assert opts.quiet is False
    assert opts.no_warnings is False
    assert opt

# Generated at 2022-06-22 09:13:32.256344
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-o', 'a.%(ext)s'])
    assert opts.outtmpl == 'a.%(ext)s'
    assert len(args) == 0
    parser, opts, args = parseOpts(['http://www.example.com/watch?v=BaW_jenozKc'])
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert len(args) == 1


# http://stackoverflow.com/questions/1208916/decoding-html-entities-with-python/1208931#1208931

# Generated at 2022-06-22 09:13:40.805109
# Unit test for function parseOpts
def test_parseOpts():
    # Test with an empty list
    assert parseOpts(overrideArguments=[]).args == []

    # Test with a list containing two elements
    parser, options, args = parseOpts(overrideArguments=['--version', '--ignore-config'])
    assert args == []
    assert options.version
    assert options.ignoreconfig

    # Test with one element which is a list
    parser, options, args = parseOpts(overrideArguments=['--version', '--ignore-config', ['--list-extractors', '--list-extractor-descriptions']])
    assert options.list_extractors
    assert options.listextractor
    assert options.ignoreconfig

    # Test that a config file is loaded, even if it is empty

# Generated at 2022-06-22 09:13:50.611710
# Unit test for function parseOpts
def test_parseOpts():
    import re
    import sys
    class FakeOptionParser:
        def __init__(self, *args, **kargs):
            pass
        def add_option(self, *args, **kargs):
            pass
        def add_option_group(self, *args, **kargs):
            pass
        def error(self, *args, **kargs):
            pass
    class FakeOption:
        def __init__(self, *args, **kargs):
            pass
    def _fake_getprogpath():
        return 'fake'
    def _fake_get_on_win_registry_value(unused, unused_name):
        return 'c:\\program files\\youtube-dl\\fake.exe'

# Generated at 2022-06-22 09:14:11.295223
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print(opts.__dict__)
    print(args)


# Generated at 2022-06-22 09:14:22.358089
# Unit test for function parseOpts
def test_parseOpts():
    class FakeArgs(object):
        def __init__(self):
            self.username = None
            self.password = None
            self.twofactor = None
            self.videopassword = None
    fake_args = FakeArgs()
    from .extractor.common import InfoExtractor
    class FakeYoutubeDL(object):
        def __init__(self, params=None):
            self._ies = [InfoExtractor(self, 'Youtube', 'youtube')]
            self._ies_inst = {}
            self.params = params or {}
            self.to_screen = lambda *args, **kargs: None
        def add_info_extractor(self, ie):
            self._ies.append(ie)
        def set_option(self, key, val):
            self.params[key] = val
   

# Generated at 2022-06-22 09:14:31.304580
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'youtube-dl', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    login_info = _hide_login_info([
        '-U', 'youtube-dl',
        'https://www.youtube.com/watch?v=BaW_jenozKc',
        '--username', 'my_username', '--password', 'my_password',
    ])
    assert opts.username == 'my_username'
    assert opts.password == 'my_password'
    assert opts.noprogress == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opt

# Generated at 2022-06-22 09:14:42.462111
# Unit test for function parseOpts
def test_parseOpts():
    args = ['--verbose', '-U', 'Mozilla/5.0',
            '--quiet', '--youtube-skip-dash-manifest',
            '--proxy', '1.2.3.4',
            '--extract-audio', '--audio-format', 'aac', '--audio-quality', '3',
            'http://www.youtube.com/watch?v=BaW_jenozKc']
    opts = parseOpts(args)[1]
    assert opts.verbose
    assert opts.quiet
    assert opts.writeinfojson
    assert opts.writethumbnail
    assert opts.writeannotations
    assert opts.writeautomaticsub
    assert opts.usenetrc is False
    assert opts.username is None

# Generated at 2022-06-22 09:14:52.918864
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.youtube_include_dash_manifest == True
    assert opts.dump_user_agent == False
    assert opts.dump_intermediate_pages == False
    assert opts.write_pages == False
    assert opts.write_json == False
    assert opts.write_info_json == False
    assert opts.print_json == False
    assert opts.match_filter == None
    assert opts.no_color == False

# Generated at 2022-06-22 09:15:03.400879
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.format == None
    assert opts.extractaudio == False
    assert opts.audioformat == "best"
    assert opts.outtmpl == "%(id)s"
    assert opts.nooverwrites == False
    assert opts.usetitle == False
    assert opts.listformats == False
    assert opts.listsubtitles == False
    assert opts.subtitlesformat == "srt"
    assert opts.continue_dl == True
    assert opts.noplaylist == False
    assert opts.usernames == None
    assert opts.password == None
    assert opts.ap_mso == ""

# Generated at 2022-06-22 09:15:05.212861
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([])



# Generated at 2022-06-22 09:15:08.418279
# Unit test for function parseOpts
def test_parseOpts():
    """
    Test the parseOpts() function.
    """
    #
    # TODO: Complete this test
    #
    pass
#
# Test for the classes in this module
#

# Generated at 2022-06-22 09:15:16.105199
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: This test is not very good, it should be improved
    # to check if opts(s) given to parseOpts() are equal to the
    # opts(s) received from parseOpts().
    print(parseOpts())

    print(parseOpts(['-h']))

    print(parseOpts(['--ignore-config', '-h']))

# }}} #


# Generated at 2022-06-22 09:15:20.255017
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts(['-U', 'test'])

    assert opts.username == 'test'
# parseOpts()



# Generated at 2022-06-22 09:15:44.924062
# Unit test for function parseOpts
def test_parseOpts():
    #
    # mock_sys is a mock object that represents sys.argv.
    # To call parseOpts() on it, we have to first insert a mock object for sys itself.
    # Later, that mock object is removed,
    # to avoid tests that use sys.argv from failing
    #
    with mock.patch('sys.argv', ['youtube-dl', '-U']):
        with mock.patch('sys.modules', {'sys': None}):
            parser, opts, args = parseOpts()
            assert_equals(opts.update_self, True)

#
# Library functions
#



# Generated at 2022-06-22 09:15:55.067196
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.usenetrc is False
    assert opts.password is None

    parser, opts, args = parseOpts(['--username', 'foo', '--password', 'bar'])
    assert opts.usenetrc is False
    assert opts.username == 'foo'
    assert opts.password == 'bar'

    parser, opts, args = parseOpts(['--usenetrc'])
    assert opts.usenetrc is True
    assert opts.username is None or opts.username == ''
    assert opts.password is None or opts.password == ''

    parser, opts, args = parseOpts(['--usenetrc', '--username', 'foo', '--password', 'bar'])

# Generated at 2022-06-22 09:16:00.788094
# Unit test for function parseOpts
def test_parseOpts():
    # Config variable is defined in the global scope
    # as to prevent pylint from complaining about accessing
    # a variable before it is defined
    config = {}
    config['general'] = {}
    config['general']['quiet'] = True
    config['general']['ignoreerrors'] = False
    config['general']['forcefilename'] = True
    config['general']['forcetitle'] = True
    config['general']['forcedescription'] = False
    config['general']['forceformat'] = False
    config['general']['forceduration'] = True
    config['general']['forcefilename'] = True
    config['general']['max_downloads'] = None
    config['general']['max_filesize'] = None

    config['network'] = {}

# Generated at 2022-06-22 09:16:08.298170
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args  = parseOpts()
    assert opts.addmetadata == True
    assert opts.embedthumbnail == True
    assert opts.embedsubtitles == True
    assert opts.nopostoverwrites == True
    assert opts.keepvideo == True
    assert opts.metafromtitle == None
    assert opts.xattrs == False
    assert opts.fixup == 'detect_or_warn'
    assert opts.prefer_ffmpeg == True
    assert opts.ffmpeg_location == None
    assert opts.exec_cmd == None
    assert opts.convertsubtitles == None

# Similar to os.path.expanduser

# Generated at 2022-06-22 09:16:19.757201
# Unit test for function parseOpts
def test_parseOpts():
    # Creates a parser object and calls the parseOpts function to parse the arguments
    # with the defined options
    parser, opts, args = parseOpts(['-f', '18', '--max-downloads', '1', 'http://youtube.com/watch?v=BaW_jenozKc'])
    # Checks whether the parser is a subclass of the subclass of the OptionParser class
    assert(isinstance(parser, optparse.OptionParser))
    # Checks whether the given arguments are successfully parsed
    assert(args == ['http://youtube.com/watch?v=BaW_jenozKc'])
    # Checks if the correct values are retrieved for the options
    assert(opts.format == '18')
    assert(opts.max_downloads == '1')

# Determines whether the download should resume and returns a

# Generated at 2022-06-22 09:16:29.320952
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeArgument

    # Basic test
    parser, opts, args = parseOpts([])
    assert opts.verbose == False

    # Test -v
    parser, opts, args = parseOpts([encodeArgument('-v')])
    assert opts.verbose == True

    # Test -v
    parser, opts, args = parseOpts([encodeArgument('-v')])
    assert opts.verbose == True

    # Test -v -v
    parser, opts, args = parseOpts([encodeArgument('-v'), encodeArgument('-v')])
    assert opts.verbose == False

    # Test -4 (--force-ipv4)
    parser, opts, args = parseOpts([encodeArgument('-4')])

# Generated at 2022-06-22 09:16:38.579108
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(None)
    assert opts.default_search == 'auto'
    parser, opts, args = parseOpts(['--default-search', 'ytsearch'])
    assert opts.default_search == 'ytsearch'
    parser, opts, args = parseOpts([])
    assert opts.user_agent == 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)'
    parser, opts, args = parseOpts(['--user-agent', 'my-user-agent'])
    assert opts.user_agent == 'my-user-agent'
    parser, opts, args = parseOpts(['--retries', '1'])
    assert opts.retries == 1
    parser, opt

# Generated at 2022-06-22 09:16:47.517216
# Unit test for function parseOpts
def test_parseOpts():
    from .compat import compat_shlex_quote
    import sys
    for args in [[], ['-h'], ['--help']]:
        try:
            parseOpts(args)
        except SystemExit as se:
            # These args should terminate
            assert se.code == 0, 'Should exit with code 0 for --help'
        else:
            assert False, 'Should exit for --help'

    for args in [['-U', 'foobar'], ['--username', 'foobar']]:
        try:
            parseOpts(args)
        except SystemExit as se:
            # These args with no url should terminate
            assert se.code == 2, 'Should exit with code 2 when username is provided without URL'
        else:
            assert False, 'Should exit when username is provided without URL'


# Generated at 2022-06-22 09:16:59.938716
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([
        '-U', 'Mozilla',
        '-f', '18/22/37',
        '--prefer-free-formats',
        '-o', 'a.fmt',
        '-F',
        'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.noplaylist == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forceduration == False
    assert opts.forcefilename == False
    assert opts.forcedlurl == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False

# Generated at 2022-06-22 09:17:08.767097
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import chdir
    from os.path import isdir
    from tempfile import mkdtemp
    from shutil import rmtree

    global original_fd

    opts = None
    args = None
    usage = 'usage: foobar' # placeholder for later replacement
    my_argv = [u'prog']
    original_fd = sys.stderr


# Generated at 2022-06-22 09:17:56.397305
# Unit test for function parseOpts
def test_parseOpts():
    try:
        import StringIO
    except ImportError:
        import io as StringIO
    # Load the script without raising SystemExit exception
    def _read_script():
        return open(__scriptname__, 'rb').read().decode('utf-8')
    old_read_script = youtube_dl.__main__._read_script
    old_sys_exit = sys.exit
    old_sys_stdout = sys.stdout
    try:
        sys.exit = lambda code: None
        sys.stdout = StringIO.StringIO()
        youtube_dl.__main__._read_script = _read_script
        parseOpts()
    finally:
        youtube_dl.__main__._read_script = old_read_script
        sys.exit = old_sys_exit
        sys.stdout = old_

# Generated at 2022-06-22 09:17:59.878770
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    print(parser.format_help().encode('utf-8'))
    #print(opts)
    #print(args)

#test_parseOpts()


# Generated at 2022-06-22 09:18:11.491356
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import os
    import shutil
    import tempfile
    from unittest import TestCase
    import youtube_dl.utils

    tempdir = os.path.realpath(tempfile.mkdtemp())

    test_filename_output = os.path.realpath(os.path.join(tempdir, 'foo.%(ext)s'))

    test_env = {
        'HOME': tempdir,
        'XDG_CONFIG_HOME': tempdir,
        'XDG_CACHE_HOME': tempdir,
        'YOUTUBE_DL_CONFIG_FILE': '',
    }

    def clear_tempdir():
        youtube_dl.utils.delete_file(test_filename_output)
        for f in os.listdir(tempdir):
            f = os.path

# Generated at 2022-06-22 09:18:22.362873
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv as sys_argv
    try:
        sys_argv = sys_argv[:1]
        sys_argv += ['--verbose']
        _, opts, _ = parseOpts()
        assert opts.verbose
        sys_argv[1:] = ['--proxy', '1.1.1.1']
        _, opts, _ = parseOpts()
        assert opts.proxy == '1.1.1.1'
    finally:
        sys_argv = sys_argv[:1]
# extractor/common.py

# Copyright (C) 2010-2019 The python-ytdl Project
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software

# Generated at 2022-06-22 09:18:29.062815
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from youtube_dl.utils import encodeArgument
    sampleconf = u'''--no-playlist --username=bar --password aaa --verbose --ignore-config --list-extractors --proxy http://localhost:8118 -i
--extractor-descriptions
--dump-user-agent'''

    sampleopts = [
        'youtube-dl', '--ignore-config', 'http://www.youtube.com/',
        '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config',
        '--', '-i', '--extractor-descriptions', '--dump-user-agent', '--', '--verbose']

    sampleargs = sampleopts[len(sampleconf.split()) + 1:]

# Generated at 2022-06-22 09:18:41.626332
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-o', 'fuck'])
    assert opts.outtmpl == 'fuck'
    parser, opts, args = parseOpts(['-o', 'fuck', '-o', 'fuck2'])
    assert opts.outtmpl == 'fuck2'
    parser, opts, args = parseOpts(['-f', 'fuck'])
    assert opts.format == 'fuck'
    parser, opts, args = parseOpts(['-f', 'fuck', '-f', 'fuck2'])
    assert opts.format == 'fuck2'
    parser, opts, args = parseOpts(['--ffmpeg-location', 'fuck'])
    assert opts.ffmpeg_location == 'fuck'
    parser, opts, args = parseOpts

# Generated at 2022-06-22 09:18:53.450269
# Unit test for function parseOpts
def test_parseOpts():
    from .YoutubeDL import YoutubeDL
    from .postprocessor import FFmpegMergerPP
    from .utils import encodeFilename
    from .extractor import get_info_extractor
    for opts, desc in _test_parseOpts():
        parser, opts, args = _parseOpts(overrideArguments=opts)

        # Check audio formats
        if opts.extractaudio:
            if opts.audioformat not in ['best', 'aac', 'flac', 'mp3', 'm4a', 'opus', 'vorbis', 'wav']:
                parser.error(('invalid audio format "%s"' % opts.audioformat).encode(preferredencoding()))
            if opts.audioformat == 'best':
                opts.audioformat = None
            # TODO Remove when #980 has been merged

# Generated at 2022-06-22 09:18:55.711749
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    # TODO: Do more testing

### File Availability

# Generated at 2022-06-22 09:19:02.330945
# Unit test for function parseOpts
def test_parseOpts():
    from ydl.YoutubeDL import YoutubeDL
    #    parser, opts, args = parseOpts(overrideArguments=['-o', '/tmp/myvideo'])
    parser, opts, args = parseOpts(None, YoutubeDL)
    print(opts.outtmpl)
    print(opts.playliststart)
    print(opts.nooverwrites)


# Generated at 2022-06-22 09:19:13.542744
# Unit test for function parseOpts
def test_parseOpts():
    # Test using a custom configuration file
    from tempfile import mkstemp, NamedTemporaryFile
    from os.path import exists
    from os import close, remove
    # Createa a tempfile
    __, fname = mkstemp(suffix='-youtube-dl-test.conf')
    with open(fname, 'wb') as f:
        # Write some configuration to it
        f.write(b'--dump-user-agent\n')
        f.write(b'--ignore-config\n')
        f.write(b'--default-search iscript\n')
        f.write(b'--no-check-certificate\n')
        f.write(b'--playlist-reverse\n')
        f.write(b'--no-color\n')