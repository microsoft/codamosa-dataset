

# Generated at 2022-06-22 09:10:55.382064
# Unit test for function parseOpts
def test_parseOpts():
    class FileFaker:
        def __init__(self, content=[]):
            self.read = lambda: '\n'.join(content)

    # No config file
    options = FileFaker()
    parser, opts, args = parseOpts(FileFaker([
        '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio',
        '--config-location', '/dev/null', '--yes-playlist', 'https://www.youtube.com/watch?v=BaW_jenozKc']), options)
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio'
    assert opts.ignoreerrors
    assert opts.noplaylist
    assert opts.yes

# Generated at 2022-06-22 09:11:03.844500
# Unit test for function parseOpts
def test_parseOpts():
    oldstderr = sys.stderr
    sys.stderr = StringIO()
    # Let's see if it handles -o correctly
    try:
        parseOpts(['-o', 'Hallå.flv', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
        assert(False)
    except SystemExit:
        pass
    parseOpts(['-o', 'Hallå/%(title)s-%(id)s.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-22 09:11:06.507504
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--no-check-certificate'])
    assert not opts.check_certificate

# vim: expandtab:sw=4:ts=4

# Generated at 2022-06-22 09:11:16.971743
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts()
    assert opts.username == None
    parser, opts, _ = parseOpts(['-u', 'mylogin', '--password', 'mypasswd'])
    assert opts.username == 'mylogin'
    assert opts.password == 'mypasswd'
    parser, opts, _ = parseOpts(['--username', 'foobar'])
    assert opts.username == 'foobar'
    assert opts.password is None
    parser, opts, _ = parseOpts(['--usenetrc'])
    assert opts.username is None
    assert opts.password is None
    parser, opts, _ = parseOpts(['--netrc'])
    assert opts.username is None
    assert opts.password is None


# Generated at 2022-06-22 09:11:24.158455
# Unit test for function parseOpts
def test_parseOpts():
    (parser, opts, args) = parseOpts(['-U', 'randomSpider', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'randomSpider'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    (parser, opts, args) = parseOpts([])
    assert not args


# Generated at 2022-06-22 09:11:27.740314
# Unit test for function parseOpts
def test_parseOpts():
    from .YoutubeDL import YoutubeDL
    sys.argv = ['youtube-dl']
    ydl = YoutubeDL()
    assert(isinstance(ydl, YoutubeDL))

if __name__ == '__main__':
    test_parseOpts()

# Generated at 2022-06-22 09:11:39.238181
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeFilename
    from youtube_dl.compat import get_filesystem_encoding

    enc = get_filesystem_encoding()
    if enc is None:
        enc = 'utf-8'

    def _check_encoding(s):
        try:
            s.encode(enc)
        except UnicodeEncodeError:
            return False
        else:
            return True

    # https://github.com/ytdl-org/youtube-dl/issues/13537
    INVALID = '\xff\xa0'
    if _check_encoding(INVALID):
        raise Exception('Invalid test, ' + repr(INVALID) + ' is not invalid in ' + repr(enc))

    # Basic test
    opts, args = parseOpts(['-o', '.'])

# Generated at 2022-06-22 09:11:40.534217
# Unit test for function parseOpts
def test_parseOpts():
    assert(parseOpts(['-h']) == None)


# Generated at 2022-06-22 09:11:53.349077
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.utils import _hide_login_info
    assert parseOpts([
        'youtube-dl',
        '--version',
    ]) == (
        'youtube-dl 2017.1.7\n',
        '',
        ''
    )

# Generated at 2022-06-22 09:12:04.080802
# Unit test for function parseOpts
def test_parseOpts():
    global _hide_login_info
    def hide_login_info_identity(s):
        return s
    _hide_login_info = hide_login_info_identity
    opts = parseOpts([])[1]
    opts_expected = {}
    assert opts.__dict__ == opts_expected, 'Expected: %r, but received: %r' % (opts_expected, opts.__dict__)
    opts = parseOpts(['--help'])[1]
    assert opts.__dict__ == opts_expected, 'Expected: %r, but received: %r' % (opts_expected, opts.__dict__)
    opts = parseOpts(['--list-extractors'])[1]
    assert opts.__dict__ == opts_

# Generated at 2022-06-22 09:12:22.331004
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'IE', '-g', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert type(parser) == optparse.OptionParser
    assert type(opts) == optparse.Values
    assert type(args) == list
    assert opts.username == 'IE'
    assert opts.geo_verification_proxy == 'https://www.youtube.com/watch?v=BaW_jenozKc'


# Generated at 2022-06-22 09:12:34.451316
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(overrideArguments=['-i', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.ignoreerrors == True, 'Ignore errors set to True'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc'], 'Accepted arguments'
    parser, opts, args = parseOpts(overrideArguments=['--username', 'testuser', '--password', 'testpass', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'testuser', 'Username set to testuser'
    assert opts.password == 'testpass', 'Password set to testpass'

# Generated at 2022-06-22 09:12:45.185589
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts()
    assert opts.proxy
    assert opts.simulate
    assert opts.skip_download
    assert opts.quiet
    assert opts.verbose
    assert opts.format == 'best'
    assert not opts.dump_user_agent
    assert not opts.list_extractors
    assert not opts.dump_interfaces
    assert not opts.dump_json
    assert not opts.usenetrc
    assert not opts.username
    assert not opts.password
    assert not opts.twofactor
    assert not opts.videopassword
    assert not opts.ap_mso
    assert not opts.ap_username
    assert not opts.ap_password
    assert not opts.list_formats


# Generated at 2022-06-22 09:12:54.077791
# Unit test for function parseOpts
def test_parseOpts():
    class FakeArgs(object):
        def __init__(self, args):
            self.args = args

        def __iter__(self):
            return self.args.__iter__()

        def __len__(self):
            return len(self.args)

        def __getitem__(self, i):
            return self.args[i]

    # We need http_proxy to be defined and non-empty.
    http_proxy = os.environ.get('http_proxy')
    os.environ['http_proxy'] = 'http://localhost:3128'


# Generated at 2022-06-22 09:13:01.377364
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    from pathlib import Path
    import tempfile
    import shutil
    import sys

    class FakeYDL(YoutubeDL):
        """Minimal YoutubeDL subclass for testing.

        Attributes:
          _ydl_opts: stores the options
          executable: stores the executable
          to_stderr: stores messages written to stderr
          to_stdout: stores messages written to stdout
        """
        def __init__(self, *args, **kwargs):
            self._ydl_opts = None
            self._outtmpl = None
            self._opener = None
            self._cookiejar = None
            self._cachedir = None
            self._nopart = None
            self._progress_hooks = []

# Generated at 2022-06-22 09:13:12.454800
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-ivu', 'http://example.com'])
    assert opts.verbose == 2
    assert opts.quiet == False
    assert opts.update == True
    assert opts.url == ['http://example.com']

    parser, opts, args = parseOpts(['--verbose', '--max-quality=22', 'http://example.com', '--'])
    assert opts.verbose == True
    assert opts.max_quality == '22'
    assert opts.url == ['http://example.com']
    assert args == ['--']

    parser, opts, args = parseOpts(['--ignore-config', '-U', 'test1', '--config-location', 'test'])
    assert opts.noconfig == True

# Generated at 2022-06-22 09:13:21.504514
# Unit test for function parseOpts
def test_parseOpts():
    dummy_args = [
        '-v', 'https://www.youtube.com/watch?v=BaW_jenozKc',
        '-o', '/Users/user/Desktop/%(title)s.%(ext)s'
    ]
    parser, opts, _ = parseOpts(dummy_args)
    # Check video id
    assert_equal(opts.videoid, 'BaW_jenozKc')
    # Check formats
    assert_equal(opts.format, None)
    assert_equal(opts.listformats, False)
    # Check preferred format
    assert_equal(opts.prefer_free_formats, False)
    assert_equal(opts.format_limit, None)
    # Check proxy
    assert_equal(opts.proxy, None)
   

# Generated at 2022-06-22 09:13:32.793120
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import os
    import warnings
    import pprint

    opt = __import__('optparse').OptionParser()
    opt.add_option('-u', '--url', action='append', dest='urls', default=[])
    opt.add_option('-v', '--verbose', action='store_true', dest='verbose')
    opt.add_option('--progress-url', action='store_true', dest='progress_url')
    opt.add_option('--config-location', action='store', dest='config_location')
    opt.add_option('--ignore-config', action='store_true', dest='ignore_config')
    opt.add_option('-a', '--batch-file', action='store', dest='batchfile')

# Generated at 2022-06-22 09:13:41.124558
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', '37/22/18', '--no-mtime', '--', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '37/22/18'
    assert not opts.updatetime
    assert args == ['http://youtube.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts(['--format', '37/22/18', '--no-mtime', '--', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '37/22/18'
    assert not opts.updatetime

# Generated at 2022-06-22 09:13:50.737793
# Unit test for function parseOpts
def test_parseOpts():
    opts1 = {'verbose': True}
    opts2 = {'verbose': True, 'nooverwrites': True, 'usetitle': True}
    opts3 = {'verbose': True, 'nooverwrites': True, 'usetitle': True, 'writethumbnail': True}
    opts4 = {'verbose': True, 'writethumbnail': True}
    opts5 = {'verbose': True, 'writethumbnail': True, 'writeannotations': True}

    parser, resultOpts, args = parseOpts([])
    assert resultOpts.verbose == opts1['verbose']
    assert resultOpts.nooverwrites == opts1['nooverwrites']
    assert resultOpts.usetitle == opts1['usetitle']


# Generated at 2022-06-22 09:14:08.214324
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.geturl
    assert opts.usenetrc is True
    assert opts.username is None
    assert opts.password is None

# If a video needs a login, this function is called.

# Generated at 2022-06-22 09:14:10.707080
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import doctest
    sys.exit(doctest.testmod()[0])

if __name__ == "__main__":
    test_parseOpts()

# Generated at 2022-06-22 09:14:14.187596
# Unit test for function parseOpts
def test_parseOpts():
    opts = _parseOpts(overrideArguments=['--max-downloads=50'])
    assert opts.max_downloads == 50


# Generated at 2022-06-22 09:14:24.697592
# Unit test for function parseOpts
def test_parseOpts():
    print("Testing parseOpts()")
    parser, opts, args = parseOpts(["-g", "youtube.com", "-m", "-f", "http://www.youtube.com/watch?v=BaW_jenozKc"])
    assert(opts.__dict__["url"] == "youtube.com")
    assert(opts.__dict__["matchtitle"] == True)
    assert(opts.__dict__["format"] == "http://www.youtube.com/watch?v=BaW_jenozKc")
    assert(opts.__dict__["cachedir"] == None)
    parser, opts, args = parseOpts(["--no-cache"])
    assert(opts.__dict__["cachedir"] == False)

# Generated at 2022-06-22 09:14:31.364082
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--ignore-config', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.ignoreconfig
    assert opts.usenetrc
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'



# Generated at 2022-06-22 09:14:39.655658
# Unit test for function parseOpts
def test_parseOpts():
    try:
        parser, opts, args = parseOpts(['-U', 'unit_test'])
    except (IOError, DownloadError) as err:
        _, e, _ = sys.exc_info()
        raise Error(e)

    assert opts.usenetrc == False
    assert opts.username == 'unit_test'
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
test_parseOpts()

# Generated at 2022-06-22 09:14:45.910457
# Unit test for function parseOpts
def test_parseOpts():
  # Define "in" and "out" for parseOpts
  #in: command line OPTIONS,
  #out: parser, opts, args
  # We don't need to test config file
  # and argv
  # So just pass None to them

  assert parseOpts(None)[0]
  assert parseOpts(None)[1]
  assert parseOpts(None)[2]

  # Test --version
  assert parseOpts(['--version'])[0] == None
  assert parseOpts(['--version'])[1] == None
  with pytest.raises(SystemExit):
    parseOpts(['--version'])[2]

  
  # Test --help
  assert parseOpts(['--help'])[0] == None

# Generated at 2022-06-22 09:14:58.449233
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import tempfile

    def _test_parse_opts_impl(args, expected):
        with tempfile.NamedTemporaryFile(suffix='.conf') as f:
            f.write(b' '.join(args))
            f.flush()
            parser, opts, args = parseOpts(['--config-location=' + f.name])
            assert opts.__dict__ == expected

    _test_parse_opts_impl(
        [b'--username', b'foo', b'--password', b'bar'],
        {'username': 'foo', 'password': 'bar'})

    _test_parse_opts_impl(
        [b'--no-check-certificate'],
        {'nocheckcertificate': True})

    _test_parse_opts_impl

# Generated at 2022-06-22 09:15:02.370924
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    opts, args = parseOpts(argv)
    assert opts
    assert args

# ======================================================================================================================
# Functions for initializing and cleaning up
# ======================================================================================================================

# Generated at 2022-06-22 09:15:13.326971
# Unit test for function parseOpts
def test_parseOpts():
    def _test_compat_parser(parser, argv):
        """Parse argv using the optparse parser and return the result as optparse.Values instance.

        In Python 2, optparse returns the tuple (opts, args) while in Python 3 it returns only opts.
        This function guarantees that opts is always returned.
        """
        if sys.version_info < (3,):
            return parser.parse_args(argv)[0]
        else:
            return parser.parse_args(argv)

    def _test_compat_opts(opts):
        """Convert optparse.Values instance opts to a dict.

        In Python 2, optparse.Values is a subclass of dict while in Python 3 it's a regular class.
        This function guarantees that opts is always a dict.
        """

# Generated at 2022-06-22 09:15:47.129728
# Unit test for function parseOpts
def test_parseOpts():
    def test(argv):
        write_string('Testing with %s\n\n' % repr(argv))
        parser, opts, args = parseOpts(argv)
        for opt in parser.option_list:
            write_string('%s: %s\n' % (opt.get_opt_string(), str(getattr(opts, opt.dest))))
        write_string('files: %s\n' % args)
        if opts.verbose:
            write_string('\n\n')
    test([])
    test(['-h'])
    test(['--username', 'user', '--password', 'passwd'])
    test(['http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-22 09:15:59.046178
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeArgument

    def test(argv, expected):
        expected_command_line_conf = expected.pop('command_line_conf', [])
        expected_system_conf = expected.pop('system_conf', [])
        expected_user_conf = expected.pop('user_conf', [])
        expected_custom_conf = expected.pop('custom_conf', [])
        expected_parser_error = expected.pop('parser_error', None)
        expected_opts = expected.pop('opts', None)
        expected_args = expected.pop('args', [])
        assert not expected, 'unexpected parameters: ' + ', '.join(map(repr, expected.keys()))

        argv = list(map(encodeArgument, argv))


# Generated at 2022-06-22 09:16:07.908449
# Unit test for function parseOpts
def test_parseOpts():
    # No exception == pass.
    parseOpts()
    parseOpts(overrideArguments=['--version'])
    # Simple test for option overrides
    parser, opts, args = parseOpts(overrideArguments=['-f', 'mp4'])
    assert opts.format == 'mp4'
    # Invalid option
    try:
        parseOpts(overrideArguments=['--nonexistent'])
    except optparse.OptionValueError:
        pass
    else:
        assert False, 'invalid option should raise OptionValueError'
    # Invalid positional argument
    try:
        parseOpts(overrideArguments=['invalid', 'positional', 'argument'])
    except optparse.BadArgumentError:
        pass

# Generated at 2022-06-22 09:16:11.764028
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.usenetrc
    parser.destroy()

# Generated at 2022-06-22 09:16:23.559352
# Unit test for function parseOpts
def test_parseOpts():
    def _test(args, expected):
        parser, opts, _args = parseOpts(args)
        assert opts.__dict__ == expected.__dict__


# Generated at 2022-06-22 09:16:26.216978
# Unit test for function parseOpts
def test_parseOpts():
    # XXX: run and confirm
    parser, opts, args = parseOpts(['-v', '--verbose'])


# Generated at 2022-06-22 09:16:37.541217
# Unit test for function parseOpts

# Generated at 2022-06-22 09:16:48.561586
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    
    # Argument
    # test youtube url
    url = 'https://www.youtube.com/watch?v=yvN988Ou8XA'
    assert(url in args)
    
    # Option
    #  Option: General
    assert(opts.update == True)
    assert(opts.verbose == True)
    assert(opts.dump_user_agent == True)
    assert(opts.list_extractors == False)
    assert(opts.extractor_descriptions == False)
    
    #  Option: Network
    assert(opts.proxy == None)
    assert(opts.socket_timeout == None)
    assert(opts.source_address == None)
    
    #  Option: Geo
   

# Generated at 2022-06-22 09:16:58.200021
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    import sys
    import os
    import optparse
    from youtube_dl.utils import (expand_path, prepend_extension,
                                  unified_strdate, US_RATINGS,
                                  DEFAULT_OUTTMPL)

    compat_getenv = os.getenv

    old_getenv = os.getenv
    os.getenv = lambda var: {'LANG': 'C.UTF-8'}.get(var, old_getenv(var))

    old_parse_qs = compat_parse_qs
    def _parse_qs(qs):
        return dict((k, v[0]) for k, v in old_parse_qs(qs).items())

    compat_parse_qs = _parse_qs

    old_urlencode = compat_urlencode
    compat_url

# Generated at 2022-06-22 09:17:07.390363
# Unit test for function parseOpts
def test_parseOpts():
    def test(args, opts):
        parser, options, _ = parseOpts(args)
        for k, v in opts.items():
            assert getattr(options, k) == v
    test(['-o', 'test'], {'outtmpl': 'test'})
    test(['--output', 'test'], {'outtmpl': 'test'})
    test(['-o', 'test', '-o', 'test2'], {'outtmpl': 'test2'})
    test(['-o', 'test', '--output', 'test2'], {'outtmpl': 'test2'})
    test(['--output', 'test', '-o', 'test2'], {'outtmpl': 'test2'})

# Generated at 2022-06-22 09:18:11.252468
# Unit test for function parseOpts
def test_parseOpts():
    print('Unit test for parseOpts')
    overrideArguments=['--verbose']
    _, opts, _ = parseOpts(overrideArguments)
    assert(opts.verbose)
    overrideArguments=['--playlist-reverse']
    _, opts, _ = parseOpts(overrideArguments)
    assert(opts.playliststart == -1)
    assert(opts.playlistend == -1)


# Generated at 2022-06-22 09:18:22.051415
# Unit test for function parseOpts
def test_parseOpts():
    from io import io

# Generated at 2022-06-22 09:18:32.143672
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert(opts.version == None)
    assert(not opts.list_extractors)
    assert(not opts.list_formats)
    assert(not opts.list_subtitles)
    assert(not opts.dump_user_agent)
    assert(not opts.dump_interfaces)
    assert(not opts.simulate)
    assert(opts.quiet == False)
    assert(opts.no_warnings == False)
    assert(opts.outtmpl == None)
    assert(opts.ignoreerrors == False)
    assert(opts.forceurl == False)
    assert(opts.forcetitle == False)
    assert(opts.forceid == False)

# Generated at 2022-06-22 09:18:43.632074
# Unit test for function parseOpts
def test_parseOpts():
    ydl = YoutubeDL()

    def testConf(args, conf):
        (parsed_args, parsed_conf) = ydl.parseOpts(args)
        assert(parsed_args == conf)

    # Test output template
    testConf(['-o', '%(id)s-%(uploader)s-%(title)s-%(ext)s.%(ext)s.%(ext)s'],
             {
                 'outtmpl': '%(id)s-%(uploader)s-%(title)s-%(ext)s.%(ext)s.%(ext)s',
                 'restrictfilenames': True,
             })

    # Test default outtmpl when using -o

# Generated at 2022-06-22 09:18:44.503318
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts()[0]



# Generated at 2022-06-22 09:18:56.724889
# Unit test for function parseOpts
def test_parseOpts():
    # Create a temporary configuration file to test the --config-location function
    with tempfile.NamedTemporaryFile(prefix='youtubedl-test-config-location') as f:
        with open(f.name, 'w') as fd:
            fd.write('-b\n')
            fd.write('--no-progress\n')
            fd.write('--no-mtime\n')
            fd.write('-o $HOME/some_folder/video.%(ext)s\n')
            fd.flush()
            fd.seek(0)
            fd.close() # Close it because otherwise it will be removed
            assert os.path.isfile(f.name), 'The test configuration file does not exist!!!'

            # Test the parser and the options
            parser, opts, args

# Generated at 2022-06-22 09:19:08.240837
# Unit test for function parseOpts
def test_parseOpts():
    def parse(args, overrideArguments=None):
        return parseOpts(args, overrideArguments)

    opts, args = parse([])
    assert opts.ratelimit is None
    assert opts.retries == 10
    assert opts.dump_intermediate_pages is False

    opts, args = parse(['-r', '10K'])
    assert opts.ratelimit == '10K'
    assert opts.retries == 10

    # short option grouping
    opts, args = parse(['-r', '5K', '-R', '3'])
    assert opts.ratelimit == '5K'
    assert opts.retries == 3

    # long option grouping
    opts, args = parse(['-r', '5K', '--retries', '3'])

# Generated at 2022-06-22 09:19:15.306172
# Unit test for function parseOpts
def test_parseOpts():
    mparser, opts, args = parseOpts(overrideArguments=None)
    print(mparser.get_prog_name())
    print(mparser.get_usage())
    print(mparser.get_version())
    print(mparser.format_help())
    for opt in mparser.option_list:
        if opt.dest is not None:
            key = opt.dest
            value = getattr(opts, key)
            if value == opt.default:
                continue
            if value is not None:
                if opt.dest == 'writeinfojson':
                    continue
                if opt.dest == 'call_home':
                    continue
                if opt.dest == 'ignoreerrors':
                    continue
                if opt.dest == 'ignoreconfig':
                    continue

# Generated at 2022-06-22 09:19:24.994161
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor.common import InfoExtractor

    usage = 'Usage: test-parser -v video.file [options]'
    parser, opts, args = parseOpts(['-o', '/dev/null', '-v', 'video.file'])
    args = ['-o', '/dev/null']
    opts = parser.parse_args(args)[0]
    assert opts.verbose == 0
    assert opts.outtmpl == '/dev/null'
    assert opts.format == None

    args = ['-o', '/dev/null']
    opts = parser.parse_args(args)[0]
    assert opts.verbose == 0
    assert opts.outtmpl == '/dev/null'
    assert opts.format == None

    args = ['-o', '/dev/null']


# Generated at 2022-06-22 09:19:34.134612
# Unit test for function parseOpts