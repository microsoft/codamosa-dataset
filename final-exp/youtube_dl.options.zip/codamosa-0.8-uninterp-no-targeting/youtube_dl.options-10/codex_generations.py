

# Generated at 2022-06-22 09:11:17.053936
# Unit test for function parseOpts
def test_parseOpts():
    import os
    import re
    import shutil
    import tempfile

    def write_string(s):
        sys.stderr.write(s)

    def get_config_homedir():
        return os.path.join(tempfile.gettempdir(), 'youtube-dl-config-home')

    def compat_expanduser(path):
        if isinstance(path, bytes) and sys.version_info < (3,):
            path = path.decode(preferredencoding())
        return os.path.expanduser(path)

    def get_config_dir():
        if sys.platform == 'win32':
            return compat_expanduser(b'~\\youtube-dl')
        else:
            return os.path.join(get_config_homedir(), '.config', 'youtube-dl')

# Generated at 2022-06-22 09:11:22.704268
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.username == 'abc'
    assert opts.password == 'def'
    assert opts.usenetrc == False
    assert opts.video_password == 'ghi'
# Define function clear_console

# Generated at 2022-06-22 09:11:34.237732
# Unit test for function parseOpts
def test_parseOpts():
    from hashlib import md5
    from codecs import decode
    parser, opts, args = parseOpts()
    assert(isinstance(parser, optparse.OptionParser))
    assert(isinstance(opts, optparse.Values))
    assert(isinstance(args, list))
    assert(md5(decode(opts.username, 'rot_13')).hexdigest() == '0cab135cf14650b3cc446f64d0051db1')
    assert(md5(decode(opts.password, 'rot_13')).hexdigest() == 'd1078f425e608a89b53e2d27ee0cabd7')

# Generated at 2022-06-22 09:11:40.382620
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-h'])
    assert opts.help == True
    parser, opts, args = parseOpts(['--config-location', '~/youtube-dl.conf'])
    assert opts.config_location == os.path.expanduser('~/youtube-dl.conf')

# }}}

# {{{ Browser cookie extraction


# Generated at 2022-06-22 09:11:53.144101
# Unit test for function parseOpts
def test_parseOpts():
    def test(optlist):
        parser, opts, args = parseOpts(optlist)
        assert optlist == args, (optlist, args)
        return opts

    testing = lambda: None
    testing.quiet = False
    testing.verbose = False
    testing.dumpjson = False
    testing.simulate = False
    testing.outtmpl = None
    testing.outtmpl_na_placeholder = 'NA'
    testing.ignoreerrors = False
    testing.forceurl = False
    testing.forcetitle = False
    testing.forceid = False
    testing.forcefilename = False
    testing.forceduration = False
    testing.forcejson = False
    testing.dump_single_json = False
    testing.playliststart = None
    testing.playlistend = None
    testing.playlist_

# Generated at 2022-06-22 09:12:01.558499
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import parseOpts
    inp = ['--username=xyz', '--password=xyz', '--usenetrc', '--verbose']
    _, opts, _ = parseOpts(inp)
    return opts.password=='xyz' and opts.username=='xyz' and opts.usenetrc and opts.verbose

# Read the authentication credentials from the netrc file
# Returns: (username, password)
# Raises: netrc.NetrcParseError if no suitable authentication credentials are found

# Generated at 2022-06-22 09:12:07.462421
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-b', '--username', 'me', '--password', 'secret', '--verbose', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert parseOpts(['-u', 'me', '-p', 'secret', '--verbose', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert parseOpts(['-u', 'me', '-iw', '-i', '--verbose', 'https://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-22 09:12:19.429691
# Unit test for function parseOpts

# Generated at 2022-06-22 09:12:20.776934
# Unit test for function parseOpts
def test_parseOpts():
    pass


# Generated at 2022-06-22 09:12:32.134406
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(overrideArguments=['-h'])
    if opts is None:
        print('parseOpts() parse error')
        return

    try:
        opts = parseOpts(overrideArguments=['--ignore-config', '--no-check-certificate', '--output=%(title)s.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
        if opts is None:
            print('parseOpts() parse error')
            return
        print('parseOpts() parse successfully')
    except:
        print('parseOpts() parse wrong')


# System default configuration file

# Generated at 2022-06-22 09:12:45.481952
# Unit test for function parseOpts
def test_parseOpts():
    import warnings
    warnings.filterwarnings("ignore")
    parser, opts, args = parseOpts(['https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.proxy

# Generated at 2022-06-22 09:12:47.440496
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts()
    print(opts[2])

#test_parseOpts()


# Generated at 2022-06-22 09:12:59.690349
# Unit test for function parseOpts
def test_parseOpts():
    class FakeOptionParser:
        def __init__(self, list_opts, list_opts_str, additional_opts):
            self._list_opts = list_opts
            self._list_opts_str = list_opts_str
            self._additional_opts = additional_opts
        def add_option(self, *args, **kwargs):
            if args[0] in self._list_opts:
                del self._list_opts[args[0]]
                return
            if args[1] in self._list_opts_str:
                del self._list_opts_str[args[1]]
                return
            if args[0] in self._additional_opts:
                del self._additional_opts[args[0]]
                return

# Generated at 2022-06-22 09:13:11.211603
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from io import StringIO
    from youtube_dl.utils import encodeFilename

    parser, opts, args = _real_parseOpts(['-U', 'foobar'])
    assert opts.username == 'foobar'
    parser, opts, args = _real_parseOpts(['-u', 'foobar'])
    assert opts.username == 'foobar'
    parser, opts, args = _real_parseOpts(['--username', 'foobar'])
    assert opts.username == 'foobar'
    parser, opts, args = _real_parseOpts(['--username', 'foobar', '--usenetrc'])
    assert opts.username == 'foobar'
    assert opts.usenetrc

    # leaving parameters and seeing if there are

# Generated at 2022-06-22 09:13:14.428909
# Unit test for function parseOpts
def test_parseOpts():
    opts = _parseOpts([])
    assert opts.verbose == False
    opts = _parseOpts(['--verbose'])
    assert opts.verbose == True


# Generated at 2022-06-22 09:13:19.013777
# Unit test for function parseOpts
def test_parseOpts():
    arguments = ["--username", "val1", "--password", "val2", "http://www.youtube.com/watch?v=BaW_jenozKc"]
    (parser, opts, args) = parseOpts(arguments)
    assert opts.username == 'val1'
    assert opts.password == 'val2'


# Generated at 2022-06-22 09:13:30.470414
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.version import __version__

    usage = 'youtube-dl <options> url [url...]'
    version = __version__
    ua = 'youtube-dl/' + version
    parser, opts, args = parseOpts(['-v', 'http://example.org/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.version == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.get_format == False
    assert opts.proxy is None
    assert opts.extract_flat == False

# Generated at 2022-06-22 09:13:40.536742
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["-f 'bestvideo[height<=480]+bestaudio'", "http://youtu.be/BaW_jenozKc"])
    assert opts.format != None
    assert opts.format == "bestvideo[height<=480]+bestaudio"
    assert opts.usenetrc != None
    assert not opts.usenetrc
    assert opts.noplaylist != None
    assert not opts.noplaylist
    assert opts.username != None
    assert opts.password != None
    assert opts.twofactor != None
    assert opts.videopassword != None
    assert opts.ap_username != None
    assert opts.ap_password != None
    assert opts.ap_mso != None
    assert opt

# Generated at 2022-06-22 09:13:47.397804
# Unit test for function parseOpts
def test_parseOpts():
    if __name__ == '__main__':
        parser, opts, args = parseOpts()
        opts.config_location = '/etc/youtube-dl.conf'
        parser, opts, args = parseOpts()
    else:
        try:
            from six.moves import configparser
            config = configparser.RawConfigParser()
            config.read('/etc/youtube-dl.conf')
            for section in config.sections():
                for option in config.options(section):
                    opts = config.get(section, option)
        except Exception:
            pass

# parseOpts



# Generated at 2022-06-22 09:13:57.529769
# Unit test for function parseOpts

# Generated at 2022-06-22 09:14:24.061133
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert(isinstance(parser, optparse.OptionParser))
    assert(isinstance(opts, optparse.Values))
    assert(isinstance(args, list))

# Return the syntax for output template (a string)
# @param outtmpl: the template string
# @return: a list of strings

# Generated at 2022-06-22 09:14:30.645769
# Unit test for function parseOpts
def test_parseOpts():
    print("Running test for function parseOpts (in test mode)")
    parser, opts, args = parseOpts({})
    assert opts.usenetrc == True
    parser, opts, args = parseOpts({}, "--no-usenetrc")
    assert opts.usenetrc == False
    print("Pass")

# Generated at 2022-06-22 09:14:42.150982
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import gen_extractors

    def test_boolean_argument_with_override(args, override):
        conf = ['--%s' % a for a in args]
        _, opts, _ = parseOpts(override + conf)
        return opts

    assert test_boolean_argument_with_override(['ignore-errors'], []).ignoreerrors
    assert not test_boolean_argument_with_override(['no-ignore-errors'], []).ignoreerrors
    assert test_boolean_argument_with_override(['abort-on-error'], ['--no-ignore-errors']).ignoreerrors
    assert not test_boolean_argument_with_override(['no-abort-on-error'], []).ignoreerrors

    assert test_boolean_argument_with

# Generated at 2022-06-22 09:14:47.277617
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.extractor import gen_extractors
    gen_extractors()
    opts, args = parseOpts()
    # TODO: Do checks for opts with assert

# Generated at 2022-06-22 09:14:54.345926
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    if sys.version_info >= (3, 3):
        from unittest.mock import patch
    elif sys.version_info >= (3,):
        from mock import patch

    # Override --ignore-config and parse options
    parser, opts, args = parseOpts(['-U', '--ignore-config', '--no-check-certificate', '--username', 'foo', '--password', 'bar', '-i'])

    # Test option values
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.ignore_errors is True
    assert opts.no_check_certificate is True
    assert opts.proxy is None

    # Restore normal parsing of command line arguments
    parser, opts, args = parseOpts()

    #

# Generated at 2022-06-22 09:15:03.903360
# Unit test for function parseOpts
def test_parseOpts():
    assert('--get-title' not in [o for o in parseOpts()[0].option_list])
    assert('--get-title' in [o for o in parseOpts(['--get-title'])[0].option_list])
    assert('--get-title' not in [o for o in parseOpts(['--get-id'])[0].option_list])
    assert('--get-title' in [o for o in parseOpts(['--get-id', '--get-title'])[0].option_list])
    assert('--get-title' in [o for o in parseOpts(['--get-id', '--get-title', '--get-description'])[0].option_list])
# end: parseOpts


# Generated at 2022-06-22 09:15:10.980616
# Unit test for function parseOpts
def test_parseOpts():
    with tempfile.NamedTemporaryFile() as tf:
        with open(tf.name, 'w') as f:
            f.write('-i\n--username=foo\n')
        parser, opts, args = parseOpts(['--ignore-config', '--usenetrc', tf.name])
        # opts.username shall not be set
        assert opts.username is None
        # args shall contain all unparsed options
        assert args == ['-i', '--username=foo']

# Generated at 2022-06-22 09:15:23.123417
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = [sys.argv[0]]
    sys.argv += '-f 34'.split()
    assert parseOpts()[2] == ['34']
    sys.argv = [sys.argv[0]]
    sys.argv += '-f34'.split()
    assert parseOpts()[2] == ['34']
    sys.argv = [sys.argv[0]]
    sys.argv += '-f34'.split()
    assert parseOpts()[2] == ['34']
    sys.argv = [sys.argv[0]]
    sys.argv += '-f 34 -f 18'.split()
    assert parseOpts()[2] == ['34', '18']
    sys.argv = [sys.argv[0]]

# Generated at 2022-06-22 09:15:34.822139
# Unit test for function parseOpts
def test_parseOpts():

    from distutils.version import LooseVersion

    time1 = time.time()
    print('Testing parseOpts:')

    try:
        import json
    except ImportError:
        import simplejson as json

    # Unit test urlopen
    class urlopen_mock(object):
        def __init__(self, s):
            self._s = s
        def read(self):
            return '["%s"]' % self._s.replace('"', '\\"').replace('\\', '\\\\')

    options_file_contents = [
        '[youtube]',
        'username = foo',
        'password = bar',
        '[youtube:bar]',
        'username = foo2',
        'password = bar2'
        ]

    def _readOptions():
        class opts(object):
            pass
       

# Generated at 2022-06-22 09:15:44.288351
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(None)
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == False
    assert opts.listformats == False
    assert opts.usagestats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False

# Generated at 2022-06-22 09:16:37.565722
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-i', '--yes-playlist', '--dump-user-agent', '--min-sleep-interval', '10', '-v', '--ignore-errors', '--download-archive', 'a.txt', '--password', 'p', '--write-sub', '-k', '--username', 'u', 'https://www.youtube.com/playlist?list=PLL-MtQ9XzW837QgOFS1VoylpplxH7G8ni'])[1]
    assert opts.ignoreerrors
    assert opts.min_sleep_interval == 10.0
    assert opts.download_archive == 'a.txt'
    assert opts.password == 'p'
    assert opts.writesubtitles
    assert opts.keep

# Generated at 2022-06-22 09:16:45.988774
# Unit test for function parseOpts
def test_parseOpts():
    def test_parsing(self, args, expected):
        parser, opts, _ = parseOpts(overrideArguments=args)
        for key, val in expected.items():
            if isinstance(val, list):
                val.sort()
                assert getattr(opts, key) == val
            else:
                assert getattr(opts, key) == val

    if 'windows' in sys.platform:
        # Don't test --ffmpeg-location on Windows
        return

    def test_parse_file(self, filename):
        parser, opts, _ = parseOpts(overrideArguments=['--config-location=' + filename])
        assert opts.username == 'myuser'
        assert opts.password == 'mypass'
        assert opts.ap_username == 'myapuser'
       

# Generated at 2022-06-22 09:16:52.802991
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    test_argv = ["-x", "--artist", "--audio-format", "mp3", "--postprocessor-args", "--embed-metadata"]
    if sys.version_info < (3,):
        test_argv = [a.decode(preferredencoding(), 'replace') for a in test_argv]
    parser, opts, args = parseOpts(test_argv)
    assert opts.extractaudio
    assert opts.audioformat == 'mp3'
    assert opts.artist
    assert opts.postprocessor_args == '--embed-metadata'

# Parse options
parser, opts, args = parseOpts()


# Generated at 2022-06-22 09:17:04.267916
# Unit test for function parseOpts
def test_parseOpts():
#     overrideArguments = ['youtube-dl', '--version']
    overrideArguments = ['youtube-dl', '-h']
#     overrideArguments = ['youtube-dl', '-U']
#     overrideArguments = ['youtube-dl', '--dump-user-agent']
#     overrideArguments = ['youtube-dl', '--geo-bypass']
#     overrideArguments = ['youtube-dl', '--geo-bypass-country', 'DE']
#     overrideArguments = ['youtube-dl', '-4', '--geo-bypass']
#     overrideArguments = ['youtube-dl', '-6', '--geo-bypass']
#     overrideArguments = ['youtube-dl', '-v']
#     overrideArguments = ['youtube-dl', '-v', '-f', 'worst']


# Generated at 2022-06-22 09:17:14.128778
# Unit test for function parseOpts
def test_parseOpts():
    class DummyOptParser(object):
        def __init__(self):
            self.optiongroups = []
            self.disable_interspersed_args = False
            self.allow_interspersed_args = True
        def add_option_group(self, optgroup):
            self.optiongroups.append(optgroup)
        def parse_args(self, argv):
            return arglist_to_dict(argv)

    def optgroup_test(name, options, expected_defaults, expected_args):
        parser, opts, args = parseOpts(None, ['--' + o for o in options])
        assert opts == expected_defaults
        assert args == expected_args

        parser = DummyOptParser()
        optgroup = optparse.OptionGroup(parser, name)

# Generated at 2022-06-22 09:17:23.194504
# Unit test for function parseOpts
def test_parseOpts():
    for opts in [['--username', 'test'], ['-u', 'test'], ['--username=test']]:
        parser, actual, _ = parseOpts(opts)
        assert(actual.username == 'test'), actual
    for opts in [['--password', 'test'], ['-p', 'test'], ['--password=test']]:
        parser, actual, _ = parseOpts(opts)
        assert(actual.password == 'test'), actual
    for opts in [['--twofactor', 'test'], ['--twofactor=test']]:
        parser, actual, _ = parseOpts(opts)
        assert(actual.twofactor == 'test'), actual

# Generated at 2022-06-22 09:17:29.135176
# Unit test for function parseOpts
def test_parseOpts():
    from os.path import isfile, isdir, dirname, join, expanduser
    from os import remove
    from shutil import copyfile
    from sys import stderr# for logging

    # Check for the case where no config is present
    opts = parseOpts(['--get-url', '--get-title', '--get-description', '--get-filename', '--get-format', '-g', 'https://www.youtube.com/watch?v=BaW_jenozKc'])[1]

# Generated at 2022-06-22 09:17:41.430550
# Unit test for function parseOpts
def test_parseOpts():
    input1 = ["-f", "bestvideo+bestaudio/best"]
    input2 = []
    input3 = ["-f","bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4"]
    input4 = ["-f","bestvideo[ext=mp4][height<=480]+bestaudio[ext=m4a]/mp4"]
    input5 = ["-f","bestvideo[ext=mp4][height<=480]+bestaudio[ext=m4a]/best"]
    input6 = ["-f", "[ext=mp4]+bestaudio[ext=m4a]/best"]
    input7 = ["-f", "[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio"]

# Generated at 2022-06-22 09:17:44.708934
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert type(parser) is optparse.OptionParser
    assert type(opts) is optparse.Values
    assert type(args) is list

# parseOpts()



# Generated at 2022-06-22 09:17:53.102132
# Unit test for function parseOpts
def test_parseOpts():
    # Test if we can parse all the options without raising errors
    import tempfile
    htmlfile = tempfile.NamedTemporaryFile(delete=False)
    htmlfile.write(b'<html></html>')
    htmlfile.close()
    fmt_val = 'best'
    for opt in get_supported_options():
        if opt.dest is None:
            continue
        assert parseOpts([opt.get_opt_string()])

        if opt.type == 'string':
            assert parseOpts([opt.get_opt_string(), str(htmlfile.name)])
        elif opt.type == 'int':
            assert parseOpts([opt.get_opt_string(), '42'])

# Generated at 2022-06-22 09:19:44.162702
# Unit test for function parseOpts
def test_parseOpts():
    """
    Test youtube_dl.parseOpts
    """

    import os.path


# Generated at 2022-06-22 09:19:55.551616
# Unit test for function parseOpts
def test_parseOpts():
    try:
        from collections import namedtuple
    except ImportError:
        # For Python < 2.6
        from compat import namedtuple
    from types import ListType, TupleType
    import sys

    def parseOpts(parser, opts, args, overrideArguments = None):
        if overrideArguments is None:
            overrideArguments = []
            if sys.argv[1] == "--no-download":
                # Don't run a download with the unit test
                overrideArguments.append("--no-download")
        return namedtuple('parseOpts', 'parser, opts, args')(*_parseOpts(parser, opts, args, overrideArguments))

    opts = parseOpts('-i -u [user] -p [pass] URL [URL...]'.split())
    assert opts.op

# Generated at 2022-06-22 09:20:01.826060
# Unit test for function parseOpts

# Generated at 2022-06-22 09:20:11.106280
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    (parser, opts, args) = parseOpts()
    assert not os.path.exists(opts.outtmpl)
    assert opts.cachedir
    assert opts.default_search
    assert opts.format in ('bestvideo', 'best', 'bestaudio')
    assert os.path.exists(opts.cachedir)

    my_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    my_file.write('--video-format bestvideo\n')
    my_file.write('-o "%(uploader)s/%(title)s-%(id)s.%(ext)s"\n')
    my_file.write('--ignore-config\n')
    my_file.write('--ignore-config\n')

# Generated at 2022-06-22 09:20:20.792197
# Unit test for function parseOpts
def test_parseOpts():
    from .downloader.common import FileDownloader
    from .utils import prepend_extension
    from .extractor import gen_extractors


# Generated at 2022-06-22 09:20:24.537919
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts)
parseOpts()


# Generated at 2022-06-22 09:20:31.443178
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
