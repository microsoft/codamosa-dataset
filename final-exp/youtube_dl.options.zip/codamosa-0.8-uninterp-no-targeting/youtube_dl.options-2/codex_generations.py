

# Generated at 2022-06-22 09:10:52.443108
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(["-v","--flat-playlist"])
    assert opts.verbose
    assert opts.flat_playlist


# Generated at 2022-06-22 09:11:03.678037
# Unit test for function parseOpts
def test_parseOpts():
    from collections import namedtuple
    import pytest
    from .XAttrMetadata import XAttrMetadata
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .utils import DEFAULT_OUTTMPL, prepend_extension


# Generated at 2022-06-22 09:11:15.544725
# Unit test for function parseOpts
def test_parseOpts():
    argv = ['-f', '18/22/37/38', '-c', '-b', '--no-playlist', '--', 'BLM']
    (parser, opts, args) = parseOpts(argv)
    assert opts.usenetrc == True
    assert opts.password == None
    assert opts.username == None
    assert opts.videoformat == []
    assert opts.ratelimit == None
    assert opts.retries == 10
    assert opts.buffersize == None
    assert opts.noplaylist == True
    assert opts.age_limit == None
    assert opts.download_archive == None
    assert opts.include_ads == False
    assert opts.ignore_errors == False
    assert opts.dump_intermediate_pages == False


# Generated at 2022-06-22 09:11:27.756449
# Unit test for function parseOpts
def test_parseOpts():
    try:
        parseOpts(['-u', 'testuser', '-p', 'testpass', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    except SystemExit:
        raise
    except:
        raise

_filename_regex = r'[a-zA-Z0-9_-]+'
_filename_regex_simple = r'[a-zA-Z0-9]+'
_simplified_title_chars = r'[^%s]' % re.escape(string.punctuation.replace('-', ''))

# Generated at 2022-06-22 09:11:34.616475
# Unit test for function parseOpts

# Generated at 2022-06-22 09:11:37.171661
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod(option_parsing)
    print('ok')


# Generated at 2022-06-22 09:11:44.855332
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['--version'])
    assert opts.version

    opts, args = parseOpts(['--ignore-config', '-o', 'out.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.outtmpl == 'out.%(ext)s'

    opts, args = parseOpts(['--verbose', '--extract-audio', '--audio-format', 'mp3', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.extractaudio
    assert opts.audioformat == 'mp3'


# Generated at 2022-06-22 09:11:51.941280
# Unit test for function parseOpts
def test_parseOpts():
    opts, _ = parseOpts([
        '--username', 'foo', '--password', 'bar', '--download-archive',
        'archive.txt', '--cookies', 'cookies.txt', 'dummy'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.download_archive == 'archive.txt'
    assert opts.cookiefile == 'cookies.txt'


# Generated at 2022-06-22 09:11:53.772730
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['_unit_test_'])
    assert not opts.simulate



# Generated at 2022-06-22 09:12:00.013342
# Unit test for function parseOpts
def test_parseOpts():
    opts=parseOpts()
    url = "https://www.youtube.com/watch?v=1gGzh1x7nHg"
    #opts =['--output','/home/ganesh/YTPlayList/%(title)s-%(id)s.%(ext)s',url]
    #assert parseOpts(opts) == 0

# Generated at 2022-06-22 09:12:22.176482
# Unit test for function parseOpts
def test_parseOpts():
    # Test for --max-downloads negative integer
    _, opts, _ = parseOpts(['-r', '-i', '--max-downloads', '-1'])
    if opts.max_downloads != -1:
        print('parseOpts: Failed to parse --max-downloads -1')
        return False

    # Test for --max-downloads zero
    _, opts, _ = parseOpts(['-r', '-i', '--max-downloads', '0'])
    if opts.max_downloads != 0:
        print('parseOpts: Failed to parse --max-downloads 0')
        return False

    return True

# Generated at 2022-06-22 09:12:34.348275
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    assert opts.quiet is False
    assert opts.geturl is False
    assert opts.gettitle is False
    assert opts.getid is False
    assert opts.getthumburl is False
    assert opts.get_filename is False
    assert opts.get_format is False
    assert opts.proxy is None
    assert opts.listformats is False
    assert opts.age_limit is None
    assert opts.list_thumbnails is False
    assert opts.usenetrc is False
    assert opts.username is None
    assert opts.password is None
    assert opts.two_factor is None
    assert opts.videopassword is None
    assert opt

# Generated at 2022-06-22 09:12:45.100072
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-f', '18', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '18'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    opts, args = parseOpts(['-F', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert not opts.format
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    opts, args = parseOpts(['-f', '22', '-o', '%(id)s.%(ext)s', 'https://vimeo.com/138655100'])

# Generated at 2022-06-22 09:12:48.816880
# Unit test for function parseOpts
def test_parseOpts():
    url = 'http://www.youtube.com/watch#!v=BaW_jenozKc'
    custom_args = [url, '-v']
    parser, opts, _ = parseOpts(overrideArguments=custom_args)
    assert(opts.verbose)
# End of unit test


# Generated at 2022-06-22 09:12:52.654101
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    # Remove to see the test output, it's quite voluminous
    import logging; logging.disable(logging.CRITICAL)
    doctest.testmod()



# Generated at 2022-06-22 09:13:04.882969
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()


# Generated at 2022-06-22 09:13:16.607760
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: Since we're not calling youtube_dl.main(), we have to call prepare_args() here
    # and they don't share the same code path. Should be refactored to use only one place.
    args, _ = prepare_args()
    parser, opts, _ = parseOpts(args)

    # Test config files
    if use_limit_rate:
        assert opts.limit_rate == "10k"
        assert opts.verbose == True

    # Test short option
    assert opts.get_filename == True
    assert opts.format == '22'
    assert opts.proxy == 'http://10.10.10.10'
    assert opts.usenetrc == True
    assert opts.cookiefile == 'mycookie'

# Generated at 2022-06-22 09:13:22.935305
# Unit test for function parseOpts
def test_parseOpts():
    opts = options = {}
    parser, opts, args = parseOpts(['-f', '22/44/55'])
    assert opts.format == '22/44/55'
    assert 'format' not in options
    parser, opts, args = parseOpts(['--format=22/44/55'])
    assert opts.format == '22/44/55'
# }}}


# Generated at 2022-06-22 09:13:31.437014
# Unit test for function parseOpts
def test_parseOpts():
    opts = ['-i', '-u', 'myuser', '-p', 'mypass', '-F', 'myformat', 'https://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(opts)
    assert(opts.username == 'myuser')
    assert(opts.password == 'mypass')
    assert(opts.format == 'myformat')
    assert(args[0] == 'https://www.youtube.com/watch?v=BaW_jenozKc')



# Generated at 2022-06-22 09:13:40.608159
# Unit test for function parseOpts
def test_parseOpts():
    try:
        write_string = lambda x: sys.stdout.write(encodeArgument(x))
        encodeArgument = lambda s: s
        decodeArgument = lambda s: s
        compat_expanduser = lambda s: s
        preferredencoding = lambda: 'utf-8'
    except:
        def write_string(s):
            if str is not bytes:
                sys.stdout.buffer.write(s.encode('utf-8'))
            else:
                sys.stdout.write(s)
        def encodeArgument(s):
            if str is bytes:
                return s.encode(preferredencoding())
            return s
        def decodeArgument(s):
            if str is bytes:
                return s.decode(preferredencoding())
            return s

# Generated at 2022-06-22 09:14:18.083020
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert(type(opts) == type(ArgumentParser()))
    assert(type(args) == list)
# Update __main__ if run directly
if __name__ == '__main__':
    __main__ = sys.modules['__main__']
# Update youtube_dl.__main__ if run directly
if __name__ == '__main__':
    youtube_dl.__main__ = sys.modules['__main__']

# Generated at 2022-06-22 09:14:26.991552
# Unit test for function parseOpts
def test_parseOpts():
    # Testing with python 2.6
    if sys.version_info[:2] < (2, 7):
        return
    import unittest

    class ParseOptsTest(unittest.TestCase):
        def setUp(self):
            self.parser, self.opts, self.args = parseOpts(['-i'])

        def test_parser(self):
            self.assertIsInstance(self.parser, optparse.OptionParser)

        def test_parser_version(self):
            self.assertEqual(self.parser.version, __version__)

        def test_opts(self):
            self.assertIsInstance(self.opts, optparse.Values)

        def test_opts_values(self):
            self.assertTrue(self.opts.ignoreerrors)


# Generated at 2022-06-22 09:14:34.503778
# Unit test for function parseOpts
def test_parseOpts():
    from types import ModuleType
    testOpts = ['--username', 'foo', '--password', 'bar', '--verbose', 'foobar']

    old_sys = sys.modules['__main__']
    sys.modules['__main__'] = ModuleType('__main__')
    sys.modules['__main__'].__file__ = __file__
    try:
        res = parseOpts(testOpts)
    finally:
        sys.modules['__main__'] = old_sys

    assert res[1].username == 'foo'
    assert res[1].password == 'bar'
    assert res[1].verbose == True



# Generated at 2022-06-22 09:14:46.383028
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeArgument
    from .extractor import get_info_extractor
    from .compat import urlopen, PY2
    from .extractor.youtube import YoutubeIE
    print('Testing parseOpts')

    parser, opts, args = parseOpts(
        ['-U', '--username', 'user', '--password', 'pass', '--yes-playlist', '--min-sleep-interval', '0', '--max-sleep-interval', '0',
         'https://www.youtube.com/watch?v=BaW_jenozKc'])
    ie = get_info_extractor(YoutubeIE.ie_key())
    data = urlopen(ie._WORKAROUND_URL).read()
    if PY2:
        data = data.decode('utf-8')


# Generated at 2022-06-22 09:14:54.390480
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    sys.argv = ["/usr/bin/youtube-dl","-v"]
    (parser, opts, args) = parseOpts()
    assert opts.verbose == True
    sys.argv = ["/usr/bin/youtube-dl","-V"]
    (parser, opts, args) = parseOpts()
    assert opts.verbose == False

# }}}

# {{{ cache

# Generated at 2022-06-22 09:14:59.504863
# Unit test for function parseOpts
def test_parseOpts():
    # Ensure we can parse options from a config file
    open_url_mock = Mock()
    downloader_mock = Mock()
    YoutubeDL.get_suitable_downloader = lambda x, y: downloader_mock
    YoutubeDL.urlopen = open_url_mock
    open_url_mock.return_value.read.return_value = b'--no-progress'
    parser, opts, args = parseOpts([])
    assert opts.noprogress is True
    # Ensure command-line options override those in a config file
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose is True
    assert opts.noprogress is False
    # Ensure we can parse config file options while ignoring command-line options
    parser, opts,

# Generated at 2022-06-22 09:15:10.879459
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parsing_options_impl(cmd_line_conf, expected_opts):
        opts = {}
        parser, actual, args = parseOpts(cmd_line_conf)
        assert args == []
        assert actual.__dict__ == expected_opts
        # Check that opts are set in the parser too
        for o in parser.option_list:
            if o.dest is not None:
                opts[o.dest] = getattr(actual, o.dest)
        assert opts == expected_opts


# Generated at 2022-06-22 09:15:13.748739
# Unit test for function parseOpts
def test_parseOpts():
    from run_tests import parseOpts
    opts, _ = parseOpts(['--get-url', 'https://www.youtube.com/watch?v=BaW_jenozKc', '-q'])
    assert(opts.geturl == True)


# Generated at 2022-06-22 09:15:19.438278
# Unit test for function parseOpts
def test_parseOpts():
    # Called with no arguments, it should not fail and return the parsed options
    # which is a tuple containing the parser, the options and the arguments
    assert len(parseOpts()) == 3
    # Called with an invalid option, it should raise an exception
    raised = False
    try:
        parseOpts(['-a'])
    except (OptionValueError, optparse.OptionValueError, TypeError):
        raised = True
    assert raised

# Helper function to retrieve the real version (1.2.3, 1.2.3.4)

# Generated at 2022-06-22 09:15:31.224977
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.nooverwrites
    assert opts.ratelimit == '0'
    parser, opts, args = parseOpts(['-r', '5m'])
    assert opts.nooverwrites
    assert opts.ratelimit == '300'
    parser, opts, args = parseOpts(['-r', 'asdf'])
    assert opts.ratelimit == '0'
    parser, opts, args = parseOpts(['--no-overwrites', '-r', '5m'])
    assert opts.nooverwrites
    assert opts.ratelimit == '300'

# Generated at 2022-06-22 09:16:10.050182
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert(isinstance(parser, optparse.OptionParser))
    # optparse.Option.__dict__ is not writable and cannot be tested
    assert(isinstance(opts, optparse.Values))
    assert(isinstance(args, list))

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-22 09:16:20.535635
# Unit test for function parseOpts

# Generated at 2022-06-22 09:16:26.022981
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    opts_, args_ = parseOpts(['-i'])
    assert(opts.ignoreerrors is True)
    assert(opts_.ignoreerrors is True)


if __name__ == '__main__':
    sys.exit(main())

# Generated at 2022-06-22 09:16:30.969888
# Unit test for function parseOpts
def test_parseOpts():
    import pprint
    pp = pprint.PrettyPrinter(indent=2)
    pp.pprint(parseOpts())
    return parseOpts()



# Generated at 2022-06-22 09:16:41.090106
# Unit test for function parseOpts

# Generated at 2022-06-22 09:16:47.508189
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    opts = []
    val = StringIO()
    def _print(*args):
        val.write(' '.join(args))
    print = _print
    parseOpts(opts, ['--no-check-certificate', '-i', '-r', '--no-playlist'])
    assert val.getvalue() == '-i -r --no-playlist'


# Generated at 2022-06-22 09:16:54.032824
# Unit test for function parseOpts
def test_parseOpts():

    parser, opts, args = parseOpts()

    opts_dict = vars(opts)
    if 'cachedir' in opts_dict and opts_dict['cachedir'] is not None:
        opts_dict['cachedir'] = '<SENSITIVE>'
    if 'username' in opts_dict and opts_dict['username'] is not None:
        opts_dict['username'] = '<SENSITIVE>'
    if 'password' in opts_dict:
        opts_dict['password'] = '<SENSITIVE>'
    if 'twofactor' in opts_dict:
        opts_dict['twofactor'] = '<SENSITIVE>'
    if 'videopassword' in opts_dict:
        opts_dict

# Generated at 2022-06-22 09:16:55.728294
# Unit test for function parseOpts
def test_parseOpts():
    _parseOpts()


# Generated at 2022-06-22 09:17:05.781885
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv as sys_argv

# Generated at 2022-06-22 09:17:15.500126
# Unit test for function parseOpts
def test_parseOpts():
    args = '-f 22/18/17/160 -o test.%(ext)s.mp4 http://www.youtube.com/watch?v=videoid'
    opts = parseOpts(shlex.split(args))[1]
    assert opts.format == '22/18/17/160'
    assert opts.outtmpl == 'test.%(ext)s.mp4'
    assert opts.usenetrc
    assert not opts.password
    assert opts.username is None

    args = '-u username -p password -f 22/18/17/160 -o test.%(ext)s.mp4 http://www.youtube.com/watch?v=videoid'
    opts = parseOpts(shlex.split(args))[1]
    assert not opts.us

# Generated at 2022-06-22 09:18:37.498116
# Unit test for function parseOpts
def test_parseOpts():
    from ydl.utils import urlopen

    class MockUrllib(object):
        def __init__(self, cookie_jar):
            self.cookie_jar = cookie_jar

        def build_opener(self, *handlers):
            return MockOpener(self.cookie_jar)

    class MockOpener(object):
        def __init__(self, cookie_jar):
            self.cookie_jar = cookie_jar

        def open(self, *args, **kwargs):
            resp = urlopen(*args, **kwargs)
            self.cookie_jar.extract_cookies(resp, MockRequest())
            return resp

    class MockRequest(object):
        def __init__(self):
            self.type = 'https'
            self.host = 'youtube.com'
            self.selector = '/'

# Generated at 2022-06-22 09:18:46.150669
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([])[1].verbose == False
    assert parseOpts(['-v'])[1].verbose == True
    assert parseOpts(['-i'])[1].ignoreerrors == True
    assert parseOpts(['--no-warnings'])[1].noprogress == True

    assert parseOpts([])[1].logtostderr == False
    assert parseOpts(['-v'])[1].logtostderr == True
    assert parseOpts(['--no-progress'])[1].logtostderr == False

    assert parseOpts([])[1].usenetrc == True
    assert parseOpts(['-n'])[1].usenetrc == False

# Generated at 2022-06-22 09:18:57.757385
# Unit test for function parseOpts
def test_parseOpts():
    import youtube_dl.YoutubeDL
    parser, opts, args = parseOpts(['--username', 'user', '--password', 'pass@word', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert youtube_dl.YoutubeDL(opts).params['username'] == 'user'
    assert youtube_dl.YoutubeDL(opts).params['password'] == 'pass@word'


# Generated at 2022-06-22 09:19:08.987285
# Unit test for function parseOpts
def test_parseOpts():
    import doctest

# Generated at 2022-06-22 09:19:19.797978
# Unit test for function parseOpts
def test_parseOpts():
    assert(parseOpts(['-h'])[2] == [])
    assert(parseOpts(['-i'])[2] == [])
    assert(parseOpts(['-i', 'www.youtube.com'])[2] == [])
    assert(parseOpts(['-U', 'youtube-dl'])[2] == [])
    assert(parseOpts(['-U', 'youtube-dl', 'www.youtube.com'])[2] == [])
    assert(parseOpts(['-U', 'youtube-dl', '-i', 'www.youtube.com'])[2] == [])
    assert(parseOpts(['-v', 'www.youtube.com'])[2] == ['www.youtube.com'])

# Generated at 2022-06-22 09:19:28.975774
# Unit test for function parseOpts
def test_parseOpts():
    def parse(arg_str, eq=False):
        assert _parseOpts(arg_str)[1] == opts
        if eq:
            assert arg_str == _format_args(arg_str)
        else:
            assert arg_str == _format_args(arg_str) or arg_str == _format_args('--flat-playlist ' + arg_str)

    opts = _parseOpts('abc')[1]
    parse('abc', True)
    parse('--no-warnings')
    parse('-v')
    parse('--get-id')
    parse('--get-filename')
    parse('--get-url')
    parse('--get-title')
    parse('--get-thumbnail')
    parse('--get-description')
    parse('--get-duration')

# Generated at 2022-06-22 09:19:30.218355
# Unit test for function parseOpts
def test_parseOpts():
    print(parseOpts(['-v']))


# Generated at 2022-06-22 09:19:41.430177
# Unit test for function parseOpts
def test_parseOpts():
    def test_parseOpts_exception(args, exception, message):
        try:
            parseOpts(args)
        except exception as err:
            assert message == str(err)
        else:
            assert False

    test_parseOpts_exception([], optparse.OptionError, 'no such option: -h')
    test_parseOpts_exception([-h], optparse.OptionError, 'no such option: -h')
    test_parseOpts_exception(['--config-location'], optparse.OptionError, 'option --config-location: expected one argument')
    test_parseOpts_exception(['--extract-audio'], optparse.OptionError, '--audio-format and --extract-audio are mutually exclusive, use only one of them')

# Generated at 2022-06-22 09:19:53.172762
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    from sys import argv as sys_argv
    former_argv = sys_argv[:]


# Generated at 2022-06-22 09:19:57.474566
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts()
    assert len(args) >= 1, "At least a url must be provided"
    assert args, "video url must be provided"
    assert not (opts.username is not None and opts.password is None), "You must specify both username and password"