

# Generated at 2022-06-22 09:11:14.066621
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(overrideArguments=[])
    assert opts.confirm_ambiguous is False

    parser, opts, args = parseOpts(overrideArguments=['-h'])
    assert opts.nooverwrites is False
    assert opts.quiet is False
    assert opts.verbose is False
    assert opts.dump_json is False
    assert opts.print_trailer is False
    assert opts.print_json is False
    assert opts.print_pages is False
    assert opts.youtube_include_dash_manifest is False
    assert opts.dump_user_agent is False
    assert opts.no_warnings is False
    assert opts.simulate is False
    assert opts.skip_download is False

# Generated at 2022-06-22 09:11:21.982401
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    class FakeStdin(StringIO):
        def close(self):
            pass

    stdin = sys.stdin
    # Test with empty arguments
    sys.stdin = FakeStdin('abc')
    sys.argv[1:] = ['--batch-file', '-']
    parser, opts, args = parseOpts()
    assert opts.batchfile == '-'
    # Test with non-empty arguments
    sys.stdin = FakeStdin('abc')
    sys.argv[1:] = ['--batch-file', '-', '-v', '--playlist-items', '1', '2']
    parser, opts, args = parseOpts()
    assert opts.batchfile == '-'
    assert opts.verbose
    assert opts.playliststart == 1

# Generated at 2022-06-22 09:11:34.178503
# Unit test for function parseOpts
def test_parseOpts():
    try:
        import nose.tools
        assert 'parseOpts' in globals(), 'parseOpts() function not found!'
    except ImportError:
        pass

    # Test default argument
    parser, opts, args = parseOpts()
    for option in parser.option_list:
        if option.dest:
            if option.default != NO_DEFAULT:
                nose.tools.assert_equal(
                    option.default, getattr(opts, option.dest),
                    'Option %s has unexpected default value.' % option)

    # Test option overriding
    custom_opts = ['--no-check-certificate', '--console-title', '--min-filesize', '1']
    parser, opts, args = parseOpts(overrideArguments=custom_opts)

# Generated at 2022-06-22 09:11:44.809505
# Unit test for function parseOpts
def test_parseOpts():
    common.load_extensions(common.get_extensions())

# Generated at 2022-06-22 09:11:56.876290
# Unit test for function parseOpts
def test_parseOpts():
    # This testcase is designed to test "parseOpts" function.
    # It tests all the function in the function

    # initialize the output and input variables
    output = []

    # define a class to replace the "optparse.OptionParser" class
    # this is used to test the function "parser.error(msg)"
    class MyOptionParser(object):
        def __init__(self, prog, conflict_handler, description, version, option_list, add_help_option):
            pass
        def add_option_group(self, *args, **kargs):
            pass
        def error(self, msg):
            output.append(msg)

    # use the defined class to replace the original class
    # this is used to test the function "parser.error(msg)"
    global optparse, optparse_orig
    optparse_orig

# Generated at 2022-06-22 09:12:06.450778
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import mkstemp
    from os import remove

    # Setting test values
    # Youtube URL
    testvideo1 = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    # Youtube playlist
    testvideo2 = 'https://www.youtube.com/watch?v=BaW_jenozKc&index=2&list=PLWz5rJ2EKKc9CBxr3BVjPTPoDPLdPIFCE'
    # Youtube user URL
    testvideo3 = 'https://www.youtube.com/user/TheLinuxFoundation'
    # Youtube age restricted URL
    testvideo4 = 'https://www.youtube.com/watch?v=8ptDd_wvY_c'
    # Dailymotion URL
    test

# Generated at 2022-06-22 09:12:18.696366
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    import shutil
    parser, opts, args = parseOpts(["-h"])
    assert opts.help
    parser, opts, args = parseOpts(["--version"])
    assert opts.version
    parser, opts, args = parseOpts(["--ignore-config", "--verbose", "-o", "test.mp4", "bestvideo+bestaudio", "http://youtube.com/watch?v=BaW_jenozKc"])
    assert opts.verbose

    d = tempfile.mkdtemp()

# Generated at 2022-06-22 09:12:20.895931
# Unit test for function parseOpts
def test_parseOpts():
    # TODO : Write unit test for function parseOpts
    pass


# Generated at 2022-06-22 09:12:33.591390
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.outtmpl == '%(id)s'
    assert opts.format == None
    assert not opts.usenetrc
    parser, opts, args = parseOpts(['-f', 'best'])
    assert opts.outtmpl == '%(id)s'
    assert opts.format == 'best'
    parser, opts, args = parseOpts(['-f', 'best', '-o', '%(title)s-%(id)s.%(ext)s'])
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.format == 'best'

# Generated at 2022-06-22 09:12:44.529027
# Unit test for function parseOpts
def test_parseOpts():
    from .extractor import gen_extractor_classes
    extractors = list(gen_extractor_classes())
    for e in extractors:
        if e.IE_NAME == 'test':
            class TestIE(e):
                def _real_extract(self, url):
                    return {
                        'url': url,
                        'id': 'test',
                        'title': 'test',
                        'ext': 'mp4',
                    }
            TestIE.__name__ = 'TestIE'
            break
    else:
        raise ValueError('Test extractor not found')
    test_ie = TestIE()

    opts, args = parseOpts(['-v', 'http://example.com/'])
    assert opts.verbose == True
    assert args == ['http://example.com/']

    opts,

# Generated at 2022-06-22 09:13:12.539442
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['youtube-dl', '-x', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.extractaudio == True
    parser, opts, args = parseOpts(['youtube-dl', '--extract-audio', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.extractaudio == True
    parser, opts, args = parseOpts(['youtube-dl', '-f', '22/18', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '22/18'

# Generated at 2022-06-22 09:13:22.644290
# Unit test for function parseOpts
def test_parseOpts():
    from collections import namedtuple
    Opt = namedtuple('Opt', ['general', 'auth', 'video_format', 'geo_blocked_countries', 'format'])
    opts = Opt(general=['url'], auth=[], video_format=[], geo_blocked_countries=[], format=['best'])
    
    parser, opts, args = parseOpts(opts.general+['--username', 'aaa', '--password', 'bbb', 
                                                 '--format', 'worst', '--geo-bypass-country', 'US', '--geo-bypass'])
    assert opts.username == 'aaa'
    assert opts.password == 'bbb'
    assert opts.format == 'worst'
    assert opts.geo_bypass_country == ['US']


# Generated at 2022-06-22 09:13:33.847050
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parseOpts(args):
        logger.info('test_args=' + str(args))
        parser, opts, _ = parseOpts(args)
        logger.info(opts)
        return parser, opts

    parser, opts = _test_parseOpts(['--default-search', 'dummy'])
    assert opts.default_search == 'dummy'
    _test_parseOpts(['--default-search', 'dummy', '--cookie', 'dummy'])
    _test_parseOpts(['--default-search', 'dummy', '--ignore-config'])
    _test_parseOpts(['--default-search', 'dummy', '--config-location', '/tmp/dummy'])

# Generated at 2022-06-22 09:13:39.736968
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'username'
    assert opts.password == 'password'
    assert opts.usenetrc == True
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.verbose == True
    assert opts.ratelimit == '10k'
    assert opts.retries == 10
    assert opts.buffersize == '1024'
    assert opts.nooverwrites == True
    assert opts.format == 'best'
    assert opts.listformats == True
    assert opts.listsubtitles == True
    assert opts.list_thumbnails == True
    assert opts.writesubtitles == True
    assert opts.write

# Generated at 2022-06-22 09:13:50.037719
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts()
    _, opts, _ = parseOpts(['-U', 'foo'])
    assert opts.username == 'foo'
    _, opts, _ = parseOpts(['--username', 'foo'])
    assert opts.username == 'foo'
    _, opts, _ = parseOpts(['-P', 'foo'])
    assert opts.password == 'foo'
    _, opts, _ = parseOpts(['--password', 'foo'])
    assert opts.password == 'foo'
    _, opts, _ = parseOpts(['--max-downloads', '1'])
    assert opts.max_downloads == 1

# Generated at 2022-06-22 09:13:55.648385
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'hunter2'
    assert '--username' in argv
    assert '--password' not in argv
    assert '--usenetrc' in argv
    print('[debug] Options:', repr(_hide_login_info(argv)))



# Generated at 2022-06-22 09:14:05.373348
# Unit test for function parseOpts
def test_parseOpts():
    from nose.tools import assert_raises, assert_equal
    from tempfile import NamedTemporaryFile

    opts_in = ['--username', 'foo', '--password', 'bar', '--get-title',
        '--get-url', '--output', '%(id)s.%(ext)s', '--no-verbose']
    parser, opts, args = parseOpts(opts_in)
    assert_equal(opts.username, 'foo')
    assert_equal(opts.password, 'bar')
    assert_equal(opts.geturl, True)
    assert_equal(opts.gettitle, True)
    assert_equal(opts.usetitle, False)
    assert_equal(opts.outtmpl, '%(id)s.%(ext)s')


# Generated at 2022-06-22 09:14:16.050200
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-o', 'test', '-f', '251'])[1]
    assert opts.outtmpl == u'test'
    assert opts.format == '251'
    opts = parseOpts(['--no-playlist', '-f', 'best[ext=mp4]'])[1]
    assert opts.extractor_desc == ['generic']
    assert opts.format == 'best[ext=mp4]'
    opts = parseOpts(['--format', 'best[ext=mp4]'])[1]
    assert opts.extractor_desc == ['youtube']
    assert opts.format == 'best[ext=mp4]'

# Generated at 2022-06-22 09:14:18.463656
# Unit test for function parseOpts
def test_parseOpts():
    with captured_output() as (out, _):
        parser, opts, args = parseOpts()
        print(parser.format_help())



# Generated at 2022-06-22 09:14:24.339994
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-x', '-c', '--audio-quality', '0', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.extractaudio
    assert opts.continue_dl
    assert opts.audioquality == '0'
    assert 'http://www.youtube.com/watch?v=BaW_jenozKc' in args


# Generated at 2022-06-22 09:15:04.515408
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, _ = parseOpts([])

    assert opts.get('outtmpl') == '%(id)s.%(ext)s'

    parser, opts, _ = parseOpts(['-o', 'xxx.%(ext)s'])
    assert opts.get('outtmpl') == 'xxx.%(ext)s'

    parser, opts, _ = parseOpts(['-o', 'xxx.%(ext)s', '-o', 'yyy.%(ext)s'])
    assert opts.get('outtmpl') == 'yyy.%(ext)s'

    parser, opts, _ = parseOpts(['-o', 'xxx.%(ext)s', '-a', 'a'])

# Generated at 2022-06-22 09:15:06.645799
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.verbose

# Generated at 2022-06-22 09:15:14.998152
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument

    def _check_decode_str(s, codec='utf-8', esc=None, apn=None):
        """
        Return True if s is decoded properly
        """
        if type(s) is str:
            return True
        if esc and type(s) is bytes and s.startswith(b'\x1b'):
            return True
        if apn and type(s) is bytes and s.startswith(b'\x00'):
            return True
        return False

    def _check_urlopen(url, data=None, ret=None):
        """
        Return True if url is a valid URL
        """
        if type(url) is str and url.startswith('http'):
            return True


# Generated at 2022-06-22 09:15:28.324354
# Unit test for function parseOpts
def test_parseOpts():
    import doctest

    # Encode/decode unicode/bytes so as to be able to convert them to strings
    # in Python 2 and 3.
    # NOTE: doctest.OutputChecker.check_output takes bytes in Python 2 and
    # unicode in Python 3
    def enc(x):
        if isinstance(x, type('')):
            return x.encode('utf-8')
        return x.decode('utf-8').encode('utf-8')

    def dec(x):
        if isinstance(x, type(u'')):
            return x
        return x.decode('utf-8')


# Generated at 2022-06-22 09:15:34.022626
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.ratelimit == '5k'
    parser, opts, args = parseOpts(['--rate-limit', '10000k'])
    assert opts.ratelimit == '10000k'
    parser, opts, args = parseOpts(['--config-location', 'foobar'])
    assert opts.config_location == 'foobar'
    parser, opts, args = parseOpts(['--config-location', '~/bar'])
    assert opts.config_location == expanduser('~/bar')
    assert opts.ignoreconfig == False
    parser, opts, args = parseOpts(['--ignore-config'])
    assert opts.ignoreconfig == True

# Generated at 2022-06-22 09:15:40.557185
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(overrideArguments = ['--simulate', '--verbose', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.simulate
    assert opts.verbose
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Retrieve options
opts = None

# Generated at 2022-06-22 09:15:46.632018
# Unit test for function parseOpts
def test_parseOpts():
    from pytube.compat import str
    parser, opts, args = parseArgs()
    opts = vars(opts)
    assert type(opts['format']) == str
    assert opts['verbose'] == False
    assert opts['no_warnings'] == False
    assert opts['simulate'] == False
    assert opts['skip_download'] == False
    assert opts['format'] == ''
    assert opts['listformats'] == False
    assert opts['ratelimit'] == ''
    assert opts['retries'] == 10
    assert opts['buffersize'] == '1024'
    assert opts['noresizebuffer'] == False
    assert opts['playliststart'] == 1
    assert opts['playlistend'] == 0
    assert opts['playlistreverse'] == False

# Generated at 2022-06-22 09:15:56.200175
# Unit test for function parseOpts
def test_parseOpts():
    # Set the working directory
    os.chdir(WORKING_PATH)

    # Create a new instance of class FakeYDL

    # This is a mandatory parameter
    fake_ydl = FakeYDL()

    # This is an optional parameter
    fake_ydl.params = {'logger': YoutubeDLHandler()}

    # This is an optional parameter
    fake_ydl.add_default_info_extractors()

    # This is a mandatory parameter
    fake_ydl.add_info_extractor(YoutubeIE(fake_ydl))
    fake_ydl.add_info_extractor(YoutubePlaylistIE(fake_ydl))

    # This is an optional parameter
    fake_ydl.add_info_extractor(YoutubeUserIE(fake_ydl))
    fake_ydl.add_info

# Generated at 2022-06-22 09:16:08.131634
# Unit test for function parseOpts

# Generated at 2022-06-22 09:16:19.658303
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from sys import executable, argv
    from locale import getpreferredencoding
    from os import path

    test_conf = path.join(path.dirname(argv[0]), 'youtube-dl_test_conf.txt')

    # Test 1: Check that the options are correctly parsed
    opts_string = '-f best -F -i https://www.youtube.com/watch?v=BaW_jenozKc'
    arguments = opts_string.split()
    parser, opts, args = parseOpts(arguments)
    assert opts.format == 'best'
    assert opts.listformats
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']
    assert opts.verbose == 0



# Generated at 2022-06-22 09:17:20.260471
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: This test will not test the help output nor the shell completion
    arguments = ['-o', "HELLO", 'http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(arguments)
    return opts.outtmpl == "HELLO"


# Generated at 2022-06-22 09:17:25.979020
# Unit test for function parseOpts
def test_parseOpts():
    """ Run unit test for function parseOpts() """
    from optparse import OptionValueError

    def run_parseOpts(override_arguments, expected_error_substring, expected_error_lineno, test_desc):
        try:
            parser, opts, args = parseOpts(override_arguments)
        except OptionValueError as err:
            assert expected_error_substring in str(err)
            # print('Expected error: %s' % expected_error_substring)
            return
        except TypeError as err:
            if 'option -o: invalid integer value' in str(err):
                assert expected_error_substring == 'invalid integer value'
                # print('Expected error: %s' % expected_error_substring)
                return

# Generated at 2022-06-22 09:17:30.916409
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert isinstance(parser, optparse.OptionParser)
    assert opts.verbose
    assert opts.version
    assert opts.help
    assert opts.SIMULATE
    assert opts.def_search
    assert not opts.dump_user_agent
    assert not opts.dump_interfaces
    assert opts.dump_json
    assert opts.outtmpl
    assert opts.outtmpl_na_placeholder
    assert opts.autonumber_size
    assert opts.autonumber_start
    assert opts.restrictfilenames
    assert opts.usetitle
    assert opts.nooverwrites
    assert opts.continue_dl
    assert opts.nopart
    assert opts.up

# Generated at 2022-06-22 09:17:35.873865
# Unit test for function parseOpts
def test_parseOpts():
    if __name__ == '__main__':
        _useCustomConfig()
    parser, opts, args = parseOpts()
    if __name__ == '__main__':
        _restoreStandardConfig()
    return parser, opts, args

# Generated at 2022-06-22 09:17:42.698687
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv as sys_argv
    sys_argv[1:1] = ['--extract-audio', '-o', '/home/NAME/FOLDER/%(stitle)s-%(id)s-%(ext)s']
    parser, opts, args = parseOpts()
    assert opts.extractaudio == True
    assert opts.outtmpl == '/home/NAME/FOLDER/%(stitle)s-%(id)s-%(ext)s'

# Generated at 2022-06-22 09:17:51.504967
# Unit test for function parseOpts
def test_parseOpts():  # pylint: disable=unused-variable
    import sys
    parser, opts, args = parseOpts(['--ignore-config', '--no-check-certificate', '--username', 'test', '-p', 'pw', 'http://youtube.com/watch?v=BaW_jenozKc'])
    assert opts.nocheckcertificate
    assert opts.username == 'test'
    assert opts.password == 'pw'
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert len(args) == 1


# Generated at 2022-06-22 09:17:55.153418
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    return doctest.testmod(
        parseOpts,
        optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS)



# Generated at 2022-06-22 09:17:58.447624
# Unit test for function parseOpts
def test_parseOpts():
    # Just testing evaluation order of if statements
    # (inside and outside parseOpts)
    assert 0, parseOpts()


# Generated at 2022-06-22 09:17:59.879814
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-x'])[1].extractaudio


# Generated at 2022-06-22 09:18:04.569214
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['--no-warnings', '-o', 'video.%(ext)s', '--sleep-interval', '2', '--max-sleep-interval', '5', 'x'])
    assert isinstance(opts, optparse.Values)
    assert 'x' in args
