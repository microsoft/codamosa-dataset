

# Generated at 2022-06-22 09:10:57.479777
# Unit test for function parseOpts
def test_parseOpts():
    # Create a temporary config file so that the
    # test can start from a clean configuration
    config_file = NamedTemporaryFile(delete=False)
    with config_file as cf:
        cf.write(b'--cache-dir=/tmp')
    try:
        # Check that the configuration file is properly read
        _, opts, _ = parseOpts(overrideArguments=['--config-location', config_file.name])
        assert opts.cachedir == '/tmp'
        # Check that the command line arguments override the configuration file
        _, opts, _ = parseOpts(overrideArguments=['--config-location', config_file.name, '--no-cache-dir'])
        assert opts.cachedir == False
    finally:
        os.remove(config_file.name)


# Generated at 2022-06-22 09:11:08.859411
# Unit test for function parseOpts

# Generated at 2022-06-22 09:11:19.796369
# Unit test for function parseOpts
def test_parseOpts():
    from .getInfo import _availableParams
    all_params = _availableParams
    def _test(args):
        info = getParams(args)
        if info != {}:
            assert set(all_params) != set(info.keys()), "All params are present"
            assert set(all_params) > set(info.keys()), "Some params are missing"
    _test(['-F', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    _test(['-F', '-f', '34/35/18', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    _test(['-F', 'http://www.youtube.com/watch#!v=BaW_jenozKc'])
    _

# Generated at 2022-06-22 09:11:29.492903
# Unit test for function parseOpts
def test_parseOpts():
    import tempfile
    _, configfile = tempfile.mkstemp(prefix='youtube-dl-config-')
    try:
        # Write to config file
        with open(configfile, 'w') as outf:
            outf.write('-v\n')
            outf.write('--min-filesize 1M\n')
        parser, opts, _ = parseOpts(overrideArguments=[
            '--max-filesize', '2M',
            '--ignore-config',
            '--config-location', configfile])
        assert opts.verbose == 1
        assert opts.max_filesize == '2M'
        assert opts.min_filesize == '1M'
    finally:
        os.remove(configfile)


# Generated at 2022-06-22 09:11:36.016367
# Unit test for function parseOpts

# Generated at 2022-06-22 09:11:48.493842
# Unit test for function parseOpts
def test_parseOpts():
    # Write out a config file
    fd, conf = tempfile.mkstemp(prefix='youtube-dl-config-')
    os.write(
        fd,
        ('--username=foo\n'
         '--password=bar\n'
         ).encode('utf-8'))
    os.close(fd)
    # Set default environment variable
    os.environ['XDG_CONFIG_HOME'] = tempfile.gettempdir()

    try:
        parser, opts, args = parseOpts(['--config-location=' + conf, 'https://example.com', '--verbose'])
        assert opts.username == 'foo'
        assert opts.password == 'bar'
        assert args == ['https://example.com']
    finally:
        os.unlink(conf)
   

# Generated at 2022-06-22 09:11:56.858741
# Unit test for function parseOpts
def test_parseOpts():
    from yt_dl.extractor.common import InfoExtractor
    from yt_dl.utils import prepend_extension

    opts, args = parseOpts([])
    assert opts.get('ignoreerrors', False) == False
    assert opts.get('format', None) == None
    assert opts.get('usenetrc', False) == False
    assert opts.get('prefer_usenetrc', False) == False
    assert opts.prefer_ffmpeg == True
    assert opts.get('proxy', None) == None
    assert opts.get('outtmpl', None) == None
    assert opts.get('writethumbnail', False) == False
    assert opts.postprocessor_args == None


# Generated at 2022-06-22 09:12:03.058435
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([]).args == []
    assert parseOpts(['-f', 'mp4', 'pl', '--ignore-config', 'http://youtu.be/BaW_jenozKc'])\
        .args == ['pl', 'http://youtu.be/BaW_jenozKc']

_FILE_FORMAT_PREFERENCE = ['flv', 'webm', 'mp4', '3gp']



# Generated at 2022-06-22 09:12:06.962874
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose


# Generated at 2022-06-22 09:12:14.857394
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['--default-search', 'auto', '--format', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '--ignore-config', '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])


## Abstracted Option Parser.

# Generated at 2022-06-22 09:12:42.460400
# Unit test for function parseOpts
def test_parseOpts():
    # Test simple parse
    opts, args = parseOpts()

    # Test case when override arguments is passed
    opts_override, args = parseOpts(['-f', 'best'])
    assert opts_override.format == 'best'

    # Test case when override arguments is passed but it is empty
    opts_override_empty, args = parseOpts([])
    assert opts_override_empty.format == 'best'


# -- Helper functions for downloading --

# Writes a string to output.
# If encoding is not None, it must be a string that indicates the encoding.
# If not, the default system encoding will be used.
# If on_tty is True, no encoding conversion is applied even if encoding != None.

# Generated at 2022-06-22 09:12:51.160063
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-i', '-v', '-a', 'unittest.log', '-o', '/tmp/unit.test'])
    assert opts.verbose

    opts, args = parseOpts(['-x', '-o', '%(stitle)s/%(uploader)s/%(autonumber)s.%(uploader)s-%(title)s-%(id)s-%(format_id)s-%(ext)s', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.extractaudio

# Generated at 2022-06-22 09:12:59.460966
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts()[1]
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_list == False
    assert opts.videopassword == None
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forceduration == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.force

# Generated at 2022-06-22 09:13:11.062636
# Unit test for function parseOpts
def test_parseOpts():
    class Options(object):
        pass
    opts = Options()
    opts.username = opts.password = opts.twofactor = opts.videopassword = None
    opts.usenetrc = False
    compat_setattr(opts, 'username', None)
    compat_setattr(opts, 'password', None)
    compat_setattr(opts, 'twofactor', None)
    compat_setattr(opts, 'videopassword', None)
    compat_setattr(opts, 'usenetrc', False)
    parser, opts, args = parseOpts(args=['--username', 'user', '--password', 'pass'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
test_parseOpts()

# Generated at 2022-06-22 09:13:20.086187
# Unit test for function parseOpts
def test_parseOpts():
    from .utils import encodeFilename

    parser, opts, args = parseOpts(['-f', '37/22/18', 'test'])
    assert opts.format == '37/22/18'
    assert args == ['test']

    # Issue 272: https://github.com/rg3/youtube-dl/issues/272
    # In Python 2.x, optparse converts the parameters to str
    # when it reads the configuration file
    argv = [a.encode('utf-8') for a in [
        '--username', u'test user', '--password', u'p@ss word', 'test']]

    parser, opts, args = parseOpts(argv)
    assert opts.username == u'test user'
    assert opts.password == u'p@ss word'

    parser, opt

# Generated at 2022-06-22 09:13:22.596470
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-i', '-F', 'http://example.com/'])[1]
    assert opts.simulate
    assert opts.listformats

# Generated at 2022-06-22 09:13:33.803730
# Unit test for function parseOpts
def test_parseOpts():
    from types import ModuleType
    m = ModuleType('__main__')
    m.__dict__.update({
        '__name__': '__main__',
        '__doc__': None,
        '__file__': sys.argv[0],
    })
    sys.modules['__main__'] = m
    for args in (['-U', 'P', 'u', 'p'], sys.argv[1:]):
        parser, opts, _args = parseOpts(args)
        assert opts.usenetrc is True
        assert opts.username == 'u'
        assert opts.password == 'p'
        assert opts.playlistend is None
        assert opts.playliststart is None
        assert opts.playlistreversed is False
        assert opts.playlistrandom

# Generated at 2022-06-22 09:13:41.691933
# Unit test for function parseOpts
def test_parseOpts():
    """
    Unit test for function parseOpts
    """
    from youtube_dl.utils import prepend_extension
    from tempfile import mkstemp
    from subprocess import Popen, PIPE, check_output
    from os import unlink


    opts = None
    retcode = None
    args = None


# Generated at 2022-06-22 09:13:48.176383
# Unit test for function parseOpts
def test_parseOpts():
    import_simplejson()
    args = ['youtube-dl', '--version']
    parser, opts, args = parseOpts(args)
    assert not opts.usenetrc
    assert not opts.password
    assert not opts.ap_password
    assert opts.outtmpl == '%(id)s'
    assert opts.verbose == 0



# Generated at 2022-06-22 09:13:58.432248
# Unit test for function parseOpts
def test_parseOpts():
    # Test to check if proxy settings are read correctly
    #
    # Setup: Fake the environment variables
    # Test: Pass empty arguments to parseOpts(), check the proxy settings
    # Cleanup: N/A
    import os
    import shutil
    import tempfile
    from youtube_dl.utils import _hide_login_info
    def _readUserConf(userConfPath = None):
        """
        Locate and read the user configuration file and return the parsed data.
        """
        if userConfPath is None:
            userConfPath = os.path.join(os.path.expanduser(os.path.expandvars('%APPDATA%')), 'youtube-dl', 'config')

# Generated at 2022-06-22 09:14:26.940054
# Unit test for function parseOpts
def test_parseOpts():
    def test_parse_opts_1():
        parser, opts, _ = parseOpts(['-U', 'testuser', '-P', 'testpass', '-i', '--get-url', 'www.youtube.com/watch?v=BaW_jenozKc'])
        assert opts.username == 'testuser'
        assert opts.password == 'testpass'
        assert opts.simulate
        assert opts.geturl
        assert not opts.gettitle

    def test_parse_opts_2():
        parser, opts, _ = parseOpts(['-g', '-e', 'http://www.youtube.com/watch?v=_HSylqgVYQI'])
        assert opts.geturl
        assert opts.extracturl
        assert not opts

# Generated at 2022-06-22 09:14:35.675615
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-o', '%(title)s.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert len(args) == 1
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'

    parser, opts, args = parseOpts([
        '-o', '%(title)s.%(ext)s',
        '--username', 'user', '--password', 'pass',
        'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'user'
    assert opt

# Generated at 2022-06-22 09:14:40.716061
# Unit test for function parseOpts
def test_parseOpts():
    # Test for https://github.com/rg3/youtube-dl/issues/3880
    parser, opts, args = parseOpts(['--output', '%%(title)%%'])
    assert opts.outtmpl == '%(title)%'



# Generated at 2022-06-22 09:14:42.272905
# Unit test for function parseOpts
def test_parseOpts():
    # Need to learn how to test this function
    pass


# Generated at 2022-06-22 09:14:52.772055
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-U', 'Unittest'])[1].username == 'Unittest'
    assert parseOpts(['-2'])[1].extract_flat is True
    assert parseOpts(['-4'])[1].noplaylist is True
    assert parseOpts(['-i'])[1].ignoreerrors is True
    assert parseOpts(['-r', '10'])[1].ratelimit == '10'
    assert parseOpts(['-R'])[1].retries == 10
    assert parseOpts(['-s'])[1].simulate is True
    assert parseOpts(['-g'])[1].geo_verification_proxy == '127.0.0.1:8118'

# Generated at 2022-06-22 09:14:54.656361
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()



# Generated at 2022-06-22 09:14:56.504151
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()


# Generated at 2022-06-22 09:15:05.131995
# Unit test for function parseOpts
def test_parseOpts():
    expected_option_group_titles = ['General Options', 'Network Options', 'Geo Restriction Options', 'Video Selection Options', 'Download Options', 'Filesystem Options', 'Verbosity / Simulation Options', 'Workarounds', 'Video Format Options', 'Subtitle Options', 'Authentication Options', 'Adobe Pass Options', 'Post-processing Options']
    parser, opts, args = parseOpts()
    option_groups = parser.option_groups
    assert len(option_groups) == len(expected_option_group_titles)
    for option_group in option_groups:
        assert option_group.title in expected_option_group_titles

# Generated at 2022-06-22 09:15:08.319415
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(None)
    assert parser is not None
    assert opts is not None
    assert args is not None
    assert vars(opts) is not None

# Generated at 2022-06-22 09:15:19.293004
# Unit test for function parseOpts
def test_parseOpts():
    def check(opts, attr, value):
        global __Py_TrueValue, __Py_ZeroValue # pylint: disable=W0612
        attr_value = getattr(opts, attr)
        if value is __Py_TrueValue:
            assert attr_value is True, 'Expected True for %s but got %s (%s)' % (attr, attr_value, type(attr_value))
        elif value is __Py_ZeroValue:
            assert attr_value is False, 'Expected False for %s but got %s (%s)' % (attr, attr_value, type(attr_value))
        else:
            assert attr_value == value, 'Expected %s for %s but got %s' % (value, attr, attr_value)


# Generated at 2022-06-22 09:16:08.894238
# Unit test for function parseOpts
def test_parseOpts():
    def test(inArr=None, expectedArgs=[], expectedOpts=None):
        parser, opts, args = parseOpts(inArr)
        assert expectedArgs == args, (expectedArgs, args)
        assert expectedOpts == vars(opts), (expectedOpts, vars(opts))

    test(['-f', '37', 'http://www.youtube.com/watch?v=BaW_jenozKc'],
         ['http://www.youtube.com/watch?v=BaW_jenozKc'],
         {'format': '37', 'forceurl': False, 'forcetitle': False})


# Generated at 2022-06-22 09:16:20.160319
# Unit test for function parseOpts
def test_parseOpts():
    # testing function parseOpts()
    # -------------------------
    # function parseOpts() mainly tests the function _youtube_dl.readOptions(),
    # which is used to get configuration from youtube-dl.conf
    # Here, we test if the configurations in youtube-dl.conf
    # can be effectively loaded
    #
    # The configurations are in the following format
    # format
    # key1 = value1
    # in the test file test_config.txt
    # -------------------------
    youtube_dl.utils.std_headers = {} # reset head
    # -------------------------
    # tests if read_config can read configuration from a file
    test_config = 'test_config.txt'
    test_config_content = read_config(test_config)
    assert isinstance(test_config_content, dict)


    # tests

# Generated at 2022-06-22 09:16:29.642306
# Unit test for function parseOpts
def test_parseOpts():
    def parseOpts(overrideArguments):
        parser, opts, args = parseOpts_(overrideArguments)
        return parser, opts.__dict__, args

    # get opts
    parser, opts, args = parseOpts(['-v'])

    assert(opts['verbose'] == 1)
    assert(opts['playliststart'] == 1)
    assert(opts['playlistend'] == None)
    assert('youtube.com' in opts['extractor_descriptions']['youtube']['IE_NAME'])

    # get opts
    parser, opts, args = parseOpts(['--verbose'])

    assert(opts['verbose'] == True)

# Generated at 2022-06-22 09:16:31.866806
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert(opts.verbose==False)

# Generated at 2022-06-22 09:16:41.752968
# Unit test for function parseOpts
def test_parseOpts():
    global write_string

    def dummy_write(string):
        print(string)

    write_string = dummy_write

    opts, args = parseOpts(['--skip-download', '-v', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert(opts.skip_download)
    assert(opts.verbose > 0)
    assert(len(args) == 1)

    opts, args = parseOpts(['--format', 'bestvideo[height<=?720]+bestaudio/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert(opts.format == 'bestvideo[height<=?720]+bestaudio/best')
    assert(len(args) == 1)

    opts, args

# Generated at 2022-06-22 09:16:42.261363
# Unit test for function parseOpts
def test_parseOpts():
    return



# Generated at 2022-06-22 09:16:53.827432
# Unit test for function parseOpts
def test_parseOpts():
    """ test for parseOpts"""
    # Check if the output file exists
    if not os.path.exists(os.getcwd() + '/test_parseOpts.txt'):
        open(os.getcwd() + '/test_parseOpts.txt', 'w+')
    # Parse the options using the parseOpts
    a, b, c = parseOpts(['-o', 'test_parseOpts.txt', 'https://www.youtube.com/watch?v=LqzqTqTqJjc'])
    # Check if -o has been parsed
    assert b.outtmpl == os.getcwd() + '/test_parseOpts.txt'
    # Check if there is a video with the given URL

# Generated at 2022-06-22 09:16:56.485748
# Unit test for function parseOpts
def test_parseOpts():
    raise NotImplementedError()
#------------------------------------------------------------------------------
# Option value functions
#------------------------------------------------------------------------------

# Generated at 2022-06-22 09:17:06.120620
# Unit test for function parseOpts
def test_parseOpts():
    # _______ test empty argument list __________
    _, opts, args = parseOpts([])
    assert opts.usenetrc is False
    assert opts.username is None
    assert opts.password is None
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.no_warnings is False
    assert opts.v is False
    assert opts.dump_user_agent is False
    assert opts.dump_interceptor is False
    assert opts.dump_json is False
    assert opts.listformats is False
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.format == []
    assert opts.matchtitle is None
    assert opts.rejecttitle is None

# Generated at 2022-06-22 09:17:15.832528
# Unit test for function parseOpts
def test_parseOpts():
    """Test for function parseOpts"""
    test_cases = [
        ('youtube-dl -U', ['youtube-dl', '-U']),
        ('youtube-dl -U --', []),
        ('youtube-dl --version --username PASSWORD URL', ['youtube-dl', '--version', '--username', 'PASSWORD', 'URL']),
        ('youtube-dl --ignore-config --', []),
        ('youtube-dl --config-location /etc/', ['youtube-dl', '--config-location', '/etc/']),
        ('youtube-dl --config-location /etc/youtube-dl.conf --', []),
    ]
    for test_str, expected_argv in test_cases:
        write_string('TEST CASE: ' + test_str + '\n')
        sys_argv = test_str

# Generated at 2022-06-22 09:18:51.427407
# Unit test for function parseOpts
def test_parseOpts():
    from collections import namedtuple
    Opts = namedtuple('Opts', ['verbose', 'quiet', 'write_pages'])
    opts = Opts(verbose=True, quiet=True, write_pages=True)
    parser, opts, args = parseOpts([])
    assert opts.verbose == True
    assert opts.quiet == True
    assert opts.write_pages == True


# Generated at 2022-06-22 09:19:03.505072
# Unit test for function parseOpts
def test_parseOpts():
    from types import ModuleType
    from collections import namedtuple
    from itertools import count


# Generated at 2022-06-22 09:19:12.378191
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['--username', 'user', '--password', 'pass', 'http://www.youtube.com'])[1].username == 'user'
    assert parseOpts(['--username', 'user', '--password', 'pass', 'http://www.youtube.com'])[1].password == 'pass'
    assert parseOpts(['--usenetrc'])[1].usenetrc is True
    assert parseOpts(['--username', 'user', '--password', 'pass', 'http://www.youtube.com'])[1].usenetrc is False
    assert parseOpts(['--usenetrc', '--username', 'user', '--password', 'pass', 'http://www.youtube.com'])[1].usenetrc is True

# Generated at 2022-06-22 09:19:22.504561
# Unit test for function parseOpts
def test_parseOpts():
    from collections import namedtuple
    from sys import argv
    from pprint import pprint
    from platform import system
    from os.path import exists, isdir, dirname
    import re

    class _namedtuple_with_default(namedtuple('Options', ['__getitem__'])):
        def __init__(self, *args, **kwargs):
            super(_namedtuple_with_default, self).__init__()
            self.defaults = kwargs

        def __getitem__(self, key):
            if key in self._fields:
                return super(_namedtuple_with_default, self).__getitem__(key)
            return self.defaults[key]


# Generated at 2022-06-22 09:19:31.130937
# Unit test for function parseOpts
def test_parseOpts():
    # Test --verbose
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    assert opts.quiet == False
    assert opts.no_warnings == False
    # Test --quiet
    parser, opts, args = parseOpts(['--quiet'])
    assert opts.verbose == False
    assert opts.quiet
    assert opts.no_warnings
    # Test -v
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    # Test --no-warnings
    parser, opts, args = parseOpts(['--no-warnings'])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings
    #

# Generated at 2022-06-22 09:19:41.897718
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-u', 'user', '-p', 'passwd', '--get-url', 'http://www.youtube.com/']
                   )[2] == ['http://www.youtube.com/']
    assert parseOpts(['-u', 'user', '-p', 'passwd', 'youtube.com'])[2] == ['youtube.com']
    assert parseOpts(['-u', 'user', '-p', 'passwd', '--get-title', 'http://www.youtube.com/'])[2] == ['http://www.youtube.com/']
    assert parseOpts(['http://www.youtube.com/watch?v=BaW_jenozKc'])[2] == ['http://www.youtube.com/watch?v=BaW_jenozKc']



# Generated at 2022-06-22 09:19:53.622146
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import NamedTemporaryFile
    parser, opts, args = parseOpts([])
    assert not (opts.username or opts.password or opts.twofactor or opts.videopassword)
    # Issue #2482
    assert not opts.proxy
    # Issue #2461
    assert opts.match_filter_from_file is None
    # Issue #2450
    assert opts.ffmpeg_location is None
    parser, opts, args = parseOpts(['--proxy', 'http://example.com', '-u', 'login', '-psecret', '--twofactor', 'code', '-vpass', 'passwd'])
    assert opts.proxy == 'http://example.com'
    assert opts.username == 'login'

# Generated at 2022-06-22 09:20:01.056409
# Unit test for function parseOpts
def test_parseOpts():
    if __name__ == '__main__':
        import unittest

        class TestParseOpts(unittest.TestCase):
            def test_combination(self):
                with tempfile.NamedTemporaryFile(mode='wt', delete=False) as temp_user_conf:
                    temp_user_conf.write('''\
--verbose
--ignore-config
--proxy 127.0.0.1
-k
username=myuser
--username myuser
password=mypass
--password mypass
''')

# Generated at 2022-06-22 09:20:08.104891
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = ['youtube-dl']
    parser, opts, args = parseOpts(overrideArguments = ['--version'])
    assert opts.version == True
    assert opts.verbose == False
    sys.argv = ['youtube-dl']
    parser, opts, args = parseOpts(overrideArguments = ['--verbose'])
    assert opts.version == False
    assert opts.verbose == True

# The main function; the entry point of this program
# Gets a list of URLs from the command line arguments and calls
# the download function for each URL.

# Generated at 2022-06-22 09:20:10.352488
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts([])[:2] == (parseCL(), parseOpts()[1])
# }}}

