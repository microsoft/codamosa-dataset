

# Generated at 2022-06-22 09:10:51.272593
# Unit test for function parseOpts
def test_parseOpts():
    assert (parseOpts(overrideArguments=['-h'])[2] == 0)
 

# Generated at 2022-06-22 09:11:02.027752
# Unit test for function parseOpts
def test_parseOpts():
    def _assert_error(args, msg):
        with pytest.raises(SystemExit) as exit:
            parseOpts(args)
        assert exit.value.code == 2
        assert msg in exit.value.msg

    if sys.platform != 'win32':
        _assert_error(['-ic'], '--ignore-config')

    # Input/output files
    opts, args = parseOpts(['-o', '<outfile>', 'https://www.example.com/watch?v=videoid'])
    assert opts.outtmpl == '<outfile>'
    assert len(args) == 1

    opts, args = parseOpts(['https://www.example.com/watch?v=videoid'])
    assert opts.nooverwrites
    assert opts.out

# Generated at 2022-06-22 09:11:10.755429
# Unit test for function parseOpts
def test_parseOpts():
    for args in (
            ['-h'], ['--dump-user-agent'], ['--list-extractors'], ['-U', 'dummy']):
        write_stdout(args, check_error=None)
        with ReleaseCaller() as caller:
            caller.call(_main, args)
        stdout, _, _ = caller.result
        assert 'usage:' in stdout.decode('utf-8', 'replace')

    # Test hidden config
    for opt, set_val in (('proxy', 'foo'), ('noplaylist', True), ('verbose', True), ('usenetrc', True)):
        config_file = os.path.join(os.path.dirname(__file__), 'test', 'config')
        if os.path.exists(config_file):
            os.un

# Generated at 2022-06-22 09:11:23.016641
# Unit test for function parseOpts
def test_parseOpts():
    '''
        test_parseOpts
        Test parseOpts function.
    '''
    getpass.getpass = lambda x: 'password'
    youtube_dl.utils.std_headers = {
        'User-Agent': 'test-user-agent'
    }
    description = [
        'youtube-dl is a small command-line program to download videos from YouTube.com',
        'and a few more sites.',
        '',
        'youtube-dl is a python program that has been bundled using the py2exe library.',
    ]

# Generated at 2022-06-22 09:11:26.260184
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert isinstance(opts, optparse.Values)
    assert isinstance(args, list)



# Generated at 2022-06-22 09:11:36.925639
# Unit test for function parseOpts
def test_parseOpts():
    # parsing empty arguments
    parser, opts, args = parseOpts([])
    assert opts.simulate is False
    assert opts.format is None
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'

    # parsing some --option arguments

# Generated at 2022-06-22 09:11:44.708949
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(overrideArguments=["-f", "22"])[2] == ["-f", "22"]
    assert parseOpts(overrideArguments=["--username", "cenk"])[2] == ["--username", "cenk"]


# FIXME these options should be removed
# they are either unused or can be found in the opts variable
params = ['usenetrc', 'password', 'quiet', 'geturl', 'ratelimit',
          'nooverwrites', 'retries', 'continuedl', 'noprogress',
          'playliststart', 'playlistend', 'matchtitle', 'rejecttitle',
          'max_downloads', 'prefer_insecure', 'hls_prefer_native']

_http_headers = {}



# Generated at 2022-06-22 09:11:51.360717
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(["-v", "-o", "spam.%(ext)s", "http://youtube.com/watch?v=BaW_jenozKc"])
    assert opts.verbose
    assert opts.outtmpl == "spam.%(ext)s"
    assert args == ["http://youtube.com/watch?v=BaW_jenozKc"]


# Generated at 2022-06-22 09:11:58.765717
# Unit test for function parseOpts
def test_parseOpts():
    """Unit test for parseOpts"""
    print('running test_parseOpts')
    # check if youtube-dl version required is greater than current version
    def _testVer(opts, version):
        """Unit test for version checker"""
        if opts.verbose_test:
            print('running _testVer')
        return parseOpts(['--verbose', '--ignore-config', '-U', version])

    parser, opts, _ = _testVer(None, '0.0.0')
    assert opts.update_self
    parser, opts, _ = _testVer(None, __version__)
    assert not opts.update_self

    # check for python 2/3
    if sys.version_info[0] == 2:
        import StringIO
        out = StringIO.StringIO()

# Generated at 2022-06-22 09:12:05.009266
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(['-U', 'Mozilla', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1].user_agent == 'Mozilla'
    assert parseOpts([
        'http://www.youtube.com/watch?v=BaW_jenozKc', '--max-downloads', '10'])[1].max_downloads == 10
    assert parseOpts([
        'http://www.youtube.com/watch?v=BaW_jenozKc', '--min-filesize', '10k'])[1].min_filesize == 10240
    assert parseOpts([
        'http://www.youtube.com/watch?v=BaW_jenozKc', '--max-filesize', '10M'])[1].max_files

# Generated at 2022-06-22 09:12:24.196538
# Unit test for function parseOpts
def test_parseOpts():
  print('parseOpts')
  _, opts, args = parseOpts(None)
  # assert opts.playliststart is not None
  # assert opts.playlistend is not None


# Generated at 2022-06-22 09:12:36.330484
# Unit test for function parseOpts
def test_parseOpts():
    def t(args, conf_args=None, extra_defaults=None, expected_opts=None, expected_args=None):
        parser, opts, args = parseOpts(args, conf_args=conf_args, extra_defaults=extra_defaults)
        assert vars(opts) == (expected_opts or {})
        assert args == (expected_args or [])

    t([])
    t(['-v'], expected_opts={'verbose': True})
    t(['--ignore-config'], expected_opts={'ignore_config': True})
    t(['--no-check-certificate'], expected_opts={'nocheckcertificate': True})

    t(['--format=best'], expected_opts={'format': 'best'})

# Generated at 2022-06-22 09:12:46.433832
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import os
    import tempfile
    # An example of writing to stdout. The configuration file will do the same.
    def write_string(s):
        sys.stdout.write(s)

    _, configfile = tempfile.mkstemp(suffix='.conf')
    with open(configfile, 'w') as f:
        f.write('-f best')
    try:
        parser, opts, args = parseOpts(['-f', 'worst', '-o', '%(title)s', '--config-location', configfile, '--verbose', 'youtube.com'])
    finally:
        os.unlink(configfile)
    assert opts.outtmpl == '%(title)s'
    assert opts.format == 'worst'

# Generated at 2022-06-22 09:12:54.332107
# Unit test for function parseOpts
def test_parseOpts():
    try:
        opts, args = parseOpts(['--usenetrc', '--username', 'un', '--password', 'pwd', '--verbose'])
        assert(opts.usenetrc == True)
        assert(opts.username == 'un')
        assert(opts.password == 'pwd')
        assert(opts.verbose == True)
    except:
        return False
    return True


# Generated at 2022-06-22 09:13:06.665533
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([
        '--username', 'user',
        '--password', 'pass',
        '-F', 'abcd',
        '-f', 'best',
        '--format', 'worst',
        '--max-filesize', '300000000',
        '--match-title', 'b.*',
        '--reject-title', 'a.*',
        '-o', 'abcd',
        '--output', 'edfg',
        '--no-playlist'
    ])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.format == 'abcd,best,worst'
    assert opts.max_filesize == 300000000
    assert opts.matchtitle == ['b.*']
    assert opts.re

# Generated at 2022-06-22 09:13:10.351841
# Unit test for function parseOpts
def test_parseOpts():
    args = ['--verbose']
    parser, opts, args = parseOpts(args)
    assert opts.verbose

# Generated at 2022-06-22 09:13:19.270468
# Unit test for function parseOpts

# Generated at 2022-06-22 09:13:25.893111
# Unit test for function parseOpts
def test_parseOpts():
    sys.argv = ['-i', '-u', 'abc', '--', 'hello', '--verbose']
    assert parseOpts()[2] == ['hello', '--verbose']
    sys.argv = ['-i', '-u', 'abc', '--', 'hello', '--', '--verbose']
    assert parseOpts()[2] == ['hello', '--verbose']
    sys.argv = ['-i', '-u', 'abc', '--', 'hello', '--verbose', '--', '--yes']
    assert parseOpts()[2] == ['hello', '--verbose', '--yes']
    sys.argv = ['youtube-dl', '-u', 'abc', '--', 'hello', 'world']

# Generated at 2022-06-22 09:13:34.755508
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    argv = ['--format', 'bestvideo+bestaudio', '--all-subs', '--write-auto-sub', '--sub-lang', 'en,es', '-o', '/tmp/%(id)s-%(title)s.%(ext)s', 'https://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts()
    assert(opts.format == 'bestvideo+bestaudio')
    assert(opts.writesubtitles == True)
    assert(opts.writeautomaticsub == True)
    assert(opts.allsubtitles == True)
    assert(opts.subtitleslangs == ['en', 'es'])

# Generated at 2022-06-22 09:13:40.545444
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import os
    import youtube_dl.YoutubeDL
    sys.argv = ['youtube-dl','-x','--audio-format','mp3','-ciw']
    (parser, opts, args) = parseOpts()
    assert opts.extractaudio is True
    assert opts.audioformat == 'mp3'
    assert opts.retries == 10
    assert opts.continuedl is True
    assert opts.username == None
    assert opts.password == None
    assert opts.writeannotations is False
    assert opts.writethumbnail is False
    assert opts.nopart is False
    assert opts.proxy == None
    assert opts.subtitleslangs == None
    assert opts.cookiefile == None

# Generated at 2022-06-22 09:14:15.218778
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert len(args) == 0
    assert opts.verbose == True
    assert opts.default_search == 'auto'
    assert opts.sleep_interval == None
    assert opts.continuedl == False
# Unit test
#test_parseOpts() #...
###############################################################################
from random import choice


# Generated at 2022-06-22 09:14:17.833216
# Unit test for function parseOpts
def test_parseOpts():
    test_parseOpts.__test__ = False
    parser, opts, args = parseOpts()
# parser, opts, args = parseOpts()
# print(parser, opts, args)


# Generated at 2022-06-22 09:14:21.346738
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestaudio/best', opts.format


# Generated at 2022-06-22 09:14:32.655613
# Unit test for function parseOpts
def test_parseOpts():
    """Test the parseOpts function."""
    from youtube_dl.version import __version__
    from youtube_dl.utils import DateRange
    
    # Empty config
    parser, opts, args = parseOpts([])

    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.videopassword is None
    assert opts.ap_mso is None
    assert opts.ap_username is None
    assert opts.ap_password is None

    assert opts.usenetrc is False
    assert opts.quiet is False
    assert opts.no_warnings is False
    assert opts.verbose is False
    assert opts.dump_user_agent is False

    assert opts.simulate is False

# Generated at 2022-06-22 09:14:34.787286
# Unit test for function parseOpts
def test_parseOpts():
    """simulate all possible input of parseOpts, and verify the output"""
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 09:14:46.581653
# Unit test for function parseOpts

# Generated at 2022-06-22 09:14:59.658583
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    import sys

    out_buf = StringIO()
    sys.stdout = out_buf
    sys.stderr = out_buf


# Generated at 2022-06-22 09:15:06.712680
# Unit test for function parseOpts
def test_parseOpts():    
    parser, opts, args = parseOpts([
        '-i', '--get-title', '--get-id',
        '--username', 'foo', '--password', 'bar',
        '--video-password', 'moo',
        'https://www.youtube.com/watch?v=BaW_jenozKc'
    ])
    assert opts.geturl
    assert not opts.gettitle
    assert opts.getid
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.video_password == 'moo'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts([])
    assert not opts.geturl
    assert opt

# Generated at 2022-06-22 09:15:15.034276
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    if "-t" in argv:
        parser, opts, args = parseOpts(["-t", "--verbose", "-o", "%(title)s-%(id)s.%(ext)s", "--restrict-filenames", "video_id"])
        if opts.outtmpl != '%(title)s-%(id)s.%(ext)s':
            raise Exception('parseOpts failed')
        if opts.verbose != True:
            raise Exception('parseOpts failed')
        if opts.restrictfilenames != True:
            raise Exception('parseOpts failed')
        if parser.get_usage() != None:
            raise Exception('parseOpts failed')
        parser, opts, args = parseOpts(["-h"])


# Generated at 2022-06-22 09:15:17.825790
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass

# Functions

# Generated at 2022-06-22 09:15:55.446348
# Unit test for function parseOpts
def test_parseOpts():
    print('Testing parseOpts')
    print('parseOpts accepts no arguments')
    import sys, os
    def _(x): return x

# Generated at 2022-06-22 09:16:00.838435
# Unit test for function parseOpts
def test_parseOpts():
    def _test_parse_opts(argv, expected, expected_args=[]):
        default_opts, parser, opts, args = parseOpts(argv)
        assert vars(opts) == expected
        assert args == expected_args, (args, expected_args)
    _test_parse_opts([], {})
    _test_parse_opts(['--username', 'foo', '--password', 'bar'], {'username': 'foo', 'password': 'bar'})
    _test_parse_opts(['--username=foo', '--password=bar'], {'username': 'foo', 'password': 'bar'})
    _test_parse_opts(['-4'], {'forceipv4': True})

# Generated at 2022-06-22 09:16:09.388605
# Unit test for function parseOpts
def test_parseOpts():
    class MockParser(object):
        def __init__(self, general, video_format, auth, postproc):
            self.general = general
            self.video_format = video_format
            self.auth = auth
            self.postproc = postproc

        def add_option_group(self, optiongroup):
            if optiongroup.title == 'General Options':
                for option in optiongroup.option_list:
                    self.general.append(option)
            elif optiongroup.title == 'Video Format Options':
                for option in optiongroup.option_list:
                    self.video_format.append(option)
            elif optiongroup.title == 'Authentication Options':
                for option in optiongroup.option_list:
                    self.auth.append(option)

# Generated at 2022-06-22 09:16:20.327528
# Unit test for function parseOpts
def test_parseOpts():
    # Test with all options
    for _, opts, _ in parseOpts([]):
        assert opts.verbose
        assert opts.quiet
        assert opts.no_warnings
        assert opts.simulate
        assert opts.skip_download
        assert opts.format == 'bestvideo+bestaudio'
        assert opts.listformats
        assert opts.list_thumbnails
        assert opts.match_filter == '!is_live'
        assert opts.no_playlist
        assert opts.playlistend == 1
        assert opts.playlistreverse
        assert opts.playliststart == 1
        assert opts.logger_descriptions
        assert opts.logger_file
        assert opts.nooverwrites
        assert opts.retries == 10
       

# Generated at 2022-06-22 09:16:28.025645
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import NamedTemporaryFile

    try:
        with NamedTemporaryFile('w') as conf_file:
            conf_file.write('--username user\n')
            conf_file.flush()
            _, opts, _ = parseOpts(overrideArguments=['-Uuser', '--config-location', conf_file.name])
            assert opts.username == 'user'
    except Exception as e:
        print('\ntest_parseOpts failed:\n%s' % e)
        return False
    return True


# Generated at 2022-06-22 09:16:38.146538
# Unit test for function parseOpts
def test_parseOpts():
    from xml.dom import minidom

    class Options():
        def __init__(self, items):
            self.__dict__.update(items)

    class FakeOptionParser(object):
        def __init__(self, items):
            self.__dict__.update(items)

            self.option_groups = []
            self.option_list = []

            self.filesystem = Options({
                'dest': 'filesystem',
                'help': 'Filesystem Options',
            })
            self.general = Options({
                'dest': 'general',
                'help': 'General Options',
            })
            self.network = Options({
                'dest': 'network',
                'help': 'Network Options',
            })

# Generated at 2022-06-22 09:16:47.112053
# Unit test for function parseOpts
def test_parseOpts():
    def _test(overrideArguments, expectedOptions):
        parsed_options, _args = parseOpts(overrideArguments)
        for key, value in expectedOptions.items():
            assert getattr(parsed_options, key) == value
    _test(
        overrideArguments=['--version'],
        expectedOptions={'print_version': True})
    _test(
        overrideArguments=['--help'],
        expectedOptions={'print_help': True})
    _test(
        overrideArguments=['--verbose'],
        expectedOptions={'verbose': True})

# Generated at 2022-06-22 09:16:53.846977
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--get-url', '--no-check-certificate', '--youtube-skip-dash-manifest', '--proxy', '10.10.1.10:3128', '-U', 'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20150101 Firefox/47.0 (Chrome)', '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])

# Generated at 2022-06-22 09:16:55.275311
# Unit test for function parseOpts
def test_parseOpts():
    pass


# Generated at 2022-06-22 09:17:05.533261
# Unit test for function parseOpts
def test_parseOpts():
    args = ['--ignore-config', '-v', '-i', 'http://youtu.be/BaW_jenozKc']
    parser, opts, args = parseOpts(overrideArguments=args)
    assert opts.verbose
    assert not opts.noplaylist
    assert opts.ignoreerrors
    assert not opts.forceurl
    assert args == ['http://youtu.be/BaW_jenozKc']
    args = ['--max-downloads=5', '-v', '--rm-cache-dir', '-i', 'http://youtu.be/BaW_jenozKc']
    parser, opts, args = parseOpts(overrideArguments=args)
    assert args == ['http://youtu.be/BaW_jenozKc']
    assert opts.verb

# Generated at 2022-06-22 09:18:11.882927
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert(isinstance(parser, optparse.OptionParser) == True)
    assert(isinstance(args, list) == True)


# Generated at 2022-06-22 09:18:12.582098
# Unit test for function parseOpts
def test_parseOpts():
    pass


# Generated at 2022-06-22 09:18:22.989571
# Unit test for function parseOpts
def test_parseOpts():
    # a long term goal is to use mock objects for testing,
    # see http://www.voidspace.org.uk/python/mock/
    # see also http://docs.python-guide.org/en/latest/writing/tests/
    # see also http://www.tdd-django-tutorial.com/
    # see also https://github.com/jaraco/mock

    from .postprocessor import _match_entry
    from .compat import compat_expanduser
    def parseOpts():
        parser, opts, args = _parseOpts()
        verbose = opts.verbose
        if opts.verbose > 0:
            write_string('[debug] System config: ' + repr(_readOptions('/etc/youtube-dl.conf')) + '\n')
        opts.verbose

# Generated at 2022-06-22 09:18:26.021376
# Unit test for function parseOpts
def test_parseOpts():
    assert re.compile(r'^\S+$').match(parseOpts()[1].username) is None



# Generated at 2022-06-22 09:18:32.433733
# Unit test for function parseOpts
def test_parseOpts():

    call_home = True

    try:
        import __pypy__
    except ImportError:
        pass
    else:  # kind of PyPy-specific hack
        call_home = False

    test_opts = lambda argv: parseOpts(argv)[1]
    filename = lambda opts: (opts.outtmpl % opts.__dict__).split(' ')[0]
    filename_id = lambda opts, id: (opts.outtmpl % dict(opts.__dict__, id=id)).split(' ')[0]

    def test_generic(argv, expected_opts, expected_args=[]):
        opts, args = parseOpts(argv)[1:]
        assert vars(opts) == expected_opts
        assert args == expected_args

# Generated at 2022-06-22 09:18:34.981931
# Unit test for function parseOpts
def test_parseOpts():
    assert parseOpts(["--help"])

# _match_entry

# Generated at 2022-06-22 09:18:37.737254
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts([])[1]
    assert not opts.ignoreerrors
    assert not opts.quiet
# parseCmd() function

# Generated at 2022-06-22 09:18:46.300754
# Unit test for function parseOpts
def test_parseOpts():
    assertTrue(parseOpts(["-h"])[1].help)
    assertTrue(parseOpts(["--version"])[1].version)
    assertTrue(parseOpts(["--verbose"])[1].verbose)
    assertTrue(parseOpts(["--filter-container", "mp4"])[1].filter_container)
    assertTrue(parseOpts(["--abort-on-error"])[1].abort_on_error)
    assertTrue(parseOpts(["--dump-user-agent"])[1].dump_user_agent)
    assertTrue(parseOpts(["--source-address", "127.0.0.1"])[1].source_address)
    assertTrue(parseOpts(["--sleep-interval", "10"])[1].sleep_interval)

# Generated at 2022-06-22 09:18:50.782378
# Unit test for function parseOpts
def test_parseOpts():
    from tempfile import NamedTemporaryFile
    from os.path import join, dirname
    from shutil import copy
    from sys import argv
    from itertools import chain

    here = dirname(__file__)
    long_opt_path = join(here, 'test', 'long-opt.conf')

    with NamedTemporaryFile(mode='wb', delete=False) as dest:
        with open(long_opt_path, 'rb') as src:
            dest.write(src.read())


# Generated at 2022-06-22 09:18:56.829637
# Unit test for function parseOpts
def test_parseOpts():
    # We can't test this method correctly because it has side effects
    # And also it takes --config-location as an argument
    # So, let's just test that it doesn't crash
    _, _, _ = parseOpts()
    # We skip passing arguments to parseOpts, because that might crash
    # parseOpts()

#TODO Remove following functions after deprecation

# Generated at 2022-06-22 09:20:12.637221
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.verbose == False


# Generated at 2022-06-22 09:20:22.330075
# Unit test for function parseOpts
def test_parseOpts():
    # Test function with empty argument
    parser, opts, args = parseOpts([])
    assert(not hasattr(opts, 'verbose'))
    # Test function with one argument
    parser, opts, args = parseOpts(['--verbose'])
    assert(hasattr(opts, 'verbose'))
    assert(opts.verbose)
    # Test function with two arguments
    parser, opts, args = parseOpts(['--verbose', '--version'])
    assert(hasattr(opts, 'verbose'))
    assert(opts.verbose)
    assert(hasattr(opts, 'version'))
    assert(opts.version)
    # Test function with three arguments

# Generated at 2022-06-22 09:20:24.536896
# Unit test for function parseOpts
def test_parseOpts():
    assert get_config_parser()

# Generated at 2022-06-22 09:20:32.712189
# Unit test for function parseOpts