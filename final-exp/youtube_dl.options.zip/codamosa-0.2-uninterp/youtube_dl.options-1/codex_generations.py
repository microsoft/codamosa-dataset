

# Generated at 2022-06-18 15:27:29.600893
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected_opts.__dict__

    _test_parseOpts(
        [],
        YoutubeDL())

    _test_parseOpts(
        ['--no-warnings'],
        YoutubeDL(no_warnings=True))

    _test_parseOpts(
        ['--ignore-config'],
        YoutubeDL(ignoreconfig=True))


# Generated at 2022-06-18 15:27:40.539849
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request_urlopen
    from youtube_dl.compat import compat_urlparse

# Generated at 2022-06-18 15:27:52.008934
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['-v', '-v'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['-v', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['-v', '-v', '--verbose'])
    assert opts.verbose == 3
    parser, opts, args = parseOpt

# Generated at 2022-06-18 15:28:02.731429
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_expanduser

    def test_parse_opts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:28:14.730023
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config', '--config-location', 'test/test_config'])

# Generated at 2022-06-18 15:28:24.292182
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for key, value in expected_opts.items():
            assert getattr(opts, key) == value

    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar'],
        {'username': 'foo', 'password': 'bar'})
    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar', '--ignore-config'],
        {'username': 'foo', 'password': 'bar'})

# Generated at 2022-06-18 15:28:36.964995
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'testuser', '-P', 'testpass', '-i', '-v', '-a', 'test.txt', '-o', '%(uploader)s/%(title)s-%(id)s.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'testuser'
    assert opts.password == 'testpass'
    assert opts.usenetrc == True
    assert opts.verbose == True
    assert opts.batchfile == 'test.txt'
    assert opts.outtmpl == '%(uploader)s/%(title)s-%(id)s.%(ext)s'

# Generated at 2022-06-18 15:28:45.252235
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupStretchedPP

# Generated at 2022-06-18 15:28:57.576634
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMergerPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.ffmpegmetadata import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedsubtitles import EmbedSubtitlesPP

# Generated at 2022-06-18 15:29:07.096908
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:29:37.299613
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse

# Generated at 2022-06-18 15:29:50.862234
# Unit test for function parseOpts

# Generated at 2022-06-18 15:30:02.520546
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for attr, value in expected_opts.items():
            assert getattr(opts, attr) == value

    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar', '--verbose'],
        {
            'username': 'foo',
            'password': 'bar',
            'verbose': True,
        })

    _test

# Generated at 2022-06-18 15:30:08.476890
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-o', '%(title)s.%(ext)s', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:30:18.643381
# Unit test for function parseOpts

# Generated at 2022-06-18 15:30:31.680243
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:30:39.422355
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test_username'
    assert opts.password == 'test_password'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == 'bestvideo+bestaudio'
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False

# Generated at 2022-06-18 15:30:45.673766
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    def test_parse_opts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:30:56.970513
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['--username', 'foo', '--password', 'bar', '-v', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True

# Generated at 2022-06-18 15:31:04.708671
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:31:47.288029
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:32:01.046277
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors is False
    assert opts.forceurl is False
    assert opts.forcetitle is False
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.format_limit is None
    assert opts.nooverwrites is False

# Generated at 2022-06-18 15:32:07.970696
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format_limit == None
    assert opts.dump_user_agent == False
    assert opts.list_extractors == False
    assert opts.extractor_descriptions

# Generated at 2022-06-18 15:32:19.853942
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors
    assert opts.forceurl
    assert opts.forcetitle
    assert opts.simulate
    assert opts.format == 'best'
    assert opts.format_limit == 'best'
    assert opts.usenetrc
    assert opts.nooverwrites
    assert opts.retries == 10
    assert opts.continuedl
    assert opts.noprogress
    assert opts.playliststart == 1
    assert opts.playlistend == -1
    assert opts.matchtitle
    assert opts

# Generated at 2022-06-18 15:32:26.804277
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for attr, value in expected_opts.items():
            assert getattr(opts, attr) == value

    def _test_parseOpts_raises(args, expected_exception):
        parser, opts, _ = parseOpts(args)
        try:
            YoutubeDL(opts)
        except expected_exception:
            pass
        else:
            raise AssertionError('%r not raised' % expected_exception)

    _test

# Generated at 2022-06-18 15:32:37.715766
# Unit test for function parseOpts

# Generated at 2022-06-18 15:32:49.306396
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def test(args, expected):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected
        assert args == []

# Generated at 2022-06-18 15:32:58.104848
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.verbose_count == 1
    assert opts.quiet_count == 0
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts

# Generated at 2022-06-18 15:33:10.539471
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from io import StringIO
    from youtube_dl.utils import encodeArgument

    # Test for issue #569
    # https://github.com/rg3/youtube-dl/issues/569
    #
    # When a config file contains a line with a single quote,
    # the line is not parsed correctly.
    #
    # This test checks that the line is parsed correctly.
    #
    # The config file contains the line:
    #   --match-filter 'duration <= 600'
    #
    # The test checks that the option match_filter is set to
    # the value 'duration <= 600'
    #
    # The test also checks that the option match_filter is not
    # set to the value 'duration <= 600'
    #
    # The test also checks that the option match_filter is

# Generated at 2022-06-18 15:33:19.126931
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os.path import dirname, join
    from tempfile import mkstemp
    from shutil import copyfileobj
    from io import open

    def test_parseOpts_helper(args, expected_opts, expected_args, expected_conf_args=None):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected_opts
        assert args == expected_args
        if expected_conf_args is not None:
            assert parser.rargs == expected_conf_args


# Generated at 2022-06-18 15:34:43.596045
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:34:55.706236
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:35:06.628344
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:35:15.102179
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opt

# Generated at 2022-06-18 15:35:19.666305
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '-a', 'test.txt', '-o', '%(title)s-%(id)s.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.simulate == True
    assert opts.batchfile == 'test.txt'
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:35:27.605303
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert not opts.quiet
    assert not opts.no_warnings
    assert not opts.simulate
    assert not opts.skip_download
    assert not opts.format
    assert not opts.listformats
    assert not opts.geturl
    assert not opts.gettitle
    assert not opts.getid
    assert not opts.getthumb
    assert not opts.getdescription
    assert not opts.getfilename
    assert not opts.get_format_limit
    assert not opts.usenetrc
    assert not opts.username
    assert not opts.password
    assert not opts.twofactor
    assert not opts.videopassword
   

# Generated at 2022-06-18 15:35:39.289690
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '-v', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '--verbose', '--verbose'])
    assert opts.verbose == 3
    parser, opts, args = parseOpts(['-v', '--verbose', '--verbose'])
    assert opts.verbose == 3
    parser, opts, args = parseOpts(['--verbose', '-v', '--verbose'])
    assert opts.verbose == 3
    parser, opts, args = parseOpts

# Generated at 2022-06-18 15:35:52.161870
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:36:01.125654
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert args == []
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose == True
    assert args == []
    parser, opts, args = parseOpts(['--verbose', '-v'])
    assert opts.verbose == True
    assert args == []
    parser, opts, args = parseOpts(['-v', '--verbose'])
    assert opts.verbose == True
    assert args == []
    parser, opts, args = parseOpts(['-v', '--verbose', '-v'])
    assert opts.verbose == True
    assert args == []
    parser, opts, args = parse

# Generated at 2022-06-18 15:36:10.939057
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['-v', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '-v'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['-v', '--verbose', '--verbose'])
    assert opts.verbose == 3