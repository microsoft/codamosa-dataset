

# Generated at 2022-06-18 15:27:20.949879
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass


# Generated at 2022-06-18 15:27:27.245371
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-h'])
    assert opts.help
    parser, opts, args = parseOpts(['--help'])
    assert opts.help
    parser, opts, args = parseOpts(['-U', 'unit_test'])
    assert opts.username == 'unit_test'
    parser, opts, args = parseOpts(['--username', 'unit_test'])
    assert opts.username == 'unit_test'
    parser, opts, args = parseOpts(['-P', 'unit_test'])
    assert opts.password == 'unit_test'
    parser, opts, args = parseOpts(['--password', 'unit_test'])
    assert opts.password == 'unit_test'
    parser, opts

# Generated at 2022-06-18 15:27:37.528672
# Unit test for function parseOpts

# Generated at 2022-06-18 15:27:48.534325
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.ignoreconfig == True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:28:00.337950
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        actual = dict((attr, getattr(opts, attr)) for attr in expected)
        assert actual == expected, (actual, expected)


# Generated at 2022-06-18 15:28:07.901673
# Unit test for function parseOpts
def test_parseOpts():
    # Test for function parseOpts
    # Test 1
    parser, opts, args = parseOpts(['-h'])
    assert opts.help == True
    # Test 2
    parser, opts, args = parseOpts(['-u', 'username', '-p', 'password', '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'username'
    assert opts.password == 'password'
    assert opts.usenetrc == False
    assert opts.video_password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_mso == None
    assert opts.ap_list == None

# Generated at 2022-06-18 15:28:20.962470
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert not opts.quiet
    assert not opts.no_warnings
    assert not opts.simulate
    assert not opts.skip_download
    assert not opts.format
    assert not opts.listformats
    assert not opts.list_thumbnails
    assert not opts.dump_user_agent
    assert not opts.dump_intermediate_pages
    assert not opts.write_pages
    assert not opts.write_info_json
    assert not opts.write_description
    assert not opts.write_annotations
    assert not opts.write_thumbnail
    assert not opts.write_all_thumbnails
    assert not opts.list_thumbnails

# Generated at 2022-06-18 15:28:32.297756
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.postprocessor import FFmpegMergerPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.embedsubtitles import EmbedSubtitlesPP
    from youtube_dl.postprocessor.ffmpegmetadata import FFmpegMetadataPP

# Generated at 2022-06-18 15:28:43.060391
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '-a', 'test.txt', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.simulate == True
    assert opts.batchfile == 'test.txt'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opt

# Generated at 2022-06-18 15:28:49.150455
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_opener
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_response
    from youtube_dl.compat import compat_urllib_robotparser
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat

# Generated at 2022-06-18 15:29:13.014795
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '--verbose', '--verbose'])
    assert opts.verbose == 3
    parser, opts, args = parseOpts(['--verbose', '--verbose', '--verbose', '--quiet'])
    assert opts.verbose == 2

# Generated at 2022-06-18 15:29:21.088597
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors
    gen_extractors()

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:29:30.967391
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.noplaylist == False
    assert opts.age_limit == None
    assert opts.download_archive == None
    assert opts.include_ads == False
    assert opts.sleep_inter

# Generated at 2022-06-18 15:29:39.555639
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_

# Generated at 2022-06-18 15:29:52.192238
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMetadataPP

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for attr, expected_value in expected_opts.items():
            if getattr(opts, attr) != expected_value:
                raise AssertionError('%s != %s for attr %s' % (getattr(opts, attr), expected_value, attr))


# Generated at 2022-06-18 15:30:03.624370
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test_user_agent', '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_mso == None
    assert opts.ap_list == None
    assert opts.usenetrc_machine == None

# Generated at 2022-06-18 15:30:13.846077
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP

    def test_parse_opts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:30:21.523728
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from os.path import exists
    from tempfile import mkstemp
    from shutil import move
    from random import randint
    from time import sleep
    from youtube_dl.utils import encodeArgument

    # Create a temporary file
    handle, filename = mkstemp()
    # Write some content
    with open(filename, 'w') as f:
        f.write('--verbose --dump-user-agent')
    # Move the file to the original name
    move(filename, encodeArgument(filename))

    # Parse the options
    parser, opts, args = parseOpts(['-v', '--ignore-config', '--config-location', filename])

    # Check if the options are correct
    assert opts.verbose == 2
    assert opts.dump

# Generated at 2022-06-18 15:30:34.481619
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.ignoreerrors
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts(['-i', '-v', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.ignoreerrors
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:30:43.044614
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.nooverwrites == False
    assert opts.continue_dl == True
    assert opts.nopart == False
    assert opts.updat

# Generated at 2022-06-18 15:31:18.187875
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:31:27.324388
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for attr, expected_value in expected_opts.items():
            assert getattr(opts, attr) == expected_value

    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar', '--verbose'],
        {'username': 'foo', 'password': 'bar', 'verbose': True})

# Generated at 2022-06-18 15:31:39.574536
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.force_generic_extractor == False
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opt

# Generated at 2022-06-18 15:31:44.552116
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert args == ['-i']
    parser, opts, args = parseOpts(['-i', '--ignore-config', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert args == ['-i', '--ignore-config']

# Generated at 2022-06-18 15:31:58.324783
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose', '-o', '%(title)s.%(ext)s'])
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True

# Generated at 2022-06-18 15:32:08.305379
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no argument
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.ratelimit == None
    assert opts.retries == 10
    assert opts.buffersize == '1024'
    assert opts.noresizebuffer == False
    assert opts.continuedl == True
    assert opts.noprogress == False
    assert opts.playliststart == 1
   

# Generated at 2022-06-18 15:32:20.167521
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test_user_agent', '-u', 'unit_test_username', '-p', 'unit_test_password', '-s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'unit_test_username'
    assert opts.password == 'unit_test_password'
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.verbose == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None


# Generated at 2022-06-18 15:32:26.995787
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--no-warnings', '--dump-user-agent', '--ignore-config', '--', 'foo', 'bar'])
    assert opts.verbose == True
    assert opts.dump_user_agent == True
    assert opts.ignoreconfig == True
    assert opts.noplaylist == False
    assert opts.nocheckcertificate == False
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == True
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False

# Generated at 2022-06-18 15:32:37.896981
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'

# Generated at 2022-06-18 15:32:43.349603
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-f', 'best', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'

# Generated at 2022-06-18 15:33:38.749798
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None

# Generated at 2022-06-18 15:33:44.722502
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import re

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for key, value in expected_opts.items():
            assert getattr(opts, key) == value

    def _test_parseOpts_error(args, expected_error):
        parser, _, _ = parseOpts(args)
        try:
            parser.error(expected_error)
        except (SystemExit, Exception) as err:
            assert str(err) == expected_error

    def _test_parseOpts_config(args, expected_opts):
        tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 15:33:55.551355
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:34:04.094562
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '--no-verbose'])
    assert opts.verbose == 0
    parser, opts, args = parseOpts(['--verbose', '--no-verbose', '--verbose'])
    assert opts.verbose == 1

# Generated at 2022-06-18 15:34:13.388677
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'plop'])
    assert opts.format == 'best'
    assert opts.geturl
    assert not opts.gettitle
    assert not opts.getid
    assert not opts.getthumb
    assert not opts.getdescription
    assert not opts.getfilename
    assert not opts.getformat
    assert not opts.usenetrc
    assert not opts.verbose
    assert not opts.quiet
    assert not opts.no_warnings
    assert not opts.simulate
    assert not opts.skip_download
    assert not opts.format_limit
    assert not opts.listformats

# Generated at 2022-06-18 15:34:22.748604
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-f', 'best', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'], ['--format=worst'])
    assert opts.format == 'worst'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:34:30.143013
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == None
    assert opts.password == None
    assert opts.usenetrc == False
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False

# Generated at 2022-06-18 15:34:41.163656
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose

    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-v', '--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-v', '--verbose', '--no-verbose'])
    assert not opts.verbose

    parser, opts, args = parseOpts(['--verbose', '--no-verbose'])
    assert not opts.verbose

    parser, opts, args = parseOpts(['--verbose', '--no-verbose', '--verbose'])
    assert opts.verbose

    parser

# Generated at 2022-06-18 15:34:51.252981
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    def _test(args, expected):
        parser, opts, args = parseOpts(args)
        assert opts.verbose == expected[0]
        assert opts.quiet == expected[1]
        assert opts.simulate == expected[2]
        assert opts.format == expected[3]
        assert opts.outtmpl == expected[4]
        assert opts.ignoreerrors == expected[5]
        assert opts.forceurl == expected[6]
        assert opts.forcetitle == expected[7]
        assert opts.forceid == expected[8]
        assert opts.forceduration == expected[9]
        assert opts.forcefilename == expected[10]

# Generated at 2022-06-18 15:35:02.511171
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    import tempfile
    import shutil
    import os
    import sys
    import re

    def _readOptions(filename):
        try:
            with open(filename, 'rb') as conf_file:
                conf_data = conf_file.read()
        except (IOError, OSError) as err:
            if err.errno == errno.ENOENT:
                return []
            raise
        return shlex.split(encodeArgument(conf_data))

    def _writeOptions(filename, options):
        with open(filename, 'wb') as conf_file:
            conf_file.write(encodeArgument(' '.join(options)))


# Generated at 2022-06-18 15:36:53.254274
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument

# Generated at 2022-06-18 15:37:00.573872
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.utils import _hide_login_info
    from youtube_dl.utils import _readOptions
    from youtube_dl.utils import _readUserConf
    from youtube_dl.utils import preferredencoding
    from youtube_dl.utils import write_string
    from youtube_dl.version import __version__
    from optparse import OptionParser
    from optparse import OptionGroup
    import os
    import sys
    import tempfile
    import unittest

    class FakeYDL(YoutubeDL):
        def __init__(self, params):
            YoutubeDL.__init__(self, params)
            self.params = params
            self.to_stderr_called = False
            self.to_