

# Generated at 2022-06-18 15:27:40.539093
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_xml_parse_error
    from youtube_dl.compat import compat_xml_parse_response
    from youtube_dl.compat import compat_xml_parse_

# Generated at 2022-06-18 15:27:52.056586
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected

# Generated at 2022-06-18 15:28:02.773874
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    parser, opts, args = parseOpts(['-F', '--dateafter', 'yesterday', '--datebefore', 'today', '--match-title', 'regex'])
    assert opts.format == 'best'
    assert opts.daterange == DateRange('yesterday', 'today')
    assert opts.matchtitle == 'regex'
    assert opts.match_filter == 'regex'
    assert opts.match_filter_func is None
    assert opts.match_filter_func_str == 'regex'
    assert opts.match_filter_func_result is None
    assert opts.match_filter_func_result_str == 'regex'
    assert opts.match_filter_func_result_bool is None
    assert opt

# Generated at 2022-06-18 15:28:09.935115
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-U', 'unit_test_user_agent', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.video_password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_mso == None
    assert opts.ap_list == None
    assert opts.usenetrc_machine == None
    assert opts.usenetrc_password == None
    assert opts.usenetrc_username == None
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no

# Generated at 2022-06-18 15:28:22.341383
# Unit test for function parseOpts

# Generated at 2022-06-18 15:28:34.600763
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def test_parseOpts_helper(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected

# Generated at 2022-06-18 15:28:40.892105
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_expanduser

    def _parseOpts(args):
        parser, opts, args = parseOpts(args)
        return opts

    def _parseOpts_noprog(args):
        parser, opts, args = parseOpts(args, no_prog=True)
        return opts

    def _parseOpts_override(args):
        parser, opts, args = parseOpts(overrideArguments=args)
        return opts

    def _parseOpts_override_noprog(args):
        parser, opts, args = parseOpts(overrideArguments=args, no_prog=True)
        return opt

# Generated at 2022-06-18 15:28:49.560350
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def test(args, expected):
        parser, opts, args = parseOpts(args)
        assert opts.verbose == expected
    test(['-v'], True)
    test(['--verbose'], True)
    test(['-v', '--verbose'], True)
    test(['--verbose', '-v'], True)
    test(['-v', '--no-verbose'], False)
    test(['--no-verbose', '-v'], True)
    test(['--no-verbose'], False)
    test(['--verbose', '--no-verbose'], False)

# Generated at 2022-06-18 15:28:56.080094
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'

# Generated at 2022-06-18 15:28:57.948716
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()


# Generated at 2022-06-18 15:29:26.435164
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.usenetrc == False
    assert opts.noprogress == False
    assert opts.ratelimit == '0'
    assert opts

# Generated at 2022-06-18 15:29:36.278008
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected

# Generated at 2022-06-18 15:29:50.620283
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected
    _test_parseOpts(
        ['-U', 'FooBar', '-o', '%(title)s.%(ext)s', '-a', 'a'],
        {'username': 'FooBar', 'outtmpl': '%(title)s.%(ext)s', 'batchfile': 'a', 'usenetrc': False})

# Generated at 2022-06-18 15:30:02.289373
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:30:09.290406
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.verbose == 2
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.ignoreerrors
    assert args == []

    parser, opts, args = parseOpts(['-i', '-v', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config'])
    assert opts.verbose == 2
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.ignoreerrors
    assert args == []


# Generated at 2022-06-18 15:30:18.998353
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.verbose == True
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == 'bestvideo+bestaudio'
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forceduration == False
    assert opt

# Generated at 2022-06-18 15:30:32.032126
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoConvertor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP

# Generated at 2022-06-18 15:30:40.819634
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    parser, opts, args = parseOpts(['-F', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.simulate
    assert opts.format == 'best'
    assert not opts.listformats
    assert not opts.usenetrc
    assert not opts.verbose
    assert not opts.quiet
    assert not opts.no_warnings
    assert not opts.dump_user_agent
    assert not opts.dump_intermediate_pages
    assert not opts.write_pages
    assert not opts.write_info_json
    assert not opts.write_description
    assert not opts.write_annotations
    assert not opts.write_thumbnail

# Generated at 2022-06-18 15:30:53.386209
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose == True
    parser, opts, args = parseOpts(['--verbose', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '--verbose', '--verbose'])
    assert opts.verbose == 3
    parser, opts, args = parseOpts(['--verbose', '--verbose', '--verbose', '--verbose'])
    assert opts.verbose == 4

# Generated at 2022-06-18 15:30:58.958050
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.ignoreerrors == False

# Generated at 2022-06-18 15:31:44.078087
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP

    def test_parse_opts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected_opts


# Generated at 2022-06-18 15:31:57.519274
# Unit test for function parseOpts

# Generated at 2022-06-18 15:32:03.670231
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose
    assert opts.quiet is False
    assert opts.no_warnings is False
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.format is None
    assert opts.listformats is False
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors is False
    assert opts.forceurl is False
    assert opts.forcetitle is False
    assert opts.forceid is False
    assert opts.forceduration is False
   

# Generated at 2022-06-18 15:32:11.206483
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_xml_parse_error
    from youtube_dl.compat import compat_xml_parse_fragment
    from youtube_dl.compat import compat_xml_

# Generated at 2022-06-18 15:32:21.764838
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMetadataPP

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args

    def _test_parseOpts_raises(args, expected_exception):
        parser, opts, args = parseOpts(args)
        try:
            parser.error(expected_exception)
        except (optparse.OptionValueError, optparse.OptionError) as oe:
            assert str(oe) == expected_exception

# Generated at 2022-06-18 15:32:33.273188
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def test(args, expected):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected

# Generated at 2022-06-18 15:32:44.648924
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoConvertor

# Generated at 2022-06-18 15:32:54.953829
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpeg

# Generated at 2022-06-18 15:33:08.190534
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_opener

    def test_parse_opts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:33:13.623781
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--username', 'foo', '--password', 'bar', '--verbose', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.geturl == True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:34:41.117118
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat

# Generated at 2022-06-18 15:34:48.705047
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_http_client
    from youtube_dl.compat import compat_struct_pack

# Generated at 2022-06-18 15:34:59.551342
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def test_parseOpts_helper(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected

# Generated at 2022-06-18 15:35:10.655164
# Unit test for function parseOpts

# Generated at 2022-06-18 15:35:22.032776
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.verbose == expected
    _test_parseOpts(['-v'], True)
    _test_parseOpts(['--verbose'], True)
    _test_parseOpts(['-v', '--no-verbose'], False)
    _test_parseOpts(['--verbose', '--no-verbose'], False)
    _test_parseOpts(['--verbose', '--no-verbose', '-v'], True)
    _test_parseOpts(['--no-verbose', '--verbose'], True)


# Generated at 2022-06-18 15:35:30.009298
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts()
    assert opts.usenetrc
    assert opts.password == 'hunter2'
    assert opts.username == 'test'
    assert opts.ap_username == 'test'
    assert opts.ap_password == 'hunter2'
    assert opts.ap_mso == 'mso1'
    assert opts.ap_listid == 'listid1'
    assert opts.ap_listid == 'listid1'
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert opts.ignoreerrors
    assert opts.forceurl
    assert opts.forcethumbnail
    assert opts.forceduration
    assert opts.forcefilename
   

# Generated at 2022-06-18 15:35:42.958318
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == ['bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best']
    parser, opts, args = parseOpts(['--format', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == ['bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best']
    parser,

# Generated at 2022-06-18 15:35:54.465277
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose', '--config-location', 'test/test_config'])

# Generated at 2022-06-18 15:36:00.705840
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forceduration == False
    assert opts.forcefilename == False
    assert opts.forcedownload == False
    assert opts

# Generated at 2022-06-18 15:36:10.291920
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-U', 'unit test'])
    assert opts.username == 'unit test'
    assert opts.password is None
    assert opts.usenetrc is False
    parser, opts, args = parseOpts(['--username', 'unit test'])
    assert opts.username == 'unit test'
    assert opts.password is None
    assert opts.usenetrc is False
    parser, opts, args = parseOpts(['--username', 'unit test', '--password', 'p@ssw0rd'])
    assert opts.username == 'unit test'
    assert opts.password == 'p@ssw0rd'
    assert opts.usenetrc is False
    parser,