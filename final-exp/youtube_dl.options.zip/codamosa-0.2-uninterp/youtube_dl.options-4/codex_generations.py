

# Generated at 2022-06-18 15:27:28.428825
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == ['bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best']
    assert args == []
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-o', '%(title)s.%(ext)s'])

# Generated at 2022-06-18 15:27:34.316381
# Unit test for function parseOpts

# Generated at 2022-06-18 15:27:41.106355
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:27:52.863868
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    parser, opts, args = parseOpts(['--username', 'foo', '--password', 'bar', '--verbose', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.geturl == True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    ydl = YoutubeDL(opts)
    assert ydl.params['username'] == 'foo'
    assert ydl.params['password'] == 'bar'
    assert ydl.params['verbose'] == True
    assert ydl.params

# Generated at 2022-06-18 15:28:03.341200
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoCon

# Generated at 2022-06-18 15:28:10.183886
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMergerPP

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:28:22.417727
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected
    _test(
        ['--username=user', '--password=pass', '--verbose'],
        {'username': 'user', 'password': 'pass', 'verbose': True})
    _test(
        ['--username', 'user', '--password', 'pass', '--verbose'],
        {'username': 'user', 'password': 'pass', 'verbose': True})
    _test(
        ['--username', encodeArgument('user with space'), '--password', 'pass', '--verbose'],
        {'username': 'user with space', 'password': 'pass', 'verbose': True})
    _

# Generated at 2022-06-18 15:28:34.599579
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected

    def _test_parseOpts_raises(args, expected_msg):
        parser, _, _ = parseOpts(args)
        try:
            parser.error(expected_msg)
        except (SystemExit, Exception) as err:
            assert isinstance(err, (SystemExit, Exception))
            assert str(err) == expected_msg


# Generated at 2022-06-18 15:28:44.071891
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split

    def test_parse(args, expected):
        parser, opts, args = parseOpts(args)
        assert opts.verbose == expected['verbose']
        assert opts.quiet == expected['quiet']
        assert opts.simulate == expected['simulate']
        assert opts.skip_download == expected['skip_download']
        assert opts.format == expected['format']
        assert opts.outtmpl == expected['outtmpl']
        assert opts.ignoreerrors == expected['ignoreerrors']
        assert opts.forceurl == expected['forceurl']
        assert opts.forcetitle == expected['forcetitle']

# Generated at 2022-06-18 15:28:50.572699
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None

# Generated at 2022-06-18 15:29:18.551329
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for attr, value in expected_opts.items():
            assert getattr(opts, attr) == value

    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar'],
        {'username': 'foo', 'password': 'bar'})
    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar', '--ignore-config'],
        {'username': 'foo', 'password': 'bar'})

# Generated at 2022-06-18 15:29:29.083954
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMergerPP

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for k, v in expected_opts.items():
            assert getattr(opts, k) == v

    _test_parseOpts(
        ['--format', 'best'],
        {'format': 'best'})
    _test_parseOpts(
        ['--format', 'best', '--format', 'worst'],
        {'format': 'worst'})

# Generated at 2022-06-18 15:29:38.298530
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def test(args, expected):
        parser, opts, args = parseOpts(args)
        assert opts.verbose == expected
        assert opts.username == expected
        assert opts.password == expected
        assert opts.twofactor == expected
        assert opts.videopassword == expected
        assert opts.ap_username == expected
        assert opts.ap_password == expected
        assert opts.ap_mso == expected
        assert opts.ap_list == expected
        assert opts.outtmpl == expected
        assert opts.cookiefile == expected
        assert opts.nopart == expected
        assert opts.writedescription == expected
        assert opts.writeinfojson == expected
        assert opts.writeannotations == expected


# Generated at 2022-06-18 15:29:51.350669
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        actual = dict((k, v) for k, v in vars(opts).items() if not k.startswith('_'))
        assert actual == expected


# Generated at 2022-06-18 15:30:03.017339
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMergerPP

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:30:12.949791
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None

# Generated at 2022-06-18 15:30:23.248755
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config', '--no-check-certificate', '--proxy', '127.0.0.1:8080', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == 2
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.ignoreconfig == True
    assert opts.no_check_certificate == True
    assert opts.proxy == '127.0.0.1:8080'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:30:35.488331
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.utils import _hide_login_info
    from youtube_dl.utils import _readOptions
    from youtube_dl.utils import _readUserConf

    def _readOptions(path):
        if not os.path.exists(path):
            return []
        try:
            with open(path, 'rb') as conf_file:
                conf_data = conf_file.read()
        except (IOError, OSError) as err:
            sys.exit('ERROR: unable to read config file: %s' % str(err))
        if sys.version_info < (3,):
            conf_data = conf_data.decode(preferredencoding())
        return shlex.split

# Generated at 2022-06-18 15:30:43.656343
# Unit test for function parseOpts

# Generated at 2022-06-18 15:30:55.938846
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def parseOpts(overrideArguments=None):
        return parseOpts_(overrideArguments)

    def _readOptions(filename):
        try:
            with open(filename, 'r') as conf_file:
                return conf_file.read().split()
        except (IOError, OSError):
            return []

    def _readUserConf():
        return _readOptions(compat_expanduser('~/.config/youtube-dl/config'))


# Generated at 2022-06-18 15:31:35.254710
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'testuser', '-P', 'testpass', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'testuser'
    assert opts.password == 'testpass'
    assert opts.usenetrc == False
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:31:41.125140
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert not opts.quiet
    assert not opts.no_warnings
    assert not opts.simulate
    assert not opts.skip_download
    assert not opts.format
    assert not opts.listformats
    assert not opts.outtmpl
    assert not opts.ignoreerrors
    assert not opts.forceurl
    assert not opts.forcetitle
    assert not opts.forceid
    assert not opts.forceduration
    assert not opts.forcefilename
    assert not opts.forcejson
    assert not opts.dump_single_json
    assert not opts.dump_json
    assert not opts.dump_single_json
    assert not opts.dump_

# Generated at 2022-06-18 15:31:46.548591
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:31:59.968737
# Unit test for function parseOpts

# Generated at 2022-06-18 15:32:09.473707
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.outtmpl_na_placeholder == 'NA'
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.nooverwrites == False
    assert opts

# Generated at 2022-06-18 15:32:20.979384
# Unit test for function parseOpts

# Generated at 2022-06-18 15:32:32.093150
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forceduration == False
    assert opts.forcefilename == False

# Generated at 2022-06-18 15:32:43.612865
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.video_password == None
    assert opts.ap_mso == None
    assert opts.ap_list == False
    assert opts.usenetrc_machine == None
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
   

# Generated at 2022-06-18 15:32:54.100277
# Unit test for function parseOpts

# Generated at 2022-06-18 15:33:06.701241
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        actual = dict((o.dest, getattr(opts, o.dest)) for o in parser.option_list)
        assert actual == expected


# Generated at 2022-06-18 15:34:23.781965
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    parser, opts, args = parseOpts(['-v', '--dump-user-agent'])
    assert opts.verbose == 2
    assert opts.dump_user_agent
    assert not opts.list_extractors
    assert not opts.dump_intermediate_pages
    assert not opts.write_pages
    assert not opts.write_info_json
    assert not opts.write_description
    assert not opts.write_annotations
    assert not opts.write_thumbnail
    assert not opts.write_all_thumbnails
    assert not opts.list_thumbnails
    assert not opts.dump_single_json
    assert not opts.write_sub
    assert not opts.write_auto_sub
    assert not opt

# Generated at 2022-06-18 15:34:32.082627
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert not opts.quiet
    assert not opts.no_warnings
    assert opts.simulate
    assert not opts.skip_download
    assert not opts.format
    assert not opts.listformats
    assert not opts.outtmpl
    assert not opts.usetitle
    assert not opts.autonumber
    assert not opts.autonumber_size
    assert opts.autonumber_start == 1
    assert not opts.restrictfilenames
    assert not opts.nooverwrites
    assert opts.continue_dl
    assert not opts.nopart
    assert opts.updatetime
    assert not opts.writedescription
   

# Generated at 2022-06-18 15:34:37.209398
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['--username', 'foo', '--password', 'bar', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['--username', 'foo', '--password', 'bar', 'https://www.youtube.com/watch?v=BaW_jenozKc'], overrideArguments=['--no-check-certificate'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'

# Generated at 2022-06-18 15:34:46.124108
# Unit test for function parseOpts

# Generated at 2022-06-18 15:34:57.189718
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert not opts.quiet
    assert not opts.no_warnings
    assert not opts.simulate
    assert not opts.skip_download
    assert not opts.format
    assert not opts.listformats
    assert not opts.outtmpl
    assert not opts.ignoreerrors
    assert not opts.forceurl
    assert not opts.forcetitle
    assert not opts.forceid
    assert not opts.forceduration
    assert not opts.forcefilename
    assert not opts.forcejson
    assert not opts.dump_single_json
    assert not opts.dump_json
    assert not opts.dump_single_json
    assert not opts.dump_

# Generated at 2022-06-18 15:35:02.406474
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'testuser', '-P', 'testpass', '-i', '-v', '-a', 'test.txt', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'testuser'
    assert opts.password == 'testpass'
    assert opts.usenetrc == True
    assert opts.verbose == True
    assert opts.batchfile == 'test.txt'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:35:12.841353
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP

    def test_parse_opts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:35:25.081125
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.get_format == False
    assert opts.usenetrc == False
    assert opts.noprogress == False
    assert opts.ratelimit == '0'
    assert opt

# Generated at 2022-06-18 15:35:33.750913
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import prepend_extension
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor.common import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegMetadataPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoConvertor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedThumbnailPP
    from youtube_dl.postprocessor.ffmpeg import get_ffmpeg_codec_name
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupStrict

# Generated at 2022-06-18 15:35:47.651399
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args
