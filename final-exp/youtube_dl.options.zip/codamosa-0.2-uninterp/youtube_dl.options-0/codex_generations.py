

# Generated at 2022-06-18 15:27:28.882297
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test_user_agent', '-f', '22/18/17/best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.video_password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcedescription == False


# Generated at 2022-06-18 15:27:40.447609
# Unit test for function parseOpts

# Generated at 2022-06-18 15:27:51.916455
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--dump-user-agent'])
    assert opts.verbose
    assert opts.dump_user_agent
    assert not opts.ignoreerrors
    assert not opts.simulate
    assert not opts.geturl
    assert not opts.gettitle
    assert not opts.getid
    assert not opts.getthumb
    assert not opts.getdescription
    assert not opts.getfilename
    assert not opts.getformat
    assert not opts.quiet
    assert not opts.no_warnings
    assert not opts.no_color
    assert not opts.forceurl
    assert not opts.forcethumbnail
    assert not opts.forcedescription
    assert not opts.forcefilename
   

# Generated at 2022-06-18 15:28:02.655095
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    parser, opts, args = parseOpts(['--username', 'user', '--password', 'pass', '--verbose'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.verbose
    parser, opts, args = parseOpts(['-U', 'user', '-P', 'pass', '-v'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.verbose
    parser, opts, args = parseOpts(['--ignore-config', '--username', 'user', '--password', 'pass', '--verbose'])

# Generated at 2022-06-18 15:28:14.670142
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.noover

# Generated at 2022-06-18 15:28:24.264328
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:28:36.914049
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_opener
    from youtube_dl.compat import compat_setenv
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_xml_parse_error
    from youtube_dl.compat import compat_xml_parse_response

# Generated at 2022-06-18 15:28:45.169592
# Unit test for function parseOpts

# Generated at 2022-06-18 15:28:57.503862
# Unit test for function parseOpts

# Generated at 2022-06-18 15:29:07.054022
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == 'best'
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.usetitle == False

# Generated at 2022-06-18 15:29:33.982129
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from os.path import exists
    from tempfile import mkstemp
    from shutil import move

    # Test config file

# Generated at 2022-06-18 15:29:43.700728
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '-i', '-c', '-o', '%(id)s.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.simulate == True
    assert opts.continue_dl == True
    assert opts.outtmpl == '%(id)s.%(ext)s'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:29:57.005233
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP

# Generated at 2022-06-18 15:30:03.880388
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--username', 'foo', '--password', 'bar', '-o', '%(title)s.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:30:14.661526
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    argv = [argv[0]] + ['-i', '--username', 'foo', '--password', 'bar']
    parser, opts, args = parseOpts()
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.usenetrc == False
    argv = [argv[0]] + ['--get-id']
    parser, opts, args = parseOpts()
    assert opts.geturl == True and opts.gettitle == False
    assert opts.usenetrc == True
    argv = [argv[0]] + ['--get-title']
    parser, opts, args = parseOpts()
    assert opts.geturl == False and opts.gettitle == True

# Generated at 2022-06-18 15:30:21.810879
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected_opts

    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar'],
        {'username': 'foo', 'password': 'bar'})
    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar', '--ignore-config'],
        {'username': 'foo', 'password': 'bar'})

# Generated at 2022-06-18 15:30:34.702581
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMergerPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpegmetadata import FFmpegMetadataPP
    from youtube_dl.postprocessor.ffmpegthumbnail import FFmpegThumbnailPP
    from youtube_dl.postprocessor.ffmpegaudio import FFmpegExtractAudioPP

# Generated at 2022-06-18 15:30:43.076822
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc', '--', '--username', 'baz', '--password', 'qux'])
    assert opts.verbose
    assert opts.username == 'foo'

# Generated at 2022-06-18 15:30:55.624469
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors
    gen_extractors()

# Generated at 2022-06-18 15:31:03.868051
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', '--verbose', '--no-verbose', '--ignore-config', '--config-location', '~/youtube-dl.conf', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == 1
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.geturl == True
    assert opts.ignoreconfig == True
    assert opts.config_location == '~/youtube-dl.conf'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:31:44.667576
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'bestvideo+bestaudio', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo+bestaudio'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['--format', 'bestvideo+bestaudio', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo+bestaudio'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:31:58.434468
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFix

# Generated at 2022-06-18 15:32:08.427055
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected
    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar'],
        {'username': 'foo', 'password': 'bar'})
    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar', '--no-warnings'],
        {'username': 'foo', 'password': 'bar', 'noprogress': True, 'verbose': False, 'quiet': True})

# Generated at 2022-06-18 15:32:20.253548
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--no-playlist', '--yes-playlist', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.verbose == 2
    assert opts.usenetrc == False
    assert opts.noplaylist == False
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.quiet == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False

# Generated at 2022-06-18 15:32:31.438302
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == ['bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best']
    assert args == []
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-f', 'best'])
    assert opts.format == ['bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'best']
    assert args == []
    parser, opts, args = parse

# Generated at 2022-06-18 15:32:42.806711
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_quote
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import gen_extractors
    gen_extractors()
    ydl = YoutubeDL({})
    ydl.add_default_info_extractors()

    # Test with no argument
    parser, opts, args = parseOpts(ydl)
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(id)s'

# Generated at 2022-06-18 15:32:53.315669
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    parser, opts, args = parseOpts(['-F', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.listformats == True
    assert opts.usenetrc == False
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format_limit == None
    assert opts.dump_user_agent == False
    assert opts.dump_intermediate_pages == False
    assert opts.write_pages == False
    assert opts.write_info_json == False
   

# Generated at 2022-06-18 15:33:00.446397
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--no-playlist', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.noplaylist == True
    assert opts.ignoreerrors == True
    assert opts.simulate == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False

# Generated at 2022-06-18 15:33:12.770501
# Unit test for function parseOpts

# Generated at 2022-06-18 15:33:20.496107
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == ['bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best']
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors is False
    assert opts.forceurl is False
    assert opts.forcetitle is False
    assert opts.forceid is False
    assert opts.forcethumbnail is False
    assert opts.forcedescription is False
    assert opts.forcefilename is False
    assert opts.forcejson is False

# Generated at 2022-06-18 15:34:42.210320
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:34:53.500415
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument

    def test_parse_opts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected_opts

    test_parse_opts(
        ['--username', 'foo', '--password', 'bar', '--verbose'],
        {'username': 'foo', 'password': 'bar', 'verbose': True})
    test_parse_opts(
        ['--username', 'foo', '--password', 'bar', '--verbose', '--no-verbose'],
        {'username': 'foo', 'password': 'bar', 'verbose': False})

# Generated at 2022-06-18 15:35:04.113473
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv

# Generated at 2022-06-18 15:35:13.955396
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from youtube_dl.postprocessor import FFmpegMetadataPP

# Generated at 2022-06-18 15:35:21.332122
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--no-playlist', '--youtube-skip-dash-manifest', '--verbose'])
    assert opts.ignoreerrors
    assert opts.noplaylist
    assert opts.youtube_skip_dash_manifest
    assert opts.verbose
    assert args == []


# Generated at 2022-06-18 15:35:31.064241
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-h'])
    assert opts.help
    parser, opts, args = parseOpts(['--help'])
    assert opts.help
    parser, opts, args = parseOpts(['-U', '-u', 'user', '-p', 'passwd', '-s', 'http://site.com/'])
    assert opts.usenetrc
    assert opts.username == 'user'
    assert opts.password == 'passwd'
    assert opts.video_password == 'passwd'
    assert opts.ap_username == 'user'
    assert opts.ap_password == 'passwd'
    assert opts.ap_mso == 'site'

# Generated at 2022-06-18 15:35:43.603070
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.outtmpl_na_

# Generated at 2022-06-18 15:35:54.932548
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    parser, opts, args = parseOpts(['-F', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.listformats == True
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_listmso == False
    assert opts.ratelimit == None
    assert opts.retries == 10
    assert opts.buff

# Generated at 2022-06-18 15:36:01.028459
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.get_format == False
    assert opts.usenetrc == False
    assert opts.noprogress == False
    assert opts.ratelimit == '0'
    assert opt

# Generated at 2022-06-18 15:36:10.753845
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test(args, expected):
        parser, opts, args = parseOpts(args)
        assert opts.verbose == expected[0]
        assert opts.quiet == expected[1]
        assert opts.simulate == expected[2]
        assert opts.geturl == expected[3]
        assert opts.gettitle == expected[4]
        assert opts.getid == expected[5]
        assert opts.getthumb == expected[6]
        assert opts.getdescription == expected[7]
        assert opts.getfilename == expected[8]
        assert opts.getformat == expected[9]
        assert opts.username == expected[10]
        assert opts.password == expected[11]
        assert opts.twofactor