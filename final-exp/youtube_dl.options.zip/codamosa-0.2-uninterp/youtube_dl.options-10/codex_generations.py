

# Generated at 2022-06-18 15:27:36.134440
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == ['bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best']
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors is False
    assert opts.forceurl is False
    assert opts.forcetitle is False
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.format_limit is None
    assert opts.verbose is False
    assert opts.quiet is False
    assert opt

# Generated at 2022-06-18 15:27:47.066961
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '-u', 'user', '-p', 'pass', '-F', '-g', 'http://gdata.youtube.com/feeds/api/standardfeeds/top_rated'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.simulate == False
    assert opts.format == '-1'
    assert opts.geturl == True
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumburl == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts

# Generated at 2022-06-18 15:27:58.913059
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _readOptions(filename):
        try:
            with open(filename, 'r') as conf_file:
                return [encodeArgument(l.strip()) for l in conf_file.readlines() if not l.strip().startswith('#')]
        except (IOError, OSError):
            return []

    def _readUserConf():
        xdg_config_home = os.environ.get('XDG_CONFIG_HOME') or os.path.join(compat_expanduser('~'), '.config')

# Generated at 2022-06-18 15:28:06.257578
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-i', '-f', 'best', '-o', '%(title)s-%(id)s.%(ext)s', 'foo'])
    assert opts.simulate
    assert opts.format == 'best'
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert args == ['foo']
    parser, opts, args = parseOpts(['-i', '-f', 'best', '-o', '%(title)s-%(id)s.%(ext)s', 'foo'])
    assert opts.simulate
    assert opts.format == 'best'

# Generated at 2022-06-18 15:28:19.380413
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', '22/18/17/best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '22/18/17/best'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-f', '22/18/17/best', '-f', '43/18/17/best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '22/18/17/best'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opt

# Generated at 2022-06-18 15:28:26.841856
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose
    assert opts.ignoreerrors
    assert opts.simulate
    assert opts.quiet
    assert opts.no_warnings
    assert opts.forceurl
    assert opts.forcetitle
    assert opts.forceid
    assert opts.forceduration
    assert opts.forcefilename
    assert opts.forcejson
    assert opts.dump_single_json
    assert opts.dump_json
    assert opts.dump_intermediate_pages

# Generated at 2022-06-18 15:28:31.088988
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from os.path import exists
    from tempfile import mkstemp
    from shutil import move

    # Create a temporary file
    handle, confpath = mkstemp()
    # Write some lines to it
    with open(confpath, 'w') as conf:
        conf.write('--verbose\n')
        conf.write('--dump-user-agent\n')
    # Parse command-line arguments

# Generated at 2022-06-18 15:28:42.263421
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_opener
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urlretrieve
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_xml_parse_error
    from youtube_dl.compat import compat_xml_parse_response
    from youtube_dl.compat import compat_xml_parse_string
   

# Generated at 2022-06-18 15:28:48.004331
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMergerPP

    def test_parse_opts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected


# Generated at 2022-06-18 15:28:54.773355
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['-v', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '-v'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['-v', '--verbose', '--verbose'])
    assert opts.verbose == 3

# Generated at 2022-06-18 15:29:20.054186
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    argv = ['youtube-dl']
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forceduration == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False

# Generated at 2022-06-18 15:29:20.959366
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass


# Generated at 2022-06-18 15:29:30.875949
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument

# Generated at 2022-06-18 15:29:39.488425
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.extractor import gen_extractors
    gen_extractors()

# Generated at 2022-06-18 15:29:52.138461
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.version import __version__
    parser, opts, args = parseOpts(['-U', __version__, '-i', '-v', '-g', 'foobar'])
    assert opts.usenetrc
    assert opts.verbose
    assert opts.geturl
    assert opts.geo_bypass
    assert opts.geo_bypass_ip == 'foobar'
    assert opts.geo_bypass_country == 'DE'
    assert opts.username == 'foouser'
    assert opts.password == 'foopass'
    assert opts.twofactor == 'foofactor'
    assert opts.ap_username == 'fooapuser'

# Generated at 2022-06-18 15:30:03.581720
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose
    assert args == ['-i']
    parser, opts, args = parseOpts(['-i', '--get-url', '--get-title', '--get-id', '--get-thumbnail', '--get-description', '--get-filename', '--get-format', '--dump-single-json', '--newline', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.dump_single_json

# Generated at 2022-06-18 15:30:13.805099
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.usenetrc == False
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format_limit == None
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False

# Generated at 2022-06-18 15:30:21.527635
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_xml_parse_error
    from youtube_dl.compat import compat_xml_parse_response

# Generated at 2022-06-18 15:30:34.481156
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors

    def test_parse_opts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected

    test_parse_opts(
        ['--match-title', 'foo', '--match-title', 'bar'],
        {
            'matchtitle': ['foo', 'bar'],
            'match_filter': lambda info: any(re.search(p, info['title'], re.I) for p in ['foo', 'bar']),
        })

# Generated at 2022-06-18 15:30:43.044813
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(argv, expected_opts, expected_args):
        parser, opts, args = parseOpts(argv)
        assert vars(opts) == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:31:02.571705
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == []

    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:31:14.132851
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', '--ignore-config', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
   

# Generated at 2022-06-18 15:31:24.826107
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.version import __version__

    # Test default values
    parser, opts, args = parseOpts(['--simulate'])
    assert opts.simulate
    assert not opts.quiet
    assert not opts.verbose
    assert not opts.dump_intermediate_pages
    assert not opts.write_pages
    assert not opts.write_info_json
    assert not opts.write_description
    assert not opts.write_annotations
    assert not opts.write_thumbnail
    assert not opts.write_all_thumbnails
    assert not opts.list_thumbnails
    assert not opts.write_sub


# Generated at 2022-06-18 15:31:37.541040
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:31:46.794296
# Unit test for function parseOpts

# Generated at 2022-06-18 15:32:00.507598
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'plop', '-o', '%(title)s-%(id)s.%(ext)s', 'plic', 'ploc'])
    assert opts.format == 'best'
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.simulate
    assert opts.geturl
    assert opts.gettitle
    assert opts.getid
    assert opts.getthumbnail
    assert opts.getdescription
    assert opts.getfilename
    assert opts.getformat
    assert opts.no_warnings
    assert opts.quiet

# Generated at 2022-06-18 15:32:09.609892
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.get_format == False
    assert opts.usenetrc == False
    assert opts.noprogress == False
    assert opts.ratelimit == '0'

# Generated at 2022-06-18 15:32:21.116458
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', '--', 'a', 'b'])
    assert opts.verbose == True
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['a', 'b']
    parser, opts, args = parseOpts(['-v', '--', '-v'])
    assert opts.verbose == True
    assert args == ['-v']
    parser, opts, args = parseOpts(['-v', '--', '-v', '--', '-v'])
    assert opts.verbose == True
    assert args == ['-v', '--', '-v']
   

# Generated at 2022-06-18 15:32:27.520452
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMergerPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.ffmpegmetadata import FFmpegMetadataPP
    from youtube_dl.postprocessor.ffmpegthumbnail import FFmpegThumbnailPP

# Generated at 2022-06-18 15:32:38.538164
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMergerPP

    def test_parse(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:33:11.693547
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for attr, expected_value in expected_opts.items():
            assert getattr(opts, attr) == expected_value

    _test_parseOpts(
        ['--username', 'user', '--password', 'pass'],
        {'username': 'user', 'password': 'pass'})
    _test_parseOpts(
        ['--username', 'user', '--password', 'pass', '--verbose'],
        {'username': 'user', 'password': 'pass'})
    _test_parse

# Generated at 2022-06-18 15:33:19.794844
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange

# Generated at 2022-06-18 15:33:31.959000
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:33:40.705571
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:33:51.296922
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-o', '%(title)s.%(ext)s', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-o', '%(title)s.%(ext)s', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.outtm

# Generated at 2022-06-18 15:34:01.697223
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
   

# Generated at 2022-06-18 15:34:11.475348
# Unit test for function parseOpts

# Generated at 2022-06-18 15:34:21.251240
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    parser, opts, args = parseOpts(['-v', '--no-warnings', '--dump-user-agent', '--simulate', '--get-title', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.dump_user_agent
    assert opts.simulate
    assert opts.gettitle
    assert not opts.nooverwrites
    assert not opts.ignoreerrors
    assert not opts.forceurl
    assert not opts.forcetitle
    assert not opts.forceid
    assert not opts.forcedescription
    assert not opts.forcefilename
    assert not opts.forceformat
    assert not opts.forceduration


# Generated at 2022-06-18 15:34:28.849610
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.ratelimit == None
    assert opts.nooverwrites == False
    assert opts.retries == 10
    assert opts.continuedl

# Generated at 2022-06-18 15:34:36.873637
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:35:28.969448
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from tempfile import mkstemp
    from shutil import move
    from os.path import exists, dirname, join
    from youtube_dl.compat import compat_expanduser

    def _write_config_file(contents):
        fd, fn = mkstemp()
        with os.fdopen(fd, 'w') as f:
            f.write(contents)
        return fn

    def _write_config_file_with_default_contents(fn):
        _write_config_file('--default\n--default\n')

    def _write_config_file_with_contents(fn, contents):
        _write_config_file(contents)


# Generated at 2022-06-18 15:35:41.228940
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from sys import argv
    from tempfile import NamedTemporaryFile
    from unittest import TestCase

    class MockFile(StringIO):
        def close(self):
            pass

    class ParseOptsTest(TestCase):
        def setUp(self):
            self.parser, self.opts, self.args = parseOpts()

        def test_parse_opts(self):
            self.assertTrue(self.parser)
            self.assertTrue(self.opts)
            self.assertTrue(self.args)

        def test_parse_opts_with_override_arguments(self):
            self.parser, self.opts, self.args = parseOpts(['-i'])
            self.assertTrue(self.parser)

# Generated at 2022-06-18 15:35:53.245329
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP

    def check_parse_result(opts, args, expected_opts, expected_args):
        assert opts.verbose == expected_opts.verbose
        assert opts.quiet == expected_opts.quiet
        assert opts.simulate == expected_opts.simulate
        assert opts.skip_download == expected_opts.skip_download


# Generated at 2022-06-18 15:36:02.305600
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--no-warnings', '--ignore-config', '--', 'foo', 'bar'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.ignoreerrors == True
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None

# Generated at 2022-06-18 15:36:12.799885
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'plop', '-o', '%(title)s-%(id)s.%(ext)s', 'plic', 'ploc'])
    assert opts.format == 'best'
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.simulate
    assert opts.geturl
    assert opts.gettitle
    assert opts.getid
    assert opts.getthumbnail
    assert opts.getdescription
    assert opts.getfilename
    assert opts.getformat
    assert opts.no_warnings
    assert opts.quiet

# Generated at 2022-06-18 15:36:21.952100
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import mkstemp
    from os import remove, close
    from os.path import exists

    # Test with no argument
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts

# Generated at 2022-06-18 15:36:31.461495
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test_user_agent', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.video_password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.noplaylist == False
    assert opts.age_limit == None
    assert opts.download_archive == None
    assert opts.include_ads == False
    assert opts.sleep_interval == None
    assert opts.max_sleep_interval == None
    assert opts.match_filter == None
    assert opts.no

# Generated at 2022-06-18 15:36:40.396593
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-h'])
    assert opts.help
    parser, opts, args = parseOpts(['--help'])
    assert opts.help
    parser, opts, args = parseOpts(['-U', 'test'])
    assert opts.username == 'test'
    parser, opts, args = parseOpts(['--username', 'test'])
    assert opts.username == 'test'
    parser, opts, args = parseOpts(['-P', 'test'])
    assert opts.password == 'test'
    parser, opts, args = parseOpts(['--password', 'test'])
    assert opts.password == 'test'
    parser, opts, args = parseOpts(['-n'])
    assert opt

# Generated at 2022-06-18 15:36:50.786327
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import mkstemp
    from os import remove, close
    from os.path import exists
    from shutil import rmtree
    from json import loads
    from youtube_dl.utils import encodeArgument

    # Test config file
    config_data = '-f 22\n--no-playlist\n'
    config_fd, config_filename = mkstemp()
    config_file = open(config_filename, 'w')
    config_file.write(config_data)
    config_file.close()
    close(config_fd)

    # Test user config file
    user_config_data = '-f 34\n--yes-playlist\n'
    user_config_fd, user_config_filename = mkstemp()

# Generated at 2022-06-18 15:36:59.189999
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-i', '--no-playlist', '--username', 'foo', '--password', 'bar', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.noplaylist
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']