

# Generated at 2022-06-18 15:27:33.747157
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:27:44.883142
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for attr, value in expected_opts.items():
            assert getattr(opts, attr) == value


# Generated at 2022-06-18 15:27:56.320986
# Unit test for function parseOpts

# Generated at 2022-06-18 15:28:05.980520
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:28:19.036961
# Unit test for function parseOpts
def test_parseOpts():
    # Test for issue #9
    parser, opts, args = parseOpts(['-o', '-', 'foo'])
    assert opts.outtmpl == '-'
    assert args == ['foo']

    parser, opts, args = parseOpts(['-o', '-', '-a', '-'])
    assert opts.outtmpl == '-'
    assert opts.batchfile == '-'
    assert args == []

    parser, opts, args = parseOpts(['-o', '-', '-a', '-', 'foo'])
    assert opts.outtmpl == '-'
    assert opts.batchfile == '-'
    assert args == ['foo']


# Generated at 2022-06-18 15:28:24.183992
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '-a', 'test.txt', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.simulate == True
    assert opts.batchfile == 'test.txt'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:28:36.752198
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no argument
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None

# Generated at 2022-06-18 15:28:44.876874
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20150101 Firefox/47.0 (Chrome)', '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-o', '/home/user/%(title)s.%(ext)s', '-i', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_

# Generated at 2022-06-18 15:28:57.430462
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    # Test default values
    parser, opts, args = parseOpts(['--username', 'foo', '--password', 'bar'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.outtmpl == '%(id)s.%(ext)s'
    assert opts.ignoreerrors is False
    assert opts.forceurl is False
    assert opts.forcetitle is False
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.format is None
    assert opts.listformats is False
    assert opts.outtm

# Generated at 2022-06-18 15:29:07.054312
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    parser, opts, args = parseOpts(['--dateafter', 'yesterday', '--datebefore', 'today'])
    assert opts.daterange == DateRange('yesterday', 'today')
    parser, opts, args = parseOpts(['--dateafter', 'today', '--datebefore', 'yesterday'])
    assert opts.daterange is None
    parser, opts, args = parseOpts(['--dateafter', 'today'])
    assert opts.daterange == DateRange('today', None)
    parser, opts, args = parseOpts(['--datebefore', 'today'])
    assert opts.daterange == DateRange(None, 'today')

# Generated at 2022-06-18 15:29:34.781463
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-v', '-v'])
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-v', '-v', '-v'])
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-v', '-v', '-v', '-v'])
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-v', '-v', '-v', '-v', '-v'])


# Generated at 2022-06-18 15:29:48.322777
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import NamedTemporaryFile
    from os import remove
    from os.path import exists
    from shutil import copyfile
    from youtube_dl.utils import encodeArgument

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected

    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar', '--verbose'],
        {'username': 'foo', 'password': 'bar', 'verbose': True})

# Generated at 2022-06-18 15:29:53.326152
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.utils import _hide_login_info
    import os
    import sys
    import tempfile

    def _readOptions(filename):
        with open(filename, 'r') as f:
            return [l.strip() for l in f.readlines()]

    def _writeOptions(filename, opts):
        with open(filename, 'w') as f:
            f.write('\n'.join(opts))

    def _writeUserConf(opts):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            f.write('\n'.join(opts))
        return f.name


# Generated at 2022-06-18 15:30:04.340087
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:30:14.934597
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from sys import stdout
    from tempfile import NamedTemporaryFile

    def _test_parseOpts(args, expected_opts, expected_args, expected_out=None):
        if expected_out is None:
            expected_out = ''
        out = StringIO()
        old_stdout = stdout
        stdout = out
        try:
            parser, opts, args = parseOpts(args)
            assert opts.__dict__ == expected_opts
            assert args == expected_args
            assert out.getvalue() == expected_out
        finally:
            stdout = old_stdout
            out.close()


# Generated at 2022-06-18 15:30:21.989519
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    # Test for issue #1606
    # https://github.com/rg3/youtube-dl/issues/1606
    # https://github.com/rg3/youtube-dl/issues/1607
    # https://github.com/rg3/youtube-dl/issues/1608
    for opt in ['--proxy', '--socket-timeout', '--source-address']:
        parser, opts, args = parseOpts([opt, '1'])
        assert opts.__dict__[opt.lstrip('-')] == '1'

        parser, opts, args = parseOpts([opt, '1', '-x'])

# Generated at 2022-06-18 15:30:34.831024
# Unit test for function parseOpts

# Generated at 2022-06-18 15:30:43.200368
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'plop'])
    assert opts.format == 'best'
    assert opts.geturl
    assert opts.gettitle
    assert opts.getid
    assert opts.getthumbnail
    assert opts.getdescription
    assert opts.getfilename
    assert opts.get_format_limit() == -1
    assert opts.simulate
    assert opts.skip_download
    assert opts.format_limit == 'best'
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors
    assert opts.ratelimit == '0'
    assert opts.retries == 10
    assert opts.buff

# Generated at 2022-06-18 15:30:55.625169
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from tempfile import mkstemp
    from shutil import move

    # Test with no config file
    parser, opts, args = parseOpts()
    assert opts.username is None
    assert opts.password is None
    assert opts.usenetrc is False

    # Test with a config file
    fd, conf = mkstemp()
    with open(conf, 'w') as f:
        f.write('--username=test\n--password=test\n--usenetrc\n')
    move(conf, '/etc/youtube-dl.conf')
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc is True

# Generated at 2022-06-18 15:31:00.716065
# Unit test for function parseOpts

# Generated at 2022-06-18 15:31:42.771135
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forceduration == False
    assert opts.forcefilename == False

# Generated at 2022-06-18 15:31:48.375164
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forceduration == False
    assert opts.forcefilename == False
    assert opts.forcejson == False

# Generated at 2022-06-18 15:32:01.788732
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:32:10.365717
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '-c', '--no-continue', '--', 'foo', 'bar'])
    assert opts.verbose
    assert opts.simulate
    assert opts.continue_dl is False
    assert args == ['foo', 'bar']

    parser, opts, args = parseOpts(['-i', '-v', '-c', '--no-continue', '--', 'foo', 'bar'], overrideArguments=['-v', '--no-continue', '--', 'foo', 'bar'])
    assert opts.verbose
    assert opts.simulate is False
    assert opts.continue_dl is False
    assert args == ['foo', 'bar']


# Generated at 2022-06-18 15:32:21.689477
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors
    gen_extractors()

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        for attr, exp in expected.items():
            if isinstance(exp, DateRange):
                assert getattr(opts, attr).start == exp.start
                assert getattr(opts, attr).end == exp.end
            else:
                assert getattr(opts, attr) == exp

    _test_parseOpts(
        ['--match-title', 'foo', '--reject-title', 'bar'],
        {'matchtitle': ['foo'], 'rejecttitle': ['bar']})

# Generated at 2022-06-18 15:32:33.176223
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test(args, expected):
        parser, opts, args = parseOpts(args)
        assert opts.verbose == expected[0]
        assert opts.quiet == expected[1]
        assert opts.simulate == expected[2]
        assert opts.geturl == expected[3]
        assert opts.gettitle == expected[4]
        assert opts.getid == expected[5]
        assert opts.getthumb == expected[6]
        assert opts.getdescription == expected[7]
        assert opts.getfilename == expected[8]
        assert opts.getformat == expected[9]
        assert opts.username == expected[10]
        assert opts.password == expected[11]
        assert opts.twofactor

# Generated at 2022-06-18 15:32:44.557373
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_request_urlopen
    from youtube_dl.compat import compat_urllib_request_install_opener

# Generated at 2022-06-18 15:32:54.856948
# Unit test for function parseOpts

# Generated at 2022-06-18 15:33:08.190647
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected

# Generated at 2022-06-18 15:33:17.636904
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.force_generic_extractor == False
    assert opts.usetitle

# Generated at 2022-06-18 15:34:41.530694
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-o', '%(title)s.%(ext)s', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert opts.outtmpl == '%(title)s.%(ext)s'

# Generated at 2022-06-18 15:34:51.996131
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMergerPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupM3u8PP
    from youtube_dl.postprocessor.ffmpeg import FFmpegMetadataPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegAudioFixupPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoConvertorPP

# Generated at 2022-06-18 15:35:02.768627
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv

# Generated at 2022-06-18 15:35:07.639363
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['username'] = 'test'
    ydl.params['password'] = 'test'
    ydl.params['ap_mso'] = 'test'
    ydl.params['ap_username'] = 'test'
    ydl.params['ap_password'] = 'test'
    ydl.params['ap_list'] = 'test'
    ydl.params['verbose'] = True
    ydl.params['quiet'] = True
    ydl.params['no_warnings'] = True
    ydl.params['forceurl'] = True
    ydl.params['forcetitle'] = True
    ydl.params['forceid'] = True
    ydl.params['forcethumbnail'] = True
    y

# Generated at 2022-06-18 15:35:15.047414
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '-a', 'test.txt', '-o', '%(title)s-%(id)s.%(ext)s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.simulate == True
    assert opts.batchfile == 'test.txt'
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:35:27.157346
# Unit test for function parseOpts

# Generated at 2022-06-18 15:35:38.475353
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected

# Generated at 2022-06-18 15:35:51.464195
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:36:00.690310
# Unit test for function parseOpts

# Generated at 2022-06-18 15:36:10.244700
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.version import __version__

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args
