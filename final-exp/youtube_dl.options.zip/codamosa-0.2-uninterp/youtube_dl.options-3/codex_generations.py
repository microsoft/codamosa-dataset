

# Generated at 2022-06-18 15:27:55.518667
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.videopassword == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_mso == None
    assert opts.ap_list == None
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False


# Generated at 2022-06-18 15:28:05.338985
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--no-warnings', '--ignore-config', '--username', 'foo', '--password', 'bar', '--output', '%(uploader)s/%(title)s-%(id)s.%(ext)s', '--get-id', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.outtmpl == '%(uploader)s/%(title)s-%(id)s.%(ext)s'
    assert opts.geturl
    assert opts.getid
    assert opts.gettitle
    assert opts.getthumbnail

# Generated at 2022-06-18 15:28:11.093770
# Unit test for function parseOpts
def test_parseOpts():
    # Test with empty arguments
    parser, opts, args = parseOpts([])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts

# Generated at 2022-06-18 15:28:22.746188
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert args == ['-i']
    parser, opts, args = parseOpts(['-i', '--get-url', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert args == ['-i', '--get-url']

# Generated at 2022-06-18 15:28:34.652252
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False

# Generated at 2022-06-18 15:28:44.129640
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test', '-P', 'unit_test', '-u', 'unit_test', '-p', 'unit_test', '-v', '--no-warnings', '--get-url', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'unit_test'
    assert opts.password == 'unit_test'
    assert opts.usenetrc == True
    assert opts.verbose == True
    assert opts.noplaylist == False
    assert opts.proxy == None
    assert opts.ratelimit == None
    assert opts.noresizebuffer == False
    assert opts.retries == 10
    assert opts.buffersize == None

# Generated at 2022-06-18 15:28:50.731844
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'testuser', '-P', 'testpass', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'testuser'
    assert opts.password == 'testpass'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-u', 'testuser', '-p', 'testpass', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'testuser'
    assert opts.password == 'testpass'

# Generated at 2022-06-18 15:28:59.558300
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.usenetrc is False
    assert opts.username is None
    assert opts.password is None
    assert opts.ap_username is None
    assert opts.ap_password is None
    assert opts.video_password is None
    assert opts.noplaylist is True
    assert opts.forceurl is False
    assert opts.forcetitle is False
    assert opts.forcethumbnail is False
    assert opts.forcedescription is False
    assert opts.forcefilename is False
   

# Generated at 2022-06-18 15:29:11.342199
# Unit test for function parseOpts

# Generated at 2022-06-18 15:29:19.959615
# Unit test for function parseOpts

# Generated at 2022-06-18 15:29:53.613675
# Unit test for function parseOpts

# Generated at 2022-06-18 15:30:04.561048
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:30:15.012792
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == 2
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:30:22.032574
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    parser, opts, args = parseOpts(['-v', '--no-warnings', '--ignore-config', '--format=22/18/mp4/best', '--', 'foo', 'bar'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == True
    assert opts.ignore_config == True
    assert opts.format == ['22/18/mp4/best']
    assert args == ['foo', 'bar']
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
   

# Generated at 2022-06-18 15:30:34.830752
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpeg

# Generated at 2022-06-18 15:30:43.170985
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from tempfile import mkstemp
    from shutil import move

    # Test with no config file
    opts, args = parseOpts(['-v'])
    assert opts.verbose

    # Test with config file
    fd, filename = mkstemp()
    with open(filename, 'w') as f:
        f.write('-v\n')
    opts, args = parseOpts(['--config-location', filename])
    assert opts.verbose
    remove(filename)

    # Test with config file and override
    fd, filename = mkstemp()
    with open(filename, 'w') as f:
        f.write('-v\n')

# Generated at 2022-06-18 15:30:55.624221
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_opener
    from youtube_dl.compat import compat_setenv
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request_

# Generated at 2022-06-18 15:31:03.856329
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:31:15.036735
# Unit test for function parseOpts

# Generated at 2022-06-18 15:31:25.573049
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser

    def check_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:32:01.048984
# Unit test for function parseOpts

# Generated at 2022-06-18 15:32:09.948363
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP

# Generated at 2022-06-18 15:32:21.428255
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-i', '--username=user', '--password=pass', '--verbose'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.verbose
    assert opts.ignoreerrors
    assert args == []
    parser, opts, args = parseOpts(['-i', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.geturl
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:32:32.829568
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors == False
    assert opts.ratelimit == None
    assert opts.retries == 10
    assert opts.buffersize == None
    assert opts.noresizebuffer == False
    assert opts.continuedl == True
    assert opts.noprogress == False
    assert opts.playliststart == 1
    assert opts.playlistend == None
    assert opt

# Generated at 2022-06-18 15:32:44.169474
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMergerPP

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:32:54.551765
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP

    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected

    _test(['-U', 'Foo Bar 1.0'], {'user_agent': 'Foo Bar 1.0'})
    _test(['-u', 'user', '-p', 'pass'], {'username': 'user', 'password': 'pass'})
    _test(['-4'], {'forceipv4': True})
    _test

# Generated at 2022-06-18 15:33:07.808860
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test_user_agent', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.video_password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opt

# Generated at 2022-06-18 15:33:17.341728
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--username', 'foo', '--password', 'bar', '--verbose', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.geturl == True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:33:28.616478
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.username is None
    assert opts.password is None
    assert opts.usenetrc is False
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.no_warnings is False
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.format is None
    assert opts.listformats is False
    assert opts.outtmpl is None
    assert opts.autonumber_size is None
    assert opts.autonumber_start is 1
    assert opts.restrictfilenames is False
    assert opts.ignoreerrors is False
    assert opts.forceurl is False

# Generated at 2022-06-18 15:33:38.476696
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', '18', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '18'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts(['-f', '18', '-f', '22', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '22'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:34:44.634363
# Unit test for function parseOpts

# Generated at 2022-06-18 15:34:56.563771
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'foo', '-P', 'bar', '-u', 'user', '-p', 'pass', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.usenetrc == False
    assert opts.video_password == 'BaW_jenozKc'
    assert opts.ap_username == 'foo'
    assert opts.ap_password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:35:02.714868
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.outtmpl_na_placeholder == 'NA'
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.nooverwrites == False
    assert opts.continue_dl == True

# Generated at 2022-06-18 15:35:13.092306
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forceduration == False
    assert opts.forcefilename == False

# Generated at 2022-06-18 15:35:20.192054
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    parser, opts, args = parseOpts(['--dateafter', 'yesterday', '--datebefore', 'today', '--match-title', 'regex'])
    assert opts.daterange == DateRange('yesterday', 'today')
    assert opts.matchtitle == 'regex'
    assert args == []


# Generated at 2022-06-18 15:35:30.184585
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_xml_parse_error
    from youtube_dl.compat import compat_xml_parse_response
    from youtube_dl.compat import compat_xml_parse_

# Generated at 2022-06-18 15:35:43.012840
# Unit test for function parseOpts

# Generated at 2022-06-18 15:35:54.505719
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_quote
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP

    # Test default values
    parser, opts, args = parseOpts()
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.no_warnings is False
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.format is None
    assert opts.listformats is False

# Generated at 2022-06-18 15:36:03.651002
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config', '--no-check-certificate', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == 2
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.nocheckcertificate
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:36:15.133233
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    parser, opts, args = parseOpts(['--dateafter', 'yesterday', '--datebefore', 'today'])
    assert opts.daterange == DateRange('yesterday', 'today')
    parser, opts, args = parseOpts(['--date', '20050101-20060101'])
    assert opts.daterange == DateRange('20050101', '20060101')
    parser, opts, args = parseOpts(['--date', '20050101'])
    assert opts.daterange == DateRange('20050101', '20050101')
    parser, opts, args = parseOpts(['--date', '20050101-20060101', '--dateafter', 'yesterday', '--datebefore', 'today'])
