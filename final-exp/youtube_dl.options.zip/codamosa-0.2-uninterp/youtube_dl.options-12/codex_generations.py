

# Generated at 2022-06-18 15:27:35.921177
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.ignoreerrors == False

# Generated at 2022-06-18 15:27:46.834521
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert not opts.quiet
    assert not opts.no_warnings
    assert not opts.simulate
    assert not opts.skip_download
    assert not opts.format
    assert not opts.listformats
    assert not opts.list_thumbnails
    assert not opts.match_filter
    assert not opts.no_color
    assert not opts.geo_bypass
    assert not opts.geo_bypass_country
    assert not opts.geo_bypass_ip_block
    assert not opts.geo_bypass_restricted
    assert not opts.usenetrc
    assert not opts.username
    assert not opts.password
    assert not opt

# Generated at 2022-06-18 15:27:58.762086
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_xml_parse_error
    from youtube_dl.compat import compat_xml_parse_fragment
    from youtube_dl.compat import compat_xml_parse_string
    from youtube_dl.compat import compat_xml_

# Generated at 2022-06-18 15:28:07.668977
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '--verbose', '--verbose'])
    assert opts.verbose == 3
    parser, opts, args = parseOpts(['--verbose', '--quiet'])
    assert opts.verbose == 0
    parser, opts, args = parseOpts(['--verbose', '--quiet', '--quiet'])
    assert opts.verbose == -2
    parser

# Generated at 2022-06-18 15:28:20.960834
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.username is None
    assert opts.password is None
    assert opts.usenetrc is False
    assert opts.verbose is False
    assert opts.quiet is False
    assert opts.no_warnings is False
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.format is None
    assert opts.listformats is False
    assert opts.outtmpl is None
    assert opts.autonumber_size is None
    assert opts.autonumber_start is 1
    assert opts.restrictfilenames is False
    assert opts.usetitle is False
    assert opts.autonumber is False
    assert opts

# Generated at 2022-06-18 15:28:32.247330
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--username', 'foo', '--password', 'bar', '--verbose', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.geturl == True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:28:43.027198
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser, compat_getenv
    from youtube_dl.version import __version__
    from youtube_dl.postprocessor import FFmpegPostProcessor
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegMetadataPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideo

# Generated at 2022-06-18 15:28:49.054021
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
   

# Generated at 2022-06-18 15:28:55.680589
# Unit test for function parseOpts

# Generated at 2022-06-18 15:29:05.701381
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '-a', 'test.txt', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.simulate == True
    assert opts.batchfile == 'test.txt'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-i', '-v', '-a', 'test.txt', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.simulate == True
    assert opts.batchfile == 'test.txt'
   

# Generated at 2022-06-18 15:29:33.844472
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.verbose == True
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == 'bestvideo+bestaudio/best'
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
   

# Generated at 2022-06-18 15:29:46.981158
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--dump-user-agent'])
    assert opts.verbose
    assert opts.dump_user_agent
    assert opts.ignoreerrors
    assert not opts.usenetrc
    assert not opts.username
    assert not opts.password
    assert not opts.twofactor
    assert not opts.videopassword
    assert not opts.ap_username
    assert not opts.ap_password
    assert not opts.ap_mso
    assert not opts.ap_list
    assert not opts.ap_preferred
    assert not opts.noplaylist
    assert not opts.forcetitle
    assert not opts.forceid
    assert not opts.forcethumbnail

# Generated at 2022-06-18 15:29:59.376716
# Unit test for function parseOpts

# Generated at 2022-06-18 15:30:07.561634
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(args, expected_opts):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts.__dict__

    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar', '--verbose'],
        YoutubeDL({'username': 'foo', 'password': 'bar', 'verbose': True}))

# Generated at 2022-06-18 15:30:17.774374
# Unit test for function parseOpts

# Generated at 2022-06-18 15:30:31.191093
# Unit test for function parseOpts
def test_parseOpts():
    from .compat import compat_shlex_split
    parser, opts, args = parseOpts(['-U', 'unit_test_user_agent', '-f', '22/18/17/best', '-F', 'unit_test_format', '-o', 'unit_test_output', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_list == False
    assert opts

# Generated at 2022-06-18 15:30:39.154872
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:30:45.552085
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '--', '--all-subs', '--', 'foo', 'bar'])
    assert opts.format == 'best'
    assert opts.outtmpl == '%(id)s'
    assert args == [encodeArgument('--all-subs'), 'foo', 'bar']
    parser, opts, args = parseOpts(['--format=best', '--', '--all-subs', '--', 'foo', 'bar'])
    assert opts.format == 'best'
    assert opts.outtmpl == '%(id)s'
    assert args == [encodeArgument('--all-subs'), 'foo', 'bar']
    parser, opts,

# Generated at 2022-06-18 15:30:56.853865
# Unit test for function parseOpts

# Generated at 2022-06-18 15:31:04.616292
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_opener

    def _readOptions(filename):
        try:
            with compat_opener(encodeFilename(filename), 'r') as f:
                return f.read().split()
        except (IOError, OSError):
            return []

    def _readUserConf():
        xdg_config_home = compat_getenv('XDG_CONFIG_HOME') or compat_expanduser('~/.config')
        return _readOptions(os.path.join(xdg_config_home, 'youtube-dl', 'config'))

    def _hide_login_info(args):
        return

# Generated at 2022-06-18 15:31:45.331776
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    parser, opts, args = parseOpts(['--ignore-config', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'

# Generated at 2022-06-18 15:31:58.914721
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected

# Generated at 2022-06-18 15:32:04.859348
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '-c', '--no-continue', '--', '--verbose', '--', '-i'])
    assert opts.verbose == True
    assert opts.extractaudio == False
    assert opts.continue_dl == False
    assert opts.ignoreerrors == True
    assert args == ['--verbose', '--', '-i']
    parser, opts, args = parseOpts(['-i', '-v', '-c', '--no-continue', '--', '--verbose', '--', '-i'], ['-v', '--', '-i'])
    assert opts.verbose == True
    assert opts.extractaudio == False
    assert opts.continue_dl == False

# Generated at 2022-06-18 15:32:15.841937
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoConvertor

# Generated at 2022-06-18 15:32:24.314732
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_opener
    from youtube_dl.compat import compat_setenv
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_xml_parse_error
    from youtube_dl.compat import compat_xml_parse_response
    from youtube_dl.compat import compat_xml_parse_str

# Generated at 2022-06-18 15:32:35.982731
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])


# Generated at 2022-06-18 15:32:47.508020
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opt

# Generated at 2022-06-18 15:32:52.343939
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP

    def test_parse_opts(args, expected_opts):
        parser, opts, _ = parseOpts(args)

# Generated at 2022-06-18 15:32:59.905156
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['-v', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '--verbose', '--verbose'])
    assert opts.verbose == 3
    parser, opts, args = parseOpts(['--verbose', '--quiet'])
    assert opts.verbose == 1
    parser, opts, args = parseOpts(['--verbose', '--quiet', '--quiet'])
    assert opts.verbose

# Generated at 2022-06-18 15:33:12.228060
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.verbose == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.ignoreerrors == False
    assert opts.forceurl == False

# Generated at 2022-06-18 15:34:21.680421
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpeg

# Generated at 2022-06-18 15:34:29.172888
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.verbose == expected

    _test_parseOpts(['-v'], True)
    _test_parseOpts(['--verbose'], True)
    _test_parseOpts(['--verbose', '--no-verbose'], False)
    _test_parseOpts(['--verbose', '--no-verbose', '--verbose'], True)
    _test_parseOpts(['--no-verbose', '--verbose'], True)

# Generated at 2022-06-18 15:34:39.989998
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    def test_parse_opts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected_opts

# Generated at 2022-06-18 15:34:47.979208
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMergerPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpegmetadata import FFmpegMetadataPP
    from youtube_dl.postprocessor.ffmpegthumbnail import FFmpegThumbnailPP

# Generated at 2022-06-18 15:34:58.862942
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import gen_extractors
    gen_extractors()
    ydl = YoutubeDL({})
    parser, opts, args = parseOpts(ydl, overrideArguments=['-F', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.usenetrc == False
    assert opts.password == None
    assert opts.username == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_mso == None

# Generated at 2022-06-18 15:35:09.940617
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument

# Generated at 2022-06-18 15:35:16.978352
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    parser, opts, args = parseOpts(['--dateafter', 'yesterday', '--datebefore', 'today'])
    assert opts.daterange == DateRange('yesterday', 'today')
    parser, opts, args = parseOpts(['--dateafter', 'today', '--datebefore', 'yesterday'])
    assert opts.daterange is None
    parser, opts, args = parseOpts(['--dateafter', 'today'])
    assert opts.daterange == DateRange('today', None)
    parser, opts, args = parseOpts(['--datebefore', 'today'])
    assert opts.daterange == DateRange(None, 'today')

# Generated at 2022-06-18 15:35:27.570944
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])


# Generated at 2022-06-18 15:35:39.239321
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    parser, opts, args = parseOpts(['-F', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.listformats == True
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_listmso == False
    assert opts.ratelimit == None
    assert opts.retries == 10
    assert opts.buff

# Generated at 2022-06-18 15:35:52.100568
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == 3
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']