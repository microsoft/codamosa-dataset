

# Generated at 2022-06-18 15:27:46.405437
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoCon

# Generated at 2022-06-18 15:27:57.806816
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.common import PostProcessor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.downloader.external import ExternalFD
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.downloader.fragment import FragmentFD
    from youtube_dl.downloader.hls import HlsFD
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.rtmp import RtmpFD
    from youtube_dl.downloader.rtmpe import RtmpeFD

# Generated at 2022-06-18 15:28:04.452824
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str

# Generated at 2022-06-18 15:28:10.554294
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected

# Generated at 2022-06-18 15:28:14.963052
# Unit test for function parseOpts
def test_parseOpts():
    # Test for function parseOpts
    # This function is not unit tested because it is too complex
    # and it is not worth the effort to do so
    pass


# Generated at 2022-06-18 15:28:24.416206
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected


# Generated at 2022-06-18 15:28:37.642533
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose', '--config-location', '/tmp/youtube-dl.conf'])
    assert opt

# Generated at 2022-06-18 15:28:45.269401
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.verbose == expected
        assert opts.username == expected
        assert opts.password == expected
        assert opts.twofactor == expected
        assert opts.ap_mso == expected
        assert opts.ap_username == expected
        assert opts.ap_password == expected
        assert opts.ap_listid == expected
        assert opts.outtmpl == expected
        assert opts.proxy == expected
        assert opts.noprogress == expected
        assert opts.ratelimit == expected
        assert opts.retries == expected
        assert opts.buffersize == expected
        assert opts.noresizebuffer == expected

# Generated at 2022-06-18 15:28:52.008379
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from youtube_dl.compat import compat_str
    from youtube_dl.extractor import gen_extractors

# Generated at 2022-06-18 15:28:56.906766
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import mkstemp
    from os import remove, close
    from os.path import exists

    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors == False
    assert opts.ratelimit == None
    assert opts.retries == 10
    assert opts.buffersize == None
    assert opts.noresizebuffer == False
    assert opts

# Generated at 2022-06-18 15:29:26.388753
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'plop', '-u', 'user', '-p', 'pass', '-v', 'plip', 'http://plop.com/'])
    assert opts.outtmpl == '%(id)s'
    assert opts.usenetrc == False
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.format == 'best'
    assert opts.geturl == True
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumburl == False
    assert opts

# Generated at 2022-06-18 15:29:36.236837
# Unit test for function parseOpts

# Generated at 2022-06-18 15:29:50.619474
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '-u', 'user', '-p', 'pass', '-F', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.format == 'bestvideo+bestaudio'
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False

# Generated at 2022-06-18 15:29:52.568945
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod(sys.modules[__name__])


# Generated at 2022-06-18 15:30:03.882970
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '-a', 'test.txt', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.simulate == True
    assert opts.batchfile == 'test.txt'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['--verbose', '--simulate', '--batch-file', 'test.txt', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.simulate == True

# Generated at 2022-06-18 15:30:14.704879
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.nooverwrites == False
    assert opts.continue_dl == True
    assert opts.nopart == False
    assert opts.updat

# Generated at 2022-06-18 15:30:27.097993
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-o', '%(title)s.%(ext)s', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']
    opt

# Generated at 2022-06-18 15:30:37.174524
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_expanduser

    def test_parse_opts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected

    test_parse_opts(
        ['--username', 'foo', '--password', 'bar', '--verbose'],
        {'username': 'foo', 'password': 'bar', 'verbose': True})
    test_parse_opts(
        ['--username', 'foo', '--password', 'bar', '--verbose', '--no-verbose'],
        {'username': 'foo', 'password': 'bar', 'verbose': False})
    test_parse_

# Generated at 2022-06-18 15:30:44.808959
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_opener
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_response
    from youtube_dl.compat import compat_urllib_robotparser
    from youtube_dl.compat import compat_urllib_parse_urlencode

# Generated at 2022-06-18 15:30:56.416940
# Unit test for function parseOpts

# Generated at 2022-06-18 15:31:45.005449
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from tempfile import mkstemp
    from shutil import move

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        actual = vars(opts)
        assert actual == expected, '%s != %s' % (actual, expected)

    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar', '--verbose'],
        {'username': 'foo', 'password': 'bar', 'verbose': True})
    _test_parseOpts(
        ['--verbose', '--username', 'foo', '--password', 'bar'],
        {'username': 'foo', 'password': 'bar', 'verbose': True})
    _test_parseOpts

# Generated at 2022-06-18 15:31:58.868318
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor import FFmpegSubtitlesConvertorPP

    # Test for issue #1359
    parser, opts, args = parseOpts(['--format', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    ydl = YoutubeDL(opts)
    assert ydl.params['format'] == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'

    # Test for

# Generated at 2022-06-18 15:32:08.768945
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose
    assert args == ['-i']
    parser, opts, args = parseOpts(['-i', '--get-url', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose
    assert args == ['-i', '--get-url']

# Generated at 2022-06-18 15:32:20.567357
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.ignoreerrors == False
    assert opts.ratelimit == None
    assert opts.retries == 10
    assert opts.buffersize == None
    assert opts.noresizebuffer == False
    assert opts.continuedl == True
    assert opts.noprogress == False
    assert opts.playliststart == 1
   

# Generated at 2022-06-18 15:32:31.525887
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMergerPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.convert import ConvertSubtitlesPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP

# Generated at 2022-06-18 15:32:42.901514
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-f', 'best'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'

# Generated at 2022-06-18 15:32:53.408248
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from tempfile import mkstemp
    from shutil import move
    from os.path import exists

    # Create a temporary file
    fd, fname = mkstemp(prefix='youtube-dl_test_', suffix='.conf')
    f = open(fname, 'w')
    f.write('-f 22\n')
    f.write('--write-description\n')
    f.write('--write-info-json\n')
    f.close()

    # Parse command-line arguments
    argv = ['-f', '18', '--ignore-config', '--no-mtime', 'plAdelX1cA4', '--verbose']
    parser, opts, args = parseOpts(argv)

    # Check the parsed options

# Generated at 2022-06-18 15:33:04.278130
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from tempfile import mkstemp
    from shutil import move
    from os.path import exists, dirname, join
    from youtube_dl.utils import encodeArgument

    # Create a temporary config file
    fd, configfile = mkstemp(prefix='youtube-dl_test_', suffix='.conf')
    os.close(fd)

# Generated at 2022-06-18 15:33:15.095980
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-o', '%(title)s.%(ext)s', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:33:27.077954
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-i', '-v', '--no-warnings', '--ignore-config', '--', '--foo-bar', 'foobar', '-u', 'user', '-p', 'pass', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.ignoreerrors == True
    assert opts.ignoreconfig == True
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.no_warnings == True
    assert opts.simulate == False
    assert opts.format == None


# Generated at 2022-06-18 15:35:03.493699
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:35:13.576637
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import gen_extractors
    gen_extractors()
    ydl = YoutubeDL()
    ydl.params = {}
    ydl.cache.remove()
    ydl.params['username'] = 'foo'
    ydl.params['password'] = 'bar'
    ydl.params['verbose'] = True
    ydl.params['usenetrc'] = True
    ydl.params['quiet'] = True
    ydl.params['forceurl'] = True
    ydl.params['forcetitle'] = True
    ydl.params['forcethumbnail'] = True

# Generated at 2022-06-18 15:35:26.191464
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoConvertor
    from youtube_dl.postprocessor.ffmpeg import Audio

# Generated at 2022-06-18 15:35:34.348980
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_opener
    from youtube_dl.compat import compat_setenv
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_xml_parse_error
    from youtube_dl.compat import compat_xml_parse_response

# Generated at 2022-06-18 15:35:48.018763
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test_parseOpts(args, expected):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected
        assert args == []

# Generated at 2022-06-18 15:35:57.302457
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_expanduser

    # Test for issue #1744
    # https://github.com/rg3/youtube-dl/issues/1744
    #
    # The issue was that the config file was not read if the
    # --config-location argument was given.
    #
    # The test is a bit hacky, but it works.
    #
    # The test creates a config file with the --ignore-config
    # argument, and then tries to read the config file with
    # the --config-location argument.
    #
    # If the config file is read, the --ignore-config argument
    # will be overwritten, and the test will fail.
    #
    #

# Generated at 2022-06-18 15:36:05.457148
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.usenetrc == False

# Generated at 2022-06-18 15:36:16.823616
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose', '--config-location', 'test/config'])

# Generated at 2022-06-18 15:36:25.838854
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request_urlopen
    from youtube_dl.compat import compat_urlparse

# Generated at 2022-06-18 15:36:36.445660
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-f', 'best', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'