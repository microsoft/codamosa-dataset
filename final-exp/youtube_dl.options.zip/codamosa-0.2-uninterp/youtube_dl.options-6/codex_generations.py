

# Generated at 2022-06-18 15:27:40.582855
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoConvertor

# Generated at 2022-06-18 15:27:52.057891
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose
    parser, opts, args = parseOpts(['--get-id'])
    assert opts.getid
    parser, opts, args = parseOpts(['--get-thumbnail'])
    assert opts.getthumbnail
    parser, opts, args = parseOpts(['--get-description'])
    assert opts.getdescription
    parser, opts, args = parseOpts(['--get-filename'])
    assert opts.getfilename

# Generated at 2022-06-18 15:28:02.773589
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config', '--format', 'best', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == 2
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.format == 'best'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:28:09.934918
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-U', 'unit_test_user_agent', '-u', 'unit_test_username', '-p', 'unit_test_password', '-s', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'unit_test_username'
    assert opts.password == 'unit_test_password'
    assert opts.usenetrc == False
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False

# Generated at 2022-06-18 15:28:19.523359
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    argv = [argv[0]] + ['-i', '-v', '--no-warnings', '--ignore-config', '--username', 'foo', '--password', 'bar', '--verbose']
    parser, opts, args = parseOpts(argv)
    assert opts.ignoreerrors
    assert opts.verbose
    assert opts.no_warnings
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.ignoreconfig


# Generated at 2022-06-18 15:28:30.488523
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat

# Generated at 2022-06-18 15:28:41.744319
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.simulate
    assert opts.geturl
    assert opts.username is None
    assert opts.password is None
    assert opts.ap_mso is None
    assert opts.ap_username is None
    assert opts.ap_password is None
    assert opts.ap_list is None
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors
    assert opts.forceurl
    assert opts.forcetitle
    assert opts.forceid


# Generated at 2022-06-18 15:28:47.506351
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_str

    def _test_parseOpts(overrideArguments, expected_opts):
        parser, opts, args = parseOpts(overrideArguments)
        for key, value in expected_opts.items():
            assert getattr(opts, key) == value
        return opts

    # Test --get-url
    opts = _test_parseOpts(
        ['--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'],
        {'geturl': True, 'noplaylist': True})

# Generated at 2022-06-18 15:28:54.296388
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected

# Generated at 2022-06-18 15:28:59.257389
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:29:22.580881
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == 2
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:29:32.748361
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.nooverwrites == False
    assert opts.continuedl == True
    assert opts.nopart == False

# Generated at 2022-06-18 15:29:40.586613
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request_urlopen
    from youtube_dl.compat import compat_urllib_request_Request
    from youtube_dl.compat import compat_urllib_request_data
    from youtube_dl.compat import compat_urll

# Generated at 2022-06-18 15:29:53.188172
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected_opts

# Generated at 2022-06-18 15:30:04.266488
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'testuser', '-P', 'testpass', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'testuser'
    assert opts.password == 'testpass'
    assert opts.usenetrc == False
    assert opts.noplaylist == True
    assert opts.ignoreerrors == True
    assert opts.forceurl == True
    assert opts.forcethumbnail == True
    assert opts.forcetitle == True
    assert opts.forcedescription == True
    assert opts.forcefilename == True
    assert opts.forcejson == True
    assert opts.dump_intermediate_pages == True
    assert opts.write_pages

# Generated at 2022-06-18 15:30:14.934862
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'plop'])
    assert opts.format == 'best'
    assert opts.geturl
    assert opts.usenetrc is False
    assert opts.username is None
    assert opts.password is None
    assert opts.twofactor is None
    assert opts.videopassword is None
    assert opts.ap_username is None
    assert opts.ap_password is None
    assert opts.ap_mso is None
    assert opts.ap_list is None
    assert opts.outtmpl == '%(id)s.%(ext)s'
    assert opts.ignoreerrors is False
    assert opts.forceurl

# Generated at 2022-06-18 15:30:22.003568
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forceduration == False
    assert opts.forcefilename == False

# Generated at 2022-06-18 15:30:34.830773
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors
    parser, opts, args = parseOpts(['--dateafter', 'yesterday', '--datebefore', 'today', '--match-filter', 'duration <= 600', '--match-filter', '!age_limit >= 18', '--match-filter', '!is_live', '--match-filter', 'format in "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"'])
    assert opts.dateafter == DateRange('yesterday')
    assert opts.datebefore == DateRange('today')

# Generated at 2022-06-18 15:30:43.198649
# Unit test for function parseOpts
def test_parseOpts():
    # Test with empty arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.nooverwrites == False
    assert opts.continue_dl == True
    assert opts.nopart == False

# Generated at 2022-06-18 15:30:55.624041
# Unit test for function parseOpts
def test_parseOpts():
    # Test for issue #5
    parser, opts, args = parseOpts(['-o', '-'])
    assert opts.outtmpl == '-'
    parser, opts, args = parseOpts(['-o', '-', 'foo'])
    assert opts.outtmpl == '-'
    parser, opts, args = parseOpts(['-o', '-', 'foo', 'bar'])
    assert opts.outtmpl == '-'

    # Test for issue #9
    parser, opts, args = parseOpts(['-o', '%(title)s.%(ext)s', 'foo'])
    assert opts.outtmpl == '%(title)s.%(ext)s'

# Generated at 2022-06-18 15:31:40.012280
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.ignoreerrors is True

    parser, opts, args = parseOpts(['--get-id'])
    assert opts.getid is True

    parser, opts, args = parseOpts(['--get-title'])
    assert opts.gettitle is True

    parser, opts, args = parseOpts(['--get-url'])
    assert opts.geturl is True

    parser, opts, args = parseOpts(['--get-thumbnail'])
    assert opts.getthumbnail is True


# Generated at 2022-06-18 15:31:44.854776
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:31:58.663675
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange

# Generated at 2022-06-18 15:32:08.620929
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'testuser', '-P', 'testpass', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'testuser'
    assert opts.password == 'testpass'
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'
    parser, opts, args = parseOpts(['-u', 'testuser', '-p', 'testpass', '-i', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'testuser'
    assert opts.password == 'testpass'

# Generated at 2022-06-18 15:32:20.427051
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test_user_agent', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.video_password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opt

# Generated at 2022-06-18 15:32:31.440431
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:32:33.073630
# Unit test for function parseOpts
def test_parseOpts():
    import doctest
    doctest.testmod()


# Generated at 2022-06-18 15:32:44.438552
# Unit test for function parseOpts

# Generated at 2022-06-18 15:32:54.773859
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_quote
    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected_opts
        assert args == expected_args
    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar', '--verbose', '--', '--username', 'baz'],
        {'username': 'foo', 'password': 'bar', 'verbose': True},
        ['--username', 'baz'])

# Generated at 2022-06-18 15:33:08.141513
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['-v', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['-v', '--verbose', '--verbose'])
    assert opts.verbose == 3
    parser, opts, args = parseOpts(['--verbose', '-v'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '--verbose', '-v'])
    assert opts.verbose == 3
    parser, opt

# Generated at 2022-06-18 15:34:26.253359
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params = {}
    ydl.cache.store()
    ydl.cache.load()
    ydl.params = {}
    ydl.cache.store()
    ydl.cache.load()
    ydl.params = {}
    ydl.cache.store()
    ydl.cache.load()
    ydl.params = {}
    ydl.cache.store()
    ydl.cache.load()
    ydl.params = {}
    ydl.cache.store()
    ydl.cache.load()
    ydl.params = {}
    ydl.cache.store()
    ydl.cache.load()
    ydl.params = {}
    ydl.cache.store()
    ydl.cache

# Generated at 2022-06-18 15:34:32.033260
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--verbose', '--dump-user-agent', '--list-extractors', '--extractor-descriptions'])
    assert opts.verbose == 2
    assert opts.dump_user_agent
    assert opts.list_extractors
    assert opts.extractor_descriptions

    parser, opts, args = parseOpts(['-i', '-v', '--verbose', '--dump-user-agent', '--list-extractors', '--extractor-descriptions', '--ignore-config'])
    assert opts.verbose == 2
    assert opts.dump_user_agent
    assert opts.list_extractors
    assert opts.extractor_descriptions

   

# Generated at 2022-06-18 15:34:42.568350
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-h'])
    assert opts.help
    parser, opts, args = parseOpts(['--version'])
    assert opts.version
    parser, opts, args = parseOpts(['-U', 'foobar', '-P', 'hunter2', '-u', 'un', '-p', 'pw', '--username', 'un2', '--password', 'pw2', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc
    assert opts.username == 'un'
    assert opts.password == 'pw'
    assert opts.video_password == 'hunter2'

# Generated at 2022-06-18 15:34:54.268548
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import NamedTemporaryFile
    from os import remove
    from os.path import exists
    from shutil import copyfile

    # Test with no argument
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors == False
    assert opts.ratelimit == None
    assert opts.retries == 10
    assert opts.buffersize == None
    assert opts.noresizebuffer

# Generated at 2022-06-18 15:35:04.812242
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:35:14.367929
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP

# Generated at 2022-06-18 15:35:22.900403
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    parser, opts, args = parseOpts(['-i', '--dateafter', 'yesterday', '--datebefore', 'today', '--match-title', 'regex'])
    assert opts.simulate
    assert opts.dateafter == DateRange('yesterday')
    assert opts.datebefore == DateRange('today')
    assert opts.matchtitle == 'regex'
    assert args == []


# Generated at 2022-06-18 15:35:32.239732
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None

# Generated at 2022-06-18 15:35:45.073182
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from sys import argv
    from tempfile import NamedTemporaryFile
    from unittest import TestCase

    class FakeFile(StringIO):
        def close(self):
            pass

    class FakeOpener(object):
        def __init__(self, *args, **kwargs):
            pass

        def open(self, filename, mode='r'):
            if filename == '-':
                return FakeFile(u'http://example.com/')
            else:
                return FakeFile(u'# youtube-dl fake config file\n')

    class ParseOptsTest(TestCase):
        def setUp(self):
            self.parser, self.opts, self.args = parseOpts(['-U', 'test'])


# Generated at 2022-06-18 15:35:55.900344
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args

# Generated at 2022-06-18 15:36:58.430242
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected