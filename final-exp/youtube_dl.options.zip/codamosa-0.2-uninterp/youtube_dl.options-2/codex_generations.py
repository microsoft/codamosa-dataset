

# Generated at 2022-06-18 15:27:28.494212
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors
    gen_extractors()
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:27:34.364020
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '-c', '-a', 'test.txt'])
    assert opts.verbose == True
    assert opts.usenetrc == True
    assert opts.username == None
    assert opts.password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.noplaylist == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.simulate == False

# Generated at 2022-06-18 15:27:41.127520
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:27:52.862471
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.ffmpegmetadata import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedsubtitle import EmbedSubtitlePP
    from youtube_dl.postprocessor.subtitles import Sub

# Generated at 2022-06-18 15:28:03.343027
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected
    _test(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'],
          {'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'})
    _test(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-f', 'best'],
          {'format': 'best'})

# Generated at 2022-06-18 15:28:10.183786
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.get_format == False
    assert opts.usenetrc == False
    assert opts.noprogress == False
    assert opts.ratelimit == '0'
    assert opt

# Generated at 2022-06-18 15:28:19.232633
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '-a', 'test.txt', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.simulate == True
    assert opts.batchfile == 'test.txt'
    assert args[0] == 'http://www.youtube.com/watch?v=BaW_jenozKc'


# Generated at 2022-06-18 15:28:26.761367
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMergerPP

    def test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected


# Generated at 2022-06-18 15:28:39.856992
# Unit test for function parseOpts

# Generated at 2022-06-18 15:28:48.782577
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0 (Chrome)', '-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-o', '/home/user/%(title)s-%(id)s.%(ext)s', '-a', '/home/user/archive.txt', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts

# Generated at 2022-06-18 15:29:14.218824
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from sys import stdout
    from tempfile import mkstemp
    from os import remove, close, environ
    from os.path import exists
    from shutil import rmtree

    def _test_parseOpts(args, expected_opts, expected_args, expected_out, expected_err):
        global stdout
        global stderr
        global environ
        out = StringIO()
        err = StringIO()
        stdout = out
        stderr = err
        environ = {}
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected_opts
        assert args == expected_args
        assert out.getvalue() == expected_out
        assert err.getvalue() == expected_err


# Generated at 2022-06-18 15:29:21.880086
# Unit test for function parseOpts
def test_parseOpts():
    opts = parseOpts(['-i', '-v', '-a', 'test.txt', 'http://www.youtube.com/watch?v=BaW_jenozKc'])[1]
    assert opts.verbose
    assert opts.simulate
    assert opts.batchfile == 'test.txt'
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.video_password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.noplaylist == False
    assert opts.age_limit == None
    assert opts.download_archive == None
    assert opts.include_ads == False
    assert opts.playliststart == 1

# Generated at 2022-06-18 15:29:31.963169
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        actual = dict((o.dest, getattr(opts, o.dest)) for o in parser.option_list if o.dest != 'config_location')
        assert actual == expected


# Generated at 2022-06-18 15:29:40.101202
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected


# Generated at 2022-06-18 15:29:52.623062
# Unit test for function parseOpts

# Generated at 2022-06-18 15:30:03.914994
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test_user_agent', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.video_password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opt

# Generated at 2022-06-18 15:30:14.704735
# Unit test for function parseOpts
def test_parseOpts():
    # TODO: Add more tests
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_

# Generated at 2022-06-18 15:30:21.837086
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_opener
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_strptime
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_xml_parse_error

# Generated at 2022-06-18 15:30:34.756964
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def test_parse_opts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected_opts


# Generated at 2022-06-18 15:30:43.110190
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None

# Generated at 2022-06-18 15:31:04.867512
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        actual = [encodeArgument(a) for a in parser.option_list]
        assert actual == expected

    _test(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'],
          ['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])

# Generated at 2022-06-18 15:31:16.420496
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP

# Generated at 2022-06-18 15:31:26.476261
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for attr, value in expected_opts.items():
            assert getattr(opts, attr) == value


# Generated at 2022-06-18 15:31:39.300085
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for attr, expected_value in expected_opts.items():
            assert getattr(opts, attr) == expected_value


# Generated at 2022-06-18 15:31:45.596986
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forceduration == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.dump_json == False


# Generated at 2022-06-18 15:31:58.963941
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-i', '--username=user', '--password=pass', '--verbose', '--ignore-config', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.verbose == True
    assert opts.ignoreconfig == True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:32:08.839074
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:32:17.561019
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.geturl == True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:32:25.410152
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opt

# Generated at 2022-06-18 15:32:36.735397
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts

# Generated at 2022-06-18 15:33:14.787063
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'username'
    assert opts.password == 'password'
    assert opts.twofactor == 'twofactor'
    assert opts.videopassword == 'videopassword'
    assert opts.ap_username == 'ap_username'
    assert opts.ap_password == 'ap_password'
    assert opts.ap_mso == 'ap_mso'
    assert opts.ap_list == 'ap_list'
    assert opts.outtmpl == 'outtmpl'
    assert opts.outtmpl_na_placeholder == 'outtmpl_na_placeholder'
    assert opts.autonumber_size == 'autonumber_size'
    assert opts.autonumber_

# Generated at 2022-06-18 15:33:21.613957
# Unit test for function parseOpts

# Generated at 2022-06-18 15:33:33.462196
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--no-warnings', '--ignore-config', '--', 'foo', 'bar'])
    assert opts.verbose == True
    assert opts.ignoreerrors == True
    assert opts.no_warnings == True
    assert opts.ignoreconfig == True
    assert args == ['foo', 'bar']
    parser, opts, args = parseOpts(['-U', 'foobar', '-P', 'hunter2', '--', 'foo', 'bar'])
    assert opts.username == 'foobar'
    assert opts.password == 'hunter2'
    assert args == ['foo', 'bar']

# Generated at 2022-06-18 15:33:41.481617
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:33:52.412875
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP

# Generated at 2022-06-18 15:34:02.481709
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:34:12.661781
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv

    # Test for issue #2693
    # https://github.com/rg3/youtube-dl/issues/2693
    # https://github.com/rg3/youtube-dl/issues/2694
    # https://github.com/rg3/youtube-dl/issues/2695
    # https://github.com/rg3/youtube-dl/issues/2696
    # https://github.com/rg3/youtube-dl/issues/2697
    # https://github.com/rg3/youtube-dl/issues/2698
    # https://github.com/rg3/youtube-

# Generated at 2022-06-18 15:34:20.380305
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'testuser', '-P', 'testpass', '-i', '-v', '-a', 'test.txt', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'testuser'
    assert opts.password == 'testpass'
    assert opts.usenetrc == True
    assert opts.verbose == True
    assert opts.batchfile == 'test.txt'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:34:27.432137
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forceduration == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.dump_json == False

# Generated at 2022-06-18 15:34:38.294570
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def check_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        actual = dict((o.dest, getattr(opts, o.dest)) for o in parser.option_list)
        assert actual == expected
    check_parseOpts(
        ['--username', 'foo', '--password', 'bar'],
        {'username': 'foo', 'password': 'bar'})
    check_parseOpts(
        ['--username', 'foo', '--password', 'bar', '--no-check-certificate'],
        {'username': 'foo', 'password': 'bar', 'nocheckcertificate': True})

# Generated at 2022-06-18 15:35:47.645294
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_xml_parse_error
    from youtube_dl.compat import compat_xml_parse_response

# Generated at 2022-06-18 15:35:57.062056
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors is False
    assert opts.ratelimit == '0'
    assert opts.retries == 10
    assert opts.buffersize == '1024'
    assert opts.noprogress is False
    assert opts.playliststart == 1
    assert opts.playlistend == -1
    assert opts.n

# Generated at 2022-06-18 15:36:05.314816
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import NamedTemporaryFile
    from os import remove
    from os.path import exists

    # Test config file
    with NamedTemporaryFile(mode='w', delete=False) as configfile:
        configfile.write('-o test.%%(ext)s\n')
        configfile.write('--no-mtime\n')
        configfile.write('--verbose\n')
        configfile.write('--dump-user-agent\n')
        configfile.write('--list-extractors\n')
        configfile.write('--extractor-descriptions\n')
        configfile.write('--ignore-errors\n')
        configfile.write('--no-warnings\n')
        configfile.write('--simulate\n')

# Generated at 2022-06-18 15:36:16.782313
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.video_password == None
    assert opts.ap_mso == None
    assert opts.ap_list == None
    assert opts.outtmpl == None
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opt

# Generated at 2022-06-18 15:36:24.135754
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts, expected_args, expected_outtmpl, expected_outtmpl_na_placeholder):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args
        assert opts.outtmpl == expected_outtmpl
        assert opts.outtmpl_na_placeholder == expected_outtmpl_na_placeholder


# Generated at 2022-06-18 15:36:34.323613
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:36:42.129664
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == ['bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best']
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors is False
    assert opts.forceurl is False
    assert opts.forcetitle is False
    assert opts.forceid is False
    assert opts.force_generic_extractor

# Generated at 2022-06-18 15:36:52.208167
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.postprocessor import FFmpegMergerPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupM3u8PP

# Generated at 2022-06-18 15:37:00.070584
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import prepend_extension
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_request_urlopen
    from youtube_dl.compat import compat_urllib_request_build_opener
    from youtube_dl.compat import compat_urllib_request_install_opener
   