

# Generated at 2022-06-18 15:27:47.113840
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.extractor import gen_extractors
    gen_extractors()

    def test_parseOpts_inner(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:27:58.961910
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None

# Generated at 2022-06-18 15:28:07.836723
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.ignoreerrors == False
    assert opts.ratelimit == None
    assert opts.retries == 10
    assert opts.buffersize == None
    assert opts.noresizebuffer == False
    assert opts.continuedl == True
    assert opts.noprogress == False
    assert opts.playliststart == 1
   

# Generated at 2022-06-18 15:28:20.976137
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument

    # Test that -o - is handled correctly
    parser, opts, args = parseOpts(['-o', '-'])
    assert opts.outtmpl == '-'

    # Test that -o - is handled correctly with --
    parser, opts, args = parseOpts(['-o', '-', '--'])
    assert opts.outtmpl == '-'

    # Test that -o - is handled correctly with --
    parser, opts, args = parseOpts(['-o', '-', '--', 'foo'])
    assert opts.outtmpl == '-'

    # Test that -o - is handled correctly with --
    parser, opts, args = parseOpts(['-o', '-', '--', 'foo', 'bar'])


# Generated at 2022-06-18 15:28:32.298388
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected
    test(
        ['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'],
        {'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'})
    test(
        ['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '--format', '22'],
        {'format': '22'})

# Generated at 2022-06-18 15:28:38.040834
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpeg

# Generated at 2022-06-18 15:28:46.773204
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument

    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:28:53.627570
# Unit test for function parseOpts
def test_parseOpts():
    # Test for issue #8
    parser, opts, args = parseOpts(['-o', '-'])
    assert opts.outtmpl == '-'
    assert args == []

    parser, opts, args = parseOpts(['-o', '-', 'foo'])
    assert opts.outtmpl == '-'
    assert args == ['foo']

    parser, opts, args = parseOpts(['-o', '-', '-a', '-'])
    assert opts.outtmpl == '-'
    assert opts.batchfile == '-'
    assert args == []

    parser, opts, args = parseOpts(['-o', '-', '--', 'foo'])
    assert opts.outtmpl == '-'
    assert args == ['foo']

    parser, opts,

# Generated at 2022-06-18 15:29:01.340697
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_opener
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urlparse

    def _readOptions(filename):
        if not os.path.exists(filename):
            return []

# Generated at 2022-06-18 15:29:13.343242
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from tempfile import mkstemp
    from youtube_dl.utils import encodeArgument

    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected

    _test([], {})
    _test(['-h'], {'help': True})
    _test(['-v'], {'verbose': True})
    _test(['-U'], {'update_self': True})
    _test(['-u', 'user'], {'username': 'user'})
    _test(['-p', 'pass'], {'password': 'pass'})
    _test(['-2'], {'twofactor': None})

# Generated at 2022-06-18 15:29:50.418143
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert not opts.quiet
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors
    assert opts.ratelimit == '0'
    assert opts.retries == 10
    assert opts.buffersize == '1024'
    assert opts.noprogress
    assert opts.playliststart == 1
    assert opts.playlistend == 0
    assert opts.nooverwrites
    assert opts.forcetitle
    assert opts.forceurl
    assert opts.forcethumbnail
    assert opts.forcedescription
    assert opts.forcefilename
    assert opts.forced

# Generated at 2022-06-18 15:30:02.095727
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP

    def test_parse_opts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:30:09.179780
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        return parser, opts, args

    def _test_parseOpts_raises(args, expected_msg):
        try:
            parser, opts, args = parseOpts(args)
        except (optparse.OptionValueError, ValueError) as err:
            assert str(err) == expected_msg
        else:
            assert False, 'Expected exception not raised'

    # Test --version

# Generated at 2022-06-18 15:30:18.998335
# Unit test for function parseOpts

# Generated at 2022-06-18 15:30:32.031392
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-f', 'best'])
    assert opts.format == 'best'
    opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-f', 'worst'])

# Generated at 2022-06-18 15:30:40.858500
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert not opts.quiet
    assert not opts.no_warnings
    assert not opts.simulate
    assert not opts.skip_download
    assert not opts.format
    assert not opts.listformats
    assert not opts.list_thumbnails
    assert not opts.dump_user_agent
    assert not opts.dump_interfaces
    assert not opts.dump_json
    assert not opts.print_traffic
    assert not opts.call_home
    assert not opts.no_color
    assert not opts.no_progress
    assert not opts.console_title
    assert not opts.playliststart
    assert not opts.playlistend

# Generated at 2022-06-18 15:30:53.420537
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMergerPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP

    def test_parse_opts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for key, value in expected_opts.items():
            assert getattr(opts, key) == value

    test_parse_opts(
        ['--username', 'user', '--password', 'pass', '--verbose'],
        {'username': 'user', 'password': 'pass', 'verbose': True})

# Generated at 2022-06-18 15:31:02.372313
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.usetitle == False
    assert opts.nooverwrites == False

# Generated at 2022-06-18 15:31:14.089569
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument

# Generated at 2022-06-18 15:31:24.782899
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from youtube_dl.utils import encodeArgument

    def _parseOpts(args):
        parser, opts, args = parseOpts(args)
        return opts

    assert _parseOpts(['-h']) is None
    assert _parseOpts(['--help']) is None
    assert _parseOpts(['--get-url']) is None
    assert _parseOpts(['--get-title']) is None
    assert _parseOpts(['--get-id']) is None
    assert _parseOpts(['--get-thumbnail']) is None
    assert _parseOpts(['--get-description']) is None
    assert _parseOpts(['--get-filename']) is None
    assert _parseOpts(['--get-format']) is None


# Generated at 2022-06-18 15:32:09.853819
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    argv = ['--username', 'foo', '--password', 'bar', '--verbose']
    parser, opts, args = parseOpts()
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose
    assert not args


# Generated at 2022-06-18 15:32:21.349251
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    def test_parse_opts(args, expected_opts, expected_args, expected_postprocessors):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args

# Generated at 2022-06-18 15:32:32.725791
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '-a', 'test.txt', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.simulate == True
    assert opts.batchfile == 'test.txt'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['--ignore-config', '-v', '-a', 'test.txt', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.simulate == True
    assert opts.batchfile == 'test.txt'

# Generated at 2022-06-18 15:32:44.057427
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import is_win32

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)

# Generated at 2022-06-18 15:32:54.460880
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose

    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['--verbose', '--verbose'])
    assert opts.verbose == 2

    parser, opts, args = parseOpts(['--verbose', '--no-verbose'])
    assert opts.verbose == 0

    parser, opts, args = parseOpts(['--verbose', '--no-verbose', '--verbose'])
    assert opts.verbose == 1

    parser, opts, args = parseOpts(['--verbose', '--no-verbose', '--no-verbose'])

# Generated at 2022-06-18 15:33:07.602292
# Unit test for function parseOpts
def test_parseOpts():
    # Test for issue #979
    parser, opts, args = parseOpts(['-o', '-'])
    assert opts.outtmpl == '-'
    assert args == []

    # Test for issue #979
    parser, opts, args = parseOpts(['-o', '-', 'foo'])
    assert opts.outtmpl == '-'
    assert args == ['foo']

    # Test for issue #979
    parser, opts, args = parseOpts(['-o', '-', '-a', '-'])
    assert opts.outtmpl == '-'
    assert opts.batchfile == '-'
    assert args == []

    # Test for issue #979

# Generated at 2022-06-18 15:33:17.183994
# Unit test for function parseOpts

# Generated at 2022-06-18 15:33:28.408527
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:33:38.356416
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == ['bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best']
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-f', 'best'])
    assert opts.format == ['bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'best']

# Generated at 2022-06-18 15:33:44.468820
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', '--ignore-config', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
   

# Generated at 2022-06-18 15:35:23.379318
# Unit test for function parseOpts
def test_parseOpts():
    import sys
    sys.argv = [sys.argv[0], '-v', '-c', '-o', '%(title)s.%(ext)s']
    parser, opts, args = parseOpts()
    assert opts.verbose == True
    assert opts.continue_dl == True
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert args == []


# Generated at 2022-06-18 15:35:32.578153
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test_user_agent', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.videopassword == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_mso == None
    assert opts.ap_list == None
    assert opts.usenetrc_machine == None
    assert opts.usenetrc_password == None
    assert opts.usenetrc_username == None
    assert opts.usenetrc_password == None
    assert opts.usen

# Generated at 2022-06-18 15:35:45.454053
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_str
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoConvertor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmb

# Generated at 2022-06-18 15:35:56.070199
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:36:04.677428
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import gen_extractors
    gen_extractors()
    ydl = YoutubeDL()
    ydl.params = {}
    ydl.cache.remove()
    ydl.params['noplaylist'] = True
    ydl.params['ignoreerrors'] = True
    ydl.params['forceurl'] = True
    ydl.params['forcethumbnail'] = True
    ydl.params['forcetitle'] = True
    ydl.params['forceid'] = True
    ydl.params['forcedescription'] = True
    ydl.params['forcefilename'] = True

# Generated at 2022-06-18 15:36:16.479928
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:36:23.905455
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from tempfile import mkstemp
    from shutil import move
    from os.path import exists

    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None

# Generated at 2022-06-18 15:36:34.112687
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupM3u8PP

# Generated at 2022-06-18 15:36:42.081565
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.nooverwrites == False
    assert opts.continue_dl == True
    assert opts.nopart == False
    assert opts.up

# Generated at 2022-06-18 15:36:52.162870
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP

    def test_parse_opts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args
