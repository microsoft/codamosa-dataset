

# Generated at 2022-06-18 15:27:47.836505
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP

    def test_parse_opts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected_opts


# Generated at 2022-06-18 15:27:59.639895
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    argv = ['youtube-dl']
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts

# Generated at 2022-06-18 15:28:07.074807
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected

# Generated at 2022-06-18 15:28:20.346045
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_quote
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
   

# Generated at 2022-06-18 15:28:31.410294
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:28:42.485731
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_ur

# Generated at 2022-06-18 15:28:48.415637
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.videopassword == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_mso == None
    assert opts.ap_list == None
    assert opts.usenetrc_machine == None
    assert opts.usenetrc_password == None
    assert opts.usenetrc_username == None

# Generated at 2022-06-18 15:28:55.150298
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_opener
    from youtube_dl.compat import compat_setenv
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import getproxies
    from youtube_dl.compat import is_py2

# Generated at 2022-06-18 15:29:04.317038
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-f', 'best', '--', 'http://www.youtube.com/watch?v=BaW_jenozKc', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'

# Generated at 2022-06-18 15:29:16.313287
# Unit test for function parseOpts

# Generated at 2022-06-18 15:29:37.449569
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--username', 'foo', '--password', 'bar', '--verbose', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.geturl == True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:29:50.861023
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for key, value in expected_opts.items():
            assert getattr(opts, key) == value


# Generated at 2022-06-18 15:30:02.525690
# Unit test for function parseOpts
def test_parseOpts():
    from .compat import compat_shlex_split
    from .utils import encodeArgument

    def test_parse_opts(args, expected):
        parser, opts, _ = parseOpts(compat_shlex_split(encodeArgument(args)))
        assert vars(opts) == expected

    test_parse_opts('-F', {'format': 'best'})
    test_parse_opts('-f best', {'format': 'best'})
    test_parse_opts('-f best -f worst', {'format': 'worst'})
    test_parse_opts('-f best -f mp4', {'format': 'mp4'})
    test_parse_opts('-f best -f "mp4 video"', {'format': 'mp4 video'})
    test_

# Generated at 2022-06-18 15:30:03.193543
# Unit test for function parseOpts
def test_parseOpts():
    # TODO
    pass


# Generated at 2022-06-18 15:30:09.013968
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    parser, opts, args = parseOpts(['--dateafter', 'yesterday', '--datebefore', 'today'])
    assert opts.dateafter == DateRange('yesterday')
    assert opts.datebefore == DateRange('today')
    parser, opts, args = parseOpts(['--dateafter', 'now-1day', '--datebefore', 'now'])
    assert opts.dateafter == DateRange('now-1day')
    assert opts.datebefore == DateRange('now')
    parser, opts, args = parseOpts(['--dateafter', 'now-1day', '--datebefore', 'now-1day'])
    assert opts.dateafter == DateRange('now-1day')

# Generated at 2022-06-18 15:30:18.999910
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument

# Generated at 2022-06-18 15:30:32.032432
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors
    gen_extractors()
    parser, opts, args = parseOpts(['-F', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert opts.listformats == True
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_listmso == False
    assert opt

# Generated at 2022-06-18 15:30:40.821095
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:30:53.373688
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected


# Generated at 2022-06-18 15:31:02.338878
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from sys import stdout
    from tempfile import mkstemp
    from os import remove, close, environ

    def _test(args, expected_opts, expected_args, expected_out=None, expected_err=None, expected_retcode=0,
              config=None, env=None):
        if config is not None:
            fd, config_filename = mkstemp()
            with open(config_filename, 'w') as f:
                f.write(config)
            args += ['--config-location', config_filename]
        if env is not None:
            env_ = environ.copy()
            env_.update(env)
        else:
            env_ = None
        out = StringIO()
        err = StringIO()
        retcode = 0

# Generated at 2022-06-18 15:31:39.573952
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected
    _test(
        ['--username', 'foo', '--password', 'bar', '--verbose'],
        {'username': 'foo', 'password': 'bar', 'verbose': True})
    _test(
        ['--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config'],
        {'username': 'foo', 'password': 'bar', 'verbose': True})

# Generated at 2022-06-18 15:31:44.531529
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test(args, expected):
        parser, opts, args = parseOpts(args)
        assert opts.verbose == expected
    _test(['-v'], True)
    _test(['--verbose'], True)
    _test(['--no-verbose'], False)
    _test(['--verbose', '--no-verbose'], False)
    _test(['--no-verbose', '--verbose'], True)
    _test(['-v', '--no-verbose'], False)
    _test(['--no-verbose', '-v'], True)
    _test(['-v', '-v'], True)

# Generated at 2022-06-18 15:31:58.214824
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['-v', '--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose', '-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['-v', '--verbose', '--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose', '--verbose', '-v'])
    assert opts.verbose

# Generated at 2022-06-18 15:32:08.224722
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected

    _test_parseOpts(
        ['--username', 'user', '--password', 'pass'],
        {'username': 'user', 'password': 'pass'})
    _test_parseOpts(
        ['--username', 'user', '--password', 'pass', '--verbose'],
        {'username': 'user', 'password': 'pass', 'verbose': True})

# Generated at 2022-06-18 15:32:20.079893
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '--', '--all-subs', '--no-warnings', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'
    assert args == [encodeArgument('--all-subs'), encodeArgument('--no-warnings'), 'https://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['--format=best', '--', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'best'

# Generated at 2022-06-18 15:32:26.942697
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:32:37.863416
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None

# Generated at 2022-06-18 15:32:43.327699
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:32:53.876525
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors

# Generated at 2022-06-18 15:33:05.660016
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.ignoreerrors == False
    assert opts.forceurl == False

# Generated at 2022-06-18 15:34:03.844213
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '-v', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-i', '--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.username == None
    assert opts.password == None
    assert opts.verbose == False

# Generated at 2022-06-18 15:34:13.184276
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args

    # Test parsing of options

# Generated at 2022-06-18 15:34:22.547690
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'plop'])
    assert opts.format == 'best'
    assert opts.geturl
    assert opts.simulate
    assert not opts.gettitle
    assert not opts.getid
    assert not opts.getthumb
    assert not opts.getdescription
    assert not opts.getfilename
    assert not opts.getformat
    assert not opts.usetitle
    assert not opts.autonumber
    assert not opts.quiet
    assert not opts.no_warnings
    assert not opts.verbose
    assert not opts.dump_intermediate_pages
    assert not opts.writeinfojson
    assert not opts

# Generated at 2022-06-18 15:34:29.978648
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def test(args, expected):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected

# Generated at 2022-06-18 15:34:41.071896
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_xml_parse_error
    from youtube_dl.compat import compat_xml_parse_fragment
    from youtube_dl.compat import compat_xml_

# Generated at 2022-06-18 15:34:48.676033
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser


# Generated at 2022-06-18 15:34:57.451144
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--no-playlist', '--youtube-skip-dash-manifest', '--verbose', '--get-url', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.geturl == True
    assert opts.noplaylist == True
    assert opts.youtube_skip_dash_manifest == True
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:35:03.501867
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    argv = ['youtube-dl']
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False

# Generated at 2022-06-18 15:35:13.626582
# Unit test for function parseOpts
def test_parseOpts():
    # Test for issue #6
    # https://github.com/rg3/youtube-dl/issues/6
    parser, opts, args = parseOpts(['-f', '22/18/17/36', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '22/18/17/36'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

    # Test for issue #9
    # https://github.com/rg3/youtube-dl/issues/9

# Generated at 2022-06-18 15:35:26.244553
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected
