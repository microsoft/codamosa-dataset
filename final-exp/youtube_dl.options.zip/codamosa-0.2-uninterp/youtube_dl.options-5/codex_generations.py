

# Generated at 2022-06-18 15:27:46.926765
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.verbose == expected['verbose']
        assert opts.quiet == expected['quiet']
        assert opts.simulate == expected['simulate']
        assert opts.geturl == expected['geturl']
        assert opts.gettitle == expected['gettitle']
        assert opts.getid == expected['getid']
        assert opts.getthumb == expected['getthumb']
        assert opts.getdescription == expected['getdescription']
        assert opts.getfilename == expected['getfilename']
        assert opts.getformat == expected['getformat']
        assert opt

# Generated at 2022-06-18 15:27:58.863303
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-f', 'best'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best+best'

# Generated at 2022-06-18 15:28:06.193039
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected


# Generated at 2022-06-18 15:28:19.283219
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'best', '-g', 'plop'])
    assert opts.format == 'best'
    assert opts.geturl
    assert opts.gettitle
    assert opts.getid
    assert opts.getthumbnail
    assert opts.getdescription
    assert opts.getfilename
    assert opts.get_format_limit() == -1
    assert opts.simulate
    assert opts.skip_download
    assert opts.format_limit == 'best'
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors
    assert opts.forceurl
    assert opts.forcethumbnail
    assert opts.forcedescription

# Generated at 2022-06-18 15:28:26.789343
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os import remove
    from tempfile import mkstemp
    from shutil import move

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected

    _test_parseOpts(['-h'], {'help': True})
    _test_parseOpts(['--help'], {'help': True})
    _test_parseOpts(['-U', 'FooBar'], {'updatetime': False})
    _test_parseOpts(['--no-mtime'], {'updatetime': False})
    _test_parseOpts(['-u', 'FooBar'], {'username': 'FooBar'})

# Generated at 2022-06-18 15:28:39.857718
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--no-warnings', '--ignore-config', '--', 'foo', 'bar'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.ignoreerrors == True
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None

# Generated at 2022-06-18 15:28:48.782990
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']


# Generated at 2022-06-18 15:28:55.491030
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert not opts.quiet
    parser, opts, args = parseOpts(['-q'])
    assert not opts.verbose
    assert opts.quiet
    parser, opts, args = parseOpts(['-v', '-q'])
    assert opts.verbose
    assert opts.quiet
    parser, opts, args = parseOpts(['-v', '-v'])
    assert opts.verbose
    assert opts.verbose_count == 2
    parser, opts, args = parseOpts(['-v', '-v', '-q'])
    assert opts.verbose
    assert opts.verbose_count == 2
    assert opts.quiet

# Generated at 2022-06-18 15:29:05.006813
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfil

# Generated at 2022-06-18 15:29:16.773653
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose

    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-v', '--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-v', '--verbose', '--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-v', '--verbose', '--verbose', '--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-v', '--verbose', '--verbose', '--verbose', '--verbose'])


# Generated at 2022-06-18 15:29:39.921830
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.verbose == 2
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.usenetrc == False

    parser, opts, args = parseOpts(['-v', '--usenetrc', '--verbose'])
    assert opts.verbose == 2
    assert opts.username == None
    assert opts.password == None
    assert opts.usenetrc == True

    parser, opts, args = parseOpts(['-v', '--usenetrc', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts

# Generated at 2022-06-18 15:29:52.527088
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--no-playlist', '--youtube-skip-dash-manifest', '--', 'foo', 'bar'])
    assert opts.ignoreerrors
    assert opts.noplaylist
    assert opts.youtube_skip_dash_manifest
    assert args == ['foo', 'bar']

    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'

    parser, opts, args = parseOpts(['-f', '22/17/36'])

# Generated at 2022-06-18 15:30:03.874848
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP

    def _test_parse_opts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for attr, exp_val in expected_opts.items():
            assert getattr(opts, attr) == exp_val

    # Test --get-filename
    _test_parse_opts(
        ['--get-filename'],
        {'getfilename': True})

    # Test

# Generated at 2022-06-18 15:30:14.661297
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose', '--ignore-config'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True

# Generated at 2022-06-18 15:30:21.839423
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(overrideArguments, expected_opts, expected_args):
        parser, opts, args = parseOpts(overrideArguments)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:30:34.745087
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:30:43.109282
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def _test(args, expected):
        parser, opts, _ = parseOpts(args)
        assert opts.__dict__ == expected

# Generated at 2022-06-18 15:30:55.626293
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP

# Generated at 2022-06-18 15:31:00.715438
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    parser, opts, args = parseOpts(['-o', '%(title)s.%(ext)s', '--', 'foo'])
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert args == ['foo']
    parser, opts, args = parseOpts(['-o', '%(title)s.%(ext)s', '--', 'foo', 'bar'])
    assert opts.outtmpl == '%(title)s.%(ext)s'
    assert args == ['foo', 'bar']

# Generated at 2022-06-18 15:31:12.140277
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.utils import _hide_login_info
    from youtube_dl.version import __version__
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSub

# Generated at 2022-06-18 15:31:47.503943
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', '-f', 'best'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best+best'

# Generated at 2022-06-18 15:32:01.275819
# Unit test for function parseOpts

# Generated at 2022-06-18 15:32:10.055874
# Unit test for function parseOpts
def test_parseOpts():
    # Test with no arguments
    parser, opts, args = parseOpts([])
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(id)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forceduration == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts

# Generated at 2022-06-18 15:32:21.544944
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import gen_extractors
    gen_extractors()

# Generated at 2022-06-18 15:32:32.985875
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def test_parseOpts_helper(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for opt_name, opt_value in expected_opts.items():
            assert getattr(opts, opt_name) == opt_value

    # Test --verbose
    test_parseOpts_helper(['--verbose'], {'verbose': True})
    test_parseOpts_helper(['--verbose', '--verbose'], {'verbose': True})
    test_parseOpts_helper(['--no-verbose'], {'verbose': False})
    test_parse

# Generated at 2022-06-18 15:32:44.329317
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['-v', '-v'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['-v', '-v', '-v'])
    assert opts.verbose == 3
    parser, opts, args = parseOpts(['-v', '-v', '-v', '-v'])
    assert opts.verbose == 4
    parser, opts, args = parseOpts(['-v', '-v', '-v', '-v', '-v'])
    assert opts.verbose == 5

# Generated at 2022-06-18 15:32:54.771366
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import mkstemp
    from os import remove, close
    from os.path import exists
    from shutil import move

    # Test for reading config files
    fd, conf = mkstemp()
    try:
        with open(conf, 'w') as f:
            f.write('-o test\n')
        parser, opts, args = parseOpts(['-v'])
        assert opts.outtmpl == 'test'
        assert opts.verbose
    finally:
        close(fd)
        remove(conf)

    # Test for overriding config files
    fd, conf = mkstemp()

# Generated at 2022-06-18 15:33:08.190044
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os.path import dirname, join
    from tempfile import mkstemp
    from shutil import copyfileobj
    from os import close, remove
    from youtube_dl.utils import encodeArgument

    def _write_config(config_lines):
        fd, config_filename = mkstemp()
        config_file = open(config_filename, 'w')
        config_file.write('\n'.join(config_lines))
        config_file.close()
        close(fd)
        return config_filename

    def _test_parseOpts(args, expected_opts, expected_args, config_lines=None):
        if config_lines is not None:
            config_filename = _write_config(config_lines)

# Generated at 2022-06-18 15:33:17.638582
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.ignoreerrors == False
    assert opts.forceurl == False

# Generated at 2022-06-18 15:33:29.035936
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL

# Generated at 2022-06-18 15:34:43.692032
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:34:55.863399
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    parser, opts, args = parseOpts(['-U', 'testuseragent'])
    assert opts.user_agent == 'testuseragent'

    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['--dump-user-agent'])
    assert opts.dump_user_agent

    parser, opts, args = parseOpts(['--list-extractors'])
    assert opts.list_extractors

    parser, opts, args = parseOpts(['--extractor-descriptions'])

# Generated at 2022-06-18 15:35:06.788852
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL

# Generated at 2022-06-18 15:35:12.901758
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test_user_agent', '-f', '22/18/17/best', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.video_password == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forcetitle == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False


# Generated at 2022-06-18 15:35:25.131824
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from tempfile import NamedTemporaryFile
    from os import remove
    from os.path import exists
    from shutil import rmtree
    from youtube_dl.utils import encodeArgument

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for key, value in expected_opts.items():
            assert getattr(opts, key) == value

    _test_parseOpts(
        ['--username', 'foo', '--password', 'bar', '--verbose'],
        {'username': 'foo', 'password': 'bar', 'verbose': True})

# Generated at 2022-06-18 15:35:33.769449
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser, compat_getenv
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP

# Generated at 2022-06-18 15:35:47.639187
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _run_parseOpts(args):
        parser, opts, _ = parseOpts(args)
        return parser, opts

    def _run_parseOpts_YDL(args):
        parser, opts, _ = parseOpts(args)
        ydl = YoutubeDL(opts)
        return parser, ydl

    # Test --version
    parser, opts = _run_parseOpts(['--version'])
    assert opts.version
    assert not opts.verbose

    # Test -v
    parser, opts = _run_parseOpts(['-v'])
    assert opts.verbose

# Generated at 2022-06-18 15:35:57.032485
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['-v', '--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['-v', '--verbose', '--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['-v', '--verbose', '--verbose', '--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['-v', '--verbose', '--verbose', '--verbose', '--verbose'])


# Generated at 2022-06-18 15:36:05.325761
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_mso == None

# Generated at 2022-06-18 15:36:16.784788
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split

    def _test_parseOpts(args, expected):
        parser, opts, _ = parseOpts(args)
        assert vars(opts) == expected
