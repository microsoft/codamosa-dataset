

# Generated at 2022-06-18 15:27:34.264686
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forceduration == False
    assert opts.forcefilename == False
    assert opts.forcejson == False

# Generated at 2022-06-18 15:27:45.083225
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert vars(opts) == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:27:56.517753
# Unit test for function parseOpts
def test_parseOpts():
    # Test for function parseOpts
    # This test is not complete
    # TODO: Complete this test
    #
    # Test 1: Test with no arguments
    # Expected Result: No error
    parser, opts, args = parseOpts([])
    # Test 2: Test with --version
    # Expected Result: No error
    parser, opts, args = parseOpts(['--version'])
    # Test 3: Test with --help
    # Expected Result: No error
    parser, opts, args = parseOpts(['--help'])
    # Test 4: Test with --extract-audio
    # Expected Result: No error
    parser, opts, args = parseOpts(['--extract-audio'])
    # Test 5: Test with --audio-format
    # Expected Result: No error

# Generated at 2022-06-18 15:28:06.184557
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP

# Generated at 2022-06-18 15:28:19.283953
# Unit test for function parseOpts
def test_parseOpts():
    opts, args = parseOpts(['-i', '-v', '--no-progress', '--', 'foo', 'bar'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forcethumbnail == False
    assert opts.forcedescription == False
    assert opts.forcefilename == False
    assert opts.forcejson == False
    assert opts.dump_single_json == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False

# Generated at 2022-06-18 15:28:29.926822
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_xml_parse_error
    from youtube_dl.compat import compat_xml_parse_response

# Generated at 2022-06-18 15:28:35.569331
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-f', '18', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == '18'
    assert args == ['http://www.youtube.com/watch?v=BaW_jenozKc']
    parser, opts, args = parseOpts(['-f', '18', 'http://www.youtube.com/watch?v=BaW_jenozKc', 'http://www.youtube.com/watch?v=v1uyQZNg2vE'])
    assert opts.format == '18'

# Generated at 2022-06-18 15:28:44.494278
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    parser, opts, args = parseOpts(['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.format == 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:28:57.355058
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_expanduser
    from youtube_dl.compat import compat_getenv
    from youtube_dl.compat import compat_os_name
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_xml_parse_error
    from youtube_dl.compat import compat_xml_parse_response
    from youtube_dl.compat import compat_xml_parse_

# Generated at 2022-06-18 15:29:07.054020
# Unit test for function parseOpts

# Generated at 2022-06-18 15:29:36.937620
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--no-playlist', '--yes-playlist', '--', 'foo', 'bar'])
    assert opts.ignoreerrors
    assert opts.noplaylist
    assert not opts.playliststart is None
    assert args == ['foo', 'bar']

    parser, opts, args = parseOpts(['-4', '--no-check-certificate', '--', 'foo', 'bar'])
    assert opts.prefer_ipv4
    assert opts.nocheckcertificate
    assert args == ['foo', 'bar']

    parser, opts, args = parseOpts(['-U', 'foobar', '-P', 'hunter2', '--', 'foo', 'bar'])
    assert opts.usenet

# Generated at 2022-06-18 15:29:50.812915
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_getenv

    parser, opts, args = parseOpts(['-i', '--username', 'user', '--password', 'pass', '--verbose'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.verbose

    parser, opts, args = parseOpts(['-i', '--username', 'user', '--password', 'pass', '--verbose', '--ignore-config'])
    assert opts.username == 'user'
    assert opts.password == 'pass'
    assert opts.verbose


# Generated at 2022-06-18 15:30:02.475377
# Unit test for function parseOpts
def test_parseOpts():
    from io import StringIO
    from sys import stdout
    from tempfile import mkstemp
    from unittest import TestCase

    from youtube_dl.utils import encodeArgument

    class FakeStdout(StringIO):
        def isatty(self):
            return False

    class FakeTTYStdout(StringIO):
        def isatty(self):
            return True

    class FakeStdin(StringIO):
        def isatty(self):
            return False

    class FakeTTYStdin(StringIO):
        def isatty(self):
            return True

    class ParseOptsTest(TestCase):
        def setUp(self):
            self.to_delete = []

        def tearDown(self):
            for f in self.to_delete:
                os.remove(f)

       

# Generated at 2022-06-18 15:30:08.401102
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.nooverwrites == False
    assert opts.continue_dl == True
    assert opt

# Generated at 2022-06-18 15:30:18.577127
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMetadataPP

    def _test_parse_opts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for attr, expected_value in expected_opts.items():
            assert getattr(opts, attr) == expected_value

    def _test_parse_opts_raises(args, expected_exception, expected_exception_regexp):
        parser, opts, _ = parseOpts(args)

# Generated at 2022-06-18 15:30:31.681650
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split

    def test_parseOpts_inner(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for attr, exp in expected_opts.items():
            assert getattr(opts, attr) == exp, '%s: %r != %r' % (attr, getattr(opts, attr), exp)

    # Test --get-url
    test_parseOpts_inner(
        ['--get-url', 'http://www.youtube.com/watch?v=BaW_jenozKc'],
        {'geturl': True, 'noplaylist': True})

    # Test --get

# Generated at 2022-06-18 15:30:39.449652
# Unit test for function parseOpts
def test_parseOpts():
    # Test for issue #1630
    parser, opts, args = parseOpts(['-o', '-', 'http://example.com'])
    assert opts.outtmpl == '-'
    assert args == ['http://example.com']

    # Test for issue #1888
    parser, opts, args = parseOpts(['-o', '-', '-a', '-'])
    assert opts.outtmpl == '-'
    assert args == []

    # Test for issue #1888
    parser, opts, args = parseOpts(['-o', '-', '-a', '-', 'http://example.com'])
    assert opts.outtmpl == '-'
    assert args == ['http://example.com']

    # Test for issue #1888
    parser, opts, args

# Generated at 2022-06-18 15:30:43.470735
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--no-warnings', '--ignore-config', '--', 'foo', 'bar'])
    assert opts.verbose == True
    assert opts.ignoreerrors == True
    assert opts.no_warnings == True
    assert opts.ignoreconfig == True
    assert args == ['foo', 'bar']


# Generated at 2022-06-18 15:30:55.667010
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMergerPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupM3u8PP

# Generated at 2022-06-18 15:31:00.754597
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.getformat == False
    assert opts.username == None
    assert opts.password == None
    assert opts.twofactor == None
    assert opts.videopassword == None
    assert opts.ap_mso == None
    assert opts.ap_username == None
    assert opts.ap_password == None

# Generated at 2022-06-18 15:31:46.367677
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    parser, opts, args = parseOpts()
    assert opts.verbose == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.usetitle == False
    assert opts.autonumber == False
    assert opts.autonumber_size == None
    assert opts.autonumber_start == 1
    assert opts.restrictfilenames == False
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opt

# Generated at 2022-06-18 15:31:59.732920
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose
    assert opts.quiet is False
    assert opts.no_warnings is False
    assert opts.simulate is False
    assert opts.skip_download is False
    assert opts.format is None
    assert opts.listformats is False
    assert opts.outtmpl is None
    assert opts.ignoreerrors is False
    assert opts.forceurl is False
    assert opts.forcetitle is False
    assert opts.forceid is False
    assert opts.forcedescription is False
    assert opts.forcefilename

# Generated at 2022-06-18 15:32:09.354879
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '-v', '--username', 'foo', '--password', 'bar', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == True
    assert opts.simulate == False
    assert opts.geturl == False
    assert opts.gettitle == False
    assert opts.getid == False
    assert opts.getthumb == False
    assert opts.getdescription == False
    assert opts.getfilename == False
    assert opts.get_format_preference == False
    assert opts.usenetrc == False
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.dump_user

# Generated at 2022-06-18 15:32:20.894980
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose
    parser, opts, args = parseOpts(['--verbose', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['-v', '-v'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['-v', '--verbose'])
    assert opts.verbose == 2
    parser, opts, args = parseOpts(['--verbose', '-v'])
    assert opts.verbose == 2

# Generated at 2022-06-18 15:32:31.931287
# Unit test for function parseOpts

# Generated at 2022-06-18 15:32:43.335935
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose

    parser, opts, args = parseOpts(['--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-v', '--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-v', '--verbose', '-v'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-v', '--verbose', '-v', '--verbose'])
    assert opts.verbose

    parser, opts, args = parseOpts(['-v', '--verbose', '-v', '--verbose', '-v'])
    assert opts

# Generated at 2022-06-18 15:32:53.876821
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    import tempfile
    import os
    import shutil
    import sys

    def _test_parseOpts(args, expected_opts):
        parser, opts, _ = parseOpts(args)
        for attr, value in expected_opts.items():
            assert getattr(opts, attr) == value

    def _test_parseOpts_raises(args, expected_msg):
        parser, opts, _ = parseOpts(args)
        try:
            parser.error(expected_msg)
        except (SystemExit, Exception) as err:
            assert isinstance(err, SystemExit)
            assert str(err) == expected_msg


# Generated at 2022-06-18 15:33:00.676522
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    from youtube_dl.postprocessor.xattrpp import XAttrMetadataPP
    from youtube_dl.postprocessor.metadatafromtitle import MetadataFromTitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP

# Generated at 2022-06-18 15:33:12.906989
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-i', '--username', 'foo', '--password', 'bar', '-v', '--verbose'])
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert opts.verbose == 2
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == None
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.forceid == False
    assert opts.forceduration == False
   

# Generated at 2022-06-18 15:33:21.543044
# Unit test for function parseOpts

# Generated at 2022-06-18 15:34:53.437334
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    def test(argstr, expected):
        parser, opts, args = parseOpts(compat_shlex_split(argstr))
        assert vars(opts) == expected
        assert args == []
    test('-o -', {'outtmpl': '-'})
    test('-o-', {'outtmpl': '-'})
    test('-o -u user -p pass', {'outtmpl': '-', 'username': 'user', 'password': 'pass'})
    test('-o-u user -p pass', {'outtmpl': '-u user -p pass'})

# Generated at 2022-06-18 15:35:04.064052
# Unit test for function parseOpts
def test_parseOpts():
    from sys import argv
    from os.path import dirname
    from os import chdir
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import remove
    from os.path import exists
    from os.path import join
    from os.path import expanduser
    from os.path import isdir
    from os import getcwd
    from os import mkdir
    from os import environ
    from os import getenv
    from os import chmod
    from os import access
    from os import W_OK
    from os import X_OK
    from stat import S_IRWXU
    from stat import S_IRWXG
    from stat import S_IRWXO
    from stat import S_IRUSR
    from stat import S_IWUSR
    from stat import S_

# Generated at 2022-06-18 15:35:13.959814
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_expanduser

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:35:26.582140
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP

    def _test_parseOpts(args, expected_opts, expected_args):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args


# Generated at 2022-06-18 15:35:37.316712
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v', '--username', 'foo', '--password', 'bar', 'https://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.verbose == True
    assert opts.username == 'foo'
    assert opts.password == 'bar'
    assert args == ['https://www.youtube.com/watch?v=BaW_jenozKc']

# Generated at 2022-06-18 15:35:50.432094
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts()
    assert opts.username == 'test'
    assert opts.password == 'test'
    assert opts.usenetrc == False
    assert opts.verbose == True
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.simulate == False
    assert opts.skip_download == False
    assert opts.format == None
    assert opts.listformats == False
    assert opts.outtmpl == '%(title)s-%(id)s.%(ext)s'
    assert opts.ignoreerrors == False
    assert opts.forceurl == False
    assert opts.forcethumbnail == False
    assert opts.forceduration == False
    assert opts.forcefilename == False

# Generated at 2022-06-18 15:35:55.780640
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert not opts.quiet
    assert not opts.no_warnings
    assert not opts.simulate
    assert not opts.skip_download
    assert not opts.format
    assert not opts.listformats
    assert not opts.list_thumbnails
    assert not opts.dump_user_agent
    assert not opts.dump_intermediate_pages
    assert not opts.write_pages
    assert not opts.write_info_json
    assert not opts.write_description
    assert not opts.write_annotations
    assert not opts.write_thumbnail
    assert not opts.write_all_thumbnails
    assert not opts.list_subtitles
    assert not opt

# Generated at 2022-06-18 15:36:04.653059
# Unit test for function parseOpts
def test_parseOpts():
    from youtube_dl.utils import encodeArgument
    from youtube_dl.compat import compat_shlex_split
    from youtube_dl.YoutubeDL import YoutubeDL
    import tempfile
    import os
    import shutil
    import sys

    def _test_parseOpts(args, expected_opts, expected_args, expected_conf=None):
        parser, opts, args = parseOpts(args)
        assert opts.__dict__ == expected_opts
        assert args == expected_args
        if expected_conf is not None:
            with tempfile.NamedTemporaryFile(mode='w', delete=False) as conf:
                conf.write(expected_conf)

# Generated at 2022-06-18 15:36:16.436286
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-U', 'unit_test_user_agent', 'http://www.youtube.com/watch?v=BaW_jenozKc'])
    assert opts.usenetrc == False
    assert opts.username == None
    assert opts.password == None
    assert opts.videopassword == None
    assert opts.ap_username == None
    assert opts.ap_password == None
    assert opts.ap_mso == None
    assert opts.ap_list == None
    assert opts.usenetrc_machine == None
    assert opts.quiet == False
    assert opts.no_warnings == False
    assert opts.forceurl == False
    assert opts.forcetitle == False
    assert opts.force

# Generated at 2022-06-18 15:36:23.874588
# Unit test for function parseOpts
def test_parseOpts():
    parser, opts, args = parseOpts(['-v'])
    assert opts.verbose
    assert not opts.quiet
    assert not opts.simulate
    assert not opts.geturl
    assert not opts.gettitle
    assert not opts.getid
    assert not opts.getthumb
    assert not opts.getdescription
    assert not opts.getfilename
    assert not opts.getformat
    assert not opts.listformats
    assert not opts.list_thumbnails
    assert not opts.matchtitle
    assert not opts.rejecttitle
    assert not opts.writedescription
    assert not opts.writeinfojson
    assert not opts.writeannotations
    assert not opts.writethumbnail
    assert not opts.write_all_thumbnails
   