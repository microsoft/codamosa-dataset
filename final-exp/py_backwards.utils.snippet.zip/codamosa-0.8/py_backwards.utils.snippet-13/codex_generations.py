

# Generated at 2022-06-12 04:36:31.358498
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(lst)
    print(1)
    """)
    extend_tree(tree, {
        'lst': [ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
                ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))]
    })
    assert get_source(tree).strip() == """
    x = 1
    x = 2
    print(1)
    """

# Generated at 2022-06-12 04:36:39.250968
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_test(a: int, b: str) -> Any:
        let(x)
        let(y)
        extend(z)
        print(a, b, x, y)


# Generated at 2022-06-12 04:36:42.689583
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(vars)")
    vars = ast.parse('x = 1; x = 2')
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse('x = 1; x = 2'))

# Generated at 2022-06-12 04:36:44.709312
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x)\ny = 1')
    variables = find_variables(tree)

    assert variables == ['x']



# Generated at 2022-06-12 04:36:52.770212
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x)')
    assert tuple(find_variables(tree)) == ('x',)

    tree = ast.parse('let(x)\nlet(y)')
    assert tuple(find_variables(tree)) == ('x', 'y')

    tree = ast.parse('x = 1\nlet(x)\nlet(y)\ny = 1')
    assert tuple(find_variables(tree)) == ('x', 'y')

    tree = ast.parse('let(x)\nlet(y)\nx = 1\ny = 1')
    assert tuple(find_variables(tree)) == ('x', 'y')



# Generated at 2022-06-12 04:36:54.597558
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x) + let(y)')
    assert set(find_variables(tree)) == {'x', 'y'}

# Generated at 2022-06-12 04:36:58.845282
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    x = 1
    y = 2
    let(z)
    z = 3
    '''

    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'z'}



# Generated at 2022-06-12 04:37:03.853893
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(x)
        print(x)
    """)
    replace_at(0, tree.body, [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(1))])
    assert get_source(tree.body) == """[y] = [2, 3]"""

# Generated at 2022-06-12 04:37:07.999147
# Unit test for function find_variables
def test_find_variables():
    source = """
let(x)
let(y)
let(z)
"""
    tree = ast.parse(source)

    assert list(find_variables(tree)) == ['x', 'y', 'z']


# Generated at 2022-06-12 04:37:12.346478
# Unit test for function find_variables
def test_find_variables():
    source = '''
    print(x)
    x = 1
    let(x)
    print(x)
    y = x
    let(y)
    '''
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-12 04:37:24.938986
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = 'var = x + 1'
    tree = ast.parse(source)
    variables = {'x': VariablesGenerator.generate('x'), 'y': VariablesGenerator.generate('y')}
    VariablesReplacer.replace(tree, variables)
    assert len(tree.body) is 1
    assert isinstance(tree.body[0], ast.Assign)
    # cast to object for mypy
    assert isinstance(tree.body[0].targets[0], object)
    assert isinstance(tree.body[0].value, object)
    assert isinstance(tree.body[0].targets[0], ast.Name)
    assert isinstance(tree.body[0].value, ast.BinOp)
    # cast to object for mypy

# Generated at 2022-06-12 04:37:33.604979
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda: None).get_body() == []
    assert snippet(lambda x: None).get_body() == []
    assert snippet(lambda x: 42).get_body() == [ast.Expr(value=ast.Num(n=42))]
    assert snippet(lambda x: let(x)).get_body() == []
    assert snippet(lambda x: let(x) or x + 1).get_body() \
        == [ast.Expr(
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)))]

# Generated at 2022-06-12 04:37:36.278894
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: x + 1).get_body()[0].value \
        == ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()), ast.Add(),
                     ast.Num(1))



# Generated at 2022-06-12 04:37:45.331745
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Unit test for method get_body of class snippet."""
    assert snippet(lambda: let(a)).get_body() == [ast.Expr(value=ast.Name(id='a'))]
    assert snippet(lambda: let(a)).get_body(a=1) == [ast.Expr(value=ast.Num(n=1))]
    assert snippet(lambda: let(a)).get_body(a=ast.Num(n=1)) == [ast.Expr(value=ast.Num(n=1))]
    assert snippet(lambda: extend(extend_tree)).get_body(extend_tree=[ast.Pass(), ast.Pass()]) == [ast.Pass(), ast.Pass()]

# Generated at 2022-06-12 04:37:53.689382
# Unit test for function extend_tree
def test_extend_tree():
    import unittest

    class TestExtendTree(unittest.TestCase):
        def test_extend_tree(self):
            import textwrap

            snippet = textwrap.dedent(
                """
                extend(x)
                y = 0
                """
            )
            tree = ast.parse(snippet)
            replace = [ast.Assign(
                targets=[ast.Name(id='x')],
                value=ast.Num(n=1)
            )]
            extend_tree(tree, {
                'x': replace
            })

# Generated at 2022-06-12 04:38:03.051044
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def sqr(x: int) -> int:
        let(result)
        result = x * x
        return result

    def check(vars, expected):
        body = sqr.get_body(**vars)
        assert body == expected

    check({}, [ast.Assign([ast.Name(id='_py_backwards_result_0', ctx=ast.Store())], ast.BinOp(ast.Name(id='x', ctx=ast.Load()), ast.Mult(), ast.Name(id='x', ctx=ast.Load()))), ast.Return(ast.Name(id='_py_backwards_result_0', ctx=ast.Load()))])

# Generated at 2022-06-12 04:38:13.103921
# Unit test for function extend_tree
def test_extend_tree():
    snippet(get_body)
    snippet(get_body)
    tree = ast.parse(
        '''
        let(vars)
        extend(vars)
        let(x)
        y = x
        z = 2
        '''
    )

    extend_tree(tree, {'vars': [ast.Assign([ast.Name('x', ast.Store())], ast.Name('a', ast.Load())),
                                ast.Assign([ast.Name('x', ast.Store())], ast.Name('b', ast.Load()))], 'z': 'e'})

# Generated at 2022-06-12 04:38:16.210419
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def foo(x):
        let(y)
        y = x
        return y
    
    source = 'z = foo(1)'
    tree = ast.parse(source)
    eval(compile(tree, '', 'exec'))
    assert z == 1



# Generated at 2022-06-12 04:38:19.249587
# Unit test for function find_variables
def test_find_variables():
    source = """
        def fn(a):
            let(x)
            let(y)
    
            x = y = 1
            return x + y
    """

    expected = {'x', 'y'}
    tree = ast.parse(source)
    assert set(find_variables(tree)) == expected



# Generated at 2022-06-12 04:38:28.157358
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        x += 1
        y = 1
        extend(vars())
        print(x, y)

    snippet_ = snippet(f)
    result = snippet_.get_body()


# Generated at 2022-06-12 04:38:39.492761
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Natural example:
    @snippet
    def test_snippet(x, y):
        let(x)
        x += 1
        y = 1

    result = test_snippet.get_body(x=x, y=y)
    assert result == [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Add()),
                      ast.Assign([ast.Name(id='y', ctx=ast.Store())], ast.Num())]

# Generated at 2022-06-12 04:38:48.113587
# Unit test for function extend_tree
def test_extend_tree():
    import textwrap
    source = """\
    class A:
      extend(vars)
    """
    tree = ast.parse(textwrap.dedent(source))
    var = ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=1)
    )
    extend_tree(tree, {'vars': [var]})

# Generated at 2022-06-12 04:38:51.164271
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import get_ast
    def f():
        let(x)
        x += 1

    snippet = snippet(f)
    body = snippet.get_body()
    assert body == get_ast('_py_backwards_x_0 += 1')



# Generated at 2022-06-12 04:39:00.209278
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import pytest
    from textwrap import dedent
    from .helpers import check_ast

    def test_inner_method(a, b):
        let(a)
        a = a + b
        return a

    snippet_ast = ast.parse('a += b')
    test_snippet = snippet(test_inner_method)
    test_snippet.get_body(a=1, b=2)
    variables = {'a': '_py_backwards_a_0', 'b': '_py_backwards_b_0'}

# Generated at 2022-06-12 04:39:00.649098
# Unit test for function extend_tree

# Generated at 2022-06-12 04:39:06.289982
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 10
    b = 20
    @snippet
    def snippet_func():
        let(a)
        a += 1
        let(b)
        b += 1

    snippet_body = snippet_func.get_body()
    assert snippet_body[0].value.id == 'a'
    assert snippet_body[2].value.id == 'b'
    assert snippet_body[1].value.op == ast.Add
    assert snippet_body[3].value.op == ast.Add

# Generated at 2022-06-12 04:39:08.904404
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1

    @snippet
    def fn(c):

        let(x)
        let(y)

        x += 1
        return x

    print(fn.get_body(c='c', y='y'))

# Generated at 2022-06-12 04:39:17.883352
# Unit test for function extend_tree
def test_extend_tree():
    import textwrap as txt
    import astunparse as unp
    from .tree import find

    def extract_tree(fn: Callable[..., None]) -> ast.AST:
        tree = ast.parse(txt.dedent(fn.__doc__[1:])).body[0]
        extend_tree(tree, {'a': [ast.parse(txt.dedent(i))] for i in txt.dedent(fn.__doc__).split('$$')[1:]})
        return tree

    def _test(fn: Callable[..., None]) -> bool:
        tree = extract_tree(fn)
        expected = ast.parse(fn.__doc__.split('$$')[0])

# Generated at 2022-06-12 04:39:22.315495
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    snippet_body = snippet(lambda a, b: let(x + y)).get_body(a=x, b=y)
    assert len(snippet_body) == 1
    assert isinstance(snippet_body[0], ast.Assign)
    assert snippet_body[0].targets[0].id == '_py_backwards_a_0'



# Generated at 2022-06-12 04:39:30.800790
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from . import snippet
    from . import extend
    from . import let

    @snippet
    def test():
        let(x)

        x += 1
        y = 1

    @snippet
    def test2():
        extend(vars)

        print(x, y)

    assert test.get_body() == test2.get_body(vars=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1))], x='x')
    assert test.get_body() == test2.get_body(vars=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1))])

# Generated at 2022-06-12 04:39:47.361656
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 1
    snippet_get_body = snippet(fn).get_body({})
    assert snippet_get_body[0].targets[0].id == '_py_backwards_x_0'
    assert snippet_get_body[1].targets[0].id == 'y'
    assert snippet_get_body[1].value.n == 1

# Generated at 2022-06-12 04:39:55.341033
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 5
    b = 7
    c = 9
    #noinspection PyUnusedLocal
    @snippet
    def test_snippet():
        let(a)
        let(b)
        let(c)
        c = a + b

    #non local variables
    assert test_snippet.get_body() == ([ast.Assign([ast.Name(id='_py_backwards_c_0')], ast.BinOp(left=ast.Name(id='_py_backwards_a_0'), op=ast.Add(), right=ast.Name(id='_py_backwards_b_0')))], [])



# Generated at 2022-06-12 04:40:04.117373
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = let(1)
    b = let(1)

# Generated at 2022-06-12 04:40:09.310239
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tests.snippet_get_body import snippet_get_body
    generated_body = snippet(snippet_get_body).get_body(x=1, y=2)
    assert generated_body == [ast.Assign([ast.Name(id='x')], ast.Num(n=1)),
                              ast.Assign([ast.Name(id='y')], ast.Num(n=2))]



# Generated at 2022-06-12 04:40:14.865249
# Unit test for function find_variables
def test_find_variables():
    from .helpers import remove_white_space

    @snippet
    def _(x: Let, y: Let) -> None:
        x = 1
        y = 2
        let(x + y)

    assert remove_white_space(ast.dump(_.get_body())) == \
        remove_white_space('''
        x = 1
        y = 2
        _py_backwards_x_0
        ''')



# Generated at 2022-06-12 04:40:19.253720
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    tmp = let().get_body
    source = get_source(tmp)
    tree = ast.parse(source)
    assert tree.body[0].body[0].value.id == '_py_backwards_x_0'



# Generated at 2022-06-12 04:40:26.382440
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_class = snippet(test)
    snippet_ast = snippet_class.get_body(x=ast.Name(id='_x', ctx=ast.Load()),
                                         y=ast.Name(id='_y', ctx=ast.Load()))
    assert len(snippet_ast) == 2
    assert isinstance(snippet_ast[0], ast.AugAssign)
    assert isinstance(snippet_ast[0].target, ast.Name)
    assert snippet_ast[0].target.id == '_py_backwards_x_0'
    assert isinstance(snippet_ast[1], ast.Assign)

# Generated at 2022-06-12 04:40:33.144433
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo():
        let(x)
        let(y)
        let(z)
        x += 1
        y = 1
        z = 2

    expected = """
x = VariablesGenerator.generate('x')
y = VariablesGenerator.generate('y')
z = VariablesGenerator.generate('z')
x += 1
y = 1
z = 2
"""
    actual = snippet(foo).get_body()
    assert [get_source(node) for node in actual] == expected.split('\n')[1:-1]



# Generated at 2022-06-12 04:40:43.052778
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda: let(x) or x + x).get_body() == \
        [ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
          value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                          op=ast.Add(), right=ast.Name(id='_py_backwards_x_0', ctx=ast.Load())
                          ))]
    assert snippet(lambda: let(x) or x).get_body() == \
        [ast.Expr(ast.Name(id='_py_backwards_x_0', ctx=ast.Load()))]

# Generated at 2022-06-12 04:40:51.370807
# Unit test for function extend_tree
def test_extend_tree():

    # x = 1, y = 2
    vars = [ast.Assign(targets=[ast.Name('x', ast.Store())], value=ast.Num(1)),
            ast.Assign(targets=[ast.Name('y', ast.Store())], value=ast.Num(2))]

    # print(x, y)
    code = ast.parse('print(x, y)').body[0]

    # extend(vars)
    extend_node = ast.Call(func=ast.Name('extend', ast.Load()),
                           args=[ast.Name('vars', ast.Load())],
                           keywords=[])
    extend_node.lineno = 0
    extend_node.col_offset = 0

    # extend(vars)
    # print(x, y)

# Generated at 2022-06-12 04:41:22.760245
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snip(a, b, x=3, y=4, z=5, extend_me=None):
        let(x)
        let(y)
        z = let(z)
        extend(extend_me)

    body = snip.get_body(a=2, b=1, x=ast.Name(id='a', ctx=ast.Load()), y=3, extend_me=[
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2)),
    ])

    assert isinstance(body, list)

# Generated at 2022-06-12 04:41:31.580966
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from . import codegen

    @snippet
    def foo(x: ast.AST, y: str):
        let(x)
        x += 2
        y = 'a'
        return y

    @snippet
    def bar(x: ast.AST):
        let(x)
        extend(x)
        return x

    vars_ = ast.Assign(
        targets=[ast.Name(id='x')],
        value=ast.Num(n=1),
    )
    tree = foo.get_body(x=vars_, y='a')
    assert codegen.to_source(tree) == """\
_py_backwards_x_0 += 2
y = 'a'"""


# Generated at 2022-06-12 04:41:37.563152
# Unit test for function extend_tree
def test_extend_tree():
    source = 'extend(x)'
    tree = ast.parse(source)
    extend_tree(tree, {'x': [ast.parse('x = 1').body[0], ast.parse('x = 2').body[0]]})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=2))])'

# Generated at 2022-06-12 04:41:38.442258
# Unit test for function extend_tree
def test_extend_tree():
    pass



# Generated at 2022-06-12 04:41:46.647263
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_body = ['x = 1', 'y = 2', 'let(x)', 'x = 3', 'x+=1', 'extend(vars)']
    test_body = '\n'.join(test_body)
    tree = ast.parse(test_body)
    body = snippet(lambda: None).get_body(x=1, y=2, vars=ast.parse('a = 2').body)
    expected = ['x = 1', 'y = 2', '_py_backwards_x_0 = 3', '_py_backwards_x_0 += 1', 'a = 2']
    expected = '\n'.join(expected)
    expected = ast.parse(expected).body
    assert body == expected

# Generated at 2022-06-12 04:41:49.810483
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x: int) -> int:
        return x + 1

    x = ast.Name(id='x', ctx=ast.Load())
    print(snippet(fn).get_body(x=x))
    print([])


# Generated at 2022-06-12 04:41:59.075217
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import unittest
    import ast
    class TestSnippetGetBody(unittest.TestCase):
        def setUp(self):
            self.snippet = snippet

            @self.snippet
            def test_snippet():
                let(x)
                y = x
                print(1 + 2)

            @self.snippet
            def test_snippet_with_extend():
                extend(vars)
                print(x + y)


# Generated at 2022-06-12 04:42:03.879315
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_kwargs = {'x': ast.Name(id='_x', ctx=ast.Load())}

    def test_fn():
        let(x)
        return x == 0

    snippet_obj = snippet(test_fn)
    body = snippet_obj.get_body(**snippet_kwargs)

    assert isinstance(body[0], ast.Return)
    assert ast.dump(body[0].value) == "Eq(Name(_x, Load()), Num(0))"

# Generated at 2022-06-12 04:42:11.712689
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .compiler import compile_snippet  # type: ignore

    @snippet
    def f1(x: str) -> None:
        let(x)
        return x + x

    @snippet
    def f2(x: str, expand_me: str) -> None:
        let(x)
        y: str = x + ' '
        let(y)
        return y + expand_me

    @snippet
    def f3(celsius: int) -> None:
        let(FAHRENHEIT_FORMULA)
        let(celsius)

        return FAHRENHEIT_FORMULA

    @snippet
    def f4(celsius: int) -> None:
        let(FAHRENHEIT_FORMULA)

# Generated at 2022-06-12 04:42:19.689620
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x, y = 'x', 'y'

    @snippet
    def fcn(x: int) -> None:
        let(y)
        x += y
        print(x)
        extend(y)

    body = fcn.get_body(x=2, y=[ast.Assign(targets=[ast.Name(id=x, ctx=ast.Store())],
                                          value=ast.Num(1)),
                              ast.Assign(targets=[ast.Name(id=x, ctx=ast.Store())],
                                          value=ast.Num(2))])

# Generated at 2022-06-12 04:43:08.093566
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .methods import _test_snippet_get_body
    _test_snippet_get_body()

# Generated at 2022-06-12 04:43:16.799041
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        print(x)
    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body()
    assert isinstance(body, list)
    assert len(body) == 1
    assert isinstance(body[0], ast.Expr)
    assert isinstance(body[0].value, ast.Call)
    assert isinstance(body[0].value.func, ast.Name)
    assert body[0].value.func.id == 'print'
    assert len(body[0].value.args) == 1
    assert isinstance(body[0].value.args[0], ast.Name)
    assert body[0].value.args[0].id == '_py_backwards_x_0'
    assert body[0].value.args

# Generated at 2022-06-12 04:43:21.832171
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import typing_inspect
    from .helpers import parse

    def snippet_function(x: ast.Name, y: ast.Name):
        let(x)
        extend(y)

    snippet_fn = snippet(snippet_function)
    assert snippet_fn.get_body(x="x", y=parse('x = 1')) == [parse('_py_backwards_x_0 = x'),
                                                            parse('x = 1')]

# Generated at 2022-06-12 04:43:29.494228
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test code with keyword arguments
    @snippet
    def snippet1(x: int) -> None:
        print(x)

    assert snippet1.get_body(x=1) == snippet1.get_body(x=2)

    # Test code with variable and keyword arguments
    @snippet
    def snippet2(x: int) -> None:
        print(x)

    assert snippet2.get_body(x=1) != snippet2.get_body(x=2)

    # Test code with variable and keyword arguments, where variable differs
    @snippet
    def snippet3(x: int) -> None:
        let(y)
        print(y)

    assert snippet3.get_body(x=1) != snippet3.get_body(x=2)

    # Test code with variable and keyword

# Generated at 2022-06-12 04:43:37.123624
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import get_tree
    from .helpers import node_sum, sub_sum
    
    a_var = ast.Name(id='a', ctx=ast.Load())
    b_var = ast.Name(id='b', ctx=ast.Load())
    x_var = ast.Name(id='x', ctx=ast.Load())


# Generated at 2022-06-12 04:43:45.498300
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_function():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)


# Generated at 2022-06-12 04:43:48.061807
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse(
        """
        let(x)
        let(y)
        let(z)
        """
    ))) == ['x', 'y', 'z']

# Generated at 2022-06-12 04:43:51.692393
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('x = 1; extend(y); print(x, y)')
    extend_tree(tree, {'y': ast.parse('x = 2')})
    assert ast.dump(tree, True) == ast.dump(ast.parse('x = 1; x = 2; print(x, y)'), True)

# Generated at 2022-06-12 04:43:59.998767
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast as ast_lib
    @snippet
    def example(x: int, y: int) -> None:
        let(x)
        extend(y)
        x += 1
        print(y)
    
    y = ast_lib.parse("x = 1; x = 2; y = 1; y = 2; y = 3")

# Generated at 2022-06-12 04:44:02.936869
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        x = 1
        y = 2
        let(z)
        z = 'hello'
        print('hello', x, y, z)

    source = get_source(test)

# Generated at 2022-06-12 04:45:42.121556
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('var = 1\nextend(vars)')
    vars = ast.fix_missing_locations(ast.Assign(
        targets=[ast.Name(id='var', ctx=ast.Store())],
        value=ast.Num(n=2)))
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == 'Assign(targets=[Name(id=\'var\', ctx=Store())], value=Num(n=1))\nAssign(targets=[Name(id=\'var\', ctx=Store())], value=Num(n=2))'



# Generated at 2022-06-12 04:45:46.874495
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda: let(x)).get_body() == ast.parse(
        '''
        _py_backwards_x_0 = None
        '''
    ).body[0].body
    assert snippet(lambda: let(x)).get_body(x='a') == ast.parse(
        '''
        _py_backwards_x_0 = None
        '''
    ).body[0].body



# Generated at 2022-06-12 04:45:54.840543
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_example(x_0):
        y = 1
        let(x_0)
        z = 2
        extend(x_0)
        return None
    plugin = snippet(snippet_example)
    body = plugin.get_body(x_0=[ast.Assign([ast.Name(id='x_0', ctx=ast.Store())], ast.Num(n=1))])

# Generated at 2022-06-12 04:46:04.418008
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from itertools import repeat
    from .test import test

    def function(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1
    
    snippet_ = snippet(function)
    body = snippet_.get_body(x=0, y=0)

    test.assert_equals(len(body), 2)
    
    x_assign = body[0]
    test.assert_equals(x_assign.__class__.__name__, "AugAssign")
    test.assert_equals(x_assign.target.__class__.__name__, "Name")
    test.assert_equals(x_assign.target.id, "_py_backwards_x_0")

# Generated at 2022-06-12 04:46:09.689256
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    
    @snippet
    def body():
        let(x)
        x += 1
        y = 1

    source = """x = 1
               y = 2"""
    tree = ast.parse(source)
    
    var = body.get_body()
    
    body = tree.body
    
    replace_at(0, body, var[1])
    replace_at(0, body, var[0])
    
    assert tree == ast.parse(source)


# Generated at 2022-06-12 04:46:12.368151
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(a)
let(b)
a, b = b, a
    """)
    result = list(find_variables(tree))
    assert result == ['a', 'b']



# Generated at 2022-06-12 04:46:21.595189
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(x: int, y: ast.Name, z: int = 3) -> int:
        let(x)
        let(y)
        extend(z)
        return x + y.id  # type: ignore
