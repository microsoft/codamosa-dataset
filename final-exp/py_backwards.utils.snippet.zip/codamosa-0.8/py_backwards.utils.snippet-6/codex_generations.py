

# Generated at 2022-06-12 04:36:33.845129
# Unit test for function extend_tree
def test_extend_tree():
    # Given a tree of following code:
    tree = ast.parse("""
extend(vars)
x = 3
""")

    # And a variables dictionary:
    variables = {
        'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                         value=ast.Num(n=1)),
               ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                         value=ast.Num(n=3))]
    }

    # And extend_tree is called with it:
    extend_tree(tree, variables)

    # Then it should be like:
    expected = """
x = 1
x = 3
x = 3
"""
    assert ast.dump(tree) == expected



# Generated at 2022-06-12 04:36:35.851359
# Unit test for function find_variables
def test_find_variables():
    source = """
let(x)
x += 1
y = 1
    """
    tree = ast.parse(source)
    assert find_variables(tree) == ['x']

# Generated at 2022-06-12 04:36:38.773219
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
    """)
    assert sorted(find_variables(tree)) == ['x', 'y']
    assert ast.dump(tree) == "Module(body=[])"



# Generated at 2022-06-12 04:36:44.675105
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    """Test for code like: 
        from io import BytesIO
        from io import StringIO
    """
    source = 'from io import BytesIO\nfrom io import StringIO'
    module_name = 'from io import BytesIO'
    import_name = 'from io import StringIO'
    tree = ast.parse(source)
    variables = {module_name: BytesIO}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == ast.dump(ast.parse(import_name))


# Generated at 2022-06-12 04:36:54.075097
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    sn = snippet(lambda: let(x))

    assert len(sn.get_body()) == 0

    sn = snippet(lambda: let(x) and x + 1)
    assert len(sn.get_body()) == 1
    assert sn.get_body() == [ast.parse('_py_backwards_x_0 + 1').body[0]]

    sn = snippet(lambda: let(x) and let(y) and x + y)
    assert len(sn.get_body()) == 1
    assert sn.get_body() == [ast.parse('_py_backwards_x_0 + _py_backwards_y_0').body[0]]

    sn = snippet(lambda: let(x) and x + 1 and let(y) and y + 1)
    assert len(sn.get_body()) == 2


# Generated at 2022-06-12 04:36:56.565629
# Unit test for function find_variables
def test_find_variables():
    data = """
    if True:
        let(x)
        let(y)
    """

    assert list(find_variables(ast.parse(data))) == ['x', 'y']

# Generated at 2022-06-12 04:37:06.056425
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # In snippet is used let and extend methods
    def fn():
        from .nat import nat

        let(x)
        extend(xs)

        x += 1
        y = x
        z = x + y

    # Get AST of body of snippet without replacing of variables
    tree = ast.parse(get_source(fn))
    body = tree.body[0].body

    # Get AST of body of snippet with replacing of variables
    body_with_vars = snippet(fn).get_body()

    # Compare bodies of snippet
    assert len(body_with_vars) == len(body)
    for node_with_vars, node in zip(body_with_vars, body):
        assert type(node_with_vars) == type(node)

# Generated at 2022-06-12 04:37:10.965477
# Unit test for function find_variables
def test_find_variables():
    code_snippet = snippet(lambda x, y, z: let(x))
    body = code_snippet.get_body()

    assert body == [ast.Assign([ast.Name('x', ast.Store())], ast.Name('_py_backwards_x_0', ast.Load()))]


# Generated at 2022-06-12 04:37:12.098886
# Unit test for function extend_tree

# Generated at 2022-06-12 04:37:21.292853
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet._test_var_name = '_test_var'

    @snippet
    def _test_snippet(one: int, two: str, three: str):
        let(x)
        y = one + two
        z = three

    body = _test_snippet.get_body(one=1, two='x', three='z')
    assert isinstance(body[0], ast.Expr)
    assert isinstance(body[0].value, ast.Name)
    assert body[0].value.id == '_py_backwards_x_0'
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[1].value, ast.BinOp)
    assert isinstance(body[1].value.left, ast.Name)

# Generated at 2022-06-12 04:37:30.984154
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nprint(x, y)')
    vars = ast.parse('x = 1\nx = 2').body  # type: ignore
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == 'x = 1\nx = 2\nprint(x, y)'



# Generated at 2022-06-12 04:37:34.145395
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(vars)")
    extend_tree(tree, {"vars": [ast.Assign([ast.Name(id="a")], ast.Name(id="b"))]})
    assert get_source(tree) == "a = b\n"



# Generated at 2022-06-12 04:37:37.673602
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)')
    vars = [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1))]
    extend_tree(tree, {'vars': vars})
    assert astunparse.unparse(tree) == 'x = 1'

# Generated at 2022-06-12 04:37:48.230628
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(t)")
    assert isinstance(tree.body[0], ast.Expr)
    t = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Constant(value=123, kind=None)),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                   value=ast.Constant(value=456, kind=None)),
    ]
    extend_tree(tree, {'t': t})
    assert len(tree.body) == 2
    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[1], ast.Assign)



# Generated at 2022-06-12 04:37:54.839838
# Unit test for function extend_tree
def test_extend_tree():
    def test_fn(extend, x):
        x = 1
        extend(vars)
        return x

    vars = ast.parse('x = 2').body[0]
    source = get_source(test_fn)
    tree = ast.parse(source)
    variables = {'x': VariablesGenerator.generate('x'),
                 'vars': vars}
    extend_tree(tree, variables)
    assert ast.dump(tree) == ast.dump(ast.parse("""
        def _py_backwards_test_fn(extend, _py_backwards_x_0):
            _py_backwards_x_0 = 1
            _py_backwards_x_0 = 2
            return _py_backwards_x_0
        """))  # noqa E501

# Generated at 2022-06-12 04:37:58.315433
# Unit test for function extend_tree
def test_extend_tree():
    t = ast.parse('extend(vars)')
    t1 = ast.parse('x = 1\nx = 2')
    extend_tree(t, {'vars': t1.body})
    assert get_source(t) == 'x = 1\nx = 2'

# Generated at 2022-06-12 04:38:07.880515
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(x);")

    extend_tree(tree, {'x':[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
                            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))]})

    assert tree.body == [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
                         ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))]

    tree = ast.parse("extend(func);")

    extend

# Generated at 2022-06-12 04:38:15.365070
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
if True:
    extend(a)
    print(x)
'''
    tree = ast.parse(source)
    extend_tree(tree, {
        'a': [
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(n=1),
            ),
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(n=2),
            ),
        ],
    })
    print(ast.dump(tree))

# Generated at 2022-06-12 04:38:21.299914
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        x = 1
        extend(x)
        y = 2
    """)
    extend_tree(tree, {'x': ast.parse("x = 2").body[0]})

# Generated at 2022-06-12 04:38:25.210841
# Unit test for function extend_tree
def test_extend_tree():
    extend_tree(ast.parse(
        """
        def x():
            extend(x)
            print(x)
        """), {'x': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                value=ast.Num(n=1))]})



# Generated at 2022-06-12 04:38:39.744183
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test 1
    def f():
        let(x)
        x += 1
        y = 1
        return x

    body = snippet(f).get_body()
    assert len(body) == 8
    assert str(body[3]) == 'x += 1'
    assert str(body[4]) == 'y = 1'
    assert str(body[7]) == 'return x'

    # Test 2
    def f():
        let(x)
        x += 2
        return x

    body = snippet(f).get_body()
    assert len(body) == 8
    assert str(body[3]) == 'x += 2'
    assert str(body[7]) == 'return x'

    # Test 3
    def f():
        let(x)
        x += 1
        return x

    body = snippet

# Generated at 2022-06-12 04:38:48.392517
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(vars)\nx = 1\ny = 2")
    tree.body[0].value.args[0].id = "vars"
    assert tree.body[0].value.args[0].id == "vars"
    extend_tree(tree, {"vars": [ast.Assign([ast.Name("x", ast.Store())], ast.Num(1)),
                                ast.Assign([ast.Name("y", ast.Store())], ast.Num(2))]})
    assert str(tree.body[0].value) == "x = 1\ny = 2"
    tree = ast.parse("extend(vars)\nx = 1\ny = 2")

# Generated at 2022-06-12 04:38:49.154655
# Unit test for function extend_tree

# Generated at 2022-06-12 04:38:50.477329
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = snippet.get_body()
    assert a == []



# Generated at 2022-06-12 04:38:56.308426
# Unit test for function extend_tree
def test_extend_tree():
    class Foo:
        def bar(self):
            z = 1
    class Baa:
        def bar(self):
            z = 2
    baa = Baa()
    baa.bar()
    test_code = """
foo = Foo()
extend(foo)
foo.bar()
"""
    tree = ast.parse(test_code)
    extend_tree(tree, {'foo': baa.bar.__code__.co_consts[1]})



# Generated at 2022-06-12 04:39:03.421722
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
extend(vars)
fn1()
fn2()
'''
    tree = ast.parse(source)
    extend_tree(tree, {
        'vars': [
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],  # type: ignore
                value=ast.Constant(value=1)
            ),
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],  # type: ignore
                value=ast.Constant(value=2)
            ),
        ]
    })

# Generated at 2022-06-12 04:39:06.905869
# Unit test for function find_variables
def test_find_variables():
    source = """
    for i in range(5):
        let(x)
        x += 1
    """
    tree = ast.parse(source)
    actual = [var for var in find_variables(tree)]
    assert actual == ['x']



# Generated at 2022-06-12 04:39:10.834465
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(x)\nx.y = 1')
    extend_tree(tree, {'x': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(1))]})
    assert get_source(tree) == 'x.y = 1\n'



# Generated at 2022-06-12 04:39:20.247204
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_1() -> None:
        x = let(100)
        y = 100
        z = x + y
        print(z)

    def test_2() -> None:
        x = 100
        y = let(100)
        z = x + y
        print(z)

    def test_3() -> None:
        x = let(100)
        y = let(100)
        z = x + y
        print(z)

    def test_4() -> None:
        x = 100
        y = 100
        z = let(x + y)
        print(z)

    def test_5() -> None:
        x = 100
        y = 100
        z = let(x + let(100))
        print(z)


# Generated at 2022-06-12 04:39:26.984808
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_func(x: int) -> int:
        let(x)
        x += 1
        return x

    snippet_ = snippet(test_func)
    test_tree = snippet_.get_body(x=4)

    assert test_tree[0].value.left.id == '_py_backwards_x_0'
    assert test_tree[0].value.right.n == 4
    assert test_tree[1].value.left.id == '_py_backwards_x_0'
    assert test_tree[1].value.right.n == 1
    assert test_tree[2].value.id == '_py_backwards_x_0'



# Generated at 2022-06-12 04:39:49.714951
# Unit test for function extend_tree
def test_extend_tree():  # pragma: no cover
    from .dsl import let, extend
    import ast
    import random

    def extend_tree_test():
        let(a=1)
        let(b=2)
        let(c=3)
        let(d=4)
        extend(x=[
            let(a=3),
            let(b=4),
            let(c=5),
            let(d=6)
        ])
        extend(y=[
            let(a=5),
            let(b=6),
            let(c=7),
            let(d=8)
        ])
        extend(z=[
            let(a=9),
            let(b=10),
            let(c=11),
            let(d=12)
        ])


# Generated at 2022-06-12 04:39:58.995853
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = let(1)
    y = let(2)
    z = let(3)
    extend(dict(a=let(4), b=let(5)))
    extend([y])
    print(x, y, z)

    tree = snippet(test_snippet_get_body).get_body()
    assert len(tree) == 8
    assert isinstance(tree[0], ast.Assign)
    assert isinstance(tree[1], ast.Assign)
    assert isinstance(tree[2], ast.Assign)
    assert isinstance(tree[3], ast.Assign)
    assert isinstance(tree[4], ast.Assign)
    assert isinstance(tree[5], ast.Expr)
    assert isinstance(tree[5].value, ast.Call)

# Generated at 2022-06-12 04:40:06.679689
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        y = 0
        x = y + 1

    snippet = snippet(test)
    body = snippet.get_body(x=1)
    assert body[0].value.right.value == 1
    assert isinstance(body[1], ast.Assign)

    snippet = snippet(test)
    body = snippet.get_body()
    assert isinstance(body[0].value.left, ast.Name)
    assert isinstance(body[0].value.right, ast.BinOp)
    assert isinstance(body[1].value, ast.Num)
    assert isinstance(body[1].targets[0], ast.Name)



# Generated at 2022-06-12 04:40:12.046772
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("\n".join(("x = 1", "extend(lst)", "x = 2")))
    extend_tree(tree, {"lst": [ast.parse("x = 1").body[0]]})
    assert ast.dump(tree) == "\n".join(("x = 1", "x = 1", "x = 2"))

if __name__ == "__main__":
    test_extend_tree()

# Generated at 2022-06-12 04:40:19.335769
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import test_tree
    from .typing import N
    from .tests.types_define import T
    def expr() -> None:
        let(x)
        x += 2
        x += y
        x += 3
        y = x

    assert test_tree(snippet(expr).get_body(y=ast.parse('1 + 1').body[0]), '''
    x += 2
    x += y
    x += 3
    y = x
    ''')



# Generated at 2022-06-12 04:40:24.727377
# Unit test for function extend_tree
def test_extend_tree():
    ast_source = """
    let(stuff)
    extend(stuff)
    """

    tree = ast.parse(ast_source)
    variables = find_variables(tree)
    extend_tree(tree, {
        'stuff': [
            ast.parse('x = 1;').body[0],
            ast.parse('x = 2;').body[0],
        ]
    })
    output = ast.unparse(tree)
    assert output == '\n\nx = 1;\nx = 2;\n'

# Generated at 2022-06-12 04:40:33.918980
# Unit test for function extend_tree
def test_extend_tree():
    code1 = '''
a = 0
extend(b)
c = 2
    '''
    tree = ast.parse(code1)
    extend_tree(tree, {'b': [ast.Assign([ast.Name('b', ast.Store())], ast.Num(1))]})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'a\', ctx=Store())], value=Num(n=0)), Assign(targets=[Name(id=\'b\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'c\', ctx=Store())], value=Num(n=2))])'


if __name__ == '__main__':

    test_extend_tree()

# Generated at 2022-06-12 04:40:43.569602
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def my_snippet(f):
        extend(f)
        let(x)
        let(y)
        print(x, y)

    def get_snippet_body():
        return my_snippet.get_body(
            f=ast.parse_expr('x = 1; y = 2'),
            x=ast.parse_expr('x'),
            y=ast.parse_expr('y'))


# Generated at 2022-06-12 04:40:48.672968
# Unit test for function extend_tree
def test_extend_tree():
    program = """\
    extend(vars)
    print(x)
    """

    vars = """\
    x = 1
    y = 2
    """

    expected = """\
    x = 1
    y = 2
    print(x)
    """

    tree = ast.parse(program)
    extend_tree(tree, {'vars': ast.parse(vars).body})
    assert ast.dump(tree) == expected



# Generated at 2022-06-12 04:40:54.978158
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import inspect
    import ast

    def test() -> None:
        let(x)
        extend(vars)
        print(x)

    snippet_obj = snippet(test)
    assert isinstance(snippet_obj.get_body(vars=['x = 2']), ast.Module)
    assert snippet_obj.get_body(vars=['x = 2']).body[0].value.right.n == 2
    assert snippet_obj.get_body(vars=['x = 2']).body[1].value.args[0].id == "_py_backwards_x_0"

# Generated at 2022-06-12 04:41:13.215482
# Unit test for function extend_tree
def test_extend_tree():
    body = ast.parse("""
r = x
r = y
r += 3
r += 4
r
""").body[0].body
    var = ast.parse("""
r = 1
r = 2
""").body[0].body
    extend_tree(body, {'var': var})
    assert get_source(body) == """
r = 1
r = 2
r += 3
r += 4
r
"""

# Generated at 2022-06-12 04:41:21.258858
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: let(x)).get_body(x=1) == [
        ast.parse("x = 1").body[0],
    ]

    assert snippet(lambda x: let(x)).get_body(x=1, y=2) == [
        ast.parse("x = 1").body[0],
        ast.parse("y = 2").body[0],
    ]

    assert snippet(lambda x: let(x)).get_body(x=1, y=2) == [
        ast.parse("x = 1").body[0],
        ast.parse("y = 2").body[0],
    ]

    assert snippet(lambda x: let(x)).get_body(x=ast.Name(id='z')) == [
        ast.parse("x = z").body[0],
    ]



# Generated at 2022-06-12 04:41:30.109106
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 1
    b = 2
    def t1(x):
        let(y)
        y += a
        z = x + b
        return z

    v = t1.__code__.co_varnames
    assert v == ('x', 'y', 'z')

    tree = snippet(t1).get_body(x=1)
    print(ast.dump(tree))

    assert isinstance(tree, list)
    assert len(tree) == 2

    assert isinstance(tree[0], ast.AugAssign)
    assert isinstance(tree[0].target, ast.Name)
    assert tree[0].target.id == '_py_backwards_y_0'
    assert isinstance(tree[0].value, ast.Num)
    assert tree[0].value.n == 1

   

# Generated at 2022-06-12 04:41:38.683034
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(a) -> None:
        let(a)
        let(b)
        print(a)
        print(b)
        let(c)
        print(c)

    snippet = snippet(fn)
    body = snippet.get_body(a=1, b=2, c=[9, 10])


# Generated at 2022-06-12 04:41:45.259309
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nprint(x, y)')
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)), ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))]})
    assert get_source(tree) == 'x = 1\n x = 2\nprint(x, y)'

# Generated at 2022-06-12 04:41:50.189231
# Unit test for function extend_tree
def test_extend_tree():
    with open('tests/snippet.py') as f:
        src = f.read()
    tree = ast.parse(src)
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(2))]})
    Func = ast.FunctionDef('test', ast.arguments(args=[ast.arg('x', None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(1)), ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(2))], [])

# Generated at 2022-06-12 04:41:55.750987
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""extend(vars)
print(x, y)
""")
    vars = ast.parse("""x = 1
x = 2
y = 3
""")
    extend_tree(tree, {'vars': vars.body})
    assert get_source(tree).strip() == """x = 1
x = 2
y = 3
print(x, y)
""".strip()



# Generated at 2022-06-12 04:41:59.581090
# Unit test for function find_variables
def test_find_variables():
    from py_backwards import snippet
    source = 'let(x) x += 1\n'
    tree = ast.parse(source)
    variables = snippet._Snippet(lambda: None)._get_variables(tree, {})
    assert variables == {'x': '_py_backwards_x_0'}



# Generated at 2022-06-12 04:42:05.948332
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func():
        let(x)
        x += 1
        y = 1

    s = snippet(func)
    assert s.get_body() == [
        ast.Assign([ast.Name(id="_py_backwards_x_0", ctx=ast.Store())], ast.BinOp(
            left=ast.Name(id="_py_backwards_x_0", ctx=ast.Load()), op=ast.Add(), right=ast.Constant(value=1, kind=None))),
        ast.Assign([ast.Name(id="y", ctx=ast.Store())], ast.Constant(
            value=1, kind=None))]

# Generated at 2022-06-12 04:42:13.943528
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .transformers import AssignOptimizer, FunctionOptimizer
    from . import tree as tree_module
    from astunparse import unparse

    source = """
    def foo(x):
        let(y)
        extend(z)
        let(a)
        print(x, y, z, a)
        return x + y + z
    """
    tree = ast.parse(source)

    snippet_ = snippet(foo)
    body = snippet_.get_body(y=1, z=['y = 1'])

    body2 = AssignOptimizer.transform(body)

    body3 = FunctionOptimizer.transform(body2)
    tree_module.print_tree(body3)

    result = unparse(ast.Module(body3))
    print('result')
    print(result)


# Generated at 2022-06-12 04:42:50.265060
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def s0(a: int, b: int) -> None:
        let(x)
        let(y)
        extend(vars)

    body = s0.get_body(a=0, b=1, vars=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Load())], value=ast.Num(n=1))])
    assert len(body) == 1
    assert isinstance(body[0], ast.Assign)
    assert len(body[0].targets) == 1
    assert isinstance(body[0].targets[0], ast.Name)
    assert body[0].targets[0].id == '_py_backwards_x_0'

# Generated at 2022-06-12 04:42:51.127424
# Unit test for function extend_tree

# Generated at 2022-06-12 04:42:57.996476
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nx = 1')
    extend_tree(tree, {'vars': [ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Store()),
                                              value=ast.Num(n=2))]})
    assert tree.body == [ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Store()),
                                       value=ast.Num(n=2)),
                         ast.AnnAssign(target=ast.Name(id='x', ctx=ast.Store()),
                                       value=ast.Num(n=1))]

# Generated at 2022-06-12 04:43:04.332491
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test)
    x = ast.parse('x = 2').body[0]
    body = snippet_.get_body(x=x)
    # body will contain: [Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2))]
    assert body[0].__class__.__name__ == 'Assign'
    assert body[0].value.__class__.__name__ == 'Num'

# Generated at 2022-06-12 04:43:10.907718
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Provided
    def snippet1(arg1: int, arg2: str) -> ast.FunctionDef:
        let(x)
        print(arg1)
        print(x)
        return x

    # Expected
    def expected_snippet1(arg1: int, arg2: str) -> ast.FunctionDef:
        print(arg1)
        print("_py_backwards_x_0")
        return "_py_backwards_x_0"

    # Test
    assert snippet1.get_body() == expected_snippet1.get_body()



# Generated at 2022-06-12 04:43:19.593760
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 1
    b = 2
    c = 3

    @snippet
    def test_fn(a, b, c):
        let(a)
        let(b)
        let(c)
        a = b
        b = c
        c = 1


# Generated at 2022-06-12 04:43:27.200705
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    body = snippet(lambda: let(x) or extend(vars) or print(x, y)).get_body(
        x=ast.Name(id='x', ctx=ast.Load()), vars=ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)))
    assert ast.dump(body[0]) == 'Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1))'
    assert ast.dump(body[1]) == 'Print(dest=None, values=[Name(id=\'x\', ctx=Load()), Name(id=\'y\', ctx=Load())], nl=True)'

# Generated at 2022-06-12 04:43:31.311127
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet(x: int):
        x += 1

    assert test_snippet.get_body(x=0) == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                                           ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()), ast.Add(), ast.Num(1)))]

# Generated at 2022-06-12 04:43:37.296726
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    vars1 = {'x': 'x1'}
    vars2 = {'x': 'x2'}

    def test_func():
        let(x)
        x += y
        extend(vars1)

    @snippet
    def test_func2():
        let(x)
        x += y
        extend(vars2)

    tree = test_func.get_body()
    tree2 = test_func2.get_body()
    print(tree)
    print(tree2)
    assert ast.dump(tree) == ast.dump(tree2)

# Generated at 2022-06-12 04:43:39.925234
# Unit test for function extend_tree
def test_extend_tree():
    source = inspect.getsource(extend_tree)
    tree = ast.parse(source)
    tree = ast.fix_missing_locations(tree)
    extend_tree(tree, {})
    assert source == astor.to_source(tree)



# Generated at 2022-06-12 04:44:44.623852
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = let  # noqa: F841
    y = extend  # noqa: F841

    @snippet
    def test() -> None:
        let(x)
        x += 1  # type: ignore
        y = 1  # type: ignore


# Generated at 2022-06-12 04:44:52.904572
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import pytest
    from .backend import Backend

    backend = Backend()

    @snippet
    def test_snippet(a, b, c):
        let(a)
        var = 'some_text'
        let(var)
        extend(b)
        y = var
        let(y)
        c = x + 1

    test_snippet_body = test_snippet.get_body(a=5, b=[x + 1, y + 1], c=3)

# Generated at 2022-06-12 04:44:55.630661
# Unit test for function extend_tree
def test_extend_tree():
    det_node = ast.parse('x = 1').body[0]
    node = ast.parse('extend(x)').body[0]

    extend_tree(node, {'x': [det_node]})
    assert node.value == [det_node]

# Generated at 2022-06-12 04:45:03.759204
# Unit test for function find_variables
def test_find_variables():
    from .test_helpers import assert_same_ast
    assert_same_ast(find_variables(ast.parse('let(x)')),
                    ['x'])
    assert_same_ast(find_variables(ast.parse('''
        def blah(a, b):
            let(x)
            
            print(x)
    ''')), ['x'])
    assert_same_ast(find_variables(ast.parse('''
        def blah(a, b):
            let(x)
            let(z)
            
            print(x)
    ''')), ['x', 'z'])

# Generated at 2022-06-12 04:45:06.877986
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x):
        let(3)
        y = x
        return y

    snippet_ast = snippet(snippet_fn).get_body()
    assert len(snippet_ast) == 2



# Generated at 2022-06-12 04:45:17.279435
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    _ = let
    @snippet
    def snippet():
        _(x)
        y = _(z)
        assert x == z
        print(y)

    x = let(1)
    z = let(1)
    variables = {'x': x, 'z': z}
    body = snippet.get_body(**variables)
    # Checks correctness of AST

# Generated at 2022-06-12 04:45:25.535162
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(vars)")
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2))])"

# Generated at 2022-06-12 04:45:29.334581
# Unit test for function extend_tree
def test_extend_tree():
    t = let(1)
    v = extend(t)
    tree = ast.parse(get_source(v))
    extend_tree(tree, {'t': ast.parse('x = 1').body,
                       'v': 'print(x)'})
    assert get_source(tree) == '\nx = 1\nprint(x)\n'

# Generated at 2022-06-12 04:45:38.451235
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    global x
    x = 0
    @snippet
    def fn():
        global x
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    vars = ast.Module(body=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                       value=ast.Num(n=1)),
                            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                       value=ast.Num(n=2))])

    body = fn.get_body(vars=vars)

# Generated at 2022-06-12 04:45:47.828176
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Example of using `let`.
    example = snippet(lambda x: let(x))
    assert example.get_body(x=1) == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.Num(n=1),
        )
    ]

    # Example of using `extend`.
    example = snippet(lambda x, y: extend(x))