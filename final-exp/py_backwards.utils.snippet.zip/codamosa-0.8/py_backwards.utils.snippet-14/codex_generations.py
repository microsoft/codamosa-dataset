

# Generated at 2022-06-12 04:36:35.755939
# Unit test for function extend_tree
def test_extend_tree():
    body = snippet(lambda x: x).get_body()
    assert body == [ast.Expr(ast.Name('_py_backwards_x_0', ast.Load()))]

# Generated at 2022-06-12 04:36:38.133160
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
    x = 1
    y = 2
    z = 3
    '''
    tree = ast.parse(source)
    extend_tree(tree, {'vars': tree.body})
    assert get_source(tree) == source

# Generated at 2022-06-12 04:36:46.307762
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f(x):
        let(y)
        x += y
        return x

    tree = f.get_body(y=1)
    assert isinstance(tree, list) and len(tree) == 3  # type: ignore
    assert isinstance(tree[1], ast.Assign)  # type: ignore
    assert isinstance(tree[1].targets[0], ast.Name) and tree[1].targets[0].id == '_py_backwards_y_0'  # type: ignore
    assert isinstance(tree[2], ast.Return)  # type: ignore
    assert isinstance(tree[2].value, ast.BinOp)  # type: ignore
    assert isinstance(tree[2].value.op, ast.Add)  # type: ignore
   

# Generated at 2022-06-12 04:36:50.285644
# Unit test for function find_variables
def test_find_variables():
    source = '''a = 1
    b = 2
    let(x)
    x = 2
    '''
    tree = ast.parse(source)
    variables = list(find_variables(tree))

    assert variables == ['x']


# Generated at 2022-06-12 04:37:00.032991
# Unit test for function extend_tree
def test_extend_tree():
    a = snippet(lambda: extend(vars))
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))]

# Generated at 2022-06-12 04:37:02.267267
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    alias = ast.alias(name="a")
    alias = VariablesReplacer.replace(alias, {"a": "b"})
    assert alias.name == "b"

# Generated at 2022-06-12 04:37:12.465280
# Unit test for function extend_tree
def test_extend_tree():
    code = """
        extend(vars)
        print(x)
    """
    tree = ast.parse(code)
    v1 = ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=1)
    )
    v2 = ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=2)
    )
    vars = [v1, v2]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-12 04:37:13.858792
# Unit test for function extend_tree

# Generated at 2022-06-12 04:37:20.846304
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    test_alias = ast.alias('y', 'test_y')
    variables = { 'test_y': 'z'}
    test_tree = ast.parse('x = 1')
    test_tree.body[0].value = test_alias

    expected_tree = ast.parse('x = 1')
    expected_alias = ast.alias('y', 'z')
    expected_tree.body[0].value = expected_alias

    # test
    test_tree = VariablesReplacer.replace(test_tree, variables)

    assert ast.dump(test_tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 04:37:30.364695
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:37:45.037674
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars); v = y')
    extend_tree(tree, {'vars': [
        ast.Assign(
            targets=[ast.Name(id='x')],
            value=ast.Num(n=1)),
        ast.Assign(
            targets=[ast.Name(id='x')],
            value=ast.Num(n=2))], 'y': ast.Num(n=3)})

    assert ast.dump(tree) == "Module(body=[Name(id='x', ctx=Store()), Name(id='x', ctx=Store()), Assign(targets=[Name(id='v', ctx=Store())], value=Num(n=3))])"

# Generated at 2022-06-12 04:37:53.581955
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda: None).get_body() == []
    assert snippet(lambda x: let(x)).get_body(y=2) == []
    assert snippet(lambda x: let(x)).get_body(x=1) == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.Num(n=1),
        )
    ]
    assert snippet(lambda x: let(x)).get_body(y=2) == []
    assert snippet(lambda x, y: let(x)).get_body(y=2) == []

# Generated at 2022-06-12 04:37:56.963605
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("import ext as z")
    variables = {'ext': 'st'}
    expected_result = "import st as z"
    assert(VariablesReplacer.replace(tree, variables).body[0].print_tree() == expected_result)


# Generated at 2022-06-12 04:38:03.213137
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import typed_ast.ast3
    from .variables import VariablesReplacer
    from .helpers import VariablesGenerator
    tree = typed_ast.ast3.parse('''from x import y''')  # type: ignore
    tree = VariablesReplacer.replace(tree, {"x": VariablesGenerator.generate("x")})
    assert(ast.dump(tree) == 'ImportFrom(module="x", names=[alias(name="y", asname=None)], level=0)')

# Generated at 2022-06-12 04:38:05.942325
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    z = 0
    let(x)
    y = 1
    """)
    assert list(find_variables(tree)) == ['x']



# Generated at 2022-06-12 04:38:11.073250
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nx = 1')
    extend_tree(tree, {
        'vars': [
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(n=1))]
    })
    assert astor.to_source(tree) == 'x = 1\nx = 1\n'

# Generated at 2022-06-12 04:38:18.650575
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test() -> None:
        let(x)
        x += 1
        y = 1

    body = test.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[0].value, ast.BinOp)
    assert isinstance(body[0].value.op, ast.Add)
    assert isinstance(body[0].value.left, ast.Name)
    assert isinstance(body[0].value.left.ctx, ast.Load)
    assert body[0].value.left.id in body[0].value.left.id
    assert isinstance(body[0].value.right, ast.Num)
    assert body[0].value.right.n == 1

# Generated at 2022-06-12 04:38:27.575220
# Unit test for function extend_tree
def test_extend_tree():
    def f():
        vars = [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=1)),
                ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=2))]
        extend(vars)
        print(x, y)

    source = get_source(f)
    tree = ast.parse(source)
    extend_tree(tree, {'vars': vars})
    result = ast.dump(tree)

# Generated at 2022-06-12 04:38:28.382619
# Unit test for function find_variables

# Generated at 2022-06-12 04:38:32.081529
# Unit test for function extend_tree
def test_extend_tree():
    source_x = ast.parse("x = 1")
    source_y = ast.parse("y = 1")
    source = ast.parse("extend(source_x)")
    variables = {'source_x': source_x}
    extend_tree(source, variables)
    assert source.body[0].body[0].value.value == 1

# Generated at 2022-06-12 04:38:43.481682
# Unit test for function extend_tree
def test_extend_tree():
    # type: () -> None
    tree = ast.parse('''
    def func(x):
        extend(vars)
        return x
    ''')  # type: ast.AST
    variables: Dict[str, ast.AST] = {'vars': ast.parse('''
    x = 1
    x = 2
    ''').body[0]}

    extend_tree(tree, variables)
    assert get_source(tree) == '''
    def func(x):
        x = 1
        x = 2
        return x
    '''



# Generated at 2022-06-12 04:38:48.912171
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet():
        let(x)
        x = 1
        return x
    body = test_snippet.get_body()
    for node in body:
        source = ast.dump(node)
        assert source == 'Assign(targets=[Name(_py_backwards_x_0, Store())], ' \
                         'value=Constant(value=1, kind=None))'



# Generated at 2022-06-12 04:38:51.769225
# Unit test for function find_variables
def test_find_variables():
    source = """
        def fn():
            let(x)
            let(y)
    """
    tree = ast.parse(source)
    variables = list(find_variables(tree))
    assert variables == ['x', 'y']



# Generated at 2022-06-12 04:38:54.837254
# Unit test for function find_variables
def test_find_variables():
    tree = """
    let(x)
    print(x)
    """.strip()
    variables = list(find_variables(ast.parse(tree)))
    assert variables == ['x']



# Generated at 2022-06-12 04:38:59.217265
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet = Snippet(test_snippet_get_body)
    body = snippet.get_body()
    assert len(body) == 3
    assert isinstance(body[0], ast.Assign)
    assert body[0].value.n == 1
    assert body[1].value.n == 2
    assert body[2].value.n == 3



# Generated at 2022-06-12 04:39:01.606919
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x += 1
    """
    tree = ast.parse(source)
    vars = list(find_variables(tree))
    assert vars == ['x']



# Generated at 2022-06-12 04:39:06.557694
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo():
        let(x)
        x += 1
        y = 1
        return y

    print('foo goes:')
    print(ast.dump(foo()))

    # x = sniffets.snippet(foo)
    # x = x.get_body()
    # print(ast.dump(x))


if __name__ == '__main__':
    test_snippet_get_body()

# Generated at 2022-06-12 04:39:14.709514
# Unit test for function find_variables
def test_find_variables():
    # Create AST of code:
    # let(a)
    # let(b)
    # a + b
    a = ast.Name('a', ast.Load())
    b = ast.Name('b', ast.Load())
    let_a = ast.Call(
        func=ast.Name('let', ast.Load()),
        args=[a],
        keywords=[]
    )
    let_b = ast.Call(
        func=ast.Name('let', ast.Load()),
        args=[b],
        keywords=[]
    )
    add = ast.BinOp(a, ast.Add(), b)
    tree = ast.Module(body=[let_a, let_b, add])

    # Check that find_variables finds variable four times

# Generated at 2022-06-12 04:39:19.436000
# Unit test for function find_variables
def test_find_variables():
    def test(code):
        tree = ast.parse(code)
        assert set(find_variables(tree)) == set(code.split())

    test('let(x) let(y)')
    test('let(x) let (y)')
    test('let(x) let(y)\nlet(z)')



# Generated at 2022-06-12 04:39:27.352253
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    y = 1
    """

    tree = ast.parse(source)
    variables = find_variables(tree)
    assert list(variables) == ['x']

    source = """
    i = 0
    let(x)
    i = 1
    let(y) = 1
    """

    tree = ast.parse(source)
    variables = find_variables(tree)
    assert list(variables) == ['x', 'y']

    source = """
    let(x)
    let(y) = {
        let(z) = 1
    }
    """

    tree = ast.parse(source)
    variables = find_variables(tree)
    assert list(variables) == ['x', 'y']


# Generated at 2022-06-12 04:39:39.835871
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    def fn1(n):
        let(x)
        return x + n

    def fn2(n):
        let(x)
        x += 1
        return x + n

    def fn3():
        let(x)
        x += 1
        y = 2
        return x, y

    def fn4():
        x = 1
        let(y)
        y = x + 1
        z = 2
        return x, y, z

    def fn5():
        extend(x)
        y = x + 1
        return x, y

    def fn6():
        extend(x)
        x += 1
        return x

    def fn7():
        extend(x)
        x = x - 1
        return x

    assert snippet(fn1).get_body(n=1)

# Generated at 2022-06-12 04:39:44.336316
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo(x):
        pass
    assert foo(1) is None
    assert len(snippet(foo).get_body()) == 2
    assert len(snippet(foo).get_body(x="test")) == 2
    assert len(snippet(foo).get_body(x=ast.Name("test", ast.Load()))) == 2



# Generated at 2022-06-12 04:39:53.772717
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def func(a, b=None, *args, k=1):
        let(x)
        x += 1
        y = 1
        extend(z)
        return x + y

    snippet_kwargs = {'a': 1, 'b': None, 'args': ['a', 'b'], 'k': 1}
    snippet_variables = {'x': '_py_backwards_x_0', 'z': '_py_backwards_z_1', 'y': 1}

    snippet_result = func.get_body(**snippet_kwargs)

    insert_statement_1 = ast.parse('_py_backwards_x_0 += 1').body[0]
    body_statement_1 = snippet_result[0]

# Generated at 2022-06-12 04:39:58.228688
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse(
        'let(x)\nlet(y)\nx += 1\nif let(z):\n    z = z\nelse: z = z\n'
        'let(a)\ny = 3')
    variables = [variables for variables in find_variables(tree)]
    assert variables == ['x', 'y', 'z', 'a']



# Generated at 2022-06-12 04:40:01.378900
# Unit test for function find_variables
def test_find_variables():
    readline = snippet(lambda: let(input()))
    assert readline.get_body()[0].value.args[0].s == '_py_backwards_input__py_backwards_0'



# Generated at 2022-06-12 04:40:06.834325
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class C:
        @snippet
        def function(a: int, b: int = 5) -> int:
            """Adds two numbers, `a` and `b`."""
            let(a_copy = a)
            c = a_copy + b
            return c
            
    snippet_body = C.function.get_body(a=10, b=20)
    assert snippet_body[0].value.right.n == 10
    assert snippet_body[1].value.value.n == 20

# Generated at 2022-06-12 04:40:10.931142
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        def f(a, b, c):
            print(f(a, b, c))
            let(a)
            return a + b
    """)

    find_var_res = [v for v in find_variables(tree)]
    assert find_var_res == ['a']

# Generated at 2022-06-12 04:40:17.698841
# Unit test for function find_variables
def test_find_variables():
    source = dedent('''
        def fn():
            let(x)
            if x:
                print(x)
            let(z)
            if x and z:
                print(z)
    ''')
    tree = ast.parse(source)
    vars = find_variables(tree)
    assert list(vars) == ['x', 'z']


test_find_variables()



# Generated at 2022-06-12 04:40:25.486603
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    s = snippet(lambda x, y: (x, y) + (x, y))  # noqa

# Generated at 2022-06-12 04:40:27.197709
# Unit test for function find_variables
def test_find_variables():
    body = snippet(lambda x: let(x)).get_body()
    assert list(find_variables(body)) == ['x']



# Generated at 2022-06-12 04:40:42.875604
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f(x):
        let(y)
        y += 1
        return x + y

    body = f.get_body(x=1)
    assert isinstance(body, list)
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[0].target, ast.Name)
    assert body[0].target.id == '_py_backwards_y_0'
    assert body[0].op == ast.Add()
    assert body[0].value == 1

    assert isinstance(body[1], ast.Return)
    assert isinstance(body[1].value, ast.BinOp)
    assert isinstance(body[1].value.left, ast.Name)
    assert body[1].value.left

# Generated at 2022-06-12 04:40:45.772769
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import pytest

    @snippet
    def snip(x: int, y: int) -> None:
        let(temp)
        temp = x + y
        y = temp
        extend(snip)

    # TODO: add assertion

# Generated at 2022-06-12 04:40:48.939484
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo(a):
        let(x)
        x += a

    body = snippet(foo).get_body(a=123)
    assert len(body) == 1
    assert isinstance(body[0], ast.AugAssign)

# Generated at 2022-06-12 04:40:51.057164
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(x) + 1; let(y); let(z)")
    assert list(find_variables(tree)) == ['x', 'y', 'z']

# Generated at 2022-06-12 04:40:59.032794
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 1
    b = 2
    c = 3
    d = 4
    snippet_body = snippet(lambda x, y, z, w: let(x + y + z + w)).get_body(
        x=a, y=b, z=c, w=d)


# Generated at 2022-06-12 04:41:04.934267
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import astor

    def x_2():
        let(y)
        y = 1
        let(x)
        x += 1

    # snippet is an instance of class snippet
    snippet = Snippet(x_2)

    expected = 'y = 1\n_py_backwards_x_0 += 1\n'
    expected = astor.to_source(ast.parse(expected))

    actual = snippet.get_body()
    actual = astor.to_source(ast.Module(body=actual))
    assert expected == actual

# Generated at 2022-06-12 04:41:12.841619
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import dump
    from .helpers import VariablesGenerator

    def foo(x: int, y: int) -> int:
        let(z)
        let(w)
        return x + y + z + w

    generator = VariablesGenerator()
    generator.generate = lambda: '_py_backwards_z_0'
    generator.get_variables = lambda: 'z, w'

    s = snippet(foo)
    tree = s.get_body()
    print(dump(tree))

# Generated at 2022-06-12 04:41:16.614078
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    from x import y
    def f():
        let(z)
        print(x, y, z)
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert set(variables) == set(['x', 'y', 'z'])



# Generated at 2022-06-12 04:41:24.618106
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: int, y: int) -> int:
        let(x)
        x += 1
        extend(y)
        return int(x)

    assert test.get_body(x=1, y=[ast.parse("y = 1")]) == [
        ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   ast.BinOp(ast.Name(id='_py_backwards_x_0', ctx=ast.Load()), ast.Add(), ast.Constant(1, kind=None))),
        ast.Assign([ast.Name(id='y', ctx=ast.Store())], ast.Constant(1, kind=None))
    ]

# Generated at 2022-06-12 04:41:26.497334
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: x + 1).get_body(x=1)[0].value.left.id == '_py_backwards_x_0'

# Generated at 2022-06-12 04:41:35.476895
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        x += 1

    snippet_obj = snippet(test)
    assert snippet_obj.get_body() == [
        ast.Assign(
            [ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            ast.BinOp(
                ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                ast.Add(),
                ast.Num(n=1)
            )
        )
    ]

# Generated at 2022-06-12 04:41:39.323043
# Unit test for function extend_tree
def test_extend_tree():
    ext = ast.parse('x = 1').body[0]
    tree = ast.parse('extend(vars)\nprint(x, y)')
    extend_tree(tree, {'vars': ext})
    assert tree.body[0].value.left.id == 'x'  # type: ignore

# Generated at 2022-06-12 04:41:46.707015
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f():
        let(x)
        x = x + 1
        return x

    assert f.get_body() == [ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())], ast.BinOp(ast.Name(id='_py_backwards_x_0', ctx=ast.Load()), ast.Add(), ast.Num(n=1))), ast.Return(ast.Name(id='_py_backwards_x_0', ctx=ast.Load()))]
    assert get_source(f.get_body) == 'x = x + 1\nreturn x'

# Generated at 2022-06-12 04:41:55.870733
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Arrange
    @snippet
    def fn(x: int, y: ast.Name) -> None:
        let(x)
        let(y)
        x += 1
        y += 1
        
    x_tree = ast.parse('x = 1').body[0]
    y_tree = ast.parse('y = 1').body[0]
    
    # Act
    res = fn.get_body(x=x_tree, y=y_tree)
    
    # Assert
    assert isinstance(res[0], ast.Assign)
    assert isinstance(res[1], ast.Assign)
    assert 'x_0' in res[0].__dict__.values()
    assert 'y_0' in res[1].__dict__.values()
    

# Generated at 2022-06-12 04:42:02.062753
# Unit test for function find_variables
def test_find_variables():
    code = """\
    let(x)
    x = 1
    y = 2
    x, y = y, x
    """
    tree = ast.parse(code)
    variables = find_variables(tree)
    assert list(variables)[0] == 'x'
    assert tree.body[0].value == lit(1)
    assert tree.body[1].value == lit(2)
    assert tree.body[2].targets[0] == lit(2)
    assert tree.body[2].targets[1] == lit(1)



# Generated at 2022-06-12 04:42:06.937940
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def add_one():
        let(x)
        x += 1

    assert add_one.get_body() == [ast.Assign(targets=[ast.Name(id='_py_backwards_x_0')],
                                            value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0'),
                                                            op=ast.Add(),
                                                            right=ast.Num(n=1)))]



# Generated at 2022-06-12 04:42:15.145102
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    s = snippet(lambda: let(x))
    assert s.get_body() == [ast.Assign(
        targets=[ast.Name(id='_py_backwards_x_0')],
        value=None
    )]

    s = snippet(lambda: let(x))
    assert s.get_body(x=2) == [ast.Assign(
        targets=[ast.Name(id='_py_backwards_x_0')],
        value=ast.Constant(value=2)
    )]

    s = snippet(lambda: let(x))

# Generated at 2022-06-12 04:42:15.918942
# Unit test for function extend_tree

# Generated at 2022-06-12 04:42:20.731023
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from . import examples
    source = get_source(examples.simple_example)
    tree = ast.parse(source)
    examples_snippet = snippet(examples.simple_example)
    variables = examples_snippet._get_variables(tree, {})
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert str(examples.simple_example) == str(ast.fix_missing_locations(tree))

# Generated at 2022-06-12 04:42:21.999597
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:42:36.758064
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def my_snippet(a: int, b: int = 1) -> int:
        c = a + b
        d = c * b
        return d
    tree = ast.parse(get_source(my_snippet))
    variables = find_variables(tree)
    print(variables)
    snippet_kwargs = {"a": ast.parse("1 + 2"), "b": ast.parse("1 + 2")}
    variables.update(snippet_kwargs)
    print(variables)
    extend_tree(tree, variables)
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    print(ast.dump(tree))

# Generated at 2022-06-12 04:42:40.017686
# Unit test for function find_variables
def test_find_variables():
    source = """
let(x)
let(y)
let(z)
x = 1
y = 2
z = 3
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert variables == {'x', 'y', 'z'}



# Generated at 2022-06-12 04:42:44.848475
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: x + 1).get_body() == \
           snippet(lambda x: x + 1).get_body()
    assert str(snippet(lambda x: x + 1).get_body()) == \
           '[Expr(value=BinOp(left=Name(id=\'x\', ctx=Load()), ' \
           'op=Add(), right=Num(n=1)))]'


# Generated at 2022-06-12 04:42:48.855958
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import doctest
    from .helpers import ast_to_string

    def snippet(x: int) -> int:
        let(v)
        v += x + 1
        return v
    snippet = snippet.get_body
    doctest.run_docstring_examples(snippet, globals())

# Generated at 2022-06-12 04:42:57.109309
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    res = snippet(lambda x, y: x + y).get_body(x=1, y=2)
    assert ast.dump(res[0]) == 'Assign(targets=[Name(_py_backwards_x_0, Store())], value=Num(1))'
    assert ast.dump(res[1]) == 'Assign(targets=[Name(_py_backwards_y_1, Store())], value=Num(2))'
    assert ast.dump(res[2]) == 'Expr(value=BinOp(left=Name(_py_backwards_x_0, Load()), op=Add(), right=Name(_py_backwards_y_1, Load())))'

# Generated at 2022-06-12 04:43:06.213524
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test():
        let(a)
        a.b
        let(c)
        a.b = c
        let(d)
        d.e += 7
        extend(vars)
    test_tree = test.get_body(
        a=ast.Name(id='_a'),
        c=['_x', ast.Subscript(ast.Name(id='_a'), 'b', ast.Load), '_x'],
        d=ast.Name(id='_d'),
        vars=['let(abc)']
    )
    # print(ast.dump(test_tree))
    assert len(test_tree) == 3
    assert isinstance(test_tree[0], ast.Assign)

# Generated at 2022-06-12 04:43:12.724670
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fun(x: Any, y: Any):
        let(x)
        let(y)
        x += 1
        y = 1

    tree = fun.get_body(x=ast.Name(id='foo', ctx=ast.Load()), y=1)
    assert isinstance(tree[0], ast.Assign)
    assert isinstance(tree[0].value, ast.BinOp)
    assert isinstance(tree[1], ast.Assign)
    assert isinstance(tree[1].value, ast.Num)

# Generated at 2022-06-12 04:43:21.110610
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def x(a: int, b: int, c: int) -> int:
        x = a + b + c
        return x + let(x)
    
    first = snippet(x).get_body()
    assert ast.dump(first) == u"Expr(value=BinOp(left=Name(id='_py_backwards_x_0', ctx=Load()), op=Add(), right=Name(id='_py_backwards_x_0', ctx=Load())))"
    second = snippet(x).get_body(x=let(5))

# Generated at 2022-06-12 04:43:26.463690
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(var)')
    extend_tree(tree, {'var': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                         value=ast.Num(n=1)),
                               ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                          value=ast.Num(n=2))]})
    assert get_source(tree) == 'x = 1\nx = 2'

# Generated at 2022-06-12 04:43:30.938685
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = '_py_backwards_x_0'

    @snippet
    def fn():
        let(x)
        let(x)
        return x

    variables = fn.get_body()

    assert variables == [
        ast.Expr(
            value=ast.Str(s='%s' % x)
        ),
        ast.Expr(
            value=ast.Str(s='%s' % x)
        )
    ]

# Generated at 2022-06-12 04:43:47.111032
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .test_helpers import assert_tree_equal
    assert_tree_equal(
        snippet(lambda x=let(2): x).get_body(),
        snippet(lambda x: x).get_body(x=2)
    )
    assert_tree_equal(
        snippet(lambda x=let(2): x).get_body(x=3),
        snippet(lambda x: x).get_body(x=3)
    )
    assert_tree_equal(
        snippet(lambda x=let(2), y=let(3): x + y).get_body(x=let(4), y=let(5)),
        snippet(lambda x, y: x + y).get_body(x=4, y=5)
    )

# Generated at 2022-06-12 04:43:55.179598
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: x).get_body() == [ast.parse(get_source(lambda x: x)).body[0].body[0]]
    assert snippet(lambda x: x + 1).get_body() == [ast.parse(get_source(lambda x: x + 1)).body[0].body[0]]
    assert snippet(lambda x, y: (let(x),)).get_body(x=1) == [ast.parse(get_source(lambda x, y: (let(x),))).body[0].body[0]]
    assert snippet(lambda x: (let(x),)).get_body(x=1) == [ast.parse(get_source(lambda x: (let(x),))).body[0].body[0]]
    assert snippet(lambda x, y: (let(x),)).get_

# Generated at 2022-06-12 04:44:02.940028
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(func)
    import ast as ast_test
    x = ast_test.parse('x = 1')
    y = ast_test.parse('y = 2')
    x_id = ast_test.parse('x')
    y_id = ast_test.parse('y')
    assert snippet_obj.get_body(x=x, y=y) == [ast_test.Assign(targets=[x_id.body[0].value], value=x.body[0].value),
                                              ast_test.Assign(targets=[y_id.body[0].value], value=y.body[0].value)]

# Generated at 2022-06-12 04:44:11.292981
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # init
    @snippet
    def _():
        let(x)
        x += 1  # type: ignore
        y = 1

    # run
    res = _.get_body(x=1, y=1)

    # verify
    assert len(res) == 2
    assert isinstance(res[0], ast.AugAssign)
    assert res[0].target.id == '_py_backwards_x_0'
    assert isinstance(res[0].value, ast.Num)
    assert res[0].value.n == 1
    assert isinstance(res[1], ast.Assign)
    assert res[1].targets[0].id == 'y'
    assert isinstance(res[1].value, ast.Num)
    assert res[1].value.n == 1

# Generated at 2022-06-12 04:44:19.913417
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    obj = snippet(lambda: None)
    assert obj.get_body() == []

    obj = snippet(lambda x, y: None)
    assert obj.get_body() == []

    x = let(None)
    obj = snippet(lambda x, y: x + y)
    assert obj.get_body(x=1) == [ast.Expr(value=ast.BinOp(
        left=ast.Num(1), op=ast.Add(), right=ast.Name(id='y', ctx=ast.Load())))]

    x = let(None)
    obj = snippet(lambda x, y: x + y)

# Generated at 2022-06-12 04:44:26.481496
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_snippet_get_body).get_body() == [ast.Pass()]
    assert snippet(test_snippet_get_body).get_body(x=1) == [
        ast.Expr(
            value=ast.Constant(
                value=1,
            )
        )
    ]
    assert snippet(test_snippet_get_body).get_body(x=2) == [
        ast.Expr(
            value=ast.Constant(
                value=2,
            )
        )
    ]



# Generated at 2022-06-12 04:44:33.716876
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test():
        let(x)
        x += 1
        if True:
            let(y)
            y += 2
            if True:
                print(x, y)
            print(z)
            v = x + y
            print(v)
        print(x)
        print(x + y)
        

# Generated at 2022-06-12 04:44:42.097726
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def s():
        let(x)
        extend(y)
        print(x, y)


# Generated at 2022-06-12 04:44:45.921915
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    let('x')
    snippet_kwargs = {'x': 3}
    source = """
        let(x)
        x += 1
        y = 1
        """
    code_snippet = snippet(None)
    code_snippet.get_body(**snippet_kwargs) == ast.parse(source).body[0].body

# Generated at 2022-06-12 04:44:54.102957
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 1
    b = 2
    y = 3
    Z = 4
    @snippet
    def test_snippet():
        let(x)
        let(x)
        let(y)
        let(z)
        let(Z)
        x += 1
        z = 1
        print(Z, x, y, z)
        extend(vars)
    vars = [
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=a)),
        ast.Assign([ast.Name(id='z', ctx=ast.Store())], ast.Num(n=b)),
        ast.Assign([ast.Name(id='Z', ctx=ast.Store())], ast.Num(n=y)),
    ]
    actual_

# Generated at 2022-06-12 04:45:31.566545
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert (snippet(lambda x, y: let(x) + y).get_body(x=2, y=[3]) ==
            [ast.Assign(
                targets=[ast.Name(id='_py_backwards_x_0')],
                value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0'),
                                op=ast.Add(),
                                right=ast.Num(n=2)))])

    assert (snippet(lambda x: let(x)).get_body(x=[3]) ==
            [ast.Assign(
                targets=[ast.Name(id='_py_backwards_x_0')],
                value=ast.Num(n=3))])


# Generated at 2022-06-12 04:45:38.541531
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2

    def one():
        let(x)
        x += 1
        y = 1
        return y

    def two():
        let(y)
        x += y
        return y

    def three():
        extend(x)
        print(1)

    one_snippet = snippet(one)
    two_snippet = snippet(two)
    three_snippet = snippet(three)

    print(one_snippet.get_body())
    print(two_snippet.get_body())
    print(three_snippet.get_body())

# Generated at 2022-06-12 04:45:43.119081
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = ast.Name(id='x', ctx=ast.Load())
    y = ast.Name(id='y', ctx=ast.Load())
    @snippet
    def test():
        let(x)
        x += 1
        y = 1

    body = test.get_body()
    assert body[0].value.left.id == '_py_backwards_x_0'  # type: ignore
    assert body[0].value.op.__class__.__name__ == 'Add'  # type: ignore

    body = test.get_body(x=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()))
    assert body[0].value.left.id == '_py_backwards_x_0'  # type: ignore
    assert body

# Generated at 2022-06-12 04:45:49.158509
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    extend(x)
    extend(y)
    """)

    vars_ = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                         value=ast.Num(n=1)),
             ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                         value=ast.Num(n=2)),
             ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                         value=ast.Num(n=1))]

    x = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1))


# Generated at 2022-06-12 04:45:57.714042
# Unit test for function find_variables

# Generated at 2022-06-12 04:46:01.855189
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1
    
    body = snippet(test_fn).get_body()
    assert body[0].value.id == '_py_backwards_x_0'
    assert body[1].targets[0].id == 'y'

# Generated at 2022-06-12 04:46:05.813699
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        x = let(1)
        y = let(2)
        print(x + y)

    snippet = snippet(f).get_body()
    assert snippet == ast.parse('_py_backwards_x_0 + _py_backwards_y_0').body # type: ignore

# Generated at 2022-06-12 04:46:11.956669
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def func(x: int) -> int:
        let(x)
        x += 1
        let(y)
        y = 1
        return y + let(z) + z


# Generated at 2022-06-12 04:46:14.306220
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(ast.parse('let(x)\nx += 1\nlet(y)\ny = 1\n')) == ['x', 'y']


# Unit tests for function snippet

# Generated at 2022-06-12 04:46:17.717910
# Unit test for function find_variables
def test_find_variables():
    source = """\
let(a)
let(b)
let(c)
"""

    assert find_variables(ast.parse(source)) == ['a', 'b', 'c']
    print('PASSED')

