

# Generated at 2022-06-12 04:36:45.253964
# Unit test for function extend_tree
def test_extend_tree():  # noqa
    def test_snippet():
        let(vars)
        x = 1
        y = 2

    extend_kwargs = {'vars': ast.Module(body=[
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ])}

    tree = ast.parse(inspect.getsource(test_snippet))
    extend_tree(tree, extend_kwargs)
    expected = ast.parse('''
    x = 1
    y = 2
    ''')

# Generated at 2022-06-12 04:36:54.713318
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f1(x: int, y: int) -> int:
        return x + y

    def f2(x: int, y: int) -> int:
        let(z)
        z = x + y

    def f3(x: int, y: int) -> int:
        extend(z)
        z = x + y

    snippet1 = snippet(f1)
    snippet2 = snippet(f2)
    snippet3 = snippet(f3)

    a1 = snippet1.get_body(x=1, y=2)
    a2 = snippet2.get_body(x=1, y=2)
    a3 = snippet3.get_body(x=1, y=2)


# Generated at 2022-06-12 04:37:02.189993
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\na = 1')
    extend_tree(tree, {'vars': [ast.parse('x = 1').body[0], \
                                ast.parse('x = 2').body[0]]})
    assert ast.dump(tree) == "Module([Assign([(Name(id='x', ctx=Store()), Num(n=1))], []), Assign([(Name(id='x', ctx=Store()), Num(n=2))], []), Assign([(Name(id='a', ctx=Store()), Num(n=1))], [])])"

# Generated at 2022-06-12 04:37:12.391529
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse(textwrap.dedent(
        '''
            let(vars)
            extend(vars)
            let(params)
            extend(params)
        '''))
    extend_tree(tree, {
        'vars': [ast.parse(textwrap.dedent(
            '''
                x = 1
                x = 2
            ''')).body],
        'params': ast.parse(textwrap.dedent(
            '''
                a = 1
                b = 2
            ''')).body,
    })

# Generated at 2022-06-12 04:37:19.789967
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # Variable name is used in the import statement
    node = ast.parse("import testtest")
    variables = {"testtest": "newtest"}
    tree = VariablesReplacer.replace(node, variables)
    assert get_source(tree) == "import newtest"

    # Variable name is used in the import statement and as a module
    node = ast.parse("import testtest")
    variables = {"testtest": ast.Name(id="newtest", ctx=ast.Load())}
    tree = VariablesReplacer.replace(node, variables)
    assert get_source(tree) == "import newtest.testtest"


# Generated at 2022-06-12 04:37:28.759143
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .parser import parse_stmts

    def test_snippet(x=1, y=2):
        let(a)
        let(b)
        return a * x + b * y


# Generated at 2022-06-12 04:37:37.174499
# Unit test for function extend_tree
def test_extend_tree():
    import unittest.mock
    def foo():
        let(x)
        let(z)
        y = 1
        extend(z)
        print(x, y)

    tree = ast.parse(get_source(foo))
    let1, let2, assign, extend_, print_ = tree.body[0].body
    let_x = let1.args[0].id
    let_y = let2.args[0].id
    param = ast.Name(id=let_y, ctx=ast.Store())
    assign.value = ast.List([ast.Num(42), param], ast.Store())
    extend_tree(tree, {let_x: assign, let_y: extend_})

    assert tree.body[0].body[-1].value.elts[1].id == let_

# Generated at 2022-06-12 04:37:48.088738
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""extend(variables)
    print(x)""")
    variables = {
        'variables': [
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))
        ],
    }
    extend_tree(tree, variables)

# Generated at 2022-06-12 04:37:54.780909
# Unit test for function extend_tree
def test_extend_tree():
    code = """
extend(vars)
print(x, y)
    """
    tree = ast.parse(code)
    vars = [
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=1)),
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})
    assert tree.body[0].value.args[0].id == 'x'  # type: ignore
    assert tree.body[0].value.args[1].id == 'y'  # type: ignore
    assert tree.body[1].value.args[0].n == 1  # type: ignore

# Generated at 2022-06-12 04:38:00.696765
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet(x):
        let(x)
        x += 1

    body = test_snippet.get_body()
    assert isinstance(body, List)
    assert isinstance(body[0], ast.AugAssign)
    assert body[0].target.id == '_py_backwards_x_0'


if __name__ == '__main__':
    test_snippet_get_body()

# Generated at 2022-06-12 04:38:18.650142
# Unit test for function extend_tree
def test_extend_tree():
    def test_fn():
        let(x)
        extend(vars)
        print()

    # declare AST of assignments
    extend_vars = ast.parse('''x = 1
x = 2''').body

    tree = ast.parse(get_source(test_fn))
    variables = {'vars': extend_vars, 'x': '_x'}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

    assert len(tree.body[0].body) == 3
    assert isinstance(tree.body[0].body[0], ast.Assign)
    assert isinstance(tree.body[0].body[1], ast.Assign)



# Generated at 2022-06-12 04:38:27.575209
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse(
        """
        let(x)
        extend(vars)
        x += 1
        """
    )
    extend_tree(
        tree,
        {
            'x': ast.parse(
                """
                x = 1
                x = 2
                """
            ).body
        }
    )
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Constant(value=1)), Assign(targets=[Name(id=\'x\', ctx=Store())], value=Constant(value=2)), AugAssign(target=Name(id=\'x\', ctx=Load()), op=Add(), value=Constant(value=1))])'

# Generated at 2022-06-12 04:38:35.208179
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    extend(x)
    print(y)
    """
    tree = ast.parse(source)

    variables = {'x': [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(1)),
                       ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(2))],
                 'y': ast.Num(3)}
    extend_tree(tree, variables)

    assert len(tree.body) == 3
    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[1], ast.Assign)
    assert isinstance(tree.body[1].targets[0], ast.Name)
    assert isinstance(tree.body[2], ast.Expr)


# Generated at 2022-06-12 04:38:41.910142
# Unit test for function extend_tree
def test_extend_tree():
    def test_fn():
        x = 1
        extend(vars)
        print(x)

    extend_tree(ast.parse(get_source(test_fn)), {'vars': [
        ast.parse('x = 2').body[0]
    ]})


# Generated at 2022-06-12 04:38:42.864773
# Unit test for function extend_tree

# Generated at 2022-06-12 04:38:51.394093
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        extend(vars)
        let(c)
        let(a)
        c = d
        a = b


# Generated at 2022-06-12 04:39:00.421071
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = ast.Name(id='x', ctx=ast.Load())
    y = ast.Name(id='y', ctx=ast.Load())
    x = ast.Name(id='x', ctx=ast.Load())
    y = ast.Name(id='y', ctx=ast.Load())
    @snippet
    def snippet_test(x: ast.AST, y: ast.AST):
        let(x)
        x += 1
        y = 1

    ast_from_snippet = snippet_test.get_body()


# Generated at 2022-06-12 04:39:04.573797
# Unit test for function extend_tree
def test_extend_tree():
    code = """
            extend(tree)
            tree += 1
            """
    var = [ast.Assign([ast.Name(id='tree', ctx=ast.Store())],
                      ast.Num(1))]
    tree = ast.parse(code)
    extend_tree(tree, {'tree': var})
    assert tree.body[0].value.elts[0].value.n == 1

# Generated at 2022-06-12 04:39:13.075459
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse('''
        let(x)
        let(y)
        def let(x):
            pass
        x = let(1)
        y = 2
    '''))) == ['x', 'y']

    assert list(find_variables(ast.parse('''
        x = 1
        y = 2
    '''))) == []

    # test that let call is removed
    assert (get_source(ast.parse('''
        let(x)
        let(y)
        def let(x):
            pass
        x = let(1)
        y = 2
    ''')) == '''
        def let(x):
            pass
        x = let(1)
        y = 2
    ''')


# Generated at 2022-06-12 04:39:18.309139
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    i = let(1)
    j = let(i)
    assert snippet(lambda i, j: i + j).get_body(i=2, j=3) == [ast.Expr(ast.BinOp(ast.Name('_py_backwards_i_0', ast.Load()), ast.Add(), ast.Name('_py_backwards_j_0', ast.Load())))]

# Generated at 2022-06-12 04:39:29.418645
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    x += 1
    y = 2
    """)
    names = list(find_variables(tree))
    assert names == ['x']

    tree = ast.parse("""
    let(a)
    a += 1
    let(b)
    a + b
    """)
    names = list(find_variables(tree))
    assert names == ['a', 'b']



# Generated at 2022-06-12 04:39:37.711984
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(ex)
    pass
    """)
    extend_tree(tree, {'ex': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store()),
                                                 ast.Name(id='y', ctx=ast.Store())],
                                       value=ast.Num(n=1))]})
    module = ast.Module([ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store()),
                                             ast.Name(id='y', ctx=ast.Store())],
                                   value=ast.Num(n=1)),
                         ast.Pass()])

    assert ast.dump(tree) == ast.dump(module)



# Generated at 2022-06-12 04:39:38.268596
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:39:41.883800
# Unit test for function find_variables
def test_find_variables():
    source = """
a = 1
let(x)
let(y)
x = y
    """
    tree = ast.parse(source)
    assert next(find_variables(tree)) == 'x'
    assert next(find_variables(tree)) == 'y'



# Generated at 2022-06-12 04:39:44.295631
# Unit test for function find_variables
def test_find_variables():
    """Unit test for function `find_variables`"""
    assert set(find_variables(ast.parse("let(x)\nlet(y)"))) == {'x', 'y'}

# Generated at 2022-06-12 04:39:53.723061
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo():
        let(a)
        a += 1
        b = 2
        extend(vars)
        return a + b

    foo.__code__ = foo.__code__.replace(co_firstlineno, 1)
    tree = snippet(foo).get_body(vars=[ast.Assign([ast.Name('a', ast.Store())],
                                                  ast.Num(1))])

# Generated at 2022-06-12 04:39:55.481560
# Unit test for function extend_tree
def test_extend_tree():
    from .test.test_snippets import test_extend_tree
    test_extend_tree()


# Generated at 2022-06-12 04:39:59.750831
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''
let(a)
let(b)
    c = 1
    ''')

    names = find_variables(tree)
    assert 'a' in names
    assert 'b' in names
    assert 'c' not in names

    assert find_variables(tree) == ['a', 'b']



# Generated at 2022-06-12 04:40:02.399370
# Unit test for function find_variables
def test_find_variables():  # pragma: no cover
    from .helpers import parse_string
    find_variables(parse_string("""let(x)
x += 1
y = 1"""))



# Generated at 2022-06-12 04:40:11.130938
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse("a = 1"))) == []
    assert list(find_variables(ast.parse("let(a); a = 5"))) == ["a"]
    assert list(find_variables(ast.parse("let(a); let(b); a = b"))) == ["a", "b"]
    assert list(find_variables(ast.parse("let(a); a = 1\na = 2"))) == ["a"]
    assert list(find_variables(ast.parse("let(a); a = 1\nlet(b); b = 2"))) == ["a", "b"]
    assert list(find_variables(ast.parse("let(a); a = 1\nlet(b); b = 2\na = b"))) == ["a", "b"]

# Generated at 2022-06-12 04:40:23.741934
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import astor
    @snippet
    def test(x: int) -> None:
        let(y)
        y += 1
        z = x + y
        let(w)
        w = z + w + 1
    node = ast.parse('def test(x, y, z):\n\ty = x + y\n\tz = x + y')
    assert astor.dump_tree(test.get_body(y=node)) == 'y = x + y\n'
    assert astor.dump_tree(test.get_body(y=node, z=node)) == 'y = x + y\nz = x + y\n'

# Generated at 2022-06-12 04:40:31.607720
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    x = 1
    let(x)
    extend(x)
    """
    tree = ast.parse(source)
    extend_tree(tree, {'x': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(1))]})

    assert ast.dump(tree) == 'Module([Assign(targets=[Name(id="x", ctx=Store())], value=Num(1)), Assign(targets=[Name(id="x", ctx=Store())], value=Num(1))])'
# P.S.: ast.dump() for test is much more readable then str(tree)



# Generated at 2022-06-12 04:40:38.211513
# Unit test for function extend_tree
def test_extend_tree():
    a = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Str(s='1'))
    b = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Str(s='2'))
    extend_tree(ast.parse('extend({a}); print(x, y)'), {'a': [a, b]})

# Generated at 2022-06-12 04:40:42.571922
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''
    extend(vars)
    a = 3
    ''')
    vars = ast.parse('''
    a = 1
    a = 2
    ''')
    extend_tree(tree, {'vars': vars.body})
    assert ast.dump(tree) == ast.dump(vars)


# Generated at 2022-06-12 04:40:50.776160
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""x=1
    extend(vars)
    y = x""")
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
                                ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))]})
    tree = ast.fix_missing_locations(tree)

# Generated at 2022-06-12 04:40:51.598511
# Unit test for function find_variables

# Generated at 2022-06-12 04:40:57.798560
# Unit test for function extend_tree
def test_extend_tree():
    source = """
vars = []
extend(vars)
a = 1
print(a)
"""

    tree = ast.parse(source)
    kwarg = ast.keyword(arg='vars', value=ast.List(elts=[
                       ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=1))]))
    extend_tree(tree, {'vars': kwarg})
    assert get_source(tree) == """\
vars = []
a = 1
print(a)
"""

# Generated at 2022-06-12 04:40:59.925222
# Unit test for function find_variables
def test_find_variables():
    code = """
        a = let(1)
    """
    tree = ast.parse(code)
    assert list(find_variables(tree)) == ['a']



# Generated at 2022-06-12 04:41:08.165053
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _get_body(fn, **kwargs):
        return snippet(fn).get_body(**kwargs)  # type: ignore

    def _compare_source(fn, body):
        source = get_source(fn)
        source = source[source.index('):') + 2:]
        return source == body

    def _test(fn, body):
        assert _compare_source(fn, body)

    def fn():
        let(x)
        x += 1
        y = 1

    _test(fn, ' x += 1\n y = 1')

    def fn():
        let(x)
        let(y)
        x += 1
        y = 1

    _test(fn, ' _py_backwards_x_0 += 1\n _py_backwards_y_0 = 1')



# Generated at 2022-06-12 04:41:12.402983
# Unit test for function extend_tree
def test_extend_tree():
    fn = snippet(lambda x: extend(x))
    source = ast.parse("""x = 1
x = 2\n""")  # type: ignore
    tree = ast.parse("""extend(x)""")
    extend_tree(tree, {'x': source})
    assert tree.body[0].body[0].value.right.n == 2  # type: ignore



# Generated at 2022-06-12 04:41:19.621449
# Unit test for function find_variables

# Generated at 2022-06-12 04:41:28.181390
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test(a, b):
        i = 0
        let(b)
        extend(a)
        i += 2
        y = 2
        z = a + b
        return z + y
    a = [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=1)),
         ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=2))]
    b = ast.Name(id='b', ctx=ast.Load())
    body = snippet(test).get_body(a=a, b=b)

# Generated at 2022-06-12 04:41:34.017960
# Unit test for function find_variables
def test_find_variables():
    # function object that will be mocked
    def _find(tree, theclass):
        return [tree]

    # setup
    import sys
    import unittest.mock

    with unittest.mock.patch('_py_backwards.tree.find', _find):
        source = """let(x)
                   print(x)"""
        tree = ast.parse(source)

        # run
        variables = find_variables(tree)
        assert list(variables) == ['x']



# Generated at 2022-06-12 04:41:37.639850
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def check(fn: Callable[..., None], **kwargs: ast.AST) -> None:
        s = snippet(fn)
        s.get_body(**kwargs)  # type: ignore
    check(lambda x, y: None, x=ast.parse("x"), y=ast.parse("y"))

# Generated at 2022-06-12 04:41:46.530750
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        x += 1
        y = 1

    res = snippet(f).get_body()
    assert type(res) == list
    assert len(res) == 2
    assert type(res[0]) == ast.Assign
    assert type(res[1]) == ast.Assign
    assert type(res[0].targets[0]) == ast.Name
    assert type(res[0].targets[0].ctx) == ast.Store
    assert type(res[0].value) == ast.BinOp
    assert type(res[0].value.left) == ast.Name
    assert type(res[0].value.op) == ast.Add
    assert type(res[0].value.right) == ast.Num

# Generated at 2022-06-12 04:41:55.831564
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    global x, _py_backwards_x_0
    global y, _py_backwards_y_1
    global z, _py_backwards_z_2
    global _py_backwards_z_1
    global _py_backwards_q_3
    _py_backwards_a_0 = 'a'
    _py_backwards_x_0 = 'x'
    _py_backwards_y_1 = 'y'
    _py_backwards_z_2 = 'z'
    _py_backwards_z_1 = 'z'
    _py_backwards_q_3 = 'q'
    global _py_backwards_x_1
    global _py_backwards_q_2
    _py_backwards_x_1 = 'x'
    _py_

# Generated at 2022-06-12 04:42:01.228151
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1

    fn = snippet(test_fn)
    body = fn.get_body()
    assert body == [ast.AugAssign(ast.Name('_py_backwards_x_0', ast.Store()),
                                  ast.Add(), ast.Num(1)),
                    ast.Assign(targets=[ast.Name('y', ast.Store())],
                               value=ast.Num(1))]



# Generated at 2022-06-12 04:42:06.346546
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 2
    y = 3
    z = 4
    # We want to test this code:
    fn = lambda x, y, z: x * y * z
    tree = snippet(fn).get_body(x=x, y=y, z=z)
    assert tree == [ast.Expr(ast.BinOp(ast.BinOp(ast.Num(2),
                                                ast.Mult(),
                                                ast.Num(3)),
                                       ast.Mult(),
                                       ast.Num(4)))]

# Generated at 2022-06-12 04:42:10.631972
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_func():
        let(a)
        b = a

    snippet_class = snippet(test_func)
    tree = snippet_class.get_body()

    print(tree)
    assert tree[0].targets[0].id == '_py_backwards_a_0'
    assert tree[1].value.id == '_py_backwards_a_0'

# Generated at 2022-06-12 04:42:15.010686
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import get_source
    @snippet
    def foo(x: int, y: int) -> int:
        let(a)
        a += 1
        b = 2
        return a + b

    snip = foo.get_body(x=2)
    assert get_source(snip) == '_py_backwards_a_0 += 1\nb = 2\n'

# Generated at 2022-06-12 04:42:27.614970
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x, y):
        let(x)
        x += 1
        y = 1

    assert snippet(test_snippet).get_body() == [
        ast.AugAssign(
            target=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
            op=ast.Add(),
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-12 04:42:36.145145
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test(x: int, y: int) -> int:
        let(y)
        return y + x

    code = snippet(test).get_body(x=1)
    assert ast.dump(code) == ast.dump([
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_y_0', ctx=ast.Store())],
            value=ast.Name(id='y', ctx=ast.Load())),
        ast.Return(value=ast.BinOp(
            left=ast.Name(id='_py_backwards_y_0', ctx=ast.Load()),
            op=ast.Add(),
            right=ast.Name(id='x', ctx=ast.Load()))),
    ])

# Generated at 2022-06-12 04:42:44.302654
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 1
    b = 2
    @snippet
    def test():
        assert a == let(a)
        assert b == let(b)
        print('a + b = ' + str(a + b))
        return a

    tree_body = test.get_body()
    assert tree_body[0].test.left.id == 'a'
    assert tree_body[0].test.comparators[0].id == '_py_backwards_a_0'
    assert tree_body[0].test.comparators[0].id != tree_body[0].test.left.id

    assert tree_body[1].test.left.id == 'b'
    assert tree_body[1].test.comparators[0].id == '_py_backwards_b_0'

# Generated at 2022-06-12 04:42:46.704944
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Arrange
    snp = snippet(lambda: let(x))
    # Act
    body = snp.get_body()
    # Assert
    assert len(body) == 0



# Generated at 2022-06-12 04:42:48.167896
# Unit test for function find_variables

# Generated at 2022-06-12 04:42:56.372889
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class B:
        pass
    
    fn = lambda x, y: let(x) + x + y + extend(B) + print(x, y)

# Generated at 2022-06-12 04:42:59.422419
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda: let(x) or x + 2).get_body() == [ast.Expr(value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0'), op=ast.Add(), right=ast.Num(n=2)))]

# Generated at 2022-06-12 04:43:06.885451
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    # snippet that we want to test
    test_snippet = snippet(test_fn)

    # get body of snippet
    body = test_snippet.get_body(x=1, y=1, vars=[])

    # assert body of snippet
    assert len(body) == 3
    assert type(body[0]) is ast.AugAssign
    assert type(body[1]) is ast.Assign
    assert type(body[2]) is ast.Expr

# Generated at 2022-06-12 04:43:11.107613
# Unit test for function find_variables
def test_find_variables():
    source = '''
        let(x)
        let(y)
        x = 1
        y = 2
        def foo():
            let(z)
            return x + y + z
    '''

    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-12 04:43:19.789609
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn1(a: int, b: int, c: int) -> List[ast.AST]:
        let(x)
        let(y)
        let(z)
        x = a + 1
        y = b + 2
        z = c + a - b
        return [x, y, z]

    def snippet_fn2(a: int, b: int) -> List[ast.AST]:
        extend(vars)
        let(x)
        let(y)
        z = a - b
        return [x, y, z]

    tree1 = snippet(snippet_fn1).get_body(a=2, b=3, c=2)

# Generated at 2022-06-12 04:43:37.726847
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def body():
        let(x)
        return x
    snippet_obj = snippet(body)
    snippet_body = snippet_obj.get_body({'x': 3})
    assert snippet_body == [ast.Return(ast.Name('_py_backwards_x_0'))]

# Generated at 2022-06-12 04:43:41.312420
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    s = snippet(lambda x, y: let(x) + let(y) * y + x)
    assert len(s.get_body(x=1, y=2)) == 3
    assert len(s.get_body(x=1, y=2)) == 3
    assert len(s.get_body(x=1, y=3)) == 3

# Generated at 2022-06-12 04:43:44.734935
# Unit test for function find_variables
def test_find_variables():
    source = '''
    def f(a):
        let(x)
        x += 1
        return x + 1
    '''
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x']



# Generated at 2022-06-12 04:43:45.574636
# Unit test for function extend_tree

# Generated at 2022-06-12 04:43:48.986819
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''
        if True:
            let(x)
            let(y)
        else:
            let(z)
    ''')
    assert set(name for name in find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-12 04:43:57.589471
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = get_source(test_snippet_get_body) # type: ignore
    tree = ast.parse(source)
    snippet_kwargs = {}
    variables = {'y': [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                                 value=ast.Num(n=1))]}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-12 04:43:59.479004
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def function():
        let(x)
        x += 1
    function()
    assert isinstance(function.get_body(), type([]))



# Generated at 2022-06-12 04:44:04.817470
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''
        extend(a)
        extend(b)
        extend(c)
    ''')
    a = ast.parse('x = 1')
    b = ast.parse('y = 2')
    c = ast.parse('z = 3')
    extend_tree(tree, {'a': a, 'b': b, 'c': c})
    assert ast.dump(tree) == ast.dump(ast.parse('x = 1; y = 2; z = 3;'))

# Generated at 2022-06-12 04:44:10.133034
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse(
        """
        def fn():
            extend(vars)
            print(x, y, z)
        """
    )
    vars = ast.parse('x = 1\nx = 2').body
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == 'def fn():\n\tx = 1\n\tx = 2\n\tprint(x, y, z)'

# Generated at 2022-06-12 04:44:15.469108
# Unit test for function extend_tree
def test_extend_tree():
    # Declare simple snippet
    @snippet
    def test_snippet(vars: ast.AST, y: str):
        extend(vars)
        print(y)

    # Declare tree as x = 1
    tree: ast.AST = ast.parse("x = 1")

    # Extend function
    extend_tree(tree, {'vars': tree})

    # Check that x is equal to 1
    assert get_source(tree) == 'x = 1'



# Generated at 2022-06-12 04:44:50.389471
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_func(x: int) -> str:
        let(a)
        extend(b)
        let(c)
        return (a + x)

    body_done = snippet(snippet_func).get_body(b=ast.parse('y = 1'), c=2)
    body_expected = """\
y = 1
_py_backwards_a_0 = 2
_py_backwards_return_0 = (_py_backwards_a_0 + x)
"""
    assert ast.dump(ast.parse(body_expected)) == ast.dump(ast.Module(body=body_done))

# Generated at 2022-06-12 04:44:58.233936
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snp(x: int) -> None:
        let(y)  # y will be replaced by a unique name
        x += y

    snp_obj = snippet(snp)
    x = ast.parse('x = 1').body[0]  # `x = 1` assignment
    y = ast.parse('y = 2').body[0]  # `y = 2` assignment

    body = snp_obj.get_body(x=x, y=y)  # should be like: `_py_backwards_x_0 = 1` and `x += _py_backwards_x_0`
    assert ast.dump(body[0]) == ast.dump(ast.parse('_py_backwards_x_0 = 1').body[0])

# Generated at 2022-06-12 04:45:06.800143
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:45:15.178643
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(a: int):
        let(a)
        b = 1
        return a

    assert test.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_a_0')],  # type: ignore
            value=ast.Name(id='a')),
        ast.Assign(
            targets=[ast.Name(id='b')],
            value=ast.Num(n=1)),
        ast.Return(value=ast.Name(id='_py_backwards_a_0'))  # type: ignore
    ]

# Generated at 2022-06-12 04:45:23.210525
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def body(x: Any, y: Any) -> List[ast.AST]:
        x += 1
        y += 1
        return [
            ast.AugAssign(
                target=ast.Name(id=x, ctx=ast.Load()),
                op=ast.Add(),
                value=ast.Num(n=1)
            ),
            ast.AugAssign(
                target=ast.Name(id=y, ctx=ast.Load()),
                op=ast.Add(),
                value=ast.Num(n=1)
            )
        ]

    snip = snippet(body)
    assert list(snip.get_body()) == body(let(None), let(None))



# Generated at 2022-06-12 04:45:28.609558
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    lets = {'x': 1, 'y': 2}

    @snippet
    def test():
        let(x)  # type: ignore
        z = x + y  # type: ignore

    source = get_source(test)
    tree = ast.parse(source)
    variables = test.get_variables(tree, lets)
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == 'z = 1 + 2'

# Generated at 2022-06-12 04:45:29.753055
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:45:38.930017
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(my_var)
        a = my_var + 1

    snippet_ = snippet(test)
    body = snippet_.get_body(my_var=1)
    code = ast.dump(body[0])
    print_code = ast.dump(body[1])
    assert code == "Assign(targets=[Name(id='_py_backwards_my_var_0', ctx=Store())], value=BinOp(left=Num(n=1), op=Add(), right=Name(id='my_var', ctx=Load())))", code

# Generated at 2022-06-12 04:45:43.430181
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast
    import astor
    import inspect

    class snippet:
        """Snippet of code."""

        def __init__(self, fn: Callable[..., None]) -> None:
            self._fn = fn

        def _get_variables(self, tree: ast.AST,
                           snippet_kwargs: Dict[str, Variable]) -> Dict[str, Variable]:
            names = find_variables(tree)
            variables = {name: VariablesGenerator.generate(name)
                         for name in names}

            for key, val in snippet_kwargs.items():
                if isinstance(val, ast.Name):
                    variables[key] = val.id
                else:
                    variables[key] = val  # type: ignore

            return variables  # type: ignore


# Generated at 2022-06-12 04:45:49.245907
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 1
    let(a)
    a += 1

    snippet_fn = snippet(lambda: None)
    body = snippet_fn.get_body()
    assert body == [
        ast.Assign([ast.Name('_py_backwards_a_0', ast.Store())],
                   ast.BinOp(ast.Name('_py_backwards_a_0', ast.Load()),
                             ast.Add(),
                             ast.Num(1))),
    ]

    a = 1
    b = 2
    let(a)
    let(b)
    a += b

    snippet_fn = snippet(lambda: None)
    body = snippet_fn.get_body()