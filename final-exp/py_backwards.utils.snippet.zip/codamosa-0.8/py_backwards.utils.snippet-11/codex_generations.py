

# Generated at 2022-06-12 04:36:39.347316
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse('from os.path import join')
    inst = VariablesReplacer({'os': 'sys', 'join': 'ensure_dir'})
    inst.visit(tree)
    assert get_source(tree) == 'from sys.path import ensure_dir'

# Generated at 2022-06-12 04:36:47.605393
# Unit test for function extend_tree
def test_extend_tree():
    def fn():
        extend(vars)
        print(x)

    vars = ast.parse('x = 1\nx = 2').body
    tree = ast.parse(get_source(fn))
    extend_tree(tree, {'vars': vars})
    assert find_variables(tree) == []
    assert len(tree.body[0].body) == 3
    assert ast.dump(tree.body[0].body[0]) == 'Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=1))'
    assert ast.dump(tree.body[0].body[1]) == 'Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=2))'

# Generated at 2022-06-12 04:36:50.957072
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(x)\nlet(y)\nlet(z)")
    actual = set(find_variables(tree))
    assert actual == {'x', 'y', 'z'}



# Generated at 2022-06-12 04:36:55.986781
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    v = {'a': 'b'}

# Generated at 2022-06-12 04:37:05.269329
# Unit test for function extend_tree
def test_extend_tree():
    source = get_source(test_extend_tree)
    tree = ast.parse(source)
    extend_tree(tree, {'x': [ast.parse('x = 1').body[0], ast.parse('x = 2').body[0]]})
    assert ast.dump(tree) == """
    Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)),
                    Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2)), 
                    Print(dest=None, values=[Name(id='x', ctx=Load()), Name(id='y', ctx=Load())], nl=True)])
    """.strip()

# Generated at 2022-06-12 04:37:12.387153
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # Arrange
    source = 'from module_1.module_2 import obj_1, obj_2'
    expected = 'from module_3.module_4 import obj_1, obj_2'
    variables = {
        'module_1': 'module_3',
        'module_2': 'module_4',
    }

    # Act
    node = ast.parse(source)
    VariablesReplacer.replace(node, variables)
    result = ast.dump(node)

    # Assert
    assert result == expected

# Generated at 2022-06-12 04:37:21.545455
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def get_body(**kwargs):
        res = snippet(fn).get_body(**kwargs)
        res = ast.fix_missing_locations(ast.Module(body=res))
        return compile(res, filename='<ast>', mode='exec')

    def fn():
        let(x)
        x += 1
        print(y, z)
        print('hello')
        if True:
            print(a, b)
        let(y)
        let(z)
        y += 1
        return 5
        
    globals_ = {'y': 1, 'z': 2, 'a': 3, 'b': 4}
    locals_ = {}
    exec(get_body(), globals_, locals_)
    assert locals_['_py_backwards_x_0'] == 2  # type

# Generated at 2022-06-12 04:37:27.782083
# Unit test for function extend_tree
def test_extend_tree():
    test = "a = {}\na['c'] = 1\na['d'] = 2\nprint(a)"
    with open('tmp.py', 'w') as f:
        f.write(test)
    from .tree import print_tree
    from .run import run_script
    import sys
    import builtins

    @let
    def tmp():
        extend(test)
    run_script('tmp.py', 'tmp', sys.modules, builtins)
    print_tree(tmp().get_body(test=test))



# Generated at 2022-06-12 04:37:31.881991
# Unit test for function find_variables
def test_find_variables():
    body = [let(x), x, let(z), z, let(y), y, extend(vars), let(x), x, extend(vars), let(y), y, z]
    assert list(find_variables(body)) == ['x', 'z', 'y', 'x', 'y']

# Generated at 2022-06-12 04:37:34.654617
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert list(variables) == ['x', 'y', 'z']

# Generated at 2022-06-12 04:37:41.662803
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(x)
y = 1
z = 2

x = 3
""")
    variables = find_variables(tree)
    assert sorted(variables) == ['x', 'y', 'z']



# Generated at 2022-06-12 04:37:48.589299
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        let(y)
        extend(z)

    correct_result = ["x = _py_backwards_x_1", "y = _py_backwards_y_2", 'extend(z)']
    result = snippet(test_snippet).get_body()

    assert [ast.dump(item) for item in result] == correct_result

# Generated at 2022-06-12 04:37:52.585416
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f(x: int) -> int:
        let(y)
        return x + y

    assert f.get_body(y=ast.Num(n=1))[0] == ast.Expr(
        ast.BinOp(ast.Name(id='x', ctx=ast.Load()),
                  ast.Add(), ast.Num(n=1)))

# Generated at 2022-06-12 04:38:01.826973
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(x, y):
        """Some docstring."""
        let(a)
        extend(b)
        c = (1, 2, 3)
        d = 4, 5, 6
        e = (1, 2, 3)
        f = 4, 5, 6
        a += x
        y += 1
        return a, y  # type: ignore


# Generated at 2022-06-12 04:38:06.883370
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import parse_ast_tree

    def test_snippet_with_vars(x: int) -> None:
        let(x)
        x += 1

    body = snippet(test_snippet_with_vars).get_body()
    assert parse_ast_tree(body) == '''\
    _py_backwards_x_0 += 1
    '''



# Generated at 2022-06-12 04:38:07.992616
# Unit test for function extend_tree

# Generated at 2022-06-12 04:38:13.334778
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x: int

    @snippet
    def f():
        extend(x)
        z = 20
        y = x + z
        print(y)
        print(z)
        print('')

    x = 20

    body = f.get_body(x=x, z=10)
    print(ast.dump(ast.Module(body)))

# Generated at 2022-06-12 04:38:19.456868
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda: let(x)).get_body() == [
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   value=ast.Name(id='None', ctx=ast.Load()),
                   type_comment=None),
    ]

    assert snippet(lambda: x).get_body() == [
        ast.Expr(value=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                 type_comment=None),
    ]

    fn = lambda: let(x) and let(x)

# Generated at 2022-06-12 04:38:25.129471
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def body():
        if True:
            let(x)
            y = x + 1
            print(y)
        if False:
            let(z)
            x = z + 1
            print(x)
    assert snippet(body).get_body() == body().body
    assert snippet(body).get_body(x=1) == (ast.parse(body().body[0]).body + [ast.Print(values=[ast.Num(1)])])[0].body



# Generated at 2022-06-12 04:38:33.373975
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, *, y: str) -> None:
        let(x)
        let(y)
        extend(vars)
        return x, y

    variables = {'x': 42, 'y': 'a', 'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                             value=ast.Num(n=1)),
                                             ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                        value=ast.Num(n=2))]}

    snip = snippet(test_snippet)
    body = snip.get_body(**variables)
    assert len(body) == 4
    assert body[0]._py_backwards

# Generated at 2022-06-12 04:38:46.901862
# Unit test for function extend_tree
def test_extend_tree():
    import unittest
    import py_backwards

    @py_backwards.snippet
    def snippet():
        extend(a)
        return x

    tree = ast.parse("x = 1; a = x;")
    py_backwards.extend_tree(tree, {"a": tree.body[0]})
    assert ast.dump(tree) == "Assign(targets=[Name(id='x', ctx=Store())], value=Name(id='x', ctx=Load()))"

    @py_backwards.snippet
    def snippet():
        extend(a)
        return x

    tree = ast.parse("x = 1; a = x;")
    py_backwards.extend_tree(tree, {"a": tree.body[0]})

# Generated at 2022-06-12 04:38:53.532469
# Unit test for function extend_tree
def test_extend_tree():
    def foo(a):
        let(x)
        extend(a)
        y = x
        return y
    source = get_source(foo)
    tree = ast.parse(source)
    a = [ast.Assign([ast.Name(id="x", ctx=ast.Store())], ast.Num(1)),
         ast.Assign([ast.Name(id="x", ctx=ast.Store())], ast.Num(2))]
    variables = {'x': '_py_backwards_x_0'}
    extend_tree(tree, {'a': a})
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-12 04:39:01.696508
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import pytest
    from .helpers import matcher

    @snippet
    def fn1(a):
        a = 1
        return a
    
    variables = matcher(get_body=matcher(
        body=matcher(
            (ast.Assign, {
                'targets': matcher(
                    (ast.Name, {'id': 'a'})
                ),
                'value': 1
            }),
            (ast.Return, {
                'value': matcher(
                    (ast.Name, {'id': 'a'})
                )
            })
        )
    ))
    
    assert variables.match(fn1())

    @snippet
    def fn2(a):
        let(b)
        b = 1
        return b
    

# Generated at 2022-06-12 04:39:07.888298
# Unit test for function extend_tree
def test_extend_tree():
    code = """
let(a)
let(b)
extend(c)
a = 1
b = 2
"""
    tree = ast.parse(code)
    extend_tree(tree, {
        'c': [ast.Assign(
            [ast.Name('a', ast.Load())],
            ast.Num(1)
        )],
    })
    result = ast.dump(tree)
    assert result == 'Module([Assign([Name(a, Load())], Num(1)), Assign([Name(b, Load())], Num(2))])'

# Generated at 2022-06-12 04:39:11.837696
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def get_body():
        let(x)
        y = x + 1
        z = x + y

    snippet = get_body()
    print(snippet.get_body(x=4, y=2))


if __name__ == '__main__':
    test_snippet_get_body()

# Generated at 2022-06-12 04:39:16.935196
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_test(a, b):
        let(a)
        let(b)
        x = a + b
        return x

    x = snippet_test.get_body(a=ast.Num(1), b=ast.Num(2))
    assert x == ast.parse('x = _py_backwards_a_0 + _py_backwards_b_0').body

# Generated at 2022-06-12 04:39:20.941501
# Unit test for function find_variables
def test_find_variables():
    src = """
    def let_test():
        let(a)
        a += 1
        return let(b)
        def c():
            return 1
        let(c)
    """
    tree = ast.parse(src)
    assert set(find_variables(tree)) == {'a', 'b', 'c'}

# Generated at 2022-06-12 04:39:29.380150
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_with_let_statement():
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_instance = snippet(snippet_with_let_statement)


# Generated at 2022-06-12 04:39:38.004534
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse(
        """
        extend(variables)
        extend(variables)
        extend(variables)
        extend(variables)
        """
    )

    variables = {
        'variables': [
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())], value=ast.Num(n=2))
        ]
    }

    extend_tree(tree, variables)

# Generated at 2022-06-12 04:39:46.753864
# Unit test for function extend_tree
def test_extend_tree():
    expected = ast.Module(
        body=[
            ast.Assign(
                targets=[ast.Name(id='x')],
                value=ast.Num(n=1)
            ),
            ast.Assign(
                targets=[ast.Name(id='x')],
                value=ast.Num(n=2)
            ),
            ast.Expr(
                value=ast.Call(
                    func=ast.Name(id='print'),
                    args=[
                        ast.Name(id='x'),
                        ast.Name(id='y')
                    ],
                    keywords=[]
                )
            )
        ]
    )

# Generated at 2022-06-12 04:40:08.448572
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = """
    def f(x):
        if x:
            pass
        else:
            pass

    g = lambda y, z: y + z
    """
    snippet_source = """
    def annotated_f(x: int) -> None:
        let(a)
        a = x
        a += 1
        b = 1
        extend(vars)
        print(b)
    """
    snippets = ast.parse(snippet_source).body

# Generated at 2022-06-12 04:40:18.921966
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert get_source(snippet(lambda x: '').get_body) == get_source(lambda x: '')
    assert get_source(snippet(lambda x: let(x) + 1).get_body) == get_source(lambda x: x + 1)
    assert get_source(snippet(lambda x, y: 2 * x + 2 * y)
                      .get_body(y=let(y))) == get_source(lambda x, y: 2 * x + 2 * y)
    assert get_source(snippet(lambda x, y: 2 * x + 2 * y)
                      .get_body(y=let(y))) == get_source(lambda x, y: 2 * x + 2 * y)

# Generated at 2022-06-12 04:40:26.186388
# Unit test for function extend_tree
def test_extend_tree():
    a = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1))
    b = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))

# Generated at 2022-06-12 04:40:31.885947
# Unit test for function extend_tree
def test_extend_tree():
    snippet_code = """
    extend(snippet_vars)
    """
    ast_snippet = ast.parse(snippet_code)
    snippet_vars = ast.parse("y = 2; z = 3;").body  # type: ignore
    extend_tree(ast_snippet, {'snippet_vars': snippet_vars})
    assert "y = 2\n    z = 3\n    " in ast.dump(ast_snippet)

# Generated at 2022-06-12 04:40:36.499965
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        x += 1
        y = 1
        return x, y

    snippet_code = snippet(f).get_body()
    body = ast.parse('''
    x = 1
    print(x)
    ''')

    assert snippet_code == body.body



# Generated at 2022-06-12 04:40:43.510933
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
x = 1
y = 2
extend(vars)
""")
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(2))]
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
x = 1
y = 2
x = 1
x = 2
"""

# Generated at 2022-06-12 04:40:51.711969
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: int, y: str) -> None:
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    body = test.get_body(x=let(1),
                         y='abc',
                         vars=let(
                             [ast.Assign(
                                 targets=[ast.Name(id='x', ctx=ast.Store())],
                                 value=ast.Num(n=1)
                             ),
                              ast.Assign(
                                  targets=[ast.Name(id='x', ctx=ast.Store())],
                                  value=ast.Num(n=2)
                              ),
                              ]))

# Generated at 2022-06-12 04:40:58.796190
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''
    extend(foo)
    foo = 1
    bar = 2
    ''')
    variables = {
        'foo': [ast.Assign([ast.Name('foo', ast.Store())], ast.Num(42)),
                ast.Assign([ast.Name('bar', ast.Store())], ast.Num(10))]
    }
    extend_tree(tree, variables)
    assert ast.dump(tree) == '''Module(body=[Assign(targets=[Name(id='foo', ctx=Store())], value=Num(n=42)), Assign(targets=[Name(id='bar', ctx=Store())], value=Num(n=10))])'''

# Generated at 2022-06-12 04:41:07.233517
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: x).get_body() == [ast.Expr(ast.Name(id='x'))]
    assert snippet(lambda x: x).get_body(x=1) == [ast.Expr(ast.Num(n=1))]
    assert snippet(lambda x, y: x).get_body(y=1) == [ast.Expr(ast.Name(id='_py_backwards_x_0'))]
    assert snippet(lambda: let(x)).get_body() == []
    assert snippet(lambda x: let(y, x)).get_body(x=1) == []
    assert snippet(lambda x: let(x)).get_body(x=1).__len__() == 0

# Generated at 2022-06-12 04:41:10.304539
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # code
    @snippet
    def f():
        let(x)
        x += 1
    # expected
    ex_body = ast.parse('x += 1').body
    # test
    body = f.get_body()
    assert body == ex_body

# Generated at 2022-06-12 04:41:32.089028
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _get_body(snippet_kwargs):
        return snippet(lambda: let(x)).get_body(**snippet_kwargs)

    tree = _get_body({'x': 1})
    assert len(tree) == 2
    assert isinstance(tree[0], ast.Assign)
    assert isinstance(tree[1], ast.Print)

    tree = _get_body({'x': ast.Name(id='z', ctx=ast.Load())})
    assert len(tree) == 1
    assert isinstance(tree[0], ast.Print)

    tree = _get_body({'y': 1})
    assert len(tree) == 3
    assert isinstance(tree[0], ast.Expr)
    assert isinstance(tree[1], ast.Assign)

# Generated at 2022-06-12 04:41:41.068768
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def transform(x):
        let(y)
        x += y
        extend(z)
        x += z_0
        return x


# Generated at 2022-06-12 04:41:45.905231
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    extend(var)
    foo += 1
    """
    tree = ast.parse(source)
    extend_tree(tree, {'var': [ast.Assign([ast.Name(id='foo', ctx=ast.Store())], ast.Num(n=5))]})
    assert get_source(tree) == """
    foo = 5
    foo += 1
    """

# Generated at 2022-06-12 04:41:55.711145
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x, y: let(x + 1)).get_body() == \
           [ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                       ast.BinOp(ast.Name(id='x', ctx=ast.Load()), ast.Add(),
                                 ast.Num(n=1)))]


# Generated at 2022-06-12 04:41:56.290684
# Unit test for function extend_tree

# Generated at 2022-06-12 04:42:00.393600
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
let(x)
extend(y)
    x = 1
    x = 2
    """)

    extend_tree(tree, {'y': [ast.parse("x = 1"), ast.parse("x = 2")]})

    assert ''.join(get_source(tree).split()) == 'x=1x=2'

# Generated at 2022-06-12 04:42:02.304767
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    fn = lambda x: x.lower()
    body = snippet(fn).get_body(x='X')
    assert body == [ast.parse('return x.lower()').body[0]]

# Generated at 2022-06-12 04:42:09.365472
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_function():
        let(x)
        x += 1
        y = 1

    s = snippet(test_function)
    assert s.get_body() == [
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                   op=ast.Add(),
                                   right=ast.Num(n=1))),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                   value=ast.Num(n=1))
    ]

# Generated at 2022-06-12 04:42:14.041153
# Unit test for function extend_tree
def test_extend_tree():
    new_tree = ast.parse("""x = 1
            x = 2
            y = 3""")
    old_tree = ast.parse("""extend(x)
                y = 3
                """)
    extend_tree(old_tree, {'x': new_tree.body})
    assert ast.dump(old_tree) == ast.dump(
        ast.parse("""x = 1
            x = 2
            y = 3"""))

# Generated at 2022-06-12 04:42:21.767431
# Unit test for function extend_tree
def test_extend_tree():
    source = """def foo():
    let(x)
    x += 1
    y = 1
    extend(vars)
    print(x, y)
"""
    tree = ast.parse(source)
    variables = {'x': '_x', 'vars': [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2)),
    ]}
    extend_tree(tree, variables)

# Generated at 2022-06-12 04:42:49.539013
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn():
        let(x)
        let(y)
        z = 1

    assert fn.get_body() == fn().get_body()

# Generated at 2022-06-12 04:42:55.403233
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: int, y: float = 1.0) -> None:
        let(x)
        x += 1
        extend(y)
        print(x, y)

    body = test.get_body(x=2)
    assert eval(compile(ast.Module(body=[body[0]]), '<ast>', 'exec')) == 2
    assert eval(compile(ast.Module(body=[body[1]]), '<ast>', 'exec')) == 3
    assert isinstance(body[2], ast.Print)

# Generated at 2022-06-12 04:42:58.968373
# Unit test for function extend_tree
def test_extend_tree():
    a = ast.parse("""
    extend(v)
    """)
    b = ast.parse("""
    a = 1
    b = 2
    """)
    extend_tree(a, {'v': b.body})
    assert ast.dump(a) == ast.dump(b)



# Generated at 2022-06-12 04:43:05.883722
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def t():
        x = 1
        y = 2
        let(x)
        x += 1
        y = 1
        extend(vars)

    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))]
    snippet(t).get_body(vars=vars)



# Generated at 2022-06-12 04:43:12.683438
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x=0, y=1):
        let(x)
        let(y)
        x += 1
        y = 1

    snippet_ = snippet(f)

    assert snippet_.get_body(x=1, y=2) == [ast.Assign([ast.AugAssign(ast.Name('_py_backwards_x_0', ast.Store()),
                                                                      ast.Add())], ast.Num(1)),
                                            ast.Assign([ast.Name('_py_backwards_y_1', ast.Store())], ast.Num(1))]

# Generated at 2022-06-12 04:43:21.029464
# Unit test for function extend_tree
def test_extend_tree():
    ast_x = ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=1)
    )
    ast_y = ast.Assign(
        targets=[ast.Name(id='y', ctx=ast.Store())],
        value=ast.Str(s='string')
    )

    func_ast = ast.parse("""
    extend(var)
    print(x, y)
    """)
    extend_tree(func_ast, {'var': ast.Expr(value=ast_x)})
    assert func_ast == ast.parse("""
    x = 1
    print(x, y)
    """)

    extend_tree(func_ast, {'var': ast_x})
    assert func_ast

# Generated at 2022-06-12 04:43:28.759280
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_source = """
    def get_body(self, **snippet_kwargs: Variable) -> List[ast.AST]:
        source = get_source(self._fn)
        tree = ast.parse(source)
        variables = self._get_variables(tree, snippet_kwargs)
        extend_tree(tree, variables)
        VariablesReplacer.replace(tree, variables)
        return tree.body[0].body  # type: ignore
    """
    tree = ast.parse(snippet_source)

# Generated at 2022-06-12 04:43:36.018132
# Unit test for function extend_tree
def test_extend_tree():
    source = """
        extend(vars)

        print(x, y)
    """

    tree = ast.parse(source)
    vars = [
        ast.Assign(
            targets=[ast.Name(id="x", ctx=ast.Store())],
            value=ast.Num(n=1),
        ),
        ast.Assign(
            targets=[ast.Name(id="x", ctx=ast.Store())],
            value=ast.Num(n=2),
        ),
    ]
    extend_tree(tree, {"vars": vars})

# Generated at 2022-06-12 04:43:41.663270
# Unit test for function extend_tree
def test_extend_tree():  # pragma: no cover
    tree = ast.parse("""
    a = 1
    b = 2
    c = 3
    extend(d)
    d = 4
    """)
    variables = {"d" : ast.parse("""
    a = 5
    b = 6
    extends(d)
    d = 7
    """)}
    extend_tree(tree, variables)

# Generated at 2022-06-12 04:43:45.351251
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_func(x: str) -> str:
        return x

    body = snippet_func.get_body()
    assert body == [ast.Return(value=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()))]

# Generated at 2022-06-12 04:44:44.662746
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: x + 1).get_body(x=6) == [
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_0')],
                   value=ast.Num(n=6)),
        ast.Assign(targets=[ast.Name(id='_py_backwards_call_0')],
                   value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0'),
                                   op=ast.Add(),
                                   right=ast.Num(n=1))),
    ]

# Generated at 2022-06-12 04:44:48.827681
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("a = 1; extend(vars); b = 1 + a")
    vars = ast.parse("c = 1; a = 2").body
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("c = 1; a = 2; b = 1 + a"))

# Generated at 2022-06-12 04:44:53.720250
# Unit test for function extend_tree
def test_extend_tree():
    import astor

    def f(stmt: ast.AST) -> None:
        tree = ast.parse('''
a = 1
extend(stmt)
c = 6
''')
        extend_tree(tree, {'stmt': [stmt]})
        assert astor.to_source(tree) == '''
a = 1
b = 2
c = 6
'''

    f(ast.parse('b = 2').body[0])



# Generated at 2022-06-12 04:44:58.561184
# Unit test for function extend_tree
def test_extend_tree():
    readonly = {'readonly': 8}
    tree = ast.parse("extend(readonly)")
    extend_tree(tree, readonly)
    readonly = {'readonly': ast.parse("x = 1")}
    tree = ast.parse("extend(readonly)")
    extend_tree(tree, readonly)
    assert "extend(readonly)" not in ast.dump(tree)
    assert "x = 1" in ast.dump(tree)

# Generated at 2022-06-12 04:45:03.966088
# Unit test for function extend_tree
def test_extend_tree():
    # Function let
    @snippet
    def test_extend(a):
        extend(a)

    t = ast.parse('x = 1')
    test_extend.get_body(a=t)

    # Function extend
    @snippet
    def test_extend_2(a):
        extend(a)
        a = 1 + 1

    t = ast.parse('x = 1')
    test_extend_2.get_body(a=t)


# Generated at 2022-06-12 04:45:07.031815
# Unit test for function extend_tree
def test_extend_tree():
    e = ast.parse('extend(a)')
    a = ast.parse('a = 1')

    extend_tree(e, {'a': a})
    assert ast.dump(e) == ast.dump(a)



# Generated at 2022-06-12 04:45:17.426530
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(1)

    snippet = snippet(test)
    assert snippet.get_body() == [
        ast.Expr(
            value=ast.Call(
                func=ast.Call(
                    func=ast.Name('let', ast.Load()),
                    args=[
                        ast.Num(1, 1)
                    ],
                    keywords=[])
            )
        )
    ]

# Generated at 2022-06-12 04:45:19.849247
# Unit test for method get_body of class snippet
def test_snippet_get_body(): # type: ignore
    ast_stmt = ast.parse("x = 1").body[0]
    assert snippet(lambda x: x).get_body(x=ast_stmt)[0] == ast_stmt

# Generated at 2022-06-12 04:45:28.183348
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('x = 1\nfrom a import b')
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                           value=ast.Num(n=1),
                                           type_comment=None),
                               ast.Expr(value=ast.Str(s='x = 2'))]})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Expr(value=Str(s=\'x = 2\')), ImportFrom(module=\'a\', names=[alias(name=\'b\', asname=None)], level=0)])'

# Unit test

# Generated at 2022-06-12 04:45:35.507107
# Unit test for function extend_tree
def test_extend_tree():
    # pylint: disable=invalid-name
    x = 1
    tree = ast.parse("extend(vars)")
    variables = {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                     value=ast.Constant(value=1, kind=None))]}
    extend_tree(tree, variables)
    assert(tree.body[0].value.targets[0].id) == 'x'
    assert(tree.body[0].value.value.n) == 1
    # pylint: enable=invalid-name