

# Generated at 2022-06-12 04:36:41.254047
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    tree = ast.parse("from a.b.c import d, e")
    replacer = VariablesReplacer({"d": "D"})
    node = replacer.visit(tree)
    assert node == ast.Module(body=[ast.ImportFrom(module="a.b.c", names=[ast.alias(name="D", asname=None)], level=0)])


# Generated at 2022-06-12 04:36:44.496679
# Unit test for function find_variables
def test_find_variables():
    source = """
let(x)
x += 1
let(y)
print(x, y)
"""

    tree = ast.parse(source)
    variables = list(find_variables(tree))
    assert variables == ['x', 'y']


# Generated at 2022-06-12 04:36:48.345568
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse('''
        from a.b import c
    ''')
    variables = {'c': 'd'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == '''
        from a.b import d
    '''



# Generated at 2022-06-12 04:36:58.071421
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: x**2).get_body() == ast.parse("""
    def _py_backwards_0(_py_backwards_1):
        return _py_backwards_1 ** 2
    """).body

    assert snippet(lambda x, y=1: x + y).get_body() == ast.parse("""
    def _py_backwards_0(_py_backwards_1, _py_backwards_2=1):
        return _py_backwards_1 + _py_backwards_2
    """).body


# Generated at 2022-06-12 04:37:06.260165
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nprint(x)')
    vars = ast.parse('x = 1\nx = 2')
    extend_tree(tree, dict(vars=vars))
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=2)), Expr(value=Call(func=Name(id=\'print\', ctx=Load()), args=[Name(id=\'x\', ctx=Load())], keywords=[]))])'

# Generated at 2022-06-12 04:37:14.371760
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse('let(x)'))) == ['x']
    assert list(find_variables(ast.parse('x = 1; let(x)'))) == ['x']
    assert list(find_variables(ast.parse('let(x); x = 1'))) == ['x']
    assert list(find_variables(ast.parse('let(x); x = 1; let(x)'))) == ['x']
    assert list(find_variables(ast.parse('let(x); x = 1; let(x); x = 2'))) == ['x']



# Generated at 2022-06-12 04:37:16.596187
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    body = fn.get_body(x=1, y=1)
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-12 04:37:23.634591
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(vars)")
    variables = {'vars': [ast.parse("x = 1"), ast.parse("x = 2")]}
    extend_tree(tree, variables)
    assert tree.body == [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                    value=ast.Num(n=1)),
                         ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                    value=ast.Num(n=2))]


# Unit test

# Generated at 2022-06-12 04:37:27.211872
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('x = 1; extend(y); z = 2')
    y = ast.parse('x = 2').body[0]
    extend_tree(tree, {'y': y})

    assert get_source(tree) == 'x = 1; x = 2; z = 2'



# Generated at 2022-06-12 04:37:31.953765
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(var)\n')
    extend_tree(tree, {'var': [ast.Assign([ast.Name(id='x', ctx=ast.Store())],
                                        ast.Constant(value=123))]})
    assert out_ast_to_code(tree) == 'x = 123\n'



# Generated at 2022-06-12 04:37:37.505021
# Unit test for function extend_tree

# Generated at 2022-06-12 04:37:48.404553
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import find

    def foo():
        extend(vars)
        let(x)
        let(y)
        x += 1
        y = 3

    vars = [
        ast.Assign(
            targets=[ast.Name(id='x')],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x')],
            value=ast.Num(n=2)
        )
    ]

    body = snippet(foo).get_body(x=ast.Name(id='x'), y=ast.Name(id='y'))

# Generated at 2022-06-12 04:37:53.166391
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(a: int, b: str) -> None:
        let(x)
        y = let(x) + let(x)
        print(len(b))
        print(a)

    tree = test.get_body(x=7)
    assert len(tree) == 3
    assert isinstance(tree[0], ast.AugAssign)
    assert isinstance(tree[1], ast.Assign)
    assert isinstance(tree[2], ast.Print)

# Generated at 2022-06-12 04:38:02.407862
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_function():
        let(a)
        let(b)
        let(c)
        let(d)

        return a + b + c + d

    body = snippet(snippet_function).get_body()
    result = ast.dump(body)
    must_be = '[Expr(value=BinOp(left=BinOp(left=BinOp(left=Name(id=_py_backwards_a_0, ctx=Load()), op=Add(), right=Name(id=_py_backwards_b_0, ctx=Load())), op=Add(), right=Name(id=_py_backwards_c_0, ctx=Load())), op=Add(), right=Name(id=_py_backwards_d_0, ctx=Load())))], []'
   

# Generated at 2022-06-12 04:38:12.540323
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # const
    var1 = 10
    var2 = 10
    assert type(let(var1)) == snippet
    assert type(let(var2)) == snippet
    assert type(extend(var1)) == snippet
    assert type(extend(var2)) == snippet
    # function
    def var3(): pass
    def var4(): pass
    assert type(let(var3)) == snippet
    assert type(let(var4)) == snippet
    assert type(extend(var3)) == snippet
    assert type(extend(var4)) == snippet
    # class
    class var5: pass
    class var6: pass
    assert type(let(var5)) == snippet
    assert type(let(var6)) == snippet
    assert type(extend(var5)) == snippet
    assert type(extend(var6))

# Generated at 2022-06-12 04:38:14.536432
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        x += 1
        y = 2
        def func():
            pass
        class Class:
            pass
    """)
    _, names = zip(*find_variables(tree).items())
    assert sorted(names) == ['x', 'y', 'z']



# Generated at 2022-06-12 04:38:17.471075
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet1():
        let(x)
        x += 1
        y = 1

    assert snippet(snippet1).get_body() == \
        ast.parse('''
            _py_backwards_x_0 += 1
            y = 1
        ''').body



# Generated at 2022-06-12 04:38:25.894019
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import pytest

    @snippet
    def snippet_1(a):
        let(x)
        x += 1
        y = 1

    body = snippet_1.get_body(a='hello_world', x=3)
    assert len(body) == 2

    x, y = body
    assert isinstance(x, ast.AugAssign)
    assert isinstance(x.target, ast.Name)
    assert x.target.id == '_py_backwards_x_0'

    assert isinstance(y, ast.Assign)
    assert isinstance(y.value, ast.Num)
    assert y.value.n == 1

    @snippet
    def snippet_2():
        extend(vars)
        print(x, y)


# Generated at 2022-06-12 04:38:34.013251
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = None   # type: Any
    y = None   # type: Any
    z = None   # type: Any

    @snippet
    def fn(a: int, b: int, e: int) -> None:
        let(x)
        x += 1
        y = 1
        let(z)
        z += e
        y = b

    import sys

# Generated at 2022-06-12 04:38:41.127457
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test with no variables
    def code_no_vars():
        print(123)

    snippet_no_vars = snippet(code_no_vars)
    code_no_vars = snippet_no_vars.get_body()
    assert code_no_vars == [ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                                                   args=[ast.Num(n=123)], keywords=[]))]

    # Test with variables
    def code_with_vars(x: int, y: int):
        let(x)
        let(y)
        x += 1
        y *= 2
        print(x, y)

    snippet_with_vars = snippet(code_with_vars)
    code_with_

# Generated at 2022-06-12 04:38:47.888174
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo(x: int) -> int:
        let(y)
        y = x + 1
        return y

    s = snippet(foo)
    body = s.get_body(x=1)
    assert len(body) == 2, body
    assert body[0].value.op == '+', body



# Generated at 2022-06-12 04:38:49.890818
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(x)\nreturn x")
    assert list(find_variables(tree)) == ['x']



# Generated at 2022-06-12 04:38:59.217074
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x_var = ast.Name('x', ast.Load())
    @snippet
    def test(x_var):
        let(x_var)
        x_var += 1
        y_var = 3 # ast.Name('y_var',ast.Load())
        return y_var
    assert test.get_body() == [
                                 ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())], x_var),
                                 ast.AugAssign(ast.Name('_py_backwards_x_0', ast.Load()), 
                                              ast.Add(), ast.Num(1)),
                                 ast.Assign([ast.Name('y_var', ast.Store())], ast.Num(3))
                               ]

# Generated at 2022-06-12 04:39:06.018172
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = let(1)
    y = let(2)
    extend(x)
    print(x, y)

    s = snippet(test_snippet_get_body)
    body = s.get_body()
    assert body[0].targets[0].id == '_py_backwards_x_0'
    assert body[1].value.args[0].s == "'_py_backwards_x_0'"
    assert body[2].targets[0].id == '_py_backwards_y_1'
    assert body[3].value.args[0].s == "'_py_backwards_y_1'"



# Generated at 2022-06-12 04:39:14.076034
# Unit test for function extend_tree
def test_extend_tree():
    # Type check should be ok
    def foo():
        extend(vars)
        print(x, y)
        x = 1
        x = 2

    tree = ast.parse(get_source(foo))
    extend_tree(tree, {'vars': [
        ast.Expr(ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                            value=ast.Num(n=1))),
        ast.Expr(ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                            value=ast.Num(n=2))),
    ]})
    assert get_source(tree) == 'x = 1\nx = 2\nprint(x, y)\n'



# Generated at 2022-06-12 04:39:22.656899
# Unit test for function find_variables
def test_find_variables():
    from astunparse import unparse

    @snippet
    def test_snippet(a):
        let(a)
        print(a)

    tree = ast.parse(unparse(test_snippet.get_body(a=ast.Name(id='haha'))))
    assert find_variables(tree) == {'a'}

    @snippet
    def snippet_nested(a):
        let(b)
        print(a)

        def inner_func(a):
            let(c)
            print(b)
            print(a)
            print(c)

        print(b)
        print(a)

    tree = ast.parse(unparse(snippet_nested.get_body(a=ast.Name(id='haha'))))
    assert find_vari

# Generated at 2022-06-12 04:39:26.148511
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f(x: int) -> int:
        let(y)
        y += x
        return y

    tree = ast.parse('y = 1\ny += 2\nprint(y)')

    assert f.get_body(y=tree.body) == tree.body

# Generated at 2022-06-12 04:39:34.894372
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def x_y():
        let(x)
        let(y)
        z = x + y

    def z():
        let(z)
        w = z * 2

    def z_for_snippet():
        let(z)
        for i in range(10):
            print(z)
    
    # Unit test for variables merging
    source = snippet(x_y).get_body()
    assert source == snippet(z).get_body()

    # Unit test for variables generation
    assert snippet(x_y).get_body(x=0.5, y=10) == snippet(z).get_body(z=5)

    # Unit test for control statements

# Generated at 2022-06-12 04:39:43.176631
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet():
        let(x)
        x += 1
        y = 1
    
    snippet_obj = snippet(snippet)
    source = get_source(snippet)
    assert snippet_obj.get_body() == ast.parse(source).body[0].body
    assert snippet_obj.get_body(x=42) == ast.parse(source).body[0].body
    source_with_var = source[:source.find('let(x)')] + 'x = 42' + source[source.find('let(x)'):]
    assert snippet_obj.get_body(x=ast.parse(source_with_var).body[0].body[0])[0].value.n == 42

# Generated at 2022-06-12 04:39:51.846815
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 7
    extended = False
    if extended:
        x = 1
        y = 2
        b = 3
        c = 4
    else:
        x = 5

    @snippet
    def fn():
        let(x)
        let(y)
        let(z)
        extend(scope)
        z = x + y
        z -= b + c

    # Tests
    variables = {'x': 1, 'y': 2, 'z': VariablesGenerator.generate('z'), 'b': 3,
                 'c': 4, 'scope': True}
    body = fn.get_body(**variables)
    assert len(body) == 2
    assert body[0].value.right.left.left.id == '_py_backwards_x_0'

# Generated at 2022-06-12 04:40:03.258672
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import get_source, get_compiled_code, eval_code_in_env
    x = 1
    y = 2
    z = 3
    code = '''
    def snippet():
        let(x)
        let(y)
        x = 1
        y = 2
        z = 3
        let(a)
        a = x + y + z
        
    '''
    res_code = '''
        _py_backwards_x_0 = 1 
        _py_backwards_y_0 = 2 
        z = 3 
        _py_backwards_a_0 = _py_backwards_x_0 + _py_backwards_y_0 + z 
        
    '''

    snippet_fn = ast.parse(code).body[0]
    snippet

# Generated at 2022-06-12 04:40:11.012475
# Unit test for function find_variables
def test_find_variables():
    # single call
    source = """
    let(x)
    print(x)
    """
    assert {'x'} == set(find_variables(ast.parse(source)))

    # multiple calls
    source = """
    let(x)
    let(y)
    print(x, y)
    """
    assert {'x', 'y'} == set(find_variables(ast.parse(source)))

    # call inside call
    source = """
    let(x)
    if let(y):
        print(x, y)
    """
    assert {'x', 'y'} == set(find_variables(ast.parse(source)))



# Generated at 2022-06-12 04:40:17.790218
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_ = snippet(lambda x, y: x + y)
    assert snippet_.get_body() == [
        ast.Expr(ast.BinOp(
            ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
            ast.Add(),
            ast.Name(id='_py_backwards_y_0', ctx=ast.Load())
        ))
    ]



# Generated at 2022-06-12 04:40:21.108812
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test() -> ast.AST:
        class TestClass:
            def __init__(self):
                let(a)
                self.a = a
        return TestClass()

    tree = snippet(test).get_body()
    assert isinstance(tree[0], ast.ClassDef)

# Generated at 2022-06-12 04:40:24.530282
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .backwards import backwards

    @snippet
    def test():
        let(x)
        x += 1
        y = 1

    backwards.test_get_body = test.get_body  # type: ignore


# Generated at 2022-06-12 04:40:31.605966
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(foo)
    assert snippet_obj.get_body(x=42) == [
        ast.AugAssign(
            op=ast.Add(),
            target=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()),
            value=ast.Num(n=1),
        ),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())], value=ast.Num(n=1))
    ]



# Generated at 2022-06-12 04:40:40.335992
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 10

    @snippet
    def test():
        let(x)
        x += 1
        y = 1

    body = test.get_body(x=x)
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert body[0].target.id == '_py_backwards_x_0'
    assert body[0].op.__class__ == ast.Add
    assert isinstance(body[1], ast.Assign)
    assert body[1].targets[0].id == 'y'
    assert isinstance(body[1].value, ast.Num)

# Generated at 2022-06-12 04:40:45.986304
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(a)
        let(c)
        x = a * c
        a += 1
        y = c


# Generated at 2022-06-12 04:40:54.170528
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_fn(x: int, y: int, z: int):
        let(x)
        let(y)
        extend(z)
        let(x)  
        x += 1

    x = ast.Name('x')
    y = ast.Name('y')
    z = [ast.Assign(targets=[ast.Name('a')], value=ast.Num(42))]

    body = test_fn.get_body(x=x, y=y, z=z)
    assert isinstance(body, list)
    assert len(body) == 1
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[0].targets[0], ast.Name)

# Generated at 2022-06-12 04:41:02.413015
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f():
        let(x)
        x += 1
        return x

    @snippet
    def g():
        let(y)
        y += 1
        y.attr = 1
        return y

    @snippet
    def h():
        let(y)
        y += 1
        y.attr = 1
        return y.attr

    @snippet
    def i():
        let(y)
        y += 1
        y.attr = 1
        return y.attr.attr

    @snippet
    def j():
        let(y)
        y += 1
        y.attr = 1
        let(z)
        z += 1
        z = 1
        return z

    @snippet
    def k():
        let(z)
        y

# Generated at 2022-06-12 04:41:08.511858
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .snippets import snippet_get_body
    from .helpers import get_source

    body = snippet_get_body.get_body(a=1, b=2)
    assert get_source(body, skip_prefixes=['py_backwards']) == 'a + b'

# Generated at 2022-06-12 04:41:13.157688
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(i: int) -> int:
        let(i)
        return i

    tree = ast.parse(get_source(fn))
    snippet_kwargs = {'i': 5}
    variables = snippet(fn)._get_variables(tree, snippet_kwargs)
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].body[0].value.value == 5



# Generated at 2022-06-12 04:41:16.959234
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class A(snippet):
        def __init__(self, a, b):
            super().__init__(a)
            self.b = b

    def method(a, b):
        let(x)
        x += 1
        y = 1

    a = A(method, 2)
    print(ast.dump(a.get_body()))

# Generated at 2022-06-12 04:41:19.699335
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(10)
        x = let(y)
        if x:
            x += 2
            y += x
        extend(a=x)
        return y
    return snippet(fn).get_body()


# Generated at 2022-06-12 04:41:23.881712
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    y = let(z)
    z = let(x)
    '''
    tree = ast.parse(source)

    names = list(find_variables(tree))
    sorted_names = sorted(names)
    assert sorted_names == ['x', 'x', 'z', 'z']  # type: ignore

# Generated at 2022-06-12 04:41:30.463634
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)')
    variables = {
        'vars': [
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(n=1)
            ),
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(n=2)
            )
        ]
    }
    extend_tree(tree, variables)
    assert tree.body[0].body == variables['vars']

# Generated at 2022-06-12 04:41:39.168300
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = Variable('x', 100)
    y = Variable('y', 5)
    z = Variable('z', 0)

    def ff1():
        let(x)
        x += 1
        y = 1

    snip1 = snippet(ff1)
    assert length(snip1.get_body(y=y)) == 2
    assert length(snip1.get_body(x=x)) == 2
    assert length(snip1.get_body(x=x, y=y)) == 2
    assert length(snip1.get_body(x=x, y=y, z=z)) == 3

    def ff2():
        extend(x)
        print(x, y)

    snip2 = snippet(ff2)

# Generated at 2022-06-12 04:41:47.456112
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def code():
        x = 5
        let(x)
        x += 1
        y = 1
        return x, y

    tree = ast.parse(get_source(code))
    variables = find_variables(tree)
    assert variables == {'x'}

    replaced_variables = VariablesReplacer.replace(tree, {'x': 'new_x'})
    assert replaced_variables.body[0].body[1].targets[0].id == 'new_x'
    assert replaced_variables.body[0].body[3].value.args[0].id == 'new_x'

    snippet_ = snippet(code)
    body = snippet_.get_body()
    assert len(body) == 4


# Generated at 2022-06-12 04:41:54.616693
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Test snippet get_body function for expected behaviour."""
    assert snippet(lambda x, y, z: None).get_body(x=1, y=1, z=1) == [
        ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name('_py_backwards_y_1', ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name('_py_backwards_z_2', ast.Store())], ast.Num(1))
    ]

# Generated at 2022-06-12 04:41:58.891369
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x):
        let(y_0)
        z = x + y_0
        return z

    body = snippet(test_fn).get_body(y_0=0)
    assert len(body) == 1

    body = snippet(test_fn).get_body(y_0=1)
    assert len(body) == 1



# Generated at 2022-06-12 04:42:12.010384
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
from py_backwards.tree import extend_tree, extend
from typed_ast import ast3

vars = {'a': ast3.Name(id='a', ctx=ast3.Store()), 'b': ast3.Name(id='b', ctx=ast3.Store())}

tree = ast3.parse('''
let(a)
let(b)
extend(vars)

# Generated at 2022-06-12 04:42:19.946772
# Unit test for function extend_tree
def test_extend_tree():
    import unittest
    import script
    import astor
    from .mocks import run

    class TestExtendTree(unittest.TestCase):

        def test_extend(self):
            @run
            def test():
                extend({
                    'x': 1,
                    'y': 2
                })
                print(x)
                print(y)

            tree = ast.parse(get_source(test)).body[0].body
            variables = {v: VariablesGenerator.generate(v) for v in ['x', 'y']}
            extend_tree(tree, variables)
            res = astor.to_source(tree)

# Generated at 2022-06-12 04:42:24.797776
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .data import ASSIGN_VARS, EXPR_X, EXPR_Y, EXPR_Z, ASSIGN_X, ASSIGN_Z,\
        ASSIGN_A
    assert snippet(lambda x, y: x + y).get_body(  # type: ignore
        x=EXPR_X, y=EXPR_Y) == [ASSIGN_VARS, ASSIGN_X, ASSIGN_Z, EXPR_Z]



# Generated at 2022-06-12 04:42:30.936213
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x, z):
        let(y)
        print(x * y * z)
    snippet_body = test.get_body(x=1, z=1)

# Generated at 2022-06-12 04:42:32.090645
# Unit test for function extend_tree

# Generated at 2022-06-12 04:42:39.978214
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_with_vars() -> None:
        let(x)
        let(y)
        x += 1
        y = 1

    res = snippet(snippet_with_vars).get_body()

    assert len(res) == 2

# Generated at 2022-06-12 04:42:48.050607
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    assert test.get_body(x=1, y=2) == [
        ast.Assign(
            [ast.Name('_py_backwards_x_0', ast.Store())],
            ast.BinOp(
                ast.Name('_py_backwards_x_0', ast.Load()),
                ast.Add(),
                ast.Num(1)
            )
        ),
        ast.Assign(
            [ast.Name('y', ast.Store())],
            ast.Num(1)
        )
    ]


# Generated at 2022-06-12 04:42:56.251960
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    tree = ast.parse("x = 2\ny = 2")
    variables = {
        None: VariablesGenerator.generate(None),
        'x': VariablesGenerator.generate('x')
    }

    expected_tree = ast.parse(
        "x_0 = 2\ny = 2"
    )

    extended_tree = ast.parse(
        "x = 2\nx_1 = 2\ny = 2"
    )

    expected_extended_tree = ast.parse(
        "x_0 = 2\nx_1 = 2\ny = 2"
    )

    extensions = {
        'vars': tree,
        'extensions': extended_tree
    }

    @snippet
    def test_fn():
        let(x)  # mypy: ignore

# Generated at 2022-06-12 04:43:00.306972
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_test() -> None:
        let(x)
        let(y)
        let(z)
        print(x)  # type: ignore
        print(y)
        print(z)

    s = snippet(snippet_test)
    print(ast.dump(ast.Module(body=s.get_body(x=3, y=4, z=5))))

# Generated at 2022-06-12 04:43:09.401278
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = ast.Name(id='x', ctx=ast.Load())
    y = ast.Name(id='y', ctx=ast.Load())
    i = ast.Name(id='i', ctx=ast.Load())
    let(x)
    let(y)
    def fn():
        let(i)
        x = let(x)
        y += 1
        y += i
        print(x, y)
    snippet_fn = snippet(fn)
    snippet_body = snippet_fn.get_body(y=y)
    assert str(ast.dump(snippet_body[0])) == "Assign(targets=[Name(_py_backwards_x_0, Load())], " \
                                            "value=Name(_py_backwards_x_0, Load()))"


# Generated at 2022-06-12 04:43:27.922317
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import find, find_all

    def test():
        let(x)
        y = x
        x = 1
        return x

    assert find(snippet(test).get_body(), ast.Assign, lambda node: node.lineno == 4).value.n == 1

    def test():
        let(x)
        let(y)
        y = x
        x = 1
        return x

    assert find(snippet(test).get_body(), ast.Assign, lambda node: node.lineno == 5).value.n == 1

    def test():
        let(x)
        y = x
        x = 1
        return x

    x = ast.Name(id=VariablesGenerator.generate('x'), ctx=ast.Store())


# Generated at 2022-06-12 04:43:35.244294
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .types import Function

    @snippet
    def foo(x, y):
        let(x)
        x += 1
        y = 1

    assert foo.get_body() == ast.parse("""
    x += 1
    y = 1
    """).body

    @snippet
    def foo(x, y):
        let(x)
        let(y)
        x = 1
        y = 2

    assert foo.get_body() == ast.parse("""
    x = 1
    y = 2
    """).body

    @snippet
    def foo(x, y):
        let(x)
        let(y)
        x = 1
        y = 2
        z = 3


# Generated at 2022-06-12 04:43:41.218680
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def sum(x: int, y: int, z: int) -> int:
        let(res)
        res = x + y + z
        return res

    def test(tree: ast.AST) -> None:
        assert ast.dump(tree) == \
            "Assign(targets=[Name(id='_py_backwards_res_0', ctx=Store())], value=BinOp(left=BinOp(left=Name(id='x', ctx=Load()), op=Add(), right=Name(id='y', ctx=Load())), op=Add(), right=Name(id='z', ctx=Load())))"

    test(sum.get_body(res=ast.Name(id='my_res', ctx=ast.Store())))



# Generated at 2022-06-12 04:43:50.143492
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_function(a: int, b: int) -> None:
        let(c)
        let(b)
        print(a, b)
        extend(f"{a}")


# Generated at 2022-06-12 04:43:51.907800
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x); let(y); x + y')
    assert list(find_variables(tree)) == ['x', 'y']

# Generated at 2022-06-12 04:43:55.032768
# Unit test for function find_variables
def test_find_variables():
    source = """
        def foo():
            let(x)
            let(y)
            x += 1
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-12 04:44:01.329511
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int, z: int) -> None:
        let(x)
        x -= 1
        y += 2
        z += 3

    body = snippet(test_snippet).get_body(x=1, y=2, z=3)
    code = ast.Module(body=[ast.Expr(value=ast.Sub(left=ast.Name('_py_backwards_x_0', ast.Load()), right=ast.Num(1)))], type_ignores=[])
    assert code == ast.Module(body=body)

# Generated at 2022-06-12 04:44:09.758036
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x: int, y: int) -> None:
        let(z)
        z += 1
        y += x
        print(z)

    snippet_ins = snippet(fn)
    body = snippet_ins.get_body(x=10)

# Generated at 2022-06-12 04:44:16.638757
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """This function checks if get_body returns the same result as code in snippet."""

    @snippet
    def snippet_test():
        let(x)
        let(y)
        let(z)

        extend(vars)

        a = x + z
        b = y + z
        c = a * b

    snippet_test_code = snippet_test.get_body(x=1, y=2, z=3, vars=[ast.Assign()])

    assert snippet_test_code == ast.parse("""
    a = 1 + 3
    b = 2 + 3
    c = a * b
    """).body



# Generated at 2022-06-12 04:44:18.490560
# Unit test for function extend_tree
def test_extend_tree():
    x = 1
    y = 2
    z = 3

# Generated at 2022-06-12 04:44:37.316998
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        import foo, bar
        let(y)
        from foo import x
        extend(vars)
        print(x, y)

    snippet_instance = snippet(test_fn)

# Generated at 2022-06-12 04:44:45.699066
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_source = """
        def _py_backwards_snippet_0() -> None:
            let(x)
            let(y)
            a = x + y
    """
    expected_source = """
            a = _py_backwards_x_0 + _py_backwards_y_0
    """
    tree = ast.parse(snippet_source)
    variables = {'x': VariablesGenerator.generate('x'),
                 'y': VariablesGenerator.generate('y')}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    expected_ast = ast.parse(expected_source)
    assert tree.body[0].body == expected_ast.body


# Generated at 2022-06-12 04:44:48.341699
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(get_body_example).get_body(x=2) == ast.parse(
        """x = 2
_py_backwards_y_0 += 1""").body



# Generated at 2022-06-12 04:44:55.478781
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_code_with_let():
        let(a)
        a += 1
        b = 1
        return a, b

    test_snippet = snippet(test_code_with_let)
    snippet_body = test_snippet.get_body()
    assert snippet_body == [ast.Assign([ast.Name('_py_backwards_a_0', ast.Store())],
                                       ast.BinOp(ast.Name('_py_backwards_a_0', ast.Load()),
                                                 ast.Add(),
                                                 ast.Constant(1))),
                            ast.Assign([ast.Name('b', ast.Store())],
                                       ast.Constant(1))]

# Generated at 2022-06-12 04:45:03.614469
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: int):
        let(y)
        extend(z)
        return x + y + z  # type: ignore


# Generated at 2022-06-12 04:45:13.814496
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(a, b):
        let(c)
        # let(d)
        return a + b + c

    snippet_instance = snippet(fn)
    ast_body = snippet_instance.get_body(c=2)

    assert ast_body == ast.Module(
        body=[
            ast.Return(
                value=ast.BinOp(
                    left=ast.BinOp(
                        left=ast.Name(id='a', ctx=ast.Load()),
                        op=ast.Add(),
                        right=ast.Name(id='b', ctx=ast.Load())
                    ),
                    op=ast.Add(),
                    right=ast.Name(id='_py_backwards_c_0', ctx=ast.Load())
                )
            )
        ]
    ).body


#

# Generated at 2022-06-12 04:45:22.126475
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    y = 1
    """)
    xs = [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=n))
          for n in [1, 2]]
    extend_tree(tree, {'vars': xs})
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2)), Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=1))])"

# Generated at 2022-06-12 04:45:30.333152
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def __py_backwards_test():
        let(x)
        x += 1
        y = 1
        extend(__py_backwards_y)
        print(x, y)

    snippet_obj = snippet(__py_backwards_test)

# Generated at 2022-06-12 04:45:39.422189
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    ast_tree = snippet(test_snippet_get_body).get_body()
    assert isinstance(ast_tree[0], ast.Assign)
    assert isinstance(ast_tree[1], ast.Assign)
    assert isinstance(ast_tree[0].value, ast.Name)
    assert isinstance(ast_tree[0].targets[0], ast.Name)
    assert isinstance(ast_tree[1].value, ast.Num)
    assert isinstance(ast_tree[1].targets[0], ast.Name)
    assert ast_tree[0].value.id == "z"
    assert ast_tree[0].targets[0].id == "y"
    assert ast_tree[1].value.n == 2

# Generated at 2022-06-12 04:45:46.311964
# Unit test for function extend_tree
def test_extend_tree():
    assert extend_tree(ast.parse('extend(vars); x = 1'), {
        'vars': [
            ast.parse('x = 1'),
            ast.parse('x = 2')
        ]
    }) == None
    assert extend_tree(ast.parse('extend(vars); x = 1'), {
        'vars': [
            ast.parse('x = 1')
        ]
    }) == None



# Generated at 2022-06-12 04:46:17.679841
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def foo(x: int, y: int) -> int:
        let(z)
        return x + y + z

    body = foo.get_body(x=1, y=2)
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[0].value, ast.Num)
    assert body[0].value.n == 3  # type: ignore

    body = foo.get_body(x=1, y=2)
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[0].value, ast.Num)
    assert body[0].value.n == 3  # type: ignore

    body = foo.get_body(x=ast.Name(id='a', ctx=ast.Load()), y=2)

# Generated at 2022-06-12 04:46:27.153430
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        extend(vars)
        let(x)
        x += 1
        print(x)
    source = get_source(test_snippet)
    tree = ast.parse(source)
    snippet_kwargs = {'vars': [ast.Assign(
        [ast.Name('x')], ast.Num(1))], 'x': ast.Name('y')}
    variables = snippet(test_snippet)._get_variables(tree, snippet_kwargs)
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree.body[0].body) == 'x = 1\nx += 1\nprint(x)'

# Generated at 2022-06-12 04:46:29.425524
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''
        let(x)
        x = 1
        let(y)
        y = 2
    ''')
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-12 04:46:29.919923
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:46:39.461184
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo():
        let(x)
        x += 1
        y = 1

    snippet_foo = snippet(foo)
    assert snippet_foo.get_body(x=10) == [
        ast.Assign(targets=[ast.Name(id="_py_backwards_x_0", ctx=ast.Store())],
                   value=ast.BinOp(left=ast.Name(id="_py_backwards_x_0", ctx=ast.Load()),
                                   op=ast.Add(),
                                   right=ast.Num(n=1))),
        ast.Assign(targets=[ast.Name(id="y", ctx=ast.Store())],
                   value=ast.Num(n=1))]

    def bar():
        let(x)
        let(y)
