

# Generated at 2022-06-12 04:36:26.906569
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    tree = ast.parse('x = 1')
    variables = {'x': VariablesGenerator.generate('x')}
    extend_tree(tree, variables)
    result = VariablesReplacer.replace(tree, variables)
    fn = snippet(lambda: None)
    assert fn.get_body(x=1) == result.body

# Generated at 2022-06-12 04:36:29.236321
# Unit test for function find_variables
def test_find_variables():
    t: ast.AST = ast.parse("let(x)\n"
                           "x += 1\n"
                           "y = 1\n")
    expected_vars = ['x']
    assert find_variables(t) == expected_vars

# Generated at 2022-06-12 04:36:34.394735
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    """)
    vars_tree = ast.parse("""
    a = 1
    b = 2
    """)
    extend_tree(tree, {'vars': vars_tree.body})
    assert list(find(tree, ast.Assign)) == [vars_tree.body[0], vars_tree.body[1]]

# Generated at 2022-06-12 04:36:41.983509
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    code = '''\
        @snippet
        def sum(a, b):
            let(c)
            c = a + b
            return c
    '''
    tree = ast.parse(code)
    snippet_fn = tree.body[0]  # type: ignore
    snippet_instance = snippet_fn.body[0].value

    body = snippet_instance.get_body(a=1, b=2)


# Generated at 2022-06-12 04:36:44.606004
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(x)
y = x + 1
let(y)

"""
    )
    assert list(find_variables(tree)) == ["x", "y"]



# Generated at 2022-06-12 04:36:52.326177
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
    x = 0
    extend(vars)
    x += 1
    print(x)
    '''
    assign1 = ast.parse('x = 1').body[0]
    assign2 = ast.parse('x = 2').body[0]
    tree = ast.parse(source)
    extend_tree(tree, {'vars': [assign1, assign2]})
    assert [get_source(node) for node in tree.body] == [
        'x = 0',
        'x = 1',
        'x = 2',
        'x += 1',
        'print(x)'
    ]

# Generated at 2022-06-12 04:37:01.791867
# Unit test for function find_variables
def test_find_variables():
    if find_variables(ast.parse("let(x)")):
        assert False, 'should not find variable'

    if find_variables(ast.parse("let('x')")):
        assert False, 'should not find variable'

    for name in find_variables(ast.parse("let(x)\nx = 1")):
        assert name == 'x'

    for name in find_variables(ast.parse("let(x)\nlet(y)\nx = 1")):
        assert name in ['x', 'y']

    for name in find_variables(ast.parse("let(x)\nlet(y)\nx = 1\ny = [1, 2]")):
        assert name in ['x', 'y']


# Generated at 2022-06-12 04:37:11.978482
# Unit test for function find_variables
def test_find_variables():
    from .tree import find_index, equal

    tree = ast.parse("let(x); let(y); x=1; y=2")

    variables = find_variables(tree)
    assert list(variables) == ['x', 'y']

    variables = find_variables(tree)
    assert list(variables) == []

    tree = ast.parse("x=1; let(x); x+1")
    variables = find_variables(tree)
    assert list(variables) == ['x']

    tree = ast.parse("x=1; let(x); let(y); x+1; y+1")
    variables = find_variables(tree)
    assert list(variables) == ['x', 'y']


# Generated at 2022-06-12 04:37:15.397910
# Unit test for function extend_tree
def test_extend_tree():
    assert ast.parse('x = 1\ny = 2\nprint(x, y)\n') == extend_tree(ast.parse('extend(vars)\nprint(x, y)\n'), {'vars': [ast.parse('x = 1\ny = 2\n')]})

# Generated at 2022-06-12 04:37:22.083178
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(node)")
    vars = {'node': ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                               value=ast.Name(id='y', ctx=ast.Load()))}
    extend_tree(tree, vars)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Name(id='y', ctx=Load()))])"



# Generated at 2022-06-12 04:37:30.677525
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    vars = {'foo': ast.Name(id='bar', ctx=ast.Load()),
            'bar': ast.Name(id='baz', ctx=ast.Load())}
    tree = ast.parse('''
from .foo import bar as baz
''')
    tree = VariablesReplacer.replace(tree, vars)
    assert get_source(tree) == '''
from .baz import baz as baz
'''

# Generated at 2022-06-12 04:37:38.451904
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(x: int, y: int, z: List[int]) -> None:
        let(x)
        let(y)
        extend(z)

    z = ast.parse('x = 1\nx = 2').body
    body = fn.get_body(x=ast.Name('a'), y='b', z=z)
    print(ast.dump(body[0]))
    print(ast.dump(body[1]))
    print(ast.dump(body[2]))
    print(ast.dump(body[3]))
    assert ast.dump(body[0]) == "Assign(targets=[Name(id='a', ctx=Store())], value=Name(id='a', ctx=Load()))"
    assert ast.dump(body[1])

# Generated at 2022-06-12 04:37:49.393394
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def my_snippet(x, y):
        let(a)
        let(b)
        assert a == x
        assert b == a + y  # noqa


# Generated at 2022-06-12 04:37:57.597790
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def greeting(name, age):
        let(name)
        let(age)
        return 'Hello, {name} ({age})'.format(**vars())


# Generated at 2022-06-12 04:37:59.333477
# Unit test for function find_variables
def test_find_variables():
    find_variables(ast.parse('let(x)\nx + 2')) == ['x']

# Generated at 2022-06-12 04:38:08.716781
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 10
    y = 10

    @snippet
    def f(a: int, b: int) -> None:
        let(x)
        let(y)
        x += 1
        y += 1

        extend(vars)
        vars = [
            ast.parse("x = 1").body[0],
            ast.parse("x = 2").body[0]
        ]
        print(x, y)

    tree = f.get_body(vars=vars)
    assert len(tree) == 4
    assert tree[0].left.id == '_py_backwards_x_0'
    assert tree[1].left.id == '_py_backwards_y_0'
    assert tree[2].value.id == '_py_backwards_print_0'

# Generated at 2022-06-12 04:38:13.373557
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse('import a as b')
    variables = {'b': 'abc'}
    VariablesReplacer.replace(tree, variables)

    assert ast.dump(tree) == 'ImportFrom(module="a", names=[alias(name="abc", asname=None)], level=0)'

# Generated at 2022-06-12 04:38:18.791311
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_func():
        let(x)
        x += 1
        y = 1
    
    test_func_snippet = snippet(test_func)
    assert test_func_snippet.get_body() == [
        ast.AugAssign(
            target=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
            op=ast.Add(),
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
    ]

# Generated at 2022-06-12 04:38:26.440405
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    variables = {'vars': [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                   value=ast.Num(n=2)),
    ]}
    extend_tree(tree, variables)

    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        y = 2
        print(x, y)
    """))

# Generated at 2022-06-12 04:38:29.756212
# Unit test for function find_variables
def test_find_variables():
    source = """\
        def foo():
            let(x)
            let(y)
    """
    tree = ast.parse(source)
    names = find_variables(tree)
    assert set(names) == set('xy')



# Generated at 2022-06-12 04:38:42.041523
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet():
        let(x)
        let(y)
        return y+2
    
    assert str(ast.dump(snippet.get_body(), annotate_fields=False)) == \
            'Expr(value=BinOp(left=Name(id="py_backwards_y_0", ctx=Load()),' + \
            ' op=Add(), right=Constant(value=2, kind=None)))'

# Generated at 2022-06-12 04:38:46.441551
# Unit test for function find_variables
def test_find_variables():
    import pytest

    @snippet
    def fn():
        let(x)
        let(y)
        return 1

    tree = ast.parse('let(x)\nlet(y)')
    variables = list(find_variables(tree))
    assert variables == ['x', 'y']
    assert type(variables) == list



# Generated at 2022-06-12 04:38:53.281595
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """
    Creates a snippet to mutate an array by shifting the values down in the array
    Given an array, will mutate the array so that the values are shifted down
    :return: returns an updated array
    """

# Generated at 2022-06-12 04:38:55.396879
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse('let(x)\nlet(y)'))) == ['x', 'y']



# Generated at 2022-06-12 04:39:01.841950
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    let(x)
    y = 2
    def func(x: int, y: int) -> int:
        return x + y
    snippet_ = snippet(func)
    assert snippet_.get_body(x=x, y=y) == [ast.Assign(
        targets=[ast.Name(id="x", ctx=ast.Store())],
        value=ast.Num(n=1)), ast.Assign(
        targets=[ast.Name(id="y", ctx=ast.Store())],
        value=ast.Num(n=2))]

test_snippet_get_body()


# Generated at 2022-06-12 04:39:05.905578
# Unit test for function find_variables
def test_find_variables():
    def fn1():
        let(x)
        let(y)

    def fn2():
        let(x)

    assert find_variables(ast.parse(get_source(fn1))) == ['x', 'y']
    assert find_variables(ast.parse(get_source(fn2))) == ['x']



# Generated at 2022-06-12 04:39:08.226418
# Unit test for function find_variables
def test_find_variables():
    source = """
let(x)
let(y)
y = x = 1
"""
    tree = ast.parse(source)
    assert sorted(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-12 04:39:17.122056
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""\
let(a)
let(b)
let(c)
extend(d)
extend(a)
let(d)""")


# Generated at 2022-06-12 04:39:24.019583
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _assert(expected: ast.AST, actual: ast.AST) -> None:
        assert ast.dump(expected) == ast.dump(actual)

    def test_snippet_get_body():
        x = ast.Name(id='name')
        y = ast.Name(id='name_1')

# Generated at 2022-06-12 04:39:33.100490
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import replace_ids
    from .patch_typed_ast import patch_typed_ast

    with patch_typed_ast():
        @snippet
        def fn():
            let(x)
            x += 1
            y = 1
            extend(vars)
            
            print(x, y)
            
        body = fn.get_body(x='_py_backwards_x_0', vars=[ast.Assign(targets=[ast.Name(id='x')],
                                                                  value=ast.Num(1)),
                                                         ast.Assign(targets=[ast.Name(id='x')],
                                                                  value=ast.Num(2))])

# Generated at 2022-06-12 04:39:47.016668
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Given
    source = '''
        @snippet
        def test_snippet_get_body(x, y):
            let(a)
            let(b)
            let(c)
            let(d)
            a = x
            b = y
            c = a + 1
            d = x + y
            return a, b, c, d
    '''

    # When
    tree = ast.parse(source)
    extend_tree(tree, {'x': ast.parse("x = 1").body[0]})
    extend_tree(tree, {'y': ast.parse("y = 2").body[0]})

# Generated at 2022-06-12 04:39:56.325455
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test with empty snippet
    @snippet
    def empty_snippet():
        pass

    assert empty_snippet.get_body() == []

    # Test with one variable in snippet
    @snippet
    def snippet_with_one_var():
        let(x)
        print(x)
    
    assert snippet_with_one_var.get_body() == [
        ast.Print(
            values=[ast.Name(id='_py_backwards_x_0', ctx=ast.Load())],
            dest=None,
            nl=True)
    ]
    
    # Test with few variables in snippet
    @snippet
    def snippet_with_few_vars():
        let(x)
        let(y)
        print(x, y)
    
   

# Generated at 2022-06-12 04:40:03.497944
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    _snippet = snippet(lambda x: 1)

    def _check(x, y, z):
        x += y
        z += x

    def _test_snippet_get_body() -> None:
        """Test snippet.get_body for all methods"""
        x, y, z = _snippet.get_body(x=_check(x, y, z), y=_check(x, y, z), z=_check(x, y, z))
        _snippet.get_body(x=x, y=y, z=z)

    _test_snippet_get_body()

# Generated at 2022-06-12 04:40:12.471536
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Test method snippet.get_body."""
    @snippet
    def snippet_func(x: int, y: int):
        """Docstring of snippet func."""
        let(x)
        x += 1
        y += 2

    assert snippet_func.get_body() == snippet_func.get_body(x=1, y=2)
    assert snippet_func.get_body() == snippet_func.get_body(x=1, y=None)
    assert snippet_func.get_body() == snippet_func.get_body(x=None, y=2)
    assert snippet_func.get_body(x=1, y=2) == snippet_func.get_body(x=1, y=None)
    assert snippet_func.get_body(x=1, y=2) == snippet

# Generated at 2022-06-12 04:40:14.536192
# Unit test for function extend_tree
def test_extend_tree():
    import inspect
    import astor
    from .tree import find
    from .helpers import get_source
    

# Generated at 2022-06-12 04:40:21.022909
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet():
        x = True
        let(x)

    def snippet_kwargs():
        return {}

    tree = snippet.get_body(**snippet_kwargs())

    assert_equal(ast.dump(tree), '[Assign(targets=[Name(id=\'_py_backwards_x_0\', ctx=Store())], value=NameConstant(value=True))]')



# Generated at 2022-06-12 04:40:27.204859
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = ast.Name(id='a', ctx=ast.Load())
    extend_expected = ast.Assign(targets=[ast.Name(id='y', ctx=ast.Load())],
                                 value=ast.Num(n=1))
    let_expected0 = ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                                            args=[ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                                  ast.Name(id='y', ctx=ast.Load())],
                                            keywords=[]))

# Generated at 2022-06-12 04:40:37.485205
# Unit test for function extend_tree
def test_extend_tree():
    def fn1(x):
        return 1


    def fn2(x):
        return x * 2


    def main(a, b):
        f = fn1
        extend(f)
        f = fn2
        return f(a)


    snippet = snippet(main)
    tree = snippet.get_body(f=main.__code__.co_consts[0])


# Generated at 2022-06-12 04:40:44.954966
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 2
        y = 1 + y
        if x > 5:
            print(y)

    snippet_instance = snippet(fn)
    result = snippet_instance.get_body(x=2)

    assert len(result) == 4
    assert isinstance(result[0], ast.Assign)
    assert isinstance(result[0].targets[0], ast.Name)
    assert isinstance(result[0].value, ast.BinOp)
    assert isinstance(result[0].value.left, ast.Name)
    assert result[0].value.left.id.startswith('_py_backwards_x')
    assert isinstance(result[0].value.op, ast.Add)

# Generated at 2022-06-12 04:40:48.786039
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    s = snippet(lambda x: let(x) + x + 1)
    code = s.get_body(x=3)
    assert code[0].value.left.id == '_py_backwards_x_0'
    assert code[0].value.right.n == 4
    assert code[1].value.n == 1



# Generated at 2022-06-12 04:41:03.900394
# Unit test for function find_variables
def test_find_variables():
    source = """let(x)
x += 1
y = 1
        """
    tree = ast.parse(source)
    assert find_variables(tree) == ['x']



# Generated at 2022-06-12 04:41:12.099081
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def sample_fn():
        x = 1
        y = 2
        z = 3
        let(x)
        let(y)
        extend(z)

    body = sample_fn.get_body(z=[ast.Assign(targets=[ast.Name(id='y')], value=ast.Num(n=2)), ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=3))])

    print(body)

# Generated at 2022-06-12 04:41:17.074020
# Unit test for method get_body of class snippet
def test_snippet_get_body():  # type: ignore
    def snippet_func():  # type: ignore
        let(x)
        x += 1
        y = 1
        return x, y

    snippet_result = snippet(snippet_func).get_body()
    assert len(snippet_result) == 3
    assert isinstance(snippet_result[0], ast.AugAssign)
    assert isinstance(snippet_result[1], ast.Assign)
    assert isinstance(snippet_result[2], ast.Return)

    snippet_func = snippet_func
    snippet_result = snippet(snippet_func).get_body()
    assert isinstance(snippet_result[0], ast.AugAssign)
    assert isinstance(snippet_result[1], ast.Assign)

# Generated at 2022-06-12 04:41:25.461985
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x, y):
        let(x)
        x += 1
        let(y)
        y += 1
        return x + y

    snippet_fn = snippet(snippet_fn)

    snippets = [
        snippet_fn.get_body(),
        snippet_fn.get_body(x=1),
        snippet_fn.get_body(y=1),
        snippet_fn.get_body(x=1, y=1)
    ]

    # assert len(snippets) == 4
    # assert snippets[0] == [
    #     ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
    #                value=ast.BinOp(left=ast.Name(id='_py_back

# Generated at 2022-06-12 04:41:31.012843
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo():
        let(x)
        y = x
        return y

    _snippet = snippet(foo)
    assert _snippet.get_body() == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())], ast.Name('x', ast.Load())),
             ast.Assign([ast.Name('y', ast.Store())], ast.Name('_py_backwards_x_0', ast.Load()))]

# Generated at 2022-06-12 04:41:39.707213
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    f = '''def main():
        let(x)
        x += 1
        y = 1
    '''
    expected = '''x += 1
    y = 1'''

    source = get_source(f)
    tree = ast.parse(source)
    variables = find_variables(tree)
    new_variables = {name: VariablesGenerator.generate(name) for name in variables}
    VariablesReplacer.replace(tree, new_variables)

    def main():
        pass

    snippet_instance = snippet(main)
    body = snippet_instance.get_body()
    assert ast.dump(body) == ast.dump(tree.body[0].body)

    new_tree = ast.parse(f)
    extend_tree(new_tree, new_variables)

# Generated at 2022-06-12 04:41:47.795342
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_source = '''
    @py_backwards.snippet
    def new_snippet(x):
        a = let(x)
        b = let([a, x])
        c = extend(x)
        let(b)
    '''
    tree = ast.parse(snippet_source)
    snippet_ast_node = tree.body[0].body[0]
    assert snippet_ast_node.name == 'new_snippet'

    snippet_tree = snippet(None).get_body()
    extract_variables = {
        variable.targets[0].id: variable.value
        for variable in snippet_tree if isinstance(variable, ast.Assign)
    }

# Generated at 2022-06-12 04:41:50.026942
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    fn = snippet(lambda: x)
    assert fn.get_body()[0].value.id == '_py_backwards_x_0'   # type: ignore


# Generated at 2022-06-12 04:41:59.268729
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x: ast.AST):
        let(x)
        x += 1
        y = 1

    code_gen = snippet(f)
    tree = code_gen.get_body(x=ast.Name(id="y", ctx=ast.Load()))
    assert str(tree) == "[Assign([Name(id='_py_backwards_x_0', ctx=Store(), annotation=None)], Name(id='y', ctx=Load(), annotation=None)), Assign([AugAssign(Name(id='_py_backwards_x_0', ctx=Store(), annotation=None), Add(), Num(n=1))], Name(id='y', ctx=Load(), annotation=None)), Assign([Name(id='y', ctx=Store(), annotation=None)], Num(n=1))]"



# Generated at 2022-06-12 04:42:05.673633
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class A:
        pass

    x = A()
    y = A()

    @snippet
    def a():
        let(x)
        x.value = 1
        extend(y)

    assert isinstance(a.get_body(x=x, y=[ast.Assign(targets=[ast.Name(id=x.value, ctx=ast.Store())],
                                                   value=ast.Num(n=0)),
                                            ast.Assign(targets=[ast.Name(id=x.value, ctx=ast.Store())],
                                                       value=ast.Num(n=1))]
                                 ),
                      list)

# Generated at 2022-06-12 04:42:23.210334
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: int) -> None:
        x += 1
        y = let(x)
        z = let(y)
        z += 1


# Generated at 2022-06-12 04:42:30.180347
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    let_ = ast.parse("""
let(x)
x += 1
y = 1
""").body[0]
    extend_ = ast.parse("""
extend(vars)
print(x, y)
""").body[0]
    extend_vars = {
        "vars": ast.Module(
            body=[ast.Assign(targets=[ast.Name(id="x", ctx=ast.Store())],
                             value=ast.Num(n=1)),
                  ast.Assign(targets=[ast.Name(id="x", ctx=ast.Store())],
                             value=ast.Num(n=2))]
        )
    }
    print(snippet(lambda x, y: x).get_body())

# Generated at 2022-06-12 04:42:38.611614
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    _y = 2

    @snippet
    def fn():
        let(x)
        x += 1

        let(y)
        y = 3

        extend(vars)
        return x, y

    # result = (x + 1, y)
    # _y = 3
    variables = {'x': x, 'vars': [ast.Assign(targets=[ast.Name(_y, ast.Store())], value=ast.Num(3))]}
    result = fn.get_body(**variables)
    assert len(result) == 2
    assert result[0] == ast.Assign(targets=[ast.Name(_y, ast.Store())], value=ast.Num(3))

# Generated at 2022-06-12 04:42:47.587405
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # This is the code of snippets
    def fn1():
        x = 5
        let(x)

    def fn2(x):
        let(x)
        x += 1

    def fn3(x):
        let(x)
        y = 1

    # This is the result of tree of snippets
    def fn1_result():
        __py_backwards_x_0 = 5

    def fn2_result(x):
        __py_backwards_x_0 = x
        __py_backwards_x_0 += 1

    def fn3_result(x):
        __py_backwards_x_0 = x
        y = 1

    # Right here is the unit test
    assert snippet(fn1).get_body() == snippet(fn1_result).get_body()

# Generated at 2022-06-12 04:42:53.744294
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import io
    import sys

    class TestSnippet(snippet):
        def __init__(self, value: str) -> None:
            self._value = value

        def _snippet(self) -> None:
            let(x)
            print(x)  # type: ignore

    old_stdout = sys.stdout
    captured_output = io.StringIO()
    sys.stdout = captured_output
    TestSnippet('test').get_body(x=10)
    sys.stdout = old_stdout

    assert captured_output.getvalue() == '10\n'

# Generated at 2022-06-12 04:43:02.756026
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_code():
        x = let(1)

    source_code = get_source(snippet_code)
    tree = ast.parse(source_code)
    for node in find(tree, ast.Call):
        if isinstance(node.func, ast.Name) and node.func.id == 'let':
            parent, index = get_non_exp_parent_and_index(tree, node)
            parent.body.pop(index)
            y = node.args[0].id
            parent.body.insert(0, ast.Assign(targets=[ast.Name(id=y, ctx=ast.Store())], value=y))
            break

    print(tree)

# Generated at 2022-06-12 04:43:09.028698
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def code():
        let(x)
        let(y)
        x += 1
        y = 1
    snippet = snippet(code)
    body = snippet.get_body(x=1, y=2)
    assert ast.dump(body) == '[Assign(targets=[Name(id=_py_backwards_x_0, ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=_py_backwards_y_0, ctx=Store())], value=Num(n=2))]'



# Generated at 2022-06-12 04:43:15.555539
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x, y = 1, 2
    
    @snippet
    def snippet():
        let(x)
        x += 1
        y = 1
    
    assert snippet.get_body() == ast.parse("_py_backwards_x_0 += 1; y = 1").body
    assert snippet.get_body(y=5) == ast.parse("_py_backwards_x_0 += 1; y = 5").body
    assert snippet.get_body(_x=0) == ast.parse("_x += 1; y = 1").body



# Generated at 2022-06-12 04:43:23.665263
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_function(x: int) -> int:
        let(a)
        y = a
        return y + x

    snippet_instance = snippet(test_function)
    body = snippet_instance.get_body()
    expected = [ast.Assign(
        targets=[ast.Name(id="_py_backwards_a_0", ctx=ast.Store())],
        value=ast.Name(id="_py_backwards_a_0", ctx=ast.Load())
    ), ast.Return(value=ast.BinOp(
        left=ast.Name(id="_py_backwards_a_0", ctx=ast.Load()),
        op=ast.Add(),
        right=ast.Name(id="x", ctx=ast.Load())
    ))
    ]
    assert body

# Generated at 2022-06-12 04:43:28.451363
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)')
    tree.body[0].args[0].value = 'vars'

    x1 = ast.parse('x = 1').body[0]
    x2 = ast.parse('x = 2').body[0]
    extend_tree(tree, {'vars': [x1, x2]})
    assert get_source(tree.body[0]) == 'x = 1\nx = 2'

# Generated at 2022-06-12 04:43:58.005316
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 10

    @snippet
    def snippet():
        let(x)
        x += 1

    tree = snippet.get_body()
    assert get_source(tree).strip() == 'x += 1'

    @snippet
    def snippet():
        let(x)
        x += 1
        y = 1

    tree = snippet.get_body()
    assert get_source(tree).strip() == 'x += 1\ny = 1'

    @snippet
    def snippet():
        let(x)
        x += 1
        y = 1

    tree = snippet.get_body(x=ast.Name(id='_x', ctx=ast.Load()), y='2')
    assert get_source(tree).strip() == '_x += 1\ny = 2'


# Generated at 2022-06-12 04:44:04.080450
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    let = snippet.get_body
    assert let(x=1, y=2) == [ast.Assign(where=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()), value=ast.Num(n=1)),
                             ast.Assign(where=ast.Name(id='_py_backwards_y_0', ctx=ast.Store()),
                                        value=ast.Num(n=2)),
                             ast.Expr(ast.Name(id='_py_backwards_let_0', ctx=ast.Load()))]

# Generated at 2022-06-12 04:44:11.284990
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_code = """
    def foo():
        let(a)
        let(b)
        extend(c)
        let(d)
        let(e)
        extend(f)
        return a+b+d+e
    """
    code_ast = ast.parse(snippet_code)

    func_body = code_ast.body[0].body
    func = snippet(lambda: None)
    func_b = func.get_body(a=1, b=2, c=func_body, d=3, e=4, f=func_body)
    assert func_b == [ast.parse('return 1+2+3+4').body[0]]

# Generated at 2022-06-12 04:44:18.976070
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def body():
        let(x)
        x += 1
        if True:
            let(y)
            y += 2

    snippet = snippet(body).get_body()
    assert len(snippet) == 2
    assert isinstance(snippet[0], ast.If)
    assert isinstance(snippet[1], ast.Expr)
    assert isinstance(snippet[1].value, ast.BinOp)
    assert isinstance(snippet[1].value.left, ast.Name)
    assert isinstance(snippet[1].value.op, ast.Add)
    assert isinstance(snippet[1].value.right, ast.Num)


# Generated at 2022-06-12 04:44:24.509722
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_obj = snippet(lambda x, y: x + y)
    result = snippet_obj.get_body(x=1, y=2)
    assert len(result) == 1
    assert isinstance(result[0], ast.Expr)
    assert isinstance(result[0].value, ast.BinOp)
    assert isinstance(result[0].value.op, ast.Add)

# Generated at 2022-06-12 04:44:26.534386
# Unit test for function extend_tree
def test_extend_tree():

    assert eval(
        ast3.dump(
            ast3.parse(
                "extend(vars)")
        )
    ) == extend

# Generated at 2022-06-12 04:44:29.542702
# Unit test for function extend_tree
def test_extend_tree():
    source = dedent("""
    extend(y)
    x = 1
    """)
    y = ast.parse("y = 1")
    tree = ast.parse(source)
    extend_tree(tree, {"y": y})
    code = compile(tree, '<test>', 'exec')
    exec(code)
    assert x == 1
    assert y == 1

# Generated at 2022-06-12 04:44:32.472837
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_kwargs = {'x': 'test'}
    s = snippet(lambda x: x)
    tree = s.get_body(**snippet_kwargs)
    assert tree[0].value.id == snippet_kwargs['x']

# Generated at 2022-06-12 04:44:38.928201
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse(""))) == []
    src = "let(x)\nx += 1\ny = 1"
    assert list(find_variables(ast.parse(src))) == ["x"]
    src = "let(x)\nlet(y) * y * x"
    assert set(find_variables(ast.parse(src))) == set(["x", "y"])
    src = "let(x)\nx += 1\nextend(vars)\nn = 1"
    assert set(find_variables(ast.parse(src))) == set(["x", "vars"])



# Generated at 2022-06-12 04:44:47.757642
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class example:
        context = {'x': 1}

        def run(self):
            def snippet(x: int, y: int) -> int:
                let(z)
                x = 1
                y = x + 5
                return x, y, z + y

            x = let(y)
            z = extend(vars)

            extend(context)
            x += 1
            z = snippet(x, y)

            return x


# Generated at 2022-06-12 04:45:30.556393
# Unit test for function find_variables

# Generated at 2022-06-12 04:45:37.307800
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_function():
        let(1)
        extend(2)

    s = snippet(test_function)

    assert s.get_body() == [
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_1', ctx=ast.Store())],
                   value=ast.Num(n=2))] \
        # type: ignore

# Generated at 2022-06-12 04:45:42.223697
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x = 1
    let(y)
    y = 2
    """

    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-12 04:45:47.874370
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(a: int) -> None:
        let(b)
        let(c)
        b = a + 1
        print(b)
        c = a - 1
        print(c)

    assert test.get_body(a=5, b=6, c=7) == ast.parse('''
    _py_backwards_b_0 = a + 1
    print(_py_backwards_b_0)
    _py_backwards_c_0 = a - 1
    print(_py_backwards_c_0)
    ''').body



# Generated at 2022-06-12 04:45:55.868226
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn_test(x: float, y: float, z: float) -> None:
        x = y = z = 0.
        let(x)
        let(y)
        let(z)
        x += 1
        y += 2
        z += 3
        extend([x, y, z])
        x = 1
        y = 2
        z = 3
        extend([x + 1, y + 2, z + 3])
        print(x, y, z)

    method_body = fn_test.get_body(x=12, y=13, z=14)

# Generated at 2022-06-12 04:46:00.929790
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("x = 1\ny = 2")
    extend_tree(tree, {'vars': vars})
    assert str(tree) == "x = 1\ny = 2\nprint(x, y)"



# Generated at 2022-06-12 04:46:02.871438
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x: int) -> int:
        let(y)
        return x + y

    snippet(f).get_body(x=1)

# Generated at 2022-06-12 04:46:07.165653
# Unit test for function find_variables
def test_find_variables():
    source = """
from _py_backwards import let
let(x)
let(y)
x += 1
y += 1
let(z)
z += 1
"""
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']


# Generated at 2022-06-12 04:46:12.628792
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test(fn, wanted):
        got = snippet(fn).get_body()
        assert tuple(map(type, got)) == tuple(map(type, wanted)), \
            'got {}, wanted {}'.format(got, wanted)

    def f(arg=0):
        let(x)
        let(y)
        z = x + y


# Generated at 2022-06-12 04:46:21.189243
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(a)\nlet(b)\na = 1\nlet(c)')
    assert tuple(find_variables(tree)) == ('a', 'b', 'c')

    tree = ast.parse('let(a)\nlet(b)\na = 1')
    assert tuple(find_variables(tree)) == ('a', 'b')

    tree = ast.parse('let(a)\nc = 1\na = 1')
    assert tuple(find_variables(tree)) == ('a',)

    tree = ast.parse('let(a)\na = 1\na = 2\nlet(b)\nlet(c)')
    assert tuple(find_variables(tree)) == ('a', 'b', 'c')

