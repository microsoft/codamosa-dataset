

# Generated at 2022-06-12 04:36:20.519375
# Unit test for function extend_tree
def test_extend_tree():
    fn = snippet(lambda: extend(vars))

# Generated at 2022-06-12 04:36:27.691672
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""extend(x)
            """)
    variables = {'x': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                  value=ast.Num(n=1)),
                       ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                  value=ast.Num(n=2))
                       ]}
    extend_tree(tree, variables)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=2))])'

# Generated at 2022-06-12 04:36:34.395163
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(
        ast.parse('let(x)'))) == ['x']
    assert list(find_variables(
        ast.parse('let(x) + let(y)'))) == ['x', 'y']
    assert list(find_variables(
        ast.parse('let(x) + let(y)'),
        ast.parse('let(z)'))) == ['x', 'y', 'z']
    assert list(find_variables(
        ast.parse('let(y) + let(z)'),
        ast.parse('let(z)'))) == ['y', 'z']

# Generated at 2022-06-12 04:36:41.984233
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_function(x: float, y: float) -> float:
        """Returns sum of x and y."""
        let(x)
        x += y
        extend(y)

        return x

    snippet_kwargs = {
        'x': ast.Name('_py_backwards_x_0', ast.Load()),
        'y': [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1)),
              ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(2))]
    }


# Generated at 2022-06-12 04:36:51.191761
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert ast.dump(snippet(lambda: let(x)).get_body()) == ast.dump([
        ast.Assign(
            targets=[
                ast.Name(id='_py_backwards_x_0', ctx=ast.Store())
            ],
            value=ast.Num(n=1)
        )
    ])

    assert ast.dump(snippet(lambda: let(x)).get_body(x=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()))) == ast.dump([
        ast.Assign(
            targets=[
                ast.Name(id='_py_backwards_x_0', ctx=ast.Store())
            ],
            value=ast.Num(n=1)
        )
    ])


# Generated at 2022-06-12 04:37:00.774294
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse(
        'a = 1\nb = 2\n'
        'extend(other)\nprint(a, b)'  # type: ignore
    )
    variables = {
        'other': [
            ast.parse('x = 1\ny = 2').body[0],
        ],
    }
    extend_tree(tree, variables)

# Generated at 2022-06-12 04:37:05.476832
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = """
from a import x, y
from b.c import g
"""
    tree = ast.parse(source)
    variables = snippet(lambda: let(x=3))._get_variables(tree, {})
    tree = VariablesReplacer.replace(tree, variables)
    assert get_source(tree.body[0]) == """from ... import x, y"""

# Generated at 2022-06-12 04:37:11.938711
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # tree: import a.b
    tree = ast.ImportFrom(module='a.b', names=[], level=0)

    # variables: {'a.b': 'c.d'}
    variables = {'a.b': 'c.d'}

    # replace
    VariablesReplacer.replace(tree, variables)

    # expect: import c.d
    assert isinstance(tree, ast.ImportFrom)
    assert tree.module == 'c.d'

# Generated at 2022-06-12 04:37:21.145025
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class Z():
        def test_snippet(self, x, y) -> None:
            let(x)
            x += 1
            y = 1
            extend(vars)
            print(x, y)

    z = Z()
    test_snippet = snippet(z.test_snippet)
    body = test_snippet.get_body(x=10,
                                 y=20,
                                 vars=[ast.Assign([ast.Name(id='x', ctx=ast.Store())],
                                                  ast.Num(n=1)),
                                       ast.Assign([ast.Name(id='x', ctx=ast.Store())],
                                                  ast.Num(n=2)),
                                       ])

# Generated at 2022-06-12 04:37:25.483459
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: x + 1).get_body() == [ast.parse('return _py_backwards_x_0 + 1').body[0]]
    assert snippet(lambda x: x + 1).get_body(x=1) == [ast.parse('return 1 + 1').body[0]]
    

# Generated at 2022-06-12 04:37:37.266548
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 1

    @snippet
    def b(x, y):
        let(y)
        return y + 1

    @snippet
    def c():
        let(x)
        x += 1
        let(y)
        print(x + y)

    @snippet
    def d():
        a = 1
        extend(a)
        print(a)

    ast_b = b.get_body(x=1, y=ast.Name(id='a', ctx=ast.Load()))

# Generated at 2022-06-12 04:37:48.183850
# Unit test for function extend_tree
def test_extend_tree():
    module = ast.parse("""
    test = 5
    extend(vars)
    let(x)
    let(y)
    let(z)
    x = 1
    z = 2
    """)
    vars = ast.parse("""
    x = 1
    y = 2
    z = 3
    """).body
    extend_tree(module, {'vars': vars})

# Generated at 2022-06-12 04:37:54.287846
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    tree = snippet(test_snippet_get_body).get_body(y=1)
    assert (
        ast.dump(tree) ==
        '[Assign(targets=[Name(id=\'_py_backwards_x_0\', ctx=Store())], value=Add(left=Name(id=\'_py_backwards_x_0\', ctx=Load()), right=Num(n=1))), Assign(targets=[Name(id=\'y\', ctx=Store())], value=Num(n=1))]')
    assert (
        get_source(tree) ==
        '_py_backwards_x_0 += 1\ny = 1')

# Generated at 2022-06-12 04:38:01.944080
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars1); extend(vars2)')
    vars1 = [ast.parse('x = 1').body[0], ast.parse('x = 2').body[0]]
    vars2 = [ast.parse('y = 1').body[0], ast.parse('y = 2').body[0]]
    vars1.extend(vars2)
    extend_tree(tree, {'vars1': vars1, 'vars2': vars2})
    assert get_source(tree) == 'x = 1\nx = 2\ny = 1\ny = 2'

# Generated at 2022-06-12 04:38:07.303758
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(x)
let(y)
z = 10
""")

    a = find_variables(tree)
    assert list(a) == ['x', 'y']

    tree = ast.parse("""
let(x)
z = 10
""")
    a = find_variables(tree)
    assert list(a) == ['x']


# Generated at 2022-06-12 04:38:12.951027
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    print("test_VariablesReplacer_visit_alias")
    node = ast.alias(name="module.submodule.other.py_backwards", asname="py_backwards")
    result = VariablesReplacer.replace(node, dict(module="module_backwards"))
    assert(result.name == "module_backwards.submodule.other.py_backwards")


# Generated at 2022-06-12 04:38:17.243887
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    """Returns alias node with having replaced variables."""

    def test():
        import sys.test.test as test
        test.foo()

    source = get_source(test)
    tree = ast.parse(source)
    variables = {'test': 'something', 'foo': 'bar'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "import sys.something.something as bar\nbar.bar()\n"

# Generated at 2022-06-12 04:38:25.574842
# Unit test for function extend_tree
def test_extend_tree():
    origin = ast.parse('''
        extend(let(a) +
               let(b) +
               let(c))
    ''', mode='exec')
    tree = origin.copy()
    variables = {'a': ast.parse('let(d) + let(e)').body[0],
                 'b': ast.parse('let(f) + let(g)').body[0],
                 'c': ast.parse('let(h) + let(i)').body[0]}
    extend_tree(tree, variables)
    assert str(origin) == 'extend(let(a)\n       let(b)\n       let(c))'
    assert str(tree) == 'let(d)\nlet(e)\nlet(f)\nlet(g)\nlet(h)\nlet(i)'

# Generated at 2022-06-12 04:38:32.443639
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""\
    extend(foo)
    extend(bar)
    x = 1
    y = 2
    z = 3""")
    extend_tree(tree, {
        'foo': [ast.Assign(targets=[ast.Name(id='x')],
                           value=ast.Num(n=1))],
        'bar': [ast.Assign(targets=[ast.Name(id='y')],
                           value=ast.Num(n=2))]})
    assert get_source(tree) == """\
    x = 1
    x = 2
    y = 2
    z = 3"""

# Generated at 2022-06-12 04:38:35.343593
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nprint(x)\n')
    fill = ast.parse('x = 1\nx = 2\n')
    extend_tree(tree, {'vars': fill.body})

    assert ast.dump(tree) == ast.dump(fill)



# Generated at 2022-06-12 04:38:44.255771
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = snippet(test_snippet_get_body)
    print(x.get_body())

test_snippet_get_body()

# Generated at 2022-06-12 04:38:52.140679
# Unit test for function extend_tree
def test_extend_tree():
    import ast_helpers

    body = ast_helpers.snippet(lambda: extend(vars))
    body = list(body)
    vars = ast_helpers.snippet(lambda x: x + 1).get_body()

    ast_helpers.extend_tree(ast.Module([ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())], value=ast.Name(id='x', ctx=ast.Load())), ast.FunctionDef(name='test', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=body, decorator_list=[], returns=None, type_comment=None)]), {'vars': vars})


# Generated at 2022-06-12 04:39:01.153880
# Unit test for function extend_tree
def test_extend_tree():
    a = ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=1)
    )
    b = ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=2)
    )

    tree = ast.parse(
        """\
extend(vars)
print(x)"""
    )

    extend_tree(tree, {'vars': [a, b]})

# Generated at 2022-06-12 04:39:09.480178
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Set up a snippet instance
    def snippet_function_1(x: int) -> int:
        extend(vars)
        let(y)
        return x + y + z

    # Test snippet with two variables
    vars = [ast.Assign(targets=[ast.Name(id='z', ctx=ast.Store())],
                      value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='z', ctx=ast.Store())],
                      value=ast.Num(n=2))]
    snip_ext_2 = snippet(snippet_function_1)
    snip_ext_2_body = snip_ext_2.get_body(vars=vars)

# Generated at 2022-06-12 04:39:12.858258
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2

    def test_snippet_function():
        let(x)
        x += 1
        print(x + y)

    body = snippet(test_snippet_function).get_body()
    assert body[0].value.right.value == 3

# Generated at 2022-06-12 04:39:18.053705
# Unit test for function find_variables
def test_find_variables():
    source = """
if (a):
    let(x)
    let(y)
    let(z)
    b = x + y
    c = a
else:
    let(z)
    d = z
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert sorted(variables) == ['x', 'y', 'z']

# Generated at 2022-06-12 04:39:22.833861
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    tree = snippet(lambda x, y: x + y).get_body(x=1, y=2)
    assert tree == [ast.Assign([ast.Name('_py_backwards_ans_', ast.Store())],
                               ast.BinOp(ast.Name('_py_backwards_x_0',
                                                  ast.Load()),
                                         ast.Add(),
                                         ast.Name('_py_backwards_y_1',
                                                  ast.Load())))]

# Generated at 2022-06-12 04:39:31.782761
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn_s():
        let(x)
        let(y)
        x += 1
        y += 2
        z = 1
        print(x, y, z)
    
    s = snippet(fn_s)
    ast_body = s.get_body(x=1)
    assert len(ast_body) == 5
    assert isinstance(ast_body[0], ast.AugAssign)
    assert isinstance(ast_body[0].value, ast.Num)
    assert ast_body[0].value.n == 1
    assert isinstance(ast_body[1], ast.AugAssign)
    assert isinstance(ast_body[2], ast.Assign)
    assert isinstance(ast_body[3], ast.Print)
    assert len(ast_body[3].values) == 3


# Generated at 2022-06-12 04:39:37.326079
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""let(vars)
extend(vars)
x = 1
y = 2
""")
    variables = {'vars': ast.parse('x = 1\ny = 2')}
    extend_tree(tree, variables)
    node = tree.body[0]
    assert node.body[0].targets[0].id == 'x' # type: ignore
    assert node.body[1].targets[0].id == 'y' # type: ignore



# Generated at 2022-06-12 04:39:46.141386
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: ast.Name, y: ast.Name, z: int, **kwargs: ast.Name) -> None:
        let(z)
        x = y
        x = 1
        y = 2
        extend(kwargs)  # type: ignore

    var_x = ast.Name(id='x', ctx=ast.Store())
    var_y = ast.Name(id='y', ctx=ast.Store())
    var_z = ast.Name(id='z', ctx=ast.Store())
    var_kwargs = ast.Name(id='kwargs', ctx=ast.Store())

# Generated at 2022-06-12 04:39:55.727026
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def t() -> None:
        let(x)
        let(y)
        print(x, y)

    snippet_ = snippet(t)
    source = get_source(t)
    variables = snippet_._get_variables(ast.parse(source), {})
    tree = ast.parse(source)
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert (source == (''.join(ast.unparse(node) for node in tree.body[0].body)))
    print(tree)

# Generated at 2022-06-12 04:39:59.066799
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        x += 1
        y = 1

    snippet = snippet(test)
    snippets = ast.Module(body=snippet.get_body(x=42))
    assert snippet.get_body() == snippets.body

# Generated at 2022-06-12 04:40:07.815616
# Unit test for function extend_tree
def test_extend_tree():
    def extend_tree_test():
        x = extend(vars)
        pass

    source = get_source(extend_tree_test)
    tree = ast.parse(source)
    vars = [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1)),
    ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(2))]
    extend_tree(tree, {'vars': vars})

    actual_source = ast.fix_missing_locations(tree).body[0].body[0].body[0].value.values[0].elts[0]
    expected_source = ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1))
   

# Generated at 2022-06-12 04:40:14.191541
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        x = 1
        let(x)
        x += 1
        y = 1
        extend(vars)

    snippet_ = snippet(test)
    ast_ = snippet_.get_body()
    assert ast_[0].targets[0].id.startswith('_py_backwards_x_')
    assert ast_[1].targets[0].id == 'y'
    assert ast_[2].targets[0].id == 'x'
    assert ast_[2].value.n == 1

# Generated at 2022-06-12 04:40:22.056960
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def sample(x: int, y: int = 1, z: int = 2) -> None:
        """
        let(y)
        print(x, y, z)
        """

    expected = ast.parse('''
        _py_backwards_y_0 = y
        print(x, _py_backwards_y_0, z)
    ''')

    res = sample.get_body(x=2)
    assert ast.dump(res, annotate_fields=False) == ast.dump(expected, annotate_fields=False)

# Generated at 2022-06-12 04:40:28.458022
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_snippet_get_body(y: int, z: int):
        let(x)
        extend(vars)
        x += y

    s = snippet(snippet_snippet_get_body)
    body = s.get_body(x=2, y=1)
    assert body == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1),
            )
        ),
    ]

# Generated at 2022-06-12 04:40:36.189081
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    s = snippet(lambda: extend(vars))

    assert s.get_body(vars=[ast.Assign(targets=[ast.Name(id='x')],
                                       value=ast.Num()),
                            ast.Assign(targets=[ast.Name(id='y')],
                                       value=ast.Num())]) == \
           [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num()),
            ast.Assign(targets=[ast.Name(id='y')], value=ast.Num())]

# Generated at 2022-06-12 04:40:38.862660
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(x); x = 1; y = 2")
    variables = find_variables(tree)
    assert variables == ['x']

# Generated at 2022-06-12 04:40:45.445074
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var1 = ast.Name(id='a')
    var2 = ast.Name(id='b')
    var3 = ast.Name(id='a')
    var4 = ast.Name(id='b')
    var5 = ast.Name(id='_py_backwards_c_0')
    var6 = ast.Name(id='_py_backwards_d_0')
    var7 = ast.Name(id='_py_backwards_e_0')
    var8 = ast.Name(id='_py_backwards_f_0')
    var9 = ast.Name(id='_py_backwards_g_0')

    @snippet
    def snippet_test_get_body():
        let(a)
        let(b)
        c = 1


# Generated at 2022-06-12 04:40:53.598176
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Test snippet get_body. It is crucial to right process, because it
    has no public API and no guarantees, that internal API won't change
    between versions."""
    from .helpers import ast_to_source
    a,b = 1,2
    @snippet
    def add_numbers():
        a = let(a)
        b = let(b)
        extend(vars)
        return a + b

    assert ast_to_source(add_numbers.get_body(a=a, b=b, vars=[ast.Assign([ast.Name('a', ast.Store())], ast.Constant('1'))])) == (
        'a = 1\n'
        'a = a\n'
        'b = 2\n'
        'return a + b'
    )

# Generated at 2022-06-12 04:41:06.052067
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f():
        let(x)
        x += 1
        y = x + 1
        extend(vars)
    

# Generated at 2022-06-12 04:41:13.567129
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var1 = ast.Name(id='var1')
    var2 = ast.Name(id='var2')

    @snippet
    def func():
        var1 = 1
        var2 = 2

    body = func.get_body()
    assert body == [ast.Assign([ast.Name(id='var1')], ast.Num(1)),
                    ast.Assign([ast.Name(id='var2')], ast.Num(2))]

    body = func.get_body(var1=var1, var2=var2)
    assert body == [ast.Assign([ast.Name(id='var1')], ast.Name(id='var1')),
                    ast.Assign([ast.Name(id='var2')], ast.Name(id='var2'))]

    body = func.get

# Generated at 2022-06-12 04:41:17.402587
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class A:
        pass

    @snippet
    def test_snippet(x: ast.Name, y: ast.Name) -> None:
        let(x)
        let(y)
        x += 1
        x += 1
        y += 1
        y += 1
        extend(A())

    assert len(test_snippet.get_body()) == 8

# Generated at 2022-06-12 04:41:22.527730
# Unit test for function extend_tree
def test_extend_tree():
    import unittest
    import astor
    vars = [
        ast.parse('x = 1').body[0],
        ast.parse('y = 1').body[0]
    ]
    orig_tree = ast.parse('print(x, y)')
    extend_tree(orig_tree, {'vars': vars})
    assert astor.to_source(orig_tree) == 'x = 1\ny = 1\nprint(x, y)'

# Generated at 2022-06-12 04:41:25.023541
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(z)
        z = x + y

    snippet(test_snippet).get_body(x=10, y=20)

# Generated at 2022-06-12 04:41:33.909690
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn() -> None:
        let(x)
        let(y)
        x += 1
        y += 2


# Generated at 2022-06-12 04:41:43.452491
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_ = snippet(lambda: [let(i) for i in [1, 2, 3]])
    body = snippet_.get_body()
    assert body == [ast.AugAssign(target=ast.Name(id='_py_backwards_i_0', ctx=ast.Store()), op=ast.Add(),
                                  value=ast.Num(n=1)),
                    ast.AugAssign(target=ast.Name(id='_py_backwards_i_1', ctx=ast.Store()), op=ast.Add(),
                                  value=ast.Num(n=1)),
                    ast.AugAssign(target=ast.Name(id='_py_backwards_i_2', ctx=ast.Store()), op=ast.Add(),
                                  value=ast.Num(n=1))]

# Generated at 2022-06-12 04:41:48.295161
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def incr(i):
        return i + 1

    def test_fn(x: int) -> int:
        let(a)
        a += 1
        return incr(x)

    assert snippet(test_fn).get_body(a=32) == [
        ast.AugAssign(ast.Name(_py_backwards_x_0, ast.Store()), ast.Add(), ast.Num(1)),
        ast.Return(ast.Call(ast.Name('incr', ast.Load()), [ast.Name('x', ast.Load())], [], None, None))
    ]

# Generated at 2022-06-12 04:41:57.737860
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(a, b):
        assert isinstance(a, ast.Name)
        assert isinstance(b, ast.Name)
        let(x)
        extend(vars)
        a += 1
        x += 1

    tree = ast.parse('x = 1\ny = 2')
    vars = list(tree.body)
    snippet = Snippet(fn)
    result = snippet.get_body(a=ast.Name(id='a', ctx=ast.Load()),
                              b=ast.Name(id='b', ctx=ast.Load()),
                              vars=vars)
    s = astor.to_source(result)
    assert s == 'a += 1\n_py_backwards_x_0 += 1'



# Generated at 2022-06-12 04:42:02.722603
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import inspect

    def snippet1(x: int, y: ast.Name) -> int:
        let(x)
        x += 1
        return x

    snippet_object = snippet(snippet1)

    ast_code = snippet_object.get_body(y=ast.Name(id='y'))
    expected_code = '''
x += 1
return x
'''
    assert ast.dump(ast_code) == ast.dump(ast.parse(inspect.cleandoc(expected_code)).body)

# Generated at 2022-06-12 04:42:07.414587
# Unit test for function extend_tree

# Generated at 2022-06-12 04:42:13.975770
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def _snippet(x: int, y: ast.Name) -> int:
        x += 1
        setattr(y, 'id', 'new_id')
        let(y)
        return x
    # Check that body have 2 statements and second statement have name 'new_id'
    body = _snippet.get_body(x=1, y=ast.Name('5', ast.Load()))
    assert len(body) == 2
    assert isinstance(body[1], ast.Assign) and isinstance(body[1].value, ast.Name) and body[1].value.id == 'new_id'

# Generated at 2022-06-12 04:42:21.735613
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x: ast.Name, y: str=None, z: ast.Num=None) -> None:
        let(x)
        x += 1  # type: ignore
        y = 1  # type: ignore
        z = 3  # type: ignore
        let(y)
        let(z)

    snippet_func = snippet(fn)

# Generated at 2022-06-12 04:42:29.326037
# Unit test for function extend_tree
def test_extend_tree():
    import pytest
    code = """
    f()
    extend(vars)
    g()
    """
    tree = ast.parse(code)
    vars = [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1)),
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(2))]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-12 04:42:37.739549
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    "test get_body method of snippet"
    def _add(x, y):
        let(x)
        x += y

    def _sub(a, b):
        let(b)
        b -= a

    add_snippet = snippet(_add)
    sub_snippet = snippet(_sub)

    add_body = add_snippet.get_body(x=1, y=2)
    sub_body = sub_snippet.get_body(a=1, b=2)

    assert [ast.parse(s).body[0] for s in [
        "_py_backwards_x_0 += 2",
    ]] == add_body


# Generated at 2022-06-12 04:42:40.394557
# Unit test for function find_variables
def test_find_variables():
    def function():
        let(x)
        x += 1

    tree = ast.parse(get_source(function)).body[0]

    variables = set(find_variables(tree))

    assert 'x' in variables



# Generated at 2022-06-12 04:42:49.320165
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def add_one():
        let(a)
        a += 1
        return a

    @snippet
    def add_two():
        let(b)
        b += 2
        return b

    @snippet
    def add_four():
        let(c)
        c += 4
        return c

    @snippet
    def add_one_and_two():
        a = add_one()
        b = add_two()
        return a + b

    @snippet
    def add_one_and_four():
        a = add_one()
        c = add_four()
        return a + c

    tree_a = add_one.get_body()

# Generated at 2022-06-12 04:42:57.740616
# Unit test for function extend_tree
def test_extend_tree():
    func = snippet(lambda a: ...)
    names = find_variables(ast.parse(get_source(func._get_variables)))
    variables = {name: VariablesGenerator.generate(name)
                 for name in names}
    tree = ast.parse(
        """y = 1
extend(x)
print(y)""")
    extend_tree(tree, variables)

# Generated at 2022-06-12 04:43:04.331417
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        let(vars)
        extend(vars)
        return x

    snippet_obj = snippet(test_fn)
    test_var = ast.Name(id='x', ctx=ast.Load())
    assert(snippet_obj.get_body(x=test_var) == [ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())], value=test_var)])
    print('get_body method test for snippet object passed!')

# Generated at 2022-06-12 04:43:09.761828
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    code = ("let(a)\n"
            "\na += 1\n"
            "\nprint(a)\n")
    tree = ast.parse(code)
    variables = {"a": VariablesGenerator.generate('a')}
    extend_tree(tree, variables)
    new_tree = VariablesReplacer.replace(tree, variables)
    assert get_source(new_tree) == "_py_backwards_a_0 += 1\nprint(_py_backwards_a_0)\n"

# Generated at 2022-06-12 04:43:25.123405
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from operator import add, mul
    from py_backwards.core.helpers import generate_call

    variables = {
        'x': 1,
        'y': 2,
        'f': add,
        'g': mul,
        'body': [
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=3)),
            ast.AugAssign(target=ast.Name(id='y', ctx=ast.Store()),
                          op=ast.Add(), value=ast.Num(n=5))
        ]
    }
    snippet_body = snippet(lambda x, y, f, g: let(g(let(f(let(body), x)), y))).get_body(**variables)

# Generated at 2022-06-12 04:43:32.602756
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x):
        assert x == 1
        let(y)
        y = y + 1
        assert y == 2


# Generated at 2022-06-12 04:43:39.674769
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn() -> None:
        let(x)
        x += 1
        y = 1

    sn = snippet(fn)

    assert sn.get_body() == [
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],  # type: ignore
                   value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),  # type: ignore
                                   op=ast.Add(),
                                   right=ast.Num(n=1))),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],  # type: ignore
                   value=ast.Num(n=1)),
    ]



# Generated at 2022-06-12 04:43:42.120685
# Unit test for function extend_tree

# Generated at 2022-06-12 04:43:49.300845
# Unit test for function extend_tree
def test_extend_tree():
    source = """
extend(vars)
print(a)
"""
    tree = ast.parse(source)
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
        value=ast.Num(n=(1)))]})
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1)), Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Name(id='a', ctx=Load())], keywords=[]))])"


# Generated at 2022-06-12 04:43:56.312880
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''def extend_tree():
        if True:
            y = 1
            x = 2
            print(x, y)
        ''')

    variables = ast.parse('''
    x = 1
    x = 2
    ''').body

    extend_tree(tree, {"vars": variables})
    result = ast.parse('''def extend_tree():
        if True:
            y = 1
            x = 1
            x = 2
            print(x, y)
        ''')
    assert result.body[0] == tree.body[0]
    assert result.body[0].body == tree.body[0].body

# Generated at 2022-06-12 04:44:04.546539
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def function(x: int, y: str = 'foo'):
        let(z)
        let(s)
        print(x, y, z, s)

    body = function.get_body(x=1, y='bar', z=2, s='b')
    assert len(body) == 3

    assert isinstance(body[0], ast.Assign)
    assert len(body[0].targets) == 1
    assert body[0].targets[0].id == '_py_backwards_z_0'
    assert isinstance(body[0].value, ast.Num)
    assert body[0].value.n == 2

    assert isinstance(body[1], ast.Assign)
    assert len(body[1].targets) == 1
    assert body

# Generated at 2022-06-12 04:44:12.786423
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import numpy as np
    @snippet
    def fn(x: int, y: int) -> List[ast.AST]:
        let(z)
        z += x
        z += x + y
        if z > 2:
            z += 5
        return z, z

    body = fn.get_body(x=1, y=2)

# Generated at 2022-06-12 04:44:22.451947
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """
    Test snippet.get_body() method.
    """
    @snippet
    def f(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2)),
    ]
    body = f.get_body(x=1, y=1, vars=vars)

# Generated at 2022-06-12 04:44:29.021344
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    t = snippet(test_snippet)
    assert t.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                    value=ast.Num(n=1))
    ]



# Generated at 2022-06-12 04:44:49.336753
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: x + 1).get_body() == [
        ast.Assign(
            targets=[
                ast.Name(
                    id='_py_backwards_x_0',
                    ctx=ast.Store()
                )
            ],
            value=ast.BinOp(
                left=ast.Name(
                    id='_py_backwards_x_0',
                    ctx=ast.Load()
                ),
                op=ast.Add(),
                right=ast.Num(
                    n=1
                )
            )
        )
    ]



# Generated at 2022-06-12 04:44:51.190914
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Test get_body method of snippet class."""
    var = VariablesGenerator.generate('x')

# Generated at 2022-06-12 04:44:59.032230
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(a: int, b: int):
        let(c)
        let(d)
        return a + b + c + d

    snippet_instance = snippet(test_fn)
    snippets_body = snippet_instance.get_body(c=1, d=2)

# Generated at 2022-06-12 04:45:07.629695
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = let(1)
    a = snippet(
        extend(x + 1)
    ).get_body()
    assert isinstance(a, list)
    assert len(a) == 1
    assert isinstance(a[0], ast.Expr)
    assert isinstance(a[0].value, ast.BinOp)
    assert isinstance(a[0].value.left, ast.Name)
    assert a[0].value.left.id == 'x'
    assert isinstance(a[0].value.op, ast.Add)
    assert isinstance(a[0].value.right, ast.Num)
    assert a[0].value.right.n == 1


# Generated at 2022-06-12 04:45:18.094612
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = (
        'def f(z):\n'
        '    let(x)\n'
        '    x += 1\n'
        '    let(y)\n'
        '    y = 1\n'
    )
    tree = ast.parse(source)
    variables = get_variables(tree)
    extend_tree(tree, variables)
    variables_replacer.replace(tree, variables)

# Generated at 2022-06-12 04:45:25.302800
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x)
    """)
    
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                          value=ast.Num(n=1)),
                                ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                           value=ast.Num(n=2))]})
    
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x)
    """))



# Generated at 2022-06-12 04:45:33.969626
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import AstExamples

    snippet_content = """
    def test():
        let(x)
        x += 1
        y = 1
    """

    snippet_content = """
    def test():
        let(x)
        x += 1
        y = 1
    """

    variables = {'x': '_py_backwards_x_0'}
    tree = ast.parse(snippet_content)
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert_equal(AstExamples.func_body, tree.body[0].body)
    # TODO: Currently implemented algorithm is not perfect.
    # For example `x += 1` will be `_py_backwards_x_0 += 1`.
    # It's not the best choice for example when we

# Generated at 2022-06-12 04:45:39.455703
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def foo(x: int, y: int) -> int:
        return f(x + y)

    def f(n: int) -> int:
        return n + 1

    import sys
    import astor
    src = astor.to_source(foo.get_body(x=1, y=2))
    print(src)
    sys.stdout.flush()
    return

test_snippet_get_body()

# Generated at 2022-06-12 04:45:48.468652
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import sys
    import os
    import astor
    from .process import process
    from .rewrite import rewrite
    from .process import post_process
    from .meet_type import meet_type, meet_types

    def foo(x: int, y: int) -> int:
        # with snippet(foo_inner) as body:
        #     body[0].args.append(ast.Num(n=5))
        body = snippet(foo_inner).get_body()
        body[0].args.append(ast.Num(n=5))
        return process(foo_inner, body)

    def foo_inner():
        let(x)
        let(y)
        return x * y + 5

    def foo2(x: int, y: int) -> int:
        body = snippet(foo2_inner).get

# Generated at 2022-06-12 04:45:57.002940
# Unit test for function find_variables
def test_find_variables():
    from .test import test
    tree = ast.parse('let(x)')
    expected = ['x']
    actual = find_variables(tree)
    test.assert_equal(expected, actual)

    tree = ast.parse('let(y)\nx = 1')
    expected = ['y']
    actual = find_variables(tree)
    test.assert_equal(expected, actual)

    tree = ast.parse('let(y)\nx = 1\nlet(z)')
    expected = ['y', 'z']
    actual = find_variables(tree)
    test.assert_equal(expected, actual)

    tree = ast.parse('let(y)\nx = 1\nlet(z)\nclass Hello: pass')
    expected = ['y', 'z']