

# Generated at 2022-06-12 04:36:34.537723
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(var);')
    extend_tree(tree, {'var': ast.parse('x=1;')})
    assert get_source(tree) == 'x=1'

# Generated at 2022-06-12 04:36:42.458544
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('1\n'
                     'a = 1\n'
                     'b = 2\n'
                     'extend(vars)\n'
                     'print(c)')
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='c', ctx=ast.Store())],
                                           value=ast.Num(n=3))]})


# Generated at 2022-06-12 04:36:45.919115
# Unit test for function find_variables
def test_find_variables():
    import astor
    input_code = """
    let(a)
    a = 0
    """
    tree = ast.parse(input_code)
    assert list(find_variables(tree)) == ['a']
    assert astor.to_source(tree) == """
    a = 0
    """



# Generated at 2022-06-12 04:36:54.155363
# Unit test for function extend_tree
def test_extend_tree():
    code = """
    extend(vars)
    """
    tree = ast.parse(code)
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                        value=ast.Num(n=1)),
                                ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                        value=ast.Num(n=2))]})
    code2 = """
    x = 1
    x = 2
    """
    tree2 = ast.parse(code2)
    assert tree.body == tree2.body


# Generated at 2022-06-12 04:36:57.086058
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
    """)
    assert sorted(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-12 04:37:07.226054
# Unit test for function find_variables
def test_find_variables():
    def f():
        let(x = 2)
        let(y = 3)
        print(x * y)

    tree = ast.parse(get_source(f))
    variables = list(find_variables(tree))
    assert variables == ['x', 'y']

# Generated at 2022-06-12 04:37:14.371605
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(foo)")
    extend_tree(tree, {"foo": [ast.parse("x = 1").body[0], 
                               ast.parse("y = 2").body[0]]})
    assert(ast.dump(tree) == "[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=2))]")



# Generated at 2022-06-12 04:37:15.806041
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse('let(a)\nlet(b)'))) == ['a', 'b']

# Generated at 2022-06-12 04:37:18.689167
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''
let(a)
let(b)
let(c)
''')
    assert eager(find_variables(tree)) == ['a', 'b', 'c']

# Generated at 2022-06-12 04:37:24.576845
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1
        print(x, y)

    body = snippet(snippet_fn).get_body(x=2, y=3)
    assert ast.unparse(body).strip() == '_py_backwards_x_0 += 1\ny = 1\nprint(_py_backwards_x_0, y)'



# Generated at 2022-06-12 04:37:35.976603
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x: int, y: int) -> None:
        let(z)
        x, y, z = x * 2, y * 2, z * 2


# Generated at 2022-06-12 04:37:42.824711
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x, y):
        let(x)
        x += 1
        y = 1
        print(x, y)

    from .tree import build

    ast_body = test.get_body(y=1)
    assert build(ast_body) == '_py_backwards_x_0 += 1\ny = 1\nprint(_py_backwards_x_0, y)'

    ast_body = test.get_body(x=1)
    assert build(ast_body) == 'x += 1\nprint(x, _py_backwards_y_1)'



# Generated at 2022-06-12 04:37:51.578055
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def a(x: int, y: int) -> int:
        let(z)
        return x + y + z

    code = a.get_body(x=1, y=2)
    assert code == [ast.Assign([ast.Name('z', ast.Store())],
                               ast.BinOp(ast.Num(1), ast.Add(), ast.Num(2)),
                               type_comment=None),
                    ast.Return(ast.BinOp(ast.Name('z', ast.Load()), ast.Add(), ast.Num(2)))]

# Generated at 2022-06-12 04:37:56.844388
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("y = 3")
    variables = {'vars': ast.parse("x = 1").body}
    extend_tree(tree, variables)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=3))])"

# Generated at 2022-06-12 04:38:03.380807
# Unit test for function extend_tree
def test_extend_tree():
    code = f"""
extend(vars)
print(x, y)
    """
    vars = [
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(2)),
    ]
    tree = ast.parse(code)
    extend_tree(tree, {'vars': vars})
    assert tree.body[2].body[0].value.elts[0].n == 2

# Generated at 2022-06-12 04:38:08.989489
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse("let(x)"))) == ["x"]
    assert list(find_variables(ast.parse("let(x=1)"))) == ["x"]
    assert list(find_variables(ast.parse("let(x); let(y)"))) == ["x", "y"]
    assert list(find_variables(ast.parse("let(x=1); let(y=2)"))) == ["x", "y"]



# Generated at 2022-06-12 04:38:17.597777
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: int, y: int) -> int:
        let(z)
        z = x + y
        return z

    locals_ = dict(x=1, y=2, z=3)

    for i in range(2):
        result = test.get_body(**locals_)
        assert ast.dump(result, include_attributes=True) == (
            '[Assign(targets=[Name(_py_backwards_z_0, Store())], value=BinOp(left=Name(x, Load()), op=Add(), right=Name(y, Load()))), Return(value=Name(_py_backwards_z_0, Load()))]'
        )

    locals_['z'] = result
    test.get_body(**locals_)

# Generated at 2022-06-12 04:38:26.048240
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet(x: str, y: str):
        let(x)
        x += y
        y = 1
        return x + y

    assert isinstance(test_snippet.get_body(x='x', y='y'), list)
    assert isinstance(test_snippet.get_body(x='x', y='y')[0], ast.Assign)
    assert isinstance(test_snippet.get_body(x='x', y='y')[1], ast.Assign)
    assert isinstance(test_snippet.get_body(x='x', y='y')[0].targets[0], ast.Name)

# Generated at 2022-06-12 04:38:34.150133
# Unit test for function extend_tree
def test_extend_tree():
    # Just to avoid pylint errors
    let(None)
    extend(None)

    tree = ast.parse('x = 1\nextend(l)\n')
    variables = {'l': [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=1)),
                       ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=2))]}
    extend_tree(tree, variables)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2))])"



# Generated at 2022-06-12 04:38:37.865167
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet(y):
        let(x)
        return x + y

    body = snippet.get_body(x=1)
    assert ast.dump(body) == '[Assign(targets=[Name(_py_backwards_x_0, Store())], value=Num(1))]'



# Generated at 2022-06-12 04:38:47.464991
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    code = '''\
    let(x)
    let(y)
    x = 1
    print(y)
    '''

    tree = ast.parse(code)
    cls = tree.body[0].body[0]
    assert cls.targets[0].id == 'x'
    assert cls.value.n == 1

    snippet = Snippet(lambda x: x + 1)
    body = snippet.get_body(x=2)
    assert len(body) == 3
    assert body[1].value.n == 2

# Generated at 2022-06-12 04:38:53.738594
# Unit test for function extend_tree
def test_extend_tree():
    tree: ast.AST = ast.parse("""extend(vars)
    print(x, y)""")
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        ),
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=' \
                            '"x", ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=' \
                

# Generated at 2022-06-12 04:39:00.396295
# Unit test for function extend_tree
def test_extend_tree():
    source = '\n'.join((
        'extend(body)',
        'x = 2',
    ))

    tree = ast.parse(source)
    body = ast.Module(body=[
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ])
    extend_tree(tree, {
        'body': body
    })

    assert get_source(tree) == '\n'.join((
        'x = 1',
        'x = 2',
    ))

# Generated at 2022-06-12 04:39:08.680320
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f(x: int):
        let(x)
        x += 1
        y = 1
        z = 2
        extend(vars)
        print(x, y, z)

    body = f.get_body(x=0, vars=[
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=1)),
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=2)),
    ])

    res = ast.dump(body)

# Generated at 2022-06-12 04:39:14.338521
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x, y: None).get_body() == []

    assert snippet(lambda x, y: let(x)).get_body() == []

    assert snippet(lambda x, y: extend(None)).get_body() == []

    assert snippet(lambda x, y: let(x)).get_body(x=1) == []

    assert snippet(lambda x, y: extend(None)).get_body(x=1) == []

    assert snippet(lambda x, y: let(x)).get_body(x=1) == []



# Generated at 2022-06-12 04:39:22.809328
# Unit test for function extend_tree
def test_extend_tree():
    source = get_source(_test_extend_tree)

    tree = ast.parse(source)
    node = find(tree, ast.Call, lambda node: node.func.id == 'extend')
    parent, index = get_non_exp_parent_and_index(tree, node)
    assert parent is tree
    assert index == 1

    variables = {'vars': [
        ast.Assign(
            [ast.Name('x')],
            ast.Constant(1))]}
    extend_tree(tree, variables)
    # tree has: [Assign(Name('x'), Constant(1)), Call(name('extend'), [Name('vars')])]
    assert [node.node for node in find(tree, ast.Assign)] == [variables['vars'][0]]



# Generated at 2022-06-12 04:39:31.734867
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # type: (...) -> None

    def test():
        # type: () -> None
        let(x)
        x += 3
        y = 1

    snippet_instance = snippet(test)
    test_let_parameter = '_py_backwards_x_0'
    get_body_result = snippet_instance.get_body(x=test_let_parameter)
    assert len(get_body_result) == 2
    assert isinstance(get_body_result[0], ast.AugAssign)
    assert get_body_result[0].target.id == test_let_parameter
    assert isinstance(get_body_result[1], ast.Assign)
    assert get_body_result[1].value.n == 1
    assert get_body_result[1].targets[0].id

# Generated at 2022-06-12 04:39:38.308135
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x):
        let(y)
        y += 1
        return x

    f_snippet = snippet(f)
    print(ast.dump(ast.Module(body=f_snippet.get_body())))
    assert ast.dump(ast.Module(body=f_snippet.get_body())) == "Module(body=[Assign(targets=[Name(_py_backwards_y_0, Store())], value=BinOp(left=Name(_py_backwards_y_0, Load()), op=Add(), right=Num(1)))])"

# Generated at 2022-06-12 04:39:43.790194
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        let(y)
        print(x, y)
    s = snippet(test)
    variables = {'x': 10, 'y': 20}
    body = s.get_body(**variables)
    assert body == [ast.Expr(ast.Call(ast.Name('print'), [
        ast.Str(variables['x']), ast.Str(variables['y'])], [], None, None))]



# Generated at 2022-06-12 04:39:51.714446
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = ast.Name(id='x', ctx=ast.Load())
    y = ast.Name(id='y', ctx=ast.Load())
    statement = ast.Assign(targets=[x], value=0)
    call = ast.Call(func=y, args=[], keywords=[])

    @snippet
    def snippet_fn(x: int, y: Callable[[], int]):
        let(x)
        x += 1
        y()

    assert snippet_fn.get_body(x=y) == [call]
    assert snippet_fn.get_body(x=2) == []  # type: ignore
    assert snippet_fn.get_body(y=ast.Call) == [statement]  # type: ignore

# Generated at 2022-06-12 04:40:04.993095
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    s = snippet(lambda x: 1)
    source = get_source(s._fn)
    tree = ast.parse(source)
    variables = s._get_variables(tree, {})
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

    assert tree.body == [
        ast.Expr(
            value=ast.Call(
                func=ast.Name(
                    id='print',
                    ctx=ast.Load()),
                args=[
                    ast.Num(
                        n=1)],
                keywords=[],
                starargs=None,
                kwargs=None))]



# Generated at 2022-06-12 04:40:14.150206
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    let, extend = let, extend
    import inspect

    @snippet
    def test_snippet():
        a = 1
        b = 2
        let(bla)
        bla += 1
        extend(vars)
        return bla + a + b

    frame = inspect.currentframe()
    while frame and frame.f_code.co_name != 'test_snippet':
        frame = frame.f_back
    assert frame is not None


# Generated at 2022-06-12 04:40:20.268823
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(f)
    tree = snippet_.get_body()

    assert tree[0].value.id == '_py_backwards_x_0'
    assert tree[0].value.ctx.__class__.__name__ == 'Load'
    assert tree[1].targets[0].id == 'y'

# Generated at 2022-06-12 04:40:20.829284
# Unit test for function extend_tree

# Generated at 2022-06-12 04:40:25.725366
# Unit test for function extend_tree
def test_extend_tree():
    extendable = ast.parse('''
        x += 1
        print(x)
    ''').body
    extend(extendable)

    def f():
        x = 1
        extend(extendable)

    tree = ast.parse(get_source(f))
    extend_tree(tree, {'extendable': extendable})
    assert ast.dump(tree) == ast.dump(ast.parse(
        """
x = 1
x += 1
print(x)
"""))



# Generated at 2022-06-12 04:40:34.718416
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test(expected_code_lines, code_lines):
        def _test_snippet():
            let(x)
            x += 1
            y = 1
            extend(vars)
            return x

        vars = ast.parse("""
            x = 1
            x = 2
        """)

        expected = ast.parse(expected_code_lines)
        got = snippet(_test_snippet).get_body(x=x, vars=vars.body)

        assert expected.body[0].body == got


# Generated at 2022-06-12 04:40:44.040485
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var1 = 1
    var2 = 2
    @snippet
    def tree():
        extend(var1)
        extend(var2)
        let(x)
        x += 1
        y = 1
    assert (tree.get_body()) == [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                           value=ast.BinOp(left=ast.Name(id='x', ctx=ast.Load()),
                                                           op=ast.Add(),
                                                           right=ast.Num(n=1))),
                                   ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())], value=ast.Num(n=1))]

# Generated at 2022-06-12 04:40:51.935350
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(x: int, y: str) -> None:
        let(x)
        let(y)
        x = 1
        return x + 1

    res = fn.get_body(x=ast.Num(n=1), y='b')
    assert res == [
        ast.Assign(
            targets=[ast.Name(id="_py_backwards_x_0", ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Return(value=ast.BinOp(
            left=ast.Name(id="_py_backwards_x_0", ctx=ast.Load()),
            op=ast.Add(),
            right=ast.Num(n=1)))
    ]

# Generated at 2022-06-12 04:41:00.109071
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:41:01.999440
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    s = snippet(lambda x: let(x) + x)
    assert s.get_body(x=ast.Name('y', ast.Load()))

# Generated at 2022-06-12 04:41:25.577957
# Unit test for function extend_tree
def test_extend_tree():
    program = """
import sys
extend(vars)
print(x, y)
"""
    tree = ast.parse(program)
    vars = ast.Module(body=ast.Assign(targets=[ast.Name(id="x", ctx=ast.Store())],
                                      value=ast.Num(n=1)),
                     type_ignores=[ast.Assign(targets=[ast.Name(id="x", ctx=ast.Store())],
                                      value=ast.Num(n=2))])
    extend_tree(tree, {"vars": vars})
    assert "x = 1" in str(tree)
    assert "x = 2" in str(tree)
    assert "print(x, y)" in str(tree)


# Generated at 2022-06-12 04:41:33.224068
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def body(x: int) -> None:
        let(a)
        a = x
        extend(code)
        print(a)

    assert str(body.get_body(x=3)) == '_py_backwards_a_0 = x\nprint(_py_backwards_a_0)\n'
    assert str(body.get_body(x=3, a=4)) == 'a = 4\nprint(a)\n'
    assert str(body.get_body(x=3, code=ast.parse('a = 10').body[0])) == 'a = 10\na = x\nprint(a)\n'



# Generated at 2022-06-12 04:41:42.778071
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    n = 10
    x = 5
    multiply = snippet(lambda x, y: let(a=1))  # Type(a) = ast.Name

    assert multiply.get_body(x=n, y=x) == [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=1)),
                                           ast.Expr(value=ast.BinOp(left=ast.Name(id='a', ctx=ast.Load()),
                                                                    op=ast.Add(),
                                                                    right=ast.Num(n=x)))]


# Generated at 2022-06-12 04:41:46.214257
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        def f():
            let(x)
            x = 1

        let(y)
        y = 2
        
        print(x, y)
    """)

    assert list(find_variables(tree)) == ['x', 'y']


# Units tests for class VariablesReplacer

# Generated at 2022-06-12 04:41:47.222789
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    pass

# Generated at 2022-06-12 04:41:53.029725
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(var)
        print(v)
    """)
    tree.body[1] = ast.parse('def f(): pass').body[0]
    extend_tree(tree, {'var': ast.parse('v = 2').body[0]})
    assert (ast.dump(tree) ==
            'Module([Assign([Name(v, Store())], Num(2)), '
            'FunctionDef(f, arguments([]), [], [], None, [])])')

# Generated at 2022-06-12 04:42:01.684607
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda: let(x)
                   ).get_body(x=[ast.parse("y = 1").body[0],
                                ast.parse("z = 2").body[0]]) == \
        ast.parse("_py_backwards_x_0 = y = 1; z = 2").body

    def with_extend():
        x = let(x)
        extend(vars_)
        print(x, y)


# Generated at 2022-06-12 04:42:09.292829
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_fn(a: ast.Name, b: ast.Name, c: ast.Name) -> None:
        y = 1
        x = 2
        let(a)
        let(b)
        let(c)
        extend(a)
        extend(b)
        extend(c)


# Generated at 2022-06-12 04:42:12.008415
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(arg)
    let(arg2)
    '''
    tree = ast.parse(source)
    names = eager(find_variables(tree))
    assert names == ['arg', 'arg2']



# Generated at 2022-06-12 04:42:15.658460
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # 'hello' - literal of string
    hello = ast.Str('hello')

    def hello_world():
        x = let('hello')
        y = extend('hello')

    # return strings 'hello'
    assert [node.s for node in snippet(hello_world).get_body(hello=hello)] == ['hello']


# Generated at 2022-06-12 04:42:58.503016
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(a); let(b); print(a, b);')
    result = find_variables(tree)
    assert list(result) == ['a', 'b']
    assert ast.dump(tree) == "<Module []>"

# Generated at 2022-06-12 04:43:07.652359
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test of snippet without let, without kwargs
    actual = snippet(lambda x, y=10: x + y).get_body()
    expected = [
        ast.Assign(
            targets=[ast.Name(id='__result__', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='x', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Name(id='y', ctx=ast.Load()),
            )
        ),
        ast.Return(
            value=ast.Name(id='__result__', ctx=ast.Load())
        )
    ]
    assert actual == expected

    # Test of snippet with let, without kwargs

# Generated at 2022-06-12 04:43:08.457376
# Unit test for function find_variables

# Generated at 2022-06-12 04:43:17.140432
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test1(x):
        let(x)
        x += 1
        y = 1

    container = test1.get_body(x=1)
    assert container[0].value.left.id == '_py_backwards_x_0'
    assert container[1].value.n == 1
    assert container[1].value.op.__class__.__name__ == 'Add'

    @snippet
    def test2(x):
        let(x)
        if x == 0:
            x = 2
        else:
            x = 1
        y = 1

    scope = test2.get_body(x=1)
    assert scope[0].value.left.id == '_py_backwards_x_0'
    assert scope[1].value.n == 1

# Generated at 2022-06-12 04:43:25.055305
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(x)").body[0]
    assert tuple(find_variables(tree)) == ('x',)
    assert ast.dump(tree) == 'Module'

    tree = ast.parse("let(x)\nlet(y)").body[0]
    assert tuple(find_variables(tree)) == ('x', 'y')
    assert ast.dump(tree) == "Module"

    tree = ast.parse("let(x)\ny = x + 1\nlet(z)").body[0]
    assert tuple(find_variables(tree)) == ('x', 'y', 'z')

# Generated at 2022-06-12 04:43:32.538943
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:43:39.625936
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = let(0)
    y = let(1)

    @snippet
    def snippet():
        x += 1
        y = 1
        extend(vars)

    vars = [
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(2))
    ]


# Generated at 2022-06-12 04:43:48.279051
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 11
    y = 22

    def function_body(x: int, y: int) -> int:
        x = let(x)
        x += 1
        y = let(y)
        sum_ = x + y
        i = 1

# Generated at 2022-06-12 04:43:50.592823
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> int:
        let(z)
        z = x + y
        return z


# Generated at 2022-06-12 04:43:51.151869
# Unit test for function find_variables

# Generated at 2022-06-12 04:44:49.185775
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn_get_body():
        var = 1
        let(var)  # type: ignore
        another_var = 2  # type: ignore
        extend(another_var)  # type: ignore

    body = fn_get_body.get_body(x=1)
    for node in body:
        print(node)



# Generated at 2022-06-12 04:44:54.567045
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_instance = snippet(lambda: x)
    out = snippet_instance.get_body(x=ast.Name("a", ast.Load()))
    assert out == ast.Module(body=[ast.Expr(value=ast.Name("a", ast.Load()))]).body
    snippet_instance2 = snippet(lambda: x)
    out2 = snippet_instance2.get_body(x=1)
    assert out2 == ast.Module(body=[ast.Expr(value=ast.Num(n=1))]).body

# Generated at 2022-06-12 04:44:57.253867
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(a)
    let(b)
    let(c)
    """
    tree = ast.parse(source)
    assert find_variables(tree) == ['a', 'b', 'c']



# Generated at 2022-06-12 04:45:05.741282
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 3
    y = 5
    z = 7
    @snippet
    def foo():
        let(x)
        y = x + 1
        z = y + 1
        return x

    snippet1 = foo.get_body()
    new_source1 = ast.fix_missing_locations(ast.Module(body=snippet1))
    snippet2 = foo.get_body()
    new_source2 = ast.fix_missing_locations(ast.Module(body=snippet2))
    src = compile(new_source1, '<ast>', 'exec')
    namespace = {}
    exec(src, namespace)
    print('Check 1:', namespace['_py_backwards_x_0'] == x)
    src = compile(new_source2, '<ast>', 'exec')

# Generated at 2022-06-12 04:45:07.259583
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import inspect
    body = snippet(inspect.currentframe).get_body()
    assert len(body) == 6

# Generated at 2022-06-12 04:45:10.740642
# Unit test for function find_variables
def test_find_variables():
    source = "let(x)\nx + 1"
    tree = ast.parse(source)
    print(find_variables(tree))
    assert find_variables(tree) == ['x']


# Generated at 2022-06-12 04:45:19.811883
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 123
    y = 456
    z = 789
    def f(a, b, *args, **kwargs):
        let(x)
        assert x == 123
        let(y)
        assert y == 456
        let(z)
        assert z == 789
        let(a)
        assert a == 10
        let(b)
        assert b == 20
        extend(args)
        extend(kwargs)
        return x + y + z + a + b + args[0] + args[1] + kwargs['a'] + kwargs['b']

    assert f(10, 20, 100, 200, a=1000, b=2000) == 123 + 456 + 789 + 10 + 20 + 100 + 200 + 1000 + 2000


# Generated at 2022-06-12 04:45:28.145148
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''
    if a:
        let(x)
        let(y)
        z = x + 1
    else:
        let(x)
        print(x)
    let(y)
    ''')
    assert set(find_variables(tree)) == {'x', 'y', 'z'}

# Generated at 2022-06-12 04:45:37.154739
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test() -> None:
        let(x)
        let(y)
        print(x + y)

    snippet = snippet(test).get_body(x=1, y=2)

# Generated at 2022-06-12 04:45:47.158550
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1

    @snippet
    def test():
        let(x)
        x += 1
        y = 1  # noqa

    body = test.get_body()

    assert isinstance(body, List)
    assert len(body) == 2

    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[0].targets[0], ast.Name)
    assert body[0].targets[0].id == '_py_backwards_x_0'

    assert isinstance(body[0].value, ast.BinOp)
    assert isinstance(body[0].value.left, ast.Name)
    assert body[0].value.left.id == '_py_backwards_x_0'