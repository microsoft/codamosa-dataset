

# Generated at 2022-06-12 04:36:31.629058
# Unit test for function find_variables
def test_find_variables():
    from .helpers import get_source
    source = get_source(lambda: None)

    def test_func():
        let(x)
        let(y)

    tree = ast.parse(source(test_func))
    assert list(find_variables(tree)) == [
        'x', 'y'
    ]



# Generated at 2022-06-12 04:36:35.366679
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(x)")
    assert list(find_variables(tree)) == ['x']

    tree = ast.parse("""let(x)
    let(y)
    (x, y)
    """)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-12 04:36:37.413571
# Unit test for function find_variables
def test_find_variables():
    import ast
    tree = ast.parse("let(a)\nlet(b)\nlet(c)")
    assert find_variables(tree) == ['a', 'b', 'c']



# Generated at 2022-06-12 04:36:41.621759
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse(dedent('''
                        let(a)
                        let(b) = 1
                        let(a) = 1
                        let(b) = 2
                        let(a) = 3
                        
                    '''))

    variables = set(find_variables(tree))
    assert len(variables) == 2
    assert 'a' in variables
    assert 'b' in variables



# Generated at 2022-06-12 04:36:50.819678
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def get_snippet() -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(get_snippet)

# Generated at 2022-06-12 04:37:00.460854
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""a, b = 1, 2
    c = extend(arg)
    """)
    extend_tree(tree, {'arg': [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1)),
                                ast.Assign([ast.Name(id='y', ctx=ast.Store())], ast.Num(2))]})


# Generated at 2022-06-12 04:37:07.450895
# Unit test for function extend_tree
def test_extend_tree():
    with open('test_extend_tree.py', 'r') as f:
        original_source = f.read()
        original_ast = ast.parse(original_source)
        new_source = 'x = 1\nx = 2\n'
        f.seek(0)
        new_ast = ast.parse(new_source)
        extend_tree(original_ast, {'vars': new_ast.body})
        source = ast.unparse(original_ast)
        assert source == new_source + 'print(x, y)\n', source


# Generated at 2022-06-12 04:37:15.807524
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''def f():
    extend(vars)
    x += 1
''')
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                          value=ast.Num(n=1)), ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                                         value=ast.Num(n=2))]})

    assert get_source(tree) == 'def f():\n    x = 1\n    x = 2\n    x += 1\n'



# Generated at 2022-06-12 04:37:18.689548
# Unit test for function find_variables
def test_find_variables():
    code = """\
    let(x)
    """
    tree = ast.parse(code)
    variables = [var for var in find_variables(tree)]
    assert variables == ['x']


# Generated at 2022-06-12 04:37:24.280412
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(x)\n"
                     "let(y)\n"
                     "let(z)\n"
                     "let(increment_x)\n"
                     "let(increment_y)\n")
    assert list(find_variables(tree)) == ['x', 'y', 'z', 'increment_x', 'increment_y']
    assert tree == ast.parse('')



# Generated at 2022-06-12 04:37:33.291619
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda: let(x)).get_body() == [
        ast.Assign(
            [ast.Name(id='_py_backwards_x_0',
                      ctx=ast.Store(),
                      annotation=None)],
            ast.Name(id='x', ctx=ast.Load(), annotation=None),
            type_comment=None
        )
    ]

# Generated at 2022-06-12 04:37:35.542647
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""let(x)
    x = 1
    y = 2""")
    assert set(find_variables(tree)) == {'x'}



# Generated at 2022-06-12 04:37:37.413919
# Unit test for function find_variables
def test_find_variables():
    s = snippet(find_variables)
    ast = s.get_body()
    assert len(ast) == 0


# Generated at 2022-06-12 04:37:48.320268
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
i = 1
j = 2
extend(vars)
k = 3
l = 4
'''
    tree = ast.parse(source)
    assign_x = ast.Assign([ast.Name(id='i', ctx=ast.Store())], ast.Num(n=0))
    assign_y = ast.Assign([ast.Name(id='k', ctx=ast.Store())], ast.Num(n=0))

    extend_tree(tree, {'vars': [assign_x]})

# Generated at 2022-06-12 04:37:54.874946
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from astpretty import pprint

    @snippet
    def snippet():
        let(x)
        x += 1
        y = 1

    # Output the body
    pprint(snippet.get_body())

    # Output the body without the first line
    print('Body without the first line:')
    body = snippet.get_body()
    body.pop(0)
    pprint(ast.Module(body))

    @snippet
    def snippet():
        let(x)
        x += 1
        print(x, y)

    tree = ast.parse('x = 1')
    vars = [n.name for n in find(tree, ast.Name) if isinstance(n.ctx, ast.Store)]
    variables = {name: tree.body[0].value for name in vars}

   

# Generated at 2022-06-12 04:38:01.630214
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    expected = [ast.Assign([ast.Name('x', ast.Store())],
                           ast.BinOp(ast.Name('x', ast.Load()),
                                     ast.Add(),
                                     ast.Num(1))),
                ast.Assign([ast.Name('y', ast.Store())],
                           ast.Num(1))]

    def test_body() -> None:
        let(x)
        x += 1
        y = 1

    body = snippet(test_body).get_body()

    assert body == expected

# Generated at 2022-06-12 04:38:04.253152
# Unit test for function extend_tree
def test_extend_tree():
    var = ast.parse('x = 1').body[0]  # type: ast.AST

    extend(var)
    extend(var)


# Unit tests for function find_variables

# Generated at 2022-06-12 04:38:14.184859
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def add(x, y):
        let(z)
        return x + y + z

    assert add.get_body(x=1, y=2) == [ast.Assign(
        targets=[ast.Name(id='_py_backwards_z_0', ctx=ast.Store())],
        value=ast.BinOp(left=ast.BinOp(left=ast.Name(id='x', ctx=ast.Load()),
                                       op=ast.Add(),
                                       right=ast.Name(id='y', ctx=ast.Load())),
                        op=ast.Add(),
                        right=ast.Name(id='_py_backwards_z_0',
                                       ctx=ast.Load())))]


# Generated at 2022-06-12 04:38:16.173747
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x)\nx = 1')  # type: ignore
    assert find_variables(tree) == ['x']



# Generated at 2022-06-12 04:38:19.215887
# Unit test for function find_variables
def test_find_variables():
    snippet = ast.parse('''
    let(x)
    let(y)

    if x:
        x
    if y:
        y
    if let(z):
        z
    ''')

    assert set(find_variables(snippet)) == set(['x', 'y', 'z'])



# Generated at 2022-06-12 04:38:26.535959
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(var_1)\nvar_2 = 1\nlet(var_3)')
    assert list(find_variables(tree)) == ['var_1', 'var_3']


# Generated at 2022-06-12 04:38:33.206417
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var = 'test'
    # body = snippet.body(var)
    # assert body == [ast.Assign(
    #                            [ast.Name(
    #                                      id='_py_backwards_var_0',
    #                                      ctx=ast.Load())],
    #                            ast.Num(n=1))]
    body = snippet.get_body(var)
    assert body == [ast.Assign(
                               [ast.Name(
                                         id='_py_backwards_var_0',
                                         ctx=ast.Load())],
                               ast.Num(n=1))]

# Generated at 2022-06-12 04:38:39.688671
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(vars)\nprint(x)")
    tree.body.append(ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                value=ast.Num(1)))

    extend_tree(tree, {'vars': [tree.body.pop(1)]})
    assert str(tree) == 'extend(vars)\nx = 1\nprint(x)\n'

    extend_tree(tree, {'vars': []})
    assert str(tree) == 'extend(vars)\nx = 1\nx = 2\nprint(x)\n'



# Generated at 2022-06-12 04:38:43.362139
# Unit test for function extend_tree
def test_extend_tree():
    var = ast.parse("x = 1; x = 2; print(x)").body
    tree = ast.parse("extend(var); print(x)")
    extend_tree(tree, {'var': var})
    assert get_source(tree) == 'x = 1; x = 2; print(x); print(x)'



# Generated at 2022-06-12 04:38:51.745098
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def print_function_1():
        print('a')

    def print_function_2():
        print(a)

    def print_function_3():
        print(a, b)

    def print_function_4():
        a = 1
        return a

    def print_function_5():
        print(a)
        a = 1
        print(a)

    def print_function_6():
        print(a)
        return a

    def print_function_7():
        print(a)
        print(a, b)
        print(c)

    def print_function_8():
        let(a)
        print(a)
        a = 1
        print(a)

    def print_function_9():
        b = 1
        let(a)
        print(a, b)


# Generated at 2022-06-12 04:38:57.167326
# Unit test for function extend_tree
def test_extend_tree():
    assert extend_tree(ast.parse('extend(vars)'), {'vars': [ast.parse('x = 5')]}) == None
    assert extend_tree(ast.parse('func(extend(vars))'), {'vars': [ast.parse('x = 5')]}) == None
    assert get_source(extend_tree) == '''if value in self._variables:\n    ...'''


# Generated at 2022-06-12 04:39:03.678224
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_code():
        let(x)
        x += 1
        y = 1
    snippet_body = snippet(snippet_code).get_body()
    assert isinstance(snippet_body, list)
    assert len(snippet_body) == 2
    assert isinstance(snippet_body[0], ast.Assign)
    assert isinstance(snippet_body[1], ast.Assign)
    assert isinstance(snippet_body[0].value, ast.BinOp)
    assert snippet_body[0].value.op.__class__.__name__ == 'Add'
    assert isinstance(snippet_body[1].value, ast.Num)
    assert snippet_body[1].value.n == 1



# Generated at 2022-06-12 04:39:12.164294
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:39:18.656756
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import find_expr_root

    @snippet
    def s(x: int, y: int) -> int:
        let(z)
        z += 1
        a = {'z': z}
        return a[x] + y

    a, b = s.get_body(x='z', y=5)
    assert type(a) is ast.Assign
    assert len(b) == 1
    assert b[0].value.left.id == '_py_backwards_z_0'

# Generated at 2022-06-12 04:39:24.734790
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(a: int, b: str) -> int:
        let(x)
        x = a
        y = b
        let(z)
        z = x + 1
        return z


# Generated at 2022-06-12 04:39:33.683069
# Unit test for function find_variables
def test_find_variables():
    from .tree import to_source
    source = 'let(a)\na += 1'
    tree = ast.parse(source)
    assert find_variables(tree) == ['a']
    assert to_source(tree) == 'a += 1'
    source = 'let(a)\nlet(b[0])\na += 1'
    tree = ast.parse(source)
    assert find_variables(tree) == ['a', 'b']
    assert to_source(tree) == 'a += 1'



# Generated at 2022-06-12 04:39:42.412781
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    src = """
        def foo():
            extend(vars)
            let(x)
            print(x)
            let(z)
        """
    tree = ast.parse(src)
    extend_var_tree = ast.parse("x = 1")
    extend_var_replace_tree = ast.parse("x = 2")
    variables = {'vars': extend_var_tree, 'x': 'y', 'z': 'w'}
    extend_tree(tree, {'vars': extend_var_replace_tree})

    snippet_body = snippet(_test_snippet_get_body).get_body(**variables)

    expected_body = ast.parse("""
        x = 1
        x = 2
        print('y')
        """).body

    assert snippet_body == expected_body


# Generated at 2022-06-12 04:39:48.454281
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # noinspection PyMethodFirstArgAssignment
    def test():
        let(x)
        x += 1
        x += 1

    snippet = snippet(test)
    x = ast.parse('x = 0').body[0]
    assert snippet.get_body(x=x) == ast.parse('_py_backwards_x_0 = 0').body
    assert snippet.get_body(x='_py_backwards_x_0') == ast.parse('_py_backwards_x_0 = 0').body



# Generated at 2022-06-12 04:39:57.811381
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from ..expression import Expression
    from ..slicing import VariableRange

    def fn2():
        x = 2
        (x * 2) + y
        x = 1

    x = Expression('x')
    y = Expression('y')
    z = Expression('z')

    # User defined function
    def fn(a: VariableRange, b: Expression, c: int = 3, **kwargs: Expression) -> Expression:
        x = a
        y = 2 * b
        let(z)
        y + z
        return (x * 2) + y
        let(vars)
        extend(vars)
        let(a)
        let(b)
        return a + b

    res = snippet(fn).get_body(a=x, b=y, c=4, d=x+y)
    assert res

# Generated at 2022-06-12 04:40:06.564657
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Checks that snippet gets correctly replaced."""
    @snippet
    def fn(x, y):
        let(z)
        z += 1
        y += x
        if z > 1:
            z += 1
        for z in range(z):
            pass
        if x:
            let(y)
            y = 4
        if 1:
            pass
        if 2:
            pass
        if 3:
            pass
        if 4:
            pass
        if 5:
            pass
        if 6:
            pass
        if 7:
            pass


# Generated at 2022-06-12 04:40:16.471225
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def get_body(x, y):
        let(x)
        extend(y)

    x = ast.Name(id='x', ctx=ast.Load())  # type: ast.AST
    x_assign = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                          value=ast.Num(n=1))  # type: ast.AST
    y_assign = ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                          value=ast.Num(n=2))  # type: ast.AST

    snippet_obj = snippet(get_body)

# Generated at 2022-06-12 04:40:25.159969
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def foo(x: int, y: int, z: int):
        let(x)
        x += 1
        x += y 
        extend(z)

    x: ast.Name = ast.Name(id='x', ctx=ast.Load(), lineno=2, col_offset=6)
    y: ast.Name = ast.Name(id='y', ctx=ast.Load(), lineno=2, col_offset=10)
    add: ast.Add = ast.Add()
    stmt_x_plus_one: ast.AugAssign = ast.AugAssign(target=x, op=add, value=ast.Num(1), lineno=3, col_offset=4)

# Generated at 2022-06-12 04:40:25.900567
# Unit test for function find_variables

# Generated at 2022-06-12 04:40:31.487289
# Unit test for function extend_tree
def test_extend_tree():
    local_vars = dict()
    tree = ast.parse('''vars = ['var1 = 1', 'var2 = 2']
                       extend(vars)''')
    extend_tree(tree, locals())
    assert(len(tree.body) == 2)
    assert(tree.body[0].value.s == "'var1 = 1'")
    assert(tree.body[1].value.s == "'var2 = 2'")


# Generated at 2022-06-12 04:40:41.819338
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import inspect
    from .helpers import get_source

    def snippet_to_test():
        let(x)
        let(y)
        let(z)
        x += 1
        y = 1
        z = 2

        extend(vars)
        extend(vars2)

    # Test part
    # Prepare variables for test
    source = get_source(snippet_to_test)
    tree = ast.parse(source)
    names = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name)
                 for name in names}

    variables['vars'] = [ast.Assign(targets=[ast.Name(id=variables['x'], ctx=ast.Store())],
                                    value=ast.Num(1))]


# Generated at 2022-06-12 04:40:50.775215
# Unit test for function find_variables
def test_find_variables():
    # noinspection PyUnusedLocal
    def foo() -> None:
        let(x)
        let(y)
        let(z)

    tree = ast.parse(get_source(foo))
    variables = find_variables(tree)
    assert list(variables) == ['x', 'y', 'z']



# Generated at 2022-06-12 04:40:58.761848
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Arrange
    def function(x: int, y: int) -> None:
        let(x)
        x += 1
        y += 2
        print(x, y)

    # Act
    body = snippet(function).get_body(x=5, y=7)

    # Assert

# Generated at 2022-06-12 04:41:01.686940
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test():
        let(x)
        x += 1
        y = 1
        
    tree = ast.parse('x += 1\ny = 1')
    assert test.get_body() == tree.body

# Generated at 2022-06-12 04:41:09.919065
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x: Any, y: Any) -> None:
        let(z)
        extend(extra)
        x = z + y + 1
        print(x + y)


# Generated at 2022-06-12 04:41:15.942482
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def my_snippet1(x, y):
        extend(dict(x=1, y=2))
        print(x, y)

    body = snippet(my_snippet1).get_body(x='_py_backwards_x_0', y='_py_backwards_y_0')
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[2], ast.Expr)

    def my_snippet2(x):
        let(x)
        x += 1
        y = 1

    body = snippet(my_snippet2).get_body(x='_py_backwards_x_0')
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance

# Generated at 2022-06-12 04:41:19.027339
# Unit test for function find_variables
def test_find_variables():
    code = """
    def some_func():
        let(a)
        let(b)
        a + b
    """

    tree = ast.parse(code)
    variables = find_variables(tree)

    assert list(variables) == ['a', 'b']

# Generated at 2022-06-12 04:41:27.470925
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _foo():
        """
        a = 0
        let(x)
        let(y)
        extend(vars)
        x = 1
        """

    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1),
            lineno=8,
            col_offset=0
        )
    ]
    snippet_get_body = snippet(_foo).get_body(vars=vars)

# Generated at 2022-06-12 04:41:35.023637
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func(x, y):
        let(x)
        x += 1
        y = 1

    expected_body = [
        ast.AugAssign(target=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()), op=ast.Add(), value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())], value=ast.Num(n=1)),
    ]

    test = snippet(func).get_body(x=0, y=0)
    assert test == expected_body, 'snippet.get_body() method works incorrectly'

# Generated at 2022-06-12 04:41:44.561050
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import numpy as np

    def snippet_function(x: float) -> float:
        x += 1.1
        let(x)
        for a in range(4):
            z = a**4
            let(z)
            x *= z
        return x

    snippet_function(1.0)

    code_snippet = snippet(snippet_function)
    snippet_body = code_snippet.get_body(x=3.14)

    assert(isinstance(snippet_body, list))
    assert(isinstance(snippet_body[0], ast.Assign))
    assert(isinstance(snippet_body[0].value, ast.BinOp))

    snippet_body = ast.Module(snippet_body)

# Generated at 2022-06-12 04:41:48.227832
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def my_snippet(x: int) -> int:
        let(x)
        return x + 1

    my_snippet_body = snippet(my_snippet).get_body()
    assert my_snippet_body == [ast.Return(ast.BinOp(ast.Name(id='_py_backwards_x_0', ctx=ast.Load()), ast.Add(), ast.Num(n=1)))]



# Generated at 2022-06-12 04:42:16.407743
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a: ast.Name
    b: ast.Name
    c: ast.Name

    @snippet
    def func_1(a: ast.Name, b: ast.Name, c: ast.Name):
        let(1)
        let(2)
        let(a)
        let(b)
        extend(a)

    # get_source to get the source code
    source_without_extend_func = get_source(func_1)
    # get_body to get the AST of function
    tree_without_extend_func = func_1.get_body(a=1, b=2, c=3)
    # ast_to_source to transform the list AST to source code
    source_with_extend_func = ast.unparse(tree_without_extend_func)

    source_

# Generated at 2022-06-12 04:42:24.761997
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def _test_snippet(a: int, b: int, c: int) -> int:
        let(x)
        x = a * 2
        let(y)
        y = b * 3
        extend(vars)
        vars = [
            ast.Assign([ast.Name(id='x')], ast.Num(n=1)),
            ast.Assign([ast.Name(id='x')], ast.Num(n=2)),
            ast.Assign([ast.Name(id='y')], ast.Num(n=3))
        ]
        return x + y + c

# Generated at 2022-06-12 04:42:29.761408
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Testing snippet.get_body()"""
    import py_backwards.helpers as helpers
    x = helpers.VariablesGenerator.generate('x')
    y = helpers.VariablesGenerator.generate('y')
    ast_x = ast.Num(x)
    ast_y = ast.Num(y)

    @snippet
    def test(x: int):
        let(x)
        y = 1
        return None

    assert test.get_body(x=ast_x) == [ast.Assign([ast.Name(id=y, ctx=ast.Store())], ast_y)]

# Generated at 2022-06-12 04:42:38.249169
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''
    if 1:
        extend(var)
        print(x)
        z = 1
        print(y)
        ''').body[0]
    extensions = ast.parse('''
    x = 1
    y = 2
    ''')
    extend_tree(tree, {'var': extensions})
    result = ast.dump(tree)

# Generated at 2022-06-12 04:42:46.456122
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast
    @snippet
    def foo(a, b, c) -> None:
        let(a)
        extend(b)
        let(c)
        print(a)
        print(b)
        print(c)

    # Variable `a` is replaced with unique name.
    # Variable `b` is replaced with AST of assignments.
    # Variable `c` is replaced with unique name.

# Generated at 2022-06-12 04:42:50.432864
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse(
        """
        let(x)
        let(y)
        x += 1
        y = 1
        print(x, x)
        """
    )
    names = find_variables(tree)
    expected = {'x', 'y'}
    assert set(names) == expected

# Generated at 2022-06-12 04:42:58.876620
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet1(x: int) -> int:
        let(y)
        return x + y

    def snippet1_body(x: int) -> int:
        return x + y

    assert snippet1.get_body(x=1) == snippet1_body(x=1).body

    @snippet
    def snippet2(x: int) -> int:
        let(y)
        let(z)
        return x + y + z

    def snippet2_body(x: int) -> int:
        return x + y + z

    assert snippet2.get_body(x=1) == snippet2_body(x=1).body

    @snippet
    def snippet3(x: int) -> int:
        extend(vars)
        return x


# Generated at 2022-06-12 04:43:08.093315
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def func():
        let(x)
        x += 1
        y = 1
        extend(vars)
        return (x, y)
        
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    body = func.get_body(vars=vars)

# Generated at 2022-06-12 04:43:16.834261
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def not_assign(x: int) -> None:
        let(x)
        x += 1
        y = 1

    print(snippet(not_assign).get_body())

    def assign_node(x: int) -> None:
        let(x)
        x = 1

    print(snippet(assign_node).get_body())

    def assign_literal(x: int) -> None:
        let(x)
        x = 1

    print(snippet(assign_literal).get_body())

    def assign_ast(x: int) -> None:
        let(x)
        x = ast.parse('x = 1').body[0]

    print(snippet(assign_ast).get_body())


# Generated at 2022-06-12 04:43:21.260512
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def t(x: str, y: ast.Name) -> None:
        let(x)
        y = 1

    assert t.get_body(x='s', y=ast.Name(id='a')) == [
        ast.Assign(
            targets=[
                ast.Name(id='a')
            ],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-12 04:43:46.767597
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('x = 1\n'
                     'extend(vars)\n'
                     'print(x, y)')
    vars = ast.parse('x = 1\n'
                     'x = 2\n')
    extend_tree(tree, {'vars': vars})
    assert(ast.dump(tree) == '<_ast.Module object at 0x7f058d66b780>')

# Generated at 2022-06-12 04:43:53.071015
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    extend(vars)
    print(x)
    """

    tree = ast.parse(source)
    vars = [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=1)),
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    result = ast.parse("""
    x = 1
    x = 2
    print(x)
    """)

    assert ast.dump(result) == ast.dump(tree)

# Generated at 2022-06-12 04:44:01.595060
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f(x: int) -> None:
        let(y)
        y += 2
        y += x
        return y

    assert f.get_body(x=1) == [
        ast.AugAssign(  # type: ignore
            target=ast.Name(id='_py_backwards_y_0', ctx=ast.Store()),
            op=ast.Add(),
            value=ast.Num(n=2)
        ),
        ast.AugAssign(
            target=ast.Name(id='_py_backwards_y_0', ctx=ast.Store()),
            op=ast.Add(),
            value=ast.Name(id='_py_backwards_x_0', ctx=ast.Load())
        )
    ]



# Generated at 2022-06-12 04:44:09.963041
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    with open('test_snippet_get_body.py', 'r') as f:
        source = f.read()
    tree = ast.parse(source)
    body = list(tree.body)
    assert len(body) == 4

    expected = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
        ast.BinOp(left=ast.Name(id='x', ctx=ast.Store()), op=ast.Add(), right=ast.Num(n=5)),
        ast.Return(value=ast.Name(id='y', ctx=ast.Load()))
    ]
    actual = snippet(test_snippet_get_body).get_body()
    assert actual == expected


#

# Generated at 2022-06-12 04:44:12.578820
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class A:
        @snippet
        def f(x: int, y: int) -> int:
            let(z)
            z = 0
            return x + y + z

    assert A().f(x=1, y=2) == 3

# Generated at 2022-06-12 04:44:22.346387
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def example_snippet(x: int) -> int:
        let(x)
        x += 1
        return x

    snippet_example = snippet(example_snippet)
    assert snippet_example.get_body(x=1) == [
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.AugAssign(target=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                      op=ast.Add(),
                      value=ast.Num(n=1)),
        ast.Return(value=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()))
    ]




# Generated at 2022-06-12 04:44:28.997821
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_function(x: str, y: str = 'y') -> None:
        let(x)
        let(y)
        x = 1
        y = 2

    test_snippet = snippet(test_function)
    variables = {'x': VariablesGenerator.generate('x'), 'y': VariablesGenerator.generate('y')}
    actual_body = test_snippet.get_body(**variables)

# Generated at 2022-06-12 04:44:31.654935
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_one():
        let(x)
        x += 1
        y = 1

    assert isinstance(snippet_one.get_body(), list)



# Generated at 2022-06-12 04:44:34.027138
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo():
        let(x)  # type: ignore
        x += 1
        y = 1

    fn = snippet(foo)
    variables = find_variables(fn.get_body())
    assert not variables

# Generated at 2022-06-12 04:44:41.725815
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def show_x_and_y(x: int, y: int, z: int) -> None:
        let(x)
        let(z)
        print(x, y)
        print(z)

    expected_source = '\n'.join([
        '_py_backwards_x_0 = 1',
        '_py_backwards_z_0 = 2',
        'print(_py_backwards_x_0, y)',
        'print(_py_backwards_z_0)'])
    tree = ast.parse(expected_source)
    source = show_x_and_y.get_body(x=1, y=2, z=3)
    assert source == tree.body

# Generated at 2022-06-12 04:45:23.593670
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        let(y)
        x = 1

    snippet(test).get_body()

# Generated at 2022-06-12 04:45:26.675765
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_body = snippet(lambda x: x * x).get_body()
    wanted_body = ast.parse('_py_backwards_x_0 * _py_backwards_x_0').body
    assert snippet_body == wanted_body



# Generated at 2022-06-12 04:45:28.543534
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(z); let(a)')
    assert tuple(find_variables(tree)) == ('z', 'a')

# Generated at 2022-06-12 04:45:37.756944
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda: 1).get_body() == [ast.Expr(value=ast.Num(n=1))]
    assert snippet(lambda x: x).get_body() == \
           [ast.Expr(value=ast.Name(id='_py_backwards_x_0',
                                    ctx=ast.Load()))]
    assert snippet(lambda x=2: x).get_body() == \
           [ast.Expr(value=ast.Num(n=2))]
    assert snippet(lambda x, y: y).get_body() == \
           [ast.Expr(value=ast.Name(id='_py_backwards_y_1',
                                    ctx=ast.Load()))]

# Generated at 2022-06-12 04:45:45.952608
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _fn():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    snippet_kwargs = {'x': 1, 'vars': [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=1))]}
    tree = snippet(_fn).get_body(**snippet_kwargs)
    assert [t.__class__ for t in tree] == [ast.Assign, ast.Assign, ast.Expr, ast.Expr]

# Generated at 2022-06-12 04:45:54.189533
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def my_func(a: int, b: int) -> None:
        let(x)
        x += a
        
        let(y)
        y = x + b
        
        extend(vars)
        print(x, y)
        
    s = snippet(my_func)
    tree = ast.parse('\n'.join([
          'x = 1',
          'y = 2'
    ]))
    body = s.get_body(a=1, b=3, vars=tree.body)
    assert str(body[0]) == "_py_backwards_x_0 += 1"
    assert str(body[1]) == "_py_backwards_y_0 = _py_backwards_x_0 + 3"
    assert str(body[2]) == "x = 1"
   

# Generated at 2022-06-12 04:46:03.171999
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def func(x: int, **kwargs: int) -> int:
        let(y)
        let(kwargs)
        extend(y)
        return x + y

    stmt_list = func.get_body(x=1, kwargs=3)
    assert len(stmt_list) == 2
    assert isinstance(stmt_list, list)
    assert isinstance(stmt_list[0], ast.Expr)
    assert isinstance(stmt_list[0].value, ast.Call)
    assert isinstance(stmt_list[0].value.func, ast.Name)
    assert stmt_list[0].value.func.id == 'let'
    assert isinstance(stmt_list[0].value.args[0], ast.Name)

# Generated at 2022-06-12 04:46:10.618288
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .parser import get_ast
    from .helpers import code_to_ast, ast_to_code

    ast1 = get_ast('''
        a = 3
    ''')

    ast2 = get_ast('''
        a = 4
    ''')

    expected = get_ast('''
        a = 4
        a = 3
    ''')

    @snippet
    def test(ast1: ast.AST, ast2: ast.AST):
        extend(ast1)
        extend(ast2)

    actual = ast.parse(ast_to_code(test.get_body(ast1=ast1, ast2=ast2)))
    assert ast_to_code(actual) == ast_to_code(expected)

# Generated at 2022-06-12 04:46:17.952343
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        let(y)
        x = 1
        y = 1

    s = snippet(test)
    x = ast.Name(id='_py_backwards_x_0', ctx=ast.Load())
    assert s.get_body(x=x) == [
        ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   ast.Num(n=1)),
        ast.Assign([ast.Name(id='_py_backwards_y_0', ctx=ast.Store())],
                   ast.Num(n=1))
    ]