

# Generated at 2022-06-12 04:36:27.721594
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test(val: int) -> int:
        let(x)
        x += val
        return x

    assert snippet(test).get_body(val=3) == [
        ast.Assign(
            targets=[
                ast.Name(id='_py_backwards_x_0', ctx=ast.Store())
            ],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Name(id='val', ctx=ast.Load())
            )
        ),
        ast.Return(
            value=ast.Name(id='_py_backwards_x_0', ctx=ast.Load())
        )
    ]



# Generated at 2022-06-12 04:36:36.139259
# Unit test for function find_variables
def test_find_variables():
    source1 = '''let(x)
x += 1
y = 1
'''

    source2 = '''let(x)
let(y)

y += x
'''

    source3 = '''let(x)
let(y)

y += x
let(z)
y += z
'''

    source4 = '''let(x)
let(y)
let(z)

y += x
y += z
'''

    source5 = '''def fn():
    let(x)
    x += 1
    y = 1'''

    source6 = '''def fn():
    let(x)
    let(y)

    y += x'''


# Generated at 2022-06-12 04:36:40.560248
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
let(x)
extend(x)
extend(y)
""")
    x = ast.parse('x = 1')
    y = ast.parse('x = 1; x = 2')
    extend_tree(tree, {'x': x.body, 'y': y.body})
    assert ast.dump(tree) == ast.dump(ast.parse('x = 1; x = 1; x = 2'))

# Generated at 2022-06-12 04:36:45.004009
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse('''from a.b as c''')
    vars_ = {'c': 'd'}
    VariablesReplacer.replace(tree, vars_)
    assert ast.dump(tree, include_attributes=True) == \
        "Module(body=[ImportFrom(module='a.b', names=[alias(name='d', asname=None)], level=0)])"

# Generated at 2022-06-12 04:36:49.478863
# Unit test for function find_variables
def test_find_variables():
    code = """
    let(x)
    x += 1
    let(y)
    y = 2
    """

    tree = ast.parse(code)
    assert frozenset(find_variables(tree)) == frozenset(['x', 'y'])
    assert len(tree.body) == 4



# Generated at 2022-06-12 04:36:54.319518
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = '''
        def fn(x):
            let(y)
            y += 1
            return y
    '''

    tree = ast.parse(source)
    snippets = find(tree, snippet)
    variables = snippets[0]._get_variables(tree, {})

    assert variables['y'] == '_py_backwards_y_0'
    assert len(variables) == 1

# Generated at 2022-06-12 04:37:01.000512
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_class = snippet(test_snippet_get_body)
    code_ast = snippet_class.get_body()
    assert code_ast == \
           [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                        ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                  ast.Add(), ast.Num(1))),
            ast.Assign([ast.Name('y', ast.Store())], ast.Num(1))]

# Generated at 2022-06-12 04:37:05.310263
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def empty_snippet():
        pass

    tree = snippet(empty_snippet).get_body()
    assert len(tree) == 0

    def simple():
        x = 1

    tree = snippet(simple).get_body()
    assert len(tree) == 1
    assert type(tree[0]) is ast.Assign



# Generated at 2022-06-12 04:37:15.359297
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(x: int, y: int) -> None:
        let(q)
        q = x + y
        print(q)

    body = fn.get_body(x=1, y=2)

# Generated at 2022-06-12 04:37:24.871192
# Unit test for function find_variables
def test_find_variables():
    import py_backwards
    code = """
    def foo(self):
        let(x)
        x += 1
    """

    # Check find_variables function
    tree = ast.parse(code)
    assert 'x' in list(py_backwards.find_variables(tree))
    tree2 = ast.parse(code)
    assert 'x' in list(py_backwards.find_variables(tree2))

    # Check that tree is correctly transformed
    assert len(tree.body) == 1
    assert len(tree2.body) == 1
    fn1 = tree.body[0]
    assert len(fn1.body) == 1
    assert isinstance(fn1.body[0], ast.AugAssign)
    assert isinstance(fn1.body[0].target, ast.Name)


# Generated at 2022-06-12 04:37:36.204014
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = textwrap.dedent("""
    from foo import bar, baz as _py_backwards_my_var
    """)
    tree = ast.parse(source)
    variables = {
        'my_var': 'foo',
    }
    replace = VariablesReplacer(variables)
    replace.visit(tree)
    assert tree.body[0].module == 'foo'
    assert isinstance(tree.body[0].names[0], ast.alias)
    assert tree.body[0].names[0].name == 'bar'
    assert tree.body[0].names[1].name == 'baz'
    assert tree.body[0].names[1].asname == 'foo'



# Generated at 2022-06-12 04:37:46.814023
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(x)")
    variables = {'x': ast.parse("x = 1").body[0]}

    extend_tree(tree, variables)
    body = tree.body  # type: ignore

    assert len(body) == 2

    assert isinstance(body[0], ast.Assign)
    assign = body[0]
    assert len(assign.targets) == 1
    assert isinstance(assign.targets[0], ast.Name)
    assert isinstance(assign.targets[0].ctx, ast.Store)
    assert assign.targets[0].id == 'x'

    assert isinstance(assign.value, ast.Num)
    assert assign.value.n == 1

    assert isinstance(body[1], ast.Expr)
   

# Generated at 2022-06-12 04:37:51.510687
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 5
    # Declare snippet
    @snippet
    def get_x_plus_one():
        # Declare variable
        let(x)
        # Modify the variable
        x += 1

    # Check that snippet ends up with code x += 1
    assert get_x_plus_one.get_body() == [ast.parse('x += 1').body[0]]



# Generated at 2022-06-12 04:38:00.509999
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(a: int, b: int) -> List[int]:
        let(x)
        let(y)
        x = a + b
        y = x**2
        return [x, y]


# Generated at 2022-06-12 04:38:03.659544
# Unit test for function find_variables
def test_find_variables():
    source = """
        let(x)
        let(y)
        x, y = 1, 2
    """
    tree = ast.parse(source)
    assert find_variables(tree) == ['x', 'y']

# Generated at 2022-06-12 04:38:07.880994
# Unit test for function find_variables
def test_find_variables():
    code = """
    let(set_trace)
    let(x)
    if False:
        let(y)
        print(x, y)
    let(z)
    """
    tree = ast.parse(code)
    assert find_variables(tree) == ['set_trace', 'x', 'y', 'z']

# Generated at 2022-06-12 04:38:16.847561
# Unit test for function extend_tree
def test_extend_tree():
    from .helpers import get_source
    from .tree import get_non_exp_parent_and_index, replace_at
    from .visitor import NodeVisitor
    from .typing import AST

    class MyVisitor(NodeVisitor[AST]):
        def visit_Call(self, node: AST) -> AST:
            return node

    tree = ast.parse("""let(l1)

let(l2)

l1 = 1

l2 = 2

extend(l2)
""")
    find = MyVisitor().visit(tree)
    extend_tree(tree, {'l2': find[2]})
    parent, index = get_non_exp_parent_and_index(tree, find[3])
    replace_at(index, parent, find[3].args[0])

# Generated at 2022-06-12 04:38:17.529035
# Unit test for function extend_tree

# Generated at 2022-06-12 04:38:25.612398
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo(x: int) -> int:
        let(x)
        x += 2
        return x

    snippet_foo = snippet(foo)
    result = snippet_foo.get_body()

    assert result == [
        ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   ast.BinOp(left=ast.Name(id='_py_backwards_x_0',
                                           ctx=ast.Load()),
                             op=ast.Add(),
                             right=ast.Num(n=2))),
        ast.Return(value=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()))]



# Generated at 2022-06-12 04:38:29.906041
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse('import X as Y')
    ast.dump(tree)
    replacer = VariablesReplacer({'X': 'ast3'})
    replace_tree = replacer.visit(tree)
    assert ast.dump(replace_tree) == "ImportFrom(module='ast3', names=[alias(name='Y', asname=None)], level=0)"

# Generated at 2022-06-12 04:38:40.553097
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert ast.dump(snippet(lambda: None).get_body()) == 'Expr(value=Pass())'
    assert ast.dump(snippet(lambda x: x + 1).get_body()) == dedent('''\
        Expr(value=BinOp(left=Name(id='_py_backwards_x_0', ctx=Load()),
                              op=Add(),
                              right=Constant(value=1, kind=None)))
    ''')

# Generated at 2022-06-12 04:38:49.051134
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
    extend(variables)
    y = 1
    '''
    tree = ast.parse(source)
    variables = {
        'variables': [ast.AnnAssign(ast.Name('x', ast.Store()), ast.Num(1)),
                      ast.AnnAssign(ast.Name('x', ast.Store()), ast.Num(2))]
    }
    extend_tree(tree, variables)
    res = ast.Module(body=[ast.AnnAssign(ast.Name('x', ast.Store()), ast.Num(1)),
                           ast.AnnAssign(ast.Name('x', ast.Store()), ast.Num(2)),
                           ast.AnnAssign(ast.Name('y', ast.Store()), ast.Num(1))])
    assert tree == res

# Generated at 2022-06-12 04:38:51.193657
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int) -> None:
        print(x)

    from .tree import dump
    dump(snippet(test_snippet).get_body())

# Generated at 2022-06-12 04:38:53.850300
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x']



# Generated at 2022-06-12 04:38:57.780926
# Unit test for function find_variables
def test_find_variables():
    """Test function ``find_variables``."""
    def alphabet():
        let(a)
        let(b)
        let(c)
        let(d)
        let(e)

    source = get_source(alphabet)
    tree = ast.parse(source)
    assert list(find_variables(tree)) == list('abcde')

# Generated at 2022-06-12 04:39:02.517479
# Unit test for function find_variables
def test_find_variables():
    assert set(find_variables(ast.parse("let(x)\nx += 1\ny = 1"))) == {'x'}
    assert set(find_variables(ast.parse("let(x, y)\nx += 1\ny = 1"))) == {'x', 'y'}
    assert set(find_variables(ast.parse("let(x, y)\nx += 1\ny = 1\nlet(z)\n"))) == {'x', 'y', 'z'}



# Generated at 2022-06-12 04:39:05.478704
# Unit test for function find_variables
def test_find_variables():
    A = snippet(lambda x, y, z: let(z) + x - let(y))
    assert find_variables(ast.parse(get_source(A))) == {'x', 'y', 'z'}

# Generated at 2022-06-12 04:39:09.068201
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    let(y)
    let(z)
    let(a)
    let(b)
    '''
    tree = ast.parse(source)
    assert find_variables(tree) == ['x', 'y', 'z', 'a', 'b']



# Generated at 2022-06-12 04:39:18.053796
# Unit test for function extend_tree
def test_extend_tree():
    assert str(extend_tree(ast.parse('extend(x)'), {'x': [ast.parse('a=1')]})) == 'Module(body=[Assign(targets=[Name(id=\'a\', ctx=Store())], value=Num(n=1))])'

# Generated at 2022-06-12 04:39:20.428902
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(v)
v = 1
""")
    assert list(find_variables(tree)) == ["v"]



# Generated at 2022-06-12 04:39:33.102256
# Unit test for function extend_tree
def test_extend_tree():
    import inspect
    import sys

    from .utils import get_source

    def get_parent(node, level=1):
        for _ in range(level):
            node = node.parent

        return node

    for name, obj in inspect.getmembers(sys.modules[__name__]):
        if inspect.isfunction(obj):
            print(get_source(obj))
            print(obj.__module__)
            tree = ast.parse(get_source(obj))
            # vars = {
            #     'get_non_exp_parent_and_index': 'get_non_exp_parent_and_index'
            # }
            # extend_tree(tree, vars, False)
            # print(ast.dump(tree))

# Generated at 2022-06-12 04:39:38.714908
# Unit test for function find_variables
def test_find_variables():
    code = '''
    def fn(x):
        let(a)
        a += 1
        let(b)
        extend(c)
        for var in c:
            pass
        return a + b + fn2(let(y)) - let(z) + x
    '''
    tree = ast.parse(code)
    variables = find_variables(find(tree, ast.FunctionDef)[0])
    assert variables == set(['a', 'b', 'c', 'y', 'z'])

# Generated at 2022-06-12 04:39:47.483849
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # GIVEN
    @snippet
    def snippet(a: int, b: int) -> int:
        let(x)
        let(y)
        let(z)
        return x + y

    # WHEN
    ast = snippet.get_body(x=ast.Num(4), z=6)

    # THEN

# Generated at 2022-06-12 04:39:51.467339
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''extend(a)
    print(1)''')
    variables = {'a': ast.parse('x = 1;x = 2')}
    extend_tree(tree, variables)
    assert get_source(tree) == 'x = 1\nx = 2\nprint(1)\n'

# Generated at 2022-06-12 04:40:00.991573
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2

    @snippet
    def test_snippet():
        let(x)
        x += 1
        y = 1
        
        extend(vars)
        
        print(x, y)

    vars = [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=1))]
    body = test_snippet.get_body(x=5, vars=vars)


# Generated at 2022-06-12 04:40:03.809268
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    res = snippet(lambda x: x + 1).get_body(x=7)
    for i in res:
        if isinstance(i, ast.Return):
            assert i.value.value == 8
            break

# Generated at 2022-06-12 04:40:12.780500
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    fn = ast.parse("""
    import re
    import requests
    
    let(url)
    let(regex)
    let(regex_compiled)
    let(headers)
    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
    let(html)
    html = requests.get(url, headers=headers).text
    regex_compiled = re.compile(regex)
    let(response)
    response = regex_compiled.search(html).group()
    """)
    var = ast.Name(id='regex', ctx=ast.Load())

# Generated at 2022-06-12 04:40:23.057188
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2

    @snippet
    def test_snippet():
        let(x)
        let(y)
        x += 1
        y += 1


# Generated at 2022-06-12 04:40:31.794224
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = """let(x)
    arg = ast.parse(x).body[0].value.left
    """
    tree = ast.parse(source)
    variables = {'x': 'x = 1'}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    body = ast.Body(tree.body[0].body, lineno=1, col_offset=0)

# Generated at 2022-06-12 04:40:42.060550
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import astunparse

    # Some simple examples
    @snippet
    def simple_example1(x: int) -> None:
        let(x)
        x += 2

    assert astunparse.unparse(simple_example1.get_body(x=1)) == "  _py_backwards_x_0 += 2\n"

    @snippet
    def simple_example2(x: int) -> None:
        let(x)
        y = x
        x += 2

    assert astunparse.unparse(simple_example2.get_body(x=1)) == \
           "  y = _py_backwards_x_0\n  _py_backwards_x_0 += 2\n"

    # Some nested examples

# Generated at 2022-06-12 04:40:58.300291
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x):
        let(x)
        let(y)
        z = 3
        return x, z

    tree = ast.parse(get_source(fn))
    variables = {'x': '_py_backwards_x_0', 'y': '_py_backwards_y_0'}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    expected = """
        def fn(_py_backwards_x_0):
            _py_backwards_y_0 = None
            z = 3
            return _py_backwards_x_0, z
    """  # noqa: E501

    assert expected == get_source(tree)

# Generated at 2022-06-12 04:41:04.421753
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def _test_snippet_get_body() -> None:
        let(x)
        x += 1
        y = 1

    body = _test_snippet_get_body.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)
    assert body[0].target.id == '_py_backwards_x_0'
    assert isinstance(body[1].value, ast.Num)

# Generated at 2022-06-12 04:41:10.034217
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def create_snippet() -> ast.AST:
        let(x)
        x += 1

    s = snippet(create_snippet)
    body = s.get_body()

    assert isinstance(body, list)
    assert len(body) == 1
    assert isinstance(body[0], ast.Assign)
    assert body[0].targets[0].id == 'x'

    body = s.get_body(x='a')
    assert body[0].targets[0].id == 'a'



# Generated at 2022-06-12 04:41:16.005085
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast

    class Add(ast.NodeTransformer):
        def __init__(self):
            self.local_var = 0

        def visit_Name(self, node):
            if isinstance(node.ctx, ast.Store):
                node.id = "ast_local_var_%d" % self.local_var
                self.local_var += 1
            return node

    def snippet_get_body_fn(a, b, c):
        let(c)
        x = a + b
        y = c + b

    s = snippet(snippet_get_body_fn)
    body = s.get_body(c = ast.Name(id = "_py_backwards_c_0", ctx = ast.Store()))
    tree = ast.Module(body = body)
    Add().visit

# Generated at 2022-06-12 04:41:24.354839
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    class obj:
        def __init__(self, deep, tree, source):
            self.deep = deep
            self.tree = tree
            self.source = source

        def __eq__(self, other):
            if not isinstance(other, obj):
                return False
            if self.deep != other.deep:
                return False
            if self.tree != other.tree:
                return False
            if self.source != other.source:
                return False
            return True

    def check(node: ast.AST, deep: int) -> obj:
        if isinstance(node, ast.FunctionDef):
            tree = [check(n, deep + 1) for n in node.body]
            source = ast.dump(node)
            return obj(deep, tree, source)

# Generated at 2022-06-12 04:41:29.474625
# Unit test for function extend_tree
def test_extend_tree():
    original_tree = ast.parse('''
let(vars)
if True:
    x = 1''')
    tree = deepcopy(original_tree)
    extend_tree(tree, {'vars': [ast.parse("def foo(): pass").body[0],
                                ast.parse("def bar(): pass").body[0]]})

# Generated at 2022-06-12 04:41:38.195218
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def add_one(var):
        let(var)
        var += 1

    @snippet
    def extend_vars(vars):
        extend(vars)

    tree1 = add_one.get_body(var=['x', 'y'])

# Generated at 2022-06-12 04:41:45.939290
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import get_assign_values
    from inspect import signature
    def foo(a: int, b: int = 10, **kwargs) -> int:
        let(ret)
        ret = a + b
        extend(kwargs)
        return ret

    body = snippet(foo).get_body(a=1, b=2, c=3, d=4)
    assert len(body) == 2  # extend replaces list of Assigns by its elements
    assert get_assign_values(body) == {'ret': 3, 'c': 3, 'd': 4}
    # check function signature
    assert signature(foo) == signature(snippet(foo))

# Generated at 2022-06-12 04:41:53.398278
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_example = snippet(lambda x, y: x + y)
    snippet_example_code = [ast.Assign([
        ast.Name(id='x', ctx=ast.Store())],
        ast.BinOp(
            ast.Name(id='x', ctx=ast.Load()),
            ast.Add(),
            ast.Name(id='y', ctx=ast.Load()))), ast.Return(ast.Name(id='x', ctx=ast.Load()))]
    assert snippet_example.get_body(x=1, y=2) == snippet_example_code



# Generated at 2022-06-12 04:41:56.744906
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def func():
        """ print(x)
            x = 1
        """

    tree = ast.parse("""
        print(x)
        x = 1
    """)

    assert func.get_body() == tree.body

# Generated at 2022-06-12 04:42:15.366833
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def foo(x, y):
        let(z)
        extend(a)
        print(x, y, z, a)
    a = let(a)
    b = let(b)
    source = [ast.Assign(
                [ast.Name(id='a', ctx=ast.Store())],
                ast.Num(n=1)),
              ast.Assign(
                [ast.Name(id='b', ctx=ast.Store())],
                ast.Num(n=2))]
    source = ast.Module(body=source)
    source = foo.get_body(x=1, y=2, z=3, a=source)

# Generated at 2022-06-12 04:42:21.005691
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .test_helpers import assert_equal_ast

    snippet_exp_ast = ast.parse("""
        print(a)
        print(b)
    """)

    def my_snippet(a: ast.AST, b: ast.AST):
        extend(locals())
        let(a)
        let(b)

    ast_ = my_snippet.get_body(a=ast.parse("a = 1"), b=ast.parse("b = 2"))
    assert_equal_ast(snippet_exp_ast, ast.Module(body=ast_))

# Generated at 2022-06-12 04:42:28.713391
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def example_snippet():
        let(foo)

        if bar:
            bar()

    snippet_instance = snippet(example_snippet)

    assert get_source(snippet_instance.get_body(foo=1, bar=2)) == get_source(example_snippet)  # noqa

    assert get_source(snippet_instance.get_body(foo=1, bar=ast.Name('b'))) == '\n'.join(  # noqa
        ['if b:', '    b()'])  # noqa

    def example_snippet2():
        let(foo)

        if foo:
            print(foo)

    snippet_instance = snippet(example_snippet2)


# Generated at 2022-06-12 04:42:37.092692
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    MULTI_BODY = [
        ast.Expr(ast.Call(ast.Name('let', ast.Load()), [ast.Str('x')], []), None),
        ast.Expr(ast.Call(ast.Name('let', ast.Load()), [ast.Str('y')], []), None),
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name('y', ast.Store())], ast.Num(2))
    ]

    ONE_BODY = ast.Body(MULTI_BODY)

    SINGLE_BODY = ast.Expr(ast.Call(ast.Name('let', ast.Load()), [ast.Str('x')], []), None)


# Generated at 2022-06-12 04:42:45.361601
# Unit test for function extend_tree
def test_extend_tree():
    # Test case:
    # extend(vars)
    # print(x, y)
    # test should transform in:
    # x = 1
    # y = 2
    # print(x, y)
    tree = ast.parse("""\
extend(vars)
print(x, y)""")
    variables = {'vars': [ast.copy_location(ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                       value=ast.Num(1)),
                                            tree),
                          ast.copy_location(ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                                                       value=ast.Num(2)),
                                            tree)]}
    extend_tree(tree, variables)

# Generated at 2022-06-12 04:42:54.048108
# Unit test for function extend_tree
def test_extend_tree():
    tree: ast.AST = ast.parse('''def foo():
        extend(vars)
        print("hello world")''')

    variables: Dict[str, Variable] = {
        'vars': [ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Constant(value=1)),
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Constant(value=2))
        ]
    }

    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, {})

    assert get_source(tree) == '''def foo():
    x = 1
    x = 2
    print("hello world")'''

# Generated at 2022-06-12 04:43:00.645954
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_with_let():
        let(x)
        x += 1
        y = 1

    body = snippet(snippet_with_let).get_body()
    assert body == [ast.AugAssign(
                        target=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                        op=ast.Add(),
                        value=ast.Num(n=1)),
                    ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                               value=ast.Num(n=1))]

# Generated at 2022-06-12 04:43:04.006529
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    body = snippet(lambda x: let(x)).get_body(x=1)
    expected_body = ast.parse('''
y = _py_backwards_x_0
''').body
    assert body == expected_body


# Generated at 2022-06-12 04:43:05.956551
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = snippet(lambda x: x)
    assert a.get_body() is not []
    assert a.get_body() == a.get_body()

# Generated at 2022-06-12 04:43:11.758217
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = ast.Name(id='x', ctx=ast.Load())
    y = ast.Name(id='y', ctx=ast.Load())
    add = ast.Add()
    binop = ast.BinOp(left=x, op=add, right=y)
    assign = ast.Assign(targets=[x], value=binop)
    mod = ast.Module(body=[assign])
    assert snippet(lambda x: x + y).get_body()[0] == mod.body[0]

# Generated at 2022-06-12 04:43:37.761582
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func():
        let(1)
        let(2)

    source = get_source(func)
    tree = ast.parse(source)
    variables = find_variables(tree)
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    nodes = [tree.body[0].body[0].value, tree.body[0].body[1].value]
    assert [node.value.n for node in nodes] == ['_py_backwards_1_0', '_py_backwards_2_0']

# Generated at 2022-06-12 04:43:40.708273
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f1(x: int) -> ast.AST:
        let(x)
        return x + 1

    assert snippet(f1).get_body(x=1) == [ast.parse(
        '_py_backwards_x_0 = 1 + 1').body[0]]



# Generated at 2022-06-12 04:43:46.574445
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func():
        let(x)
        let(a)
        print(a)

    a = ast.Name('a', ast.Load())

    tree = snippet(func).get_body(x=0, a=a)

    assert len(tree) == 1
    assert isinstance(tree[0], ast.Expr)
    assert isinstance(tree[0].value, ast.Name)
    assert tree[0].value.id == 'a'



# Generated at 2022-06-12 04:43:48.060105
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import inspect
    snippet = snippet(inspect.currentframe().f_code)
    assert snippet.get_body() == []

# Generated at 2022-06-12 04:43:55.920797
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import inspect
    import astor
    import sys

    a = 1
    b = 2
    c = 3

    @snippet
    def test(x):
        let(a)
        let(b)
        let(c)
        a += 1
        b += 2
        c += 3
        print(a, b, c)

    def test_fn(x):
        a += 1
        b += 2
        c += 3
        print(a, b, c)

    body = test.get_body()

    code = astor.to_source(body)
    frame = inspect.stack()[1]
    module = inspect.getmodule(frame[0])
    exec(code, module.__dict__)

    test_fn(2)

# Generated at 2022-06-12 04:43:59.702295
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        let(y)
        let(z)
        x += 2
        y += 1
    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body(x=1, z=1)
    assert len(body) == 2

# Generated at 2022-06-12 04:44:01.729378
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: x + 1).get_body(x=1) == ast.parse('x = x + 1').body

# Generated at 2022-06-12 04:44:07.228232
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def _():
        let(x)
        x += 1

    assert _.get_body() == [ast.Assign(
        [ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
        ast.BinOp(
            ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
            ast.Add(), ast.Num(n=1)))]

# Generated at 2022-06-12 04:44:15.121674
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Test snippet get_body method."""

    @snippet
    def f(x: int) -> None:
        let(x)
        x += 1
        y = 1
        for i in range(2):
            extend(vars_body)

        if True:
            extend(vars_body)

    vars_body = [ast.Assign(
                    targets=[ast.Name(id='v1', ctx=ast.Load())],
                    value=ast.Num(n=1)),
                ast.Assign(
                    targets=[ast.Name(id='v2', ctx=ast.Load())],
                    value=ast.Num(n=2))]

    body = f.get_body(vars_body=vars_body)
    assert len(body) == 4


# Generated at 2022-06-12 04:44:24.203268
# Unit test for function extend_tree
def test_extend_tree():
    source = """
        vars = \
        {
            x: 1
        }
        extend(vars)
        print(x)
    """
    tree = ast.parse(source)
    extend_tree(tree, {'vars': [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1))]})
    assert ast.dump(tree) == """Module(body=[Assign(targets=[Name(id='vars', ctx=Store())], value={x: 1}), Assign(targets=[Name(id='x', ctx=Store())], value=1), Print(dest=None, values=[Name(id='x', ctx=Load())], nl=True)])"""

# Generated at 2022-06-12 04:45:15.255371
# Unit test for function find_variables
def test_find_variables():
    # valid case:
    source = """
    x = 1
    let(x)
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert list(variables) == ['x']
    assert tree.body == [
        ast.Assign(
            [ast.Name(id='x', ctx=ast.Store())],
            ast.Num(n=1),
        )
    ]

    # invalid case:
    source = """
    x = 1
    let()
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert list(variables) == []

# Generated at 2022-06-12 04:45:19.375784
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import astpretty

    def test_function(a: int, b: int) -> int:
        c = a + b
        let(d)
        d += 1
        return let(c)
    s = snippet(test_function)
    tree = s.get_body(d=5)
    print(astpretty.pformat(tree))



# Generated at 2022-06-12 04:45:27.617414
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    def f(a, b, c):
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    actual = snippet(f).get_body(vars=['y = 1', 'vars = 1', 'let = 2'],
                                 x=ast.Name(id='y', ctx=ast.Load()))


# Generated at 2022-06-12 04:45:36.662482
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test1(x, y, z):
        let(x)
        let(y)
        return x + 1, y + 2, z

    @snippet
    def test2(x, y):
        extend(x)
        return x + 1, y

    # assert test1.get_body(x=1, y=2, z=3) == ast.parse(
    #     '_py_backwards_x_0 = 1\n'
    #     '_py_backwards_y_1 = 2\n'
    #     'return _py_backwards_x_0 + 1, _py_backwards_y_1 + 2, z\n').body

# Generated at 2022-06-12 04:45:45.282087
# Unit test for function extend_tree
def test_extend_tree():
    # Sample snippet and var name
    @snippet
    def snippet1(test):
        let(test)
        extend(test)
    name = 'a'

    # A test function with a decorator
    @snippet1(test=name)
    def sample_function():
        a = 1
        a = 2
        return a

    # Get source from function body
    source = inspect.getsource(sample_function)
    assert source.count('a') == 2
    assert source == 'a = 1\na = 2\nreturn a\n'

# Generated at 2022-06-12 04:45:47.782368
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import dump

    def body():
        let(x)
        x += 1
        y = 2
        y += 1
        extend(z)

    dump(snippet(body).get_body(z=["x", "y"]))

# Generated at 2022-06-12 04:45:50.625408
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var = ast.Name('x')
    x = 2
    s = snippet(lambda: let(x) + 'x += 1' + extend(var))

    assert len(s.get_body(x=var, y=1)) == 2

# Generated at 2022-06-12 04:45:54.158467
# Unit test for function find_variables
def test_find_variables():
    code = '''
    let(x)
    let(y)
    let(z)
    x, y, z = 1
    '''
    tree = ast.parse(code)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-12 04:46:03.210495
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import unittest
    from unittest.mock import MagicMock, Mock

    class TestSnippet(unittest.TestCase):
        def test_snippet_get_body(self):
            def _fn(x: int) -> None:
                let(x)
                y = x + 1
                print(x, y)

            source = get_source(_fn)
            tree = ast.parse(source)
            variables = find_variables(tree)
            variables.update({'x': '_py_backwards_x_0'})
            VariablesReplacer.replace(tree, variables)
            expected_body = ast.parse('_py_backwards_x_0 += 1; print(_py_backwards_x_0, _py_backwards_x_0 + 1)\n').body
           

# Generated at 2022-06-12 04:46:10.831455
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import test
    from .ast_builders import let, extend

    @snippet
    def f(x: int, y: int, z: int) -> None:
        let(a)
        let(b)
        b += 2
        a += 3
        extend(w)
        w = a + b + x + y + z
        print(w)
