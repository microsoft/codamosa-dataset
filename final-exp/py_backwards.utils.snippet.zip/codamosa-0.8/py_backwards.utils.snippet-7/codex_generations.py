

# Generated at 2022-06-12 04:36:39.879491
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    py_test = snippet(test_snippet_get_body)
    body = py_test.get_body()
    assert len(body) == 1
    assert isinstance(body[0], ast.Assign)


# Generated at 2022-06-12 04:36:40.388522
# Unit test for function extend_tree

# Generated at 2022-06-12 04:36:43.031571
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(x);')
    extend_tree(tree, {'x': ast.parse('x; y;').body})
    assert get_source(tree) == 'x; y;'

# Generated at 2022-06-12 04:36:45.880039
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""let(x)
let(hello)
x += 1
foo(x, hello)
bar()
""")
    vars = {var for var in find_variables(tree)}
    assert vars == {'x', 'hello'}



# Generated at 2022-06-12 04:36:55.344240
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)')
    vars_list = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                            value=ast.Num(n=1)),
                 ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                            value=ast.Num(n=2))]
    vars = {'vars': vars_list}
    extend_tree(tree, vars)

# Generated at 2022-06-12 04:37:05.268442
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def my_snippet(x, y):
        let(x)
        x += 1
        y = 1

    s = snippet(my_snippet)
    body = s.get_body()

    import inspect
    assert inspect.getsource(snippet.__init__) == inspect.getsource(snippet)
    act = ast.dump(body[0])
    exp = ast.dump(ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())], value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()), op=ast.Add(), right=ast.Num(n=1))))
    assert act == exp


# Generated at 2022-06-12 04:37:15.270679
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(a, b):
        let(c)
        return a + b + c


# Generated at 2022-06-12 04:37:18.485468
# Unit test for function find_variables
def test_find_variables():
    source = '''
let(a)
let(b)
let(c)
'''
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'a', 'b', 'c'}



# Generated at 2022-06-12 04:37:21.705951
# Unit test for function find_variables
def test_find_variables():
    source = """
    def fn():
        let(x)
        let(y)
        print(x, y)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-12 04:37:30.906497
# Unit test for function extend_tree
def test_extend_tree():
    source = "extend(vars)\nx=1"
    tree = ast.parse(source)
    vars = [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=1)), ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2))])"

test_extend_tree()

# Generated at 2022-06-12 04:37:48.736916
# Unit test for function extend_tree
def test_extend_tree():
    source = textwrap.dedent(
        """
            extend(vars)
            print(x, y)
        """)

    tree = ast.parse(source)
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                           value=ast.Num(n=1)),
                               ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                          value=ast.Num(n=2))]})


# Generated at 2022-06-12 04:37:54.056594
# Unit test for function extend_tree
def test_extend_tree():
    original_tree = ast.parse('y = y + x')
    variables = {
        'vars': [
            ast.Assign([ast.Name(
                id='y', ctx=ast.Store())], ast.Num(n=9)),
            ast.Assign([ast.Name(
                id='y', ctx=ast.Store())], ast.Name(id='y'))
        ]
    }
    extend_tree(original_tree, variables)
    assert ast.dump(original_tree) == ast.dump(ast.parse('y = y; y = y + x'))



# Generated at 2022-06-12 04:37:54.895739
# Unit test for function extend_tree

# Generated at 2022-06-12 04:38:04.409948
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def my_snippet(x1: int, x2: int=1) -> int:
        let(x2)
        x2 += 1
        y = 1
        return x1 + x2 + y

    assert my_snippet.get_body()[0].target.id == '_py_backwards_x2_0'
    assert my_snippet.get_body(x1=1)[0].value.n == 1
    assert my_snippet.get_body(x1=1)[-1].value.n == 3
    assert my_snippet.get_body(x1=1, x2=2)[0].target.id == '_py_backwards_x2_1'

# Generated at 2022-06-12 04:38:13.104206
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_kwargs = {}
    let_variables_names = []

    @snippet
    def _(x: 'int', y: 'int'):
        let(x)
        x += 1
        y = 1

        let(x)
        x += 2
        y = 3

        extend(snippet_kwargs)
        print(x, y)

    for name in find_variables(_.get_body()):
        let_variables_names.append(name)
    assert let_variables_names == ['x', 'x']

    _.get_body(x=1, y=1)
    assert snippet_kwargs == {'x': 1}

# Generated at 2022-06-12 04:38:19.341052
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    tree = ast.parse('''let(x)
    x += 1
    print(x)''')
    tree.body.append(ast.Pass())
    tree2 = ast.parse('''let(y)
    y += 1''')
    variables = {'x': tree2, 'y': '_py_backwards_temp_0'}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert isinstance(tree.body[0].body[0], ast.Assign)
    assert isinstance(tree.body[0].body[0].value, ast.AugAssign)
    assert isinstance(tree.body[0].body[0].value.value, ast.Name)

# Generated at 2022-06-12 04:38:28.230238
# Unit test for function extend_tree
def test_extend_tree():
    source = """
vars = [Assign(targets=[Name(id='x', ctx=Store())],
               value=Num(n=1, type=None, lineno=2, col_offset=8)),
        Assign(targets=[Name(id='x', ctx=Store())],
               value=Num(n=2, type=None, lineno=3, col_offset=8))]
extend(vars)
print(x)
"""

    expected_source = """
x = 1
x = 2
print(x)
""".strip()

    tree = ast.parse(source)
    extend_tree(tree, {})
    assert get_source(tree).strip() == expected_source


# Generated at 2022-06-12 04:38:35.242152
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def my_snippet(x):
        let(x)
        y = 1
        x += 2

    tree = snippet(my_snippet).get_body(x=1)
    assert tree == [
        ast.Assign(
            targets=[ast.Name("_py_backwards_x_0", ast.Store())],
            value=ast.BinOp(
                left=ast.Name("_py_backwards_x_0", ast.Load()),
                op=ast.Add(),
                right=ast.Num(2),
            ),
        ),
        ast.Assign(
            targets=[ast.Name("y", ast.Store())],
            value=ast.Num(1),
        ),
    ]

# Generated at 2022-06-12 04:38:38.873769
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    let(1)
    x = 2
    x += 1
    print(x)

    snippet_body = snippet(test_snippet_get_body).get_body()

    assert snippet_body == ast.parse('x = 2\nx += 1\nprint(x)').body



# Generated at 2022-06-12 04:38:47.047380
# Unit test for function extend_tree
def test_extend_tree():
    @snippet
    def tree():
        let(x)
        extend(body)
        return x

    class Assign(ast.AST):
        _fields = ['targets', 'value']

        def __init__(self, targets, value):
            self.targets = targets
            self.value = value
    body1 = Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(1))
    body2 = Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(2))
    a = tree(x=1, body=[body1, body2])
    assert a == 1
    b = tree(x=2, body=[body1, body2])
    assert b == 2



# Generated at 2022-06-12 04:38:59.767840
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snip = snippet(lambda x, y, z: x + y)

    assert snip.get_body(x=1, y=2) == \
        [ast.Assign([ast.Name('_py_backwards_z_0', ast.Store())], ast.BinOp(ast.Num(1), ast.Add(), ast.Num(2)))]

    assert snip.get_body(x=1, y=2, z=3) == \
        [ast.Assign([ast.Name('_py_backwards_z_1', ast.Store())], ast.Num(3))]

# Generated at 2022-06-12 04:39:06.981706
# Unit test for function extend_tree
def test_extend_tree():
    string = """
    def test():
        a = 1
        a = 2
        extend(vars)
        print(a, b)
    """
    tree = ast.parse(string)
    vars = {'vars': [ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())],
                                value=ast.Num(n=1))]}
    extend_tree(tree, vars)
    expected = ast.parse("""
    def test():
        a = 1
        a = 2
        b = 1
        print(a, b)
    """)
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-12 04:39:13.160440
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def function():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(function)
    body = snippet_.get_body(x=['x', 'y'])
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[0].value, ast.List)
    assert body[0].value.elts[0].s == 'x'
    assert body[0].value.elts[1].s == 'y'



# Generated at 2022-06-12 04:39:22.036900
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # flag checking whether function is called
    called = False

    # function definition
    @snippet
    def t_function(value):
        let(value)
        called = True

    assert(t_function.get_body() == [
        ast.Assign([ast.Name('_py_backwards_value_0', ast.Store())],
                   ast.Name('_py_backwards_value_0', ast.Load())),
        ast.Assign([ast.Name('called', ast.Store())], ast.NameConstant(True))
    ])

    # function call
    @snippet
    def t_call():
        let(t_function(1))
        called = True


# Generated at 2022-06-12 04:39:30.846584
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    z = 3

    def snippet_fn(a: int, b: int) -> List[int]:
        let(x)
        let(y)
        let(z)
        extend([x, y, z])
        return [1, 2, 3]

    snippet_obj = snippet(snippet_fn).get_body(x=x, y=_py_backwards_y_0, z=z)

# Generated at 2022-06-12 04:39:35.560290
# Unit test for function find_variables
def test_find_variables():
    source = """
            def foo():
                let(x)
                let(y)
                x = 1
                y = 2
                print(x, y)
    """
    names = find_variables(ast.parse(source))
    assert next(names) == 'x'
    assert next(names) == 'y'
    with pytest.raises(StopIteration):
        next(names)



# Generated at 2022-06-12 04:39:41.381559
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int) -> None:
        let(y)
        print(x, y)

    print(test_snippet.get_body(x=1))

    def test_snippet(x: int) -> None:
        let(y)
        print(x, y)

    print(test_snippet.get_body(x=1))


if __name__ == '__main__':
    test_snippet_get_body()

# Generated at 2022-06-12 04:39:50.368807
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Test snippet.get_body method."""

    @snippet
    def s():
        let(x)
        let(y)
        z = x + y
        return z

    def check(expected, got):
        if not got == expected:
            raise Exception(
                "Expected value to be '%s' but it is '%s'" % (expected, got))

    for i, node in enumerate(s.get_body()):
        body = ast.Module([node]).body[0]
        check(s._get_variables(body, {}), VariablesGenerator.convert_to_dict(node))
        check('x_%s' % i, node.id)
        check(1, len(node.targets))

# Generated at 2022-06-12 04:39:58.998096
# Unit test for function find_variables
def test_find_variables():
    """
    Tests the following snippet:
    
    let(x)
    x = 10
    y = let(y)
    y = 20
    z = let(z)
    z = 30
    
    Should end up like:
    
    _py_backwards_x_0 = 10
    _py_backwards_y_1 = 20
    _py_backwards_z_2 = 30
    """

    def snippet():
        let(x)
        x = 10
        y = let(y)
        y = 20
        z = let(z)
        z = 30
    root = snippet.__code__
    assert set(find_variables(root)) == {'x', 'y', 'z'}

# Generated at 2022-06-12 04:40:05.639934
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def foo(x):
        let(y)
        y += 42

    body = foo(2).get_body()
    expected = [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_y_0', ctx=ast.Store())],
            value=ast.BinOp(left=ast.Name(id='_py_backwards_y_0', ctx=ast.Load()),
                            op=ast.Add(),
                            right=ast.Num(n=42))
        )
    ]
    assert body == expected

# Generated at 2022-06-12 04:40:19.084254
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test of let(x) x += 1
    @snippet
    def plus_one():
        let(x)
        x += 1
    plus_one_tree = ast.parse("x = 0; x += 1;").body[0]
    assert plus_one.get_body() == plus_one_tree.body

    # Test of let(x) y = 1
    @snippet
    def y_assignment():
        let(x)
        y = 1
    y_assignment_tree = ast.parse("y = 1;").body[0]
    assert y_assignment.get_body() == y_assignment_tree.body

    # Test of let(x) y = 1; extend(vars)
    @snippet
    def vars_extend():
        let(x)


# Generated at 2022-06-12 04:40:26.276588
# Unit test for method get_body of class snippet
def test_snippet_get_body():  # pragma: no cover
    @snippet
    def test(x: int, y: int) -> None:
        let(x)
        x *= 2
        y = 1

    tree = test.get_body(x=2, y=3)
    print(ast.dump(tree))

    @snippet
    def test2(x: int) -> None:
        let(x)
        extend(x)

    extend_x = ast.Expr(value=ast.Call(
        func=ast.Name(id='print', ctx=ast.Load()),
        args=[ast.Num(n=2)],
        keywords=[],
    ))
    tree = test2.get_body(x=ast.Module(body=[extend_x]))
    print(ast.dump(tree))

# Generated at 2022-06-12 04:40:36.063310
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var1 = ast.Name(id='_py_backwards_var1_0', ctx=ast.Load())
    var2 = ast.Name(id='_py_backwards_var2_0', ctx=ast.Load())
    var3 = ast.Name(id='_py_backwards_var3_0', ctx=ast.Load())

    @snippet
    def body():
        let(var1)
        var1 += 1
        var2 = 1
        extend(var3)
        print(var2)

    var3_assign_1 = ast.Assign(targets=[ast.Name(id='var3', ctx=ast.Store())],
                               value=ast.Num(n=1))

# Generated at 2022-06-12 04:40:44.421113
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        let(y)
        a = 0
        b = 0
        extend(vars)
        print(x, y, a, b)

    snippet_vars = {
        'x': '1',
        'y': '2',
        'a': '3',
        'b': '4',
        'vars': [ast.Assign([ast.Name(id='a', ctx=ast.Store())], ast.Num(n=5)),
                 ast.Assign([ast.Name(id='b', ctx=ast.Store())], ast.Num(n=6))]
    }


# Generated at 2022-06-12 04:40:48.553562
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import get_single_ast, get_source
    from .tests.snippets import simple_snippet
    
    ast_body = get_single_ast(snippet(simple_snippet).get_body())
    source = get_source(simple_snippet)
    
    assert ast_body == get_single_ast(source)

# Generated at 2022-06-12 04:40:56.746908
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Test get_body method from class snippet"""
    from .snippets.fibonacci_numbers_head import fibonacci_numbers_head
    from .snippets.fibonacci_numbers_tail import fibonacci_numbers_tail

    body_fibonacci_numbers_head = fibonacci_numbers_head.get_body()
    body_fibonacci_numbers_tail = fibonacci_numbers_tail.get_body()

    assert len(body_fibonacci_numbers_head) == 4
    assert len(body_fibonacci_numbers_tail) == 4
    assert body_fibonacci_numbers_head[0].value.id == '_py_backwards_result_0'
    assert body_fibonacci_numbers

# Generated at 2022-06-12 04:41:04.930567
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snip(x: int) -> int:
        let(y)
        y += 1
        return y + x

    snippet_inst = snippet(snip)
    node = snippet_inst.get_body(x=5)
    assert isinstance(node, list)
    func_body = ast.Module(body=node)
    func_body.filename = '<string>'
    assert ast.dump(func_body) == dedent('''\
    Module(body=[Assign(targets=[Name(id='_py_backwards_y_0', ctx=Store())], value=BinOp(left=Name(id='_py_backwards_y_0', ctx=Load()), op=Add(), right=Num(n=1)))])
    ''')



# Generated at 2022-06-12 04:41:12.301770
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 1
    b = 2
    x = 3
    assert snippet(lambda x, y, z: None).get_body(
        x=a,
        y=b,
        z=x,
    ) == [ast.Assign(
        targets=[ast.Name(id=x, ctx=ast.Store())],
        value=ast.Num(n=a)),
        ast.Assign(
            targets=[ast.Name(id=y, ctx=ast.Store())],
            value=ast.Num(n=b)),
        ast.Assign(
            targets=[ast.Name(id=z, ctx=ast.Store())],
            value=ast.Name(id='x', ctx=ast.Load()))]

# Generated at 2022-06-12 04:41:20.119785
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet1 = snippet(lambda x, y: let(x))
    snippet2 = snippet(lambda x, y: let(x) + let(y))
    snippet3 = snippet(lambda x: let(x) + let(x) + let(x))
    snippet4 = snippet(lambda a, b, c: let(a) + let(b) + let(a) + let(c))
    snippet5 = snippet(lambda a, x, y: let(a) + let(x) + let(a) + let(y))
    snippet6 = snippet(lambda x, y: let(x) + let(y) + let(x))

    tree = snippet1.get_body()
    assert str(tree) == '[_py_backwards_x_0]'
    tree = snippet2.get_body()

# Generated at 2022-06-12 04:41:28.615220
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class A:
        """Class for unit testing of class snippet"""
        def __init__(self, a: int, b: int) -> None:
            self.a = a
            self.b = b

        @snippet
        def f(self, x: int, y: int) -> None:
            """Function for unit testing of class snippet"""
            let(a)
            let(b)
            self._b = b + 2
            y += a + b + x

        def g(self) -> Any:
            """Function for unit testing of class snippet"""
            let(c)
            let(x)
            return self.f(c, c)

        @classmethod
        def h(cls) -> Any:
            """Class method for unit testing of class snippet"""
            let(x)

# Generated at 2022-06-12 04:41:33.872305
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test() -> None:
        let(x)
        x += 1
        y = 1
    snippet(_test).get_body()



# Generated at 2022-06-12 04:41:40.698073
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        x += 1
        y = 1

    assert snippet(f).get_body() == [
        ast.AugAssign(
            target=ast.Name(
                id='_py_backwards_x_0',
                ctx=ast.Load()),
            op=ast.Add(),
            value=ast.Num(n=1)),
        ast.Assign(
            targets=[
                ast.Name(
                    id='y',
                    ctx=ast.Store())
            ],
            value=ast.Num(n=1))
    ]

# Generated at 2022-06-12 04:41:45.328971
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def my_snippet(x: int, y: str = 'x') -> None:
        let(x)
        x += 1
        extend(y)

    snippet_obj = snippet(my_snippet)
    source_code = snippet_obj.get_body()
    assert get_source(source_code) == "x += 1\nx\n"


# Generated at 2022-06-12 04:41:54.850353
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """collected tests for method get_body of class snippet"""
    import pytest
    import inspect

    def test_snippet_get_body_1():
        """test snippet with one variable"""
        import ast
        import astor

        @snippet
        def snippet1(a):
            let(a)
            a += 1

        ast_body = snippet1.get_body(a=1)
        assert astor.to_source(ast_body) == '[_py_backwards_a_0 += 1]'

    def test_snippet_get_body_2():
        """test snippet with two variable"""
        import ast
        import astor

        @snippet
        def snippet2(a, b):
            let(a)
            a += 1
            b = 2
            let(b)
           

# Generated at 2022-06-12 04:42:02.305191
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(x, y):
        let(x)
        x += y
        return y

    assert (fn.get_body(x=ast.Name(id='x'), y=ast.Name(id='y'))) == [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='x', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Name(id='y', ctx=ast.Load())
            )
        ),
        ast.Return(value=ast.Name(id='y', ctx=ast.Load()))
    ]

# Generated at 2022-06-12 04:42:08.100225
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def some_snippet(a: int, b: int) -> None:
        let(x)
        x = a
        y = b
        x = x + y
        print(x)

    body = some_snippet.get_body(a=1, b=2)
    expected_result = ast.parse('_py_backwards_x_0 = 1; y = 2; _py_backwards_x_0 = _py_backwards_x_0 + y; print(_py_backwards_x_0)')
    assert body == expected_result.body

# Generated at 2022-06-12 04:42:16.149486
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def two_plus(a, b: ast.Name):
        # type: (int, int) -> int
        let(c)
        c = 2 + a
        return c + b  # type: ignore


# Generated at 2022-06-12 04:42:24.476336
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    z = 4
    @snippet
    def foo():
        let(x)
        y = 2
        extend(z)
        print(x, y, z)
    body = foo.get_body()

# Generated at 2022-06-12 04:42:30.732319
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x, y):
        let(x)
        x += 1
        y = 1

    assert test.get_body(x=1, y=1) == [
        ast.Assign(
            targets=[ast.Name(id='__py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='__py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-12 04:42:37.483829
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo(x: int) -> None:
        let(x)
        let(y)
        print(x, y)

    snippet_get_body = foo.__py_backwards__.get_body()
    assert snippet_get_body == [
        ast.Print(  # type: ignore
            dest=None,
            values=[
                ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),  # type: ignore
                ast.Name(id='_py_backwards_y_0', ctx=ast.Load())],  # type: ignore
            nl=True),
    ]

# Generated at 2022-06-12 04:42:51.876925
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:43:00.267578
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import assert_source_equals
    from .tests.example_project.foo.bar import test_import  # Will be swapped on fake import
    import importlib.util
    spec = importlib.util.spec_from_loader('module.name', loader=Mock(return_value=Mock()))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.test_import = test_import  # type: ignore

    ast = snippet(test_import).get_body(test_import=module)
    assert_source_equals('a == b', [i for i in ast if not isinstance(i, ast.Expr)][0])
    assert_source_equals('x + 1', ast[1])
    assert_source_equ

# Generated at 2022-06-12 04:43:04.046678
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(a)
    print(a)
    def fn():
        let(b)
        return b
    b = fn()
    """)

    assert {'a', 'b'} == find_variables(tree)



# Generated at 2022-06-12 04:43:11.264275
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    variables = {
        'vars': [
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2)),
        ]
    }
    extend_tree(tree, variables)
    assert get_source(tree) == """x = 1
x = 2
print(x, y)"""

# Generated at 2022-06-12 04:43:19.945864
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from . import let, extend

    class Foo(snippet):
        def __call__(self, *args, **kwargs):
            extend(kwargs)  # type: ignore
            let(x)
            let(y)
            let(z)
            print(x, y, z)

    assert Foo().get_body(x=10) == ast.parse('x = 10\nprint(x)').body
    assert Foo().get_body(x=10, y=1) == ast.parse('x, y = 10, 1\nprint(x, y)').body

    assert Foo().get_body(z=1, y=2, x=3) == ast.parse('x, y, z = 3, 2, 1\nprint(x, y, z)').body

# Generated at 2022-06-12 04:43:27.785910
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test(x: int, y: ast.Name) -> None:
        a = 1
        let(y)
        b = a + x  # type: ignore
        return b

    value = snippet(test).get_body(x=5, y=ast.Name(id='z', ctx=ast.Load()))

# Generated at 2022-06-12 04:43:32.950152
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda: let('x')).get_body() == ast.parse(
        '_py_backwards_x_0 = x').body

    assert snippet(lambda: extend('x')).get_body(x=['x', 'x']) == ast.parse(
        'x = x').body + ast.parse('x = x').body

    assert snippet(lambda: let('x') and let('y')).get_body() == ast.parse(
        '_py_backwards_x_0 = x\n_py_backwards_y_0 = y').body

# Generated at 2022-06-12 04:43:38.463191
# Unit test for function extend_tree
def test_extend_tree():
    import astor
    extended_var = ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=2)
    )
    tree = ast.parse("""
x = 1
extend(vars)
print(x)
""")
    extend_tree(tree, {'vars': extended_var})
    expected_code = """
x = 1
x = 2
print(x)
"""
    assert astor.to_source(tree) == expected_code



# Generated at 2022-06-12 04:43:44.815375
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        foo = 'bar'
        let(foo)
        print(foo)
    snippet = snippet(test)
    body = snippet.get_body()
    assert body == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_foo_0', ctx=ast.Store())],
            value=ast.Str(s='bar')
        ),
        ast.Print(
            values=[ast.Name(id='_py_backwards_foo_0', ctx=ast.Load())],
            dest=None
        )
    ]

# Generated at 2022-06-12 04:43:48.602803
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(f)')
    f = ast.parse('x=0')
    extend_tree(tree, {'f': f})
    assert(ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=0))])")

# Generated at 2022-06-12 04:44:03.600031
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Note: The line below is not used in production
    assert snippet(lambda x, y: let(x), lambda z: z).get_body() == [ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Name(id='y', ctx=ast.Load()))]

# Generated at 2022-06-12 04:44:12.030247
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: let(x)).get_body() == []
    assert snippet(lambda x: let(x)).get_body(x=(x := 3)) == []
    assert snippet(lambda x: let(x)).get_body(x=3) == []

# Generated at 2022-06-12 04:44:17.290700
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import astor
    @snippet
    def get_body(a, b):
        let(x)
        x += 1
        y = 1

    # In pyhton3.6 ast.dump() prints strings in single quotes
    # so we use ast.to_source().
    expected = '''\
x += 1
y = 1'''
    assert astor.to_source(get_body.get_body()).strip() == expected



# Generated at 2022-06-12 04:44:21.710660
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    ctx = {'s': 'foo'}
    s = snippet(lambda x, y: x + y)
    body = s.get_body(s=s, ctx=ctx)
    assert(len(body) == 1)
    assert(isinstance(body[0], ast.Assign))

# Generated at 2022-06-12 04:44:27.519442
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_body = snippet(lambda x: let(x)).get_body(x=[
        ast.BinOp(ast.Name(id='x'), ast.Add(), ast.Num(n=1)),
        ast.BinOp(ast.Name(id='x'), ast.Add(), ast.Num(n=2))
    ])
    assert(snippet_body == [
        ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=2))
    ])

# Generated at 2022-06-12 04:44:32.372486
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def get_body():
        extend(body1)
        extend(body2)

        let(var1)
        let(var2)
        let(var3)

    body1 = ast.Assign([ast.Name(id='var1', ctx=ast.Store())],
                       ast.Num(1))
    body2 = ast.Assign([ast.Name(id='var2', ctx=ast.Store())],
                       ast.Num(2))

    var1 = 'var1_snippet'
    var2 = 'var2_snippet'
    var3 = ast.Name(id='var3_snippet', ctx=ast.Load())

    result = get_body.get_body(var1=var1, var2=var2, var3=var3)


# Generated at 2022-06-12 04:44:38.855317
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        x = 1
        print(x)

    assert snippet(f).get_body() == [
        ast.Assign(
            targets=[
                ast.Name(
                    id='_py_backwards_x_0',
                    ctx=ast.Store())
            ],
            value=ast.Num(
                n=1)
        ),
        ast.Print(
            dest=None,
            values=[
                ast.Name(
                    id='_py_backwards_x_0',
                    ctx=ast.Load())
            ],
            nl=True)
    ]


# Generated at 2022-06-12 04:44:46.850275
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Example 1
    @snippet
    def example(x):
        let(x)
        return x + 1

    print(example.get_body())
    print(example.get_body(x=2))
    print(example.get_body(x=ast.Name(id='my_var', ctx=ast.Load())))

    # Example 2
    @snippet
    def example2(x):
        extend(vars)
        return x + 1

    print(example2.get_body())
    print(example2.get_body(vars=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                            value=ast.Num(1))]))

# Generated at 2022-06-12 04:44:51.629276
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_body(x):
        x = 0
        x += 1
        x = 5
        return x

    x = ast.Name(id='x', ctx=ast.Store())
    body = snippet_body.get_body(x=x)

    expected = ast.parse('''
x = 0
x += 1
x = 5
return x
''').body

    assert body == expected



# Generated at 2022-06-12 04:44:55.049317
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet = snippet(lambda x, y: x + y)
    body = snippet.get_body(x=1, y=5)
    assert body == [ast.Expr(value=ast.BinOp(left=ast.Num(n=1),
                                            op=ast.Add(),
                                            right=ast.Num(n=5)))]

# Generated at 2022-06-12 04:45:20.423228
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(a)")
    variables = find_variables(tree)
    assert list(variables) == ["a"]
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 0


# Generated at 2022-06-12 04:45:26.024909
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import make_ast
    result = snippet(lambda x: x ** 2).get_body(x=make_ast('x'))
    assert result == [ast.Assign(targets=[ast.Name(id='_py_backwards_x_0')],
                                 value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0'),
                                                 op=ast.Pow(),
                                                 right=ast.Num(n=2)))]



# Generated at 2022-06-12 04:45:28.856078
# Unit test for function find_variables
def test_find_variables():
    def test_fn():
        let(3)
        let(4)

    tree = ast.parse(get_source(test_fn))
    assert set(find_variables(tree)) == {'_0', '_1'}



# Generated at 2022-06-12 04:45:38.056368
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def callable_body(x: int, y: int):
        x += 1
        y -= 1

    body = snippet(callable_body).get_body(x=5, y=5)
    assert isinstance(body, list)

    assert isinstance(body[0].value, ast.BinOp)
    assert isinstance(body[0].value.left, ast.Name)
    assert body[0].value.left.id == VariablesGenerator.generate('x')
    assert isinstance(body[0].value.op, ast.Add)
    assert isinstance(body[0].value.right, ast.Num)
    assert body[0].value.right.n == 1

    assert isinstance(body[1].value, ast.BinOp)

# Generated at 2022-06-12 04:45:42.658760
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: None).get_body() == []
    assert snippet(lambda x: x).get_body() == [ast.Expr(ast.Name(id='_py_backwards_x_0'))]
    assert snippet(lambda x: x + 1).get_body() == [ast.Expr(ast.BinOp(
        left=ast.Name(id='_py_backwards_x_0'), op=ast.Add(), right=ast.Num(n=1)))]

# Generated at 2022-06-12 04:45:45.551590
# Unit test for function find_variables
def test_find_variables():
    def fn():
        let(x)
        x += 1
        let(y)

    tree = ast.parse(get_source(fn))
    assert list(find_variables(tree)) == ['x', 'y']

# Generated at 2022-06-12 04:45:53.384535
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    vars = {
        'x': [
            ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
            ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))
        ]
    }

    extend(vars)
    print(x)
    """
    tree = ast.parse(source)
    extend_tree(tree, {'vars': [ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
                                ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))]})

# Generated at 2022-06-12 04:46:02.582051
# Unit test for function extend_tree
def test_extend_tree():
    original = ast.parse("""let(x)
                            x = 1
                            x = 2""")
    snip = ast.parse("""extend(x)
                        let(y)
                        print(x, y)""")

    extend_tree(snip, {
        'x': original.body[1:]
    })


# Generated at 2022-06-12 04:46:06.768310
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda: 1).get_body() == [ast.Expr(value=ast.Num(n=1))]  # type: ignore
    assert snippet(lambda x: x).get_body(x=1) == [ast.Expr(value=ast.Num(n=1))]  # type: ignore



# Generated at 2022-06-12 04:46:12.141051
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def add(x: int, y: int) -> int:
        return let(x) + let(y)  # noqa

    tree = add.get_body(x=1, y=2)
    assert ast.dump(tree) == '[Assign(targets=[Name(_py_backwards_x_0, Store())], value=Num(n=1)), Assign(targets=[Name(_py_backwards_y_0, Store())], value=Num(n=2)), Assign(targets=[Name(y, Store())], value=BinOp(left=Name(_py_backwards_x_0, Load()), op=Add(), right=Name(_py_backwards_y_0, Load())))]'