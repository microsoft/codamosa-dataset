

# Generated at 2022-06-12 04:36:32.995721
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    tree = ast.parse("from os import path")
    tree = VariablesReplacer.replace(tree, {"os": "osModule"})
    assert(str(tree) == "from osModule import path")

# Generated at 2022-06-12 04:36:40.741846
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import inspect

    def func_x():
        def func_y():
            let(q)
        return q

    assert inspect.getsource(func_x) == snippet(func_x).get_body()

    class Test:
        def func_x(self):
            let(a)

        def func_y(self):
            let(a)
            let(b)
            print(a, b)

        def func_z(self):
            def func_y():
                let(q)

    assert inspect.getsource(Test.func_x) == snippet(Test.func_x).get_body()
    assert inspect.getsource(Test.func_y) == snippet(Test.func_y).get_body()

# Generated at 2022-06-12 04:36:45.180659
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = "from some_module import some_name"
    tree = ast.parse(source)
    variables = {'some_module': 'another_module'}
    VariablesReplacer.replace(tree, variables)
    generated_code = ast.dump(tree)
    assert generated_code == "ImportFrom(module='another_module', names=[alias(name='some_name', asname=None)], level=0)"

# Generated at 2022-06-12 04:36:45.949837
# Unit test for function find_variables

# Generated at 2022-06-12 04:36:48.900008
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse('''
    let(x)
    let(y)
    '''))) == ['x', 'y']

# Generated at 2022-06-12 04:36:57.126913
# Unit test for function extend_tree
def test_extend_tree():
    source = """
        extend(a)
        a = 3
        print(a)
    """

    tree = ast.parse(source)
    extend_tree(tree, {
        'a': [
            ast.Assign(
                targets=[ast.Name(id='a', ctx=ast.Store())],
                value=ast.Num(n=1)
            ),
            ast.Assign(
                targets=[ast.Name(id='a', ctx=ast.Store())],
                value=ast.Num(n=2)
            )
        ]
    })

    assert ast.dump(tree) == astunparse.unparse(tree) == \
        "a = 1\na = 2\nprint(a)"

# Generated at 2022-06-12 04:37:01.234689
# Unit test for function find_variables
def test_find_variables():
    test_source = """
let(x)
x += 1
y += 1
    """
    tree = ast.parse(test_source)
    assert 'x' in list(find_variables(tree))
    assert 'y' in list(find_variables(tree))

# Generated at 2022-06-12 04:37:08.303851
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    x = 2
    y = 3
    """)
    assert list(find_variables(tree)) == ['x', 'y']
    assert ast.dump(tree) == """
    Module(body=[Assign(targets=[Name(id='x', ctx=Store())],
                 value=Num(n=2)),
               Assign(targets=[Name(id='y', ctx=Store())],
                 value=Num(n=3))])
    """.strip()



# Generated at 2022-06-12 04:37:13.102469
# Unit test for function find_variables
def test_find_variables():
    snippet_ = snippet(find_variables)
    nodes = snippet_.get_body()
    assert isinstance(nodes, list)
    assert len(nodes) == 1
    assert isinstance(nodes[0], ast.Assign)
    assert nodes[0].value.elts[0].num == 1


# Generated at 2022-06-12 04:37:16.496309
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    x = 1
    y = 2
    extend(vars)
    
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """).body
    expected = ast.parse("""
    x = 1
    y = 2
    x = 1
    x = 2
    """).body
    extend_tree(tree, {"vars": vars})
    assert expected == tree.body

# Generated at 2022-06-12 04:37:28.833450
# Unit test for function extend_tree
def test_extend_tree():
    import inspect
    from .shortcuts import run, let, extend

    @snippet
    def first():
        extend(templar)
        let(code)
        second(code=code)

    tree = ast.parse(inspect.getsource(first))
    extend_tree(tree, {'templar': [
        ast.parse("x = 1").body[0],
        ast.parse("x = 2").body[0],
    ]})

    assert run(tree, {
        'code': 1,
        'second': lambda code: code + 1,
    }) == 3, 'Code in snippets was not extended'

# Generated at 2022-06-12 04:37:37.176851
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def x_plus_one(x: int, y: str) -> int:
        let(x)
        x += 1
        y = 'y'
        return x

    @snippet
    def y_plus_one(x: int, y: int) -> int:
        extend(vars)
        y = x + 1
        return y
    

# Generated at 2022-06-12 04:37:48.135880
# Unit test for function extend_tree
def test_extend_tree():
    source = """
import os
import sys
extend(vars)
print(x, y)"""
    tree = ast.parse(source)
    extend_tree(tree, {
        'vars': [
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=1)),
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=2)),
        ]
    })

# Generated at 2022-06-12 04:37:54.805989
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():

    class MockedVariablesReplacer(VariablesReplacer):
        def __init__(self, variables: Dict[str, ast.AST]) -> None:
            self._variables = variables

        def _replace_module(self, module: str) -> str:
            def _replace(name):
                if name in self._variables:
                        return 'top_level'

                return name

            return '.'.join(_replace(part) for part in module.split('.'))

    variables = {
            'module1': ast.Str(s='1'),
            'module2': ast.Str(s='2')
        }

    node = ast.parse("""
        from module1 import x
        from module1.module2 import y
    """)
    MockedVariablesReplacer.replace(node, variables)
    assert get_

# Generated at 2022-06-12 04:38:04.293660
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = inspect.getsource(test_VariablesReplacer_visit_alias)
    tree = ast.parse(source)
    alias_node = tree.body[0].body[0]
    
    variables = {'alias_node': alias_node, 'a_': 'a_1', 'b_': 'b_1'}
    
    class MockTransformer(ast.NodeTransformer):
        def visit(self, node):
            for key in variables:
                if isinstance(node, variables[key].__class__):
                    return variables[key]
            else:
                return node

    sub_tree = MockTransformer().visit(tree)

    real_transformer = VariablesReplacer(variables)
    real_transformer.visit(sub_tree)


# Generated at 2022-06-12 04:38:11.602284
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo():
        let(x)
        y = x + 1
        let(z)
        z += 1

    s = snippet(foo)
    var1 = ast.parse("x = 1")
    var2 = ast.parse("x = 2")
    assert s.get_body(x=var1) == ast.parse("y = x + 1").body
    assert s.get_body(x=var1, z=var2) == [
        ast.parse("y = x + 1").body[0], ast.parse("z += 1").body[0]
    ]

# Generated at 2022-06-12 04:38:18.475165
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def foo(a: int, b: int, c: int) -> int:
        let(x)
        let(y)
        u = 1
        for i in range(b):
            v = 1
            y += x
            u += 2
        extend(vars)
        v = 2
        x = y
        return y

    vars = [ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=1))]
    body = foo.get_body(a=2, b=3, c=3, vars=vars)
    assert body[0].value.right.id == '_py_backwards_y_0'

# Generated at 2022-06-12 04:38:23.097045
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet():
        let(x)
        x += 1
        y = 1

    body = test_snippet.get_body()
    assert body[0].value.op == ast.Add()
    assert body[0].targets[0].id == '_py_backwards_x_0'
    assert body[1].value.n == 1

# Generated at 2022-06-12 04:38:31.673609
# Unit test for function extend_tree
def test_extend_tree():
    var_x = ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=1)
    )

    var_y = ast.Assign(
        targets=[ast.Name(id='y', ctx=ast.Store())],
        value=ast.Num(n=2)
    )

    source = 'extend({})'.format(ast.dump([var_x, var_y]))
    tree = ast.parse(source)
    extend_tree(tree, {})

# Generated at 2022-06-12 04:38:39.347239
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # type: () -> None
    x = y = z = 1
    arr = [x, y, z]
    
    def fn():
        # type: () -> None
        let(x)
        let(y)
        x += 1
        y += 1
        arr.append(x)
        arr.append(y)
    
    snippet_fn = snippet(fn)
    code = snippet_fn.get_body(x=1, y=2)

# Generated at 2022-06-12 04:38:54.364274
# Unit test for function find_variables

# Generated at 2022-06-12 04:39:01.085625
# Unit test for function extend_tree
def test_extend_tree():
    """
    >>> import astor
    >>> code = '''
    ext = extend
    def f():
        ext(x)
        
        y = 2
    '''
    >>> tree = ast.parse(code, 'test_extend_tree')
    >>> x = ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(42))
    >>> extend_tree(tree, {'x': x})
    >>> print(astor.to_source(tree))
    ext = extend
    def f():
        x = 42
        
        y = 2
    <BLANKLINE>
    """

# Generated at 2022-06-12 04:39:04.334968
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_get_body_func(x, y) -> None:
        let(x)
        let(y)
        x += 1
        y = 'test'

    snippet_get_body = snippet(snippet_get_body_func)
    snippet_get_body_get_body = s

# Generated at 2022-06-12 04:39:09.668157
# Unit test for function find_variables
def test_find_variables():
    code_instance = """\
    let(a)
    let(b)
    c = a
    let(d)
    def def_snippet(c, d):
        let(e)
        f = a
    """
    code_instance_expected = ['a', 'b', 'd', 'e']
    tree = ast.parse(code_instance)
    assert list(find_variables(tree)) == code_instance_expected


# Generated at 2022-06-12 04:39:12.736103
# Unit test for function extend_tree
def test_extend_tree():
    fun = snippet(
        lambda x, y:
        extend(vars)
    )
    vars = ast.parse("x = 1\nx = 2").body
    assert fun.get_body(vars=vars) == vars


# Generated at 2022-06-12 04:39:20.428982
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from . import Assert

    class c: pass
    variable = ast.Name('_py_backwards_variable_0', ast.Load())
    var = c()
    var.value = variable

    @snippet
    def func():
        let(var)
        var.value += 1

    # Test that get_body method of snippet class returns correct Node objects
    Assert(func.get_body() == [ast.AugAssign(target=variable, value=ast.Constant(1), op=ast.Add()),
                               ast.Assign(targets=[variable], value=ast.Constant(2))])


# Generated at 2022-06-12 04:39:24.298629
# Unit test for function extend_tree
def test_extend_tree():
    source = "extend(vars); print(y)"
    tree = ast.parse(source)
    vars_str = """x = 1
x = 2"""
    vars_tree = ast.parse(vars_str)
    extend_tree(tree, {"vars": vars_tree.body})
    ast.fix_missing_locations(tree)
    print(ast.dump(tree))



# Generated at 2022-06-12 04:39:28.397688
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
extend([1])
""".strip())
    extend_tree(tree, {'[1]': [ast.parse('x = 1').body[0]]})
    assert get_source(tree) == "x = 1\nx = 1"



# Generated at 2022-06-12 04:39:34.215464
# Unit test for function extend_tree
def test_extend_tree():
    import astor

    code = '''
x = 1
extend(vars)
y = 2
'''
    tree = ast.parse(code)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Constant(value=2, kind=None))]
    extend_tree(tree, {'vars': vars})
    assert astor.to_source(tree).strip() == '''
x = 1
x = 2
y = 2'''

# Generated at 2022-06-12 04:39:43.034665
# Unit test for function extend_tree
def test_extend_tree():
    from .tree import print_tree
    from .test_tree import test_tree_visitor_and_transformer
    from .helpers import VariablesGenerator

    def snippet_fn():
        extend(vars)
        print(x)
        print(y)

    tree = ast.parse(get_source(snippet_fn))
    variables = {
        'vars': [
            ast.Assign(
                targets=[ast.Name(id='x',
                                  ctx=ast.Store())],
                value=ast.Num(n=1)),
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.Num(n=2))
        ]
    }
    extend_tree(tree, variables)
    test_tree_visitor

# Generated at 2022-06-12 04:39:58.995200
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: let(x) + x + y).get_body(x=1, y=2) == [
        ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                             op=ast.Add(),
                             right=ast.Num(n=1))),
        ast.Assign([ast.Name(id='y', ctx=ast.Store())],
                   ast.Num(n=2))
    ]


# Generated at 2022-06-12 04:40:02.721524
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    """
    tree = ast.parse(source)
    variables = list(find_variables(tree))
    assert variables == ['x', 'y']
    assert compile(tree, filename="<ast>", mode="exec") is not None



# Generated at 2022-06-12 04:40:07.607855
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(vars)")
    vars = [ast.Assign([ast.Name('x', ast.Store())],
                       ast.Num(1)),
            ast.Assign([ast.Name('x', ast.Store())],
                       ast.Num(2))]
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == 'x = 1\nx = 2\n'

# Generated at 2022-06-12 04:40:11.376466
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test(x, y):
        let(x)
        let(y)
        x += 1
        y += 2

    snippet = snippet(test)
    assert snippet.get_body(x=0, y=0) == ast.parse("""\
x += 1
y += 2""").body

# Generated at 2022-06-12 04:40:20.543271
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo(x: int) -> None:
        let('foo')
        let('bar')
        let('baz')
        let('qux')
        foo = x
        bar = x * 2
        baz = x * x
        qux = x * x * x
        
    s = snippet(foo)
    _, x = s.get_body()[0].value.elts
    assert x.id == '_py_backwards_x_0'
    assert x.ctx.__class__ == ast.Load
    x.id = 'x'
    assert ast.dump(x) == 'Name(id="x", ctx=Load())'

# Generated at 2022-06-12 04:40:24.075747
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    assert snippet_obj.get_body(x=2, y=3) == ast.parse("x += 1\ny = 1").body



# Generated at 2022-06-12 04:40:28.628635
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = 'def fn(a, b):\n    let(c)\n    return c + b'
    tree = ast.parse(source)
    variables = {
        'c': 'a',
        'b': 'c'
    }

    expected = 'def fn(a, c):\n    return a + c'
    actual = ast.dump(VariablesReplacer.replace(tree, variables))
    assert actual == expected



# Generated at 2022-06-12 04:40:39.802587
# Unit test for function extend_tree
def test_extend_tree():
    def find_node(node: ast.AST, name: Union[str, Callable]) -> ast.Name:
        if isinstance(name, str):
            return find(node, ast.Name).__next__()
        else:
            return find(node, name).__next__()

    source = 'extend(vars)\nprint(x)'
    ast_ = ast.parse(source)
    vars_ = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
             ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())], value=ast.Num(n=2))]
    extend_tree(ast_, {'vars': vars_})
    assert find_node

# Generated at 2022-06-12 04:40:45.598542
# Unit test for function extend_tree
def test_extend_tree():
    body = [ast.Assign(targets=[ast.Name(id='a')], value=ast.Num(1)),
            ast.Assign(targets=[ast.Name(id='b')], value=ast.Num(2))]
    tree = ast.parse('extend(t)')
    tree.body[0].args[0].id = 'body'
    extend_tree(tree, {'body': body})
    assert ast.dump(tree) == ('Module(body=[Assign(targets=[Name(id='
                               '"a")], value=Num(n=1))], orelse=[Assign(targets='
                               '[Name(id="b")], value=Num(n=2))])')



# Generated at 2022-06-12 04:40:53.425917
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
y = 3
extend(x)
""")
    x = ast.parse("""
x = 1
x = 2
""")
    extend_tree(tree, {"x": x})
    assert ast.dump(tree.body[0]) == "Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1))"
    assert ast.dump(tree.body[1]) == "Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2))"
    assert ast.dump(tree.body[2]) == "Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=3))"



# Generated at 2022-06-12 04:41:07.984379
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class Test1(snippet):
        def __init__(self):
            super().__init__(self.test_snippet)

        def test_snippet(self, list_: ast.Name) -> None:
            list_.id = '_py_backwards_list_0'
            let(list_)
            list_.id += '_0'
            list_.id += '_0'
            list_.id += '_0'

    class Test2(snippet):
        def __init__(self):
            super().__init__(self.test_snippet)

        def test_snippet(self,  # pylint: disable=R0913
                         x: ast.Num, y: ast.Str) -> None:
            let(x)
            let(y)

# Generated at 2022-06-12 04:41:14.878512
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def body_test(a: int, b: int):
        let(x)
        x = a + b + 1
        extend(vars)
        x = 1
        x = 2


# Generated at 2022-06-12 04:41:22.448814
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import get_source

    def method():
        let(x)
        return x

    snippet_ = snippet(method)
    expected = 'return _py_backwards_x_0'
    assert snippet_.get_body()[-1].value.s == expected

    expected = 'return x'
    assert snippet_.get_body(x=2)[-1].value.n == expected

    def method2():
        extend(vars)
        return

    snippet_ = snippet(method2)
    expected = 'return'
    assert snippet_.get_body(vars=[])[-1].value == expected
    assert snippet_.get_body(vars=[ast.parse('a=1')])[-1].value == expected

# Generated at 2022-06-12 04:41:26.532254
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    stmt = ast.Expr(ast.Call(ast.Name("print", ast.Load()), [ast.Str("Hello, world!")], []))
    global_snippet = ast.Module([stmt])
    def test_body():
        global_snippet
    snippet = snippet(test_body)
    assert snippet.get_body() == [stmt]

# Generated at 2022-06-12 04:41:35.291479
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippets = {}

    def add_snippet(name: str, fn: Callable[..., None]) -> None:
        """Adds snippet to dict."""
        snippets[name] = snippet(fn)

    # snippet       
    @add_snippet('snippet')
    def snippet_01():
        let(x)
        x += 1
        y = 1

    assert snippets['snippet'].get_body() == ast.parse(
        '_py_backwards_x_0 += 1;y = 1;').body

    # snippet with args
    @add_snippet('snippet_with_args')
    def snippet_02(a: int, b: int):
        x = a + b
        y = a + b

    assert snippets['snippet_with_args'].get_body

# Generated at 2022-06-12 04:41:44.807502
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\n'
                     'print(x, y)\n')
    variables = {
        'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(1)),
                 ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(2))]
    }
    extend_tree(tree, variables)

# Generated at 2022-06-12 04:41:53.600427
# Unit test for function find_variables
def test_find_variables():
    source = dedent('''
        x = 1
        let(a)
        a = 2
        let(b)
        def foo(c):
            let(d)
            d = c + 1
            b = a + d
        c = foo(b)
        x = c
        print(x)
    ''')

    tree = ast.parse(source)
    expected = {'a', 'b', 'd', 'c'}
    assert expected == set(find_variables(tree))


# Generated at 2022-06-12 04:42:02.133392
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var = ast.Name(id='x', ctx=ast.Load())

    @snippet
    def foo(x: int) -> int:
        let(x)
        return (x << 1) + 1

    get_body = foo.get_body(x=var)
    assert len(get_body) == 2

    return_ = get_body[-1]
    assert isinstance(return_, ast.Return)
    assert isinstance(return_.value, ast.BinOp)
    assert isinstance(return_.value.right, ast.Num)
    assert return_.value.right.n == 1
    assert isinstance(return_.value.left, ast.BinOp)
    assert isinstance(return_.value.left.right, ast.Name)

# Generated at 2022-06-12 04:42:05.879219
# Unit test for function extend_tree
def test_extend_tree():
    var = ast.parse('''x = 1
x = 2''')
    tree = ast.parse('''extend(vars)
print(x, y)''')
    extend_tree(tree, {"vars": var})
    assert tree == ast.parse('''x = 1
x = 2
print(x, y)''')


# Generated at 2022-06-12 04:42:13.874756
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(a: int, b: int = 1):
        let(x)
        let(y)
        let(z)
        x += b
        y = 1
        z = 2
        extend(vars)
        return x, y, z

    snippet_ = snippet(test_snippet)
    variables = {'x': VariablesGenerator.generate('x'),
                 'y': VariablesGenerator.generate('y'),
                 'z': VariablesGenerator.generate('z'),
                 'vars': [ast.Assign(targets=[ast.Name(id='x')],
                                     value=ast.Num(1)),
                          ast.Assign(targets=[ast.Name(id='x')],
                                     value=ast.Num(2))]}
    body

# Generated at 2022-06-12 04:42:27.497425
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse(dedent("""
        extend(vars)
        print(x, y)
    """))

    vars = [
        ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=1))
    ]
    extensions = {
        'vars': vars
    }

    extend_tree(tree, extensions)
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Expr(value=Call(func=Name(id=\'print\', ctx=Load()), args=[Name(id=\'x\', ctx=Load()), Name(id=\'y\', ctx=Load())], keywords=[]))])'

# Generated at 2022-06-12 04:42:34.311680
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def example():
        let(x)
        x += 1
        return x

    assert example.get_body() == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                                             ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                                       ast.Add(), ast.Num(1))),
                                 ast.Return(ast.Name('_py_backwards_x_0', ast.Load()))]


# Generated at 2022-06-12 04:42:42.333386
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test(x: int, y: int) -> int:
        let(z)
        let(y)
        return x + y + z

    test_snippet = snippet(test)
    variables = test_snippet._get_variables(test_snippet.test_source, {'z': 0, 'y': 1})
    assert variables['z'] == '_py_backwards_z_0'
    assert variables['y'] == '_py_backwards_y_1'

    body = test_snippet.get_body(z=0, y=1)

# Generated at 2022-06-12 04:42:46.667807
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(a)\nprint(a)')
    extend_tree(tree, {
        'a': [ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Load())],
            value=ast.Num(n=1)
        )]
    })
    assert get_source(tree) == 'a = 1\nprint(a)'

# Generated at 2022-06-12 04:42:53.430408
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        let(y)
        import x
        import y
        x += 1
        y += 1
        for i in range(5):
            print(x, y)
        return x

    from .utils import get_ast_snippet
    from .tree import print_tree

    snippet._fn = test
    snippet_kwargs = {}
    obj = snippet(test)
    body = obj.get_body(**snippet_kwargs)
    ast = get_ast_snippet(body)
    print_tree(ast)



# Generated at 2022-06-12 04:43:02.428086
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
y = 1
extend(vars)
'''
    tree = ast.parse(source)
    vars = {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
                     ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))]}
    extend_tree(tree, vars)

# Generated at 2022-06-12 04:43:06.394594
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(a)
    let(b)
    b = 1
    let(c)
    c = 2
    let(extend)
    let(let)
    let(let_1)
    """)
    assert list(find_variables(tree)) == ['a', 'b', 'c']

# Generated at 2022-06-12 04:43:12.267016
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def my_snippet(x, **kwargs):
        let(x)
        kwargs['a'].value += 1
        return x + 1

    snippet_object = snippet(my_snippet)
    body = snippet_object.get_body(a=ast.Name(id='b', ctx=ast.Load()), b=1, x=1)
    assert len(body) == 2
    assert body[0].id == '_py_backwards_x_0'
    assert body[1].value == 2

# Generated at 2022-06-12 04:43:20.865185
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    example = [ast.Num(n=1), ast.Num(n=2)]

    @snippet
    def fn1(x: int, y: int) -> int:
        let(x)
        return x * x

    @snippet
    def fn2(x: int) -> ast.AST:
        let(y)

# Generated at 2022-06-12 04:43:23.489038
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("let(a);a+a")
    variables = [variable for variable in find_variables(tree)]
    assert len(variables) == 1
    assert variables[0] == 'a'


# Generated at 2022-06-12 04:43:37.124243
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test_snippet_get_body(fn, expected_body, **kwargs):
        snippet_instance = snippet(fn)
        body = snippet_instance.get_body(**kwargs)
        assert body == expected_body
        assert body[0].value.left.id == '_py_backwards_x_0'
        assert body[0].value.op == 'Add'
        assert body[0].value.right.n == 1
        assert body[1].targets[0].id == 'y'
        assert body[1].value.n == 1

    def test_input(x):
        let(x)
        x += 1
        y = 1

    @snippet
    def test_input(x):
        let(x)
        x += 1
        y = 1

    expected_

# Generated at 2022-06-12 04:43:45.498163
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x: ast.Name
    y: ast.Name
    @snippet
    def test_snippet1(x: ast.Name) -> None:
        let(x)
        x.id = 'y'
        y = 0
        
    assert test_snippet1.get_body(x=x)[0].targets[0].id == 'y'
    assert test_snippet1.get_body(x=x)[1].value.n == 0

    w: ast.Name
    @snippet
    def test_snippet2(x: ast.Name, y: ast.Name) -> None:
        let(x)
        let(y)
        x.id = 'w'
        y.id = 'w'
        w.id = 'w'
        
    assert test

# Generated at 2022-06-12 04:43:49.134218
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def get_body():
        let(x)
        x += 1
        y = 1
        let(z)
        z = z + ' ' + 'world'
        let(vars)
        extend(vars)
        print(x, y, z)
        return let(ret)

    snippet_var = snippet(get_body)
    body = snippet_var.get_body(
        x=5,
        y=10,
        z='Hello',
        vars=[ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
              ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))],
        ret=42,
    )

    assert isinstance(body[-1], ast.Return,)

# Generated at 2022-06-12 04:43:52.566670
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(a: int, b: int) -> int:
        let(c)
        c = a + b
        return c

    snippet_obj = snippet(test_snippet)
    snippet_obj.get_body(a=10, b=20)



# Generated at 2022-06-12 04:43:58.268357
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo():
        a = 1
        let(a)
        a += 1

    s = snippet(foo)
    assert s.get_body() == [
        ast.Assign(
            targets=[ast.Name('a', ast.Store())],
            value=ast.Num(1)
        ),
        ast.AugAssign(
            target=ast.Name('a', ast.Store()),
            op=ast.Add(),
            value=ast.Num(1)
        )
    ]


# Generated at 2022-06-12 04:44:04.390928
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: ast.Name):
        let(x)
        x += 1

    tree = test.get_body(x=ast.Name(id='x', ctx=ast.Store()))
    assert tree == [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                               value=ast.BinOp(left=ast.Name(id='x', ctx=ast.Load()),
                                               op=ast.Add(),
                                               right=ast.Num(n=1)))]



# Generated at 2022-06-12 04:44:07.495245
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    s = snippet(lambda x, y: x + y)
    body = s.get_body(a=2, b=4)
    assert body[-1].value.right.n == 6

# Generated at 2022-06-12 04:44:14.800209
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo(x: int) -> int:
        let(y)
        return y + 1

    snippet_body = snippet(foo).get_body(
        x=1,
        y=[
            ast.Assign(targets=[ast.Name(id="y")], value=ast.Num(n=2))
        ]
    )

    assert snippet_body == [
        ast.Assign(targets=[ast.Name(id='y')], value=ast.Num(n=2)),
        ast.Return(value=ast.BinOp(left=ast.Name(id='y'), op=ast.Add(), right=ast.Num(n=1)))
    ]

test_snippet_get_body()



# Generated at 2022-06-12 04:44:24.509819
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import datetime
    from .examples import date_mock
    from .helpers import print_ast, assert_ast

    @date_mock(datetime.date(year=2020, month=1, day=2))
    def g() -> snippet.get_body:
        let(x)
        y = 1
        z = 2
        return x, y, z


# Generated at 2022-06-12 04:44:26.041345
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_instance = snippet(lambda x: None)
    snippet_instance.get_body()

# Generated at 2022-06-12 04:44:45.166412
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    variables = dict(a=1, b='foo')

    def fn():
        let(a)
        let(b)
        print(a + b)
        print(a - b)

    snippet_instance = snippet(fn)
    body = snippet_instance.get_body(**variables)

    expected = ast.parse('''
print(_py_backwards_a_0 + _py_backwards_b_1)
print(_py_backwards_a_0 - _py_backwards_b_1)
''').body

    for node, expected_node in zip(body, expected):
        assert node.__class__ == expected_node.__class__



# Generated at 2022-06-12 04:44:53.410042
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def my_snippet(x: int, y: int = 1) -> None:
        let(x)
        let(y)
        x += 1
        y = 3
        return x, y

    expected_body = [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1))),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=3))
    ]


# Generated at 2022-06-12 04:45:01.258568
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x: float) -> float:
        let(x)
        let(y)
        x += 2
        y += 3

        return x + y


# Generated at 2022-06-12 04:45:05.074727
# Unit test for function find_variables
def test_find_variables():
    code = """let(x)
x.a += 1
x.b = let(y)
z = y + 1
let(z)"""
    tree = ast.parse(code)
    assert set(find_variables(tree)) == {'x', 'z', 'y'}



# Generated at 2022-06-12 04:45:10.242725
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(x: int) -> None:
        let(x)
        x += 1
        y = 1

    assert len(fn.get_body()) == 2
    assert isinstance(fn.get_body()[0], ast.Assign)
    assert isinstance(fn.get_body()[1], ast.Assign)



# Generated at 2022-06-12 04:45:17.382393
# Unit test for function find_variables
def test_find_variables():
    source = '''
            def test():
                let(x)
                let(y)
                let(z)
                print(z, y)

            x = 1
            '''

    expected = {
        'test': {'x', 'y', 'z'},
        'global': {'x'},
    }

    tree = ast.parse(source)
    actual = {
        node.name: set(find_variables(node)) for node in tree.body if isinstance(node, ast.FunctionDef)
    }

    assert expected == actual



# Generated at 2022-06-12 04:45:18.248867
# Unit test for function find_variables

# Generated at 2022-06-12 04:45:26.492079
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        if y > 0:
            pass
        else:
            print(x)
        x += 1

    @snippet
    def body_snippet(x: int, y: int) -> None:
        let(x)
        if y > 0:
            pass
        else:
            print(x)
        x += 1

    assert test_snippet.__code__.co_varnames == body_snippet.__code__.co_varnames
    assert ast.dump(ast.parse(get_source(test_snippet))).strip() == \
           ast.dump(body_snippet.get_body(x=1, y=2)).strip()

# Generated at 2022-06-12 04:45:31.276310
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(5)
    """)
    vars = [ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=2)
    )]
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == 'x = 2\nprint(5)'

# Generated at 2022-06-12 04:45:40.286638
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import make_assign, make_body

    def fn():
        let(x)
        z = x + y

    assert snippet(fn).get_body(x=make_assign(1), y=make_assign(2)) == make_body(
        '_py_backwards_x_0 = 1',
        '_py_backwards_y_0 = 2',
        'z = _py_backwards_x_0 + _py_backwards_y_0'
    )

    def fn2():
        let(x)
        let(y)
        extend(x)
        z = x + y

    assert snippet(fn2).get_body(x=make_body(
        'x = 1',
        'x = 2'), y=make_assign(2)) == make_

# Generated at 2022-06-12 04:46:10.400455
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x, y):
        let(x)
        x += 1
        y = 1
        x = 2

        extend(vars)
        print(x, y)

    @snippet
    def f(x, y):
        let(x)
        x += 1
        y = 1
        x = 2

        extend(vars)
        print(x, y)

    body = f.get_body(x=1, vars=[ast.Assign([ast.Name('x', ast.Load())], ast.Num(2))])

# Generated at 2022-06-12 04:46:13.590391
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    with snippet(snippet_body_function) as snippet_controller:
        loaded_ast = snippet_controller.get_body(x=x, y=y)
        assert loaded_ast == snippet_body_function.__code__.co_consts[0]


# Generated at 2022-06-12 04:46:23.710179
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast
    import astunparse

    @snippet
    def snippet_func(x, y):
        let(x)
        x += y
        y += 2
        y -= 3
        return x, y

    body = snippet_func.get_body(x=4, y=5)
    assert isinstance(body, list)
    assert isinstance(body[0], ast.Assign)
    assert body[0].targets[0].id == '_py_backwards_x_0'
    assert body[0].value.left.id == '_py_backwards_x_0'
    assert body[0].value.op == '+='
    assert body[0].value.right.id == 'y'

# Generated at 2022-06-12 04:46:31.028797
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    def test_snippet():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))
    ]

    f = snippet(test_snippet)
    tree = ast.parse('a = 1\n')
    tree.body.extend(f.get_body(vars=vars))
    print(tree)