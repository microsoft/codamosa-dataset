

# Generated at 2022-06-12 04:36:44.708839
# Unit test for function find_variables
def test_find_variables():
    source = r"""
        let(a)
        let(b)
        let(a)
        let(c)
        let(a)
        """
    tree = ast.parse(source)
    names = [name for name in find_variables(tree)]
    assert names == ['a', 'b', 'a', 'c', 'a']

# Generated at 2022-06-12 04:36:50.823249
# Unit test for function extend_tree
def test_extend_tree():
    """Test if extend_tree works as expected."""
    tree = ast.parse("""extend(x)
print(x, y, z)
""")
    extend_tree(tree, {'x': ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(1))})
    assert ast.dump(tree) == "Assign(targets=[Name(id='x', ctx=Store())], value=Num(1))\n"

# Generated at 2022-06-12 04:36:53.306570
# Unit test for function find_variables
def test_find_variables():
    source = '''
        let(x)
        x = 2
        '''
    tree = ast.parse(source)
    assert find_variables(tree) == ['x']

# Generated at 2022-06-12 04:37:02.734734
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet(param1: int, param2: int) -> int:
        let(x)
        x = param1
        x += param2
        return x

    node = ast.parse('result = test_snippet(1, 2)')
    extend_tree(node, {'test_snippet': test_snippet.get_body(x=x)})  # type: ignore

# Generated at 2022-06-12 04:37:07.542715
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = ast.parse("x = 0").body[0]
    b = ast.parse("x += 1").body[0]
    assert snippet(
        lambda x: let(x),
        lambda y: let(y),
        extend(let(x))
    ).get_body(x=a, y=b) == [ast.copy_location(a, b), b]



# Generated at 2022-06-12 04:37:12.346284
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(a)
    def test(a):
        print(a)
    
    def other():
        let(b)
        print(b)
    '''
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'a', 'b'}



# Generated at 2022-06-12 04:37:13.108268
# Unit test for function extend_tree

# Generated at 2022-06-12 04:37:13.613959
# Unit test for function find_variables

# Generated at 2022-06-12 04:37:22.820964
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_body(a, b):
        let(z)
        x = a + b
        x = x * 2
        y = z + x
        x = 42

    module = snippet(snippet_body)
    ast = module.get_body(a=1, b=2, z=3)

# Generated at 2022-06-12 04:37:32.028789
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    if True:
        var = 1
        extend(vars)
        print(var)
    """

    tree = ast.parse(source)
    variables = {'vars': [ast.parse('var = 2').body[0]]}
    extend_tree(tree, variables)
    assert ast.dump(tree) == "Module(body=[If(test=NameConstant(value=True), body=[Assign(targets=[Name(id='var', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='var', ctx=Store())], value=Num(n=2)), Print(dest=None, values=[Name(id='var', ctx=Load())], nl=True)], orelse=[])])"


# Generated at 2022-06-12 04:37:44.687780
# Unit test for function extend_tree
def test_extend_tree():
    source = (
        'print(a, b)\n'
        'extend(vars)\n'
        'print(a, b)')
    tree = ast.parse(source)
    replace_at(2, tree, [ast.Assign(targets=[ast.Name(id='a')],
                                    value=ast.Num(n=1))])
    assert normalize(get_source(tree)) == normalize(
        'print(a, b)\n'
        'a = 1\n'
        'print(a, b)\n'
    )


# Generated at 2022-06-12 04:37:49.156307
# Unit test for function find_variables
def test_find_variables():
    source = '''
    x = 1
    let(y)
    def f():
        let(z)
        pass
    '''
    tree = ast.parse(source)
    assert find_variables(tree) == ['y', 'z']



# Generated at 2022-06-12 04:37:57.521725
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    let(x)
    extend(vars)
    print(x, y)
""")
    variables = {
        'x': '_py_backwards_x_0',
        'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                            value=ast.Num(1)),
                 ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                            value=ast.Num(2))]
    }
    extend_tree(tree, variables)

# Generated at 2022-06-12 04:38:07.153513
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    import sys

    extend(vars)
    print("Hello,", name)
    """
    tree = ast.parse(source)
    vars = [
        ast.Assign([ast.Name(id='name', ctx=ast.Store())], ast.Str('World')),
        ast.Assign([ast.Name(id='name', ctx=ast.Store())], ast.Str('Python')),
        ast.Expr(ast.Call(ast.Name(id='print', ctx=ast.Load()),
                          [ast.Str('Hello, '), ast.Name(id='name', ctx=ast.Load())], [])),
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-12 04:38:16.334572
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # snippet 1
    @snippet
    def snippet1():
        let(x)
        let(y)
        x += 1

    # snippet 2
    @snippet
    def snippet2():
        extend(vars)
        let(x)
        let(y)
        x += 1
        y += 1

    b1 = snippet1.get_body()
    b2 = snippet2.get_body(vars=[ast.parse("x = 1").body[0]])  # type: ignore
    b3 = snippet2.get_body(vars=[ast.parse("x = 1").body[0], ast.parse("y = 1").body[0]])  # type: ignore

    assert len(b1) == 1
    assert isinstance(b1[0], ast.AugAssign)  # type

# Generated at 2022-06-12 04:38:21.586679
# Unit test for function find_variables
def test_find_variables():
    import astor
    code_snippet = """
    let(x)
    let(y)
    let(z)
    x += 1
    y *= 2
    z *= 3
    """
    tree = ast.parse(code_snippet)
    variables = set(find_variables(tree))
    assert variables == {'x', 'y', 'z'}
    assert astor.to_source(tree).strip() == 'x += 1\ny *= 2\nz *= 3\n'



# Generated at 2022-06-12 04:38:30.146075
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    s = snippet(lambda x, y: None)
    a, b, c = s.get_body()
    assert a.__class__ == ast.FunctionDef
    assert a.name == '_py_backwards_fn'
    assert b.__class__ == ast.Assign
    assert b.targets[0].__class__ == ast.Name
    assert b.targets[0].id == '_py_backwards_x'
    assert b.value.__class__ == ast.Name
    assert b.value.id == 'x'
    assert c.__class__ == ast.Assign
    assert c.targets[0].__class__ == ast.Name
    assert c.targets[0].id == '_py_backwards_y'
    assert c.value.__class__ == ast

# Generated at 2022-06-12 04:38:33.173175
# Unit test for function find_variables
def test_find_variables():
    snippet_code = """
    let(x)
    let(y)

    def f():
        pass
    """
    tree = ast.parse(snippet_code)
    assert {'x', 'y'} == set(find_variables(tree))



# Generated at 2022-06-12 04:38:33.912475
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:38:37.896266
# Unit test for function find_variables
def test_find_variables():
    from . import let, extend
    source = """
    let(x)
    let(y)
    extend(vars)
    let(z)
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert set(variables) == {'x', 'y', 'vars', 'z'}

# Generated at 2022-06-12 04:38:50.922348
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        x += 1
        let(y)
        y += 1
        extend(vars)

    snippet_ = snippet(test)
    body = snippet_.get_body()
    assert len(body) == 6

    names = [x.name for x in body if isinstance(x, ast.Assign)]
    assert names == ['_py_backwards_x_0', '_py_backwards_x_0',
                     '_py_backwards_y_0', '_py_backwards_y_0']

    names = [x.id for x in body if isinstance(x, ast.Name)]
    assert names == ['_py_backwards_x_0', '_py_backwards_y_0']



# Generated at 2022-06-12 04:38:54.836937
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(x)
let(y)
let(z)
x = 1
y = 2
z = 3
""")
    vars_ = list(find_variables(tree))
    assert vars_ == ['x', 'y', 'z']

# Generated at 2022-06-12 04:38:59.528054
# Unit test for function find_variables
def test_find_variables():
    source = 'let(local_var)\nlet(local_var2)\n' \
             'let(local_var3)\n' \
             'var = local_var'
    expected_vars = {'local_var', 'local_var2', 'local_var3'}
    tree = ast.parse(source)
    result = find_variables(tree)
    assert result == expected_vars

# Generated at 2022-06-12 04:39:03.705801
# Unit test for function extend_tree
def test_extend_tree():
    def fn():
        extend(x)
        a = 2
        return a

    assert fn() == 2
    x = ast.parse('print(1)').body

    def fn():
        extend(x)
        a = 2
        return a

    assert fn() == 2

    x = ast.parse('a = 1').body

    def fn():
        extend(x)
        a = 2
        return a

    assert fn() == 1

# Generated at 2022-06-12 04:39:12.164497
# Unit test for function extend_tree
def test_extend_tree():
    a, b, c = map(ast.parse,
                  ('x, y = 1, 1',
                   'x, y = 2, 2',
                   'print(x, y)'))
    tree = ast.parse('extend(vars)\nprint(x, y)')

    extend_tree(tree, {
        'vars': [a, b, c]
    })


# Generated at 2022-06-12 04:39:13.686136
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse("let(x)\n"))) == ["x"]

# Generated at 2022-06-12 04:39:22.397067
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def should_be_ok(a, b):
        return a == b

    should_be_ok(snippet(should_be_ok).get_body(a=5, b=5),
                 [ast.Assign([ast.Name('_py_backwards_a_0', ast.Store())], ast.Num(5)),
                  ast.Assign([ast.Name('_py_backwards_b_0', ast.Store())], ast.Num(5)),
                  ast.Return(ast.Call(ast.Name(id='_py_backwards_should_be_ok_0', ctx=ast.Load()),
                                      [ast.Name('_py_backwards_a_0', ast.Load()), ast.Name('_py_backwards_b_0', ast.Load())],
                                      []))])

# Generated at 2022-06-12 04:39:27.391352
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''
let(vars)
extend(vars)
''')
    extend_tree(tree, {'vars': [ast.Assign([ast.Name('x', None)],
                                           ast.Num(1), None)]})
    assert ast.dump(tree) == 'Module([Assign([Name(\'x\', Load())], Num(1), None)])'



# Generated at 2022-06-12 04:39:28.550581
# Unit test for function extend_tree

# Generated at 2022-06-12 04:39:32.169074
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x = 1
    let(b)
    y = b
    z = 3
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert set(variables) == {'x', 'b'}



# Generated at 2022-06-12 04:39:41.216959
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''
        extend(vars)
        print(x, y)
    ''')

    vars = ast.parse('''
        x = 1
        x = 2
        pass
    ''')
    extend_tree(tree, {'vars': vars})

    assert get_source(tree) == '''
    x = 1
    x = 2
    print(x, y)
    '''

# Generated at 2022-06-12 04:39:50.207695
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    global x
    @snippet
    def hello():
        let(x)
        for i in range(10):
            x += i
        print('Hello, {}!'.format(x))


# Generated at 2022-06-12 04:39:57.770525
# Unit test for function extend_tree
def test_extend_tree():
    def snippet_with_extend(vars: Any) -> None:
        extend(vars)

    source = get_source(snippet_with_extend)
    tree = ast.parse(source)

    vars = [ast.Assign(targets=[ast.Name(id='x')],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x')],
                       value=ast.Num(n=12))]
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == 'x = 1\nx = 12'

# Generated at 2022-06-12 04:40:06.484535
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snip(x):
        x += 1
        y = 1
        z = x + y
        while x < 10:
            let(x)
            extend(y)
            pass  # x += 1
    tree = ast.parse(test_snip())
    assert tree.body[0].body[0].value.left.id == 'x'
    assert tree.body[0].body[0].value.right.n == 1
    assert tree.body[0].body[1].value.n == 1
    assert tree.body[0].body[2].value.left.n == 1
    assert tree.body[0].body[2].value.right.id == 'y'
    assert len(tree.body[0].body[3].body) == 1
    assert tree.body

# Generated at 2022-06-12 04:40:08.983601
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo():
        let(x)
        x += 1
        y = 1
    snippet = Snippet(foo)
    assert snippet.get_body()[0].value == 1

# Generated at 2022-06-12 04:40:12.988961
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''
        let(x)
        x += 1
        y = 1
    ''')
    assert find_variables(tree) == {'x', 'y'}  # type: ignore
    assert tree == ast.parse('''
        x += 1
        y = 1
    ''')



# Generated at 2022-06-12 04:40:22.565824
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
x = 1
extend(a)
x
""")
    extend_tree(tree, {'a': [ast.parse("x = 2").body[0], ast.parse("x = 3").body[0]]})  # type: ignore
    assert ast.dump(tree) == """Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Name(id='x', ctx=Load()), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2)), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=3))])"""

# Generated at 2022-06-12 04:40:30.742077
# Unit test for function extend_tree

# Generated at 2022-06-12 04:40:31.310989
# Unit test for function extend_tree

# Generated at 2022-06-12 04:40:40.097691
# Unit test for function extend_tree
def test_extend_tree():
    from . import test_helpers
    from .transforms import Function
    tree = test_helpers.parse("""
async def f(x):
    def g(y):
        return x + y
    return await x
""")(Function)

    assign = test_helpers.parse("y = 1")(ast.Assign)
    extend_tree(tree, {'vars': [assign]})
    assert test_helpers.unparse(tree) == '''\
async def f(x):
    y = 1
    def g(y):
        return x + y
    return await x
'''



# Generated at 2022-06-12 04:40:51.784387
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var = ast.Name('None', ast.Load())

    @let
    def fn():
        return var

    assert fn.get_body() == ast.copy_location(ast.Assign([ast.Name('var', ast.Store())], var), var)

    @let
    def fn():
        return [var]

    assert fn.get_body() == ast.copy_location([ast.Assign([ast.Name('var', ast.Store())], var)], var)

    @let
    def fn(name: ast.Name):
        return name

    assert fn.get_body(name=var) == [ast.Assign([ast.Name('name', ast.Store())], var)]

# Generated at 2022-06-12 04:40:59.921767
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def example(x: ast.Name, y: ast.expr, z: ast.expr):
        let(x)
        x += 1
        some_var = 2
        let(y)
        extend(z)
        some_var += 1
    snippet_instance = snippet(example)
    x = ast.Name(id='x', ctx=ast.Store())
    y = ast.expr(lineno=5, col_offset=0)
    z = ast.Assign(targets=[ast.Name(id='some_var', ctx=ast.Store())],
                   value=ast.Num(n=1))
    args = dict(x=x, y=y, z=z)
    func = snippet_instance.get_body(**args)
    assert func[0].value.op == ast.Add()


# Generated at 2022-06-12 04:41:00.556581
# Unit test for function extend_tree
def test_extend_tree():
    """Tests extend_tree function."""

# Generated at 2022-06-12 04:41:04.639326
# Unit test for function extend_tree
def test_extend_tree():
    code = """
    foo = bar()
    extend(vars)
    print(x)
    """
    tree = ast.parse(code)
    new_tree = ast.parse('y=1')
    extend_tree(tree, {'vars': [new_tree]})
    assert ast.dump(tree) == ast.dump(new_tree)

# Generated at 2022-06-12 04:41:12.601487
# Unit test for function extend_tree
def test_extend_tree():
    source = 'extend(vars)\nprint(x, y)'
    tree = ast.parse(source)

# Generated at 2022-06-12 04:41:17.003218
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(print).get_body(x='0') == [
        ast.Expr(ast.Call(ast.Name('print', ast.Load()), [ast.Str('0')], []))
    ]

    assert snippet(lambda x: x + 1).get_body(x='0') == [
        ast.Return(ast.BinOp(ast.Str('0'), ast.Add(), ast.Num(1)))
    ]



# Generated at 2022-06-12 04:41:25.422892
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test(res, fn, **kwargs):
        s = snippet(fn)
        assert len(s.get_body(**kwargs)) == len(res)
        for i in range(len(res)):
            assert type(res[i]) == type(s.get_body(**kwargs)[i])

    def fn(x, y=1):
        let(x)
        x += 1
        let(y)
        y += 1
        return x, y

    def fn1(x, z, **kwargs):
        let(x)
        let(z)
        x += 1
        y = 1
        if y == 1:
            y += 1
        else:
            x += 1
        return x, y


# Generated at 2022-06-12 04:41:33.372729
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_fn(x: int, y: int) -> None:
        let(x)
        extend(x)
        y += 1

    body = test_fn.get_body(
        x=[ast.parse("x = 1").body[0]],
        y=y
    )

    assert body == [
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='y', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        )
    ]

# Generated at 2022-06-12 04:41:38.272009
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 12
    y = 5
    def foo():
        let(x)
        x += y
        y += 2
        assert x == 17
        assert y == 7

    body = snippet(foo).get_body(y=5)
    ast.fix_missing_locations(body)
    exec_body = compile(ast.Module(body), '<snippet>', 'exec')
    exec(exec_body)

# Generated at 2022-06-12 04:41:46.267808
# Unit test for function extend_tree
def test_extend_tree():
    expected = ast.parse("""
    a = 1
    b = 2
    c = 3
    """)
    snippet = ast.parse("""
    extend(vars)
    """)
    for node in find(snippet, ast.Call):
        if isinstance(node.func, ast.Name) and node.func.id == 'extend':
            parent, index = get_non_exp_parent_and_index(snippet, node)
            replace_at(index, parent, [ast.parse("a = 1"), ast.parse("b = 2"), ast.parse("c = 3")])
            break
    assert ast.dump(snippet) == ast.dump(expected)

# Generated at 2022-06-12 04:41:59.372266
# Unit test for function extend_tree
def test_extend_tree():
    f = ast.parse("extend(vars); print(x, y)").body[0]
    assert str(f) == "extend(vars); print(x, y)"
    vars = ast.parse("x = 1; x = 2").body
    extend_tree(f, {'vars': vars})
    assert str(f) == "x = 1; x = 2\nprint(x, y)"

# Generated at 2022-06-12 04:42:06.905253
# Unit test for function extend_tree
def test_extend_tree():
    import pytest
    from textwrap import dedent

    body1 = dedent("""
        def f():
            x = 1
            y = 2""")
    body2 = dedent("""
        def f():
            x = 1
            y = 2""")
    tree1 = ast.parse(body1)
    tree2 = ast.parse(body2)
    extend_tree(tree1, {'extend_this': tree2})
    assert ast.dump(tree1) == ast.dump(tree2)

    body1 = dedent("""
        def f():
            x = 1
            z = 3""")
    body2 = dedent("""
        def f():
            x = 1
            y = 2""")
    tree1 = ast.parse(body1)

# Generated at 2022-06-12 04:42:10.633961
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
extend(vals)
a = 1
a = 2
""")

    vals = ast.parse("""
a = 1
a = 2
""").body  # type: ignore

    extend_tree(tree, {'vals': vals})

    assert ast.dump(tree) == ast.dump(vals)

# Generated at 2022-06-12 04:42:16.115328
# Unit test for function find_variables
def test_find_variables():
    source1 = """let(x)
        let()
    """
    tree = ast.parse(source1)
    variables = find_variables(tree)
    assert list(variables) == ['x']

    source2 = """let(x)
        let(y)
        let(x)
        x += 1
        let(x)
    """
    tree = ast.parse(source2)
    variables = find_variables(tree)
    assert list(variables) == ['x', 'y', 'x', 'x']

# Generated at 2022-06-12 04:42:21.206018
# Unit test for function extend_tree
def test_extend_tree():
    source = """
extend(vars)
print(x)
    """
    vars = [ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=1))]
    expected_source = """
x = 1
print(x)
    """

    tree = ast.parse(source)
    extend_tree(tree, {'vars': vars})
    assert expected_source == ast.unparse(tree)

# Generated at 2022-06-12 04:42:28.911224
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test1(a):
        let(x)
        x = 1
        x += a
        return x

    assert test1.get_body(a=1) == test1.get_body(a=1)

# Generated at 2022-06-12 04:42:37.325357
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test = snippet(lambda x: let(x) and extend(x) and extend(x))
    let_0, extend_0, extend_1 = test.get_body(x=[ast.parse(
        'x = 1').body[0], ast.parse('x = 2').body[0]], y=[
        ast.parse('y = 3').body[0], ast.parse('y = 4').body[0]])
    assert isinstance(let_0, ast.Assign)
    assert let_0.targets[0].id == '_py_backwards_x_0'
    assert let_0.value.id == 'x'
    assert isinstance(extend_0, ast.Assign)
    assert extend_0.targets[0].id == 'x'

# Generated at 2022-06-12 04:42:45.515161
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = """
    def let(var):
        pass
    def extend(var):
        pass

    def foo():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)
    """
    tree = ast.parse(source)
    var_map = find_variables(tree)
    VarGen = VariablesGenerator()
    for key in var_map:
        new_var = VarGen.generate(key)
        var_map[key] = new_var
    extend_tree(tree, var_map)
    VariablesReplacer.replace(tree, var_map)
    expect = """x += 1
y = 1
print(x, y)"""

# Generated at 2022-06-12 04:42:50.063605
# Unit test for function extend_tree
def test_extend_tree():
    import pytest
    from .helpers import bytecode_to_ast

    def test_func(*vars):
        extend(*vars)

    # test bad arguments
    with pytest.raises(TypeError):
        test_func(1)

    # test good argument
    test_func(bytecode_to_ast("x = 1"))



# Generated at 2022-06-12 04:42:56.533396
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nprint(x, y)')
    vars = ast.Module(body=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                       value=ast.Num(n=1))
                      ,ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                       value=ast.Num(n=2))])

    extend_tree(tree, {'vars': vars})
    assert ast.dump(vars) == ast.dump(tree)

# Generated at 2022-06-12 04:43:22.478807
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(a)
        extend(b)
        x = 1
    """)
    extend_tree(tree, {
        'a': [ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
              ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))],
        'b': [ast.Assign([ast.Name('y', ast.Store())], ast.Num(3)),
              ast.Assign([ast.Name('y', ast.Store())], ast.Num(4))]})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        y = 3
        y = 4
        x = 1
    """))

# Generated at 2022-06-12 04:43:25.289332
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        x += 1
        y = 1
    snippet_f = snippet(f)
    assert snippet_f.get_body() == ast.parse('_py_backwards_x_0 += 1\ny = 1').body

# Generated at 2022-06-12 04:43:26.208527
# Unit test for function extend_tree

# Generated at 2022-06-12 04:43:29.908224
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def some_snippet(x: int) -> int:
        let(y)
        let(z)
        return x + y - z

    tree = some_snippet.get_body(x=1, y=2, z=1)
    assert kall(tree, ast.BinOp) == 2



# Generated at 2022-06-12 04:43:37.262472
# Unit test for function extend_tree
def test_extend_tree():
    ast_tree = ast.parse('a = 1; extend(test_vars); b = 2')
    test_vars = ast.parse('x = 1').body
    extend_tree(ast_tree, {'test_vars': test_vars})
    assert ast_tree.body == [
        ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(1)),
        ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())], value=ast.Num(2)),
    ]



# Generated at 2022-06-12 04:43:38.046445
# Unit test for function extend_tree

# Generated at 2022-06-12 04:43:44.699397
# Unit test for function extend_tree
def test_extend_tree():
    variables: Dict[str, ast.AST] = {'x': ast.parse('x = 1').body[0]}

    tree = ast.parse(
        """
    extend(x)
    x = 2
    """
    )
    extend_tree(tree, variables)

    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Constant(value=1)), Assign(targets=[Name(id='x', ctx=Store())], value=Constant(value=2))])"



# Generated at 2022-06-12 04:43:52.800698
# Unit test for function extend_tree
def test_extend_tree():
    assert(str(ast.parse(
        """
        if True:
            extend(a1)

        if True:
            extend(a2)
        """).body[0].body[0]) ==
        """
        if True:
            x = 4
            x = 4
            x = 4
        """
    )

    assert(str(ast.parse(
        """
        if True:
            extend(a1)

            if True:
                extend(a2)
        """).body[0].body[0]) ==
        """
        if True:
            x = 4
            x = 4
            x = 4
            x = 4
            x = 4
            x = 4
        """
    )


# Generated at 2022-06-12 04:44:01.407317
# Unit test for function extend_tree
def test_extend_tree():
    # Global code
    def add_42_to(what: int) -> int:
        return what + 42

    # Code in snippet
    def make_add_42_to_lambda() -> Callable[[int], int]:
        extend(body)
        return lambda x: x + 42

    # What extend_tree should create
    def make_add_42_to_lambda2() -> Callable[[int], int]:
        return lambda x: x + 42 + add_42_to(42) + 1

    tree = ast.parse(get_source(add_42_to))
    body = tree.body[0].body
    new_tree = ast.parse(get_source(make_add_42_to_lambda))
    extend_tree(new_tree, {'body': body})

# Generated at 2022-06-12 04:44:05.544777
# Unit test for function extend_tree
def test_extend_tree():
    src = """
    x = 2
    y = 3
    extend(x)
    """
    tree = ast.parse(src)
    variables = dict()
    variables[ast.parse('x = 1').body[0].targets[0].id] = ast.parse('x = 1').body[0]
    extend_tree(tree, variables)
    assert(tree.body[0].value.n == 1)

# Generated at 2022-06-12 04:44:48.869567
# Unit test for function extend_tree
def test_extend_tree():
    import pytest
    from .test_helpers import assert_ast_equals

    tree = ast.parse("""
    extend(param)
    print("test")
    """)

    extend_tree(tree, {'param': [ast.Assign(targets=[ast.Name(id='x')],
                                            value=ast.Num(n=1)),
                                  ast.Assign(targets=[ast.Name(id='x')],
                                            value=ast.Num(n=2))
                                  ]})
    assert_ast_equals(tree, """
    x = 1
    x = 2
    print("test")
    """)



# Generated at 2022-06-12 04:44:56.791583
# Unit test for function extend_tree
def test_extend_tree():
    from .helpers import run_in_exec, run_eval

    # Test for extending with AST
    vars = ast.Expression(ast.List([ast.Assign(targets=[ast.Name(id='x')],
                                               value=ast.Num(n=1)),
                                    ast.Assign(targets=[ast.Name(id='x')],
                                               value=ast.Num(n=2))],
                                   ctx=ast.Load()))
    node = ast.parse('''if True:
                            extend(vars)
                            print(x)''')

    extend_tree(node, {'vars': vars})
    source = ast.fix_missing_locations(node).body[0].body
    assert run_eval(source) == 1

    # Test for extending

# Generated at 2022-06-12 04:45:01.358985
# Unit test for function extend_tree
def test_extend_tree():
    text = '''
x = 1
extend(vars)
print(x)
'''
    tree = ast.parse(text)
    vars = ast.parse('y = 1; x = 2;').body
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == '''\
x = 1
y = 1
x = 2
print(x)
'''



# Generated at 2022-06-12 04:45:05.954401
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1

    @snippet
    def test():
        let(x)
        extend(test_body)
        x += 2

    test_body.append(ast.Assign([ast.Name(id='x', ctx=ast.Store())],
                                ast.Num(n=2)))
    test.get_body()

    assert x == 3

# Generated at 2022-06-12 04:45:06.799798
# Unit test for function extend_tree

# Generated at 2022-06-12 04:45:14.705201
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # arrange
    source = "let(x)  x += 1  y = 1"
    tree = ast.parse(source)
    variables = {'x': '_py_backwards_x_0'}
    expected_body = ast.parse("""_py_backwards_x_0 += 1
y = 1""").body

    # act
    def snippet_test(x: int) -> None:
        let(x)
        x += 1
        y = 1

    body = snippet(snippet_test).get_body(x=1)

    # assert
    assert body == expected_body

# Generated at 2022-06-12 04:45:23.517680
# Unit test for function find_variables
def test_find_variables():
    import sys
    import os

    # For unit test this file must be imported as a module
    # But in order for this to work we need to append its path to the current working dir
    this_file_path = os.path.abspath(__file__)
    sys.path.append(os.path.dirname(this_file_path))

    from .test import find_variables as find_variables_test
    from .test.find_variables import A, B, C
    from .test import find_variables as find_variables_test
    if find_variables(A) == find_variables_test.A:
        print('All good')
    else:
        print(find_variables(A))
        print(find_variables_test.A)
        exit(1)
    

# Generated at 2022-06-12 04:45:32.130363
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:45:37.836249
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''
let(extending)
extend(extending)
    ''')
    variables = {'extending': [ast.parse('a = 1').body[0],
                               ast.parse('b = 2').body[0]]}
    extend_tree(tree, variables)
    assert ast.dump(tree) == ast.dump(
        ast.parse('''
a = 1
b = 2
'''))



# Generated at 2022-06-12 04:45:41.748379
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""let(vars)
            print(x, y)""")
    variables = {'vars': [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Constant(value=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Constant(value=2)
        )
    ]}
    extend_tree(tree, variables)
    assert get_source(tree) == """x = 1
x = 2
print(x, y)"""