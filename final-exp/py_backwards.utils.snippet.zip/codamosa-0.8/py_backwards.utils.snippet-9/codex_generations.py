

# Generated at 2022-06-12 04:36:39.180252
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import sys
    sys.stderr.write("""\
This file is a unittest for method visit_alias of class VariablesReplacer.
If this file cause any issues, it would mean that something is wrong in
this function.
If this is the case, please, report it to the upstream.
If this file causes no issues, you can delete it.
If you get an error that this test is missing, you should install the
python3-typed-ast package.\n""")
    import typing



# Generated at 2022-06-12 04:36:43.571590
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from typed_ast import ast3 as ast
    from .tree import dump_tree
    import sys
    import pathlib
    source = pathlib.Path(__file__).parent.joinpath('mod.py')
    tree = ast.parse(source.read_text())
    replaced = VariablesReplacer.replace(tree, {'foo': 'bar'})
    dump_tree(replaced, sys.stdout)

# Generated at 2022-06-12 04:36:47.602746
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import unittest

    import astor

    # vars = {'x': 'test'}

    # tree = ast.parse('from test import x')
    # VariablesReplacer.replace(tree, vars)

    # output = astor.to_source(tree)
    # expected = 'from test import test'
    # self.assertEquals(output, expected)

# Generated at 2022-06-12 04:36:56.920570
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 1
    b = 2
    c = 3
    d = 4
    e = 5
    f = 6

    @snippet
    def test(x: str, y: str, z: str, t: str, u: str) -> None:
        let(a)
        let(b)
        let(c)
        let(d)
        let(e)
        let(f)
        let(f)
        let(f)
        extend(x)
        extend(y)
        extend(z)
        extend(t)
        extend(u)

        if True:
            let(a)
            let(b)
            let(c)
            let(d)
            let(e)
            let(f)
            let(f)
            let(f)

# Generated at 2022-06-12 04:36:59.954410
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x)\nx += 1')
    variables = find_variables(tree)
    assert list(variables) == ['x']



# Generated at 2022-06-12 04:37:09.796687
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .snippet import snippet
    from .helpers import assert_ast_equal
    import sys

    @snippet
    def snippet():
        extend(vars)

    # Source from formatter.py of astor project

# Generated at 2022-06-12 04:37:14.968100
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("from foo import bar")
    variables = {"foo": "buzz"}
    tree = VariablesReplacer.replace(tree, variables)
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.ImportFrom)
    assert tree.body[0].module == "buzz"
    assert tree.body[0].names[0].name == "bar"

# Generated at 2022-06-12 04:37:23.133746
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    extend(vars)
    print(a, b)
    """
    expected = """
    x = 1
    x = 2
    print(a, b)
    """
    tree = ast.parse(source)
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                          value=ast.Num(1)),
                                ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                           value=ast.Num(2))]})
    assert ast.dump(tree, annotate_fields=False) == expected



# Generated at 2022-06-12 04:37:26.554544
# Unit test for function extend_tree
def test_extend_tree():
    node = ast.parse('a = 1')
    tree = ast.parse('extend(vars)\na = 0')
    extend_tree(tree, {'vars': node})
    assert ast.dump(tree) == ast.dump(node)



# Generated at 2022-06-12 04:37:32.539430
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(a: str,  b: int) -> int:
        let(x)
        return x * b
    snippet = snippet(fn)
    # 1 + 2*2 == 5
    body = snippet.get_body(x=1, b=2)
    assert len(body) == 1
    assert isinstance(body[0], ast.Return)
    assert isinstance(body[0].value, ast.BinOp)
    assert isinstance(body[0].value.op, ast.Mult)

# Generated at 2022-06-12 04:37:47.145369
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("x = 5; extend(values); y = 5")
    values = {'values': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                    value=ast.Num(n=2))]}
    extend_tree(tree, values)
    assert ast.dump(tree) == "Module([Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=5)), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2)), Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=5))])"

# Generated at 2022-06-12 04:37:54.405844
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse('''
from py_backwards.snippets import let, extend

let(x)
let(y)

extend(vars)
''')

    variables = {'x': VariablesGenerator.generate('x'),
                 'y': VariablesGenerator.generate('y'),
                 'vars': ast.parse('x = 1; x = 2;')}

    VariablesReplacer.replace(tree, variables)

    expected_tree = ast.parse('''
from py_backwards._py_backwards_snippets import let, extend

let(_py_backwards_x_0)
let(_py_backwards_y_1)

x = 1; x = 2;

''')

    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 04:38:03.861089
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet = snippet(lambda x, y, z: None)
    body = snippet.get_body(x=1, y=2)
    assert isinstance(body, list)
    assert isinstance(body[0], ast.Expr)
    assert isinstance(body[0].value, ast.Call)
    assert isinstance(body[0].value.func, ast.Name)
    assert body[0].value.func.id == 'let'
    assert len(body[0].value.args) == 2
    assert body[0].value.args[0].id == 'y'
    assert isinstance(body[1], ast.Assign)
    assert len(body[1].targets) == 1
    assert body[1].targets[0].id == '_py_backwards_y_0'

# Generated at 2022-06-12 04:38:13.802638
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import get_all_names, get_one_or_raise
    from astunparse import unparse
    from .helpers import substitute

    def snippet_test(*args, **kwargs):
        var = let(3)
        return x + var

    fn = snippet(snippet_test)
    body = fn.get_body()
    assert unparse(body) == 'return x + _py_backwards_var_0\n'

    x = 1
    parsed = substitute(fn.get_body()).body[0].body[0]
    assert unparse(parsed) == 'return x + 3\n'
    assert get_all_names(parsed) == ['x', '3']

    body = fn.get_body(var=3)

# Generated at 2022-06-12 04:38:18.057296
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def a(x):
        x = 1
        let(x)
        x += 1
    sn = snippet(a)
    tree = sn.get_body()
    assert tree == [ast.Assign([ast.Name(id = 'x', ctx = ast.Store())], ast.Num(n = 1)), ast.AugAssign(target = ast.Name(id = 'x', ctx = ast.AugLoad()), op = ast.Add(), value = ast.Num(n = 1))]

# Generated at 2022-06-12 04:38:24.374926
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def let_x():
        let(x)
        x += 1

    tree = snippet(let_x).get_body()
    assert ast.dump(tree[0]) == "Assign(targets=[Name(id='_py_backwards_x_0', ctx=Store())], value=BinOp(left=Name(id='_py_backwards_x_0', ctx=Load()), op=Add(), right=Num(n=1)))",\
        f"tree = snippet(let_x).get_body()\n{ast.dump(tree[0])}"

# Generated at 2022-06-12 04:38:25.893852
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    print("Testing visit_alias of VariablesReplacer")
    import astor

# Generated at 2022-06-12 04:38:30.378654
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    sample_ast = ast.parse(
        """
        from typing import List, Tuple
        """
    )
    variables = {
        'List': 'Sequence'
    }
    VariablesReplacer.replace(sample_ast, variables)
    assert ast.dump(sample_ast) == ast.dump(
        ast.parse(
            """
            from typing import Sequence, Tuple
            """
        )
    )

# Generated at 2022-06-12 04:38:38.510902
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_kwargs = {}

    assert snippet(lambda x, y: None).get_body(**snippet_kwargs) == \
           [ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())], ast.Name(id='x', ctx=ast.Load())),
            ast.Assign([ast.Name(id='_py_backwards_y_1', ctx=ast.Store())], ast.Name(id='y', ctx=ast.Load()))]

    snippet_kwargs = {'x': ast.Name(id='y', ctx=ast.Load())}


# Generated at 2022-06-12 04:38:46.713245
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from . import let, extend
    from .helpers import AssertVisitor

    @snippet
    def snip(a, b):
        let(x)
        y = 1
        extend(vars)
        y += 1
        return x + y

    assert vars(snip) == {'_fn': snip._fn}

    assert snip.get_body() == snip.get_body(a=0, b=0)


# Generated at 2022-06-12 04:39:01.372308
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    class AliasesTest(ast.NodeVisitor):
        test_dunder = '__init__'
        def visit_alias(self, node):
            self.test_dunder = node.name
    
    from_info = ast.alias(name = '__init__', asname = None)
    from_info = VariablesReplacer.replace(from_info, {'__init__': '__init__'})
    AliasTest = AliasesTest()
    AliasTest.visit(from_info)
    assert AliasTest.test_dunder == '__init__'

# Generated at 2022-06-12 04:39:04.578210
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from astor import to_source
    alias = ast.alias(name="jaws", asname="x")
    variables = {"jaws": "y"}
    VariablesReplacer.replace(alias, variables)
    assert to_source(alias) == "alias(name='y', asname=None)"


# Generated at 2022-06-12 04:39:13.075141
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: float) -> None:
        let(y)
        x += y
        x += 1
        y += x

    lst = test.get_body(x=1)
    assert len(lst) == 6
    assert isinstance(lst[0], ast.Assign)
    assert isinstance(lst[0].targets[0], ast.Name)
    assert lst[0].targets[0].id == '_py_backwards_y_0'
    assert isinstance(lst[0].value, ast.Call)
    assert lst[0].value.args[0].id == '_py_backwards_x_0'
    assert isinstance(lst[1], ast.Assign)

# Generated at 2022-06-12 04:39:19.478584
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .tree import get_tree
    class A:
        @snippet
        def f():
            let(a)

# Generated at 2022-06-12 04:39:23.854403
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    z = x + y
    print(z)
    """
    tree = ast.parse(source)
    variables = list(find_variables(tree))
    assert len(variables) == 2
    assert variables[0] == 'x'
    assert variables[1] == 'y'
    assert get_source(tree) == """
    z = x + y
    print(z)
    """



# Generated at 2022-06-12 04:39:29.225511
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = 'from a.b import x'
    tree = ast.parse(source)
    source = 'from a.b.c import x'
    expected_tree = ast.parse(source)
    replacer = VariablesReplacer({'b': 'b.c'})
    result = replacer.visit_alias(tree.body[0].names[0])
    assert result == expected_tree.body[0].names[0]

# Generated at 2022-06-12 04:39:35.287889
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet():
        let(x)
        x += 1
        let(y)
        y -= 1

    variables = test_snippet.get_body()
    assert len(variables) == 2
    assert isinstance(variables[0], ast.AugAssign)
    assert isinstance(variables[1], ast.AugAssign)
    assert variables[0].target.id == '_py_backwards_x_0'
    assert variables[1].target.id == '_py_backwards_y_0'



# Generated at 2022-06-12 04:39:39.113686
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .typed_ast_to_python import to_python
    @snippet
    def fn():
        let(x)
        x += 1
        y = 1
    body = fn.get_body()
    assert to_python(body) == "x += 1\ny = 1"



# Generated at 2022-06-12 04:39:47.199380
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(name: str, age: int):
        let(name)
        let(age)
        let(age2)
        let(x)
        extend(x)
        return name, age

    x = ast.Assign(targets=[
        ast.Name(id='x'),
    ], value=ast.Num(1))
    body = fn.get_body(name='john', age=20, x=x)
    assert len(body) == 3
    assert body[0].targets[0].id == 'x'
    assert body[1].value.right.value == 1
    assert body[1].value.left.id == '_py_backwards_age2_0'

# Generated at 2022-06-12 04:39:54.856662
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def get_var(x: int) -> int:
        let(y)
        return y

    tree = snippet(get_var).get_body(y=1)
    assert len(tree) == 1
    assert isinstance(tree[0], ast.Assign)
    assert len(tree[0].targets) == 1
    assert isinstance(tree[0].targets[0], ast.Name)
    assert tree[0].targets[0].id == '_py_backwards_y_0'
    assert isinstance(tree[0].value, ast.Constant)
    assert tree[0].value.value == 1

# Generated at 2022-06-12 04:40:16.751758
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x: int) -> int:
        let(y)
        return y + x

    assert snippet(f).get_body(x=1) == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_y_1', ctx=ast.Store())],
            value=ast.Num(n=0)
        ),
        ast.Return(
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_y_1', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        )
    ]

# Generated at 2022-06-12 04:40:25.348591
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    class VariablesReplacer(ast.NodeTransformer):
        """Replaces declared variables with unique names."""
        def __init__(self, variables: Dict[str, Variable]) -> None:
            self._variables = variables
        def _replace_field_or_node(self, node: T, field: str, all_types=False) -> T:
            value = getattr(node, field, None)
            if value in self._variables:
                if isinstance(self._variables[value], str):
                    setattr(node, field, self._variables[value])
                elif all_types or isinstance(self._variables[value], type(node)):
                    node = self._variables[value]  # type: ignore
            return node

# Generated at 2022-06-12 04:40:29.957884
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # pylint: disable=too-few-public-methods
    @snippet
    def body(x: int) -> int:
        let(y)
        return x + y

    assert body.get_body(y=0) == [ast.Return(ast.BinOp(ast.Name('x'), ast.Add(), ast.Name('_py_backwards_y_0')))]



# Generated at 2022-06-12 04:40:36.270285
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(): # pylint: disable=function-redefined
        let(x)
        x += 1
        y = 1

    class Test:
        @staticmethod
        @snippet
        def test_snippet(x):
            let(y)
            x = 0
            y = 1
            return y

    assert Test.test_snippet.get_body(x=1) == test_fn.__code__.co_consts[0]

# Generated at 2022-06-12 04:40:44.536185
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test set of the assignments
    @snippet
    def snippet1(a, b, c):
        let(a, b, c)
        a = 1
        b = 2
        c = 3
    
    body = snippet1.get_body()
    assert body[0].value.left.id == '_py_backwards_a_0'
    assert body[0].value.right.n == 1
    assert body[1].value.left.id == '_py_backwards_b_0'
    assert body[1].value.right.n == 2
    assert body[2].value.left.id == '_py_backwards_c_0'
    assert body[2].value.right.n == 3
    
    # Test set of the function calls

# Generated at 2022-06-12 04:40:51.784474
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var = 3

    @snippet
    def _fn():
        let(a)
        b = a + 1
        let(c)
        d = c + 1
        c -= 1

    body = _fn.get_body(a=var, c=var, e=var)
    assert all(isinstance(node, ast.Assign) for node in body)
    assert all(isinstance(node.value, ast.BinOp) for node in body)
    assert all((node.value.left.id == '_py_backwards_a_0'
                or node.value.left.id == '_py_backwards_c_0') for node in body)



# Generated at 2022-06-12 04:40:56.433195
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet = snippet(lambda x : x + 1)
    body = snippet.get_body(x = 1)
    assert(body == [[ast.Return(value = ast.BinOp(left = ast.Constant(value = 1, kind = None),
                                                 op = ast.Add(),
                                                 right = ast.Constant(value = 1, kind = None)))]])

test_snippet_get_body()

# Generated at 2022-06-12 04:41:04.600426
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def a():
        let(x)
        let(y)
        z = x + y

    a_snippet = snippet(a)
    res = a_snippet.get_body()

    assert len(res) == 2

    assert isinstance(res[0], ast.Expr)
    assert isinstance(res[0].value, ast.BinOp)
    assert isinstance(res[0].value.left, ast.Name)
    assert isinstance(res[0].value.left.ctx, ast.Load)
    assert res[0].value.left.id == '_py_backwards_x_0'

    assert isinstance(res[0].value.right, ast.Name)
    assert isinstance(res[0].value.right.ctx, ast.Load)
    assert res[0].value

# Generated at 2022-06-12 04:41:12.601919
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""extend(vars)
                        print(a)""")
    variables = {
        "vars": [
            ast.Assign(
                targets=[ast.Name(id='a', ctx=ast.Store())],
                value=ast.Num(n=1)
            ),
            ast.Assign(
                targets=[ast.Name(id='a', ctx=ast.Store())],
                value=ast.Num(n=2)
            )
        ]
    }
    extend_tree(tree, variables)

# Generated at 2022-06-12 04:41:20.613252
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import pytest
    @snippet
    def f():
        let(x)  # noqa: F841
        let(y)  # noqa: F841
        return y

    class InsertToCode(ast.NodeTransformer):
        """Inserts code after
        """

        def __init__(self, line_to_insert: int, insert_code: ast.AST) -> None:
            self.insert_code = insert_code
            self.line_to_insert = line_to_insert

        def visit_Expr(self, node: ast.Expr) -> ast.Expr:
            if getattr(node, 'lineno', 0) >= self.line_to_insert:
                return None

            return self.generic_visit(node)


# Generated at 2022-06-12 04:42:37.738726
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def a(a: let, b: let):
        a += 1
        b += 1

    assert(str(a.get_body()) == str(
        ast.parse('_py_backwards_a_0 += 1\n_py_backwards_b_0 += 1\n')))

    @snippet
    def a(a: extend, b: let):
        print(a)
        b += 1

    assert(str(a.get_body(b=2)) == str(
        ast.parse('b = 2\nx = 1\nx = 2\nprint(a)\n')))

# Generated at 2022-06-12 04:42:44.389523
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import make_module
    from .printer import print_ast

    def test_fn(x: int, y: int) -> int:
        a = x
        b = y
        print(x, y)
        let(a)
        a += 1
        return a + b

    source = get_source(test_fn)
    tree = ast.parse(source)

    snippet_fn = snippet(test_fn)

    module = make_module(snippet_fn.get_body(x=2, y=2))
    print_ast(module)


# Generated at 2022-06-12 04:42:53.123372
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def s() -> None:
        let(x)
        x += 1
        y = 1

    def s2() -> None:
        let(x)
        x += 1
        let(z)
        y = 1

    def s3() -> None:
        let(x)
        x += 1
        y = 1
        x -= 1

    def s4() -> None:
        extend(vars)
        print(x, y)

    def s5() -> None:
        let(x)
        extend(vars)
        print(x, y)

    class A(ast.AST):
        _fields = ()

    class B(ast.AST):
        _fields = ()

    @snippet
    def s0() -> None:
        let(x)
        x += 1
        y = 1

# Generated at 2022-06-12 04:42:55.177470
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def instance_fn():
        let(x)
        x = 0
    Snippet = snippet(instance_fn)
    assert len(Snippet.get_body()) == 2

# Generated at 2022-06-12 04:43:04.372065
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: let(x)).get_body() == []
    assert snippet(lambda x: let(x) and let(y)).get_body() == []
    assert snippet(lambda x: let(x) and x+2).get_body() == [ast.Expr(value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0'), op=ast.Add(), right=ast.Num(n=2)))]
    x = ast.Name(id='x')
    assert snippet(lambda x: let(x) and x + 2).get_body(x=x) == [ast.Expr(value=ast.BinOp(left=ast.Name(id='x'), op=ast.Add(), right=ast.Num(n=2)))]

# Generated at 2022-06-12 04:43:08.055494
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    s = snippet(lambda x: x + 1)
    res = s.get_body()
    assert isinstance(res, list)
    assert isinstance(res[0], ast.Assign)


if __name__ == '__main__':
    test_snippet_get_body()

# Generated at 2022-06-12 04:43:11.542831
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _snippet():
        let(x)
        x = 2

    s = snippet(_snippet)
    body = s.get_body(x=1)
    assert len(body) == 1
    assert isinstance(body[0], ast.Assign)



# Generated at 2022-06-12 04:43:15.403544
# Unit test for function find_variables
def test_find_variables():
    fn = snippet(lambda a, b, c: 1)
    fn_source = get_source(fn._fn)
    result = fn.get_body(a=1, c=2)
    print(ast.dump(ast.Module(result)))
    assert fn_source == get_source(result)

# Generated at 2022-06-12 04:43:22.301932
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _snippet(x, y):
        extend(vars)
        let(x)
        x += 1
        y += 1
        return x, y

    vars = [ast.parse('z = 1'), ast.parse('z = 2')]
    snippet_instance = snippet(_snippet)
    expected_body = ast.parse('_py_backwards_x_0 += 1\ny += 1\nreturn _py_backwards_x_0, y').body
    assert snippet_instance.get_body(vars=vars, x=ast.Name(id='_x'), y=ast.Name(id='_y')) == expected_body

# Generated at 2022-06-12 04:43:27.674758
# Unit test for function extend_tree
def test_extend_tree():
    extension = [
        ast.Assign(
            [ast.Name(id='x', ctx=ast.Store())], ast.Num(1)
        ),
        ast.Assign(
            [ast.Name(id='x', ctx=ast.Store())], ast.Num(2)
        ),
    ]
    tree = ast.parse('x = 3')
    extend_tree(tree, {'vars': extension})
    assert get_source(tree) == 'x = 1\nx = 2\nx = 3'

# Generated at 2022-06-12 04:44:20.047349
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: int, y: int) -> x.__add__(y):
        pass

    fn_body = test.get_body(x=10, y=1)
    assert fn_body[0].value.left.n == 10  # type: ignore
    assert fn_body[0].value.right.n == 1  # type: ignore

# Generated at 2022-06-12 04:44:24.879217
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""extend(vars)
x = 1
x += 1""")

    vars = {"vars": ast.parse("""x = 1
x = 2""").body}

    extend_tree(tree, vars)

    assert get_source(tree) == """x = 1
x = 2
x += 1"""

# Generated at 2022-06-12 04:44:31.698315
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    times = 1
    real_snippet = snippet(lambda a, b: (a ** b - 1) ** (1 / b))
    assert len(real_snippet.get_body(a=1, b=2)) == 3
    assert len(real_snippet.get_body(a=1, b=2)) == 3
    assert len(real_snippet.get_body(a=1, b=2)) == 3
    with pytest.raises(NameError):
        assert real_snippet.get_body(a=1, b=2) == [[{'a': 1, 'b': 2, 'x': 1, 'y': 2, 'times': 1}]]

# Generated at 2022-06-12 04:44:35.493582
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    def f():
        extend(a)
    """)
    a = ast.parse("""
    print(42)
    """)
    extend_tree(tree, {'a': a})
    assert ast_to_source(tree) == """
    def f():
        print(42)
    """


# Generated at 2022-06-12 04:44:36.228190
# Unit test for function extend_tree

# Generated at 2022-06-12 04:44:45.014391
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Test snippet.get_body()"""
    
    def var1_fn():
        var1 = 1
        var1 += 1
        print(var1)

    var1_body = snippet(var1_fn).get_body()
    
    # var1 += 1
    assert type(var1_body[0]) == ast.AugAssign
    assert type(var1_body[0].target) == ast.Name
    assert var1_body[0].target.id == '_py_backwards_var1_0'
    
    # var1 = 1
    assert type(var1_body[-1]) == ast.Assign
    assert type(var1_body[-1].targets[0]) == ast.Name

# Generated at 2022-06-12 04:44:48.215886
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def get_body(x: int) -> ast.AST:
        let(x)
        return x + 1

    source = get_source(get_body)
    assert source == 'def get_body(x):\n    let(x)\n    return x + 1'

# Generated at 2022-06-12 04:44:56.008104
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(a: int, b: float, c: float) -> None:
        """
        def fn(a, b):
            return a + b

        fn(1, 2)
        """
        let(a)
        let(b)
        let(c)

        extend(a)
        extend(b)

    snippet_ = snippet(snippet_fn)
    a = ast.parse('x = 1').body[0]
    b = ast.parse('x = 2').body[0]
    body = snippet_.get_body(a=a, b=b, c=c)

# Generated at 2022-06-12 04:44:59.066319
# Unit test for function find_variables
def test_find_variables():
    source = """x = 1
    y = 2
    let(z)
    let(u)
    v = 3
    let(w)"""

    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['z', 'u', 'w']

# Generated at 2022-06-12 04:45:07.678304
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x: int, y: int) -> None:
        let(x)
        x += 1
        z = x + y
        return z

    result = snippet(fn).get_body(x=1, y=2)