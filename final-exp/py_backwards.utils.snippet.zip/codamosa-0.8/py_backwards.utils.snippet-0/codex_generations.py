

# Generated at 2022-06-12 04:36:24.252903
# Unit test for function find_variables

# Generated at 2022-06-12 04:36:29.089452
# Unit test for function extend_tree
def test_extend_tree():
    var = ast.parse('x = 1\nx = 2').body
    tree = ast.parse('extend(x)\nprint(x, y)')
    extend_tree(tree, {'x': var})
    assert VariablesReplacer.replace(tree, {}).body[0].body == [ast.Expr(var[1]), ast.Expr(ast.Call(ast.Name('print', ast.Load()), [ast.Name('x', ast.Load()), ast.Name('y', ast.Load())], [], None, None))]

# Generated at 2022-06-12 04:36:34.251600
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
extend(vars)
print(x, y)
""")
    vars = ast.parse("""
x = 1
x = 2
""")

    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
x = 1
x = 2
print(x, y)
"""))

# Generated at 2022-06-12 04:36:40.670454
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = inspect.getsource(test_snippet_get_body)
    tree = ast.parse(source)
    snippet_body = tree.body[1:]
    var = 'x'
    variables = find_variables(tree)
    assert var in variables
    variables = {'x': 'yyyy'}
    extend_tree(tree, variables)
    assert len(tree.body[1].body) == 2
    # VariablesReplacer.replace(tree, variables)
    # snippet_body = VariablesReplacer.replace(snippet_body, variables)
    assert snippet_body == [let(var), var + '+=1', 'y=1']

# Generated at 2022-06-12 04:36:44.533554
# Unit test for function find_variables
def test_find_variables():
    source = '''
    def fn():
        let(fn1)
        let(fn2)
        print(fn1, fn2)
    '''

    tree = ast.parse(source)
    variables = find_variables(tree)
    assert list(variables) == ['fn1', 'fn2']



# Generated at 2022-06-12 04:36:48.900188
# Unit test for function find_variables
def test_find_variables():
    from .testing import assert_equal

    source = '''
    let(x)
    let(y)
    
    if x == y:
        pass
    '''

    tree = ast.parse(source)
    names = list(find_variables(tree))

    assert_equal(names, ['x', 'y'])



# Generated at 2022-06-12 04:36:49.753534
# Unit test for function extend_tree

# Generated at 2022-06-12 04:36:54.903942
# Unit test for function find_variables
def test_find_variables():
    from .helpers import get_ast

    test_tree = get_ast("""
        let(a)
        x = a
        fun()
            let(b)
            c = b
        let(d)
        let(e)
        x = d
        x = e
    """)
    assert set(find_variables(test_tree)) == {'a', 'b', 'd', 'e'}



# Generated at 2022-06-12 04:37:00.032301
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1

    snippet_obj = snippet(fn)
    assert len(snippet_obj.get_body()) == 1
    assert isinstance(snippet_obj.get_body()[0], ast.AugAssign)
    assert snippet_obj.get_body()[0].value.n == 1



# Generated at 2022-06-12 04:37:06.015116
# Unit test for function extend_tree
def test_extend_tree():
    # test case
    func = snippet(lambda: extend(vars))
    func.get_body(vars=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                   value=ast.Constant(value=1, kind=None)),
                       ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                  value=ast.Constant(value=2, kind=None))])


# Generated at 2022-06-12 04:37:22.266227
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_code(x, y, z):
        let(var)
        var += 1
        y = 1
        extend(vars)

    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]

    snippet_body = snippet(snippet_code).get_body(var=ast.Name(id='var',
                                                              ctx=ast.Store()),
                                                  vars=vars)


# Generated at 2022-06-12 04:37:31.096842
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int) -> int:
        let(y)
        y = x + 1
        return y

    o = snippet(test_snippet)
    body = o.get_body(x=10)
    assert body == [
        ast.Assign(
            targets=[
                ast.Name(id='y', ctx=ast.Store())
            ],
            value=ast.BinOp(
                left=ast.Num(n=10),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Return(
            value=ast.Name(id='y', ctx=ast.Load())
        )
    ]



# Generated at 2022-06-12 04:37:34.020856
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    # Let's make some changes
    x = 12
    y = 13
    """)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-12 04:37:37.841087
# Unit test for function find_variables
def test_find_variables():
    """Finds variables in AST of code."""
    tree = ast.parse("""
        let(x)
        print(x)
        let(y)
    """)

    assert next(find_variables(tree)) == 'x'
    assert next(find_variables(tree)) == 'y'
    assert list(find_variables(tree)) == []



# Generated at 2022-06-12 04:37:41.010608
# Unit test for function find_variables
def test_find_variables():
    source = """
        let(x)
        let(y)
        x = 1
    """

    tree = ast.parse(source)
    res = find_variables(tree)
    expected = ['x', 'y']

    assert list(res) == expected



# Generated at 2022-06-12 04:37:44.759135
# Unit test for function find_variables
def test_find_variables():
    source = 'let(x)\nlet(y)'
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert sorted(list(variables)) == ['x', 'y']



# Generated at 2022-06-12 04:37:49.822499
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    arr = []

    @snippet
    def foo(x: int, y: int) -> None:
        let(arr)
        extend(arr)
        arr.append(x + y)
        arr.append(x - y)

    foo.get_body(x=1, y=2)
    assert arr == [3, -1]

# Generated at 2022-06-12 04:37:52.919283
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(a, b, c=None):
        let(a)
        a += 1  # noqa
        b.append(c)  # noqa

    snp = snippet(fn)
    assert isinstance(snp.get_body(a=1, b=2, c=3), list)

# Generated at 2022-06-12 04:37:54.961326
# Unit test for function find_variables
def test_find_variables():
    source = """let(x)
x = 1
x = 2
"""
    assert set(find_variables(ast.parse(source))) == {'x'}



# Generated at 2022-06-12 04:37:57.087485
# Unit test for function find_variables
def test_find_variables():
    def _test(a, b):
        let(x)

    assert _test('a', 'b') == []



# Generated at 2022-06-12 04:38:02.808416
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def pure_snippet(x: int) -> int:
        let(y)
        y = x * 2  # some side effects here
        return y
    

# Generated at 2022-06-12 04:38:12.875294
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x = 1
        y = 2
        z = x + y
    expected = [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=1)), ast.Assign([ast.Name(id='y', ctx=ast.Store())], ast.Num(n=2)), ast.Assign([ast.Name(id='z', ctx=ast.Store())], ast.BinOp(left=ast.Name(id='x', ctx=ast.Load()), op=ast.Add(), right=ast.Name(id='y', ctx=ast.Load())))]
    result = snippet(fn).get_body()
    assert result[0].__class__ == expected[0].__class__  
    assert result[1].__

# Generated at 2022-06-12 04:38:19.216449
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:38:28.156250
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test(x):
        let(x)
        x += 1
        y = 1
        extend(z)

    tree = snippet(test).get_body(x=ast.Name(id='a'), z=ast.parse("a = 1").body[0])

# Generated at 2022-06-12 04:38:33.274836
# Unit test for function extend_tree
def test_extend_tree():
    assert extend_tree(ast.parse("""extend(12)"""), {}) == None
    assert ast.dump(extend_tree(ast.parse("""extend({"x": 1})"""), {})) == ast.dump(ast.parse("""1"""))
    assert ast.dump(extend_tree(ast.parse("""extend({"x": 1, "y": 2})"""), {})) == ast.dump(ast.parse("""1\n2"""))


# Generated at 2022-06-12 04:38:34.830178
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast as ast
    import inspect

    import pytest
    from py_backwards.tree import replace_at


# Generated at 2022-06-12 04:38:39.463810
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast
    from .compile import compile_to_module
    from .run import run

    def foo():
        let(x)
        x = 1

    m = compile_to_module(foo)

    my_module = compile_to_module(foo)
    assert run({'x': m.x}) == {'x': 1}

    snippet1 = snippet(foo)

# Generated at 2022-06-12 04:38:48.113462
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn() -> None:
        let(var)
        var = 1
        let(vars)
        extend(vars)
        extend(vars)
        extend(vars)
        var = 2
        var = 3
        var = 4

    snip = snippet(fn)
    extract_var = ast.parse('var').body[0]  # type: ignore
    extract_vars = ast.parse('var = 1').body[0]  # type: ignore

    body_nokwargs = snip.get_body()
    assert body_nokwargs == [extract_var, extract_vars]
    body_kwargs = snip.get_body(vars=[extract_vars, extract_vars, extract_vars,
                                      extract_vars, extract_vars])


# Generated at 2022-06-12 04:38:52.019880
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    let(y)
    def foo():
        let(z)
        x += 1
        y += 1
        z += 1
    '''
    tree = ast.parse(source)
    variables = list(find_variables(tree))
    assert set(variables) == {'x', 'y', 'z'}



# Generated at 2022-06-12 04:39:01.087844
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import pytest
    test_class_body = ast.parse("""x = 5
x += 1
y = 5
y += 1
y = 5
y += 1
y += 1
y = 5
y = 5""").body[0].body

    def test():
        let(x)
        let(y)
        x += 1
        y += 1
        y = 5
        y += 1

    @snippet
    def new_name_var_code():
        let(x)
        x += 1

    @snippet
    def two_var_code():
        let(x)
        let(y)
        x += 1
        y += 1

    @snippet
    def four_var_code():
        let(x)
        let(y)
        x += 1
        y += 1


# Generated at 2022-06-12 04:39:11.285597
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def method():
        let(x)
        x += 1
        y = 1

    assert method.get_body().body == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)),
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1),
        )
    ]

# Generated at 2022-06-12 04:39:16.749222
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo():
        let(x)
        x += 1

    snippet_ = snippet(foo)
    body = snippet_.get_body()
    assert isinstance(body[0], ast.Assign)
    body_assign_target = body[0].targets[0]
    assert isinstance(body_assign_target, ast.Name)
    assert body_assign_target.id == '_py_backwards_x_0'

# Generated at 2022-06-12 04:39:23.656076
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x: int) -> int:
        let(y)
        y += 1
        let(z)
        z = x + 1
        return z

    tree = snippet(f).get_body()
    assert tree[0].targets[0].id == '_py_backwards_y_0'
    assert tree[1].value.left.id == '_py_backwards_y_0'
    assert tree[1].value.op.__class__.__name__ == 'Add'
    assert tree[2].targets[0].id == '_py_backwards_z_0'
    assert tree[3].value.left.id == 'x'
    assert tree[3].value.op.__class__.__name__ == 'Add'

# Generated at 2022-06-12 04:39:25.151188
# Unit test for function extend_tree

# Generated at 2022-06-12 04:39:26.188764
# Unit test for method get_body of class snippet

# Generated at 2022-06-12 04:39:32.754331
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_test(a: int) -> int:
        a = 1
        let(b)
        if b:
            let(c)
            c = 2
        else:
            extend(c)
        return a

    assert snippet_test.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_c_2', ctx=ast.Store())],
            value=ast.Num(n=2)
        ),
        ast.Return(value=ast.Num(n=1))
    ]

# Generated at 2022-06-12 04:39:33.920139
# Unit test for function extend_tree

# Generated at 2022-06-12 04:39:39.237408
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: x).get_body(x=5) == [ast.Expr(value=ast.Num(20))]
    assert snippet(lambda x, y: x).get_body(x=5, y=7) == [ast.Expr(value=ast.Num(20))]
    assert snippet(lambda w: w).get_body(y=5, x=7) == [ast.Expr(value=ast.Num(20))]



# Generated at 2022-06-12 04:39:41.381914
# Unit test for function find_variables
def test_find_variables():
    def a():
        let(1)
        let(2)

    assert find_variables(ast.parse(get_source(a))) == ['1', '2']



# Generated at 2022-06-12 04:39:44.902985
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .monkey_patch import monkey_patch
    monkey_patch()

    def foo(a):
        let(res)
        if a > 0:
            res = 0
        else:
            res = -1
        return res

    snippet_(foo).get_body()

# Generated at 2022-06-12 04:39:51.714161
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    tree = snippet(
        lambda: let(x)
    ).get_body()
    assert get_source(tree) == "_py_backwards_x_0"



# Generated at 2022-06-12 04:40:01.229260
# Unit test for function find_variables
def test_find_variables():
    code = """
let(a)
let(b)
let(c)
let(d)
let(e)
let(f)
let(g)
let(h)
let(i)
let(j)
let(k)
let(l)
let(m)
let(n)
let(o)
let(p)
let(q)
let(r)
let(s)
let(t)
let(u)
let(v)
let(w)
let(x)
let(y)
let(z)
"""
    tree = ast.parse(code)

# Generated at 2022-06-12 04:40:09.959198
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # noinspection PyPep8Naming
    def __pysnippet(x: int, m: str,
                    y: int = let(100),  # noqa
                    z: str = let('hello'),  # noqa
                    extend_vars: List[ast.AST] = extend([])) -> int:  # noqa
        extend_vars.extend([ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                       value=ast.Num(n=1)),
                            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                       value=ast.Num(n=2))])
        print(x, y)
        return x + y + int(z)
    __pysnippet

# Generated at 2022-06-12 04:40:12.664948
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(x)
let(y)
x = y
    """)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-12 04:40:21.309834
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .pyintercept import pyintercept
    from .ast_builder import assign, expr


# Generated at 2022-06-12 04:40:26.036562
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def x():
        let(y)
        x = y + 1
        return x
    tree = snippet(x).get_body()
    assert ast.dump(tree[0]).strip() == "Assign(targets=[Name(_py_backwards_y_0, Store())], value=Num(1))"
    assert ast.dump(tree[1]).strip() == "Return(value=BinOp(left=Name(_py_backwards_y_0, Load()), op=Add(), right=Num(1)))"



# Generated at 2022-06-12 04:40:35.768700
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Implementation of method __init__ of class snippet
    # Get the name of the current file
    filename = inspect.getframeinfo(inspect.currentframe()).filename
    # Find the position of 'test' in the path ( to exclude all the path before )
    position_of_test = filename.find('test')
    # Get only the path of the folder containing test and not the path of the current test
    main_path = filename[:position_of_test]
    # Get the path of the example
    example_path = path.join(main_path, 'examples')
    sys.path.append(example_path)
    from test_snippet_get_body import f

    result = f(1)
    snippet_f = snippet(f)
    result_2 = snippet_f.get_body(x=1)


# Generated at 2022-06-12 04:40:40.700306
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x,y,z: let(x)).get_body() == [ast.Pass()]
    assert snippet(lambda x,y,z: let(y)).get_body() == [ast.Pass()]
    assert snippet(lambda x,y,z: let(z)).get_body() == [ast.Pass()]



# Generated at 2022-06-12 04:40:43.596654
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    def let(x):
        pass
    """

    tree = ast.parse(source)
    variables = list(find_variables(tree))
    assert variables == ['x', 'y']



# Generated at 2022-06-12 04:40:51.826088
# Unit test for function extend_tree
def test_extend_tree():
    """
    Check that correct code will be generated for
    simple example
    """
    tree = ast.parse(''.join([
        'extend(vars)',
        'print(x, y)',
    ]))
    vars = [
        ast.Assign(
                targets=[ast.Name(id="x", ctx=ast.Store())],
                value=ast.Name(id="1", ctx=ast.Load())),
        ast.Assign(
                targets=[ast.Name(id="x", ctx=ast.Store())],
                value=ast.Name(id="2", ctx=ast.Load())),
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-12 04:41:07.531222
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet(x: int, y: int):
        let(x)
        x += 1
        y = 1

    vars = test_snippet.get_body(x=1)
    assert vars == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                               ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()), ast.Add(), ast.Num(1))),
                     ast.Assign([ast.Name('y', ast.Store())], ast.Num(1))]

# Generated at 2022-06-12 04:41:13.329251
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('print(x)')
    snippet._extend_tree(tree, {
        'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                            value=ast.Num(n=1))]
    })
    assert ast.dump(tree) == \
        "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Print(dest=None, values=[Name(id='x', ctx=Load())], nl=True)])"



# Generated at 2022-06-12 04:41:21.415630
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    tree = ast.parse("def f(a,b,c): return a+b-c")
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='f', args=arguments(args=[arg(arg='a', annotation=None), arg(arg='b', annotation=None), arg(arg='c', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=BinOp(left=BinOp(left=Name(id='a', ctx=Load()), op=Add(), right=Name(id='b', ctx=Load())), op=Sub(), right=Name(id='c', ctx=Load())))], decorator_list=[], returns=None)])"

# Generated at 2022-06-12 04:41:22.286867
# Unit test for function extend_tree

# Generated at 2022-06-12 04:41:31.092822
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 2
    y = 3
    z = 4

    def test():
        let(x)
        x += 1
        y = 1
        extend(y)
        z = x + y

    result = snippet(test).get_body()

# Generated at 2022-06-12 04:41:39.207676
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    with_globals = snippet(test_snippet_get_body)

    def my_function():
        x = 5
        y = 7
        z = 2

    def your_function():
        x = 10
        x = 20
        z = 0

    res = with_globals.get_body(__func__=ast.parse(get_source(my_function))
                                .body[0])

    assert get_source(my_function) == get_source(res)

    res = with_globals.get_body(__func__=ast.parse(get_source(your_function))
                                .body[0])

    assert get_source(your_function) == get_source(res)

# Generated at 2022-06-12 04:41:47.063745
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(x: ast.Name, y: ast.Name):
        let(x)
        x += 1
        y = 1

    body = fn.get_body(x=ast.Name('_x_', ast.Load()), y=ast.Name('_y_', ast.Load()))
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[0].value, ast.Name)
    assert body[0].value.id == '_x_'
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[1].value, ast.Name)
    assert body[1].value.id == '_y_'

# Generated at 2022-06-12 04:41:51.895215
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x = 1
    def func():
        let(y)
        y = 2
        def nested():
            let(z)
            z = 3
        extend(func2)
    """
    tree = ast.parse(source)
    variables = set(find_variables(tree))
    assert variables == {'x', 'y', 'z'}

# Generated at 2022-06-12 04:41:53.068891
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snip = snippet(None)
    snip.get_body()



# Generated at 2022-06-12 04:42:01.730175
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x: int, y: int) -> int:
        extend(vars)
        let(z)
        return z

    vars = [ast.Assign([ast.Name(id='z', ctx=ast.Store())], ast.Num(3))]
    variables = {'x': 1, 'y': 2}

    snippet_instance = snippet(f)
    body = snippet_instance.get_body(**variables)

    assert len(body) == 2
    assert isinstance(body[0], ast.Expr)
    assert isinstance(body[0].value, ast.Call)
    assert isinstance(body[0].value.func, ast.Name)
    assert body[0].value.func.id == 'vars'

    assert isinstance(body[1], ast.Return)

# Generated at 2022-06-12 04:42:25.215019
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def s():
        let(x)
        x += 1
        y = 1
    body = s.get_body()
    assert(len(body) == 2)
    assert(get_source(body[0]) == '_py_backwards_x_0 += 1')
    assert(get_source(body[1]) == 'y = 1')


# Generated at 2022-06-12 04:42:31.188597
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """It tests the get_body method of the snippet class."""
    import ast
    import astor
    t = ast.parse(get_source(snippet_sample)).body[0]
    s = snippet(snippet_sample)
    body = s.get_body()
    body0 = astor.to_source(body[0]).strip()
    body1 = astor.to_source(body[1]).strip()
    body3 = astor.to_source(body[3]).strip()
    expected_body0 = "x = 1"
    expected_body1 = "x = 1"
    expected_body3 = "x = 1"
    assert body0 == expected_body0 and \
           body1 == expected_body1 and \
           body3 == expected_body3


# Generated at 2022-06-12 04:42:39.421636
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda x: x + 1).get_body(x=1) == [
        ast.Expr(
            ast.BinOp(
                ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                ast.Add(),
                ast.Num(n=1)
            )
        )
    ]


# Generated at 2022-06-12 04:42:45.863020
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test_function():
        a = 1
        let(a)
        a = 2

    test_snippet = snippet(_test_function)
    assert test_snippet.get_body() == [ast.Assign(targets=[ast.Name(
        id='_py_backwards_a_0', ctx=ast.Store())], value=ast.Num(n=1)),
                                     ast.Assign(targets=[ast.Name(
                                         id='_py_backwards_a_0', ctx=ast.Store())], value=ast.Num(n=2))]

# Generated at 2022-06-12 04:42:48.646070
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func():
        let(x)
        x = 1
        return x

    body = snippet(func).get_body()
    assert isinstance(body, list)

# Generated at 2022-06-12 04:42:53.238131
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def extract_line(lines, line_num):
        let(line)
        line += '!' * 3
        print(line)
    
    body = extract_line.get_body(lines=[], line_num=0)
    assert body[0].value.id == 'line'
    assert body[0].value.value.s == '!' * 3
    assert body[1].value.value.s == 'line'

# Generated at 2022-06-12 04:43:02.217461
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        let(y)
        y = 2
        return x + y


# Generated at 2022-06-12 04:43:08.531462
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet():
        let(x)
        y = x
        extend(vars)

    body = test_snippet.get_body(x=1,
                                 vars=[ast.Assign(targets=[ast.Name(id='x')],
                                                  value=ast.Num(n=2))])

    assert body[0].value == 2
    assert body[1].targets[0].id == 'y'
    assert body[1].value.id == 'x'


# Generated at 2022-06-12 04:43:17.209252
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import pytest
    import sys

    @snippet
    def f(x: int, y: int) -> None:
        let(z)
        z += 1
        y = 1

    body = f.get_body(x=1, y=2)
    assert body == ast.parse('z += 1\ny = 1').body

    body = f.get_body(x=1, y=2)
    assert body == ast.parse('_py_backwards_z_0 += 1\ny = 1').body

    body = f.get_body(y=1)
    assert body == ast.parse('_py_backwards_x_0 += 1\ny = 1').body

    @snippet
    def g(x: int, y: int) -> None:
        let(z)
        z += 1

# Generated at 2022-06-12 04:43:21.901784
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import to_source

    def add(a, b):
        let(a)
        b += 1
        return a + b

    L1 = snippet(add).get_body(a=1)
    assert L1 == ast.parse(to_source(add)).body[0].body

    def sub(a, b):
        let(a)
        let(b)
        return a - b


# Generated at 2022-06-12 04:44:34.257487
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import codegen
    @codegen.snippet
    def snippet_example():
        let(x)
        x += 1
        y = 1

    assert snippet_example.get_body() == ast.parse(
        '_py_backwards_x_0 += 1\ny = 1').body



# Generated at 2022-06-12 04:44:42.434505
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_one():
        let(x)
        x += 1
        y = 1

    assert snippet_one.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0',
                              ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0',
                             ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1))),
        ast.Assign(
            targets=[ast.Name(id='y',
                              ctx=ast.Store())],
            value=ast.Num(n=1))
    ]



# Generated at 2022-06-12 04:44:50.888060
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func():
        let(a)
        let(b)
        c = a + b
        return c

    t = snippet(func).get_body()

    assert ast.dump(t) == ast.dump([
        ast.Assign([ast.Name(id='_py_backwards_c_0', ctx=ast.Store())],
                   ast.BinOp(left=ast.Name(id='_py_backwards_a_0', ctx=ast.Load()),
                             op=ast.Add(),
                             right=ast.Name(id='_py_backwards_b_0', ctx=ast.Load()))),
        ast.Return(value=ast.Name(id='_py_backwards_c_0', ctx=ast.Load()))])


# Generated at 2022-06-12 04:44:57.596097
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 42
    y = 'a'
    z = ast.Name(id='a', ctx=ast.Load())
    w = ast.Name(id='b', ctx=ast.Load())
    result = snippet(lambda: let(x + 1) & extend(y) & extend(z) & extend(w)).get_body()
    assert result == [ast.Assign([ast.Name(id='y', ctx=ast.Store())], ast.Name(id='a', ctx=ast.Load())),
                       ast.Assign([ast.Name(id='b', ctx=ast.Store())], ast.Name(id='b', ctx=ast.Load()))]

# Generated at 2022-06-12 04:45:06.075412
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def some_snippet(x: int, y, z: int = 10) -> int:
        let(y)
        return x + y + z

    assert some_snippet.get_body() == some_snippet.get_body()
    assert some_snippet.get_body() == some_snippet.get_body(x=1, y=2)
    assert some_snippet.get_body() == some_snippet.get_body(y=2, x=1)
    assert some_snippet.get_body(y=2) == some_snippet.get_body(y=2, x=1)

# Generated at 2022-06-12 04:45:14.625818
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    expected_body = [ast.FunctionDef(
        name='f',
        args=ast.arguments(
            args=[], defaults=[], kwonlyargs=[], kw_defaults=[], kwarg=None, vararg=None),
        body=[ast.Return(value=ast.Num(n=1))],
        decorator_list=[],
        returns=None,
        type_comment=None
    )]

    def f():
        return 1

    actual_body = snippet(f).get_body()
    assert actual_body
    assert len(actual_body) == 1
    assert actual_body[0].name == 'f'


# Generated at 2022-06-12 04:45:23.441495
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_var = 'test'
    test_num = 'test_num'

    @snippet
    def test_fn(x: int, **variables: ast.AST) -> None:
        extend(variables[test_var])
        let(x)
        let(variables[test_num])
        let(test_var)

    # Test:
    tree = ast.parse(
        '''
        x = 2
        y = 3
        '''
    )
    variables = {
        test_num: '100',
        test_var: tree
    }
    body = test_fn.get_body(**variables)

# Generated at 2022-06-12 04:45:27.466312
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(a)
        let(b)
        extend(c)
        let(d)
        assert a == b
        assert c == 0
        assert d == a
        return a

    assert isinstance(fn, snippet)
    assert isinstance(fn.get_body(a=10, b=20, c=0, d=a), list)

# Generated at 2022-06-12 04:45:31.010029
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    value = 42
    variable = 'a'

    @snippet
    def my_func(variable):
        let(variable)
        return variable

    result = my_func.get_body(variable=value)
    assert result == [ast.Return(value=ast.Num(value))]

# Generated at 2022-06-12 04:45:40.184770
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _():
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(_)
    body = snippet_instance.get_body()

    assert body == [
        ast.Assign(targets=[
            ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                            op=ast.Add(),
                            right=ast.Num(n=1))
            ),
        ast.Assign(targets=[
            ast.Name(id='y', ctx=ast.Store())
        ],
            value=ast.Num(n=1)
        )]