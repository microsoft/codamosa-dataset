

# Generated at 2022-06-18 01:03:39.380689
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body()
    assert body == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]




# Generated at 2022-06-18 01:03:51.383031
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    import sys
    import astunparse
    from .helpers import VariablesGenerator
    from .tree import find
    from .snippet import VariablesReplacer
    from .snippet import let
    from .snippet import extend
    from .snippet import snippet

    def test_func():
        let(x)
        let(y)
        let(z)
        extend(vars)
        print(x, y, z)

    source = get_source(test_func)
    tree = ast.parse(source)
    names = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name) for name in names}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-18 01:04:00.242594
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    import astunparse
    import sys
    import unittest
    from py_backwards.transformers import VariablesReplacer
    from py_backwards.tree import find

    class TestVariablesReplacer(unittest.TestCase):
        def test_visit_alias(self):
            source = '''
            from a.b import c as d
            '''
            tree = ast.parse(source)
            variables = {'a': 'e', 'b': 'f', 'c': 'g', 'd': 'h'}
            VariablesReplacer.replace(tree, variables)
            self.assertEqual(astunparse.unparse(tree), 'from e.f import g as h')

    unittest.main()

# Generated at 2022-06-18 01:04:07.309690
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:14.603125
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:17.119868
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:04:23.377233
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:29.171001
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:36.631533
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    snippet_obj = snippet(test_snippet)
    snippet_obj.get_body(x=1, vars=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                               value=ast.Num(n=1)),
                                    ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                               value=ast.Num(n=2))])

# Generated at 2022-06-18 01:04:45.272697
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    import snippet
    import VariablesReplacer
    import VariablesGenerator
    import find
    import get_source
    import replace_at
    import get_non_exp_parent_and_index
    import eager
    import ast3 as ast
    import ast3 as ast
    import ast3 as ast
    import ast3 as ast
    import ast3 as ast
    import ast3 as ast
    import ast3 as ast
    import ast3 as ast
    import ast3 as ast
    import ast3 as ast
    import ast3 as ast
    import ast3 as ast
    import ast3 as ast
    import ast3 as ast

# Generated at 2022-06-18 01:04:57.603284
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import get_source
    from .tree import find
    from .snippet import VariablesReplacer
    from .snippet import let
    import ast
    import astor
    import astunparse
    import sys
    import unittest

    class TestVariablesReplacer(unittest.TestCase):
        def test_visit_alias(self):
            source = get_source(self.test_visit_alias)
            tree = ast.parse(source)
            variables = {'x': '_py_backwards_x_0'}
            extend_tree(tree, variables)
            VariablesReplacer.replace(tree, variables)
            for node in find(tree, ast.alias):
                self.assertEqual(node.name, '_py_backwards_x_0')
                self

# Generated at 2022-06-18 01:05:02.655070
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x += 1
    let(y)
    y += 1
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:05:12.541929
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int, z: int) -> None:
        let(x)
        let(y)
        let(z)
        x += 1
        y += 2
        z += 3


# Generated at 2022-06-18 01:05:14.270724
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(x)
x = 1
let(y)
y = 2
""")
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:05:24.892560
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:05:28.414352
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        x = 1
        y = 2
    """)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:05:32.505614
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:05:35.971741
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:05:42.983054
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:46.217988
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:56.114365
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:06:04.065311
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    import inspect
    import sys
    import unittest

    class TestVariablesReplacer(unittest.TestCase):
        def test_visit_alias(self):
            import_node = ast.parse("from a import b as c").body[0]
            alias_node = import_node.names[0]
            alias_node.name = "a"
            alias_node.asname = "c"
            variables = {"a": "b"}
            replacer = VariablesReplacer(variables)
            replacer.visit_alias(alias_node)
            self.assertEqual(alias_node.name, "b")
            self.assertEqual(alias_node.asname, "c")

    if __name__ == '__main__':
        unittest.main

# Generated at 2022-06-18 01:06:14.911442
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import get_source
    from .tree import find
    from .snippet import VariablesReplacer
    from .snippet import let
    from .snippet import extend
    from .snippet import snippet
    from .snippet import find_variables
    from .snippet import extend_tree
    from .snippet import VariablesGenerator
    from .snippet import Variable
    from .snippet import Variable
    from .snippet import Variable
    from .snippet import Variable
    from .snippet import Variable
    from .snippet import Variable
    from .snippet import Variable
    from .snippet import Variable
    from .snippet import Variable
    from .snippet import Variable
    from .snippet import Variable
    from .snippet import Variable


# Generated at 2022-06-18 01:06:20.076376
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test)
    body = snippet_obj.get_body()
    assert body[0].value.left.id == '_py_backwards_x_0'
    assert body[1].value.left.id == 'y'

# Generated at 2022-06-18 01:06:23.520534
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:06:31.789643
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    import astor
    import sys
    import os
    import inspect
    import importlib
    import importlib.util

    def get_module_ast(module_name):
        module_spec = importlib.util.find_spec(module_name)
        module_file = module_spec.origin
        with open(module_file, 'r') as f:
            module_source = f.read()
        module_ast = ast.parse(module_source)
        return module_ast

    def get_module_source(module_name):
        module_spec = importlib.util.find_spec(module_name)
        module_file = module_spec.origin
        with open(module_file, 'r') as f:
            module_source = f.read()
        return module_source


# Generated at 2022-06-18 01:06:41.622337
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from typed_ast import ast3 as ast
    from .tree import find
    from .helpers import VariablesGenerator
    from .snippet import VariablesReplacer

    source = '''
    import a.b.c as d
    '''
    tree = ast.parse(source)
    variables = {'a': VariablesGenerator.generate('a'),
                 'b': VariablesGenerator.generate('b'),
                 'c': VariablesGenerator.generate('c'),
                 'd': VariablesGenerator.generate('d')}
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-18 01:06:45.342216
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:06:55.018472
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    import astor
    import sys
    import os
    import tempfile
    import shutil
    import importlib
    import random
    import string
    from .tree import find, get_non_exp_parent_and_index, replace_at
    from .helpers import eager, VariablesGenerator, get_source
    from .snippet import VariablesReplacer
    from .snippet import let
    from .snippet import extend
    from .snippet import snippet
    from .snippet import test_VariablesReplacer_visit_ImportFrom
    from .snippet import test_VariablesReplacer_visit_alias
    from .snippet import test_VariablesReplacer_visit_ExceptHandler
    from .snippet import test_VariablesReplacer_visit_Name

# Generated at 2022-06-18 01:07:00.011610
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("from a import b as c")
    variables = {'c': 'd'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "ImportFrom(module='a', names=[alias(name='b', asname='d')], level=0)"

# Generated at 2022-06-18 01:07:14.822557
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:07:24.081982
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(test_snippet)
    snippet_body = snippet_instance.get_body(x=1, y=2)

# Generated at 2022-06-18 01:07:31.731907
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from = ast.ImportFrom(module='module', names=[ast.alias(name='name', asname='asname')], level=0)
    variables = {'module': 'module_new', 'name': 'name_new', 'asname': 'asname_new'}
    VariablesReplacer.replace(import_from, variables)
    assert import_from.module == 'module_new'
    assert import_from.names[0].name == 'name_new'
    assert import_from.names[0].asname == 'asname_new'

# Generated at 2022-06-18 01:07:32.738847
# Unit test for function extend_tree

# Generated at 2022-06-18 01:07:39.708541
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from = ast.ImportFrom(module='a.b.c', names=[ast.alias(name='d', asname='e')], level=0)
    variables = {'a': 'f', 'b': 'g', 'c': 'h', 'd': 'i', 'e': 'j'}
    VariablesReplacer.replace(import_from, variables)
    assert import_from.module == 'f.g.h'
    assert import_from.names[0].name == 'i'
    assert import_from.names[0].asname == 'j'

# Generated at 2022-06-18 01:07:49.031633
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
        x = 1
        x = 2
        print(x, y)
    """

# Generated at 2022-06-18 01:07:52.815841
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body()
    assert body[0].value.left.id == '_py_backwards_x_0'
    assert body[0].value.op.__class__.__name__ == 'Add'
    assert body[0].value.right.n == 1
    assert body[1].value.n == 1

# Generated at 2022-06-18 01:08:02.633740
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test(x: int) -> int:
        let(y)
        y = x + 1
        return y

    assert snippet(test).get_body(x=1) == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_y_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='x', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Return(
            value=ast.Name(id='_py_backwards_y_0', ctx=ast.Load())
        )
    ]



# Generated at 2022-06-18 01:08:09.835740
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:08:14.138045
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .test_helpers import assert_ast_equal
    import_from = ast.parse('from . import a').body[0]
    variables = {'a': 'b'}
    VariablesReplacer.replace(import_from, variables)
    assert_ast_equal(import_from, ast.parse('from . import b').body[0])

# Generated at 2022-06-18 01:08:29.253085
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    assert snippet_obj.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:08:36.918929
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)
    assert body[0].value.n == 1
    assert body[1].value.n == 2

# Generated at 2022-06-18 01:08:44.345258
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x: int, y: int) -> int:
        let(z)
        z = x + y
        return z

    snippet_f = snippet(f)
    body = snippet_f.get_body(x=ast.Name(id='a', ctx=ast.Load()),
                              y=ast.Name(id='b', ctx=ast.Load()))

# Generated at 2022-06-18 01:08:53.385497
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    extend_tree(tree, {'vars': [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2)),
    ]})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """



# Generated at 2022-06-18 01:08:58.779390
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:09:08.964893
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1


# Generated at 2022-06-18 01:09:14.619377
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:09:23.007288
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    assert snippet_obj.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:09:31.164947
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:09:35.128376
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(vars)

# Generated at 2022-06-18 01:10:00.213542
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:10:09.081252
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:10:12.930360
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(fn)
    assert snippet_.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:10:23.480099
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:10:32.208309
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nprint(x, y)')
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:10:35.525285
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(fn)
    snippet_obj.get_body()

# Generated at 2022-06-18 01:10:42.170098
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)')
    vars = ast.parse('x = 1\nx = 2')
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=2))])'

# Generated at 2022-06-18 01:10:46.765307
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:10:54.452106
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_fn)
    body = snippet_obj.get_body()
    assert body == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:11:05.360114
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    snippet_body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:11:55.177737
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:12:01.920933
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    assert snippet(test_snippet).get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]



# Generated at 2022-06-18 01:12:10.835435
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body()
    assert body == [ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                               value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                               op=ast.Add(),
                                               right=ast.Num(n=1))),
                     ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                                value=ast.Num(n=1))]

# Generated at 2022-06-18 01:12:20.315379
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(test_snippet)
    assert snippet_instance.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]


# Unit

# Generated at 2022-06-18 01:12:27.628006
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(snippet_fn)
    body = snippet_instance.get_body(x=1, y=2)
    assert len(body) == 2
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[0].value, ast.BinOp)
    assert isinstance(body[1].value, ast.Num)
    assert isinstance(body[0].value.left, ast.Name)
    assert isinstance(body[0].value.right, ast.Num)

# Generated at 2022-06-18 01:12:34.916359
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:12:44.898227
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:12:50.272123
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    snippet_body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:12:54.238389
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(test_fn)
    body = snippet_obj.get_body(x=1, y=2)
    assert len(body) == 3
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[2], ast.Return)

# Generated at 2022-06-18 01:12:56.837550
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']

