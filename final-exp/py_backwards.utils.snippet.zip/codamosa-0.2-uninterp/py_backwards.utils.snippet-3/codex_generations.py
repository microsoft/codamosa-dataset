

# Generated at 2022-06-18 01:03:34.044459
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        x = 1
        y = 2
    """)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:03:38.972174
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    x = 1
    x = 2
    """



# Generated at 2022-06-18 01:03:44.268891
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x += 1
    y += 1
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:03:50.848758
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars.body})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:03:59.523761
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:07.521428
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:04:18.113155
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:20.076710
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:04:24.712917
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        x = 1
        y = 2
        z = 3
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:04:29.029244
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body()
    assert isinstance(body, list)
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-18 01:04:42.370318
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        let(y)
        x += 1
        y += 1

    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body(x=1, y=2)
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.AugAssign)
    assert body[0].target.id == '_py_backwards_x_0'
    assert body[1].target.id == '_py_backwards_y_1'
    assert body[0].value.n == 1
    assert body[1].value.n == 2



# Generated at 2022-06-18 01:04:45.875030
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:04:50.669484
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test_snippet_get_body():
        x = 1
        let(x)
        x += 1
        y = 1

    snippet = snippet(_test_snippet_get_body)
    body = snippet.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-18 01:04:58.830882
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    def f():
        extend(vars)
        print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1),
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2),
        ),
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:05:03.244527
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x += 1
    y = 1
    """
    tree = ast.parse(source)
    assert find_variables(tree) == ['x']



# Generated at 2022-06-18 01:05:06.357071
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:05:10.004686
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(x)
let(y)
x = 1
y = 2
""")
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:05:18.575073
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]

    snippet_obj = snippet(test_fn)
    body = snippet_obj.get_body(vars=vars)

# Generated at 2022-06-18 01:05:27.338911
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars.body})
    assert ast.dump(tree) == """Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2)), Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Name(id='x', ctx=Load()), Name(id='y', ctx=Load())], keywords=[]))])"""

# Generated at 2022-06-18 01:05:36.970357
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:48.607993
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:05:54.794401
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:06:02.765800
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_test(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(snippet_test)

# Generated at 2022-06-18 01:06:12.790118
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:06:22.342018
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:06:27.460283
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:06:38.328148
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:06:45.990602
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body(x=1, y=2)
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                               ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                         ast.Add(),
                                         ast.Num(1))),
                     ast.Assign([ast.Name('y', ast.Store())],
                                ast.Num(1))]

# Generated at 2022-06-18 01:06:51.639635
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-18 01:07:01.994533
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body(x=1, y=2)
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                               ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                         ast.Add(),
                                         ast.Num(1))),
                     ast.Assign([ast.Name('y', ast.Store())],
                                ast.Num(1))]

# Generated at 2022-06-18 01:07:15.845331
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:07:24.847913
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    extend(vars)
    print(x, y)
    """
    tree = ast.parse(source)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:07:28.791270
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:07:32.311096
# Unit test for function find_variables
def test_find_variables():
    source = """
        let(x)
        x += 1
        y = 1
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x'}



# Generated at 2022-06-18 01:07:41.274108
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1


# Generated at 2022-06-18 01:07:50.972776
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    assert snippet_obj.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]


# Unit

# Generated at 2022-06-18 01:08:02.204457
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body()

# Generated at 2022-06-18 01:08:10.440447
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(test_snippet)
    assert snippet_instance.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:08:16.554567
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:08:20.827086
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:08:39.009311
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(test_snippet)
    body = snippet_instance.get_body()
    assert body == [
        ast.AugAssign(
            target=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()),
            op=ast.Add(),
            value=ast.Num(n=1)),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1))
    ]

# Generated at 2022-06-18 01:08:42.967452
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:08:52.465026
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:08:54.457076
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """

# Generated at 2022-06-18 01:09:05.309826
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:09:14.517470
# Unit test for function find_variables

# Generated at 2022-06-18 01:09:22.397234
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x: int, y: int) -> int:
        let(z)
        z = x + y
        return z

    snippet_ = snippet(fn)
    body = snippet_.get_body(x=1, y=2)
    assert body == [ast.Assign(targets=[ast.Name(id='_py_backwards_z_0', ctx=ast.Store())],
                               value=ast.BinOp(left=ast.Num(n=1),
                                               op=ast.Add(),
                                               right=ast.Num(n=2))),
                     ast.Return(value=ast.Name(id='_py_backwards_z_0', ctx=ast.Load()))]

# Generated at 2022-06-18 01:09:31.050673
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)
    assert len(body) == 2
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[1], ast.Assign)
    assert body[0].targets[0].id == '_py_backwards_x_0'
    assert body[1].targets[0].id == 'y'
    assert isinstance(body[0].value, ast.BinOp)
    assert isinstance(body[1].value, ast.Num)

# Generated at 2022-06-18 01:09:38.914901
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(test_snippet)
    snippet_body = snippet_instance.get_body(x=1, y=2)
    assert snippet_body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                                       ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                                 ast.Add(),
                                                 ast.Num(1))),
                             ast.Assign([ast.Name('y', ast.Store())],
                                        ast.Num(1))]

# Generated at 2022-06-18 01:09:44.017929
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:10:19.664834
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:10:29.357207
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    snippet_body = snippet_obj.get_body(x=1, y=2)
    assert snippet_body == [ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())], ast.BinOp(ast.Name(id='_py_backwards_x_0', ctx=ast.Load()), ast.Add(), ast.Num(n=1))), ast.Assign([ast.Name(id='y', ctx=ast.Store())], ast.Num(n=1))]

# Generated at 2022-06-18 01:10:37.006908
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_ = snippet(test_fn)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:10:43.015791
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        x = 1
        y = 2
        z = 3
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']
    assert ast.dump(tree) == """
        Module(body=[
            Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)),
            Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=2)),
            Assign(targets=[Name(id='z', ctx=Store())], value=Num(n=3))
        ])
    """.strip()



# Generated at 2022-06-18 01:10:50.024633
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:10:55.484741
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:11:06.421798
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:11:12.206032
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(fn)
    body = snippet_.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-18 01:11:17.241873
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    snippet_body = snippet_obj.get_body()
    assert snippet_body == [ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                                       value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                                       op=ast.Add(),
                                                       right=ast.Num(n=1))),
                            ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                                       value=ast.Num(n=1))]

# Generated at 2022-06-18 01:11:23.110909
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet():
        let(x)
        x += 1
        y = 1

    assert test_snippet.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]



# Generated at 2022-06-18 01:12:10.286840
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:12:19.754021
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:12:27.258543
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=ast.Name(id='_x', ctx=ast.Load()), y=2)

# Generated at 2022-06-18 01:12:31.483050
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:12:34.233148
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:12:39.209669
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """

# Generated at 2022-06-18 01:12:46.809475
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())], ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()), ast.Add(), ast.Num(1))), ast.Assign([ast.Name('y', ast.Store())], ast.Num(1))]

# Generated at 2022-06-18 01:12:50.628691
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """).body
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:12:58.500081
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=1)

# Generated at 2022-06-18 01:13:03.686159
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars.body})
    assert get_source(tree) == """
        x = 1
        x = 2
        print(x, y)
    """