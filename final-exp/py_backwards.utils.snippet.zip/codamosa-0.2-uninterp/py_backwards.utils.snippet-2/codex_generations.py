

# Generated at 2022-06-18 01:03:40.615378
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars.body})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """

# Generated at 2022-06-18 01:03:44.597116
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:03:51.719849
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:03:57.354178
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars.body})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:05.454533
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nprint(x, y)')
    vars = ast.parse('x = 1\nx = 2')
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=2)), Expr(value=Call(func=Name(id="print", ctx=Load()), args=[Name(id="x", ctx=Load()), Name(id="y", ctx=Load())], keywords=[]))])'

# Generated at 2022-06-18 01:04:16.514239
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    assert snippet_obj.get_body() == [
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                   op=ast.Add(),
                                   right=ast.Num(n=1))),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                   value=ast.Num(n=1))
    ]

# Generated at 2022-06-18 01:04:21.608230
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:04:30.904745
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))



# Generated at 2022-06-18 01:04:34.199773
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:04:37.116661
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:04:44.413795
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        x = 1
        y = 2
        z = 3
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:04:47.057221
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(x)
let(y)
let(z)
""")
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:04:51.478785
# Unit test for function find_variables
def test_find_variables():
    source = """
        let(x)
        x += 1
        y = 1
        let(z)
        z += 1
        let(a)
        a += 1
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert list(variables) == ['x', 'z', 'a']



# Generated at 2022-06-18 01:04:57.206629
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:05:02.145517
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:05:11.732971
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(fn)
    body = snippet_.get_body()
    assert body == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:05:19.675051
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:05:21.182491
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert find_variables(tree) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:05:24.225323
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:05:27.971953
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:05:40.637826
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_fn)
    body = snippet_.get_body(x=1, y=2)
    assert len(body) == 2
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[0].value, ast.BinOp)
    assert isinstance(body[0].value.left, ast.Name)
    assert body[0].value.left.id == '_py_backwards_x_0'
    assert isinstance(body[0].value.op, ast.Add)
    assert isinstance(body[0].value.right, ast.Num)
    assert body[0].value.right.n == 1

# Generated at 2022-06-18 01:05:46.646933
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test)
    body = snippet_.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-18 01:05:53.117763
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:06:02.165520
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    snippet_body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:06:05.978707
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:06:11.030104
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_fn)
    body = snippet_.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-18 01:06:21.519117
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:06:29.722622
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)
    assert body[0].target.id == '_py_backwards_x_0'
    assert body[1].targets[0].id == 'y'

# Generated at 2022-06-18 01:06:40.120797
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        let(y)
        return x + y

    snippet_obj = snippet(test_snippet)
    snippet_body = snippet_obj.get_body(x=1, y=2)
    assert snippet_body[0].value.left.id == '_py_backwards_x_0'
    assert snippet_body[0].value.right.n == 1
    assert snippet_body[1].value.left.id == '_py_backwards_y_1'
    assert snippet_body[1].value.right.n == 2
    assert snippet_body[2].value.left.id == '_py_backwards_x_0'

# Generated at 2022-06-18 01:06:51.216830
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:07:03.094164
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet(a: int, b: int) -> int:
        let(x)
        x = a + b
        return x

    assert test_snippet.get_body(a=1, b=2) == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Num(n=1),
                op=ast.Add(),
                right=ast.Num(n=2)
            )
        ),
        ast.Return(
            value=ast.Name(id='_py_backwards_x_0', ctx=ast.Load())
        )
    ]

# Generated at 2022-06-18 01:07:08.323169
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(fn)
    body = snippet_obj.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-18 01:07:11.531735
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:07:18.051561
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
        x = 1
        x = 2
        print(x, y)
    """

# Generated at 2022-06-18 01:07:24.634860
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        let(y)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)
    assert body[0].target.id == '_py_backwards_x_0'
    assert body[1].targets[0].id == '_py_backwards_y_1'



# Generated at 2022-06-18 01:07:31.134749
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()), y=ast.Name(id='_py_backwards_y_1', ctx=ast.Load()))

# Generated at 2022-06-18 01:07:37.101465
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:07:43.654805
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    snippet_body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:07:51.734194
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_fn)
    assert snippet_obj.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:07:56.473366
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x += 1
    let(y)
    y += 2
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:08:08.211089
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:08:19.036681
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:08:26.330660
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_fn)
    body = snippet_.get_body()
    assert body == [
        ast.AugAssign(
            target=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
            op=ast.Add(),
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]



# Generated at 2022-06-18 01:08:37.126994
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    result = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:08:44.453046
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        let(y)
        x += 1
        y += 1
        print(x, y)

    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:08:55.279452
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y


# Generated at 2022-06-18 01:09:05.535669
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1


# Generated at 2022-06-18 01:09:14.841938
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=ast.Name(id='x', ctx=ast.Load()), y=ast.Name(id='y', ctx=ast.Load()))

# Generated at 2022-06-18 01:09:23.079299
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(snippet_fn)
    snippet_body = snippet_instance.get_body(x=1, y=2)

# Generated at 2022-06-18 01:09:33.086966
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:09:44.756103
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:09:49.790652
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:09:57.862797
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:10:02.306060
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test)
    body = snippet_.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-18 01:10:11.689385
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    extend_tree(tree, {'vars': [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]})

# Generated at 2022-06-18 01:10:21.896506
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]

    body = snippet(test_snippet).get_body(x=1, y=2, vars=vars)


# Generated at 2022-06-18 01:10:31.765617
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:10:37.738412
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:10:41.707281
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:10:48.782434
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:11:04.587115
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:11:13.997886
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_fn)
    body = snippet_obj.get_body()
    assert body == [ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                               value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                               op=ast.Add(),
                                               right=ast.Num(n=1))),
                    ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                               value=ast.Num(n=1))]

# Generated at 2022-06-18 01:11:17.467929
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    snippet_instance = snippet(f)
    snippet_instance.get_body()

# Generated at 2022-06-18 01:11:23.193734
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:11:28.160579
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:11:37.595353
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:11:47.174643
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(test_fn)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:11:56.014460
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:12:02.773933
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:12:11.785294
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)
    assert len(body) == 2
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[1], ast.Assign)
    assert body[0].targets[0].id == '_py_backwards_x_0'
    assert body[1].targets[0].id == 'y'
    assert isinstance(body[0].value, ast.BinOp)
    assert isinstance(body[1].value, ast.Num)
    assert body[0].value.op.__class

# Generated at 2022-06-18 01:12:46.715634
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)

# Generated at 2022-06-18 01:12:53.420850
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(test_fn)
    body = snippet_instance.get_body()
    assert body == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:13:03.082385
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    assert snippet_obj.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]



# Generated at 2022-06-18 01:13:09.314420
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(test_snippet)
    snippet_body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:13:18.592025
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:13:25.293205
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_fn)
    body = snippet_obj.get_body(x=1, y=2)
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                               ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                         ast.Add(),
                                         ast.Num(1))),
                     ast.Assign([ast.Name('y', ast.Store())],
                                ast.Num(1))]

# Generated at 2022-06-18 01:13:33.932803
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y
