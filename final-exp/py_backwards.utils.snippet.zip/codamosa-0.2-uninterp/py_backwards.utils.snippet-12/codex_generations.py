

# Generated at 2022-06-18 01:03:41.638661
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(snippet_fn)
    body = snippet_instance.get_body()
    assert body == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:03:48.803114
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:03:58.463784
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from .helpers import VariablesGenerator
    from .tree import find
    from .snippet import VariablesReplacer
    from .snippet import let
    from .snippet import extend
    from .snippet import snippet
    from .snippet import find_variables
    from .snippet import extend_tree
    from .snippet import get_source
    from .snippet import replace_at
    from .snippet import get_non_exp_parent_and_index
    from .snippet import eager
    from .snippet import Variable
    from .snippet import T

# Generated at 2022-06-18 01:04:08.841396
# Unit test for function find_variables

# Generated at 2022-06-18 01:04:13.580189
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:04:20.989664
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astunparse
    from .tree import find
    from .helpers import VariablesGenerator
    from .snippet import VariablesReplacer

    source = """
    from a.b import c as d
    """
    tree = ast.parse(source)
    variables = {'a': VariablesGenerator.generate('a'),
                 'b': VariablesGenerator.generate('b'),
                 'c': VariablesGenerator.generate('c'),
                 'd': VariablesGenerator.generate('d')}
    VariablesReplacer.replace(tree, variables)
    for node in find(tree, ast.alias):
        assert node.name == 'a.b'
        assert node.asname == 'd'


# Generated at 2022-06-18 01:04:25.597173
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:28.986029
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x += 1
    let(y)
    y = 1
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:04:34.033507
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    def f():
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    def f():
        x = 1
        x = 2
        print(x, y)
    """

# Generated at 2022-06-18 01:04:37.978429
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import parse
    tree = parse('''
        from a import b as c
    ''')
    variables = {'b': 'd'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == 'from a import d as c'



# Generated at 2022-06-18 01:04:51.304254
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:56.130699
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:02.630927
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import astor
    import ast
    import os
    import sys
    import tempfile
    import unittest

    class TestVariablesReplacer(unittest.TestCase):
        def test_visit_ImportFrom(self):
            # Create a temporary file
            fd, path = tempfile.mkstemp()
            os.close(fd)
            with open(path, 'w') as f:
                f.write('import os\n')
                f.write('import sys\n')
                f.write('import tempfile\n')
                f.write('import unittest\n')
                f.write('import astor\n')
                f.write('import ast\n')
                f.write('import os\n')
                f.write('import sys\n')

# Generated at 2022-06-18 01:05:12.546259
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import get_source
    from .tree import find
    from .snippet import VariablesReplacer
    from .snippet import let
    from .snippet import extend
    import ast
    import astor

    def test():
        let(x)
        extend(y)
        import x as y
        import x as z

    tree = ast.parse(get_source(test))
    variables = {'x': '_py_backwards_x_0', 'y': '_py_backwards_y_1'}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-18 01:05:15.995994
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:05:20.637562
# Unit test for function find_variables
def test_find_variables():
    source = """
        let(x)
        let(y)
        let(z)
        x = 1
        y = 2
        z = 3
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert list(variables) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:05:25.698391
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:32.085671
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x)
    """))

# Generated at 2022-06-18 01:05:35.589113
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert find_variables(tree) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:05:41.575080
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from = ast.ImportFrom(module='module', names=[ast.alias(name='name', asname='asname')], level=0)
    variables = {'module': 'module_new', 'name': 'name_new', 'asname': 'asname_new'}
    VariablesReplacer.replace(import_from, variables)
    assert import_from.module == 'module_new'
    assert import_from.names[0].name == 'name_new'
    assert import_from.names[0].asname == 'asname_new'

# Generated at 2022-06-18 01:05:59.614444
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:06:10.662127
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_ = snippet(fn)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:06:16.280361
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:06:21.110830
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        x += 1
        y = 1
        z = 2
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:06:28.929860
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:06:32.396489
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:06:35.912124
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert find_variables(tree) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:06:39.870035
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:06:48.709662
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    from .helpers import VariablesGenerator
    from .snippet import VariablesReplacer
    from .tree import find
    from .helpers import get_source

    source = get_source(test_VariablesReplacer_visit_alias)
    tree = ast.parse(source)
    names = find(tree, ast.Name)
    variables = {name.id: VariablesGenerator.generate(name.id) for name in names}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == 'import a.b.c as d'

# Generated at 2022-06-18 01:06:53.135306
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("from a import b as c")
    variables = {'a': 'd', 'b': 'e', 'c': 'f'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "ImportFrom(module='d', names=[alias(name='e', asname='f')], level=0)"

# Generated at 2022-06-18 01:07:11.798404
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    extend_tree(tree, {'vars': [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:07:15.960182
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:07:21.505364
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-18 01:07:28.852483
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    assert snippet(test_snippet).get_body(x=1, y=2) == [
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                   op=ast.Add(),
                                   right=ast.Num(n=1))),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                   value=ast.Num(n=1))
    ]

# Generated at 2022-06-18 01:07:32.760201
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:07:39.419410
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    snippet_body = snippet_obj.get_body()
    assert snippet_body[0].value.left.id == '_py_backwards_x_0'
    assert snippet_body[0].value.op.__class__.__name__ == 'Add'
    assert snippet_body[1].value.n == 1
    assert snippet_body[1].targets[0].id == 'y'

# Generated at 2022-06-18 01:07:45.186157
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    from .helpers import VariablesGenerator
    from .tree import find
    from .snippet import VariablesReplacer

    source = """
    from a.b.c import d as e
    """

    tree = ast.parse(source)
    variables = {'a': VariablesGenerator.generate('a'),
                 'b': VariablesGenerator.generate('b'),
                 'c': VariablesGenerator.generate('c'),
                 'd': VariablesGenerator.generate('d'),
                 'e': VariablesGenerator.generate('e')}
    VariablesReplacer.replace(tree, variables)
    print(astor.to_source(tree))


# Generated at 2022-06-18 01:07:46.906583
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:07:52.195884
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    import astunparse
    from .tree import find
    from .helpers import VariablesGenerator
    from .snippet import VariablesReplacer

    source = """
    from a.b.c import d, e as f
    """
    tree = ast.parse(source)
    variables = {'a': VariablesGenerator.generate('a'),
                 'b': VariablesGenerator.generate('b'),
                 'c': VariablesGenerator.generate('c'),
                 'd': VariablesGenerator.generate('d'),
                 'e': VariablesGenerator.generate('e'),
                 'f': VariablesGenerator.generate('f')}
    VariablesReplacer.replace(tree, variables)
    print(astor.to_source(tree))
    print

# Generated at 2022-06-18 01:07:57.159526
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    let(y)
    let(z)
    '''
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:08:26.161839
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2)),
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:08:35.357458
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                               ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                         ast.Add(),
                                         ast.Num(1))),
                     ast.Assign([ast.Name('y', ast.Store())],
                                ast.Num(1))]

# Generated at 2022-06-18 01:08:41.196478
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:08:46.391441
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        x = 1
        y = 2
        z = 3
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:08:55.974525
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:08:58.470913
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    from .tree import find
    from .helpers import VariablesGenerator
    from .snippet import VariablesReplacer

    source = """
    from a.b.c import d
    """
    tree = ast.parse(source)
    variables = {'a': VariablesGenerator.generate('a')}
    VariablesReplacer.replace(tree, variables)
    assert find(tree, ast.ImportFrom)[0].module == 'a.b.c'

# Generated at 2022-06-18 01:09:04.822093
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """

# Generated at 2022-06-18 01:09:07.629077
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:09:18.089913
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(fn)
    assert snippet_.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]



# Generated at 2022-06-18 01:09:28.531063
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:09:56.760475
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)

    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]

    extend_tree(tree, {'vars': vars})

    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:10:06.569888
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:10:13.556797
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body()
    assert body == [
        ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   ast.BinOp(ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                             ast.Add(), ast.Num(n=1))),
        ast.Assign([ast.Name(id='y', ctx=ast.Store())], ast.Num(n=1))
    ]

# Generated at 2022-06-18 01:10:18.828969
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """

# Generated at 2022-06-18 01:10:28.500071
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:10:31.957086
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:10:42.672598
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:10:49.834154
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:10:55.511358
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    assert snippet(test_snippet).get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]



# Generated at 2022-06-18 01:11:02.517851
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:11:51.631036
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''
    extend(vars)
    print(x, y)
    ''')
    vars = ast.parse('''
    x = 1
    x = 2
    ''')
    extend_tree(tree, {'vars': vars.body})
    assert ast.dump(tree) == ast.dump(ast.parse('''
    x = 1
    x = 2
    print(x, y)
    '''))

# Generated at 2022-06-18 01:11:59.469818
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:12:08.974032
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:12:11.241530
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    x += 1
    let(y)
    y += 2
    """)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:12:20.739772
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:12:24.027524
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:12:30.697365
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:12:33.738283
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        x = 1
        y = 2
        z = 3
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:12:36.513507
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:12:46.521224
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)')
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=2))])'

