

# Generated at 2022-06-18 01:03:38.444883
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:03:43.940018
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:03:53.849584
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body()
    assert body == [
        ast.AugAssign(
            target=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
            op=ast.Add(),
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]


# Generated at 2022-06-18 01:04:03.586662
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    import snippets
    import snippets.helpers
    import snippets.tree
    import snippets.snippet
    import snippets.snippet_helpers
    import snippets.snippet_helpers.variables_generator
    import snippets.snippet_helpers.variables_replacer
    import snippets.snippet_helpers.variables_replacer.test_VariablesReplacer_visit_ImportFrom
    import snippets.snippet_helpers.variables_replacer.test_VariablesReplacer_visit_ImportFrom.test_VariablesReplacer_visit_ImportFrom
    import snippets.snippet_helpers.vari

# Generated at 2022-06-18 01:04:16.085893
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:04:21.468813
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:04:28.211813
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    import astor
    import sys
    import os

    class VariablesReplacer(ast.NodeTransformer):
        def __init__(self, variables: Dict[str, Variable]) -> None:
            self._variables = variables

        def _replace_field_or_node(self, node: T, field: str, all_types=False) -> T:
            value = getattr(node, field, None)
            if value in self._variables:
                if isinstance(self._variables[value], str):
                    setattr(node, field, self._variables[value])
                elif all_types or isinstance(self._variables[value], type(node)):
                    node = self._variables[value]  # type: ignore

            return node


# Generated at 2022-06-18 01:04:33.666485
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:04:37.632021
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        x = 1
        y = 2
        z = 3
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:04:42.472572
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:04:53.743220
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:05:01.099963
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_instance = snippet(test_fn)
    body = snippet_instance.get_body(x=1, y=2)

# Generated at 2022-06-18 01:05:07.270785
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:15.917613
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2)),
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:25.499284
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:05:36.113930
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    import astor
    import sys
    import os
    import inspect
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import inspect
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import inspect
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import inspect
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import inspect
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import inspect
    import re
    import astunparse
    import astor
    import ast
    import sys


# Generated at 2022-06-18 01:05:42.644790
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    """))

# Generated at 2022-06-18 01:05:52.255625
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:05:55.337814
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x)\nlet(y)\nx + y')
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:06:03.038443
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, vars=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                   value=ast.Num(n=2))])

# Generated at 2022-06-18 01:06:18.017706
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:06:28.097700
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:06:38.377759
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(test_snippet)
    snippet_body = snippet_instance.get_body(x=1, y=2)
    assert snippet_body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                                       ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                                 ast.Add(),
                                                 ast.Num(1))),
                            ast.Assign([ast.Name('y', ast.Store())],
                                       ast.Num(1))]

# Generated at 2022-06-18 01:06:42.672869
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:06:48.954784
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:06:56.655922
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:07:02.733823
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:07:07.980787
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        x = 1
        y = 2
        z = 3
    """)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:07:12.698959
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:07:19.143133
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """

# Generated at 2022-06-18 01:07:36.639762
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)')
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=2))])'

# Generated at 2022-06-18 01:07:41.180779
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:07:50.925561
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    def foo():
        extend(vars)
        print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:07:56.429194
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_fn)
    body = snippet_obj.get_body()
    assert body[0].value.id == '_py_backwards_x_0'
    assert body[1].value.value == 1

# Generated at 2022-06-18 01:08:05.535189
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:08:13.615530
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1


# Generated at 2022-06-18 01:08:14.523173
# Unit test for function extend_tree

# Generated at 2022-06-18 01:08:24.576100
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:08:30.509379
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:08:40.097394
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:09:05.346111
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    assert snippet_obj.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]


# Unit

# Generated at 2022-06-18 01:09:14.529469
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:09:21.815884
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_fn)
    snippet_body = snippet_obj.get_body()
    assert snippet_body[0].value.left.id == '_py_backwards_x_0'
    assert snippet_body[0].value.op.__class__.__name__ == 'Add'
    assert snippet_body[0].value.right.n == 1
    assert snippet_body[1].value.n == 1
    assert snippet_body[1].targets[0].id == 'y'


# Generated at 2022-06-18 01:09:30.055724
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                               ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                         ast.Add(),
                                         ast.Num(1))),
                     ast.Assign([ast.Name('y', ast.Store())],
                                ast.Num(1))]

# Generated at 2022-06-18 01:09:35.051638
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """

# Generated at 2022-06-18 01:09:35.808386
# Unit test for function extend_tree

# Generated at 2022-06-18 01:09:40.199775
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """

# Generated at 2022-06-18 01:09:46.017318
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:09:50.263047
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:09:54.626889
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:10:36.859885
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:10:42.422748
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:10:49.666999
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    extend(vars)
    print(x, y)
    """
    tree = ast.parse(source)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:10:53.600050
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)')
    vars = ast.parse('x = 1\nx = 2')
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=2))])'

# Generated at 2022-06-18 01:10:56.074660
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(x)
let(y)
let(z)
x += 1
y += 2
z += 3
""")
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:11:07.059483
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                           value=ast.Num(n=1)),
                                ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                           value=ast.Num(n=2))]})

# Generated at 2022-06-18 01:11:13.724193
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:11:18.959748
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:11:29.975558
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_fn)
    assert snippet_obj.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:11:39.569633
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y


# Generated at 2022-06-18 01:12:14.255031
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:12:23.244749
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:12:31.101120
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """

# Generated at 2022-06-18 01:12:35.629767
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int):
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    snippet_body = snippet_obj.get_body(x=ast.Name(id='x', ctx=ast.Load()), y=ast.Name(id='y', ctx=ast.Load()))

# Generated at 2022-06-18 01:12:42.037743
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:12:47.340493
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(fn)
    body = snippet_.get_body()
    assert body == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:12:53.263747
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    assert snippet_.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:13:02.978955
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:13:09.056107
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    assert snippet(test_snippet).get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]



# Generated at 2022-06-18 01:13:18.522527
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)
    assert len(body) == 2
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[0].value, ast.BinOp)
    assert isinstance(body[0].value.left, ast.Name)
    assert isinstance(body[0].value.right, ast.Num)
    assert isinstance(body[1].value, ast.Num)