

# Generated at 2022-06-18 01:03:41.286671
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body()
    assert body[0].value.left.id == '_py_backwards_x_0'
    assert body[0].value.op.__class__.__name__ == 'Add'
    assert body[0].value.right.n == 1
    assert body[1].value.n == 1
    assert body[1].targets[0].id == 'y'



# Generated at 2022-06-18 01:03:52.483345
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:04:01.885008
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:04:06.548329
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:12.006207
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("from a import b as c")
    variables = {'a': 'd'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "ImportFrom(module='d', names=[alias(name='b', asname='c')], level=0)"

# Generated at 2022-06-18 01:04:19.274610
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())], ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()), ast.Add(), ast.Num(1))), ast.Assign([ast.Name('y', ast.Store())], ast.Num(1))]

# Generated at 2022-06-18 01:04:27.133673
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:04:32.272820
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from = ast.ImportFrom(module='a.b.c', names=[ast.alias(name='d', asname='e')], level=0)
    variables = {'a': 'A', 'b': 'B', 'c': 'C', 'd': 'D', 'e': 'E'}
    VariablesReplacer.replace(import_from, variables)
    assert import_from.module == 'A.B.C'
    assert import_from.names[0].name == 'D'
    assert import_from.names[0].asname == 'E'

# Generated at 2022-06-18 01:04:35.331292
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    x = 1
    y = 2
    """)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:04:44.184718
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:04:56.686294
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:05:00.703352
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:11.595491
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    import backwards
    import backwards.tree
    import backwards.helpers
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet
    import backwards.snippet

# Generated at 2022-06-18 01:05:19.600376
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    import sys
    import os
    import inspect
    import astunparse
    import astpretty
    import astor
    import ast
    import astor
    import sys
    import os
    import inspect
    import astunparse
    import astpretty
    import astor
    import ast
    import astor
    import sys
    import os
    import inspect
    import astunparse
    import astpretty
    import astor
    import ast
    import astor
    import sys
    import os
    import inspect
    import astunparse
    import astpretty
    import astor
    import ast
    import astor
    import sys
    import os
    import inspect
    import astunparse
    import astpretty
    import astor
    import ast
    import astor
    import sys
   

# Generated at 2022-06-18 01:05:28.082688
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()))

# Generated at 2022-06-18 01:05:36.563171
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .test_helpers import assert_source_equal
    from .helpers import VariablesGenerator

    source = '''
    from a.b.c import d
    '''

    tree = ast.parse(source)
    variables = {'a': VariablesGenerator.generate('a'),
                 'b': VariablesGenerator.generate('b'),
                 'c': VariablesGenerator.generate('c'),
                 'd': VariablesGenerator.generate('d')}
    VariablesReplacer.replace(tree, variables)
    assert_source_equal(source, tree)



# Generated at 2022-06-18 01:05:41.476213
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:50.553715
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(test_snippet)
    body = snippet_instance.get_body()
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                               ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                         ast.Add(),
                                         ast.Num(1))),
                     ast.Assign([ast.Name('y', ast.Store())],
                                ast.Num(1))]

# Generated at 2022-06-18 01:05:59.467757
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:06:05.686944
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars.body})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:06:20.984939
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    from ast import alias
    from ast import ImportFrom
    from ast import Module
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse
    from ast import parse

# Generated at 2022-06-18 01:06:24.025187
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:06:27.058079
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:06:38.697314
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(x)')
    extend_tree(tree, {'x': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                       value=ast.Num(n=1)),
                            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                       value=ast.Num(n=2))]})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=2))])'



# Generated at 2022-06-18 01:06:46.317959
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[0].target, ast.Name)
    assert isinstance(body[1].value, ast.Num)
    assert body[0].target.id == '_py_backwards_x_0'
    assert body[1].value.n == 1

# Generated at 2022-06-18 01:06:54.951253
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    import sys
    import os
    import inspect
    import unittest

    class TestVariablesReplacer(unittest.TestCase):
        def test_visit_alias(self):
            import_node = ast.parse("from a import b as c").body[0]
            variables = {'a': 'd', 'b': 'e', 'c': 'f'}
            replacer = VariablesReplacer(variables)
            replacer.visit(import_node)
            self.assertEqual(astor.to_source(import_node), "from d import e as f")

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-18 01:06:59.268741
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:07:05.723272
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:07:14.073508
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from typed_ast import ast3 as ast
    from .tree import find
    from .helpers import VariablesGenerator
    from .snippet import VariablesReplacer
    from .snippet import let
    from .snippet import extend
    import sys
    import os
    import io
    import unittest
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse

# Generated at 2022-06-18 01:07:23.231787
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:07:32.358026
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:07:41.304288
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    assert snippet_obj.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]


# Unit

# Generated at 2022-06-18 01:07:51.029347
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        let(y)
        x += 1
        y += 2
        print(x, y)

    snippet_obj = snippet(test_snippet)
    snippet_body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:08:02.249823
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:08:04.627103
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:08:06.520586
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:08:09.533643
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:08:20.239256
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1


# Generated at 2022-06-18 01:08:25.528154
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:08:35.182779
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:08:51.144005
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars.body})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:09:01.830537
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    assert snippet_.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]



# Generated at 2022-06-18 01:09:06.807512
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:09:10.085778
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:09:13.881590
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:09:22.494758
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:09:30.728125
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:09:39.310395
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nprint(x, y)')
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:09:44.370867
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:09:51.131514
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """



# Generated at 2022-06-18 01:10:19.676475
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:10:29.925233
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    snippet_body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:10:35.022221
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        let(a)
        let(b)
        let(c)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z', 'a', 'b', 'c']



# Generated at 2022-06-18 01:10:38.088636
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:10:47.364766
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)
    assert body[0].value.left.id == '_py_backwards_x_0'
    assert body[0].value.op.__class__.__name__ == 'Add'
    assert body[1].value.n == 1
    assert body[2].value.left.id == '_py_backwards_x_0'
    assert body[2].value.op.__class__.__name__ == 'Add'
    assert body[2].value.right.id == 'y'
    assert body

# Generated at 2022-06-18 01:10:49.053376
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''
    let(x)
    let(y)
    x = 1
    y = 2
    ''')
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:10:50.653912
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:10:53.867085
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:11:04.625798
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:11:09.051176
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-18 01:12:02.925143
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:12:11.857282
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int):
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=ast.Name(id='x', ctx=ast.Load()), y=ast.Name(id='y', ctx=ast.Load()))

# Generated at 2022-06-18 01:12:17.940958
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:12:20.352663
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x += 1
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x']



# Generated at 2022-06-18 01:12:25.591313
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))


# Generated at 2022-06-18 01:12:32.410205
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:12:36.013178
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-18 01:12:45.316700
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                               ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                         ast.Add(),
                                         ast.Num(1))),
                     ast.Assign([ast.Name('y', ast.Store())],
                                ast.Num(1))]

# Generated at 2022-06-18 01:12:48.060796
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:12:54.568027
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y
