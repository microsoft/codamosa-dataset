

# Generated at 2022-06-18 01:03:45.413277
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:03:49.434775
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:03:58.189804
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:04:01.167262
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:04:07.868784
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:18.080429
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:21.047898
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """

# Generated at 2022-06-18 01:04:27.467479
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))



# Generated at 2022-06-18 01:04:36.717121
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .helpers import get_source
    from .tree import find
    from .snippet import VariablesReplacer
    from .snippet import let
    from .snippet import extend
    from .snippet import snippet

    def test_fn():
        let(x)
        import x.y.z
        extend(x)

    source = get_source(test_fn)
    tree = ast.parse(source)
    names = find(tree, ast.Name)
    variables = {name.id: VariablesGenerator.generate(name.id) for name in names}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].body[0].value.module == '_py_backwards_x_0.y.z'

# Generated at 2022-06-18 01:04:39.496504
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:04:55.168855
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:05:01.598691
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:03.352032
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert find_variables(tree) == ['x', 'y']



# Generated at 2022-06-18 01:05:09.129224
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:17.173561
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:22.446950
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:25.054122
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from = ast.parse("from a import b").body[0]
    assert VariablesReplacer.replace(import_from, {'a': 'c'}).module == 'c'



# Generated at 2022-06-18 01:05:27.869745
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:05:38.637508
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1),
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2),
        ),
    ]

    body = snippet(test_snippet).get_body(x=1, y=2, vars=vars)

# Generated at 2022-06-18 01:05:41.277540
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:06:32.059222
# Unit test for function find_variables

# Generated at 2022-06-18 01:06:39.989262
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> int:
        let(z)
        z = x + y
        return z

    snippet_obj = snippet(test_fn)
    body = snippet_obj.get_body(x=1, y=2)
    assert body == [ast.Assign([ast.Name(id='_py_backwards_z_0', ctx=ast.Store())],
                               ast.BinOp(ast.Num(n=1), ast.Add(), ast.Num(n=2)))]



# Generated at 2022-06-18 01:06:51.087213
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2)),
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:06:57.708240
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:07:01.514286
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:07:11.862136
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet():
        let(x)
        x += 1
        y = 1

    assert test_snippet.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]



# Generated at 2022-06-18 01:07:22.348715
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body(x=1, y=2)
    assert len(body) == 2
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[0].value, ast.BinOp)
    assert isinstance(body[0].value.left, ast.Name)
    assert body[0].value.left.id == '_py_backwards_x_0'
    assert isinstance(body[0].value.op, ast.Add)
    assert isinstance(body[0].value.right, ast.Num)
    assert body[0].value.right.n

# Generated at 2022-06-18 01:07:26.204190
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        x = 1
        y = 2
        z = 3
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:07:30.525325
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:07:39.815135
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:08:28.282528
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    snippet_obj = snippet(test)
    snippet_obj.get_body(x=1, y=2, vars=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                    value=ast.Num(n=1)),
                                          ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                     value=ast.Num(n=2))])

# Generated at 2022-06-18 01:08:39.290081
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:08:43.183570
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:08:49.971678
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:08:59.545208
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:09:09.154931
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:09:13.314100
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        x = 1
        y = 2
        z = 3
    """)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:09:18.235180
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    let(y)
    let(z)
    '''
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:09:25.018051
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:09:27.949164
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:11:02.780580
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x)\nlet(y)')
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:11:13.386457
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:11:16.398674
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    x = 1
    y = 2
    """)
    assert list(find_variables(tree)) == ['x']



# Generated at 2022-06-18 01:11:19.291667
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:11:21.454246
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:11:27.093912
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """

# Generated at 2022-06-18 01:11:30.120567
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:11:33.401667
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:11:40.787002
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                               ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                         ast.Add(),
                                         ast.Num(1))),
                     ast.Assign([ast.Name('y', ast.Store())],
                                ast.Num(1))]

# Generated at 2022-06-18 01:11:50.649923
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)