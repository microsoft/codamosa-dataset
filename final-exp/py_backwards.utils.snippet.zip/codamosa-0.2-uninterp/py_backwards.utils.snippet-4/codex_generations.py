

# Generated at 2022-06-18 01:03:43.306021
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    import astor
    import sys
    import os
    import inspect
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import inspect
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import inspect
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import inspect
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import inspect
    import re
    import astunparse
    import astor
    import ast
    import sys
    import os
    import inspect
    import re
    import astunparse
    import astor
    import ast
    import sys


# Generated at 2022-06-18 01:03:45.009295
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:03:55.665179
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1


# Generated at 2022-06-18 01:04:04.830130
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    import sys
    import os
    import inspect
    import importlib

    # Get the path of the current file
    path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))

    # Add the path to the sys.path
    sys.path.insert(0, path)

    # Import the module
    import py_backwards

    # Get the source code of the module
    source = inspect.getsource(py_backwards)

    # Parse the source code
    tree = ast.parse(source)

    # Get the class VariablesReplacer
    cls = py_backwards.VariablesReplacer

    # Get the method visit_alias
    method = cls.visit_alias

    # Get the AST of the method


# Generated at 2022-06-18 01:04:16.549922
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    from .tree import find
    from .helpers import VariablesGenerator
    from .snippet import VariablesReplacer
    from .snippet import let

    def test_func():
        let(x)
        let(y)
        let(z)
        let(a)
        let(b)
        let(c)
        let(d)
        let(e)
        let(f)
        let(g)
        let(h)
        let(i)
        let(j)
        let(k)
        let(l)
        let(m)
        let(n)
        let(o)
        let(p)
        let(q)
        let(r)
        let(s)
        let(t)
        let(u)


# Generated at 2022-06-18 01:04:23.917087
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    from .helpers import get_source
    from .tree import find
    from .snippet import VariablesReplacer

    source = get_source(test_VariablesReplacer_visit_alias)
    tree = ast.parse(source)
    variables = {'x': 'y'}
    VariablesReplacer.replace(tree, variables)
    for node in find(tree, ast.alias):
        assert node.name == 'y'
        assert node.asname == 'x'

# Generated at 2022-06-18 01:04:26.952506
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:04:36.475801
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    assert snippet_obj.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:04:46.341435
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:55.091240
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:05:02.551413
# Unit test for function extend_tree

# Generated at 2022-06-18 01:05:10.631854
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    snippet_obj = snippet(snippet_fn)
    snippet_obj.get_body(x=1, y=2, vars=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                    value=ast.Num(n=1)),
                                          ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                    value=ast.Num(n=2))])

# Generated at 2022-06-18 01:05:18.988669
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    from .tree import find
    from .helpers import VariablesGenerator
    from .snippet import VariablesReplacer
    from .snippet import let
    from .snippet import extend

    def test_snippet():
        let(x)
        let(y)
        extend(vars)

    tree = ast.parse(get_source(test_snippet))
    variables = {name: VariablesGenerator.generate(name)
                 for name in find_variables(tree)}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.ImportFrom)
    assert tree.body[0].module

# Generated at 2022-06-18 01:05:22.588848
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
let(x)
let(y)
let(z)
x = 1
y = 2
z = 3
""")
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:05:27.268545
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:05:37.999166
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:05:40.813194
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:05:50.589338
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:06:00.313450
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1


# Generated at 2022-06-18 01:06:10.106079
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body(x=1, y=2)
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                               ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                         ast.Add(),
                                         ast.Num(1))),
                     ast.Assign([ast.Name('y', ast.Store())],
                                ast.Num(1))]

# Generated at 2022-06-18 01:06:24.278871
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    from .helpers import VariablesGenerator
    from .tree import find
    from .snippet import VariablesReplacer
    from .snippet import let
    from .snippet import extend
    from .snippet import snippet
    from .snippet import find_variables
    from .snippet import get_body
    from .snippet import _get_variables
    from .snippet import _replace_module
    from .snippet import _replace_field_or_node
    from .snippet import replace
    from .snippet import extend_tree
    from .snippet import _replace_module
    from .snippet import _replace_field_or_node
    from .snippet import replace
    from .snippet import extend_tree

# Generated at 2022-06-18 01:06:32.242353
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:06:38.751926
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(snippet_fn)
    snippet_body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:06:44.602378
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:06:54.439046
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import get_source
    from .tree import find
    from .snippet import VariablesReplacer
    from .snippet import let
    from .snippet import extend
    from .snippet import snippet

    def test_func():
        let(x)
        let(y)
        extend(vars)
        print(x, y)

    source = get_source(test_func)
    tree = ast.parse(source)

# Generated at 2022-06-18 01:07:00.292958
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-18 01:07:04.227724
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars.body})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:07:12.912565
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:07:16.870556
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:07:22.347817
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:07:43.706477
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]


# Generated at 2022-06-18 01:07:49.006805
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nprint(x, y)')
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:07:54.441463
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:07:59.700029
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:08:08.595978
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> int:
        let(z)
        z = x + y
        return z

    snippet_instance = snippet(test_fn)
    body = snippet_instance.get_body(x=1, y=2)
    assert len(body) == 1
    assert isinstance(body[0], ast.Return)
    assert isinstance(body[0].value, ast.BinOp)
    assert isinstance(body[0].value.left, ast.Name)
    assert body[0].value.left.id == '_py_backwards_z_0'
    assert isinstance(body[0].value.right, ast.Num)
    assert body[0].value.right.n == 2



# Generated at 2022-06-18 01:08:11.529957
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    let(y)
    '''
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:08:22.489010
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:08:25.089258
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:08:31.795925
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
        x = 1
        x = 2
    """)
    extend_tree(tree, {'vars': vars.body})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:08:41.385639
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body()
    assert body == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:09:05.498709
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x: int, y: int) -> None:
        let(z)
        z = x + y
        print(z)

    snippet_ = snippet(f)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:09:14.713778
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body(x=1, y=2)
    assert len(body) == 2
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[0].value, ast.BinOp)
    assert isinstance(body[0].value.left, ast.Name)
    assert isinstance(body[0].value.right, ast.Num)
    assert isinstance(body[1].value, ast.Num)

# Generated at 2022-06-18 01:09:20.482669
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:09:30.239973
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    assert snippet_obj.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:09:38.949463
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(a: int, b: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)
    assert len(body) == 3
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[2], ast.Return)
    assert body[0].targets[0].id == '_py_backwards_x_0'
    assert body[1].targets[0].id == 'y'
    assert isinstance(body[2].value, ast.BinOp)

# Generated at 2022-06-18 01:09:48.268083
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> int:
        let(z)
        z = x + y
        return z

    snippet_obj = snippet(test_fn)
    snippet_body = snippet_obj.get_body(x=1, y=2)
    assert snippet_body == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_z_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Num(n=1),
                op=ast.Add(),
                right=ast.Num(n=2)
            )
        ),
        ast.Return(value=ast.Name(id='_py_backwards_z_0', ctx=ast.Load()))
    ]

# Generated at 2022-06-18 01:09:51.526734
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    x = 1
    x = 2
    print(x, y)
    """

# Generated at 2022-06-18 01:09:59.899514
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:10:10.216440
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:10:17.949453
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:10:52.035564
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))



# Generated at 2022-06-18 01:10:57.545009
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:11:04.501037
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:11:14.567298
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:11:21.214415
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
        extend(vars)
        print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
        x = 1
        x = 2
        print(x, y)
    """))

# Generated at 2022-06-18 01:11:30.682762
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet():
        let(x)
        x += 1
        y = 1

    assert test_snippet.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]



# Generated at 2022-06-18 01:11:39.830346
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:11:43.831929
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x += 1
    y = 1
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert set(variables) == {'x', 'y'}



# Generated at 2022-06-18 01:11:53.741480
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:12:00.610902
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)
    assert isinstance(body, list)
    assert len(body) == 2
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[1], ast.Assign)
    assert body[0].targets[0].id == '_py_backwards_x_0'
    assert body[1].targets[0].id == 'y'
    assert body[0].value.value == 2
    assert body[1].value.value == 1

# Generated at 2022-06-18 01:13:14.781529
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    def f():
        extend(vars)
        print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert get_source(tree) == """
    def f():
        x = 1
        x = 2
        print(x, y)
    """

# Generated at 2022-06-18 01:13:23.353011
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:13:32.800454
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)')
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=2))])'