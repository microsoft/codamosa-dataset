

# Generated at 2022-06-18 01:03:41.685736
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)\nprint(x, y)')
    vars = [ast.parse('x = 1'), ast.parse('x = 2')]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == 'Module(body=[Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=2)), Expr(value=Call(func=Name(id=\'print\', ctx=Load()), args=[Name(id=\'x\', ctx=Load()), Name(id=\'y\', ctx=Load())], keywords=[]))])'

# Generated at 2022-06-18 01:03:52.881212
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    assert snippet_obj.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]


# Unit

# Generated at 2022-06-18 01:04:02.017017
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import astor
    import ast
    import unittest
    from .helpers import VariablesGenerator
    from .variables import VariablesReplacer

    class TestVariablesReplacer(unittest.TestCase):
        def test_visit_alias(self):
            node = ast.parse('from a import b as c').body[0]
            variables = {'a': VariablesGenerator.generate('a'),
                         'b': VariablesGenerator.generate('b'),
                         'c': VariablesGenerator.generate('c')}
            VariablesReplacer.replace(node, variables)
            self.assertEqual(astor.to_source(node),
                             'from _py_backwards_a_0 import _py_backwards_b_0 as _py_backwards_c_0')

   

# Generated at 2022-06-18 01:04:05.309576
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x = 1
    let(y)
    y = 2
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:04:16.715254
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:04:21.666204
# Unit test for function find_variables
def test_find_variables():
    source = '''
    let(x)
    let(y)
    let(z)
    '''
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:04:28.803640
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:04:37.941980
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body()
    assert body == [ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                               value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                               op=ast.Add(),
                                               right=ast.Num(n=1))),
                     ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                                value=ast.Num(n=1))]


# Generated at 2022-06-18 01:04:41.064905
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert list(variables) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:04:44.184620
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:04:59.172401
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import astor
    from .helpers import VariablesGenerator
    from .tree import find
    from .snippet import VariablesReplacer

    source = '''
    import a.b as c
    '''

    tree = ast.parse(source)
    variables = {'a': VariablesGenerator.generate('a'),
                 'b': VariablesGenerator.generate('b'),
                 'c': VariablesGenerator.generate('c')}
    VariablesReplacer.replace(tree, variables)
    assert astor.to_source(tree) == '''
    import {}.{} as {}
    '''.format(variables['a'], variables['b'], variables['c'])

# Generated at 2022-06-18 01:05:10.678993
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:05:19.018866
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=ast.Name(id='_x', ctx=ast.Load()), y=2)

# Generated at 2022-06-18 01:05:22.628527
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:05:29.321387
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    from .helpers import VariablesGenerator
    from .tree import find
    from .snippet import VariablesReplacer
    from .snippet import let
    from .snippet import extend

    def test_function():
        let(x)
        extend(vars)
        print(x)

    source = get_source(test_function)
    tree = ast.parse(source)
    names = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name)
                 for name in names}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    print(astor.to_source(tree))

# Generated at 2022-06-18 01:05:39.573481
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    snippet_body = snippet_obj.get_body()
    assert snippet_body == [ast.Assign(
        targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
        value=ast.BinOp(
            left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
            op=ast.Add(),
            right=ast.Num(n=1)
        )
    ), ast.Assign(
        targets=[ast.Name(id='y', ctx=ast.Store())],
        value=ast.Num(n=1)
    )]

# Generated at 2022-06-18 01:05:41.976666
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:05:51.972108
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    snippet_instance = snippet(snippet_fn)
    snippet_body = snippet_instance.get_body(x=1, y=2, vars=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                                       value=ast.Num(n=1)),
                                                           ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                                      value=ast.Num(n=2))])

# Generated at 2022-06-18 01:06:01.372233
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> None:
        let(x)
        let(y)
        x += 1
        y += 1
        print(x, y)

    snippet_ = snippet(test_fn)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:06:12.410466
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body()

# Generated at 2022-06-18 01:06:32.469205
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(test_snippet)
    body = snippet_instance.get_body(x=1, y=2)

# Generated at 2022-06-18 01:06:36.282650
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:06:45.965887
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:06:55.210383
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test)
    assert snippet_.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]



# Generated at 2022-06-18 01:07:04.227982
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:07:11.799401
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
let(vars)
extend(vars)
""")
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
x = 1
x = 2
"""))

# Generated at 2022-06-18 01:07:16.312067
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:07:20.078230
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:07:27.896167
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(test_snippet)
    assert snippet_instance.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:07:31.645744
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        x = 1
        y = 2
    """)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:07:49.510168
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_ = snippet(fn)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:07:51.831927
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:08:02.827612
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''
    extend(vars)
    print(x, y)
    ''')
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:08:05.361809
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:08:10.410414
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:08:21.303846
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:08:29.142542
# Unit test for function find_variables

# Generated at 2022-06-18 01:08:40.099071
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)


# Generated at 2022-06-18 01:08:51.524681
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_fn)
    body = snippet_obj.get_body()
    assert body == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
            value=ast.BinOp(
                left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                op=ast.Add(),
                right=ast.Num(n=1)
            )
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:09:02.288470
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(test_fn)
    body = snippet_obj.get_body(x=1, y=2)

# Generated at 2022-06-18 01:09:20.417952
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:09:30.228229
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body(x=1, y=2)

# Generated at 2022-06-18 01:09:38.149788
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:09:47.346273
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        x += 1
        y = 1
        return x + y

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=2, y=3)

# Generated at 2022-06-18 01:09:50.584040
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:09:53.485263
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:09:56.530527
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:10:00.135861
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        x += 1
        y = 1
        z = 2
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:10:10.454027
# Unit test for function extend_tree
def test_extend_tree():
    source = """
    extend(vars)
    print(x, y)
    """
    tree = ast.parse(source)
    vars = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2))
    ]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:10:15.740351
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:10:29.718417
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = ast.parse("""
    x = 1
    x = 2
    """)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == ast.dump(ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """))

# Generated at 2022-06-18 01:10:33.989917
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:10:44.189397
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-18 01:10:50.570009
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1


# Generated at 2022-06-18 01:10:52.897529
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x += 1
    let(y)
    y += 1
    """
    tree = ast.parse(source)
    variables = list(find_variables(tree))
    assert variables == ['x', 'y']



# Generated at 2022-06-18 01:10:58.001940
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_fn)
    body = snippet_.get_body(x=1, y=2)
    assert body == [ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                               ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                         op=ast.Add(),
                                         right=ast.Num(n=1))),
                     ast.Assign([ast.Name(id='y', ctx=ast.Store())],
                                ast.Num(n=1))]

# Generated at 2022-06-18 01:11:02.845345
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        let(a)
        let(b)
        let(c)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z', 'a', 'b', 'c']



# Generated at 2022-06-18 01:11:06.130190
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    x += 1
    y += 1
    """)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:11:12.205418
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    body = snippet_obj.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.AugAssign)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-18 01:11:16.063434
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
        let(x)
        let(y)
        let(z)
        x = 1
        y = 2
        z = 3
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:11:29.122018
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:11:33.556597
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    let(z)
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y', 'z'}



# Generated at 2022-06-18 01:11:37.132869
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert find_variables(tree) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:11:43.039461
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)
    snippet_body = snippet_obj.get_body(x=1, y=2)
    assert len(snippet_body) == 2
    assert isinstance(snippet_body[0], ast.Assign)
    assert isinstance(snippet_body[1], ast.Assign)
    assert snippet_body[0].targets[0].id == '_py_backwards_x_0'
    assert snippet_body[1].targets[0].id == 'y'
    assert isinstance(snippet_body[0].value, ast.BinOp)

# Generated at 2022-06-18 01:11:53.129807
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(x)
        y = 1
        return x + y

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()))

# Generated at 2022-06-18 01:12:00.067962
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)
    body = snippet_.get_body()
    assert body == [
        ast.AugAssign(
            target=ast.Name(id='_py_backwards_x_0', ctx=ast.Store()),
            op=ast.Add(),
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Store())],
            value=ast.Num(n=1)
        )
    ]

# Generated at 2022-06-18 01:12:04.475451
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:12:08.161894
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:12:10.905600
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    let(z)
    """)
    assert list(find_variables(tree)) == ['x', 'y', 'z']



# Generated at 2022-06-18 01:12:13.382921
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    let(y)
    x += 1
    y = 1
    """)
    assert list(find_variables(tree)) == ['x', 'y']



# Generated at 2022-06-18 01:12:33.388077
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(snippet_fn)
    snippet_body = snippet_obj.get_body(x=1, y=2)
    assert len(snippet_body) == 2
    assert isinstance(snippet_body[0], ast.Assign)
    assert isinstance(snippet_body[1], ast.Assign)
    assert isinstance(snippet_body[0].value, ast.BinOp)
    assert isinstance(snippet_body[0].value.left, ast.Name)
    assert isinstance(snippet_body[0].value.right, ast.Num)

# Generated at 2022-06-18 01:12:36.004314
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    let(y)
    x = 1
    y = 2
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:12:46.150742
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_instance = snippet(test_snippet)
    body = snippet_instance.get_body(x=1, y=2)
    assert body == [ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                               ast.BinOp(ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                         ast.Add(),
                                         ast.Num(n=1))),
                     ast.Assign([ast.Name(id='y', ctx=ast.Store())],
                                ast.Num(n=1))]

# Generated at 2022-06-18 01:12:48.782847
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(x)
    x += 1
    let(y)
    y = 1
    """
    tree = ast.parse(source)
    assert set(find_variables(tree)) == {'x', 'y'}



# Generated at 2022-06-18 01:12:55.330123
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_snippet)

# Generated at 2022-06-18 01:13:01.332261
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn(x: int) -> int:
        let(y)
        return x + y

    snippet_obj = snippet(test_fn)
    body = snippet_obj.get_body(y=1)
    assert body == [ast.Assign([ast.Name('_py_backwards_y_0', ast.Store())],
                               ast.Num(1))]



# Generated at 2022-06-18 01:13:07.812484
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> int:
        let(z)
        return x + y + z

    snippet_obj = snippet(test_snippet)
    body = snippet_obj.get_body(x=1, y=2, z=3)
    assert body == [ast.Assign([ast.Name('_py_backwards_z_0', ast.Store())],
                               ast.Num(3)),
                     ast.Return(ast.BinOp(ast.BinOp(ast.Num(1), ast.Add(), ast.Num(2)),
                                          ast.Add(),
                                          ast.Name('_py_backwards_z_0', ast.Load())))]

# Generated at 2022-06-18 01:13:17.182710
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1

    snippet_ = snippet(test_snippet)

# Generated at 2022-06-18 01:13:24.902434
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        x += 1
        y = 1

    snippet_obj = snippet(test_fn)
    body = snippet_obj.get_body()
    assert len(body) == 2
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[1], ast.Assign)
    assert body[0].targets[0].id == '_py_backwards_x_0'
    assert body[1].targets[0].id == 'y'
    assert body[0].value.op == 'Add'
    assert body[1].value.n == 1
    assert body[0].value.left.id == '_py_backwards_x_0'
    assert body[0].value.right.n == 1

