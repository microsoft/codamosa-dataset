

# Generated at 2022-06-25 23:14:39.108399
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    extend_tree(a_s_t_0, {"a_s_t_1": a_s_t_1})


# Generated at 2022-06-25 23:14:40.783707
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(test_case_0) == {'a_s_t_0'}


# Generated at 2022-06-25 23:14:47.615742
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Module()
    a_s_t_0.body.extend([a_s_t_1])
    a_s_t_2 = module_0.Call()
    a_s_t_3 = module_0.Name()
    a_s_t_3.id = 'extend'
    a_s_t_3.ctx = module_0.Load()
    a_s_t_2.func = a_s_t_3
    a_s_t_4 = module_0.Name()
    a_s_t_4.id = 'a'
    a_s_t_4.ctx = module_0.Load()
    a_s_t_2.args

# Generated at 2022-06-25 23:14:50.728912
# Unit test for function find_variables
def test_find_variables():
    import astor

    tree = ast.parse('let(a); let(b); a + b')
    assert list(find_variables(tree)) == ['a', 'b']
    assert astor.to_source(tree) == 'a + b'



# Generated at 2022-06-25 23:15:00.231598
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def source():
        let(x)
        x += 1
        y = 1

    snippet_0 = snippet(source)
    
    s_n_i_p_p_e_t_k_w_a_r_g_s_0 = {"x": 0}
    body_0 = snippet_0.get_body(**s_n_i_p_p_e_t_k_w_a_r_g_s_0)
    assert(body_0 == [ast.Assign([ast.Name("x", ast.Store())], [ast.BinOp(ast.Name("x", ast.Load()), ast.Add(), ast.Num(1))]), ast.Assign([ast.Name("y", ast.Store())], [ast.Num(1)])])


# Generated at 2022-06-25 23:15:07.455304
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class snippet_get_body_0(snippet):
        def __init__(self):
            pass
        def get_body(self, **snippet_kwargs_1):
            return None
        def _get_variables(self, tree_2, snippet_kwargs_3):
            return {}
    snippet_get_body_0_0 = snippet_get_body_0()
    snippet_get_body_0_1 = snippet_get_body_0_0.get_body(a_0=1)


# Generated at 2022-06-25 23:15:11.926912
# Unit test for function find_variables
def test_find_variables():
    source = \
        """let(x)
        let(y)
        print(x, y)
        """
    tree = ast.parse(source)
    variables = eager(find_variables)(tree)
    assert list(variables) == ['x', 'y']


# Generated at 2022-06-25 23:15:14.635819
# Unit test for function find_variables
def test_find_variables():
    prog = """let(x)
let(y)
x"""

    assert list(find_variables(ast.parse(prog))) == ['x', 'y']


# Generated at 2022-06-25 23:15:23.512726
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f():
        let(x) # type: ignore
        let(y) # type: ignore
        y += x # type: ignore
    x = f.get_body(x=1, y=2)
    assert_equal(x[0].value.left.id, '_py_backwards_x_0') # type: ignore
    assert_equal(x[0].value.right.n, 1) # type: ignore
    assert_equal(x[1].value.left.id, '_py_backwards_y_1') # type: ignore
    assert_equal(x[1].value.right.n, 2) # type: ignore
    assert_equal(x[2].value.left.id, '_py_backwards_y_1') # type: ignore
    assert_equal

# Generated at 2022-06-25 23:15:32.003153
# Unit test for function find_variables
def test_find_variables():
    import sys
    from typed_ast import ast3 as ast
    from .tree import find, get_non_exp_parent_and_index, replace_at
    from .helpers import eager, VariablesGenerator, get_source
    from .snippet import VariablesReplacer
    from .snippet import snippet
    for module in (ast, eager, find, get_non_exp_parent_and_index, get_source,
                   replace_at, snippet, VariablesGenerator, VariablesReplacer,
                   sys):
        importlib.reload(module)

    source = '''
    def test_snippet():
        let(x)
        x += 1
        extend(x)
        y = 1
    '''

    tree = ast.parse(source)

# Generated at 2022-06-25 23:15:46.081892
# Unit test for function extend_tree
def test_extend_tree():
    int_0 = 123
    source = '''
        extend(vars)
        '''.format(int_0)
    tree = ast.parse(source)
    assert ast.dump(tree) == "Module(body=[Extend(vars=Name(id='vars', ctx=Load()))])"
    replace_map = {'vars': [ast.Assign(
        targets=[ast.Name(id='x', ctx=ast.Store())],
        value=ast.Num(n=1))]}
    extend_tree(tree, replace_map)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Extend(vars=Name(id='vars', ctx=Load()))])"

# Generated at 2022-06-25 23:15:48.828445
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)
    assert snippet_0.get_body() == [ast.Assign([ast.Name('_py_backwards_int_0_0', ast.Load())], ast.Constant(1, None))]

# Generated at 2022-06-25 23:15:53.610734
# Unit test for function extend_tree
def test_extend_tree():
    def my_func():
        int_0 = 1
        int_0 += 1
        print(int_0)

    tree = ast.parse(get_source(my_func)).body[0]
    assert tree.body[0].targets[0].id == 'int_0'

    variables = find_variables(tree)
    variables['int_0'] = [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(n=2)
        )
    ]
    extend_tree(tree, variables)


# Generated at 2022-06-25 23:15:55.996167
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse(get_source(test_case_0))
    variables = find_variables(tree)

    assert 'int_0' in variables


# Generated at 2022-06-25 23:16:05.712666
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    int_1 = 1
    int_0 = 2
    @snippet
    def add(x, y):
        '''adds two values'''
        let(x)
        let(y)

        x += 1
        y += 1

        return x + y

    assert len(add.get_body(x=int_1, y=int_0)) == 6

# Generated at 2022-06-25 23:16:17.399336
# Unit test for function extend_tree
def test_extend_tree():
    import pytest

    @snippet
    def a(x):
        let(a)
        extend(b)
        let(c)
        print(a, x, b, c)

    code = a.get_body(x=1, b=[ast.Assign(targets=[ast.Name(id='u')], value=ast.Num(n=1))])
    assert len(code) == 4
    assert isinstance(code[0], ast.Assign)
    assert len(code[0].targets) == 1
    assert isinstance(code[0].targets[0], ast.Name)
    assert code[0].targets[0].id == "u"
    assert isinstance(code[0].value, ast.Num)
    assert code[0].value.n == 1

   

# Generated at 2022-06-25 23:16:18.515391
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(test_case_0).to_list() == []

# Generated at 2022-06-25 23:16:29.266788
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    input_0 = snippet(test_case_0)
    expected_output = [
        ast.FunctionDef(
            name='test_case_0',
            args=ast.arguments(
                args=[],
                vararg=None,
                kwarg=None,
                kwonlyargs=[],
                defaults=[],
                kw_defaults=[]
            ),
            body=[
                ast.Assign(
                    targets=[
                        ast.Name(
                            id='int_0',
                            ctx=ast.Store()
                        )
                    ],
                    value=ast.Num(
                        n=1
                    )
                )
            ],
            decorator_list=[],
            returns=None
        )
    ]
    assert input_0.get_body() == expected_output



# Generated at 2022-06-25 23:16:32.837048
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import NodeVisitor, find, find_subtree
    namespace = globals()
    namespace.update(__builtins__=__builtins__)


# Generated at 2022-06-25 23:16:39.251856
# Unit test for function extend_tree
def test_extend_tree():
    a = 1
    b = 2
    c = 3

    treea = ast.parse('x = 5')
    treeb = ast.parse('y = 10')
    treemod = ast.parse('x = a + b + c')
    extend_tree(treemod, {'a': treea.body[0], 'b': treeb.body[0]})

    assert get_source(treemod) == 'x = a + b + c'

# Generated at 2022-06-25 23:16:52.609013
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('int_0 = 1')

# Generated at 2022-06-25 23:16:55.105504
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # 
    # Test 0
    # 
    f = snippet(test_case_0)
    output = ['int_0 = 1\n']
    assert f.get_body() == output


# Generated at 2022-06-25 23:16:56.060830
# Unit test for function extend_tree
def test_extend_tree():
    assert test_case_0() is None

# Generated at 2022-06-25 23:17:03.902933
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast
    import astunparse
    import types
    fn = test_case_0
    source = get_source(fn)
    tree = ast.parse(source)
    variables = {'var': ['var']}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert astunparse.unparse(tree.body[0]) == "int_0 = 1"
    assert type(snippet) == types.TypeType
    assert isinstance(snippet(fn), snippet) == True
    snp = snippet(fn)
    assert snp.get_body() == [ast.parse('int_0 = 1').body[0]]

# Generated at 2022-06-25 23:17:11.641916
# Unit test for function extend_tree
def test_extend_tree():
    from .helpers import get_source
    from .tree import find
    import astor.codegen as astor

    source = get_source(test_case_0)
    module = ast.parse(source)
    let(int_0)
    extend_tree(module, {'int_0': [ast.Assign(targets=[ast.Name(id='int_0', ctx=ast.Store())], value=ast.Num(n=2))]})

    assert astor.to_source(module) == 'int_0 = 1\n'
    assert astor.to_source(find(module, ast.Assign))[0] == 'int_0 = 2\n'

# Generated at 2022-06-25 23:17:15.015497
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse(get_source(test_case_0)).body[0]
    assert list(find_variables(tree)) == ['int_0']



# Generated at 2022-06-25 23:17:21.991322
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""extend(new_vars)""").body[0].body
    vars = ast.parse("""x = 1
                        y = 2""").body
    extend_tree(tree, {'new_vars': vars})
    assert ast.dump(tree) == "[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=2))]"



# Generated at 2022-06-25 23:17:26.455100
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    expected_body = [ast.parse(body).body[0] for body in [
        'int_0 = 1',
    ]]

    snippet_get_body_0 = snippet(test_case_0).get_body()

    assert snippet_get_body_0 == expected_body[0]

if __name__ == "__main__":
    test_snippet_get_body()

# Generated at 2022-06-25 23:17:32.657143
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse(test_case_0.__doc__)
    int_0_old = tree.body[0].body[0].value.n
    extend_tree(tree, {'int_0': 5})
    int_0_new = tree.body[0].body[0].value.n
    if int_0_new == int_0_old:
        print('test_extend_tree was unsuccessful\n')
    else:
        print('test_extend_tree was successful\n')


# Generated at 2022-06-25 23:17:35.576059
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # int_0 = 1
    print(snippet(test_case_0).get_body())



# Generated at 2022-06-25 23:17:46.066456
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''def f():
        x = 1
        let(x)
        extend(y)''')
    extend_tree(tree, {'x': [ast.Expr(ast.Num(1)), ast.Expr(ast.Num(2))],
                         'y': [ast.Expr(ast.Num(3))]})
    assert get_source(tree) == '''def f():
    x = 1
    let(x)
    extend(y)
    1
    2
    3
'''


# Generated at 2022-06-25 23:17:49.707118
# Unit test for function extend_tree
def test_extend_tree():
    # Test case 0
    int_0 = 1
    my_func_0 = extend(vars)
    print(int_0)
    assert ast.dump(ast.parse(get_source(test_case_0))) == ast.dump(ast.parse(get_source(my_func_0)))


# Generated at 2022-06-25 23:17:50.786181
# Unit test for function extend_tree
def test_extend_tree():
    assert not test_case_0.__code__.co_varnames


# Generated at 2022-06-25 23:17:54.248910
# Unit test for function extend_tree
def test_extend_tree():
    t = ast.parse("x = 1")
    tree = ast.parse("let(x)\nint_0 = 1")
    extend_tree(tree, {'x': t})
    assert tree.body[0].body[0].value.func.id == 'let'
    assert tree.body[0].body[1].targets[0].id == 'int_0'
    assert tree.body[0].body[1].value.n == 1


# Generated at 2022-06-25 23:18:00.631269
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    res = snippet(test_case_0).get_body()

    assert res == [ast.Assign(targets=[ast.Name(id='int_0', ctx=ast.Store())], value=ast.Num(n=1))] # test_case_0 result


# Generated at 2022-06-25 23:18:04.087123
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("")
    variables = {
        0: ast.ClassDef(name="test")
    }

    extend_tree(tree, variables)

    assert tree.body == [variables[0]]


# Generated at 2022-06-25 23:18:16.094546
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    '''
    Test 0: test_case_0(simple int)
    '''
    def test_case_0():
        let(int_0)
        print(int_0)

    test_case_0_snippet = snippet(test_case_0)
    assert str(test_case_0_snippet.get_body()) == '[Assign(targets=[Name(id=\'_py_backwards_int_0_0\', ctx=Store())], value=Constant(value=1, kind=None)), Expr(value=Call(func=Name(id=\'print\', ctx=Load()), args=[Name(id=\'_py_backwards_int_0_0\', ctx=Load())], keywords=[]))]'
    
    def test_case_0():
        int

# Generated at 2022-06-25 23:18:21.069719
# Unit test for function extend_tree
def test_extend_tree():
    output = ast.parse('x = 1')
    assert extend_tree(output, {'a': output}) == None


# Generated at 2022-06-25 23:18:26.592533
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def for_assert():
        def inner():
            let(int_0)
            let(int_1)
            int_0 += 1
            int_2 = 1
    snip = snippet(for_assert)
    body = snip.get_body(int_0=0, int_1=1)
    assert len(body) > 0

# Generated at 2022-06-25 23:18:31.380046
# Unit test for function extend_tree
def test_extend_tree():
    # When
    tree = ast.parse("""
    extend(vars)
    """)
    variables = { "vars": ast.parse("x = 1") }
    
     # Then
    extend_tree(tree, variables)
    assert [x.s for x in find(tree, ast.Assign)] == ['x = 1']


# Generated at 2022-06-25 23:18:41.081680
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import _py_backwards_ast3
    expected = _py_backwards_ast3.a_s_t_0

# Generated at 2022-06-25 23:18:50.747608
# Unit test for function extend_tree
def test_extend_tree():
    class Stummy0(ast.AST):
        _fields = ()
        _attributes = ()
    class Stummy1(ast.AST):
        _fields = ()
        _attributes = ()
    class Stummy2(ast.AST):
        _fields = ()
        _attributes = ()
    class Stummy3(ast.AST):
        _fields = ()
        _attributes = ()
    class Stummy4(ast.AST):
        _fields = ()
        _attributes = ()
    class Stummy5(ast.AST):
        _fields = (('id', 's_t_u_m_m_y_0'),)
        _attributes = ()
    class Stummy6(ast.AST):
        _fields = ()
        _attributes = ()

# Generated at 2022-06-25 23:18:57.263429
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    # Create snippet instance
    snippet_0 = snippet(test_case_0)

    # Create snippet_kwargs
    snippet_kwargs_0 = {}

    # Execute method
    output_0 = snippet_0.get_body(**snippet_kwargs_0)

    # Test equality
    assert output_0 == [ast.Expr(value=ast.Call(func=ast.Name(id='extend', ctx=ast.Load()), args=[ast.Name(id='a_s_t_0', ctx=ast.Load())], keywords=[]))]

# Generated at 2022-06-25 23:19:02.200621
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import typed_ast._ast3 as module_0
    # 
    a_s_t_0 = module_0.AST()
    s_n_i_p_p_e_t_0 = snippet(test_case_0)
    s_n_i_p_p_e_t_0.get_body()

# Generated at 2022-06-25 23:19:06.154397
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body() == \
    [
        ast.Assign(
            targets=[
                ast.Name(
                    id='a_s_t_0',
                    ctx=ast.Load()
                )
            ],
            value=ast.Num(n=0)
        )
    ]

# Generated at 2022-06-25 23:19:10.117597
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    class Namespace(object):
        pass

    _namespace_0 = Namespace()
    _namespace_0.arg_1 = 1
    _namespace_0.arg_2 = 2

    assert snippet(test_case_0).get_body() == [extend(ast.parse("x = 1\nx = 2").body[0])]


# Generated at 2022-06-25 23:19:20.496342
# Unit test for function extend_tree
def test_extend_tree():
    source1 = """
        extend(vars)
        print(x, y)
    """
    tree1 = ast.parse(source1)
    vars1 = {'vars': ast.parse("x = 1").body}
    extend_tree(tree1, vars1)
    node1 = tree1.body[1]
    assert isinstance(node1, ast.Print)
    assert [str(n) for n in node1.values] == ['x', 'y']

    source2 = """
        extend(vars)
        print(x, y)
    """
    tree2 = ast.parse(source2)
    vars2 = {'vars': ast.parse("x = 1; x = 2;").body}
    extend_tree(tree2, vars2)
    node2a = tree

# Generated at 2022-06-25 23:19:23.138690
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    let(a_s_t_0)
    extend(a_s_t_0)


# Generated at 2022-06-25 23:19:30.426074
# Unit test for function find_variables
def test_find_variables():
    a_s_t_8 = module_0.Call()
    a_s_t_8.func = module_0.Name()
    a_s_t_8.func.id = 'let'
    a_s_t_8.args = []
    a_s_t_8.args.append(module_0.Name())
    a_s_t_8.args[0].id = 'x'
    _py_backwards_find_variables_10_0 = find_variables(a_s_t_8)
    _py_backwards_find_variables_10_1 = list(_py_backwards_find_variables_10_0)
    assert _py_backwards_find_variables_10_1 == ['x']


# Generated at 2022-06-25 23:19:40.424766
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from ._ast3 import Module
    from ._ast3 import FunctionDef
    from ._ast3 import arguments
    from ._ast3 import arg
    from ._ast3 import Return
    from ._ast3 import Num
    from ._ast3 import Call
    from ._ast3 import Name
    from ._ast3 import Load
    from ._ast3 import Store
    from ._ast3 import Str
    from ._ast3 import Expr
    from ._ast3 import Assign
    from ._ast3 import alias
    from ._ast3 import ImportFrom
    from ._ast3 import alias_1
    from ._ast3 import Assign_0
    from ._ast3 import Add
    from ._ast3 import BinOp
    def _func_0(var_0):
        let(name_0)
        extend(a_s_t_4)
        return name_0

# Generated at 2022-06-25 23:19:54.241023
# Unit test for function extend_tree
def test_extend_tree():
    node = ast.parse("""
CODE = extend(VARS)
CODE = extend(VARS)
""", mode='exec')
    variables = {'VARS': [
        ast.Assign(targets=[ast.Name(id="a", ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id="b", ctx=ast.Store())],
                   value=ast.Num(n=2)),
    ]}
    extend_tree(node, variables)

# Generated at 2022-06-25 23:20:04.676820
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test empty body
    def empty_body():
        pass
    assert list(snippet(empty_body).get_body()) == []
    # Test simple case
    def simple_body(a: int) -> float:
        '''brief
        long comment'''
        let(a)
        a = 1
        c = a
        return c

    result = snippet(simple_body).get_body(a=1)
    assert len(result) == 3
    assert isinstance(result[0], ast.Assign)
    assert isinstance(result[0].targets[0], ast.Name)
    assert result[0].targets[0].id == '_py_backwards_a_0'
    assert isinstance(result[0].value, ast.Num)

# Generated at 2022-06-25 23:20:12.450281
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn_0():
        let(a_s_t_0)
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = []
    a_s_t_0.body.append(module_0.Expr(module_0.Name(id='_py_backwards_a_s_t_0_0', ctx=module_0.Load())))
    a_s_t_1 = module_0.AST()
    a_s_t_1.body = [module_0.Expr(module_0.Name(id='_py_backwards_a_s_t_0_0', ctx=module_0.Load()))]

# Generated at 2022-06-25 23:20:22.760719
# Unit test for function extend_tree
def test_extend_tree():
    tree_0 = module_0.Module(body=module_0.convert( let(module_0.arg('a_s_t_0', None)) ))
    extend_tree(module_0.module, module_0.convert({'a_s_t_0': a_s_t_0}))


# Generated at 2022-06-25 23:20:30.240631
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def a_s_t_0(a: int, b: int) -> int:
        let(a + b)
        let(b)
        extend(a_s_t_0)
        return a + b

    a_s_t_1 = a_s_t_0.get_body()

    assert a_s_t_1[0].value.value == a_s_t_1[0].value.left.id
    assert module_0.NameConstant(value=True).__eq__(a_s_t_1[0].value.ctx)
    assert module_0.Store().__eq__(a_s_t_1[0].target.ctx)
    assert a_s_t_1[1].value.value == a_s_t_1[1].value.left.id

# Generated at 2022-06-25 23:20:34.023717
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import cProfile
    cProfile.run('test_case_0()', sort='cumtime')

if __name__ == "__main__":
    test_snippet_get_body()

# Generated at 2022-06-25 23:20:41.909962
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
a = 1
extend(variables)
b = 2
    """.strip())
    variables = {
        'variables': ast.Module(body=[
            ast.Assign(targets=[ast.Name(id='a', ctx=ast.Load())],
                       value=ast.Num(n=2))
        ]),
    }
    extend_tree(tree, variables)
    # Inplace replacement
    assert str(tree) == 'a = 2'

# Generated at 2022-06-25 23:20:43.818131
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from ..helpers import test_snippet_get_body
    test_snippet_get_body(snippet)

# Generated at 2022-06-25 23:20:46.389134
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(test_case_0)) == ["a_s_t_0"]


# Generated at 2022-06-25 23:20:52.686977
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class my_snippet(snippet):
        def _fn(self):
            let(a_s_t_0)
            test_case_0()
    my_snippet_0 = my_snippet(my_snippet._fn)
    my_snippet_1 = my_snippet(my_snippet._fn)
    assert my_snippet_0.get_body() == my_snippet_1.get_body()

# Generated at 2022-06-25 23:21:13.191737
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_contains_extend_assignments(self):
        a_s_t_0 = module_0.AST()
        extend(a_s_t_0)
        a_s_t_1 = self.get_body(a_s_t_0=a_s_t_0)
        self.assertEqual(a_s_t_1, [a_s_t_0])

    def test_does_not_contain_extend_assignments(self):
        a_s_t_0 = module_0.AST()
        a_s_t_1 = self.get_body(a_s_t_0=a_s_t_0)
        self.assertEqual(a_s_t_1, [])


# Generated at 2022-06-25 23:21:14.029847
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_case_0()

# Generated at 2022-06-25 23:21:24.250462
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Creation of instance of class snippet
    snippet_i_0 = snippet(test_snippet_get_body)
    # Execution of method get_body of class snippet
    test_snippet_get_body_result_0 = snippet_i_0.get_body()
    assert test_snippet_get_body_result_0 == [], "wtf"
    # assert isinstance(test_snippet_get_body_result_0, list)
    # assert test_snippet_get_body_result_0 == [(assign, ['a', (name, 'a')]),
    # (assign, ['b', (name, 'b')]), (assign, ['c', (binop, [(name, 'a'), add, (name, 'b')])]),
    # (assign, ['d', (

# Generated at 2022-06-25 23:21:32.708490
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class snippet_0(snippet):
        @property
        def _fn(self):
            return let
    s_n_i_p_0 = snippet_0()
    
    def test_case_0():
        d_i_c_t_0 = let(0)
        a_s_t_0 = s_n_i_p_0.get_body(d_i_c_t_0 = d_i_c_t_0)
    
    def test_case_1():
        d_i_c_t_0 = let(0)
        a_s_t_0 = s_n_i_p_0.get_body(**{d_i_c_t_0: d_i_c_t_0})
    

# Generated at 2022-06-25 23:21:34.018545
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    extend(a_s_t_0)


# Generated at 2022-06-25 23:21:38.183233
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    let(a_s_t_0)
    test_case_0()


if __name__ == '__main__':
    test_snippet_get_body()

# Generated at 2022-06-25 23:21:46.303803
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse('let(x); y = x'))) == ['x']
    assert list(find_variables(ast.parse('let(x); let(x); y = x'))) == ['x', 'x']
    assert list(find_variables(ast.parse('let(x); let(y); y = x'))) == ['x', 'y']
    assert list(find_variables(ast.parse('a = x; let(x); y = x'))) == ['x']
    assert list(find_variables(ast.parse('a = x; let(x + 1); y = x'))) == []


# Generated at 2022-06-25 23:21:51.109709
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import typed_ast._ast3
    a_s_t_0 = typed_ast._ast3.AST()
    def _fn_0(  ):
        let(a_s_t_0)
        a_s_t_0
    _snippet = snippet(_fn_0)
    _snippet.get_body()
    _snippet.get_body(  )
    _snippet.get_body(a_s_t_0=None)


# Generated at 2022-06-25 23:21:53.264366
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_fn_0(a_0):
        let(a_0)
        return a_0
    result_0 = test_case_0.get_body()
    assert(result_0 == [])


# Generated at 2022-06-25 23:21:55.653940
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse("let(x); x * 2"))) == ["x"]


# Generated at 2022-06-25 23:22:29.791161
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Snippet of code."""

    # On class snippet
    # Calling method get_body
    #

    # On class snippet
    # Calling method get_body
    #

    # On class snippet
    # Calling method get_body
    #

    # On class snippet
    # Calling method get_body
    #

    # On class snippet
    # Calling method get_body
    #

    # On class snippet
    # Calling method get_body
    #

    # On class snippet
    # Calling method get_body
    #

    pass



# Generated at 2022-06-25 23:22:33.723267
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import tree_equal
    result = snippet(test_case_0).get_body()
    expected = ast.parse("""
        a_s_t_0 = AST()
    """).body
    assert tree_equal(result, expected)




# Generated at 2022-06-25 23:22:38.715428
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    let(a_s_t_0)
    let(a_s_t_0)
    let(a_s_t_0)
    let(a_s_t_0)
    let(a_s_t_0)
    let(a_s_t_0)


# Generated at 2022-06-25 23:22:45.603162
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def get_snippet_ast() -> ast.AST:
        return snippet(test_snippet_get_body).get_body()
    result = "Module([FunctionDef(name='test_snippet_get_body', args=arguments(posonlyargs=[], args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Call(func=Name('test_case_0', Load()), args=[], keywords=[], starargs=None, kwargs=None)), Expr(value=Call(func=Name('test_snippet_get_body', Load()), args=[], keywords=[], starargs=None, kwargs=None)), Return(value=None)], decorator_list=[], returns=None)])"

# Generated at 2022-06-25 23:22:47.912797
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # TODO: Implement test_snippet_get_body
    pass


# Generated at 2022-06-25 23:22:51.050658
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    extend(a_s_t_0)


# Generated at 2022-06-25 23:22:53.229034
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0():
        s_n_0 = snippet( test_case_0 )
        l_b_0 = s_n_0.get_body()

# Generated at 2022-06-25 23:23:02.806590
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import snippet

    def fn(a, b):
        b += 1
        let(c)
        let(d)

    sn = snippet(fn)
    expected = [
        ast.stmt(value=ast.BinOp(left=ast.Name(id='b', ctx=ast.Load()), op=ast.Add(), right=ast.Num(n=1))),
        ast.stmt(value=ast.Name(id='_py_backwards_c_0', ctx=ast.Load())),
        ast.stmt(value=ast.Name(id='_py_backwards_d_0', ctx=ast.Load()))
    ]
    assert sn.get_body(a=1, b=0) == expected

# Generated at 2022-06-25 23:23:04.789617
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    extend(a_s_t_0)

# Generated at 2022-06-25 23:23:08.096885
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)
    a_s_t_0 = module_0.AST()
    a_s_t_1 = snippet_0.get_body(a_s_t_0=a_s_t_0)
    assert(False)


# Generated at 2022-06-25 23:24:21.187395
# Unit test for function extend_tree
def test_extend_tree():
    snippet_0 = snippet(test_case_0)
    a_s_t_0 = snippet_0.get_body()[-1] # index 2
    # ast.Assign
    assert(isinstance(a_s_t_0, ast.Assign))
    # a_s_t_0.targets
    assert(len(a_s_t_0.targets) == 1)
    assert(isinstance(a_s_t_0.targets[0], ast.Name))
    assert(a_s_t_0.targets[0].id == "a_s_t_0")
    assert(a_s_t_0.targets[0].ctx == ast.Store())
    # a_s_t_0.value

# Generated at 2022-06-25 23:24:23.748321
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def function_0(a: str, b: str) -> str:
        let(a)
        let(b)
        return a + b

    assert function_0('1', '2') == '12'



# Generated at 2022-06-25 23:24:29.217447
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class_1 = snippet
    value_2 = class_1(test_case_0)
    tuple_3 = (value_2, [])
    namespace_4 = dict(tuple_3)
    class_5 = snippet
    value_6 = class_5(test_case_0)
    value_7 = class_5.get_body(value_6, **namespace_4)
    value_8 = list
    value_9 = isinstance(value_7, value_8)
    value_10 = True
    value_11 = value_9 == value_10
    value_12 = assertEqual(value_11, True)
    value_13 = assertEqual(value_7, [])
    return None
