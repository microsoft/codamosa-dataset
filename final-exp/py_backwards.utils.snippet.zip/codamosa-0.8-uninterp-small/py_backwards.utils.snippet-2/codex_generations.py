

# Generated at 2022-06-25 23:14:34.838438
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)


# Generated at 2022-06-25 23:14:44.892776
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _fn(x: int):
        pass
    _self_0 = snippet(_fn)
    _self_0.get_body()
    def _fn_0(x: int):
        pass
    _self_1 = snippet(_fn_0)
    _self_1.get_body(x=1)
    def _fn_1(x: int):
        pass
    _self_2 = snippet(_fn_1)
    _self_2.get_body(x=1)
    def _fn_2(x: int):
        pass
    _self_3 = snippet(_fn_2)
    _self_3.get_body(x=1)
    def _fn_3(x: int):
        pass
    _self_4 = snippet(_fn_3)
    _self_4.get

# Generated at 2022-06-25 23:14:46.068224
# Unit test for function extend_tree
def test_extend_tree():
    root.a = 1
    root.b = 2
    root.c = 3


# Generated at 2022-06-25 23:14:49.553231
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    print("[INFO] Running: {}".format("find_variables"))
    print("{}".format(iterable_0))


import astor as module_1


# Generated at 2022-06-25 23:14:52.939850
# Unit test for function find_variables
def test_find_variables():
    import ast
    a_s_t_0 = ast.AST()
    iterable_0 = find_variables(a_s_t_0)
    (name_0,) = iterable_0



# Generated at 2022-06-25 23:14:56.843287
# Unit test for function find_variables
def test_find_variables():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    for item_0 in iterable_0:
        str_0 = item_0


# Generated at 2022-06-25 23:15:03.811850
# Unit test for function find_variables
def test_find_variables():
    assert_equal(list(find_variables(module_0.AST(body=[module_0.Expr(value=module_0.Call(func=module_0.Name(id='let', ctx=module_0.Load()), args=[module_0.Name(id='x', ctx=module_0.Load())], keywords=[]))]))), ['x'])

# Generated at 2022-06-25 23:15:15.120827
# Unit test for function find_variables
def test_find_variables():
    # from snippets.test_snippets import test_snippets
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    assert list(iterable_0) == []
    a_s_t_1 = module_0.AST()
    iterable_1 = find_variables(a_s_t_1)
    assert list(iterable_1) == []
    a_s_t_2 = module_0.AST()
    iterable_2 = find_variables(a_s_t_2)
    assert list(iterable_2) == []
    a_s_t_3 = module_0.AST()
    iterable_3 = find_variables(a_s_t_3)

# Generated at 2022-06-25 23:15:22.400591
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func_0():
        let(x)
        x += 1
        y = 1
    snippet_object_0 = snippet(func_0)
    variables_0 = snippet_object_0._get_variables(module_0.parse(get_source(func_0)), {})
    extend_tree(module_0.parse(get_source(func_0)), variables_0)
    VariablesReplacer.replace(module_0.parse(get_source(func_0)), variables_0)
    assert(snippet_object_0.get_body() == module_0.parse(get_source(func_0)).body[0].body)

# Generated at 2022-06-25 23:15:29.489779
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f_0():
        let(a_0)
        x_0 = a_0
        extend(vars_0)
        let(b_0)
        let(c_0)
        x_0 = c_0

    s_0 = snippet(f_0)
    body_0 = s_0.get_body(a_0=54, b_0=54, c_0=54, vars_0=[])
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    test_case_0()
    test_snippet_get_body()

# Generated at 2022-06-25 23:15:45.998384
# Unit test for function extend_tree
def test_extend_tree():
    source = '''class C():
    def __init__(self):
        extend(vars)
'''
    
    def get_source_without_extend(source):
        tree = ast.parse(source)
        extend_tree(tree, {})
        return tree.body[0]
    
    class_source = get_source(C)
    tree = ast.parse(class_source)
    extend_tree(tree, {'vars': tree.body[0].body[0]})
    assert get_source(test_case_0) == get_source(tree.body[0])
    assert get_source(test_case_0) == get_source(get_source_without_extend(source))



# Generated at 2022-06-25 23:15:47.842115
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(ast.parse('let(x); let(y)')) == ['x', 'y']



# Generated at 2022-06-25 23:15:56.978715
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_snippet():
        int_0 = 1
        string_1 = ''
        let(int_0)
        int_0 = 2
        extend({int_0: 3, string_1: 'string_1'})
        extend({string_1: 'string_1'})
        let(True)

    assert [ass.value for ass in test_snippet.get_body()] == [2, 3, 'string_1', 'string_1']



# Generated at 2022-06-25 23:16:02.630914
# Unit test for function extend_tree
def test_extend_tree():
    global int_0
    tree = ast.parse("int_0 = 1")
    extend_tree(tree, {"int_0" : ast.parse("int_0 = 2")})
    exec(compile(tree, filename="", mode='exec'))
    assert int_0 == 2


# Generated at 2022-06-25 23:16:06.280962
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body(int_0) == [ast.Assign([ast.Name("_py_backwards_int_0_0", ast.Store())], ast.Num(1))]

# Generated at 2022-06-25 23:16:17.957246
# Unit test for function extend_tree
def test_extend_tree():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    variables = {'var': [ast.Assign(targets=[ast.Name(id='int_0', ctx=ast.Store())], value=ast.Num(n=1))]}
    extend_tree(tree, variables)
    variables = find_variables(tree)
    extend_tree(tree, variables)
    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[0].targets[0], ast.Name)
    assert isinstance(tree.body[0].value, ast.Num)
    assert tree.body[0].targets[0].id == 'int_0'
    assert tree.body[0].value.n == 1



# Generated at 2022-06-25 23:16:24.355329
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet = snippet(test_case_0)
    body = snippet.get_body(int_0=1)
    assert isinstance(body, list)
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[0].targets[0], ast.Name)
    assert body[0].targets[0].id == 'int_0'
    assert body[0].value == 1



# Generated at 2022-06-25 23:16:27.397326
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    @snippet
    def test_case_0():
        let(x)
        x = 1
        x = 2

    assert test_case_0.get_body() == test_case_0().get_body()



# Generated at 2022-06-25 23:16:30.870799
# Unit test for function find_variables
def test_find_variables():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    assert list(find_variables(tree)) == ['int_0']


# Generated at 2022-06-25 23:16:35.878756
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body() == [
        ast.Assign([ast.Name(id='int_0', ctx=ast.Store())], ast.Constant(value=1, kind=None))]


# Generated at 2022-06-25 23:16:49.705609
# Unit test for method get_body of class snippet

# Generated at 2022-06-25 23:16:52.884026
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet.get_body(test_case_0) == \
         [ast.Assign(targets=[ast.Name(id='int_0')], value=ast.Num(n=1))]


# Generated at 2022-06-25 23:16:58.441815
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
    extend(vars)
    '''
    tree = ast.parse(source)

    vars = [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=1))]
    extend_tree(tree, {'vars': vars})

    generated_code = astor.to_source(tree)
    expected_code = '''
    x = 1
    '''
    assert generated_code == expected_code



# Generated at 2022-06-25 23:16:59.346965
# Unit test for function extend_tree
def test_extend_tree():
    assert 0 == 0

# Generated at 2022-06-25 23:17:07.923667
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_0():
        let(int_0)
        int_0 += 1
        string_0 = "string"
        extend(vars)

    assert test_0.get_body(int_0 = 1, vars = [ast.Assign(targets=[ast.Name(id='int_0', ctx=ast.Store())], value=ast.Num(n=1)), ast.Assign(targets=[ast.Name(id='int_0', ctx=ast.Store())], value=ast.Num(n=2))]) == test_case_0()

    @snippet
    def test_1():
        let(int_0)
        int_0 += 1
        string_0 = "string"
        extend(vars)

    assert test_1.get_

# Generated at 2022-06-25 23:17:13.706423
# Unit test for function extend_tree
def test_extend_tree():
    source = get_source(test_case_0)
    source = source.replace('int_0','extend(vars)')
    tree = ast.parse(source)
    variables = {
            'vars': ast.parse('int_1 = 2')
    }
    extend_tree(tree,variables)
    assert tree.body[0].body[1].targets[0].id == 'int_1'


# Generated at 2022-06-25 23:17:16.628185
# Unit test for function extend_tree
def test_extend_tree():
    int_0 = 1
    int_1 = 2
    extend(vars)
    assert int_0 == 1
    assert int_1 == 2


# Generated at 2022-06-25 23:17:21.508954
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    snippet_kwargs = {'x': x, 'y': y}
    SourceCode = snippet(test_case_0)
    assert SourceCode.get_body(**snippet_kwargs) == ast.parse(
        'int_0 = 1').body[0].body


# Generated at 2022-06-25 23:17:25.197390
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse(get_source(test_case_0))
    extend_tree(tree, {"int_0": ast.parse(get_source(test_case_1)).body})

    assert get_source(test_case_0) == get_source(ast.fix_missing_locations(tree))



# Generated at 2022-06-25 23:17:25.995592
# Unit test for function extend_tree

# Generated at 2022-06-25 23:17:39.466703
# Unit test for function extend_tree
def test_extend_tree():
    from .helpers import VariablesGenerator
    from .tree import replace_at
    from .transforms import find_variables

    @snippet
    def f():
        let(a)

        extend(asd)

    tree = ast.parse(get_source(f))
    names = find_variables(tree)
    variables = {name: VariablesGenerator.generate(name)
                 for name in names}

    body = f.get_body()

# Generated at 2022-06-25 23:17:42.861648
# Unit test for function find_variables
def test_find_variables():
    from .test_data import find_variables_test_cases

    test_cases = find_variables_test_cases

    for test_case in test_cases:
        if test_case == 0:
            test_case_0()

# Generated at 2022-06-25 23:17:43.731697
# Unit test for function extend_tree
def test_extend_tree():
    assert True


# Generated at 2022-06-25 23:17:48.082817
# Unit test for function extend_tree
def test_extend_tree():
    import random
    import string
    import math

    a_s_t_0 = module_0.AST()
    tree = a_s_t_0
    var_1 = None
    var_2 = None
    variables = {var_1: var_2}
    extend_tree(tree, variables)

    return


# Generated at 2022-06-25 23:17:50.158007
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    iterable_0 = VariablesReplacer.replace(a_s_t_0, list())


# Generated at 2022-06-25 23:17:53.367457
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_method_0(var_0: Any) -> None:
        var_0 = 1
        var_1 += 1
        var_2 = 1
    a_s_t_0 = test_method_0.get_body()
    list_0 = a_s_t_0

# Generated at 2022-06-25 23:18:03.087364
# Unit test for function extend_tree
def test_extend_tree():
    class ast_0(module_0.AST):
        call_0 = module_0.Call()
        call_0.args = [None]

        call_1 = module_0.Call()
        call_1.args = [None]

    def function_0(vars):
        extend(vars)

        a_s_t_0 = ast_0()
        extend_tree(a_s_t_0, {'vars': [ast_0.call_0, ast_0.call_1]})


# Generated at 2022-06-25 23:18:07.803196
# Unit test for function extend_tree
def test_extend_tree():
    import typed_ast._ast3 as module_0
    import typing as module_1
    a_s_t_0 = module_0.AST()
    d_i_c_t___v_a_r_i_a_b_l_e_s_0 = module_1.Dict[str, object]
    extend_tree(a_s_t_0, d_i_c_t___v_a_r_i_a_b_l_e_s_0)


# Generated at 2022-06-25 23:18:11.264679
# Unit test for function extend_tree
def test_extend_tree():
    def test_code_0():
        import typed_ast._ast3 as module_0

        a_s_t_0 = module_0.AST()
        extend_tree(a_s_t_0, {})

    test_code_0()


# Generated at 2022-06-25 23:18:21.585235
# Unit test for function extend_tree
def test_extend_tree():
    from .tree import Function
    import ast

# Generated at 2022-06-25 23:18:28.536387
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(lambda x : None)
    snippet_0.get_body()


# Generated at 2022-06-25 23:18:38.401619
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    d_i_c_t_0 = {'a': a_s_t_0}
    extend_tree(a_s_t_0, d_i_c_t_0)
    s_t_r_0 = str(a_s_t_0)
    s_t_r_1 = str(a_s_t_0)
    assert s_t_r_0 == s_t_r_1
    s_t_r_0 = str(a_s_t_0)
    s_t_r_1 = str(a_s_t_0)
    assert s_t_r_0 == s_t_r_1

# Generated at 2022-06-25 23:18:43.515549
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    variables = _get_variables(tree, {})
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

    snippet_0 = snippet(test_case_0)
    assert snippet_0.get_body() == tree.body[0].body

# Generated at 2022-06-25 23:18:47.593571
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    __snippet_1 = snippet(test_case_0)
    __snippet_1.get_body()


# Generated at 2022-06-25 23:18:52.708526
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = ast.parse('import a')
    variables = {'a': ['x = 1\n', 'x = 2\n']}
    extend_tree(a_s_t_0, variables)
    test_0 = str(a_s_t_0)
    assert test_0 == 'x = 1\nx = 2\nimport a\n'


# Generated at 2022-06-25 23:18:55.226383
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn_0():
        let(x)
        x += 1
        y = 1
    snippet_0 = snippet(fn_0)
    list_0 = snippet_0.get_body()


# Generated at 2022-06-25 23:18:57.076433
# Unit test for function extend_tree
def test_extend_tree():
    # variable definition
    a_s_t_0 = module_0.AST()
    extend_tree(a_s_t_0, {})

# Generated at 2022-06-25 23:19:06.685492
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def testcase():
        from . import let

# Generated at 2022-06-25 23:19:09.568638
# Unit test for function extend_tree
def test_extend_tree():
    vars = {'x': [ast.Assign([ast.Name(id='x', ctx=ast.Store())],
                         ast.Num(n=1))]}
    extend_tree([ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                                     args=[], keywords=[], starargs=None, kwargs=None))],
             vars)



# Generated at 2022-06-25 23:19:15.677043
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class_0 = snippet()
    name_0 = Name(id='_py_backwards_x_0', ctx=Load())
    keyword_0 = keyword(arg='a', value=name_0)
    list_0 = List(elts=[keyword_0])
    dict_0 = Dict(keys=[name_0], values=[list_0])
    class_0._get_variables(list_0, dict_0)


# Generated at 2022-06-25 23:19:25.564094
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def s_n_i_p_p_e_t_0() -> None:
        let(foo)
        foo = 1
        assert(foo == 1)
    s_n_i_p_p_e_t_0.get_body()


# Generated at 2022-06-25 23:19:26.391255
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert True


# Generated at 2022-06-25 23:19:30.137035
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import capture_stdout
    @snippet
    def foo():
        let(x)
        let(y)
        print(x, y)
    out, err = capture_stdout(foo.get_body, x=1, y=2)
    assert out == '1 2\n'
    assert err == ''


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:19:40.145212
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class snippet(object):

        def __init__(self, fn_0: Callable[[ast.AST], None], *args_0: Any, **kwargs_0: Any) -> None:
            self._fn_0 = fn_0

        @property
        def _count_0(self) -> int:
            return 1

        @property
        def _count_1(self) -> int:
            return 2

        @property
        def _count_2(self) -> int:
            return 3

        @property
        def _count_3(self) -> int:
            return 4

        @property
        def _count_4(self) -> int:
            return 5

        @property
        def _count_5(self) -> int:
            return 6


# Generated at 2022-06-25 23:19:49.022701
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.Call()
    a_s_t_0.func = module_0.Name()
    a_s_t_0.func.id = "let"
    a_s_t_0.args = [module_0.Name()]
    a_s_t_0.args[0].id = "var"
    a_s_t_1 = module_0.Assign()
    a_s_t_1.targets = [module_0.Name()]
    a_s_t_1.targets[0].id = "var"
    a_s_t_1.value = module_0.Name()
    a_s_t_1.value.id = "var"

# Generated at 2022-06-25 23:19:57.188358
# Unit test for function extend_tree
def test_extend_tree():
    a = None
    b = None

# Generated at 2022-06-25 23:20:05.879929
# Unit test for function extend_tree
def test_extend_tree():
    def extend_tree(tree: ast.AST, variables: Dict[str, Variable]) -> None:
        for node in find(tree, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == 'extend':
                parent, index = get_non_exp_parent_and_index(tree, node)
                replace_at(index, parent, variables[node.args[0].id])  # type: ignore

    def check_extend_tree(tree: ast.AST, variables: Dict[str, Variable]) -> None:
        extend_tree(tree, variables)


# Generated at 2022-06-25 23:20:06.961316
# Unit test for function extend_tree
def test_extend_tree():
    pass


# Generated at 2022-06-25 23:20:09.103682
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_0(x_0, x_1=2):
        let(x_0)
        
        let(x_1)
        return x_0 + x_1
    
    a_s_t_0 = snippet_0.get_body(x_0=2, x_1=1)

# Generated at 2022-06-25 23:20:11.259387
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("def foo(): pass")
    extend_tree(tree, {"foo": [ast.parse("pass")]})
    assert str(tree) == "def foo():\n    pass"


# Generated at 2022-06-25 23:20:26.158617
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 23:20:31.995601
# Unit test for function extend_tree
def test_extend_tree():
    
    def constructor_0():
        return module_0.AST()

    a_s_t_0 = constructor_0()
    a_s_t_1 = constructor_0()
    d_i_c_t_0 = {id(a_s_t_0): a_s_t_1}
    extend_tree(a_s_t_0, d_i_c_t_0)


# Generated at 2022-06-25 23:20:36.098159
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def _fn_0():
        let(x)
        y = x
        z = x
    
    a_s_t_0 = _fn_0.get_body()


# Generated at 2022-06-25 23:20:45.664495
# Unit test for function extend_tree
def test_extend_tree():
    class mock_find:
        def __init__(self, return_val):
            self.return_val = return_val

        def __call__(self, tree: ast.AST, ast_type) -> ast.AST:
            return self.return_val[0]

    class mock_replace:
        def __init__(self, return_val):
            self.return_val = return_val

        def __call__(self, index: int, parent: ast.AST,
            val_to_replace: ast.AST) -> ast.AST:
            self.index = index
            self.parent = parent
            self.val_to_replace = val_to_replace
            return self.return_val

    tree = ast.AST()
    variables = {'foo': ast.Num(1)}
    node = ast.Call()

# Generated at 2022-06-25 23:20:55.793127
# Unit test for function extend_tree
def test_extend_tree():
    # Test with inner function
    def function_0_0(arg_0: ast.AST) -> None:
        extend_tree(arg_0, {'a': 'b'})
    a_s_t_0 = ast.Module((
        ast.Expr(ast.Call(func=ast.Name(id='extend', ctx=ast.Load()),
                          args=[ast.Str(s='a')], keywords=())),),)
    function_0_0(a_s_t_0)
    assert ast.dump(a_s_t_0) == \
        "Module(body=[Str(s='b')])"
    # Test with inner function

# Generated at 2022-06-25 23:21:03.298858
# Unit test for function extend_tree
def test_extend_tree():
    import ast
    import astor
    import _py_backwards
    tree = ast.parse('print(1)')
    a = ast.Assign()
    a.value = 1
    b = ast.Assign()
    b.value = 2
    _py_backwards.extend_tree(tree, {'a': [a], 'b': [b]})
    assert astor.to_source(tree) == 'x = 1\nx = 2\nprint(1)\n'


# Generated at 2022-06-25 23:21:10.612622
# Unit test for function extend_tree
def test_extend_tree():
    _py_backwards_extend_tree_0 = variable_1
    a_s_t_0 = ast.parse(_py_backwards_extend_tree_0)
    iterable_0 = [value_1, value_2]
    iterable_0_iter = iter(iterable_0)
    value_0 = next(iterable_0_iter)
    assert(value_0 == value_1)
    assert(value_0 == value_3)
    assert(value_0 == value_4)
    assert(value_0 == value_5)
    assert(value_0 == value_6)
    assert(value_0 == value_7)
    assert(value_0 == value_8)
    assert(value_0 == value_9)


# Generated at 2022-06-25 23:21:13.047480
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    variables_0 = {}
    extend_tree(a_s_t_0, variables_0)


# Generated at 2022-06-25 23:21:19.688004
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    l_i_s_t_0 = list()
    d_i_c_t_2 = {1 : l_i_s_t_0, 2 : l_i_s_t_0, 3 : l_i_s_t_0}
    extend_tree(a_s_t_0, d_i_c_t_2)
    assert a_s_t_0 == module_0.AST()


# Generated at 2022-06-25 23:21:29.431756
# Unit test for function extend_tree
def test_extend_tree():
    module_0 = module_0()
    a_s_t_0 = ast.parse(get_source(let))
    module_0.body.extend(a_s_t_0.body)
    function_def_0 = a_s_t_0.body[0]
    import_0 = module_0.body[0]
    keyword_0 = function_def_0.args.kwonlyargs[0]
    iterable_0 = find_variables(module_0)
    iterable_1 = find_variables(module_0)
    assert(module_0 == a_s_t_0)
    assert(function_def_0.args.kwonlyargs[0].arg == 'var')
    assert(import_0.body[0].value.args[0].id == 'var')


# Generated at 2022-06-25 23:22:01.578824
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _fn(arg1):
        let(var_0)
        let(var_1)
        _py_backwards_var_0_0 = var_1
    snippet_0 = snippet(_fn)
    ret = snippet_0.get_body()
    print(ret)

# Generated at 2022-06-25 23:22:03.114349
# Unit test for function extend_tree
def test_extend_tree():
    # TODO: rewrite with pytest
    # Write unit test here
    pass



# Generated at 2022-06-25 23:22:03.910161
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # TODO
    pass

# Generated at 2022-06-25 23:22:08.318346
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    extend_tree(a_s_t_0, {'a_s_t_1': a_s_t_1})


# Generated at 2022-06-25 23:22:14.573806
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def lambda_0(snippet_kwargs_0: Dict[str, Variable]):
        _py_backwards_x_0 = VariablesGenerator.generate('x')
        _py_backwards_y_0 = VariablesGenerator.generate('y')
        return {'x': _py_backwards_x_0, 'y': _py_backwards_y_0}
    snippet_0 = snippet(lambda_0)
    snippet_kwargs_0 = {'x': 1, 'y': 2}
    body_0 = snippet_0.get_body(**snippet_kwargs_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:22:16.766235
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    dictionary_0 = {}
    c_l_a_s_s_0 = snippet(test_snippet_get_body)
    list_0 = c_l_a_s_s_0.get_body(**dictionary_0)

# Generated at 2022-06-25 23:22:28.335669
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0(var_0_0, var_0_1):
        a_s_t_0 = ast.parse("a = 1")
        a_s_t_1 = ast.parse("1")
        a_s_t_2 = ast.parse("b = 2")
        a_s_t_3 = ast.parse("2")
        a_s_t_4 = ast.parse("c = 3")
        a_s_t_5 = ast.parse("3")
        a_s_t_0.body[0].value = var_0_0
        a_s_t_2.body[0].value = var_0_1
        a_s_t_4.body[0].value = a_s_t_5

# Generated at 2022-06-25 23:22:38.395234
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(a)
        let(b)
        vars = __import_result__ = __import__(
            'typed_ast._ast3',
            globals(),
            locals(),
            ['AST'],
            2,
        )
        extend(vars)
        return a, b

# Generated at 2022-06-25 23:22:41.076647
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    d_i_c_0 = dict()
    extend_tree(a_s_t_0, d_i_c_0)


# Generated at 2022-06-25 23:22:51.477682
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import os
    import sys
    PATH = os.getcwd() + "\\test_snippet_get_body"
    try:
        os.mkdir(PATH)
    except:
        pass
    sys.path.insert(0, PATH)
    def test_function(var_0):
        let(var_0)
        var_0 += 1
        var_1 = 1
    test_case_snippet_0 = snippet(test_function)
    test_case_snippet_0.get_body(var_0)

# Generated at 2022-06-25 23:24:02.664800
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    dict_0 = {}
    extend_tree(a_s_t_0, dict_0)


# Generated at 2022-06-25 23:24:05.970034
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class snippet_0(snippet):
        def __init__(self, fn_0: Callable[..., None]) -> None:
            pass
    snippet_1 = snippet_0(lambda  : None)
    test_snippet_get_body.__annotations__ = {'snippet_0': snippet_0, 'snippet_1': snippet_1}

# Generated at 2022-06-25 23:24:07.707257
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    dict_0 = { }
    extend_tree(a_s_t_0, dict_0)


# Generated at 2022-06-25 23:24:10.126699
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    vars_0 = {}
    extend_tree(a_s_t_0, vars_0)


# Generated at 2022-06-25 23:24:13.824756
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = test_case_0()
    a_s_t_1 = test_case_0()
    extend_tree(a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 23:24:20.416953
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_case_0():
        var_0 = 1
        let(var_0)
        var_1 = var_0 + var_0
        var_1 += 1
        var_2 = 1
        extend(var_2)
        return var_2
    var_0 = test_case_0.get_body(var_0=1)
    var_1 = var_0[0]
    assert type(var_1) == module_0.Assign
    var_2 = var_1.value
    assert type(var_2) == module_0.Num
    var_3 = var_2.n
    assert var_3 == 1
    var_4 = var_1.targets[0]
    assert type(var_4) == module_0.Name
    var

# Generated at 2022-06-25 23:24:21.517720
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_foo():
        let(x)
        x += 1


# Generated at 2022-06-25 23:24:26.528600
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _snippet_0(x_0_a_s_t_0, y_0_a_s_t_0):
        let(x_0_a_s_t_0)
        x_0_a_s_t_0.n = x_0_a_s_t_0.n + 1
        y_0_a_s_t_0 = 1
        return y_0_a_s_t_0
    _snippet_0(1, 1)
