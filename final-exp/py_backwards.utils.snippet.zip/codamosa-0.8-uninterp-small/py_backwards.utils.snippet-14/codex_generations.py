

# Generated at 2022-06-25 23:14:41.579535
# Unit test for function find_variables
def test_find_variables():
    checker_0 = find_variables(test_case_0)

    dict_0 = list(checker_0)

    assert dict_0 == ["dict_0"], "Test case 0 failed"



# Generated at 2022-06-25 23:14:45.143981
# Unit test for function extend_tree
def test_extend_tree():
    dict_0 = ({'x': 1, 'y': 2},{'z':3})
    extend(dict_0)
    assert(len(dict_0) == 3)
    assert('x' in dict_0)
    assert(dict_0['x'] == 1)
    assert(dict_0['z'] == 3)
    for i in range(2):
        for key,value in dict_0[i].items():
            assert(value == i+1)
            print(key,'=',value)

# Generated at 2022-06-25 23:14:50.406338
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(dict_0)")
    variables = {'dict_0': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],  # type: ignore
                                        value=ast.Num(1))]}
    extend_tree(tree, variables)
    assert get_source(tree) == "x = 1"

# Output:
#
# test_case_0
#   extend(dict_0)
#
# test_extend_tree
#   x = 1

# Generated at 2022-06-25 23:14:59.951119
# Unit test for function extend_tree
def test_extend_tree():
    def test_func_0(vars):
        print(x, y)

    def test_func_1(vars):
        let(x)
        extend(vars)
        print(x, y)

    source_0 = get_source(test_func_0)
    source_1 = get_source(test_func_1)
    tree_0 = ast.parse(source_0)
    tree_1 = ast.parse(source_1)

    assert len(tree_0.body) == 1
    assert isinstance(tree_0.body[0], ast.FunctionDef)
    assert len(tree_0.body[0].body) == 1
    assert isinstance(tree_0.body[0].body[0], ast.Expr)

# Generated at 2022-06-25 23:15:02.430709
# Unit test for function find_variables
def test_find_variables():
    source = 'let(x)\na = x + 1'
    tree = ast.parse(source)
    assert list(find_variables(tree)) == [source[4:-1]]



# Generated at 2022-06-25 23:15:06.036842
# Unit test for function find_variables
def test_find_variables():
    dict_0 = {}
    extend(dict_0)
    assert find_variables(ast.parse(get_source(test_case_0))) == {'dict_0'}

# Generated at 2022-06-25 23:15:11.093941
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    body = snippet(test_case_0).get_body()
    assert type(body) == list
    assert len(body) == 2
    assert body[0].value.elts[0].s == '"a"', body[0].value.elts[0].s

# Generated at 2022-06-25 23:15:20.605127
# Unit test for function extend_tree
def test_extend_tree():
    dict_0 = {}
    extend(dict_0)

# Generated at 2022-06-25 23:15:25.680938
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source0 = get_source(test_case_0)
    tree0 = ast.parse(source0)
    snippet0 = snippet(test_case_0)
    variables0 = snippet0._get_variables(tree0, {})
    extend_tree(tree0, variables0)
    VariablesReplacer.replace(tree0, variables0)
    assert tree0.body[0].body == snippet0.get_body()


# Generated at 2022-06-25 23:15:28.051387
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def s0():
        let(dict_0)
        extend(dict_0)

    assert s0.get_body() == test_case_0().body  # type: ignore

# Generated at 2022-06-25 23:15:41.766108
# Unit test for function extend_tree
def test_extend_tree():
    def f():
        var_0 = {}
        var_1 = {'x': 1}
        var_2 = {'y': 2}
        extend(var_1)
        extend(var_2)

    source = get_source(f)
    tree = ast.parse(source)
    find_variables(tree)
    extend_tree(tree, {
        'var_1': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                     value=ast.Num(n=1))],
        'var_2': [ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                     value=ast.Num(n=2))]})

# Generated at 2022-06-25 23:15:50.618609
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _fn_0(x_0):
        let(var_0)
        var_0[x_0] = 1
        x_0 += 1
        y_0 = 1
        extend(var_0)
        
    _var_0 = {}
    _kwargs_0 = dict(x_0='_py_backwards_x_0', var_0='_py_backwards_var_0')
    _fn_0_snippet = snippet(_fn_0)
    _body_0 = _fn_0_snippet.get_body(**_kwargs_0)
    _var_0_expected_0 = "{'_py_backwards_x_0': 1}"
    _var_0_actual_0 = str(_var_0)

# Generated at 2022-06-25 23:15:55.898557
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''
        let(x)
        x += 1
        y = 1
    ''')

    assert list(find_variables(tree)) == ['x']



# Generated at 2022-06-25 23:16:03.853114
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    s = snippet(test_case_0)
    var_2 = ['import dis', 'dis.dis(test_case_0)']
    var_1 = {'x': var_2}
    var_3 = s.get_body(**var_1)
    assert var_3 == [ast.Expr(ast.Call(ast.Attribute(ast.Name('dis', ast.Load()), 'dis', ast.Load()), [ast.Name('test_case_0', ast.Load())], []))]


# Generated at 2022-06-25 23:16:08.416147
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)
    assert snippet_0.get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_var_0_0', ctx=ast.Store())],
            value=ast.Dict(keys=[], values=[])
        )
    ]

# Generated at 2022-06-25 23:16:17.054044
# Unit test for function find_variables
def test_find_variables():
    c0 = ast.parse('x = 1').body[0]
    assert len(list(find_variables(c0))) == 0
    c1 = ast.parse('let(x)\nx = 1').body[0]
    assert list(find_variables(c1)) == ['x']
    c2 = ast.parse('let(x)\nlet(y)\nx = 1\ny = 1').body[0]
    assert set(find_variables(c2)) == {'x', 'y'}



# Generated at 2022-06-25 23:16:23.344604
# Unit test for function extend_tree
def test_extend_tree():
    var_0 = {}
    var_1 = {}

    def _fn(foo):
        extend(foo)

    var_2 = ast.parse("var_1 = 1; var_1 = 2; var_1 += 1; var_1 += 2; var_1 += 3; var_1 += 4; var_1 += 5").body
    _fn(var_2)


# Generated at 2022-06-25 23:16:26.986997
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse(get_source(test_case_0))
    extend_tree(tree, {'var_0': ast.parse('x = 1').body})
    assert isinstance(tree.body[0].body[0], ast.Assign)


# Generated at 2022-06-25 23:16:38.754400
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(ast.parse("let(var_1)").body[0]) == set(['var_1'])
    test_case_0()
    assert find_variables(ast.parse("tuple([var_0])").body[0]) == set(['var_0'])
    assert find_variables(ast.parse("let(var_3)").body[0]) == set(['var_3'])
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 23:16:43.576589
# Unit test for function extend_tree
def test_extend_tree():
    # Test declarations
    var_0: dict = {}

    # Test code
    func_0 = test_case_0()
    var_0 = tree.find(func_0, ast.Call)

    # Test assertion(s)

# Generated at 2022-06-25 23:16:48.877825
# Unit test for function extend_tree

# Generated at 2022-06-25 23:16:50.337588
# Unit test for function extend_tree
def test_extend_tree():
    with pytest.raises(Exception):
        extend_tree(None, None)


# Generated at 2022-06-25 23:16:55.938865
# Unit test for function extend_tree
def test_extend_tree():
    global var_0
    var_0 = {}
    extend_tree(ast.parse('extend(var_0)'), {'var_0': ast.Module(body=[ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(1)), ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(2))])})
    assert(var_0 == {'x': 2})


# Generated at 2022-06-25 23:16:58.453510
# Unit test for function extend_tree
def test_extend_tree():
    global var_0

    var_0 = {}
    extend_tree(ast.parse('''
x = 10
print(x)
'''), var_0)
    assert var_0 == {}


# Generated at 2022-06-25 23:17:00.329036
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = snippet.get_body()
    assert var_0 == []


# Generated at 2022-06-25 23:17:02.883294
# Unit test for function extend_tree
def test_extend_tree():
    """
    # 
    """
    test_0 = snippet(test_case_0)
    assert test_0.get_body()[0].value == {}


# Generated at 2022-06-25 23:17:11.551297
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 2
    var_0 = {'x': x}
    var_1 = var_0
    var_2 = var_0
    var_3 = var_1
    var_4 = var_3
    var_5 = var_4
    var_6 = var_5
    var_7 = var_6
    var_8 = var_7
    var_9 = var_8
    var_10 = var_9
    var_11 = var_10
    var_12 = var_11
    var_13 = var_12
    var_14 = var_13
    var_15 = var_14
    var_16 = var_15
    var_17 = var_16
    var_18 = var_17
    var_19 = var_18
    var_20 = var_19
    var

# Generated at 2022-06-25 23:17:20.571140
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}
    
    def args() -> None:
        x = 1
        y = 2
        z = 3
    
    def body(x: int = var_0, y: int = var_0, z: int = var_0) -> None:
        raise Exception()
    test_case_0()
    test_snippet_get_body()


from typing import Dict
from typing import Iterable
from typed_ast import ast3 as ast
from .tree import find, get_non_exp_parent_and_index, replace_at
from .helpers import eager, VariablesGenerator, get_source



# Generated at 2022-06-25 23:17:23.743920
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(x)')
    assert extend_tree(tree, {'x': 'y'}) is None
    assert ast.dump(tree) == 'Module(body=[Expr(value=y)])'


# Generated at 2022-06-25 23:17:25.535726
# Unit test for function extend_tree
def test_extend_tree():
    var_0 = {}

    def test_case_0():
        extend(var_0)

    test_case_0()


# Generated at 2022-06-25 23:17:31.182580
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0: dict = {}
    var_1 = snippet(test_case_0)
    var_2 = var_1.get_body()
    assert var_2 == []


# Generated at 2022-06-25 23:17:35.767984
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}
    var_1 = {}
    class_0 = snippet(test_case_0)
    result_0 = class_0.get_body()
    assert result_0 == [], 'Failed ' + 'snippet get_body'


# Generated at 2022-06-25 23:17:39.616703
# Unit test for function find_variables
def test_find_variables():
    def test_case():
        var_0 = {}
     
    
    # Call the function
    var_0 = find_variables(ast.parse(get_source(test_case)).body[0])
    
    # Check the result
    var_0 = True
    assert var_0


# Generated at 2022-06-25 23:17:43.989549
# Unit test for function extend_tree
def test_extend_tree():
    var_0 = {}
    var_0[str] = 'x = 1'
    var_0[str] = 'x = 2'
    var_0[str] = 'print(x, y)'
    var_0[str] = 'x = 1\nx = 2\nprint(x, y)\n'


# Generated at 2022-06-25 23:17:48.929848
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    _py_backwards_a_0 = 0
    _py_backwards_b_1 = 0
    let(_py_backwards_a_0)
    _py_backwards_a_0 += 1
    _py_backwards_b_1 = 1
    assert (_py_backwards_a_0) == 1
    assert (_py_backwards_b_1) == 1


# Generated at 2022-06-25 23:17:51.182560
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''
x = 1
y = 2
''')
    variables = find_variables(tree)
    assert variables == ['x', 'y']


# Generated at 2022-06-25 23:17:51.944687
# Unit test for function find_variables
def test_find_variables():
    test_case_0()



# Generated at 2022-06-25 23:17:55.483314
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_ = snippet(test_case_0)
    snippet_kwargs_ = {}
    res_ = snippet_.get_body(**snippet_kwargs_)
    assert isinstance(res_, list)


# Unit tests for function test_case_0

# Generated at 2022-06-25 23:18:03.348494
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test(a):
        let(x)
        let(y)
        extend(vars)
        print(x, y)
    snippet_kwargs = {'vars': var_0, 'y': var_1, 'x': var_2}
    body = snippet(_test).get_body(**snippet_kwargs)


# Generated at 2022-06-25 23:18:06.102339
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}
    var_1 = test_case_0()
    var_2 = snippet(test_snippet_get_body).get_body()
    assert var_2 == [], var_2


# Generated at 2022-06-25 23:18:13.975582
# Unit test for function find_variables
def test_find_variables():
    assert test_case_0 == find_variables(ast.parse(get_source(test_case_0)))


# Generated at 2022-06-25 23:18:16.704465
# Unit test for function extend_tree
def test_extend_tree():
    var_0 = {}

    test_case_0()

# Generated at 2022-06-25 23:18:18.182195
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = test_case_0()


# Generated at 2022-06-25 23:18:19.001933
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}


# Generated at 2022-06-25 23:18:28.574673
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}
    var_1 = {'x': 1}
    var_2 = vars = {}
    with snippet(test_case_0) as test_case:
        assert test_case.get_body() == ast.parse("""
            var_0 = {}
        """).body
        assert test_case.get_body(x=1) == ast.parse("""
            var_1 = {'x': 1}
        """).body
        assert test_case.get_body(vars=1) == ast.parse("""
            var_2 = vars = {}
        """).body

test_snippet_get_body()

# Generated at 2022-06-25 23:18:30.157595
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(var_0)
        var_0 = {}[()]
    assert snippet(fn).get_body() == ast.parse("var_0 = {}[()]").body[0].body


# Generated at 2022-06-25 23:18:31.660594
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body(var_0 = {}) == []

# Generated at 2022-06-25 23:18:38.164885
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def a():
        let(var_0)
        var_0["test"] = 5
    c = snippet(a).get_body()
    assert(len(c) == 1)
    for i in c:
        if isinstance(i, ast.Assign):
            assert(get_source(i.value) == "5")
            assert(get_source(i.targets[0]) == "_py_backwards_var_0_0[\"test\"]")



# Generated at 2022-06-25 23:18:43.361649
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def x():
        extend(var_0)

    test_case_0()
    assert snippet(x).get_body(var_0=var_0) == [comprehension(target=Name(id='_py_backwards_var_0_0', ctx=Store()), iter=Dict(keys=[], values=[]), ifs=[]), Return(value=None)]

# Generated at 2022-06-25 23:18:48.744996
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = 'var_0 = {}'
    tree = ast.parse(source)
    variables = {'var_0': 'var_1'}
    extend_tree(tree, variables)
    expected = VariablesReplacer.replace(tree, variables).body
    assert expected == test_case_0.get_body(var_0=ast.Name(id='var_1', ctx=ast.Load()))

# Generated at 2022-06-25 23:19:02.766987
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = test_case_0()
    var_1 = snippet(test_case_0)
    var_2 = var_1.get_body()
    var_3 = [ast.Assign(targets=[ast.Name(id='_py_backwards_var_0', ctx=ast.Store())],
                        value=ast.Dict(keys=[], values=[])), ast.Expr(value=ast.Call(func=ast.Name(id='_py_backwards_print', ctx=ast.Load()),
                                                                                    args=[], keywords=[], starargs=None, kwargs=None))]
    assert var_2 == var_3


# Generated at 2022-06-25 23:19:06.647872
# Unit test for function extend_tree
def test_extend_tree():
    var_0 = {'var_1': 'var_1'}

    var_2 = ast.parse('(var_2)').body[0]  # type: ignore
    extend_tree(var_2, var_0)
    assert var_2.value.args[0].id == 'var_1'  # type: ignore



# Generated at 2022-06-25 23:19:08.435217
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def get_body(x: int) -> None:
        let(var_0)
        var_0["a"] = x
    x = 1
    test_case_0()

    snippet(get_body).get_body(x = x)

# Generated at 2022-06-25 23:19:18.573113
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}
    var_1 = {}
    try:
        var_1['x'] = None
    except Exception as var_3:
        var_2 = var_3
    try:
        var_1['y'] = 0
    except Exception as var_3:
        var_2 = var_3
    try:
        var_1['x'] = extend(var_1)
    except Exception as var_3:
        var_2 = var_3
    try:
        var_1['y'] = let(var_1)
    except Exception as var_3:
        var_2 = var_3
    try:
        var_0['_py_backwards_x_0'] = 0
    except Exception as var_3:
        var_2 = var_3

# Generated at 2022-06-25 23:19:27.394878
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class snippet_1:
        """Snippet of code."""
    
        def __init__(self) -> None:
            self.var_0 = {}
        
        def get_body(self, var_0: Variable) -> List[ast.AST]:
            """Get AST of snippet body with replaced variables."""
            source = get_source(self._fn)
            tree = ast.parse(source)
            variables = self._get_variables(tree, snippet_kwargs)
            extend_tree(tree, variables)
            VariablesReplacer.replace(tree, variables)
            return tree.body[0].body  # type: ignore
        
        def _get_variables(self, tree: ast.AST, snippet_kwargs: Dict[str, Variable]) -> Dict[str, Variable]:
            names = find_

# Generated at 2022-06-25 23:19:28.716999
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(test_case_0) == {'var_0'}


# Generated at 2022-06-25 23:19:30.073765
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def _(_):
        let(var_0)


# Generated at 2022-06-25 23:19:32.649513
# Unit test for function find_variables
def test_find_variables():
    assert _py_backwards_find_variables(test_case_0.__code__.co_consts[1]) == ['_py_backwards_var_0']


# Generated at 2022-06-25 23:19:42.711407
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}
    # TEST get_body.test_snippet
    # TEST snippet.get_body.test_snippet
    var_0["snippet"] = snippet
    var_0["test_case_0"] = test_case_0
    def test_case_0():
        var_1 = {}
        # TEST get_body.test_snippet.test_case_0
        # TEST snippet.get_body.test_snippet.test_case_0
        var_1["var_0"] = var_0
        var_1["var_1"] = var_1

test_snippet_get_body()

# Generated at 2022-06-25 23:19:49.775387
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = 2
    var_0 = {}
    var_0["x"] = x
    var_0["y"] = y
    snip_0 = snippet(test_case_0)
    var_1 = snip_0.get_body(**var_0)
    assert var_1[0].targets[0].id == "_py_backwards_x_0"
    assert var_1[0].value.n == 1
    assert var_1[1].targets[0].id == "_py_backwards_y_0"
    assert var_1[1].value.n == 2

# Generated at 2022-06-25 23:19:55.624790
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    pass

# Generated at 2022-06-25 23:20:05.880505
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Call(func=module_0.Name(id="let"), args=[module_0.Name(id="_py_backwards_x_0")], keywords=[])
    a_s_t_2 = module_0.Name(id="_py_backwards_x_0")
    a_s_t_3 = module_0.Assign(targets=[a_s_t_2], value=module_0.Num(n=1.0))

# Generated at 2022-06-25 23:20:13.145952
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_1 = Let(x)
    x += 1
    y = 1
    a_s_t_1 = extend(vars)
    print(x, y)
    snippet_0 = snippet(test_snippet_get_body)
    a_s_t_2 = snippet_0.get_body(snippet_kwargs={}, vars={}, x={})
    expected = [Assign(targets=[Name(id='_x_0', ctx=Store())], value=BinOp(left=Name(id='_x_0', ctx=Load()), op=Add(), right=Num(n=1))),
                Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=1))]

# Generated at 2022-06-25 23:20:27.532723
# Unit test for function find_variables
def test_find_variables():
    a_s_t_1 = module_0.AST()
    s_l_i_c_e_0 = slice(0, 1, None)
    a_t_t_r_i_b_u_t_e_0 = getattr(a_s_t_1, "body")
    a_t_t_r_i_b_u_t_e_1 = getattr(a_s_t_1, "body")

# Generated at 2022-06-25 23:20:40.543592
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Creating params
    var_x_0 = 1
    var_y_0 = 1
    var_z_0 = 1
    # Creating lambda
    lambda_0 = lambda x, y, z : x + y + z
    # Creating snippet
    snippet_0 = snippet(lambda_0)
    # Calling method get_body
    var_res_0 = snippet_0.get_body(x=var_x_0, y=var_y_0, z=var_z_0)
    # Checking result
    assert(len(var_res_0) == 3)
    for var_index_0 in range(len(var_res_0)):
        var_elem_0 = var_res_0[var_index_0]

# Generated at 2022-06-25 23:20:52.435897
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Snippet of code.:
    class snippet_0(snippet):
        def __init__(self) -> None:
            snippet.__init__(self, self.__my_method)

        def __my_method(self) -> None:
            let(x)
            x = 1
            print(x)
    # -- end snippet -- #
    snippet_0_0 = snippet_0()
    list_0 = snippet_0_0.get_body()
    assert type(list_0[1]) is module_0.Assign
    assert type(list_0[2]) is module_0.Print

# Generated at 2022-06-25 23:21:01.674074
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def reverse(s):
        return s[::-1]

    def reverse_words(string):
        return ' '.join(reverse(word) for word in string.split())

    s = snippet(reverse)
    s.get_body()

    for i in range(10):
        assert reverse(str(i)) == s.get_body(s=str(i))[0].value.s  # type: ignore

    s = snippet(reverse_words)
    s.get_body()

    for i in range(10):
        assert reverse_words(str(i)) == ''.join(s.get_body(string=str(i))[0].value.s)  # type: ignore



# Generated at 2022-06-25 23:21:09.760462
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    UNNECESSARY_SNIPPET = b'\x68\x65\x6c\x6c\x6f'
    # Test case 1
    def snippet_fn_1(x_1: let, y_1: extend):
        let(x_1)
        x_1 += 1
        _py_backwards_y_1_0 = 1
        extend(_py_backwards_y_1_0)
        return _py_backwards_y_1_0
    snippet_0 = snippet(snippet_fn_1)
    assert snippet_0.get_body(
        x_1=UNNECESSARY_SNIPPET,
        _py_backwards_y_1_0=UNNECESSARY_SNIPPET
    )
    # Test case 2

# Generated at 2022-06-25 23:21:15.279579
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _2(function):
        var_2 = 2
        var_1 = 1
        function(var_1, var_2)

    snippet_0 = snippet(_2)
    body_0 = snippet_0.get_body()
    assert len(body_0) == 2
    assert isinstance(body_0[0], module_0.Assign)
    assert isinstance(body_0[1], module_0.Assign)

# Generated at 2022-06-25 23:21:19.074850
# Unit test for function find_variables
def test_find_variables():
    try:
        assert False
    except AssertionError:
        raise

import unittest as module_1

import typed_ast._ast3 as module_2
import typed_ast._ast3 as module_3
from . import tree as module_4
from . import helpers as module_5


# Generated at 2022-06-25 23:21:39.608787
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # (1)
    """
    let(f)
    f(1)
    """
    
    
    def _f_0(arg_0):
        print(arg_0)
    
    
    snippet_0 = snippet(_f_0)
    list_0 = snippet_0.get_body()
    _f_0 = list_0[1]
    assert isinstance(_f_0, module_0.Expr)
    _f_1 = _f_0.value
    assert isinstance(_f_1, module_0.Call)
    _f_2 = _f_1.func
    assert isinstance(_f_2, str)
    _f_3 = _f_1.args
    list_1 = _f_3[0]

# Generated at 2022-06-25 23:21:43.597184
# Unit test for function extend_tree
def test_extend_tree():
    @snippet
    def test_0():
        let(a)
        let(b)
        extend(a)
        let(c)

    assert len(test_0.get_body()) == 3



# Generated at 2022-06-25 23:21:44.407453
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # TODO: Implement unit test.
    pass

# Generated at 2022-06-25 23:21:50.482605
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    dict_0 = {a_s_t_1: a_s_t_0}
    list_0 = [a_s_t_0]
    s_n_i_p_p_e_t_0 = snippet(test_snippet_get_body)
    list_1 = s_n_i_p_p_e_t_0.get_body(dict_0)
    test.assertEqual(list_0, list_1)

# Generated at 2022-06-25 23:21:58.904775
# Unit test for function find_variables
def test_find_variables():
    # Not-Checked attributes:
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    # Checked attributes:
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    assert iterable_0 == list()

# Generated at 2022-06-25 23:22:01.568147
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x):
        print(x)
    snippet_0 = snippet(fn)
    dict_0 = dict()
    list_0 = snippet_0.get_body(**dict_0)

# Generated at 2022-06-25 23:22:05.578966
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 1
    a_s_t_0 = fn()
    a_s_t_1 = ast.parse("x=1\ny=1")
    assert a_s_t_1 == a_s_t_0

# Generated at 2022-06-25 23:22:10.965580
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Body of method snippet.get_body
    def a_s_t_0():
        let(a_s_t_0)
        a_s_t_0 += a_s_t_0
        a_s_t_0 = a_s_t_0
    snippet_0 = snippet(a_s_t_0)
    a_s_t_0 = snippet_0.get_body()


# Generated at 2022-06-25 23:22:16.810409
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import typed_ast._ast3 as module_0
    import typing as module_1
    import __future__ as module_2
    import enum as module_3
    import weakref as module_4
    import typing as module_5
    import numpy as module_6
    import collections as module_7
    @snippet
    def function_0(arg_0):
        let(a_0)
        let(b_0)
        a_0 = arg_0
        b_0 += 2
        return a_0, b_0
    a_s_t_0 = module_0.AST()
    snippet_kwargs_0 = {"arg_0": a_s_t_0}
    body_0 = function_0.get_body(**snippet_kwargs_0)

# Generated at 2022-06-25 23:22:18.832996
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def nested_fn_0(a: Any, b: Any=1) -> Any:
        pass


# Generated at 2022-06-25 23:22:54.702956
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def a_s_t_0():
        class ClassDef_1():
            def FunctionDef_2():
                let(Exec_3)
                a_n_n_0 = Exec_3()
                Not_4 = (Call_5 != a_n_n_0)
        Exec_6 = a_n_n_0()
        a_n_n_1 = Exec_6()
        Name_7 = a_n_n_1()
    snippet_0 = snippet(a_s_t_0)
    dict_1 = dict(Name_6=1)
    list_0 = snippet_0.get_body(**dict_1)

# Generated at 2022-06-25 23:23:03.122463
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def generator_function_0(*args, **kwargs):
        snippet_kwargs_0 = kwargs
        x_0 = kwargs.get('x', None)
        let(x_0)
        x_0 += 1
        y_0 = kwargs.get('y', None)
        y_0 = 1
        return
    generator_function_1 = snippet(generator_function_0)
    snippet_kwargs_0 = {'x': 1, 'y': 2}
    a_s_t_1 = generator_function_1.get_body(**snippet_kwargs_0)


# Generated at 2022-06-25 23:23:05.198111
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def target_1():
        def body_3():
            pass
        body_3()
    target_1.get_body()

# Generated at 2022-06-25 23:23:12.835812
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import typed_ast._ast3 as module_0
    def func_0(arg_0):
        let(arg_0)
        var_0 = module_0.Name(id='arg_0', ctx=module_0.Load())
        var_1 = module_0.Name(id='var_0', ctx=module_0.Load())
        func_0.__code__.co_consts = (module_0.Name(id='arg_0', ctx=module_0.Load()), module_0.Store(), module_0.Add(), module_0.Name(id='var_1', ctx=module_0.Load()), module_0.Name(id='var_0', ctx=module_0.Load()), )

# Generated at 2022-06-25 23:23:19.655144
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_1():
        class_0 = snippet(test_case_1)
        a_s_t_0 = ast.parse('y = 1\n')
        a_s_t_0 = ast.fix_missing_locations(a_s_t_0)
        a_s_t_1 = ast.parse('x = 0\n')
        a_s_t_2 = ast.parse('x+=1\n')
        dict_0 = {'vars': [a_s_t_1, a_s_t_2]}
        s_t_0 = class_0.get_body(**dict_0)
        assert(s_t_0 != a_s_t_0.body)


# Generated at 2022-06-25 23:23:22.335158
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test(x: int) -> None:
        x = let(x)
        x += 1
        y = 1
    snippet_0 = snippet(test)
    snippet_0.get_body()

# Generated at 2022-06-25 23:23:31.296654
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        x += 1
        y = 1
    s = snippet(f)
    b = s.get_body()
    assert isinstance(b, list)
    assert len(b) == 2
    assert isinstance(b[0], ast.Assign)
    assert isinstance(b[0].value, ast.BinOp)
    assert isinstance(b[0].value.op, ast.Add)
    assert isinstance(b[0].targets[0], ast.Name)
    assert b[0].targets[0].id == '_py_backwards_x_0'
    assert isinstance(b[1], ast.Assign)
    assert isinstance(b[1].value, ast.Constant)
    assert b[1].value.value == 1


# Generated at 2022-06-25 23:23:34.026953
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn_0():
        let(x)
        x += 1
        y = 1
    a_s_t_0 = snippet(fn_0).get_body(x=ast.Name(id="_py_backwards_x_0"))


# Generated at 2022-06-25 23:23:39.722433
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def a_s_t_0():
        let('a_s_t_0')
        let('x')
        a_s_t_0 = extend('a_s_t_0')
        x = x
    instance = snippet(a_s_t_0)
    instance.get_body(a_s_t_0=[], x=module_0.Name(id='x_0', ctx=module_0.Load()))


# Generated at 2022-06-25 23:23:40.741176
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
