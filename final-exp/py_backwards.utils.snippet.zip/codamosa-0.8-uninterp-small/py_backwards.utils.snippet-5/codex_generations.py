

# Generated at 2022-06-25 23:14:36.465703
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(x)\ny=1')
    extend_tree(tree, {'x': [ast.Assign([ast.Name('m')], ast.Num(1)), ast.Assign([ast.Name('n')], ast.Num(1))]})
    assert tree == ast.parse('m = 1\nn = 1\ny=1')


# Generated at 2022-06-25 23:14:38.293105
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse(get_source(test_case_0)))) == ['str_0']



# Generated at 2022-06-25 23:14:46.634772
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("x = 1\n x = 2\n print(x,y)")
    variables = {'vars': ast.parse("x = 1\n x = 2")}
    extend_tree(tree, variables)
    assert str(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=2)), Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Name(id='x', ctx=Load()), Name(id='y', ctx=Load())], keywords=[]))])"



# Generated at 2022-06-25 23:14:53.904560
# Unit test for function extend_tree
def test_extend_tree():
    try:
        from typed_ast.ast3 import parse
    except ImportError:
        from ast import parse
    from .tree import find
    
    # Case 0
    source = """print(x)"""
    source_ast = parse(source)
    tree = source_ast.body[0]
    node = list(find(tree, ast.Name))[0]
    node.id = 'y'
    variables = {'x': source_ast}
    extend_tree(tree, variables)
    assert(tree.body[0].args[0].id == 'y')


# Generated at 2022-06-25 23:14:56.757013
# Unit test for function find_variables
def test_find_variables():
    assert find_variables('let(str_0)\nstr_0 = \'email_mime_image\''
                          == {'str_0': '_py_backwards_str_0_0'})



# Generated at 2022-06-25 23:14:58.159886
# Unit test for function extend_tree
def test_extend_tree():
    str_0 = 'email_mime_image'
    let(str_0)
    return_value = "email_mime_image.open('rb')".split()
    return return_value

# Generated at 2022-06-25 23:15:00.596013
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snip = snippet(test_case_0)
    assert snip.get_body()[0].value.args[0].s == "_py_backwards_str_0_0"

# Generated at 2022-06-25 23:15:03.418801
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("from foo.bar import a, b, c as g")
    variables = {'a': 'b', 'g': 'd'}
    inst = VariablesReplacer(variables)
    inst.visit_alias(tree)

# Generated at 2022-06-25 23:15:04.415440
# Unit test for function extend_tree

# Generated at 2022-06-25 23:15:11.851790
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    def call_0(x_0, x_1):
        return x_0.visit_alias(x_1)
    x_0 = VariablesReplacer(x_1, x_2, x_3, x_4, x_5)
    x_1 = dict()
    x_2 = dict()
    x_3 = dict()
    x_4 = dict()
    x_5 = dict()
    call_0(x_0, x_1)


# Generated at 2022-06-25 23:15:22.715089
# Unit test for function find_variables
def test_find_variables():
    assert set(find_variables(test_case_0)) == {'str_0'}



# Generated at 2022-06-25 23:15:31.202251
# Unit test for function extend_tree
def test_extend_tree():
    extend_test_tree1 = ast.parse('''
        class Foo(object):

            def wrap(self, num_threads):
                pass

            def extend(self, vars):
                x = 1
                y = 1
                list(x, y)

            def extend(self, vars):
                print(x, y)
    ''')
    extend_test_tree2 = ast.parse('''
        class Foo(object):

            def wrap(self, num_threads):
                pass

            def extend(self, vars):
                x = 1
                y = 1
                list(x, y)


            def extend(self, vars):
                print(x, y)

            def method(self):
                pass
    ''')

# Generated at 2022-06-25 23:15:40.771017
# Unit test for function extend_tree
def test_extend_tree():
    val = ast.parse("""
    extend(vars)
    x = 1
    """).body

    variables = {"vars": [
        ast.Assign(
            targets=[ast.Name(id="x", ctx=ast.Store())],
            value=ast.Num(n=2),
        )
    ]}

    replace_at(1, val, variables["vars"])
    assert val == [
        ast.Assign(
            targets=[ast.Name(id="x", ctx=ast.Store())],
            value=ast.Num(n=2),
        ),
        ast.Assign(
            targets=[ast.Name(id="x", ctx=ast.Store())],
            value=ast.Num(n=1),
        ),
    ]



# Generated at 2022-06-25 23:15:44.076286
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert str(snippet(test_case_0).get_body()) == str(ast.parse(
        'str_0 = \'email_mime_image\''
    ).body)



# Generated at 2022-06-25 23:15:47.160237
# Unit test for function find_variables
def test_find_variables():
    # Case 0
    tree_0 = ast.parse(inspect.getsource(test_case_0)).body[0]
    assert(list(find_variables(tree_0)) == ['str_0'])


# Generated at 2022-06-25 23:15:53.291937
# Unit test for function find_variables
def test_find_variables():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert('str_0' in variables)

# Generated at 2022-06-25 23:15:56.112779
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    str_0 = 'email_mime_image'
    body = snippet(test_case_0).get_body()
    assert body[0].value.value.s == 'email_mime_image'

# Generated at 2022-06-25 23:16:04.511693
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import_from_0 = ast.ImportFrom('typed_ast', [ast.alias('parse', None)],  # type: ignore
                                   0)
    import_from_1 = ast.ImportFrom('typed_ast', [ast.alias('parse', None)],  # type: ignore
                                   1)

    trans = VariablesReplacer({
        'typed_ast.parse': 'my.ast.parse',
    })
    result = trans.visit_ImportFrom(import_from_0)
    expected_result = import_from_1
    assert result == expected_result


# Generated at 2022-06-25 23:16:07.600952
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from unittest.mock import Mock
    from py_backwards.transformers.snippets import snippet
    snippet_get_body = snippet(Mock()).get_body
    assert snippet_get_body() == []



# Generated at 2022-06-25 23:16:12.487371
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test_snippet_get_body_0():
        str_0 = 'email_mime_image'
        let(str_0)
    snippet_0 = snippet(_test_snippet_get_body_0)
    ast_0 = snippet_0.get_body()


# Generated at 2022-06-25 23:16:21.120785
# Unit test for function find_variables
def test_find_variables():
    function_body = test_case_0.__globals__["test_case_0"].__code__.co_code
    assert find_variables(function_body) == ["int_0"]


# Generated at 2022-06-25 23:16:24.823775
# Unit test for function find_variables
def test_find_variables():
    test_code = 'let(int_0); let(int_1);'
    expected_list = ['int_0', 'int_1']
    assert find_variables(ast.parse(test_code)) == expected_list


# Generated at 2022-06-25 23:16:32.238039
# Unit test for function find_variables
def test_find_variables():
    '''
    Asserts that find_variables returns list of strings containing names of
    variables declared with let.
    '''
    snippet_code = """
    def main():
        let(x)
        print(x)
        let(y)
        print(x)
        print(y)
    """
    variables = find_variables(ast.parse(snippet_code))
    assert next(variables) == 'x'
    assert next(variables) == 'y'



# Generated at 2022-06-25 23:16:40.853067
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    def test_case_0():
        int_0 = 0
    
    snippet_0 = snippet(test_case_0)
    body = snippet_0.get_body()

    assert isinstance(body, list) and body == [
        ast.Assign(
            targets=[
                ast.Name(id='int_0', ctx=ast.Store())
            ],
            value=ast.Num(n=0)
        )
    ]

    def test_case_1(int_0, int_1):
        int_0 = 0
        int_1 += 1
    
    snippet_1 = snippet(test_case_1)
    body = snippet_1.get_body()


# Generated at 2022-06-25 23:16:42.900589
# Unit test for function extend_tree
def test_extend_tree():
    assert len(test_case_0.__code__.co_names) == 1


#  Unit test for function find_variables

# Generated at 2022-06-25 23:16:49.394374
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse('let(x) + x'))) == ['x']
    assert list(find_variables(ast.parse('x + let(x)'))) == ['x']
    assert list(find_variables(ast.parse('let(x) + let(x)'))) == ['x', 'x']
    assert list(find_variables(ast.parse('let(x) + x + let(x)'))) == ['x', 'x']



# Generated at 2022-06-25 23:16:57.948243
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = "let(io) let(dir) io.dir(dir)"
    tree = ast.parse(source)
    io = ast.Name(id="io")
    dir = ast.Name(id="dir")
    snp = snippet(test_case_0)
    variables = snp._get_variables(tree, {'io': io, 'dir': dir})
    assert 'io' in variables and variables['io'] == "io"
    assert 'dir' in variables and variables['dir'] == "dir"
    extend_tree(tree, variables)
    body = snp.get_body(**variables)
    assert body[0].value.func.id == "io.dir"
    assert body[0].value.args[0].id == "dir"

# Generated at 2022-06-25 23:17:05.691923
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from typed_ast import ast3 as ast
    from .helpers import VariablesGenerator
    obj0 = None
    var0 = VariablesReplacer(obj0)
    lst0 = ["x", "y", "z"]
    obj1 = VariablesGenerator(lst0)
    var1 = VariablesGenerator.generate
    lst1 = ["x", "y", "z"]
    obj2 = VariablesGenerator(lst1)
    var2 = VariablesGenerator.generate
    var3 = ast.alias(name = 'x', asname = var2)
    var3 = var0._replace_module('x')


# Generated at 2022-06-25 23:17:10.138328
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import astor
    snippet_0_instance = snippet(test_case_0)
    snippet_0_instance_get_body_result = snippet_0_instance.get_body()
    snippet_0_instance_get_body_result_str = astor.to_source(snippet_0_instance_get_body_result).lstrip()
    assert snippet_0_instance_get_body_result_str == "int_0 = 0"

# Test that the case works when the source is a normal Python file.
# TODO: This test will fail because we can't change the source file.
#def test_snippet_get_body_file():
#    import astor
#    snippet_0_instance = snippet(test_snippet_get_body_file)
#    snippet_0_instance_get_body

# Generated at 2022-06-25 23:17:12.231842
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(ast.parse("let(x)\nx += 1")) == ['x']


# Generated at 2022-06-25 23:17:18.793596
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    int_0 = 0
    assert type(int_0) == int
    if int_0 == 0:
        tmp_0 = int_0
        assert type(tmp_0) == int
        int_0 = tmp_0
    else:
        assert False
    return 0

# Generated at 2022-06-25 23:17:22.755013
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def _test_case_0():
        int_0 = 0
        return int_0
    int_0 = _test_case_0.get_body()
    assert int_0 == test_case_0()


# Generated at 2022-06-25 23:17:24.093882
# Unit test for function find_variables
def test_find_variables():
    source = """
    let(a)
    a += 1
    """
    tree = ast.parse(source)
    variables = list(find_variables(tree))
    assert variables == ['a']



# Generated at 2022-06-25 23:17:31.876147
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class snippet_get_body:
        int_0 = 0
        int_1 = 1
        int_2 = 2
        int_3 = 3
        int_4 = 4
        int_5 = 5
        int_6 = 6
        int_7 = 7
        int_8 = 8
        int_9 = 9
        int_10 = 10
        int_11 = 11
        int_12 = 12
        int_13 = 13
        int_14 = 14
        int_15 = 15
        int_16 = 16
        int_17 = 17
        int_18 = 18
        int_19 = 19
        int_20 = 20
        int_21 = 21
        int_22 = 22
        int_23 = 23
        int_24 = 24
        int_25 = 25
        int_26 = 26
       

# Generated at 2022-06-25 23:17:36.881523
# Unit test for function find_variables
def test_find_variables():
    source = """
        let(x = 3)
        y = x + 1
        def foo():
            pass
        bar = x
    """
    parsed_source = ast.parse(source)
    assert ('x', 'y') == tuple(find_variables(parsed_source))



# Generated at 2022-06-25 23:17:41.032138
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from typed_ast.ast3 import ImportFrom
    from typed_ast.ast3 import alias
    import sys

    import_from = ImportFrom()
    alias = alias()

    instance = VariablesReplacer.replace(import_from, alias)
    assert instance == ImportFrom(alias)


# Generated at 2022-06-25 23:17:50.086586
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(x):
        let(y)
        y += 1
        print(x, y)

# Generated at 2022-06-25 23:17:52.888454
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse('from math import sin, cos, pi as math_pi')
    variables = {
        'math': 'math'
    }
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == 'from math import sin, cos, pi as math_pi'


# Generated at 2022-06-25 23:18:03.087376
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import_from = ast.ImportFrom(module='datetime', names=[ast.alias(name='datetime', asname='datetime')], level=0)
    assert import_from.names[0].name == 'datetime'
    assert import_from.names[0].asname == 'datetime'
    VariablesReplacer.replace(import_from, {'datetime': 'datetime_1'})
    assert import_from.names[0].name == 'datetime_1'
    assert import_from.names[0].asname == 'datetime_1'
    

# Generated at 2022-06-25 23:18:07.169678
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """If this test does not raise any exception, then everything is okay."""

    class TestSnippet(snippet):
        def __init__(self, fn):
            snippet.__init__(self, fn)

    ts = TestSnippet(test_case_0)
    ts.get_body()

if __name__ == "__main__":
    test_snippet_get_body()

# Generated at 2022-06-25 23:18:19.465729
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast
    import _ast
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    @snippet_0.get_body(a=10, b=20)
    def func_snippet_0(a, b, c):
        let(c)
        c = a + b
        return c

    assert (
        repr(func_snippet_0) == "[Assign(targets=[Name(id='_py_backwards_c_0', ctx=Store())], value=BinOp(left=Num(n=10), op=Add(), right=Num(n=20)))]"
    )

# Generated at 2022-06-25 23:18:30.600641
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    # Test case 0
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    var_0 = 1
    var_1 = 2
    var_2 = 3
    var_3 = 4
    var_4 = 7
    var_5 = 8
    var_6 = 9
    var_7 = 10
    var_8 = 11
    var_9 = 12
    var_10 = 13
    var_11 = 14
    var_12 = 15
    var_13 = 16
    var_14 = 17
    var_15 = 18
    var_16 = 19
    var_17 = 20
    var_18 = 21
    var_19 = 22
    var_20 = 23
    var_21 = 24
    var_22 = 25
    var_23 = 26
    var_

# Generated at 2022-06-25 23:18:39.732942
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    float_0 = -3.0
    float_1 = -3.0
    float_2 = -3.0
    float_3 = -3.0
    float_4 = -3.0
    float_5 = -3.0
    float_6 = -3.0
    float_7 = -3.0
    float_8 = -3.0
    float_9 = -3.0
    float_10 = -3.0
    float_11 = -3.0
    float_12 = -3.0
    float_13 = -3.0
    float_14 = -3.0
    float_15 = -3.0
    float_16 = -3.0
    float_17 = -3.0
    float_18 = -3.0
    float_19 = -3.0

# Generated at 2022-06-25 23:18:42.949201
# Unit test for function extend_tree
def test_extend_tree():
    float_1 = float_0
    snippet_1 = snippet(float_1)
    __py_result_0 = extend_tree(snippet_0.get_body(), snippet_1.get_body())


# Generated at 2022-06-25 23:18:47.335082
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    float_0 = -390.8
    snippet_0 = snippet(float_0)

    str_0 = snippet_0.get_body()
    str_1 = "import numpy as _py_backwards_np_0"
    assert str_0 == str_1



# Generated at 2022-06-25 23:18:56.426445
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    for i in range(10):
        float_0 = -390.8
        snippet_0 = snippet(float_0)
        if float_0 != float_0:
            float_0 = float_0
        else:
            if float_0 <= float_0:
                float_0 -= float_0
            else:
                if float_0 > float_0:
                    float_0 += float_0
                else:
                    if float_0 < float_0:
                        float_0 += float_0
                    else:
                        if float_0 >= float_0:
                            float_0 = float_0
                        elif float_0 < float_0:
                            float_0 -= float_0
                        else:
                            if float_0 >= float_0:
                                float_0 += float_0
                            el

# Generated at 2022-06-25 23:18:58.761978
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    data = {'name': 'Foo', 'value': 1}
    snippet_body = snippet(test_case_0).get_body(**data)



# Generated at 2022-06-25 23:19:08.016011
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    float_1 = -170.0
    float_2 = float_0
    int_0 = 2
    float_3 = float_1
    int_1 = 2
    float_4 = float_3
    int_2 = 2
    float_5 = float_4
    int_3 = 2
    float_6 = float_2
    int_4 = 2
    float_7 = float_5
    int_5 = 2
    float_8 = float_6
    int_6 = 2
    float_9 = float_8
    int_7 = 2
    float_10 = float_1
    int_8 = 2
    float_11 = float_5
    int_9 = 2
    float_12 = float_0
    int_10 = 2
    float_

# Generated at 2022-06-25 23:19:11.292061
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    expect_0 = ast.parse('float_0 = -390.8')
    snippet_0 = snippet(float_0)
    assert snippet_0.get_body() == expect_0.body[0].body


# Generated at 2022-06-25 23:19:22.173751
# Unit test for function extend_tree
def test_extend_tree():
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    int_0 = -4
    int_1 = -4
    int_1 = int_1 * int_0
    int_0 = -1
    snippet_1 = snippet(float_0)
    tuple_0 = (-2, 3)
    tuple_2 = (-2, 3)
    list_0 = (1, 2)
    tuple_3 = (1, 2)
    int_2 = -4
    int_2 = int_2 * int_1
    int_1 = -1
    tuple_3 = (1, 2)
    int_3 = -4
    int_3 = int_3 * int_2
    int_2 = -1
    list_0 = (1, 2)
    int_4

# Generated at 2022-06-25 23:19:35.387752
# Unit test for function extend_tree
def test_extend_tree():
    import ast
    import io
    import pandas as pd
    import numpy as np
    from pandas.testing import assert_frame_equal

    # Arrange

# Generated at 2022-06-25 23:19:38.440237
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Case 0
    float_1 = -390.8
    snippet_0 = snippet(float_1)
    snippet_0.get_body()
    assert snippet_0._fn(-390.8)

# Generated at 2022-06-25 23:19:41.153857
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = -390.8
    actual = snippet(x).get_body()
    expected = [ast.Expr(value=ast.Num(-390.8))]
    assert actual == expected


# Generated at 2022-06-25 23:19:49.420502
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_fn(x):
        let(x)
        while x:
            let(x)
            if x:
                let(x)
                x += 1
                let(x)
                x -= 1
            let(x)
            x += 1
            let(x)
            x -= 1
        let(x)
        x += x
        return x

    body = test_fn.get_body(x=1)
    assert isinstance(body, list)
    assert len(body) == 1
    assert isinstance(body[0], ast.FunctionDef)
    assert body[0].name == 'test_fn'
    assert body[0].args.args[0].arg == 'x'



# Generated at 2022-06-25 23:19:57.969702
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from py_backwards.core.syntax import snippet
    from py_backwards.core.tree import find
    from typed_ast import ast3 as ast
    parse_0_args = ('''
import math
print(math.exp(x))
''')
    parse_0_kwargs = {}
    parse_0_result = ast.parse(*parse_0_args, **parse_0_kwargs)
    tree_0_result = parse_0_result
    tree_0_result_get_body_args = (tree_0_result, )
    tree_0_result_get_body_kwargs = {'x': 'float_0'}

# Generated at 2022-06-25 23:20:04.890101
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def int_0():
        int_0 = 1
        let(int_0)
        int_1 = int_0
        int_0 = 2
        int_1 += int_0
        return int_1

    def int_1():
        int_0 = 1
        let(int_0)
        int_1 = int_0
        int_0 = 2
        int_1 += int_0
        return int_1

    int_0()
    int_1()

# Generated at 2022-06-25 23:20:07.698374
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    int_0 = snippet_0.get_body()
    assert(len(int_0) == 1)

# Generated at 2022-06-25 23:20:11.122317
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    with open("/Users/leo_lou/Documents/Code/Python/py-backwards/data/test_snippet_get_body", 'w') as f:
        f.write(str(snippet_0.get_body()))


# Generated at 2022-06-25 23:20:17.385408
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    print(snippet_0.get_body())



# Generated at 2022-06-25 23:20:18.902103
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    pass

test_case_0()

# Generated at 2022-06-25 23:20:43.160383
# Unit test for function find_variables
def test_find_variables():
    source = """
    import a
    import b, c
    let(x)
    extend(y)
    def let(x):
        extend(z)
    float_0 = -390.8
    let(float_0)
    float_1 = float_0
    let(float_1)"""

    tree = ast.parse(source)
    names = find_variables(tree)

    assert names == ['x', 'y', 'z', 'float_0', 'float_1']
    assert tree.body[0] == ast.parse('import a').body[0]
    assert tree.body[1] == ast.parse('import b, c').body[0]
    assert tree.body[2] == ast.parse('import b, c').body[0]

# Generated at 2022-06-25 23:20:47.919931
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    float_1 = snippet_0.get_body()
    float_2 = float_0
    assert float_2 == float_1


# Generated at 2022-06-25 23:20:51.370580
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)

    # Assert body of snippet is a list
    assert isinstance(snippet_0.get_body(), list)



# Generated at 2022-06-25 23:21:02.391014
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    float_1 = float_0
    float_2 = -float_1
    lng_0 = float_2
    float_3 = float_1
    float_4 = float_3
    lng_1 = float_4
    float_5 = -float_3
    lng_2 = float_5
    float_6 = -float_1
    lng_3 = float_6
    float_7 = abs(float_1)
    lng_4 = float_7
    float_8 = -float_0
    assert_true(math.isnan(float_8))
    float_9 = -float_0
    assert_true(math.isnan(float_9))
    float_10 = -float_

# Generated at 2022-06-25 23:21:06.807864
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    body_0 = snippet_0.get_body()
    for node_0 in body_0:
        assert isinstance(node_0, ast.Expr)
        assert isinstance(node_0.value, ast.Name)
        assert node_0.value.id == '_py_backwards_float_0'

# Generated at 2022-06-25 23:21:11.130145
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Get AST of snippet body with replaced variables."""
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    float_1 = float_0
    snippet_0.get_body(float_0=float_1)
    int_0 = -2
    str_0 = 'test_snippet_get_body'
    float_3 = float_0
    assert (float_3 == float_0)


# Generated at 2022-06-25 23:21:12.614916
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 23:21:17.175808
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    doubleArray_0 = [float_0]
    doubleArray_1 = doubleArray_0
    # Assert.assertArrayEquals(doubleArray_1, snippet_0.get_body())



# Generated at 2022-06-25 23:21:23.470223
# Unit test for function extend_tree
def test_extend_tree():
    def extend_tree(tree, variables):
        for node in find(tree, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == 'extend':
                parent, index = get_non_exp_parent_and_index(tree, node)
                replace_at(index, parent, variables[node.args[0].id]) # type: ignore
    # test_case_0
    float_0 = -390.8
    snippet_0 = snippet(float_0)


# Generated at 2022-06-25 23:21:32.247456
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Inputs
    snippet_kwargs = {'float_0': -390.8}

    # Expected result
    expected_result = [ast.Assign(targets=[ast.Name(id='float_0', ctx=ast.Store())],
                                  value=ast.Num(n=-390.8)),
                       ast.Expr(value=ast.Call(func=ast.Name(id='let', ctx=ast.Load()),
                                               args=[ast.Str(s='float_0')],
                                               keywords=[]))]

    # Getting code of snippet and getting the body
    result = snippet(test_case_0).get_body(**snippet_kwargs)

    # Comparing the result with our expected result
    assert (result == expected_result)



# Generated at 2022-06-25 23:22:08.863867
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def def_snippet_0_inner(a: Any, b: Any) -> None:
        let(a)
        let(b)
    def_snippet_0 = snippet(def_snippet_0_inner)
    a = -445.4
    b = -419.9
    expected_0 = [ast.Assign([ast.Name(id='_py_backwards_a_0')], ast.Num(n=-445.4)), ast.Assign([ast.Name(id='_py_backwards_b_0')], ast.Num(n=-419.9))]
    actual_0 = def_snippet_0.get_body(a=a, b=b)

# Generated at 2022-06-25 23:22:12.341230
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)

    # Test with no arguments
    assert snippet_0.get_body() == [ast.Expr(value=ast.UnaryOp(op=ast.USub(), operand=ast.Num(n=390.8)))]



# Generated at 2022-06-25 23:22:14.930305
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    assert snippet_0.get_body() == [ast.Assign([ast.Name('_py_backwards_float_0_0', ast.Store())], ast.Num(n=-390.8))]


# Generated at 2022-06-25 23:22:16.478443
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x)\n    print(x)')
    assert list(find_variables(tree)) == ['x']



# Generated at 2022-06-25 23:22:28.161643
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = None
    y = None
    z = None
    let(x)
    let(y)
    let(z)
    x += 1
    y = 1
    z *= 10

    def check_variable(var, name, value):
        assert isinstance(var, ast.Name)
        assert var.lineno == name.lineno
        assert var.col_offset == name.col_offset
        assert var.id == value  # type: ignore

    tree = ast.parse(get_source(test_case_0))

    variables = {'float_0': 'float_1'}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    variables = {'x': 'x_0', 'y': 'y_0', 'z': 'z_0'}

# Generated at 2022-06-25 23:22:33.290497
# Unit test for function extend_tree
def test_extend_tree():
    code = """
    if True:
        extend(vars)
    """
    tree = ast.parse(code)
    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num())]})
    assert tree.body[0].body[0].value.n == 0



# Generated at 2022-06-25 23:22:37.207984
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    assert snippet_0.get_body() == [ast.parse(
        '_py_backwards_float_0_0 = -390.8').body[0]]


# Generated at 2022-06-25 23:22:44.739257
# Unit test for function extend_tree
def test_extend_tree():
    str_0 = 'extend'
    float_0 = -440.7
    float_1 = -77.2
    float_2 = -223.3
    float_3 = -344.0
    float_4 = -44.7
    float_5 = -248.8
    float_6 = -236.6
    float_7 = -212.5
    float_8 = -293.0
    float_9 = -5.5
    float_10 = -241.6
    float_11 = -489.3
    float_12 = -308.9
    float_13 = -356.1
    float_14 = -424.4
    float_15 = -95.9
    float_16 = -82.0
    float_17 = -90.8
    float_18 = -379.2

# Generated at 2022-06-25 23:22:51.676776
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 1
    y = [1, 2]
    z = 'str'
    code = snippet(test_case_0).get_body(x=x, y=y, z=z)
    assert 'x = 1' in get_source(code)
    assert 'y = [1, 2]' in get_source(code)
    assert 'z = str' in get_source(code)

# Generated at 2022-06-25 23:23:01.765638
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    float_1 = float_0
    float_2 = -390.8
    float_3 = float_1
    float_2 = float_0
    float_0 = float_2
    float_0 = float_3
    float_2 = float_1
    float_1 = float_0
    float_0 = float_2
    float_2 = float_3
    float_3 = float_1
    float_0 = float_3
    float_0 = float_2
    float_1 = float_0
    float_2 = float_1
    float_0 = float_2
    float_0 = float_1
    float_2 = float_0
    float_0 = float_1

# Generated at 2022-06-25 23:24:06.289568
# Unit test for function extend_tree
def test_extend_tree():
    float_0 = -390.8
    float_1 = -505.0
    float_2 = -383.4
    float_3 = -841.7
    float_4 = -726.4
    float_5 = -999.0
    float_6 = -829.5
    float_7 = -726.4
    float_8 = -999.0
    float_9 = -829.5
    float_10 = -726.4
    float_11 = -999.0
    float_12 = -829.5
    float_13 = -726.4
    float_14 = -999.0
    float_15 = -829.5
    float_16 = -726.4
    float_17 = -999.0
    float_18 = -829.

# Generated at 2022-06-25 23:24:14.740568
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    short_float_0 = float_0
    short_complex_0 = -9.6j
    short_complex_1 = float_0
    str_0 = "H8W"
    str_1 = str_0
    str_2 = str_1
    float_1 = float_0
    snippet_0_in = {'var_0': float_0, 'short_float_0': short_float_0, 'short_complex_0': short_complex_0, 'short_complex_1': short_complex_1, 'str_0': str_0, 'str_1': str_1, 'str_2': str_2, 're_0': short_float_0, 'float_1': float_1}


# Generated at 2022-06-25 23:24:16.483981
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    float_0 = -390.8
    snippet_0 = snippet(float_0)
    variables_0 = snippet_0.get_body()


# Generated at 2022-06-25 23:24:23.332615
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def __main__(x: int) -> int:
        let(y)
        extend(z)
        y = x + 1
        return y

    x = 1
    y = 2
    z = [ast.AnnAssign(ast.Name('y', ast.Store()), ast.Num(2)),
         ast.AnnAssign(ast.Name('y', ast.Store()), ast.Num(3))]

    expected_0 = [
        ast.AnnAssign(ast.Name('_py_backwards_y_0', ast.Store()),
                      ast.BinOp(ast.Name('x', ast.Load()), ast.Add(), ast.Num(1))),
        ast.Return(_py_backwards_y_0)]
    
    snippet_0 = snippet(__main__)

# Generated at 2022-06-25 23:24:29.264421
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert [
        ast.Expr(
            value=ast.BinOp(
                left=ast.Name(
                    id='x',
                    ctx=ast.Load(),
                ),
                op=ast.Add(),
                right=ast.Num(
                    n=1,
                ),
            ),
        ),
        ast.Assign(
            targets=[
                ast.Name(
                    id='y',
                    ctx=ast.Store(),
                ),
            ],
            value=ast.Num(
                n=1,
            ),
        ),
    ] == snippet(lambda x: None).get_body(x=1)