

# Generated at 2022-06-25 23:14:43.048154
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    str_0 = 'jT~z\\TU[--N@'
    args = {'str_0': str_0} # tmp
    test_snippet_get_body_body = [ast.Assign([ast.Name(id='_py_backwards_str_0_0', ctx=ast.Store())], ast.Str(s=str_0)),]
    assert test_case_0.get_body(**args) == test_snippet_get_body_body


# Generated at 2022-06-25 23:14:49.941596
# Unit test for function extend_tree
def test_extend_tree():
    import io
    import sys

    my_source = """
    extend(vars)
    x = 5
    print(x)
    """

    original_stdout = sys.stdout
    try:
        vars = ast.parse('''
        x = 1
        x = 2
        ''')
        out = io.StringIO()
        sys.stdout = out
        tree = ast.parse(my_source)
        extend_tree(tree, {'vars': vars})
        exec(compile(tree, filename="<ast>", mode="exec"))
        output = out.getvalue().strip()
        assert output == '5'
    finally:
        sys.stdout = original_stdout



# Generated at 2022-06-25 23:14:54.630247
# Unit test for function find_variables
def test_find_variables():
    str_0 = 'XT<x.Ag'
    let(str_0)
    str_1 = '#yR(R1'
    extend(str_1)
    str_2 = '\n'
    # assert find_variables(ast.parse(get_source(test_case_0))) == ['str_2', 'str_1']

# Generated at 2022-06-25 23:14:56.757594
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert 'jT~z\\TU[--N@' == snippet(test_case_0).get_body()[0].value.s

# Generated at 2022-06-25 23:14:58.911384
# Unit test for function find_variables
def test_find_variables():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    assert 'str_0' in find_variables(tree)


# Generated at 2022-06-25 23:15:03.889856
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('print(1)')
    extend_tree(tree, {});
    assert ast.dump(tree) == 'Module(body=[Print(dest=None, values=[Num(n=1)], nl=True)])'
    extend_tree(tree, {'v': ast.parse('print(1)').body})
    assert ast.dump(tree) == 'Module(body=[Print(dest=None, values=[Num(n=1)], nl=True), Print(dest=None, values=[Num(n=1)], nl=True)])'


# Generated at 2022-06-25 23:15:10.869569
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    class alias:
        def __init__(self, name, asname = None):
            self.name = name
            self.asname = asname
    obj = alias("obj")
    var = VariablesReplacer({'obj': 'obj_0'})
    result = var.visit_alias(obj)
    assert result.name == 'obj'
    assert result.asname == 'obj_0'


# Generated at 2022-06-25 23:15:13.331243
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(ast.parse(get_source(test_case_0))) == ('str_0',)



# Generated at 2022-06-25 23:15:16.301477
# Unit test for function extend_tree
def test_extend_tree():
    def test_case_1():
        str_0 = 'pC\\`B|xO{#mn'
        let(str_0)
        int_0 = 2
        extend(int_0)

    test_case_1()

# Generated at 2022-06-25 23:15:25.372541
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    str_0 = 'o*:|0T*1)r>'
    str_1 = ')m]^X'
    test_case_0.__annotations__ = {'var': str}
    test_case_0.__annotations__ = {'str_0': str}
    tree = ast.parse('def test_case_0():\n    str_0 = \'jT~z\\\\TU[--N@\'\n    let(str_0)')
    snippet_kwargs = {'var': str('o*:|0T*1)r>'), 'str_0': str(')m]^X')}

# Generated at 2022-06-25 23:15:38.297491
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import inspect
    import ast
    import astor
    source_code_string = inspect.getsource(test_case_0)
    tree = ast.parse(source_code_string)
    test_case_0_snippet = snippet(test_case_0)
    new_tree = test_case_0_snippet.get_body()
    assert ast.dump(tree) == ast.dump(new_tree)
    assert astor.to_source(tree) == astor.to_source(new_tree)
    assert source_code_string == astor.to_source(new_tree)


# Generated at 2022-06-25 23:15:48.039380
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body() == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_str_0', ctx=ast.Store())],
            value=ast.Str('jT~z\\TU[--N@')
        )
    ]
    # Check if variable is written as variable
    assert snippet(test_case_0).get_body() == [ast.Expr(value=ast.Subscript(
        value=ast.Name(id='_py_backwards_str_0', ctx=ast.Load()),
        slice=ast.Index(value=ast.Num(n=0)),
        ctx=ast.Load()
    ))]


# Generated at 2022-06-25 23:16:02.195902
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import random
    import string

    def random_string(length):
        return ''.join(random.choice(string.ascii_letters) for _ in range(length))

    rand_str_0 = random_string(15)
    rand_str_1 = random_string(50)
    rand_str_2 = random_string(20)

    vars_0 = {
        'rand_str_1': [ast.alias(name=rand_str_1, asname=rand_str_0)],
        'rand_str_2': rand_str_2
    }
    inst_0 = VariablesReplacer(vars_0)
    inst_0.visit(ast.alias(name=rand_str_1, asname=rand_str_2))



# Generated at 2022-06-25 23:16:09.854509
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0():
        str_0 = 'jT~z\\TU[--N@'
        let(str_0)

    test_snippet_0 = snippet(test_case_0)
    assert test_snippet_0.get_body() == [ast.Assign([ast.Name(id='_py_backwards_str_0_0', ctx=ast.Store())], ast.Str('jT~z\\TU[--N@'))]



# Generated at 2022-06-25 23:16:13.811590
# Unit test for function find_variables
def test_find_variables():
    str_0 = 'jT~z\\TU[--N@'
    let(str_0)
    assert len(list(find_variables(ast.parse(inspect.getsource(test_case_0))))) == 1


# Generated at 2022-06-25 23:16:21.828697
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    # Create instance of class 'VariablesReplacer'
    VariablesReplacer_instance_0 = VariablesReplacer({})
    # Create an instance of 'alias'
    alias_instance_0 = ast.alias()
    # Create an instance of 'Name'
    Name_instance_0 = ast.Name()
    # Set 'Name_instance_0' as attribute 'asname' of 'alias_instance_0'
    setattr(alias_instance_0, 'asname', Name_instance_0)
    # Set 'alias_instance_0' as attribute 'alias' of 'ImportFrom'
    # Type warning
    # Warning: Unexpected type(s) - expected `str` but got `Name` instead
    setattr(ImportFrom_instance_0, 'alias', alias_instance_0)
    # Call method visit_alias of 'Vari

# Generated at 2022-06-25 23:16:30.374847
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from textwrap import dedent
    from ast import parse
    from unittest.case import TestCase

    def sample_function():
        let(str_0)

    source = dedent(get_source(sample_function))
    expected_source = dedent('''
    def sample_function():
        _py_backwards_str_0_0
    ''')
    tree = parse(source)
    expected_tree = parse(expected_source)
    snippet_obj = snippet(sample_function)
    TestCase().assertEqual(snippet_obj.get_body(), expected_tree.body[0].body)

# Generated at 2022-06-25 23:16:37.313080
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    _py_backwards_x_0 = 'jT~z\\TU[--N@'
    let(_py_backwards_x_0)
    str_0 = 'jT~z\\TU[--N@'
    let(str_0)
    str_1 = '-'
    let(str_1)
    str_2 = '-'
    let(str_2)



# Generated at 2022-06-25 23:16:46.253553
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0():
        str_0 = 'jT~z\\TU[--N@'
        let(str_0)
    tree = ast.parse(get_source(test_case_0))
    body = snippet(test_case_0).get_body()
    assert body == [
        ast.Assign(
            targets=[
                ast.Name(
                    id='_py_backwards_str_0_0',
                    ctx=ast.Store())],
            value=ast.Str(
                s='jT~z\\TU[--N@'))]


# Generated at 2022-06-25 23:16:49.034776
# Unit test for function find_variables
def test_find_variables():
    str_0 = 'jT~z\\TU[--N@'
    let(str_0)
    s, = find_variables(ast.parse('let(str_0)'))
    assert s == 'str_0'



# Generated at 2022-06-25 23:17:03.294231
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    str_0 = 'jT~z\\TU[--N@'

# Generated at 2022-06-25 23:17:11.279481
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from astunparse import unparse
    from .tree import fix_missing_locations
    
    tree = snippet(test_case_0).get_body()
    for node in tree:
        if isinstance(node, ast.Assign):
            assert node.value.s == 'jT~z\\TU[--N@'
        elif isinstance(node, ast.Print):
            print(unparse(fix_missing_locations(node)))
            assert node.values[0].s == 'jT~z\\TU[--N@'
        else:
            raise ValueError('Should be only Assign and Print nodes.')


if __name__ == '__main__':
    test_snippet_get_body()

# Generated at 2022-06-25 23:17:16.754929
# Unit test for function extend_tree
def test_extend_tree():
    str_1 = 'a'
    extend(str_1)
    str_2 = 'a'
    asd = ast.parse(str_2).body[0]
    assert asd == ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Str(s='a'))



# Generated at 2022-06-25 23:17:26.278985
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend([Assign(targets=[Name(id=str_0, ctx=Store())], '
                     'value=Call(func=Attribute(value=Name(id=str_0, ctx=Load()), '
                     'attr=join, ctx=Load()), args=[List(elts=[Str(s=_py_backwards_str_0_0)], ctx=Load())], '
                     'keywords=[], starargs=None, kwargs=None))])')
    extend_tree(tree, {'str_0': ast.Str(s='test')})
    assert(ast.dump(tree) == 'Assign(targets=[Name(id=str_0, ctx=Store())], '
                             'value=Str(s=test))')


# Unit test

# Generated at 2022-06-25 23:17:31.552804
# Unit test for function find_variables
def test_find_variables():
    str_0 = 'jT~z\\TU[--N@'
    fn = snippet(test_case_0)
    body = fn.get_body()
    assert len(body) == 1
    assert isinstance(body[0], ast.Assign)
    assert isinstance(body[0].value, ast.Str)
    assert isinstance(body[0].value.s, str)
    assert body[0].value.s == str_0

# Generated at 2022-06-25 23:17:35.443320
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert len(snippet(test_case_0).get_body().body) == 1
    assert snippet(test_case_0).get_body().body[0].id == 'str_0'


# Generated at 2022-06-25 23:17:44.221298
# Unit test for function extend_tree
def test_extend_tree():
    str_0 = 'jT~z\\TU[--N@'
    test_snippet = ast.parse("extend(a)\n")
    extend_tree(test_snippet, {'a': [ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())],
                                         value=ast.Str(s=str_0)),
                                    ast.Assign(targets=[ast.Name(id='c', ctx=ast.Store())],
                                         value=ast.Num(n=7))]})
    assert test_snippet.body[0].targets[0].id == 'b'

# Unit tests for function replace_field_or_node

# Generated at 2022-06-25 23:17:46.325266
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse(get_source(test_case_0)))) == ['str_0']


# Generated at 2022-06-25 23:17:48.692686
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(test_case_0.get_body()) == {'str_0': '_py_backwards_str_0_0'}


# Generated at 2022-06-25 23:17:50.406961
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse(get_source(test_case_0)))) == ['str_0']



# Generated at 2022-06-25 23:17:57.959908
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse(test_case_0.__name__))
               ) == ['str_0']


# Generated at 2022-06-25 23:18:07.344445
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_obj = snippet(test_case_0)
    ast_tree = snippet_obj.get_body()
    ast_tree_str = ast.dump(ast_tree)
    assert ast_tree_str == "Module(body=[FunctionDef(name='test_case_0', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Assign(targets=[Name(id='str_0', ctx=Store())], value=Str(s='jT~z\\\\TU[--N@'))], decorator_list=[], returns=None)])"


# Generated at 2022-06-25 23:18:10.172297
# Unit test for function find_variables
def test_find_variables():
    import astor
    source = get_source(test_case_0)
    tree = ast.parse(source)
    result = [x for x in find_variables(tree)]
    assert result == []


# Generated at 2022-06-25 23:18:12.428032
# Unit test for function extend_tree
def test_extend_tree():
    tmp_0 = []
    str_0 = 'jT~z\\TU[--N@'
    str_0


# Generated at 2022-06-25 23:18:22.121086
# Unit test for function find_variables
def test_find_variables():
    bytes_0 = bytearray(4)
    bytes_0[0] = (int(str_0[6]) >> 5)
    bytes_0[1] = ((int(str_0[11]) + 84) & ((int(str_0[3]) + (int(str_0[10]) << 4)) & 254))
    bytes_0[2] = ((int(str_0[1]) + (int(str_0[14]) >> 5)) & ((int(str_0[13]) - (int(str_0[10]) + 207)) & (int(str_0[5]) & int(str_0[6]))))

# Generated at 2022-06-25 23:18:32.142756
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet_get_body_0(code_0):
        snippet_get_body_var_0 = code_0
        tmp_0 = True
        tmp_1 = True
        if None is not snippet_get_body_var_0:
            tmp_1 = (snippet_get_body_var_0 is not False)
        if tmp_1:
            tmp_0 = ('' is not snippet_get_body_var_0)
        return tmp_0
    snippet_0 = snippet(test_case_0)
    snippet_0.get_body(str_0=str(0))
    snippet_0.get_body(str_0=str(10))
    snippet_0.get_body(str_0=str(None))

# Generated at 2022-06-25 23:18:40.737454
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = test_case_0.__wrapped__
    snippet_1 = snippet(snippet_0)
    map_0 = {}
    list_0 = snippet_1.get_body(**map_0)
    str_1 = 'else:'
    str_2 = '{'
    str_3 = 'continue'
    str_4 = ':'
    str_5 = '}'
    str_6 = 'if'
    str_7 = 'var_0'
    int_0 = 1
    str_8 = 'N[X$xN'
    str_9 = 'uVF#c'
    str_10 = '\\'
    str_11 = '~'
    str_12 = 'u'
    str_13 = '['
    str_14 = '['
    str

# Generated at 2022-06-25 23:18:50.502814
# Unit test for function find_variables
def test_find_variables():

    # test 1:
    str_0 = 'jT~z\\TU[--N@'

    # test 2:
    str_0 = 'jT~z\\TU[--N@'

    # test 3:
    str_0 = 'jT~z\\TU[--N@'

    # test 4:
    str_0 = 'jT~z\\TU[--N@'

    # test 5:
    str_0 = 'jT~z\\TU[--N@'

    # test 6:
    str_0 = 'jT~z\\TU[--N@'

    # test 7:
    str_0 = 'jT~z\\TU[--N@'

    # test 8:
    str_0 = 'jT~z\\TU[--N@'

# Generated at 2022-06-25 23:18:59.506850
# Unit test for method get_body of class snippet

# Generated at 2022-06-25 23:19:03.260395
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(ast.parse("""let(str_0)
str_0 = 'jT~z\\TU[--N@'
str_0 = str_0[:5]""")) == ['str_0']


# Generated at 2022-06-25 23:19:10.935358
# Unit test for function extend_tree
def test_extend_tree():
    str_0 = 'UX(\\X\\H+;AA'
    var_0 = str_0
    var_1 = 'E' + round(42)
    assert var_1 == var_0


# Generated at 2022-06-25 23:19:15.207200
# Unit test for function find_variables
def test_find_variables():
    str_0 = 'jT~z\\TU[--N@'
    _py_backwards_str_0 = 'tst_0'
    test_case_0()
    _py_backwards_str_0 = 'tst_1'
    test_case_0()

# Generated at 2022-06-25 23:19:23.260998
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(vars)')
    vars_ = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                        value=ast.Num(n=1)),
             ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                        value=ast.Num(n=2))]
    extend_tree(tree, {'vars': vars_})
    assert tree.body == vars_
    assert get_source(tree) == 'x = 1\nx = 2'



# Generated at 2022-06-25 23:19:26.314395
# Unit test for function extend_tree
def test_extend_tree():
    import sys
    import astor
    
    tree = ast.parse('extend(x)')
    extend_tree(tree, {'x': [ast.parse('a = 1').body[0], ast.parse('b = 2').body[0]]})
    assert astor.to_source(tree).strip() == 'a = 1\nb = 2'
    
    

# Generated at 2022-06-25 23:19:32.092327
# Unit test for function extend_tree
def test_extend_tree():
    str_0 = "str_0"
    str_1 = "str_1"
    str_2 = "str_2"
    str_3 = "str_3"
    str_4 = "str_4"
    str_5 = "str_5"
    str_6 = "str_6"
    pass_0 = ast.Pass()
    pass_1 = ast.Pass()
    pass_2 = ast.Pass()
    pass_3 = ast.Pass()
    pass_4 = ast.Pass()
    pass_5 = ast.Pass()
    pass_6 = ast.Pass()
    pass_7 = ast.Pass()
    pass_8 = ast.Pass()
    pass_9 = ast.Pass()
    pass_10 = ast.Pass()
    pass_11 = ast.Pass()
    pass

# Generated at 2022-06-25 23:19:40.383811
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    str_0 = 'jT~z\\TU[--N@'
    bytes_0 = b'jT~z\\TU[--N@'
    int_0 = -22
    tuple_0 = (int_0, bytes_0, int_0, int_0, str_0)
    slice_0 = slice(int_0, int_0, int_0)
    def test_case_0():
        test_case_0()
        str_1 = 'jT~z\\TU[--N@'
    assert test_snippet_get_body.get_body.__annotations__ == dict()


# Generated at 2022-06-25 23:19:49.272830
# Unit test for method get_body of class snippet

# Generated at 2022-06-25 23:19:51.578996
# Unit test for function find_variables
def test_find_variables():
    from typed_ast import ast3 as ast

    source = find_variables(ast.parse(test_case_0.__code__))
    assert source == ['str_0']


# Generated at 2022-06-25 23:19:54.429086
# Unit test for function extend_tree
def test_extend_tree():
    filename = 'extend_tree.py'
    with open(filename) as file:
        text_in = file.read()

    with open(filename) as file:
        text_expect = file.read()

    text_out, _ = equivalent(text_in, str_0)
    assert text_expect == text_out

# Generated at 2022-06-25 23:19:56.307086
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet.get_body(snippet_kwargs={'snippet_kwargs': {}}) == []


# Generated at 2022-06-25 23:20:07.486975
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body() == [
        ast.FunctionDef(
            name='test_case_0',
            args=ast.arguments(
                args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
            body=[
                ast.Assign(
                    targets=[ast.Name(
                        id='str_0', ctx=ast.Store())],
                    value=ast.Str(s='jT~z\\TU[--N@'))],
            decorator_list=[], returns=None)
    ]


# Generated at 2022-06-25 23:20:09.580406
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Test case for function get_body of class snippet."""

    snippet_a = snippet(test_case_0)
    body = snippet_a.get_body()

# Generated at 2022-06-25 23:20:15.720613
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Check that '*' and '**' are not allowed to be used as args
    # of method get_body of class snippet
    test_case_0()


# Generated at 2022-06-25 23:20:27.602480
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = 0
    y = 0
    let(x)
    x += 1
    y = 1
    @snippet
    def test_snippet_get_body_0(x: int, y: int) -> None:
        if x == 1:
            if y == 1:
                print('x = 1 and y = 1')
        else:
            print('x != 1')
    tree = test_snippet_get_body_0.get_body()
    assert len(tree) == 4
    assert isinstance(tree[0], ast.Assign)
    assert isinstance(tree[1], ast.Assign)
    assert isinstance(tree[2], ast.If)
    assert isinstance(tree[3], ast.If)
    x = 0
    y = 0
    let(x)


# Generated at 2022-06-25 23:20:33.167866
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    s = snippet(test_case_0)
    assert s.get_body(str_0) == [
        ast.Expr(
            ast.Name(
                id = 'str_0',
                ctx = ast.Store()
            )
        ),
    ]



# Generated at 2022-06-25 23:20:44.138066
# Unit test for function extend_tree
def test_extend_tree():
    def func():
        test_case_0()

    def set_up():
        pass

    def test_0():
        src = """
        def test_case_0():
            str_0 = 'jT~z\\\\TU[--N@'
        """
        expected = ast.parse(src)
        actual = extend_tree(ast.parse(src), {})
        assert ast.dump(expected) == ast.dump(actual)
        expected.body[0].body.append(ast.parse("str_0 = 'jT~z\\\\TU[--N@'").body[0])
        actual = extend_tree(ast.parse(src), {'str_0': ast.parse("str_0 = 'jT~z\\\\TU[--N@'").body[0]})

# Generated at 2022-06-25 23:20:54.933137
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    str_0 = 'jT~z\\TU[--N@'
    str_1 = 'Vx-L.=z)V^M(Nc'
    str_2 = 'OnuI7lH%E^wA1$'
    str_3 = 'I!mpl!mentation'
    str_4 = 'jT~z\\TU[--N@'
    str_5 = 'Vx-L.=z)V^M(Nc'
    str_6 = 'OnuI7lH%E^wA1$'
    str_7 = 'I!mpl!mentation'
    str_8 = 'I&8[9YqJ4o*{s~'
    str_9 = 'y|n_y`|m),Qm`C='
    str_10

# Generated at 2022-06-25 23:20:55.781518
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_case_0()

# Generated at 2022-06-25 23:20:57.876668
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_case_0()
    assert False


# Generated at 2022-06-25 23:21:06.418528
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_1(x: ast.Name):
        let(x)
        let(y)
        x = 1
        y = x
        return y
    assert(snippet(test_case_1).get_body(x=ast.Name(id='x', ctx=ast.Load())) == [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)), ast.Assign(targets=[ast.Name(id='_py_backwards_y_0', ctx=ast.Store())], value=ast.Name(id='x', ctx=ast.Load()))])


# Generated at 2022-06-25 23:21:10.570141
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    pass 


# Generated at 2022-06-25 23:21:11.056739
# Unit test for function extend_tree

# Generated at 2022-06-25 23:21:13.800375
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0():
        str_0 = 'jT~z\\TU[--N@'
    #snippet.get_body(test_case_0)


# Generated at 2022-06-25 23:21:16.747138
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    code_snippet_0 = snippet(test_case_0)
    code_snippet_0.get_body()


# Generated at 2022-06-25 23:21:21.932785
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()


# Generated at 2022-06-25 23:21:31.212972
# Unit test for function extend_tree
def test_extend_tree():
    class A:
        def method(this):
            ...
        def method_not_seen(this):
            ...

    class B(A):
        def method(this):
            ...
        def method_2(this):
            ...

    class C:
        def method(this):
            ...

    a = A()
    b = B()
    c = C()
    extend_tree(c, {'a': a, 'b': b})
    assert c == a
    assert c == b
    assert c != c

    class A:
        def method(this):
            ...
        def method_not_seen(this):
            ...

    class B(A):
        def method(this):
            ...
        def method_2(this):
            ...


# Generated at 2022-06-25 23:21:40.498619
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet_get_body___body_0(str_0):
        str_1 = '-{W8xF;KMXUl'
    def test_snippet_get_body___body_0(str_0):
        str_1 = 'z6Uj~Y!0Hm&_'
    def test_snippet_get_body___body_0(str_0):
        str_1 = 'H&%Kj$-TrX'
    def test_snippet_get_body___body_0(str_0):
        str_1 = ';pz}w0za:Z'
    def test_snippet_get_body___body_0(str_0):
        str_1 = 'TZ}t7|2k-%c3'

#

# Generated at 2022-06-25 23:21:42.424725
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert test_case_0()

# Generated at 2022-06-25 23:21:50.544714
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0(snippet_var_0, snippet_var_1, snippet_var_2):
        print(snippet_var_0)
        print(snippet_var_1)
    snippet_instance = snippet(test_case_0)

# Generated at 2022-06-25 23:21:51.687827
# Unit test for function extend_tree
def test_extend_tree():
    _str_0 = str_0
    extend_tree(str_0, _str_0)


# Generated at 2022-06-25 23:22:07.138990
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    var_snippet_0 = snippet(fn)
    var_list_0 = var_snippet_0.get_body(vars=())

# Generated at 2022-06-25 23:22:09.638602
# Unit test for function find_variables
def test_find_variables():
    assert find_variables.__name__ == 'find_variables'


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:22:20.012110
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0_snippet_0(a_s_t_0: int, a_s_t_1: str) -> None:
        let(a_s_t_0)
        let(a_s_t_1)
    a_s_t_0 = module_0.AST()
    snippet_0 = snippet(test_case_0_snippet_0)
    snippet_0.get_body(a_s_t_0=1, a_s_t_1='0')

# Generated at 2022-06-25 23:22:23.835406
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        x += 1
        y = 1
    s = snippet(f)
    body = s.get_body()
    assert '_py_backwards_x_0 += 1' in get_source(body)

# Generated at 2022-06-25 23:22:31.284630
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def _test_function(a: str, b: str, c: int) -> None:
        c = 1
        let(a)
        a += b

    a_s_t_0 = _test_function.get_body(a = '_py_backwards_a_0', b = '_py_backwards_b_0', c = 1)

if __name__ == '__main__':
    test_snippet_get_body()

# Generated at 2022-06-25 23:22:34.851846
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet_0():
        let(x)
        y = x
        x += 2
        extend(v)

    snippet_0 = snippet(test_snippet_0)
    d_i_c_t_0 = snippet_0.get_body()
    pass


# Generated at 2022-06-25 23:22:37.499815
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_snippet_get_body)
    result_0 = snippet_0.get_body()


# Generated at 2022-06-25 23:22:40.777393
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn_0():
        let(a)
        let(b)
        return a + b

    snippet_instance_0 = snippet(fn_0)

    code_gen_snippet_0 = snippet_instance_0.get_body()


# Generated at 2022-06-25 23:22:47.736517
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_1 = module_0.AST()
    d_i_c_t_0 = {'y': 1}
    class_0 = snippet(let)
    variable_0 = class_0.get_body(**d_i_c_t_0)


# Generated at 2022-06-25 23:22:51.914744
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_inner():
        let(a)
        a = 1
        print(a)

    test_instance = snippet(test_inner)

    def test_fixture(a):
        pass

    test_instance.get_body(a)

# Generated at 2022-06-25 23:23:06.025536
# Unit test for method get_body of class snippet

# Generated at 2022-06-25 23:23:13.471872
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast
    import inspect
    import cStringIO

    # create a snippet of code
    def snippet_source():
        let(dict(a=42, b=43))

    snippet_ast = ast.parse(inspect.getsource(snippet_source))
    snippet = snippet(snippet_source)
    new_body = snippet.get_body()

    assert new_body[0].body[0].value.value == 42
    assert new_body[0].body[1].value.value == 43

    # check that body was replaced correctly
    ast.fix_missing_locations(snippet_ast)
    out_stream = cStringIO.StringIO()
    ast.dump(snippet_ast, out_stream)
    new_out_stream = cStringIO.StringIO()
    ast.fix

# Generated at 2022-06-25 23:23:20.536400
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast
    import astor  # type: ignore
    import typing
    import types
    import copy
    import inspect

    def snippet_func(a: int, b: typing.AnyStr) -> None:
        let(a)
        let(b)
        _py_backwards_a_0 = 1
        _py_backwards_b_0 = 2

    def fix_tree(tree):
        for child in ast.iter_child_nodes(tree):
            tree = fix_tree(child)
        if isinstance(tree, ast.FunctionDef):
            func_type = types.FunctionType(tree.body, globals())
            func_type.__name__ = tree.name
            tree = ast.copy_location(func_type, tree)
        return tree


# Generated at 2022-06-25 23:23:28.623092
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = let(var_0)
    var_0 += 1
    var_1 = 1
    def test_0():
        pass
    a_s_t_0 = test_0.get_body(var_0=var_0, var_1=var_1)
    a_s_t_1 = test_0.get_body(var_0=var_0, var_1=var_1)
    a_s_t_2 = test_0.get_body(var_0=var_0, var_1=var_1)

if __name__ == "__main__":
    test_case_0()
    test_snippet_get_body()

# Generated at 2022-06-25 23:23:33.251254
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast
    source_0 = ast.parse("a")
    a_s_t_0 = source_0.body
    iterable_0 = a_s_t_0[0]
    # test with ast.Expr
    # - Expr(value=Name(id='x', ctx=Load()))
    # - expect Name(id='x', ctx=Load())
    ast_1 = iterable_0
    assert True

# Generated at 2022-06-25 23:23:35.257552
# Unit test for function find_variables
def test_find_variables():
    @snippet
    def fn():
        let(x)
        x += 1
        y = 1

    assert len(list(fn.get_body(x=2))) == 2



# Generated at 2022-06-25 23:23:43.142612
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    global names
    def snippet_0(n_a_m_e_0, *args, **kwargs):
        nonlocal names
        def function_0(n_a_m_e_1, *args, **kwargs):
            names = (n_a_m_e_0, n_a_m_e_1)
    snippet_0_instance = snippet(snippet_0)
    result_0 = snippet_0_instance.get_body(n_a_m_e_0=n_a_m_e_2)
    assert result_0 == []
    assert names == (n_a_m_e_2, n_a_m_e_3)


# Generated at 2022-06-25 23:23:50.515349
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from typed_ast import ast3 as ast

    class snippet_mock:
        # Mock method _get_variables
        def _get_variables(self, tree: ast.AST, snippet_kwargs: Dict[str, Variable]) -> Dict[str, Variable]:
            assert isinstance(tree, ast.AST)
            assert isinstance(snippet_kwargs, dict)
            names = find_variables(tree)
            variables = {name: VariablesGenerator.generate(name)
                         for name in names}

            for key, val in snippet_kwargs.items():
                if isinstance(val, ast.Name):
                    variables[key] = val.id
                else:
                    variables[key] = val  # type: ignore

            return variables  # type: ignore

        # Mock method get_source 


# Generated at 2022-06-25 23:23:59.663447
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    # test case for function find_variables
    # Type is: <class 'typed_ast.ast3.AST'>
    a_s_t_1 = module_0.AST()
    # Type is: <class 'typed_ast.ast3.AST'>
    a_s_t_2 = a_s_t_1
    a_s_t_3 = module_0.AST()
    # Type is: <class 'typed_ast.ast3.AST'>
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    # Type is: <class 'typed_ast.ast3.AST'>
    a_s_t_6 = module_0.AST()

# Generated at 2022-06-25 23:24:03.266167
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)


# Generated at 2022-06-25 23:24:25.628858
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_0(**kwargs):
        let(x)
        x += 1
        y = 1

    assert snippet_0().get_body() == [ast.AugAssign(target=variables_0, op=ast.Add, value=ast.Num(n=1)), ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())], value=ast.Num(n=1))]
