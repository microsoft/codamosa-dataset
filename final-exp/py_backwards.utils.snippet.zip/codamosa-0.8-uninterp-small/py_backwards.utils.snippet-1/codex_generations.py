

# Generated at 2022-06-25 23:14:33.253669
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    dict_0 = {}
    variables_replacer_0 = VariablesReplacer(dict_0)
    def f():
        let(x)
        x += 1
        y = 1
    snippet_0 = snippet(f)
    snippet_0.get_body()


# Generated at 2022-06-25 23:14:36.655953
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test 1
    class_0 = snippet(test_case_0)
    snippet_kwargs_0: Dict[str, Variable] = {}
    body_0 = class_0.get_body(**snippet_kwargs_0)
    print(body_0)



# Generated at 2022-06-25 23:14:41.470858
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    variables_replacer_0 = VariablesReplacer({});
    alias_0 = ast.alias();
    alias_0.name = '';
    alias_0.asname = '';
    ast.copy_location(alias_0, None);
    ast.fix_missing_locations(alias_0);
    variables_replacer_0.visit_alias(alias_0);


# Generated at 2022-06-25 23:14:42.517708
# Unit test for function find_variables

# Generated at 2022-06-25 23:14:46.528714
# Unit test for function extend_tree
def test_extend_tree():
    assert ast.dump(extend_tree(ast.parse('print(1)'),
                                {'x': ast.parse('x = 1'), 'y': ast.parse('y = 2')})) == \
        ast.dump(ast.parse('x = 1\nx = 2\nprint(1)'))


# Generated at 2022-06-25 23:14:53.026561
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func_0():
        let(x)
        x += 1
        y = 1
    snippet_0 = snippet(func_0)
    maybe_result_0 = snippet_0.get_body()
    assert isinstance(maybe_result_0, list)
    result_0 = maybe_result_0[0]
    assert isinstance(result_0, ast.AugAssign)
    result_1 = maybe_result_0[1]
    assert isinstance(result_1, ast.Assign)


# Generated at 2022-06-25 23:15:00.408307
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Step 1:
    @snippet  # type: ignore
    def snippet():
        let(x)
        x += 1
        y = 1

    expected = [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())]
                         + [ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()),
                                      ast.Add(), ast.Num(1))],
                          []),
                ast.Assign([ast.Name('y', ast.Store())],
                          [ast.Num(1)])]
    actual = snippet.get_body()

    assert actual == expected



# Generated at 2022-06-25 23:15:05.473671
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    dict_0 = {}
    str_0 = 'def a():\n    let(x)\n'
    ast_0 = ast.parse(str_0)
    variables_replacer_0 = VariablesReplacer(dict_0)
    ast_1 = ast_0
    ast.NodeTransformer.visit(variables_replacer_0, ast_1)

# Generated at 2022-06-25 23:15:08.810593
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    dict_0 = {}
    variables_replacer_0 = VariablesReplacer(dict_0)
    alias_0 = ast.alias()
    variables_replacer_0.visit(alias_0)



# Generated at 2022-06-25 23:15:09.669215
# Unit test for function find_variables

# Generated at 2022-06-25 23:15:25.012566
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(test_case_0) == []


# Generated at 2022-06-25 23:15:27.375177
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = snippet(test_case_0)
    var_0.get_body()

if __name__ == '__main__':
    test_snippet_get_body()

# Generated at 2022-06-25 23:15:28.200757
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert test_case_0() == {}

# Generated at 2022-06-25 23:15:29.604141
# Unit test for function find_variables
def test_find_variables():
    var_0 = find_variables(test_case_0)
    assert var_0 == []



# Generated at 2022-06-25 23:15:36.326546
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        extend(var_0)
        x = 1
        print(x)
    assert snippet(fn).get_body() == [
        ast.Assign(
            targets=[ast.Name(id="x", ctx=ast.Store())],
            value=ast.Num(n=1)),
        ast.Expr(value=ast.Call(
            func=ast.Name(id="print", ctx=ast.Load()),
            args=[ast.Name(id="x", ctx=ast.Load())], keywords=[]))]



# Generated at 2022-06-25 23:15:40.524573
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def x(a):
        let(var_0)
        var_0[4] = a
        print(var_0)
        print(b)
        t_1 = 1
        return t_1

    x.get_body(a=1, b=2)

# Generated at 2022-06-25 23:15:49.729165
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet_0(x, y=1, z=None):
        a = {x: y}
        b = [1, 2, 3]
        try:
            z += 1
        except TypeError:
            z = 1
        let(c)
        print(x)
        x += 1
        let(y)
        x += 1
        let(a)
        let(b)
        b.append(4)
        let(z)
        return a, b, c, x, y

    def test_snippet_1(x, y=1, z=None):
        c = 'some_string'
        d = ()
        let(c)
        let(d)
        extend(vars)
        return a, b, c, x, y


# Generated at 2022-06-25 23:15:55.402956
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)
    var_0 = {}
    var_1 = snippet_0.get_body(var_0)
    assert isinstance(var_1, list)


# Generated at 2022-06-25 23:16:05.351955
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # simple test
    __snippet0 = snippet(test_case_0)
    __body0 = __snippet0.get_body(var_0={})
    assert __body0 == [ast.Assign(targets = [ast.Name(id = '_py_backwards_var_0_0', ctx = ast.Store())], value = ast.Dict(keys = [], values = []))]
    # test with no variables
    __snippet1 = snippet(test_case_0)
    __body1 = __snippet1.get_body()

# Generated at 2022-06-25 23:16:08.301516
# Unit test for function find_variables
def test_find_variables():
    def test_0():
        var_0 = {}
        return var_0

    expected = {'var_0'}
    assert find_variables(test_0) == expected



# Generated at 2022-06-25 23:16:23.259443
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class snippet_0(snippet):

        def __init__(self):
            snippet.__init__(self, test_case_0)

    snippet_0().get_body()

# Generated at 2022-06-25 23:16:34.045422
# Unit test for function find_variables
def test_find_variables():
    def test_case_1():
        let(var_0)

        def func_0(arg_0):
            let(arg_0)

            arg_0 = func_1(arg_0)
            var_1 = func_2(arg_0)
            var_2 = func_0(0)

            return var_2

        def func_1(arg_0):
            return arg_0

        def func_2(arg_0):
            return arg_0

        var_0 = 0
    assert sorted(find_variables(ast.parse(get_source(test_case_1)))) == ['arg_0', 'var_0', 'var_1', 'var_2']

    assert sorted(find_variables(ast.parse(get_source(test_case_0)))) == []



# Generated at 2022-06-25 23:16:42.765527
# Unit test for function find_variables
def test_find_variables():
    expected = {'x': '_py_backwards_x_1', 'y': '_py_backwards_y_2'}
    assert find_variables(ast.parse('let(x); let(y);')) == expected
    assert find_variables(ast.parse('x, y = let(x), let(y);')) == expected



# Generated at 2022-06-25 23:16:43.934644
# Unit test for function find_variables
def test_find_variables():
    assert find_variables({}) == set()



# Generated at 2022-06-25 23:16:47.107200
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Tests that returned body of snippet is an AST tree."""
    assert isinstance(snippet(test_case_0).get_body(), list)


# Generated at 2022-06-25 23:16:55.939118
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from astunparse import unparse
    from .parser import parse

    @snippet
    def function_0():
        let(x)
        x += 1
        y = 1
        y += 2
        return x + y

    body = function_0.get_body()
    assert unparse(body[0]) == '_py_backwards_x_0 += 1'
    assert unparse(body[1]) == 'y = 1'
    assert unparse(body[2]) == 'y += 2'
    assert unparse(body[3]) == 'return _py_backwards_x_0 + y'

    @snippet
    def function_1():
        let(x)
        x += 1
        y = 1
        y += 2
        return x + y

    body = function_1.get_body

# Generated at 2022-06-25 23:16:57.468539
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(test_case_0) == {"var_0"}


# Generated at 2022-06-25 23:16:59.671506
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .test_helpers import assert_valid_ast

    assert_valid_ast(test_case_0.get_body())



# Generated at 2022-06-25 23:17:02.550148
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # tests 0 to 0
    var_0 = {}
    var_1 = snippet(test_case_0).get_body()
    var_2 = None
    assert var_1 == var_2


# Generated at 2022-06-25 23:17:03.412720
# Unit test for function extend_tree
def test_extend_tree():
    assert var_0 == {}


# Generated at 2022-06-25 23:17:16.715294
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _py_backwards_test_0(a, b):
        a = b + 1
        return a

    snippet_0 = snippet(_py_backwards_test_0)
    b = module_0.parse('b + 1')
    a_s_t_0 = snippet_0.get_body(a=b)


# Generated at 2022-06-25 23:17:19.069991
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)



# Generated at 2022-06-25 23:17:27.738530
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.Module()
    a_s_t_0.body = []
    a_s_t_0_0 = module_0.Num()
    a_s_t_0_0.n = 1
    a_s_t_0_1 = module_0.Name()
    a_s_t_0_1.id = 'a'
    a_s_t_0_2 = module_0.Assign()
    a_s_t_0_2.targets = [a_s_t_0_1]
    a_s_t_0_2.value = a_s_t_0_0
    a_s_t_0_3 = module_0.Num()
    a_s_t_0_3.n = 1


# Generated at 2022-06-25 23:17:37.857005
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = ast.Module()
    a_s_t_1 = ast.Assign()
    a_s_t_2 = ast.Name()
    a_s_t_2.id = 'x'
    a_s_t_1.targets = [a_s_t_2]
    a_s_t_3 = ast.Num()
    a_s_t_3.n = 1
    a_s_t_1.value = a_s_t_3
    a_s_t_0.body = [a_s_t_1]
    instance_0 = snippet(None)
    a_s_t_4 = ast.Assign()
    a_s_t_5 = ast.Name()

# Generated at 2022-06-25 23:17:38.849849
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # TODO implement test
    pass


# Generated at 2022-06-25 23:17:48.464873
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet((lambda _py_backwards_x: _py_backwards_x * _py_backwards_x))
    variable_0 = snippet_0.get_body()
    variable_0 = snippet_0.get_body(_py_backwards_x=module_0.Name(id="_py_backwards_x_0", ctx=module_0.Load()))
    variable_0 = snippet_0.get_body(_py_backwards_x=module_0.Name(id="_py_backwards_x_0", ctx=module_0.Load()))

# Generated at 2022-06-25 23:17:49.935770
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _fn():
        ...
    _snippet_0 = snippet(_fn)
    iterable_0 = _snippet_0.get_body()


# Generated at 2022-06-25 23:17:51.644454
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    let('a')
    let('b')
    let('c')

    @snippet
    def code():
        a ** 2
        b * c
        b / c

# Generated at 2022-06-25 23:18:04.136644
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _fn(x: Any, y: Any) -> None:
        let(x + y)
        x += 1
        y = 1
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    a_s_t_1 = module_0.AST()
    iterable_1 = find_variables(a_s_t_1)
    var_0: Any = iterable_0
    var_1: Any = iterable_1
    a_s_t_2 = module_0.AST()
    iterable_2 = find_variables(a_s_t_2)
    var_2: Any = iterable_2
    var_3: Any = iterable_1
    var_4: Any = iter

# Generated at 2022-06-25 23:18:13.402566
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_0():
        def f(a):
            let(b)
            return a + b

        snippet_0 = snippet(f)
        a_s_t_1 = snippet_0.get_body()

    def test_1():
        def f(a):
            extend(b)
            return a + b

        snippet_0 = snippet(f)
        a_s_t_1 = snippet_0.get_body()

    def test_2():
        def f(a):
            let(b)
            extend(c)
            return a + b

        snippet_0 = snippet(f)
        a_s_t_1 = snippet_0.get_body()


# Generated at 2022-06-25 23:18:27.627436
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def function_0(arg_0, kwarg_0=2, *args_0, **kwargs_0):
        pass
    
test_snippet_get_body()

# Generated at 2022-06-25 23:18:30.525930
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test_snippet_get_body_case_0():
        class _test_snippet_get_body_class_0():
            pass

        s_n_i_p_p_e_t_0 = snippet(_test_snippet_get_body_class_0)
        dict_0 = dict()
        l_i_s_t_0 = s_n_i_p_p_e_t_0.get_body(**dict_0)


# Generated at 2022-06-25 23:18:31.750028
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from typed_ast import ast3 as ast

# Generated at 2022-06-25 23:18:36.161477
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    a_s_t_1 = module_0.AST()
    extend_tree(a_s_t_1, iterable_0)


# Generated at 2022-06-25 23:18:47.333122
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0():
        def fn_0():
            let(x)
            x += 1
            y = 1
        
        snippet_0 = snippet(fn_0)
        result_0 = snippet_0.get_body()
        assert isinstance(result_0, list)
        result_0.__class__.__name__ == list.__name__
        assert len(result_0) == 2
        assert isinstance(result_0[0], module_0.AugAssign)
        result_0[0].__class__.__name__ == module_0.AugAssign.__name__
        assert isinstance(result_0[1], module_0.Assign)
        result_0[1].__class__.__name__ == module_0.Assign.__name__

# Generated at 2022-06-25 23:18:52.802163
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn_1():
        let(x)
        x += 1
        y = 1

    s_n_0 = snippet(fn_1)
    l_i_s_0 = s_n_0.get_body()

    assert l_i_s_0[0].value.id == '_py_backwards_x_0'
    assert l_i_s_0[1].value.n == 1


# Generated at 2022-06-25 23:19:02.326621
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    s_t_r_0 = 'x'
    let(s_t_r_0)
    d_i_c_t_0 = {s_t_r_0 : a_s_t_0}
    import typed_ast._ast3 as module_1
    a_s_t_3 = module_1.AST()
    a_s_t_4 = module_1.AST()
    a_s_t_5 = module_1.AST()
    a_s_t_5.id_0 = 'y'

# Generated at 2022-06-25 23:19:10.738602
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func_0(a_0: str, b_0: int, c_0: str) -> int:
        let(a_0)
        let(b_0)
        let(c_0)
        return c_0
    def func_1(a_1: str, b_1: int, c_1: str) -> int:
        let(a_1)
        let(b_1)
        let(c_1)
        return c_1
    def func_2(a_2: str, b_2: int, c_2: str) -> int:
        let(a_2)
        let(b_2)
        let(c_2)
        return c_2
    assert 1 < 2
    assert 1 > 2
    assert 2 > 1
    assert 1 < 2
   

# Generated at 2022-06-25 23:19:19.542968
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def variadic_with_non_tuple_arg_0(*args):
        let('a')
        let('b')
        extend('c')
    test_snippet_get_body_0 = snippet(variadic_with_non_tuple_arg_0)
    d_i_c_t_0 = {'a': 1, 'b': 2, 'c': 3}
    list_0 = test_snippet_get_body_0.get_body(**d_i_c_t_0)

if __name__ == '__main__':
    test_case_0()
    test_snippet_get_body()

# Generated at 2022-06-25 23:19:23.775420
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Allocation
    test_class = snippet(test_case_0)

    # Call
    ast_list_0 = test_class.get_body()

    # Release
    del test_class
    del ast_list_0

import typed_ast._ast3 as module_2


# Generated at 2022-06-25 23:19:54.834044
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet_get_body_0():
        a_s_t_0 = module_0.AST()
        iterable_0 = find_variables(a_s_t_0)
        a_s_t_1 = module_0.AST()
        iterable_1 = find_variables(a_s_t_1)
        a_s_t_2 = module_0.AST()
        iterable_2 = find_variables(a_s_t_2)
        a_s_t_3 = module_0.AST()
        iterable_3 = find_variables(a_s_t_3)
        a_s_t_4 = module_0.AST()
        iterable_4 = find_variables(a_s_t_4)

test_case

# Generated at 2022-06-25 23:19:58.046734
# Unit test for function extend_tree
def test_extend_tree():
    ast_0 = let(x)
    extend(vars)
    print(x, y)
    variables = {'x': x, 'y': y, 'vars': vars, 'print': print}
    extend_tree(ast_0, variables)


# Generated at 2022-06-25 23:20:03.874970
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = "let(x)\nx += 1\ny = 1\n"
    tree = ast.parse(source)
    snippet_kwargs = {}  # type: Dict[str, Variable]
    variables = {'x': VariablesGenerator.generate('x')}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-25 23:20:07.449620
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .tree import Module
    from .traverse import traverse
    from .transform import expr_to_stmts
    snippet_0 = snippet(test_snippet_get_body)
    arguments_0 = dict()
    snippet_0.get_body(**arguments_0)

# Generated at 2022-06-25 23:20:11.890382
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _c():
        snippets_0 = snippet(test_snippet_get_body)
        _py_backwards_snippet_kwargs_0_0 = dict()
        snippets_1 = snippets_0.get_body(**_py_backwards_snippet_kwargs_0_0)
        return
    _c()

if __name__ == '__main__':
    test_case_0()
    test_snippet_get_body()

# Generated at 2022-06-25 23:20:27.507058
# Unit test for function extend_tree
def test_extend_tree():
    x = VariablesGenerator.generate('x')
    assert eval(ast.dump(ast.parse('''
extend(vars)
print(x)
        ''').body[0].body[1])) == f'print({x})'

    vars = [ast.Assign(
        targets=[ast.Name('x', ast.Store())],
        value=ast.Num(1),
    )]
    assert eval(ast.dump(ast.parse('''
extend(vars)
print(x)
        ''').body[0].body[1])) == f'print(x)'

    vars = [ast.Assign(
        targets=[ast.Name('x', ast.Store())],
        value=ast.Num(1),
    )]

# Generated at 2022-06-25 23:20:40.532361
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def var(var_0: module_0.AST, var_1: module_0.AST, var_2: int) -> None:
        pass

    def var_3(var_4: module_0.AST) -> None:
        let(var_4)

    def var_5() -> module_0.AST:
        a_s_t_0 = module_0.AST()
        var_6 = var_3(a_s_t_0)
        return var_6

    def var_7() -> module_0.AST:
        a_s_t_0 = module_0.AST()
        var_7 = var_3(a_s_t_0)
        return var_7

    def var_8() -> module_0.AST:
        a_s_t_0 = module_0

# Generated at 2022-06-25 23:20:46.674711
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)


# Generated at 2022-06-25 23:20:49.224241
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    def _pass():
        pass

    _snippet_0 = snippet(_pass)
    iterable_0 = _snippet_0.get_body()


# Generated at 2022-06-25 23:20:59.592694
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from ..helpers import VariablesGenerator
    VariablesGenerator.reset()
    import copy
    import ast
    import astunparse

    def snip(a, b, s='ssss', **kwargs):
        let(a)
        let(b)
        let(s)
        let(c=42)
        let(d=None)
        let(e=lst)
        extend(lst)
        return a + b + s + kwargs['x']  # type: ignore
        # TODO: fix type: ignore

    a_s_t_0 = module_0.arg(arg=None, annotation=None)
    a_s_t_1 = module_0.arg(arg=None, annotation=None)

# Generated at 2022-06-25 23:22:20.461961
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x, y, z):
        let(x)
        let(y)
        let(z)
        x += y
        return y * z

    snippet_0 = snippet(fn)
    r = snippet_0.get_body(x=1, y=2, z=3)

    references = [
        ast.parse("_py_backwards_x_0 += _py_backwards_y_0"),
        ast.parse("return _py_backwards_y_0 * _py_backwards_z_0")
    ]

    assert [str(x) for x in r] == [str(x) for x in references]


# Generated at 2022-06-25 23:22:27.114702
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
    let(x)
    x += 1
    y = 1
    '''
    tree = ast.parse(source)
    extend_tree(tree, {'x': ['y = 1']})
    assert get_source(tree) == '''
    let(x)
    x += 1
    y = 1
    '''


# Generated at 2022-06-25 23:22:30.549547
# Unit test for function extend_tree
def test_extend_tree():
    # test_extend_tree_0
    a_s_t_0 = module_0.AST()
    iterable_0 = extend_tree(a_s_t_0, {})


# Generated at 2022-06-25 23:22:33.330097
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func():
        a = 1
        let(a)
        a = 2

    snippet_0 = snippet(func)
    list_0 = snippet_0.get_body()


# Generated at 2022-06-25 23:22:42.393175
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import unittest
    import ast
    import typed_ast.ast3 as ast3

    class TestSnippet(unittest.TestCase):
        def test_snippet_get_body(self):
            def fn(a, b, c):
                let(a)
                let(b)
                let(c)
                return a + b + c

            body = snippet(fn).get_body(
                a=1, b=2, c=3
            )
            print(ast.dump(body))
            # i = a + b + c
            # self.assertEqual(i, 6)
            # self.assertEqual(a.__class__, ast3.Name)
            # self.assertEqual(ast3.dump(a), "Name(id='a', ctx=Load())")



# Generated at 2022-06-25 23:22:45.872682
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Regression test for issue #24
    snippet_0 = snippet(None)
    iterable_0 = snippet_0.get_body()


# Generated at 2022-06-25 23:22:52.609668
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import typed_ast._ast3 as module_1
    a_s_t_0 = module_1.AST()
    s_n_i_p_p_e_t_0 = snippet(None)
    kwargs_0 = {"var": a_s_t_0}
    s_n_i_p_p_e_t_0.get_body(**kwargs_0)

# Unit tests for function find_variables

# Generated at 2022-06-25 23:22:57.738280
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = {'key_0': 'value_0'}
    extend_tree(a_s_t_0, d_i_c_t_0)

if __name__ == '__main__':
    test_case_0()
    test_extend_tree()

# Generated at 2022-06-25 23:23:03.277980
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class snippet_0(snippet):
        def _get_variables(self, tree: ast.AST, snippet_kwargs: Dict[str, Variable]) -> Dict[str, Variable]:
            return {'x': 'a', 'y': 2}
    snippet_1 = snippet_0(lambda x, y: x + y)
    str_0 = snippet_1.get_body()
    assert str_0 == 'a2'


# Generated at 2022-06-25 23:23:06.283030
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def a_function(x_0):
        let(a_0)
        let(b_0)
        a_0 += x_0
        b_0 = 1

    a_function('foo')
