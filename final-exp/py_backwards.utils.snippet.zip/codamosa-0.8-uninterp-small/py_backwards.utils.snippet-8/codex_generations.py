

# Generated at 2022-06-25 23:14:44.570575
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    str_0 = 'G`Y+F&LaA;Pr0aL#C3t'
    dict_0 = {str_0: str_0}
    variables_replacer_0 = VariablesReplacer(dict_0)
    import_from_0 = ast.ImportFrom(module=str_0, names=[ast.alias(name=str_0, asname=None)], level=0)
    actual_value_0 = variables_replacer_0.visit_ImportFrom(import_from_0)
    assert actual_value_0 == import_from_0


# Generated at 2022-06-25 23:14:48.353297
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn_0():
        x = let(1)
        x = let(1)
        x = extend(x)
    dict_0 = {'x': 1}
    snippet_0 = snippet(snippet_fn_0)
    list_0 = snippet_0.get_body(**dict_0)
    assert len(list_0) == 2


# Generated at 2022-06-25 23:14:50.854177
# Unit test for function find_variables
def test_find_variables():
    fn_0 = snippet
    snippet_0 = fn_0(test_case_0)
    body_0 = snippet_0.get_body()
    assert body_0


# Generated at 2022-06-25 23:14:54.202480
# Unit test for function extend_tree
def test_extend_tree():
    str_0 = 'v'
    str_1 = '.'
    dict_0 = {str_0: str_1}
    extend_tree(dict_0, dict_0)



# Generated at 2022-06-25 23:14:59.330134
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    str_0 = 'G`Y+F&LaA;Pr0aL#C3t'
    dict_0 = {str_0: str_0}
    variables_replacer_0 = VariablesReplacer(dict_0)
    ast_0 = ast.parse('import x')
    alias_0 = ast_0.body[0].names[0]
    variables_replacer_0.visit(alias_0)


# Generated at 2022-06-25 23:15:03.987028
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn_0():
        def snippet_fn_0_fn_0():
            let(snippet_fn_0_fn_0_vars_0)
        snippet_fn_0_fn_0()

    snippet_0 = snippet(snippet_fn_0)
    snippet_0_body_0 = snippet_0.get_body()


# Generated at 2022-06-25 23:15:15.294764
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _fn_0(param_0: int) -> int:
        int_0 = 0
        string_0 = 'lLT_T"Tk'
        int_1 = len(string_0)
        int_2 = int_0
        int_1 = int_1 + int_1
        int_2 = int_2 + int_1
        int_2 = int_2 + int_1
        int_2 = int_2 + int_1
        int_0 = int_0 + int_2
        int_0 = int_0 + int_2
        int_0 = int_0 + int_2
        tuple_0 = (param_0, string_0)
        return int_0

    snippet_0 = snippet(_fn_0)
    int_0 = 0

# Generated at 2022-06-25 23:15:20.145717
# Unit test for function find_variables
def test_find_variables():
    str_0 = 'i.I$&3A=yJ(W}_[Zh2'
    str_1 = ',1@JY#yw$#3qBd?p9P'
    dict_0 = {str_0: str_1}
    dict_1 = {str_0: str_0}
    snippet_0 = snippet(test_case_0)



# Generated at 2022-06-25 23:15:26.481439
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    str_0 = 'G`Y+F&LaA;Pr0aL#C3t'
    dict_0 = {str_0: str_0}
    variables_replacer_0 = VariablesReplacer(dict_0)
    string_0 = 'import sys'
    ast_0 = ast.parse(string_0)
    node_0 = ast_0.body[0]
    node_0 = variables_replacer_0.visit_ImportFrom(node_0)
    assert node_0.module == str_0, "AssertionError"


# Generated at 2022-06-25 23:15:32.195733
# Unit test for function find_variables
def test_find_variables():
    str_0 = 'Tj?M-sL&Jw'
    dict_0 = {str_0: str_0}
    variables_replacer_0 = VariablesReplacer(dict_0)
    str_1 = 'g`+f&LA;Pr0aL#c3t'
    tree_0 = ast.parse(str_1)
    int_0 = 0
    list_0 = find_variables(tree_0)
    assert(list_0[int_0] == 'g')


# Generated at 2022-06-25 23:15:47.495868
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""let(int_0)
int_0 += 1
extend(vars)
print(int_0)""")
    vars = [ast.Assign(targets=[ast.Name(id='int_0',
                       ctx=ast.Store())],
            value=ast.Num(n=2)),
            ast.Assign(targets=[ast.Name(id='int_0',
                       ctx=ast.Store())],
            value=ast.Num(n=1))]
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-25 23:15:49.495566
# Unit test for function find_variables
def test_find_variables():
    result = find_variables(ast.parse("let(int_0)\nassert(int_0 == 1)"))
    assert next(result) == 'int_0'

# Generated at 2022-06-25 23:16:01.690995
# Unit test for function extend_tree
def test_extend_tree():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    def replace_int_0(node):
        if isinstance(node, ast.Assign) and node.targets[0].id == 'int_0':
            return '_py_backwards_int_0_0 = 1'
        return None
    replace_map = {'int_0': replace_int_0}
    extend_tree(tree, replace_map)
    assert get_source(tree) == \
            'if 0 != _py_backwards_int_0_0:\n    _py_backwards_int_0_0 = 1\n'

# Generated at 2022-06-25 23:16:13.967690
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    def my_snippet_0(x):
        let(x)
        x += 1

    snip_0 = snippet(my_snippet_0)
    body_0 = snip_0.get_body(x=1)

    assert isinstance(body_0[0], ast.Assign)
    assert body_0[0].value.n == 1

    def my_snippet_1(x):
        let(x)
        x += 1
        y = x
        let(y)

    snip_1 = snippet(my_snippet_1)
    body_1 = snip_1.get_body(x=1)

    assert isinstance(body_1[0], ast.Assign)
    assert body_1[0].value.n == 1

# Generated at 2022-06-25 23:16:18.260419
# Unit test for function find_variables
def test_find_variables():
    source = get_source(test_case_0)
    tree = ast.parse(source)

    assert tree.body[0].name == 'int_0'
    assert tuple(find_variables(tree)) == ('int_0',)


# Generated at 2022-06-25 23:16:20.583037
# Unit test for function extend_tree
def test_extend_tree():
    int_0 = 0
    extend(int_0)
    int_1 = 1
    int_0 = int_0 + int_1

# Generated at 2022-06-25 23:16:22.810126
# Unit test for function extend_tree

# Generated at 2022-06-25 23:16:28.703025
# Unit test for function find_variables
def test_find_variables():
    find_variables_snippet = """
    def test_function(a, b, c):
        let(a)
        let(b)
        let(c)
        print(a, b, c)
    """
    
    tree = ast.parse(find_variables_snippet)
    variables = find_variables(tree)
    assert variables == ['a', 'b', 'c']
    
    

# Generated at 2022-06-25 23:16:32.369942
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body() == \
    [ast.Assign(
        [ast.Name('int_0', ast.Store())],
        ast.Num(0),
    )]


# Generated at 2022-06-25 23:16:37.440177
# Unit test for function extend_tree
def test_extend_tree():
    int_0 = 0
    int_1 = 1
    lst_0 = [0]
    extend(lst_0)
    assert int_0 == 0
    assert int_1 == 1
    assert lst_0 == [1]


# Generated at 2022-06-25 23:16:49.859746
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast
    import astor
    class Class:
        def __init__(self, int_0=0, int_1=1, int_2=2, int_3=3, int_4=4, int_5=5, int_6=6, int_7=7, int_8=8, int_9=9):
            self.int_0 = int_0
            self.int_1 = int_1
            self.int_2 = int_2
            self.int_3 = int_3
            self.int_4 = int_4
            self.int_5 = int_5
            self.int_6 = int_6
            self.int_7 = int_7
            self.int_8 = int_8
            self.int_9 = int_9
        

# Generated at 2022-06-25 23:16:52.401901
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body() == [ast.Assign([ast.Name('int_0', ast.Store())], ast.Num(0))]


# Generated at 2022-06-25 23:17:01.589904
# Unit test for function extend_tree
def test_extend_tree():

    # 1. If node is not call, it should be unchanged
    int_0 = 0
    extend_tree(int_0, {"int_0": int_0})
    assert not int_0

    # 2. If call node.func is not name, it should be unchanged
    int_1 = let(1)
    extend_tree(int_1, {"int_1": int_1})
    assert not int_1

    # 3. If call node.func is name, but not "extend", it should be unchanged
    int_2 = extend(2)
    extend_tree(int_2, {"int_2": int_2})
    assert not int_2

    # 4. If call node.func is name "extend", it should be replaced
    int_3 = extend(3)

# Generated at 2022-06-25 23:17:05.462172
# Unit test for method get_body of class snippet

# Generated at 2022-06-25 23:17:09.850952
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn():
        let(int_0)
        int_0 += 1
        extend(vars)
        print(int_0)
    

# Generated at 2022-06-25 23:17:16.516654
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    #Input Parameters:
    import_from_value = ast.ImportFrom(module='test',
                                            names=[],
                                            level=0)
    variables = dict()

    #Expected Output
    expected_output = ast.ImportFrom(module='test',
                                            names=[],
                                            level=0)
    #Output
    output = VariablesReplacer.replace(import_from_value, variables)

    assert(expected_output == output)


# Generated at 2022-06-25 23:17:26.096261
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    _int_0 = 13
    _str_0 = "eN"
    _str_1 = "t8"
    _str_2 = "zM"
    _str_3 = "Iw"
    _str_4 = "=="
    _str_5 = "c3"
    _str_6 = "B5"
    _str_7 = "b3"
    _str_8 = "c9"
    _str_9 = "wI"
    _str_10 = "xM"
    _str_11 = "zM"
    _str_12 = "Iw"
    _str_13 = "F8"
    _str_14 = "NQ"
    _str_15 = "=="
    _str_16 = "c3"

# Generated at 2022-06-25 23:17:30.034000
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    filter = ast.parse('from datetime import datetime')
    visitor = VariablesReplacer({'_py_backwards_int_0': 'int_0'})
    new_filter = visitor.visit(filter)
    assert new_filter == ast.parse('from datetime import datetime')


# Generated at 2022-06-25 23:17:39.558666
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""
    extend(vars)
    x = 1
    y = 2
    """)
    variables = {
        'vars':
            [
                ast.Assign(
                    targets=[ast.Name(id='x', ctx=ast.Store())],
                    value=ast.Num(n=1)
                ),
                ast.Assign(
                    targets=[ast.Name(id='y', ctx=ast.Store())],
                    value=ast.Num(n=2)
                )
            ]
    }
    extend_tree(tree, variables)
    import astor
    assert astor.to_source(tree) == """
    x = 1
    y = 2
    """

# Generated at 2022-06-25 23:17:49.060497
# Unit test for function extend_tree
def test_extend_tree():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    var = {'vars': ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                            args=[ast.Str(s='hello world')],
                            keywords=[],
                            starargs=None, kwargs=None)}
    extend_tree(tree, var)
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert isinstance(tree.body[0].body[0], ast.Expr)
    assert isinstance(tree.body[0].body[0].value, ast.Call)
    assert isinstance(tree.body[0].body[0].value.func, ast.Name)
    assert tree

# Generated at 2022-06-25 23:17:56.881795
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    dic_0 = {'k_0': a_s_t_1}
    extend_tree(a_s_t_0, dic_0)


# Generated at 2022-06-25 23:18:07.658777
# Unit test for function extend_tree
def test_extend_tree():
    import ast
    import typed_ast
    import textwrap
    import sys
    import io

    if sys.version_info[:2] <= (3, 7):
        import unittest.mock as mock
    else:
        import unittest.mock as mock

    from .tree import extend_tree

    tree = typed_ast.ast3.parse(textwrap.dedent('''
        def foo():
            extend(assignments)
    '''))

    assignments_tree = typed_ast.ast3.Assign(
        targets=[typed_ast.ast3.Name(id='x', ctx=typed_ast.ast3.Store())],
        value=typed_ast.ast3.Num(n=42))

    extend_tree(tree, {'assignments': assignments_tree})


# Generated at 2022-06-25 23:18:19.118456
# Unit test for function extend_tree
def test_extend_tree():
    import typed_ast._ast3 as module_2
    def testable_extend_tree(tree: ast.AST, variables: Dict[str, Variable]) -> None:
        for node in find(tree, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == 'extend':
                parent, index = get_non_exp_parent_and_index(tree, node)
                replace_at(index, parent, variables[node.args[0].id])  # type: ignore

    a_s_t_1 = module_2.AST()
    a_s_t_2 = module_2.AST()
    d_i_c_t_0 = {'k_0': a_s_t_2}

# Generated at 2022-06-25 23:18:24.799919
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    assert len(iterable_0) == 0

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 23:18:30.008307
# Unit test for function find_variables
def test_find_variables():
    print('Testing find_variables')

    # Run test with functions in test cases
    for i in range(4):
        test_case_i = globals()['test_case_' + str(i)]
        try:
            test_case_i()
        except Exception as e:
            print('error in test case {}: {}'.format(i, e))
            return 1

    print('OK')
    return 0



# Generated at 2022-06-25 23:18:32.780205
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    variables_0 = {'x': 'y'}
    extend_tree(a_s_t_0, variables_0)

# Generated at 2022-06-25 23:18:36.646786
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    assert iterable_0 == None

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:18:40.701190
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_snippet_get_body)
    a_s_t_0 = snippet_0.get_body(x=0, y=0)


# Generated at 2022-06-25 23:18:42.706783
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)


# Generated at 2022-06-25 23:18:52.675760
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    snippet_kwargs_0 = {'x': a_s_t_0}
    snippet_kwargs_1 = {'y': a_s_t_1}
    string_0 = 'def f():\n    let(x)\n    x += 1\n    y = 1'
    variables_0 = {'x': '_py_backwards_x_0', 'y': a_s_t_1}
    variables_1 = {'y': '_py_backwards_y_0', 'x': a_s_t_0}

# Generated at 2022-06-25 23:19:02.039713
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Create two instances of the snippet class
    a_s_t_0 = snippet(test_snippet_get_body)
    a_s_t_1 = snippet(test_snippet_get_body)

    # Test that calling get_body on both instances results in two different objects
    assert a_s_t_0.get_body(testing_0=1) is not a_s_t_1.get_body(testing_0=2)


# Generated at 2022-06-25 23:19:04.851773
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_2 = module_0.AST()
    d_i_c_t_1 = { }
    extend_tree(a_s_t_2, d_i_c_t_1)


# Generated at 2022-06-25 23:19:09.777513
# Unit test for function extend_tree

# Generated at 2022-06-25 23:19:17.596922
# Unit test for function extend_tree
def test_extend_tree():
    # Main body
    # Module body
    a_s_t_0 = module_0.AST()
    iterable_1 = find_variables(a_s_t_0)
    iterable_num_1 = len(iterable_1)
    iterable_num_2 = 0
    while iterable_num_2 < iterable_num_1:
        variable_1 = iterable_1[iterable_num_2]
        variable_1 += 1
        iterable_num_2 += 1
    assert True

if __name__ == '__main__':
    test_case_0()
    test_extend_tree()

# Generated at 2022-06-25 23:19:21.563627
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    v_a_r_s_0 = {}
    extend_tree(a_s_t_0, v_a_r_s_0)

# Generated at 2022-06-25 23:19:22.464529
# Unit test for function find_variables
def test_find_variables():
    test_case_0()

# Generated at 2022-06-25 23:19:26.796670
# Unit test for function extend_tree
def test_extend_tree():
    import unittest
    import inspect
    import ast
    import typed_ast._ast3 as module_0

    class test_extend_tree_case_0(unittest.TestCase):
        def test(self):
            a_s_t_0 = module_0.AST()
            variables_0 = dict()
            extend_tree(a_s_t_0, variables_0)
    suite = unittest.TestSuite()
    suite.addTest(test_extend_tree_case_0("test"))
    runner = unittest.TextTestRunner()
    runner.run(suite)

# Generated at 2022-06-25 23:19:27.665854
# Unit test for function extend_tree
def test_extend_tree():
    # TODO add unit tests
    pass



# Generated at 2022-06-25 23:19:37.724166
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    module_0 = ast.Module()
    a_s_t_0 = module_0.body
    decl_0 = ast.Expr()
    decl_0.value = ast.Call()
    decl_0.value.func = ast.Name()
    decl_0.value.func.id = 'let'
    decl_0.value.args = [ast.Str()]
    decl_0.value.keywords = []
    decl_0.value.starargs = None
    decl_0.value.kwargs = None
    a_s_t_0.append(decl_0)
    decl_1 = ast.FunctionDef()
    decl_1.name = 'test_snippet_get_body'
    decl_1.args = ast.arguments()
    decl_1.args.args = []


# Generated at 2022-06-25 23:19:42.910839
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _py_backwards_func_0(**_py_backwards_kwargs_0):
        let(_py_backwards_x_0)
        _py_backwards_x_0 += 1
        y = 1

    _py_backwards_obj_0 = snippet(_py_backwards_func_0)
    _py_backwards_body_0 = _py_backwards_obj_0.get_body()


# Generated at 2022-06-25 23:19:47.968192
# Unit test for function extend_tree
def test_extend_tree():
    var_0 = ast.AST()
    var_1 = {}
    extend_tree(var_0, var_1)


# Generated at 2022-06-25 23:19:54.800327
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Function with different code style
    def f():
        let(a)
        de = [1]
        a.append(de)
        exten = extend(de)

    s = snippet(f)
    body = s.get_body()

    for idx, node in enumerate(body):
        if isinstance(node, ast.Assign):
            assert node.targets[0].id == '_py_backwards_a_0'
        elif isinstance(node, ast.Expr):
            assert isinstance(node.value, ast.List)
            assert node.value.elts[0].n == 1
        else:
            raise AssertionError(node)

        assert not isinstance(node, ast.Call)
        assert not isinstance(node, ast.Str)


# Generated at 2022-06-25 23:19:55.979517
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_snippet_get_body_0()


# Generated at 2022-06-25 23:19:59.840296
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = None
    extend_tree(a_s_t_0, d_i_c_t_0)


# Generated at 2022-06-25 23:20:09.314946
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def method(var_0_x: int, var_1_y: int, var_2_z: int = 3) -> int:
        let(var_0_x)
        let(var_2_z)
        var_3_a = var_0_x + var_1_y
        var_4_b = var_1_y + var_2_z
        return var_3_a + var_4_b
    var_5_x = 2
    var_6_y = 3
    var_7_obj = snippet(method)
    var_8_result = var_7_obj.get_body(var_0_x=var_5_x, var_1_y=var_6_y)

# Generated at 2022-06-25 23:20:13.169741
# Unit test for function extend_tree
def test_extend_tree():
    def test_case_0():
        pass

    def test_case_1():
        pass

    def test_case_2():
        pass

    def test_case_3():
        pass



# Generated at 2022-06-25 23:20:21.426702
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _get_snippet():
        let(x)
        print(x)
    snippet_0 = snippet(_get_snippet)
    a_s_t_2 = snippet_0.get_body()

# End tests for snippet class


# Generated at 2022-06-25 23:20:24.543814
# Unit test for function find_variables
def test_find_variables():
    # TODO: tests
    pass


import typed_ast.ast3 as module_1

a_s_t_1 = module_1.AST()


# Generated at 2022-06-25 23:20:29.550329
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class __let_0:
        def __init__(self, x):
            self.x = x

    def __extend_0(vars):
        vars = vars
    def _snippet():
        let(x)
        x += 1
        y = 1

    anon_type_0 = type(_snippet)
    anon_snippet_type_0 = snippet(anon_type_0)
    anon_snippet_type_0.get_body(**{'x': __let_0(1)})

# Generated at 2022-06-25 23:20:33.564165
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    d_i_c_0 = {}
    extend_tree(a_s_t_0, d_i_c_0)


# Generated at 2022-06-25 23:20:44.070026
# Unit test for function extend_tree
def test_extend_tree():

    # Nested function definition
    def extend_tree(tree: ast.AST, variables: Dict[str, Variable]) -> None:
        for node in find(tree, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == 'extend':
                parent, index = get_non_exp_parent_and_index(tree, node)
                replace_at(index, parent, variables[node.args[0].id])  # type: ignore

    # Function call
    extend_tree()



# Generated at 2022-06-25 23:20:46.139250
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_1 = module_0.AST()
    d_i_c_t_0 = { }
    extend_tree(a_s_t_1, d_i_c_t_0)


# Generated at 2022-06-25 23:20:48.798395
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    dict_0 = dict()
    extend_tree(a_s_t_0, dict_0)


# Generated at 2022-06-25 23:20:59.173524
# Unit test for function extend_tree
def test_extend_tree():
    # Test 1:
    a_s_t_0 = ast.parse('''
        import ast

        extend(__builtins__)
    ''')
    extend_tree(a_s_t_0, {})
    extend_tree(a_s_t_0, {})
    a_s_t_0 = ast.parse('''
        import ast

        extend(__builtins__)
    ''')
    extend_tree(a_s_t_0, {})
    extend_tree(a_s_t_0, {})
    # Test 2:
    a_s_t_0 = ast.parse('''
        import ast

        extend({'boolean': 123})
    ''')
    extend_tree(a_s_t_0, {})
    extend_tree

# Generated at 2022-06-25 23:21:01.224887
# Unit test for function extend_tree
def test_extend_tree():
    try:
        extend_tree(arg_0, arg_1)
    except ValueError as e_0:
        pass


# Generated at 2022-06-25 23:21:04.612123
# Unit test for function extend_tree
def test_extend_tree():
    with pytest.raises(TypeError):
        # Type error test
        assert extend_tree('ast', 'variables')

    # Normal test
    assert extend_tree(module_0.AST(), dict())

# Generated at 2022-06-25 23:21:11.465442
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    i_t_e_r_a_b_l_e_0 = find_variables(a_s_t_0)
    v_a_r_i_a_b_l_e_0 = {i_t_e_r_a_b_l_e_0: VariablesGenerator.generate(i_t_e_r_a_b_l_e_0)}
    s_t_r_0 = get_source(snippet._fn)
    a_s_t_1 = ast.parse(s_t_r_0)

# Generated at 2022-06-25 23:21:15.020912
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test():
        let(x)
        x += 1
        y = 1
    _py_backwards_x_0 = None
    y = 1
    return


# Generated at 2022-06-25 23:21:20.365192
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Create a stub for the class snippet
    stub_0 = snippet(test_snippet_get_body)

    # Create a stub for the method let
    def stub_1():
        pass
    stub_0._fn = stub_1

    # Call method get_body of class snippet
    stub_2 = {}
    stub_0.get_body(**stub_2)


# Generated at 2022-06-25 23:21:29.778584
# Unit test for function extend_tree
def test_extend_tree():
    vars_s_t_1 = module_0.Name('vars', (1, 0))
    module_0.Alias('a', None, (1, 0))
    a_s_t_1 = module_0.Name('a', (1, 5))
    a_s_t_2 = module_0.Store()
    a_s_t_3 = module_0.Num(1)
    a_s_t_4 = module_0.Assign([a_s_t_1], a_s_t_3, a_s_t_2, (1, 0))
    a_s_t_5 = module_0.Name('a', (1, 0))
    a_s_t_6 = module_0.Store()

# Generated at 2022-06-25 23:21:40.425917
# Unit test for function extend_tree
def test_extend_tree():
    import random
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    dict_0 = { }
    extend_tree(a_s_t_0, dict_0)
    a_s_t_1 = module_0.AST()
    dict_1 = { }
    extend_tree(a_s_t_1, dict_1)
    a_s_t_2 = module_0.AST()
    dict_2 = { }
    extend_tree(a_s_t_2, dict_2)


# Generated at 2022-06-25 23:21:43.810431
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    variables_0 = {}
    extend_tree(a_s_t_0, variables_0)


# Generated at 2022-06-25 23:21:47.369489
# Unit test for function extend_tree
def test_extend_tree():
    # Make sure that extend_tree works as expected
    # 0. Prepare test data
    a_s_t_0 = module_0.AST()
    
    # 1. Call function
    extend_tree(a_s_t_0, {})
    # 2. Assert results
    assert True

# Generated at 2022-06-25 23:21:53.525010
# Unit test for function extend_tree
def test_extend_tree():
  # Case: when tree argument is a Call object with function attribute set to Name object with value of 'extend'
  def case_0():
    a_s_t_0 = module_0.Call()
    a_s_t_1 = module_0.Name()
    a_s_t_1.id = "extend"
    a_s_t_0.func = a_s_t_1
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.Str()
    a_s_t_3.s = "x"
    a_s_t_2.body = [a_s_t_3]
    variables_0 = {'x': a_s_t_2}

# Generated at 2022-06-25 23:21:58.750069
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    snippet_kwargs = {}
    s_n_i_p_p_e_t_0 = snippet(test_snippet_get_body)
    assert s_n_i_p_p_e_t_0.get_body(**snippet_kwargs) == [], 'AssertionError'

# Generated at 2022-06-25 23:22:08.108277
# Unit test for function extend_tree
def test_extend_tree():
    # We are testing two cases: add and replace.
    a_s_t_0 = module_0.AST()
    a_s_t_2 = module_0.AST()

    ast.fix_missing_locations(a_s_t_2)

    # first case
    a_s_t_0.body = [a_s_t_2]

    variables_0 = {}

    extend_tree(a_s_t_0, variables_0)

    # second case

    a_s_t_2.body = []

    a_s_t_0.body = [a_s_t_2]

    variables_0 = {}

    extend_tree(a_s_t_0, variables_0)


# Generated at 2022-06-25 23:22:10.211685
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    dict_0 = dict()
    extend_tree(a_s_t_0, dict_0)

# Generated at 2022-06-25 23:22:18.506761
# Unit test for function extend_tree
def test_extend_tree():
    test_value = ast.parse("x = 1")
    test_variables = {'y': test_value}
    extend_tree(test_value, test_variables)
    assert test_value.body[0].value == test_variables['y']


# Generated at 2022-06-25 23:22:29.500877
# Unit test for function extend_tree
def test_extend_tree():
    code = """
    extend(vars)
    print(x, y)
    """
    
    a_s_t_0 = ast.parse(code)
    variables_0 = {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)), ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))]}
    extend_tree(a_s_t_0, variables_0)
    
    # Compare to AST generated with astor
    a_s_t_1 = ast.parse(code)

# Generated at 2022-06-25 23:22:39.697068
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.FunctionDef()
    a_s_t_2 = module_0.Name()
    a_s_t_3 = module_0.Name()
    a_s_t_2.id = 'let'
    a_s_t_3.id = 'y'
    a_s_t_0.body = [a_s_t_1]
    a_s_t_1.args = a_s_t_2
    a_s_t_1._fields = ['args']
    a_s_t_2._fields = ['id']
    a_s_t_3._fields = ['id']

# Generated at 2022-06-25 23:22:47.796620
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_2 = module_0.AST()
    d_i_c_t_0 = {  }
    extend_tree(a_s_t_2, d_i_c_t_0)


# Generated at 2022-06-25 23:22:51.308874
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    list_0 = list()
    extend_tree(a_s_t_0, list_0)


# Generated at 2022-06-25 23:23:01.353366
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func(x: int, y: int, z: int) -> int:
        let(x)
        return x + y
    
    snippet_0 = snippet(func)
    list_1 = snippet_0.get_body(x=1)
    list_2 = snippet_0.get_body(x=1, y=1)
    list_3 = snippet_0.get_body(x=1, y=1, z=1)
    list_4 = snippet_0.get_body()
    list_5 = snippet_0.get_body(x=1, y=1, z=1)

# Generated at 2022-06-25 23:23:04.768005
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn_0():
        a_s_t_0 = module_0.AST()
        iterable_0 = find_variables(a_s_t_0)
        return iterable_0
    a_s_t_1 = module_0.AST()
    snippet_0 = snippet(fn_0)
    iterable_1 = snippet_0.get_body()


# Generated at 2022-06-25 23:23:08.393138
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    d_i_c_t_0 = {'x': a_s_t_1}
    extend_tree(a_s_t_0, d_i_c_t_0)


# Generated at 2022-06-25 23:23:15.665759
# Unit test for function extend_tree
def test_extend_tree():
    from .test.test_helpers import new_module
    tree = new_module("""
        def foo():
            extend(x)
            print(x, y)
            
        def bar():
            let(x)
    """)

# Generated at 2022-06-25 23:23:17.547003
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    dict_0 = {"a": 1}
    extend_tree(a_s_t_0, dict_0)

# Generated at 2022-06-25 23:23:24.960964
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn_0(k_0: str) -> None:
        def fn_1() -> None:
            let('x')
    snippet_0 = snippet(fn_0)
    extend_0 = extend('x')
    a_s_t_0 = module_0.AST()
    extend_1 = extend('x')
    a_s_t_1 = module_0.AST()
    extend_2 = extend('x')
    a_s_t_2 = module_0.AST()
    extend_3 = extend('x')
    assert type(snippet_0.get_body(x=a_s_t_0)) == type(extend_0)
    assert type(snippet_0.get_body(x=a_s_t_1)) == type(extend_1)
   

# Generated at 2022-06-25 23:23:28.134005
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class_0 = snippet(test_snippet_get_body)
    result_0 = class_0.get_body()

test_snippet_get_body()

# Generated at 2022-06-25 23:23:31.160929
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        x += 1
        y = 1
    snippet_obj_0 = snippet(f)
    var_0 = {}
    ret_0 = snippet_obj_0.get_body(**var_0)

# Generated at 2022-06-25 23:23:43.857293
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()

    class snippet_0(snippet):

        def get_body(self, **kwargs_0):
            a_s_t_0 = module_0.AST()

            def f():
                let(0)
            f()
            return a_s_t_0.body

    snippet_0(f).get_body(a='b')

# Generated at 2022-06-25 23:23:46.024811
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    a_d_i_c_t_0 = {}
    extend_tree(a_s_t_0, a_d_i_c_t_0)


# Generated at 2022-06-25 23:23:49.031535
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from collections import namedtuple
    obj = snippet(test_snippet_get_body)
    args = namedtuple('args', 'arg')
    args.arg = 1
    obj.get_body()

    # Add tests for other methods of class snippet


# Generated at 2022-06-25 23:23:52.271076
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = { }
    extend_tree(a_s_t_0, d_i_c_t_0)


# Generated at 2022-06-25 23:23:55.532912
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def function_0(a: Any) -> None:
        print(a)
    
    snippet_0 = snippet(function_0)
    iterable_0 = snippet_0.get_body(a=2)
    for element_0 in iterable_0:
        pass


# Generated at 2022-06-25 23:24:00.574526
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = {'value_name': 'value'}
    s_n_i_p_p_e_t_0 = snippet(a_s_t_0)
    class0 = s_n_i_p_p_e_t_0.get_body(**d_i_c_t_0)

# Generated at 2022-06-25 23:24:07.258547
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    '''
    Tests how snippet takes source code and process it
    '''
    # Code to test
    def test_fn():
        'Total test function. Here we will test functions'
        extend(vars)
        print(x, y)
    
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))]
    
    s = snippet(test_fn)
    body = s.get_body(vars=vars)
    
    # We import ast from typed-ast.
    from typed_ast import ast3 as ast
    
    # Here we

# Generated at 2022-06-25 23:24:15.575411
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import typed_ast._ast3 as module_0
    # Create instance of class snippet
    snippet_0 = snippet(lambda : None)
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    # Test 1-st variant
    result_0 = snippet_0.get_body(arg_0 = a_s_t_0, arg_1 = a_s_t_1)
    assert result_0 is None
    # Test 2-nd variant
    result_1 = snippet_0.get_body()
    assert result_1 is None
    # Test 3-rd variant
    result_2 = snippet_0.get_body(arg_0 = a_s_t_0)
    assert result_2 is None

# Generated at 2022-06-25 23:24:16.938544
# Unit test for function extend_tree
def test_extend_tree():
    """
    Test extend_tree function
    """
    # TODO: implement test case
    raise NotImplementedError()


# Generated at 2022-06-25 23:24:19.294015
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_1 = module_0.AST()
    extend_tree(a_s_t_1, dict_0)
    extend_tree(a_s_t_1, dict_0)
