

# Generated at 2022-06-25 23:14:43.839734
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_instance = snippet(test_case_0)
    snippet_instance_body = snippet_instance.get_body()
    instance_body = test_case_0.__code__.co_consts[0]

    assert instance_body == snippet_instance_body # Unit test case
    snippet_instance_body_string = ast.dump(snippet_instance_body, True)
    assert snippet_instance_body_string == "[Assign(targets=[Name(id='_py_backwards_int_0_0', ctx=Store())], value=Num(n=9999))]" # Unit test case

# Generated at 2022-06-25 23:14:49.251889
# Unit test for function extend_tree
def test_extend_tree():
    """
    This test will check if the extend_tree function is working properly.

    The test_case above will be used.
    The result should be:
        int_0 = 9999
        extend(int_0)
    """
    int_0 = 9999
    extend(int_0)
    tree = ast.parse(get_source(test_case_0))
    extend_tree(tree, {'int_0': int_0})
    assert get_source(tree) == 'int_0 = 9999\nextend(int_0)\n'



# Generated at 2022-06-25 23:14:53.312173
# Unit test for function find_variables
def test_find_variables():
    let(x)
    let(y)
    l = []
    extend(l)
    l.append(x)

    tree = ast.parse(get_source(test_case_0))
    assert find_variables(tree) == {'x', 'y'}



# Generated at 2022-06-25 23:14:55.836130
# Unit test for function find_variables
def test_find_variables():
    # First test case
    int_0 = 9999
    extend(int_0)
    assert find_variables(test_case_0) == ["int_0"]


# Generated at 2022-06-25 23:15:00.852094
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    vars: List[ast.AST] = []
    def snippet_test_case_0():
        int_0 = 9999
        extend(int_0)

    snippet_test_case_0 = snippet(snippet_test_case_0) 
    snippet_test_case_0_body = snippet_test_case_0.get_body(vars=vars)
    assert snippet_test_case_0_body[0].value.value == 9999



# Generated at 2022-06-25 23:15:05.976286
# Unit test for function find_variables
def test_find_variables():
    def test():
        let(x)
        let(y)
        print(x)
        return y

    variables = dict(find_variables(test))
    assert variables == {'x': '_py_backwards_x_0', 'y': '_py_backwards_y_0'}



# Generated at 2022-06-25 23:15:08.974585
# Unit test for function find_variables
def test_find_variables():
    sample_snippet = '''
    let(a)
    a
    '''
    tree = ast.parse(sample_snippet)
    assert(find_variables(tree) == ['a'])



# Generated at 2022-06-25 23:15:16.586882
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    int_0 = 9999
    extend(int_0)
    snippet_instance = snippet(test_case_0)
    snippet_kwargs = {'int_0': let(1)}
    snippet_body = snippet_instance.get_body(**snippet_kwargs)
    first_node = snippet_body[0]
    assert first_node.__class__ == ast.Assign
    assert first_node.targets[0].id == '_py_backwards_int_0_0'
    assert first_node.value.n == 1

# Generated at 2022-06-25 23:15:19.149430
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
    let(x)
    print(x)
    """)
    assert list(find_variables(tree)) == ['x']


# Generated at 2022-06-25 23:15:25.527434
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse(test_case_0.__func__.__code__)
    extend_tree(tree, {"int_0": ast.Assign(targets=[ast.Name(id="x", ctx=ast.Store())],
     value=ast.Num(n=1, lineno=0, col_offset=0), lineno=0, col_offset=0)})

    assert tree.body[0].body[0].targets[0].id == "x"
    assert tree.body[0].body[0].value.n == 1


# Generated at 2022-06-25 23:15:40.317036
# Unit test for function extend_tree
def test_extend_tree():
    from .tree import flatten, insert_at
    from .visitor import SnippetVisitor

    class Test(SnippetVisitor):

        def visit_Assign(self, node: ast.Assign):
            assert node.value.n == 1

    var_0 = [ast.parse('y = 1').body[0].value, ast.parse('y = 2').body[0].value]


# Generated at 2022-06-25 23:15:48.714762
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test_snippet_get_body_impl():
        var_0 = 1
        var_1 = 2
        var_2 = 3
        var_3 = 4
        var_4 = 5
        var_5 = 6
        var_6 = 7
        def _test_snippet_get_body_impl_11(var_9 : int) -> int:
            var_8 = 8
            var_7 = 9
            return var_8
        var_9 = _test_snippet_get_body_impl_11(var_0)
        return var_1
    var_9 = _test_snippet_get_body_impl()
    print(var_9)

# Generated at 2022-06-25 23:15:51.570955
# Unit test for function find_variables
def test_find_variables():
    ast_1: ast.Module = ast.parse("let(var_0)")
    if find_variables(ast_1) != ['var_0']:
        raise RuntimeError('find_variables returned wrong results')
    if find_variables(ast_1) != []:
        raise RuntimeError('find_variables returned wrong results')


# Generated at 2022-06-25 23:15:55.406431
# Unit test for function find_variables
def test_find_variables():
    assert set(find_variables(test_case_0.__code__)) == set(['var_0'])


# Generated at 2022-06-25 23:15:57.627389
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse(get_source(test_case_0))
    assert set(find_variables(tree)) == set(['var_0'])


# Generated at 2022-06-25 23:16:02.145670
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body() == [ast.Assign([ast.Name('_py_backwards_var_0_0', ast.Store())], ast.List([]))]


# Generated at 2022-06-25 23:16:05.961719
# Unit test for function find_variables
def test_find_variables():
    # Function test_case_0
    # Call #0 of function find_variables
    assert ['var_0'] == list(find_variables(test_case_0()))



# Generated at 2022-06-25 23:16:09.665642
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''
    let(x)
    x += 1
    y = 1
    ''')
    assert len(find_variables(tree)) == 1
    assert find_variables(tree)[0] == 'x'



# Generated at 2022-06-25 23:16:14.008357
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse(test_case_0.__source__)
    var_0 = find_variables(tree)
    print(var_0)
    # variable = [var_0]
    # assert variable == find_variables(tree)




# Generated at 2022-06-25 23:16:18.583522
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = []
    var_1 = []
    var_0.append(1)
    var_1.append(1)
    if var_0 == var_1:
        print('OK')
    else:
        print('NG')



# Generated at 2022-06-25 23:16:33.039740
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_1 = []
    var_2 = {}
    def test_method_0():
        let(var_0)
        def test_method_1(var_3):
            let(var_1)
            var_4 = var_3 + var_0
            var_5 = 2
            var_1 = var_4 + var_5
            var_6 = {}
            let(var_6)
            for (var_7, var_8) in var_6.items():
                print(var_7)
                print(var_8)
            print(var_1)
        extend(var_2)
        var_9 = 2
        test_method_1(var_9)
    test_method_0()

# Generated at 2022-06-25 23:16:37.391145
# Unit test for function extend_tree
def test_extend_tree():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    extend_tree(tree, {'vars': []})
    t = let, extend


# Generated at 2022-06-25 23:16:40.305672
# Unit test for function extend_tree
def test_extend_tree():
    var_0 = []
    var_1 = let(var_0)
    extend(var_1)
    return var_0


# Generated at 2022-06-25 23:16:42.077252
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(test_case_0.__code__) == ['var_0']



# Generated at 2022-06-25 23:16:46.664076
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body() == [
        ast.Assign(targets=[
            ast.Name(id='var_0', ctx=ast.Store())],
                   value=ast.List(elts=[], ctx=ast.Load())
                   )
    ]


# Generated at 2022-06-25 23:16:49.118685
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test = snippet(test_case_0)
    import astor
    res = test.get_body()
    assert astor.to_source(res) == 'var_0 = []'


# Generated at 2022-06-25 23:16:50.579977
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # === begin ===
    test_case_0()
    # === end ===


# Generated at 2022-06-25 23:16:52.143239
# Unit test for method get_body of class snippet

# Generated at 2022-06-25 23:17:01.226929
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn():
        let(var_0)
        import sys, sys.path
        extend(var_1)
        var_0 = 1
        var_2 = 2
        var_3 = "fsd"
        var_4 = "fds"
        var_5 = 'aoeu'
        var_6 = var_0
        var_7, var_8 = var_1, var_2
        if True:
            var_9 = var_3
            var_10 = var_4
            var_11 = var_5
            var_12 = var_6
            var_13, var_14 = var_7, var_8
            pass


# Generated at 2022-06-25 23:17:05.381091
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_instance = snippet(test_case_0)
    body = snippet_instance.get_body()
    assert len(body) == 1
    assert type(body[0]) is ast.Assign
    assert type(body[0].value) is ast.List
    assert body[0].targets[0].id == '_py_backwards_var_0_0'

# Generated at 2022-06-25 23:17:20.477523
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source_0 = 'let(x)\n    print(x)\n    '
    a_s_t_0 = ast.parse(source_0)
    snippet_instance_0 = snippet(None)
    __args_0 = {'x': a_s_t_0}
    body_0 = snippet_instance_0.get_body(**__args_0)

# Generated at 2022-06-25 23:17:23.009948
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)


# Generated at 2022-06-25 23:17:24.861202
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)


# Generated at 2022-06-25 23:17:30.540894
# Unit test for function extend_tree
def test_extend_tree():
    class FunctionDef_0(ast.FunctionDef):
        def __init__(self, name, args, body, decorator_list, returns):
            self.name = name
            self.args = args
            self.body = body
            self.decorator_list = decorator_list
            self.returns = returns

    def Call_0(func, args, keywords):
        return ast.Call(func, args, keywords)

    class Arg_0(ast.arg):
        def __init__(self, arg, annotation):
            self.arg = arg
            self.annotation = annotation

    def Name_0(id, ctx):
        return ast.Name(id, ctx)


# Generated at 2022-06-25 23:17:32.406369
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)


# Generated at 2022-06-25 23:17:43.156467
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import sys
    import os
    import inspect
    from io import StringIO

    current_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    py_backwards_path = os.path.abspath(os.path.join(current_path, os.pardir, os.pardir))

    sys.path.insert(0, py_backwards_path)
    sys.path.insert(0, current_path)

    from typed_ast import ast3 as ast
    try:
        import py_backwards.sources.snippets.snippet as module_2
    except ImportError:
        module_2 = __import__('py_backwards.sources.snippets.snippet', fromlist=['snippet'])



# Generated at 2022-06-25 23:17:47.841815
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    a_s_t_1 = module_0.AST()
    iterable_1 = find_variables(a_s_t_1)

if __name__ == '__main__':
    pass  # pragma: no cover

# Generated at 2022-06-25 23:17:53.606936
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = ast.Module(
        body=[ast.Assign(
                targets=[ast.Name(id="x", ctx=ast.Store())],
                value=ast.Call(
                    func=ast.Name(id="let", ctx=ast.Load()),
                    args=[ast.Num(n=1)],
                    keywords=[]
                )
            )]
    )
    iterable_0 = find_variables(a_s_t_0)

    iterable_1 = iter(iterable_0)
    try:
        # next(iterable_1)
        pass
    except StopIteration as exception_0:
        pass


# Generated at 2022-06-25 23:17:58.310375
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_function_0(x):
        let(x)
        x += 1
        y = 1
    assert test_function_0(x=1) == 1

if __name__ == '__main__':
    test_case_0()
    test_snippet_get_body()

# Generated at 2022-06-25 23:18:02.831038
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # snippet_test_0
    def test_0():
        let(x)
        x += 1
        y = 1
    def test_0():
        _py_backwards_x_0 += 1
        y = 1

    # snippet_test_1
    def test_1():
        let(x)
        x += 1
        y = 1
    def test_1():
        _py_backwards_x_0 += 1
        y = 1

# Generated at 2022-06-25 23:18:46.667916
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _fn():
        a = let(1)
        b = let(2)
        a += 1
        b += 2

    source = get_source(_fn)
    tree = ast.parse(source)
    variables = find_variables(tree)
    _py_backwards_0 = _py_backwards_0
    _py_backwards_1 = _py_backwards_1
    extend_tree(tree, variables)
    snippet.VariablesReplacer.replace(tree, variables)
    snippet_0 = snippet(_fn)
    snippet_1 = snippet_0.get_body(a=_py_backwards_0 + 1, b=_py_backwards_1 + 2)
    assert snippet_1 == tree.body[0].body

# Generated at 2022-06-25 23:18:50.179794
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func_0():
        let(x)
        let(y)
        x += 1
        y = 1

    s_n_0 = snippet(func_0)
    result_0 = s_n_0.get_body()


# Generated at 2022-06-25 23:18:56.104471
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f(x: int, y: str):
        let(x)
        x += 1
        x[y] = 1

    new_body = f.get_body(x=2, y='a')
    assert new_body == [ast.Assign([ast.Subscript(ast.Name('_py_backwards_x_0', ast.Load()),
        ast.Index(ast.Str('a')), ast.Store())], ast.Num(1))]

# Generated at 2022-06-25 23:18:58.437697
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = ast.parse("print(x)")
    iterable_0 = find_variables(a_s_t_0)


# Generated at 2022-06-25 23:19:07.717077
# Unit test for function find_variables
def test_find_variables():
    from .ast_helpers import parse
    tree = parse('''
        let(x)
        let(y)
        y = x + 1
    ''')
    variables = list(find_variables(tree))
    assert variables == ['x', 'y']
    assert get_source(tree) == 'y = x + 1'

    tree = parse('''
        let(x)
        let(y)
        y = x + 1
        let(z)
    ''')
    variables = list(find_variables(tree))
    assert variables == ['x', 'y', 'z']
    assert get_source(tree) == 'y = x + 1'


# Generated at 2022-06-25 23:19:09.125430
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)


# Generated at 2022-06-25 23:19:19.345888
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    function_0_arg_0 = module_0.AST()
    function_0_arg_1 = module_0.AST()
    function_0_kwarg_0 = module_0.AST()
    function_0_kwarg_1 = module_0.AST()
    function_0_varargs = module_0.AST()
    function_0_kwargs = module_0.AST()
    function_0_defaults = module_0.AST()
    function_0_kw_defaults = module_0.AST()
    function_0_body = module_0.AST()
    function_0_decorator_list = module_0.AST()
    function_0_name = "function_0_name"
    function_0_returns = module_0.AST()
    function_0_returns_0

# Generated at 2022-06-25 23:19:28.036884
# Unit test for function extend_tree
def test_extend_tree():
    ast_0 = ast.parse('''[a, b, c]''') 
    module_0 = ast.Module()
    function_0 = ast.FunctionDef()
    module_0.body.append(function_0)
    list_0 = ast.List()
    list_0.elts.append(ast.Name('a', ast.Load()))
    list_0.elts.append(ast.Name('b', ast.Load()))
    list_0.elts.append(ast.Name('c', ast.Load()))
    ast.fix_missing_locations(list_0)
    extend_tree(module_0, {'a': ast_0.body[0]})
    assert module_0.body == [function_0]

# Generated at 2022-06-25 23:19:29.172413
# Unit test for function extend_tree
def test_extend_tree():
    assert True


# Generated at 2022-06-25 23:19:33.204752
# Unit test for function extend_tree
def test_extend_tree():
    test_tree = ast.parse("foo()")
    test_variable = ast.Variable(name="foo")
    extend_tree(test_tree, {
        "foo": test_variable
    })
    actual = test_tree.body[0]
    assert isinstance(actual, ast.Variable)
    assert actual == test_variable

# Generated at 2022-06-25 23:20:04.303169
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:20:12.007050
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippets_test_0():
        x = 1
        x += 1
        y = 1
    let(1)
    def snippets_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_test_1():
        x = 1
        y = 1
    let(1)
    def snippets_test_2():
        y = 1
        x += 1
    let(1)


# Generated at 2022-06-25 23:20:21.331200
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    assert list(iterable_0) == list()

    # Test example from snippet.py
    iterable_1 = find_variables(ast.parse(inspect.getsource(let)).body[0])
    assert list(iterable_1) == ['x']

    # Test example from snippet.py
    iterable_2 = find_variables(ast.parse(inspect.getsource(extend)).body[0])
    assert list(iterable_2) == ['vars']

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:20:29.793532
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Case 0
    a_s_t_0 = module_0.AST()
    a_s_t_0_0 = module_0.AST()
    a_s_t_0_0_0 = module_0.AST()
    dic_0 = {}
    dic_0_0 = {}
    dic_0_0_0 = {}
    dic_0_0_1 = {}
    dic_0_0_2 = {}
    dic_0_0_3 = {}
    dic_0_1 = {}
    dic_0_2 = {}
    dic_0_3 = {}
    dic_0_4 = {}
    dic_0_5 = {}
    dic_0_6 = {}
    dic_0_7 = {}

# Generated at 2022-06-25 23:20:37.504198
# Unit test for function extend_tree
def test_extend_tree():
    x = 1

    tree = ast.parse("""
    extend(vars)
    y = x + y
""")

    extend_tree(tree, {'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=1))]})

    assert compile(tree, '<string>', mode='exec').co_consts[0] == x + 1


# Generated at 2022-06-25 23:20:44.545866
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = {}
    a_s_t_1 = None
    s_n_i_p_p_e_t_0 = snippet(function.function_0)
    l_i_s_t_0 = s_n_i_p_p_e_t_0.get_body(a_s_t_1=a_s_t_1)


# Generated at 2022-06-25 23:20:49.603395
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)
    dict_1 = dict()
    snippet_0.get_body(**dict_1)

if __name__ == "__main__":
    print("[*] Unit tests of file py_backwards.py:")
    test_snippet_get_body()
    print("[+] All unit tests passed.")

# Generated at 2022-06-25 23:20:52.575002
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    d_0 = {}
    extend_tree(a_s_t_0, d_0)


# Generated at 2022-06-25 23:20:56.078322
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)

    class_0 = snippet(test_case_0)
    list_0 = class_0.get_body()


# Generated at 2022-06-25 23:21:02.071110
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    replace_at(0, a_s_t_0, [1, 2, 3])
    extend_tree(a_s_t_0, {'a': [1, 2, 3]})
    replace_at(0, a_s_t_0, 'a_s_t_0')


# Generated at 2022-06-25 23:21:22.901156
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    dic_0 = {}
    extend_tree(a_s_t_0, dic_0)


# Generated at 2022-06-25 23:21:27.296258
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        a = 1
    s = snippet(fn)

    result = s.get_body()
    assert len(result) == 1
    assert isinstance(result[0], ast.Expr)
    assert isinstance(result[0].value, ast.Constant)
    assert result[0].value.value == 1

# Generated at 2022-06-25 23:21:34.509803
# Unit test for function extend_tree
def test_extend_tree():
    def stub_a_s_t_2():
        return module_0.Module(
            body = [ast.parse("foo()").body[0]]
        )

    def stub_a_s_t_1():
        return module_0.Module(
            body = [ast.parse("let(x)").body[0]]
        )

    def stub_a_s_t_0():
        return module_0.Module(
            body = [ast.parse("extend(x)").body[0]]
        )

    t_e_s_t_0 = stub_a_s_t_2()
    extend_tree(t_e_s_t_0, {'x': ast.parse("1")})

    t_e_s_t_1 = stub_a_s_t_1()


# Generated at 2022-06-25 23:21:41.537649
# Unit test for function extend_tree
def test_extend_tree():
    ast_0 = ast.parse("if x < y: \n    x = y")
    replace_at(0, ast_0.body, ast.parse("pass").body[0])
    assert ast.dump(ast_0) == "Module(body=[If(test=Compare(left=Name(id='x', ctx=Load()), ops=[Lt()], comparators=[Name(id='y', ctx=Load())]), body=[Pass()], orelse=[])])"


# Generated at 2022-06-25 23:21:44.498196
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_1 = module_0.AST()
    d_0 = {}
    extend_tree(a_s_t_1, d_0)


# Generated at 2022-06-25 23:21:51.940922
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def function_f_n_0(param_0):
        let(l_e_t_0)
        let(l_e_t_1)
        with l_e_t_1:
            let(l_e_t_2)
            l_e_t_2.append(l_e_t_0)
            extend(e_x_t_e_n_d_0)
            extend(e_x_t_e_n_d_1)
    s_n_i_p_p_e_t_0 = snippet(function_f_n_0)
    s_n_i_p_p_e_t_0.get_body()
    s_n_i_p_p_e_t_0.get_body(param_0=1)

# Generated at 2022-06-25 23:22:01.127630
# Unit test for function extend_tree
def test_extend_tree():
    from math import sqrt
    from .helpers import to_source

    tree = ast.parse('print(x)')
    variables = {'x': [ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
                       ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))]}

    extend_tree(tree, variables)
    assert to_source(tree) == 'x = 1\nx = 2\nprint(x)'

    assert to_source(extend_tree(tree, {'y': ast.Num(2)})) == 'x = 1\nx = 2\nprint(x)'

    tree = ast.parse('print(sqrt(x))')

# Generated at 2022-06-25 23:22:04.479367
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(): pass
    snippet_0_0 = snippet(fn)
    snippet_0_1 = snippet_0_0.get_body(**{})
    assert snippet_0_1 is not None
    expected_value = 0
    assert len(snippet_0_1) == expected_value


# Generated at 2022-06-25 23:22:13.483242
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    try:
        import ast_support
    except ImportError:
        pass
    s_n_i_p_p_e_t_0 = snippet(ast_support.fn_0)
    snippet_kwargs_0 = {}
    snippet_kwargs_0['x'] = 'x'
    s_n_i_p_p_e_t_0.get_body(**snippet_kwargs_0)

    s_n_i_p_p_e_t_1 = snippet(ast_support.fn_1)
    s_n_i_p_p_e_t_1.get_body()

    s_n_i_p_p_e_t_2

# Generated at 2022-06-25 23:22:14.439828
# Unit test for function find_variables
def test_find_variables():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 23:22:49.090399
# Unit test for function extend_tree
def test_extend_tree():
    variables = {'a': 1}
    tree = ast.parse("""let(a)
extend(a)
a = 1
""")
    extend_tree(tree, variables)
    assert(get_source(tree) == """let(a)
extend(a)
a = 1
""")


# Generated at 2022-06-25 23:22:51.676654
# Unit test for function extend_tree
def test_extend_tree():
    let(x)
    extend(y)
    z = 1
    assert z == 1
    

# Generated at 2022-06-25 23:22:54.339243
# Unit test for function find_variables
def test_find_variables():
    # Test 1
    try:
        a_s_t_0 = module_0.AST()
        find_variables(a_s_t_0)
    except:
        print("\nThis code should not raise an exception.")


# Generated at 2022-06-25 23:23:03.948588
# Unit test for function extend_tree
def test_extend_tree():
    class module_0:
        class _ast3:
            class AST:
                pass
            class Call:
                def __init__(self):
                    self.func = 1
                def get_func(self):
                    return self.func
            class Name:
                def __init__(self):
                    self.id = 1
                def get_id(self):
                    return self.id
            class FunctionDef:
                def __init__(self):
                    self.body = 1
                def get_body(self):
                    return self.body
            class Assign:
                def __init__(self):
                    self.targets = 1
                def get_targets(self):
                    return self.targets
            class AugAssign:
                def __init__(self):
                    self.target = 1

# Generated at 2022-06-25 23:23:05.516326
# Unit test for function extend_tree
def test_extend_tree():
    with pytest.raises(AssertionError):
        extend_tree(None, None)


# Generated at 2022-06-25 23:23:13.078445
# Unit test for function extend_tree
def test_extend_tree():
    module_0.import_name("typed_ast._ast3")
    vars = {
        'x': 'a'
    }
    a_s_t_0 = module_0.FunctionDef('b', [], [module_0.Call(module_0.Name('let', module_0.Load()), [module_0.Str('x')], [], None, None)], [], None, None)
    extend_tree(a_s_t_0, vars)
    a_s_t_1 = module_0.Assign([module_0.Name('a', module_0.Load())], module_0.Call(module_0.Name('let', module_0.Load()), [module_0.Str('x')], [], None, None))
    a_s_t_2 = module_0

# Generated at 2022-06-25 23:23:14.771298
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)


# Generated at 2022-06-25 23:23:17.162697
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    snippet_variables_0 = {}
    extend_tree(a_s_t_0, snippet_variables_0)


# Generated at 2022-06-25 23:23:18.899561
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    variables = {'x': 'y', 'y': 1}
    class_0 = snippet(test_case_0)
    class_0.get_body(**variables)

# Generated at 2022-06-25 23:23:24.755569
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    a_s_t_0 = module_0.Call()
    s_n_i_p_p_e_t_0 = snippet(test_snippet_get_body)
    s_n_i_p_p_e_t_0.get_body(func=a_s_t_0)
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Name()
    test_snippet_get_body(a_s_t_0, mode=a_s_t_1)


# Generated at 2022-06-25 23:24:01.203265
# Unit test for method get_body of class snippet
def test_snippet_get_body():

  # Test case 0
  def test_case_0():
    source = get_source(test_snippet_get_body.test_case_0)
    tree = ast.parse(source)
    variables = {'_data': '_py_backwards_data_0', '_x': '_py_backwards_x_0', '_y': '_py_backwards_y_1'}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)

  # Test case 1
  def test_case_1():
    source = get_source(test_snippet_get_body.test_case_1)
    tree = ast.parse(source)

# Generated at 2022-06-25 23:24:05.305593
# Unit test for function extend_tree
def test_extend_tree():
    # Test arguments:
    a_s_t_0 = module_0.AST()
    variables = dict()

    # Call the function:
    if hasattr(extend_tree, "__call__"):
        extend_tree(a_s_t_0, variables)
    else:
        extend_tree.__call__(a_s_t_0, variables)


# Generated at 2022-06-25 23:24:09.642117
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn_0(a_s_t_0, a_s_t_1, a_s_t_2):
        variable_0 = declare(a_s_t_0, a_s_t_1)
        variable_1 = variable_0
        variable_1 = variable_1 + int(1)
        a_s_t_2.body.extend([variable_1, a_s_t_1])
    snippet_fn_1 = snippet(snippet_fn_0)
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()

# Generated at 2022-06-25 23:24:17.604623
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    func_0 = snippet(test_case_0)
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_0.body = [a_s_t_1]
    a_s_t_2.body = [a_s_t_3]
    a_s_t_4 = module_0.Module(body=[a_s_t_0])
    a_s_t_4.body = [a_s_t_5]
    a_s_t_5.body = [a_s_t_6]

# Generated at 2022-06-25 23:24:24.435162
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from x import snippet as module_0
    def func_0(arg_0):
        arg_0 += 1
    def func_1(arg_0):
        arg_0 += 1
    func_1(1)
    def func_2():
        pass
    func_2()
    def func_3(arg_0):
        arg_0 += 1
    func_3(0)
    def func_4(arg_0):
        arg_0 += 1
    func_4(0)
    def func_5(arg_0):
        arg_0 += 1
    a_s_t_0 = module_0(func_5)
    def func_6(arg_0):
        arg_0 += 1
    a_s_t_0.get_body(arg_0=1)