

# Generated at 2022-06-25 23:14:37.953509
# Unit test for function find_variables
def test_find_variables():
    # Test case with AST of empty code
    a_s_t = module_0.AST()
    iterable = find_variables(a_s_t)
    assert len(iterable) == 0
    # Test case with none-empty AST
    a_s_t = module_0.parse("let('x')")
    iterable = find_variables(a_s_t)
    assert len(iterable) == 1
    assert next(iterable) == 'x'

# Generated at 2022-06-25 23:14:39.903695
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = ast.AST()
    iterable_0 = find_variables(a_s_t_0)


# Generated at 2022-06-25 23:14:44.560067
# Unit test for function find_variables
def test_find_variables():
    snippet_0 = snippet(None)
    a_s_t_1 = module_0.AST()
    dictionary_0 = snippet_0._get_variables(a_s_t_1, {})
    extend_tree(a_s_t_1, dictionary_0)
    VariablesReplacer.replace(a_s_t_1, dictionary_0)


# Generated at 2022-06-25 23:14:51.105900
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class sample:
        def __init__(self):
            self._0 = dict()
        def __call__(self, **kwargs):
            self._0 = kwargs
    s = sample()

    class sample_1:
        def __init__(self):
            self._0 = dict()
        def __call__(self, **kwargs):
            self._0 = kwargs
    s_1 = sample_1()

    class sample_2:
        def __init__(self):
            self._0 = dict()
        def __call__(self, **kwargs):
            self._0 = kwargs
    s_2 = sample_2()

    class sample_3:
        def __init__(self):
            self._0 = dict()

# Generated at 2022-06-25 23:14:54.517424
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def method_0(a_0):
        pass
    snippet_0 = snippet(method_0)
    dict_0 = {}
    list_0 = snippet_0.get_body(**dict_0)

# Generated at 2022-06-25 23:15:02.450213
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(x)
        x += 1
        y = 1
    
    snippet_0 = snippet(fn)
    list_0 = snippet_0.get_body()
    
    assert len(list_0) == 2
    assert isinstance(list_0[0], module_0.Assign)
    assert isinstance(list_0[0].targets[0], module_0.Name)
    assert list_0[0].targets[0].id == '_py_backwards_x_0'
    assert isinstance(list_0[0].value, module_0.BinOp)
    assert list_0[0].value.op.__class__.__name__ == 'Add'
    assert isinstance(list_0[0].value.left, module_0.Name)


# Generated at 2022-06-25 23:15:13.886426
# Unit test for function extend_tree
def test_extend_tree():
    import ast
    import astor
    a_s_t_0 = ast.AST()
    function_def_0 = ast.FunctionDef(name='l')
    arguments_0 = ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    function_def_0.args = arguments_0
    function_def_0.body = []
    a_s_t_0.body = [function_def_0]
    d_i_c_0 = {}
    function_def_1 = ast.FunctionDef(name='l')
    arguments_1 = ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    function_def_1

# Generated at 2022-06-25 23:15:17.174476
# Unit test for function extend_tree
def test_extend_tree():
    test_class_0 = snippet
    snippet_0 = test_class_0(test_case_0)
    test_dict_0 = {var_0: 1 for var_0 in ()}
    body_0 = snippet_0.get_body(**test_dict_0)

# Generated at 2022-06-25 23:15:26.171529
# Unit test for function find_variables
def test_find_variables():
    extend([])
    extend([])
    let(test_case_0)
    a_s_t_8 = module_0.parse("""def f():
    let(x)
    let(y)
    x = 1
    y = x
""")
    d_i_c_t_0 = _get_variables(a_s_t_8, {
    })
    assert d_i_c_t_0 == {
        'x': '_py_backwards_x_3',
        'y': '_py_backwards_y_4',
    }
    a_s_t_9 = module_0.parse("""def f():
    let(x)
    let(y)
    x = 1
    y = x
""")

# Generated at 2022-06-25 23:15:29.148223
# Unit test for function extend_tree
def test_extend_tree():
    def dummy_fn(x: int) -> None:
        a = 1
        return x
    assert get_source(dummy_fn) == 'def dummy_fn(x: int) -> None:\n    a = 1\n    return x'


# Generated at 2022-06-25 23:15:41.889427
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body() == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())], ast.Num(0))]


# Generated at 2022-06-25 23:15:42.457957
# Unit test for function extend_tree

# Generated at 2022-06-25 23:15:51.039746
# Unit test for function extend_tree
def test_extend_tree():
    @snippet
    def f():
        extend(test_case_0)
        int_5 = 5
        int_0 = 0
    res = f.get_body()
    assert(len(res) == 3)
    assert(isinstance(res[0], ast.Assign))
    assert(isinstance(res[1], ast.Assign))
    assert(isinstance(res[2], ast.Assign))

    # Test private methods
    assert(ast.dump(res[0], include_attributes=True) == 'Assign(targets=[Name(id=\'int_0\', ctx=Store())], value=Num(n=0))')

# Generated at 2022-06-25 23:16:00.193080
# Unit test for function extend_tree
def test_extend_tree():
    source = """
let(vars)
if vars:
    x = 1
    y = 2
else:
    x = 3
    y = 4
"""
    tree = ast.parse(source)

    variables = {'vars': [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Load())],
            value=ast.Num(n=1)
        ),
        ast.Assign(
            targets=[ast.Name(id='y', ctx=ast.Load())],
            value=ast.Num(n=2)
        )
    ]}

    extend_tree(tree, variables)
    source = ast.fix_missing_locations(tree).body[0].body[1].body


# Generated at 2022-06-25 23:16:06.247755
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source_0 = "let(int_0)\nassert int_0 == 0\n"
    tree_0 = ast.parse(source_0)
    snippet_kwargs_0 = {}
    int_0 = 0
    snippet_kwargs_0["int_0"] =  int_0
    variables_0 = {
        "int_0": "int_0",
    }
    result_0 = snippet(test_case_0).get_body(**snippet_kwargs_0)
    assert result_0 == tree_0.body[0].body

# Generated at 2022-06-25 23:16:10.173176
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test case 0
    tree = ast.parse('int_0 = 0')
    #assert snippet(test_case_0).get_body() == tree.body[0].body
    print(snippet(test_case_0).get_body())



# Generated at 2022-06-25 23:16:18.693656
# Unit test for function extend_tree
def test_extend_tree():
    @snippet
    def source():
        extend(my_list)
        a = 1
        b = 2

    tree = ast.parse("a = 3")
    extend_tree(tree, {'my_list': [ast.Assign(targets = [ast.Name(id='a')],value = ast.Num(n = 4)),
                                   ast.Assign(targets = [ast.Name(id='b')], value = ast.Num(n = 5))]})
    assert(tree.body[1].value.n == 5)


# Generated at 2022-06-25 23:16:29.489869
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    int_0 = 0
    int_1 = 1

    body = snippet(let(x))
    x = 5
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())], ast.Num(5))]


    x = 0
    body = snippet(let(x)).get_body(x = int_0)
    x = 5
    assert body == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())], ast.Num(0))]


    y = 0
    body = snippet(let(x)).get_body(x = int_0, y = int_1)
    x = 5

# Generated at 2022-06-25 23:16:38.339232
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        a = let(1)
        for b in let([2, 3]):
            c = let(a + b)
            print(c)

    class Tester(unittest.TestCase):
        _snippet = snippet(test_snippet)
        
        def test_get_body(self):
            body = self._snippet.get_body()
            self.assertEqual(len(body), 1)

    unittest.main(exit=False, verbosity=2)


# Generated at 2022-06-25 23:16:45.745469
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippets = {'test_case_{}'.format(i): snippet(func) for i,
                func in enumerate([test_case_0])}
    for i in range(len(snippets)):
        assert snippets['test_case_{}'.format(i)].get_body() == [
            ast.Assign(targets=[
                ast.Name(id='int_0', ctx=ast.Store())], value=ast.Num(n=0))
        ]


# Generated at 2022-06-25 23:17:01.274230
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    variables = find_variables(tree)
    extend_tree(tree, variables)
    tree = VariablesReplacer.replace(tree, variables)
    body = tree.body[0].body  # type: ignore
    expected = [ast.Assign([ast.Name(id='_py_backwards_int_0_0', ctx=ast.Store())], ast.Num(n=0))]
    assert body == expected, '\n'.join([str(body), str(expected)])



# Generated at 2022-06-25 23:17:09.810582
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test_snippet_get_body_f(_arg_int_0):
        int_1 = _arg_int_0
        _py_backwards_int_1_1 = 1
        int_2 = _py_backwards_int_1_1 + int_1

# Generated at 2022-06-25 23:17:20.712053
# Unit test for function extend_tree
def test_extend_tree():  # noqa
    x = ast.Name(id='x', ctx=ast.Store())
    y = ast.Name(id='y', ctx=ast.Store())
    t = ast.Name(id='t', ctx=ast.Store())
    let_x = ast.Expr(value=ast.Call(func=ast.Name(id='let', ctx=ast.Load()),
                                    args=[x], keywords=[]))
    let_y = ast.Expr(value=ast.Call(func=ast.Name(id='let', ctx=ast.Load()),
                                    args=[y], keywords=[]))
    let_t = ast.Expr(value=ast.Call(func=ast.Name(id='let', ctx=ast.Load()),
                                    args=[t], keywords=[]))


# Generated at 2022-06-25 23:17:24.531956
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test():
        int_0 = 0

        return int_0

    source = test.get_body()
    assert ast.dump(source[0]) == 'Assign(targets=[Name(_py_backwards_int_0_0, Load())], value=Num(n=0))'

# Generated at 2022-06-25 23:17:27.303248
# Unit test for function extend_tree
def test_extend_tree():
  int_0 = 0
  extend_tree(test_case_0.get_body(), {"int_0": ast.parse("int_0 = 0;").body[0].value})
  assert test_case_0.get_body()[0].value.value == 0


# Generated at 2022-06-25 23:17:28.954720
# Unit test for function find_variables
def test_find_variables():
    variables = find_variables(test_case_0)
    assert int_0 in variables


# Generated at 2022-06-25 23:17:34.463003
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_function_func_0(int_0):
        let(int_0)
        int_0 += 1
        y = 1
    snippet_func_0 = snippet(test_function_func_0)
    assert snippet_func_0.get_body() == test_function_func_0(0).__code__.co_consts[0]


# Generated at 2022-06-25 23:17:43.997829
# Unit test for function extend_tree
def test_extend_tree():
    def test_case_1():
        extend(vars)

    def test_case_2():
        vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1))]
        extend(vars)

    def test_case_3():
        def f():
            a = 1

        vars = f.__code__
        extend(vars)

    def test_case_4():
        class A: pass

    # Snippet to run:
    def snippet_to_test():
        test_case_0()
        test_case_4()


    # Actual test:

# Generated at 2022-06-25 23:17:48.484890
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_case_1(x: int):
        for _ in range(4):
            let(x)
            x = x + 1
        y = x + 1
        return y
    @snippet
    def test_case_2(x: int):
        test_case_3(x)

    @snippet
    def test_case_3(x: int):
        int_x = x
        int_x = int_x + 1
        return int_x
    
    @snippet
    def test_case_4(x: int):
        int_x = x
        test_case_5(int_x)
        int_x = test_case_5(int_x)


# Generated at 2022-06-25 23:17:49.974689
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(x)\nx = 1\nx = 2')
    assert ['x'] == list(find_variables(tree))



# Generated at 2022-06-25 23:18:01.182373
# Unit test for function extend_tree
def test_extend_tree():
    # Call extend_tree
    extend_tree(a_s_t_0_0, a_s_t_0_1)

# Generated at 2022-06-25 23:18:07.285097
# Unit test for function extend_tree
def test_extend_tree():
    # Check for function extend_tree with arguments of type ast.AST, dict
    try:
        c_allable_0 = snippet(lambda x, y: print(x, y))
        a_s_t_0 = module_0.AST()
        d_i_c_t_0 = {"dict_key_0": a_s_t_0, "dict_key_1": a_s_t_0}
        extend_tree(a_s_t_0, d_i_c_t_0)
    except:
        pass


# Generated at 2022-06-25 23:18:18.734861
# Unit test for function extend_tree
def test_extend_tree():
    module_0 = ast.Module([
        ast.FunctionDef(
            name="sample_func",
            args=ast.arguments(
                args=[],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[]
            ),
            body=[
                ast.Call(
                    func=ast.Name(
                        id="extend",
                        ctx=ast.Load()
                    ),
                    args=[
                        ast.Constant(
                            value="hello"
                        )
                    ],
                    keywords=[],
                    starargs=None,
                    kwargs=None
                )
            ],
            decorator_list=[],
            returns=None
        )
    ])

# Generated at 2022-06-25 23:18:20.966076
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test with non-default arguments
    test_0 = snippet.get_body(self, 1)



# Generated at 2022-06-25 23:18:31.702816
# Unit test for function extend_tree
def test_extend_tree():
    from typing import Any
    from .helpers import VariablesGenerator
    from .tree import find
    from .snippets import extend, let
    from .helpers import eager
    from .tree import replace_at

    def test_case_0():
        # Variable a_s_t_0 store AST for 'let(x) x += 1'
        a_s_t_0 = ast.parse('let(x) x += 1', mode='eval')
        # Variable a_s_t_1 store AST for 'None'
        a_s_t_1 = ast.parse('None', mode='eval')
        # Variable d_i_c_t_0 store variable values
        d_i_c_t_0 = {'x': a_s_t_1}
        # Body for extend_tree
        extend_tree

# Generated at 2022-06-25 23:18:34.532265
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    dict_0 = {}
    extend_tree(a_s_t_0, dict_0)


# Generated at 2022-06-25 23:18:42.833751
# Unit test for function extend_tree
def test_extend_tree():
    snippet_kwargs_0 = {
        'tree': module_0.AST(),
        'variables': {
            'arg_0': module_0.AST()
        }
    }
    extend_tree(**snippet_kwargs_0)

if __name__ == '__main__':
    raise Exception('''You shouldn't run tests.py of this library directly.
Run tests/tests.py to run all tests.''')


# Generated at 2022-06-25 23:18:50.788595
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = ast.parse('a = 1')
    a_s_t_1 = ast.parse('a = 2')

    def fn_0(a_s_t_2, variables_0):
        replace_at(1, a_s_t_2, variables_0['a'])

    fn_0(a_s_t_0, {'a': a_s_t_1})
    assert ast.dump(a_s_t_0) == 'Module(body=[Assign(targets=[Name(id="a", ctx=Store())], value=Num(n=2))])'


# Generated at 2022-06-25 23:18:56.665327
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _snippet():
        let(x)
        x += 1
        y = 1
    _snippet.__name__ = '_snippet'
    snippet_instance = snippet(_snippet)
    result = snippet_instance.get_body()
    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], module_0.Assign)
    assert isinstance(result[1], module_0.Assign)


# Generated at 2022-06-25 23:18:58.680538
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(x):
        let(x)
        x += 1
        y = 1

    snippet(fn).get_body()

# Generated at 2022-06-25 23:19:09.689801
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_1 = module_0.AST()
    dict_0 = dict()
    extend_tree(a_s_t_1, dict_0)


# Generated at 2022-06-25 23:19:14.607705
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = ast.parse("x += 1")
    extend_tree(a_s_t_0, {'x': 'y'})
    assert a_s_t_0.body[0].value.value == 'y'
    assert a_s_t_0.body[0].value.op == '+'


# Generated at 2022-06-25 23:19:17.721584
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = {"0"}
    extend_tree(a_s_t_0, d_i_c_t_0)


# Generated at 2022-06-25 23:19:21.606053
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    extend_tree(a_s_t_0, {})

test_extend_tree()
test_case_0()


# Generated at 2022-06-25 23:19:22.516934
# Unit test for function extend_tree
def test_extend_tree():
    pass


# Generated at 2022-06-25 23:19:24.002808
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_function_0 = test_case_0
    snippet_kwargs_0 = {  }
    var_0 = snippet(snippet_function_0).get_body(**snippet_kwargs_0)

# Generated at 2022-06-25 23:19:30.918764
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Unit-test for method snippet.get_body

    import ast
    from helpers import get_source

    def _fn():
        x = 1
        let(True)
        y = 2

    a_s_t_source = get_source(_fn)
    a_s_t_0 = ast.parse(a_s_t_source)
    assert a_s_t_0 is not None
    iterable_0 = snippet(_fn).get_body()
    a_s_t_1 = ast.Expression(body=iterable_0[0])
    assert a_s_t_1 is not None and a_s_t_0.body[0].value.n == 1
    a_s_t_1 = ast.Expression(body=iterable_0[1])
    assert a_s_t

# Generated at 2022-06-25 23:19:40.848410
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _create_case_0(self):
        try:
            return snippet.get_body(self)
        except:
            raise AssertionError("AssertionError while evaluating snippet.get_body(self)")
    def _create_case_1(self):
        try:
            return snippet.get_body(self)
        except:
            raise AssertionError("AssertionError while evaluating snippet.get_body(self)")
    def _create_case_2(self):
        try:
            return snippet.get_body(self)
        except:
            raise AssertionError("AssertionError while evaluating snippet.get_body(self)")
    def _create_case_3(self):
        try:
            return snippet.get_body(self)
        except:
            raise AssertionError

# Generated at 2022-06-25 23:19:45.446464
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def function_0():
        let(1)
        return try_type(1, str)
    s_n_i_p_p_e_t_0 = snippet(function_0)
    l_i_s_t_0 = s_n_i_p_p_e_t_0.get_body()
    return l_i_s_t_0

# Generated at 2022-06-25 23:19:53.299445
# Unit test for function extend_tree
def test_extend_tree():

    class _function_0_lambda(snippet):
        def get_body(self, **snippet_kwargs):
            return super().get_body(**snippet_kwargs)
    fn = _function_0_lambda(lambda : None)

    class _function_1_lambda(snippet):
        def get_body(self, **snippet_kwargs):
            return super().get_body(**snippet_kwargs)
    fn_1 = _function_1_lambda(lambda : None)
    class _function_2_lambda(snippet):
        def get_body(self, **snippet_kwargs):
            return super().get_body(**snippet_kwargs)
    fn_2 = _function_2_lambda(lambda : None)
    a_s_t

# Generated at 2022-06-25 23:20:19.745605
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn(i):
        let(x)
        print(x)

    snippet_0 = snippet(fn)
    result_0 = snippet_0.get_body(x=1)
    assert result_0 == [ast.Expr(
        ast.Call(
            ast.Name('print', ast.Load()),
            [ast.Name(_py_backwards_x_0_0, ast.Load())],
            []
        )
    )]

# Generated at 2022-06-25 23:20:23.328186
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(None)
    d_i_c_t_0 = {}
    list_0 = snippet_0.get_body(**d_i_c_t_0)


# Generated at 2022-06-25 23:20:30.570198
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Checks whether the file is being tested by pytest
    assert 'pytest' in sys.modules
    def _():
        let(x)
        let(y)
        x += 1
    a_s_t_0 = ast.parse('x, y = 1, 2')
    a_s_t_1 = ast.parse('x = 1')
    a_s_t_2 = ast.parse('x += 1')
    a_s_t_3 = _()
    assert a_s_t_3.body[0].body[0] == a_s_t_2
    assert a_s_t_3.body[0].body[1] == a_s_t_1
    assert a_s_t_3.body[0].body[2] == a_s_t_0
    snippet

# Generated at 2022-06-25 23:20:42.288487
# Unit test for function extend_tree
def test_extend_tree():
    # arrange:
    assign_x = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                          value=ast.Num(n=1))

    assign_y = ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                          value=ast.Num(n=2))

    tree = ast.parse("""
    extend(vars)
    print(x, y)
    """)

    # act:
    extend_tree(tree, {'vars': [assign_x, assign_y]})

    # assert:
    assert str(tree) == """
    x = 1
    x = 2
    print(x, y)
    """


# Generated at 2022-06-25 23:20:43.379720
# Unit test for function find_variables
def test_find_variables():
    from typed_ast import ast3 as ast


# Generated at 2022-06-25 23:20:47.950371
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = {}
    extend_tree(a_s_t_0, d_i_c_t_0)


# Generated at 2022-06-25 23:20:58.411635
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn_0(a:int):
        let(x)
        x += 1
        y = 1
        return x + y
    def fn_1(a:int):
        let(x)
        x += 1
        y = 1
        return x + y
    def fn_2(a:int):
        let(x)
        x += 1
        y = 1
        return x + y
    def fn_3(a:int):
        let(x)
        x += 1
        y = 1
        return x + y
    def fn_4(a:int):
        let(x)
        x += 1
        y = 1
        return x + y
    def fn_5(a:int):
        let(x)
        x += 1
        y = 1
        return x + y
   

# Generated at 2022-06-25 23:21:07.721690
# Unit test for function extend_tree
def test_extend_tree():
    a_1 = module_0.AST()
    iterable_0 = find(a_1, ast.Call)
    for node_0 in iterable_0:
        if isinstance(node_0.func, ast.Name):
            if (node_0.func.id == 'extend'):
                iterable_0 = find(a_1, ast.Call)
                for node_1 in iterable_0:
                    if isinstance(node_1.func, ast.Name):
                        if (node_1.func.id == 'extend'):
                            pass
                        else:
                            pass
                    else:
                        pass
                else:
                    pass
            else:
                iterable_0 = find(a_1, ast.Call)

# Generated at 2022-06-25 23:21:09.901333
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    dictionary_0 = {}
    extend_tree(a_s_t_0, dictionary_0)


# Generated at 2022-06-25 23:21:19.448971
# Unit test for function extend_tree
def test_extend_tree():
    # Unit test for function extend_tree
    # Check that tree will extend
    original_tree = ast.parse("1")
    to_extend = ast.parse("let(y)\nx = y")
    extend_tree(to_extend, {"y": original_tree})
    assert ast.dump(to_extend) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Expression(body=Num(n=1)))])" # noqa
    # Check that tree will extend
    original_tree = ast.parse("1")
    to_extend = ast.parse("let(y)\nextend(y)")
    extend_tree(to_extend, {"y": original_tree})

# Generated at 2022-06-25 23:21:37.770549
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = ast.parse('print(1)')
    var_1 = ast.parse('x = 1')
    var_2 = Snippet(lambda x: 1)
    var_3 = var_2.get_body(x = var_1)
    var_4 = ast.parse('print(2)')
    assert var_3 == var_4.body, 'Failed assertion'


# Generated at 2022-06-25 23:21:45.519842
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    v_a_r_0 = module_0.Name()
    i_n_t_0 = extend_tree(a_s_t_0, {'x': v_a_r_0})
    l_i_s_t_0 = [v_a_r_0]
    s_n_i_p_p_e_t_1 = snippet(lambda: i_n_t_0)
    s_t_r_0 = s_n_i_p_p_e_t_1.get_body(x=l_i_s_t_0)

# Generated at 2022-06-25 23:21:50.674522
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = {}
    t_u_p_l_e_0 = (
        d_i_c_t_0,
    )
    s_n_i_p_p_e_t_0 = snippet(a_s_t_0)
    s_n_i_p_p_e_t_0.get_body(*t_u_p_l_e_0)

# Generated at 2022-06-25 23:21:59.264640
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Typed_ast has no attribute parse
    module_0 = None
    a_s_t_0 = module_0.literal_eval('<unknown>')
    variables_0 = {'x': 'a', 'y': 1}
    d_0 = {'x': 1, 'y': 2}
    snippet_0 = snippet(lambda: let(x))
    assert snippet_0.get_body(**d_0) == variables_0
    d_1 = {'x': 1, 'y': 2}
    snippet_1 = snippet(lambda: let(x))
    assert snippet_1.get_body(**d_1) == variables_0
    a_s_t_1 = module_0.literal_eval('<unknown>')

# Generated at 2022-06-25 23:22:02.392681
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn_0(arg_0):
        """Snippet function."""
        let(arg_0)
    
    snippet_0 = snippet(snippet_fn_0)
    l_s_t_0 = snippet_0.get_body()



# Generated at 2022-06-25 23:22:11.842851
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet():
        import sys
        import types
        snippets = types.ModuleType('snippets')
        sys.modules['snippets'] = snippets
        import snippets
        import typed_ast._ast3 as ast
        import typing as t
        @snippets.snippet
        def test_snippet(x_0: t.List[str], y_0: t.List[str]):
            let(x_0)
            let(y_0)
            let(z_0)
            let(z_0)
            let(z_0)
            x_0.append('3')
            y_0.append('4')
            z_0.append('5')

# Generated at 2022-06-25 23:22:17.298600
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def _fn_fn_(x: int) -> None:
        class A:
            x: int

        a = A()
        let(a)
        extend([ast.Assign([ast.Name(id='x', ctx=ast.Store())],
             [ast.Num(n=1)])])
    s = snippet(_fn_fn_)
    actual = s.get_body(a=ast.Name(id='_py_backwards_a_0', ctx=ast.Load()))

# Generated at 2022-06-25 23:22:27.974352
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def undecorated_fn_0(arg):
        let(arg)
        let(arg)
        return extend(arg)
    undecorated_fn_0(module_0.Module())
    undecorated_fn_0(module_0.FunctionDef())
    undecorated_fn_0(module_0.Assign())
    undecorated_fn_0(module_0.Module())
    undecorated_fn_0(module_0.ClassDef())
    undecorated_fn_0(module_0.FunctionDef())
    undecorated_fn_0(module_0.Pass())
    undecorated_fn_0(module_0.Module())


# Generated at 2022-06-25 23:22:32.447672
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def main(main_param_0):
        let(main_param_0)
        a_s_t_0 = module_0.AST()
        iterable_0 = find_variables(a_s_t_0)
    s_n_i_p_0 = snippet(main)

# Generated at 2022-06-25 23:22:37.373766
# Unit test for function extend_tree
def test_extend_tree():
    typos = {'x': '_', 'y': '_'}

    def check(var, value):
        tree = ast.parse(f'extend({var})\n')
        extend_tree(tree, {var: value})
        assert get_source(tree) == value

    for var, value in typos.items():
        check(var, value)



# Generated at 2022-06-25 23:23:09.874790
# Unit test for function extend_tree
def test_extend_tree():
    snippet_0 = snippet(test_case_0)
    d_i_c_t_0 = {'a_s_t_0': {}}
    l_i_s_t_0 = snippet_0.get_body(**d_i_c_t_0)
    a_s_t_1 = module_0.AST()
    extend_tree(a_s_t_1, {'a_s_t_0': a_s_t_0})
    assert l_i_s_t_0 == a_s_t_1.body
    assert a_s_t_0 is a_s_t_1

# Generated at 2022-06-25 23:23:16.991026
# Unit test for function find_variables
def test_find_variables():
    from itertools import cycle
    from .tree import find, get_non_exp_parent_and_index, replace_at

    def check_find(case):
        tree = ast.parse(case)
        result = ['x', 'y', 'z']
        expected = cycle(result)
        for node in find(tree, ast.Name):
            assert node.id in result
            assert node.id == next(expected)

    def check_find_by_parent(case):
        tree = ast.parse(case)
        result = ['x', 'y', 'z']
        expected = cycle(result)
        for node in find(tree, ast.Name, lambda node, parent: parent):
            assert node.id in result
            assert node.id == next(expected)

    def check_replace(case):
        tree = ast

# Generated at 2022-06-25 23:23:19.418416
# Unit test for function find_variables
def test_find_variables():
    test_case_0()
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    assert iterable_0 == ()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:23:24.005301
# Unit test for function find_variables
def test_find_variables():
    a_s_t_1 = module_0.AST()
    iterable_1 = find_variables(a_s_t_1)
    a_s_t_2 = module_0.AST()
    iterable_2 = find_variables(a_s_t_2)
    a_s_t_3 = module_0.AST()
    iterable_3 = find_variables(a_s_t_3)



# Generated at 2022-06-25 23:23:33.064321
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import random
    import pytest
    from .helpers import create_ast_for_code
    a_s_t_0 = create_ast_for_code('x = 1')

    def function_0(x: int) -> int:
        with pytest.raises(TypeError):
            x = let(a_s_t_0)
        return x

    with pytest.raises(TypeError):
        c_a_s_e_0 = snippet(function_0)
        s_t_r_0 = c_a_s_e_0.get_body(x=random.AGRANDIR)

    def function_1(x: int) -> int:
        return let(x)


# Generated at 2022-06-25 23:23:37.430816
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    list_0 = snippet.get_body(a_s_t_0, x=a_s_t_0)
    tuple_0 = (id(node) for node in find(a_s_t_0))
    tuple_1 = (id(node) for node in list_0)
    assert tuple_0 != tuple_1


# Generated at 2022-06-25 23:23:41.125006
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f_0_0() -> None:
        let(a_0_0)
        a_0_0 = a_0_0 + 1
        return a_0_0
    snippet(f_0_0).get_body()


# Generated at 2022-06-25 23:23:48.202416
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = "def g(x):\n    let(y)\n    x += 1\n    y = 1\n    print(x, y)\n"
    main_0 = ast.parse(source)
    snippet_0 = snippet(None)
    tree_0 = main_0
    snippet_kwargs_0 = {}
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    dictionary_1 = {'y':a_s_t_1}
    dictionary_2 = {'y':a_s_t_2}
    snippet_kwargs_0['y'] = a_s_t_1
    snippet_1 = snippet_0.get_body(**snippet_kwargs_0)
    variables_0 = dictionary_1

# Generated at 2022-06-25 23:23:57.445793
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def _snippet():
        let(x)
        x += 1
        y = 1

    module_0 = ast.parse(""""""
                         )
    snippet_kwargs_0 = {
        'x': ast.Name(
        id = '_py_backwards_x_0',
        ctx = ast.Load()
        ),
        'y': 1
    }

    a_s_t_0 = _snippet.get_body(**snippet_kwargs_0)
    a_s_t_1 = module_0.body[0].body
    assert (a_s_t_0 == a_s_t_1)

# Generated at 2022-06-25 23:24:05.421553
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class int_0(int): # subclass of int
        pass

    class int_1(int): # subclass of int
        pass

    class int_2(int): # subclass of int
        pass

    class int_3(int): # subclass of int
        pass

    class Module_0(ast.Module):
        def __init__(self, body: List[ast.AST]) -> None:
            self.body = body
    
        def __setattr__(self, name: str, value: Any) -> None:
            if name in {'body'}:
                raise AttributeError("can't set attribute")
            else:
                super().__setattr__(name, value)
        
        def __eq__(self, other: Any) -> bool:
            if isinstance(other, Module_0):
                return self.body