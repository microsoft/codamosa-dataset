

# Generated at 2022-06-25 23:14:33.638668
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    callable_0 = None
    snippet_0 = snippet(callable_0)
    test_case_0()

# last line of code

# Generated at 2022-06-25 23:14:38.490018
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .test_utils import SnippetRunner
    snippet_runner = SnippetRunner()
    variables = None
    code = """
        x = 0
        let(x)
        x += 1
        print(x)
        """.strip()

    correct_result = """
    def callable_0():
        x = 0
        _py_backwards_x_0 += 1
        print(x)
    """.strip()

    result = snippet_runner.run(code, variables)
    assert(result == correct_result)



# Generated at 2022-06-25 23:14:47.400020
# Unit test for function find_variables
def test_find_variables():
    def callable_0():
        let(x0)
        let(x1)
        x0 += 1

    tree = snippet(callable_0).get_body()
    names = find_variables(tree)
    assert names == ('x0', 'x1')
    
    def callable_1():
        let(x0)
        x0 += 1
        let(x1)

    tree = snippet(callable_1).get_body()
    names = find_variables(tree)
    assert names == ('x0', 'x1')
    
    def callable_2():
        x0 += 1
        let(x1)
        let(x2)

    tree = snippet(callable_2).get_body()
    names = find_variables(tree)

# Generated at 2022-06-25 23:14:53.603152
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    callable_0 = None

    def method_0(self, forward: ast.Call) -> ast.Call:
        forward.args = [ast.Name('forward', ast.Load())]  # type: ignore
        return forward

    callable_0 = method_0

    snippet_0 = snippet(callable_0)
    try:
        snippet_0.get_body()
    except SystemError as e:
        assert True
    else:
        assert False


# `let` tests:


# Generated at 2022-06-25 23:14:58.444196
# Unit test for function find_variables
def test_find_variables():
    '''
    Test function find_variables with input:
    let(x)
    x += 1
    y = 1
    '''
    callable_0 = None
    snippet_0 = snippet(callable_0)
    input_0 = snippet_0.get_body()
    result_0 = ['x', 'y']
    assert find_variables(input_0) == result_0


# Generated at 2022-06-25 23:15:01.705775
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    callable_0 = None
    snippet_0 = snippet(callable_0)
    
    # get_body()
    
    
    
    
    
    
    class_0 = snippet_0.get_body()
    assert class_0 == None

# Generated at 2022-06-25 23:15:07.041331
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    callable_0 = None
    snippet_0 = snippet(callable_0)
    var_0 = let(None)
    var_1 = let(None)
    var_2 = extend(None)
    assert snippet_0.get_body(var_0, var_1, var_2) == [None]



# Generated at 2022-06-25 23:15:13.595273
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def callable_0():
        let(x)
        x += 1
        y = 1
    snippet_0 = snippet(callable_0)
    # Testing if assertion 'isinstance(x, ast.AST) or isinstance(x, str) or isinstance(x, ast.Name)' raised
    assert 'isinstance(x, ast.AST) or isinstance(x, str) or isinstance(x, ast.Name)'
    assert snippet_0.get_body()


# Generated at 2022-06-25 23:15:18.367296
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Body of method get_body of class snippet
    def _test_snippet_get_body():
        callable_0 = None
        snippet_0 = snippet(callable_0)
        _test_snippet_get_body_body_0 = snippet_0.get_body()
    # End body of method get_body of class snippet
    _test_snippet_get_body()


# Generated at 2022-06-25 23:15:20.728649
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    callable_0 = None
    snippet_0 = snippet(callable_0)
    # snippet_0.get_body(*args, **kwargs)


# Generated at 2022-06-25 23:15:32.588062
# Unit test for function find_variables
def test_find_variables():
    assert [i for i in find_variables(
        ast.parse('let(a)\nlet(b)\nlet(c)'),
    )] == ['a', 'b', 'c']

    assert [i for i in find_variables(
        ast.parse('let(a)\nlet(b)\na + b\nlet(c)\n'),
    )] == ['a', 'b', 'c']



# Generated at 2022-06-25 23:15:39.436383
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(ast.parse("let(x) x += 1")) == ('x',)
    assert find_variables(ast.parse("""let(x)
let(y)
x += 1 """)) == ('x', 'y')
    assert find_variables(ast.parse("""let(x)
y = 1 """)) == ('x',)
    assert find_variables(ast.parse("""let(x)
x += 1
let(y)
y += 2 """)) == ('x', 'y')


# Generated at 2022-06-25 23:15:47.998240
# Unit test for function find_variables
def test_find_variables():
    callable_0 = None
    snippet_0 = snippet(callable_0)
    assert list(snippet_0._get_variables(snippet_0.get_body(), {})) == []
    assert list(snippet_0._get_variables(snippet_0.get_body(a=1), {})) == []
    assert list(snippet_0._get_variables(snippet_0.get_body(a=let), {})) == ['a']
    assert list(snippet_0._get_variables(snippet_0.get_body(a=let, b=let), {})) == ['a', 'b']


# Generated at 2022-06-25 23:15:52.953133
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    callable_0 = None
    var_0 = None
    snippet_0 = snippet(callable_0)

# Generated at 2022-06-25 23:16:03.967785
# Unit test for function extend_tree
def test_extend_tree():
    def check(tree, variables):
        expected = tree.copy()
        extend_tree(expected, variables)
        assert ast.dump(expected) == ast.dump(expected)

    tree1 = ast.parse("""
            extend(x)
            extend(y)
            extend(z)
            """)
    variables1 = {
        'x': ['x = 1', 'x = 2', 'x = 3'],
        'y': 'y = 2',
        'z': ['z = 3'],
    }

    check(tree1, variables1)

    tree2 = ast.parse("""
            a = 3
            extend(b)
            extend(c)
            extend(d)
            extend(e)
            extend(f)
            a = 1
            extend(g)
            """)
    variables2

# Generated at 2022-06-25 23:16:05.785673
# Unit test for function extend_tree
def test_extend_tree():
    callable_0 = None
    snippet_0 = snippet(callable_0)


# Generated at 2022-06-25 23:16:07.749826
# Unit test for function find_variables
def test_find_variables():
    assert find_variables.__annotations__ == {'tree': ast.AST, 'return': Iterable[str]}


# Generated at 2022-06-25 23:16:08.897947
# Unit test for function find_variables
def test_find_variables():
    pass


# Generated at 2022-06-25 23:16:12.104672
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    callable_0 = None
    snippet_0 = snippet(callable_0)
    snippet_0.get_body(None)
    assert True


# Generated at 2022-06-25 23:16:16.780783
# Unit test for function find_variables
def test_find_variables():
    callable_0 = None
    snippet_0 = snippet(callable_0)
    names_0 = find_variables(snippet_0)
    assert names_0 == []


# Generated at 2022-06-25 23:16:22.479464
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert 1

# Generated at 2022-06-25 23:16:33.328045
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def method_0():
        i = let(0)

    class_0 = snippet(method_0)
    result_0 = class_0.get_body()
    assert len(result_0) == 1
    assert result_0[0].lineno == 1
    assert result_0[0].col_offset == 0
    assert result_0[0].__class__.__name__ == 'Assign'
    assert len(result_0[0].targets) == 1
    assert result_0[0].targets[0].__class__.__name__ == 'Name'
    assert result_0[0].targets[0].id == '_py_backwards_i_0'
    assert result_0[0].value.__class__.__name__ == 'Num'

# Generated at 2022-06-25 23:16:41.322071
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class Class_0:
        def __init__(self):
            self.string_0 = ''
        
        def __str__(self):
            return self.string_0
        
    class_0 = Class_0()
    def func_0(arg_0: bool, arg_1: bool) -> bool:
        let(class_0)
        a = 1
        if arg_0:
            a = 3
        
        b = 2
        if arg_1:
            b = 4
        
        return a + b
    

# Generated at 2022-06-25 23:16:46.944939
# Unit test for function extend_tree
def test_extend_tree():
    from typed_ast import ast3 as ast
    from .tree import find, get_non_exp_parent_and_index, replace_at
    import unittest
    tree = 5
    variables = {'x': 'new_x'}
    extend_tree(tree, variables)
    try:
        tree
    except NameError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 23:16:49.075810
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 23:16:50.855939
# Unit test for function find_variables
def test_find_variables():
    a_s_t_1 = module_0.AST()
    iterable_1 = find_variables(a_s_t_1)


# Generated at 2022-06-25 23:16:55.076432
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    d_i_c_t_1 = {}
    s_n_i_p_p_e_t_0 = snippet(test_case_0)
    l_i_s_t_0 = s_n_i_p_p_e_t_0.get_body(**d_i_c_t_1)

# Generated at 2022-06-25 23:17:00.327346
# Unit test for function extend_tree
def test_extend_tree():
    class a_s_t_0(module_0.AST):
        class _fields(object):
            pass
    a_s_t_1 = a_s_t_0()
    l_s_t_0 = []
    l_s_t_1 = extend_tree(a_s_t_1, l_s_t_0)
    assert l_s_t_1 == None


# Generated at 2022-06-25 23:17:03.861123
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn_0(a_0, b_0=let(a_0)):
        pass
    s_n_i_p_0 = snippet(snippet_fn_0)
    s_n_i_p_0.get_body()


# Generated at 2022-06-25 23:17:05.339871
# Unit test for function extend_tree
def test_extend_tree():
    # TODO: Implement test
    raise Exception("Test not implemented for function extend_tree")


# Generated at 2022-06-25 23:17:17.746426
# Unit test for function extend_tree
def test_extend_tree():
    import typed_ast.ast3 as ast
    a_s_t_0 = ast.AST(body=[ast.Expr(value=ast.Call(func=ast.Name(id='let'), 
                               args=[ast.arg(arg='x', annotation=None), 
                                     ast.arg(arg='1', annotation=None)], 
                               keywords=[], starargs=None, kwargs=None))])
    extend_tree(a_s_t_0, {'x': ast.Name(id='2')})


# Generated at 2022-06-25 23:17:26.353846
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def function_0(arg_0, arg_1, arg_2=None):
        let(arg_0)
        let(arg_1)
        let(arg_2)
        arg_0 += arg_1
        arg_0 = arg_2
    
    snippet_0 = snippet(function_0)
    a_s_t_0 = module_0.parse('x = 1')
    a_s_t_1 = module_0.parse('x = 2')
    function_1 = snippet_0.get_body(arg_0=a_s_t_0, arg_1=a_s_t_1)
    assert function_1 == module_0.parse('x = 1\nx = 2').body

# Generated at 2022-06-25 23:17:36.713395
# Unit test for function extend_tree
def test_extend_tree():
    # Test 1: assert that extend_tree(tree, {}) do nothing
    module_1 = ast.Module(
    body=[
    ast.FunctionDef(
    name='test',
    args=ast.arguments(
    args=[],
    vararg=None,
    kwonlyargs=[],
    kw_defaults=[],
    kwarg=None,
    defaults=[],
    ),
    body=[
    ast.Return(
    value=ast.Num(
    n=0,
    ),
    ),
    ],
    decorator_list=[],
    returns=None,
    ),
    ],
    )
    variables_0: Dict[str, Variable] = dict()
    assert module_1 == extend_tree(module_1, variables_0)
    assert module_1 == module_1

# Generated at 2022-06-25 23:17:43.994869
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _fn():
        ys = [1, 2, 3]
        let(xs)
        xs.append(1)
        xs.append(2)
        xs.append(3)

    _fn()

    source = get_source(_fn)
    tree = ast.parse(source)
    variables = snippet._get_variables(tree, {})
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    assert(tree.body[0].body == snippet(_fn).get_body())

test_snippet_get_body()

# Generated at 2022-06-25 23:17:46.458948
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    extend_tree(a_s_t_0, {'a': 'b'})


# Generated at 2022-06-25 23:17:47.866831
# Unit test for function extend_tree
def test_extend_tree():
    tree_0 = ast.parse('a = 1')
    variables_0 = {'a': ast.parse('b = 1')}
    extend_tree(tree_0, variables_0)


# Generated at 2022-06-25 23:17:49.583889
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    dic_0 = dict({})
    extend_tree(a_s_t_0, dic_0)


# Generated at 2022-06-25 23:18:00.756208
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    i_t_e_0 = {}
    extend_tree(a_s_t_0, i_t_e_0)
    a_s_t_1 = module_0.AST()
    i_t_e_1 = {}
    extend_tree(a_s_t_1, i_t_e_1)
    a_s_t_2 = module_0.AST()
    i_t_e_2 = {}
    extend_tree(a_s_t_2, i_t_e_2)
    a_s_t_3 = module_0.AST()
    i_t_e_3 = {}
    extend_tree(a_s_t_3, i_t_e_3)
    a_

# Generated at 2022-06-25 23:18:01.844396
# Unit test for function extend_tree
def test_extend_tree():
    pass


# Generated at 2022-06-25 23:18:04.036375
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn_0(a_0, b_1):
        let(a_0)
        let(b_1)


# Generated at 2022-06-25 23:18:10.035612
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_1 = module_0.AST()
    d_i_c_t_0 = {'0': '0'}



# Generated at 2022-06-25 23:18:20.778970
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    d_i_c_t_0 = { }
    a_s_t_2 = module_0.AST()
    d_i_c_t_1 = { }
    a_s_t_3 = module_0.AST()
    d_i_c_t_2 = { }
    a_s_t_4 = module_0.AST()
    d_i_c_t_3 = { }
    a_s_t_5 = module_0.AST()
    d_i_c_t_4 = { }
    a_s_t_6 = module_0.AST()
    d_i_c_t_5 = { }
    a_

# Generated at 2022-06-25 23:18:31.541665
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = { }
    extend_tree(a_s_t_0, d_i_c_t_0)
    a_s_t_1 = module_0.AST()
    d_i_c_t_1 = { }
    extend_tree(a_s_t_1, d_i_c_t_1)
    a_s_t_2 = module_0.AST()
    d_i_c_t_2 = { }
    extend_tree(a_s_t_2, d_i_c_t_2)
    a_s_t_3 = module_0.AST()
    d_i_c_t_3 = { }

# Generated at 2022-06-25 23:18:39.933508
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source_0 = (
        "\n"
        "    let(x)\n"
        "    x += 1\n"
        "    y = 1\n"
        "    \n"
        "    "
    )
    a_s_t_1 = ast.parse(source_0)
    dict_0 = {
        "x":
        "_py_backwards_x_0"
    }
    a_s_t_2 = VariablesReplacer.replace(a_s_t_1, dict_0)
    a_s_t_3 = a_s_t_2.body[0]
    iterable_0 = a_s_t_3.body
    iterable_1 = iterable_0

# Generated at 2022-06-25 23:18:49.806489
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _function_0_0():
        pass


    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    s_t_0 = a_s_t_1.body
    s_n_0 = _function_0_0
    _function_0_0()
    _function_0_0(a_s_t_0, a_s_t_0)
    _function_0_0(a_s_t_0)
    _function_0_0(a_s_t_0, a_s_t_0)
    _function_0_0()
    _function_0_0()
    _function_0_0()
    s_n_0()

# Generated at 2022-06-25 23:18:54.703733
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test type just "for fun"
    s_n_i_p_p_e_t_0 = snippet(None)
    l_i_s_t_0 = s_n_i_p_p_e_t_0.get_body()
    assert type(l_i_s_t_0) == list
    assert type(l_i_s_t_0[0]) == ast.Assign

# Generated at 2022-06-25 23:18:58.681399
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _fn_0() -> None:
        let(x)
        x += 1
        y = 1
    c_l_s_s_0 = snippet(_fn_0)
    list_0 = c_l_s_s_0.get_body()
    expression_0 = list_0[0] # Assign



# Generated at 2022-06-25 23:19:03.806234
# Unit test for function extend_tree
def test_extend_tree():
    import ast
    from .tree import find
    from .runtime import extend
    from .helpers import eager
    from .snippet import extend as snippet_extend
    from .snippet import let as snippet_let


# Generated at 2022-06-25 23:19:12.190708
# Unit test for function extend_tree
def test_extend_tree():
    assert extend_tree(
        tree = ast.Module(body = []),
        variables = {'x': 1}
    ) == None, 'Failed test #0'
    assert extend_tree(
        tree = ast.Module(body = [ast.Expr(value = ast.Call(func = ast.Name(id = 'extend', ctx = ast.Load()), args = [ast.Name(id = 'x', ctx = ast.Load())], keywords = []))]),
        variables = {'x': 1}
    ) == None, 'Failed test #1'

# Generated at 2022-06-25 23:19:23.051974
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class Class:
        def method (self, arg1:int, arg2:int) -> None:
            a = None
            let(a)
            a += 1
            b = 1
            print(b, a)
    class_0 = Class()
    method_0 = class_0.method
    snippet_0 = snippet(method_0)
    result_0 = snippet_0.get_body()
    assert len(result_0) == 2
    assert isinstance(result_0[0], module_0.Assign)
    assert isinstance(result_0[1], module_0.Expr)
    assert isinstance(result_0[0].targets[0], module_0.Name)
    assert isinstance(result_0[0].value, module_0.Add)

# Generated at 2022-06-25 23:19:39.948655
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source_0 = get_source(((lambda test_case_0: (test_case_0.getSource()))))
    source_1 = source_0.replace("test_case_0", "x")
    a_s_t_0 = ast.parse(source_1)
    iterable_0 = find_variables(a_s_t_0)
    string_0 = "x"
    object_0 = iterable_0[string_0]
    a_s_t_1 = ast.parse((("x=1;").replace("x=1;", "x = 1")))
    string_1 = ""
    object_1 = a_s_t_1.body[string_1]
    function_0 = VariablesReplacer.replace(object_1, object_0)



# Generated at 2022-06-25 23:19:47.577545
# Unit test for function extend_tree
def test_extend_tree():
    class a_s_t_0(object):
        body = ()
        def visit_0(self, node):
            return node
    a_s_t_1 = a_s_t_0()
    a_s_t_2 = a_s_t_0()
    a_s_t_3 = a_s_t_0()
    a_s_t_1.body = ()
    extend_tree(a_s_t_2, {a_s_t_0(): a_s_t_1})
    extend_tree(a_s_t_3, {a_s_t_0(): a_s_t_1})


# Generated at 2022-06-25 23:19:49.105261
# Unit test for method get_body of class snippet

# Generated at 2022-06-25 23:19:54.196465
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def instance_0(x_0, y_0):
        let(x_0)
        let(y_0)
        x_0 = 1
        x_0 = 2
        y_0 = 3
    instance_0(1, 2)
    s_n_i_p_p_e_t_0 = snippet(instance_0)
    a_s_t_0 = module_0.AST()
    i_t_e_r_a_b_l_e_0 = find_variables(a_s_t_0)



# Generated at 2022-06-25 23:19:59.594816
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = test_snippet_get_body_d_i_c_t_0()
    body_0 = snippet(test_snippet_get_body_f_n_0).get_body(**d_i_c_t_0)


# Generated at 2022-06-25 23:20:03.783738
# Unit test for function extend_tree
def test_extend_tree():
    # Given
    a_s_t_0 = module_0.AST()
    d_i_c_0 = {"key_0": a_s_t_0}
    # When
    extend_tree(a_s_t_0, d_i_c_0)
    # Then


# Generated at 2022-06-25 23:20:08.651360
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn_0() -> None:
        let('x_1')
        let('y_0')
        x_1 += 1
        y_0 = 1

    test_snippet_get_body_0 = snippet(fn_0)
    a_s_t_0 = test_snippet_get_body_0.get_body()

test_snippet_get_body()

# Generated at 2022-06-25 23:20:09.761036
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class_0 = snippet(test_case_0)


# Generated at 2022-06-25 23:20:14.914961
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    module_0 = ast.__dict__
    class_0 = snippet
    object_0 = class_0(lambda: None)
    module_1 = ast.__dict__
    class_1 = ast.Module
    object_1 = class_1()
    object_0._fn = ast.parse
    object_0.get_body()
    object_0._fn = ast.parse
    object_0.get_body(a=ast.Name('arg', ast.Load()))
    object_0._fn = ast.parse
    object_0.get_body(a=ast.Name('arg', ast.Load()), b=ast.Name('arg', ast.Load()))
    object_0._fn = ast.parse

# Generated at 2022-06-25 23:20:27.579106
# Unit test for function extend_tree
def test_extend_tree():
    import random
    import ast


# Generated at 2022-06-25 23:20:44.354651
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def foo():
        let(x)
        x += 1
        y = 1
    import ast
    import astor
    snip = snippet(foo)
    first = snip.get_body()[0]
    assert isinstance(first, ast.AugAssign)

# Generated at 2022-06-25 23:20:54.662090
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    a_s_t_1 = module_0.AST()
    iterable_1 = find_variables(a_s_t_1)
    a_s_t_2 = module_0.AST()
    iterable_2 = find_variables(a_s_t_2)
    a_s_t_3 = module_0.AST()
    iterable_3 = find_variables(a_s_t_3)
    a_s_t_4 = module_0.AST()
    iterable_4 = find_variables(a_s_t_4)

import typing as module_1

# Generated at 2022-06-25 23:21:05.032188
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f_0(str_0: str, num_0: int) -> None:
        num_0 = 1
        a_s_t_0 = ast.parse("let(x)")
        a_s_t_1 = ast.parse("let(y)")
        dic_0 = {'x': a_s_t_0.body[0].args[0].id,
                 'y': a_s_t_1.body[0].args[0].id}
        dic_1 = {'x': dic_0}
        a_s_t_2 = VariablesReplacer.replace(a_s_t_0, dic_1)
        print(dic_0['x'])
        a_s_t_3 = ast.parse('print(x)')
        dic

# Generated at 2022-06-25 23:21:10.528436
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def a_s_t_0():
        let(x)
        x += 1
        y = 1
    
    a_s_t_1 = ast.parse(get_source(a_s_t_0))
    a_s_t_2 = a_s_t_1.body[0].body
    
    snippet_0 = snippet(a_s_t_0)
    a_s_t_3 = snippet_0.get_body()
    a_s_t_4 = a_s_t_3 == a_s_t_2
    
    assert a_s_t_4

# Generated at 2022-06-25 23:21:16.282406
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def some_snippet(**kwargs):
        let(x)
        x += 1
        y = 1
        extend(vars)
        print(x, y)

    var = some_snippet.get_body(vars=[])
    print(var)

if __name__ == '__main__':
    test_case_0()
    test_snippet_get_body()

# Generated at 2022-06-25 23:21:26.024297
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import os
    import sys
    import builtins
    import types

    p = os.path.join(os.path.dirname(sys.executable), "pip")
    # Python 2
    py2 = p + "2"
    py2_exists = os.path.isfile(py2)
    if not py2_exists:
        py2 = p + "2.7"
        py2_exists = os.path.isfile(py2)
    # Python 3
    py3 = p + "3"
    py3_exists = os.path.isfile(py3)
    if not py3_exists:
        py3 = p + "3.6"
        py3_exists = os.path.isfile(py3)


# Generated at 2022-06-25 23:21:26.862897
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Check get_body function
    pass

# Generated at 2022-06-25 23:21:33.855181
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def my_fn():
        let(x)
        extend(vars)
        return x + z + y

    my_snippet = snippet(my_fn)
    body = my_snippet.get_body(x=1, y=2, z=3, vars=['print(z)'])
    assert body == [
        ast.Expr(
            ast.Call(
                func=ast.Name(
                    id='print',
                    ctx=ast.Load()
                ),
                args=[ast.Name(
                    id='z',
                    ctx=ast.Load()
                )],
                keywords=[],
                starargs=None,
                kwargs=None
            )
        ),
    ]


# Generated at 2022-06-25 23:21:38.638688
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_0(update):
        let(update)
        update += 1
        c = 1
        return c
    snippet_0_instance = snippet(snippet_0)
    snippet_0_get_body_call_result_0 = snippet_0_instance.get_body(update=1)

# Generated at 2022-06-25 23:21:41.273835
# Unit test for function extend_tree
def test_extend_tree():
    # Arguments
    a_s_t_0 = module_0.AST()
    variables_0 = {}
    extend_tree(a_s_t_0, variables_0)


# Generated at 2022-06-25 23:21:56.947767
# Unit test for function extend_tree
def test_extend_tree():
    assert type(extend_tree(1, 2)) is None


# Generated at 2022-06-25 23:22:02.278292
# Unit test for function extend_tree
def test_extend_tree():
    from .test_cases.test_1 import expected_tree, source
    tree = ast.parse(source)
    extend_tree(tree, {
        "fn": [(ast.Expr(value=ast.Str(s="foo")))]
    })

    ast.dump(tree, include_attributes=True, annotate_fields=False) == \
    ast.dump(expected_tree, include_attributes=True, annotate_fields=False)


# Generated at 2022-06-25 23:22:11.738573
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet_get_body_body():
        # Calls to let
        let(x)
        let(y)
        # Calls to extend
        extend(vars)
        extend(more)
        # Body
        print(x, y)
    import ast
    import astor
    class Test(snippet):
        def __get_body(self, **snippet_kwargs):
            return self.get_body(**snippet_kwargs)
    test_0 = Test(test_snippet_get_body_body)
    vars = [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1))]

# Generated at 2022-06-25 23:22:23.044785
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def t_e_s_t_0(arg1 = None, arg2 = None):
        print("a")
    a_s_t_0 = {'arg1': 1, 'arg2': 2}
    s_n_i_p_p_e_t_0 = snippet(t_e_s_t_0)
    s_n_i_p_p_e_t_1 = s_n_i_p_p_e_t_0.get_body(**a_s_t_0)

# Generated at 2022-06-25 23:22:29.649231
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    dict_0 = {(module_0.Name()): (module_0.Name())}
    extend_tree(a_s_t_0, dict_0)
    dict_1 = {(module_0.Name()): [module_0.Name()]}
    extend_tree(a_s_t_0, dict_1)


# Generated at 2022-06-25 23:22:32.624981
# Unit test for function find_variables
def test_find_variables():
    begin_unit_test(__name__, test_find_variables.__name__)
    test_case_0()
    end_unit_test()


# Generated at 2022-06-25 23:22:38.929557
# Unit test for function extend_tree
def test_extend_tree():
    from .tree import find, replace_at
    from .helpers import get_source

    def test_fn(a, b):
        extend(b)
        print(a)

    tree = ast.parse(get_source(test_fn))
    b = ast.parse('''
    print(2)
    print(3)
    ''').body
    extend_tree(tree, {'b': b})
    assert len(find(tree, ast.Print)['node']) == 3

# Generated at 2022-06-25 23:22:45.712673
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = "def s_n_i_p_p_e_t_0():\n   let(v_a_r_0)\n   v_a_r_0 += 1\n   v_a_r_1 = 1"
    tree_0 = ast.parse(source)
    snippet_kwargs_0 = {}
    variables_0 = {'v_a_r_0': '_py_backwards_v_a_r_0_0', 'v_a_r_1': '_py_backwards_v_a_r_1_0'}
    extend_tree(tree_0, variables_0)
    body_0 = tree_0.body[0].body

# Generated at 2022-06-25 23:22:49.857198
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = {str: str}
    extend_tree(a_s_t_0, d_i_c_t_0)


# Generated at 2022-06-25 23:22:52.338314
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    assert True

# Generated at 2022-06-25 23:23:09.567872
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    ast_0 = a_s_t_0
    module_0.extend_tree(ast_0)
    dict_0 = dict()
    module_0.extend_tree(ast_0, dict_0)


# Generated at 2022-06-25 23:23:15.991004
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def function_0():
        let(x)
        x += 1
        y = 1
    snippet_0 = snippet(function_0)
    a_s_t_0 = snippet_0.get_body(x=1)

    def function_1():
        extend(vars)
        print(x, y)
    snippet_1 = snippet(function_1)
    a_s_t_1 = snippet_1.get_body(vars=2)

    def function_2():
        let(x)
        x += 1
        y = 1
    snippet_2 = snippet(function_2)
    a_s_t_2 = snippet_2.get_body(x=[2, 3])


# Generated at 2022-06-25 23:23:19.561711
# Unit test for function extend_tree
def test_extend_tree():
    """
    Tests if extening tree works as expected
    """

    def fn():
        extend(x)
        x

    body = snippet(fn).get_body(x=['a', 'b'])
    assert body[0].value.elts[0].value.id == 'a'
    assert body[0].value.elts[1].value.id == 'b'


# Generated at 2022-06-25 23:23:24.999479
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    class_0 = snippet(a_s_t_0)
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    d_i_c_0 = {}
    d_i_c_0["x"] = a_s_t_2
    d_i_c_0["y"] = "1"
    list_0 = class_0.get_body(**d_i_c_0)

# Generated at 2022-06-25 23:23:34.026191
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    string_0 = "x = 1"
    module_0 = ast.parse(string_0, "string_0")
    a_s_t_1 = module_0.body[0]
    a_s_t_2 = module_0.body[0].value
    a_s_t_3 = module_0.body[0].targets[0]
    d_i_c_t_0 = {'a': a_s_t_1, 'b': a_s_t_2, 'c': a_s_t_3, }
    snippet_0 = snippet(test_case_0)
    string_1 = "x = 1"
    module_1 = ast.parse(string_1, "string_1")
    a_s_t_4 = module_1.body[0]

# Generated at 2022-06-25 23:23:42.815155
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    # Parameterized tests

    @snippet
    def add_to_argument(x):
        let(y)
        y += 1
        return x + y

    assert isinstance(add_to_argument.get_body(), list)

    @snippet
    def add_to_argument_with_kwargs(x):
        let(y)
        y += 1
        return x + y

    assert isinstance(add_to_argument_with_kwargs.get_body(y = 'foo'), list)

    @snippet
    def add_to_two_arguments(x, y):
        let(z)
        z += 1
        return x + y + z

    assert isinstance(add_to_two_arguments.get_body(), list)


# Generated at 2022-06-25 23:23:43.718440
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # TODO
    return


# Generated at 2022-06-25 23:23:45.199072
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    extend_tree(a_s_t_0, {})


# Generated at 2022-06-25 23:23:53.353029
# Unit test for function extend_tree
def test_extend_tree():
    import _py_backwards_module_0 as module_0
    module_1 = module_0.module()
    
    a_s_t_4 = module_1.a_s_t()
    a_s_t_4.body = [module_1.function_def_0(), module_1.function_def_1()]
    a_s_t_5 = module_1.a_s_t()
    a_s_t_5.body = [module_1.function_def_2(), module_1.function_def_3()]
    extend_tree(a_s_t_4, {'_src_var_0': a_s_t_5})

# Generated at 2022-06-25 23:23:55.803984
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    extend_tree(a_s_t_0, {'a': module_0.Name(id='a')})
