

# Generated at 2022-06-25 23:14:35.480503
# Unit test for function find_variables
def test_find_variables():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    variables = find_variables(tree)
    assert str_0 in variables



# Generated at 2022-06-25 23:14:44.974204
# Unit test for function find_variables
def test_find_variables():
    '''
    Test that find_variables function works properly
    '''
    let_str1 = 'QaE\x7f\x0b!\xc7\x80\xc0h\xbf\xa8\x0e\x0cJX\xdd\x11\x7f\xa3\xaa\xd2\x8c\xd0\x17\x9e'
    let(let_str1)
    let_str2 = '\xd8\x14,\x11\r\xb9\xba\x1bm/\x1e\x1b\x16\x0c\x96\xc9\x9e)&\xbe\xb7\x1c\x0b0\x8d'
    let(let_str2)
    let_str

# Generated at 2022-06-25 23:14:50.610270
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    expected_result = [
        ast.Assign([ast.Name(id='__py_backwards_str_0', ctx=ast.Store())],
                   ast.Str(s='esNfnD\tRxgP[;AJC', kind=None)),
    ]
    x = snippet(test_case_0)
    expected_result = [
        ast.Assign([ast.Name(id='__py_backwards_str_0', ctx=ast.Store())],
                   ast.Str(s='esNfnD\tRxgP[;AJC', kind=None)),
    ]
    assert x.get_body() == expected_result


# Generated at 2022-06-25 23:14:55.163611
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import get_body

    source = get_source(test_case_0)
    tree = ast.parse(source)
    snippet_fn = get_body(tree.body[0].body[0], 'let')
    snippet_fn(str_0=42)



# Generated at 2022-06-25 23:14:59.715177
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Declaring snippet, where body is function:
    @snippet
    def snippet_0():
        # Declaring variables what will be available in snippet_0.
        test_case_0()
    # Getting AST of body of snippet_0.
    body = snippet_0.get_body()
    # And comparing strings of generated code with expected one.
    assert get_source(body) == "test_case_0()"

# Generated at 2022-06-25 23:15:09.826632
# Unit test for function extend_tree
def test_extend_tree():
    var_1 = [ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
             ast.Assign([ast.Name('y', ast.Store())], ast.Num(2))]
    var_2 = 'E@}\\b^9Wr`R<8Y=K'
    source = get_source(test_case_0)
    tree = ast.parse(source)
    variables = {
        'str_0': VariablesGenerator.generate(str_0),
        'var_1': var_1,
        'var_2': var_2
    }
    extend_tree(tree, variables)
    assert tree.body[0].body[0].targets[0].id == 'str_0'

# Generated at 2022-06-25 23:15:14.671205
# Unit test for function find_variables
def test_find_variables():
    import astunparse
    tree = ast.parse('let(a)\nlet(b)')
    variables = find_variables(tree)
    assert(list(variables) == ['a', 'b'])
    assert(astunparse.unparse(tree) == '\n')


# Generated at 2022-06-25 23:15:16.882538
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    let(str_0)
    expected_result = []
    actual_result = snippet(test_case_0).get_body()

    assert expected_result == actual_result

# Generated at 2022-06-25 23:15:20.406556
# Unit test for function extend_tree
def test_extend_tree():

    tree = ast.parse('x = 1')
    tree_2 = ast.parse('y = 2')
    extend_tree(tree, {'x': tree_2})

    assert tree.body[0].value.value.body[0].value.value.value == 2



# Generated at 2022-06-25 23:15:25.841759
# Unit test for function extend_tree
def test_extend_tree():
    source = '''
let(x)
vars = {
    x: 'abc'
}
extend(vars)
z = 'def'
    '''
    tree = ast.parse(source)
    extend_tree(tree, {'vars': {}})
    VariablesReplacer.replace(tree, {})
    assert(str(tree) == '''
if 1:
    z = 'def'
    ''')



# Generated at 2022-06-25 23:15:36.326311
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet1 = snippet(test_case_0)
    snippet1.get_body()
    # Check types of the variables here
    assert isinstance(var_0, list)
    # Check the value of the variables
    assert var_0 == []


# Generated at 2022-06-25 23:15:46.502510
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    # 1 - Global 'from math import *'
    from math import *
    # 1 - Global 'import math'
    import math
    # 1 - Global 'from math import pi'
    from math import pi
    # 1 - Global 'from math import e'
    from math import e
    # 1 - Global 'from math import asin'
    from math import asin
    # 1 - Global 'from math import asinh'
    from math import asinh
    # 1 - Global 'from math import acos'
    from math import acos
    # 1 - Global 'from math import acosh'
    from math import acosh
    # 1 - Global 'from math import atan'
    from math import atan
    # 1 - Global 'from math import atanh'
    from math import atanh
    # 1 - Global 'from

# Generated at 2022-06-25 23:15:52.183035
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .check import Check

    c = Check()
    assert c.check_function(snippet.get_body, 1) == c.refute

    snippet_q3 = snippet(test_case_0)
    c.set_context(snippet_q3=snippet_q3)
    assert c.check_function(snippet_q3.get_body) == [
        c.assign_to_name(
            ast.Assign(
                targets=[
                    ast.Name(id='var_0', ctx=ast.Store())
                ],
                value=ast.List(elts=[], ctx=ast.Load())
            ),
            'var_0'
        ),
    ]


# Generated at 2022-06-25 23:15:53.432527
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast

    obj = VariablesReplacer({})
    node = ast.alias(name = 'name', asname = 'asname')
    obj.visit_alias(node)



# Generated at 2022-06-25 23:16:04.225716
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import unittest

    from typed_ast import ast3 as ast

    from .helpers import VariablesGenerator

    class VariablesReplacer(ast.NodeTransformer):
        def __init__(self, variables: Dict[str, Variable]) -> None:
            self._variables = variables

        def _replace_field_or_node(self, node: T, field: str, all_types=False) -> T:
            value = getattr(node, field, None)
            if value in self._variables:
                if isinstance(self._variables[value], str):
                    setattr(node, field, self._variables[value])
                elif all_types or isinstance(self._variables[value], type(node)):
                    node = self._variables[value]  # type: ignore

            return node



# Generated at 2022-06-25 23:16:10.399619
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    tree = snippet(test_case_0).get_body()
    assert isinstance(tree, list)
    assert len(tree) == 1
    assert isinstance(tree[0], ast.Assign)
    assert len(tree[0].targets) == 1
    assert isinstance(tree[0].targets[0], ast.Name)
    assert isinstance(tree[0].value, ast.List)
    assert len(tree[0].value.elts) == 0

# Generated at 2022-06-25 23:16:20.395663
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    alias_0 = ast.alias()
    alias_0.name = "module_0"
    alias_0.asname = None

    alias_1 = ast.alias()
    alias_1.name = "module_1"
    alias_1.asname = None

    alias_2 = ast.alias()
    alias_2.name = "module_2"
    alias_2.asname = None

    aliases_0 = [
        alias_0,
        alias_1,
        alias_2
    ]

    module_0 = ast.Module()
    module_0.body = [
        ast.ImportFrom(
            module = "module_0",
            names = aliases_0
        )
    ]

    module_1 = ast.Module()

# Generated at 2022-06-25 23:16:24.269151
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Calls get_body with following arguments
    # args and kwargs are bound to object snippet
    # returns AST node of body of function test_case_0
    return snippet(test_case_0).get_body()



# Generated at 2022-06-25 23:16:36.496643
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from astroid import nodes, scoped_nodes
    from astroid import MANAGER
    from astroid import builder as b
    from astroid import parse

    from .helpers import VariablesGenerator, VariablesReplacer
    v = VariablesGenerator()
    var_1 = v.generate('var_1')

    builder = b.Builder(MANAGER)
    module = parse('''
from os import path
import tensorflow as tf
''')
    var_1_alias = module.body[0].names[0]
    var_2_alias = module.body[1].names[0]
    alias_node = scoped_nodes.Alias(var_1, name=var_1_alias.name, asname=var_1_alias.name)
    alias_node_2 = scoped_n

# Generated at 2022-06-25 23:16:39.880836
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert test_case_0(snippet(test_case_0).get_body()) == None

# Generated at 2022-06-25 23:16:47.238165
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = ast.parse('')
    snippet_instance_0 = snippet(lambda : None)
    expected_0 = list()
    actual_0 = snippet_instance_0.get_body(arg_0=a_s_t_0)
    assert expected_0 == actual_0


# Generated at 2022-06-25 23:16:50.015005
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def function_0():
        let(x)
        x += 1
        y = 1
    
    function_0_get_body_result = function_0.get_body()


# Generated at 2022-06-25 23:16:50.855928
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    pass


# Generated at 2022-06-25 23:16:54.737455
# Unit test for function extend_tree
def test_extend_tree():
    assert __name__ == '__builtin__'
    import py_backwards.code
    snippet = py_backwards.code.snippet(extend_tree)
    a_s_t_0 = snippet.get_body()
    assert __name__ == '__builtin__'



# Generated at 2022-06-25 23:17:03.333559
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _snippet_fn_get_body_0(a_s_t_0: ast.AST, **kwargs: Variable) -> List[ast.AST]:
        a_s_t_0 = let(a_s_t_0)
        return a_s_t_0

    a_s_t_0 = ast.parse('x=1')
    kwargs_0 = {'a_s_t_0': a_s_t_0}
    snippet_instance_get_body_0 = snippet(_snippet_fn_get_body_0)
    snippet_fn_get_body_0 = snippet_instance_get_body_0.get_body(**kwargs_0)


# Generated at 2022-06-25 23:17:12.327127
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _snippet_0(var_0: int, var_1: int):
        let(var_0)
        var_1 = var_1
    # body_0
    assert _snippet_0.get_body(var_0=1, var_1=1) == [
        ast.Assign(
            targets=[ast.Name(id='_py_backwards_var_0_0', ctx=ast.Store())],
            value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='var_1', ctx=ast.Store())],
                    value=ast.Name(id='_py_backwards_var_0_0', ctx=ast.Load()))]

# Generated at 2022-06-25 23:17:23.010201
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    v_a_r_i_a_b_l_e_0 = 1
    v_a_r_i_a_b_l_e_1 = 1
    v_a_r_i_a_b_l_e_2 = 1
    v_a_r_i_a_b_l_e_3 = find_variables(v_a_r_i_a_b_l_e_2)
    v_a_r_i_a_b_l_e_4 = 1
    v_a_r_i_a_b_l_e_5 = 1
    v_a_r_i_a_b_l_e_6 = 1
    v_a_r_i_a_b_l_e_7 = 1
    v_a_r_i_

# Generated at 2022-06-25 23:17:24.539783
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = None
    a_s_t_1 = None
    iterable_0 = snippet.get_body(a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 23:17:26.062393
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def method(a):
        let(x)
        print(x)
    
    instance = snippet(method)
    instance.get_body(x=1)


# Generated at 2022-06-25 23:17:36.416467
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import assert_equal
    from .tree import print_ast

    @snippet
    def snippet_get_body():
        let(x)
        x += 1
        y = 1

    assert_equal(snippet_get_body.get_body(), [
        ast.AugAssign(target=ast.Name('_py_backwards_x_0', ctx=ast.Load()), op=ast.Add(), value=ast.Num(1)),
        ast.Assign(targets=[ast.Name('y', ctx=ast.Store())], value=ast.Num(1))
    ])

    @snippet
    def snippet_get_body_1(x: ast.AST):
        let(x)
        x += 1
        y = 1


# Generated at 2022-06-25 23:17:42.512348
# Unit test for function find_variables
def test_find_variables():
    assert test_case_0() == ()



# Generated at 2022-06-25 23:17:51.205510
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _var_0():
        return "a"
    def _var_1():
        return "b"
    def _var_2():
        return "c"
    def _var_3():
        return "d"
    def _var_4():
        return "e"
    def _var_5():
        return "f"
    def _var_6():
        return "g"
    def _var_7():
        return "h"
    def _var_8():
        return "i"
    def _var_9():
        def f():
            # [
            let(x)
            x = 5
            # ]
            return x
        return f()
    def _var_10():
        return "k"
    def _var_11():
        return "l"

# Generated at 2022-06-25 23:18:03.537394
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f_0():
        let(x)
        x += 1
    #
    #  Call: snippet(f_0).get_body()
    #  Expected result: [Assign([Name(_py_backwards_x_0, Load()]
    #, BinOp(Name(_py_backwards_x_0, Load()), Add(), Num(1,)))]
    #
    #
    #
    #  Call: snippet(f_0).get_body(x=y)
    #  Expected result: [Assign([Name(_py_backwards_x_0, Load()]
    #, BinOp(Name(y, Load()), Add(), Num(1,)))]
    #
    #
    #
    #  Call: snippet(f_0).get_body(x=x)
   

# Generated at 2022-06-25 23:18:06.001989
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0_0 = None
    body_0 = snippet(test_case_0).get_body(a_s_t_0=a_s_t_0_0)



# Generated at 2022-06-25 23:18:17.193964
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)
    a_s_t_0 = None
    snippet_kwargs_0 = {}
    variables_0 = snippet_0._get_variables(a_s_t_0, snippet_kwargs_0)
    body_0 = snippet_0.get_body(**snippet_kwargs_0)

# Generated at 2022-06-25 23:18:23.318100
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(None)
    get_body_of_snippet_0 = snippet_0.get_body(var_for_snippet_0=None)
    assert get_body_of_snippet_0 == []


# Generated at 2022-06-25 23:18:27.626540
# Unit test for function find_variables
def test_find_variables():
    import pytest
    from test_helper import get_ast
    a_s_t_0 = get_ast("let(x);")
    iterable_0 = find_variables(a_s_t_0)
    for val in iterable_0:
        assert False, "Unreachable"


# Generated at 2022-06-25 23:18:31.303177
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(y)
        y += 1
        x = 1
    snippet_0 = snippet(test_fn)
    snippet_kwargs_0 = None
    t = snippet_0.get_body(**snippet_kwargs_0)


# Generated at 2022-06-25 23:18:40.211801
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test case 0
    def a_s_t_0():
        a_s_t_0 = None

    def s_n_i_p_p_e_t_0(a_s_t_0):
        def s_n_i_p_p_e_t_0():
            a_s_t_0 = None
            s_n_i_p_p_e_t_0 = snippet(s_n_i_p_p_e_t_0)
            c_a_s_e_0 = s_n_i_p_p_e_t_0.get_body(a_s_t_0=a_s_t_0)
            return c_a_s_t_0(a_s_t_0, c_a_s_e_0)

# Generated at 2022-06-25 23:18:42.013749
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_fn_0() -> str:
        let(a_s_t_0)


# Generated at 2022-06-25 23:18:54.633096
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_param_0 = None
    snippet_0 = snippet(lambda: None)
    result_0 = snippet_0.get_body(**test_param_0)


# Generated at 2022-06-25 23:18:59.261410
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def place_holder_s_n_i_p_p_e_t_0():
        let(x)
        return x
    s_n_i_p_p_e_t_0 = snippet(place_holder_s_n_i_p_p_e_t_0)
    a_s_t_0 = s_n_i_p_p_e_t_0.get_body()

# Generated at 2022-06-25 23:19:02.686730
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = None
    dict_0 = {'a': 1, 'b': 2}
    extend_tree(a_s_t_0, dict_0)


# Generated at 2022-06-25 23:19:04.262127
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)
    snippet_0.get_body()

# Generated at 2022-06-25 23:19:10.423737
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    __var = 1
    def fn(__var: int) -> None:
        __var = 1
        a = let(__var)
        a += 1
    s_n_i_p_p_e_t_0 = snippet(fn)
    b_o_d_y_0 = s_n_i_p_p_e_t_0.get_body()
    # Should get parse tree of body of snippet with replaced variables
    assert b_o_d_y_0 == ast.parse("a += 1\n").body


# Generated at 2022-06-25 23:19:17.437029
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(a)
        a_1 = 5
        return a_1

    test_object_0 = snippet(test_fn)
    assert test_object_0.get_body() == [ast.Assign(targets=[ast.Name(id='_py_backwards_a_0', ctx=ast.Store())],
                                                  value=ast.Num(n=5)),
                                        ast.Return(value=ast.Name(id='_py_backwards_a_0', ctx=ast.Load()))]

# Generated at 2022-06-25 23:19:21.732197
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = None
    extend_tree(a_s_t_0, {'name': 42})

# Generated at 2022-06-25 23:19:23.984644
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(a)\nlet(b)')
    assert list(find_variables(tree)) == ['a', 'b']


# Generated at 2022-06-25 23:19:29.621265
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    _snippet_get_body_snippet_0 = snippet(
    )  # type: snippet
    ast_0 = None  # type: ast.AST
    _snippet_get_body_snippet_0 = _snippet_get_body_snippet_0.get_body(
        ast_0)  # type: List[ast.AST]


_snippet_0 = snippet(
)  # type: snippet
_snippet_get_body_1 = _snippet_0.get_body(
)  # type: List[ast.AST]

# Generated at 2022-06-25 23:19:32.532478
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Creating an instance of class snippet
    snippet_0 = snippet(test_case_0)
    # Calling method get_body of class snippet with kwargs:
    # {}
    a_s_t_1 = snippet_0.get_body()

# Generated at 2022-06-25 23:19:57.926122
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_0():
        let(x)
        let(x)
        extend(y)
        return x
    
    x = None
    y = None
    body = snippet_0.get_body(x=x, y=y)
    assert(body == [ast.Expr(value=None), ast.Return(value=x)])


# Generated at 2022-06-25 23:20:08.418534
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # checking for the case when fn is a function
    def function_0(*args, **kwargs):
        a_s_t_0 = None
        return a_s_t_0
    snippet_0 = snippet(function_0)
    key = None
    value = None
    snippet_kwargs = {key: value}
    snippet_0.get_body(**snippet_kwargs)
    # checking for the case when fn is a function
    def function_1(*args, **kwargs):
        a_s_t_1 = None
        return a_s_t_1
    snippet_1 = snippet(function_1)
    key = None
    value = None
    snippet_kwargs = {key: value}
    snippet_1.get_body(**snippet_kwargs)

# Generated at 2022-06-25 23:20:14.288246
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn():
        let(x)
        extend(vars)
        y = x + 1


# Generated at 2022-06-25 23:20:27.532634
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0():
        a_s_t_0 = None
        iterable_0 = find_variables(a_s_t_0)

        assert isinstance(iterable_0, Iterator)
        assert isinstance(iterable_0, Iterable)
        assert isinstance(iterable_0, Iterator)
        assert isinstance(iterable_0, Iterable)

    def test_case_1():
        a_s_t_0 = None
        vars_0 = {'x': ast.Name('y', ast.Load())}
        variables_0 = {'x': 'y'}

        assert isinstance(variables_0, dict)
        assert isinstance(variables_0, Mapping)
        assert isinstance(variables_0, Mapping)

# Generated at 2022-06-25 23:20:28.282544
# Unit test for method get_body of class snippet

# Generated at 2022-06-25 23:20:37.465204
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = [ast.BinOp(ast.Name('x', ast.Store()), ast.Add(), ast.Num(1))]
    a_s_t_1 = {'x': ast.Name('x', ast.Store())}
    a_s_t_2 = snippet.get_body(a_s_t_0, a_s_t_1)
    assert a_s_t_2 == [ast.BinOp(ast.Name('x', ast.Store()), ast.Add(), ast.Num(1))]

# Generated at 2022-06-25 23:20:43.964364
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def value(x):
        let(a)
        let(b)
        extend(a_s_t_0)
        return x
    snippet_0 = snippet(value)
    variables_0 = {'b': 1}
    body_0 = snippet_0.get_body(a_s_t_0=a_s_t_0, **variables_0)
    names_0 = find_variables(body_0)
    assert len(names_0) == 2

# Generated at 2022-06-25 23:20:49.411987
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = None
    iterable_0 = find_variables(a_s_t_0)
    string_0 = 'extend'
    a_s_t_1 = None
    a_s_t_0 = a_s_t_0.body[0].body
    a_s_t_2 = extend(a_s_t_1)

# Generated at 2022-06-25 23:20:59.785297
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class snippet_0(snippet):
        def __init__(self) -> None:
            a_s_t_0 = None
            get_source_0 = get_source(a_s_t_0)
            a_s_t_1 = ast.parse(get_source_0)
            snippet_kwargs_0 = None
            find_variables_0 = find_variables(a_s_t_0)
            variables_generator_generate_0 = VariablesGenerator.generate(find_variables_0)
            variables_0 = None
            extend_tree_0 = extend_tree(a_s_t_0, variables_0)
            variables_replacer_replace_0 = VariablesReplacer.replace(a_s_t_0, variables_0)

# Generated at 2022-06-25 23:21:03.454521
# Unit test for function find_variables
def test_find_variables():
    print('Test find_variables')
    a_s_t = ast.parse('let(a); a+b')
    assert len(list(find_variables(a_s_t))) == 1


# Generated at 2022-06-25 23:22:09.523038
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _py_let_0():
        _py_backwards_a_s_t_0 = None
        iterable_0 = find_variables(_py_backwards_a_s_t_0)
        iterable_0 = eager(iterable_0)
        var_0 = iterable_0.next()
        var_1 = get_source(_py_let_0)
        var_2 = ast.parse(var_1)
        var_2 = VariablesReplacer.replace(var_2, {'a_s_t_0': None}) # type: ignore
        var_3 = var_2.body[0].body


# Generated at 2022-06-25 23:22:14.766595
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import VariablesGenerator

    @snippet
    def fn_0():
        let(x)
        print(x)
    assert fn_0.get_body(x=123) == [
        ast.Expr(
            value=ast.Call(
                func=ast.Name(id='print', ctx=ast.Load()),
                args=[ast.Name(id=VariablesGenerator._generate('x'), ctx=ast.Load())],
                keywords=[],
                starargs=None,
                kwargs=None
            )
        ),
    ]

# Generated at 2022-06-25 23:22:20.061623
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _py_backwards_add_parentheses__0(a_0, b_0):
        a_0 = int(a_0)
        b_0 = int(b_0)
        return a_0 + b_0

    snippet_0 = _py_backwards_add_parentheses__0
    a_0 = 1
    b_0 = 2
    snippet_kwargs_0 = {'a_0': a_0, 'b_0': b_0}
    _py_backwards_snippet_0 = snippet_0
    _py_backwards_names_0 = find_variables(_py_backwards_snippet_0.__code__)

# Generated at 2022-06-25 23:22:28.922992
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_snippet_get_body_var_0 = None
    test_snippet_get_body_var_1 = None
    test_snippet_get_body_var_0_obj = snippet(test_snippet_get_body_var_0)
    test_snippet_get_body_var_1_obj = test_snippet_get_body_var_1
    test_snippet_get_body_var_0_obj.get_body(**test_snippet_get_body_var_1_obj)


# Generated at 2022-06-25 23:22:39.050879
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def get_body():
        a_s_t_0 = None
        iterable_0 = find_variables(a_s_t_0)
        list_0 = []
        for item_0 in iterable_0:
            dictionary_0 = {item_0: VariablesGenerator.generate(item_0)}
            list_0.append(dictionary_0)
        list_1 = []
        for item_1 in list_0:
            for value_0 in item_1:
                dictionary_0 = {value_0: item_1[value_0]}
                list_1.append(dictionary_0)
        dictionary_1 = {}

# Generated at 2022-06-25 23:22:45.770154
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0():
        a_s_t_0 = ast.parse('let(__py_backwards_a_0)')
        a_s_t_1 = ast.parse('let(__py_backwards_b_0)')
        a_s_t_2 = ast.parse('let(__py_backwards_c_0)')
        a_s_t_3 = ast.parse('let(__py_backwards_d_0)')
        a_s_t_4 = ast.parse('extend(__py_backwards_extend_0)')
        a_s_t_5 = ast.parse('let(__py_backwards_f_0)')

# Generated at 2022-06-25 23:22:49.554202
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_function_0(x: Any):
        let(x)
        x += 1
        y = 1
    print(snippet(test_function_0).get_body())



# Generated at 2022-06-25 23:22:53.153424
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Local variables.
    snippet_instance = snippet(None)
    snippet_kwargs: Dict[str, Variable] = {}
    # Local variables end.
    snippet_instance.get_body(**snippet_kwargs)


# Generated at 2022-06-25 23:23:02.999584
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet(a: int) -> int:
        let(a)
        let(b)
        return a + b

    assert snippet(test_snippet).get_body(a=1, b=2) == [
        ast.Expr(value=ast.BinOp(left=ast.Name(id='_py_backwards_a_0', ctx=ast.Load()), op=ast.Add(),
                                 right=ast.Name(id='_py_backwards_b_0', ctx=ast.Load()))),
        ast.Return(value=None)]

    def test_snippet(b: int) -> int:
        let(b)
        return b + 2


# Generated at 2022-06-25 23:23:07.734421
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var1 = ast.parse('let(snippet_kwargs)').body[0]    # type: ignore
    var2 = ast.parse('let(tree)').body[0]    # type: ignore
    var3 = ast.parse('let(source)').body[0]    # type: ignore
    var4 = ast.parse('let(tree)').body[0]    # type: ignore
    var5 = ast.parse('let(variables)').body[0]    # type: ignore
    var6 = ast.parse('let(tree)').body[0]    # type: ignore
    var7 = ast.parse('let(variables)').body[0]    # type: ignore
    var8 = ast.parse('let(tree)').body[0]    # type: ignore