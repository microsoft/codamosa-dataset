

# Generated at 2022-06-25 23:14:27.751416
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def test_case_1(x, y):
        let(x)
        let(y)
        x += 1
        return x + y

    body = test_case_1.get_body(x=0, y=1)
    expected = """\
    _py_backwards_x_0 += 1
    return _py_backwards_x_0 + _py_backwards_y_1
"""
    assert repr(body) == repr(ast.parse(expected).body)



# Generated at 2022-06-25 23:14:30.566719
# Unit test for function extend_tree
def test_extend_tree():
    my_module = snippet(test_case_0)
    res = my_module.get_body()
    print(ast.dump(res[0]))
    assert ast.dump(res[0]).startswith("Assign(Assign(Assign")


fib = snippet(test_case_0)

# Generated at 2022-06-25 23:14:36.282959
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    var_0 = test_case_0()
    if isinstance(var_0, snippet):
        var_0_body = var_0.get_body()
        for var_1 in var_0_body:
            if isinstance(var_1, ast.Assign):
                for var_2 in var_1.targets:
                    if isinstance(var_2, ast.Name):
                        assert var_2.id == '_py_backwards_int_0_0'



# Generated at 2022-06-25 23:14:43.175843
# Unit test for function extend_tree
def test_extend_tree():
    def foo():
        tree = ast.parse("extend(vars)")
        variables = {
            'vars': [
                ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
                ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2))
                ]
            }
        extend_tree(tree, variables)
        return tree.body[0].body == variables['vars']
    assert foo()
    
    

# Generated at 2022-06-25 23:14:44.396008
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(test_case_0.__code__.co_consts[0]) == {"int_0"}

# Generated at 2022-06-25 23:14:52.809164
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import py_backwards.tests.visitors.test_snippet as snippet

    @snippet.snippet
    def snippet_test_case_0(int_0):
        import py_backwards.tests.test_snippet as snippet

        extend(snippet)
        assert y != int_0

    expected = ast.parse('import py_backwards.tests.test_snippet as _py_backwards_snippet_1\n'
                         '\n'
                         '_py_backwards_snippet_1.y = None\n'
                         '_py_backwards_int_0 = 2787\n'
                         '_py_backwards_snippet_1.y != _py_backwards_int_0')


# Generated at 2022-06-25 23:15:00.784181
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    dict_0 = dict()
    dict_0['alias_0'] = 'ast.alias'
    dict_0['alias_1'] = 'alt.alias'
    dict_0['name_0'] = 'indent'
    dict_0['name_1'] = 'code'
    dict_0['name_2'] = 'asname'
    dict_1 = dict_0
    alias_0 = ast.alias(name='indent', asname='code')
    dict_1['alias_0'] = alias_0
    alias_1 = ast.alias(name='code', asname='asname')
    dict_1['alias_1'] = alias_1
    let(dict_1)
    extend(dict_0)


# Generated at 2022-06-25 23:15:11.638756
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    int_0 = 2787
    let(int_0)
    int_1 = 1
    int_0 += int_1
    int_2 = 2
    int_0 += int_2
    int_3 = 2
    int_0 *= int_3

# Generated at 2022-06-25 23:15:15.324877
# Unit test for function find_variables
def test_find_variables():
    def my_fn():
        let(int_0)
        let(int_1)

    tree = ast.parse(get_source(my_fn))
    actual = list(find_variables(tree))
    assert actual == ['int_0', 'int_1']



# Generated at 2022-06-25 23:15:17.215525
# Unit test for function find_variables
def test_find_variables():
    assert find_variables(ast.parse('let(x)\nlet(y)')) == ['x', 'y']



# Generated at 2022-06-25 23:15:37.162399
# Unit test for function extend_tree
def test_extend_tree():
    x, y, z = 'x', 'y', 'z'
    import_from = ast.parse('from a import b').body[0]  # type: ast.ImportFrom
    import_from.module = 'c'
    tree = ast.parse('extend(x)\nlet(y)\nlet(z)')
    variables = {'x': import_from, 'y': y, 'z': z}
    extend_tree(tree, variables)
    assert tree.body[0] == import_from
    assert tree.body[1].args[0].id == y
    assert tree.body[2].args[0].id == z


# Generated at 2022-06-25 23:15:47.283220
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import astor
    x = ast.alias(name=ast.Name(id='x', ctx=ast.Load(), lineno=0, col_offset=0), asname=None, lineno=0, col_offset=0)
    x1 = ast.alias(name=ast.Name(id='x', ctx=ast.Load(), lineno=0, col_offset=0), asname=None, lineno=0, col_offset=0)
    y = ast.alias(name=ast.Name(id='y', ctx=ast.Load(), lineno=0, col_offset=0), asname=None, lineno=0, col_offset=0)
    variables = {'x': x1, 'y': y}
    replacer = VariablesReplacer(variables)
    actual = repl

# Generated at 2022-06-25 23:15:50.534680
# Unit test for function extend_tree
def test_extend_tree():
    snippet_2 = snippet(test_case_1)
    source = get_source(test_case_1)
    tree = ast.parse(source)
    variables = snippet_2._get_variables(tree, {})
    extend_tree(tree, variables)
    assert VariablesReplacer.replace(tree, variables)



# Generated at 2022-06-25 23:15:57.878998
# Unit test for function extend_tree
def test_extend_tree():
    int_0 = 0
    fn = lambda: extend(vars)
    body = snippet(fn).get_body(vars=[ast.Assign([ast.Name(id='int_0', ctx=ast.Store())], ast.Num(45))])
    # Now we have to test that int_0 was replaced with 45
    assert body[0].value.n == 45


# Generated at 2022-06-25 23:16:03.482939
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def foo():
        let(int_0)
        int_0 += 1
        y = 1
    assert foo.get_body() == ast.parse('''
    _py_backwards_int_0_0 += 1
    y = 1
    ''').body


# Generated at 2022-06-25 23:16:12.106069
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse(get_source(test_case_0))
    extend_tree(tree, {'int_0': [ast.Assign(targets=[ast.Name(id='int_0', ctx=ast.Store())],
                                            value=ast.Num(n=1)),
                                 ast.Assign(targets=[ast.Name(id='int_0', ctx=ast.Store())],
                                            value=ast.Num(n=2))]})
    assert ast.dump(tree) == ast.dump(ast.parse("int_0 = 1\nint_0 = 2"))


# Generated at 2022-06-25 23:16:18.346733
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_case_0()
    source = get_source(test_case_0)
    tree = ast.parse(source)
    expected = [ast.Assign(targets=[ast.Name(id='int_0', ctx=ast.Store())], value=ast.Num(n=0))]
    result = [tree.body[0].body[0]]
    assert expected == result

# Generated at 2022-06-25 23:16:25.946592
# Unit test for function extend_tree
def test_extend_tree():
    source1 = "x = 1"
    source2 = "y = 2"
    tree1 = ast.parse(source1)
    tree2 = ast.parse(source2)
    body1 = tree1.body
    body2 = tree2.body
    exts = {"vars": body2}
    tree = ast.parse("extend(vars)")
    extend_tree(tree, exts)
    result = tree.body
    assert len(result) == len(body1) + len(body2)
    assert result[0].lineno == 2


# Generated at 2022-06-25 23:16:30.919389
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet.get_body(test_case_0, int_0=let(int_0)) == [
        ast.Assign(targets=[ast.Name(id='int_0', ctx=ast.Store())], value=ast.Num(n=0))
    ]


# Generated at 2022-06-25 23:16:37.430761
# Unit test for function extend_tree
def test_extend_tree():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    variables = find_variables(tree)
    tree.body[0].body.insert(0, ast.Pass())
    extend_tree(tree, variables)
    assert isinstance(tree.body[0].body[0], ast.Pass)



# Generated at 2022-06-25 23:16:47.117263
# Unit test for function find_variables
def test_find_variables():
    def x():
        let(a)
        let(b)

    assert find_variables(ast.parse(get_source(x))) == ['a', 'b']



# Generated at 2022-06-25 23:16:52.518222
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    a = ast.parse("from testpack import testcase_0")
    v = dict()
    v['testcase_0'] = 'test_case_0'
    res = VariablesReplacer.replace(a, v)
    v = res.body[0].names[0]
    t = type(v)
    assert t.__name__ == 'alias'
    assert v.name == 'test_case_0'
    assert v.asname is None


# Generated at 2022-06-25 23:16:55.358546
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body()[0] == ast.Assign(
        targets=[ast.Name(id='int_0', ctx=ast.Store())],
        value=ast.Num(n=0))

# Generated at 2022-06-25 23:17:03.609828
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    input = ast.parse('from x import a as b, c')
    expected = ast.parse('from x import a as b, c')
    assert isinstance(VariablesReplacer.replace(input, {
        'a': ast.Name(id='b')
    }), ast.Module)
    assert compare_ast.compare(input, expected)

    input = ast.parse('from x import a as b, c')
    expected = ast.parse('from x import a as b, c')
    assert isinstance(VariablesReplacer.replace(input, {
        'a': 'b'
    }), ast.Module)
    assert compare_ast.compare(input, expected)


# Generated at 2022-06-25 23:17:10.542941
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import to_source
    from .helpers import example_tree as example
    alias_0 = ast.alias('ast', 'ast')
    alias_1 = ast.alias('_py_backwards_alias_0', '_py_backwards_alias_0')
    assert to_source(VariablesReplacer.replace(alias_0, {'ast': '_py_backwards_alias_0'})) == to_source(alias_1)
    assert to_source(VariablesReplacer.replace(alias_0, {'ast': 'ast'})) == to_source(alias_0)


# Generated at 2022-06-25 23:17:16.753890
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    # Given
    import_0 = ast.ImportFrom(module="module_0", names=[ast.alias(name="module_0", asname="module_0")], level=0)

    # When
    import_0 = VariablesReplacer.replace(import_0, {"module_0": "module_1"})

    # Then
    assert_equal(get_source(import_0), "from module_1 import module_1")


# Generated at 2022-06-25 23:17:21.599370
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse("import a.b as c")
    variables = {"a.b": "d"}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    assert ast.dump(tree).strip() == "ImportFrom(module='d', names=[alias(name='c', asname=None)], level=0)"

# Generated at 2022-06-25 23:17:29.028983
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test case 1
    def test_case_1():
        int_0 = 0

    assert snippet(test_case_1).get_body() == [ast.Assign([ast.Name('_py_backwards_int_0_0', ast.Store())], ast.Num(0))]
    # Test case 2
    def test_case_2():
        x = y = z = 0

    assert snippet(test_case_2).get_body() == [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store()), ast.Name('_py_backwards_y_1', ast.Store()), ast.Name('_py_backwards_z_2', ast.Store())], ast.Num(0))]
    # Test case 3
    def test_case_3():
        x

# Generated at 2022-06-25 23:17:34.546333
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    ast1 = ast.parse("""
import x.y
    """)
    ast2 = ast.parse("""
import x.y
    """)
    t = VariablesReplacer({'x': 'a'})
    v = t.visit(ast1)
    assert ast.dump(v) == ast.dump(ast2)


# Generated at 2022-06-25 23:17:44.029768
# Unit test for function extend_tree
def test_extend_tree():
    # Test 0:
    Variable = Union[ast.AST, List[ast.AST], str]

    @eager
    def find_variables(tree: ast.AST) -> Iterable[str]:
        """Finds variables and remove `let` calls."""
        for node in find(tree, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == 'let':
                parent, index = get_non_exp_parent_and_index(tree, node)
                parent.body.pop(index)  # type: ignore
                yield node.args[0].id  # type: ignore

    T = TypeVar('T', bound=ast.AST)

    class VariablesReplacer(ast.NodeTransformer):
        """Replaces declared variables with unique names."""


# Generated at 2022-06-25 23:17:50.544809
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def inner():
        let(a.b)
        a.b._a = 1
        
    body = inner.get_body()
    assert len(body) == 1
    expr = body[0]
    assert isinstance(expr, ast.Assign)
    assert len(expr.targets) == 1
    assert isinstance(expr.targets[0], ast.Attribute)
    assert isinstance(expr.value, ast.Num)
    assert isinstance(expr.value.n, int)
    assert expr.value.n == 1
    

# Generated at 2022-06-25 23:17:53.223092
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert test_case_0.__code__.co_varnames[0] == 'int_0'
    snippet_obj = snippet(test_case_0)
    body = snippet_obj.get_body(var=0)
    assert type(body) is list
    assert len(body) == 1

# Generated at 2022-06-25 23:17:58.245856
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def names_test():
        let(x)
        y = 0
        print(x)
        return y

    expected = ast.parse("x = 0\ny = 0\nprint(x)\nreturn y").body
    actual = names_test.get_body()
    assert actual == expected



# Generated at 2022-06-25 23:18:08.274968
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    new_lines = ['if true:\n', '    let(int_0)\n', '    int_0 += 1']
    def test_case_0():
        int_0 = 0
    source = get_source(test_case_0)
    for new_line in new_lines:
        source += new_line
    # source after added new lines
    expect_source = 'def test_case_0():\n    int_0 = 0\n' + new_lines[0] + '    _py_backwards_int_0_0 += 1\n'
    expect_tree = ast.parse(expect_source)
    # tree before added new lines
    tree = ast.parse(source)
    variables = {'int_0': VariablesGenerator.generate('int_0')}

# Generated at 2022-06-25 23:18:17.232289
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_0(int_0, int_1):
        x = let(int_0)
        print(x)
        x = let(int_1)
        print(x)

    assert snippet_0.get_body(x=1, y=2) == [
        ast.Print(dest=None,
                  values=[ast.Num(n=1)],
                  nl=True),
        ast.Print(dest=None,
                  values=[ast.Num(n=2)],
                  nl=True)]



# Generated at 2022-06-25 23:18:20.746498
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body() == [
        ast.Assign(
            targets = [
                ast.Name(
                    id="int_0",
                    ctx=ast.Store(),
                )
            ],
            value=ast.Num(
                n=0,
            ),
        )
    ]


# Generated at 2022-06-25 23:18:25.631720
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = '''def test_case_1():
    let(int_0)
    int_0 = 1
    x = 1'''
    assert snippet(test_case_0).get_body() == ast.parse(source).body[0].body


# Generated at 2022-06-25 23:18:35.535102
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _py_backwards_f_0():
        let(_py_backwards_x_0=1)
        let(_py_backwards_x_1=2)
        let(_py_backwards_x_2=3)
        let(_py_backwards_y_0=1)
        let(_py_backwards_y_1=2)
        _py_backwards_x_0 += 1
        _py_backwards_x_1 += 1
        _py_backwards_x_2 += 1
        _py_backwards_y_0 += 1
        _py_backwards_y_1 += 1
        x = 1
        x = 2
        x = 3
        y = 1
        y = 2
        return _py_backwards_y_0, _py_backwards_y_1

# Generated at 2022-06-25 23:18:42.875014
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_1 = 1
    var_2 = 2
    var_3 = 3
    var_4 = 4
    var_5 = 5
    var_6 = 6

    @snippet
    def test_case_1(var_0):
        var_0 = var_1
        var_0 += var_2
        var_0 -= var_3
        var_0 /= var_4
        var_0 *= var_5
        return var_0 + var_6

    _py_backwards_var_0_0 += var_1
    _py_backwards_var_0_0 += var_2
    var_0 -= var_3
    var_0 /= var_4
    var_0 *= var_5
    var_4 = var_0 + var_6
    return var_4

# Generated at 2022-06-25 23:18:46.932563
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_snippet = snippet(test_case_0)
    test_snippet_body = test_snippet.get_body()
    assert test_snippet_body[0].id == VariablesGenerator.generate('int_0')


# Generated at 2022-06-25 23:18:53.157618
# Unit test for function extend_tree
def test_extend_tree():
    # assert_equal(expected, extend_tree(tree, variables))

    a_s_t_0 = None
    variables_0 = {
        'key_0': None,
    }
    extend_tree(a_s_t_0, variables_0)



# Generated at 2022-06-25 23:18:54.381298
# Unit test for function find_variables

# Generated at 2022-06-25 23:18:58.002535
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def case_0():
        a_s_t_0 = ast.parse('let(x)\nx += 1\ny = 1')
        variables_0 = find_variables(a_s_t_0)
        body_0 = snippet(case_0).get_body()



# Generated at 2022-06-25 23:19:06.762233
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _fn_0(*args_0: Any) -> None:
        let(var_0_0)
        var_0_1 = 2
        y_0 = 1
        v_0 = 3
        a_s_t_0 = None
        snippet_kwargs_0 = {'var_0_1': var_0_1, 'args_0': args_0, 'y_0': y_0, 'v_0': v_0}
        _fn_0._snippet = snippet(fn=_fn_0)
        body_0 = _fn_0._snippet.get_body(**snippet_kwargs_0)
        iterable_0 = find_variables(a_s_t_0)
    pass

# Generated at 2022-06-25 23:19:07.518864
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # TODO: Implement unit test
    assert True


# Generated at 2022-06-25 23:19:11.993446
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = ast.parse('''
i = 1
j = i

i += 1
''').body[0]

    a_s_t_1 = ast.parse('''
i = 1
j = i

i += 1
''').body[0]

    a_s_t_2 = ast.parse('''
1

i += 1
''').body[0]

    a_s_t_3 = ast.parse('''
i = 1
j = i

i += 1
''').body[0]

    a_s_t_4 = ast.parse('''
i = 1
j = i

i += 1
''').body[0]

    snippet_0 = snippet(lambda s: s)

# Generated at 2022-06-25 23:19:22.844916
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _get_body_call_function(
            snippet_kwargs=None,
            ):
        snippet_kwargs = {'args...': [('args...', 'ast3.AST[]')]}
        _get_body_call_function_returns = None
        _get_body_call_function_returns = snippet().get_body(**snippet_kwargs)
        return _get_body_call_function_returns

# Generated at 2022-06-25 23:19:24.360295
# Unit test for function extend_tree
def test_extend_tree():
    """
    Check if extend_tree functions properly.
    """

# Generated at 2022-06-25 23:19:31.137187
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    tree = None

    def let_0(arg):
        return
    variables_0 = {'arg': None}
    arguments_0 = {'arg': None}
    args, kwargs = (arguments_0, arguments_0)
    instance = snippet(let_0)
    body = instance.get_body(**arguments_0)

    def let_1(arg):
        return
    variables_1 = {'arg': None}
    arguments_1 = {'arg': None}
    args, kwargs = (arguments_1, arguments_1)
    instance = snippet(let_1)
    body = instance.get_body(**arguments_1)

    def let_2(arg):
        return
    variables_2 = {'arg': None}

# Generated at 2022-06-25 23:19:33.016603
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = None
    iterable_0 = snippet(a_s_t_0).get_body()


# Generated at 2022-06-25 23:19:40.297946
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(1 + 1)
    snippet_0 = snippet(test)
    ast_0 = snippet_0.get_body()


# Generated at 2022-06-25 23:19:45.526847
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def a_s_t_0():
        def snippet_fn_1(arg_0, arg_1):
            let(arg_0)
            extend(arg_1)
        a_s_t_1 = snippet(snippet_fn_1).get_body(arg_0='a', arg_1=ast.Assign(targets=[ast.Name(id='a')], value=ast.Num(n=1)))


# Generated at 2022-06-25 23:19:48.779669
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(lambda: let(x))
    a_s_t_0 = ast.parse('')
    d_i_c_t_0 = None
    list_0 = snippet_0.get_body(**d_i_c_t_0)

# Generated at 2022-06-25 23:19:50.235091
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    if True:
        _py_backwards_x_0 = 2

# Generated at 2022-06-25 23:20:00.224221
# Unit test for function extend_tree
def test_extend_tree():
    from tree import make
    from .helpers import VariablesGenerator
    from .snippet import let
    from .helpers import get_source

    def _extend_tree_test():
        # given
        def _fn(iterable: int, *args) -> int:
            let(a)
            let(b)
            let(c)
            let(d)

            extend(assignments)

            return iterable

        # when
        assignments = ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.Num(n=1))

        # then
        return _fn

    def check(fn):
        assert get_source(fn) == get_source(_extend_tree_test())

    check(_extend_tree_test)




# Generated at 2022-06-25 23:20:07.498385
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = None
    snippet_kwargs = {'a_s_t_0': a_s_t_0} #@
    tree = {'a_s_t_0': a_s_t_0}
    variables = {'a_s_t_0': '_py_backwards_a_s_t_0_0'}
    extend_tree(tree, variables)
    snippet_0 = snippet(next_line) #@
    snippet_0.get_body(**snippet_kwargs)



# Generated at 2022-06-25 23:20:19.131825
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = ast.parse('a += 1')
    a_s_t_1 = ast.parse('a += 1')
    a_s_t_2 = ast.parse('a += 1')
    snippet_kwargs_0 = {
        'a': a_s_t_0
    }
    
    a_s_t_3 = ast.parse('a += 1')
    a_s_t_4 = ast.parse('a += 1')
    a_s_t_5 = ast.parse('a += 1')

    def test_snippet_0():
        let(a)
        a += 1
        y = 1
    

# Generated at 2022-06-25 23:20:28.600046
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # test_snippet_get_body.py
    a_s_t_0 = None
    from .test_utils import require_equal

# Generated at 2022-06-25 23:20:36.730514
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # test snippet without arguments
    def snippet_code_0():
        let(x)
    # create snippet
    snippet_0 = snippet(snippet_code_0)
    # get code as AST with replaced variables
    body_0 = snippet_0.get_body()
    # check that body is
    assert body_0 == [ast.Assign([ast.Name('x', ast.Load())],
                       ast.Name('_py_backwards_x_0', ast.Load()))]



# Generated at 2022-06-25 23:20:44.990304
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = None
    snippet_kwargs_0 = None
    class_1 = snippet(a_s_t_0)
    variables_0 = class_1._get_variables(a_s_t_0, snippet_kwargs_0)
    a_s_t_1 = None
    extend_tree(a_s_t_1, variables_0)
    a_s_t_2 = None
    VariablesReplacer.replace(a_s_t_2, variables_0)
    body_0 = class_1.get_body(**snippet_kwargs_0)


# Generated at 2022-06-25 23:21:06.565932
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0(**variables):
        print(x, y, z)

    x = 1
    y = 2
    z = 3
    assert [ast.Print(
        dest=None,
        values=[
            ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
            ast.Name(id='_py_backwards_y_1', ctx=ast.Load()),
            ast.Name(id='_py_backwards_z_2', ctx=ast.Load()),
        ],
        nl=True,
    )] == snippet(test_case_0).get_body()

# Generated at 2022-06-25 23:21:07.272449
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert 0


# Generated at 2022-06-25 23:21:09.791252
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(None)
    snippet_kwargs_0 = {}
    actual = snippet_0.get_body(**snippet_kwargs_0)
    expected = []
    assert actual == expected


# Generated at 2022-06-25 23:21:19.376363
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    x = None
    y = None
    a_s_t_0 = None
    a_s_t_1 = None
    a_s_t_2 = None
    a_s_t_3 = None
    a_s_t_4 = None
    a_s_t_5 = None
    a_s_t_6 = None
    a_s_t_7 = None
    a_s_t_8 = None
    a_s_t_9 = None
    a_s_t_10 = None
    a_s_t_11 = None
    a_s_t_12 = None
    a_s_t_13 = None
    a_s_t_14 = None
    a_s_t_15 = None
    a_s_t_16 = None
    a

# Generated at 2022-06-25 23:21:29.164187
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Test for method snippet.get_body"""
    class snippet_0(snippet):
        def _get_variables(self_0, a_s_t_0, **kwargs_0):
            class VariablesGenerator_0:
                def generate(self_1, var_0):
                    return None
            names_0 = find_variables(a_s_t_0)
            variables_0 = dict()
            for name_0 in names_0:
                variables_0[name_0] = VariablesGenerator_0().generate(name_0)

# Generated at 2022-06-25 23:21:35.319509
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    code = get_source(test_case_0)

    import astor

    try:
        if test_case_0.__code__.co_filename.endswith('.py'):
            code_lines = code.split('\n')[1:-1]
            code_lines = '\n'.join(code_lines)
            code = 'def test_case_0():\n' + code_lines + '\n'
        else:
            code = code.split('\n')[0]

        tree = ast.parse(code)
        snippet_get_body = snippet.get_body(tree)

        assert astor.to_source(snippet_get_body) == 'None'
    except (AssertionError, TypeError, SyntaxError) as _e:
        pass

# Generated at 2022-06-25 23:21:45.624298
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = None
    c_o_d_e_0 = None
    d_i_c_t_0 = {'n': c_o_d_e_0}
    extend_tree(a_s_t_0, d_i_c_t_0)
    a_s_t_1 = None
    c_o_d_e_1 = None
    d_i_c_t_1 = {'n': c_o_d_e_1}
    extend_tree(a_s_t_1, d_i_c_t_1)
    a_s_t_2 = None
    c_o_d_e_2 = None
    d_i_c_t_2 = {'n': c_o_d_e_2}
   

# Generated at 2022-06-25 23:21:52.614024
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class _class:
        def __init__(self) -> None:
            pass
    _class_0 = _class()
    _class_0._get_variables_0 = None  # type: ignore
    _class_0._get_variables_1 = None  # type: ignore
    _class_0._get_variables_1 = None  # type: ignore
    def fn_get_body_0(*args, **kwargs) -> None:
        if (len(args) >= 1) and (len(args) <= 2):
            if all(isinstance(arg, str) for arg in args):
                pass
        if (len(args) >= 1) and (len(args) <= 2):
            if all(isinstance(arg, str) for arg in args):
                pass

# Generated at 2022-06-25 23:22:01.982499
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = None
    a_s_t_1 = None
    a_s_t_2 = None
    a_s_t_3 = None
    a_s_t_4 = None
    a_s_t_5 = None
    a_s_t_6 = None
    a_s_t_7 = None
    a_s_t_8 = None
    a_s_t_9 = None
    a_s_t_10 = None
    a_s_t_11 = None
    a_s_t_12 = None
    a_s_t_13 = None
    a_s_t_14 = None
    a_s_t_15 = None
    a_s_t_16 = None
    a_s_t_17 = None
   

# Generated at 2022-06-25 23:22:03.228018
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        let(0)  # type: ignore


# Generated at 2022-06-25 23:22:31.235216
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_kwargs = [Variable]
    assert hasattr(snippet, 'get_body'), \
        "Class snippet does not have method 'get_body'"
    assert callable(snippet.get_body), \
        "Method 'get_body' of class snippet should be callable"


# Generated at 2022-06-25 23:22:39.376009
# Unit test for function extend_tree
def test_extend_tree():
    x_1 = ast.Name(id='x', ctx=ast.Load())
    iterable_0 = (1, 2)
    vars_0 = {'x': [ast.Assign(targets=[x_1], value=ast.Num(n=i)) for i in iterable_0]}
    extend_tree(x_1, vars_0)
    assert [ast.Assign(targets=[x_1], value=ast.Num(n=1)), ast.Assign(targets=[x_1], value=ast.Num(n=2))] == x_1.nodes  # type: ignore


# unit test for class snippet

# Generated at 2022-06-25 23:22:42.541237
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func_0(arg_1, arg_2):
        let(arg_1)
        let(arg_2)
    snippet_0 = snippet(func_0)
    assert snippet_0.get_body() == []
    assert snippet_0.get_body() == []


# Generated at 2022-06-25 23:22:49.553391
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class snippet_0:
        def __init__(self):
            self._fn = test_snippet_get_body
        def get_body(self):
            a_s_t_0 = None
            iterable_0 = find_variables(a_s_t_0)
            return iterable_0
    i = snippet_0()
    i.get_body()

# Generated at 2022-06-25 23:22:53.745927
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = None
    variables_0 = {'test_0': [ast.AnnAssign(target=ast.Name('a', ast.Store()), annotation=None, value=None, simple=1)]}
    extend_tree(a_s_t_0, variables_0)


# Generated at 2022-06-25 23:22:54.516949
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    pass


# Generated at 2022-06-25 23:22:59.930998
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Init instance
    snippet_get_body_0 = snippet(let)
    # Init variables
    snippet_kwargs = {'var': 1}

    # Run method
    snippet_get_body_0.get_body(**snippet_kwargs)
    # Check result
    assert True

# Generated at 2022-06-25 23:23:06.129164
# Unit test for function extend_tree
def test_extend_tree():
    res = []
    to_ext = [
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(2)),
        ast.Assign([ast.Name('y', ast.Store())], ast.Num(2)),
    ]
    let(to_ext)
    tree = ast.parse('extend(to_ext)\n')
    extend_tree(tree, to_ext=to_ext)
    iterable_0 = tree
    for a_s_t_0 in iterable_0:
        a_s_t_1 = a_s_t_0.body
        for a_s_t_2 in a_s_t_1:
            res.append(a_s_t_2)
    assert res == to_ext


# Generated at 2022-06-25 23:23:13.551519
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test case 0
    def fn_0():
        a_s_t_0 = None
        let(a_s_t_0)
        _py_backwards_a_s_t_0_0 = _py_backwards_a_s_t_0_0
        _py_backwards_a_s_t_0_0 = _py_backwards_a_s_t_0_0
        _py_backwards_a_s_t_0_0 = _py_backwards_a_s_t_0_0
        a_s_t_0 = _py_backwards_a_s_t_0_0
    snippet_0 = snippet(fn_0)
    assert snippet_0.get_body() == fn_0.__code__.co_code.co_consts

# Generated at 2022-06-25 23:23:18.495439
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def sample_snippet_0(x: int) -> int:
        let(x)
        x += 1
        return x
    instance_0 = snippet(sample_snippet_0)
    source_0 = get_source(instance_0._fn)
    a_s_t_0 = ast.parse(source_0)
    expect_0 = a_s_t_0.body[0].body
    result_0 = instance_0.get_body()
    assert expect_0 == result_0
