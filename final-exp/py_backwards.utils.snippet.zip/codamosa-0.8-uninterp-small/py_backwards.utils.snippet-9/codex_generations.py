

# Generated at 2022-06-25 23:14:27.484534
# Unit test for function extend_tree
def test_extend_tree():
    assert test_case_0() == "extend"

# Generated at 2022-06-25 23:14:32.840232
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = test_case_0.__code__.co_consts[0]
    tree = ast.parse(source)
    snippet_kwargs = {'str_0': ['extend']}
    expected = [
        ast.Assign(
            targets=[ast.Name(id='str_0', ctx=ast.Store())],
            value=ast.Str(s='extend'),
        )
    ]
    snippet_ins = snippet(test_case_0)
    assert snippet_ins.get_body(**snippet_kwargs) == expected



# Generated at 2022-06-25 23:14:39.618466
# Unit test for function extend_tree
def test_extend_tree():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    tree_str = str(tree)

    extend_tree(tree, {'str_0': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], 
                                             value=ast.Num(n=1)),
                                  ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                             value=ast.Num(n=2))]})
    tree_str_after = str(tree)

# Generated at 2022-06-25 23:14:48.274368
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class snippet_0(snippet):
        def __init__(self, fn: Callable[..., None], **kwargs: Variable) -> None:
            super().__init__(fn)
            self.kwargs = kwargs

    test_case_0()
    snippet_0_0 = snippet_0(test_case_0)
    body_0 = snippet_0_0.get_body()
    assert body_0[0] == (ast.Expr(value=ast.Lambda(args=ast.arguments(args=[], vararg=None,
            kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=ast.Str(s='extend')),
            lineno=0, col_offset=0),)


# Generated at 2022-06-25 23:14:57.919041
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    global_0, global_1, global_2, global_3, global_4, global_5, global_6, global_7, global_8, global_9, global_10, global_11, global_12, global_13, global_14, global_15, global_16, global_17, global_18, global_19, global_20, global_21, global_22, global_23, global_24, global_25, global_26, global_27, global_28, global_29, global_30, global_31, global_32, global_33, global_34, global_35, global_36, global_37 = (0 for i in range(38))
    global_38 = "extend"
    global_39 = None
    class Class_0:
        global_0, global_1, global_2

# Generated at 2022-06-25 23:15:02.391795
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    try:
        str_0 = '__main__.circle_pi_0'
        _py_backwards_circle_pi_0 = str_0
        _py_backwards_circle_pi_0 += ' hello'

        str_1 = 'math.circle_pi_1'
        _py_backwards_circle_pi_1 = str_1
        pass
    except:
        assert False, 'Uncaught exception'


# Generated at 2022-06-25 23:15:07.782624
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('''let(e)
    print(e)''')
    assert find_variables(tree) == ['e']
    assert ast.dump(tree) == \
        "Module([Expr(Call(Name('print', Load()), [Name('e', Load())], []))])"



# Generated at 2022-06-25 23:15:13.330828
# Unit test for function extend_tree
def test_extend_tree():
    source = '''extend(x)'''

    # replace extend(x) with 'x'
    tree = ast.parse(source)
    extend_tree(tree, {'x': ast.Name(id='x', ctx=ast.Load())})

    # check AST is equal
    new_source = ast.get_source(tree)
    assert source == new_source

# Generated at 2022-06-25 23:15:14.512565
# Unit test for function extend_tree
def test_extend_tree():
    print('-----------------')
    print('Running extend_tree unit tests...')

    # Before it was throwing an error, now should not.
    test_case_0()

    # TODO: Create more tests for extend_tree

# Generated at 2022-06-25 23:15:15.365400
# Unit test for method get_body of class snippet

# Generated at 2022-06-25 23:15:25.912227
# Unit test for function find_variables
def test_find_variables():
    test_case_0()
    test_ast = ast.parse(get_source(test_case_0))
    assert find_variables(test_ast) == ['extend']

# Generated at 2022-06-25 23:15:34.242007
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Given
    def test_fn():
        str_1 = 'a'
        let(str_1)
        extend(str_1)
        str_0 = str_1
        let(str_0)
        str_0 = 'b'
        let(str_0)
        str_0 = str_0
        let(str_0)
        test_case_0()
    snippet_instance = snippet(test_fn)
    snippet_kwargs: Dict[str, Variable] = {
        'str_1': 'str_1_val',
        'str_0': 'str_0_val'
    }
    # When
    body = snippet_instance.get_body(**snippet_kwargs)
    # Then

# Generated at 2022-06-25 23:15:39.338279
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    alias1 = ast.alias()
    alias1.name = 'import_0'
    alias_list = [alias1]
    import_from1 = ast.ImportFrom()
    import_from1.names = alias_list
    module1 = 'extend'
    import_from1.module = module1
    extend(import_from1)


# Generated at 2022-06-25 23:15:48.829476
# Unit test for function extend_tree
def test_extend_tree():
    new_body = []
    new_body.append(ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)))
    new_body.append(ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=2)))

    new_body.append(ast.Print(dest=None, values=[ast.Name(id='x', ctx=ast.Load())], nl=True))
    new_body.append(ast.Print(dest=None, values=[ast.Name(id='y', ctx=ast.Load())], nl=True))

    assert ast.dump(new_body) != ast.dump(test_case_0())

# Generated at 2022-06-25 23:16:02.772730
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from py_backwards.snippet import snippet
    from py_backwards.transformations.helpers import VariablesGenerator
    from py_backwards.transformations import let, extend
    from py_backwards.tree import find
    from py_backwards.transformations.base import extend_tree
    import typed_ast.ast3 as ast
    import astunparse
    VariablesGenerator.reset()
    snippet_0 = snippet(test_case_0)
    kwargs = {}
    snippet_1 = snippet_0.get_body(**kwargs)

# Generated at 2022-06-25 23:16:10.914757
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    v = ast.alias(name='test_case_0', asname=None)
    tree = ast.Module(body=[ast.ImportFrom(module='test.test_extend', names=[v], level=None)])
    variables = {'test_case_0': '_py_backwards_test_case_0_0'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == ast.parse('from test.test_extend import _py_backwards_test_case_0_0').body[0]



# Generated at 2022-06-25 23:16:14.750211
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    n = ast.parse("from a import b").body[0].names[0]
    assert n is not None
    n = VariablesReplacer.replace(n, {'a': 'b'})
    assert n is not None


# Generated at 2022-06-25 23:16:22.524458
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    _py_backwards_variables_0 = dict()
    _py_backwards_tree_0 = ast.parse('''import package1.package2
''')
    VariablesReplacer.replace(_py_backwards_tree_0, _py_backwards_variables_0)


# Generated at 2022-06-25 23:16:26.065518
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)
    snippet_kwargs_0 = {}
    snippet_0_body = snippet_0.get_body(**snippet_kwargs_0)
    assert isinstance(snippet_0_body, list)

# Generated at 2022-06-25 23:16:38.214524
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse('let(a)'))) == ['a']
    assert list(find_variables(ast.parse('let(a)\nlet(b)'))) == ['a', 'b']
    assert list(find_variables(ast.parse('let(a)\nprint(a)'))) == ['a']
    assert list(find_variables(ast.parse('a = 1\nlet(a)\nprint(a)'))) == ['a']
    assert list(find_variables(ast.parse('a = 1\nlet(a)\nprint(a)', mode='exec'))) == ['a']
    assert list(find_variables(ast.parse('let(a)\nlet(a)', mode='exec'))) == ['a']

# Generated at 2022-06-25 23:16:54.160790
# Unit test for function extend_tree
def test_extend_tree():
    from .helpers import get_source_and_tree

    source = get_source(test_case_0)
    tree = ast.parse(source)

    # Assertion 1
    if not isinstance(tree.body[0], ast.FunctionDef):
        raise AssertionError()

    # Assertion 2
    if not isinstance(tree.body[0].name, str):
        raise AssertionError()

    # Assertion 3
    if not isinstance(tree.body[0].args, ast.arguments):
        raise AssertionError()

    # Assertion 4
    if not isinstance(tree.body[0].body, list):
        raise AssertionError()

    # Assertion 5

# Generated at 2022-06-25 23:16:56.435462
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(var_0)")
    extend_tree(tree, {'var_0': []})
    assert tree == ast.parse("")


# Generated at 2022-06-25 23:17:00.286770
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # <class 'str'>
    assert isinstance(snippet(test_case_0).get_body()[0].value.id, str)
    # <class 'int'>
    assert isinstance(snippet(test_case_0).get_body()[0].value.value, int)


# Generated at 2022-06-25 23:17:03.490844
# Unit test for function extend_tree
def test_extend_tree():
    from .test_cases import test_case_0
    var_0 = test_case_0()
    tree = ast.parse(get_source(test_case_0))
    extend_tree(tree, var_0)
    assert False

# Generated at 2022-06-25 23:17:04.325472
# Unit test for function extend_tree
def test_extend_tree():
    var_0 = {}



# Generated at 2022-06-25 23:17:13.490153
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def get_body():
        let(var_0)
        var_1 = {}
        var_1['foo'] = var_0
        var_1['bar'] = {}
        var_0.update(var_1)

# Generated at 2022-06-25 23:17:15.147815
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}


# Generated at 2022-06-25 23:17:22.922808
# Unit test for function extend_tree
def test_extend_tree():
    test_case_tree_0=ast.parse("extend(var_0)")
    test_case_tree_1=ast.parse("var_0['b']=1")
    extend_tree(test_case_tree_0,{'var_0':test_case_tree_1})
    assert(dump(test_case_tree_0)=="Module(body=[Assign(targets=[Subscript(value=Name(id='var_0', ctx=Load()), slice=Index(value=Str(s='b')), ctx=Store())], value=Num(n=1))])\n")

# Generated at 2022-06-25 23:17:29.615624
# Unit test for function extend_tree
def test_extend_tree():
    source = [{'00': 'var_0 = {}'}, {'01': ''}, {'02': ''}, {'03': ''}, {'04': ''}, {'05': ''}, {'06': ''}, {'07': 'var_1 = {}'}, {'08': ''}, {'09': 'var_2 = {}'}, {'10': ''}]
    expected = [{'00': 'var_0 = {}'}, {'01': ''}, {'02': ''}, {'03': ''}, {'04': ''}, {'05': ''}, {'06': ''}, {'07': 'var_1 = {}'}, {'08': ''}, {'09': 'var_2 = {}'}, {'10': ''}]
    tree = ast.parse(source[0]['00'])
    extend_

# Generated at 2022-06-25 23:17:36.257205
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def foo():
        let(var_0)
        var_0 = {}
        x = 1
    x = 2
    assert str(foo.get_body()) == "[Assign(targets=[Name(id='_py_backwards_var_0_0', ctx=Store())], value=Dict()), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1))]"


# Generated at 2022-06-25 23:17:52.557522
# Unit test for method get_body of class snippet

# Generated at 2022-06-25 23:18:05.237647
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = {'x': module_0.Name(module_0.Load(), 'var')}
    l_i_s_t_0 = snippet(test_snippet_get_body).get_body(**d_i_c_t_0)
    replace_at(0, a_s_t_0, l_i_s_t_0[0])
    replace_at(0, a_s_t_0, l_i_s_t_0[1])
    a_s_t_2 = module_0.AST()
    d_i_c_t_2 = {'x': module_0.Name(module_0.Load(), 'var')}
    l_i_s_t

# Generated at 2022-06-25 23:18:13.650479
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func_name_0(p_a_r_a_m_0_0, p_a_r_a_m_0_1=None, *args, **kwargs):
        let(p_a_r_a_m_0_0)
        p_a_r_a_m_0_0 += 1
        y = 1
    _py_backwards_get_body_0_0 = snippet(func_name_0).get_body(p_a_r_a_m_0_0=1)
    for a_s_t_0 in _py_backwards_get_body_0_0:
        pass

test_snippet_get_body()

# Generated at 2022-06-25 23:18:22.761203
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_1 = module_0.If()
    a_s_t_2 = module_0.NodeTransformer()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.FunctionDef()
    a_s_t_5 = module_0.parse()
    vari_0 = (a_s_t_4, a_s_t_4)
    vari_1 = (a_s_t_2, a_s_t_3)
    vari_2 = (a_s_t_1, vari_1, vari_0)
    vari_3 = (a_s_t_3, vari_2)
    vari_4 = tuple()
    vari_5 = (module_0, vari_4)

# Generated at 2022-06-25 23:18:32.340456
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Case 0
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = {'a_s_t_0': a_s_t_0}
    n_a_m_e_0 = module_0.Name('a_s_t_0', module_0.Load())
    s_t_r_0 = "a_s_t_0"
    v_a_r_0 = s_t_r_0
    d_i_c_t_1 = {s_t_r_0: n_a_m_e_0}
    l_i_s_t_0 = [n_a_m_e_0]
    s_n_i_p_p_e_t_0 = snippet(test_case_0)


# Generated at 2022-06-25 23:18:40.856686
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _get_body(a_1):
        try:
            a_1[0]
        except IndexError:
            pass

    _get_body([1])
    snippet_0 = snippet(_get_body)

# Generated at 2022-06-25 23:18:43.804054
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    iterable_0 = {'x': a_s_t_0}
    extend_tree(a_s_t_0, iterable_0)


# Generated at 2022-06-25 23:18:49.968457
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func_0():
        let(a)
        x = 1
        let(b)
        y = 2
        return a

    # Test 1
    func_0_obj_0 = snippet(func_0)
    var_0 = {
        "a": 1,
        "b": 2,
    } # type: Dict[str, Variable]
    func_0_obj_0.get_body(**var_0)


# Generated at 2022-06-25 23:18:56.505943
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    d_i_c_0 = {'a': a_s_t_0}
    l_i_s_t_0 = list()
    l_i_s_t_1 = l_i_s_t_0
    assert get_body(a_s_t_0, d_i_c_0) == l_i_s_t_1

if __name__ == "__main__":
    test_case_0()
    test_snippet_get_body()

# Generated at 2022-06-25 23:19:06.102334
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:19:31.473616
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from typed_ast import ast3 as ast
    source = b'\n    a = 0\n    b = 2\n    c = 3\n'
    tree = ast.parse(source)
    variables = {'a': VariablesGenerator.generate('a'), 'b': VariablesGenerator.generate('b'), 'c': VariablesGenerator.generate('c')}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    snippet_kwargs = {}
    from py_backwards.snippet import snippet
    snippet_0 = snippet(None)
    snippet_body_0 = snippet_0.get_body(**snippet_kwargs)

# Generated at 2022-06-25 23:19:41.308417
# Unit test for function extend_tree
def test_extend_tree():
    import os.path
    import sys

    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '__pycache__')))
    import py_backwards_helpers as helpers_0

    class D(dict):
        def __getitem__(self, item):
            return item

    class test_case_1():
        extend_tree(module_0.AST(), D())

    def test_case_2():
        helpers_0.VariablesGenerator.generate(test_case_1)

    def test_case_3():
        helpers_0.get_source(test_case_2)

    def test_case_4():
        helpers_0.VariablesGenerator.generate(test_case_3)


# Generated at 2022-06-25 23:19:50.209317
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _test(inputs):
        _snippet_0 = snippet(_test)
        actual = _snippet_0.get_body(**inputs)
        if actual != inputs["expected"]:
            raise AssertionError("""
snippet.get_body(snippet_kwargs=%s):
    Expected: %s
    Actual: %s"""
                                 % (inputs["snippet_kwargs"], inputs["expected"], actual))

    _test({
        "snippet_kwargs": {},
        "expected": []
    })

    _test({
        "snippet_kwargs": {},
        "expected": [],
    })

    _test({
        "snippet_kwargs": {},
        "expected": [],
    })


# Generated at 2022-06-25 23:19:52.465593
# Unit test for function find_variables
def test_find_variables():
    source = "let(x)\nx += 1\ny = 1"
    tree = ast.parse(source)
    result = find_variables(tree)
    assert result == ['x']



# Generated at 2022-06-25 23:19:55.259981
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn():
        a = 1
    a_0 = snippet(fn)
    a_1 = a_0.get_body()

# Generated at 2022-06-25 23:20:00.098578
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0():
        s_n_i_p_p_e_t_0 = snippet(test_snippet_get_body)
        i_t_e_r_a_b_l_e_1 = s_n_i_p_p_e_t_0.get_body()
    test_case_0()

# Generated at 2022-06-25 23:20:09.542904
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0():
        a_s_t_0 = module_0.AST()
        extend_tree(a_s_t_0, {'x': let(1)})
        extend_tree(a_s_t_0, {'x': extend(a_s_t_0.body.pop())})
        extend_tree(a_s_t_0, {'x': extend(a_s_t_0.body)})
    def test_case_1():
        a_s_t_0 = module_0.AST()
        extend_tree(a_s_t_0, {'x': let(1)})
        extend_tree(a_s_t_0, {'x': extend(a_s_t_0.body[0])})

# Generated at 2022-06-25 23:20:18.857591
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test():
        let(x)
        x += 1

    method_0 = snippet(test).get_body

    def test_0():
        let(x)
        x += 1
        method_0()

    def test_1():
        let(x)
        x += 1
        method_0(x=2)

    def test_2():
        let(x)
        x += 1
        method_0(y=2)

# Generated at 2022-06-25 23:20:23.941885
# Unit test for function extend_tree
def test_extend_tree():
    """Check if extend function works correctly."""
    body = [
        extend(x),
        y,
        z,
    ]
    variables = {
        'x': [y, z],
    }
    extend_tree(body, variables)
    assert body == [y, z, y, z]


# Generated at 2022-06-25 23:20:30.867467
# Unit test for function find_variables
def test_find_variables():
    # Initial variables
    a_s_t_0 = module_0.AST()
    # Unit test operation
    iterable_0 = find_variables(a_s_t_0)
    # Test equality of iterators
    unit_test.test(type(iterable_0) is type(iter([])))
    unit_test.test(type(iterable_0) is not type(iter('')))
    unit_test.test(type(iterable_0) is not type(1))
    unit_test.test(type(iterable_0) is not type(1.1))
    unit_test.test(type(iterable_0) is not type({}))
    unit_test.test(type(iterable_0) is not type((0,)))

# Generated at 2022-06-25 23:20:45.553716
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    s_n_i_p_p_e_t_0 = snippet(module_0.AST)
    d_i_c_t_0 = s_n_i_p_p_e_t_0.get_body()

# Generated at 2022-06-25 23:20:49.298708
# Unit test for function find_variables
def test_find_variables():
    a_s_t_1 = module_0.AST()
    iterable_1 = find_variables(a_s_t_1)

# End unit test

# Intended output (based on execution of test_find_variables):

#
 

# Generated at 2022-06-25 23:20:51.959438
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)


# Generated at 2022-06-25 23:20:57.713340
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class snippet_get_body_0:
        def snippet_get_body_0_0():
            let(x)
            x += 1
            y = 1
        
        def snippet_get_body_1_0():
            let(x)
            extend(vars)
            print(x, y)
        

test_snippet_get_body()
test_case_0()

# Generated at 2022-06-25 23:20:58.519419
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    return


# Generated at 2022-06-25 23:21:07.818084
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import inspect
    import ast
    def v_s_0(func, **param_0):
        l_0 = inspect.signature(func).parameters.keys()
        for i_0 in l_0:
            if isinstance(param_0[i_0], ast.Name):
                param_0[i_0] = param_0[i_0].id
        return param_0
    def v_s_1(func, **param_0):
        l_0 = inspect.signature(func).parameters.keys()
        for i_0 in l_0:
            if callable(param_0[i_0]):
                param_0[i_0] = param_0[i_0]()
        return param_0


# Generated at 2022-06-25 23:21:10.388163
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def __py_backwards_fn_0(__py_backwards_x: Any) -> None:
        __py_backwards_x = 1
        let(__py_backwards_y)
        z = __py_backwards_y_0 * 2


# Generated at 2022-06-25 23:21:11.151809
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert 1


# Generated at 2022-06-25 23:21:15.320220
# Unit test for function find_variables
def test_find_variables():
    Snippet = snippet
    snippet_0 = Snippet(test_case_0)
    result_0 = snippet_0.get_body()
    assert len(result_0) == 1


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:21:24.964677
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Expr(module_0.Call(module_0.Name(id='let', ctx=module_0.Load()), [module_0.Name(id='x', ctx=module_0.Load())], [], None, None)), module_0.Expr(module_0.BinOp(module_0.Name(id='x', ctx=module_0.Load()), module_0.Add(), module_0.Num(n=1))), module_0.Assign([module_0.Name(id='y', ctx=module_0.Store())], module_0.Num(n=1))]
    iterable_0 = find_variables(a_s_t_0)


# Generated at 2022-06-25 23:22:09.094751
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn_0():
        let(x_0)
        x_0 = 1
    snippet_0 = snippet(fn_0)
    a_s_t_0 = snippet_0.get_body()


# Generated at 2022-06-25 23:22:15.086064
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class snippet_0(snippet):
        def __init__(self):
            snippet.__init__(self, None)

        def _get_variables(self, tree, snippet_kwargs):
            assert tree == a_s_t_0
            assert snippet_kwargs == {"k_w_a_r_g_s": False}
            return {"_v_a_r_i_a_b_l_e_s_0": True}

    _s_n_i_p_p_e_t_0 = snippet_0()
    _s_n_i_p_p_e_t_0.get_body(k_w_a_r_g_s=False)

# Generated at 2022-06-25 23:22:20.225672
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    d_i_c_t_0 = {'_a_s_t_0': a_s_t_1}
    d_i_c_t_1 = {'_a_s_t_0': a_s_t_1, '_a_s_t_1': a_s_t_0}
    d_i_c_t_2 = {'_a_s_t_0': a_s_t_1, '_a_s_t_1': a_s_t_0, '_a_s_t_2': d_i_c_t_1}

# Generated at 2022-06-25 23:22:21.507674
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    function_0 = snippet__get_body


# Generated at 2022-06-25 23:22:32.503230
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Create instance
    s_n_i_p_p_e_t_0 = snippet(test_case_0)

    # Call method
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Assign()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.FunctionDef()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.arg()
    a_s_t_6 = module_0.arg()
    a_s_t_7 = module_0.arg()
    a_s_t_8 = module_0.Call()
    a_s_t_9 = module_0.Name()
   

# Generated at 2022-06-25 23:22:41.728239
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def try_0(x: str, y: int) -> int:
        let(x)
        x += 1
        y = 1

    def try_1(x: str, y: int) -> int:
        let(x)
        y = 1

    def try_2(x: str, y: int) -> int:
        let(x)

    def try_3(x: str, y: int) -> int:
        let(y)

    def try_4(x: str, y: int) -> int:
        let(y)
        y += 1
        x = 1

    def try_5(x: str, y: int) -> int:
        let(y)
        y += 1

    def try_6(x: str, y: int) -> int:
        let(y)
       

# Generated at 2022-06-25 23:22:46.355689
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(lambda : None)
    list_0 = snippet_0.get_body()


# Tests output:
test_case_0()
test_snippet_get_body()

# Generated at 2022-06-25 23:22:57.445681
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func_0(a):
        let(let_0_0)
        let(let_0_1)
        let_0_1 = 1
        let_0_0 = 2
        extend(extend_0_2)
        return let_0_0, let_0_1
    snippet_0 = snippet(func_0)
    extend_0_2 = [ast.Assign([ast.Name(id='x', ctx=ast.Store()), ast.Name(id='y', ctx=ast.Store())], [ast.Num(n=1), ast.Num(n=2)]), ast.Assign([ast.Name(id='foo', ctx=ast.Store())], [ast.Num(n=3)])]

# Generated at 2022-06-25 23:23:02.568388
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Stub
    def test_snippet_0(a_s_t_0):
        let(a_s_t_0)
        extend(a_s_t_0)
        return

    result_0 = snippet(test_snippet_0).get_body(a_s_t_0)
    assert result_0 is not None
    assert type(result_0) is list


# Generated at 2022-06-25 23:23:05.038724
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .snippets import test_snippet_get_body
    test_snippet_get_body()
