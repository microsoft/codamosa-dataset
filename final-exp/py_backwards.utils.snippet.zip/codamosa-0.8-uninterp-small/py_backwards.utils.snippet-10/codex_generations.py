

# Generated at 2022-06-25 23:14:39.617371
# Unit test for function find_variables
def test_find_variables():
    # Test where `tree` is an instance of AST
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Expr(value=module_0.Call(func=module_0.Name(id='let', ctx=module_0.Load()),
                                                      args=[module_0.Str(s='x')], keywords=[], starargs=None,
                                                      kwargs=None))]
    iterable_0 = find_variables(a_s_t_0)
    # Verify that the iterator returned by find_variables returns the expected values
    expected_0 = ['x']
    actual_0 = list(iterable_0)
    # Verify that the elements in the iterator returned by find_variables are equal to the expected values
    assert actual

# Generated at 2022-06-25 23:14:44.351496
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _fn_0() -> None:
        a_s_t_0 = let(3)
        a_s_t_0 = let(3)
        a_s_t_0 = let(3)
    snippet_0 = snippet(_fn_0)
    a_s_t_0 = snippet_0.get_body()


# Generated at 2022-06-25 23:14:47.646049
# Unit test for function find_variables
def test_find_variables():
    # Setup
    a_s_t_0 = module_0.AST()
    def test(actual, expected):
        assert actual == expected
    # Assert
    test(
        eager(find_variables(a_s_t_0))
        , [])

import typing as module_1


# Generated at 2022-06-25 23:14:57.224855
# Unit test for function find_variables
def test_find_variables():
    from .helpers import make_test

    a_s_t_0 = ast.parse("let(x)\n")
    iterable_0 = find_variables(a_s_t_0)
    make_test("let(x)\n", find_variables)
    a_s_t_1 = ast.parse("let(x)\nx = 1\n")
    iterable_1 = find_variables(a_s_t_1)
    make_test("let(x)\nx = 1\n", find_variables)
    a_s_t_2 = ast.parse("let(x)\nx = let(y)\ny\n")
    iterable_2 = find_variables(a_s_t_2)

# Generated at 2022-06-25 23:14:58.341431
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = module_0.AST()
    extend_tree(a_s_t_0, {})


# Generated at 2022-06-25 23:15:02.478093
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet(var):
        let(var)
        var += 1
        let(var)
        return var

    snip = snippet(snippet)
    body = snip.get_body(var=1)
    assert body[-2].value == body[-1].value, 'Last lines of code should be equal if they are same variables'



# Generated at 2022-06-25 23:15:06.927956
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def function_0():
        # 1
        let(x)
        # 2
        x += 1
        # 3
        y = 1
    
    result_0 = snippet(function_0).get_body()


# Generated at 2022-06-25 23:15:13.810237
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    a_s_t_0 = module_0.from_alias()
    a_s_t_0.name = str_0
    string_0 = a_s_t_0.name
    d_i_c_t_0 = {}
    a_s_t_1 = VariablesReplacer.replace(a_s_t_0, d_i_c_t_0)
    string_1 = a_s_t_1.name
    assert string_1 == string_0


# Generated at 2022-06-25 23:15:17.428210
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    a_s_t_0 = module_0.alias(name='Name', asname=None)
    dict_0 = dict()
    instance_0 = VariablesReplacer(dict_0)
    instance_0.visit_alias(a_s_t_0)


# Generated at 2022-06-25 23:15:26.408716
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    a_i_m_p_o_r_t_f_r_o_m_0 = module_0.ImportFrom(module='test', names=[module_0.alias(name='VisitImportFrom')])
    v_a_r_i_a_b_l_e_s_0 = {'VisitImportFrom': module_0.alias(name='VisitImportFrom_asname_0')}
    v_a_r_i_a_b_l_e_s_r_e_p_l_a_c_e_r_0 = VariablesReplacer(v_a_r_i_a_b_l_e_s_0)
    v_a_r_i_a_b_l_e_s_r_e_p_l_a_c_e_r_0.vis

# Generated at 2022-06-25 23:15:34.451335
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test snippet case 0
    s = snippet(test_case_0)
    body = s.get_body()
    assert isinstance(body, list) and body == [], 'The value of "body" should be "[]".'


# Generated at 2022-06-25 23:15:41.306638
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(var_0)\nprint(x, y)')
    extend_tree(tree, {'var_0': [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=1)), ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=2))]})
    assert get_source(tree) == 'x = 1\nx = 2\nprint(x, y)'




# Generated at 2022-06-25 23:15:49.007257
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .lib import snippet
    from .lib import let
    var_0: Any
    var_0 = 0
    def func():
        let(var_0)
        var_0 += 1
        return None
    var_1 = func
    var_2 = snippet(var_1).get_body()
    var_3 = var_2
    assert var_3 == [ast.Assign([ast.Name('_py_backwards_var_0_0', ast.Store())], ast.BinOp(ast.Name('_py_backwards_var_0_0', ast.Load()), ast.Add(), ast.Num(1)))]


# Generated at 2022-06-25 23:15:50.023901
# Unit test for function extend_tree
def test_extend_tree():
    var_0 = {}
    


# Generated at 2022-06-25 23:16:03.445175
# Unit test for function extend_tree
def test_extend_tree():    
    tree = ast.parse(get_source(test_case_0))
    extend_tree(tree, {'var_0': [ast.Assign(targets=[ast.Name(id='var_1', ctx=ast.Store())], value=ast.Num(n=1)), ast.Assign(targets=[ast.Name(id='var_2', ctx=ast.Store())], value=ast.Num(n=2))]})
    assert str(tree) == 'Module(body=[Assign(targets=[Name(id=\'var_1\', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id=\'var_2\', ctx=Store())], value=Num(n=2))])'


# Generated at 2022-06-25 23:16:06.075912
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("extend(x)")
    var_0 = {}
    extend_tree(tree, {"x": var_0})


# Generated at 2022-06-25 23:16:08.657582
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    expected = None
    source = snippet(test_case_0).get_body()
    actual = ast.dump(source)
    assert actual == expected


# Generated at 2022-06-25 23:16:19.528927
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    def fn_0(a, b):
        let(c)
        c = a
        d = b
        return d
    var_2['fn_0'] = snippet(fn_0)
    var_1['c'] = c
    var_1['d'] = d
    var_1['a'] = var_0['a']
    var_1['b'] = var_0['b']
    var_3 = var_2['fn_0'].get_body(**var_1)
    print(var_3)

# Generated at 2022-06-25 23:16:21.398617
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = test_case_0()
    var_1 = {}


# Generated at 2022-06-25 23:16:22.762482
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    var_1 = {}


# Generated at 2022-06-25 23:16:30.012193
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    
        def test_fn_0(var_0):
            let(var_0)
            var_0 = {}


# Generated at 2022-06-25 23:16:32.190883
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    code = snippet(test_case_0).get_body()
    assert len(code) == 1

# Generated at 2022-06-25 23:16:36.925932
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(var_0)\nvar_0 = {}\nvar_0 = {}\nvar_0')
    res = test_case_0()
    assert list(find_variables(tree)) == list(res)


# Generated at 2022-06-25 23:16:38.302732
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = snippet(test_case_0)
    var_0.get_body()
    pass

# Generated at 2022-06-25 23:16:47.409454
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test with arguments: var_0
    source = ast.parse("let(var_0)\nvar_0['a'] = 1")
    assert snippet(test_case_0).get_body(var_0=source.body[0].body[0]) == [
        ast.Assign(targets=[ast.Subscript(value=ast.Name(id='_py_backwards_var_0_0', ctx=ast.Load()),
                                          slice=ast.Index(value=ast.Str(s='a')),
                                          ctx=ast.Store())],
                    value=ast.Num(n=1)),
    ]

# Generated at 2022-06-25 23:16:48.928014
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_case_0()
    assert 1 == 1

test_snippet_get_body()

# Generated at 2022-06-25 23:16:57.750744
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_var_0 = snippet(test_case_0)
    snippet_var_1 = snippet_var_0.get_body()
    assert snippet_var_1 == [ast.Expr(value=ast.Call(func=ast.Name(id='let', ctx=ast.Load()), args=[ast.Str(s='_py_backwards_var_0')], keywords=[])), ast.Assign(targets=[ast.Name(id='_py_backwards_var_0', ctx=ast.Store())], value=ast.Dict(keys=[], values=[]))]
    snippet_var_0 = snippet(test_case_0)
    snippet_var_1 = snippet_var_0.get_body(x=1)

# Generated at 2022-06-25 23:17:06.724653
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert hasattr(snippet, 'get_body')
    snippet_get_body = getattr(snippet, 'get_body')
    assert callable(snippet_get_body)

    # Call snippet_get_body
    arg_0 = {'var_0': var_0}
    snippet_get_body_result = snippet_get_body(**arg_0)
    assert isinstance(snippet_get_body_result, list)

# Generated at 2022-06-25 23:17:07.922830
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_snippet_get_body_0()


# Generated at 2022-06-25 23:17:13.331050
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0():
        var_0 = {}
        extend(var_0)
        let(1)
        var_0['a'] = 1
    assert snippet(test_case_0).get_body() == [
        ast.Assign([
                ast.Name(id="a", ctx=ast.Store())
            ], ast.Num(n=1)
        )
    ]


# Generated at 2022-06-25 23:17:17.113254
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = snippet(test_case_0)

# Generated at 2022-06-25 23:17:26.500831
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    for i in range(100):
        var_0 = {}
        var_0[1] = 1
        var_0['a'] = 1
        var_0[2] = 2
        var_0['b'] = 2
        var_0[3] = 3
        var_0['c'] = 3
        var_0[4] = 4
        var_0['d'] = 4
        var_0[5] = 5
        var_0['e'] = 5
        if len(var_0[1]) > 0:
            print(1)
        else:
            if len(var_0[2]) > 0:
                print(2)
            else:
                if len(var_0[3]) > 0:
                    print(3)

# Generated at 2022-06-25 23:17:29.305966
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    code_0 = snippet(test_case_0).get_body()
    code_0_tree = ast.parse("var_0 = {}")
    assert code_0 == code_0_tree.body[0].body

# Generated at 2022-06-25 23:17:35.948973
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Declare variables and methods.
    var_0 = {}
    var_0 = snippet(test_case_0)
    var_1 = {}
    var_1 = var_0.get_body()
    var_2 = {}
    var_2 = len(var_1)
    var_3 = {}
    var_3 = 1
    assert var_2 < var_3

if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 23:17:45.506766
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    vars_0 = {'fn': Callable[[Any], None]}
    vars_1 = vars_0.copy()
    vars_1.update()
    vars_1.update({'snippet_kwargs': {}})
    vars_2 = vars_1.copy()
    vars_2.update()

# Generated at 2022-06-25 23:17:49.255287
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    with open('tests/data/snippet_get_body.py') as file_0:
        # Test for 'snippet_get_body.py'
        assert len(ast.parse(file_0.read()).body) == len(snippet(test_case_0).get_body())

# Generated at 2022-06-25 23:17:49.908724
# Unit test for method get_body of class snippet

# Generated at 2022-06-25 23:18:01.477062
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # [TEST] test_snippet_get_body SNIPPET_0
    # var_0 = {}
    # assert var_0 == {}
    # [TEST] test_snippet_get_body SNIPPET_0
    
    var_1 = {'x': 1}
    var_2 = {'x': 1}
    # [TEST] test_snippet_get_body SNIPPET_1
    # let(x)
    # x += 1
    # assert var_1 == var_2
    # [TEST] test_snippet_get_body SNIPPET_1
    
    var_3 = {'x': {'y': 1}}
    var_4 = {'x': {'y': 1}}
    # [TEST] test_snippet_get_

# Generated at 2022-06-25 23:18:05.384170
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class _Test:
        @staticmethod
        def _func():
            var_0 = {}

    # Replace with real execution
    def _assert_equals(x, y):
        assert x == y

    _assert_equals(snippet(_Test._func).get_body(), [])



# Generated at 2022-06-25 23:18:11.254128
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn():
        var_0 = {}
        var_1 = ast.parse("print('Hello World')").body[0]  # type: ignore
    snippet_0 = fn
    var_0 = snippet_0.get_body()
    assert [ast.parse("print('Hello World')").body[0]] == var_0  # type: ignore

if __name__ == '__main__':
    test_case_0()
    test_snippet_get_body()

# Generated at 2022-06-25 23:18:20.966482
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = snippet(test_case_0)
    var_1 = var_0.get_body()
    assert len(var_1) == 1

# Generated at 2022-06-25 23:18:24.763880
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)
    assert [ast.parse("var_0 = {}").body[0]] == snippet_0.get_body()


# Generated at 2022-06-25 23:18:27.082005
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_000():
        let(var_0)
        let(var_1)
    snippet_000.get_body()


# Generated at 2022-06-25 23:18:36.923845
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_6 = {}
    var_7 = {}
    var_8 = {}
    var_9 = {}
    var_10 = {}
    var_11 = {}
    var_12 = {}
    var_13 = {}
    var_14 = {}
    var_15 = {}
    var_16 = {}
    var_17 = {}
    
    class var_18:
        def __init__(self):
            self.x = 1
    
    def test_case_1():
        var_19 = {}
        var_20 = {}
        var_21 = {}
        var_22 = {}
        var_23 = {}
        var_24 = {}
        var

# Generated at 2022-06-25 23:18:39.582218
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_i = snippet(test_case_0)
    snippet_i.get_body()


# Generated at 2022-06-25 23:18:49.287682
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(ast.parse("(a,b,c,d)"))) == []
    assert list(find_variables(ast.parse("{{(a,b,c,d)}}"))) == []
    assert list(find_variables(ast.parse("{(a,b,c,d)}"))) == []
    assert list(find_variables(ast.parse("[(a,b,c,d)]"))) == []
    assert list(find_variables(ast.parse("a"))) == []
    assert list(find_variables(ast.parse("a = 1"))) == []
    assert list(find_variables(ast.parse("(a = 1)"))) == []
    assert list(find_variables(ast.parse("a, b = 1, 2"))) == []
   

# Generated at 2022-06-25 23:18:50.989303
# Unit test for function extend_tree
def test_extend_tree():
    var_0 = {"test_var": None}
    assert test_case_0() == var_0


# Generated at 2022-06-25 23:18:55.227136
# Unit test for function find_variables
def test_find_variables():
    ast_0 = ast.parse("let(x)")
    res_0 = {"x"}
    assert find_variables(ast_0) == res_0

    ast_0 = ast.parse("extend(vars)\n")
    res_0 = set()
    assert find_variables(ast_0) == res_0


# Generated at 2022-06-25 23:18:59.221871
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import compare_source

    @snippet
    def snippet():
        let(x)
        x += 1
        y = 1
        
    tree = snippet.get_body()
    compare_source(tree, """
        _py_backwards_x_0 += 1
        y = 1
    """)


# Generated at 2022-06-25 23:19:00.640894
# Unit test for function extend_tree
def test_extend_tree():
    test_case_0()



# Generated at 2022-06-25 23:19:11.864308
# Unit test for function extend_tree
def test_extend_tree():
    import astor
    var_0 = {}
    var_1 = 5
    var_2 = 5
    var_3 = 5
    var_0[0] = 5
    var_0[1] = 3
    var_0[2] = 2
    var_0[3] = 1
    while (var_1 > 1):
        var_1 = var_1 - var_2
    var_3 = var_3 + var_1
    var_4 = {var_5 for var_5 in var_0}
    test_case_0()
    var_5 = extend(var_4)
    var_6 = var_5 - var_3
    print(var_6)
    var_7 = "test"
    var_8 = let(var_7)
    var_9 = test_case_

# Generated at 2022-06-25 23:19:22.762920
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}
    var_1 = {}
    var_1['__call'] = snippet.get_body.__call__
    var_1['__getitem'] = snippet.get_body.__getitem__
    var_1['__setitem'] = snippet.get_body.__setitem__
    var_1['__repr'] = snippet.get_body.__repr__
    var_1['__delitem'] = snippet.get_body.__delitem__
    var_1['__getslice'] = snippet.get_body.__getslice__
    var_1['__setslice'] = snippet.get_body.__setslice__
    var_1['__delslice'] = snippet.get_body.__delslice__
    var_1['__getattribute'] = snippet

# Generated at 2022-06-25 23:19:26.576456
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body(var_0={}) == [ast.Assign(targets=[ast.Name(id='var_0', ctx=ast.Store())], value=ast.Dict(keys=[], values=[])), ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Name(id='var_0', ctx=ast.Load())], keywords=[]))]


# Generated at 2022-06-25 23:19:35.557882
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet_fn_0(obj_0: str) -> int:
        let(test_snippet_test_case_0)
        extend(test_snippet_test_case_1)
        return test_snippet_test_case_2.charAt(0)

    test_snippet_test_case_0 = ast.parse('{}')
    test_snippet_test_case_1 = [ast.parse('x = 1'), ast.parse('x = 2')]
    test_snippet_test_case_2 = 'x'


# Generated at 2022-06-25 23:19:45.123238
# Unit test for function extend_tree
def test_extend_tree():
    code = """
    def test_case_0():
        var_0 = {}
        extend(var_0)
        a = 1
        b = 2
        var_0['a'] = x = 1
        var_0['b'] = y = 2
        extend(var_0)
        a = 1
        b = 2
        var_0['a'] = x = 1
        var_0['b'] = y = 2
    """
    tree = ast.parse(code)
    var_0 = {}
    extend_tree(tree, {'var_0': var_0})


# Generated at 2022-06-25 23:19:48.994562
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = """
    def baZ(foo):
        let(x)
        x += 1
        y = 1
    baZ(1)
    """
    tree = ast.parse(source)
    res = snippet(test_case_0).get_body(x=1)
    assert res != tree.body[0].body


# Generated at 2022-06-25 23:19:55.254882
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}
    var_0 = _py_backwards_test_case_0_0 = test_case_0()
    var_1 = _py_backwards_test_case_0_1 = get_source(_py_backwards_test_case_0_0)
    var_2 = _py_backwards_test_case_0_2 = ast.parse(_py_backwards_test_case_0_1)
    var_3 = _py_backwards_test_case_0_3 = find_variables(_py_backwards_test_case_0_2)
    var_4 = _py_backwards_test_case_0_4 = {name: VariablesGenerator.generate(name) for name in _py_backwards_test_case_0_3}
    extend_tree

# Generated at 2022-06-25 23:19:59.754095
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    S = snippet(test_case_0)
    assert S.get_body() == [ast.Assign(targets=[ast.Name(id='_py_backwards_var_0_0', ctx=ast.Store())], value=ast.Dict(keys=[], values=[]))]


# Generated at 2022-06-25 23:20:04.732624
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    snippet_0 = snippet(test_case_0)

    output_var_0 = snippet_0.get_body()

    expected_output_var_0 = [ast.Assign([ast.Name("_py_backwards_var_0", ast.Store())], ast.Dict([]))]

    assert output_var_0 == expected_output_var_0

# Generated at 2022-06-25 23:20:09.132194
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    instance = snippet(test_case_0)
    assert (instance.get_body() == [ast.Assign([ast.Name('_py_backwards_var_0_0', ast.Store())], ast.Dict([], []) )])

abbrs = {
    'snippet': snippet,
    'extend': extend,
    'let': let
}

# Generated at 2022-06-25 23:20:27.567356
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}
    var_1 = test_case_0()
    var_2 = {}
    var_3 = test_snippet_get_body()
    var_4 = {}
    var_5 = test_snippet_get_body()
    if (var_1 == var_2):
        let(var_3)
        extend(var_4)
        var_3 = var_3
        var_6 = 1
        var_3 = var_6
        var_7 = 2
        var_3 = var_7
        var_3 = var_3
        print(var_3)
    var_8 = 3
    var_8 = var_8
    print(var_8)
    return var_7

if __name__ == '__main__':
    test_snippet

# Generated at 2022-06-25 23:20:40.591842
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .helpers import compare_ast, assert_raises, str_to_ast
    from .tree import find_all_names, find_all_attributes
    assert_raises(TypeError, snippet.get_body)

    var_0 = {'x': 1}
    # Original snippet code:
    #  x = 0
    #  x += 1
    snippet_code_0 = 'x = 0\nlet(x)\nx += 1\n'
    expected_names_0 = {'x': 1, 'x_0': 1}
    expected_attributes_0 = {}
    assert compare_ast(snippet(test_case_0).get_body(x=var_0),
                       str_to_ast(snippet_code_0))

# Generated at 2022-06-25 23:20:47.910067
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def case_0():
        var_0 = {'x': ast.Name('x', ast.Load()), 'y': ast.Num(1)}
        return var_0

    assert (test_case_0() == case_0())

# Generated at 2022-06-25 23:20:58.411120
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    @snippet
    def f0():
        let(var_0)
        extend(var_0)
        return var_0

    context = test_case_0()
    var_0 = ast.FunctionDef(
        name='var_0',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kwarg=None,
            defaults=[]),
        body=[ast.Expr(
            value=ast.Call(
                func=ast.Name(
                    id='print',
                    ctx=ast.Load()),
                args=[ast.Name(
                    id='var_0',
                    ctx=ast.Load())],
                keywords=[]))],
        decorator_list=[],
        returns=None)

    snippet_0_

# Generated at 2022-06-25 23:21:07.720020
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}
    var_1 = ast.Name(id='x', ctx=ast.Load())
    var_0['x'] = var_1
    var_2 = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1))
    var_3 = ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())], value=ast.Num(n=1))
    var_4 = ast.Module(body=[var_2, var_3])
    var_5 = snippet(test_case_0).get_body(**var_0)

# Generated at 2022-06-25 23:21:08.968666
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    with pytest.raises(Exception):
        snippet(test_case_0).get_body(var_0=1)

# Generated at 2022-06-25 23:21:10.209593
# Unit test for function find_variables
def test_find_variables():
    var_0 = {}
    let(var_0)
    return var_0


# Generated at 2022-06-25 23:21:14.442004
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    data = snippet(test_case_0)
    get_body_0 = data.get_body()
    expected_0 = [ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())],
                  ast.Dict([], []))]
    assert get_body_0 == expected_0



# Generated at 2022-06-25 23:21:15.874708
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body()


# Generated at 2022-06-25 23:21:22.114427
# Unit test for function find_variables
def test_find_variables():
    # function for testing
    def test_func():
        let(var_0)
        var_0[var_1] = 1
    # source code of function
    source = get_source(test_func)
    # ast tree of function
    tree = ast.parse(source)
    # variables
    variables = find_variables(tree)
    # asserts
    assert 2 == len(variables)
    assert 'var_0' in variables
    assert 'var_1' in variables


# Generated at 2022-06-25 23:21:29.814172
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert get_source(test_case_0) == 'var_0 = {}'


# Generated at 2022-06-25 23:21:30.636224
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = {}


# Generated at 2022-06-25 23:21:36.007859
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source_0 = get_source(test_case_0)
    tree_0 = ast.parse(source_0)
    snippet_kwargs = locals()
    snippet_0 = snippet(test_case_0)
    variables = snippet_0._get_variables(tree_0, snippet_kwargs)
    extend_tree(tree_0, variables)
    VariablesReplacer.replace(tree_0, variables)
    body = tree_0.body[0].body
    assert body
    assert len(body) == 1
    assert isinstance(body[0], ast.Assign)
    assert body[0].targets == [ast.Name(id='var_0', ctx=ast.Store())]
    assert isinstance(body[0].value, ast.Dict)
    assert body[0].value.keys

# Generated at 2022-06-25 23:21:38.939919
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    with pytest.raises(TypeError):
        var_2 = snippet(test_case_0)
        var_2.get_body()


# Generated at 2022-06-25 23:21:40.312326
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0(a: int = 123, b: int = 456):
        pass

# Generated at 2022-06-25 23:21:43.375617
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Run test case
    var_0 = test_case_0()

    # Asserts
    assert(var_0 == {})


# Generated at 2022-06-25 23:21:51.109757
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_0():
        let(x)
        let(y)
        var_0 = x
        var_1 = y
        var_2 = x
        var_3 = y
        var_2 = 1
        var_3 = 1
        var_4 = x
        var_5 = y
        var_6 = x
        var_7 = y
        var_6 = 1
        var_7 = 1
        var_8 = x
        var_9 = y
        var_10 = x
        var_11 = y
        var_12 = x
        var_13 = y
        var_12 = 1
        var_13 = 1
        var_10 = var_12
        var_11 = var_13
        var_8 = var_10
        var_9 = var_

# Generated at 2022-06-25 23:21:59.850584
# Unit test for function find_variables
def test_find_variables():
    '''This test case is generated by PyBackwards
    Please add more tests
    <AUTOGENERATED>
    '''
    var_0 = {'__name__': '__main__', '__file__': 'pybackwards/snippet.py', '__package__': None, '__doc__': None, '__spec__': None}
    var_1 = let({'__name__': 'pybackwards.snippet', '__file__': 'pybackwards/snippet.py', '__package__': 'pybackwards', '__doc__': None, '__spec__': None})
    var_2 = ['let', 'extend', 'test_case_0']
    var_3 = None
    var_4 = 'y'

# Generated at 2022-06-25 23:22:02.647076
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    var_0 = snippet(test_case_0)
    var_1 = var_0.get_body()
    assert var_1 == [ast.Expr(value=ast.Dict(keys=[], values=[]))]


# Generated at 2022-06-25 23:22:11.665872
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from . import get_source
    import ast
    import inspect
    import random

    for _ in range(100):
        @snippet
        def _0(x: int, y: float):
            let(x)
            let(y)
            _0 = y
            _1 = x
            _2 = y
            print(_0)
            print(_1)
            print(_2)
            print(_1)
            _3 = x
            print(_3)
            print(_3)

        test_case_0()
        _tree = ast.parse(get_source(_0._fn))
        expected = _tree.body[0].body
        actual = _0.get_body(x=None, y=None)
        assert_equal(expected, actual)



# Generated at 2022-06-25 23:22:28.784851
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0(target_snippet : snippet, snippet_kwargs_0 : Dict[str, ast.AST]):
        expected_target_body_0 = tuple([])
        target_body_0 = target_snippet.get_body(**snippet_kwargs_0)
        # target_body_0.sort()
        # expected_target_body_0.sort()
        assert target_body_0 == expected_target_body_0
    def test_case_1(target_snippet : snippet, snippet_kwargs_0 : Dict[str, ast.AST]):
        expected_target_body_0 = tuple([])

# Generated at 2022-06-25 23:22:31.812904
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(None)
    snippet_kwargs_0 = dict()
    snippet_0.get_body(**snippet_kwargs_0)

# Generated at 2022-06-25 23:22:38.356473
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Given
    a_s_t_0 = module_0.AST()
    d_i_c_t_0 = dict()
    d_i_c_t_0['x'] = a_s_t_0
    given_kwargs = d_i_c_t_0
    expected_result = list()
    snippet_0 = snippet(lambda: None)

    # When
    actual_result = snippet_0.get_body(**given_kwargs)

    # Then
    assert expected_result == actual_result



# Generated at 2022-06-25 23:22:42.745665
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def func():
        let(x)
        x += 1
        y = 1

    assert func.get_body() == [ast.AugAssign(ast.Name('_py_backwards_x_0', ast.Load()), ast.Add(), ast.Num(1)), ast.Assign([ast.Name('y', ast.Store())], ast.Num(1))]


# Generated at 2022-06-25 23:22:46.746451
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_0():
        let(x)
        let(y)
        pass

    a_s_t_0 = snippet_0.get_body()


# Generated at 2022-06-25 23:22:53.522321
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_0():
        x = 1
        y = 2 + 3
        print('dummy')

    # Case 0
    a_s_t_0 = module_0.AST()
    snippet_kwargs_0 = {
        'y': 'x',
    }
    body_0 = snippet(snippet_0).get_body(
        **snippet_kwargs_0
    )
    assert isinstance(body_0, list)


# Generated at 2022-06-25 23:22:57.158000
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast as module_0
    local_0 = module_0.Num(n=1)
    class_0 = snippet(lambda : None)
    local_1 = class_0.get_body(x=local_0)


# Generated at 2022-06-25 23:22:58.619626
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    #TODO: implement!
    pass

# Generated at 2022-06-25 23:23:00.299839
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_instance_0 = snippet(test_case_0)
    snippet_instance_0.get_body()

# Generated at 2022-06-25 23:23:03.122494
# Unit test for function extend_tree
def test_extend_tree():
    import unittest

    class Extend_treeTestCase(unittest.TestCase):
        def test_extend_tree(self):
            # Arrange
            # Act
            # Assert
            pass
    unittest.main()



# Generated at 2022-06-25 23:23:24.038578
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn_0():
        let(x)
        x += 1
        y = 1
    try:
        var_0 = snippet(test_fn_0)
        var_1 = var_0.get_body()
        assert(var_1[0].value.id in ('x', '_py_backwards_x_0'))
        assert(var_1[0].targets[0].id in ('x', '_py_backwards_x_0'))
        assert(var_1[1].value.value == 1)
        assert(var_1[1].targets[0].id == 'y')
    except:
        raise


# Generated at 2022-06-25 23:23:33.106855
# Unit test for function extend_tree
def test_extend_tree():
    from .helpers import assert_ast
    from .helpers import check_dump
    from .helpers import assert_source
    
    a_s_t_0 = module_0.parse('x = z')
    a_s_t_1 = module_0.parse('let(y)')
    a_s_t_2 = module_0.parse('y = 1')
    
    extend_tree(a_s_t_0, {'y': a_s_t_1, 'z': a_s_t_2})
    
    assert_ast(a_s_t_0, module_0.parse('x = y = 1'))
    assert_source(a_s_t_0, 'x = y = 1')
    

# Generated at 2022-06-25 23:23:39.966755
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn_0(x):
        let(x)
        x += 1
        y = 1
    
    class_0 = snippet(fn_0)
    assert class_0.get_body() == [
        ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())], ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()), ast.Add(), ast.Num(1))),
        ast.Assign([ast.Name('y', ast.Store())], ast.Num(1))
    ]


# Generated at 2022-06-25 23:23:44.067509
# Unit test for function extend_tree
def test_extend_tree():
    i = 1
    tree = ast.parse(get_source(lambda: extend(i)))
    i = ast.parse(get_source(lambda: let(2))).body[0]
    extend_tree(tree, {'i': i})
    assert tree == ast.parse(get_source(lambda: extend(let(2))))
    assert tree.body[0].value == i


# Generated at 2022-06-25 23:23:48.723585
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet  # type: ignore
    def f():
        a = 7
        return a
    a_s_t_0 = module_0.parse('b = f()')
    copy_0 = copy(a_s_t_0)
    body = f.get_body()
    for a_s_t_1 in body:
        copy_0.body[0].body.append(a_s_t_1)
    assert copy_0 == a_s_t_0

# Generated at 2022-06-25 23:23:51.282065
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_i_n_s_t_0 = snippet(test_snippet_get_body)
    l_i_s_t_0 = snippet_i_n_s_t_0.get_body()


# Generated at 2022-06-25 23:23:59.629583
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet_0(x: int):
        let(x)
        x += 1
        y = 1

    snippet_0 = snippet(test_snippet_0)
    assert snippet_0.get_body(x=1) == [ast.Assign([ast.Name(id='_py_backwards_x_0', ctx=ast.Store())], ast.BinOp(ast.Name(id='_py_backwards_x_0', ctx=ast.Load()), ast.Add(), ast.Num(n=1))), ast.Assign([ast.Name(id='y', ctx=ast.Store())], ast.Num(n=1))]


# Generated at 2022-06-25 23:24:04.046624
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    class snippet_0(snippet):

        def get_body(self, **kwargs):
            return super(snippet_0, self).get_body(**kwargs)

    s_n_i_p_0 = snippet_0(test_snippet_get_body)
    a_s_t_0 = s_n_i_p_0.get_body()


# Generated at 2022-06-25 23:24:06.048926
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # constructor args for class snippet
    snippet_0 = snippet(test_case_0)
    # method to test
    snippet_1 = snippet_0.get_body()
    # assert condition
    assert snippet_1 == None

# Generated at 2022-06-25 23:24:07.251973
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)
    body = snippet_0.get_body()