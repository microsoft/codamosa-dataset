

# Generated at 2022-06-25 23:14:38.568598
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from .helpers import VariablesGenerator
    from .snippets import snippet_3_1
    from typed_ast import ast3 as ast

    node = ast.alias(
        name = 'typing',
        asname = VariablesGenerator.generate('asname')
    )
    obj = VariablesReplacer(
        variables = {
            'typing': snippet_3_1
        }
    )
    visited = obj.visit_alias(node)
    # Validate the variable "visited"
    # There should be no assignment
    assert visited is not None, "The variable visited should not be undefined"
    assert isinstance(visited, ast.alias), "The variable visited should be of type ast.alias"
    assert visited.name == 'test', "visited.name should be equal to 'test'"

# Generated at 2022-06-25 23:14:40.618775
# Unit test for function find_variables
def test_find_variables():
    dict_0 = {}
    let(x_0)
    dict_0[x_0] = 1
    extend(dict_0)



# Generated at 2022-06-25 23:14:42.676158
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(test_case_0.__code__.co_consts[0])) == ['dict_0']



# Generated at 2022-06-25 23:14:45.051887
# Unit test for function find_variables
def test_find_variables():  # type: ignore
    """Test case for function find_variables"""
    assert len(list(find_variables(test_case_0()))) == 1


# Generated at 2022-06-25 23:14:50.981560
# Unit test for function extend_tree
def test_extend_tree():
    dict_0 = {'x': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                        value=ast.Num(n=4))]}
    source = get_source(test_case_0)
    tree = ast.parse(source)
    extend_tree(tree, dict_0)
    assert ast.dump(tree).strip() == "Module(body=[Expr(value=Call(func=Name(id='extend', ctx=Load()), args=[Name(id='dict_0', ctx=Load())], keywords=[]))])"



# Generated at 2022-06-25 23:14:55.926372
# Unit test for function extend_tree
def test_extend_tree():
    var_0 = {}
    extend(var_0)
    assert tree.get_var_names(tree.get_tree()) == ["var_0"]
    assert tree.get_var_names(var_0) == []
    assert tree.get_var_names(tree.get_tree()) == ["var_0"]


# Generated at 2022-06-25 23:15:03.246948
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def fn(dict_0, str_1):
        let(str_2)
        let(dict_1)
        let(dict_0_values)
        let(dict_0_keys)
        let(dict_0_items)
        let(dict_0_get)
        let(dict_0_iter)
        let(dict_0_copy)
        let(dict_0_popitem)
        let(dict_0_pop)
        let(dict_0_update)
        let(dict_0_fromkeys)
        let(dict_0_setdefault)
        let(dict_0_clear)
        let(dict_0_items)
        let(dict_0_keys)
        let(dict_0_values)
        let(dict_0_2)
       

# Generated at 2022-06-25 23:15:07.864690
# Unit test for function extend_tree
def test_extend_tree():
    dict_0 = {
        'x': 'y'
    }
    extend(dict_0)
    dict_1 = {
        'y': 'x'
    }
    extend(dict_1)
    assert dict_0 == dict_1


# Generated at 2022-06-25 23:15:12.046155
# Unit test for function find_variables
def test_find_variables():
    assert set(find_variables(ast.parse("f()"))) == set()
    assert set(find_variables(ast.parse("let(x) let(y) f(x, y)"))) == {'x', 'y'}



# Generated at 2022-06-25 23:15:21.004683
# Unit test for function extend_tree
def test_extend_tree():
    def test_case_0():
        dict_0 = {'a': 1}
        extend(dict_0)
    tree = ast.parse(inspect.getsource(test_case_0))
    variables = {
        'dict_0': [
            ast.Assign(
                targets=[ast.Name(id='a', ctx=ast.Store())],
                value=ast.Num(n=1)
            ),
            ast.Assign(
                targets=[ast.Name(id='b', ctx=ast.Store())],
                value=ast.Num(n=4)
            )
        ]
    }
    extend_tree(tree, variables)

# Generated at 2022-06-25 23:15:26.099639
# Unit test for function extend_tree
def test_extend_tree():
    import astor
    from .tree import find
    from .helpers import last_node


# Generated at 2022-06-25 23:15:34.129672
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_0(x):
        let(x)
        x += 1
        y = 1
    expected = [
        ast.Assign(targets=[ast.Name(id='_py_backwards_x_0', ctx=ast.Store())],
                   value=ast.BinOp(left=ast.Name(id='_py_backwards_x_0', ctx=ast.Load()),
                                   op=ast.Add(),
                                   right=ast.Num(n=1))),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                   value=ast.Num(n=1))
    ]
    assert snippet_0.get_body() == expected


# Generated at 2022-06-25 23:15:41.775813
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 1
    b = 2
    c = 3
    x = 4
    y = 5
    z = 6
    bool_0 = bool(a)
    snippet_0 = snippet(bool_0)
    snippet_0.get_body(var=x, d=z)
    bool_1 = bool(b)
    snippet_1 = snippet(bool_1)
    snippet_1.get_body(var=y)
    bool_2 = bool(c)
    snippet_2 = snippet(bool_2)
    snippet_2.get_body(var=x)


# Generated at 2022-06-25 23:15:48.230225
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test(a: int, b: int) -> int:
        c = 1
        let(a)
        let(c)
        d = 1
        let(d)
        if a:
            return
        if b < c:
            while c:
                d = 0
                let(d)
        return d
    assert test(1, 1)
    assert not test(0, 1)
    assert not test(1, 0)
    assert test(0, 0)



# Generated at 2022-06-25 23:15:49.288731
# Unit test for function extend_tree
def test_extend_tree():
    import pytest


# Generated at 2022-06-25 23:15:56.621904
# Unit test for function extend_tree
def test_extend_tree():
    tree_0 = ast.parse("def funct_0(): x = y")
    extend_tree(tree_0, {'y': [ast.Assign([ast.Name("x", ast.Store())]), ast.Assign([ast.Name("y", ast.Store())])]})
    assert str(tree_0) == "x = 2\ny = 2"


# Generated at 2022-06-25 23:16:04.235339
# Unit test for function extend_tree
def test_extend_tree():
    block = ast.parse('1+2').body[0]
    assert isinstance(block, ast.Expr)
    assert isinstance(block.value, ast.BinOp)
    assert isinstance(block.value.left, ast.Num)
    assert block.value.left.n == 1
    assert isinstance(block.value.op, ast.Add)
    assert isinstance(block.value.right, ast.Num)
    assert block.value.right.n == 2



# Generated at 2022-06-25 23:16:12.387805
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast
    import asttokens
    atok = asttokens.ASTTokens(source=r"""
        import a.b as c
    """, start='single')
    module = atok.tree
    variables = {'c': 'abc'}
    replaced = VariablesReplacer.replace(module, variables)
    assert str(module) == "Module(body=[Import(names=[alias(name='a.b', asname='c')])])"
    assert str(replaced) == "Module(body=[Import(names=[alias(name='a.b', asname='abc')])])"


# Generated at 2022-06-25 23:16:21.173296
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    bool_0 = False
    snippet_0 = snippet(bool_0)
    result_0 = snippet_0.get_body()
    assert result_0 == [ast.Expr(value=ast.Name(id='False', ctx=ast.Load()))]

    def test_fn_1():
        let(var_0)
        var_1 = var_0
        bool_0 = False
        extend(var_1)
    snippet_0 = snippet(test_fn_1)
    result_0 = snippet_0.get_body(var_0=ast.Num(n=1))
    assert isinstance(result_0, list)
    assert len(result_0) == 1

# Generated at 2022-06-25 23:16:28.531523
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    test_tree = ast.parse("from a import r as t")
    test_in_variables = dict()
    test_in_variables['r'] = 'c'
    test_in_variables['t'] = 'd'
    test_expected = ast.parse("from a import c as d")
    test_out_tree = VariablesReplacer.replace(test_tree, test_in_variables)
    assert ast.dump(test_expected) == ast.dump(test_out_tree)


# Generated at 2022-06-25 23:16:48.149414
# Unit test for function extend_tree
def test_extend_tree():

    def test_extend_tree(fn_0: Callable[[], None],
                         var_0: Any, var_1: Any, var_2: Any) -> None:
        """Extends tree with variables"""
        assert fn_0 is None
        assert var_0 is None
        assert var_1 is None
        assert var_2 is None


# Generated at 2022-06-25 23:16:56.970977
# Unit test for function extend_tree
def test_extend_tree():
    globals_from_file = {}
    locals_from_file = {}

    # Assign values to variables
    bool_0 = False
    snippet_0 = snippet(bool_0)
    var_0 = 0
    var_1 = 2
    assert_0 = False
    list_0 = []
    dict_0 = {}
    str_0 = "var_0, var_1"
    str_1 = "assert var_0 == var_1"

    # Check ast:
    expected_0 = ast.parse(str_0)
    expected_1 = ast.parse(str_1)
    actual_0 = extend_tree(
        ast.parse(str_0),
        {'var_0': var_0, 'var_1': var_1}
    )

# Generated at 2022-06-25 23:16:57.515265
# Unit test for function extend_tree
def test_extend_tree():
    pass

# Generated at 2022-06-25 23:16:59.427174
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_case_0()
    print('Test: snippet.get_body: ...done')



# Generated at 2022-06-25 23:17:01.578538
# Unit test for function extend_tree
def test_extend_tree():
    class_0 = ast.NameConstant(False)
    extend_tree(int_0, dict_0)


# Generated at 2022-06-25 23:17:10.092109
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Check if snippet_0.get_body() returns list of 2 ast.Assign nodes
    snippet_0 = snippet(bool_0)
    snippet_0_get_body_outcome = snippet_0.get_body()
    snippet_0_get_body_outcome_types = []
    for node in snippet_0_get_body_outcome:
        snippet_0_get_body_outcome_types.append(type(node))
    snippet_0_get_body_outcome_types_set = set(snippet_0_get_body_outcome_types)
    snippet_0_expected_outcome_types_set = set((ast.Assign,))
    assert snippet_0_get_body_outcome_types_set == snippet_0_expected_outcome_types_set
    # Check if

# Generated at 2022-06-25 23:17:15.105091
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('if x: pass')
    variables = {'x': ast.parse('x, y = 1, 2').body[0]}
    extend_tree(tree, variables)
    assert get_source(tree) == 'x, y = 1, 2\nif x:\n    pass\n'



# Generated at 2022-06-25 23:17:16.006789
# Unit test for function find_variables
def test_find_variables():
    assert False


# Generated at 2022-06-25 23:17:19.024927
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(a)')
    variables = {'a': 'A'}
    extened_tree = extend_tree(tree, variables)
    assert extened_tree == ast.parse('A')

# Generated at 2022-06-25 23:17:20.279071
# Unit test for function extend_tree
def test_extend_tree():
    assert False == True


# Generated at 2022-06-25 23:17:45.271296
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f(a, b):
        let(a)
        b = a
        a += 1
        return b, a
    snippet_0 = snippet(f)
    assert snippet_0.get_body(a=3, b=2) == ast.parse('\n_py_backwards_a_0 += 1\nreturn _py_backwards_a_0, _py_backwards_a_0\n').body


# Generated at 2022-06-25 23:17:53.066842
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(let, extend)
    f0 = fn()
    source_code_0 = get_source(f0)
    snippet_0.get_body(let, extend, source_code_0, f0)
    source_code_1 = get_source(f1)
    snippet_0.get_body(let, extend, source_code_1, f1)
    var_0: ast.Name
    var_1: ast.Name
    if var_0 in snippet_0:
        var_0 = snippet_0.get(var_0)
    else:
        var_0 = snippet_0.put(var_0)
    if var_1 in snippet_0:
        var_1 = snippet_0.get(var_1)
    else:
        var_1 = snippet_0

# Generated at 2022-06-25 23:17:54.803970
# Unit test for function find_variables
def test_find_variables():
    assert list(find_variables(test_case_0())) == ['bool_0']


# Generated at 2022-06-25 23:18:05.384283
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse('let(a); 3')
    assert list(find_variables(tree)) == ['a']
    assert tree.body[0].value == 3
    tree = ast.parse('let(a); let(b); a, b')
    assert list(find_variables(tree)) == ['a', 'b']
    assert tree.body[0].value == ast.Tuple(elts=[ast.Name(id='a', ctx=ast.Load()),
                                                 ast.Name(id='b', ctx=ast.Load())],
                                           ctx=ast.Load())



# Generated at 2022-06-25 23:18:16.592817
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    bool_0 = False
    bool_1 = bool_0
    bool_1 = True
    bool_2 = bool_1
    bool_2 = bool_0

# Generated at 2022-06-25 23:18:23.921312
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    bool_0 = False
    snippet_1 = snippet(bool_0)
    # test to check var bool_0
    body = snippet_1.get_body()
    assert len(body) == 1
    assert isinstance(body[0], ast.Expr)



# Generated at 2022-06-25 23:18:27.668648
# Unit test for function extend_tree
def test_extend_tree():
    tree_0 = ast.parse('if True: print(1); else: print(2)')
    assert isinstance(extend_tree(tree_0, {'var_0': ast.Name(id='var_0', ctx=ast.Load())}), None) == True




# Generated at 2022-06-25 23:18:30.561594
# Unit test for function find_variables
def test_find_variables():
    """This function is a unit test for the function find_variables in the file
        snippet.py
        NOTE: All other classes and functions in the file snippet.py are tested
        with this unit test.
    """

    # Case 1: Valid Case (only case)
    assert set(find_variables(ast.parse('''
    let(x)
    x = 1
    let(y)
    y = 2
    '''))) == {'x', 'y'}



# Generated at 2022-06-25 23:18:38.061729
# Unit test for function find_variables
def test_find_variables():
    bool_0 = False

    def func_0():
        let(bool_0)

        if bool_0:
            return True
        else:
            return False

    assert find_variables(ast.parse(get_source(func_0))) == ['bool_0']

    int_0 = 0
    int_1 = 0

    def func_1():
        let(int_0)
        let(int_1)
        int_0 += int_1

    assert find_variables(ast.parse(get_source(func_1))) == ['int_0', 'int_1']



# Generated at 2022-06-25 23:18:43.281804
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def a():
        let(x)
        x += 1
    snippet_0 = snippet(a)
    x = 2
    stub_0 = snippet_0.get_body(x)
    expected_result_0 = [ast.parse('_py_backwards_x_0 += 1').body[0]]
    assert stub_0 == expected_result_0


# Generated at 2022-06-25 23:18:51.555034
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import pickle
    expected = pickle.loads(b'(lp0\nI0\na.')
    assert snippet_0.get_body() == expected


# Generated at 2022-06-25 23:19:01.545345
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    bool_0 = False
    snippet_0 = snippet(bool_0)

# Generated at 2022-06-25 23:19:03.728546
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Verifies that get_body of class snippet works correctly"""
    assert snippet(test_case_0).get_body() == [bool_0]


# Generated at 2022-06-25 23:19:08.830481
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert ast.dump(snippet_0.get_body()) == "FunctionDef(name='bool_0', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Assign(targets=[Name(_py_backwards_bool_0_0, Store())], value=Name(False, Load()))], decorator_list=[], returns=None)"



# Generated at 2022-06-25 23:19:12.975331
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = """x += 1"""
    tree = ast.parse(source)
    variables = {'x': VariablesGenerator.generate('x')}
    extend_tree(tree, variables)
    VariablesReplacer.replace(tree, variables)
    body = tree.body[0].body
    # for node in body:
    #     print(ast.dump(node))


# Generated at 2022-06-25 23:19:23.909568
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast
    import astor
    x_0 = ast.Name(id='x', ctx=ast.Load())
    x_1 = ast.Name(id='x', ctx=ast.Load())
    y_0 = ast.Name(id='y', ctx=ast.Load())
    print_0 = ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[x_0, y_0], keywords=[])
    test_case_0 = ast.Module(body=[print_0])
    snippet_0 = snippet(test_case_0)
    expected = ast.Module(body=[ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[x_0, y_0], keywords=[]))])


# Generated at 2022-06-25 23:19:30.294830
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Input vars for get_body
    bool_0 = False
    snippet_0 = snippet(bool_0)
    snippet_0_kwargs = {}

    # Expected output vars
    snippet_0_expected = []

    snippet_0_actual = snippet_0.get_body(**snippet_0_kwargs)

    snippet_0_expected_str = \
        '[]'

    snippet_0_actual_str = \
        str(snippet_0_actual)

    assert snippet_0_expected_str == \
        snippet_0_actual_str

if __name__ == '__main__':
    test_case_0()
    test_snippet_get_body()

# Generated at 2022-06-25 23:19:34.108850
# Unit test for function extend_tree
def test_extend_tree():
    vars = ast.parse("x = 1").body
    tree = ast.parse("extend(vars)\nx = 2\nprint(x)")
    extend_tree(tree, {"vars": vars})
    assert get_source(tree) == "\nvars\nx = 2\nprint(x)"



# Generated at 2022-06-25 23:19:44.431543
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test case 0
    bool_0 = False
    snippet_0 = snippet(bool_0)
    assert len(snippet_0.get_body()) == 0
    # Test case 1
    bool_1 = False
    snippet_1 = snippet(bool_1)
    assert len(snippet_1.get_body()) == 0
    # Test case 2
    bool_2 = False
    snippet_2 = snippet(bool_2)
    assert len(snippet_2.get_body()) == 0
    # Test case 3
    bool_3 = False
    snippet_3 = snippet(bool_3)
    assert len(snippet_3.get_body()) == 0
    # Test case 4
    bool_4 = True
    snippet_4 = snippet(bool_4)

# Generated at 2022-06-25 23:19:51.106605
# Unit test for function extend_tree
def test_extend_tree():
    def extend_test_0():
        vars = ast.parse('''
            x = 1
            y = 2
        ''').body
        extend(vars)
    tree = ast.parse(get_source(extend_test_0))
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='y', ctx=Store())], value=Num(n=2))])"


# Generated at 2022-06-25 23:20:11.057456
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('let(var)\n'
                     'var = 10\n'
                     'var += 1\n'
                     'extend(var_list)\n'
                     'var += 1\n')

# Generated at 2022-06-25 23:20:19.131276
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_snippet_get_body_0():
        let(x_0)
        x_0 = 1

    result_0 = ast.parse("x_0 = 1").body
    body_0 = snippet(test_snippet_get_body_0).get_body()
    assert body_0 == result_0



# Generated at 2022-06-25 23:20:28.599596
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert '' == ''.join(str(node) for node in []), 'Incorrect'

# Generated at 2022-06-25 23:20:33.927399
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    bool_0 = False
    snippet_0 = snippet(bool_0)
    with pytest.raises(AssertionError) as e:
        snippet_0.get_body()
    assert e.match(r"Expected type 'int' for 'var_0', but got 'bool'")


# Generated at 2022-06-25 23:20:44.731061
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def get_variables(fn, **kwargs):
        return snippet(fn).get_body(**kwargs)
    source_0 = """
    get_variables(
        bool(false),
        test=ast_Name(
            id='test',
            ctx=ast_Load(
            )
        ),
        undefined=ast_Name(
            id='undefined',
            ctx=ast_Load(
            )
        )
    )
    """
    tree_0 = ast.parse(source_0)
    body_0 = tree_0.body
    # assert len(body_0) == 1
    assert type(body_0[0]) == ast.Expr
    node_0 = body_0[0].value
    # assert type(node_0) == ast.Call
    # assert type(

# Generated at 2022-06-25 23:20:49.413216
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)
    result_0 = snippet_0.get_body()
    assert result_0 == [ast.Assign(targets=[ast.Name(id='bool_0', ctx=ast.Store())], value=ast.Constant(value=False, kind=None))]


# Generated at 2022-06-25 23:20:59.820820
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(lambda: None)
    snippet_0_kwargs: Dict[str, ast.AST] = {}
    snippet_0_kwargs['bool_0'] = ast.Name(id='bool_0', ctx=ast.Load())
    snippet_0_kwargs['bool_1'] = ast.Name(id='bool_1', ctx=ast.Load())
    snippet_0_kwargs['bool_2'] = ast.Name(id='bool_2', ctx=ast.Load())
    snippet_0_kwargs['bool_3'] = ast.Name(id='bool_3', ctx=ast.Load())
    snippet_0_kwargs['bool_4'] = ast.Name(id='bool_4', ctx=ast.Load())
    snippet_0_kwargs['bool_5']

# Generated at 2022-06-25 23:21:02.797230
# Unit test for method get_body of class snippet

# Generated at 2022-06-25 23:21:10.273476
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(lambda: 1 + 2).get_body() == [ast.Expr(ast.BinOp(ast.Num(1), ast.Add(), ast.Num(2)))]
    assert snippet(lambda: [1, 2, 3][2]).get_body() == [ast.Expr(ast.Subscript(ast.List([ast.Num(1), ast.Num(2), ast.Num(3)], ast.Load()), ast.Index(ast.Num(2)), ast.Load()))]
    assert snippet(lambda: 1 if True else 2).get_body() == [ast.Expr(ast.IfExp(ast.NameConstant(True), ast.Num(1), ast.Num(2)))]

# Generated at 2022-06-25 23:21:20.351898
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    bool_0 = False
    snippet_0 = snippet(bool_0)
    # 
    bool_1 = False
    snippet_1 = snippet(bool_1)
    str_2 = str()
    snippet_1.get_body(str_2)
    # 
    bool_3 = False
    snippet_2 = snippet(bool_3)
    int_4 = int()
    snippet_2.get_body(int_4)
    # 
    bool_5 = False
    snippet_3 = snippet(bool_5)
    int_6 = int()
    snippet_3.get_body(int_6)
    int_7 = int()
    snippet_3.get_body(int_7)
    # 
    bool_8 = False
    snippet_4 = snippet(bool_8)


# Generated at 2022-06-25 23:21:44.846975
# Unit test for function find_variables
def test_find_variables():
    snippet_0 = snippet(test_case_0)


# Generated at 2022-06-25 23:21:50.334462
# Unit test for function extend_tree
def test_extend_tree():
    x = 3
    y = 4

    source_0 = "extend(var)\nprint(" + str(x) + ", " + str(y) + ")"
    expected_0 = "var\nprint(" + str(x) + ", " + str(y) + ")"
    tree_0 = ast.parse(source_0)
    extend_tree(tree_0, {"var": ast.parse("x = 2\ny = 4")})
    actual_0 = ast.dump(tree_0)

    assert actual_0 == expected_0

# Generated at 2022-06-25 23:21:55.615404
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    """Test snippet.get_body."""
    def fn(x: ast.Name, let):
        let(x)
    
    snippet_0 = snippet(fn)
    body = snippet_0.get_body(x=ast.Name(id='a', ctx=ast.Load()), let=let)
    assert body[0].value.id == '_py_backwards_x_0'
    assert body[0].value.ctx._fields == ('_py_backwards_x_0', )


# Generated at 2022-06-25 23:22:04.477959
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def __tmp__0():
        let(x)
        x += 1
    tree_0 = __tmp__0.get_body()
    ret_0 = bool(isinstance(tree_0, list))
    assert ret_0
    assert len(tree_0) == 1
    ret_1 = bool(isinstance(tree_0[0], ast.AugAssign))
    assert ret_1
    assert isinstance(tree_0[0].value, ast.Num)
    assert tree_0[0].value.n == 1
    assert tree_0[0].op.__class__.__name__ == 'Add'
    assert tree_0[0].target.__class__.__name__ == 'Name'

# Generated at 2022-06-25 23:22:08.667993
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    assert snippet(test_case_0).get_body() == [ast.Assign(targets=[ast.Name(id='bool_0', ctx=ast.Store())], value=ast.NameConstant(value=False))]


# Generated at 2022-06-25 23:22:10.705123
# Unit test for method get_body of class snippet
def test_snippet_get_body():
  with pytest.raises(TypeError):
    test_case_0()

if __name__ == "__main__":
  test_snippet_get_body()

# Generated at 2022-06-25 23:22:24.365720
# Unit test for function find_variables
def test_find_variables():
    def function0(bool_0):
        bool_1 = bool_0
        bool_2 = bool_1
        bool_1 = bool_2
        bool_3 = not bool_2
        bool_4 = bool_2 if bool_3 else bool_1
        bool_1 = bool_4
        bool_5 = not bool_4
        bool_2 = bool_5
        bool_6 = (not bool_5) if bool_0 else bool_4
        bool_4 = bool_6
        return bool_4
    bool_0 = True
    bool_5 = function0(bool_0)
    bool_3 = bool_5
    assert bool_3 == function0(bool_0)


# Generated at 2022-06-25 23:22:28.539828
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    bool_0 = False
    snippet_0 = snippet(bool_0)
    body_0 = snippet_0.get_body(bool_0)


# Generated at 2022-06-25 23:22:38.541389
# Unit test for method get_body of class snippet

# Generated at 2022-06-25 23:22:45.507871
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Verify that type of `snippet_0` is class snippet

    assert(isinstance(snippet_0, snippet))
    # Verify that length of `snippet_0.get_body()` is 4

    assert(len(snippet_0.get_body()) == 4)
    # Verify that type of first element of `snippet_0.get_body()` is class Assign

    assert(isinstance(snippet_0.get_body()[0], ast.Assign))
    # Verify that type of first element of `snippet_0.get_body()[0].targets` is class Name

    assert(isinstance(snippet_0.get_body()[0].targets[0], ast.Name))
    # Verify that value of variable `snippet_0.get