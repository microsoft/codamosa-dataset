

# Generated at 2022-06-25 23:14:38.725956
# Unit test for function extend_tree
def test_extend_tree():
    func_body = ast.parse('x = 2').body
    input = ast.Module([ast.Expr(ast.Call(ast.Name('extend', ast.Load()),
                                         [ast.Name('var', ast.Load())], []))])
    extend_tree(input, {'var': func_body})
    #print(ast.dump(input))
    #print(ast.dump(ast.Module(func_body + [ast.Expr(ast.Call(ast.Name('extend', ast.Load()),
    #                                                 [ast.Name('var', ast.Load())], []))])))

# Generated at 2022-06-25 23:14:41.897275
# Unit test for function find_variables
def test_find_variables():
    source = '''
let(import_from_0)
import from_0
'''
    tree = ast.parse(source)
    assert set(find_variables(tree)) == set(['import_from_0'])



# Generated at 2022-06-25 23:14:49.681357
# Unit test for function find_variables
def test_find_variables():
    import_from_0 = ast.ImportFrom(module='__future__', names=[ast.alias(name='absolute_import', asname=None), ast.alias(name='print_function', asname=None)], level=0)
    let(import_from_0)

# Generated at 2022-06-25 23:14:56.366953
# Unit test for function extend_tree
def test_extend_tree():
    import_from_0 = ast.ImportFrom(
        module='from_module',
        names=[ast.alias(
            asname=None,
            name='from_name_0',
        )],
    )
    let(import_from_0)
    extend(import_from_0)

    assert import_from_0 == ast.ImportFrom(
        module='from_module',
        names=[ast.alias(
            asname=None,
            name='from_name_1',
        )],
    )

# Generated at 2022-06-25 23:14:59.534416
# Unit test for function find_variables
def test_find_variables():
    import_from_0 = None
    let(import_from_0)
    tree = ast.parse(get_source(test_case_0))
    res = list(find_variables(tree))
    assert res == ['import_from_0']



# Generated at 2022-06-25 23:15:05.226999
# Unit test for function extend_tree
def test_extend_tree():
    import_from_0 = ast.ImportFrom(module='typed_ast.ast3',
                                   names=[ast.alias(name='Name', asname=None)],
                                   level=0)

    tree = ast.parse(
        "extend(import_from_0)\n"
        "def f(a: int, b: int):\n"
        "    let(x)\n"
        "    return x")

    extend_tree(tree, {'import_from_0': import_from_0})

    assert tree.body[0].module == 'typed_ast.ast3'  # type: ignore
    assert tree.body[1].name == 'f'  # type: ignore
    assert tree.body[1].args.args != []  # type: ignore

# Generated at 2022-06-25 23:15:15.806477
# Unit test for function extend_tree
def test_extend_tree():
    import astunparse

    @snippet
    def test_fn():
        let(import_from_0)
        extend(vars)

    vars = [ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())],
                       value=ast.Num(n=4)),
            ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                       value=ast.Num(n=3))]
    import_from_0 = ast.ImportFrom(module='a', names=[ast.alias(name='b', asname=None)], level=0)
    body = test_fn.get_body(import_from_0=import_from_0, vars=vars)

# Generated at 2022-06-25 23:15:24.312643
# Unit test for function extend_tree
def test_extend_tree():
    s = snippet(test_case_0)
    vars_to_extend_tree = {'import_from_0': ast.parse('x = 1\nx = 2')}
    extend_tree(s.get_body(**vars_to_extend_tree), vars_to_extend_tree)
    assert ast.dump(s.get_body(**vars_to_extend_tree)) == "[Assign(targets=[Name(id='_py_backwards_import_from_0_0', ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id='_py_backwards_import_from_0_0', ctx=Store())], value=Num(n=2))]"



# Generated at 2022-06-25 23:15:26.242253
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    body = snippet(test_case_0).get_body()
    assert body == ast.parse("import_from_0 = None").body



# Generated at 2022-06-25 23:15:31.408570
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import_from_0 = None
    let(import_from_0)
    tree = ast.parse('import_from_0 = 2')
    variables = {'import_from_0': tree.body[0]}
    s = snippet(test_case_0)
    tree = ast.parse('import_from_0 = 2')
    assert s.get_body() == tree.body

snippet_1 = snippet(test_case_0)


# Generated at 2022-06-25 23:15:39.289786
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import_from = ast.ImportFrom(module='a.b.c', names=[ast.alias(name='A', asname='B')])

    @snippet
    def s():
        let(import_from)

    assert s.get_body() == [import_from]



# Generated at 2022-06-25 23:15:44.691020
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import unittest

    snippet_obj = snippet(test_case_0)
    expected_body = [ast.parse('None').body[0]]
    actual_body = snippet_obj.get_body()

    class TestSnippetGetBody(unittest.TestCase):
        def test_body(self):
            self.assertEqual(expected_body, actual_body)

    unittest.main()

# Generated at 2022-06-25 23:15:50.895102
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import_from_0 = ast.ImportFrom(
        module='datetime',
        names=[ast.alias(name='datetime', asname=None)],
        level=0,
    )
    s = snippet(test_case_0)
    tree = s.get_body(import_from_0=import_from_0)
    assert tree == [
        let('_py_backwards_import_from_0_0'),
        ast.ImportFrom(
            module='datetime',
            names=[ast.alias(name='datetime', asname=None)],
            level=0,
        )
    ], tree



# Generated at 2022-06-25 23:16:00.192874
# Unit test for function extend_tree
def test_extend_tree():
    from .tree import get_non_exp_parent_and_index, replace_at

    tree = ast.parse(
        'let(a)\n'
        'let(b)\n'
        'let(c)\n'
        'extend(a)\n'
        'extend(b)\n'
        'extend(c)'
    )

# Generated at 2022-06-25 23:16:04.127242
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    function_0 = snippet(test_case_0)
    res = function_0.get_body()
    assert res == [ast.ImportFrom(module='', names=[ast.alias(name='', asname=None)], level=0)]



# Generated at 2022-06-25 23:16:15.895529
# Unit test for function extend_tree
def test_extend_tree():
    snippet_kwargs = {}
    import_from_0 = ast.ImportFrom(
        module='abc',
        names=[ast.alias(
            name='def',
            asname=None
        )]
    )
    snippet_kwargs['import_from_0'] = import_from_0

    import_from_1 = ast.ImportFrom(
        module='abc.q',
        names=[ast.alias(
            name='def',
            asname=None
        )]
    )
    snippet_kwargs['import_from_1'] = import_from_1


# Generated at 2022-06-25 23:16:23.345114
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import pytest
    import ast_tools

    _snippet = ast_tools.snippet(test_case_0)
    body = _snippet.get_body()

    expected_body = '''
import_from_0 = None
    '''.strip()

    assert ast.dump(body) == ast.dump(ast.parse(expected_body))



# Generated at 2022-06-25 23:16:35.671336
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import_from_0 = ast.ImportFrom(module='import_module_0', names=[ast.alias(name='test_alias_0', asname=None)], level=0)
    test_snippet_0 = snippet(test_case_0)
    test_snippet_0_get_body_result = test_snippet_0.get_body(import_from_0=import_from_0)
    test_snippet_0_get_body_expected = [ast.ImportFrom(module='import_module_0', names=[ast.alias(name='test_alias_0', asname=None)], level=0)]
    if not (test_snippet_0_get_body_result == test_snippet_0_get_body_expected):
        test_snippet_0_

# Generated at 2022-06-25 23:16:41.828983
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def let_import_from():
        import_from_0 = ast.parse('from abc import x').body[0]
        let(import_from_0)

    assert let_import_from.get_body() == []



# Generated at 2022-06-25 23:16:47.760705
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .test_tree import is_equal

    @snippet
    def snippet_test_0():
        let(a)
        b = 1

    tree = snippet_test_0.get_body()

    test_0_result = ast.parse('''\
_py_backwards_a_0 = None
b = 1''')
    assert is_equal(tree, test_0_result.body)



# Generated at 2022-06-25 23:16:53.296975
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 23:16:57.223022
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Test for match excepted result
    def test_0():
        class Snippet:
            def get_body(self, **snippet_kwargs: Variable) -> List[ast.AST]:
                return test_case_0()
        test = Snippet()
        assert str(test.get_body()) == str_0

# Generated at 2022-06-25 23:17:06.227747
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def _0():
        str_0 = '\nimport_from_0 = None\n    '
        let(import_from_0)
    _0 = _0()
    value_0 = _0.get_body()
    del _0
    value_1 = value_0[0]
    value_2 = isinstance(value_1, ast.Assign)
    value_3 = value_0[1]
    value_4 = isinstance(value_3, ast.Assign)
    value_5 = isinstance(value_0[2], ast.ImportFrom)
    value_6 = value_0[3]
    value_7 = isinstance(value_6, ast.ImportFrom)
    value_8 = isinstance(value_0[4], ast.ImportFrom)
   

# Generated at 2022-06-25 23:17:10.615931
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    str_1 = 'def fn_0():'
    str_2 = '  extend(vars_0)'
    str_3 = '\n'
    str_4 = 'def main():'
    str_5 = '  print(str_0)'
    list_0 = [str_0, ]
    list_1 = [None, ]
    str_6 = '  let(str_0)'
    list_2 = [str_0, ]
    list_3 = [None, ]
    dict_0: Dict[str, Any] = {'vars_0': list_0}
    dict_1: Dict[str, Any] = {'str_0': str_0}
    list_4 = [str_0, ]

# Generated at 2022-06-25 23:17:15.500905
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    str_2 = 'def test_case_0():\n            str_0 = \'\\nimport_from_0 = None\\n    \'\n        '
    str_3 = '\nimport_from_0 = None\n    '
    str_4 = 'test_case_0()\n    '

# Generated at 2022-06-25 23:17:25.197100
# Unit test for function extend_tree
def test_extend_tree():
    def test_case_0():
        str_0 = '\nfrom typing import Any\nfrom py_backwards.tree import find\nfrom py_backwards.helpers import eager\nfrom py_backwards.extend import extend\n\ndef enumerate_0(iterable_0: Any, start_0: Any=0) -> Any:\n    count_0 = start_0\n    for item_0 in iterable_0:\n        yield count_0, item_0\n        count_0 += 1\n\n    extend(vars)\n    yield 0, 0\n'
        ast_0 = ast.parse(str_0)

# Generated at 2022-06-25 23:17:32.286681
# Unit test for function find_variables
def test_find_variables():
    # Test 1
    source = "let(x)"
    tree = ast.parse(source)
    found_variables = find_variables(tree)

    assert len(found_variables) == 1
    assert found_variables[0] == "x"

    # Test 2
    source = "let(x)\nlet(y)"
    tree = ast.parse(source)
    found_variables = find_variables(tree)

    assert len(found_variables) == 2
    assert found_variables[0] == "x"
    assert found_variables[1] == "y"


# Generated at 2022-06-25 23:17:43.026034
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from unittest import mock
    from .snippet import snippet
    from .type_inference import TypeInferenceVisitor
    from ..type import type_from_callable
    from .tree import apply_type_inference
    code_0 = 'x = 1\ny = 2'
    snippet_0 = snippet(lambda:None)
    fn_0 = lambda:None
    type_0 = type_from_callable(fn_0)
    fn_0 = lambda:None
    type_1 = type_from_callable(fn_0)
    snippet_1 = snippet(lambda:None)
    apply_type_inference(code_0, type_0, TypeInferenceVisitor, {}, {})
    apply_type_inference(code_0, type_1, TypeInferenceVisitor, {}, {})

# Generated at 2022-06-25 23:17:43.902341
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    test_case_0()

# Generated at 2022-06-25 23:17:50.409010
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import astor
    from .test_data import test_data

    test_case = test_data.test_main_0
    ast_0 = test_case.ast_0
    source_0 = test_case.source_0

    def _fn(arg: str) -> None:
        extend(vars)
        pass

    snippet_0 = snippet(_fn)
    result = snippet_0.get_body(vars=ast_0)
    ast_str = astor.to_source(result).strip()
    return ast_str == source_0


# Generated at 2022-06-25 23:18:04.473399
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = get_source(test_case_0)
    tree = ast.parse(source)
    get_body = snippet(test_case_0).get_body
    snippet_kwargs = {'import_from_0': 'str'}
    assert get_body(**snippet_kwargs) == [ast.parse(str_0).body[0]]


# Generated at 2022-06-25 23:18:11.095051
# Unit test for method get_body of class snippet
def test_snippet_get_body():

    @snippet
    def snippet_0(var_0, var_1):
        let(var_0)
        let(var_1)
        var_0 += 1
        var_1 = 1

    tree_0 = snippet_0.get_body(var_0=10, var_1=20)
    assert(get_source(tree_0) == '\n_py_backwards_var_0_0 += 1\n_py_backwards_var_1_0 = 1')

# Generated at 2022-06-25 23:18:21.475824
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0():
        str_0 = '\nimport_from_0 = None\n    '

# Generated at 2022-06-25 23:18:26.605204
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    str_0 = '\nimport_from_0 = None\n    '
    # Test case with no assert
    snippet_0 = snippet(test_case_0)
    # Should end with : None
    assert(snippet_0.get_body()) is None
    # Test another case



# Generated at 2022-06-25 23:18:28.564682
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0():
        str_0 = '\nimport_from_0 = None\n    '


# Generated at 2022-06-25 23:18:30.322951
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    tree = ast.parse(test_case_0.__func__.__doc__)
    result = snippet(test_case_0).get_body()
    for x, y in zip(tree.body, result):
        assert ast.dump(x) == ast.dump(y)

# Generated at 2022-06-25 23:18:37.462376
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    from .context import snippet
    from .context import let
    from .context import extend
    import ast
    import typed_ast.ast3 as ast3
    import astor
    import astor.codegen as codegen
    
    #Part 1: test for case 1
    source_ast1 = snippet(test_case_0).get_body()
    source_code1 = codegen.to_source(source_ast1)
    assert source_code1 == '\nimport_from_0 = None\n    '

    #Part 2: test for case 2



# Generated at 2022-06-25 23:18:43.825494
# Unit test for function find_variables
def test_find_variables():
    '''
    Test for correct AST of find_variables function
    '''
    import ast
    import textwrap
    from .tree import find, findall

    snippet_0 = """let(a)
    let(b)
    def test():
        let(b)
        return a, b
    """
    ast_0 = ast.parse(snippet_0)
    ast.fix_missing_locations(ast_0)
    variables = find_variables(ast_0)
    assert list(variables) == ['a', 'b']
    assert len(find(ast_0, ast.Call)) == 0
    assert len(find(ast_0, ast.Name)) == 3


# Generated at 2022-06-25 23:18:46.330694
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)
    assert snippet_0.get_body(import_from_0=str_0) == []

# Generated at 2022-06-25 23:18:47.327708
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    print('Test #0')



# Generated at 2022-06-25 23:19:11.554734
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    str_0 = '\nimport_from_0 = None\n    '
    test_snippet_0 = snippet(test_case_0)
    assert test_snippet_0.get_body() == [ast.ImportFrom(module='_py_backwards', names=[ast.alias(name='let', asname=None), ast.alias(name='extend', asname=None)], level=0)]

# Generated at 2022-06-25 23:19:22.422333
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)

    # Test 0, args: dict

    dict_0 = dict()
    dict_0['arg_0'] = ast.Name(id='import_from_0', ctx=ast.Load())
    body_0 = snippet_0.get_body(**dict_0)

# Generated at 2022-06-25 23:19:29.960540
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    source = '\ndef foo(z):\n    let(x)\n    let(y)\n    extend(vars)\n    y = x\n    x = y\n    print(x, y)\n    \n\n'
    tree = ast.parse(source)
    # VariablesGenerator.set_seed(1)
    variables = {'y': '_py_backwards_x_0'}
    extended_tree = tree
    variables2 = {'x': '_py_backwards_y_0', 'y': '_py_backwards_x_0', 'vars': [ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=88))]}
    extended_tree2 = extended_tree
    expected_ext

# Generated at 2022-06-25 23:19:36.795310
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # snippet 1
    fn_0 = test_case_0
    snippet_1 = snippet(fn_0)
    body_0 = snippet_1.get_body()
    assert body_0[0].value.s == 'import_from_0'
    # snippet 2
    fn_1 = let
    snippet_2 = snippet(fn_1)
    body_1 = snippet_2.get_body()
    assert body_1[0].value.s == '_py_backwards_x_0'

# Generated at 2022-06-25 23:19:45.903194
# Unit test for function extend_tree
def test_extend_tree():
    str_0 = '\n%(var_2)s += %(var_2)s\n'
    str_1 = '\n%(var_0)s += %(var_2)s\n'
    vars_0 = {'var_1': 'a', 'var_0': 'b'}

# Generated at 2022-06-25 23:19:48.137437
# Unit test for method get_body of class snippet
def test_snippet_get_body():
  import_from_0 = None
  assert snippet(test_case_0).get_body() == [ast.parse(str_0).body[0]]



# Generated at 2022-06-25 23:19:49.301980
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet = snippet(test_case_0)
    snippet.get_body()

# Generated at 2022-06-25 23:19:50.121205
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    ast = snippet.get_body()
    assert ast == ast.parse(str_0)

# Generated at 2022-06-25 23:20:00.011492
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import ast
    import datetime
    a = ast.parse('#first comment\nimport_from_0 = None\n    ')
    b = ast.parse('#first comment\nimport_from_0 = None\n    ')
    c = ast.parse('#first comment\nimport_from_0 = None\n    ')
    d = ast.parse('#first comment\nimport_from_0 = None\n    ')
    e = ast.parse('#first comment\nimport_from_0 = None\n    ')
    f = ast.parse('#first comment\nimport_from_0 = None\n    ')
    g = ast.parse('#first comment\nimport_from_0 = None\n    ')

# Generated at 2022-06-25 23:20:02.676456
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_0():
        let(x_1)
        let(str_1)
        str_2 = x_1


# Generated at 2022-06-25 23:20:19.599007
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def func_0():
        let(x)
        x += 1
        y = 1
    obj_0 = snippet(func_0)
    res_0 = obj_0.get_body()
    assert callable(res_0)  # Type check.


# Generated at 2022-06-25 23:20:24.713650
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    snippet_kwargs_0 = {
        "a": 1,
        "b": 2,
        "c": 3
    }
    l_s_t_0 = snippet.get_body(a_s_t_0, snippet_kwargs_0)

# Generated at 2022-06-25 23:20:35.047408
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def fn_0():
        let(x)
        let(y)
        return x + y

    s_n_i_p_p_e_t_0 = snippet(fn_0)

    def fn_1():
        _py_backwards_x_0 = x
        _py_backwards_y_0 = y
        return _py_backwards_x_0 + _py_backwards_y_0

    a_s_t_0 = ast.parse(get_source(fn_1))

    assert s_n_i_p_p_e_t_0.get_body() == a_s_t_0.body

    def fn_2():
        extend(x)
        return x

    s_n_i_p_p_e_t_1 = snippet(fn_2)

# Generated at 2022-06-25 23:20:45.386460
# Unit test for function find_variables
def test_find_variables():
    print('Test', 'find_variables', sep=' ', end='...')
    import math
    from io import StringIO
    from contextlib import contextmanager
    from types import ModuleType
    old_stdout = sys.stdout
    result = StringIO()
    sys.stdout = result

# Generated at 2022-06-25 23:20:48.526192
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_case_0)
    a_s_t_0 = snippet_0.get_body(a_s_t_0=let(module_0.AST()))


# Generated at 2022-06-25 23:20:53.065490
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    snippet_0 = snippet(test_snippet_get_body)
    dict_0 = {'arg_0':'0a56624f2a5a5bd5a47e5c07f1d0aac6'}
    list_0 = snippet_0.get_body(**dict_0)


# Generated at 2022-06-25 23:21:00.221032
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def _func0(x, *args, y = 0, z = 0, a = 0, b = 0, **kwargs):
        let(x)
        extend(vars)
        return x
    _func0_var0 = module_0.AST()
    test_class_0 = snippet(_func0)
    _func1 = test_class_0.get_body(vars=_func0_var0)

import pytest

if __name__ == '__main__':
    pytest.main(['-x'])

# Generated at 2022-06-25 23:21:08.968424
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_

# Generated at 2022-06-25 23:21:10.316327
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    class_0 = snippet(None)
    lis_0 = class_0.get_body()

# Generated at 2022-06-25 23:21:20.353495
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # Define variables
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
   

# Generated at 2022-06-25 23:21:57.023616
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    imports = [
        ast.Import(names=[ast.alias(name='typed_ast._ast3', asname=None)])
    ]

    body = [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='y', ctx=ast.Store())], value=ast.Num(n=2))
    ]

    code = snippet(lambda: let(x))

    result = code.get_body(x=1, y=2)

    assert result == imports + body

# Generated at 2022-06-25 23:22:06.094171
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    import typed_ast._ast3 as module_1
    def function_1(*args, **kwargs):
        a_s_t_0 = module_1.AST()
        iterable_0 = find_variables(a_s_t_0)
        for a_s_t_0 in iterable_0:
            a_s_t_0 = VariablesGenerator.generate(a_s_t_0)
            yield a_s_t_0
        extend_tree(a_s_t_0, a_s_t_0)
        a_s_t_0 = VariablesReplacer.replace(a_s_t_0, a_s_t_0)
        return a_s_t_0.body[0].body
    a_s_t_1 = module_1.AST

# Generated at 2022-06-25 23:22:07.641084
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def function():
        module_0._ast3.AST()


# Generated at 2022-06-25 23:22:13.063339
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_case_0():
        snippet_instance_0 = snippet(test_case_0)
        a_s_t_0 = snippet_instance_0.get_body()
    def test_case_1():
        snippet_instance_0 = snippet(test_case_1)
        a_s_t_0 = snippet_instance_0.get_body()
    def test_case_2():
        snippet_instance_0 = snippet(test_case_2)
        a_s_t_0 = snippet_instance_0.get_body()

# Generated at 2022-06-25 23:22:16.736900
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    _py_backwards_i_0 = None
    class C:
        def __init__(self, i):
            pass
        @snippet
        def foo(self, x):
            let(i)
            y = 2
            y = x
            return
    
    C._py_backwards_foo._py_backwards_i_0 = _py_backwards_i_0
    C._py_backwards_foo.get_body(i=_py_backwards_i_0)

# Generated at 2022-06-25 23:22:20.253924
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_0(x, y):
        let(x)
        x += 1
        y = 1
    snippet_0 = snippet(snippet_0)
    body = snippet_0.get_body(x=1, y=4)
    assert len(body) == 2

# Generated at 2022-06-25 23:22:21.042284
# Unit test for function extend_tree
def test_extend_tree():
    extend_tree(ast.expr, {})

# Generated at 2022-06-25 23:22:22.931433
# Unit test for function find_variables
def test_find_variables():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 23:22:27.327501
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def f():
        let(x)
        y = x
        z = let(c)
    snippet_0 = snippet(f)
    snippet_0.get_body()

# Generated at 2022-06-25 23:22:31.603974
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet():
        x = 1
    
    res = snippet.get_body()
    
    assert 'x' not in res[0]._fields
    assert '_py_backwards_x_0' in res[0]._fields

# Generated at 2022-06-25 23:23:41.001325
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    for name_0 in iterable_0:
        print(name_0)

import typed_ast._ast3 as module_0

a_s_t_0 = module_0.AST()


# Generated at 2022-06-25 23:23:44.437071
# Unit test for function extend_tree
def test_extend_tree():
    a_s_t_0 = ast.parse('x = 1')
    extend_tree(a_s_t_0, {'x': 'y'})
    assert a_s_t_0.body[0].value.id == 'y'

# Used for testing in snippets.
assert_equals = lambda x, y: (y, x)

# Generated at 2022-06-25 23:23:52.459179
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def func_0():
        let(x)
        x += 1
        y = 1
    test_case_0_0_0 = func_0.get_body()
    test_case_0_0_1 = list()
    a_s_t_0_0 = module_0.Assign()
    a_s_t_0_0._fields = ('targets', 'value', 'type_comment')
    a_s_t_0_0._attributes = ('lineno', 'col_offset', 'end_lineno', 'end_col_offset')
    a_s_t_0_0.targets = (1, 2)
    a_s_t_0_0.value = 1
    a_s_t_0_0.raw = 0
    a

# Generated at 2022-06-25 23:23:59.209732
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    iterable_0 = find_variables(a_s_t_0)
    a_s_t_1 = module_0.AST()
    map_0 = map(a_s_t_1, iterable_0)
    dictionary_0 = {map_0 : map_0}
    instance_0 = snippet(test_snippet_get_body)
    a_s_t_2 = module_0.AST()
    instance_1 = VariablesReplacer.replace(a_s_t_2, dictionary_0)

# Generated at 2022-06-25 23:24:02.968059
# Unit test for function extend_tree
def test_extend_tree():
    test_tree = ast.parse('x = 5')
    variables = {'x': ast.parse('y = 5').body[0]}
    extend_tree(test_tree, variables)
    assert test_tree.body[0].targets[0].id == 'y'


# Generated at 2022-06-25 23:24:05.063220
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a_s_t_0 = module_0.AST()
    dict_0 = dict()
    list_0 = snippet.get_body(a_s_t_0, dict_0)

# Generated at 2022-06-25 23:24:07.735277
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def test_fn_0(arg_0):
        let(arg_0)

    snippet_0 = snippet(test_fn_0)
    list_0 = snippet_0.get_body(arg_0=1)


# Generated at 2022-06-25 23:24:10.126586
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def function(x, y):
        let(x)
        x += 1
        y = 1

    o = snippet(function)
    o_get_body = o.get_body()


# Generated at 2022-06-25 23:24:14.319559
# Unit test for function find_variables
def test_find_variables():
    a_s_t_0 = ast.parse(dedent("""\
        let(x)
        x += 1
        y = 1
        """))
    test_case_0()

snippet1 = snippet(test_case_0)

test_case_0()

test_find_variables()

# Generated at 2022-06-25 23:24:16.104279
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def function_0():
        let(x)

    snippet_0 = snippet(function_0)
    snippet_0.get_body()
