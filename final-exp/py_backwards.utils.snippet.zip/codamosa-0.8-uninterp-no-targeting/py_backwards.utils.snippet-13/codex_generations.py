

# Generated at 2022-06-21 18:41:46.839395
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("x")
    variables = {"x": "y"}
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].value.id == "y"


# Generated at 2022-06-21 18:41:58.063385
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    # case 1
    class Attribute(ast.AST):
        _fields = ('value', 'name')
        _attributes = ('_fields', '__dict__', '__weakref__')
        value = Callable[[], int]
        name = Callable[[], str]
        __dict__ = Dict[str, int]
        __weakref__ = Callable[[], None]
        __init__ = Callable[[], None]
        __repr__ = Callable[[], None]
        __setstate__ = Callable[[int], None]
        __module__ = str
        __annotations__ = Dict[str, bool]

    node = Attribute()
    node.value = 10
    node.name = "value"
    variables = {'value': 'new_value'}

# Generated at 2022-06-21 18:42:02.058208
# Unit test for function find_variables
def test_find_variables():
    ast_tree = ast.parse("""let(x)
    let(y)
    x = 1
    y = 1
    z = 1
    let(z)""")
    assert(list(find_variables(ast_tree)) == ['x', 'y', 'z'])



# Generated at 2022-06-21 18:42:09.716152
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse("""\
        def test():
            extend(x)
            print(x, y)
    """)  # type: ast.Module
    extend_tree(tree, {'x': [ast.parse('x = 1'), ast.parse('x = 2')]})
    print(ast.dump(tree))

# Generated at 2022-06-21 18:42:20.640746
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse('x')
    variables = {}
    VariablesReplacer.replace(tree,variables)
    assert tree == ast.parse('x')

    tree = ast.parse('x')
    variables = {'x': 2}
    VariablesReplacer.replace(tree,variables)
    assert tree == ast.parse('2')

    tree = ast.parse('x')
    variables = {'x': 'x'}
    VariablesReplacer.replace(tree,variables)
    assert tree == ast.parse('x')

    tree = ast.parse('x')
    variables = {'x': ast.parse('2').body[0].value}
    VariablesReplacer.replace(tree,variables)
    assert tree == ast.parse('2')

    tree = ast.parse('x=x')


# Generated at 2022-06-21 18:42:31.215105
# Unit test for function let
def test_let():
    @snippet
    def my_snippet():  # type: ignore # noqa: E501
        let(x)
        let(y)
        x += 1
        y += 2

    body = my_snippet.get_body()

    assert body[0].value.op == 'Add'  # type: ignore # noqa: E501
    assert body[1].value.op == 'Add'  # type: ignore # noqa: E501
    assert body[0].value.left.id == '_py_backwards_x_0'  # type: ignore # noqa: E501
    assert body[1].value.left.id == '_py_backwards_y_0'  # type: ignore # noqa: E501



# Generated at 2022-06-21 18:42:37.374116
# Unit test for function find_variables
def test_find_variables():
    source = '''
let(x)
x += 1
x = 3

for _ in range(10):
    let(y)
    y += 1
    y = 3
    
let(x)
let(z)
'''
    tree = ast.parse(source)
    assert find_variables(tree) == ['x', 'y', 'x', 'z']  # type: ignore

# Generated at 2022-06-21 18:42:38.424310
# Unit test for method visit_alias of class VariablesReplacer

# Generated at 2022-06-21 18:42:39.493269
# Unit test for method visit_arg of class VariablesReplacer

# Generated at 2022-06-21 18:42:44.038320
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():

    source = 'from a.b import c'
    tree = ast.parse(source)
    variables = {'a': 'b', 'c': 'd'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == ast.dump(ast.parse('from b.b import d'))

# Generated at 2022-06-21 18:42:55.654320
# Unit test for function extend_tree

# Generated at 2022-06-21 18:43:00.370016
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = 'from x import y'
    tree = ast.parse(source)
    variables = {'x': 'z'} # type: Dict[str, Variable]
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == 'Module(body=[ImportFrom(module="z", names=[alias(name="y", asname=None)], level=0)])'


# Generated at 2022-06-21 18:43:04.120540
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
  sourceCode = "import a.b.c as d"
  tree = ast.parse(sourceCode)
  alias = tree.body[0].names[0]
  variables = {"d": "e"}
  new_alias = VariablesReplacer.replace(alias, variables)
  assert(new_alias.name == "a.b.c")
  assert(new_alias.asname == "e")



# Generated at 2022-06-21 18:43:10.509771
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    src = """
    def func1(x):
        y = x + 1
        return y
    def func2(x):
        return x + 1
    """
    tree = ast.parse(src)
    variables = {'x': '_py_backwards_x_0'}
    cls = VariablesReplacer(variables)
    cls.visit(tree)

# Generated at 2022-06-21 18:43:21.766393
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("import X; import X.Y.Z; from X import Y; from X.Y import Z; from X import Y as Z; from X.Y import Z as A")
    
    variables = {}
    variables["X"] = ast.Name(id="Y", ctx=ast.Load())
    variables["X.Y"] = ast.Name(id="Z", ctx=ast.Load())
    
    VariablesReplacer.replace(tree, variables)
    import_stmts = [stmt for stmt in tree.body if isinstance(stmt, ast.ImportFrom)]

    # import statements
    assert len(import_stmts) == 6

    assert import_stmts[0].module == "X"
    assert import_stmts[1].module == "Y.Z"

# Generated at 2022-06-21 18:43:31.605298
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    from .tests import test_snippets
    from .dump import dump
    from .helpers import are_equal
    tree = ast.parse("""
    def f():
        pass
    def g():
        pass
    def h():
        pass
    class c:
        def f(self):
            pass
        def g(self):
            pass
        def h(self):
            pass
    """)
    variables = {
            'f': 'z',
            'g': 'k',
            'h': 'l',
    }
    result = VariablesReplacer.replace(tree, variables)
    assert are_equal(result, dump(test_snippets.attributes_variabledefs))

# Generated at 2022-06-21 18:43:32.517802
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    assert VariablesReplacer({})



# Generated at 2022-06-21 18:43:37.959588
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("""import x.y.z\nx.y.z""")
    assert VariablesReplacer.replace(tree, {'x.y.z': 'u'}).body[1].value.value == 'u'


# Generated at 2022-06-21 18:43:42.179464
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""x = let(2)
                        y = let(2)
                        z = let(2)
                        z += 1
                        z += 2
                        z += 3""")
    variables = [name for name in find_variables(tree)]
    assert variables == ['x', 'y', 'z']

# Generated at 2022-06-21 18:43:49.056091
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import astor
    old_name = astor.to_source(ast.alias('old', 'b'))
    expected_result = astor.to_source(ast.alias('new', 'b'))

    alias = ast.alias('old', 'b')
    replacer = VariablesReplacer({'old': 'new'})
    node = replacer.visit(alias)
    assert astor.to_source(node) == expected_result

# Generated at 2022-06-21 18:43:59.972288
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .helpers import get_tree

# Generated at 2022-06-21 18:44:06.253261
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    a = 1

    @snippet
    def gen_1_2():
        let(a)
        a += 1
        return a

    assert gen_1_2.get_body() == [
        ast.parse('_0 = _0 + 1').body[0],
        ast.parse('return _0').body[0],
    ]



# Generated at 2022-06-21 18:44:12.336994
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def add(a: int, b: int) -> int:
        let(x)
        x = a
        x += b
        return x

    src = snippet(add)
    tree = ast.FunctionDef(
        name='add',
        args=ast.arguments(
            args=[ast.arg('a', None), ast.arg('b', None)],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=src.get_body(a=1, b=1),
        decorator_list=[],
        returns=None
    )

# Generated at 2022-06-21 18:44:18.373871
# Unit test for function extend
def test_extend():
    def test():
        x = 1
        x = 2
        print(x, y)

    source = get_source(test)
    tree = ast.parse(source)

    expected = ast.parse("""
    x = 1
    x = 2
    print(x, y)
    """)

    expected = expected.body

    extend_tree(tree, {'vars': expected})

    assert expected == tree.body[0].body



# Generated at 2022-06-21 18:44:26.480542
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    import astor
    from .helpers import VariablesGenerator
    from .tree import find
    from .node_transformers import VariablesReplacer
    
    def target_function():
        pass
    
    TARGET_FUNCTION_NAME = target_function.__name__
    tree = ast.parse(get_source(target_function))
    variables = {TARGET_FUNCTION_NAME: VariablesGenerator.generate(TARGET_FUNCTION_NAME)}
    VariablesReplacer.replace(tree, variables)
    
    assert TARGET_FUNCTION_NAME not in [assignment.target.id for assignment in find(tree, ast.Assign)]
    assert TARGET_FUNCTION_NAME not in [function_def.name for function_def in find(tree, ast.FunctionDef)]
    
    


# Generated at 2022-06-21 18:44:35.924082
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    # test without arguments
    def _test_snippet_get_body_1():
        a = 1
        b = 2

    source = get_source(_test_snippet_get_body_1)
    tree = ast.parse(source)
    assert snippet(_test_snippet_get_body_1).get_body() == tree.body[0].body
    assert snippet(_test_snippet_get_body_1).get_body().__repr__() == '<Call _py_backwards_a_0 at 0x7f40a8d94e10>'  # noqa

    # test with one argument
    def _test_snippet_get_body_2(v: ast.Name):
        let(v)
        for i in range(v):
            v = v - 1



# Generated at 2022-06-21 18:44:47.208497
# Unit test for function extend_tree
def test_extend_tree():
    def foo() -> None:
        x = 1
        extend(vars)
        print(x)

    vars: List[List[ast.AST]] = [
        [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=2))],
        [ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=3))],
    ]

    tree = ast.parse(get_source(foo))
    extend_tree(tree, {'vars': vars})

# Generated at 2022-06-21 18:44:55.816618
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def f(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1
    x = ast.Name(id='x')
    y = ast.Name(id='y')
    snippet_body = f.get_body(x=x, y=y)
    let_stmt = ast.Assign(targets=[x], value=ast.Name(id='_py_backwards_x_0'))
    let_expr = ast.Expr(value=let_stmt)
    assert snippet_body == [let_expr, ast.Assign(targets=[y], value=ast.Num(n=1))]


# Generated at 2022-06-21 18:44:59.636617
# Unit test for function extend_tree
def test_extend_tree():

    source = """
    x = 1
    """

    tree = ast.parse(source)
    extend_tree(tree, {"vars": tree.body})

    assert repr(tree) == repr(ast.parse("""
    x = 1
    x = 1""").body)

# Generated at 2022-06-21 18:45:07.296684
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    test_str = """
        class Test(object):
            def __init__(self, var):
                self.var = var

            def f(self):
                return self.var
        """
    tree = ast.parse(test_str)
    var = VariablesGenerator.generate("Test")
    VariablesReplacer.replace(tree, {"Test": var})
    assert get_source(tree) == "class {0}(object):".format(var)


# Generated at 2022-06-21 18:45:18.139800
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .helpers import get_source
    from .tree import ast_eq
    from .backwards import snippet


# Generated at 2022-06-21 18:45:27.590268
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class ReplaceClass(ast.NodeTransformer):
        def __init__(self, name: str, new_name: str):
            self.name = name
            self.new_name = new_name

        def visit_FunctionDef(self, node):
            node = super().generic_visit(node)
            if node.name == self.name:
                node.name = self.new_name
            return node

    kw = ast.parse('def func(new_name): pass').body[0].body[0].value.keywords[0]
    replacer = ReplaceClass('func', 'asd')
    kw = replacer.visit(kw)
    assert kw.arg == 'asd'

# Generated at 2022-06-21 18:45:39.078821
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import ast
    import os

    from .tree import find

    from .snippet import snippet, let, extend

    @snippet
    def inner_module():
        let(name)
        let(module)
        extend(imports)
        import_module(name, module)

    @snippet
    def import_module(name: str, module: str) -> str:
        let(name)
        let(module)
        extend(imports)
        from_module = f'from {module} import {name}'
        import_module = f'import {name}'
        if from_module in imports:
            return from_module
        elif import_module in imports:
            return import_module
        else:
            raise ValueError('Cannot find module.')


# Generated at 2022-06-21 18:45:43.409694
# Unit test for constructor of class snippet
def test_snippet():
    from .test_utils import assert_ast_equal

    @snippet
    def test_snippet():
        let(x)
        x += 1
        let(y)
        y = 1
        return x, y

    res = test_snippet.get_body()

# Generated at 2022-06-21 18:45:45.385367
# Unit test for constructor of class snippet
def test_snippet():
    snippet(lambda: None)

# Generated at 2022-06-21 18:45:53.075517
# Unit test for function extend
def test_extend():
    def ttt(a, b):
        extend([
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=a)),
            ast.Assign([ast.Name(id='x', ctx=ast.Store())], ast.Num(n=b))
        ])
        print(x)
        print(x)

    import py_backwards.runner

    assert py_backwards.runner.run_source(ttt, 1, 2) == """
    1
    2
    """


# Generated at 2022-06-21 18:45:58.598684
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("def f(x, y=x+1): pass")
    replacer = VariablesReplacer({'x': 'y'})
    replacer.visit_keyword(tree.body[0].args.defaults[0])
    assert tree.body[0].args.defaults[0].value.args[0].id == 'y'

# Generated at 2022-06-21 18:46:05.341481
# Unit test for function extend_tree
def test_extend_tree():
    with open('tests/filesystem.py') as file:
        text = file.read()
    tree = ast.parse(text)
    extend_tree(tree, {
        'f': ast.parse('x += 1').body,
        'g': ast.parse('print(1)').body
    })
    ast.fix_missing_locations(tree)
    target_tree = ast.parse('x += 1\n\nprint(1)')
    ast.fix_missing_locations(target_tree)
    assert ast.dump(tree) == ast.dump(target_tree)


# Generated at 2022-06-21 18:46:12.023623
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():

    class TestClass:
        def fn(self, x, y=2):
            pass

    tree = ast.parse(get_source(TestClass.fn))
    variables = {'y': '_y', 'self': '_self'}
    VariablesReplacer.replace(tree, variables)
    assert [
        ast.arg('x', None), ast.arg('_y', ast.Num(2)), ast.arg('_self', None)
    ] == tree.body[0].args.args  # type: ignore

# Generated at 2022-06-21 18:46:13.771151
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    import typed_ast.ast3  # noqa


# Generated at 2022-06-21 18:46:23.567923
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    tree = ast.parse("class _py_backwards_x_0: pass")
    variables = {"_py_backwards_x_0": "_py_backwards_x_1"}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree.body[0]) == "ClassDef(_py_backwards_x_1, [], [], [], None)"



# Generated at 2022-06-21 18:46:30.748645
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from .tree import get_tree
    from .snippet import snippet
    from .helpers import let

    @snippet
    def snip(prefix="not_default"):
        from .helpers import let
        let(prefix=prefix)
        from .helpers import let as let_alias
        let_alias

    tree = get_tree(snip)
    assert(tree[-1].module == 'not_defaulthelpers')
    assert(tree[-1].names[0].name == 'let')
    assert(tree[-1].names[0].asname == 'let_alias')
    assert(tree[-1].names[1].name == 'let_alias')
    assert(tree[-1].names[1].asname == None)



# Generated at 2022-06-21 18:46:36.116247
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    tree = ast.parse("from a.b import c")
    variables = {
        "b": VariablesGenerator.generate("b")
    }
    VariablesReplacer.replace(tree, variables)
    assert tree.body[0].module == "a.a_b"

# Generated at 2022-06-21 18:46:45.473629
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    class_node = ast.parse('class A(): pass')
    class_body = class_node.body[0].body
    class_body.append(ast.parse('def __init__(self): pass'))

    tree = ast.parse('let(A)\nA()')
    variables = {'A': class_node}
    VariablesReplacer.replace(tree, variables)
    source = get_source(tree)
    assert source == '_py_backwards_A_0()'

    tree = ast.parse('let(x)\nlet(y)\nx = 1\ny = 2\n')
    variables = {'x': '_py_backwards_x_0', 'y': '_py_backwards_y_0'}
    VariablesReplacer.replace(tree, variables)
    source = get

# Generated at 2022-06-21 18:46:51.765437
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
  tree = ast.parse("from long_path.to_constant import constant")
  variables = {}
  variables['long_path.to_constant'] = 'c'
  VariablesReplacer.replace(tree, variables)
  assert isinstance(tree.body[0], ast.ImportFrom)
  assert tree.body[0].module == 'c'


# Generated at 2022-06-21 18:46:55.608881
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_get_body():
        let(1)
        print(1)
        return 2
    res = snippet_get_body.get_body()
    assert res == ast.parse('print(1)\nreturn 2').body

# Generated at 2022-06-21 18:47:02.033366
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = 'from foo import bar'
    tree = ast.parse(source)
    variables = {'foo': 'bar'}
    inst = VariablesReplacer(variables)
    inst.visit(tree)
    new_source = ast.unparse(tree)
    assert new_source == 'from bar import bar'

# Generated at 2022-06-21 18:47:09.444902
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import sys
    my_sys_prefix = sys.prefix
    tree = ast.parse("print(my_sys_prefix)").body[0]
    variables = {'my_sys_prefix': 'some_prefix'}
    VariablesReplacer.replace(tree, variables)
    assert len(tree.args) == 1
    assert isinstance(tree.args[0], ast.Str)
    assert tree.args[0].s == 'some_prefix'



# Generated at 2022-06-21 18:47:09.959851
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-21 18:47:17.066109
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    tree = ast.parse("v = f(a={k: v})")
    var = VariablesGenerator.generate("k")
    variables = { "v": var}
    replacer = VariablesReplacer(variables)
    replacer.visit(tree)
    expected = ast.parse("v = f(a={_py_backwards_k_0: v})")
    tree = deepcopy(tree)
    expected = deepcopy(expected)
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-21 18:47:32.095306
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    asttree = ast.parse("from core.utils.snippets import let")
    variables = {'let': '_py_backwards_let_0'}
    VariablesReplacer.replace(asttree, variables)
    assert ast.dump(asttree) == 'Module(body=[ImportFrom(module=\'core.utils._py_backwards_snippets_0\', names=[alias(name=\'let\', asname=None)], level=0)])'


# Generated at 2022-06-21 18:47:39.700409
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    # Wrapping code in a function
    fn_definition = '''def function():
        try:
            print(1, 2)
        except Exception as e:
            print(e)
        '''
    tree = ast.parse(fn_definition)

    # Testing if transformer works on FunctionDef node
    transformer = VariablesReplacer({"e": 'variable_name'})
    transformer.visit(tree)

    # Creating new ast.FunctionDef to compare with
    fn_definition_with_variable = '''def function():
    try:
        print(1, 2)
    except Exception as variable_name:
        print(variable_name)
    '''
    tree2 = ast.parse(fn_definition_with_variable)

    assert(ast.dump(tree) == ast.dump(tree2))

# Generated at 2022-06-21 18:47:52.005794
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    def f():
        let(x)
        x += 1
        y = 1
        return x + y

    tree = ast.parse(get_source(f))

    variables = {'x': '_py_backwards_x_0',
                 'y': [ast.Assign(
                     targets=[ast.Name(id='x', ctx=ast.Store())],
                     value=ast.Num(n=1))]}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree.body[0].body[2]) == 'Assign(targets=[Name(id=\'x\', ctx=Store())], value=Num(n=1))'


# Generated at 2022-06-21 18:47:56.638665
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    my_class = ast.ClassDef(name='my_class')
    variables = {'my_class': ast.ClassDef(name='my_new_class')}
    assert VariablesReplacer.replace(my_class, variables).name == 'my_new_class'



# Generated at 2022-06-21 18:48:06.251282
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    x = ast.parse("from y import *")
    variables = {"y": "z"}
    replacer = VariablesReplacer(variables)
    replacer.visit(x)
    assert x.body[0].__class__ == ast.ImportFrom
    assert x.body[0].module == "z"

    x = ast.parse("from y.z import *")
    variables = {"y": "a"}
    replacer = VariablesReplacer(variables)
    replacer.visit(x)
    assert x.body[0].__class__ == ast.ImportFrom
    assert x.body[0].module == "a.z"

# Generated at 2022-06-21 18:48:06.896496
# Unit test for function find_variables

# Generated at 2022-06-21 18:48:13.355554
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    def func_arg(a, b=2):
        pass

    setattr(func_arg, '__globals__', {})
    func_arg_src = get_source(func_arg)
    func_arg_tree = ast.parse(func_arg_src)
    func_arg_arg = func_arg_tree.body[0].args.args[0]

    def func_kwarg(a, b=2):
        pass

    setattr(func_kwarg, '__globals__', {})
    func_kwarg_src = get_source(func_kwarg)
    func_kwarg_tree = ast.parse(func_kwarg_src)
    func_kwarg_arg = func_kwarg_tree.body[0].args.kwonlyargs[0]


# Generated at 2022-06-21 18:48:21.057432
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    # source
    source = """
from a import b
from c import d as e
import f
from g import h as i, j as k
    """

    # expected
    expected = ast.parse("""
from a as _py_backwards_a_0 import b as _py_backwards_b_1
from c as _py_backwards_c_2 import d as _py_backwards_d_3 as _py_backwards_e_4
import f as _py_backwards_f_5
from g as _py_backwards_g_6 import h as _py_backwards_h_7 as _py_backwards_i_8, j as _py_backwards_j_9 as _py_backwards_k_10
    """)

    # actual

# Generated at 2022-06-21 18:48:28.045747
# Unit test for constructor of class snippet
def test_snippet():
    x = ast.Name('x', ast.Store())
    y = ast.Name('y', ast.Store())
    z = ast.Name('z', ast.Store())
    x_plus_y = ast.BinOp(x, ast.Add(), y)
    y_plus_z = ast.BinOp(y, ast.Add(), z)
    body = [x_plus_y, y_plus_z]
    tree = ast.Module(body)
    assert ast.dump(tree) == '<Module [<BinOp <Name ctx=Store> op=Add <Name ctx=Store>>, <BinOp <Name ctx=Store> op=Add <Name ctx=Store>>]>'

# Generated at 2022-06-21 18:48:34.606280
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import astor  # type: ignore
    # just for type checking
    source = """
    from datetime import datetime as dt
    """
    tree = ast.parse(source)
    alias = tree.body[0].names[0]
    alias.name = 'xxx'
    alias.asname = 'yyy'
    VariablesReplacer.replace(tree, {})
    assert astor.to_source(tree) == source

# Generated at 2022-06-21 18:48:59.705847
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    class TestClass:
        def test_method_1(self):
            test_class_method_1_var_0 = 5
            return test_class_method_1_var_0

        def test_method_2(self):
            test_class_method_2_var_0 = 5
            return test_class_method_2_var_0
    from .checks import FunctionChecker
    checker = FunctionChecker()
    checker.check_class(TestClass)

# Generated at 2022-06-21 18:49:08.303660
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    import ast
    import io
    import re
    new_name = VariablesGenerator.generate("<module>")
    variables = {'<module>': new_name}
    input_source = """if x:
    pass
x.append(1)
y=1
y=2"""
    
    output_source = """if %s:
    pass
%s.append(1)
y=1
y=2""" % (new_name, new_name)
    
    input_stream = io.StringIO(input_source)
    tree = ast.parse(input_source)
    VariablesReplacer.replace(tree, variables)
    print(ast.dump(tree))
    output_stream = io.StringIO()
    ast.unparse(tree, output_stream)

# Generated at 2022-06-21 18:49:10.306243
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    code = """try:
        pass
except Exception as e:
    print(e)"""
    tree = ast.parse(code)
    variables = {'e': 'e'}
    VariablesReplacer.replace(tree, variables)


# Generated at 2022-06-21 18:49:17.594572
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import_node = ast.ImportFrom(module='foo.bar',
                                 names=[ast.alias(name='foo', asname='bar')])
    variables = {'foo': 'foo2', 'bar': 'bar2'}
    replace = VariablesReplacer.replace
    replace(import_node, variables)
    assert import_node.module == 'foo2.bar'
    assert import_node.names[0].name == 'foo2'
    assert import_node.names[0].asname == 'bar2'


# Generated at 2022-06-21 18:49:25.378406
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    module_ast_node = ast.parse("""
try:
    1
except:
    pass
    """)
    variables = {'E': ast.Name(id="RuntimeError", ctx=ast.Load())}
    VarReplacer = VariablesReplacer(variables)
    visit_result = VarReplacer.visit_ExceptHandler(module_ast_node.body[0].handlers[0])
    assert visit_result.type.id == variables['E'].id # type: ignore

# Generated at 2022-06-21 18:49:32.078578
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    class funcdef(ast.FunctionDef):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)


    class name(ast.Name):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)


    class arg(ast.arg):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)


    funcdef1 = funcdef(name('test_name'), [], [], [])
    funcdef1.name = name('test_name1')
    funcdef1.args = [arg('test_args', None)]
    funcdef1.body = [name('test_body')]
    funcdef1.decorator

# Generated at 2022-06-21 18:49:41.718069
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import ast, sys
    tree = ast.parse('''
from x import y, z as g
from x import k as u
''')
    replacer = VariablesReplacer({'x': 'a', 'y': 'b', 'z': 'c', 'k': 'd'})
    replacer.visit(tree)

# Generated at 2022-06-21 18:49:47.520937
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    variables = {
        'e': ast.arg(arg='_py_backwards_e_0', annotation=None)
    }
    handler = ast.ExceptHandler(type=None, name='e', body=[])
    actual = VariablesReplacer.replace(handler, variables)
    assert actual.name == '_py_backwards_e_0'



# Generated at 2022-06-21 18:49:54.984807
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    class TestClass(ast.NodeVisitor):
        def generic_visit(self, node): # type: ignore
            assert isinstance(node, ast.AST)
            super(TestClass, self).generic_visit(node)

    tree = ast.parse('x = 1')
    replacer = VariablesReplacer({'x': '_py_backwards_x_0'})
    TestClass().visit(replacer.visit_keyword(tree.body[0].value))

# Generated at 2022-06-21 18:50:03.406288
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import _py_backwards_a
    import _py_backwards_b as _py_backwards_b
    import _py_backwards_c as c

    code = '''
    import a
    import b as c
    '''

    module = ast.parse(code)
    variables = {'a': VariablesGenerator.generate('a'),
                 'b': VariablesGenerator.generate('b') }
    VariablesReplacer.replace(module, variables)

    code = test_VariablesReplacer_visit_alias.__code__  # type: ignore
    assert get_source(module) == get_source(code)

# Generated at 2022-06-21 18:50:46.987829
# Unit test for function extend
def test_extend():
    extend(vars)
    print(x, y)
    print(y)


# Generated at 2022-06-21 18:50:48.884670
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    """Test for method visit_Attribute of class VariablesReplacer"""
    import pytest

# Generated at 2022-06-21 18:50:52.455136
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    ast1 = ast.parse('def a(): pass')
    ast2 = ast.parse('def b(): pass')
    vR = VariablesReplacer({'a': 'b'})
    vR.visit_FunctionDef(ast1.body[0])
    assert ast1 == ast2


# Generated at 2022-06-21 18:51:00.908772
# Unit test for function extend
def test_extend():
    import astor


    @snippet
    def test():
        extend(vars)
        print(x, y)


    vars = [ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
            ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))]

    body = test.get_body(vars=vars)
    assert astor.to_source(body) == "x = 1\nx = 2\nprint(x, y)"



# Generated at 2022-06-21 18:51:04.732076
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    variables = {'x': '_py_backwards_x_0'}
    tree = ast.AliasedName(name='x')
    translated_tree = VariablesReplacer.replace(tree, variables)
    assert isinstance(translated_tree, ast.AliasedName)
    assert translated_tree.name == '_py_backwards_x_0'


# Generated at 2022-06-21 18:51:06.749395
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from ..calls import defn
    from .graph import Context

# Generated at 2022-06-21 18:51:11.875238
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    function = ast.parse('def arg(the_arg): pass').body[0]
    variables = {'arg': '_arg'}
    tree = VariablesReplacer.replace(function, variables)
    assert tree.name == 'arg'
    assert tree.args.args[0].arg == '_arg'

# Generated at 2022-06-21 18:51:14.529675
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    try:
        1 / 0
    except BaseException as except_handler_base_except:
        pass
    except Exception as except_handler_exception:
        pass

# Generated at 2022-06-21 18:51:19.197600
# Unit test for constructor of class snippet
def test_snippet():  # type: ignore
    import sys

    def test():
        x = 0
        let(x)
        x += 1
        sys.stdout.write("{}\n".format(x))

    def test_extend():
        y = 0
        extend(y)

    assert snippet(test).get_body() == snippet(test_extend).get_body()



# Generated at 2022-06-21 18:51:24.458791
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # Given:
    source = """
        from mymodule import var
        class Person():
            def say():
                return var
    """
    tree = ast.parse(source)
    variables = {'mymodule': [
        ast.ImportFrom(module='mymodule', names=[ast.alias(name='var', asname='var2')], level=0)
    ]}

    # When:
    VariablesReplacer.replace(tree, variables)
    result = get_source(tree)

    # Then:
    assert result == """
        from mymodule import var2
        class Person():
            def say():
                return var2
    """