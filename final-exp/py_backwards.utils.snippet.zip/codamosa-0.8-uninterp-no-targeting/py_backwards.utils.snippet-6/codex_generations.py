

# Generated at 2022-06-21 18:41:55.797016
# Unit test for function extend
def test_extend():
    from .test_helpers import assert_ast
    from .test_cases import test_case_1, test_case_2

    @snippet
    def snippet_fn(x):
        extend(test_case_2)
        print(x)

    snippet_body = snippet_fn.get_body()

# Generated at 2022-06-21 18:42:04.784130
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    def test_function(x, y, z):
        return x + y + z
    _source = get_source(test_function)
    tree = ast.parse(_source)
    _variables = {'x': '_py_backwards_x_0', 'y': '_py_backwards_y_1', 'z': '_py_backwards_z_2'}
    VariablesReplacer.replace(tree, _variables)
    _new_source = ast.unparse(tree)

# Generated at 2022-06-21 18:42:11.413760
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(_py_backwards_var_)')
    extend_tree(tree, {'_py_backwards_var_': [ast.parse('x = 1').body[0],
                                              ast.parse('y = 2').body[0]]})
    assert ast.dump(tree) == 'Module(body=[Expr(value=Call(func=Name(id="extend", ctx=Load()), args=[Name(id="_py_backwards_var_", ctx=Load())], keywords=[])), Assign(targets=[Name(id="x", ctx=Store())], value=Num(n=1)), Assign(targets=[Name(id="y", ctx=Store())], value=Num(n=2))])'

# Generated at 2022-06-21 18:42:21.137526
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    """Test for method visit_ExceptHandler of class VariablesReplacer.

    """
    from .helpers import parse
    class MyVariablesReplacer(VariablesReplacer):
        def visit_ExceptHandler(self, node):
            node = self._replace_field_or_node(node, 'name')
            return self.generic_visit(node)

    tree = parse('''
    try:
        x = y
    except Exception as ex:
        print(ex)
    ''')
    variables = {'ex': 'e'}
    tree = MyVariablesReplacer.replace(tree, variables)
    assert get_source(tree) == 'try:\n    x = y\nexcept Exception as e:\n    print(e)\n'

# Generated at 2022-06-21 18:42:28.105338
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    # Ideally, the case below could be placed as test case in
    # test_VariablesReplacer_replace. However, it cannot be done due to
    # https://github.com/python/typed_ast/issues/62.
    tree = ast.parse("import something")
    variables = {'something': 'something_else'}
    VariablesReplacer.replace(tree, variables)
    assert ast.dump(tree) == "import something_else"

# Generated at 2022-06-21 18:42:31.563937
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    assert VariablesReplacer.replace(
        ast.parse("class A: pass").body[0], {}
    ) == ast.ClassDef(name="A", body=[], decorator_list=[], lineno=1, col_offset=0)



# Generated at 2022-06-21 18:42:38.593300
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    tree = ast.parse('from m import x, y as z')
    tree = VariablesReplacer.replace(tree, {'m.x': 'a', 'm.y': 'b'})
    assert len(tree.body[0].names) == 3
    assert tree.body[0].names[0].name == 'a'
    assert tree.body[0].names[1].name == 'b'
    assert tree.body[0].names[2].name == 'z'

# Generated at 2022-06-21 18:42:47.394526
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    replace_dict = {'VAR1': 'NAME1'}
    test_dict = {
        'except OWL.OWLException as VAR1':
            'except OWL.OWLException as NAME1',
        'except OWL.OWLException as VAR1:':
            'except OWL.OWLException as NAME1:',
        'except VAR1:':
            'except NAME1:',
        'except VAR1 as v':
            'except NAME1 as v',
        'except VAR1 as v:':
            'except NAME1 as v:',
        'except (VAR1,)':
            'except (NAME1,)',
        'except (VAR1,):':
            'except (NAME1,):',
    }

# Generated at 2022-06-21 18:42:49.708678
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-21 18:43:00.074811
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse('let(x)x+x')
    assert ast.dump(tree) == "Module(body=[Expr(value=Call(func=Name(id='let', ctx=Load()), args=[Name(id='x', ctx=Load())], keywords=[], starargs=None, kwargs=None)), Expr(value=BinOp(left=Name(id='x', ctx=Load()), op=Add(), right=Name(id='x', ctx=Load())))])"

    variables = {'x': '_py_backwards_x_0'}
    result = VariablesReplacer.replace(tree, variables)

# Generated at 2022-06-21 18:43:18.215369
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    code = "print(123)"
    tree = ast.parse(code)
    assert tree.body[0].value.func.attr == "print"
    
    variables = {"print": ast.Name(id="print", ctx=ast.Load())}
    
    assert VariablesReplacer.replace(tree, variables).body[0].value.func.attr == "print"


# Generated at 2022-06-21 18:43:18.870518
# Unit test for function find_variables

# Generated at 2022-06-21 18:43:23.507790
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    tree = ast.parse('''
    try:
        x = 1
    except:
        pass
    ''')
    variables = {'x': 'foo'}
    VariablesReplacer.replace(tree, variables)
    node = find(tree, ast.ExceptHandler)[0]
    assert node.name is None


# Generated at 2022-06-21 18:43:32.715780
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    a=ast.Name(id="a", ctx=ast.Load())
    b=ast.Name(id="b", ctx=ast.Store())
    c=ast.Name(id="c", ctx=ast.Store())
    new_node=ast.Name(id="new_var", ctx=ast.Store())

# Generated at 2022-06-21 18:43:34.224011
# Unit test for constructor of class snippet
def test_snippet():
    snippet(None)

# Generated at 2022-06-21 18:43:44.849751
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    # Test for alias
    alias = ast.Alias(name="name", asname=None)
    variables = {"name": "_py_backwards_name_0"}

    alias_result = VariablesReplacer.visit_alias(alias, variables)
    assert alias_result.name == "_py_backwards_name_0"

    # Test for alias (with asname)
    alias = ast.Alias(name="name", asname="asname")
    variables = {"name": "_py_backwards_name_0"}

    alias_result = VariablesReplacer.visit_alias(alias, variables)
    assert alias_result.name == "_py_backwards_name_0"
    assert alias_result.asname == "asname"

    # Test for alias name

# Generated at 2022-06-21 18:43:55.900042
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():

    # Arguments:
    #   node: ast.arg
    
    # Returns:
    #   node: ast.arg

    func_decorator_arguments = {"node": ast.arg(arg="arg", annotation=None)}

    # Call VariablesReplacer._replace_field_or_node:
    node = VariablesReplacer._replace_field_or_node(func_decorator_arguments["node"], field="arg", all_types=True)

    # Call VariablesReplacer.generic_visit:
    # node = VariablesReplacer.generic_visit(func_decorator_arguments["node"])

    # assertEqual will raise AssertionError if the two items are not equal:
    assertEqual(node, ast.arg(arg="arg", annotation=None))



# Generated at 2022-06-21 18:44:08.540496
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from typed_ast import ast3
    replace = VariablesReplacer.replace
    var = ast3.alias(name='a', asname='b')
    tree = ast3.Name(id='a', ctx=ast3.Load())
    var.name = 'a'
    var.asname = 'b'
    tree1 = ast3.alias(name='a')
    old_name = 'a'
    alias_name = 'b'
    variables = {old_name: alias_name}
    a, b = replace(tree, variables)
    a, b = replace(tree1, {'a': 'a'})
    a, b = replace(var, {'a': 'a'})
    #assert a.id == alias_name
    #assert b.name == alias_name

# Generated at 2022-06-21 18:44:17.240462
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    def snippet_function():
        let(x)
        x = y
        y = 1

        return x

    assert snippet(snippet_function).get_body() == [
        ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())], ast.Name('y', ast.Load())),
        ast.Assign([ast.Name('y', ast.Store())], ast.Constant(1, None)),
        ast.Return(ast.Name('_py_backwards_x_0', ast.Load()))
    ]



# Generated at 2022-06-21 18:44:21.803479
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    class Test:
        def class_name(self):
            pass

    source = get_source(Test)
    tree = ast.parse(source)
    variables = {'class_name': 'new_name'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree)
    assert tree.body[0].name == 'new_name'



# Generated at 2022-06-21 18:44:33.992942
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    test_data_input = ast.parse("x('x', x=3)")
    test_data_variables = {"x": "y"}
    VariablesReplacer.replace(test_data_input, test_data_variables)

    assert test_data_input.body[0].value.func.id == "x"
    assert test_data_input.body[0].value.args[0].s == "x"
    assert test_data_input.body[0].value.keywords[0].value == 3
    assert test_data_input.body[0].value.keywords[0].arg == "x"

# Generated at 2022-06-21 18:44:43.402074
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    """Unit test for VariablesReplacer.visit_ExceptHandler method."""
    original_code = """
    try:
        2 + 2
    except InvalidOperation as e:
        pass 
    """
    expected_code = """
    try:
        2 + 2
    except InvalidOperation as e:
        pass 
    """
    variables = {'e': 'updated_e'}

    snippet_ast = ast.parse(original_code)
    VariablesReplacer.replace(snippet_ast, variables)
    actual_code = get_source(snippet_ast)
    assert expected_code == actual_code

# Generated at 2022-06-21 18:44:46.963177
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(var)')
    var = ast.parse('let(a)')
    extend_tree(tree, {'var': var})
    assert tree == ast.parse('let(a)')

# Generated at 2022-06-21 18:44:56.135905
# Unit test for function extend

# Generated at 2022-06-21 18:45:02.042070
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    from lexer import lexer
    from parser import parser
    from typing import List

    snippet_text = 'a.b.c'
    snippet_ast = parser.parse(lexer.lex(snippet_text))
    replacer_visitor = VariablesReplacer()
    import_from_node = ast.ImportFrom(module='d.e.f', level=0)
    replacer_visitor.visit(import_from_node)
    assert(import_from_node.module == 'd.e.f')


# Generated at 2022-06-21 18:45:08.105092
# Unit test for function extend
def test_extend():
    @snippet
    def test_snippet(x: int) -> int:
        """Returns x + 1."""
        x += 1
        y = 1
        return x + y

    extend({"x": 1, "y": 2})
    res = test_snippet(1)
    assert res == 3, res



# Generated at 2022-06-21 18:45:17.055052
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('extend(x)')
    tree.body[:].clear()
    tree.body.append(ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=5)))
    extend_tree(tree, {'x': [ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=1)),
                              ast.Assign(targets=[ast.Name(id='x')], value=ast.Num(n=2))]})
    assert str(tree) == """
    x = 1
    x = 2
    x = 5
    """


test_extend_tree()

# Generated at 2022-06-21 18:45:26.415182
# Unit test for method get_body of class snippet
def test_snippet_get_body():
    @snippet
    def snippet_fn(a: int, b: int) -> int:
        let(x)
        x += 1
        x += 1
        return x + a + b

    # print(ast.dump(snippet_fn.get_body(a=ast.Name("z", ast.Load()), b=1)))
    as_module = ast.Module(snippet_fn.get_body())
    codeobj = compile(as_module, "<py_backwards>", "exec")
    env = {}
    exec(codeobj, env)
    assert env["_py_backwards_x_0"] == 3

# Generated at 2022-06-21 18:45:31.285357
# Unit test for function extend
def test_extend():
    @snippet
    def test():
        x = 1
        y = 0
        extend(vars)
        y += x

        def test(vars):
            x = 2

    code = test.get_body(vars={'x': 2})
    assert code[0].value.value == 1
    assert code[1].value.value == 0
    assert code[3].value.value == 1
    assert code[4].value.left.id == 'y'
    assert code[4].value.func.id == 'add'
    assert code[4].value.args[0].id == 'x'


# Generated at 2022-06-21 18:45:36.383716
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    v = VariablesReplacer({'x': 'y'})
    assert repr(v.visit_Attribute(ast.Attribute(value=ast.Name(id='x'), attr='y', ctx=ast.Load))) == '<_ast.Attribute object at 0x000001E7B0F1D748>'

# Generated at 2022-06-21 18:45:40.645086
# Unit test for constructor of class snippet
def test_snippet():
    assert snippet is snippet

# Generated at 2022-06-21 18:45:45.423318
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    source = '''
    def test(a):
        print(a)
    '''
    tree = ast.parse(source)
    variables = {'test': 'test1'}
    VariablesReplacer.replace(tree, variables)
    source1 = '''
    def test1(a):
        print(a)
    '''
    assert source1 == ast.unparse(tree)



# Generated at 2022-06-21 18:45:56.194258
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    class Sub(VariablesReplacer):
        def __init__(self, variables: Dict[str, Variable]):
            super().__init__(variables)
        def generic_visit(self, node: ast.Node) -> ast.Node:
            return node

    v = VariablesReplacer({'a': 42, 42: 'a'})
    assert isinstance(v.visit(ast.Name(id=42, ctx=ast.Load())), ast.Name)
    s = Sub({'a': 42, 42: 'a'})
    assert isinstance(s.visit(ast.Name(id=42, ctx=ast.Load())), ast.Name)

# Generated at 2022-06-21 18:46:05.673482
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    import sys
    import os
    import unittest
    
    sys.path.append('../')
    from src.generator import VariablesReplacer
    
    
    class Test_VariablesReplacer(unittest.TestCase):
        def test_visit_Attribute(self):
            a = ast.Attribute()
            a.lineno = 'lineno'
            a.col_offset = 'col_offset'
            a.name = 'name'
            a.ctx = 'ctx'
            a.value = 'value'
            
            variables = {'name': '_0'}
            
            vr = VariablesReplacer(variables)
            
            vr.visit(a)
            
            self.assertEqual('_0', a.name)
    
    
    unittest.main

# Generated at 2022-06-21 18:46:08.464814
# Unit test for method visit_keyword of class VariablesReplacer
def test_VariablesReplacer_visit_keyword():
    node = ast.parse('fn(a=1)')
    variables = {'q_0': 'q_1'}
    VariablesReplacer(variables).visit(node)
    assert get_source(node) == 'fn(a_0=1)'

# Generated at 2022-06-21 18:46:16.792211
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    class MyVariablesReplacer(VariablesReplacer):
        def visit_alias(self, node: ast.alias) -> ast.alias:
            node.name = self._replace_module(node.name)
            node = self._replace_field_or_node(node, 'asname')
            return self.generic_visit(node)  # type: ignore

    variables = {'a': 'b'}
    inst = MyVariablesReplacer(variables)
    source = "from a import a as c"
    tree = ast.parse(source)
    result = get_source(inst.visit(tree))
    assert result == "from b import b as b"



# Generated at 2022-06-21 18:46:21.745226
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    tree = ast.parse('class x: pass').body[0]
    variables = {'x': 'y'}
    tree = VariablesReplacer.replace(tree, variables)
    assert isinstance(tree, ast.ClassDef)
    assert tree.name == 'y'


# Generated at 2022-06-21 18:46:30.134588
# Unit test for function find_variables
def test_find_variables():
    source = """
        a = 5
        let(b)
        c = let(d)
        d = 10
    """
    tree = ast.parse(source)
    assert find_variables(tree) == ['b', 'd']

# Generated at 2022-06-21 18:46:38.301238
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    source = 'def foo():\n try:\n  1/0\n except ZeroDivisionError as e:\n  e+1'
    tree = ast.parse(source)
    VariablesReplacer.replace(tree, {'e': 'f'})
    assert get_source(tree) == 'def foo():\n try:\n  1/0\n except ZeroDivisionError as f:\n  f+1'


# Unit tests for method get_body of class snippet

# Generated at 2022-06-21 18:46:48.098615
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    source = """from . import x"""
    tree = ast.parse(source)
    variables = {'x': 'z'}
    result = VariablesReplacer.replace(tree, variables)
    assert(source != ast.dump(result))
    result = ast.dump(result)
    assert(result == "ImportFrom(module='.', names=[alias(name='x', asname=None)], level=0)")
    source = """from . import x,y,z"""
    tree = ast.parse(source)
    variables = {'x': 'a', 'y': 'b', 'z': 'c'}
    result = VariablesReplacer.replace(tree, variables)
    assert(source != ast.dump(result))
    result = ast.dump(result)

# Generated at 2022-06-21 18:47:02.183973
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    from py_backwards.utils import import_helper
    from py_backwards.helpers import VariablesGenerator
    module = ast.Module(body=[])
    var_name = 'var1'
    var_asname = 'var2'
    module.body.append(ast.Import(names=[
        ast.alias(name=var_name, asname=var_asname)
    ]))
    variables = {var_name: VariablesGenerator.generate(var_name)}
    VariablesReplacer.replace(module, variables)
    result = import_helper.get_imports_from_tree(module)[var_name]
    assert result == var_asname



# Generated at 2022-06-21 18:47:12.822662
# Unit test for function let
def test_let():
    @snippet
    def s(x: int, y: int) -> None:
        let(x)
        x += 1
        y = 1


# Generated at 2022-06-21 18:47:13.858931
# Unit test for method visit_FunctionDef of class VariablesReplacer

# Generated at 2022-06-21 18:47:20.953640
# Unit test for function extend_tree
def test_extend_tree():
    source = """extend(vars)"""
    source_result = """x = 1\nx = 2"""
    tree = ast.parse(source)
    extended_tree = ast.parse(source_result)
    extend_tree(tree, {'vars': extended_tree.body})
    assert get_source(tree) == source_result


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 18:47:25.447440
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    input_ast = ast.parse("from x.y import z as w")
    source = get_source(input_ast)
    tree = ast.parse(source)
    variables = {'z': 'z_', 'w': 'w_'}
    VariablesReplacer.replace(tree, variables)
    result = get_source(tree)
    assert result == "from x.y import z_ as w_"



# Generated at 2022-06-21 18:47:36.443997
# Unit test for function extend
def test_extend():
    @snippet
    def s(x, y):
        extend(m)
        print(x)
        print(y)

    tree = s(x=1, y=2, m=[
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=1)),
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                   value=ast.Num(n=2)),
    ])
    assert ast.dump(tree[0]) == ast.dump(ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                                    value=ast.Num(n=1)))
    assert ast.dump(tree[1]) == ast.dump

# Generated at 2022-06-21 18:47:41.700729
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse('a = 1')
    tree = VariablesReplacer.replace(tree, {'a': 'b'})
    assert ast.dump(tree) == 'Assign(targets=[Name(id=b, ctx=Store())], value=Num(n=1))'

# Generated at 2022-06-21 18:47:47.662344
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    class_def = ast.ClassDef(name='TestException', bases=[], keywords=[],
                             body=[ast.ExceptHandler(type=None, body=[ast.Pass()])],
                             decorator_list=[])
    VariablesReplacer.replace(class_def, {'TestException': 'TestException1'})
    assert class_def.name == 'TestException1'

# Generated at 2022-06-21 18:47:57.302694
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    tree = ast.parse("""
foo.bar.baz = 'foobar'
""")

    variables = {'foo': '_py_backwards_foo_0'}
    tree = VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == """_py_backwards_foo_0.bar.baz = 'foobar'\n"""

    variables = {'bar': '_py_backwards_bar_0'}
    tree = VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == """foo._py_backwards_bar_0.baz = 'foobar'\n"""

    variables = {'baz': '_py_backwards_baz_0'}
    tree = VariablesReplacer.replace(tree, variables)
    assert get

# Generated at 2022-06-21 18:47:58.976353
# Unit test for constructor of class snippet
def test_snippet():
    assert isinstance(snippet(lambda x: 1), snippet)

# Generated at 2022-06-21 18:48:14.115145
# Unit test for function extend_tree
def test_extend_tree():
    tree = ast.parse('''
    def fn(x):
        extend(vars)
        print(x)
    ''')

    extend_tree(tree, {'vars': [
        ast.Assign(
            targets=[ast.Name(id='x', ctx=ast.Store())],
            value=ast.Num(1),
        )
    ]})

    assert tree == ast.parse('''
    def fn(x):
        x = 1
        print(x)
    ''')



# Generated at 2022-06-21 18:48:25.781966
# Unit test for method visit_arg of class VariablesReplacer
def test_VariablesReplacer_visit_arg():
    string = "def f(x): return x\n"
    ast_object = ast.parse(string)
    vg = VariablesGenerator()
    name = vg.generate()
    variables = {'x': name}
    replacer = VariablesReplacer(variables)
    replacer.visit(ast_object)
    actual = ast.dump(ast_object)
    expected = "FunctionDef(name='f', args=arguments(args=[arg(arg='py_backwards_x_0', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Name(id='py_backwards_x_0', ctx=Load()))], decorator_list=[], returns=None)"

# Generated at 2022-06-21 18:48:31.141837
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    t = ast.parse(
        "attribute")

    t_v = VariablesReplacer.replace(t, {"attribute": "var"})

    assert isinstance(t_v, ast.Expression)
    assert isinstance(t_v.body, ast.Name)
    assert t_v.body.id == "var"



# Generated at 2022-06-21 18:48:41.176853
# Unit test for function let

# Generated at 2022-06-21 18:48:51.299623
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    source = """
    from spam.foo import bar as _py_backwards_bar_1
    bar = _py_backwards_bar_1
    """
    tr = ast.parse(source)
    VariablesReplacer.replace(tr, {})
    result = ast.dump(tr)
    expected = """
    Module(body=[
        ImportFrom(module='spam.foo', names=[alias(name='bar', asname='_py_backwards_bar_1')], level=0),
        Assign(targets=[Name(id='bar', ctx=Store())], value=Name(id='_py_backwards_bar_1', ctx=Load()))
    ])
    """
    assert result == expected

# Generated at 2022-06-21 18:48:56.146215
# Unit test for function find_variables
def test_find_variables():
    for tree, result in (
        (
            ast.parse(
                """
                let(x)
                x = 1
                let(y)
                y = 2
                z = 3
                """
            ),
            ["x", "y"]
        ),
        (
            ast.parse(
                """
                let(x)
                x = 1
                extend(y)
                y = 2
                z = 3
                """
            ),
            ["x", "y"]
        ),
    ):
        assert list(find_variables(tree)) == result

# Generated at 2022-06-21 18:48:57.654848
# Unit test for constructor of class snippet
def test_snippet():
    snippet_ = snippet(test_snippet)
    assert snippet_


# Generated at 2022-06-21 18:49:07.511633
# Unit test for method visit_Name of class VariablesReplacer

# Generated at 2022-06-21 18:49:09.627351
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    tree = ast.parse("""f = lambda x: x""")
    variables = {'f': 'df'}
    VariablesReplacer.replace(tree, variables)
    assert get_source(tree) == """df = lambda x: x"""

# Generated at 2022-06-21 18:49:19.766871
# Unit test for function let
def test_let():
    def fn():
        a = 1
        let(a)
        a += 1

    expected = """
    a = 1
    _var1 = 1
    _var1 += 1
    """

    snippet_body = snippet(fn).get_body()
    assert ast.dump(snippet_body) == ast.dump(ast.parse(expected))

    # Test for expressions
    def fn():
        a = 1
        let(a + 2)
        a += 1

    expected = """
    a = 1
    _var1 = 1 + 2
    a += 1
    """

    snippet_body = snippet(fn).get_body()
    assert ast.dump(snippet_body) == ast.dump(ast.parse(expected))



# Generated at 2022-06-21 18:49:44.935430
# Unit test for function extend
def test_extend():
    @snippet
    def _ext(extend, vars, let):
        extend(vars)
        print(x, y, z)

    class X:
        def assign(self, a, b):
            x = a + b

    x = X()
    x.assign(1, 2)
    vars = [
            ast.Assign(targets=[ast.Name(id=a, ctx=ast.Store())], value=ast.Num(b))
            for (a, b) in zip('yxz', [1, 2, 3])
            ]
    _ext(vars, let='test')
    assert(test == 'test')
    assert(x == 1)
    assert(y == 2)
    assert(z == 3)


# Generated at 2022-06-21 18:49:56.746058
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    # Code before replacing
    var1 = ast.Name(id='var1')
    var2 = ast.Name(id='var2')
    var1_arg = ast.arg(arg='var1')
    var2_arg = ast.arg(arg='var2')
    stmt1 = ast.parse('var1 = var1').body[0]
    stmt2 = ast.parse('var2 = var2').body[0]
    funcbody = [stmt1, stmt2]
    funcdef = ast.FunctionDef(name='func', args=ast.arguments(args=[var1_arg, var2_arg], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=funcbody, decorator_list=[], returns=None)

    # Ex

# Generated at 2022-06-21 18:50:00.131970
# Unit test for function find_variables
def test_find_variables():
    tree = ast.parse("""
if let(x):
    pass
""")
    assert list(find_variables(tree)) == ['x']
    assert isinstance(ast.dump(tree, include_attributes=True), str)



# Generated at 2022-06-21 18:50:09.073910
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    tree = ast.parse("""
        class A:
            def f(self):
                self.x = 1
                self.x = 2
            def g(self):
                return self.x + self.y
    """)

# Generated at 2022-06-21 18:50:16.354769
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
    r = VariablesReplacer({})
    assert isinstance(r.visit_Attribute(ast.Attribute(value=ast.Name(id="a", ctx=ast.Load()), attr="attr", ctx=ast.Load())), ast.Attribute)
    assert isinstance(r.visit_Attribute(ast.Attribute(value=ast.Name(id="a", ctx=ast.Load()), attr="attr", ctx=ast.Store())), ast.Attribute)

# Generated at 2022-06-21 18:50:24.413168
# Unit test for method visit_ExceptHandler of class VariablesReplacer
def test_VariablesReplacer_visit_ExceptHandler():
    from .helpers import get_tree
    
    given_tree: ast.AST = ast.parse(
        '''def my_function():
            try:
                x = 1
            except Exception:
                raise Exception
        '''
    )
    
    actual_tree: ast.AST = VariablesReplacer.replace(given_tree, {})
    expected_tree: ast.AST = get_tree(
        '''def my_function():
            try:
                x = 1
            except Exception:
                raise Exception
        '''
    )

    assert actual_tree == expected_tree

# Generated at 2022-06-21 18:50:24.752456
# Unit test for constructor of class snippet
def test_snippet():
    snippet('foo')

# Generated at 2022-06-21 18:50:26.489584
# Unit test for method visit_Name of class VariablesReplacer
def test_VariablesReplacer_visit_Name():
    f = ast.parse('var')
    f = VariablesReplacer({'var': 'x'}).visit_Name(f)
    assert f.id == 'x'


# Generated at 2022-06-21 18:50:28.904714
# Unit test for constructor of class VariablesReplacer
def test_VariablesReplacer():
    source = get_source(VariablesReplacer)
    tree = ast.parse(source)
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.ClassDef)

# Generated at 2022-06-21 18:50:32.379103
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    aliase = ast.parse("from x import y as z").body[0]
    variables = {'x': 'X'}

    VariablesReplacer(variables).visit(aliase)
    assert isinstance(aliase, ast.ImportFrom)
    assert aliase.module == 'X'
    assert aliase.names[0].name == 'y'
    assert aliase.names[0].asname == 'z'


# Generated at 2022-06-21 18:50:55.582045
# Unit test for constructor of class VariablesReplacer

# Generated at 2022-06-21 18:51:02.758728
# Unit test for method visit_Attribute of class VariablesReplacer
def test_VariablesReplacer_visit_Attribute():
	class ExtendAttribute(VariablesReplacer):
		def visit_Attribute(self, node: ast.Attribute) -> ast.Attribute:
			node = super().visit_Attribute(node)
			node.attr = "name "+node.attr
			return node
			
	result = ExtendAttribute.replace(ast.parse("a.b").body[0].value, {})
	assert result.attr == "name b"
	

# Generated at 2022-06-21 18:51:03.103790
# Unit test for function find_variables

# Generated at 2022-06-21 18:51:12.359157
# Unit test for function extend
def test_extend():
    vars = ast.parse('''x = 2
                    x = 3
                    print(1)''').body  # type: ignore
    source = '''extend(vars)
                print(x)'''
    tree = ast.parse(source)
    extend_tree(tree, {'vars': vars})
    assert ast.dump(tree) == '''Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Num(n=1)], keywords=[])), Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Name(id='x', ctx=Load())], keywords=[]))])'''  # noqa: E501



# Generated at 2022-06-21 18:51:17.235536
# Unit test for method visit_alias of class VariablesReplacer
def test_VariablesReplacer_visit_alias():
    import typed_astunparse
    input_string = 'from math import pi'
    visit_alias_ast = ast.parse(input_string)
    output_string = typed_astunparse.unparse(VariablesReplacer.replace(visit_alias_ast, {}))
    assert output_string == input_string


# Generated at 2022-06-21 18:51:19.659018
# Unit test for method visit_ClassDef of class VariablesReplacer
def test_VariablesReplacer_visit_ClassDef():
    x = ast.ClassDef(name='x', body=[ast.Pass()])
    z = ast.ClassDef(name='z', body=[ast.Pass()])

# Generated at 2022-06-21 18:51:23.366604
# Unit test for method visit_ImportFrom of class VariablesReplacer
def test_VariablesReplacer_visit_ImportFrom():
    import_from = ast.parse('from a.b.c import d').body[0]
    variables = {'a': 'aa', 'c_': 'cc'}
    expected = ast.ImportFrom('aa.b.cc', [], [], 0, None)
    actual = VariablesReplacer.replace(import_from, variables)

    assert expected == actual, 'Module names should be replaced'

# Generated at 2022-06-21 18:51:30.780078
# Unit test for function let
def test_let():
    @snippet
    def t(x):
        let(x)
        x += 1
        y = 1

    assert t.get_body(x=1) == [
        ast.Assign([ast.Name('_py_backwards_x_0', ast.Store())], ast.BinOp(ast.Name('_py_backwards_x_0', ast.Load()), ast.Add(),
                                                                          ast.Num(1))),
        ast.Assign([ast.Name('y', ast.Store())], ast.Num(1))]


# Generated at 2022-06-21 18:51:38.034591
# Unit test for method visit_FunctionDef of class VariablesReplacer
def test_VariablesReplacer_visit_FunctionDef():
    s = snippet(lambda: let(x))
    parent = ast.FunctionDef(name='test', args=ast.arguments(args=[ast.arg(arg='a', annotation=None)],
                                                             vararg=None, kwonlyargs=[], kw_defaults=[],
                                                             kwarg=None, defaults=[]),
                             body=s.get_body())

    tree = ast.Module(body=[parent])
    VariablesReplacer.replace(tree, {'x': 'y'})

    assert tree.body[0].name == 'test'
    assert tree.body[0].body[0].targets[0].attr == 'y'

